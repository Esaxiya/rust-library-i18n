//! Ókeypis aðgerðir til að búa til `&[T]` og `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Myndar sneið úr bendi og lengd.
///
/// `len` rökin eru fjöldi **þátta**, ekki fjöldi bæti.
///
/// # Safety
///
/// Hegðun er óskilgreind ef brotið er á eftirfarandi skilyrðum:
///
/// * `data` verður að vera [valid] til að lesa fyrir `len * mem::size_of::<T>()` mörg bæti og það verður að vera rétt stillt.Þetta þýðir sérstaklega:
///
///     * Allt minnissvið þessarar sneiðar verður að vera innan eins úthlutaðs hlutar!
///       Sneiðar geta aldrei spannað yfir marga úthlutaða hluti.Sjá [below](#incorrect-usage) fyrir dæmi sem er rangt að taka ekki tillit til þessa.
///     * `data` verður að vera ekki-núll og samræma jafnvel fyrir núll-lengd sneiðar.
///     Ein ástæðan fyrir þessu er sú að fínstillingar enum skipulags geta reitt sig á að tilvísanir (þ.m.t. sneiðar af hvaða lengd sem er) séu samstilltar og ekki núllar til að greina þær frá öðrum gögnum.
///     Þú getur fengið bendi sem er nothæfur sem `data` fyrir sneiðar án lengdar með því að nota [`NonNull::dangling()`].
///
/// * `data` verður að benda á `len` samfellt rétt upphafsgildi af gerðinni `T`.
///
/// * Minniið sem vísað er til af sneiðinni sem er skilað má ekki breyta meðan á ævi `'a` stendur, nema inni í `UnsafeCell`.
///
/// * Heildarstærð `len * mem::size_of::<T>()` sneiðarinnar má ekki vera stærri en `isize::MAX`.
///   Sjá öryggisgögn [`pointer::offset`].
///
/// # Caveat
///
/// Líftími skilaðrar sneiðar er dreginn af notkun þess.
/// Til að koma í veg fyrir misnotkun fyrir slysni er mælt með því að binda líftímann við hvaða uppsprettulíf sem er öruggur í samhenginu, svo sem með því að veita hjálparaðgerð sem tekur líftíma hýsilgildis fyrir sneiðina, eða með skýrum skýringum.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // birtu sneið fyrir einn þátt
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Röng notkun
///
/// Eftirfarandi `join_slices` aðgerð er **óhljóð** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Fullyrðingin hér að ofan tryggir að `fst` og `snd` séu samliggjandi, en þau gætu samt verið innan _different allocated objects_, en í því tilfelli er að búa til þessa sneið óskilgreinda hegðun.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` og `b` eru mismunandi úthlutaðir hlutir ...
///     let a = 42;
///     let b = 27;
///     // ... sem engu að síður má setja samfellt í minningunni: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Framkvæmir sömu virkni og [`from_raw_parts`], nema að breytanlegri sneið er skilað.
///
/// # Safety
///
/// Hegðun er óskilgreind ef brotið er á eftirfarandi skilyrðum:
///
/// * `data` verður að vera [valid] fyrir bæði lestur og skrif fyrir `len * mem::size_of::<T>()` mörg bæti, og það verður að vera rétt stillt.Þetta þýðir sérstaklega:
///
///     * Allt minnissvið þessarar sneiðar verður að vera innan eins úthlutaðs hlutar!
///       Sneiðar geta aldrei spannað yfir marga úthlutaða hluti.
///     * `data` verður að vera ekki-núll og samræma jafnvel fyrir núll-lengd sneiðar.
///     Ein ástæðan fyrir þessu er sú að fínstillingar enum skipulags geta reitt sig á að tilvísanir (þ.m.t. sneiðar af hvaða lengd sem er) séu samstilltar og ekki núllar til að greina þær frá öðrum gögnum.
///
///     Þú getur fengið bendi sem er nothæfur sem `data` fyrir sneiðar án lengdar með því að nota [`NonNull::dangling()`].
///
/// * `data` verður að benda á `len` samfellt rétt upphafsgildi af gerðinni `T`.
///
/// * Ekki má nálgast minnið sem vísað er til með skiluðu sneiðinni í gegnum neinn annan bendil (ekki fenginn frá skilagildinu) meðan á ævi `'a` stendur.
///   Bæði les-og ritaðgangur er bannaður.
///
/// * Heildarstærð `len * mem::size_of::<T>()` sneiðarinnar má ekki vera stærri en `isize::MAX`.
///   Sjá öryggisgögn [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Breytir tilvísun í T í sneið af lengd 1 (án afritunar).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Breytir tilvísun í T í sneið af lengd 1 (án afritunar).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}