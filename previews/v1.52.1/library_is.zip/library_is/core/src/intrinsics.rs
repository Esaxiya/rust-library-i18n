//! Innri eðlisfræði þýðanda.
//!
//! Samsvarandi skilgreiningar eru í `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Samsvarandi útfærslur const eru í `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Innri eðlisfræði
//!
//! Note: Allar breytingar á konstni innri eðlis ætti að ræða við tungumálateymið.
//! Þetta felur í sér breytingar á stöðugleika constness.
//!
//! Til þess að gera innra nothæft á samantektartíma þarf að afrita útfærsluna frá <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> til `compiler/rustc_mir/src/interpret/intrinsics.rs` og bæta `#[rustc_const_unstable(feature = "foo", issue = "01234")]` við innra.
//!
//!
//! Ef ætlað er að nota innri frá `const fn` með eiginleika `rustc_const_stable`, verður eiginleiki innri líka að vera `rustc_const_stable`.
//! Slíka breytingu ætti ekki að gera án T-lang samráðs, vegna þess að hún bakar eiginleika inn á tungumálið sem ekki er hægt að endurtaka í notendakóða án stuðnings þýðanda.
//!
//! # Volatiles
//!
//! Rokgjarnra innra aðila veita aðgerðir sem ætlaðar eru til að starfa á I/O minni, sem örugglega verður ekki endurskipað af þýðandanum yfir aðrar sveiflukenndar innri.Sjá LLVM skjöl á [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Atómþátturinn veitir algengar atómaðgerðir á orðum vélarinnar, með margar mögulegar minnispöntanir.Þeir hlýða sömu merkingarfræði og C++ 11.Sjá LLVM skjöl á [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! A fljótur endurnýjun á minni röð:
//!
//! * Fá, hindrun fyrir að eignast lás.Síðari lestur og ritun á sér stað eftir hindrunina.
//! * Losun, hindrun fyrir losun lás.Fyrri lestur og ritun fer fram fyrir hindrunina.
//! * Seðlabundið stöðugt, röð í röð stöðugt er tryggt að gerast í röð.Þetta er venjulegur háttur til að vinna með lotukerfategundir og jafngildir `volatile` Java.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Þessi innflutningur er notaður til að einfalda tengla innan skjals
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // ÖRYGGI: sjá `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // Athugið að þessi innri hluti tekur hráar vísbendingar vegna þess að þær stökkbreyta alias minni, sem hvorki gildir fyrir `&` né `&mut`.
    //

    /// Geymir gildi ef núverandi gildi er það sama og `old` gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `compare_exchange` aðferðinni með því að fara með [`Ordering::SeqCst`] sem bæði `success` og `failure` breytur.
    ///
    /// Til dæmis, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Geymir gildi ef núverandi gildi er það sama og `old` gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `compare_exchange` aðferðinni með því að fara með [`Ordering::Acquire`] sem bæði `success` og `failure` breytur.
    ///
    /// Til dæmis, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Geymir gildi ef núverandi gildi er það sama og `old` gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `compare_exchange` aðferðinni með því að fara [`Ordering::Release`] sem `success` og [`Ordering::Relaxed`] sem `failure` breytur.
    /// Til dæmis, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Geymir gildi ef núverandi gildi er það sama og `old` gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `compare_exchange` aðferðinni með því að fara [`Ordering::AcqRel`] sem `success` og [`Ordering::Acquire`] sem `failure` breytur.
    /// Til dæmis, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Geymir gildi ef núverandi gildi er það sama og `old` gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `compare_exchange` aðferðinni með því að fara með [`Ordering::Relaxed`] sem bæði `success` og `failure` breytur.
    ///
    /// Til dæmis, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Geymir gildi ef núverandi gildi er það sama og `old` gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `compare_exchange` aðferðinni með því að fara [`Ordering::SeqCst`] sem `success` og [`Ordering::Relaxed`] sem `failure` breytur.
    /// Til dæmis, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Geymir gildi ef núverandi gildi er það sama og `old` gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `compare_exchange` aðferðinni með því að fara [`Ordering::SeqCst`] sem `success` og [`Ordering::Acquire`] sem `failure` breytur.
    /// Til dæmis, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Geymir gildi ef núverandi gildi er það sama og `old` gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `compare_exchange` aðferðinni með því að fara [`Ordering::Acquire`] sem `success` og [`Ordering::Relaxed`] sem `failure` breytur.
    /// Til dæmis, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Geymir gildi ef núverandi gildi er það sama og `old` gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `compare_exchange` aðferðinni með því að fara [`Ordering::AcqRel`] sem `success` og [`Ordering::Relaxed`] sem `failure` breytur.
    /// Til dæmis, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Geymir gildi ef núverandi gildi er það sama og `old` gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `compare_exchange_weak` aðferðinni með því að fara með [`Ordering::SeqCst`] sem bæði `success` og `failure` breytur.
    ///
    /// Til dæmis, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Geymir gildi ef núverandi gildi er það sama og `old` gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `compare_exchange_weak` aðferðinni með því að fara með [`Ordering::Acquire`] sem bæði `success` og `failure` breytur.
    ///
    /// Til dæmis, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Geymir gildi ef núverandi gildi er það sama og `old` gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `compare_exchange_weak` aðferðinni með því að fara [`Ordering::Release`] sem `success` og [`Ordering::Relaxed`] sem `failure` breytur.
    /// Til dæmis, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Geymir gildi ef núverandi gildi er það sama og `old` gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `compare_exchange_weak` aðferðinni með því að fara [`Ordering::AcqRel`] sem `success` og [`Ordering::Acquire`] sem `failure` breytur.
    /// Til dæmis, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Geymir gildi ef núverandi gildi er það sama og `old` gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `compare_exchange_weak` aðferðinni með því að fara með [`Ordering::Relaxed`] sem bæði `success` og `failure` breytur.
    ///
    /// Til dæmis, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Geymir gildi ef núverandi gildi er það sama og `old` gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `compare_exchange_weak` aðferðinni með því að fara [`Ordering::SeqCst`] sem `success` og [`Ordering::Relaxed`] sem `failure` breytur.
    /// Til dæmis, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Geymir gildi ef núverandi gildi er það sama og `old` gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `compare_exchange_weak` aðferðinni með því að fara [`Ordering::SeqCst`] sem `success` og [`Ordering::Acquire`] sem `failure` breytur.
    /// Til dæmis, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Geymir gildi ef núverandi gildi er það sama og `old` gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `compare_exchange_weak` aðferðinni með því að fara [`Ordering::Acquire`] sem `success` og [`Ordering::Relaxed`] sem `failure` breytur.
    /// Til dæmis, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Geymir gildi ef núverandi gildi er það sama og `old` gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `compare_exchange_weak` aðferðinni með því að fara [`Ordering::AcqRel`] sem `success` og [`Ordering::Relaxed`] sem `failure` breytur.
    /// Til dæmis, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Hleður núverandi gildi bendilsins.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `load` aðferðinni með því að fara [`Ordering::SeqCst`] sem `order`.
    /// Til dæmis, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Hleður núverandi gildi bendilsins.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `load` aðferðinni með því að fara [`Ordering::Acquire`] sem `order`.
    /// Til dæmis, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Hleður núverandi gildi bendilsins.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `load` aðferðinni með því að fara [`Ordering::Relaxed`] sem `order`.
    /// Til dæmis, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Geymir gildi á tilgreindum minnisstað.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `store` aðferðinni með því að fara [`Ordering::SeqCst`] sem `order`.
    /// Til dæmis, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Geymir gildi á tilgreindum minnisstað.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `store` aðferðinni með því að fara [`Ordering::Release`] sem `order`.
    /// Til dæmis, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Geymir gildi á tilgreindum minnisstað.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `store` aðferðinni með því að fara [`Ordering::Relaxed`] sem `order`.
    /// Til dæmis, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Geymir gildið á tilgreindum minnisstað og skilar gamla gildinu.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `swap` aðferðinni með því að fara [`Ordering::SeqCst`] sem `order`.
    /// Til dæmis, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Geymir gildið á tilgreindum minnisstað og skilar gamla gildinu.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `swap` aðferðinni með því að fara [`Ordering::Acquire`] sem `order`.
    /// Til dæmis, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Geymir gildið á tilgreindum minnisstað og skilar gamla gildinu.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `swap` aðferðinni með því að fara [`Ordering::Release`] sem `order`.
    /// Til dæmis, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Geymir gildið á tilgreindum minnisstað og skilar gamla gildinu.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `swap` aðferðinni með því að fara [`Ordering::AcqRel`] sem `order`.
    /// Til dæmis, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Geymir gildið á tilgreindum minnisstað og skilar gamla gildinu.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `swap` aðferðinni með því að fara [`Ordering::Relaxed`] sem `order`.
    /// Til dæmis, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bætir við núverandi gildi og skilar fyrra gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `fetch_add` aðferðinni með því að fara [`Ordering::SeqCst`] sem `order`.
    /// Til dæmis, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bætir við núverandi gildi og skilar fyrra gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `fetch_add` aðferðinni með því að fara [`Ordering::Acquire`] sem `order`.
    /// Til dæmis, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bætir við núverandi gildi og skilar fyrra gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `fetch_add` aðferðinni með því að fara [`Ordering::Release`] sem `order`.
    /// Til dæmis, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bætir við núverandi gildi og skilar fyrra gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `fetch_add` aðferðinni með því að fara [`Ordering::AcqRel`] sem `order`.
    /// Til dæmis, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bætir við núverandi gildi og skilar fyrra gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `fetch_add` aðferðinni með því að fara [`Ordering::Relaxed`] sem `order`.
    /// Til dæmis, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Dragðu frá núverandi gildi og skila fyrra gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `fetch_sub` aðferðinni með því að fara [`Ordering::SeqCst`] sem `order`.
    /// Til dæmis, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Dragðu frá núverandi gildi og skila fyrra gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `fetch_sub` aðferðinni með því að fara [`Ordering::Acquire`] sem `order`.
    /// Til dæmis, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Dragðu frá núverandi gildi og skila fyrra gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `fetch_sub` aðferðinni með því að fara [`Ordering::Release`] sem `order`.
    /// Til dæmis, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Dragðu frá núverandi gildi og skila fyrra gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `fetch_sub` aðferðinni með því að fara [`Ordering::AcqRel`] sem `order`.
    /// Til dæmis, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Dragðu frá núverandi gildi og skila fyrra gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `fetch_sub` aðferðinni með því að fara [`Ordering::Relaxed`] sem `order`.
    /// Til dæmis, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitvis og með núverandi gildi, skilar fyrra gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `fetch_and` aðferðinni með því að fara [`Ordering::SeqCst`] sem `order`.
    /// Til dæmis, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis og með núverandi gildi, skilar fyrra gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `fetch_and` aðferðinni með því að fara [`Ordering::Acquire`] sem `order`.
    /// Til dæmis, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis og með núverandi gildi, skilar fyrra gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `fetch_and` aðferðinni með því að fara [`Ordering::Release`] sem `order`.
    /// Til dæmis, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis og með núverandi gildi, skilar fyrra gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `fetch_and` aðferðinni með því að fara [`Ordering::AcqRel`] sem `order`.
    /// Til dæmis, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis og með núverandi gildi, skilar fyrra gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `fetch_and` aðferðinni með því að fara [`Ordering::Relaxed`] sem `order`.
    /// Til dæmis, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitvis nand með núverandi gildi og skilar fyrra gildi.
    ///
    /// Stöðug útgáfa þessa innri er fáanleg á [`AtomicBool`] gerðinni með `fetch_nand` aðferðinni með því að fara [`Ordering::SeqCst`] sem `order`.
    /// Til dæmis, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis nand með núverandi gildi og skilar fyrra gildi.
    ///
    /// Stöðug útgáfa þessa innri er fáanleg á [`AtomicBool`] gerðinni með `fetch_nand` aðferðinni með því að fara [`Ordering::Acquire`] sem `order`.
    /// Til dæmis, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis nand með núverandi gildi og skilar fyrra gildi.
    ///
    /// Stöðug útgáfa þessa innri er fáanleg á [`AtomicBool`] gerðinni með `fetch_nand` aðferðinni með því að fara [`Ordering::Release`] sem `order`.
    /// Til dæmis, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis nand með núverandi gildi og skilar fyrra gildi.
    ///
    /// Stöðug útgáfa þessa innri er fáanleg á [`AtomicBool`] gerðinni með `fetch_nand` aðferðinni með því að fara [`Ordering::AcqRel`] sem `order`.
    /// Til dæmis, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis nand með núverandi gildi og skilar fyrra gildi.
    ///
    /// Stöðug útgáfa þessa innri er fáanleg á [`AtomicBool`] gerðinni með `fetch_nand` aðferðinni með því að fara [`Ordering::Relaxed`] sem `order`.
    /// Til dæmis, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitvis eða með núverandi gildi, skilar fyrra gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `fetch_or` aðferðinni með því að fara [`Ordering::SeqCst`] sem `order`.
    /// Til dæmis, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis eða með núverandi gildi, skilar fyrra gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `fetch_or` aðferðinni með því að fara [`Ordering::Acquire`] sem `order`.
    /// Til dæmis, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis eða með núverandi gildi, skilar fyrra gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `fetch_or` aðferðinni með því að fara [`Ordering::Release`] sem `order`.
    /// Til dæmis, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis eða með núverandi gildi, skilar fyrra gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `fetch_or` aðferðinni með því að fara [`Ordering::AcqRel`] sem `order`.
    /// Til dæmis, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis eða með núverandi gildi, skilar fyrra gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `fetch_or` aðferðinni með því að fara [`Ordering::Relaxed`] sem `order`.
    /// Til dæmis, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitvis xor með núverandi gildi og skilar fyrra gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `fetch_xor` aðferðinni með því að fara [`Ordering::SeqCst`] sem `order`.
    /// Til dæmis, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis xor með núverandi gildi og skilar fyrra gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `fetch_xor` aðferðinni með því að fara [`Ordering::Acquire`] sem `order`.
    /// Til dæmis, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis xor með núverandi gildi og skilar fyrra gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `fetch_xor` aðferðinni með því að fara [`Ordering::Release`] sem `order`.
    /// Til dæmis, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis xor með núverandi gildi og skilar fyrra gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `fetch_xor` aðferðinni með því að fara [`Ordering::AcqRel`] sem `order`.
    /// Til dæmis, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis xor með núverandi gildi og skilar fyrra gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] gerðum með `fetch_xor` aðferðinni með því að fara [`Ordering::Relaxed`] sem `order`.
    /// Til dæmis, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Hámark með núverandi gildi með undirrituðum samanburði.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] undirrituðu heiltölutegundunum með `fetch_max` aðferðinni með því að fara [`Ordering::SeqCst`] sem `order`.
    /// Til dæmis, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Hámark með núverandi gildi með undirrituðum samanburði.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] undirrituðu heiltölutegundunum með `fetch_max` aðferðinni með því að fara [`Ordering::Acquire`] sem `order`.
    /// Til dæmis, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Hámark með núverandi gildi með undirrituðum samanburði.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] undirrituðu heiltölutegundunum með `fetch_max` aðferðinni með því að fara [`Ordering::Release`] sem `order`.
    /// Til dæmis, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Hámark með núverandi gildi með undirrituðum samanburði.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] undirrituðu heiltölutegundunum með `fetch_max` aðferðinni með því að fara [`Ordering::AcqRel`] sem `order`.
    /// Til dæmis, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Hámark með núverandi gildi.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] undirrituðu heiltölutegundunum með `fetch_max` aðferðinni með því að fara [`Ordering::Relaxed`] sem `order`.
    /// Til dæmis, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Lágmark með núverandi gildi með undirrituðum samanburði.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] undirrituðu heiltölutegundunum með `fetch_min` aðferðinni með því að fara [`Ordering::SeqCst`] sem `order`.
    /// Til dæmis, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lágmark með núverandi gildi með undirrituðum samanburði.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] undirrituðu heiltölutegundunum með `fetch_min` aðferðinni með því að fara [`Ordering::Acquire`] sem `order`.
    /// Til dæmis, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lágmark með núverandi gildi með undirrituðum samanburði.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] undirrituðu heiltölutegundunum með `fetch_min` aðferðinni með því að fara [`Ordering::Release`] sem `order`.
    /// Til dæmis, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lágmark með núverandi gildi með undirrituðum samanburði.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] undirrituðu heiltölutegundunum með `fetch_min` aðferðinni með því að fara [`Ordering::AcqRel`] sem `order`.
    /// Til dæmis, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lágmark með núverandi gildi með undirrituðum samanburði.
    ///
    /// Stöðuga útgáfan af þessu innri er fáanleg á [`atomic`] undirrituðu heiltölutegundunum með `fetch_min` aðferðinni með því að fara [`Ordering::Relaxed`] sem `order`.
    /// Til dæmis, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Lágmark með núverandi gildi með óundirrituðum samanburði.
    ///
    /// Stöðug útgáfa þessa innri er fáanleg á [`atomic`] óundirrituðum heiltölutegundum með `fetch_min` aðferðinni með því að fara [`Ordering::SeqCst`] sem `order`.
    /// Til dæmis, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lágmark með núverandi gildi með óundirrituðum samanburði.
    ///
    /// Stöðug útgáfa þessa innri er fáanleg á [`atomic`] óundirrituðum heiltölutegundum með `fetch_min` aðferðinni með því að fara [`Ordering::Acquire`] sem `order`.
    /// Til dæmis, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lágmark með núverandi gildi með óundirrituðum samanburði.
    ///
    /// Stöðug útgáfa þessa innri er fáanleg á [`atomic`] óundirrituðum heiltölutegundum með `fetch_min` aðferðinni með því að fara [`Ordering::Release`] sem `order`.
    /// Til dæmis, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lágmark með núverandi gildi með óundirrituðum samanburði.
    ///
    /// Stöðug útgáfa þessa innri er fáanleg á [`atomic`] óundirrituðum heiltölutegundum með `fetch_min` aðferðinni með því að fara [`Ordering::AcqRel`] sem `order`.
    /// Til dæmis, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Lágmark með núverandi gildi með óundirrituðum samanburði.
    ///
    /// Stöðug útgáfa þessa innri er fáanleg á [`atomic`] óundirrituðum heiltölutegundum með `fetch_min` aðferðinni með því að fara [`Ordering::Relaxed`] sem `order`.
    /// Til dæmis, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Hámark með núverandi gildi með óundirrituðum samanburði.
    ///
    /// Stöðug útgáfa þessa innri er fáanleg á [`atomic`] óundirrituðum heiltölutegundum með `fetch_max` aðferðinni með því að fara [`Ordering::SeqCst`] sem `order`.
    /// Til dæmis, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Hámark með núverandi gildi með óundirrituðum samanburði.
    ///
    /// Stöðug útgáfa þessa innri er fáanleg á [`atomic`] óundirrituðum heiltölutegundum með `fetch_max` aðferðinni með því að fara [`Ordering::Acquire`] sem `order`.
    /// Til dæmis, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Hámark með núverandi gildi með óundirrituðum samanburði.
    ///
    /// Stöðug útgáfa þessa innri er fáanleg á [`atomic`] óundirrituðum heiltölutegundum með `fetch_max` aðferðinni með því að fara [`Ordering::Release`] sem `order`.
    /// Til dæmis, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Hámark með núverandi gildi með óundirrituðum samanburði.
    ///
    /// Stöðug útgáfa þessa innri er fáanleg á [`atomic`] óundirrituðum heiltölutegundum með `fetch_max` aðferðinni með því að fara [`Ordering::AcqRel`] sem `order`.
    /// Til dæmis, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Hámark með núverandi gildi með óundirrituðum samanburði.
    ///
    /// Stöðug útgáfa þessa innri er fáanleg á [`atomic`] óundirrituðum heiltölutegundum með `fetch_max` aðferðinni með því að fara [`Ordering::Relaxed`] sem `order`.
    /// Til dæmis, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// `prefetch` innri er vísbending við kóðagerðina til að setja inn forhæfingarleiðbeiningar ef hún er studd;annars er það nei-op.
    /// Forhæfingar hafa engin áhrif á hegðun forritsins en geta breytt frammistöðu eiginleikum þess.
    ///
    /// `locality` rökin verða að vera stöðug heildartala og er tímabundið staðsetningarskilgrein, allt frá (0), ekkert staðhátt, til (3), mjög staðbundið í skyndiminni.
    ///
    ///
    /// Þetta innri hefur ekki stöðugan hliðstæðu.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// `prefetch` innri er vísbending við kóðagerðina til að setja inn forhæfingarleiðbeiningar ef hún er studd;annars er það nei-op.
    /// Forhæfingar hafa engin áhrif á hegðun forritsins en geta breytt frammistöðu eiginleikum þess.
    ///
    /// `locality` rökin verða að vera stöðug heildartala og er tímabundið staðsetningarskilgrein, allt frá (0), ekkert staðhátt, til (3), mjög staðbundið í skyndiminni.
    ///
    ///
    /// Þetta innri hefur ekki stöðugan hliðstæðu.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// `prefetch` innri er vísbending við kóðagerðina til að setja inn forhæfingarleiðbeiningar ef hún er studd;annars er það nei-op.
    /// Forhæfingar hafa engin áhrif á hegðun forritsins en geta breytt frammistöðu eiginleikum þess.
    ///
    /// `locality` rökin verða að vera stöðug heildartala og er tímabundið staðsetningarskilgrein, allt frá (0), ekkert staðhátt, til (3), mjög staðbundið í skyndiminni.
    ///
    ///
    /// Þetta innri hefur ekki stöðugan hliðstæðu.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// `prefetch` innri er vísbending við kóðagerðina til að setja inn forhæfingarleiðbeiningar ef hún er studd;annars er það nei-op.
    /// Forhæfingar hafa engin áhrif á hegðun forritsins en geta breytt frammistöðu eiginleikum þess.
    ///
    /// `locality` rökin verða að vera stöðug heildartala og er tímabundið staðsetningarskilgrein, allt frá (0), ekkert staðhátt, til (3), mjög staðbundið í skyndiminni.
    ///
    ///
    /// Þetta innri hefur ekki stöðugan hliðstæðu.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Atómgirðing.
    ///
    /// Stöðug útgáfa þessa innri er fáanleg í [`atomic::fence`] með því að fara [`Ordering::SeqCst`] sem `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Atómgirðing.
    ///
    /// Stöðug útgáfa þessa innri er fáanleg í [`atomic::fence`] með því að fara [`Ordering::Acquire`] sem `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Atómgirðing.
    ///
    /// Stöðug útgáfa þessa innri er fáanleg í [`atomic::fence`] með því að fara [`Ordering::Release`] sem `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Atómgirðing.
    ///
    /// Stöðug útgáfa þessa innri er fáanleg í [`atomic::fence`] með því að fara [`Ordering::AcqRel`] sem `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Minnishindrun eingöngu þýðandi.
    ///
    /// Aðgangur að minni verður aldrei endurskipulagður yfir þessa hindrun af þýðandanum, en engar leiðbeiningar verða gefnar út um það.
    /// Þetta er viðeigandi fyrir aðgerðir á sama þræði sem hægt er að forvera, svo sem þegar um er að ræða samskipti við merkiaðila.
    ///
    /// Stöðug útgáfa þessa innri er fáanleg í [`atomic::compiler_fence`] með því að fara [`Ordering::SeqCst`] sem `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Minnishindrun eingöngu þýðandi.
    ///
    /// Aðgangur að minni verður aldrei endurskipulagður yfir þessa hindrun af þýðandanum, en engar leiðbeiningar verða gefnar út um það.
    /// Þetta er viðeigandi fyrir aðgerðir á sama þræði sem hægt er að forvera, svo sem þegar um er að ræða samskipti við merkiaðila.
    ///
    /// Stöðug útgáfa þessa innri er fáanleg í [`atomic::compiler_fence`] með því að fara [`Ordering::Acquire`] sem `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Minnishindrun eingöngu þýðandi.
    ///
    /// Aðgangur að minni verður aldrei endurskipulagður yfir þessa hindrun af þýðandanum, en engar leiðbeiningar verða gefnar út um það.
    /// Þetta er viðeigandi fyrir aðgerðir á sama þræði sem hægt er að forvera, svo sem þegar um er að ræða samskipti við merkiaðila.
    ///
    /// Stöðug útgáfa þessa innri er fáanleg í [`atomic::compiler_fence`] með því að fara [`Ordering::Release`] sem `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Minnishindrun eingöngu þýðandi.
    ///
    /// Aðgangur að minni verður aldrei endurskipulagður yfir þessa hindrun af þýðandanum, en engar leiðbeiningar verða gefnar út um það.
    /// Þetta er viðeigandi fyrir aðgerðir á sama þræði sem hægt er að forvera, svo sem þegar um er að ræða samskipti við merkiaðila.
    ///
    /// Stöðug útgáfa þessa innri er fáanleg í [`atomic::compiler_fence`] með því að fara [`Ordering::AcqRel`] sem `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Galdur innra með sér sem dregur merkingu sína frá eiginleikum sem fylgja aðgerðinni.
    ///
    /// Til dæmis notar gagnaflæði þetta til að sprauta kyrrstæðum fullyrðingum þannig að `rustc_peek(potentially_uninitialized)` myndi raunverulega tvöfalda athugun á því að gagnaflæðið hafi örugglega reiknað út að það hafi ekki verið endurvirkt á þeim tímapunkti í stjórnflæðinu.
    ///
    ///
    /// Þetta innri ætti ekki að nota utan þýðandans.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Hættir við framkvæmd ferlisins.
    ///
    /// Notendavænni og stöðugri útgáfa af þessari aðgerð er [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Lætur hagræðingartækið vita að ekki sé hægt að ná þessum punkti í kóðanum, sem gerir frekari hagræðingu kleift.
    ///
    /// NB, þetta er mjög frábrugðið `unreachable!()` fjölvi: Ólíkt makróinu, sem panics þegar það er framkvæmt, þá er það *óskilgreint atferli* að ná til kóða sem er merktur með þessari aðgerð.
    ///
    ///
    /// Stöðug útgáfa þessa innri er [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Tilkynnir hagræðingarmanninn að ástand sé alltaf satt.
    /// Ef skilyrðið er rangt er hegðunin óskilgreind.
    ///
    /// Enginn kóði er búinn til fyrir þetta innra, en hagræðingaraðilinn reynir að varðveita hann (og ástand hans) milli leiða, sem getur truflað hagræðingu á nærliggjandi kóða og dregið úr afköstum.
    /// Það ætti ekki að nota ef hagræðingaraðilinn getur uppgötvað undantekningargjafann á eigin spýtur eða ef hann virkjar ekki verulega hagræðingu.
    ///
    /// Þetta innri hefur ekki stöðugan hliðstæðu.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Vísbendingar til þýðandans um að líklegt sé að branch ástand sé rétt.
    /// Skilar gildi sem var sent til þess.
    ///
    /// Öll notkun önnur en með `if` yfirlýsingum mun líklega ekki hafa áhrif.
    ///
    /// Þetta innri hefur ekki stöðugan hliðstæðu.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Vísbending til þýðandans að líklegt sé að branch ástand sé rangt.
    /// Skilar gildi sem var sent til þess.
    ///
    /// Öll notkun önnur en með `if` yfirlýsingum mun líklega ekki hafa áhrif.
    ///
    /// Þetta innri hefur ekki stöðugan hliðstæðu.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Framkvæmir brotstigagildru, til skoðunar hjá kembiforritara.
    ///
    /// Þetta innri hefur ekki stöðugan hliðstæðu.
    pub fn breakpoint();

    /// Stærð tegundar í bæti.
    ///
    /// Nánar tiltekið er þetta móti í bætum á milli eftirliggjandi atriða af sömu gerð, þ.m.t.
    ///
    ///
    /// Stöðug útgáfa þessa innri er [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Lágmarks röðun tegundar.
    ///
    /// Stöðug útgáfa þessa innri er [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Æskileg röðun tegundar.
    ///
    /// Þetta innri hefur ekki stöðugan hliðstæðu.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Stærð gildisins sem vísað er til í bæti.
    ///
    /// Stöðug útgáfa þessa innri er [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Nauðsynleg röðun á gildinu sem vísað er til.
    ///
    /// Stöðug útgáfa þessa innri er [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Fær truflaða sneið sem inniheldur nafn tegundar.
    ///
    /// Stöðug útgáfa þessa innri er [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Fær auðkenni sem er á heimsvísu einstakt fyrir tilgreinda tegund.
    /// Þessi aðgerð skilar sama gildi fyrir gerð óháð því hvaða crate hún er kölluð til.
    ///
    ///
    /// Stöðug útgáfa þessa innri er [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Vörður fyrir óörugga aðgerðir sem aldrei er hægt að framkvæma ef `T` er óbyggður:
    /// Þetta mun statískt annaðhvort panic, eða gera ekki neitt.
    ///
    /// Þetta innri hefur ekki stöðugan hliðstæðu.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Vörður fyrir óörugga aðgerðir sem aldrei er hægt að framkvæma ef `T` leyfir ekki frumstillingu núll: Þetta mun stöðugt annaðhvort panic, eða gerir ekki neitt.
    ///
    ///
    /// Þetta innri hefur ekki stöðugan hliðstæðu.
    pub fn assert_zero_valid<T>();

    /// Vörður fyrir óöruggar aðgerðir sem aldrei er hægt að framkvæma ef `T` hefur ógild bitamynstur: Þetta mun statískt annað hvort panic, eða gerir ekki neitt.
    ///
    ///
    /// Þetta innri hefur ekki stöðugan hliðstæðu.
    pub fn assert_uninit_valid<T>();

    /// Fær tilvísun í kyrrstöðu `Location` sem gefur til kynna hvar það var kallað.
    ///
    /// Íhugaðu að nota [`core::panic::Location::caller`](crate::panic::Location::caller) í staðinn.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Færir gildi utan gildissviðs án þess að keyra dropalím.
    ///
    /// Þetta er eingöngu til fyrir [`mem::forget_unsized`];venjulegur `forget` notar `ManuallyDrop` í staðinn.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Endurtúlkar bitana á gildi af einni gerð sem aðra tegund.
    ///
    /// Báðar gerðirnar verða að hafa sömu stærð.
    /// Hvorki frumritið né niðurstaðan geta verið [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` jafngildir merkingarfræðilega svolítið hreyfingu af einni gerð í aðra.Það afritar bitana frá upprunagildinu í ákvörðunargildið og gleymir síðan frumritinu.
    /// Það jafngildir `memcpy` C undir hettunni, rétt eins og `transmute_copy`.
    ///
    /// Þar sem `transmute` er aukagildi er röðun *umbreyttu gilda sjálfra* ekki áhyggjuefni.
    /// Eins og með allar aðrar aðgerðir, tryggir þýðandinn þegar að bæði `T` og `U` eru rétt stilltir saman.
    /// Hins vegar, þegar send gildi eru sem *vísa annað*(svo sem vísbendingar, tilvísanir, kassar ...), verður sá sem hringir að tryggja rétta aðlögun á þeim gildum sem bent er til.
    ///
    /// `transmute` er **ótrúlega** óöruggur.Það eru mjög margar leiðir til að valda [undefined behavior][ub] með þessari aðgerð.`transmute` ætti að vera alger síðasta úrræði.
    ///
    /// [nomicon](../../nomicon/transmutes.html) hefur viðbótargögn.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Það eru nokkur atriði sem `transmute` nýtist mjög vel.
    ///
    /// Að breyta bendi í aðgerðabenda.Þetta er *ekki* færanlegt í vélar þar sem virka ábendingar og gagnabendir hafa mismunandi stærðir.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Að lengja ævi, eða stytta óbreyttan ævi.Þetta er langt gengið, mjög óöruggt Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Ekki örvænta: marga notkun `transmute` er hægt að ná með öðrum hætti.
    /// Hér að neðan eru algeng forrit `transmute` sem hægt er að skipta út fyrir öruggari smíðar.
    ///
    /// Að breyta hráum bytes(`&[u8]`) í `u32`, `f64` osfrv .:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // notaðu `u32::from_ne_bytes` í staðinn
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // eða notaðu `u32::from_le_bytes` eða `u32::from_be_bytes` til að tilgreina endanleika
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Að breyta bendi í `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Notaðu `as` leikara í staðinn
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Að breyta `*mut T` í `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Notaðu endurlán í staðinn
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Að breyta `&mut T` í `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Nú skaltu setja saman `as` og endurlána, athugaðu að keðjan á `as` `as` er ekki tímabundin
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Að breyta `&str` í `&[u8]`:
    ///
    /// ```
    /// // þetta er ekki góð leið til að gera þetta.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Þú gætir notað `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Eða notaðu bara bítastreng, ef þú hefur stjórn á strengnum bókstaflega
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Að breyta `Vec<&T>` í `Vec<Option<&T>>`.
    ///
    /// Til að umbreyta innri gerð innihalds íláts verður þú að gæta þess að brjóta ekki í bága við innflytjendur ílátsins.
    /// Fyrir `Vec` þýðir þetta að bæði stærð *og röðun* innri gerða þarf að passa.
    /// Aðrir gámar gætu reitt sig á stærð gerðarinnar, röðunina eða jafnvel `TypeId`, en þá væri ekki mögulegt að umbreyta án þess að brjóta í bága við ílátin.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // klóna vector þar sem við munum endurnýta þá síðar
    /// let v_clone = v_orig.clone();
    ///
    /// // Að nota transmute: þetta reiðir sig á ótilgreint gagnaskipulag `Vec`, sem er slæm hugmynd og gæti valdið óskilgreindri hegðun.
    /////
    /// // Hins vegar er það ekkert eintak.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Þetta er leiðbeinandi, örugg leið.
    /// // Það afritar þó allan vector í nýtt fylki.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Þetta er rétti, óöruggi og ótryggi hátturinn við "transmuting" og `Vec`, án þess að treysta á gagnaskipan.
    /// // Í stað þess að hringja bókstaflega í `transmute`, framkvæmum við bendilinn, en hvað varðar að breyta upphaflegu innri gerðinni (`&i32`) í þann nýja (`Option<&i32>`), þá hefur þetta alla sömu fyrirvara.
    /////
    /// // Fyrir utan upplýsingarnar sem gefnar eru hér að ofan, skoðaðu einnig [`from_raw_parts`] skjölin.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Uppfærðu þetta þegar vec_into_raw_parts er stöðugt.
    ///     // Gakktu úr skugga um að upprunalega vector sé ekki sleppt.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Útfærsla `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Það eru margar leiðir til að gera þetta og það eru mörg vandamál með eftirfarandi (transmute) leið.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // í fyrsta lagi: transmute er ekki tegund öruggt;allt sem það athugar er að T og
    ///         // Þú ert af sömu stærð.
    ///         // Í öðru lagi, hérna, ert þú með tvær breytilegar tilvísanir sem benda til sömu minni.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Þetta losnar við öryggisvandamálin af gerðinni;`&mut *` mun* aðeins *gefa þér `&mut T` frá `&mut T` eða `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // þó, þú ert ennþá með tvær breytilegar tilvísanir sem benda á sama minni.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Svona gerir venjulega bókasafnið það.
    /// // Þetta er besta aðferðin, ef þú þarft að gera eitthvað svona
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Þetta hefur nú þrjár breytilegar tilvísanir sem benda á sama minni.`slice`, rvalue ret.0 og rvalue ret.1.
    ///         // `slice` er aldrei notað eftir `let ptr = ...`, og því er hægt að meðhöndla það sem "dead", og þess vegna hefurðu aðeins tvær raunverulegar breytilegar sneiðar.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Þó að þetta geri innri stöðugleika stöðugan, þá höfum við einhvern sérsniðinn kóða í const fn
    // ávísanir sem koma í veg fyrir notkun þess innan `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Skilar `true` ef raunveruleg tegund gefin upp sem `T` krefst dropalím;skilar `false` ef raunveruleg tegund sem gefin er fyrir `T` útfærir `Copy`.
    ///
    ///
    /// Ef raunverulega gerð hvorki þarf dropalím né útfærir `Copy`, þá er skilagildi þessarar aðgerð ótilgreint.
    ///
    /// Stöðug útgáfa þessa innri er [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Reiknar frávik frá bendi.
    ///
    /// Þetta er útfært sem innra til að forðast að umbreyta til og frá heiltölu, þar sem umbreytingin myndi henda aliasing upplýsingum.
    ///
    /// # Safety
    ///
    /// Bæði upphafs bendillinn og sá sem myndast verður að vera annað hvort í mörkum eða einu bæti framhjá loki úthlutaðs hlutar.
    /// Ef annar hvor bendillinn er utan marka eða reikniflæði kemur fram þá mun frekari notkun skilagildisins leiða til óskilgreindrar hegðunar.
    ///
    ///
    /// Stöðug útgáfa þessa innri er [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Reiknar móti frá bendi, hugsanlega umbúðir.
    ///
    /// Þetta er útfært sem innra til að forðast að umbreyta til og frá heiltölu, þar sem umbreytingin hamlar ákveðnum hagræðingum.
    ///
    /// # Safety
    ///
    /// Ólíkt `offset` innra, takmarkar þetta innri ekki bendilinn sem myndast til að benda í eða eitt bæti framhjá enda úthlutaðs hlutar, og hann vafinn með reiknifræði tveggja viðbótar.
    /// Gildið sem myndast er ekki endilega rétt til að nota til að fá raunverulega aðgang að minni.
    ///
    /// Stöðug útgáfa þessa innri er [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Jafngildir viðeigandi `llvm.memcpy.p0i8.0i8.*` innra með stærðinni `count`*`size_of::<T>()` og röðun
    ///
    /// `min_align_of::<T>()`
    ///
    /// Rokgjarn breytu er stillt á `true`, þannig að hún verður ekki bjartsýni nema stærðin sé jöfn núll.
    ///
    /// Þetta innri hefur ekki stöðugan hliðstæðu.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Jafngildir viðeigandi innri `llvm.memmove.p0i8.0i8.*`, með stærðina `count* size_of::<T>()` og uppstillingu
    ///
    /// `min_align_of::<T>()`
    ///
    /// Rokgjarn breytu er stillt á `true`, þannig að hún verður ekki bjartsýni nema stærðin sé jöfn núll.
    ///
    /// Þetta innri hefur ekki stöðugan hliðstæðu.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Jafngildir viðeigandi `llvm.memset.p0i8.*` innra með stærðinni `count* size_of::<T>()` og röðun `min_align_of::<T>()`.
    ///
    ///
    /// Rokgjarn breytu er stillt á `true`, þannig að hún verður ekki bjartsýni nema stærðin sé jöfn núll.
    ///
    /// Þetta innri hefur ekki stöðugan hliðstæðu.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Framkvæmir rokgjarnt álag frá `src` bendlinum.
    ///
    /// Stöðug útgáfa þessa innri er [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Framkvæmir rokgjarnan búð við `dst` bendilinn.
    ///
    /// Stöðug útgáfa þessa innri er [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Framkvæmir rokgjarnt álag frá `src` bendlinum Ekki er nauðsynlegt að bendillinn sé stilltur.
    ///
    ///
    /// Þetta innri hefur ekki stöðugan hliðstæðu.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Framkvæmir rokgjarnan búð við `dst` bendilinn.
    /// Ekki er krafist þess að bendillinn sé stilltur.
    ///
    /// Þetta innri hefur ekki stöðugan hliðstæðu.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Skilar kvaðratrót `f32`
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Skilar kvaðratrót `f64`
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Hækkar `f32` í heiltöluafl.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Hækkar `f64` í heiltöluafl.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Skilar sinus `f32`.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Skilar sinus `f64`.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Skilar kósínusi `f32`.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Skilar kósínusi `f64`.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Hækkar `f32` í `f32` afl.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Hækkar `f64` í `f64` afl.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Skilar veldisvísitölu `f32`.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Skilar veldisvísitölu `f64`.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Skilar 2 hækkað í krafti `f32`.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Skilar 2 hækkað í krafti `f64`.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Skilar náttúrulegum lógaritma `f32`.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Skilar náttúrulegum lógaritma `f64`.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Skilar grunn 10 lógaritmi `f32`.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Skilar grunn 10 lógaritmi `f64`.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Skilar grunn 2 lógaritmi `f32`.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Skilar grunn 2 lógaritmi `f64`.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Skilar `a * b + c` fyrir `f32` gildi.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Skilar `a * b + c` fyrir `f64` gildi.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Skilar algeru gildi `f32`.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Skilar algeru gildi `f64`.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Skilar lágmarki tveggja `f32` gildi.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Skilar lágmarki tveggja `f64` gildi.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Skilar hámarki tveggja `f32` gildi.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Skilar hámarki tveggja `f64` gildi.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Afritar skiltið frá `y` til `x` fyrir `f32` gildi.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Afritar skiltið frá `y` til `x` fyrir `f64` gildi.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Skilar stærstu heiltölu minna en eða jafnt og `f32`.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Skilar stærstu heiltölu minna en eða jafnt og `f64`.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Skilar minnstu heiltölu sem er stærri en eða jafnt og `f32`.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Skilar minnstu heiltölu sem er stærri en eða jafnt og `f64`.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Skilar heiltöluhluta `f32`.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Skilar heiltöluhluta `f64`.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Skilar næstu heiltölu við `f32`.
    /// Getur hækkað ónákvæmar undantekningar á flotpunkti ef rökin eru ekki heiltala.
    pub fn rintf32(x: f32) -> f32;
    /// Skilar næstu heiltölu við `f64`.
    /// Getur hækkað ónákvæmar undantekningar á flotpunkti ef rökin eru ekki heiltala.
    pub fn rintf64(x: f64) -> f64;

    /// Skilar næstu heiltölu við `f32`.
    ///
    /// Þetta innri hefur ekki stöðugan hliðstæðu.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Skilar næstu heiltölu við `f64`.
    ///
    /// Þetta innri hefur ekki stöðugan hliðstæðu.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Skilar næstu heiltölu við `f32`.Veltir hálfum málum frá núlli.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Skilar næstu heiltölu við `f64`.Veltir hálfum málum frá núlli.
    ///
    /// Stöðug útgáfa þessa innri er
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Float viðbót sem leyfir hagræðingu byggða á algebru reglum.
    /// Getur gert ráð fyrir að aðföng séu endanleg.
    ///
    /// Þetta innri hefur ekki stöðugan hliðstæðu.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Flot frádráttur sem leyfir hagræðingu byggða á algebrulegum reglum.
    /// Getur gert ráð fyrir að aðföng séu endanleg.
    ///
    /// Þetta innri hefur ekki stöðugan hliðstæðu.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Margföldun á floti sem leyfir hagræðingu byggða á algebrulegum reglum.
    /// Getur gert ráð fyrir að aðföng séu endanleg.
    ///
    /// Þetta innri hefur ekki stöðugan hliðstæðu.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Flotaskipting sem leyfir hagræðingu byggða á algebrulegum reglum.
    /// Getur gert ráð fyrir að aðföng séu endanleg.
    ///
    /// Þetta innri hefur ekki stöðugan hliðstæðu.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Flotafgang sem leyfir hagræðingu byggða á algebrulegum reglum.
    /// Getur gert ráð fyrir að aðföng séu endanleg.
    ///
    /// Þetta innri hefur ekki stöðugan hliðstæðu.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Umreiknaðu með fptoui/fptosi LLVM, sem getur skilað undef fyrir gildi utan sviðs
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Stöðugt sem [`f32::to_int_unchecked`] og [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Skilar fjölda bita sem er stilltur í heiltölu gerð `T`
    ///
    /// Stöðugu útgáfurnar af þessu innri eru fáanlegar á frumtölum heiltölunnar með `count_ones` aðferðinni.
    /// Til dæmis,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Skilar fjölda leiðandi ósettra bita (zeroes) í heiltölu `T`.
    ///
    /// Stöðugu útgáfurnar af þessu innri eru fáanlegar á frumtölum heiltölunnar með `leading_zeros` aðferðinni.
    /// Til dæmis,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `x` með gildi `0` mun skila bitabreiddinni `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Eins og `ctlz`, en aukalega óöruggur þar sem hann skilar `undef` þegar gefinn er `x` með gildi `0`.
    ///
    ///
    /// Þetta innri hefur ekki stöðugan hliðstæðu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Skilar fjölda ósamsettra bita (zeroes) í heiltölu `T`.
    ///
    /// Stöðugu útgáfurnar af þessu innri eru fáanlegar á frumtölum heiltölunnar með `trailing_zeros` aðferðinni.
    /// Til dæmis,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `x` með gildi `0` mun skila bitabreidd `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Eins og `cttz`, en aukalega óöruggur þar sem hann skilar `undef` þegar gefinn er `x` með gildi `0`.
    ///
    ///
    /// Þetta innri hefur ekki stöðugan hliðstæðu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Snýr bætunum við í heiltölu gerð `T`.
    ///
    /// Stöðugu útgáfurnar af þessu innri eru fáanlegar á frumtölum heiltölunnar með `swap_bytes` aðferðinni.
    /// Til dæmis,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Snýr bitunum við í heiltölu gerð `T`.
    ///
    /// Stöðugu útgáfurnar af þessu innri eru fáanlegar á frumtölum heiltölunnar með `reverse_bits` aðferðinni.
    /// Til dæmis,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Framkvæma merkta heiltölu viðbót.
    ///
    /// Stöðugu útgáfurnar af þessu innri eru fáanlegar á frumtölum heiltölunnar með `overflowing_add` aðferðinni.
    /// Til dæmis,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Framkvæma merkt heiltala frádrátt
    ///
    /// Stöðugu útgáfurnar af þessu innri eru fáanlegar á frumtölum heiltölunnar með `overflowing_sub` aðferðinni.
    /// Til dæmis,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Framkvæma merkta margföldun
    ///
    /// Stöðugu útgáfurnar af þessu innri eru fáanlegar á frumtölum heiltölunnar með `overflowing_mul` aðferðinni.
    /// Til dæmis,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Framkvæmir nákvæma skiptingu sem leiðir til óskilgreindrar hegðunar þar sem `x % y != 0` eða `y == 0` eða `x == T::MIN && y == -1`
    ///
    ///
    /// Þetta innri hefur ekki stöðugan hliðstæðu.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Framkvæmir ómerkta skiptingu, sem leiðir til óskilgreindrar hegðunar þar sem `y == 0` eða `x == T::MIN && y == -1`
    ///
    ///
    /// Öruggar umbúðir fyrir þessa innri eru fáanlegar á frumtölum heiltölunnar með `checked_div` aðferðinni.
    /// Til dæmis,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Skilar afganginum af ómerktri skiptingu, sem leiðir til óskilgreindrar hegðunar þegar `y == 0` eða `x == T::MIN && y == -1`
    ///
    ///
    /// Öruggar umbúðir fyrir þessa innri eru fáanlegar á frumtölum heiltölunnar með `checked_rem` aðferðinni.
    /// Til dæmis,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Framkvæmir ómerkta vinstri vakt, sem leiðir til óskilgreindrar hegðunar þegar `y < 0` eða `y >= N`, þar sem N er breidd T í bitum.
    ///
    ///
    /// Öruggar umbúðir fyrir þessa innri eru fáanlegar á frumtölum heiltölunnar með `checked_shl` aðferðinni.
    /// Til dæmis,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Framkvæmir ómerkt hægri vakt sem leiðir til óskilgreindrar hegðunar þegar `y < 0` eða `y >= N`, þar sem N er breidd T í bitum.
    ///
    ///
    /// Öruggar umbúðir fyrir þessa innri eru fáanlegar á frumtölum heiltölunnar með `checked_shr` aðferðinni.
    /// Til dæmis,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Skilar niðurstöðu ómerktrar viðbótar, sem leiðir til óskilgreindrar hegðunar þegar `x + y > T::MAX` eða `x + y < T::MIN`.
    ///
    ///
    /// Þetta innri hefur ekki stöðugan hliðstæðu.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Skilar niðurstöðu ómerktrar frádráttar sem leiðir til óskilgreindrar hegðunar þegar `x - y > T::MAX` eða `x - y < T::MIN`.
    ///
    ///
    /// Þetta innri hefur ekki stöðugan hliðstæðu.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Skilar niðurstöðu ómerktrar margföldunar, sem leiðir til óskilgreindrar hegðunar þegar `x *y > T::MAX` eða `x* y < T::MIN`.
    ///
    ///
    /// Þetta innri hefur ekki stöðugan hliðstæðu.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Framkvæmir snúa til vinstri.
    ///
    /// Stöðugu útgáfurnar af þessu innri eru fáanlegar á frumtölum heiltölunnar með `rotate_left` aðferðinni.
    /// Til dæmis,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Framkvæmir snúa til hægri.
    ///
    /// Stöðugu útgáfurnar af þessu innri eru fáanlegar á frumtölum heiltölunnar með `rotate_right` aðferðinni.
    /// Til dæmis,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Skilar (a + b) mod 2 <sup>N</sup>, þar sem N er breidd T í bitum.
    ///
    /// Stöðugu útgáfurnar af þessu innri eru fáanlegar á frumtölum heiltölunnar með `wrapping_add` aðferðinni.
    /// Til dæmis,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Skilar (a, b) mod 2 <sup>N</sup>, þar sem N er breidd T í bitum.
    ///
    /// Stöðugu útgáfurnar af þessu innri eru fáanlegar á frumtölum heiltölunnar með `wrapping_sub` aðferðinni.
    /// Til dæmis,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Skilar (a * b) mod 2 <sup>N</sup>, þar sem N er breidd T í bitum.
    ///
    /// Stöðugu útgáfurnar af þessu innri eru fáanlegar á frumtölum heiltölunnar með `wrapping_mul` aðferðinni.
    /// Til dæmis,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Reiknar `a + b`, mettandi við töluleg mörk.
    ///
    /// Stöðugu útgáfurnar af þessu innri eru fáanlegar á frumtölum heiltölunnar með `saturating_add` aðferðinni.
    /// Til dæmis,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Reiknar `a - b`, mettandi við töluleg mörk.
    ///
    /// Stöðugu útgáfurnar af þessu innri eru fáanlegar á frumtölum heiltölunnar með `saturating_sub` aðferðinni.
    /// Til dæmis,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Skilar gildi mismununar fyrir afbrigðið í 'v';
    /// ef `T` hefur engan mismunun, skilar `0`.
    ///
    /// Stöðug útgáfa þessa innri er [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Skilar fjölda afbrigða af gerðinni `T` sem steypt er í `usize`;
    /// ef `T` hefur engin afbrigði, skilar `0`.Óbyggð afbrigði verða talin.
    ///
    /// Til að vera stöðug útgáfa af þessu innri er [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// "try catch" uppbygging Rust sem kallar á aðgerðabendilinn `try_fn` með gagnabendlinum `data`.
    ///
    /// Þriðju rökin eru fall sem kallast ef panic á sér stað.
    /// Þessi aðgerð tekur gagnabendilinn og bendilinn að þeim markmiðssértæka undantekningarhlut sem var gripinn.
    ///
    /// Nánari upplýsingar er að finna í upptökum þýðandans sem og aflaútfærslu std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Sendir frá `!nontemporal` verslun samkvæmt LLVM (sjá skjöl þeirra).
    /// Verður líklega aldrei stöðugt.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Sjá upplýsingar um `<*const T>::offset_from` fyrir frekari upplýsingar.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Sjá upplýsingar um `<*const T>::guaranteed_eq` fyrir frekari upplýsingar.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Sjá upplýsingar um `<*const T>::guaranteed_ne` fyrir frekari upplýsingar.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Úthluta á samantektartíma.Ætti ekki að hringja í keyrslu.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Sumar aðgerðir eru skilgreindar hér vegna þess að þær voru óvart gerðar aðgengilegar í þessari einingu á stöðugum.
// Sjá <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` fellur einnig í þennan flokk en það er ekki hægt að pakka því vegna athugunar á því að `T` og `U` hafi sömu stærð.)
//

/// Athugar hvort `ptr` sé rétt stillt miðað við `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Afritar `count *size_of::<T>()` bæti frá `src` til `dst`.Uppruni og ákvörðunarstaður mega* ekki * skarast.
///
/// Notaðu [`copy`] í staðinn fyrir minni svæði sem gætu skarast.
///
/// `copy_nonoverlapping` jafngildir merkingarlega [`memcpy`] C, en með röksemdafærslunni skipt.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Hegðun er óskilgreind ef brotið er á eftirfarandi skilyrðum:
///
/// * `src` verður að vera [valid] til að lesa `count * size_of::<T>()` bæti.
///
/// * `dst` verður að vera [valid] til að skrifa `count * size_of::<T>()` bæti.
///
/// * Bæði `src` og `dst` verða að vera rétt samstillt.
///
/// * Svæðið um minni sem byrjar á `src` með stærðina 'telja *
///   stærð_ af: :<T>() `bæti mega *ekki* skarast við það svæði minni sem byrjar á `dst` af sömu stærð.
///
/// Eins og [`read`] býr `copy_nonoverlapping` til bitvis afrit af `T`, óháð því hvort `T` er [`Copy`].
/// Ef `T` er ekki [`Copy`], geturðu notað *bæði* gildin á svæðinu sem byrja á `*src` og svæðið sem byrjar á `* dst` getur [violate memory safety][read-ownership].
///
///
/// Athugaðu að jafnvel þótt afritaða stærðin sé virk (`telja * stærð_of: :<T>()`) er `0`, ábendingar verða að vera ekki NULL og rétt stilltar.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Útfærðu [`Vec::append`] handvirkt:
///
/// ```
/// use std::ptr;
///
/// /// Færir alla þætti `src` yfir í `dst` og skilur `src` eftir tómt.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Gakktu úr skugga um að `dst` hafi næga getu til að halda öllum `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Símtalið til jöfnunar er alltaf öruggt vegna þess að `Vec` mun aldrei úthluta meira en `isize::MAX` bæti.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Styttu `src` án þess að láta innihald hennar falla.
///         // Við gerum þetta fyrst, til að forðast vandamál ef eitthvað er lengra niður í panics.
///         src.set_len(0);
///
///         // Svæðin tvö geta ekki skarast vegna þess að breytanlegar tilvísanir eru ekki alias og tveir mismunandi vectors geta ekki átt sömu minni.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Tilkynntu `dst` um að það geymi nú innihald `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Framkvæmdu þessar athuganir aðeins á hlaupatíma
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Ekki læti til að halda áhrifum á codegen minni.
        abort();
    }*/

    // ÖRYGGI: öryggissamningur fyrir `copy_nonoverlapping` verður að vera
    // staðfest af þeim sem hringir.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Afritar `count * size_of::<T>()` bæti frá `src` til `dst`.Uppruni og ákvörðunarstaður geta skarast.
///
/// Ef uppspretta og ákvörðunarstaður skarast *aldrei* er hægt að nota [`copy_nonoverlapping`] í staðinn.
///
/// `copy` jafngildir merkingarlega [`memmove`] C, en með röksemdafærslunni skipt.
/// Afritun fer fram eins og bætin væru afrituð úr `src` í tímabundið fylki og síðan afrituð úr fylkinu í `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Hegðun er óskilgreind ef brotið er á eftirfarandi skilyrðum:
///
/// * `src` verður að vera [valid] til að lesa `count * size_of::<T>()` bæti.
///
/// * `dst` verður að vera [valid] til að skrifa `count * size_of::<T>()` bæti.
///
/// * Bæði `src` og `dst` verða að vera rétt samstillt.
///
/// Eins og [`read`] býr `copy` til bitvis afrit af `T`, óháð því hvort `T` er [`Copy`].
/// Ef `T` er ekki [`Copy`] getur [violate memory safety][read-ownership] notað bæði gildin á svæðinu sem byrja á `*src` og svæðið sem byrjar á `* dst`.
///
///
/// Athugaðu að jafnvel þótt afritaða stærðin sé virk (`telja * stærð_of: :<T>()`) er `0`, ábendingar verða að vera ekki NULL og rétt stilltar.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Búðu til á skilvirkan hátt Rust vector úr óöruggri biðminni:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` verður að vera rétt stillt fyrir gerð þess og ekki núll.
/// /// * `ptr` verður að vera gilt til að lesa `elts` samliggjandi þætti af gerðinni `T`.
/// /// * Þessa þætti má ekki nota eftir að þessi aðgerð er kölluð nema `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // ÖRYGGI: Forsenda okkar tryggir að heimildin sé samstillt og gild,
///     // og `Vec::with_capacity` tryggir að við höfum nothæft rými til að skrifa þau.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // ÖRYGGI: Við bjuggum það til með þessari miklu getu fyrr,
///     // og fyrri `copy` hefur frumstillt þessa þætti.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Framkvæmdu þessar athuganir aðeins á hlaupatíma
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Ekki læti til að halda áhrifum á codegen minni.
        abort();
    }*/

    // ÖRYGGI: öryggissamningurinn fyrir `copy` verður að vera staðfestur af þeim sem hringir.
    unsafe { copy(src, dst, count) }
}

/// Stillir `count * size_of::<T>()` bæti af minni sem byrjar á `dst` til `val`.
///
/// `write_bytes` er svipað og C01X, en stillir `count * size_of::<T>()` bæti á `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Hegðun er óskilgreind ef brotið er á eftirfarandi skilyrðum:
///
/// * `dst` verður að vera [valid] til að skrifa `count * size_of::<T>()` bæti.
///
/// * `dst` verður að vera rétt samstillt.
///
/// Að auki verður sá sem hringir að sjá til þess að skrifun `count * size_of::<T>()` bæti í tiltekið svæði af minni skili gildu gildi `T`.
/// Að nota svæði af minni sem er slegið inn sem `T` sem inniheldur ógilt gildi `T` er óskilgreind hegðun.
///
/// Athugaðu að jafnvel þótt afritaða stærðin sé virk (`telja * stærð_of: :<T>()`) er `0`, bendillinn verður að vera ekki NULL og rétt stilltur.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Grunn notkun:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Að búa til ógilt gildi:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Sleppir gildinu sem áður var haldið með því að skrifa yfir `Box<T>` með núll bendi.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Á þessum tímapunkti, með því að nota eða sleppa `v`, er óskilgreind hegðun.
/// // drop(v); // ERROR
///
/// // Jafnvel lekur `v` "uses" það, og þess vegna er óskilgreind hegðun.
/// // mem::forget(v); // ERROR
///
/// // Reyndar er `v` ógilt samkvæmt grundvallarskipulagi invariants, þannig að *hver* aðgerð sem snertir það er óskilgreind hegðun.
/////
/// // láta v2 =v;//VILLA
///
/// unsafe {
///     // Við skulum setja í gildi gildi
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Nú er kassinn í lagi
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // ÖRYGGI: sá sem hringir þarf að standa við öryggissamninginn fyrir `write_bytes`.
    unsafe { write_bytes(dst, val, count) }
}