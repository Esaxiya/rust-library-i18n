/// Ítórator sem veit nákvæmlega lengd þess.
///
/// Margir [`Iterator`] vita ekki hversu oft þeir munu endurtaka sig, en sumir gera það.
/// Ef endurtekningartæki veit hversu oft það getur endurtekið getur það verið gagnlegt að veita aðgang að þeim upplýsingum.
/// Til dæmis, ef þú vilt endurtekna afturábak, þá er góð byrjun að vita hvar endirinn er.
///
/// Þegar `ExactSizeIterator` er útfært verður þú einnig að innleiða [`Iterator`].
/// Þegar það er gert verður útfærsla [`Iterator::size_hint`] * að skila nákvæmri stærð endurtekningar.
///
/// [`len`] aðferðin er með sjálfgefna útfærslu, svo þú ættir venjulega ekki að framkvæma hana.
/// Hins vegar gætirðu veitt afkastameiri framkvæmd en sjálfgefið, svo það er skynsamlegt að hnekkja því í þessu tilfelli.
///
///
/// Athugaðu að þessi trait er öruggur trait og getur sem slík *ekki* og * ekki ábyrgst að skilað lengd sé rétt.
/// Þetta þýðir að `unsafe` kóði **má ekki** reiða sig á réttmæti [`Iterator::size_hint`].
/// Óstöðugur og óöruggur [`TrustedLen`](super::marker::TrustedLen) trait veitir þessa viðbótarábyrgð.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Grunn notkun:
///
/// ```
/// // endanlegt svið veit nákvæmlega hversu oft það endurtekur
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Í [module-level docs] útfærðum við [`Iterator`], `Counter`.
/// Við skulum útfæra `ExactSizeIterator` fyrir það líka:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Við getum auðveldlega reiknað þann fjölda endurtekninga sem eftir eru.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Og nú getum við notað það!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Skilar nákvæmri lengd endurtekningar.
    ///
    /// Útfærslan tryggir að endurtekningin skilar nákvæmlega `len()` sinnum [`Some(T)`] gildi áður en [`None`] er skilað.
    ///
    /// Þessi aðferð hefur sjálfgefna útfærslu, svo þú ættir venjulega ekki að framkvæma hana beint.
    /// Hins vegar, ef þú getur veitt skilvirkari framkvæmd geturðu gert það.
    /// Sjá [trait-level] skjölin fyrir dæmi.
    ///
    /// Þessi aðgerð hefur sömu öryggisábyrgðir og [`Iterator::size_hint`] aðgerðin.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// // endanlegt svið veit nákvæmlega hversu oft það endurtekur
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Þessi fullyrðing er of varnarleg, en hún athugar hinn undantekningarlausa
        // tryggt af trait.
        // Ef þessi trait væri rust-innri, gætum við notað debug_assert !;fullyrðing_eq!mun athuga allar útfærslur notenda Rust líka.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Skilar `true` ef endurtekningartækið er tómt.
    ///
    /// Þessi aðferð hefur sjálfgefna útfærslu með [`ExactSizeIterator::len()`], svo þú þarft ekki að framkvæma hana sjálfur.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}