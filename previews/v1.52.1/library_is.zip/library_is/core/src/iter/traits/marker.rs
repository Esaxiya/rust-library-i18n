/// Ítator sem heldur alltaf áfram að skila `None` þegar hann er búinn.
///
/// Að hringja næst í samsetta endurtekningu sem hefur skilað `None` einu sinni er tryggt að skila [`None`] aftur.
/// Þessa trait ætti að framkvæma af öllum endurtekningum sem haga sér á þennan hátt vegna þess að það gerir fínstillingu [`Iterator::fuse()`] kleift.
///
///
/// Note: Almennt ættirðu ekki að nota `FusedIterator` í almennum mörkum ef þú þarft bráðan endurtekning.
/// Þess í stað ættirðu bara að hringja í [`Iterator::fuse()`] í endurtekningunni.
/// Ef endurtekningin er þegar brædd saman, þá mun [`Fuse`] umbúðirnar vera neikvæðar án frammistöðu.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Ítórator sem tilkynnir nákvæma lengd með því að nota size_hint.
///
/// Íteratorinn tilkynnir stærðarbendingu þar sem hún er annaðhvort nákvæm (neðri mörkin eru jöfn efri mörk), eða efri mörkin eru [`None`].
///
/// Efri mörkin mega aðeins vera [`None`] ef raunveruleg endurtekningarlengd er stærri en [`usize::MAX`].
/// Í því tilfelli verða neðri mörkin að vera [`usize::MAX`], sem leiðir til [`Iterator::size_hint()`] af `(usize::MAX, None)`.
///
/// Íteratorinn verður að framleiða nákvæmlega þann fjölda þátta sem hann tilkynnti eða dreifa áður en hann nær endanum.
///
/// # Safety
///
/// Þessa trait verður aðeins hrint í framkvæmd þegar samningurinn er haldinn.
/// Neytendur þessarar trait verða að skoða [`Iterator::size_hint()`]’s efri mörk.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Íterator sem þegar hlutur er gefinn mun hafa tekið að minnsta kosti einn þátt úr undirliggjandi [`SourceIter`] þess.
///
/// Að hringja í hvaða aðferð sem er sem gengur til endurtekningar, td
/// [`next()`] eða [`try_fold()`], ábyrgist að fyrir hvert skref hafi að minnsta kosti eitt gildi undirliggjandi uppruna endurtekningsins verið flutt út og niðurstaðan af endurtekningakeðjunni gæti verið sett inn á sinn stað, miðað við að uppbyggingartakmarkanir heimildarinnar leyfi slíka innsetningu.
///
/// Með öðrum orðum, þetta trait gefur til kynna að hægt sé að safna endurtekningarleiðslu á sínum stað.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}