/// Viðskipti úr [`Iterator`].
///
/// Með því að innleiða `FromIterator` fyrir gerð skilgreinir þú hvernig það verður búið til úr endurtekningu.
/// Þetta er algengt fyrir gerðir sem lýsa safni af einhverju tagi.
///
/// [`FromIterator::from_iter()`] er sjaldan kallað gagngert og er þess í stað notað með [`Iterator::collect()`] aðferð.
///
/// Sjá [`Iterator::collect()`]'s skjöl fyrir fleiri dæmi.
///
/// Sjá einnig: [`IntoIterator`].
///
/// # Examples
///
/// Grunn notkun:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Notkun [`Iterator::collect()`] til að nota `FromIterator` óbeint:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Útfærsla `FromIterator` fyrir þína tegund:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Sýnishorn, það er bara umbúðir yfir Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Gefum því nokkrar aðferðir svo við getum búið til eina og bætt hlutum við hana.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // og við munum innleiða FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Nú getum við búið til nýjan endurtekningu ...
/// let iter = (0..5).into_iter();
///
/// // ... og gerðu MyCollection úr því
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // safna verkum líka!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Býr til gildi úr endurtekningu.
    ///
    /// Sjá [module-level documentation] fyrir meira.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Umbreyting í [`Iterator`].
///
/// Með því að innleiða `IntoIterator` fyrir gerð skilgreinir þú hvernig henni verður breytt í endurtekningu.
/// Þetta er algengt fyrir gerðir sem lýsa safni af einhverju tagi.
///
/// Einn ávinningurinn af því að innleiða `IntoIterator` er að gerð þín verður [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Sjá einnig: [`FromIterator`].
///
/// # Examples
///
/// Grunn notkun:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Útfærsla `IntoIterator` fyrir þína tegund:
///
/// ```
/// // Sýnishorn, það er bara umbúðir yfir Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Gefum því nokkrar aðferðir svo við getum búið til eina og bætt hlutum við hana.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // og við munum innleiða IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Nú getum við búið til nýtt safn ...
/// let mut c = MyCollection::new();
///
/// // ... bættu einhverju dóti við það ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... og breyttu því síðan í Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Algengt er að nota `IntoIterator` sem trait bound.Þetta gerir inntakssöfnuninni kleift að breytast, svo framarlega sem það er enn endurtekning.
/// Hægt er að tilgreina viðbótarmörk með því að takmarka
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Tegund frumefnanna sem eru endurtekin.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Hvers konar endurtekning erum við að breyta þessu í?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Býr til endurtekningu út frá gildi.
    ///
    /// Sjá [module-level documentation] fyrir meira.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Framlengdu safn með innihaldi endurtekningar.
///
/// Iterator framleiðir röð af gildum og einnig er hægt að líta á söfn sem röð af gildum.
/// `Extend` trait brýr þetta bil og gerir þér kleift að framlengja safn með því að innihalda innihald endurtekningarinnar.
/// Þegar safn er framlengt með lykli sem þegar er til er sú færsla uppfærð eða, ef um er að ræða söfn sem leyfa margar færslur með jöfnum lyklum, þá er sú færsla sett inn.
///
///
/// # Examples
///
/// Grunn notkun:
///
/// ```
/// // Þú getur framlengt streng með nokkrum bleikjum:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Útfærsla `Extend`:
///
/// ```
/// // Sýnishorn, það er bara umbúðir yfir Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Gefum því nokkrar aðferðir svo við getum búið til eina og bætt hlutum við hana.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // þar sem MyCollection er með lista yfir i32, útfærum við Extend fyrir i32
/// impl Extend<i32> for MyCollection {
///
///     // Þetta er aðeins einfaldara með steypu gerð undirskrift: við getum kallað framlengja allt sem hægt er að breyta í Iterator sem gefur okkur i32.
///     // Vegna þess að við þurfum i32 til að setja í MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Framkvæmdin er mjög einföld: lykkja í gegnum endurtekninguna og add() hver þáttur fyrir okkur sjálf.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // framlengjum safnið okkar með þremur tölum í viðbót
/// c.extend(vec![1, 2, 3]);
///
/// // við höfum bætt þessum þáttum í lokin
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Framlengir safn með innihaldi endurtekningar.
    ///
    /// Þar sem þetta er eina aðferðin sem krafist er fyrir þessa trait innihalda [trait-level] skjölin frekari upplýsingar.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// // Þú getur framlengt streng með nokkrum bleikjum:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Framlengir safn með nákvæmlega einum þætti.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Pantar getu í safni fyrir tiltekinn fjölda viðbótarþátta.
    ///
    /// Sjálfgefin útfærsla gerir ekkert.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}