// hunsa-snyrtileg filelength Þessi skrá samanstendur næstum eingöngu af skilgreiningunni á `Iterator`.
// Við getum ekki skipt því í margar skrár.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Viðmót til að takast á við endurtekninga.
///
/// Þetta er aðal endurtekningin trait.
/// Nánari upplýsingar um hugtakið endurtekningartæki er að finna í [module-level documentation].
/// Sérstaklega gætirðu viljað vita hvernig á að [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Tegund frumefnanna sem eru endurtekin.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Framfarir endurtekninguna og skilar næsta gildi.
    ///
    /// Skilar [`None`] þegar endurtekningu er lokið.
    /// Sérstakar útfærslur á endurtekningum geta valið að hefja endurtekningu og því að hringja í `next()` aftur getur byrjað að skila [`Some(Item)`] aftur á einhverjum tímapunkti eða ekki.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Símtal til next() skilar næsta gildi ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... og svo enginn þegar það er búið.
    /// assert_eq!(None, iter.next());
    ///
    /// // Fleiri símtöl skila `None` eða ekki.Hér munu þeir alltaf gera það.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Skilar mörkunum sem eftir eru af endurtekningunni.
    ///
    /// Nánar tiltekið skilar `size_hint()` túpu þar sem fyrsti þátturinn er neðri mörkin og annar þátturinn er efri mörkin.
    ///
    /// Seinni helmingur túpilsins sem skilað er er [`Valkostur`]`<`['notastærð`]`>>.
    /// [`None`] þýðir hér að annaðhvort eru engin þekkt efri mörk, eða efri mörk eru stærri en [`usize`].
    ///
    /// # Framkvæmdarnótur
    ///
    /// Það er ekki framfylgt að endurtekningarútfærsla skili uppgefnum fjölda þátta.Gallaþreifari getur gefið minna en neðri mörkin eða meira en efri mörk frumefna.
    ///
    /// `size_hint()` er fyrst og fremst ætlað að vera notaður til hagræðingar svo sem að panta pláss fyrir þætti endurtekningarinnar, en má ekki treysta því að td sleppa mörkum í óöruggum kóða.
    /// Röng útfærsla á `size_hint()` ætti ekki að leiða til brota á minni öryggi.
    ///
    /// Sem sagt, útfærslan ætti að vera rétt mat, því annars væri það brot á bókun trait.
    ///
    /// Sjálfgefin útfærsla skilar " (0,`[" Ekkert`]) " sem er rétt fyrir alla endurtekninga.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Flóknara dæmi:
    ///
    /// ```
    /// // Jöfn tölurnar frá núlli til tíu.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Við gætum endurtekið frá núlli upp í tíu sinnum.
    /// // Að vita að það eru fimm nákvæmlega væri ekki hægt án þess að framkvæma filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Bætum við fimm tölum í viðbót með chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // nú eru bæði mörkin hækkuð um fimm
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Aftur `None` fyrir efri mörk:
    ///
    /// ```
    /// // óendanleg endurtekning hefur engin efri mörk og hámarks möguleg neðri mörk
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Eyðir endurtekningunni, telur fjölda endurtekninga og skilar henni.
    ///
    /// Þessi aðferð mun hringja ítrekað í [`next`] þar til [`None`] verður vart og skilar því fjölda sinnum sem það sá [`Some`].
    /// Athugaðu að hringja þarf í [`next`] að minnsta kosti einu sinni jafnvel þó að endurtekningartækið hafi ekki neina þætti.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Ofþensluhegðun
    ///
    /// Aðferðin er ekki vörn gegn flæði, svo að telja þætti endurtekningar með fleiri en [`usize::MAX`] þætti ýmist skilar röngum árangri eða panics.
    ///
    /// Ef fullyrðingar um kembiforrit eru virkjaðar er panic tryggt.
    ///
    /// # Panics
    ///
    /// Þessi aðgerð gæti verið panic ef endurtekningartækið hefur fleiri en [`usize::MAX`] þætti.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Eyðir endurtekningunni og skilar síðasta þættinum.
    ///
    /// Þessi aðferð metur endurtekninguna þar til hún skilar [`None`].
    /// Meðan það er gert heldur það utan um núverandi frumefni.
    /// Eftir að [`None`] er skilað skilar `last()` síðan síðasta þætti sem það sá.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Framfarir endurtekninguna með `n` þáttum.
    ///
    /// Þessi aðferð mun ákaft sleppa `n` þáttum með því að hringja í [`next`] allt að `n` sinnum þar til [`None`] verður vart.
    ///
    /// `advance_by(n)` mun skila [`Ok(())`][Ok] ef endurtekning gengur áfram með `n` þætti, eða [`Err(k)`][Err] ef [`None`] verður fyrir, þar sem `k` er fjöldi þátta sem endurtekningartækið er fært fram fyrir áður en það rennur upp fyrir þætti (þ.e.
    /// lengd endurtekningar).
    /// Athugaðu að `k` er alltaf minna en `n`.
    ///
    /// Að hringja í `advance_by(0)` neytir ekki neinna þátta og skilar alltaf [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // aðeins `&4` var sleppt
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Skilar " n` þætti endurtekningar.
    ///
    /// Eins og flestar verðtryggingaraðgerðir byrjar talningin frá núlli, þannig að `nth(0)` skilar fyrsta gildinu, `nth(1)` því síðara og svo framvegis.
    ///
    /// Athugaðu að allir þættir á undan, svo og skiluðu frumefni, verða neyttir frá endurtekningunni.
    /// Það þýðir að fyrri þáttum verður fargað og einnig að það að hringja í `nth(0)` mörgum sinnum á sama endurtekningunni mun skila mismunandi þáttum.
    ///
    ///
    /// `nth()` mun skila [`None`] ef `n` er stærri eða jafn lengd endurtekningar.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Að hringja í `nth()` mörgum sinnum spilar ekki endurtekninguna til baka:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Aftur `None` ef það eru minna en `n + 1` þættir:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Býr til endurtekningu sem byrjar á sama tímapunkti en stígur með gefinni upphæð við hverja endurtekningu.
    ///
    /// Athugasemd 1: Fyrsti þáttur endurtekningarinnar verður alltaf skilað, óháð því skrefi sem gefið er.
    ///
    /// Athugasemd 2: Tíminn sem dregnir eru framhjá eimunum er ekki fastur.
    /// `StepBy` hagar sér eins og röðin `next(), nth(step-1), nth(step-1),…`, en er líka frjálst að haga sér eins og röðin
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Hvaða leið er notuð getur breyst hjá sumum endurtekningum af frammistöðuástæðum.
    /// Önnur leiðin mun hækka endurtekninguna fyrr og gæti neytt fleiri muna.
    ///
    /// `advance_n_and_return_first` jafngildir:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Aðferðin mun panic ef uppgefið skref er `0`.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Tekur tvær endurtekningar og býr til nýja endurtekningu yfir báðar í röð.
    ///
    /// `chain()` mun skila nýjum endurtekningu sem mun ítraða yfir gildum frá fyrsta endurtekningi og síðan yfir gildum frá öðrum endurtekningi.
    ///
    /// Með öðrum orðum, það tengir tvo endurtekninga saman, í keðju.🔗
    ///
    /// [`once`] er almennt notað til að laga eitt gildi í keðju annars konar endurtekningar.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Þar sem rökin við `chain()` nota [`IntoIterator`] getum við komið öllu sem hægt er að breyta í [`Iterator`], ekki bara [`Iterator`] sjálft.
    /// Til dæmis, sneiðar (`&[T]`) innleiða [`IntoIterator`], og svo er hægt að fara til `chain()` beint:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ef þú vinnur með Windows API gætirðu viljað breyta [`OsStr`] í `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Rennir upp' tveimur endurtekningum í eina endurtekningu para.
    ///
    /// `zip()` skilar nýjum endurtekningi sem mun endurtekna yfir tveimur öðrum endurtekningum, skilar túpu þar sem fyrsti þátturinn kemur frá fyrsta endurtekningunni, og annar þátturinn kemur frá seinni endurtekningunni.
    ///
    ///
    /// Með öðrum orðum, það rennir tveimur endurtekningum saman, í eina.
    ///
    /// Ef annaðhvort endurtekningin skilar [`None`], þá skilar [`next`] frá rennilásinni endurgerð [`None`].
    /// Ef fyrsti endurtekningartækið skilar [`None`] mun `zip` skammhlaupa og `next` verður ekki kallaður á seinni endurtekninguna.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Þar sem rökin við `zip()` nota [`IntoIterator`] getum við komið öllu sem hægt er að breyta í [`Iterator`], ekki bara [`Iterator`] sjálft.
    /// Til dæmis, sneiðar (`&[T]`) innleiða [`IntoIterator`], og svo er hægt að fara til `zip()` beint:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` er oft notað til að þjappa endalausri endurtekningu í endanlegan.
    /// Þetta virkar vegna þess að endanleg endurtekning mun að lokum skila [`None`] og ljúka rennilásnum.Rennilás með `(0..)` getur litið mikið út eins og [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Býr til nýjan endurtekning sem setur afrit af `separator` á milli aðliggjandi atriða upprunalegrar endurtekningar.
    ///
    /// Ef `separator` innleiðir ekki [`Clone`] eða þarf að reikna það í hvert skipti, notaðu [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Fyrsti þátturinn frá `a`.
    /// assert_eq!(a.next(), Some(&100)); // Aðskilnaðurinn.
    /// assert_eq!(a.next(), Some(&1));   // Næsta þáttur frá `a`.
    /// assert_eq!(a.next(), Some(&100)); // Aðskilnaðurinn.
    /// assert_eq!(a.next(), Some(&2));   // Síðasti þátturinn frá `a`.
    /// assert_eq!(a.next(), None);       // Íteratorinn er búinn.
    /// ```
    ///
    /// `intersperse` getur verið mjög gagnlegt að taka þátt í atriðum endurtekningar með því að nota sameiginlegan þátt:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Býr til nýjan endurtekning sem setur hlut sem myndast af `separator` milli aðliggjandi atriða upprunalega endurtekningsins.
    ///
    /// Lokunin verður kölluð nákvæmlega einu sinni í hvert skipti sem hlutur er settur á milli tveggja samliggjandi atriða frá undirliggjandi endurtekningu;
    /// sérstaklega er ekki hringt í lokunina ef undirliggjandi endurtekning skilar minna en tveimur hlutum og eftir að síðasti hluturinn er gefinn.
    ///
    ///
    /// Ef hluti endurtekningarinnar útfærir [`Clone`] getur verið auðveldara að nota [`intersperse`].
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Fyrsti þátturinn frá `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Aðskilnaðurinn.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Næsta þáttur frá `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Aðskilnaðurinn.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Síðasti þátturinn frá `v`.
    /// assert_eq!(it.next(), None);               // Íteratorinn er búinn.
    /// ```
    ///
    /// `intersperse_with` hægt að nota við aðstæður þar sem reikna þarf skiljuna:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Lokunin fær lánlaust samhengi sitt til að búa til hlut.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Tekur lokun og býr til endurtekningu sem kallar lokunina á hvern þátt.
    ///
    /// `map()` umbreytir einum endurtekningi í annan með rökum sínum:
    /// eitthvað sem útfærir [`FnMut`].Það framleiðir nýjan endurtekning sem kallar þessa lokun fyrir hvern þátt í upprunalegri endurtekningu.
    ///
    /// Ef þú ert góður í að hugsa í gerðum geturðu hugsað um `map()` svona:
    /// Ef þú ert með endurtekningu sem gefur þér þætti af einhverri gerð `A`, og þú vilt endurgerð af annarri gerð `B`, getur þú notað `map()`, farið framhjá lokun sem tekur `A` og skilar `B`.
    ///
    ///
    /// `map()` er hugmyndalega svipað og [`for`] lykkja.Hins vegar, þar sem `map()` er latur, er það best notað þegar þú ert nú þegar að vinna með öðrum endurtekningum.
    /// Ef þú ert að gera einhvers konar lykkju fyrir aukaverkun, þá er það talað málvenjulegra að nota [`for`] en `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ef þú ert að gera einhvers konar aukaverkun, frekar [`for`] en `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // ekki gera þetta:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // það mun ekki einu sinni framkvæma, þar sem það er latur.Rust mun vara þig við þessu.
    ///
    /// // Notaðu í staðinn fyrir:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Kallar lokun á hvern þátt í endurtekningu.
    ///
    /// Þetta jafngildir því að nota [`for`] lykkju á endurtekningu, þó að `break` og `continue` séu ekki mögulegar frá lokun.
    /// Yfirleitt er málvenja að nota `for` lykkju en `for_each` gæti verið læsilegra þegar unnið er úr hlutum í lok lengri endurtekningakeðjanna.
    ///
    /// Í sumum tilfellum getur `for_each` einnig verið hraðari en lykkja, því það mun nota innri endurtekningu á millistykki eins og `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Fyrir svo lítið dæmi getur `for` lykkja verið hreinni, en `for_each` gæti verið æskilegra til að halda hagnýtum stíl með lengri endurtekningum:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Býr til endurtekningu sem notar lokun til að ákvarða hvort frumefni skuli skilað.
    ///
    /// Að gefnu atriði verður lokunin að skila `true` eða `false`.Ítóran sem skilað er skilar aðeins þeim þáttum sem lokunin skilar sönnu fyrir.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Vegna þess að lokunin, sem send er til `filter()`, tekur við tilvísun og margir endurtekningar ítrera yfir tilvísunum, leiðir þetta til hugsanlega ruglingslegs ástands, þar sem gerð lokunarinnar er tvöföld tilvísun:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // þarf tvo * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Það er algengt að nota í staðinn eyðileggingu á rökunum til að fjarlægja einn:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // bæði og *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// eða bæði:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // tveir &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// þessara laga.
    ///
    /// Athugaðu að `iter.filter(f).next()` jafngildir `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Býr til endurtekningu sem bæði síar og kortar.
    ///
    /// Ítóran sem skilað er skilar aðeins " gildunum` sem lokunin sem fylgir skilar `Some(value)` fyrir.
    ///
    /// `filter_map` hægt að nota til að gera keðjur af [`filter`] og [`map`] hnitmiðaðri.
    /// Dæmið hér að neðan sýnir hvernig hægt er að stytta `map().filter().map()` í eitt símtal í `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Hér er sama dæmið, en með [`filter`] og [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Býr til endurtekningu sem gefur núverandi endurtekningu talningu sem og næsta gildi.
    ///
    /// Ítóran sem skilað er skilar pörum `(i, val)`, þar sem `i` er núverandi vísitala endurtekningar og `val` er gildi sem endurtekningin skilar.
    ///
    ///
    /// `enumerate()` heldur talningu sinni sem [`usize`].
    /// Ef þú vilt telja eftir annarri stærð heiltölu, þá veitir [`zip`] aðgerð svipaða virkni.
    ///
    /// # Ofþensluhegðun
    ///
    /// Aðferðin verndar ekki gegn yfirfalli, svo að telja upp fleiri en [`usize::MAX`] þætti, annað hvort skilar röngum árangri eða panics.
    /// Ef fullyrðingar um kembiforrit eru virkjaðar er panic tryggt.
    ///
    /// # Panics
    ///
    /// Ítórinn sem skilað er gæti panic ef vísitalan sem á að skila myndi flæða yfir [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Býr til endurtekningu sem getur notað [`peek`] til að skoða næsta þátt í endurtekningunni án þess að neyta þess.
    ///
    /// Bætir [`peek`] aðferð við endurtekningu.Sjá skjöl hennar til að fá frekari upplýsingar.
    ///
    /// Athugaðu að undirliggjandi endurtekningartækið er ennþá langt þegar [`peek`] er kallað í fyrsta skipti: Til þess að ná næsta frumefni er [`next`] kallað á undirliggjandi endurtekningu, þess vegna allar aukaverkanir (þ.e.
    ///
    /// allt annað en að sækja næsta gildi) [`next`] aðferðarinnar mun eiga sér stað.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() látum okkur sjá inn í future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // við getum peek() mörgum sinnum, endurtekningin mun ekki komast áfram
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // eftir að endurtekningartækið er búið, þá er peek() það líka
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Býr til endurtekningu sem ["sleppa"] þætti byggir á forsendu.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` tekur lokun sem rök.Það mun kalla þessa lokun fyrir hvern þátt í endurtekningunni og hunsa þætti þar til hún skilar `false`.
    ///
    /// Eftir að `false` er skilað er `skip_while()`'s starfinu lokið og restin af þættunum er skilað.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Vegna þess að lokunin, sem send er til `skip_while()`, tekur við tilvísun og margir endurtekningar ítrera yfir tilvísunum, leiðir þetta til hugsanlega ruglingslegs ástands, þar sem gerð lokunarrökstuðningsins er tvöföld tilvísun:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // þarf tvo * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Stöðvun eftir upphaflega `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // meðan þetta hefði verið rangt, þar sem við fengum nú þegar rangt, þá er skip_while() ekki notað lengur
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Býr til endurtekningu sem skilar þætti sem byggjast á forsendu.
    ///
    /// `take_while()` tekur lokun sem rök.Það mun kalla þessa lokun fyrir hvern þátt í endurtekningunni og skila þætti meðan hún skilar `true`.
    ///
    /// Eftir að `false` er skilað er `take_while()`'s starfinu lokið og restin af þáttunum hunsuð.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Vegna þess að lokunin, sem send er til `take_while()`, tekur við tilvísun og margir endurtekningar ítrera yfir tilvísunum, leiðir þetta til hugsanlega ruglingslegs ástands, þar sem gerð lokunarinnar er tvöföld tilvísun:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // þarf tvo * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Stöðvun eftir upphaflega `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Við höfum fleiri þætti sem eru minna en núll, en þar sem við höfum þegar fengið falska er take_while() ekki notað lengur
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Vegna þess að `take_while()` þarf að skoða gildið til að sjá hvort það eigi að vera með eða ekki, þá mun neyslu endurtekninga sjá að það er fjarlægt:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` er ekki lengur til staðar, vegna þess að það var neytt til að sjá hvort endurtekningin ætti að stöðvast, en var ekki sett aftur í endurtekninguna.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Býr til endurtekningu sem bæði gefur þætti byggða á forsendu og kortum.
    ///
    /// `map_while()` tekur lokun sem rök.
    /// Það mun kalla þessa lokun fyrir hvern þátt í endurtekningunni og skila þætti meðan hún skilar [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Hér er sama dæmið, en með [`take_while`] og [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Stöðvun eftir upphaflega [`None`]:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Við höfum fleiri þætti sem gætu passað í u32 (4, 5), en `map_while` skilaði `None` fyrir `-3` (eins og `predicate` skilaði `None`) og `collect` stoppaði við fyrstu `None` sem upp kom.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Vegna þess að `map_while()` þarf að skoða gildið til að sjá hvort það eigi að vera með eða ekki, þá mun neyslu endurtekninga sjá að það er fjarlægt:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` er ekki lengur til staðar, vegna þess að það var neytt til að sjá hvort endurtekningin ætti að stöðvast, en var ekki sett aftur í endurtekninguna.
    ///
    /// Athugaðu að ólíkt [`take_while`] er þessi endurtekning **ekki** sameinuð.
    /// Það er heldur ekki tilgreint hvað þessi endurtekning skilar eftir að fyrsta [`None`] er skilað.
    /// Ef þú þarft sameinaðan iterator skaltu nota [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Býr til endurtekningu sem sleppir fyrstu `n` þáttunum.
    ///
    /// Eftir að þau hafa verið neytt er afgangurinn af frumefnunum gefinn.
    /// Frekar en að hnekkja þessari aðferð beint, heldur í staðinn fyrir `nth` aðferðina.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Býr til endurtekningu sem gefur fyrstu `n` þætti sína.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` er oft notað með óendanlegri endurtekningu, til að gera það endanlegt:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ef minna en `n` þættir eru í boði mun `take` takmarka sig við stærð undirliggjandi endurtekningar:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Íterator millistykki svipað og [`fold`] sem heldur innra ástandi og framleiðir nýjan iterator.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` tekur tvö rök: upphafsgildi sem frær innra ástandið og lokun með tveimur rökum, það fyrsta er breytileg tilvísun í innra ástandið og hið síðara endurtekningarþáttur.
    ///
    /// Lokunin getur úthlutað innra ríkinu til að deila ástandi milli endurtekninga.
    ///
    /// Við endurtekningu verður lokuninni beitt á hvern þátt í endurtekningunni og ávöxtunargildið frá lokuninni, [`Option`], er gefið af endurtekningunni.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // hverri endurtekningu munum við margfalda ríkið með frumefninu
    ///     *state = *state * x;
    ///
    ///     // þá munum við skila neitun ríkisins
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Býr til endurtekningu sem virkar eins og kort, en fletur hreiðraða uppbyggingu.
    ///
    /// [`map`] millistykkið er mjög gagnlegt, en aðeins þegar lokunarrökin framleiða gildi.
    /// Ef það framleiðir endurtekningu í staðinn, þá er viðbótarlag af innleiðingu.
    /// `flat_map()` mun fjarlægja þetta auka lag af sjálfu sér.
    ///
    /// Þú getur hugsað þér `flat_map(f)` sem merkingarjafngildi [`map`] ping og síðan [`flatt`] ing eins og í `map(f).flatten()`.
    ///
    /// Önnur hugsunarháttur um `flat_map()`: lokun ["map"] skilar einum hlut fyrir hvern þátt og `flat_map()`'s lokun skilar endurtekningu fyrir hvern þátt.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() skilar endurtekningu
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Býr til endurtekningu sem fletur út hreiðurbyggingu.
    ///
    /// Þetta er gagnlegt þegar þú ert með endurtekningu á endurtekningum eða endurtekningu á hlutum sem hægt er að breyta í endurtekninga og þú vilt fjarlægja eitt stig af innleiðingu.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Kortlagning og síðan fletjun:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() skilar endurtekningu
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Þú getur einnig endurskrifað þetta með tilliti til [`flat_map()`], sem er æskilegra í þessu tilfelli þar sem það miðlar ásetningi með skýrari hætti:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() skilar endurtekningu
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Fletjun fjarlægir aðeins eitt hreiður í einu:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Hér sjáum við að `flatten()` framkvæmir ekki "deep" flet.
    /// Þess í stað er aðeins eitt hreiðurstig fjarlægt.Það er, ef þú `flatten()` þrívítt fylki, verður niðurstaðan tvívíð en ekki einvídd.
    /// Til að fá einvíða uppbyggingu þarftu að `flatten()` aftur.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Býr til endurtekningu sem lýkur eftir fyrsta [`None`].
    ///
    /// Eftir að endurtekningartæki hefur skilað [`None`] geta future símtöl skilað [`Some(T)`] aftur eða ekki.
    /// `fuse()` aðlagar endurtekningartæki og tryggir að eftir að [`None`] er gefið mun það alltaf skila [`None`] að eilífu.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// // endurtekning sem skiptist á milli Sumar og Engar
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // ef það er jafnt, Some(i32), annað Ekkert
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // við getum séð endurtekningu okkar fara fram og til baka
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // þegar við sameinum það ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // það mun alltaf skila `None` eftir fyrsta skiptið.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Gerir eitthvað við hvern þátt í endurtekningu, miðlar gildinu áfram.
    ///
    /// Þegar þú notar endurtekninga hlekkurðu oft nokkrar þeirra saman.
    /// Þegar þú vinnur að slíkum kóða gætirðu viljað athuga hvað er að gerast á ýmsum hlutum í pípunum.Til að gera það skaltu setja símtal í `inspect()`.
    ///
    /// Algengara er að `inspect()` sé notað sem kembiforrit en til staðar í lokakóðanum þínum, en forrit geta fundið það gagnlegt við vissar aðstæður þegar skrá þarf villur áður en þeim er fargað.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // þessi endurtekningaröð er flókin.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // bætum við nokkrum inspect() símtölum til að kanna hvað er að gerast
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Þetta mun prenta:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Skráningarvillur áður en þeim er fargað:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Þetta mun prenta:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Lánar endurtekningu, frekar en að neyta þess.
    ///
    /// Þetta er gagnlegt til að gera kleift að nota endurtekningar millistykki en halda áfram eignarhaldi á upprunalegu endurtekningartækinu.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // ef við reynum að nota iter aftur, gengur það ekki.
    /// // Eftirfarandi lína gefur " villu: notkun færðs gildi: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // við skulum reyna það aftur
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // í staðinn bætum við við .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // núna er þetta bara fínt:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Gerir endurtekningu að safni.
    ///
    /// `collect()` getur tekið hvað sem er ítrekað og breytt því í viðeigandi safn.
    /// Þetta er ein öflugri aðferðin í venjulegu bókasafninu, notuð í margvíslegu samhengi.
    ///
    /// Grunnmynstrið þar sem `collect()` er notað er að breyta einu safni í annað.
    /// Þú tekur safn, hringir í [`iter`] á það, gerir fullt af umbreytingum og svo `collect()` í lokin.
    ///
    /// `collect()` getur einnig búið til dæmi um gerðir sem eru ekki dæmigerð söfn.
    /// Til dæmis er hægt að byggja [`String`] úr [`char`] s og endurheimta [`Result<T, E>`][`Result`] hluti er hægt að safna í `Result<Collection<T>, E>`.
    ///
    /// Sjáðu dæmin hér að neðan til að fá frekari upplýsingar.
    ///
    /// Þar sem `collect()` er svona almennt getur það valdið vandamálum með ályktun af gerðinni.
    /// Sem slík er `collect()` eitt af fáum sinnum sem þú munt sjá setningafræðina ástúðlega þekkt sem 'turbofish': `::<>`.
    /// Þetta hjálpar ályktunarreikniritinu að skilja sérstaklega hvaða safn þú ert að reyna að safna í.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Athugaðu að við þurftum `: Vec<i32>` vinstra megin.Þetta er vegna þess að við gætum safnað til dæmis í [`VecDeque<T>`] í staðinn:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Notaðu 'turbofish' í stað þess að gera athugasemd við `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Vegna þess að `collect()` er bara sama um það sem þú ert að safna í, geturðu samt notað vísbendingu að hluta til, `_`, með túrfófiskinu:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Notkun `collect()` til að búa til [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Ef þú ert með lista yfir [`Niðurstaða<T, E>`][`Result`] s, þú getur notað `collect()` til að sjá hvort eitthvað af þeim mistókst:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // gefur okkur fyrstu villuna
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // gefur okkur lista yfir svör
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Eyðir endurtekningu og býr til tvö söfn úr henni.
    ///
    /// Forboðið sem sent er til `partition()` getur skilað `true` eða `false`.
    /// `partition()` skilar pari, allir þættir sem það skilaði `true` fyrir, og allir þættir sem það skilaði `false` fyrir.
    ///
    ///
    /// Sjá einnig [`is_partitioned()`] og [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Skipuleggur þætti þessa endurtekningar *á sínum stað* samkvæmt gefnu forsendu, þannig að allir þeir sem skila `true` eru á undan öllum þeim sem skila `false`.
    ///
    /// Skilar fjölda `true` þætti sem fundust.
    ///
    /// Hlutfallslegri röð skiptra hluta er ekki haldið.
    ///
    /// Sjá einnig [`is_partitioned()`] og [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Skipting á stað milli jöfnunar og líkinda
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: ættum við að hafa áhyggjur af því að talningin flæði yfir?Eina leiðin til að hafa meira en
        // `usize::MAX` breytanlegar tilvísanir eru með ZST, sem eru ekki gagnlegar til að skipta upp ...

        // Þessar lokunar "factory" aðgerðir eru til til að koma í veg fyrir almennni í `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Finndu fyrsta `false` ítrekað og skiptu honum við síðasta `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Athugar hvort þættir þessa endurtekningar séu skiptir samkvæmt gefnu forsendu, þannig að allir þeir sem skila `true` eru á undan öllum þeim sem skila `false`.
    ///
    ///
    /// Sjá einnig [`partition()`] og [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Annaðhvort prófa allir hlutir `true` eða þá að fyrsta ákvæðið stoppar við `false` og við athugum að það eru ekki fleiri `true` hlutir eftir það.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Ítórunaraðferð sem beitir aðgerð svo lengi sem hún skilar árangri og framleiðir eitt lokagildi.
    ///
    /// `try_fold()` tekur tvö rök: upphafsgildi og lokun með tveimur rökum: 'accumulator' og frumefni.
    /// Lokunin annaðhvort skilar sér með góðum árangri með gildið sem rafgeymirinn ætti að hafa fyrir næstu endurtekningu, eða það skilar bilun, með villugildi sem er fjölgað aftur til þess sem hringir strax (short-circuiting).
    ///
    ///
    /// Upphafsgildið er það gildi sem rafgeymirinn mun hafa við fyrsta símtalið.Ef það tókst að beita lokuninni gagnvart öllum þáttum endurtekningarinnar skilar `try_fold()` endanlegri rafgeymi sem árangri.
    ///
    /// Brjóta saman er gagnlegt hvenær sem þú hefur safn af einhverju og vilt framleiða eitt gildi úr því.
    ///
    /// # Athugasemd til framkvæmdaraðila
    ///
    /// Nokkrar af öðrum (forward) aðferðum eru með sjálfgefnar útfærslur hvað varðar þessa, svo reyndu að útfæra þetta sérstaklega ef það getur gert eitthvað betra en sjálfgefna útfærslu `for` lykkjunnar.
    ///
    /// Sérstaklega reyndu að hafa þetta símtal `try_fold()` á innri hlutunum sem þessi endurtekning er samsett úr.
    /// Ef þörf er á mörgum símtölum gæti `?` símafyrirtækið verið þægilegt til að hleypa saman gildi rafgeymisins, en varast alla innflytjendur sem þarf að halda uppi áður en þeir koma snemma aftur.
    /// Þetta er `&mut self` aðferð, þannig að endurtekning þarf að vera endurtekin eftir að hafa lent á villu hér.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // merkt summa allra þátta fylkisins
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Þessi summa flæðir yfir þegar 100 frumefninu er bætt við
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Vegna þess að það skammhlaup eru hinir þættirnir enn í boði í gegnum endurtekninguna.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Ítórunaraðferð sem beitir fallanlegri aðgerð á hvert atriði í endurtekningunni, stoppar við fyrstu villuna og skilar þeirri villu.
    ///
    ///
    /// Þetta má einnig líta á sem fallvalt form [`for_each()`] eða sem ríkisfangslausa útgáfu af [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Það skammhlaup, svo hinir hlutirnir eru enn í endurtekningunni:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Brýtur alla þætti í rafgeymi með því að beita aðgerð og skila lokaniðurstöðunni.
    ///
    /// `fold()` tekur tvö rök: upphafsgildi og lokun með tveimur rökum: 'accumulator' og frumefni.
    /// Lokunin skilar gildinu sem rafgeymirinn ætti að hafa fyrir næstu endurtekningu.
    ///
    /// Upphafsgildið er það gildi sem rafgeymirinn mun hafa við fyrsta símtalið.
    ///
    /// Eftir að þessi lokun hefur verið beitt á alla þætti endurtekningarinnar skilar `fold()` rafgeyminum.
    ///
    /// Þessi aðgerð er stundum kölluð 'reduce' eða 'inject'.
    ///
    /// Brjóta saman er gagnlegt hvenær sem þú hefur safn af einhverju og vilt framleiða eitt gildi úr því.
    ///
    /// Note: `fold()`, og svipaðar aðferðir sem fara yfir allan endurtekninguna, geta ekki endað fyrir óendanlegar endurtekningar, jafnvel ekki á traits sem niðurstaða er ákvörðuð fyrir á endanlegum tíma.
    ///
    /// Note: [`reduce()`] er hægt að nota til að nota fyrsta frumefnið sem upphafsgildi, ef tegund rafgeymis og gerð hlutar er sú sama.
    ///
    /// # Athugasemd til framkvæmdaraðila
    ///
    /// Nokkrar af öðrum (forward) aðferðum eru með sjálfgefnar útfærslur hvað varðar þessa, svo reyndu að útfæra þetta sérstaklega ef það getur gert eitthvað betra en sjálfgefna útfærslu `for` lykkjunnar.
    ///
    ///
    /// Sérstaklega reyndu að hafa þetta símtal `fold()` á innri hlutunum sem þessi endurtekning er samsett úr.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // summan af öllum þáttum fylkisins
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Við skulum ganga í gegnum hvert skref endurtekningarinnar hér:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Og svo, lokaniðurstaða okkar, `6`.
    ///
    /// Það er algengt að fólk sem hefur ekki notað endurtekninga mikið noti `for` lykkju með lista yfir hluti til að byggja upp niðurstöðu.Þessum er hægt að breyta í `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // fyrir lykkju:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // þeir eru eins
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Minnkar þættina í eitt, með því að beita ítrekað minnkandi aðgerð.
    ///
    /// Ef endurtekningartækið er tómt skilar [`None`];annars skilar niðurstöðu lækkunarinnar.
    ///
    /// Fyrir endurtekninga með að minnsta kosti einn þátt er þetta það sama og [`fold()`] með fyrsta frumefni endurtekningsins sem upphafsgildið og brýtur hvert frumefni í það.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Finndu hámarksgildið:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Prófar hvort allir þættir endurtekningarinnar passi við forsendu.
    ///
    /// `all()` tekur lokun sem skilar `true` eða `false`.Það beitir þessari lokun fyrir hvern þátt í endurtekningunni og ef þeir skila allir `true`, þá gerir `all()` það líka.
    /// Ef einhver þeirra skilar `false` skilar það `false`.
    ///
    /// `all()` er skammhlaup;með öðrum orðum, það mun hætta vinnslu um leið og það finnur `false`, í ljósi þess að sama hvað annað gerist, útkoman verður einnig `false`.
    ///
    ///
    /// Tóm endurtekning skilar `true`.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Að hætta við fyrstu `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // við getum samt notað `iter`, þar sem það eru fleiri þættir.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Próf ef einhver þáttur í endurtekningunni passar við forsendu.
    ///
    /// `any()` tekur lokun sem skilar `true` eða `false`.Það beitir þessari lokun fyrir hvern þátt í endurtekningunni, og ef einhver þeirra skilar `true`, þá gerir `any()` það líka.
    /// Ef þeir skila allir `false` skilar það `false`.
    ///
    /// `any()` er skammhlaup;með öðrum orðum, það mun hætta vinnslu um leið og það finnur `true`, í ljósi þess að sama hvað annað gerist, útkoman verður einnig `true`.
    ///
    ///
    /// Tóm endurtekning skilar `false`.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Að hætta við fyrstu `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // við getum samt notað `iter`, þar sem það eru fleiri þættir.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Leitar að þætti endurtekningar sem fullnægir forsendu.
    ///
    /// `find()` tekur lokun sem skilar `true` eða `false`.
    /// Það beitir þessari lokun fyrir hvern þátt í endurtekningunni og ef einhver þeirra skilar `true`, þá skilar `find()` [`Some(element)`].
    /// Ef þeir skila allir `false` skilar það [`None`].
    ///
    /// `find()` er skammhlaup;með öðrum orðum, það mun hætta vinnslu um leið og lokunin skilar `true`.
    ///
    /// Vegna þess að `find()` tekur tilvísun og margir endurtekningar endurtekna yfir tilvísanir leiðir þetta til hugsanlega ruglingslegs ástands þar sem rökin eru tvöföld tilvísun.
    ///
    /// Þú getur séð þessi áhrif í dæmunum hér að neðan, með `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Að hætta við fyrstu `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // við getum samt notað `iter`, þar sem það eru fleiri þættir.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Athugaðu að `iter.find(f)` jafngildir `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Gildir aðgerð á þætti endurtekningar og skilar fyrstu niðurstöðunni sem ekki er nein.
    ///
    ///
    /// `iter.find_map(f)` jafngildir `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Gildir virka fyrir þætti endurtekningar og skilar fyrstu sönnu niðurstöðunni eða fyrstu villunni.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Leitar að frumefni í endurtekningu og skilar vísitölu sinni.
    ///
    /// `position()` tekur lokun sem skilar `true` eða `false`.
    /// Það beitir þessari lokun fyrir hvern þátt í endurtekningunni og ef einn þeirra skilar `true`, þá skilar `position()` [`Some(index)`].
    /// Ef allir skila `false` skilar það [`None`].
    ///
    /// `position()` er skammhlaup;með öðrum orðum, það mun hætta vinnslu um leið og það finnur `true`.
    ///
    /// # Ofþensluhegðun
    ///
    /// Aðferðin er ekki vörn gegn flæði, þannig að ef það eru fleiri en [`usize::MAX`] þættir sem ekki passa saman, þá framleiðir það annað hvort ranga niðurstöðu eða panics.
    ///
    /// Ef fullyrðingar um kembiforrit eru virkjaðar er panic tryggt.
    ///
    /// # Panics
    ///
    /// Þessi aðgerð gæti verið panic ef endurtekningartækið hefur fleiri en `usize::MAX` þætti sem ekki passa saman.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Að hætta við fyrstu `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // við getum samt notað `iter`, þar sem það eru fleiri þættir.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Skilvísitalan er háð ástandi endurtekningar
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Leitar að frumefni í endurtekningu frá hægri og skilar vísitölu sinni.
    ///
    /// `rposition()` tekur lokun sem skilar `true` eða `false`.
    /// Það beitir þessari lokun fyrir hvern þátt í endurtekningunni, frá lokum, og ef annar þeirra skilar `true`, þá skilar `rposition()` [`Some(index)`].
    ///
    /// Ef allir skila `false` skilar það [`None`].
    ///
    /// `rposition()` er skammhlaup;með öðrum orðum, það mun hætta vinnslu um leið og það finnur `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Að hætta við fyrstu `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // við getum samt notað `iter`, þar sem það eru fleiri þættir.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Engin þörf á yfirflæðisathugun hér, því `ExactSizeIterator` felur í sér að fjöldi þátta passar í `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Skilar hámarksþætti endurtekningar.
    ///
    /// Ef nokkrir þættir eru jafn hámarkir er síðasti þátturinn skilaður.
    /// Ef endurtekningartækið er tómt er [`None`] skilað.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Skilar lágmarksþætti endurtekningar.
    ///
    /// Ef nokkrir þættir eru jafn lágmarks, þá er fyrsta frumefninu skilað.
    /// Ef endurtekningartækið er tómt er [`None`] skilað.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Skilar þætti sem gefur hámarksgildi frá tilgreindri aðgerð.
    ///
    ///
    /// Ef nokkrir þættir eru jafn hámarkir er síðasti þátturinn skilaður.
    /// Ef endurtekningartækið er tómt er [`None`] skilað.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Skilar þættinum sem gefur hámarksgildið miðað við tilgreinda samanburðaraðgerð.
    ///
    ///
    /// Ef nokkrir þættir eru jafn hámarkir er síðasti þátturinn skilaður.
    /// Ef endurtekningartækið er tómt er [`None`] skilað.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Skilar þættinum sem gefur lágmarksgildi frá tilgreindri aðgerð.
    ///
    ///
    /// Ef nokkrir þættir eru jafn lágmarks, þá er fyrsta frumefninu skilað.
    /// Ef endurtekningartækið er tómt er [`None`] skilað.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Skilar þættinum sem gefur lágmarksgildið með tilliti til tilgreinds samanburðaraðgerðar.
    ///
    ///
    /// Ef nokkrir þættir eru jafn lágmarks, þá er fyrsta frumefninu skilað.
    /// Ef endurtekningartækið er tómt er [`None`] skilað.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Snýr átt við endurtekningu.
    ///
    /// Venjulega endurtekja endurtekningar frá vinstri til hægri.
    /// Eftir notkun `rev()` mun endurtekning í staðinn endurtekja frá hægri til vinstri.
    ///
    /// Þetta er aðeins mögulegt ef endurtekningin hefur enda, þannig að `rev()` virkar aðeins á [`DoubleEndedIterator`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Breytir endurtekningu para í par af ílátum.
    ///
    /// `unzip()` eyðir heilum endurtekningu para og framleiðir tvö söfn: eitt frá vinstri þáttum paranna og eitt frá hægri hlutum.
    ///
    ///
    /// Þessi aðgerð er að vissu leyti andstæð [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Býr til endurtekningu sem afritar alla þætti þess.
    ///
    /// Þetta er gagnlegt þegar þú ert með endurtekningu yfir `&T`, en þú þarft endurtekningu yfir `T`.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // afritað er það sama og .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Býr til endurtekningu sem ["klón"] er öll frumefni þess.
    ///
    /// Þetta er gagnlegt þegar þú ert með endurtekningu yfir `&T`, en þú þarft endurtekningu yfir `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // klóna er það sama og .map(|&x| x), fyrir heiltölur
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Endurtekur endurtekningu endalaust.
    ///
    /// Í stað þess að stoppa við [`None`] byrjar endurtekningin í staðinn aftur, frá upphafi.Eftir að það hefur endurtekið byrjar það aftur í byrjun.Og aftur.
    /// Og aftur.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Sumir þætti endurtekningar.
    ///
    /// Tekur hvern þátt, bætir þeim saman og skilar niðurstöðunni.
    ///
    /// Tómt endurtekningartæki skilar núllgildi gerðarinnar.
    ///
    /// # Panics
    ///
    /// Þegar hringt er í `sum()` og frumstæðri heiltölu gerð er skilað, mun þessi aðferð panic ef útreikningurinn flæðir yfir og kembiforrit eru virk.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Snerist yfir allan endurtekninguna og margfaldar alla þætti
    ///
    /// Tómt endurtekningartæki skilar einu gildi tegundarinnar.
    ///
    /// # Panics
    ///
    /// Þegar hringt er í `product()` og frumstæðri heiltölu gerð er skilað, mun aðferðin panic ef útreikningurinn flæðir yfir og kembiforrit eru virk.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ber saman þætti þessa [`Iterator`] og annarra.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ber saman þætti þessa [`Iterator`] við þætti annars með tilliti til tilgreinds samanburðaraðgerðar.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ber saman þætti þessa [`Iterator`] og annarra.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ber saman þætti þessa [`Iterator`] við þætti annars með tilliti til tilgreinds samanburðaraðgerðar.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Ákvarðar hvort þættir þessa [`Iterator`] séu jafnir og annars.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Ákvarðar hvort þættir þessa [`Iterator`] séu jafnir og aðrir með tilliti til tilgreinds jafnréttisaðgerðar.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Ákvarðar hvort þættir þessa [`Iterator`] séu ójafnir og annars.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Ákvarðar hvort þættir þessa [`Iterator`] séu [lexicographically](Ord#lexicographical-comparison) minni en aðrir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Ákvarðar hvort þættir þessa [`Iterator`] séu [lexicographically](Ord#lexicographical-comparison) minni eða jafnir og annars.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Ákvarðar hvort þættir þessa [`Iterator`] séu [lexicographically](Ord#lexicographical-comparison) stærri en þættir annars.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Ákvarðar hvort þættir þessa [`Iterator`] séu [lexicographically](Ord#lexicographical-comparison) stærri en eða jafnt og aðrir.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Athugar hvort þættir þessa endurtekningar séu flokkaðir.
    ///
    /// Það er að fyrir hvert frumefni `a` og eftirfarandi frumefni þess `b` verður `a <= b` að halda.Ef endurtekningin skilar nákvæmlega núlli eða einum þætti er `true` skilað.
    ///
    /// Athugið að ef `Self::Item` er aðeins `PartialOrd`, en ekki `Ord`, felur ofangreind skilgreining í sér að þessi aðgerð skili `false` ef tvö atriði í röð eru ekki sambærileg.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Athugar hvort þættir þessa endurtekningar séu flokkaðir með tiltekinni samanburðaraðgerð.
    ///
    /// Í stað þess að nota `PartialOrd::partial_cmp` notar þessi aðgerð gefna `compare` aðgerð til að ákvarða röðun tveggja þátta.
    /// Fyrir utan það jafngildir það [`is_sorted`];sjá skjöl hennar til að fá frekari upplýsingar.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Athugar hvort þættir þessa endurtekningar séu flokkaðir með tiltekinni lykilútdráttaraðgerð.
    ///
    /// Í stað þess að bera saman þætti endurtekningarinnar, ber þessi aðgerð saman lykla frumefnanna, eins og `f` ákvarðar.
    /// Fyrir utan það jafngildir það [`is_sorted`];sjá skjöl hennar til að fá frekari upplýsingar.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Sjá [TrustedRandomAccess]
    // Hið óvenjulega nafn er að forðast árekstra nafna í aðferðarupplausn sjá #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}