use crate::ops::{ControlFlow, Try};

/// Íterator sem getur skilað þætti frá báðum endum.
///
/// Eitthvað sem útfærir `DoubleEndedIterator` hefur eina aukahæfileika yfir eitthvað sem útfærir [`Iterator`]: getu til að taka einnig 'hlut' frá aftan, sem og að framan.
///
///
/// Það er mikilvægt að hafa í huga að bæði fram og til baka vinna á sama bili og fara ekki yfir: endurtekningu er lokið þegar þeir hittast í miðjunni.
///
/// Á svipaðan hátt og [`Iterator`] samskiptareglur, þegar `DoubleEndedIterator` skilar [`None`] úr [`next_back()`], kallar það aftur, eða kannski ekki alltaf, aftur [`Some`].
/// [`next()`] og [`next_back()`] er skiptanlegt í þessum tilgangi.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Grunn notkun:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Fjarlægir og skilar þætti frá enda endurtekningar.
    ///
    /// Skilar `None` þegar ekki eru fleiri þættir.
    ///
    /// [trait-level] skjölin innihalda frekari upplýsingar.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Þættirnir sem gefnir eru með aðferðum " DoubleEndedIterator`geta verið frábrugðnir þeim sem [" Iterator`] hefur gefið:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Framfarir endurtekninguna að aftan með `n` þætti.
    ///
    /// `advance_back_by` er öfug útgáfa af [`advance_by`].Þessi aðferð mun fúslega sleppa `n` þætti sem byrja að aftan með því að hringja í [`next_back`] allt að `n` sinnum þar til [`None`] verður vart.
    ///
    /// `advance_back_by(n)` mun skila [`Ok(())`] ef endurtekning gengur áfram með `n` þætti, eða [`Err(k)`] ef [`None`] verður fyrir, þar sem `k` er fjöldi þátta sem endurtekningartækið er fært fram fyrir áður en það rennur upp fyrir þætti (þ.e.
    /// lengd endurtekningar).
    /// Athugaðu að `k` er alltaf minna en `n`.
    ///
    /// Að hringja í `advance_back_by(0)` neytir ekki neinna þátta og skilar alltaf [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // aðeins `&3` var sleppt
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Skilar " n` frumefni frá enda endurtekningar.
    ///
    /// Þetta er í rauninni öfug útgáfa af [`Iterator::nth()`].
    /// Þó að eins og við flestar verðtryggingaraðgerðir byrjar talningin frá núlli, þannig að `nth_back(0)` skilar fyrsta gildinu frá lokum, `nth_back(1)` því síðara og svo framvegis.
    ///
    ///
    /// Athugaðu að allir þættir milli endans og skilaðs frumefnis verða neyttir, þ.mt skilaðs þáttarins.
    /// Þetta þýðir líka að það að hringja í `nth_back(0)` mörgum sinnum á sama endurtekningunni mun skila mismunandi þáttum.
    ///
    /// `nth_back()` mun skila [`None`] ef `n` er stærri eða jafn lengd endurtekningar.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Að hringja í `nth_back()` mörgum sinnum spilar ekki endurtekninguna til baka:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Aftur `None` ef það eru minna en `n + 1` þættir:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Þetta er öfug útgáfa af [`Iterator::try_fold()`]: það tekur þætti sem byrja frá aftan á endurtekningu.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Vegna þess að það skammhlaup eru hinir þættirnir enn í boði í gegnum endurtekninguna.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Ítórunaraðferð sem dregur úr þætti endurtekningarinnar í eitt, endanlegt gildi, frá byrjun.
    ///
    /// Þetta er öfug útgáfa af [`Iterator::fold()`]: það tekur þætti sem byrja frá aftan á endurtekningu.
    ///
    /// `rfold()` tekur tvö rök: upphafsgildi og lokun með tveimur rökum: 'accumulator' og frumefni.
    /// Lokunin skilar gildinu sem rafgeymirinn ætti að hafa fyrir næstu endurtekningu.
    ///
    /// Upphafsgildið er það gildi sem rafgeymirinn mun hafa við fyrsta símtalið.
    ///
    /// Eftir að þessi lokun hefur verið beitt á alla þætti endurtekningarinnar skilar `rfold()` rafgeyminum.
    ///
    /// Þessi aðgerð er stundum kölluð 'reduce' eða 'inject'.
    ///
    /// Brjóta saman er gagnlegt hvenær sem þú hefur safn af einhverju og vilt framleiða eitt gildi úr því.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // summan af öllum þáttum a
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Þetta dæmi byggir streng, byrjar með upphafsgildi og heldur áfram með hvert frumefni að aftan og framan af:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Leitar að þætti endurtekningar að aftan sem fullnægir forsendu.
    ///
    /// `rfind()` tekur lokun sem skilar `true` eða `false`.
    /// Það beitir þessari lokun á hvern þátt í endurtekningunni, sem byrjar í lokin, og ef einhver þeirra skilar `true`, þá skilar `rfind()` [`Some(element)`].
    /// Ef þeir skila allir `false` skilar það [`None`].
    ///
    /// `rfind()` er skammhlaup;með öðrum orðum, það mun hætta vinnslu um leið og lokunin skilar `true`.
    ///
    /// Vegna þess að `rfind()` tekur tilvísun og margir endurtekningar endurtekna yfir tilvísanir leiðir þetta til hugsanlega ruglingslegs ástands þar sem rökin eru tvöföld tilvísun.
    ///
    /// Þú getur séð þessi áhrif í dæmunum hér að neðan, með `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Að hætta við fyrstu `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // við getum samt notað `iter`, þar sem það eru fleiri þættir.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}