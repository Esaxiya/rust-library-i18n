use crate::iter::{FusedIterator, TrustedLen};

/// Býr til endurtekningu sem skilar frumefni nákvæmlega einu sinni.
///
/// Þetta er almennt notað til að laga eitt gildi í [`chain()`] af annarskonar endurtekningu.
/// Kannski ertu með endurtekningu sem nær yfir næstum allt, en þú þarft auka sérstakt mál.
/// Kannski hefur þú aðgerð sem virkar á endurtekningum, en þú þarft aðeins að vinna úr einu gildi.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Grunn notkun:
///
/// ```
/// use std::iter;
///
/// // ein er einmana fjöldinn
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // bara einn, það er allt sem við fáum
/// assert_eq!(None, one.next());
/// ```
///
/// Keðja ásamt öðrum endurtekningu.
/// Við skulum segja að við viljum endurtekna yfir hverja skrá `.foo` möppunnar, en einnig stillingarskrá,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // við verðum að breyta úr endurtekningu DirEntry-s í endurtekningu á PathBufs, svo við notum kort
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // nú, endurtekningin okkar bara fyrir stillingarskrá okkar
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // hlekkja tvo endurtekninga saman í einn stóran endurtekning
/// let files = dirs.chain(config);
///
/// // þetta mun gefa okkur allar skrár í .foo sem og .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Íterator sem skilar frumefni nákvæmlega einu sinni.
///
/// Þessi `struct` er búinn til með [`once()`] aðgerðinni.Sjá skjöl hennar til að fá frekari upplýsingar.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}