use crate::iter::{FusedIterator, TrustedLen};

/// Býr til nýjan endurtekning sem endurtækir þætti af gerðinni `A` endalaust með því að nota lokunina sem fylgir, hríðskotinn, `F: FnMut() -> A`.
///
/// `repeat_with()` aðgerð kallar endurvarpann aftur og aftur.
///
/// Óendanleg endurtekningartæki eins og `repeat_with()` eru oft notuð með millistykki eins og [`Iterator::take()`], til þess að gera þau endanleg.
///
/// Ef frumgerð tegund endurtekningar sem þú þarft útfærir [`Clone`] og það er í lagi að geyma frumefni í minni, ættirðu í staðinn að nota [`repeat()`] aðgerðina.
///
///
/// Íterator framleiddur af `repeat_with()` er ekki [`DoubleEndedIterator`].
/// Ef þú þarft `repeat_with()` til að skila [`DoubleEndedIterator`] skaltu opna GitHub tölublað sem útskýrir notkunartilvik þitt.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Grunn notkun:
///
/// ```
/// use std::iter;
///
/// // við skulum gera ráð fyrir að við höfum eitthvert gildi af gerð sem er ekki `Clone` eða sem ekki vilja hafa í minni ennþá vegna þess að það er dýrt:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // sérstakt gildi að eilífu:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Nota stökkbreytingu og fara endanlega:
///
/// ```rust
/// use std::iter;
///
/// // Frá núlli til þriðja valds af tveimur:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... og nú erum við búin
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Ítrator sem endurtakar þætti af gerðinni `A` endalaust með því að beita meðfylgjandi lokun `F: FnMut() -> A`.
///
///
/// Þessi `struct` er búinn til með [`repeat_with()`] aðgerðinni.
/// Sjá skjöl hennar til að fá frekari upplýsingar.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}