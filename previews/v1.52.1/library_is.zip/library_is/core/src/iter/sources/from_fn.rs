use crate::fmt;

/// Býr til nýjan endurtekning þar sem hver endurtekning kallar lokunina sem fylgir `F: FnMut() -> Option<T>`.
///
/// Þetta gerir kleift að búa til sérsniðna endurtekningu með hvaða hegðun sem er án þess að nota meira orðrétt setningafræði við að búa til sérstaka gerð og útfæra [`Iterator`] trait fyrir það.
///
/// Athugaðu að `FromFn` endurtekningartækið gerir ekki forsendur um hegðun lokunarinnar og framkvæmir því varlega ekki [`FusedIterator`] eða hnekkir [`Iterator::size_hint()`] frá því sem er sjálfgefið `(0, None)`.
///
///
/// Lokunin getur notað myndatökur og umhverfi hennar til að rekja ástand yfir endurtekningar.Það fer eftir því hvernig endurtekningartækið er notað, það gæti þurft að tilgreina [`move`] leitarorðið á lokuninni.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Við skulum endurútfæra mótþróann frá [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Aukið talningu okkar.Þetta er ástæðan fyrir því að við byrjuðum á núlli.
///     count += 1;
///
///     // Athugaðu hvort við erum búin að telja eða ekki.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Íterator þar sem hver endurtekning kallar lokunina `F: FnMut() -> Option<T>` sem fylgir.
///
/// Þessi `struct` er búinn til með [`iter::from_fn()`] aðgerðinni.
/// Sjá skjöl hennar til að fá frekari upplýsingar.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}