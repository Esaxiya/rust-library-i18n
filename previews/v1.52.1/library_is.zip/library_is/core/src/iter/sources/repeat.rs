use crate::iter::{FusedIterator, TrustedLen};

/// Býr til nýjan endurtekning sem endurtakar endalaust einn þátt.
///
/// `repeat()` aðgerð endurtekur eitt gildi aftur og aftur.
///
/// Óendanleg endurtekningartæki eins og `repeat()` eru oft notuð með millistykki eins og [`Iterator::take()`], til þess að gera þau endanleg.
///
/// Ef frumgerðin af endurtekningunni sem þú þarft þarf ekki að framkvæma `Clone`, eða ef þú vilt ekki geyma endurtekna þáttinn í minni, getur þú í staðinn notað [`repeat_with()`] aðgerðina.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Grunn notkun:
///
/// ```
/// use std::iter;
///
/// // talan fjögur 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // jamm, samt fjögur
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Að fara endanlegt með [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // þetta síðasta dæmi var of mikið af fjórum.Höfum aðeins fjórar fjórar.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... og nú erum við búin
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Ítórator sem endurtakar þátt endalaust.
///
/// Þessi `struct` er búinn til með [`repeat()`] aðgerðinni.Sjá skjöl hennar til að fá frekari upplýsingar.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}