use crate::iter::{FusedIterator, TrustedLen};

/// Býr til endurtekning sem myndar leti gildi nákvæmlega einu sinni með því að kalla fram lokunina sem fylgir.
///
/// Þetta er almennt notað til að laga einn gildi rafall í [`chain()`] af annarskonar endurtekningu.
/// Kannski ertu með endurtekningu sem nær yfir næstum allt, en þú þarft auka sérstakt mál.
/// Kannski hefur þú aðgerð sem virkar á endurtekningum, en þú þarft aðeins að vinna úr einu gildi.
///
/// Ólíkt [`once()`] mun þessi aðgerð í leti búa til gildi sé þess óskað.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Grunn notkun:
///
/// ```
/// use std::iter;
///
/// // ein er einmana fjöldinn
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // bara einn, það er allt sem við fáum
/// assert_eq!(None, one.next());
/// ```
///
/// Keðja ásamt öðrum endurtekningu.
/// Við skulum segja að við viljum endurtekna yfir hverja skrá `.foo` möppunnar, en einnig stillingarskrá,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // við verðum að breyta úr endurtekningu DirEntry-s í endurtekningu á PathBufs, svo við notum kort
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // nú, endurtekningin okkar bara fyrir stillingarskrá okkar
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // hlekkja tvo endurtekninga saman í einn stóran endurtekning
/// let files = dirs.chain(config);
///
/// // þetta mun gefa okkur allar skrár í .foo sem og .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Íterator sem skilar einum þætti af gerðinni `A` með því að beita meðfylgjandi lokun `F: FnOnce() -> A`.
///
///
/// Þessi `struct` er búinn til með [`once_with()`] aðgerðinni.
/// Sjá skjöl hennar til að fá frekari upplýsingar.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}