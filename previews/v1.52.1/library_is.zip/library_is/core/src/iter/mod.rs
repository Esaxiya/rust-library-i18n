//! Samsettan ytri endurtekningu.
//!
//! Ef þú hefur fundið þig fyrir safni af einhverju tagi og þarft að framkvæma aðgerð á þáttum þess safns lendirðu fljótt í 'iterators'.
//! Iteratorar eru mikið notaðir í málfræðilegum Rust kóða, svo það er þess virði að kynnast þeim.
//!
//! Áður en við útskýrum meira skulum við ræða hvernig þessi eining er byggð upp:
//!
//! # Organization
//!
//! Þessi eining er að mestu raðað eftir tegundum:
//!
//! * [Traits] eru kjarnahlutinn: þessir traits skilgreina hvers konar endurtekningar eru til og hvað þú getur gert með þeim.Aðferðir þessara traits eru þess virði að leggja smá auka námstíma í það.
//! * [Functions] bjóða upp á nokkrar gagnlegar leiðir til að búa til nokkra grundvallar endurtekninga.
//! * [Structs] eru oft skilategundir hinna ýmsu aðferða á traits þessa einingar.Þú vilt venjulega skoða aðferðina sem býr til `struct`, frekar en `struct` sjálft.
//! Nánari upplýsingar um hvers vegna, sjá '[Implementing Iterator](#implement-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Það er það!Förum í endurtekninga.
//!
//! # Iterator
//!
//! Hjarta og sál þessa einingar er [`Iterator`] trait.Kjarni [`Iterator`] lítur svona út:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Íterator hefur aðferð, [`next`], sem þegar hún er kölluð, skilar [" Option`]`<Item>`.
//! [`next`] mun skila [`Some(Item)`] svo framarlega sem til eru þættir, og þegar þeir eru allir búnir, mun skila `None` til að gefa til kynna að endurgerð sé lokið.
//! Einstakir endurtekningar geta valið að hefja endurtekningu og því að hringja í [`next`] aftur getur byrjað að skila [`Some(Item)`] aftur á einhverjum tímapunkti eða ekki (til dæmis, sjá [`TryIter`]).
//!
//!
//! Full skilgreining [[Iterator`]] inniheldur fjölda annarra aðferða líka, en þær eru sjálfgefnar aðferðir, byggðar ofan á [`next`], og svo færðu þær ókeypis.
//!
//! Iterator er einnig hægt að semja og það er algengt að hleypa þeim saman til að gera flóknari vinnsluform.Sjá [Adapters](#adapters) hlutann hér að neðan til að fá frekari upplýsingar.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Þrjár gerðir endurtekningar
//!
//! Það eru þrjár algengar aðferðir sem geta búið til endurtekninga úr safni:
//!
//! * `iter()`, sem gengur yfir `&T`.
//! * `iter_mut()`, sem gengur yfir `&mut T`.
//! * `into_iter()`, sem gengur yfir `T`.
//!
//! Ýmsir hlutir í venjulegu bókasafninu geta innleitt einn eða fleiri af þessum þremur, þar sem það á við.
//!
//! # Framkvæmd Iterator
//!
//! Að búa til endurtekningu á eigin spýtur felur í sér tvö skref: að búa til `struct` til að halda ástandi endurtekningarinnar og útfæra síðan [`Iterator`] fyrir þann `struct`.
//! Þetta er ástæðan fyrir því að það eru svo margir `struct`s í þessari einingu: það er einn fyrir hvern iterator og iterator millistykki.
//!
//! Búum til endurtekningu sem heitir `Counter` og telur frá `1` til `5`:
//!
//! ```
//! // Í fyrsta lagi uppbyggingin:
//!
//! /// Ítórator sem telur frá einum upp í fimm
//! struct Counter {
//!     count: usize,
//! }
//!
//! // við viljum að talning okkar byrji á einum, svo við skulum bæta við new() aðferð til að hjálpa.
//! // Þetta er ekki stranglega nauðsynlegt en er þægilegt.
//! // Athugaðu að við byrjum `count` á núlli, við sjáum af hverju í `next()`'s útfærslu hér að neðan.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Síðan útfærum við `Iterator` fyrir `Counter` okkar:
//!
//! impl Iterator for Counter {
//!     // við munum telja með stærð
//!     type Item = usize;
//!
//!     // next() er eina aðferðin sem krafist er
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Aukið talningu okkar.Þetta er ástæðan fyrir því að við byrjuðum á núlli.
//!         self.count += 1;
//!
//!         // Athugaðu hvort við erum búin að telja eða ekki.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Og nú getum við notað það!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Að hringja í [`next`] á þennan hátt verður endurtekið.Rust er með smíð sem getur hringt í [`next`] á endurtekningunni þinni þangað til hún nær `None`.Við skulum fara yfir það næst.
//!
//! Athugaðu einnig að `Iterator` býður upp á sjálfgefna útfærslu á aðferðum eins og `nth` og `fold` sem hringja í `next` innbyrðis.
//! Hins vegar er einnig hægt að skrifa sérsniðna útfærslu á aðferðum eins og `nth` og `fold` ef endurtekning getur reiknað þær á skilvirkari hátt án þess að hringja í `next`.
//!
//! # `for` lykkjur og `IntoIterator`
//!
//! `for` lykkju setningafræði Rust er í raun sykur fyrir endurtekninga.Hér er grunndæmi um `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Þetta mun prenta tölurnar eitt til fimm, hver á sinni línu.En þú munt taka eftir einhverju hér: við kölluðum aldrei neitt á vector okkar til að framleiða endurtekningu.Hvað gefur?
//!
//! Það er trait í venjulegu bókasafninu til að breyta einhverju í endurtekningu: [`IntoIterator`].
//! Þessi trait hefur eina aðferð, [`into_iter`], sem breytir hlutnum sem útfærir [`IntoIterator`] í endurtekningu.
//! Við skulum skoða `for` lykkjuna aftur og hvað þýðandinn breytir henni í:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust de-sykur þetta í:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Í fyrsta lagi köllum við `into_iter()` á gildinu.Síðan passum við á endurtekningunni sem snýr aftur og hringjum í [`next`] aftur og aftur þar til við sjáum `None`.
//! Á þeim tímapunkti erum við `break` út úr lykkjunni og við erum búnir að ítrera.
//!
//! Það er enn einn lúmskur hluti hér: venjulega bókasafnið inniheldur áhugaverða útfærslu á [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Með öðrum orðum, allir [`Iterator`] innleiða [`IntoIterator`], með því að skila bara sjálfum sér.Þetta þýðir tvennt:
//!
//! 1. Ef þú ert að skrifa [`Iterator`] geturðu notað hann með `for` lykkju.
//! 2. Ef þú ert að búa til safn, með því að útfæra [`IntoIterator`] fyrir það, verður hægt að nota safnið þitt með `for` lykkjunni.
//!
//! # Iterating með tilvísun
//!
//! Þar sem [`into_iter()`] tekur `self` eftir gildi, eyðir það safninu með því að nota `for` lykkju til að endurgera yfir safn.Oft gætirðu viljað endurgera safn án þess að neyta þess.
//! Mörg söfn bjóða upp á aðferðir sem veita endurtekningum yfir tilvísanir, venjulega kallaðar `iter()` og `iter_mut()` í sömu röð:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` er enn í eigu þessarar aðgerð.
//! ```
//!
//! Ef safntegund `C` veitir `iter()` útfærir hún venjulega einnig `IntoIterator` fyrir `&C`, með útfærslu sem kallar bara `iter()`.
//! Sömuleiðis safn `C` sem veitir `iter_mut()` útfærir almennt `IntoIterator` fyrir `&mut C` með því að framselja til `iter_mut()`.Þetta gerir þægilegan stuttmynd:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // sama og `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // sama og `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Þó mörg söfn bjóða upp á `iter()` bjóða ekki öll `iter_mut()`.
//! Til dæmis gæti stökkbreyting á takkum [`HashSet<T>`] eða [`HashMap<K, V>`] komið safninu í ósamræmi ef lykilháskinn breytist, þannig að þessi söfn bjóða aðeins upp á `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Aðgerðir sem taka [`Iterator`] og skila öðrum [`Iterator`] eru oft kallaðar 'iterator millistykki', þar sem þær eru mynd af 'millistykki'
//! pattern'.
//!
//! Algengir endurtekningar millistykki eru [`map`], [`take`] og [`filter`].
//! Fyrir frekari upplýsingar, sjá skjöl þeirra.
//!
//! Ef endurtekningartengi panics er endurtekningartækið í ótilgreindu (en öruggu minni).
//! Þetta ástand er heldur ekki tryggt að vera það sama yfir útgáfur af Rust, svo þú ættir að forðast að treysta á nákvæm gildi sem endurtekningin skilaði í panik.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iterators (og iterator [adapters](#adapters)) eru *latir*. Þetta þýðir að það að búa til iterator er ekki _do_ mjög mikið. Ekkert gerist í raun fyrr en þú hringir í [`next`].
//! Þetta er stundum uppspretta ruglings þegar búið er til endurtekningu eingöngu vegna aukaverkana.
//! Til dæmis kallar [`map`] aðferðin lokun fyrir hvern þátt sem hún gengur yfir:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Þetta mun ekki prenta nein gildi þar sem við bjuggum aðeins til endurtekningu frekar en að nota það.Safnarinn mun vara okkur við svona hegðun:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Sjálfsfræðileg leið til að skrifa [`map`] vegna aukaverkana er að nota `for` lykkju eða hringja í [`for_each`] aðferðina:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Önnur algeng leið til að meta endurtekningu er að nota [`collect`] aðferðina til að framleiða nýtt safn.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Iteratorar þurfa ekki að vera endanlegir.Sem dæmi er opið svið óendanleg endurtekning:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Algengt er að nota [`take`] endurteknings millistykki til að breyta óendanlegri endurtekningu í endanlegan:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Þetta mun prenta tölurnar `0` til `4`, hver á sinni línu.
//!
//! Hafðu í huga að aðferðir við óendanlegar endurtekningar, jafnvel þær sem hægt er að ákvarða niðurstöðu stærðfræðilega fyrir á endanlegum tíma, geta ekki endað.
//! Nánar tiltekið eru aðferðir eins og [`min`], sem almennt krefjast að fara yfir alla þætti í endurtekningunni, líklega ekki aftur fyrir óendanlegar endurtekningar.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Ó nei!Óendanleg lykkja!
//! // `ones.min()` veldur óendanlegri lykkju, svo við munum ekki ná þessu stigi!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;