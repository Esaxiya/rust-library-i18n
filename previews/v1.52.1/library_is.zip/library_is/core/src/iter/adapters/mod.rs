use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// Þessi trait veitir tímabundinn aðgang að uppsprettustigi í leiðslumagnara millistykki við þær aðstæður sem
/// * endurtekningargjafinn `S` útfærir sjálfur `SourceIter<Source = S>`
/// * það er framseld útfærsla þessarar trait fyrir hvert millistykki í leiðslunni milli uppsprettunnar og neytandans.
///
/// Þegar uppsprettan er eigandi endurtekningar (almennt kallaður `IntoIter`) þá getur þetta verið gagnlegt til að sérhæfa [`FromIterator`] útfærslur eða endurheimta þá þætti sem eftir eru eftir að endurtekning hefur verið búinn að hluta.
///
///
/// Athugið að útfærslur þurfa ekki endilega að veita aðgang að innri uppsprettu leiðslu.Tignarlegur millistykki gæti ákaft metið hluta leiðslunnar og afhjúpað innri geymslu hennar sem uppsprettu.
///
/// trait er óörugg vegna þess að útfærendur verða að halda uppi viðbótar öryggiseiginleikum.
/// Sjá [`as_inner`] fyrir frekari upplýsingar.
///
/// # Examples
///
/// Sækir heimild sem að hluta er neytt:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// Upprunastig í leiðslu endurtekningar.
    type Source: Iterator;

    /// Náðu í uppruna endurtekningarleiðslu.
    ///
    /// # Safety
    ///
    /// Framkvæmdir verða að skila sömu breytilegu tilvísuninni alla ævi sína, nema hringir komi í staðinn.
    /// Hringjendur mega aðeins skipta um tilvísun þegar þeir stöðvuðu endurtekningu og slepptu endurtekningarleiðslunni eftir að hafa fengið upptökuna.
    ///
    /// Þetta þýðir að endurgerðar millistykki geta treyst því að uppspretta breytist ekki við endurtekningu en þeir geta ekki treyst á það í Drop útfærslum sínum.
    ///
    /// Að innleiða þessa aðferð þýðir að millistykki afsala sér einkaaðgangi að uppruna sínum og geta aðeins treyst á ábyrgðir sem gerðar eru út frá gerðum móttakaraaðferða.
    /// Skortur á takmörkuðum aðgangi krefst einnig þess að millistykki verði að viðhalda almennu forritaskilum uppsprettunnar, jafnvel þegar þeir hafa aðgang að innréttingum þess.
    ///
    /// Hringjendur þurfa aftur á móti að búast við því að uppsprettan sé í hvaða ástandi sem er í samræmi við almenna API sitt þar sem millistykki sem sitja á milli hennar og uppsprettunnar hafa sama aðgang.
    /// Sérstaklega gæti millistykki neytt fleiri þátta en bráðnauðsynlegt.
    ///
    /// Heildarmarkmið þessara krafna er að láta neytendur leiðslu nota
    /// * hvað sem er eftir í upptökum eftir að endurtekning hefur stöðvast
    /// * minningin sem hefur orðið ónotuð með því að efla neyslulegan endurtekningu
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// Ítrator millistykki sem framleiðir framleiðslu svo lengi sem undirliggjandi endurtekning framleiðir `Result::Ok` gildi.
///
///
/// Ef villa kemur upp stöðvast endurtekningin og villan er geymd.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// Unnið uppgefna endurtekningu eins og hún hafi skilað `T` í stað `Result<T, _>`.
/// Allar villur munu stöðva innri endurtekningu og heildarniðurstaðan verður villa.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}