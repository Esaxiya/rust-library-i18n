use crate::{iter::FusedIterator, ops::Try};

/// Ítórator sem endurtekur endalaust.
///
/// Þessi `struct` er búinn til með [`cycle`] aðferðinni á [`Iterator`].
/// Sjá skjöl hennar til að fá frekari upplýsingar.
///
/// [`cycle`]: Iterator::cycle
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Cycle<I> {
    orig: I,
    iter: I,
}

impl<I: Clone> Cycle<I> {
    pub(in crate::iter) fn new(iter: I) -> Cycle<I> {
        Cycle { orig: iter.clone(), iter }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> Iterator for Cycle<I>
where
    I: Clone + Iterator,
{
    type Item = <I as Iterator>::Item;

    #[inline]
    fn next(&mut self) -> Option<<I as Iterator>::Item> {
        match self.iter.next() {
            None => {
                self.iter = self.orig.clone();
                self.iter.next()
            }
            y => y,
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        // hringrásartíminn er annað hvort tómur eða óendanlegur
        match self.orig.size_hint() {
            sz @ (0, Some(0)) => sz,
            (0, _) => (0, None),
            _ => (usize::MAX, None),
        }
    }

    #[inline]
    fn try_fold<Acc, F, R>(&mut self, mut acc: Acc, mut f: F) -> R
    where
        F: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        // endurtekja núverandi endurtekningu að fullu.
        // þetta er nauðsynlegt vegna þess að `self.iter` getur verið tómt jafnvel þegar `self.orig` er það ekki
        acc = self.iter.try_fold(acc, &mut f)?;
        self.iter = self.orig.clone();

        // ljúka heill hringrás og fylgjast með því hvort reiðhjólaferðin er tóm eða ekki.
        // við þurfum að snúa aftur snemma ef um tóma endurtekningu er að ræða til að koma í veg fyrir óendanlega lykkju
        //
        let mut is_empty = true;
        acc = self.iter.try_fold(acc, |acc, x| {
            is_empty = false;
            f(acc, x)
        })?;

        if is_empty {
            return try { acc };
        }

        loop {
            self.iter = self.orig.clone();
            acc = self.iter.try_fold(acc, &mut f)?;
        }
    }

    // Engin `fold` framhjá, því `fold` er ekki mjög skynsamlegt fyrir `Cycle`, og við getum ekki gert neitt betra en sjálfgefið.
    //
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I> FusedIterator for Cycle<I> where I: Clone + Iterator {}