//! Mát til að vinna með lánuð gögn.

#![stable(feature = "rust1", since = "1.0.0")]

/// A trait fyrir lántöku gagna.
///
/// Í Rust er algengt að koma fram með mismunandi framsetningu af gerð fyrir mismunandi notkunartilvik.
/// Til dæmis er hægt að velja geymslustað og stjórnun fyrir gildi sérstaklega eftir því sem við á til sérstakrar notkunar með benditegundum eins og [`Box<T>`] eða [`Rc<T>`].
/// Fyrir utan þessar almennu umbúðir sem hægt er að nota með hvaða gerð sem er, bjóða sumar gerðir upp á valkosti sem veita mögulega kostnaðarsama virkni.
/// Dæmi um slíka gerð er [`String`] sem bætir við möguleikann á að framlengja streng í grunn [`str`].
/// Þetta krefst þess að viðbótarupplýsingar séu óþarfar fyrir einfaldan, óbreytanlegan streng.
///
/// Þessar gerðir veita aðgang að undirliggjandi gögnum með tilvísunum í gerð þeirra gagna.Þeir eru sagðir " lánaðir` sem þessi tegund.
/// Til dæmis er hægt að fá [`Box<T>`] lánaðan sem `T` en [`String`] sem `str`.
///
/// Tegundir lýsa því að hægt sé að fá þær lánaðar sem einhverja gerð `T` með því að innleiða `Borrow<T>` og veita tilvísun í `T` í [`borrow`] aðferð trait.Tegund er frjálst að taka lán sem nokkrar mismunandi gerðir.
/// Ef það vill taka lán með breytilegum hætti sem gerð-sem gerir kleift að breyta undirliggjandi gögnum, getur það auk þess innleitt [`BorrowMut<T>`].
///
/// Ennfremur, þegar útvegun er veitt fyrir viðbótar traits, þarf að íhuga hvort þeir eigi að haga sér eins og þeir af undirliggjandi gerð sem afleiðing af því að starfa sem framsetning þeirrar undirliggjandi gerðar.
/// Almenn kóði notar venjulega `Borrow<T>` þegar hann reiðir sig á sömu hegðun þessara viðbótar trait útfærslna.
/// Þessar traits munu líklega birtast sem viðbótar trait bounds.
///
/// Sérstaklega verða `Eq`, `Ord` og `Hash` að vera jafngild lánum og eignum: `x.borrow() == y.borrow()` ætti að gefa sömu niðurstöðu og `x == y`.
///
/// Ef almenna kóðinn þarf aðeins að virka fyrir allar gerðir sem geta gefið tilvísun í tengda gerð `T`, þá er oft betra að nota [`AsRef<T>`] þar sem fleiri gerðir geta framkvæmt hann á öruggan hátt.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Sem gagnasöfnun á [`HashMap<K, V>`] bæði lykla og gildi.Ef raunveruleg gögn lykilsins eru vafin inn í stjórnunartegund af einhverju tagi ætti samt að vera hægt að leita að gildi með tilvísun í gögn lykilsins.
/// Til dæmis, ef lykillinn er strengur, þá er hann líklega geymdur með kjötkássunni sem [`String`], en það ætti að vera hægt að leita með [`&str`][`str`].
/// Þannig þarf `insert` að starfa á `String` á meðan `get` þarf að geta notað `&str`.
///
/// Nokkuð einfaldað, viðkomandi hlutar `HashMap<K, V>` líta svona út:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // reitum sleppt
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Allt kjötkássukortið er almennt yfir lykilgerð `K`.Vegna þess að þessir lyklar eru geymdir með kjötkássukortinu verður þessi tegund að eiga gögn lykilsins.
/// Þegar lykilgildispar er sett inn er kortinu gefinn slíkur `K` og þarf að finna réttu kjötkássufötuna og athuga hvort lykillinn sé þegar til staðar miðað við þann `K`.Það krefst þess vegna `K: Hash + Eq`.
///
/// Þegar leitað er að gildi á kortinu þarf hins vegar að búa til slík verðmæti að þurfa að gefa tilvísun í `K` sem lykilinn til að leita að.
/// Fyrir strengjalykla þýðir þetta að búa þarf til `String` gildi bara til að leita að tilvikum þar sem aðeins `str` er í boði.
///
/// Þess í stað er `get` aðferðin almenn yfir gerð undirliggjandi lykilgagna, kölluð `Q` í aðferð undirskriftinni hér að ofan.Þar kemur fram að `K` láni sem `Q` með því að krefjast þess að `K: Borrow<Q>`.
/// Með því að þurfa að auki `Q: Hash + Eq`, gefur það til kynna kröfuna um að `K` og `Q` hafi útfærslur á `Hash` og `Eq` traits sem skila sömu niðurstöðum.
///
/// Útfærsla `get` treystir sérstaklega á eins útfærslur á `Hash` með því að ákvarða kjötkássu lykilsins með því að hringja í `Hash::hash` á `Q` gildi, jafnvel þó að það hafi sett lykilinn inn miðað við kjötkássugildið reiknað út frá `K` gildi.
///
///
/// Sem afleiðing brotnar kjötkássukortið ef `K` sem umlykur `Q` gildi framleiðir annan kjötkássa en `Q`.Til dæmis, ímyndaðu þér að þú hafir gerð sem umlykur streng en ber saman ASCII bókstafi að hunsa mál þeirra:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Vegna þess að tvö jöfn gildi þurfa að framleiða sama kjötkássugildi þarf framkvæmd `Hash` að hunsa ASCII tilfelli líka:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Getur `CaseInsensitiveString` innleitt `Borrow<str>`?Það getur vissulega veitt tilvísun í strengjasneið í gegnum strenginn sem hann inniheldur.
/// En vegna þess að `Hash` útfærsla þess er ólík hegðar hún sér öðruvísi en `str` og má því í raun ekki innleiða `Borrow<str>`.
/// Ef það vill leyfa öðrum aðgang að undirliggjandi `str` getur það gert það í gegnum `AsRef<str>` sem gerir ekki neinar auka kröfur.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Ótímabært að láni frá verðmæti í eigu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// A trait til að breyta gögnum með breytilegum hætti.
///
/// Sem félagi [`Borrow<T>`] leyfir þessi trait tegund að taka lán sem undirliggjandi gerð með því að veita breytanlega tilvísun.
/// Sjá [`Borrow<T>`] til að fá frekari upplýsingar um lántöku sem aðra tegund.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Líklega tekur lán af verðmæti í eigu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}