use crate::iter::FromIterator;

/// Fellir alla eininga hluti úr endurtekningu í einn.
///
/// Þetta er gagnlegra þegar það er samsett með afleiðingum á hærra stigi, eins og að safna í `Result<(), E>` þar sem þér er aðeins sama um villur:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}