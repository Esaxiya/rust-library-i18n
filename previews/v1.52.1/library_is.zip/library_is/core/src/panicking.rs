//! Panic stuðningur við libcore
//!
//! Algerlega bókasafnið getur ekki skilgreint læti, en það lýsir *yfir* læti.
//! Þetta þýðir að aðgerðirnar inni í libcore eru leyfðar til panic, en til að vera gagnlegar verður crate uppstreymis að skilgreina læti til að libcore geti notað.
//! Núverandi viðmót fyrir læti er:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Þessi skilgreining gerir kleift að fara í læti með almennum skilaboðum, en það gerir ekki ráð fyrir að mistakast með `Box<Any>` gildi.
//! (`PanicInfo` inniheldur bara `&(dyn Any + Send)`, sem við fyllum út gervigildi í `PanicInfo: : internal_constructor`.) Ástæðan fyrir þessu er sú að libcore er ekki heimilt að úthluta.
//!
//!
//! Þessi eining inniheldur nokkur önnur læti, en þetta eru bara nauðsynleg lang atriði fyrir þýðandann.Öll panics eru leidd í gegnum þessa einu aðgerð.
//! Raunverulegt tákn er lýst með `#[panic_handler]` eiginleikanum.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Undirliggjandi útfærsla á `panic!` fjölvi libcore þegar ekkert snið er notað.
#[cold]
// aldrei innbyggður nema panic_immediate_abort til að koma í veg fyrir að kóði blási upp eins mikið og mögulegt er
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // þörf fyrir codegen fyrir panic á yfirfalli og öðrum `Assert` MIR lúkkum
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Notaðu Arguments::new_v1 í stað format_args! ("{}", Expr) til að draga mögulega úr kostnaði.
    // Sniðið_args!makró notar str's Display trait til að skrifa expr, sem kallar Formatter::pad, sem verður að hýsa strengjaskurð og bólstrun (jafnvel þó að engin sé notuð hér).
    //
    // Notkun Arguments::new_v1 getur leyft þýðandanum að sleppa Formatter::pad úr tvöfaldri framleiðslunni og sparað allt að nokkur kílóbæti.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // þörf fyrir fast-metið panics
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // þörf fyrir codegen fyrir panic við OOB array/slice aðgang
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Undirliggjandi útfærsla `panic!` fjölvi libcore þegar notuð er formatting.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // ATH þessi aðgerð fer aldrei yfir mörk FFI;það er Rust-til-Rust símtal sem verður leyst í `#[panic_handler]` aðgerðina.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // ÖRYGGI: `panic_impl` er skilgreint í öruggum Rust kóða og er því óhætt að hringja í hann.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Innri virkni fyrir `assert_eq!` og `assert_ne!` fjölva
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}