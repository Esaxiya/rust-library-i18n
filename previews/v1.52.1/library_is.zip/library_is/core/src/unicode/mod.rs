#![unstable(feature = "unicode_internals", issue = "none")]
#![allow(missing_docs)]

pub(crate) mod printable;
mod unicode_data;

/// Útgáfan af [Unicode](http://www.unicode.org/) sem Unicode hlutar `char` og `str` aðferðanna byggja á.
///
/// Nýjar útgáfur af Unicode eru gefnar út reglulega og í kjölfarið eru allar aðferðir í venjulegu bókasafninu uppfærðar eftir Unicode.
/// Þess vegna breytist hegðun sumra `char` og `str` aðferða og gildi þessarar stöðugu með tímanum.
/// Þetta er *ekki* talið vera brotbreyting.
///
/// Útfærslunúmerakerfið er útskýrt í [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
///
///
///
#[stable(feature = "unicode_version", since = "1.45.0")]
pub const UNICODE_VERSION: (u8, u8, u8) = unicode_data::UNICODE_VERSION;

// Til notkunar í liballoc, ekki flutt út aftur í libstd.
pub use unicode_data::{
    case_ignorable::lookup as Case_Ignorable, cased::lookup as Cased, conversions,
};

pub(crate) use unicode_data::alphabetic::lookup as Alphabetic;
pub(crate) use unicode_data::cc::lookup as Cc;
pub(crate) use unicode_data::grapheme_extend::lookup as Grapheme_Extend;
pub(crate) use unicode_data::lowercase::lookup as Lowercase;
pub(crate) use unicode_data::n::lookup as N;
pub(crate) use unicode_data::uppercase::lookup as Uppercase;
pub(crate) use unicode_data::white_space::lookup as White_Space;