//! Ofhlaðanlegir rekstraraðilar.
//!
//! Útfærsla þessara traits gerir þér kleift að ofhlaða ákveðna rekstraraðila.
//!
//! Sumar af þessum traits eru fluttar inn af prelude, svo þær eru fáanlegar í hverju Rust forriti.Aðeins rekstraraðilar með traits geta verið ofhlaðnir.
//! Til dæmis er hægt að ofhlaða viðbótarrekandann (`+`) í gegnum [`Add`] trait, en þar sem verkefnisstjórinn (`=`) hefur engan stuðning trait er engin leið að ofhlaða merkingarfræði þess.
//! Að auki býður þessi eining ekki upp nein kerfi til að búa til nýja rekstraraðila.
//! Ef krafist er eiginlegrar ofhleðslu eða sérsniðinna rekstraraðila, ættirðu að horfa í átt að fjölva eða þýðara viðbætur til að lengja setningafræði Rust.
//!
//! Útfærsla rekstraraðila traits ætti að koma á óvart í sínu samhengi og hafa í huga venjulega merkingu þeirra og [operator precedence].
//! Til dæmis, þegar [`Mul`] er útfært, ætti aðgerðin að líkjast margföldun (og deila væntum eiginleikum eins og tengsl).
//!
//! Athugið að rekstraraðilar `&&` og `||` skammhlaupa, þ.e. þeir meta aðeins aðra operand sinn ef það stuðlar að niðurstöðunni.Þar sem þessi hegðun er ekki framfylgjanleg af traits, eru `&&` og `||` ekki studd sem ofhlaðanlegir rekstraraðilar.
//!
//! Margir rekstraraðilanna taka virðingar sínar eftir gildi.Í samhengi utan almennra þátta sem varða innbyggðar gerðir er þetta yfirleitt ekki vandamál.
//! Hins vegar þarf einhver athygli að nota þessa rekstraraðila í almennum kóða ef endurnýta þarf gildi í stað þess að láta rekstraraðila neyta þeirra.Einn möguleikinn er að nota stöku sinnum [`clone`].
//! Annar valkostur er að treysta á þær tegundir sem fylgja því að veita viðbótarútfærslur rekstraraðila til tilvísana.
//! Til dæmis, fyrir notendaskilgreinda gerð `T` sem á að styðja við viðbót, er líklega góð hugmynd að láta bæði `T` og `&T` innleiða traits [`Add<T>`][`Add`] og [`Add<&T>`][`Add`] svo hægt sé að skrifa almenna kóða án óþarfa einræktunar.
//!
//!
//! # Examples
//!
//! Þetta dæmi býr til `Point` strúktúr sem útfærir [`Add`] og [`Sub`], og sýnir síðan að bæta við og draga frá tveimur `punktum`.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Sjá skjöl fyrir hverja trait fyrir dæmi um framkvæmd.
//!
//! [`Fn`], [`FnMut`] og [`FnOnce`] traits eru útfærðar með gerðum sem hægt er að kalla fram eins og aðgerðir.Athugaðu að [`Fn`] tekur `&self`, [`FnMut`] tekur `&mut self` og [`FnOnce`] tekur `self`.
//! Þetta samsvarar þrenns konar aðferðum sem hægt er að kalla á dæmi: hringja-til-tilvísun, hringja-fyrir-breytanleg-tilvísun og hringja-fyrir-gildi.
//! Algengasta notkun þessara traits er að takmarka aðgerðir á hærra stigi sem taka aðgerðir eða lokanir sem rök.
//!
//! Að taka [`Fn`] sem breytu:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Að taka [`FnMut`] sem breytu:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Að taka [`FnOnce`] sem breytu:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` eyðir fanguðum breytum sínum, svo það er ekki hægt að keyra það oftar en einu sinni
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Tilraun til að ákalla `func()` aftur mun henda `use of moved value` villu fyrir `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` er ekki lengur hægt að kalla fram á þessum tímapunkti
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;