use crate::marker::Unpin;
use crate::pin::Pin;

/// Niðurstaðan af endurupptöku rafala.
///
/// Þetta enum er skilað frá `Generator::resume` aðferðinni og gefur til kynna möguleg skilagildi rafala.
/// Sem stendur samsvarar þetta annað hvort stöðvunarpunkti (`Yielded`) eða lokapunkti (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Rafallinn stöðvaður með gildi.
    ///
    /// Þetta ástand gefur til kynna að rafall hafi verið stöðvaður og samsvarar venjulega `yield` yfirlýsingu.
    /// Gildið sem gefið er upp í þessu afbrigði samsvarar tjáningunni sem send er til `yield` og gerir rafala kleift að veita gildi í hvert skipti sem þau gefa.
    ///
    ///
    Yielded(Y),

    /// Rafallinn lokið með skilagildi.
    ///
    /// Þetta ástand gefur til kynna að rafall hafi lokið framkvæmd með uppgefnu gildi.
    /// Þegar rafall hefur skilað `Complete` er það talið forritavilla að hringja aftur í `resume`.
    ///
    Complete(R),
}

/// trait útfærður með innbyggðum rafallategundum.
///
/// Rafalar, einnig oft nefndir coroutines, eru sem stendur tilraunatungumálatilbúnaður í Rust.
/// Bætt við [RFC 2033] rafala er eins og er ætlað að veita fyrst og fremst byggingarreit fyrir async/await setningafræði en mun líklega ná til einnig að veita vinnuvistfræðilega skilgreiningu fyrir endurtekninga og aðra frumstöðu.
///
///
/// Setningafræði og merkingarfræði rafala er óstöðug og þarfnast frekari RFC til að koma á stöðugleika.Á þessum tíma er setningafræðin þó eins og lokun:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Fleiri skjöl rafala er að finna í óstöðugu bókinni.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Gerð gildi sem rafall skilar.
    ///
    /// Þessi tengda gerð samsvarar `yield` tjáningu og gildin sem er leyfilegt að skila í hvert skipti sem rafall skilar.
    ///
    /// Til dæmis, endurtekning sem rafall myndi líklega hafa þessa tegund sem `T`, gerðin var endurtekin.
    ///
    type Yield;

    /// Gerðin af gildi sem rafallinn skilar.
    ///
    /// Þetta samsvarar gerðinni sem er skilað frá rafall annaðhvort með `return` fullyrðingu eða óbeint sem síðasta tjáning rafallar bókstaflega.
    /// Til dæmis myndi futures nota þetta sem `Result<T, E>` þar sem það táknar lokið future.
    ///
    ///
    type Return;

    /// Heldur áfram framkvæmd þessa rafala.
    ///
    /// Þessi aðgerð mun halda áfram að framkvæma rafalinn eða hefja framkvæmd ef það hefur ekki þegar gert það.
    /// Þetta símtal mun snúa aftur í síðasta stöðvunarstað rafallsins og hefja aftur framkvæmd frá nýjasta `yield`.
    /// Rafallinn mun halda áfram að keyra þar til hann annað hvort skilar sér eða skilar sér, á þeim tímapunkti mun þessi aðgerð snúa aftur.
    ///
    /// # Skilagildi
    ///
    /// `GeneratorState` enum sem er skilað frá þessari aðgerð gefur til kynna í hvaða ástandi rafallinn er þegar hann snýr aftur.
    /// Ef `Yielded` afbrigði er skilað þá hefur rafallinn náð stöðvunarpunkti og gildi hefur verið gefið út.
    /// Rafalar í þessu ástandi eru tiltækir til endurupptöku síðar.
    ///
    /// Ef `Complete` er skilað þá er rafallinn alveg búinn með uppgefið gildi.Það er ógilt að rafallinn verði hafinn aftur.
    ///
    /// # Panics
    ///
    /// Þessi aðgerð getur verið panic ef hún er kölluð eftir að `Complete` afbrigði hefur verið skilað áður.
    /// Þó að bókstafir rafala á tungumálinu séu tryggðir fyrir panic þegar þeir hefja aftur eftir `Complete`, þá er þetta ekki tryggt fyrir alla útfærslu `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}