/// A trait til að sérsníða hegðun stjórnanda `?`.
///
/// Tegund sem innleiðir `Try` er ein sem hefur kanóníska leið til að skoða það með tilliti til tvískipta success/failure.
/// Þetta trait gerir bæði kleift að ná þeim árangri eða bilunargildum úr núverandi dæmi og búa til nýtt dæmi úr árangurs-eða bilunargildi.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Tegund þessa gildi þegar litið er á það sem árangursríkt.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Tegund þessa gildi þegar litið er á það sem mistókst.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Gildir "?" símafyrirtækið.Skil á `Ok(t)` þýðir að framkvæmdinni ætti að halda áfram eðlilega og niðurstaðan á `?` er gildið `t`.
    /// Skil á `Err(e)` þýðir að framkvæmd ætti að branch í innsta girðinguna fyrir `catch`, eða aftur frá aðgerðinni.
    ///
    /// Ef `Err(e)` niðurstöðu er skilað verður gildið `e` "wrapped" í skilategundinni sem fylgir (sem verður sjálft að innleiða `Try`).
    ///
    /// Nánar tiltekið er gildi `X::from_error(From::from(e))` skilað, þar sem `X` er skilategund lokunaraðgerðarinnar.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Pakkaðu villugildinu til að smíða samsetta niðurstöðuna.
    /// Til dæmis eru `Result::Err(x)` og `Result::from_error(x)` jafngildir.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Pakkaðu í lagi gildi til að búa til samsetta niðurstöðuna.
    /// Til dæmis eru `Result::Ok(x)` og `Result::from_ok(x)` jafngildir.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}