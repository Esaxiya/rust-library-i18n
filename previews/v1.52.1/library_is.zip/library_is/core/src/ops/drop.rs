/// Sérsniðinn kóði innan tortímandans.
///
/// Þegar gildi er ekki lengur þörf mun Rust keyra "destructor" á því gildi.
/// Algengasta leiðin til að gildi sé ekki lengur þörf er þegar það fer út fyrir gildissvið.Eyðileggjendur geta enn hlaupið undir öðrum kringumstæðum en við ætlum að einbeita okkur að svigrúmi fyrir dæmin hér.
/// Til að fræðast um sum þessara tilvika, vinsamlegast skoðaðu [the reference] kafla um eyðileggjendur.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Þessi eyðileggjandi samanstendur af tveimur þáttum:
/// - Símtal til `Drop::drop` fyrir það gildi, ef þessi sérstaki `Drop` trait er útfærður fyrir sína gerð.
/// - "drop glue", sem myndast sjálfkrafa, kallar aftur á eyðileggjendur allra sviða þessa gildis.
///
/// Þar sem Rust kallar sjálfkrafa eyðileggjendur svæðanna sem þú hefur að geyma þarftu ekki að útfæra `Drop` í flestum tilfellum.
/// En það eru nokkur tilfelli þar sem það er gagnlegt, til dæmis fyrir gerðir sem stjórna auðlind beint.
/// Sú auðlind getur verið minni, hún getur verið skráarlýsandi, hún getur verið netnetstengi.
/// Þegar gildi af þeirri gerð er ekki lengur í notkun ætti það að "clean up" auðlind sína með því að losa um minni eða loka skránni eða falsinu.
/// Þetta er starf eyðileggjanda og því starf `Drop::drop`.
///
/// ## Examples
///
/// Til að sjá eyðileggjendur í aðgerð skulum við skoða eftirfarandi forrit:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust mun fyrst hringja í `Drop::drop` fyrir `_x` og síðan til bæði `_x.one` og `_x.two`, sem þýðir að keyrsla þessa prentar
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Jafnvel þó við fjarlægjum útfærslu `Drop` fyrir `HasTwoDrop`, þá eru samt sem áður eyðileggjendur sviða hennar kallaðir.
/// Þetta myndi leiða til
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Þú getur ekki hringt í `Drop::drop` sjálfur
///
/// Þar sem `Drop::drop` er notað til að hreinsa gildi getur verið hættulegt að nota þetta gildi eftir að aðferðin hefur verið kölluð til.
/// Þar sem `Drop::drop` tekur ekki eignarhald á inntakinu kemur Rust í veg fyrir misnotkun með því að leyfa þér ekki að hringja beint í `Drop::drop`.
///
/// Með öðrum orðum, ef þú reyndir að hringja gagngert í `Drop::drop` í dæminu hér að ofan, færðu þýðandavillu.
///
/// Ef þú vilt beinlínis kalla eyðileggjanda gildi, þá er hægt að nota [`mem::drop`] í staðinn.
///
/// [`mem::drop`]: drop
///
/// ## Slepptu pöntun
///
/// Hver af tveimur okkar `HasDrop` lækkar þó fyrst?Fyrir structs er það sama röð og þeir eru lýstir: fyrst `one`, síðan `two`.
/// Ef þú vilt prófa þetta sjálfur geturðu breytt `HasDrop` hér að ofan til að innihalda nokkur gögn, eins og heiltala, og síðan notað þau í `println!` inni í `Drop`.
/// Þessi hegðun er tryggð af tungumálinu.
///
/// Ólíkt strúktum eru staðbundnar breytur látnar falla í öfugri röð:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Þetta mun prenta
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Vinsamlegast skoðaðu [the reference] fyrir allar reglurnar.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` og `Drop` eru einkarétt
///
/// Þú getur ekki innleitt bæði [`Copy`] og `Drop` af sömu gerð.Tegundirnar sem eru `Copy` verða afdráttarlausar tvíteknar af þýðandanum, sem gerir það mjög erfitt að spá fyrir um hvenær og hversu oft eyðileggjendur verða teknir af lífi.
///
/// Sem slíkar geta þessar tegundir ekki haft eyðileggjendur.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Tekur eyðileggjanda af þessari gerð.
    ///
    /// Þessi aðferð er kölluð óbeint þegar gildið fer úr gildissviði og ekki er hægt að kalla það sérstaklega (þetta er þýðandavilla [E0040]).
    /// Hins vegar er hægt að nota [`mem::drop`] aðgerðina í prelude til að kalla `Drop` framkvæmd rökræðunnar.
    ///
    /// Þegar þessi aðferð hefur verið kölluð hefur `self` ekki enn verið úthlutað.
    /// Það gerist aðeins eftir að aðferðinni er lokið.
    /// Ef þetta væri ekki tilfellið væri `self` hangandi tilvísun.
    ///
    /// # Panics
    ///
    /// Í ljósi þess að [`panic!`] mun hringja í `drop` þegar það vindur upp, mun líklega allir [`panic!`] í `drop` framkvæmd hætta.
    ///
    /// Athugaðu að jafnvel þó að þetta panics sé talið að gildi falli niður;
    /// þú mátt ekki láta `drop` hringja aftur.
    /// Þetta er venjulega sjálfkrafa meðhöndlað af þýðandanum, en þegar þú notar óöruggan kóða getur það stundum átt sér stað óviljandi, sérstaklega þegar [`ptr::drop_in_place`] er notað.
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}