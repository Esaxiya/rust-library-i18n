/// Notað til óbreytanlegra aðferðaaðgerða, eins og `*v`.
///
/// Auk þess að vera notaður til skýrra aðferðaaðgerða með (unary) `*` símafyrirtækinu í óbreytanlegu samhengi, er `Deref` einnig notað óbeint af þýðandanum við margar kringumstæður.
/// Þessi vélbúnaður er kallaður ['`Deref` coercion'][more].
/// Í breytilegu samhengi er [`DerefMut`] notað.
///
/// Útfærsla `Deref` fyrir snjalla ábendingar gerir aðgang að gögnum á bak við sig þægileg og þess vegna innleiða þeir `Deref`.
/// Á hinn bóginn voru reglurnar varðandi `Deref` og [`DerefMut`] hannaðar sérstaklega til að koma til móts við snjalla ábendinga.
/// Vegna þessa ætti **`Deref` aðeins að vera útfærð fyrir snjalla ábendingar** til að forðast rugling.
///
/// Af svipuðum ástæðum ætti **þessi trait aldrei að mistakast**.Bilun við aðferðir geta verið mjög ruglingsleg þegar kallað er óbeint á `Deref`.
///
/// # Meira um `Deref` nauðung
///
/// Ef `T` útfærir `Deref<Target = U>` og `x` er gildi af gerðinni `T`, þá:
///
/// * Í óbreytanlegu samhengi jafngildir `*x` (þar sem `T` er hvorki tilvísun né hrá bendill) `* Deref::deref(&x)`.
/// * Gildi af gerð `&T` eru þvinguð til gildi af gerð `&U`
/// * `T` útfærir óbeint allar (immutable) aðferðir af gerðinni `U`.
///
/// Nánari upplýsingar er að finna á [the chapter in *The Rust Programming Language*][book] sem og tilvísunarköflunum um [the dereference operator][ref-deref-op], [method resolution] og [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Uppbygging með einum reit sem er aðgengilegur með því að vísa til skipulags.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Sú tegund sem myndast eftir aðferðir eru nefndar.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Ræðir gildi.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Notað til breytanlegra aðferðaaðgerða, eins og í `*v = 1;`.
///
/// Auk þess að vera notaður til skýrra aðferðaaðgerða með (unary) `*` símafyrirtækinu í breytilegu samhengi, er `DerefMut` einnig notað óbeint af þýðandanum við margar kringumstæður.
/// Þessi vélbúnaður er kallaður ['`Deref` coercion'][more].
/// Í óbreytanlegu samhengi er [`Deref`] notað.
///
/// Útfærsla `DerefMut` fyrir snjalla ábendingar gerir stökkbreytingu á gögnum á bak við þau þægileg og þess vegna innleiða þau `DerefMut`.
/// Á hinn bóginn voru reglurnar varðandi [`Deref`] og `DerefMut` hannaðar sérstaklega til að koma til móts við snjalla ábendinga.
/// Vegna þessa ætti **`DerefMut` aðeins að vera útfærð fyrir snjalla ábendingar** til að forðast rugling.
///
/// Af svipuðum ástæðum ætti **þessi trait aldrei að mistakast**.Bilun við aðferðir geta verið mjög ruglingsleg þegar kallað er óbeint á `DerefMut`.
///
/// # Meira um `Deref` nauðung
///
/// Ef `T` útfærir `DerefMut<Target = U>` og `x` er gildi af gerðinni `T`, þá:
///
/// * Í breytilegu samhengi jafngildir `*x` (þar sem `T` er hvorki tilvísun né hrá bendill) `* DerefMut::deref_mut(&mut x)`.
/// * Gildi af gerð `&mut T` eru þvinguð til gildi af gerð `&mut U`
/// * `T` útfærir óbeint allar (mutable) aðferðir af gerðinni `U`.
///
/// Nánari upplýsingar er að finna á [the chapter in *The Rust Programming Language*][book] sem og tilvísunarköflunum um [the dereference operator][ref-deref-op], [method resolution] og [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Uppbygging með einni reit sem er hægt að breyta með því að vísa til uppdráttar.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Gagngerlega vísar gildi.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Gefur til kynna að hægt sé að nota uppbyggingu sem móttakara án aðferðar án `arbitrary_self_types`.
///
/// Þetta er útfært með stdlib benditýpum eins og `Box<T>`, `Rc<T>`, `&T` og `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}