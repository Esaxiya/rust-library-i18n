use crate::marker::Unsize;

/// Trait sem gefur til kynna að þetta sé bendill eða umbúðir fyrir einn, þar sem hægt er að gera óstærð á punktinum.
///
/// Sjá [DST coercion RFC][dst-coerce] og [the nomicon entry on coercion][nomicon-coerce] fyrir frekari upplýsingar.
///
/// Fyrir innbyggðar benditegundir munu vísbendingar í `T` þvinga til vísbendinga í `U` ef `T: Unsize<U>` með því að breyta úr þunnum bendi í feitan bendil.
///
/// Fyrir sérsniðnar gerðir virkar nauðungin hér með því að þvinga `Foo<T>` til `Foo<U>` að því tilskildu að `CoerceUnsized<Foo<U>> for Foo<T>` sé til.
/// Slíkt impl er aðeins hægt að skrifa ef `Foo<T>` hefur aðeins eitt reit sem er ekki phantomdata sem tekur til `T`.
/// Ef tegund þess reits er `Bar<T>`, verður útfærsla `CoerceUnsized<Bar<U>> for Bar<T>` að vera til.
/// Þvingunin mun virka með því að þvinga `Bar<T>` reitinn í `Bar<U>` og fylla út restina af reitunum frá `Foo<T>` til að búa til `Foo<U>`.
/// Þetta mun á áhrifaríkan hátt bora niður að bendisviði og þvinga það.
///
/// Venjulega, fyrir snjalla ábendingar muntu útfæra `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized`, með valfrjálsan `?Sized` bundinn við sjálfan `T`.
/// Fyrir gerðir umbúða sem eru með `T` eins og `Cell<T>` og `RefCell<T>`, er hægt að útfæra `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` beint.
///
/// Þetta mun láta þvinganir af tegundum eins og `Cell<Box<T>>` virka.
///
/// [`Unsize`][unsize] er notað til að merkja tegundir sem hægt er að neyða til sumartíma ef þær eru á bak við ábendingar.Það er hrint í framkvæmd sjálfvirkt af þýðandanum.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Þetta er notað til að tryggja öryggi hlutar, til að athuga hvort hægt sé að senda móttökutegund aðferðar á.
///
/// Dæmi um framkvæmd trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}