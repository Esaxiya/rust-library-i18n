/// Útgáfa símafyrirtækisins sem tekur óbreytanlegan móttakara.
///
/// Tilvik `Fn` er hægt að hringja ítrekað án þess að stökkbreytast.
///
/// *Þessum trait (`Fn`) er ekki að rugla saman við [function pointers] (`fn`).*
///
/// `Fn` er útfært sjálfkrafa með lokunum sem taka aðeins óbreytanlegar tilvísanir í teknar breytur eða ná alls ekki neinu, svo og (safe) [function pointers] (með nokkrum fyrirvörum, sjá skjöl þeirra til að fá frekari upplýsingar).
///
/// Að auki, fyrir allar tegundir `F` sem útfærir `Fn`, útfærir `&F` einnig `Fn`.
///
/// Þar sem bæði [`FnMut`] og [`FnOnce`] eru ofurleiðir `Fn` er hægt að nota hvaða dæmi sem er af `Fn` sem færibreytu þar sem búist er við [`FnMut`] eða [`FnOnce`].
///
/// Notaðu `Fn` sem bundið þegar þú vilt samþykkja breytu af aðgerðarlíkri gerð og þarft að hringja í hana ítrekað og án stökkbreytingar (td þegar hringt er í hana samtímis).
/// Ef þú þarft ekki svona strangar kröfur skaltu nota [`FnMut`] eða [`FnOnce`] sem mörk.
///
/// Sjá [chapter on closures in *The Rust Programming Language*][book] til að fá frekari upplýsingar um þetta efni.
///
/// Einnig er athyglisvert sérstök setningafræði fyrir `Fn` traits (td
/// `Fn(usize, bool) -> nota stærð ').Þeir sem hafa áhuga á tæknilegum upplýsingum um þetta geta vísað til [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Að hringja í lokun
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Notkun `Fn` breytu
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // svo að regex geti treyst því `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Framkvæmir símtalið.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Útgáfa símafyrirtækisins sem tekur breytanlegan móttakara.
///
/// Hægt er að hringja í tilvik `FnMut` og geta breytt stöðum.
///
/// `FnMut` er útfært sjálfkrafa með lokunum sem taka breytanlegar tilvísanir í teknar breytur, svo og allar gerðir sem útfæra [`Fn`], td (safe) [function pointers] (þar sem `FnMut` er yfirborð [`Fn`]).
/// Að auki, fyrir allar tegundir `F` sem útfærir `FnMut`, útfærir `&mut F` einnig `FnMut`.
///
/// Þar sem [`FnOnce`] er ofursvæði `FnMut`, er hægt að nota hvaða dæmi sem er af `FnMut` þar sem búist er við [`FnOnce`] og þar sem [`Fn`] er undirlið `FnMut` er hægt að nota hvaða dæmi [`Fn`] þar sem búist er við `FnMut`.
///
/// Notaðu `FnMut` sem bundið þegar þú vilt samþykkja breytu af aðgerðarlíkri gerð og þarft að hringja í hana ítrekað, meðan þú lætur hana breytast.
/// Ef þú vilt ekki að breytan verði stökkbreytt, notaðu [`Fn`] sem bundið;ef þú þarft ekki að hringja í það ítrekað skaltu nota [`FnOnce`].
///
/// Sjá [chapter on closures in *The Rust Programming Language*][book] til að fá frekari upplýsingar um þetta efni.
///
/// Einnig er athyglisvert sérstök setningafræði fyrir `Fn` traits (td
/// `Fn(usize, bool) -> nota stærð ').Þeir sem hafa áhuga á tæknilegum upplýsingum um þetta geta vísað til [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Hringir í að taka lokun sem breytilegt er
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Notkun `FnMut` breytu
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // svo að regex geti treyst því `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Framkvæmir símtalið.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Útgáfa símafyrirtækisins sem tekur aukamóttakara.
///
/// Dæmi um `FnOnce` er hægt að hringja í en það er ekki hægt að hringja í það mörgum sinnum.Vegna þessa, ef það eina sem vitað er um tegund er að hún útfærir `FnOnce`, er aðeins hægt að hringja í hana einu sinni.
///
/// `FnOnce` er útfært sjálfkrafa með lokunum sem gætu neytt fangaðra breytna, svo og allar gerðir sem innleiða [`FnMut`], td (safe) [function pointers] (þar sem `FnOnce` er yfirborð [`FnMut`]).
///
///
/// Þar sem bæði [`Fn`] og [`FnMut`] eru undirmyndir af `FnOnce` er hægt að nota hvaða dæmi sem er af [`Fn`] eða [`FnMut`] þar sem búist er við `FnOnce`.
///
/// Notaðu `FnOnce` sem bundið þegar þú vilt samþykkja breytu af aðgerðarlíkri gerð og þarft aðeins að hringja í hana einu sinni.
/// Ef þú þarft að hringja í breytuna ítrekað skaltu nota [`FnMut`] sem bundið;ef þú þarft það líka til að breyta ekki ástandinu, notaðu [`Fn`].
///
/// Sjá [chapter on closures in *The Rust Programming Language*][book] til að fá frekari upplýsingar um þetta efni.
///
/// Einnig er athyglisvert sérstök setningafræði fyrir `Fn` traits (td
/// `Fn(usize, bool) -> nota stærð ').Þeir sem hafa áhuga á tæknilegum upplýsingum um þetta geta vísað til [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Notkun `FnOnce` breytu
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` eyðir fanguðum breytum sínum, svo það er ekki hægt að keyra það oftar en einu sinni.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Tilraun til að ákalla `func()` aftur mun henda `use of moved value` villu fyrir `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` er ekki lengur hægt að kalla fram á þessum tímapunkti
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // svo að regex geti treyst því `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Skilin gerð eftir að símafyrirtækið er notað.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Framkvæmir símtalið.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}