//! Libcore prelude
//!
//! Þessi eining er ætluð notendum libcore sem tengjast ekki líka við libstd.
//! Þessi eining er flutt inn sjálfgefið þegar `#![no_std]` er notað á sama hátt og prelude staðalsafnsins.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// 2015 útgáfan af kjarna prelude.
///
/// Sjá [module-level documentation](self) fyrir meira.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// 2018 útgáfan af kjarna prelude.
///
/// Sjá [module-level documentation](self) fyrir meira.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// 2021 útgáfan af kjarna prelude.
///
/// Sjá [module-level documentation](self) fyrir meira.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Bættu við fleiri hlutum.
}