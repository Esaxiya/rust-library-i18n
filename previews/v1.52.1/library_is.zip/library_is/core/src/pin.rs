//! Tegundir sem festa gögn við staðsetningu þeirra í minni.
//!
//! Það er stundum gagnlegt að hafa hluti sem er tryggt að hreyfast ekki, í þeim skilningi að staðsetning þeirra í minni breytist ekki og því er hægt að treysta á þau.
//! Helsta dæmið um slíka atburðarás væri að byggja upp eigin vísbendingar, þar sem að færa hlut með ábendingum til sjálfs sín ógildir þá, sem gæti valdið óskilgreindri hegðun.
//!
//! Á háu stigi tryggir [`Pin<P>`] að bendilinn af hvaða bendi sem er af gerðinni `P` hafi stöðugan stað í minni, sem þýðir að það er ekki hægt að færa hann annað og minni er ekki hægt að úthluta honum fyrr en hann fellur niður.Við segjum að pointee sé "pinned".Hlutirnir verða lúmskari þegar rætt er um gerðir sem sameina festar við gögn sem ekki eru festar;[see below](#projections-and-structural-pinning) til að fá frekari upplýsingar.
//!
//! Sjálfgefið er að allar gerðir í Rust séu hreyfanlegar.
//! Rust gerir kleift að fara framhjá öllum gerðum með gildi og algengar tegundir snjallpinna eins og [`Box<T>`] og `&mut T` gera kleift að skipta um og færa gildin sem þau innihalda: þú getur farið úr [`Box<T>`] eða þú getur notað [`mem::swap`].
//! [`Pin<P>`] sveipar bendi af gerðinni `P`, svo [`Pin`]`<`[`Box`] `<T>>`virkar eins og venjulegur
//!
//! [`Box<T>`]: when a [`Pin`]`<`[`Box`] `<T>> fellur niður, svo verður innihald hennar og minnið fær
//!
//! samið.Á sama hátt er [`Pin`]`<&mut T>`mikið eins og `&mut T`.Hins vegar leyfir [`Pin<P>`] viðskiptavinum ekki raunverulega [`Box<T>`] eða `&mut T` í pinnagögn, sem gefur í skyn að þú getir ekki notað aðgerðir eins og [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` þarf `&mut T`, en við getum ekki fengið það.
//!     // Við erum föst, við getum ekki skipt um innihald þessara tilvísana.
//!     // Við gætum notað `Pin::get_unchecked_mut`, en það er óöruggt af ástæðu:
//!     // við megum ekki nota það til að færa hluti út úr `Pin`.
//! }
//! ```
//!
//! Það er rétt að ítreka að [`Pin<P>`] breytir *ekki* þeirri staðreynd að Rust þýðandi telur allar gerðir hreyfanlegar.[`mem::swap`] er áfram hægt að hringja í alla `T`.Þess í stað kemur [`Pin<P>`] í veg fyrir að hægt sé að færa tiltekin *gildi*(sem bent er á með ábendingum vafnum í [`Pin<P>`]) með því að gera ómögulegt að hringja í aðferðir sem krefjast `&mut T` á þeim (eins og [`mem::swap`]).
//!
//! [`Pin<P>`] er hægt að nota til að vefja hvaða bendi sem er af gerðinni `P`, og sem slík hefur hún samskipti við [`Deref`] og [`DerefMut`].A [`Pin<P>`] þar sem `P: Deref` ætti að líta á sem "`P`-style pointer" við festa `P::Target`-svo, [[Pin "]" <"[" Box "]"<T>> `er benti á `T` sem er festur og [` Pin`]`<`[`Rc`]`<T>> er tilvísunartalinn bendill á festan `T`.
//! Til að vera rétt, treystir [`Pin<P>`] á útfærslurnar á [`Deref`] og [`DerefMut`] að hreyfa sig ekki út úr `self` breytu sinni, og aðeins að skila bendi til fastra gagna þegar þeir eru kallaðir á festan bendil.
//!
//! # `Unpin`
//!
//! Margar tegundir eru alltaf lausar, jafnvel þegar þær eru festar, vegna þess að þær treysta ekki á að hafa stöðugt heimilisfang.Þetta felur í sér allar grunngerðir (eins og [`bool`], [`i32`] og tilvísanir) sem og gerðir sem samanstanda eingöngu af þessum gerðum.Tegundir sem ekki er sama um að festa útfærir [`Unpin`] sjálfvirka trait sem hættir við áhrif [`Pin<P>`].
//! Fyrir `T: Unpin`, [`Pin`]`<`[`Box`] '<T>> `og [`Box<T>`] virka eins, eins og [` Pin`]`<&mut T>` og `&mut T`.
//!
//! Athugaðu að klemmur og [`Unpin`] hafa aðeins áhrif á vísaðan gerð `P::Target`, ekki bendirinn `P` sjálfur sem vafinn var í [`Pin<P>`].Til dæmis hvort [`Box<T>`] er [`Unpin`] eða ekki hefur engin áhrif á hegðun [`Pin`]`<`[`Box`] `<T>>`(hér er `T` sú tegund sem bent er til).
//!
//! # Dæmi: sjálfsvísunarsamningur
//!
//! Áður en við förum í frekari upplýsingar til að útskýra ábyrgðina og valið sem tengist `Pin<T>`, ræðum við nokkur dæmi um hvernig það gæti verið notað.
//! Ekki hika við að [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Þetta er sjálfsvísandi uppbygging vegna þess að sneiðasviðið vísar á gagnareitinn.
//! // Við getum ekki upplýst þýðandann um það með eðlilegri tilvísun, þar sem ekki er hægt að lýsa þessu mynstri með venjulegum lántökureglum.
//! //
//! // Í staðinn notum við hráan bendil, þó að vitað sé að hann sé enginn, þar sem við vitum að hann vísar á strenginn.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Til að tryggja að gögnin hreyfist ekki þegar aðgerðin snýr aftur, leggjum við þau í hrúguna þar sem þau munu dvelja alla ævi hlutarins og eina leiðin til að fá aðgang að henni væri í gegnum bendi að henni.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // við búum aðeins til bendilinn þegar gögnin eru komin á sinn stað annars hafa þau þegar færst áður en við byrjuðum
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // við vitum að þetta er öruggt vegna þess að breyting á sviði hreyfir ekki allan uppbygginguna
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Bendillinn ætti að benda á rétta staðsetningu, svo framarlega sem strúktúrinn hefur ekki hreyfst.
//! //
//! // Á meðan er okkur frjálst að færa bendilinn um.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Þar sem gerð okkar innleiðir ekki Unpin, tekst ekki að setja saman:
//! // láta mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Dæmi: uppáþrengjandi tvöfalt tengdur listi
//!
//! Á uppáþrengjandi tvöfalt tengdum lista úthlutar safninu í raun ekki minni fyrir frumefnin sjálf.
//! Úthlutun er stjórnað af viðskiptavinum og þættir geta lifað á stafla ramma sem lifir styttra en söfnunin gerir.
//!
//! Til að þetta gangi upp hefur hver þáttur vísbendingar um forvera sinn og eftirmann á listanum.Aðeins er hægt að bæta við þáttum þegar þeir eru festir, því að færa þættina í kring myndi ógilda ábendingarnar.Þar að auki mun [`Drop`] útfærsla á tengdum listaþætti plástra vísbendingar forvera síns og eftirmanns til að fjarlægja sig af listanum.
//!
//! Afgerandi, við verðum að geta treyst því að [`drop`] sé kallaður.Ef hægt væri að framselja þætti eða ógilda á annan hátt án þess að hringja í [`drop`], myndu vísar inn í það frá nálægum þáttum þess verða ógildir, sem myndi brjóta gagnasamsetningu.
//!
//! Þess vegna fylgir pinning einnig ábyrgð sem tengist [`drop`].
//!
//! # `Drop` guarantee
//!
//! Tilgangurinn með festingu er að geta treyst á staðsetningu nokkurra gagna í minni.
//! Til að þetta gangi upp er ekki bara takmarkað að færa gögnin;takmörkun á minni, endurnýtingu eða á annan hátt ógildingu á minni sem notað er til að geyma gögnin er einnig takmarkað.
//! Sérstaklega, fyrir pinnagögn, verður þú að viðhalda þeim breytileika að *minni þess verður ekki ógilt eða endurnýtt frá því að það festist þar til þegar [`drop`] er kallað*.Aðeins þegar [`drop`] snýr aftur eða panics, er hægt að endurnýta minnið.
//!
//! Minni getur verið "invalidated" með samnýtingu en einnig með því að skipta um [`Some(v)`] fyrir [`None`] eða kalla [`Vec::set_len`] til "kill" einhverja þætti frá vector.Það er hægt að nota það aftur með því að nota [`ptr::write`] til að skrifa upp á það án þess að hringja í tortímandann fyrst.Ekkert af þessu er leyfilegt fyrir pinnagögn án þess að hringja í [`drop`].
//!
//! Þetta er nákvæmlega þess háttar ábyrgð að uppáþrengjandi tengdur listi úr fyrri hlutanum þarf að virka rétt.
//!
//! Takið eftir að þessi ábyrgð þýðir *ekki* að minni leki ekki!Það er samt alveg í lagi að hringja aldrei í [`drop`] á festan þátt (td. Þú getur samt hringt í [`mem::forget`] á [`Pin`]`<`[Box`]`<T>> `).Í dæminu um tvöfalt tengda listann myndi sá þáttur bara vera á listanum.Hins vegar máttu ekki losa eða endurnýta geymsluna *án þess að hringja í [`drop`]*.
//!
//! # `Drop` implementation
//!
//! Ef tegund þín notar festingu (eins og tvö dæmi hér að ofan), verður þú að vera varkár þegar þú framkvæmir [`Drop`].Aðgerðin [`drop`] tekur `&mut self`, en þetta er kallað *jafnvel þó að gerð þín hafi áður verið fest*!Það er eins og þýðandinn kalli sjálfkrafa [`Pin::get_unchecked_mut`].
//!
//! Þetta getur aldrei valdið vandamálum í öruggum kóða vegna þess að útfærsla á gerð sem reiðir sig á festingu krefst óöruggrar kóða, en vertu meðvitaður um að ákveða að nota pinna í þína tegund (til dæmis með því að framkvæma einhverja aðgerð á [`Pin`]`<&Sjálf>`eða [`Pin`] `<&mut Self>`) hefur líka afleiðingar fyrir [`Drop`] framkvæmdina þína: Ef hluti af þessari gerð hefði verið hægt að festa þig, verður þú að meðhöndla [`Drop`] eins og með óbeinum hætti að taka [`Pin`]`<&mut Sjálf>`.
//!
//!
//! Til dæmis gætirðu innleitt `Drop` á eftirfarandi hátt:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` er í lagi vegna þess að við vitum að þetta gildi er aldrei notað aftur eftir að hafa verið lækkað.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Raunverulegur dropakóði fer hér.
//!         }
//!     }
//! }
//! ```
//!
//! Aðgerðin `inner_drop` hefur þá gerð sem [`drop`]*ætti* að hafa og því er tryggt að þú notir ekki óvart `self`/`this` á þann hátt sem stangast á við pinning.
//!
//! Þar að auki, ef gerð þín er `#[repr(packed)]`, fær þýðandinn sjálfkrafa reiti til að geta sleppt þeim.Það gæti jafnvel gert það fyrir reiti sem verða að vera nægilega samstilltir.Þar af leiðandi er ekki hægt að nota festingu með `#[repr(packed)]` gerð.
//!
//! # Framreikningar og burðarvirki
//!
//! Þegar unnið er með pinnaböndum vaknar sú spurning hvernig hægt er að fá aðgang að sviðum þess strúts með aðferð sem tekur bara [`Pin`]`<&mut Struct>`.
//! Venjuleg nálgun er að skrifa hjálparaðferðir (svokallaðar *framreikningar*) sem breyta [`Pin`]`<&mut Struct>`í tilvísun í reitinn, en hvaða tegund ætti sú tilvísun að hafa?Er það [`Pin`]`<&mut Field>`eða `&mut Field`?
//! Sama spurning vaknar við reiti `enum` og einnig þegar litið er á container/wrapper gerðir eins og [`Vec<T>`], [`Box<T>`] eða [`RefCell<T>`].
//! (Þessi spurning á við bæði umbreytanlegar og sameiginlegar tilvísanir, við notum bara algengara tilfelli breytanlegra tilvísana hér til dæmis.)
//!
//! Það kemur í ljós að það er í raun og veru höfundar gagnaskipulagsins að ákveða hvort festa vörpun fyrir tiltekinn reit breytir [`Pin`]`<&mut Struct>`í [`Pin`] `<&mut Field>` eða `&mut Field`.Það eru þó nokkrar hömlur og mikilvægasta þvingunin er *samkvæmni*:
//! hvert svið er hægt að *annaðhvort* varpað með festri tilvísun,*eða* hafa pinning fjarlægð sem hluta af vörpuninni.
//! Ef báðir eru gerðir fyrir sama reitinn þá er það líklega ósætt!
//!
//! Sem höfundur gagnaskipta færðu að ákveða fyrir hvert svið hvort þú festir "propagates" við þennan reit eða ekki.
//! Pinning sem breiðist út er einnig kallað "structural", vegna þess að það fylgir uppbyggingu gerðarinnar.
//! Í eftirfarandi undirköflum lýsum við þeim sjónarmiðum sem þarf að gera varðandi annað hvort valið.
//!
//! ## Pinning *er ekki* uppbyggilegt fyrir `field`
//!
//! Það kann að virðast gagnkvæmt að reitur á festum strúktúr sé kannski ekki festur, en það er í raun auðveldasta valið: ef [[Pin "]" <&mut Field> "er aldrei búið til, þá getur ekkert farið úrskeiðis!Svo ef þú ákveður að einhver reitur sé ekki með uppbyggingu, þá þarftu aðeins að tryggja að þú búir aldrei til festa tilvísun í þann reit.
//!
//! Svið án burðarvirks festingar geta haft vörpunaraðferð sem breytir [`Pin`]`<&mut Struct>`í `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Þetta er í lagi vegna þess að `field` er aldrei talinn fastur.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Þú getur líka `impl Unpin for Struct`*, jafnvel þó að* gerð `field` sé ekki [`Unpin`].Hvað sú tegund hugsar um festingu á ekki við þegar enginn [`Pin`]`<&mut Field>`er nokkurn tíma búinn til.
//!
//! ## Pinning *er* uppbygging fyrir `field`
//!
//! Hinn möguleikinn er að ákveða að festing sé "structural" fyrir `field`, sem þýðir að ef uppbyggingin er fest, þá er svæðið líka.
//!
//! Þetta gerir kleift að skrifa vörpun sem býr til [`Pin`]`<&mut Field>`og vitna þannig að reiturinn er festur:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Þetta er í lagi því `field` er festur þegar `self` er.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Hins vegar fylgir burðarvirki nokkur aukakröfur:
//!
//! 1. Uppbyggingin verður aðeins að vera [`Unpin`] ef öll uppbyggingarsviðin eru [`Unpin`].Þetta er sjálfgefið, en [`Unpin`] er öruggur trait, svo sem höfundur uppbyggingarinnar er það á þína ábyrgð *ekki* að bæta við eitthvað eins og `impl<T> Unpin for Struct<T>`.
//! (Takið eftir að bæta við vörpunaraðgerð krefst ótryggs kóða, þannig að sú staðreynd að [`Unpin`] er öruggur trait brýtur ekki meginregluna um að þú þurfir aðeins að hafa áhyggjur af neinu af þessu ef þú notar " óöruggt`.)
//! 2. Eyðileggjandi uppbyggingarinnar má ekki færa uppbyggingarsvið úr rökum sínum.Þetta er nákvæmlega punkturinn sem var hækkaður í [previous section][drop-impl]: `drop` tekur `&mut self`, en uppbyggingin (og þar með reitirnir) gæti hafa verið festur áður.
//!     Þú verður að ábyrgjast að þú færir ekki reit innan [`Drop`] útfærslunnar.
//!     Sérstaklega, eins og áður var útskýrt, þýðir þetta að uppbygging þín má *ekki* vera `#[repr(packed)]`.
//!     Sjá þann kafla um hvernig á að skrifa [`drop`] á þann hátt að þýðandinn geti hjálpað þér að rífa ekki óvart niður.
//! 3. Þú verður að ganga úr skugga um að þú haldir uppi [`Drop` guarantee][drop-guarantee]:
//!     þegar uppbygging þín hefur verið fest, verður minni sem inniheldur innihaldið ekki skrifað yfir eða framselt án þess að kalla á eyðileggjendur efnisins.
//!     Þetta getur verið erfiður, eins og [`VecDeque<T>`] vitni um: eyðileggjandi [`VecDeque<T>`] getur ekki kallað [`drop`] á alla þætti ef einn af eyðileggjendum panics.Þetta brýtur í bága við [`Drop`] ábyrgðina, vegna þess að það getur leitt til þess að hlutum sé úthlutað án þess að eyðandi þeirra sé kallaður til.([`VecDeque<T>`] hefur engar pinningar, þannig að þetta veldur ekki óheilindum.)
//! 4. Þú mátt ekki bjóða upp á aðrar aðgerðir sem gætu leitt til þess að gögn væru færð út úr burðarvirki þegar gerð þín er fest.Til dæmis, ef strúktúrinn inniheldur [`Option<T>`] og það er " taka`-lík aðgerð af gerðinni `fn(Pin<&mut Struct<T>>) -> Option<T>`, þá er hægt að nota þá aðgerð til að færa `T` út úr festri `Struct<T>`-sem þýðir að pinning getur ekki verið uppbygging fyrir reitinn sem heldur þessu gögn.
//!
//!     Fyrir flóknara dæmi um að færa gögn úr festri gerð, ímyndaðu þér hvort [`RefCell<T>`] hefði aðferðina `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Þá gætum við gert eftirfarandi:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Þetta er hörmulegt, það þýðir að við getum fyrst pinnað innihald [`RefCell<T>`] (með því að nota `RefCell::get_pin_mut`) og síðan fært það efni með því að breyta breytilegri tilvísun sem við fengum seinna.
//!
//! ## Examples
//!
//! Fyrir tegund eins og [`Vec<T>`] eru báðir möguleikarnir (skipulegir festingar eða ekki) skynsamlegir.
//! [`Vec<T>`] með burðarvirki gæti verið með `get_pin`/`get_pin_mut` aðferðir til að fá festar tilvísanir í þætti.Hins vegar gat það *ekki* leyft að hringja í [`pop`][Vec::pop] á festan [`Vec<T>`] vegna þess að það myndi færa (uppbyggt fest) innihald!Það gat heldur ekki leyft [`push`][Vec::push], sem gæti endurúthlutað og þannig einnig flutt innihaldið.
//!
//! [`Vec<T>`] án uppbyggingar festingar gæti `impl<T> Unpin for Vec<T>`, vegna þess að innihaldið er aldrei fest og [`Vec<T>`] sjálft er fínt með því að vera flutt líka.
//! Á þeim tímapunkti hefur pinning bara engin áhrif á vector.
//!
//! Í stöðluðu bókasafninu eru benditegundir yfirleitt ekki með skipulegar festingar og þannig bjóða þær ekki upp á útskot.Þetta er ástæðan fyrir því að `Box<T>: Unpin` gildir fyrir alla `T`.
//! Það er skynsamlegt að gera þetta fyrir bendilategundir, því að hreyfa `Box<T>` hreyfir í raun ekki `T`: [`Box<T>`] getur verið frjálslega hreyfanlegt (aka `Unpin`) jafnvel þó `T` sé það ekki.Reyndar, jafnvel [`Pin`]`<`[`Box`] `<T>>`og [`Pin`] `<&mut T>` eru alltaf [`Unpin`] sjálfir, af sömu ástæðu: innihald þeirra (`T`) er fest, en hægt er að færa vísbendingarnar sjálfar án þess að færa festu gögnin.
//! Fyrir bæði [`Box<T>`] og [`Pin`]`<`[`Box`] `<T>>`, hvort innihaldið er fest, er algjörlega óháð því hvort bendillinn er festur, sem þýðir að festing er *ekki* uppbyggileg.
//!
//! Þegar [`Future`] combinator er útfærður þarftu venjulega uppbyggingu að festa fyrir hreiður futures, þar sem þú þarft að fá festar tilvísanir til þeirra til að hringja í [`poll`].
//! En ef sameiningartækið þitt inniheldur önnur gögn sem ekki þarf að pinna, geturðu gert þá reiti ekki uppbyggilega og þess vegna frjálslega fengið aðgang að þeim með breytilegri tilvísun, jafnvel þegar þú ert bara með [`Pin`]`<&mut Self>`(svo eins og í eigin [`poll`] útfærslu).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Bindur bendill.
///
/// Þetta er umbúðir utan um eins konar bendi sem gerir þann bendi "pin" að gildi sínu á sínum stað og kemur í veg fyrir að gildi sem vísað er til af þeim bendi færist nema það útfærir [`Unpin`].
///
///
/// *Sjá [`pin` module] skjöl til að fá skýringar á festingu.*
///
/// [`pin` module]: self
///
// Note: `Clone` afleiðingin hér að neðan veldur óheilbrigði þar sem það er mögulegt að hrinda í framkvæmd
// `Clone` fyrir breytilegar tilvísanir.
// Sjá <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> fyrir frekari upplýsingar.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Eftirfarandi útfærslur eru ekki unnar til að koma í veg fyrir vandræði varðandi hljóð.
// `&self.pointer` ætti ekki að vera aðgengilegt fyrir ótraustar trait útfærslur.
//
// Sjá <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> fyrir frekari upplýsingar.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Búðu til nýjan `Pin<P>` í kringum bendi við nokkur gögn af þeirri gerð sem útfærir [`Unpin`].
    ///
    /// Ólíkt `Pin::new_unchecked` er þessi aðferð örugg vegna þess að bendillinn `P` vísar til [`Unpin`]-gerðar sem fellir niður pinnatryggingarnar.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // ÖRYGGI: gildi sem bent er á er `Unpin` og hefur því engar kröfur
        // í kringum pinning.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Afpakkar þennan `Pin<P>` sem skilar undirliggjandi bendi.
    ///
    /// Þetta krefst þess að gögnin innan þessa `Pin` séu [`Unpin`] svo að við getum hunsað festingarnar sem festast þegar við pakka þeim út.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Búðu til nýjan `Pin<P>` í kringum tilvísun í nokkur gögn af þeirri gerð sem kann að innleiða `Unpin` eða ekki.
    ///
    /// Ef `pointer` er vísað til `Unpin` tegundar ætti að nota `Pin::new` í staðinn.
    ///
    /// # Safety
    ///
    /// Þessi smiður er óöruggur vegna þess að við getum ekki ábyrgst að gögnin sem `pointer` bendir á séu fest, sem þýðir að gögnin verða ekki færð eða geymsla þeirra ógild fyrr en þau falla niður.
    /// Ef smíðaði `Pin<P>` ábyrgist ekki að gögnin sem `P` bendir á séu fest, þá er það brot á API-samningnum og getur leitt til óskilgreindrar hegðunar í síðari (safe) aðgerðum.
    ///
    /// Með því að nota þessa aðferð ertu að búa til promise um `P::Deref` og `P::DerefMut` útfærslurnar, ef þær eru til.
    /// Mikilvægast er að þeir mega ekki færa sig út úr `self` rökum sínum: `Pin::as_mut` og `Pin::as_ref` munu hringja í `DerefMut::deref_mut` og `Deref::deref`*á pinnabendinu* og búast við að þessar aðferðir haldi fast við pinnandi invariants.
    /// Þar að auki, með því að kalla þessa aðferð promise að tilvísunin `P` dereferences til verði ekki færð út aftur;sérstaklega, það má ekki vera hægt að fá `&mut P::Target` og færa sig síðan út úr þeirri tilvísun (með því að nota til dæmis [`mem::swap`]).
    ///
    ///
    /// Til dæmis, að hringja í `Pin::new_unchecked` í `&'a mut T` er ekki öruggt vegna þess að á meðan þú ert fær um að pinna það í tiltekinn líftíma `'a`, hefur þú enga stjórn á því hvort það sé haldið klemmt þegar `'a` lýkur:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Þetta ætti að þýða að pointee `a` getur aldrei hreyft sig aftur.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Heimilisfangið á `a` breyttist í stafla rauf 'b', þannig að `a` færðist þó að við höfum áður fest það!Við höfum brotið gegn festingu API samningsins.
    /////
    /// }
    /// ```
    ///
    /// Gildi, þegar það hefur verið fest, verður að vera fast að eilífu (nema gerð þess útfærir `Unpin`).
    ///
    /// Á sama hátt er óöruggt að hringja í `Pin::new_unchecked` í `Rc<T>` vegna þess að það geta verið samnefni við sömu gögn sem ekki eru háð takmörkun á festingum:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Þetta ætti að þýða að vísbendingin getur aldrei hreyft sig aftur.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Nú, ef `x` var eina tilvísunin, höfum við breytanlega tilvísun í gögn sem við festum hér að ofan, sem við gætum notað til að færa þau eins og við höfum séð í fyrra dæminu.
    ///     // Við höfum brotið gegn festingu API samningsins.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Fær samnýtta tilvísun frá þessum festa bendi.
    ///
    /// Þetta er almenn aðferð til að fara úr `&Pin<Pointer<T>>` í `Pin<&T>`.
    /// Það er öruggt vegna þess að sem hluti af samningnum um `Pin::new_unchecked` getur leiðbeinandi ekki hreyft sig eftir að `Pin<Pointer<T>>` var búinn til.
    ///
    /// "Malicious" útfærslur á `Pointer::Deref` eru sömuleiðis útilokaðar í samningnum um `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // ÖRYGGI: sjá skjöl um þessa aðgerð
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Afpakkar þennan `Pin<P>` sem skilar undirliggjandi bendi.
    ///
    /// # Safety
    ///
    /// Þessi aðgerð er óörugg.Þú verður að ábyrgjast að þú haldir áfram að meðhöndla bendilinn `P` eins og hann er festur eftir að þú kallar á þessa aðgerð, svo hægt sé að halda utan um invariants af gerðinni `Pin`.
    /// Ef kóðinn sem notar `P`, sem myndast, heldur ekki áfram að viðhalda þeim fasta invariants sem er brot á API samningnum og getur leitt til óskilgreindrar hegðunar í síðari (safe) aðgerðum.
    ///
    ///
    /// Ef undirliggjandi gögn eru [`Unpin`], ætti að nota [`Pin::into_inner`] í staðinn.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Fær festa breytanlega tilvísun frá þessum festa bendi.
    ///
    /// Þetta er almenn aðferð til að fara úr `&mut Pin<Pointer<T>>` í `Pin<&mut T>`.
    /// Það er öruggt vegna þess að sem hluti af samningnum um `Pin::new_unchecked` getur leiðbeinandi ekki hreyft sig eftir að `Pin<Pointer<T>>` var búinn til.
    ///
    /// "Malicious" útfærslur á `Pointer::DerefMut` eru sömuleiðis útilokaðar í samningnum um `Pin::new_unchecked`.
    ///
    /// Þessi aðferð er gagnleg þegar hringt er í aðgerðir sem neyta fastar tegundar.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // gera eitthvað
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` eyðir `self`, svo endurláni `Pin<&mut Self>` um `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // ÖRYGGI: sjá skjöl um þessa aðgerð
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Úthlutar nýju gildi í minnið á bak við festu tilvísunina.
    ///
    /// Þetta skrifar yfir festar gögn, en það er allt í lagi: eyðileggjandi þess keyrir áður en það er skrifað yfir, þannig að engin festingarábyrgð er brotin.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Smíðar nýjan pinna með því að kortleggja innra gildi.
    ///
    /// Til dæmis, ef þú vildir fá `Pin` af sviði af einhverju, gætirðu notað þetta til að fá aðgang að því sviði í einni línu af kóða.
    /// Hins vegar eru nokkur gotchas með þessum "pinning projections";
    /// sjá [`pin` module] skjöl fyrir frekari upplýsingar um það efni.
    ///
    /// # Safety
    ///
    /// Þessi aðgerð er óörugg.
    /// Þú verður að tryggja að gögnin sem þú skilar hreyfist ekki svo lengi sem rökgildið hreyfist ekki (til dæmis vegna þess að það er einn af reitunum í því gildi) og einnig að þú færir þig ekki út úr rökunum sem þú færð til aðgerð innanhúss.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // ÖRYGGI: öryggissamningur fyrir `new_unchecked` verður að vera
        // staðfest af þeim sem hringir.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Fær sameiginlega tilvísun úr pinna.
    ///
    /// Þetta er öruggt vegna þess að það er ekki hægt að færa sig út úr sameiginlegri tilvísun.
    /// Það kann að virðast eins og það sé vandamál hér með innri breytileika: í raun er *mögulegt* að færa `T` út úr `&RefCell<T>`.
    /// Þetta er þó ekki vandamál svo framarlega að það sé ekki til `Pin<&T>` sem bendir á sömu gögn og `RefCell<T>` leyfir þér ekki að búa til festa tilvísun í innihald þeirra.
    ///
    /// Sjá umfjöllun um ["pinning projections"] fyrir frekari upplýsingar.
    ///
    /// Note: `Pin` útfærir einnig `Deref` að markmiðinu, sem hægt er að nota til að fá aðgang að innra gildi.
    /// Hins vegar veitir `Deref` aðeins tilvísun sem lifir eins lengi og lánið af `Pin`, ekki líftími `Pin` sjálfs.
    /// Þessi aðferð gerir kleift að breyta `Pin` í viðmiðun með sömu líftíma og upprunalega `Pin`.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Breytir þessum `Pin<&mut T>` í `Pin<&T>` með sömu líftíma.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Fær breytanlega tilvísun í gögnin innan þessa `Pin`.
    ///
    /// Þetta krefst þess að gögnin í þessum `Pin` séu `Unpin`.
    ///
    /// Note: `Pin` útfærir einnig `DerefMut` við gögnin, sem hægt er að nota til að fá aðgang að innra gildi.
    /// Hins vegar veitir `DerefMut` aðeins tilvísun sem lifir eins lengi og lánið af `Pin`, ekki líftími `Pin` sjálfs.
    ///
    /// Þessi aðferð gerir kleift að breyta `Pin` í viðmiðun með sömu líftíma og upprunalega `Pin`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Fær breytanlega tilvísun í gögnin innan þessa `Pin`.
    ///
    /// # Safety
    ///
    /// Þessi aðgerð er óörugg.
    /// Þú verður að ábyrgjast að þú færir aldrei gögnin út úr breytanlegu tilvísuninni sem þú færð þegar þú kallar á þessa aðgerð, svo hægt sé að halda utan um invariants af gerðinni `Pin`.
    ///
    ///
    /// Ef undirliggjandi gögn eru `Unpin`, ætti að nota `Pin::get_mut` í staðinn.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Búðu til nýjan pinna með því að kortleggja innra gildi.
    ///
    /// Til dæmis, ef þú vildir fá `Pin` af sviði af einhverju, gætirðu notað þetta til að fá aðgang að því sviði í einni línu af kóða.
    /// Hins vegar eru nokkur gotchas með þessum "pinning projections";
    /// sjá [`pin` module] skjöl fyrir frekari upplýsingar um það efni.
    ///
    /// # Safety
    ///
    /// Þessi aðgerð er óörugg.
    /// Þú verður að tryggja að gögnin sem þú skilar hreyfist ekki svo lengi sem rökgildið hreyfist ekki (til dæmis vegna þess að það er einn af reitunum í því gildi) og einnig að þú færir þig ekki út úr rökunum sem þú færð til aðgerð innanhúss.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // ÖRYGGI: sá sem hringir er ábyrgur fyrir því að hreyfa ekki
        // gildi út af þessari tilvísun.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // ÖRYGGI: þar sem verðmæti `this` er ekki tryggt
        // verið flutt út, þetta símtal til `new_unchecked` er öruggt.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Fáðu festa tilvísun frá kyrrstöðu tilvísun.
    ///
    /// Þetta er öruggt, því `T` er fenginn að láni fyrir `'static` ævina sem endar aldrei.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // ÖRYGGI: Stöðulánin tryggja að gögnin verða ekki
        // moved/invalidated þar til það fellur niður (sem er aldrei).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Fáðu pinned breytilegt tilvísun frá statískri breytanlegri tilvísun.
    ///
    /// Þetta er öruggt, því `T` er fenginn að láni fyrir `'static` ævina sem endar aldrei.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // ÖRYGGI: Stöðulánin tryggja að gögnin verða ekki
        // moved/invalidated þar til það fellur niður (sem er aldrei).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: þetta þýðir að allir implantar af `CoerceUnsized` sem leyfa nauðung frá
// tegund sem impls `Deref<Target=impl !Unpin>` að gerð sem impls `Deref<Target=Unpin>` er ósund.
// Allar slíkar tegundir væru líklega óheiðarlegar af öðrum ástæðum, svo við verðum bara að gæta þess að leyfa slíkum tækjum ekki að lenda í std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}