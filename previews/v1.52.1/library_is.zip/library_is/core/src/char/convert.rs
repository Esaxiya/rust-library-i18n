//! Persónubreytingar.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Breytir `u32` í `char`.
///
/// Athugaðu að allar [`char`] eru gildar [`u32`] s og hægt er að steypa þær til einnar með
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Hins vegar er hið gagnstæða ekki satt: ekki eru allir gildir [`u32`] gildir [`char`].
/// `from_u32()` mun skila `None` ef inntakið er ekki gild gildi fyrir [`char`].
///
/// Fyrir óörugga útgáfu af þessari aðgerð sem hunsar þessar athuganir, sjá [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Grunn notkun:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Aftur `None` þegar inntakið er ekki gilt [`char`]:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Breytir `u32` í `char` og hunsar gildi.
///
/// Athugaðu að allar [`char`] eru gildar [`u32`] s og hægt er að steypa þær til einnar með
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Hins vegar er hið gagnstæða ekki satt: ekki eru allir gildir [`u32`] gildir [`char`].
/// `from_u32_unchecked()` mun hunsa þetta og steypa í blindni á [`char`], mögulega búa til ógilt.
///
///
/// # Safety
///
/// Þessi aðgerð er óörugg þar sem hún getur búið til ógild `char` gildi.
///
/// Fyrir örugga útgáfu af þessari aðgerð, sjá [`from_u32`] aðgerðina.
///
/// # Examples
///
/// Grunn notkun:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // ÖRYGGI: sá sem hringir þarf að ábyrgjast að `i` sé gilt gildi.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Breytir [`char`] í [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Breytir [`char`] í [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Bleikjan er steypt að gildi kóðapunktsins, síðan núlllengd í 64 bita.
        // Sjá [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Breytir [`char`] í [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Bleikjan er steypt að gildi kóðapunktsins, síðan núll framlengd í 128 bita.
        // Sjá [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Kortleggur bæti í 0x00 ..=0xFF við `char` þar sem kóðapunkturinn hefur sama gildi, í U + 0000 ..=U + 00FF.
///
/// Unicode er hannað þannig að þetta afkóðar í raun bæti með stafakóðuninni sem IANA kallar ISO-8859-1.
/// Þessi kóðun er samhæft við ASCII.
///
/// Athugið að þetta er frábrugðið ISO/IEC 8859-1 aka
/// ISO 8859-1 (með einu bandstriki minna), sem skilur eftir sig nokkur "blanks", bæti gildi sem ekki er úthlutað neinum staf.
/// ISO-8859-1 (IANA one) úthlutar þeim til C0 og C1 stjórnkóða.
///
/// Athugið að þetta er *líka* frábrugðið Windows-1252 aka
/// kóðasíðu 1252, sem er ofursett ISO/IEC 8859-1 sem úthlutar sumum (ekki öllum!) eyðum við greinarmerki og ýmsum latneskum stöfum.
///
/// Til að rugla hlutina frekar eru [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` og `windows-1252` öll samheiti fyrir ofgnótt Windows-1252 sem fyllir eyðurnar sem eftir eru með samsvarandi C0 og C1 stjórnkóða.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Breytir [`u8`] í [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Villa sem hægt er að skila við þáttun bleikju.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // ÖRYGGI: athugað hvort það sé löglegt unicode gildi
            Ok(unsafe { transmute(i) })
        }
    }
}

/// Villutegundin skilaði sér þegar umbreyting úr u32 í bleikju mistókst.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Breytir tölustaf í gefnum radix í `char`.
///
/// 'radix' hérna er stundum einnig kallaður 'base'.
/// Radix af tveimur táknar tvíundatölu, radix af tíu, aukastaf og sextán radix, hexadecimal, til að gefa nokkur sameiginleg gildi.
///
/// Geðþótta geislar eru studdir.
///
/// `from_digit()` mun skila `None` ef inntakið er ekki tölustafur í tilteknum radix.
///
/// # Panics
///
/// Panics ef radix er stærri en 36.
///
/// # Examples
///
/// Grunn notkun:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Tugastafur 11 er eins tölustafur í grunn 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Aftur `None` þegar inntakið er ekki stafur:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Að fara framhjá stórum radix og valda panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}