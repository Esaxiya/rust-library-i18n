//! Trait útfærslur fyrir `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Útfærir röðun strengja.
///
/// Strengjum er raðað [lexicographically](Ord#lexicographical-comparison) eftir byte-gildum.
/// Þetta pantar Unicode kóða punkta byggt á stöðu þeirra í kóða töflunum.
/// Þetta er ekki endilega það sama og "alphabetical" röð, sem er mismunandi eftir tungumálum og tungumálum.
/// Til að flokka strengi samkvæmt menningarlegum viðurkenndum stöðlum þarf staðbundin gögn sem eru utan gildissviðs `str`-gerðarinnar.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Framkvæmir samanburðaraðgerðir á strengjum.
///
/// Strengir eru bornir saman [lexicographically](Ord#lexicographical-comparison) með bæti gildi þeirra.
/// Þetta ber saman Unicode kóða punkta byggt á stöðu þeirra í kóða töflunum.
/// Þetta er ekki endilega það sama og "alphabetical" röð, sem er mismunandi eftir tungumálum og tungumálum.
/// Til að bera saman strengi samkvæmt menningarlegum viðurkenndum stöðlum þarf staðbundin gögn sem eru utan gildissviðs `str`-gerðarinnar.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Útfærir undirstreng sneiðar með setningafræði `&self[..]` eða `&mut self[..]`.
///
/// Skilar sneið af öllum strengnum, þ.e. skilar `&self` eða `&mut self`.Jafngildir `&sjálf [0 ..
/// len] `eða`&mut sjálf [0 ..
/// len]`.
/// Ólíkt öðrum flokkunaraðgerðum getur þetta aldrei panic.
///
/// Þessi aðgerð er *O*(1).
///
/// Fyrir 1.20.0 voru þessar flokkunaraðgerðir enn studdar af beinni útfærslu á `Index` og `IndexMut`.
///
/// Jafngildir `&self[0 .. len]` eða `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Útfærir undirstreng sneiðar með setningafræði `&self[begin .. end]` eða `&mut self[begin .. end]`.
///
/// Skilar sneið af gefnum streng frá byte sviðinu [`byrja`, `end`).
///
/// Þessi aðgerð er *O*(1).
///
/// Fyrir 1.20.0 voru þessar flokkunaraðgerðir enn studdar af beinni útfærslu á `Index` og `IndexMut`.
///
/// # Panics
///
/// Panics ef `begin` eða `end` benda ekki á upphafsbæti móti stafs (eins og skilgreint er af `is_char_boundary`), ef `begin > end`, eða ef `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // þetta mun panic:
/// // bæti 2 liggur innan `ö`:
/// // &s [2 ..3];
///
/// // byte 8 liggur innan `老`&s [1 ..
/// // 8];
///
/// // bæti 100 er fyrir utan strenginn&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // ÖRYGGI: athugaði bara hvort `start` og `end` eru á bleikjumörkum,
            // og við erum að fara í örugga tilvísun, þannig að ávöxtunargildið verður líka eitt.
            // Við athuguðum líka bleikjumörk, þannig að þetta gildir UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // ÖRYGGI: bara athugað hvort `start` og `end` séu á bleikjumörkum.
            // Við vitum að bendillinn er einstakur vegna þess að við fengum hann frá `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // ÖRYGGI: kallinn ábyrgist að `self` sé innan `slice`
        // sem uppfyllir öll skilyrði fyrir `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // ÖRYGGI: sjá athugasemdir við `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary athugar hvort vísitalan sé í [0, .len()] getur ekki endurnýtt `get` eins og að ofan, vegna NLL vandræða
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // ÖRYGGI: athugaði bara hvort `start` og `end` eru á bleikjumörkum,
            // og við erum að fara í örugga tilvísun, þannig að ávöxtunargildið verður líka eitt.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Útfærir undirstreng sneiðar með setningafræði `&self[.. end]` eða `&mut self[.. end]`.
///
/// Skilar sneið af gefnum streng frá byte sviðinu [`0`, `end`).
/// Jafngildir `&self[0 .. end]` eða `&mut self[0 .. end]`.
///
/// Þessi aðgerð er *O*(1).
///
/// Fyrir 1.20.0 voru þessar flokkunaraðgerðir enn studdar af beinni útfærslu á `Index` og `IndexMut`.
///
/// # Panics
///
/// Panics ef `end` bendir ekki á byrjunarbæti móti stafs (eins og skilgreint er af `is_char_boundary`), eða ef `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // ÖRYGGI: athugaði bara hvort `end` er á bleikjumörkum,
            // og við erum að fara í örugga tilvísun, þannig að ávöxtunargildið verður líka eitt.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // ÖRYGGI: athugaði bara hvort `end` er á bleikjumörkum,
            // og við erum að fara í örugga tilvísun, þannig að ávöxtunargildið verður líka eitt.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // ÖRYGGI: athugaði bara hvort `end` er á bleikjumörkum,
            // og við erum að fara í örugga tilvísun, þannig að ávöxtunargildið verður líka eitt.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Útfærir undirstreng sneiðar með setningafræði `&self[begin ..]` eða `&mut self[begin ..]`.
///
/// Skilar sneið af gefnum streng frá byte sviðinu [`byrja`, `len`).Jafngildir `&sjálf [byrja ..
/// len] `eða`&mut sjálf [byrja ..
/// len]`.
///
/// Þessi aðgerð er *O*(1).
///
/// Fyrir 1.20.0 voru þessar flokkunaraðgerðir enn studdar af beinni útfærslu á `Index` og `IndexMut`.
///
/// # Panics
///
/// Panics ef `begin` bendir ekki á byrjunarbæti móti stafs (eins og skilgreint er af `is_char_boundary`), eða ef `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // ÖRYGGI: athugaði bara hvort `start` er á bleikjumörkum,
            // og við erum að fara í örugga tilvísun, þannig að ávöxtunargildið verður líka eitt.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // ÖRYGGI: athugaði bara hvort `start` er á bleikjumörkum,
            // og við erum að fara í örugga tilvísun, þannig að ávöxtunargildið verður líka eitt.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // ÖRYGGI: kallinn ábyrgist að `self` sé innan `slice`
        // sem uppfyllir öll skilyrði fyrir `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // ÖRYGGI: eins og `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // ÖRYGGI: athugaði bara hvort `start` er á bleikjumörkum,
            // og við erum að fara í örugga tilvísun, þannig að ávöxtunargildið verður líka eitt.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Útfærir undirstreng sneiðar með setningafræði `&self[begin ..= end]` eða `&mut self[begin ..= end]`.
///
/// Skilar sneið af gefnum streng frá byte sviðinu [`begin`, `end`].Jafngildir `&self [begin .. end + 1]` eða `&mut self[begin .. end + 1]`, nema að `end` hafi hámarksgildi fyrir `usize`.
///
/// Þessi aðgerð er *O*(1).
///
/// # Panics
///
/// Panics ef `begin` bendir ekki á byrjunarbæti móti stafs (eins og skilgreint er með `is_char_boundary`), ef `end` bendir ekki á endabætamót á staf (`end + 1` er annað hvort byrjunarbæti móti eða jafnt og `len`), ef `begin > end`, eða ef `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Útfærir undirstreng sneiðar með setningafræði `&self[..= end]` eða `&mut self[..= end]`.
///
/// Skilar sneið af tilteknum streng frá byte sviðinu [0, `end`].
/// Jafngildir `&self [0 .. end + 1]`, nema `end` hafi hámarksgildi `usize`.
///
/// Þessi aðgerð er *O*(1).
///
/// # Panics
///
/// Panics ef `end` bendir ekki til endabætamóts stafs (`end + 1` er annaðhvort byrjunarbæti móti eins og skilgreint er af `is_char_boundary`, eða jafnt og `len`), eða ef `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Flokka gildi úr streng
///
/// [`from_str`] aðferðin við `FromStr` er oft notuð óbeint, í gegnum [`parse`] aðferð [`str`].
/// Sjá skjöl [[parse`] fyrir dæmi.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` hefur ekki ævilangt breytu og því er aðeins hægt að flokka gerðir sem ekki innihalda æviloka breytu sjálfar.
///
/// Með öðrum orðum er hægt að flokka `i32` við `FromStr`, en ekki `&i32`.
/// Þú getur flett uppbyggingu sem inniheldur `i32` en ekki einn sem inniheldur `&i32`.
///
/// # Examples
///
/// Grunnútfærsla `FromStr` á dæmi `Point` gerð:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Tengd villa sem hægt er að skila úr þáttun.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Flokkar streng `s` til að skila gildi af þessari gerð.
    ///
    /// Ef þáttun tekst, skaltu skila gildi innan [`Ok`], annars þegar strengurinn er illa sniðinn skaltu skila villu sem er sérstaklega innan [`Err`].
    /// Villutegundin er sérstök fyrir framkvæmd trait.
    ///
    /// # Examples
    ///
    /// Grunnnotkun með [`i32`], gerð sem útfærir `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Flettu `bool` úr streng.
    ///
    /// Skilar `Result<bool, ParseBoolError>`, vegna þess að `s` gæti verið eða ekki raunverulega liðanlegt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Athugið, í mörgum tilfellum er `.parse()` aðferðin á `str` réttari.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}