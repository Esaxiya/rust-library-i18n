//! Leiðir til að búa til `str` úr bæti sneið.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Breytir stykki af bæti í strengsneið.
///
/// Strengjasneið ([`&str`]) er gerð úr bæti ([`u8`]) og bæti sneið ([`&[u8]`][byteslice]) er úr bæti, þannig að þessi aðgerð breytist á milli tveggja.
/// Ekki eru allar bítasneiðar gildar strengjasneiðar, þó: [`&str`] krefst þess að það sé gilt UTF-8.
/// `from_utf8()` athugar til að tryggja að bætin séu gild UTF-8, og gerir þá umbreytinguna.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Ef þú ert viss um að byte sneiðin sé gild UTF-8 og þú vilt ekki verða fyrir kostnaði við gildisathugunina, þá er til óörugg útgáfa af þessari aðgerð, [`from_utf8_unchecked`], sem hefur sömu hegðun en sleppir athuguninni.
///
///
/// Ef þú þarft `String` í stað `&str` skaltu íhuga [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Vegna þess að þú getur úthlutað `[u8; N]` og þú getur tekið [`&[u8]`][byteslice] af honum er þessi aðgerð ein leið til að hafa stafla úthlutað streng.Það er dæmi um þetta í dæminu hér að neðan.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Skilar `Err` ef sneiðin er ekki UTF-8 með lýsingu á því hvers vegna sneiðin er ekki UTF-8.
///
/// # Examples
///
/// Grunn notkun:
///
/// ```
/// use std::str;
///
/// // nokkur bæti, í vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Við vitum að þessi bæti eru gild, svo notaðu bara `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Rangt bæti:
///
/// ```
/// use std::str;
///
/// // nokkur ógild bæti, í vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Sjá skjöl fyrir [`Utf8Error`] fyrir frekari upplýsingar um hvers konar villur sem hægt er að skila.
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // sum bæti, í staflaúthlutað fylki
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Við vitum að þessi bæti eru gild, svo notaðu bara `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // ÖRYGGI: hljóp réttlæting.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Breytir breytanlegri sneið af bæti í breytanlega strengsneið.
///
/// # Examples
///
/// Grunn notkun:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" sem breytanlegur vector
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Eins og við vitum að þessi bæti eru gild, getum við notað `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Rangt bæti:
///
/// ```
/// use std::str;
///
/// // Sum ógild bæti í breytilegum vector
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Sjá skjöl fyrir [`Utf8Error`] fyrir frekari upplýsingar um hvers konar villur sem hægt er að skila.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // ÖRYGGI: hljóp réttlæting.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Breytir sneið af bæti í strengsneið án þess að athuga hvort strengurinn innihaldi gildan UTF-8.
///
/// Sjá örugga útgáfu, [`from_utf8`], til að fá frekari upplýsingar.
///
/// # Safety
///
/// Þessi aðgerð er óörugg vegna þess að hún athugar ekki að bætin sem send eru til hennar séu gild UTF-8.
/// Ef þessi þvingun er brotin, leiðir óskilgreind hegðun, þar sem restin af Rust gerir ráð fyrir að [`&str`] séu gild UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Grunn notkun:
///
/// ```
/// use std::str;
///
/// // nokkur bæti, í vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // ÖRYGGI: sá sem hringir þarf að ábyrgjast að bætin `v` séu gild UTF-8.
    // Treystir líka á að `&str` og `&[u8]` séu með sama skipulag.
    unsafe { mem::transmute(v) }
}

/// Breytir stykki af bæti í strengsneið án þess að athuga hvort strengurinn innihaldi gildan UTF-8;breytileg útgáfa.
///
///
/// Sjá óbreytanlegu útgáfuna, [`from_utf8_unchecked()`] til að fá frekari upplýsingar.
///
/// # Examples
///
/// Grunn notkun:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // ÖRYGGI: sá sem hringir verður að ábyrgjast að bætin `v`
    // eru gild UTF-8, þannig að leikaravalið í `*mut str` er öruggt.
    // Einnig er vísbendingar um vísbendingu öruggar vegna þess að sá bendir kemur frá tilvísun sem er örugglega gild fyrir skrif.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}