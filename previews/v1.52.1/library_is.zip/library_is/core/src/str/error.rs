//! Skilgreinir utf8 villutegund.

use crate::fmt;

/// Villur sem geta komið fram þegar reynt er að túlka röð [`u8`] sem streng.
///
/// Sem slík nýtir `from_utf8` fjölskyldan af aðgerðum og aðferðum fyrir bæði [`String`] og [`&str`] s þessa villu, til dæmis.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Aðferðir þessarar villugerðar er hægt að nota til að búa til virkni svipað `String::from_utf8_lossy` án þess að úthluta hrúga minni:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Skilar vísitölunni í tilteknum streng þar sem gild UTF-8 var staðfest.
    ///
    /// Það er hámarksvísitalan þannig að `from_utf8(&input[..index])` myndi skila `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// use std::str;
    ///
    /// // nokkur ógild bæti, í vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 skilar Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // annað bæti er ógilt hér
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Veitir frekari upplýsingar um bilunina:
    ///
    /// * `None`: lok inntaksins náðust óvænt.
    ///   `self.valid_up_to()` er 1 til 3 bæti frá lokum inntaksins.
    ///   Ef verið er að afkóða bæti straum (svo sem skrá eða netnet) stigvaxandi gæti þetta verið gild `char` þar sem UTF-8 bæti röðin spannar marga klumpa.
    ///
    ///
    /// * `Some(len)`: óvænt bæti kom upp.
    ///   Lengdin sem gefin er upp er ógild bæti röðin sem byrjar við vísitöluna sem `valid_up_to()` gefur.
    ///   Afkóðun ætti að halda áfram eftir þá röð (eftir að [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] hefur verið sett inn) ef um er að ræða afkóðun sem tapast.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Villa kom aftur þegar þáttun `bool` með [`from_str`] mistókst
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}