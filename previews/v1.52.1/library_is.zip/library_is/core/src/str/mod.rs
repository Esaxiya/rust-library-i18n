//! Notkun strengja.
//!
//! Nánari upplýsingar er að finna í [`std::str`] einingunni.
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. utan marka
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. byrja <=enda
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. stafamörk
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // finna persónuna
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` verður að vera minna en len og bleikjumörk
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Skilar lengd `self`.
    ///
    /// Þessi lengd er í bæti, ekki [`char`] eða línurit.
    /// Með öðrum orðum, það er kannski ekki það sem manneskja telur lengd strengsins.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // fínt f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Skilar `true` ef `self` hefur lengdina núll bæti.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Athugar að `index`-th byte er fyrsta byte í UTF-8 kóða punktaröð eða enda strengsins.
    ///
    ///
    /// Upphaf og lok strengsins (þegar `index== self.len()`) eru talin vera mörk.
    ///
    /// Skilar `false` ef `index` er stærra en `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // byrjun `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // annað bæti af `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // þriðja bæti af `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 og len eru alltaf í lagi.
        // Prófaðu sérstaklega fyrir 0 svo að það geti hagrætt ávísuninni auðveldlega og sleppt því að lesa strengjagögn fyrir það mál.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Þetta er svolítill galdur sem jafngildir: b <128 ||(192) Blaðsíða 192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Breytir strengsneið í bæti sneið.
    /// Notaðu [`from_utf8`] aðgerðina til að breyta byte sneiðinni í strengsneið.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // ÖRYGGI: const hljóð vegna þess að við sendum tvær gerðir með sama skipulagi
        unsafe { mem::transmute(self) }
    }

    /// Breytir breyttri strengsneið í breytanlega byte sneið.
    ///
    /// # Safety
    ///
    /// Sá sem hringir þarf að sjá til þess að innihald sneiðarinnar sé gilt UTF-8 áður en láninu lýkur og undirliggjandi `str` er notað.
    ///
    ///
    /// Notkun `str` sem innihald er ekki gild UTF-8 er óskilgreind hegðun.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // ÖRYGGI: leikarinn frá `&str` til `&[u8]` er öruggur síðan `str`
        // er með sama skipulag og `&[u8]` (aðeins libstd getur veitt þessa ábyrgð).
        // Mismunur bendilsins er öruggur þar sem hann kemur frá breytanlegri tilvísun sem er örugglega gild fyrir skrif.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Breytir strengsneið í hráan bendil.
    ///
    /// Þar sem strengjasneiðar eru sneiðar af bætum vísar hrái bendillinn til [`u8`].
    /// Þessi bendill mun benda á fyrsta bæti strengjasneiðarinnar.
    ///
    /// Sá sem hringir verður að sjá til þess að bendillinn sem skilað er sé aldrei skrifaður til.
    /// Ef þú þarft að breyta innihaldi strengjasneiðarinnar skaltu nota [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Breytir breyttri strengsneið í hráan bendil.
    ///
    /// Þar sem strengjasneiðar eru sneiðar af bætum vísar hrái bendillinn til [`u8`].
    /// Þessi bendill mun benda á fyrsta bæti strengjasneiðarinnar.
    ///
    /// Það er á þína ábyrgð að ganga úr skugga um að strengjasneiðin verði aðeins breytt á þann hátt að hún haldist gild UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Skilar undirþrepi `str`.
    ///
    /// Þetta er valkosturinn sem ekki er panikker við að verðtryggja `str`.
    /// Skilar [`None`] hvenær sem samsvarandi flokkunaraðgerð myndi panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // vísitölur sem ekki eru á UTF-8 röðarmörkum
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // utan marka
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Skilar breytilegri undirdeild `str`.
    ///
    /// Þetta er valkosturinn sem ekki er panikker við að verðtryggja `str`.
    /// Skilar [`None`] hvenær sem samsvarandi flokkunaraðgerð myndi panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // rétt lengd
    /// assert!(v.get_mut(0..5).is_some());
    /// // utan marka
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Skilar ómerktri undirþrep `str`.
    ///
    /// Þetta er ómerktur valkostur við verðtryggingu `str`.
    ///
    /// # Safety
    ///
    /// Þeir sem hringja í þessa aðgerð bera ábyrgð á því að þessar forsendur séu uppfylltar:
    ///
    /// * Upphafsvísitalan má ekki fara yfir lokavísitöluna;
    /// * Vísitölur verða að vera innan marka upprunalegu sneiðarinnar;
    /// * Vísitölur verða að liggja á UTF-8 röðarmörkum.
    ///
    /// Takist það ekki getur aftur snúnings sneið vísað í ógilt minni eða brotið á innflytjendum sem komið er á framfæri af `str` gerðinni.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `get_unchecked`;
        // sneiðin er afleiðanleg vegna þess að `self` er örugg tilvísun.
        // Bendillinn sem skilað er er öruggur vegna þess að tækjabúnaður `SliceIndex` verður að ábyrgjast að svo sé.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Skilar breytilegum, ómerktum undirþrepi `str`.
    ///
    /// Þetta er ómerktur valkostur við verðtryggingu `str`.
    ///
    /// # Safety
    ///
    /// Þeir sem hringja í þessa aðgerð bera ábyrgð á því að þessar forsendur séu uppfylltar:
    ///
    /// * Upphafsvísitalan má ekki fara yfir lokavísitöluna;
    /// * Vísitölur verða að vera innan marka upprunalegu sneiðarinnar;
    /// * Vísitölur verða að liggja á UTF-8 röðarmörkum.
    ///
    /// Takist það ekki getur aftur snúnings sneið vísað í ógilt minni eða brotið á innflytjendum sem komið er á framfæri af `str` gerðinni.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `get_unchecked_mut`;
        // sneiðin er afleiðanleg vegna þess að `self` er örugg tilvísun.
        // Bendillinn sem skilað er er öruggur vegna þess að tækjabúnaður `SliceIndex` verður að ábyrgjast að svo sé.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Býr til strengjasneið úr annarri strengsneið, framhjá öryggisathugunum.
    ///
    /// Yfirleitt er ekki mælt með þessu, notið með varúð!Fyrir örugga valkosti sjá [`str`] og [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Þessi nýja sneið fer úr `begin` í `end`, þar á meðal `begin` en að undanskildum `end`.
    ///
    /// Til að fá breytta strengjasneið í staðinn, sjá [`slice_mut_unchecked`] aðferðina.
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Þeir sem hringja í þessa aðgerð bera ábyrgð á því að þrjár forsendur séu uppfylltar:
    ///
    /// * `begin` má ekki fara yfir `end`.
    /// * `begin` og `end` verða að vera bæti stöður innan strengjasneiðar.
    /// * `begin` og `end` verður að liggja á UTF-8 röðarmörkum.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `get_unchecked`;
        // sneiðin er afleiðanleg vegna þess að `self` er örugg tilvísun.
        // Bendillinn sem skilað er er öruggur vegna þess að tækjabúnaður `SliceIndex` verður að ábyrgjast að svo sé.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Býr til strengjasneið úr annarri strengsneið, framhjá öryggisathugunum.
    /// Yfirleitt er ekki mælt með þessu, notið með varúð!Fyrir örugga valkosti sjá [`str`] og [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Þessi nýja sneið fer úr `begin` í `end`, þar á meðal `begin` en að undanskildum `end`.
    ///
    /// Til að fá óbreytanlegan strengsneið í staðinn, sjá [`slice_unchecked`] aðferðina.
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Þeir sem hringja í þessa aðgerð bera ábyrgð á því að þrjár forsendur séu uppfylltar:
    ///
    /// * `begin` má ekki fara yfir `end`.
    /// * `begin` og `end` verða að vera bæti stöður innan strengjasneiðar.
    /// * `begin` og `end` verður að liggja á UTF-8 röðarmörkum.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `get_unchecked_mut`;
        // sneiðin er afleiðanleg vegna þess að `self` er örugg tilvísun.
        // Bendillinn sem skilað er er öruggur vegna þess að tækjabúnaður `SliceIndex` verður að ábyrgjast að svo sé.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Skiptu einni strengsneið í tvo við vísitölu.
    ///
    /// Rökin, `mid`, ættu að vera bæti móti frá upphafi strengsins.
    /// Það verður einnig að vera á mörkum UTF-8 kóða punkta.
    ///
    /// Tvær sneiðar sem skilað er fara frá byrjun strengjasneiðar til `mid` og frá `mid` til enda strengjasneiðar.
    ///
    /// Til að fá breyttar strengjasneiðar í staðinn, sjá [`split_at_mut`] aðferðina.
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics ef `mid` er ekki á UTF-8 kóða punktamörkum, eða ef það er framhjá loki síðasta kóðapunkts strengjasneiðar.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // er_char_boundary athugar hvort vísitalan sé í [0, .len()]
        if self.is_char_boundary(mid) {
            // ÖRYGGI: athugaði bara hvort `mid` er á bleikjumörkum.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Skiptu einni breytanlegri sneið í tvennt við vísitölu.
    ///
    /// Rökin, `mid`, ættu að vera bæti móti frá upphafi strengsins.
    /// Það verður einnig að vera á mörkum UTF-8 kóða punkta.
    ///
    /// Tvær sneiðar sem skilað er fara frá byrjun strengjasneiðar til `mid` og frá `mid` til enda strengjasneiðar.
    ///
    /// Til að fá óbreytanlegar strengjasneiðar í staðinn, sjá [`split_at`] aðferðina.
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics ef `mid` er ekki á UTF-8 kóða punktamörkum, eða ef það er framhjá loki síðasta kóðapunkts strengjasneiðar.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // er_char_boundary athugar hvort vísitalan sé í [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // ÖRYGGI: athugaði bara hvort `mid` er á bleikjumörkum.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Skilar endurtekningu yfir [`bleikjurnar '] strengjasneiðar.
    ///
    /// Þar sem strengjasneið samanstendur af gildum UTF-8 getum við endurtekið í gegnum strengsneið með [`char`].
    /// Þessi aðferð skilar slíkri endurtekningu.
    ///
    /// Það er mikilvægt að muna að [`char`] táknar Unicode Scalar gildi og passar kannski ekki við hugmynd þína um hvað 'character' er.
    ///
    /// Iteration yfir grapheme klasa gæti verið það sem þú vilt raunverulega.
    /// Þessi virkni er ekki veitt af venjulegu bókasafni Rust, athugaðu crates.io í staðinn.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Mundu að [" char`] geta ekki passað við innsæi þitt varðandi persónur:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // ekki 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Skilar endurtekningu yfir [`bleikjurnar 'af strengsneið og stöðu þeirra.
    ///
    /// Þar sem strengjasneið samanstendur af gildum UTF-8 getum við endurtekið í gegnum strengsneið með [`char`].
    /// Þessi aðferð skilar endurtekningu á báðum þessum [" bleikjum`], svo og bætustöðum þeirra.
    ///
    /// Ítóran skilar tvíburum.Staðan er fyrsta, [`char`] er önnur.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Mundu að [" char`] geta ekki passað við innsæi þitt varðandi persónur:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // ekki (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // athugaðu 3 hérna, síðasti stafurinn tók tvö bæti
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Íterator yfir bæti strengjasneiðar.
    ///
    /// Þar sem strengsneið samanstendur af röð bæti, getum við endurtekið í gegnum streng sneið fyrir bæti.
    /// Þessi aðferð skilar slíkri endurtekningu.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Skiptir strengsneið eftir hvít svæði.
    ///
    /// Ítóran sem skilað er skilar strengjasneiðum sem eru undirsneiðar upprunalegu strengjasneiðarinnar, aðgreindar með hvaða magni sem er af hvítu svæði.
    ///
    ///
    /// 'Whitespace' er skilgreint samkvæmt skilmálum Unicode afleiddra kjarnaeigna `White_Space`.
    /// Ef þú vilt aðeins skipta í ASCII hvíta rýmið í staðinn skaltu nota [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Allskonar hvít svæði eru talin:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Skiptir strengsneið eftir ASCII hvíta bilinu.
    ///
    /// Ítóran sem skilað er mun skila strengjasneiðum sem eru undirsneiðar upprunalegu strengjasneiðarinnar, aðgreindar með hvaða magni sem er af ASCII hvítu rými.
    ///
    ///
    /// Til að skipta með Unicode `Whitespace` í staðinn, notaðu [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Allskonar ASCII hvít svæði eru talin:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Ítrator yfir línurnar í streng, eins og strengir sneiðar.
    ///
    /// Línum er endað með annaðhvort nýrri línu (`\n`) eða flutningi aftur með línufóðri (`\r\n`).
    ///
    /// Lokalínulok eru valfrjáls.
    /// Strengur sem endar með lokalínulok endar aftur sömu línur og annars eins strengur án lokalínu.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Lokalínulok er ekki krafist:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Endurtekning yfir línur strengs.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Skilar endurtekningu `u16` yfir strenginn kóðaðan sem UTF-16.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Skilar `true` ef gefið mynstur samsvarar undir sneið af þessari strengsneið.
    ///
    /// Skilar `false` ef ekki.
    ///
    /// [pattern] getur verið `&str`, [`char`], sneið af [`char`] s, eða aðgerð eða lokun sem ákvarðar hvort persóna passar.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Skilar `true` ef uppgefið mynstur samsvarar forskeyti þessarar strengjasneiðar.
    ///
    /// Skilar `false` ef ekki.
    ///
    /// [pattern] getur verið `&str`, [`char`], sneið af [`char`] s, eða aðgerð eða lokun sem ákvarðar hvort persóna passar.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Skilar `true` ef uppgefið mynstur samsvarar viðskeyti þessarar strengjasneiðar.
    ///
    /// Skilar `false` ef ekki.
    ///
    /// [pattern] getur verið `&str`, [`char`], sneið af [`char`] s, eða aðgerð eða lokun sem ákvarðar hvort persóna passar.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Skilar bæti vísitölu fyrsta stafar þessarar strengjasneiðar sem passar við mynstrið.
    ///
    /// Skilar [`None`] ef mynstrið passar ekki.
    ///
    /// [pattern] getur verið `&str`, [`char`], sneið af [`char`] s, eða aðgerð eða lokun sem ákvarðar hvort persóna passar.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Einföld mynstur:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Flóknari mynstur með punktalausum stíl og lokunum:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Finnur ekki mynstrið:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Skilar bæti vísitölunni fyrir fyrsta stafinn í samsvarandi mynstri í hægri mynstri í þessari strengsneið.
    ///
    /// Skilar [`None`] ef mynstrið passar ekki.
    ///
    /// [pattern] getur verið `&str`, [`char`], sneið af [`char`] s, eða aðgerð eða lokun sem ákvarðar hvort persóna passar.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Einföld mynstur:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Flóknari mynstur með lokunum:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Finnur ekki mynstrið:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Íterator yfir undirstrengi þessarar strengsneiðar, aðgreindur með stöfum sem passa við mynstur.
    ///
    /// [pattern] getur verið `&str`, [`char`], sneið af [`char`] s, eða aðgerð eða lokun sem ákvarðar hvort persóna passar.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Hegðun ítröðunar
    ///
    /// Aftur sem skilað er verður [`DoubleEndedIterator`] ef mynstrið leyfir öfuga leit og forward/reverse leit gefur sömu þætti.
    /// Þetta gildir fyrir td [`char`] en ekki `&str`.
    ///
    /// Ef mynstrið leyfir öfugri leit en niðurstöður þess geta verið aðrar en framsókn er hægt að nota [`rsplit`] aðferðina.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Einföld mynstur:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Ef mynstrið er sneið af bleikjum skaltu skipta á hverja uppákomu einhverra persóna:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Flóknara mynstur með lokun:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Ef strengur inniheldur marga samliggjandi aðskilnað muntu enda með tóma strengi í framleiðslunni:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Samliggjandi skiljur eru aðskildir með tóma strenginn.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Aðskilnaður í byrjun eða lok strengs er nágrenni með tóma strengi.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Þegar tómur strengur er notaður sem aðskilnaður aðskilur hann sérhver staf í strengnum ásamt upphafi og lok strengsins.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Samliggjandi aðskilnaður getur leitt til hugsanlega furðuhegðunar þegar hvítt rými er notað sem aðskilnaður.Þessi kóði er réttur:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Það gefur _not_ þér:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Notaðu [`split_whitespace`] fyrir þessa hegðun.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Íterator yfir undirstrengi þessarar strengsneiðar, aðgreindur með stöfum sem passa við mynstur.
    /// Aðgreinir frá endurtekningunni sem framleidd er af `split` að því leyti að `split_inclusive` skilur eftir samsvarandi hlutann sem endar á undirlaginu.
    ///
    ///
    /// [pattern] getur verið `&str`, [`char`], sneið af [`char`] s, eða aðgerð eða lokun sem ákvarðar hvort persóna passar.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Ef síðasti þáttur strengsins er samsvöraður, verður sá þáttur talinn stöðva fyrri undirstrengsins.
    /// Þessi undirstrengur verður síðasti hluturinn sem endurtekningartækið skilar.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Íterator yfir undirstrengi gefinnar strengjasneiðar, aðgreindur með stöfum sem passa við mynstur og gefinn í öfugri röð.
    ///
    /// [pattern] getur verið `&str`, [`char`], sneið af [`char`] s, eða aðgerð eða lokun sem ákvarðar hvort persóna passar.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Hegðun ítröðunar
    ///
    /// Ítórinn sem skilað er krefst þess að mynstrið styðji öfuga leit og það verði [`DoubleEndedIterator`] ef forward/reverse leit skilar sömu þáttum.
    ///
    ///
    /// Við endurtekningu að framan er hægt að nota [`split`] aðferðina.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Einföld mynstur:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Flóknara mynstur með lokun:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Ítrator yfir undirstrengi gefinnar strengjasneiðar, aðskilin með stöfum sem passa við mynstur.
    ///
    /// [pattern] getur verið `&str`, [`char`], sneið af [`char`] s, eða aðgerð eða lokun sem ákvarðar hvort persóna passar.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Jafngildir [`split`], nema að sleppa undirstrengnum sé tómt.
    ///
    /// [`split`]: str::split
    ///
    /// Þessa aðferð er hægt að nota fyrir strengjagögn sem eru _terminated_, frekar en _separated_ með mynstri.
    ///
    /// # Hegðun ítröðunar
    ///
    /// Aftur sem skilað er verður [`DoubleEndedIterator`] ef mynstrið leyfir öfuga leit og forward/reverse leit gefur sömu þætti.
    /// Þetta gildir fyrir td [`char`] en ekki `&str`.
    ///
    /// Ef mynstrið leyfir öfuga leit en niðurstöður þess geta verið aðrar en framsókn er hægt að nota [`rsplit_terminator`] aðferðina.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Ítrator yfir undirstrengi `self`, aðgreindur með stöfum sem passa við mynstur og gefinn í öfugri röð.
    ///
    /// [pattern] getur verið `&str`, [`char`], sneið af [`char`] s, eða aðgerð eða lokun sem ákvarðar hvort persóna passar.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Jafngildir [`split`], nema að sleppa undirstrengnum sé tómt.
    ///
    /// [`split`]: str::split
    ///
    /// Þessa aðferð er hægt að nota fyrir strengjagögn sem eru _terminated_, frekar en _separated_ með mynstri.
    ///
    /// # Hegðun ítröðunar
    ///
    /// Ítórinn sem skilað er krefst þess að mynstrið styðji öfuga leit og því verði tvöfalt lokið ef forward/reverse leit skilar sömu þáttum.
    ///
    ///
    /// Við endurtekningu að framan er hægt að nota [`split_terminator`] aðferðina.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Ítrator yfir undirstrengi gefinnar strengjasneiðar, aðgreindur með mynstri, takmarkaður við að skila að hámarki `n` hlutum.
    ///
    /// Ef `n` undirstrengjum er skilað mun síðasta undirstrengurinn (`n`s undirstrengurinn) innihalda það sem eftir er af strengnum.
    ///
    /// [pattern] getur verið `&str`, [`char`], sneið af [`char`] s, eða aðgerð eða lokun sem ákvarðar hvort persóna passar.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Hegðun ítröðunar
    ///
    /// Endurtekinni endurkomu verður ekki tvöfalt lokið því hún er ekki duglegur að styðja.
    ///
    /// Ef mynstrið leyfir öfugri leit er hægt að nota [`rsplitn`] aðferðina.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Einföld mynstur:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Flóknara mynstur með lokun:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Íterator yfir undirstrengi þessarar strengjasneiðar, aðgreindur með mynstri, sem byrjar frá enda strengsins, takmarkast við að skila í mesta lagi `n` hlutum.
    ///
    ///
    /// Ef `n` undirstrengjum er skilað mun síðasta undirstrengurinn (`n`s undirstrengurinn) innihalda það sem eftir er af strengnum.
    ///
    /// [pattern] getur verið `&str`, [`char`], sneið af [`char`] s, eða aðgerð eða lokun sem ákvarðar hvort persóna passar.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Hegðun ítröðunar
    ///
    /// Endurtekinni endurkomu verður ekki tvöfalt lokið því hún er ekki duglegur að styðja.
    ///
    /// Til að kljúfa að framan er hægt að nota [`splitn`] aðferðina.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Einföld mynstur:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Flóknara mynstur með lokun:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Deilir strengnum við fyrstu uppákomu tilgreinds afmörkunar og skilar forskeyti fyrir afmörkun og viðskeyti eftir afmörkun.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Skiptir strengnum við síðustu uppákomu tilgreinds afmörkunar og skilar forskeyti fyrir afmörkun og viðskeyti eftir afmörkun.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Ítrator yfir sundurleiki samsvarana af mynstri innan gefinnar strengjasneiðar.
    ///
    /// [pattern] getur verið `&str`, [`char`], sneið af [`char`] s, eða aðgerð eða lokun sem ákvarðar hvort persóna passar.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Hegðun ítröðunar
    ///
    /// Aftur sem skilað er verður [`DoubleEndedIterator`] ef mynstrið leyfir öfuga leit og forward/reverse leit gefur sömu þætti.
    /// Þetta gildir fyrir td [`char`] en ekki `&str`.
    ///
    /// Ef mynstrið leyfir öfugri leit en niðurstöður þess geta verið aðrar en framsókn er hægt að nota [`rmatches`] aðferðina.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Ítrator yfir sundurleiki samsvarana af mynstri í þessari strengsneið, gefinn í öfugri röð.
    ///
    /// [pattern] getur verið `&str`, [`char`], sneið af [`char`] s, eða aðgerð eða lokun sem ákvarðar hvort persóna passar.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Hegðun ítröðunar
    ///
    /// Ítórinn sem skilað er krefst þess að mynstrið styðji öfuga leit og það verði [`DoubleEndedIterator`] ef forward/reverse leit skilar sömu þáttum.
    ///
    ///
    /// Við endurtekningu að framan er hægt að nota [`matches`] aðferðina.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Ítator yfir sundurleiki samsvarana í mynstri í þessari strengsneið sem og vísitölunni sem leikurinn byrjar á.
    ///
    /// Fyrir leiki `pat` innan `self` sem skarast er aðeins vísitölunum sem svara til fyrsta leiksins skilað.
    ///
    /// [pattern] getur verið `&str`, [`char`], sneið af [`char`] s, eða aðgerð eða lokun sem ákvarðar hvort persóna passar.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Hegðun ítröðunar
    ///
    /// Aftur sem skilað er verður [`DoubleEndedIterator`] ef mynstrið leyfir öfuga leit og forward/reverse leit gefur sömu þætti.
    /// Þetta gildir fyrir td [`char`] en ekki `&str`.
    ///
    /// Ef mynstrið leyfir öfugri leit en niðurstöður þess geta verið aðrar en framsókn er hægt að nota [`rmatch_indices`] aðferðina.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // aðeins fyrsta `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Ítrator yfir sundurleiki samsvarana í mynstri innan `self`, skilað í öfugri röð ásamt vísitölu leiksins.
    ///
    /// Fyrir leiki `pat` innan `self` sem skarast, er aðeins vísitölunum sem svara til síðustu samsvörunar skilað.
    ///
    /// [pattern] getur verið `&str`, [`char`], sneið af [`char`] s, eða aðgerð eða lokun sem ákvarðar hvort persóna passar.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Hegðun ítröðunar
    ///
    /// Ítórinn sem skilað er krefst þess að mynstrið styðji öfuga leit og það verði [`DoubleEndedIterator`] ef forward/reverse leit skilar sömu þáttum.
    ///
    ///
    /// Við endurtekningu að framan er hægt að nota [`match_indices`] aðferðina.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // aðeins síðasti `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Skilar strengsneið með forystu og eftirliggjandi hvít svæði fjarlægð.
    ///
    /// 'Whitespace' er skilgreint samkvæmt skilmálum Unicode afleiddra kjarnaeigna `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Skilar strengjasneið þar sem leiðandi hvít svæði er fjarlægt.
    ///
    /// 'Whitespace' er skilgreint samkvæmt skilmálum Unicode afleiddra kjarnaeigna `White_Space`.
    ///
    /// # Textaleiðbeiningar
    ///
    /// Strengur er röð bæti.
    /// `start` í þessu samhengi þýðir fyrsta staða þess bítastrengs;fyrir tungumál frá vinstri til hægri eins og ensku eða rússnesku, þetta verður vinstra megin, og fyrir tungumál frá hægri til vinstri eins og arabísku eða hebresku, þá er þetta hægri hliðin.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Skilar strengjasneið þar sem aftanhvít svæði er fjarlægt.
    ///
    /// 'Whitespace' er skilgreint samkvæmt skilmálum Unicode afleiddra kjarnaeigna `White_Space`.
    ///
    /// # Textaleiðbeiningar
    ///
    /// Strengur er röð bæti.
    /// `end` í þessu samhengi þýðir síðasta staða þessa byte-strengs;fyrir tungumál frá vinstri til hægri eins og ensku eða rússnesku, þá mun þetta vera hægri hlið og fyrir tungumál frá hægri til vinstri eins og arabísku eða hebresku, þá verður þetta vinstri hlið.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Skilar strengjasneið þar sem leiðandi hvít svæði er fjarlægt.
    ///
    /// 'Whitespace' er skilgreint samkvæmt skilmálum Unicode afleiddra kjarnaeigna `White_Space`.
    ///
    /// # Textaleiðbeiningar
    ///
    /// Strengur er röð bæti.
    /// 'Left' í þessu samhengi þýðir fyrsta staða þess bítastrengs;fyrir tungumál eins og arabísku eða hebresku sem eru " hægri til vinstri`frekar en " vinstri til hægri`, þá er þetta _right_ hliðin, ekki vinstri.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Skilar strengjasneið þar sem aftanhvít svæði er fjarlægt.
    ///
    /// 'Whitespace' er skilgreint samkvæmt skilmálum Unicode afleiddra kjarnaeigna `White_Space`.
    ///
    /// # Textaleiðbeiningar
    ///
    /// Strengur er röð bæti.
    /// 'Right' í þessu samhengi þýðir síðasta staða þessa byte-strengs;fyrir tungumál eins og arabísku eða hebresku sem eru " hægri til vinstri`frekar en " vinstri til hægri`, þá er þetta _left_ hliðin, ekki sú hægri.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Skilar strengjasneið með öllum forskeytum og viðskeytum sem passa við mynstur sem er endurtekið fjarlægt.
    ///
    /// [pattern] getur verið [`char`], sneið af [`bleikju], eða aðgerð eða lokun sem ákvarðar hvort persóna passar saman.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Einföld mynstur:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Flóknara mynstur með lokun:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Mundu eftir fyrri þekktu samsvörun, leiðréttu hana hér að neðan ef
            // síðasti leikur er öðruvísi
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // ÖRYGGI: Vitað er að `Searcher` skilar gildum vísitölum.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Skilar strengjasneið með öllum forskeytum sem passa við mynstur ítrekað fjarlægð.
    ///
    /// [pattern] getur verið `&str`, [`char`], sneið af [`char`] s, eða aðgerð eða lokun sem ákvarðar hvort persóna passar.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Textaleiðbeiningar
    ///
    /// Strengur er röð bæti.
    /// `start` í þessu samhengi þýðir fyrsta staða þess bítastrengs;fyrir tungumál frá vinstri til hægri eins og ensku eða rússnesku, þetta verður vinstra megin, og fyrir tungumál frá hægri til vinstri eins og arabísku eða hebresku, þá er þetta hægri hliðin.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // ÖRYGGI: Vitað er að `Searcher` skilar gildum vísitölum.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Skilar strengsneið með forskeytið fjarlægt.
    ///
    /// Ef strengurinn byrjar með mynstrinu `prefix`, skilar undirstrengur á eftir forskeytinu, vafinn í `Some`.
    /// Ólíkt `trim_start_matches` fjarlægir þessi aðferð forskeytið nákvæmlega einu sinni.
    ///
    /// Ef strengurinn byrjar ekki með `prefix` skilar hann `None`.
    ///
    /// [pattern] getur verið `&str`, [`char`], sneið af [`char`] s, eða aðgerð eða lokun sem ákvarðar hvort persóna passar.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Skilar strengsneið með viðskeytinu fjarlægt.
    ///
    /// Ef strengurinn endar með mynstrinu `suffix` skilarðu undirstrengnum fyrir viðskeytið, vafið í `Some`.
    /// Ólíkt `trim_end_matches` fjarlægir þessi aðferð viðskeytið nákvæmlega einu sinni.
    ///
    /// Ef strengurinn endar ekki með `suffix`, skilar hann `None`.
    ///
    /// [pattern] getur verið `&str`, [`char`], sneið af [`char`] s, eða aðgerð eða lokun sem ákvarðar hvort persóna passar.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Skilar strengjasneið með öllum viðskeytum sem passa við mynstur ítrekað fjarlægð.
    ///
    /// [pattern] getur verið `&str`, [`char`], sneið af [`char`] s, eða aðgerð eða lokun sem ákvarðar hvort persóna passar.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Textaleiðbeiningar
    ///
    /// Strengur er röð bæti.
    /// `end` í þessu samhengi þýðir síðasta staða þessa byte-strengs;fyrir tungumál frá vinstri til hægri eins og ensku eða rússnesku, þá mun þetta vera hægri hlið og fyrir tungumál frá hægri til vinstri eins og arabísku eða hebresku, þá verður þetta vinstri hlið.
    ///
    ///
    /// # Examples
    ///
    /// Einföld mynstur:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Flóknara mynstur með lokun:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // ÖRYGGI: Vitað er að `Searcher` skilar gildum vísitölum.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Skilar strengjasneið með öllum forskeytum sem passa við mynstur ítrekað fjarlægð.
    ///
    /// [pattern] getur verið `&str`, [`char`], sneið af [`char`] s, eða aðgerð eða lokun sem ákvarðar hvort persóna passar.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Textaleiðbeiningar
    ///
    /// Strengur er röð bæti.
    /// 'Left' í þessu samhengi þýðir fyrsta staða þess bítastrengs;fyrir tungumál eins og arabísku eða hebresku sem eru " hægri til vinstri`frekar en " vinstri til hægri`, þá er þetta _right_ hliðin, ekki vinstri.
    ///
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Skilar strengjasneið með öllum viðskeytum sem passa við mynstur ítrekað fjarlægð.
    ///
    /// [pattern] getur verið `&str`, [`char`], sneið af [`char`] s, eða aðgerð eða lokun sem ákvarðar hvort persóna passar.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Textaleiðbeiningar
    ///
    /// Strengur er röð bæti.
    /// 'Right' í þessu samhengi þýðir síðasta staða þessa byte-strengs;fyrir tungumál eins og arabísku eða hebresku sem eru " hægri til vinstri`frekar en " vinstri til hægri`, þá er þetta _left_ hliðin, ekki sú hægri.
    ///
    ///
    /// # Examples
    ///
    /// Einföld mynstur:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Flóknara mynstur með lokun:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Flokkar þessa sneið í aðra tegund.
    ///
    /// Þar sem `parse` er svona almennt getur það valdið vandamálum með ályktun af gerðinni.
    /// Sem slík er `parse` eitt af fáum sinnum sem þú munt sjá setningafræðina ástúðlega þekkt sem 'turbofish': `::<>`.
    ///
    /// Þetta hjálpar ályktunaralgoritmanum að skilja sérstaklega hvaða tegund þú ert að reyna að flokka í.
    ///
    /// `parse` getur greitt í hvaða gerð sem útfærir [`FromStr`] trait.
    ///

    /// # Errors
    ///
    /// Skilar [`Err`] ef ekki er hægt að flokka þessa strengjasneið í viðkomandi gerð.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Grunnnotkun
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Notaðu 'turbofish' í stað þess að gera athugasemd við `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Takist ekki að flokka:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Athugar hvort allir stafir í þessum streng eru innan ASCII sviðsins.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Við getum meðhöndlað hvert bæti sem staf hér: allir fjölbýta stafir byrja með bæti sem er ekki á ascii sviðinu, svo við munum stoppa þar þegar.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Athugar að tveir strengir séu ASCII málsnæmir.
    ///
    /// Sama og `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, en án þess að úthluta og afrita tímabundið.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Breytir þessum streng í jafngildi ASCII í stórum stíl.
    ///
    /// ASCII stafir 'a' til 'z' eru kortlagðir við 'A' til 'Z', en stafir sem ekki eru ASCII eru óbreyttir.
    ///
    /// Notaðu [`to_ascii_uppercase()`] til að skila nýju hástöfuðu gildi án þess að breyta því sem fyrir er.
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // ÖRYGGI: öruggt vegna þess að við sendum tvær gerðir með sama skipulagi.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Breytir þessum streng í ASCII smærri jafngildi þess í stað.
    ///
    /// ASCII stafir 'A' til 'Z' eru kortlagðir við 'a' til 'z', en stafir sem ekki eru ASCII eru óbreyttir.
    ///
    /// Notaðu [`to_ascii_lowercase()`] til að skila nýju lágmarksgildi án þess að breyta því sem fyrir er.
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // ÖRYGGI: öruggt vegna þess að við sendum tvær gerðir með sama skipulagi.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Skilaðu endurtekningu sem sleppur við hverja bleikju í `self` með [`char::escape_debug`].
    ///
    ///
    /// Note: aðeins slökkt á framlengdum grafíkmerkjum sem hefja strenginn.
    ///
    /// # Examples
    ///
    /// Sem endurtekning:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Notkun `println!` beint:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Báðir jafngilda:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Notkun `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Skilaðu endurtekningu sem sleppur við hverja bleikju í `self` með [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// Sem endurtekning:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Notkun `println!` beint:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Báðir jafngilda:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Notkun `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Skilaðu endurtekningu sem sleppur við hverja bleikju í `self` með [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// Sem endurtekning:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Notkun `println!` beint:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Báðir jafngilda:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Notkun `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Býr til tómt str
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Býr til tóman breytanlegan str
    #[inline]
    fn default() -> Self {
        // ÖRYGGI: Tómur strengur er gildur UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Nafngrein, klónanleg fn gerð
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // ÖRYGGI: ekki öruggt
        unsafe { from_utf8_unchecked(bytes) }
    };
}