//! Frumstæð einkenni og gerðir sem tákna grunneiginleika gerða.
//!
//! Rust gerðir er hægt að flokka á ýmsa gagnlega vegu eftir innri eiginleikum þeirra.
//! Þessar flokkanir eru táknaðar sem traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Tegundir sem hægt er að flytja yfir þræðarmörk.
///
/// Þessi trait er sjálfkrafa útfærður þegar þýðandinn ákveður að það sé viðeigandi.
///
/// Dæmi um gerð sem ekki er " Senda` er vísir að telja bendilinn [`rc::Rc`][`Rc`].
/// Ef tveir þræðir reyna að klóna ['Rc'] sem benda á sama viðmiðunartalna gildi gætu þeir reynt að uppfæra viðmiðunartalningu á sama tíma, sem er [undefined behavior][ub] vegna þess að [`Rc`] notar ekki lotukerfisaðgerðir.
///
/// Frændi hennar [`sync::Arc`][arc] notar lotukerfisaðgerðir (sem fylgja nokkrum kostnaði) og því er `Send`.
///
/// Sjá [the Nomicon](../../nomicon/send-and-sync.html) fyrir frekari upplýsingar.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Tegundir með stöðuga stærð sem vitað er um við samantektartímann.
///
/// Allar gerðarfæribreytur hafa óbeina takmörkun `Sized`.Sérstakri setningafræði `?Sized` er hægt að nota til að fjarlægja þetta bundið ef það er ekki við hæfi.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//villa: Stærð er ekki útfærð fyrir [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Eina undantekningin er óbeina `Self` gerð trait.
/// trait er ekki með óbeina `Sized` bundna þar sem þetta er ósamrýmanlegt við [trait hlutinn] þar sem, samkvæmt skilgreiningu, þarf trait að vinna með öllum mögulegum útfærslumönnum, og gæti því verið af hvaða stærð sem er.
///
///
/// Þó að Rust leyfi þér að binda `Sized` við trait, þá muntu ekki geta notað það til að mynda trait hlut síðar:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // látum y: &dyn Bar= &Impl;//villa: það er ekki hægt að gera trait `Bar` að hlut
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // fyrir Default, til dæmis, sem krefst þess að `[T]: !Default` sé metanlegt
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Tegundir sem geta verið "unsized" í dýnamískri gerð.
///
/// Til dæmis útfærir stærð fylkisgerðin `[i8; 2]` `Unsize<[i8]>` og `Unsize<dyn fmt::Debug>`.
///
/// Allar útfærslur á `Unsize` fást sjálfkrafa af þýðandanum.
///
/// `Unsize` er útfærð fyrir:
///
/// - `[T; N]` er `Unsize<[T]>`
/// - `T` er `Unsize<dyn Trait>` þegar `T: Trait`
/// - `Foo<..., T, ...>` er `Unsize<Foo<..., U, ...>>` ef:
///   - `T: Unsize<U>`
///   - Foo er uppbygging
///   - Aðeins síðasti reitur `Foo` er með gerð sem felur í sér `T`
///   - `T` er ekki hluti af gerð neinna annarra sviða
///   - `Bar<T>: Unsize<Bar<U>>`, ef síðasti reitur `Foo` er með gerð `Bar<T>`
///
/// `Unsize` er notað ásamt [`ops::CoerceUnsized`] til að leyfa "user-defined" ílátum eins og [`Rc`] að innihalda gerðir af virkum stærðum.
/// Sjá [DST coercion RFC][RFC982] og [the nomicon entry on coercion][nomicon-coerce] fyrir frekari upplýsingar.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Nauðsynlegt trait fyrir fasta sem notaðir eru í samsvörun við mynstur.
///
/// Sérhver tegund sem leiðir `PartialEq` útfærir sjálfkrafa þennan trait,*án tillits til* hvort gerðarbreytur hennar útfæra `Eq`.
///
/// Ef `const` hlutur inniheldur einhverja gerð sem ekki útfærir þessa trait, þá útfærir sú tegund annaðhvort (1.) ekki `PartialEq` (sem þýðir að fastinn mun ekki veita þá samanburðaraðferð, sem kynslóðin gerir ráð fyrir að sé fáanleg), eða (2.) sem hún framkvæmir *sína eigin* útgáfa af `PartialEq` (sem við gerum ráð fyrir að samræmist ekki samanburði á uppbyggingu og jafnrétti).
///
///
/// Í báðum sviðsmyndunum hér að ofan höfnum við notkun slíkrar fastu í mynstursleik.
///
/// Sjá einnig [structural match RFC][RFC1445] og [issue 63438] sem hvöttu til þess að flytja frá eiginleiki byggðri hönnun yfir í þessa trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Nauðsynlegt trait fyrir fasta sem notaðir eru í samsvörun við mynstur.
///
/// Sérhver tegund sem leiðir `Eq` útfærir sjálfkrafa þessa trait,*án tillits til* hvort gerðarbreytur hennar útfæra `Eq`.
///
/// Þetta er reiðhestur til að vinna í kringum takmarkanir í tegundakerfi okkar.
///
/// # Background
///
/// Við viljum krefjast þess að gerðir consts sem notaðar eru í mynstursleikjum hafi eiginleikann `#[derive(PartialEq, Eq)]`.
///
/// Í hugsjónari heimi gætum við athugað þá kröfu með því að athuga bara að tilgreind tegund útfærir bæði `StructuralPartialEq` trait *og*`Eq` trait.
/// Þú getur hins vegar haft ADT sem *gera*`derive(PartialEq, Eq)` og verið tilfelli sem við viljum að þýðandinn samþykki og samt tekst tegund fastans ekki að innleiða `Eq`.
///
/// Mál sem þetta nefnilega:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Vandamálið í ofangreindum kóða er að `Wrap<fn(&())>` innleiðir ekki `PartialEq` né `Eq`, vegna þess að `fyrir <'a> fn(&'a _)` does not implement those traits.)
///
/// Þess vegna getum við ekki treyst á barnalegt eftirlit með `StructuralPartialEq` og aðeins `Eq`.
///
/// Sem hakk til að vinna úr þessu notum við tvö aðskilin traits sem sprautað er af hvoru tveggja leiðir (`#[derive(PartialEq)]` og `#[derive(Eq)]`) og athugum hvort þau séu til staðar sem hluti af stöðvunaráhorfi.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Tegundir sem hægt er að afrita gildi einfaldlega með því að afrita bita.
///
/// Sjálfgefið er að breytilegar bindingar hafi " hreyfingu merkingarfræði`.Með öðrum orðum:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` hefur færst yfir í `y` og er því ekki hægt að nota það
///
/// // prentln! ("{: ?}", x);//villa: notkun á færðu gildi
/// ```
///
/// Hins vegar, ef tegund útfærir `Copy`, hefur hún í staðinn " afrit merkingarfræði`:
///
/// ```
/// // Við getum fengið `Copy` útfærslu.
/// // `Clone` er einnig krafist, þar sem það er ofurtog af `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` er afrit af `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Það er mikilvægt að hafa í huga að í þessum tveimur dæmum er eini munurinn hvort þú færð aðgang að `x` eftir verkefnið.
/// Undir hettunni geta bæði afrit og hreyfing valdið því að bitar eru afritaðir í minni, þó að þetta sé stundum bjartsýni.
///
/// ## Hvernig get ég útfært `Copy`?
///
/// Það eru tvær leiðir til að innleiða `Copy` á þína tegund.Einfaldast er að nota `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Þú getur einnig útfært `Copy` og `Clone` handvirkt:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Það er lítill munur á þessu tvennu: `derive` stefnan mun einnig setja `Copy` bundinn á gerð breytur, sem ekki er alltaf óskað.
///
/// ## Hver er munurinn á `Copy` og `Clone`?
///
/// Afrit gerast óbeint, til dæmis sem hluti af verkefni `y = x`.Hegðun `Copy` er ekki of mikið.það er alltaf einfalt bitvitur afrit.
///
/// Einræktun er skýr aðgerð, `x.clone()`.Útfærsla [`Clone`] getur veitt hvers konar gerðarhegðun sem er nauðsynleg til að afrita gildi á öruggan hátt.
/// Til dæmis þarf útfærsla [`Clone`] fyrir [`String`] að afrita bentu strengjabuffarann í hrúgunni.
/// Einfalt bitvís afrit af [`String`] gildi myndi einungis afrita bendilinn og leiða til tvöfaldrar lausar niður línuna.
/// Af þessum sökum er [`String`] [`Clone`] en ekki `Copy`.
///
/// [`Clone`] er supertrait af `Copy`, þannig að allt sem er `Copy` verður einnig að innleiða [`Clone`].
/// Ef tegund er `Copy` þá þarf [`Clone`] framkvæmd hennar aðeins að skila `*self` (sjá dæmið hér að ofan).
///
/// ## Hvenær getur týpan mín verið `Copy`?
///
/// Tegund getur innleitt `Copy` ef allir íhlutir hennar innleiða `Copy`.Til dæmis getur þessi uppbygging verið `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Uppbygging getur verið `Copy` og [`i32`] er `Copy`, þess vegna er `Point` gjaldgengur til að vera `Copy`.
/// Hins vegar skaltu íhuga
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Uppbyggingin `PointList` getur ekki innleitt `Copy`, því [`Vec<T>`] er ekki `Copy`.Ef við reynum að fá `Copy` útfærslu fáum við villu:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Sameiginlegar tilvísanir (`&T`) eru einnig `Copy`, þannig að gerð getur verið `Copy`, jafnvel þegar hún hefur sameiginlegar tilvísanir af gerðinni `T` sem eru *ekki*`Copy`.
/// Hugleiddu eftirfarandi strúktúr, sem getur framkvæmt `Copy`, vegna þess að það hefur aðeins *sameiginlega tilvísun* til `PointList` sem er ekki afritað að ofan:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Hvenær *getur* mín tegund ekki verið `Copy`?
///
/// Ekki er hægt að afrita sumar tegundir á öruggan hátt.Til dæmis myndi afritun `&mut T` skapa alias breytanlega tilvísun.
/// Afritun [`String`] myndi tvöfalda ábyrgð á stjórnun á biðminni [" String`], sem myndi leiða til tvöfalt ókeypis.
///
/// Með því að alhæfa síðara tilvikið geta allar gerðir sem innleiða [`Drop`] ekki verið `Copy`, vegna þess að það hefur umsjón með einhverri auðlind fyrir utan eigin [`size_of::<T>`] bæti.
///
/// Ef þú reynir að innleiða `Copy` á byggingu eða enum sem inniheldur gögn sem ekki eru 'Afritaðu', færðu villuna [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Hvenær *ætti* mín tegund að vera `Copy`?
///
/// Almennt séð, ef tegund þín _can_ innleiðir `Copy`, þá ætti það að gera það.
/// Hafðu þó í huga að útfærsla `Copy` er hluti af almenna forritaskilinu af þinni gerð.
/// Ef tegundin gæti orðið " Afritun` í future gæti verið skynsamlegt að sleppa `Copy` útfærslunni núna til að koma í veg fyrir að API breyting brjótist út.
///
/// ## Viðbótar útfærsluaðilar
///
/// Auk [implementors listed below][impls] innleiða eftirfarandi gerðir einnig `Copy`:
///
/// * Gerðir hlutaliða (þ.e. skilgreindar gerðir skilgreindar fyrir hverja aðgerð)
/// * Gerðir bendipinna (td `fn() -> i32`)
/// * Fylkisgerðir, fyrir allar stærðir, ef vörutegundin útfærir einnig `Copy` (td `[i32; 123456]`)
/// * Tuple gerðir, ef hver hluti útfærir einnig `Copy` (td `()`, `(i32, bool)`)
/// * Lokunartegundir, ef þær fanga engin gildi úr umhverfinu eða ef öll slík fanga gildi innleiða `Copy` sjálf.
///   Athugaðu að breytur sem eru teknar með sameiginlegri tilvísun innleiða alltaf `Copy` (jafnvel þó að tilvísunin geri það ekki), en breytur sem eru teknar með breytilegri tilvísun innleiða aldrei `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Þetta gerir kleift að afrita gerð sem ekki innleiðir `Copy` vegna ófullnægjandi líftíma (afritun `A<'_>` þegar aðeins `A<'static>: Copy` og `A<'_>: Clone`).
// Við höfum þennan eiginleika hér í bili vegna þess að það eru allnokkur núverandi sérhæfingar á `Copy` sem þegar eru til í venjulegu bókasafninu og það er engin leið að hafa þessa hegðun örugglega núna.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Aflaðu makró sem myndar ígræðslu af trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Tegundir sem óhætt er að deila tilvísunum á milli þráða.
///
/// Þessi trait er sjálfkrafa útfærður þegar þýðandinn ákveður að það sé viðeigandi.
///
/// Nákvæm skilgreining er: tegund `T` er [`Sync`] ef og aðeins ef `&T` er [`Send`].
/// Með öðrum orðum, ef það er enginn möguleiki á [undefined behavior][ub] (þ.mt gagnakapphlaup) þegar `&T` tilvísanir eru sendar á milli þráða.
///
/// Eins og við mátti búast, eru frumstæðar gerðir eins og [`u8`] og [`f64`] allar [`Sync`], og sömuleiðis einfaldar heildartegundir sem innihalda þær, eins og túpur, strengir og enums.
/// Fleiri dæmi um grunn [`Sync`] gerðir fela í sér "immutable" gerðir eins og `&T`, og þá sem eru með einfaldan arfbreytileika, svo sem [`Box<T>`][box], [`Vec<T>`][vec] og flestar aðrar tegundir safna.
///
/// (Almennar breytur þurfa að vera [`Sync`] til að ílát þeirra sé [" Sync`].)
///
/// Nokkuð furðuleg afleiðing af skilgreiningunni er að `&mut T` er `Sync` (ef `T` er `Sync`) jafnvel þó að það virðist eins og það gæti veitt ósamstillta stökkbreytingu.
/// Galdurinn er sá að breytanleg tilvísun á bak við sameiginlega tilvísun (það er `& &mut T`) verður skrifvarin, eins og um `& &T` sé að ræða.
/// Þess vegna er engin hætta á gagnakapphlaupi.
///
/// Tegundir sem eru ekki `Sync` eru þær sem hafa "interior mutability" í óþræðilegu formi, svo sem [`Cell`][cell] og [`RefCell`][refcell].
/// Þessar gerðir leyfa stökkbreytingu á innihaldi þeirra, jafnvel með óbreytanlegri, sameiginlegri tilvísun.
/// Til dæmis tekur `set` aðferðin á [`Cell<T>`][cell] `&self`, svo það þarf aðeins sameiginlega tilvísun [`&Cell<T>`][cell].
/// Aðferðin framkvæmir enga samstillingu, þannig að [`Cell`][cell] getur ekki verið `Sync`.
///
/// Annað dæmi um gerð sem ekki er 'Sync' er vísir að telja bendilinn [`Rc`][rc].
/// Með hliðsjón af hvaða tilvísun sem er [`&Rc<T>`][rc] geturðu klónað nýjan [`Rc<T>`][rc] og breytt viðmiðunartalningunum á ekki lotukerfinu.
///
/// Í tilfellum þegar þörf er á þráðlausum innri breytileika veitir Rust [atomic data types], auk skýrrar læsingar um [`sync::Mutex`][mutex] og [`sync::RwLock`][rwlock].
/// Þessar tegundir tryggja að einhver stökkbreyting geti ekki valdið gagnasamkeppni, þess vegna eru gerðirnar `Sync`.
/// Sömuleiðis veitir [`sync::Arc`][arc] þráðaörugga hliðstæðu [`Rc`][rc].
///
/// Allar gerðir með innri breytileika verða einnig að nota [`cell::UnsafeCell`][unsafecell] umbúðir utan um value(s) sem hægt er að breyta með sameiginlegri tilvísun.
/// Takist þetta ekki er [undefined behavior][ub].
/// Til dæmis er [`transmute`][transmute]-ing frá `&T` til `&mut T` ógilt.
///
/// Sjá [the Nomicon][nomicon-send-and-sync] til að fá frekari upplýsingar um `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): einu sinni stuðningur við að bæta við athugasemdum í `rustc_on_unimplemented` lendir í beta, og það hefur verið framlengt til að athuga hvort lokun er einhvers staðar í kröfukeðjunni, lengja hana sem slíka (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Núllstór tegund notuð til að merkja hluti sem "act like" þeir eiga `T`.
///
/// Að bæta `PhantomData<T>` reit við gerðina þína segir þýðandanum að gerð þín virkar eins og hún geymi gildi af gerðinni `T`, jafnvel þó hún virki ekki.
/// Þessar upplýsingar eru notaðar við útreikning á tilteknum öryggiseiginleikum.
///
/// Fyrir nánari útskýringar á notkun `PhantomData<T>`, vinsamlegast skoðaðu [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Hræðileg athugasemd 👻👻👻
///
/// Þrátt fyrir að þeir hafi báðir óhugnanleg nöfn eru `PhantomData` og 'fantómategundir' skyldir en ekki eins.Phantom gerð breytu er einfaldlega gerð breytu sem er aldrei notuð.
/// Í Rust veldur þetta oft þýðandanum að kvarta og lausnin er að bæta við "dummy" notkun með `PhantomData`.
///
/// # Examples
///
/// ## Ónotaðir líftíma breytur
///
/// Kannski er algengasta tilfellið fyrir `PhantomData` uppbygging sem hefur ónotaða æviloka breytu, venjulega sem hluti af einhverjum óöruggum kóða.
/// Til dæmis er hér uppbygging `Slice` sem hefur tvo ábendinga af gerðinni `*const T`, sem væntanlega vísar í fylki einhvers staðar:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Ætlunin er að undirliggjandi gögn séu aðeins gild alla ævina `'a`, þannig að `Slice` ætti ekki að lifa `'a`.
/// Þessi ásetningur kemur þó ekki fram í kóðanum, þar sem ekki er notaður ævilangt `'a` og þess vegna er ekki ljóst hvaða gögn það á við um.
/// Við getum leiðrétt þetta með því að segja þýðandanum að haga sér *eins og*`Slice` strúktúrinn innihélt tilvísun `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Þetta krefst einnig aftur skýringarinnar `T: 'a`, sem gefur til kynna að allar tilvísanir í `T` séu gildar yfir líftíma `'a`.
///
/// Þegar þú ræsir `Slice` gefurðu einfaldlega gildi `PhantomData` fyrir reitinn `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Ónotaðar gerðarbreytur
///
/// Það kemur stundum fyrir að þú hafir ónotaðar gerðarfæribreytur sem gefa til kynna hvaða gerð gagna strúktúr er "tied" fyrir, þó að þau gögn finnist í raun ekki í byggingunni sjálfri.
/// Hér er dæmi þar sem þetta kemur upp með [FFI].
/// Erlenda viðmótið notar handföng af gerðinni `*mut ()` til að vísa til Rust gildi af mismunandi gerðum.
/// Við fylgjumst með Rust gerðinni með því að nota phantom gerð breytu á struct `ExternalResource` sem hylur handfangið.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Eignarhald og dropatékk
///
/// Að bæta við reit af gerðinni `PhantomData<T>` gefur til kynna að gerð þín eigi gögn af gerðinni `T`.Þetta þýðir aftur á móti að þegar tegundinni þinni er sleppt, þá getur það fallið frá einu eða fleiri tilfellum af gerðinni `T`.
/// Þetta hefur áhrif á [drop check] greiningu Rust þýðandans.
///
/// Ef strúktúrinn þinn á í raun *ekki* gögnin af gerðinni `T`, þá er betra að nota tilvísunargerð, eins og `PhantomData<&'a T>` (ideally) eða `PhantomData<*const T>` (ef engin líftími á við), svo að ekki sé bent á eignarhald.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Tölvu innra trait notað til að gefa til kynna hvers konar mismunun.
///
/// Þessi trait er sjálfkrafa útfærður fyrir allar gerðir og bætir engum ábyrgðum við [`mem::Discriminant`].
/// Það er **óskilgreind hegðun** að umbreyta á milli `DiscriminantKind::Discriminant` og `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Tegund mismununar sem verður að fullnægja trait bounds sem krafist er af `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Tölvu-innra trait notað til að ákvarða hvort tegund innihaldi einhverja `UnsafeCell` innbyrðis, en ekki með afleiðingu.
///
/// Þetta hefur til dæmis áhrif á það hvort `static` af því tagi er sett í skriflaust minniskort eða skrifanlegt kyrrstætt minni.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Tegundir sem hægt er að færa á öruggan hátt eftir að þær hafa verið festar.
///
/// Rust sjálft hefur ekki hugmynd um órofa tegundir og telur hreyfingar (td í gegnum verkefni eða [`mem::replace`]) alltaf öruggar.
///
/// [`Pin`][Pin] gerðin er notuð í staðinn til að koma í veg fyrir að hreyfing fari í gegnum gerðarkerfið.Ekki er hægt að færa benda `P<T>` vafna í [`Pin<P<T>>`][Pin] umbúðirnar út.
/// Sjá [`pin` module] skjöl fyrir frekari upplýsingar um festingu.
///
/// Útfærsla `Unpin` trait fyrir `T` lyftir takmörkunum við að festa tegundina, sem gerir kleift að færa `T` út úr [`Pin<P<T>>`][Pin] með aðgerðum eins og [`mem::replace`].
///
///
/// `Unpin` hefur engar afleiðingar fyrir gögn sem ekki eru fest.
/// Sérstaklega flytur [`mem::replace`] glaðlega `!Unpin` gögn (það virkar fyrir alla `&mut T`, ekki bara þegar `T: Unpin`).
/// Þú getur þó ekki notað [`mem::replace`] á gögnum sem eru vafin inni í [`Pin<P<T>>`][Pin] vegna þess að þú getur ekki fengið `&mut T` sem þú þarft til þess og *það* er það sem lætur þetta kerfi virka.
///
/// Svo þetta er til dæmis aðeins hægt að gera á gerðum sem útfæra `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Við þurfum breytanlega tilvísun til að hringja í `mem::replace`.
/// // Við getum fengið slíka tilvísun með því að (implicitly) ákallar `Pin::deref_mut`, en það er aðeins mögulegt vegna þess að `String` útfærir `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Þessi trait er sjálfkrafa útfærður fyrir næstum allar gerðir.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Merkjategund sem ekki útfærir `Unpin`.
///
/// Ef tegund inniheldur `PhantomPinned` mun hún ekki sjálfkrafa innleiða `Unpin`.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Útfærsla `Copy` fyrir frumstæðar gerðir.
///
/// Útfærslur sem ekki er hægt að lýsa í Rust eru útfærðar í `traits::SelectionContext::copy_clone_conditions()` í `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Hægt er að afrita sameiginlegar tilvísanir en breytilegar tilvísanir *ekki*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}