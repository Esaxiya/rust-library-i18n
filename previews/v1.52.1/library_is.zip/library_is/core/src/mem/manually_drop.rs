use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Umbúðir til að hindra að þýðandi kalli sjálfkrafa eyðileggjanda " T`.
/// Þessi umbúðir kosta 0.
///
/// `ManuallyDrop<T>` er háð sömu hagræðingu í skipulagi og `T`.
/// Þess vegna hefur það *engin áhrif* á forsendur sem þýðandinn gerir um innihald þess.
/// Til dæmis að frumstilla `ManuallyDrop<&mut T>` með [`mem::zeroed`] er óskilgreind hegðun.
/// Ef þú þarft að meðhöndla óinnblásin gögn skaltu nota [`MaybeUninit<T>`] í staðinn.
///
/// Athugaðu að aðgangur að gildi inni í `ManuallyDrop<T>` er öruggur.
/// Þetta þýðir að `ManuallyDrop<T>` sem innihaldinu hefur verið sleppt má ekki verða afhjúpað í gegnum almennt öruggt API.
/// Samsvarandi er `ManuallyDrop::drop` óöruggur.
///
/// # `ManuallyDrop` og slepptu pöntun.
///
/// Rust hefur vel skilgreint [drop order] gildi.
/// Til að ganga úr skugga um að túnum eða heimamönnum sé sleppt í ákveðinni röð skaltu endurraða yfirlýsingunum þannig að óbeina fallpöntunin sé rétt.
///
/// Það er mögulegt að nota `ManuallyDrop` til að stjórna fallpöntuninni, en til þess þarf óöruggan kóða og erfitt er að gera rétt í því að vinda ofan af.
///
///
/// Til dæmis, ef þú vilt ganga úr skugga um að tiltekið reit falli niður á eftir hinum, gerðu það að síðasta reit strúktúr:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` verður sleppt eftir `children`.
///     // Rust ábyrgist að reitir falli niður í röð yfirlýsingarinnar.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Vefðu gildi sem á að fella handvirkt.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Þú getur samt örugglega rekið gildi
    /// assert_eq!(*x, "Hello");
    /// // En `Drop` verður ekki keyrt hér
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Dregur út gildi úr `ManuallyDrop` gámnum.
    ///
    /// Þetta gerir gildinu kleift að falla aftur.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Þetta lækkar `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Tekur gildi úr `ManuallyDrop<T>` ílátinu.
    ///
    /// Þessi aðferð er fyrst og fremst ætluð til að færa út gildi í falli.
    /// Í stað þess að nota [`ManuallyDrop::drop`] til að fella gildi handvirkt, getur þú notað þessa aðferð til að taka gildi og nota það eftir því sem óskað er.
    ///
    /// Þegar mögulegt er er æskilegra að nota [`into_inner`][`ManuallyDrop::into_inner`] í staðinn, sem kemur í veg fyrir að tvítekja innihald `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Þessi aðgerð færir merkingarlega út innihaldsgildið án þess að koma í veg fyrir frekari notkun og skilur ástand þessa íláts óbreytt.
    /// Það er á þína ábyrgð að tryggja að þessi `ManuallyDrop` verði ekki notaður aftur.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // ÖRYGGI: við erum að lesa úr tilvísun, sem er tryggð
        // að vera gildur fyrir lestur.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Handvirkt lækkar innihaldsgildið.Þetta jafngildir nákvæmlega því að hringja í [`ptr::drop_in_place`] með bendi að innihaldsgildinu.
    /// Sem slík, nema innihaldsgildið sé pakkað strúktúr, verður eyðileggjandinn kallaður á staðinn án þess að færa gildið og er þannig hægt að nota til að sleppa [pinned] gögnum á öruggan hátt.
    ///
    /// Ef þú hefur eignarhald á verðmætinu geturðu notað [`ManuallyDrop::into_inner`] í staðinn.
    ///
    /// # Safety
    ///
    /// Þessi aðgerð keyrir eyðileggjanda innihaldsgildisins.
    /// Að öðru leyti en breytingum sem gerðar eru af eyðileggjandanum sjálfum er minnið óbreytt og svo hvað þýðandann snertir er enn með bitamynstur sem gildir fyrir gerð `T`.
    ///
    ///
    /// Hins vegar ætti þetta "zombie" gildi ekki að verða fyrir öruggum kóða og ekki ætti að hringja í þessa aðgerð oftar en einu sinni.
    /// Að nota gildi eftir að því hefur verið sleppt, eða sleppa gildi mörgum sinnum, getur valdið óskilgreindri hegðun (fer eftir því hvað `drop` gerir).
    /// Þetta er venjulega komið í veg fyrir með gerðarkerfinu, en notendur `ManuallyDrop` verða að standa við þær ábyrgðir án aðstoðar frá þýðanda.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // ÖRYGGI: við sleppum gildinu sem bent er á með breyttri tilvísun
        // sem er tryggt að gildir fyrir skrif.
        // Það er undir þeim sem hringir að ganga úr skugga um að `slot` sé ekki lækkað aftur.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}