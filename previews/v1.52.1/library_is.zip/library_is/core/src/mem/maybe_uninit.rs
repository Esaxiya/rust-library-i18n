use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Umbúðir til að búa til frumlausar tilvik af `T`.
///
/// # Frumstillingarbreyting
///
/// Alþýðandinn gerir almennt ráð fyrir að breyta sé rétt frumstillt í samræmi við kröfur tegundar breytunnar.Til dæmis verður breytu tilvísunargerðar að vera samstillt og ekki NULL.
/// Þetta er undantekningarlaust sem verður að *alltaf* halda, jafnvel í óöruggum kóða.
/// Þess vegna veldur núllstilling á breytu af viðmiðunargerð tafarlausri [undefined behavior][ub], sama hvort sú tilvísun venst einhvern tíma til að fá aðgang að minni:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // óskilgreind hegðun!⚠️
/// // Samsvarandi kóði með `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // óskilgreind hegðun!⚠️
/// ```
///
/// Þetta nýtir þýðandinn fyrir ýmsar hagræðingar, svo sem að fjarlægja keyrslutíma og fínstilla `enum` skipulag.
///
/// Á sama hátt getur algjörlega óinnblásið minni haft hvaða efni sem er, en `bool` verður alltaf að vera `true` eða `false`.Þess vegna er óskilgreind hegðun að búa til frumlaus `bool`:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // óskilgreind hegðun!⚠️
/// // Samsvarandi kóði með `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // óskilgreind hegðun!⚠️
/// ```
///
/// Þar að auki er einræktað minni sérstakt að því leyti að það hefur ekki fast gildi ("fixed" sem þýðir "it won't change without being written to").Að lesa sama óinnblásna bítinn margfalt getur gefið mismunandi niðurstöður.
/// Þetta gerir það óskilgreint atferli að hafa óforvarnargögn í breytu, jafnvel þó að sú breyta hafi heiltölu, sem annars getur haft hvaða *fasta* bitamynstur:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // óskilgreind hegðun!⚠️
/// // Samsvarandi kóði með `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // óskilgreind hegðun!⚠️
/// ```
/// (Athugið að ekki er enn búið að ganga frá reglunum um óeiningarheiltölur, en þangað til þær eru, er ráðlegt að forðast þær.)
///
/// Í ofanálag skaltu muna að í flestum tegundum eru fleiri innflytjendur umfram það að vera aðeins talin upphafleg á tegundarstiginu.
/// Til dæmis er [`Vec<T>`] með '1' upphafsstafi talinn upphaflegur (samkvæmt núverandi útfærslu; þetta er ekki stöðug ábyrgð) vegna þess að eina krafan sem þýðandinn veit um það er að gagnabendillinn verði að vera enginn.
/// Að búa til slíkan `Vec<T>` veldur ekki *strax* óskilgreindri hegðun heldur mun valda óskilgreindri hegðun með öruggustu aðgerðum (þar með talið að sleppa henni).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` þjónar til að gera óöruggan kóða kleift að takast á við óupplýst gögn.
/// Það er merki til þýðandans sem gefur til kynna að gögnin hér *gætu* ekki verið frumstillt:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Búðu til gagngeran tilnefningu tilvísunar.
/// // Þáttaraðilinn veit að gögn inni í `MaybeUninit<T>` geta verið ógild og þess vegna er þetta ekki UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Stilltu það á gild gildi.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Dragðu frá upphaflegu gögnin-þetta er aðeins leyfilegt * eftir að `x` er frumstillt á réttan hátt!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Þáttaraðilinn veit þá að gera ekki rangar forsendur eða hagræðingu á þessum kóða.
///
/// Þú getur hugsað þér að `MaybeUninit<T>` sé svolítið eins og `Option<T>` en án nokkurs rekstrartíma og án öryggisskoðana.
///
/// ## out-pointers
///
/// Þú getur notað `MaybeUninit<T>` til að framkvæma "out-pointers": í stað þess að skila gögnum úr aðgerð skaltu láta það benda á eitthvað (uninitialized) minni til að setja niðurstöðuna í það.
/// Þetta getur verið gagnlegt þegar það er mikilvægt fyrir þann sem hringir í að stjórna því hvernig minni sem niðurstaðan er geymd í er úthlutað og þú vilt forðast óþarfa hreyfingar.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` sleppir ekki gamla innihaldinu, sem er mikilvægt.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Nú vitum við að `v` er frumstillt!Þetta tryggir einnig að vector falli almennilega niður.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Að frumstilla fylkið þátt fyrir lið
///
/// `MaybeUninit<T>` er hægt að nota til að frumstilla stórt fylki-fyrir-frumefni:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Búðu til uninitialized fylki af `MaybeUninit`.
///     // `assume_init` er öruggt vegna þess að sú gerð sem við segjumst hafa frumstillt hérna er fullt af " MaybeUninit`s, sem ekki þarfnast frumstillingar.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Að sleppa `MaybeUninit` gerir ekki neitt.
///     // Þannig að notkun hrás bendilverkefnis í stað `ptr::write` veldur ekki því að gamla óinnvígða gildi falli niður.
/////
///     // Einnig ef það er panic meðan á þessari lykkju stendur erum við með minnisleka, en það er ekkert minni öryggisvandamál.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Allt er frumstillt.
///     // Breyttu fylkinu í upphafsgerðina.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Þú getur líka unnið með upphafsstillt fylki, sem er að finna í gagnastarfsemi á lágu stigi.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Búðu til uninitialized fylki af `MaybeUninit`.
/// // `assume_init` er öruggt vegna þess að sú gerð sem við segjumst hafa frumstillt hérna er fullt af " MaybeUninit`s, sem ekki þarfnast frumstillingar.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Teljið fjölda þátta sem við höfum úthlutað.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Fyrir hvert atriði í fylkinu, slepptu ef við úthlutuðum því.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Að frumstilla uppbyggingu svið fyrir svið
///
/// Þú getur notað `MaybeUninit<T>` og [`std::ptr::addr_of_mut`] fjölvi til að frumstilla strengi reit fyrir reit:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Ræsir `name` reitinn
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Ræsir `list` reitinn Ef það er panic hér, þá lekur `String` í `name` reitnum.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Allir reitirnir eru frumstilltir og því hringjum við í `assume_init` til að fá frumstilltan Foo.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` er tryggt að hafa sömu stærð, röðun og ABI og `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// En mundu að tegund *sem inniheldur*`MaybeUninit<T>` er ekki endilega sama skipulag;Rust ábyrgist ekki almennt að reitir `Foo<T>` hafi sömu röð og `Foo<U>`, jafnvel þótt `T` og `U` hafi sömu stærð og röðun.
///
/// Ennfremur vegna þess að öll bitagildi eru gild fyrir `MaybeUninit<T>` getur þýðandinn ekki beitt non-zero/niche-filling hagræðingu, sem hugsanlega hefur í för með sér stærri stærð:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Ef `T` er FFI-öruggt, þá er `MaybeUninit<T>` það líka.
///
/// Þó `MaybeUninit` sé `#[repr(transparent)]` (sem gefur til kynna að það tryggi sömu stærð, röðun og ABI og `T`), þá breytir þetta * engum af fyrri fyrirvörum.
/// `Option<T>` og `Option<MaybeUninit<T>>` geta samt haft mismunandi stærðir og gerðir sem innihalda reit af gerðinni `T` geta verið lagðar (og stærðar) á annan hátt en ef sá reitur væri `MaybeUninit<T>`.
/// `MaybeUninit` er stéttarfélagsgerð og `#[repr(transparent)]` í stéttarfélögum er óstöðug (sjá [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Með tímanum geta nákvæmar ábyrgðir `#[repr(transparent)]` hjá stéttarfélögum þróast og `MaybeUninit` getur verið `#[repr(transparent)]` eða ekki.
/// Sem sagt, `MaybeUninit<T>` mun *alltaf* ábyrgjast að það hafi sömu stærð, röðun og ABI og `T`;það er bara þannig að `MaybeUninit` útfærir þá ábyrgð getur þróast.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang hlutur svo við getum pakkað öðrum tegundum í hann.Þetta er gagnlegt fyrir rafala.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Við hringjum ekki í `T::clone()`, við getum ekki vitað hvort við erum nógu upphafsstafir til þess.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Býr til nýjan `MaybeUninit<T>` frumstýrðan með gefnu gildi.
    /// Það er óhætt að hringja í [`assume_init`] á skilagildi þessarar aðgerðar.
    ///
    /// Athugaðu að sleppa `MaybeUninit<T>` kallar aldrei dropakóða " T`.
    /// Það er á þína ábyrgð að ganga úr skugga um að `T` falli niður ef það er frumstillt.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Býr til nýjan `MaybeUninit<T>` í óafgreiddu ástandi.
    ///
    /// Athugaðu að sleppa `MaybeUninit<T>` kallar aldrei dropakóða " T`.
    /// Það er á þína ábyrgð að ganga úr skugga um að `T` falli niður ef það er frumstillt.
    ///
    /// Sjá [type-level documentation][MaybeUninit] fyrir nokkur dæmi.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Búðu til nýjan fjölda `MaybeUninit<T>` atriða, í ófrumbyggðu ástandi.
    ///
    /// Note: í future Rust útgáfu getur þessi aðferð orðið óþörf þegar setningafræði bókstafstrúar leyfir [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Dæmið hér að neðan gæti þá notað `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Skilar (hugsanlega minni) sneið af gögnum sem voru í raun lesin
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // ÖRYGGI: `[MaybeUninit<_>; LEN]` sem ekki hefur verið frumflutt er gild.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Býr til nýjan `MaybeUninit<T>` í óafgreiddu ástandi, þar sem minnið er fyllt með `0` bæti.Það veltur á `T` hvort það gerir nú þegar rétta frumstillingu.
    ///
    /// Til dæmis er `MaybeUninit<usize>::zeroed()` frumstillt en `MaybeUninit<&'static i32>::zeroed()` er ekki vegna þess að tilvísanir mega ekki vera engar.
    ///
    /// Athugaðu að sleppa `MaybeUninit<T>` kallar aldrei dropakóða " T`.
    /// Það er á þína ábyrgð að ganga úr skugga um að `T` falli niður ef það er frumstillt.
    ///
    /// # Example
    ///
    /// Rétt notkun á þessari aðgerð: að frumstilla uppbyggingu með núlli, þar sem allir reitir byggingarinnar geta haldið bitamynstrinu 0 sem gildu gildi.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Rangt* notkun á þessari aðgerð: að hringja í `x.zeroed().assume_init()` þegar `0` er ekki gilt bitamynstur fyrir gerðina:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Inni í pari búum við til `NotZero` sem hefur ekki gildan mismunun.
    /// // Þetta er óskilgreind hegðun.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // ÖRYGGI: `u.as_mut_ptr()` bendir á úthlutað minni.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Stillir gildi `MaybeUninit<T>`.
    /// Þetta skrifar yfir öll fyrri gildi án þess að láta það falla, svo vertu varkár að nota þetta ekki tvisvar nema þú viljir sleppa því að keyra tortímandann.
    ///
    /// Til þæginda þinna skilar þetta einnig breytilegri tilvísun í innihald (nú örugglega frumstillt) `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // ÖRYGGI: Við frumstöfuðum þetta gildi.
        unsafe { self.assume_init_mut() }
    }

    /// Fær bendi að innihaldsgildinu.
    /// Að lesa úr þessum bendli eða breyta honum í tilvísun er óskilgreind hegðun nema `MaybeUninit<T>` sé frumstillt.
    /// Að skrifa til minni sem þessi bendill (non-transitively) bendir á er óskilgreind hegðun (nema inni í `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Rétt notkun á þessari aðferð:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Búðu til tilvísun í `MaybeUninit<T>`.Þetta er í lagi vegna þess að við frumstilltum það.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Rangt* notkun þessarar aðferðar:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Við höfum búið til tilvísun í ófrumbundið vector!Þetta er óskilgreind hegðun.⚠️
    /// ```
    ///
    /// (Athugið að ekki er enn búið að ganga frá reglunum um tilvísanir í óinnleiddar upplýsingar, en þangað til þær eru, er ráðlegt að forðast þær.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` og `ManuallyDrop` eru báðir `repr(transparent)` svo við getum kastað músinni.
        self as *const _ as *const T
    }

    /// Fær breytanlegan bendil að gildinu.
    /// Að lesa úr þessum bendli eða breyta honum í tilvísun er óskilgreind hegðun nema `MaybeUninit<T>` sé frumstillt.
    ///
    /// # Examples
    ///
    /// Rétt notkun á þessari aðferð:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Búðu til tilvísun í `MaybeUninit<Vec<u32>>`.
    /// // Þetta er í lagi vegna þess að við frumstilltum það.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Rangt* notkun þessarar aðferðar:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Við höfum búið til tilvísun í ófrumbundið vector!Þetta er óskilgreind hegðun.⚠️
    /// ```
    ///
    /// (Athugið að ekki er enn búið að ganga frá reglunum um tilvísanir í óinnleiddar upplýsingar, en þangað til þær eru, er ráðlegt að forðast þær.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` og `ManuallyDrop` eru báðir `repr(transparent)` svo við getum kastað músinni.
        self as *mut _ as *mut T
    }

    /// Dregur út gildi úr `MaybeUninit<T>` gámnum.Þetta er frábær leið til að tryggja að gögnin falli niður, vegna þess að `T` sem myndast er háð venjulegri dropameðferð.
    ///
    /// # Safety
    ///
    /// Það er undir þeim sem hringir að ábyrgjast að `MaybeUninit<T>` sé raunverulega í frumstilltu ástandi.Að hringja í þetta þegar innihaldið er ekki enn frumstillt veldur óskilgreindri hegðun strax.
    /// [type-level documentation][inv] inniheldur frekari upplýsingar um þessa upphafsbreytingu.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Í ofanálag skaltu muna að í flestum tegundum eru fleiri innflytjendur umfram það að vera aðeins talin upphafleg á tegundarstiginu.
    /// Til dæmis er [`Vec<T>`] með '1' upphafsstafi talinn upphaflegur (samkvæmt núverandi útfærslu; þetta er ekki stöðug ábyrgð) vegna þess að eina krafan sem þýðandinn veit um það er að gagnabendillinn verði að vera enginn.
    ///
    /// Að búa til slíkan `Vec<T>` veldur ekki *strax* óskilgreindri hegðun heldur mun valda óskilgreindri hegðun með öruggustu aðgerðum (þar með talið að sleppa henni).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Rétt notkun á þessari aðferð:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Rangt* notkun þessarar aðferðar:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` hafði ekki verið frumstillt ennþá, svo þessi síðasta lína olli óskilgreindri hegðun.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // ÖRYGGI: sá sem hringir þarf að ábyrgjast að `self` sé frumstillt.
        // Þetta þýðir líka að `self` verður að vera `value` afbrigði.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Lesi gildi úr `MaybeUninit<T>` ílátinu.`T` sem myndast er háð venjulegum dropameðhöndlun.
    ///
    /// Þegar mögulegt er er æskilegra að nota [`assume_init`] í staðinn, sem kemur í veg fyrir að tvítekja innihald `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Það er undir þeim sem hringir að ábyrgjast að `MaybeUninit<T>` sé raunverulega í frumstilltu ástandi.Að kalla þetta þegar innihaldið er ekki enn frumstillt að fullu veldur óskilgreindri hegðun.
    /// [type-level documentation][inv] inniheldur frekari upplýsingar um þessa upphafsbreytingu.
    ///
    /// Þar að auki skilur þetta eftir afrit af sömu gögnum í `MaybeUninit<T>`.
    /// Þegar þú notar mörg afrit af gögnum (með því að hringja í `assume_init_read` mörgum sinnum, eða hringja fyrst í `assume_init_read` og síðan [`assume_init`]), er það á þína ábyrgð að tryggja að þessi gögn geti örugglega verið endurtekin.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Rétt notkun á þessari aðferð:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` er `Copy`, svo við getum lesið það mörgum sinnum.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Að afrita `None` gildi er í lagi, svo við getum lesið það oft.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Rangt* notkun þessarar aðferðar:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Við bjuggum nú til tvö eintök af sama vector, sem leiðir til tvöfalt ókeypis ⚠️ þegar þau falla bæði!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // ÖRYGGI: sá sem hringir þarf að ábyrgjast að `self` sé frumstillt.
        // Lestur frá `self.as_ptr()` er öruggur þar sem `self` ætti að vera frumstillt.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Sleppir innihaldsgildinu á sínum stað.
    ///
    /// Ef þú hefur eignarhald á `MaybeUninit` geturðu notað [`assume_init`] í staðinn.
    ///
    /// # Safety
    ///
    /// Það er undir þeim sem hringir að ábyrgjast að `MaybeUninit<T>` sé raunverulega í frumstilltu ástandi.Að kalla þetta þegar innihaldið er ekki enn frumstillt að fullu veldur óskilgreindri hegðun.
    ///
    /// Ofan á það bætist að allir viðbótarinnflytjendur af gerðinni `T` verða að vera fullnægðir, þar sem `Drop` útfærsla `T` (eða meðlimir hennar) getur reitt sig á þetta.
    /// Til dæmis er [`Vec<T>`] með '1' upphafsstafi talinn upphaflegur (samkvæmt núverandi útfærslu; þetta er ekki stöðug ábyrgð) vegna þess að eina krafan sem þýðandinn veit um það er að gagnabendillinn verði að vera enginn.
    ///
    /// Að sleppa slíkum `Vec<T>` mun hins vegar valda óskilgreindri hegðun.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // ÖRYGGI: sá sem hringir þarf að ábyrgjast að `self` sé frumstillt og
        // fullnægir öllum innflytjendum `T`.
        // Að sleppa gildinu á sínum stað er öruggt ef það er raunin.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Fær sameiginlega tilvísun í innihaldsgildið.
    ///
    /// Þetta getur verið gagnlegt þegar við viljum fá aðgang að `MaybeUninit` sem hefur verið frumstilltur en höfum ekki eignarhald á `MaybeUninit` (kemur í veg fyrir notkun `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Að hringja í þetta þegar innihaldið er ekki enn frumstillt veldur óskilgreindri hegðun: það er hringjandans að ábyrgjast að `MaybeUninit<T>` sé raunverulega í frumstilltu ástandi.
    ///
    ///
    /// # Examples
    ///
    /// ### Rétt notkun á þessari aðferð:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Ræsið `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Nú þegar vitað er að frumstilling `MaybeUninit<_>` okkar er í lagi að búa til sameiginlega tilvísun í það:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // ÖRYGGI: `x` hefur verið frumstillt.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Rangt* notkun á þessari aðferð:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Við höfum búið til tilvísun í ófrumbundið vector!Þetta er óskilgreind hegðun.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Ræsið `MaybeUninit` með `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Tilvísun í óbyggðan `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // ÖRYGGI: sá sem hringir þarf að ábyrgjast að `self` sé frumstillt.
        // Þetta þýðir líka að `self` verður að vera `value` afbrigði.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Fær breytanlega (unique) tilvísun í innihaldsgildið.
    ///
    /// Þetta getur verið gagnlegt þegar við viljum fá aðgang að `MaybeUninit` sem hefur verið frumstilltur en höfum ekki eignarhald á `MaybeUninit` (kemur í veg fyrir notkun `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Að hringja í þetta þegar innihaldið er ekki enn frumstillt veldur óskilgreindri hegðun: það er hringjandans að ábyrgjast að `MaybeUninit<T>` sé raunverulega í frumstilltu ástandi.
    /// Til dæmis er ekki hægt að nota `.assume_init_mut()` til að frumstilla `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Rétt notkun á þessari aðferð:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Rafstilla *öll* bæti inntaks biðminnis.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Ræsið `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Nú vitum við að `buf` hefur verið frumstillt, svo við gætum `.assume_init()` það.
    /// // Hins vegar getur notkun `.assume_init()` komið af stað `memcpy` af 2048 bæti.
    /// // Til að fullyrða að biðminni okkar hafi verið frumstillt án þess að afrita hann uppfærum við `&mut MaybeUninit<[u8; 2048]>` í `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // ÖRYGGI: `buf` hefur verið frumstillt.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Nú getum við notað `buf` sem venjulega sneið:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Rangt* notkun á þessari aðferð:
    ///
    /// Þú getur ekki notað `.assume_init_mut()` til að frumstilla gildi:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Við höfum búið til (mutable) tilvísun í óbyggt `bool`!
    ///     // Þetta er óskilgreind hegðun.⚠️
    /// }
    /// ```
    ///
    /// Til dæmis er ekki hægt að [`Read`] í óinnsettan biðminni:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) tilvísun í einræktað minni!
    ///                             // Þetta er óskilgreind hegðun.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Ekki er heldur hægt að nota beinan aðgang að vettvangi til að gera stig fyrir stig af stigi frumstilling:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) tilvísun í einræktað minni!
    ///                  // Þetta er óskilgreind hegðun.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) tilvísun í einræktað minni!
    ///                  // Þetta er óskilgreind hegðun.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Nú treystum við á að ofangreint sé rangt, þ.e. við höfum tilvísanir í óupplýst gögn (td í `libcore/fmt/float.rs`).
    // Við ættum að taka endanlega ákvörðun um reglurnar fyrir stöðugleika.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // ÖRYGGI: sá sem hringir þarf að ábyrgjast að `self` sé frumstillt.
        // Þetta þýðir líka að `self` verður að vera `value` afbrigði.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Sækir gildin úr fylki `MaybeUninit` gáma.
    ///
    /// # Safety
    ///
    /// Það er undir þeim sem hringir að ábyrgjast að allir þættir fylkisins séu í upphafsstöðu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // ÖRYGGI: Nú öruggt þegar við frumstilltum alla þætti
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Sá sem hringir tryggir að allir þættir fylkisins séu frumstilltir
        // * `MaybeUninit<T>` og T er tryggt að hafa sama skipulag
        // * Kannski fellurUnint ekki niður, þannig að það eru engin tvöföld frelsi og þar með er umbreytingin örugg
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Miðað við að allir þættir séu frumstilltir skaltu fá sneið að þeim.
    ///
    /// # Safety
    ///
    /// Það er undir þeim sem hringir að ábyrgjast að `MaybeUninit<T>` þættirnir séu raunverulega í frumstilltu ástandi.
    ///
    /// Að kalla þetta þegar innihaldið er ekki enn frumstillt að fullu veldur óskilgreindri hegðun.
    ///
    /// Sjá [`assume_init_ref`] fyrir frekari upplýsingar og dæmi.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // ÖRYGGI: að steypa sneið í `*const [T]` er öruggt þar sem kallinn ábyrgist það
        // `slice` er frumstillt og 'MaybeUninit' er tryggt að hafa sama skipulag og `T`.
        // Bendillinn sem fæst er gildur þar sem hann vísar til minni í eigu `slice` sem er tilvísun og þannig tryggt að það gildir fyrir lestur.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Miðað við að allir þættir séu frumstilltir, fáðu þá breytanlega sneið.
    ///
    /// # Safety
    ///
    /// Það er undir þeim sem hringir að ábyrgjast að `MaybeUninit<T>` þættirnir séu raunverulega í frumstilltu ástandi.
    ///
    /// Að kalla þetta þegar innihaldið er ekki enn frumstillt að fullu veldur óskilgreindri hegðun.
    ///
    /// Sjá [`assume_init_mut`] fyrir frekari upplýsingar og dæmi.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // ÖRYGGI: svipað og öryggisráðstafanir fyrir `slice_get_ref`, en við höfum a
        // breytileg tilvísun sem einnig er tryggt að gildir fyrir skrif.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Fær bendi á fyrsta þáttinn í fylkinu.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Fær breytilegan bendil á fyrsta þátt fylkisins.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Afritar þættina frá `src` til `this` og skilar breytilegri tilvísun í innihald `this` sem nú er ófjármagnað.
    ///
    /// Ef `T` innleiðir ekki `Copy`, notaðu [`write_slice_cloned`]
    ///
    /// Þetta er svipað og [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Þessi aðgerð mun panic ef sneiðarnar tvær hafa mismunandi lengd.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // ÖRYGGI: við erum nýbúin að afrita alla þætti len í varaflutninginn
    /// // fyrstu src.len() þættirnir í vec eru í gildi núna.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // ÖRYGGI: &[T] og&[MaybeUninit<T>] hafa sama skipulag
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // ÖRYGGI: Gildir þættir hafa nýlega verið afritaðir í `this` svo það er ófjármagnað
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Klónar frumefnin frá `src` til `this` og skilar breytilegri tilvísun í innihald `this` sem nú er ófjármagnað.
    /// Öllum frumum sem þegar eru ónýttir verður ekki sleppt.
    ///
    /// Ef `T` útfærir `Copy`, notaðu [`write_slice`]
    ///
    /// Þetta er svipað og [`slice::clone_from_slice`] en sleppir ekki núverandi þáttum.
    ///
    /// # Panics
    ///
    /// Þessi aðgerð mun panic ef sneiðarnar tvær hafa mismunandi lengd, eða ef útfærsla `Clone` panics.
    ///
    /// Ef það er panic verður nú þegar klónað frumefni fellt.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // ÖRYGGI: við erum nýbúin að klóna alla þætti len í varahlutina
    /// // fyrstu src.len() þættirnir í vec eru í gildi núna.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // ólíkt copy_from_slice kallar þetta ekki clone_from_slice á sneiðina þetta er vegna þess að `MaybeUninit<T: Clone>` útfærir ekki Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // ÖRYGGI: þessi hráa sneið mun aðeins innihalda frumstillta hluti
                // þess vegna er leyfilegt að sleppa því.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Við verðum að sneiða þau sérstaklega í sömu lengd
        // til að kanna mörk sem hægt er að fjarlægja og fínstillirinn mun búa til memcpy fyrir einföld mál (til dæmis T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // Vörður er þörf b/c panic gæti gerst meðan á klón stendur
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // ÖRYGGI: Gildir þættir hafa nýlega verið skrifaðir í `this` svo það er ófjármagnað
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}