//! Grunnaðgerðir til að takast á við minni.
//!
//! Þessi eining inniheldur aðgerðir til að spyrja um stærð og röðun gerða, frumstilla og vinna með minni.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Tekur eignarhald og "forgets" um verðmæti **án þess að keyra eyðileggjanda þess**.
///
/// Allar auðlindir sem gildið hefur umsjón með, svo sem hrúgaminni eða skjalafgreiðsla, munu sitja að eilífu í óaðgengilegu ástandi.Það tryggir þó ekki að vísbendingar um þetta minni haldi gildi sínu.
///
/// * Ef þú vilt leka minni, sjá [`Box::leak`].
/// * Ef þú vilt fá hráan bendil á minnið, sjá [`Box::into_raw`].
/// * Ef þú vilt ráðstafa gildi rétt og keyra eyðileggjanda þess, sjá [`mem::drop`].
///
/// # Safety
///
/// `forget` er ekki merkt sem `unsafe`, vegna þess að öryggisábyrgð Rust felur ekki í sér ábyrgð á því að eyðileggjendur muni alltaf keyra.
/// Til dæmis getur forrit búið til viðmiðunarferil með því að nota [`Rc`][rc], eða hringt í [`process::exit`][exit] til að hætta án þess að keyra eyðileggjendur.
/// Þannig að leyfa `mem::forget` úr öruggum kóða breytir ekki í grundvallaratriðum öryggisábyrgð Rust.
///
/// Sem sagt, leka auðlindum eins og minni eða I/O hlutum er venjulega óæskilegt.
/// Þörfin kemur upp í sumum sérhæfðum notkunartilfellum fyrir FFI eða óöruggan kóða, en jafnvel þá er [`ManuallyDrop`] venjulega valinn.
///
/// Þar sem gleymt er gildi er leyfilegt, hvaða `unsafe` kóði sem þú skrifar verður að leyfa þennan möguleika.Þú getur ekki skilað gildi og búist við að sá sem hringir muni endilega stjórna eyðileggjanda gildisins.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Hinn kanóníska örugga notkun `mem::forget` er að sniðganga eyðileggjanda gildi sem `Drop` trait framkvæmir.Til dæmis mun þetta leka `File`, þ.e.
/// endurheimtu svæðið sem breytan tekur en lokaðu aldrei undirliggjandi kerfisauðlind:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Þetta er gagnlegt þegar eignarhald á undirliggjandi auðlind var áður flutt yfir í kóða utan Rust, til dæmis með því að senda hráa skráarlýsinguna yfir í C kóða.
///
/// # Tengsl við `ManuallyDrop`
///
/// Þó að `mem::forget` sé einnig hægt að nota til að flytja *minni* eignarhald, þá er það mistök.
/// [`ManuallyDrop`] ætti að nota í staðinn.Hugleiddu til dæmis þennan kóða:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Byggðu `String` með því að nota innihald `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // leka `v` vegna þess að minni þess er nú stjórnað af `s`
/// mem::forget(v);  // VILLA, v er ógilt og má ekki fara í aðgerð
/// assert_eq!(s, "Az");
/// // `s` er óbeint sleppt og minni hennar úthlutað.
/// ```
///
/// Það eru tvö atriði með dæminu hér að ofan:
///
/// * Ef bætt var við fleiri kóða milli smíði `String` og ákalls `mem::forget()`, myndi panic innan þess valda tvöföldu lausu vegna þess að sama minni er stjórnað af bæði `v` og `s`.
/// * Eftir að hafa hringt í `v.as_mut_ptr()` og sent eignarhald gagna til `s` er `v` gildi ógilt.
/// Jafnvel þegar gildi er bara fært yfir í `mem::forget` (sem skoðar það ekki), hafa sumar gerðir strangar kröfur um gildi þeirra sem gera þau ógild þegar þau hanga eða eru ekki lengur í eigu.
/// Notkun ógildra gilda á nokkurn hátt, þar með talin að færa þau til eða skila þeim úr föllum, er óskilgreind hegðun og getur brotið forsendur þýðandans.
///
/// Að skipta yfir í `ManuallyDrop` forðast bæði vandamál:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Áður en við sundurskiptum `v` í hráhlutana skaltu ganga úr skugga um að það falli ekki niður!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Taktu nú `v` í sundur.Þessar aðgerðir geta ekki panic, svo það getur ekki verið leki.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Að lokum skaltu byggja `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` er óbeint sleppt og minni hennar úthlutað.
/// ```
///
/// `ManuallyDrop` kemur í veg fyrir tvöfalt frelsi vegna þess að við gerum óvirkan " v` óvirkan áður en við gerum eitthvað annað.
/// `mem::forget()` leyfir þetta ekki vegna þess að það eyðir rökum sínum og neyðir okkur til að hringja í það aðeins eftir að hafa dregið allt sem við þurfum úr `v`.
/// Jafnvel ef panic væri kynnt milli smíði `ManuallyDrop` og byggingar strengsins (sem getur ekki gerst í kóðanum eins og sýnt er), myndi það leiða til leka og ekki tvöfalt ókeypis.
/// Með öðrum orðum, `ManuallyDrop` villur á hliðinni að leka í stað þess að villast á hliðinni (tvöföld-) sleppa.
///
/// Einnig kemur `ManuallyDrop` í veg fyrir að við verðum að "touch" `v` eftir að hafa flutt eignarhaldið yfir á `s`-það er alveg forðast að lokaskrefið í samskiptum við `v` til að farga því án þess að keyra eyðileggjanda þess.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Eins og [`forget`], en samþykkir einnig óstærð gildi.
///
/// Þessi aðgerð er bara shim sem ætlað er að fjarlægja þegar `unsized_locals` eiginleikinn verður stöðugur.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Skilar stærð tegundar í bæti.
///
/// Nánar tiltekið er þetta móti í bætum á milli þátta í röð í fylki með þeirri vörutegund, þ.mt jöfnunarpúði.
///
/// Þannig, fyrir allar tegundir `T` og lengd `n`, hefur `[T; n]` stærðina `n * size_of::<T>()`.
///
/// Almennt séð er stærð tegundar ekki stöðug yfir safnplöturnar, en sérstakar gerðir eins og frumefni eru.
///
/// Eftirfarandi tafla gefur stærð frumstæðra.
///
/// Gerð |stærð_ af: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 bleikjur |4
///
/// Ennfremur hafa `usize` og `isize` sömu stærð.
///
/// Tegundirnar `*const T`, `&T`, `Box<T>`, `Option<&T>` og `Option<Box<T>>` hafa allar sömu stærð.
/// Ef `T` er stærð hafa allar þessar gerðir sömu stærð og `usize`.
///
/// Breytileiki bendis breytir ekki stærð hans.Sem slík hafa `&T` og `&mut T` sömu stærð.
/// Sömuleiðis fyrir `*const T` og `* mut T`.
///
/// # Stærð `#[repr(C)]` atriða
///
/// `C` framsetning fyrir hluti hefur skilgreint útlit.
/// Með þessu skipulagi er stærð hlutanna einnig stöðug svo framarlega sem allir reitir hafa stöðuga stærð.
///
/// ## Stærð structs
///
/// Fyrir `structs` er stærðin ákvörðuð með eftirfarandi reiknirit.
///
/// Fyrir hvern reit í skipulaginu raðað eftir yfirlýsingaröð:
///
/// 1. Bæta við stærð reitsins.
/// 2. Hringaðu núverandi stærð upp í næsta margfeldi af [alignment] næsta reits.
///
/// Að lokum, hringdu stærð strútsins að næsta margfeldi [alignment] þess.
/// Jöfnun byggingarinnar er venjulega stærsta röðun allra sviða hennar;þessu er hægt að breyta með notkun `repr(align(N))`.
///
/// Ólíkt `C` eru strengir í núllstærð ekki námundaðir að einu bæti að stærð.
///
/// ## Stærð Enums
///
/// Ráðstefnur sem hafa engin önnur gögn en mismununin hafa sömu stærð og C enums á þeim vettvangi sem þeir eru settir saman fyrir.
///
/// ## Stærð stéttarfélaga
///
/// Stærð stéttarfélags er stærð stærsta sviðs þess.
///
/// Ólíkt `C` eru stéttarfélög með núllstærð ekki ávöl upp að einu bæti að stærð.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Sum frumstæði
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Sum fylki
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Stærð jafnréttis bendils
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Notkun `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Stærð fyrsta reitsins er 1, svo bæta 1 við stærðina.Stærð er 1.
/// // Röðun annars reits er 2, svo bæta 1 við stærðina fyrir bólstrun.Stærð er 2.
/// // Stærð annars reitsins er 2, svo bæta 2 við stærðina.Stærð er 4.
/// // Röðun þriðja reitsins er 1, svo bæta 0 við stærðina fyrir bólstrun.Stærð er 4.
/// // Stærð þriðja reitsins er 1, svo bæta 1 við stærðina.Stærð er 5.
/// // Að lokum er röðun strúktúrsins 2 (vegna þess að stærsta röðunin á sviðum hennar er 2), svo bæta 1 við stærðina fyrir bólstrun.
/// // Stærð er 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tuple strengir fylgja sömu reglum.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Athugið að endurröðun reitanna getur lækkað stærðina.
/// // Við getum fjarlægt bæði bólstrunarbæti með því að setja `third` fyrir `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Sambandsstærð er stærð stærsta reitsins.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Skilar stærð sem bent var á í bætum.
///
/// Þetta er venjulega það sama og `size_of::<T>()`.
/// Hins vegar, þegar `T`*hefur* enga statískt þekkta stærð, td sneið [`[T]`][slice] eða [trait object], þá er hægt að nota `size_of_val` til að fá stærð sem er þekkt.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // ÖRYGGI: `val` er tilvísun, svo það er gildur hrár bendill
    unsafe { intrinsics::size_of_val(val) }
}

/// Skilar stærð sem bent var á í bætum.
///
/// Þetta er venjulega það sama og `size_of::<T>()`.Hins vegar, þegar `T`*hefur* enga stærðarþekkta stærð, td sneið [`[T]`][slice] eða [trait object], þá er hægt að nota `size_of_val_raw` til að fá stærð sem er þekkt.
///
/// # Safety
///
/// Þessa aðgerð er aðeins óhætt að hringja í ef eftirfarandi skilyrði eru:
///
/// - Ef `T` er `Sized` er alltaf hægt að hringja í þessa aðgerð.
/// - Ef óstærð skottið á `T` er:
///     - [slice], þá verður lengd sneiðaskottins að vera upphafleg heiltala og stærð *allt gildi*(kraftmikill halalengd + forskeyti með stærðarstærð) verður að passa í `isize`.
///     - a [trait object], þá verður vtable hluti bendilsins að benda á gilt vtable fengið með óstærð þvingun og stærð *allt gildi*(dynamic halalengd + forskeyti með statískt stærð) verður að passa í `isize`.
///
///     - (unstable) [extern type], þá er alltaf hægt að hringja í þessa aðgerð, en getur panic eða á annan hátt skilað röngu gildi þar sem útlit ytri gerðar er ekki þekkt.
///     Þetta er sama hegðun og [`size_of_val`] varðandi tilvísun í gerð með utanaðkomandi skott.
///     - annars er íhaldssamt ekki leyft að kalla þessa aðgerð.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // ÖRYGGI: sá sem hringir verður að leggja fram giltan hráan bendil
    unsafe { intrinsics::size_of_val(val) }
}

/// Skilar [ABI] krafist lágmarksstillingar tegundar.
///
/// Sérhver tilvísun í gildi af gerðinni `T` verður að vera margfeldi þessarar tölu.
///
/// Þetta er jöfnunin sem notuð er fyrir uppbyggingarsvið.Það getur verið minna en æskileg röðun.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Skilar [ABI]-áskilinni lágmarksjöfnun á gerð gildisins sem `val` bendir á.
///
/// Sérhver tilvísun í gildi af gerðinni `T` verður að vera margfeldi þessarar tölu.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // ÖRYGGI: val er tilvísun, svo það er gildur hrá bendill
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Skilar [ABI] krafist lágmarksstillingar tegundar.
///
/// Sérhver tilvísun í gildi af gerðinni `T` verður að vera margfeldi þessarar tölu.
///
/// Þetta er jöfnunin sem notuð er fyrir uppbyggingarsvið.Það getur verið minna en æskileg röðun.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Skilar [ABI]-áskilinni lágmarksjöfnun á gerð gildisins sem `val` bendir á.
///
/// Sérhver tilvísun í gildi af gerðinni `T` verður að vera margfeldi þessarar tölu.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // ÖRYGGI: val er tilvísun, svo það er gildur hrá bendill
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Skilar [ABI]-áskilinni lágmarksjöfnun á gerð gildisins sem `val` bendir á.
///
/// Sérhver tilvísun í gildi af gerðinni `T` verður að vera margfeldi þessarar tölu.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Þessa aðgerð er aðeins óhætt að hringja í ef eftirfarandi skilyrði eru:
///
/// - Ef `T` er `Sized` er alltaf hægt að hringja í þessa aðgerð.
/// - Ef óstærð skottið á `T` er:
///     - [slice], þá verður lengd sneiðaskottins að vera upphafleg heiltala og stærð *allt gildi*(kraftmikill halalengd + forskeyti með stærðarstærð) verður að passa í `isize`.
///     - a [trait object], þá verður vtable hluti bendilsins að benda á gilt vtable fengið með óstærð þvingun og stærð *allt gildi*(dynamic halalengd + forskeyti með statískt stærð) verður að passa í `isize`.
///
///     - (unstable) [extern type], þá er alltaf hægt að hringja í þessa aðgerð, en getur panic eða á annan hátt skilað röngu gildi þar sem útlit ytri gerðar er ekki þekkt.
///     Þetta er sama hegðun og [`align_of_val`] varðandi tilvísun í gerð með utanaðkomandi skott.
///     - annars er íhaldssamt ekki leyft að kalla þessa aðgerð.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // ÖRYGGI: sá sem hringir verður að leggja fram giltan hráan bendil
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Skilar `true` ef að sleppa gildi af gerðinni `T` skiptir máli.
///
/// Þetta er eingöngu vísbending um hagræðingu og hægt er að útfæra hana varlega:
/// það getur skilað `true` fyrir gerðir sem ekki þarf raunverulega að sleppa.
/// Sem slík væri alltaf að skila `true` gildri útfærslu á þessari aðgerð.En ef þessi aðgerð skilar raunverulega `false`, þá geturðu verið viss um að sleppa `T` hefur enga aukaverkun.
///
/// Útfærslur á lágu stigi á hlutum eins og söfnum, sem þurfa að sleppa gögnum handvirkt, ættu að nota þessa aðgerð til að forðast að óþörfu að láta allt innihald þeirra falla þegar þeim er eytt.
///
/// Þetta gæti ekki skipt máli í útgáfubyggingum (þar sem auðvelt er að greina og útrýma lykkju sem hefur engar aukaverkanir), en er oft mikill sigur fyrir kembiforrit.
///
/// Athugaðu að [`drop_in_place`] framkvæmir nú þegar þessa athugun, þannig að ef hægt er að minnka vinnuálag þitt í einhvern lítinn fjölda af [`drop_in_place`] símtölum, þá er það óþarfi að nota þetta.
/// Sérstaklega athugaðu að þú getur [`drop_in_place`] sneið og það mun gera eina þörf_drop athugun á öllum gildum.
///
/// Tegundir eins og Vec því bara `drop_in_place(&mut self[..])` án þess að nota `needs_drop` sérstaklega.
/// Tegundir eins og [`HashMap`] verða aftur á móti að láta gildi falla í einu og ættu að nota þetta API.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Hér er dæmi um hvernig safn gæti nýtt `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // slepptu gögnunum
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Skilar gildi tegundar `T` sem er táknað með öllu núll bæti mynstrinu.
///
/// Þetta þýðir að til dæmis er bólstrun bætunnar í `(u8, u16)` ekki endilega núllstillt.
///
/// Það er engin trygging fyrir því að allt núll bæti mynstur tákni gild gildi af einhverri gerð `T`.
/// Til dæmis er allt núll bæti mynstrið ekki gild gildi fyrir viðmiðunargerðir (`&T`, `&mut T`) og virkar ábendingar.
/// Notkun `zeroed` á slíkum gerðum veldur strax [undefined behavior][ub] vegna þess að [the Rust compiler assumes][inv] að það er alltaf gild gildi í breytu sem hún telur frumstilla.
///
///
/// Þetta hefur sömu áhrif og [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Það er gagnlegt fyrir FFI stundum, en ætti almennt að forðast það.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Rétt notkun á þessari aðgerð: frumstilla heiltölu með núlli.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Rangt* notkun á þessari aðgerð: frumstilla tilvísun með núlli.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Óskilgreind hegðun!
/// let _y: fn() = unsafe { mem::zeroed() }; // Og aftur!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // ÖRYGGI: sá sem hringir þarf að ábyrgjast að gildi núlls gildi fyrir `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Hliðarbraut Rust er eðlilegt upphafsskoðun á minni með því að þykjast framleiða gildi af gerðinni `T`, en gera alls ekki neitt.
///
/// **Þessi aðgerð er úrelt.** Notaðu [`MaybeUninit<T>`] í staðinn.
///
/// Ástæðan fyrir úreldingu er sú að aðgerðin er í grunninn ekki hægt að nota rétt: hún hefur sömu áhrif og [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Eins og [`assume_init` documentation][assume_init] útskýrir, þá er [the Rust compiler assumes][inv] að gildin frumstillt rétt.
/// Sem afleiðing, kall t.d.
/// `mem::uninitialized::<bool>()` veldur strax óskilgreindri hegðun við að skila `bool` sem er ekki örugglega annað hvort `true` eða `false`.
/// Verra, sannarlega einræktað minni eins og það sem skilast hér er sérstakt að því leyti að þýðandinn veit að það hefur ekki fast gildi.
/// Þetta gerir það að óskilgreindri hegðun að hafa gögn sem ekki eru frumgreind í breytu jafnvel þó að sú breyta hafi heiltölu.
/// (Athugið að ekki er enn búið að ganga frá reglunum um óeiningarheiltölur, en þangað til þær eru, er ráðlegt að forðast þær.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // ÖRYGGI: sá sem hringir þarf að ábyrgjast að einingagildi gildi fyrir `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Skiptir um gildi á tveimur stökkbreytanlegum stöðum án þess að afnema neinn af öðrum.
///
/// * Ef þú vilt skipta með sjálfgefnu eða dummy gildi, sjá [`take`].
/// * Ef þú vilt skipta með framhjá gildi, skila gamla gildi, sjá [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // ÖRYGGI: hráir ábendingar hafa verið búnar til úr öruggum breytanlegum tilvísunum sem fullnægja öllum
    // takmarkanir á `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Skiptir um `dest` með sjálfgefnu gildi `T` og skilar fyrra `dest` gildi.
///
/// * Ef þú vilt skipta um gildi tveggja breytna, sjá [`swap`].
/// * Ef þú vilt skipta út fyrir framhjá gildi í stað sjálfgefins gildi, sjá [`replace`].
///
/// # Examples
///
/// Einfalt dæmi:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` gerir kleift að taka eignarhald á uppbyggingarsviði með því að skipta því út fyrir "empty" gildi.
/// Án `take` geturðu lent í málum sem þessum:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Athugaðu að `T` innleiðir ekki endilega [`Clone`], svo það getur ekki einu sinni klónað og endurstillt `self.buf`.
/// En `take` er hægt að nota til að aftengja upphaflegt gildi `self.buf` frá `self`, þannig að hægt sé að skila því:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Færir `src` í `dest` sem vísað er til og skilar fyrra `dest` gildi.
///
/// Hvorugt gildið fellur niður.
///
/// * Ef þú vilt skipta um gildi tveggja breytna, sjá [`swap`].
/// * Ef þú vilt skipta út fyrir sjálfgefið gildi, sjá [`take`].
///
/// # Examples
///
/// Einfalt dæmi:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` leyfir neyslu á uppbyggingarsviði með því að skipta út fyrir annað gildi.
/// Án `replace` geturðu lent í málum sem þessum:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Athugaðu að `T` innleiðir ekki endilega [`Clone`], þannig að við getum ekki einu sinni klónað `self.buf[i]` til að forðast flutninginn.
/// En `replace` er hægt að nota til að aftengja upphaflegt gildi við þá vísitölu frá `self`, þannig að hægt sé að skila því:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // ÖRYGGI: Við lesum úr `dest` en skrifum `src` beint inn í það á eftir,
    // þannig að gamla gildi er ekki endurtekið.
    // Ekkert er sleppt og ekkert hér getur panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Ráðstafar gildi.
///
/// Þetta gerir það með því að kalla útfærslu röksemdafærslunnar á [`Drop`][drop].
///
/// Þetta gerir í raun ekkert fyrir gerðir sem innleiða `Copy`, td
/// integers.
/// Slík gildi eru afrituð og _then_ flutt í aðgerðina, þannig að gildið er viðvarandi eftir þetta aðgerðarsímtal.
///
///
/// Þessi aðgerð er ekki töfrar;það er bókstaflega skilgreint sem
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Þar sem `_x` er fært í aðgerðina fellur hún sjálfkrafa niður áður en aðgerðin snýr aftur.
///
/// [drop]: Drop
///
/// # Examples
///
/// Grunn notkun:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // slepptu vector beinlínis
/// ```
///
/// Þar sem [`RefCell`] framfylgir lánareglum við keyrslutíma getur `drop` gefið út [`RefCell`] lán:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // afsala sér breytanlegu láninu á þessari rauf
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Heiltölur og aðrar gerðir sem innleiða [`Copy`] hafa ekki áhrif á `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // afrit af `x` er fært og sleppt
/// drop(y); // afrit af `y` er fært og sleppt
///
/// println!("x: {}, y: {}", x, y.0); // enn í boði
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Túlkar `src` þannig að hann sé af gerð `&U` og les svo `src` án þess að færa gildið sem er í gildi.
///
/// Þessi aðgerð mun óörugglega gera ráð fyrir að bendillinn `src` sé gildur fyrir [`size_of::<U>`][size_of] bæti með því að umbreyta `&T` til `&U` og lesa síðan `&U` (nema að þetta er gert á réttan hátt jafnvel þegar `&U` gerir strangari kröfur um aðlögun en `&T`).
/// Það mun einnig búa til ótryggt afrit af innihaldsgildinu í stað þess að flytja úr `src`.
///
/// Það er ekki villa um samantektartíma ef `T` og `U` hafa mismunandi stærðir, en það er mjög hvatt til að ákalla aðeins þessa aðgerð þar sem `T` og `U` hafa sömu stærð.Þessi aðgerð kveikir [undefined behavior][ub] ef `U` er stærri en `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Afritaðu gögnin úr 'foo_array' og meðhöndluðu þau sem 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Breyttu afrituðu gögnunum
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Innihald 'foo_array' ætti ekki að hafa breyst
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Ef U hefur meiri kröfur um jöfnun, gæti verið að src sé ekki rétt stillt.
    if align_of::<U>() > align_of::<T>() {
        // ÖRYGGI: `src` er tilvísun sem tryggt er að hún gildi fyrir lestur.
        // Sá sem hringir verður að ábyrgjast að raunveruleg umbreyting sé örugg.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // ÖRYGGI: `src` er tilvísun sem tryggt er að hún gildi fyrir lestur.
        // Við athuguðum bara hvort `src as *const U` væri rétt stillt.
        // Sá sem hringir verður að ábyrgjast að raunveruleg umbreyting sé örugg.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Ógegnsæ tegund sem táknar mismunun enum.
///
/// Sjá [`discriminant`] aðgerðina í þessari einingu til að fá frekari upplýsingar.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Þessar trait útfærslur er ekki hægt að fá vegna þess að við viljum engin mörk á T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Skilar gildi sem sérkennir einkennandi enum afbrigðið í `v`.
///
/// Ef `T` er ekki enum mun það að kalla á þessa aðgerð ekki leiða til óskilgreindrar hegðunar en skilagildið er ótilgreint.
///
///
/// # Stability
///
/// Sá sem mismunar afbrigði enum getur breyst ef skilgreining enum breytist.
/// Sá sem mismunar einhverju afbrigði mun ekki breytast á milli safnaða með sama þýðanda.
///
/// # Examples
///
/// Þetta er hægt að nota til að bera saman enums sem bera gögn, en að engu raunverulegum gögnum:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Skilar fjölda afbrigða í enum gerðinni `T`.
///
/// Ef `T` er ekki enum mun það að kalla á þessa aðgerð ekki leiða til óskilgreindrar hegðunar en skilagildið er ótilgreint.
/// Jafnvel, ef `T` er enum með fleiri afbrigði en `usize::MAX` er skilagildið ótilgreint.
/// Óbyggð afbrigði verða talin.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}