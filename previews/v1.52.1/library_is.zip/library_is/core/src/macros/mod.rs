#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Stækkar annað hvort í `$crate::panic::panic_2015` eða `$crate::panic::panic_2021` eftir útgáfu þess sem hringir.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Fullyrðir að tvö segð séu jöfn hvort öðru (nota [`PartialEq`]).
///
/// Á panic mun þetta fjölvi prenta gildi tjáninganna með kembiforritunum.
///
///
/// Eins og [`assert!`], hefur þetta fjölvi annað form, þar sem hægt er að útvega sérsniðin panic skilaboð.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Endurlánin hér að neðan eru af ásetningi.
                    // Án þeirra er upphafsrifa lánsins frumstillt jafnvel áður en gildin eru borin saman, sem leiðir til áberandi hægagangs.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Endurlánin hér að neðan eru af ásetningi.
                    // Án þeirra er upphafsrifa lánsins frumstillt jafnvel áður en gildin eru borin saman, sem leiðir til áberandi hægagangs.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Fullyrðir að tvö segð sé ekki jöfn hvort öðru (með [`PartialEq`]).
///
/// Á panic mun þetta fjölvi prenta gildi tjáninganna með kembiforritunum.
///
///
/// Eins og [`assert!`], hefur þetta fjölvi annað form, þar sem hægt er að útvega sérsniðin panic skilaboð.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Endurlánin hér að neðan eru af ásetningi.
                    // Án þeirra er upphafsrifa lánsins frumstillt jafnvel áður en gildin eru borin saman, sem leiðir til áberandi hægagangs.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Endurlánin hér að neðan eru af ásetningi.
                    // Án þeirra er upphafsrifa lánsins frumstillt jafnvel áður en gildin eru borin saman, sem leiðir til áberandi hægagangs.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Fullyrðir að boolísk tjáning sé `true` á keyrslutíma.
///
/// Þetta kallar á [`panic!`] fjölvi ef ekki er hægt að meta tilgreinda tjáningu til `true` á keyrslutíma.
///
/// Líkt og [`assert!`] hefur þessi fjölvi einnig aðra útgáfu, þar sem hægt er að útvega sérsniðin panic skilaboð.
///
/// # Uses
///
/// Ólíkt [`assert!`] eru `debug_assert!` yfirlýsingar aðeins virkar í óbjartsýnum byggingum sjálfgefið.
/// Bjartsýnd bygging mun ekki framkvæma `debug_assert!` yfirlýsingar nema `-C debug-assertions` sé send til þýðandans.
/// Þetta gerir `debug_assert!` gagnlegt fyrir ávísanir sem eru of dýrar til að vera til staðar í útgáfuuppbyggingu en getur verið gagnlegt við þróun.
/// Niðurstaðan af því að stækka `debug_assert!` er alltaf gerð athuguð.
///
/// Óhakað fullyrðing gerir forritinu í ósamræmi stöðu kleift að halda áfram að keyra, sem gæti haft óvæntar afleiðingar en innleiðir ekki óöryggi svo framarlega sem þetta gerist aðeins í öruggum kóða.
///
/// Afkomukostnaður fullyrðinga er þó ekki mælanlegur almennt.
/// Það er því aðeins hvatt til að skipta um [`assert!`] fyrir `debug_assert!` eftir ítarlega prófíl, og það sem meira er, aðeins í öruggum kóða!
///
/// # Examples
///
/// ```
/// // panic skilaboðin fyrir þessum fullyrðingum eru hert gildi tjáningarinnar sem gefin er.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // mjög einföld aðgerð
/// debug_assert!(some_expensive_computation());
///
/// // fullyrða með sérsniðnum skilaboðum
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Fullyrðir að tvö orðasambönd séu jöfn hvort öðru.
///
/// Á panic mun þetta fjölvi prenta gildi tjáninganna með kembiforritunum.
///
/// Ólíkt [`assert_eq!`] eru `debug_assert_eq!` yfirlýsingar aðeins virkar í óbjartsýnum byggingum sjálfgefið.
/// Bjartsýnd bygging mun ekki framkvæma `debug_assert_eq!` yfirlýsingar nema `-C debug-assertions` sé send til þýðandans.
/// Þetta gerir `debug_assert_eq!` gagnlegt fyrir ávísanir sem eru of dýrar til að vera til staðar í útgáfuuppbyggingu en getur verið gagnlegt við þróun.
///
/// Niðurstaðan af því að stækka `debug_assert_eq!` er alltaf gerð athuguð.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Fullyrðir að tvö orðasambönd séu ekki jöfn hvort öðru.
///
/// Á panic mun þetta fjölvi prenta gildi tjáninganna með kembiforritunum.
///
/// Ólíkt [`assert_ne!`] eru `debug_assert_ne!` yfirlýsingar aðeins virkar í óbjartsýnum byggingum sjálfgefið.
/// Bjartsýnd bygging mun ekki framkvæma `debug_assert_ne!` yfirlýsingar nema `-C debug-assertions` sé send til þýðandans.
/// Þetta gerir `debug_assert_ne!` gagnlegt fyrir ávísanir sem eru of dýrar til að vera til staðar í útgáfuuppbyggingu en getur verið gagnlegt við þróun.
///
/// Niðurstaðan af því að stækka `debug_assert_ne!` er alltaf gerð athuguð.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Skilar hvort gefin tjáning passi við eitthvað af gefnu mynstri.
///
/// Eins og í `match` tjáningu, þá er mögulega hægt að fylgja mynstrinu eftir `if` og verndartjáningu sem hefur aðgang að nöfnum sem bundin eru af mynstrinu.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Afpakkar niðurstöðu eða fjölgar villu hennar.
///
/// `?` símafyrirtækinu var bætt við í stað `try!` og ætti að nota í staðinn.
/// Ennfremur er `try` frátekið orð í Rust 2018, þannig að ef þú verður að nota það þarftu að nota [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` passar við gefna [`Result`].Ef um `Ok` afbrigðið er að ræða hefur tjáningin gildi vafins gildi.
///
/// Ef um `Err` afbrigðið er að ræða, sækir það innri villuna.`try!` framkvæmir síðan viðskipti með `From`.
/// Þetta veitir sjálfvirka umbreytingu á milli sérhæfðra villna og almennari.
/// Skekkjan sem af þessu verður er síðan strax skilað.
///
/// Vegna snemmkominnar er aðeins hægt að nota `try!` í aðgerðum sem skila [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Æskileg aðferð við að skila villum fljótt aftur
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Fyrri aðferðin til að skila villum fljótt aftur
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Þetta jafngildir:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Skrifar sniðin gögn í biðminni.
///
/// Þetta fjölvi samþykkir 'writer', sniðstreng og lista yfir rök.
/// Rök verða sniðin í samræmi við tilgreindan sniðstreng og niðurstaðan færð rithöfundinum.
/// Rithöfundurinn getur verið hvaða gildi sem er með `write_fmt` aðferð;almennt kemur þetta frá útfærslu á annað hvort [`fmt::Write`] eða [`io::Write`] trait.
/// Fjölvi skilar hvað sem `write_fmt` aðferðin skilar;venjulega [`fmt::Result`], eða [`io::Result`].
///
/// Sjá [`std::fmt`] til að fá frekari upplýsingar um setningafræði sniðstrengja.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Eining getur flutt inn bæði `std::fmt::Write` og `std::io::Write` og hringt í `write!` á hluti sem útfæra hvorugt, þar sem hlutir innleiða venjulega ekki báða.
///
/// Hins vegar verður einingin að flytja inn traits hæft svo nöfn þeirra stangist ekki á:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // notar fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // notar io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Þetta fjölvi er einnig hægt að nota í `no_std` uppsetningum.
/// Í uppsetningu `no_std` berðu ábyrgð á útfærsluatriðum íhlutanna.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Skrifaðu sniðin gögn í biðminni, með nýrri línu bætt við.
///
/// Á öllum pöllum er nýlínan LINE FEED persónan (`\n`/`U+000A`) einn og sér (engin viðbótar flutningur aftur (`\r`/`U+000D`).
///
/// Nánari upplýsingar eru í [`write!`].Upplýsingar um sniðskráningu strengja eru í [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Eining getur flutt inn bæði `std::fmt::Write` og `std::io::Write` og hringt í `write!` á hluti sem útfæra hvorugt, þar sem hlutir innleiða venjulega ekki báða.
/// Hins vegar verður einingin að flytja inn traits hæft svo nöfn þeirra stangist ekki á:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // notar fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // notar io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Sýnir ónáanlegan kóða.
///
/// Þetta er gagnlegt hvenær sem þýðandinn getur ekki ákvarðað að einhver kóði sé óaðgengilegur.Til dæmis:
///
/// * Passaðu handleggina við verndaraðstæður.
/// * Lykkjur sem ljúka á kraftmikinn hátt.
/// * Iterator sem á dynamískan hátt lýkur.
///
/// Ef ákvörðun um að kóðinn er óaðgengileg reynist röng lýkur forritinu strax með [`panic!`].
///
/// Óöruggur hliðstæða þessa fjölva er [`unreachable_unchecked`] aðgerð, sem mun valda óskilgreindri hegðun ef kóðanum er náð.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Þetta mun alltaf [`panic!`].
///
/// # Examples
///
/// Samsvörunararmar:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // safna saman villu ef athugasemd er gerð
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // ein lélegasta útfærsla x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Sýnir óútfærðan kóða með því að fara í læti með skilaboðin "not implemented".
///
/// Þetta gerir kóðanum þínum kleift að tékka, sem er gagnlegt ef þú ert að frumgera eða innleiða trait sem krefst margra aðferða sem þú ætlar ekki að nota allar.
///
/// Munurinn á `unimplemented!` og [`todo!`] er sá að á meðan `todo!` miðlar ásetningi um að innleiða virkni síðar og skilaboðin eru "not yet implemented", gerir `unimplemented!` engar slíkar kröfur.
/// Skilaboð þess eru "not implemented".
/// Einnig munu sumar IDE merkja " todo!` S.
///
/// # Panics
///
/// Þetta mun alltaf [`panic!`] vegna þess að `unimplemented!` er bara stuttmynd fyrir `panic!` með föstum, sérstökum skilaboðum.
///
/// Eins og `panic!` hefur þetta fjölvi annað form til að sýna sérsniðin gildi.
///
/// # Examples
///
/// Segjum að við séum með trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Við viljum innleiða `Foo` fyrir 'MyStruct', en af einhverjum ástæðum er aðeins skynsamlegt að innleiða `bar()` aðgerðina.
/// `baz()` og `qux()` verður samt að skilgreina við útfærslu okkar á `Foo`, en við getum notað `unimplemented!` í skilgreiningum þeirra til að leyfa kóðanum okkar að safna saman.
///
/// Við viljum samt láta forritið okkar hætta að keyra ef óútfærðu aðferðum er náð.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Það þýðir ekkert að `baz` og `MyStruct`, þannig að við höfum enga rökfræði hérna.
/////
///         // Þetta mun sýna "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Við höfum einhverja rökfræði hér, við getum bætt skilaboðum við óútfærð!til að sýna aðgerðaleysi okkar.
///         // Þetta mun sýna: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Gefur til kynna óunnið kóða.
///
/// Þetta getur verið gagnlegt ef þú ert að gera frumgerð og ert bara að leita að því að hafa kóðagerðina þína.
///
/// Munurinn á [`unimplemented!`] og `todo!` er sá að á meðan `todo!` miðlar ásetningi um að innleiða virkni síðar og skilaboðin eru "not yet implemented", gerir `unimplemented!` engar slíkar kröfur.
/// Skilaboð þess eru "not implemented".
/// Einnig munu sumar IDE merkja " todo!` S.
///
/// # Panics
///
/// Þetta mun alltaf [`panic!`].
///
/// # Examples
///
/// Hér er dæmi um einhvern kóða sem er í gangi.Við erum með trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Við viljum útfæra `Foo` á einni tegund okkar, en við viljum líka vinna aðeins á `bar()` fyrst.Til þess að kóðinn okkar taki saman þurfum við að útfæra `baz()`, svo við getum notað `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // framkvæmd fer hér
///     }
///
///     fn baz(&self) {
///         // við skulum ekki hafa áhyggjur af því að innleiða baz() í bili
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // við erum ekki einu sinni að nota baz(), svo þetta er fínt.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Skilgreiningar á innbyggðum fjölva.
///
/// Flestir makróeiginleikar (stöðugleiki, sýnileiki o.s.frv.) Eru teknir af frumkóðanum hér, að undanskildum útvíkkunaraðgerðum sem umbreyta makróinntaki í úttak, þær aðgerðir eru veittar af þýðandanum.
///
///
pub(crate) mod builtin {

    /// Veldur því að samantekt mistakast með gefnum villuboðum þegar hún verður vart.
    ///
    /// Þetta fjölvi ætti að nota þegar crate notar skilyrta tækni til að safna saman til að veita betri villuboð vegna rangra aðstæðna.
    ///
    /// Það er gerð þýðanda [`panic!`] á þýðanda stigi, en sendir frá sér villu við *samantekt* frekar en á *keyrslutíma*.
    ///
    /// # Examples
    ///
    /// Tvö slík dæmi eru fjölvi og `#[cfg]` umhverfi.
    ///
    /// Sendu frá betri þýðandavillu ef fjölvi er framhjá ógildum gildi.
    /// Án endanlegs branch myndi þýðandinn samt senda frá sér villu en skilaboðin um villuna myndu ekki nefna tvö gild gildi.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Sendu út villu í þýðanda ef einn af fjölda aðgerða er ekki í boði.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Býr til breytur fyrir aðra fjölbreytni strengjasniðanna.
    ///
    /// Þetta fjölvi virkar með því að taka snið bókstaflega sem inniheldur `{}` fyrir hvert viðbótar rifrildi framhjá.
    /// `format_args!` undirbýr viðbótarstærðirnar til að tryggja að hægt sé að túlka framleiðsluna sem streng og skilgreina rökin í eina tegund.
    /// Öll gildi sem framkvæma [`Display`] trait geta verið send til `format_args!`, eins og allir [`Debug`] framkvæmdir geta verið sendar til `{:?}` innan sniðstrengsins.
    ///
    ///
    /// Þetta fjölvi framleiðir gildi af gerðinni [`fmt::Arguments`].Þetta gildi er hægt að senda til fjölva innan [`std::fmt`] til að framkvæma gagnlegar tilvísanir.
    /// Öll önnur format fjölva ([``snið!`], [`write!`], [`println!`], osfrv.) Eru tengd í gegnum þennan.
    /// `format_args!`, ólíkt afleiddum fjölva þess, forðast úthlutun hrúga.
    ///
    /// Þú getur notað [`fmt::Arguments`] gildi sem `format_args!` skilar í `Debug` og `Display` samhengi eins og sést hér að neðan.
    /// Dæmið sýnir einnig að `Debug` og `Display` snið við það sama: interpolated sniðstrengurinn í `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Nánari upplýsingar eru í skjölunum í [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Sama og `format_args`, en bætir við nýrri línu að lokum.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Skoðar umhverfisbreytu á samsetningu tíma.
    ///
    /// Þetta fjölvi mun stækka til gildis nafngreinds umhverfisbreytu á samantektartímanum og skila tjáningu af gerðinni `&'static str`.
    ///
    ///
    /// Ef umhverfisbreytan er ekki skilgreind, þá verður gefin út safnvilla.
    /// Notaðu [`option_env!`] fjölvi í staðinn til að senda ekki frá þér samsetningarvillu.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Þú getur sérsniðið villuskilaboðin með því að senda streng sem seinni breytuna:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Ef umhverfisbreytan `documentation` er ekki skilgreind færðu eftirfarandi villu:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Valfrjálst skoðar umhverfisbreytu á samantektartíma.
    ///
    /// Ef nafngreinda umhverfisbreytan er til staðar á samantektartíma mun hún stækka í tjáningu af gerðinni `Option<&'static str>` þar sem gildi er `Some` af gildi umhverfisbreytunnar.
    /// Ef umhverfisbreytan er ekki til staðar stækkar þetta í `None`.
    /// Sjá [`Option<T>`][Option] til að fá frekari upplýsingar um þessa tegund.
    ///
    /// Aldrei er gefin út tímavilla þegar þessi fjölvi er notaður óháð því hvort umhverfisbreytan er til staðar eða ekki.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Sameinar auðkenni í eitt auðkenni.
    ///
    /// Þetta fjölvi tekur hvaða fjölda sem er aðskilin með kommum og sameinar þau öll í eitt og gefur þá tjáningu sem er nýtt auðkenni.
    /// Athugið að hreinlæti gerir það að verkum að þetta fjölvi getur ekki náð staðbundnum breytum.
    /// Einnig eru, almennt, fjölvi aðeins leyfðir í atriðum, fullyrðingu eða tjáningarstöðu.
    /// Það þýðir að þó að þú getir notað þetta fjölvi til að vísa í núverandi breytur, aðgerðir eða einingar osfrv, þá geturðu ekki skilgreint nýtt með því.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (nýtt, skemmtilegt, nafn) { }//ekki nothæft á þennan hátt!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Sameinar bókstafina í truflaða strengsneið.
    ///
    /// Þetta fjölvi tekur hvaða fjölda sem er aðskilin með bókstafstöfum, sem gefur tjáningu af gerðinni `&'static str` sem táknar alla bókstafina sem eru tengdir saman frá vinstri til hægri.
    ///
    ///
    /// Heildar-og fljótandi bókstafir eru strangaðir til að hægt sé að tengja þær saman.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Stækkar í línanúmerið sem það var kallað á.
    ///
    /// Með [`column!`] og [`file!`] veita þessi fjölvi upplýsingar um kembiforrit fyrir forritara um staðsetningu innan uppsprettunnar.
    ///
    /// Stækkaða tjáningin hefur gerð `u32` og er 1-byggð, þannig að fyrsta línan í hverri skrá metur til 1, sú síðari í 2 o.s.frv.
    /// Þetta er í samræmi við villuboð algengra þýðenda eða vinsælra ritstjóra.
    /// Skilaða línan er *ekki endilega* línan við `line!` ákallið sjálft, heldur fyrsta makrósöfnunin sem leiðir til ákalls `line!` makrósins.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Stækkar í dálknúmer sem það var kallað á.
    ///
    /// Með [`line!`] og [`file!`] veita þessi fjölvi upplýsingar um kembiforrit fyrir forritara um staðsetningu innan uppsprettunnar.
    ///
    /// Stækkaða tjáningin hefur gerð `u32` og er 1 byggð, þannig að fyrsti dálkurinn í hverri línu metur til 1, sá síðari í 2 o.s.frv.
    /// Þetta er í samræmi við villuboð algengra þýðenda eða vinsælra ritstjóra.
    /// Skilinn dálkur er *ekki endilega* línan í `column!` ákallinu sjálfu, heldur er fyrsta makrósöfnunin sem leiðir til ákalls `column!` makrósins.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Stækkar í skráarheitið sem það var kallað á.
    ///
    /// Með [`line!`] og [`column!`] veita þessi fjölvi upplýsingar um kembiforrit fyrir forritara um staðsetningu innan uppsprettunnar.
    ///
    /// Stækkaða tjáningin hefur gerð `&'static str` og skráin sem skilað er er ekki ákall `file!` makróins sjálfs, heldur fyrsta makrósóknin sem leiðir til ákalls `file!` makrósins.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Stífnar rök hennar.
    ///
    /// Þetta fjölvi gefur af sér tjáningu af gerðinni `&'static str` sem er strenging allra tokens sem sendar eru til þjóðhagsins.
    /// Engar takmarkanir eru settar á setningafræði makrósóknarinnar sjálfrar.
    ///
    /// Athugaðu að auknar niðurstöður inntaksins tokens geta breyst í future.Þú ættir að vera varkár ef þú treystir á framleiðsluna.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Inniheldur UTF-8 kóðaða skrá sem streng.
    ///
    /// Skráin er staðsett miðað við núverandi skrá (svipað og einingar finnast).
    /// Leiðin sem fylgir er túlkuð á vettvangssértækan hátt á samantektartíma.
    /// Svo, til dæmis, ákall með Windows slóð sem inniheldur bakslag `\` myndi ekki safna rétt saman á Unix.
    ///
    ///
    /// Þessi fjölvi skilar tjáningu af gerðinni `&'static str` sem er innihald skráarinnar.
    ///
    /// # Examples
    ///
    /// Geri ráð fyrir að það séu tvær skrár í sömu möppu með eftirfarandi innihaldi:
    ///
    /// Skrá 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Skrá 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Að setja saman 'main.rs' og keyra tvöfaldan myndast mun prenta "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Inniheldur skrá sem tilvísun í bæti fylki.
    ///
    /// Skráin er staðsett miðað við núverandi skrá (svipað og einingar finnast).
    /// Leiðin sem fylgir er túlkuð á vettvangssértækan hátt á samantektartíma.
    /// Svo, til dæmis, ákall með Windows slóð sem inniheldur bakslag `\` myndi ekki safna rétt saman á Unix.
    ///
    ///
    /// Þessi fjölvi skilar tjáningu af gerðinni `&'static [u8; N]` sem er innihald skráarinnar.
    ///
    /// # Examples
    ///
    /// Geri ráð fyrir að það séu tvær skrár í sömu möppu með eftirfarandi innihaldi:
    ///
    /// Skrá 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Skrá 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Að setja saman 'main.rs' og keyra tvöfaldan myndast mun prenta "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Stækkar í streng sem táknar núverandi einingaslóð.
    ///
    /// Núverandi mátaleið má líta á sem stigveldi eininga sem leiða aftur upp á crate root.
    /// Fyrsti hluti leiðarinnar sem skilað er er nafnið á crate sem nú er unnið saman.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Metur booleskar samsetningar stillingarfána á samantektartíma.
    ///
    /// Til viðbótar við `#[cfg]` eiginleikann er þessi fjölvi búinn til að leyfa boolean tjáningarmat á stillingarfánum.
    /// Þetta leiðir oft til minna afritaðra kóða.
    ///
    /// Setningafræðin sem gefin er þessu fjölvi er sama setningafræði og [`cfg`] eiginleiki.
    ///
    /// `cfg!`, ólíkt `#[cfg]`, fjarlægir ekki kóða og metur aðeins að satt eða ósatt.
    /// Til dæmis þurfa allar blokkir í if/else tjáningu að vera gildar þegar `cfg!` er notað fyrir ástandið, óháð því hvað `cfg!` er að meta.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Flokkar skrá sem tjáningu eða hlut eftir samhengi.
    ///
    /// Skráin er staðsett miðað við núverandi skrá (svipað og einingar finnast).Leiðin sem fylgir er túlkuð á vettvangssértækan hátt á samantektartíma.
    /// Svo, til dæmis, ákall með Windows slóð sem inniheldur bakslag `\` myndi ekki safna rétt saman á Unix.
    ///
    /// Að nota þennan fjölva er oft slæm hugmynd, því ef skráin er þáttuð sem tjáning, þá verður hún sett í umhverfis kóðann óhollustu.
    /// Þetta gæti leitt til þess að breytur eða aðgerðir séu frábrugðnar því sem skráin bjóst við ef það eru breytur eða aðgerðir sem bera sama heiti í núverandi skrá.
    ///
    ///
    /// # Examples
    ///
    /// Geri ráð fyrir að það séu tvær skrár í sömu möppu með eftirfarandi innihaldi:
    ///
    /// Skrá 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Skrá 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Að setja saman 'main.rs' og keyra tvöfaldan myndast mun prenta "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Fullyrðir að boolísk tjáning sé `true` á keyrslutíma.
    ///
    /// Þetta kallar á [`panic!`] fjölvi ef ekki er hægt að meta tilgreinda tjáningu til `true` á keyrslutíma.
    ///
    /// # Uses
    ///
    /// Fullyrðingar eru alltaf hakaðar í bæði kembiforrit og útgáfu og ekki er hægt að gera þær óvirkar.
    /// Sjá [`debug_assert!`] fyrir fullyrðingar sem eru ekki virkar í útgáfu smíðum sjálfgefið.
    ///
    /// Óöruggur kóði kann að reiða sig á `assert!` til að knýja fram innflytjendur í keyrslu sem, ef brotið er á þeim, gæti leitt til óöryggis.
    ///
    /// Önnur notkunartilfelli `assert!` fela í sér prófun og framfylgd innrásaraðila í öruggum kóða (þar sem brot getur ekki leitt til óöryggis).
    ///
    ///
    /// # Sérsniðin skilaboð
    ///
    /// Þetta fjölvi hefur annað form, þar sem hægt er að fá sérsniðin panic skilaboð með eða án rökstuðnings fyrir snið.
    /// Sjá [`std::fmt`] fyrir setningafræði fyrir þetta form.
    /// Tjáning sem notuð eru sem sniðrök verða aðeins metin ef fullyrðingin mistekst.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // panic skilaboðin fyrir þessum fullyrðingum eru hert gildi tjáningarinnar sem gefin er.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // mjög einföld aðgerð
    ///
    /// assert!(some_computation());
    ///
    /// // fullyrða með sérsniðnum skilaboðum
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Inline samkoma.
    ///
    /// Lestu [unstable book] til notkunar.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM-stíl inline samkoma.
    ///
    /// Lestu [unstable book] til notkunar.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Inline samkoma á einingu.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Prentanir fóru framhjá tokens í venjulegu framleiðslunni.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Kveikir eða slekkur á rekjaaðgerðum sem notaðar eru við kembiforrit annarra fjölva.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Eiginleiki fjölvi notað til að beita afleiða fjölva.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Eiginleiki fjölvi beitt á aðgerð til að breyta því í einingapróf.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Eiginleiki fjölvi beitt á aðgerð til að breyta því í viðmiðunarpróf.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Útfærsluatriði `#[test]` og `#[bench]` fjölva.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Eiginleiki fjölvi beitt á truflanir til að skrá það sem alheims úthlutunaraðila.
    ///
    /// Sjá einnig [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Heldur hlutnum sem það er notað á ef leiðin sem er liðin er aðgengileg og fjarlægir það á annan hátt.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Stækkar alla eiginleika `#[cfg]` og `#[cfg_attr]` í kóðabrotinu sem það er notað á.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Óstöðug útfærsluatriði `rustc` þýðandans, ekki nota.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Óstöðug útfærsluatriði `rustc` þýðandans, ekki nota.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}