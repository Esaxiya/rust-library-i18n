Panics núverandi þráður.

Þetta gerir forritinu kleift að ljúka strax og veita endurgjöf til þess sem hringir í forritið.
`panic!` ætti að nota þegar forrit nær óendurheimtanlegu ástandi.

Þessi fjölvi er fullkomin leið til að fullyrða um skilyrði í kóða og í prófum.
`panic!` er nátengt `unwrap` aðferðinni í bæði [`Option`][ounwrap] og [`Result`][runwrap] enums.
Báðar útfærslurnar kalla `panic!` þegar þær eru stilltar á [`None`] eða [`Err`] afbrigði.

Þegar `panic!()` er notað er hægt að tilgreina strengjaálag sem er smíðað með [`format!`] setningafræði.
Það álag er notað þegar panic er sprautað í Rust þráðinn sem kallar, og veldur því að þráðurinn að panic er allur.

Hegðun sjálfgefins `std` hook, þ.e.
kóðinn sem keyrir beint eftir að panic er kallaður fram, er að prenta skilaboðagagnið á `stderr` ásamt file/line/column upplýsingum `panic!()` símtalsins.

Þú getur hnekkt panic hook með [`std::panic::set_hook()`].
Inni í hook er hægt að nálgast panic sem `&dyn Any + Send`, sem inniheldur annað hvort `&str` eða `String` fyrir venjulegar `panic!()` ákall.
Til panic með gildi af annarri gerð er hægt að nota [`panic_any`].

[`Result`] enum er oft betri lausn til að jafna sig eftir villur en að nota `panic!` fjölvi.
Þetta fjölvi ætti að nota til að forðast að halda áfram að nota röng gildi, svo sem frá utanaðkomandi aðilum.
Ítarlegar upplýsingar um villumeðhöndlun er að finna í [book].

Sjá einnig fjölva [`compile_error!`] til að vekja villur við samsetningu.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Núverandi framkvæmd

Ef aðalþráðurinn panics mun hann ljúka öllum þráðunum þínum og ljúka forritinu með kóðanum `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





