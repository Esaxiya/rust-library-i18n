//! Næstum bein (en örlítið bjartsýni) Rust þýðing á mynd 3 af " Prentun fljótandi tölum hratt og örugglega` [^ 1].
//!
//!
//! [^1]: Burger, RG og Dybvig, RK 1996. Prentun fljótandi tölustafa
//!   fljótt og nákvæmlega.SIGPLAN Ekki.31, 5 (maí. 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// fyrirfram útreiknaðir fylkingar af `Digit`s fyrir 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// aðeins nothæf þegar `x < 16 * scale`;`scaleN` ætti að vera `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Stysta útfærsla ham fyrir Dragon.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // númerið `v` til að sníða er þekkt fyrir að vera:
    // - jafnt og `mant * 2^exp`;
    // - á undan `(mant - 2 *minus)* 2^exp` í upprunalegu gerðinni;og
    // - á eftir `(mant + 2 *plus)* 2^exp` í upprunalegu gerðinni.
    //
    // augljóslega geta `minus` og `plus` ekki verið núll.(fyrir óendanleika notum við gildi utan sviðs.) Einnig gerum við ráð fyrir að að minnsta kosti einn stafur sé myndaður, þ.e. `mant` getur ekki verið núll líka.
    //
    // þetta þýðir líka að hvaða tala sem er á milli `low = (mant - minus)*2^exp` og `high = (mant + plus)* 2^exp` mun kortleggja þetta nákvæmlega flotpunkt númer, með mörkum innifalin þegar upprunalega mantissa var jöfn (þ.e. `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` er `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // áætla `k_0` frá upprunalegum aðföngum sem fullnægja `10^(k_0-1) < high <= 10^(k_0+1)`.
    // þétt bundið `k` sem fullnægir `10^(k-1) < high <= 10^k` er reiknað síðar.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // umbreyta `{mant, plus, minus} * 2^exp` í brotform þannig að:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // deilið `mant` með `10^k`.nú `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // lagfæring þegar `mant + plus > scale` (eða `>=`).
    // við erum í raun ekki að breyta `scale`, þar sem við getum sleppt upphafs margfölduninni í staðinn.
    // nú `scale < mant + plus <= scale * 10` og við erum tilbúin til að búa til tölustafi.
    //
    // athugaðu að `d[0]`*getur* verið núll, þegar `scale - plus < mant < scale`.
    // í þessu tilfelli verður samantektarástand (`up` hér að neðan) hrundið af stað strax.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // jafngildir stigstærð `scale` um 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // skyndiminni `(2, 4, 8) * scale` fyrir tölu kynslóð.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // invariants, þar sem `d[0..n-1]` eru tölustafir sem búnir eru til þessa:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (þannig `mant / scale < 10`) þar sem `d[i..j]` er stuttmynd fyrir `d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // búa til einn tölustaf: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // þetta er einfölduð lýsing á breyttu Dragon reikniritinu.
        // mörgum millileiðbeiningum og tæmandi rökum er sleppt til hægðarauka.
        //
        // byrjaðu á breyttum innflytjendum, þar sem við höfum uppfært `n`:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // ráð fyrir að `d[0..n-1]` sé stysta framsetningin milli `low` og `high`, þ.e., `d[0..n-1]` uppfyllir bæði eftirfarandi en `d[0..n-2]` gerir það ekki:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijectivity: tölustafir hringlaga að `v`);og
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (síðasta tölustafurinn er réttur).
        //
        // annað skilyrðið einfaldast í `2 * mant <= scale`.
        // að leysa innflytjendur hvað varðar `mant`, `low` og `high` skilar einfaldari útgáfu af fyrsta skilyrðinu: `-plus < mant < minus`.
        // síðan `-plus < 0 <= mant` höfum við réttu stystu framsetninguna þegar `mant < minus` og `2 * mant <= scale`.
        // (sú fyrrnefnda verður `mant <= minus` þegar upprunalega mantissa er jöfn.)
        //
        // þegar seinni heldur ekki (`2 * mant> skala`), verðum við að auka síðasta tölustafinn.
        // þetta er nóg til að endurheimta það ástand: við vitum nú þegar að töluframleiðslan ábyrgist `0 <= v / 10^(k-n) - d[0..n-1] < 1`.
        // í þessu tilfelli verður fyrsta skilyrðið `-plus < mant - scale < minus`.
        // síðan `mant < scale` eftir kynslóðina höfum við `scale < mant + plus`.
        // (aftur, þetta verður `scale <= mant + plus` þegar upprunalega mantissa er jöfn.)
        //
        // í stuttu máli:
        // - stöðvaðu og hringdu `down` (haltu tölustöfum eins og það er) þegar `mant < minus` (eða `<=`).
        // - stöðvaðu og hringdu `up` (hækkaðu síðasta tölustafinn) þegar `scale < mant + plus` (eða `<=`).
        // - haltu áfram að búa til annað.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // við erum með stystu framsetninguna, haltu áfram að samantektinni

        // endurheimta invariants.
        // þetta gerir reikniritið alltaf að ljúka: `minus` og `plus` eykst alltaf, en `mant` er klippt modulo `scale` og `scale` er fastur.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // samantekt á sér stað þegar i) aðeins samantektarástandið var sett af stað, eða ii) bæði skilyrðin voru hrundið af stað og jafntefli kýs frekar að ná saman.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // ef hringmyndun breytir lengdinni ætti veldisvísirinn einnig að breytast.
        // það virðist sem þetta ástand sé mjög erfitt að fullnægja (mögulega ómögulegt), en við erum bara örugg og stöðug hér.
        //
        // ÖRYGGI: við frumstilltum það minni hér að ofan.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // ÖRYGGI: við frumstilltum það minni hér að ofan.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Nákvæm og fastur háttur framkvæmd fyrir Dragon.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // áætla `k_0` frá upprunalegum aðföngum sem fullnægja `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // deilið `mant` með `10^k`.nú `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // lagfæring þegar `mant + plus >= scale`, þar sem `plus / scale = 10^-buf.len() / 2`.
    // til þess að halda bignum í föstu stærð notum við í raun `mant + floor(plus) >= scale`.
    // við erum í raun ekki að breyta `scale`, þar sem við getum sleppt upphafs margfölduninni í staðinn.
    // aftur með stystu reikniritinu, `d[0]` getur verið núll en verður að lokum runnið upp.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // jafngildir stigstærð `scale` um 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // ef við erum að vinna með síðustu tölustafmörkunina, verðum við að stytta biðminnið fyrir raunverulega flutninginn til að koma í veg fyrir tvöfalda ával.
    //
    // athugaðu að við verðum að stækka biðminnið aftur þegar uppröðun gerist!
    let mut len = if k < limit {
        // úps, við getum ekki einu sinni framleitt *eina* tölu.
        // þetta er mögulegt þegar við segjum að við höfum eitthvað eins og 9.5 og það er námundað í 10.
        // við skilum tómri biðminni, að undanskildu síðara samantektartilfellinu sem á sér stað þegar `k == limit` og þarf að framleiða nákvæmlega einn tölustaf.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // skyndiminni `(2, 4, 8) * scale` fyrir tölu kynslóð.
        // (þetta getur verið dýrt, svo ekki reikna þá þegar biðminni er tómur.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // eftirfarandi tölustafir eru allir núll, við stoppum hér reynum *ekki* að framkvæma námundun!frekar, fylltu tölustafina sem eftir eru.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // ÖRYGGI: við frumstilltum það minni hér að ofan.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // námundun upp ef við stoppum í miðjum tölustöfum ef eftirfarandi tölustafir eru nákvæmlega 5000 ..., athugaðu fyrri tölustaf og reyndu að ná að jafna (þ.e. forðastu að rúlla upp þegar fyrri tölustafur er jafn).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // ÖRYGGI: `buf[len-1]` er frumstillt.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // ef hringmyndun breytir lengdinni ætti veldisvísirinn einnig að breytast.
        // en okkur hefur verið beðið um fastan fjölda stafa, svo ekki breyta biðminni ...
        // ÖRYGGI: við frumstilltum það minni hér að ofan.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... nema í staðinn hafi verið beðið um fasta nákvæmni.
            // við verðum líka að athuga að ef upprunalega biðminni var tómur er aðeins hægt að bæta við viðbótartölunni þegar `k == limit` (edge tilfelli).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // ÖRYGGI: við frumstilltum það minni hér að ofan.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}