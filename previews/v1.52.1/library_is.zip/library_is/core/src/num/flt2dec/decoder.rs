//! Afkóðar flotpunktagildi í einstaka hluta og villusvið.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Afkóðað óundirritað endanlegt gildi, þannig að:
///
/// - Upprunalega gildið jafngildir `mant * 2^exp`.
///
/// - Sérhver tala frá `(mant - minus)*2^exp` til `(mant + plus)* 2^exp` mun snúast upp í upphaflegt gildi.
/// Sviðið er aðeins innifalið þegar `inclusive` er `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Skalavöxnu mantissan.
    pub mant: u64,
    /// Neðra villusviðið.
    pub minus: u64,
    /// Efra villusviðið.
    pub plus: u64,
    /// Sameiginlegur veldisvísir í grunn 2.
    pub exp: i16,
    /// Sannar þegar villubilið er innifalið.
    ///
    /// Í IEEE 754 er þetta satt þegar upprunalega mantissa var jöfn.
    pub inclusive: bool,
}

/// Afkóðað óundirritað gildi.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Óendanleiki, annað hvort jákvæður eða neikvæður.
    Infinite,
    /// Núll, annað hvort jákvætt eða neikvætt.
    Zero,
    /// Endanlegar tölur með frekari afkóðuðum reitum.
    Finite(Decoded),
}

/// Flotpunktategund sem hægt er að 'afkóða' d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Lágmarks jákvætt eðlilegt gildi.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Skilar skilti (satt þegar það er neikvætt) og `FullDecoded` gildi frá gefnu númeri á flotpunkti.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // nágrannar: (Mant, 2, exp)-(Mant, exp)-(Mant + 2, exp)
            // Float::integer_decode varðveitir alltaf veldisvísinn, þannig að mantissa er minnkuð fyrir undirnáttúru.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // nágrannar: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // þar sem maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // nágrannar: (Mant, 1, exp)-(Mant, exp)-(Mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}