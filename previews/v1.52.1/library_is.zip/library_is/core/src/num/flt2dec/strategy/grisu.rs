//! Rust aðlögun á Grisu3 reikniritinu sem lýst er í " Prentun fljótandi tölur fljótt og örugglega með heiltölum` [^ 1].
//! Það notar um það bil 1KB af forútreiknaðri töflu og aftur á móti er það mjög fljótt fyrir flesta inntak.
//!
//! [^1]: Florian Loitsch.2010. Prentun fljótandi tölur fljótt og
//!   nákvæmlega með heiltölum.SIGPLAN Ekki.45, 6 (júní 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// sjá athugasemdirnar í `format_shortest_opt` fyrir rökstuðningnum.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Gefið `x > 0`, skilar `(k, 10^k)` þannig að `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Stysta útfærsla háttar fyrir Grisu.
///
/// Það skilar `None` þegar það myndi skila ónákvæmri framsetningu annars.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // við þurfum að minnsta kosti þrjá bita af frekari nákvæmni

    // byrjaðu á eðlilegum gildum með sameiginlega veldisvísinum
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // finndu hvaða `cached = 10^minusk` sem er þannig að `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // þar sem `plus` er eðlilegt þýðir þetta `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // miðað við val okkar á `ALPHA` og `GAMMA`, setur þetta `plus * cached` í `[4, 2^32)`.
    //
    // það er augljóslega æskilegt að hámarka `GAMMA - ALPHA`, svo að við þurfum ekki marga skyndimyndir af 10, en það eru nokkur atriði:
    //
    //
    // 1. við viljum halda `floor(plus * cached)` innan `u32` þar sem það þarf kostnaðarsama skiptingu.
    //    (þetta er í raun ekki hægt að komast hjá, afgangur er nauðsynlegur til að meta nákvæmni.)
    // 2.
    // afgangurinn af `floor(plus * cached)` margfaldast margfaldlega með 10 og það ætti ekki að flæða yfir það.
    //
    // sá fyrri gefur `64 + GAMMA <= 32` en sá annar `10 * 2^-ALPHA <= 2^64`;
    // -60 og -32 er hámarkssvið með þessari þvingun og V8 notar þær líka.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // kvarða fps.þetta gefur hámarksskekkjuna 1 ulp (sannað með setningu 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-raunverulegt svið mínus
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // fyrir ofan `minus`, `v` og `plus` eru *tölulegar* nálganir (villa <1 ulp).
    // þar sem við vitum ekki að skekkjan er jákvæð eða neikvæð notum við tvær nálganir á milli og hafa hámarksskekkjuna 2 ul.
    //
    // "unsafe region" er frjálslegt bil sem við myndum upphaflega.
    // "safe region" er íhaldssamt bil sem við samþykkjum aðeins.
    // við byrjum með rétta repr innan ótryggs svæðis og reynum að finna næst repr við `v` sem er einnig innan örugga svæðisins.
    // ef við getum það ekki gefumst við upp.
    //
    let plus1 = plus.f + 1;
    // látum plus0 = plus.f, 1;//aðeins til skýringar láta minus0 = minus.f + 1;//aðeins til skýringar
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // sameiginlegur veldisvísir

    // skiptu `plus1` í óaðskiljanlega og brotlega hluta.
    // Óaðskiljanlegur hluti er tryggður fyrir að passa í u32, þar sem skyndiminni afl tryggir `plus < 2^32` og eðlilegt `plus.f` er alltaf minna en `2^64 - 2^4` vegna nákvæmni kröfunnar.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // reikna stærsta `10^max_kappa` ekki meira en `plus1` (þar með `plus1 < 10^(max_kappa+1)`).
    // þetta er efri mörk `kappa` hér að neðan.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Setning 6.2: ef `k` er stærsta heiltala St.
    // `0 <= y mod 10^k <= y - x`,              þá er `V = floor(y / 10^k) * 10^k` í `[x, y]` og ein stysta framsetningin (með lágmarks fjölda marktækra tölustafa) á því bili.
    //
    //
    // finndu tölulengdina `kappa` á milli `(minus1, plus1)` samkvæmt setningu 6.2.
    // Setning 6.2 er hægt að samþykkja til að útiloka `x` með því að krefjast `y mod 10^k < y - x` í staðinn.
    // (td `x` =32000, `y` =32777; `kappa` =2 þar sem `y mod 10 ^ 3=777 <y, x=777`.) Reikniritið treystir á seinni sannprófunarfasa til að útiloka `y`.
    //
    let delta1 = plus1 - minus1;
    // láttu delta1int=(delta1>> e) sem stærð;//aðeins til skýringar
    let delta1frac = delta1 & ((1 << e) - 1);

    // framkvæma óaðskiljanlega hluti, meðan gætt er á nákvæmni í hverju skrefi.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // tölustafir sem á eftir að skila
    loop {
        // við höfum alltaf að minnsta kosti eina tölu til að koma til skila, eins og `plus1 >= 10^kappa` innflytjendur:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (það fylgir því að `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // deilið `remainder` með `10^kappa`.báðir eru minnkaðir með `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; við höfum fundið rétta `kappa`.
            let ten_kappa = (ten_kappa as u64) << e; // skalaðu 10 ^ kappa aftur til sameiginlega veldisvísisins
            return round_and_weed(
                // ÖRYGGI: við frumstilltum það minni hér að ofan.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // brjóta lykkjuna þegar við höfum gefið alla heildstafi.
        // nákvæmur fjöldi tölustafa er `max_kappa + 1` sem `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // endurheimta invariants
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // framkvæma brothluta, meðan verið er að athuga hvort nákvæmni sé í hverju skrefi.
    // að þessu sinni treystum við á endurtekna margföldun þar sem skipting missir nákvæmnina.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // næsta tölustafur ætti að vera marktækur þar sem við höfum prófað það áður en við brjótum út innflytjendur, þar sem `m = max_kappa + 1` (#tölustafir í heildarhlutanum):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // mun ekki flæða yfir, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // deilið `remainder` með `10^kappa`.
        // báðir eru stigstærðir með `2^e / 10^kappa`, svo hið síðarnefnda er óbeint hér.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // óbein deili
            return round_and_weed(
                // ÖRYGGI: við frumstilltum það minni hér að ofan.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // endurheimta invariants
        kappa -= 1;
        remainder = r;
    }

    // við höfum búið til alla töluverða tölustafi `plus1`, en ekki viss um hvort hann sé ákjósanlegur.
    // til dæmis, ef `minus1` er 3.14153 ... og `plus1` er 3.14158 ..., þá eru 5 mismunandi stystu framsetningar frá 3.14154 til 3.14158 en við höfum aðeins þá stærstu.
    // við verðum að fækka síðasta tölustafnum í röð og athuga hvort þetta sé ákjósanlegasta endurprófunin.
    // það eru í mesta lagi 9 frambjóðendur (..1 til ..9), svo þetta er nokkuð fljótt.("rounding" áfangi)
    //
    // aðgerðin athugar hvort þessi "optimal" repr sé í raun innan ulp sviðanna, og einnig er mögulegt að "second-to-optimal" repr geti í raun verið ákjósanlegur vegna skekkjunarvillunnar.
    // í báðum tilvikum skilar þetta `None`.
    // ("weeding" áfangi)
    //
    // öll rök hér eru stigstærð með algengu (en óbeinu) gildi `k`, þannig að:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (og einnig, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (og einnig, `threshold > plus1v` frá fyrri innflytjendum)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // framleiða tvær áætlanir til `v` (reyndar `plus1 - v`) innan 1.5 ulps.
        // framsetningin sem myndast ætti að vera næst fulltrúi beggja.
        //
        // hér er `plus1 - v` notað þar sem útreikningar eru gerðir með tilliti til `plus1` í því skyni að forðast overflow/underflow (þess vegna virðast skiptinöfnin).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // lækkaðu síðasta tölustafinn og stöðvaðu næst myndina `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // við vinnum með tölustafina `w(n)` sem er upphaflega jafn `plus1 - plus1 % 10^kappa`.eftir að hafa keyrt lykkjulíkamann `n` sinnum, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // við stillum `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (svona `afgangur= plus1w(0)`) til að einfalda ávísanir.
            // athugaðu að `plus1w(n)` eykst alltaf.
            //
            // við höfum þrjú skilyrði til að ljúka.einhver þeirra mun gera lykkjuna ófæran um að halda áfram, en við höfum þá að minnsta kosti eina rétta framsetningu sem vitað er að sé næst `v + 1 ulp` hvort eð er.
            // við munum tákna þá sem TC1 til TC3 til að gera stutt.
            //
            // TC1: `w(n) <= v + 1 ulp`, þ.e. þetta er síðasta repr sem getur verið næst.
            // þetta jafngildir `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // ásamt TC2 (sem athugar hvort `w(n+1)` is valid) kemur í veg fyrir mögulegt flæði við útreikning `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, þ.e. næsta repr endar örugglega ekki í `v`.
            // þetta jafngildir `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // vinstri hliðin getur flætt yfir, en við þekkjum `threshold > plus1v`, þannig að ef TC1 er ósatt, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` og við getum örugglega prófað hvort `threshold - plus1w(n) < 10^kappa` í staðinn.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, þ.e. næsta repr er
            // ekki nær `v + 1 ulp` en núverandi repr.
            // gefið `z(n) = plus1v_up - plus1w(n)`, þetta verður `abs(z(n)) <= abs(z(n+1))`.aftur miðað við að TC1 sé falskur, höfum við `z(n) > 0`.við höfum tvö mál til umhugsunar:
            //
            // - þegar `z(n+1) >= 0`: TC3 verður `z(n) <= z(n+1)`.
            // þar sem `plus1w(n)` eykst ætti `z(n)` að minnka og þetta er greinilega rangt.
            // - þegar `z(n+1) < 0`:
            //   - TC3a: forsenda `plus1v_up < plus1w(n) + 10^kappa`.miðað við að TC2 sé ósatt, `threshold >= plus1w(n) + 10^kappa` svo það geti ekki flætt yfir.
            //   - TC3b: TC3 verður `z(n) <= -z(n+1)`, þ.e. `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   hinn vanrækti TC1 gefur `plus1v_up > plus1w(n)`, þannig að hann getur ekki flætt yfir eða undirflæði þegar hann er sameinaður TC3a.
            //
            // þar af leiðandi ættum við að hætta þegar `TC1 || TC2 || (TC3a && TC3b)`.eftirfarandi er jafnt andhverfu þess, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // stysta repr getur ekki endað með `0`
                plus1w += ten_kappa;
            }
        }

        // athugaðu hvort þessi framsetning er einnig næst framsetning `v - 1 ulp`.
        //
        // þetta er einfaldlega það sama við lokunarskilyrði fyrir `v + 1 ulp`, í staðinn fyrir alla `plus1v_up` fyrir `plus1v_down`.
        // flæðigreining heldur jafn.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // nú höfum við næst framsetningu `v` milli `plus1` og `minus1`.
        // þetta er þó of frjálslegt, svo við höfnum öllum `w(n)` ekki á milli `plus0` og `minus0`, þ.e. `plus1 - plus1w(n) <= minus0` eða `plus1 - plus1w(n) >= plus0`.
        // við nýtum staðreyndirnar sem `threshold = plus1 - minus1` og `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Stysta útfærsla ham fyrir Grisu með Dragon fallback.
///
/// Þetta ætti að nota í flestum tilfellum.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // ÖRYGGI: Lánatékkarinn er ekki nógu klár til að leyfa okkur að nota `buf`
    // í seinni branch, svo við þvottum ævina hér.
    // En við notum bara `buf` aftur ef `format_shortest_opt` skilaði `None` svo þetta er í lagi.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Nákvæm og fastur háttur framkvæmd fyrir Grisu.
///
/// Það skilar `None` þegar það myndi skila ónákvæmri framsetningu annars.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // við þurfum að minnsta kosti þrjá bita af frekari nákvæmni
    assert!(!buf.is_empty());

    // staðla og stækka `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // skiptu `v` í óaðskiljanlega og brotlega hluta.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // bæði gamla `v` og nýja `v` (stigstærð með `10^-k`) er með villuna <1 ulp (Setning 5.1).
    // þar sem við vitum ekki að skekkjan er jákvæð eða neikvæð, notum við tvær nálganir á bilinu og hafa hámarksskekkjuna 2 súlur (sama í stysta tilfelli).
    //
    //
    // Markmiðið er að finna nákvæmlega ávalar tölustafir sem eru sameiginlegar bæði `v - 1 ulp` og `v + 1 ulp`, þannig að við séum með mesta sjálfstraust.
    // ef þetta er ekki mögulegt vitum við ekki hver er rétt framleiðsla fyrir `v`, svo við gefumst upp og fallum aftur.
    //
    // `err` er skilgreint sem `1 ulp * 2^e` hér (sama og ulpið í `vfrac`) og við munum mæla það hvenær sem `v` verður minnkað.
    //
    //
    //
    let mut err = 1;

    // reikna stærsta `10^max_kappa` ekki meira en `v` (þar með `v < 10^(max_kappa+1)`).
    // þetta er efri mörk `kappa` hér að neðan.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // ef við erum að vinna með síðustu tölustafmörkunina, verðum við að stytta biðminnið fyrir raunverulega flutninginn til að koma í veg fyrir tvöfalda ával.
    //
    // athugaðu að við verðum að stækka biðminnið aftur þegar uppröðun gerist!
    let len = if exp <= limit {
        // úps, við getum ekki einu sinni framleitt *eina* tölu.
        // þetta er mögulegt þegar við segjum að við höfum eitthvað eins og 9.5 og það er námundað í 10.
        //
        // í grundvallaratriðum getum við strax hringt í `possibly_round` með tóman biðminni, en stigstærð `max_ten_kappa << e` um 10 getur leitt til flæða.
        //
        // þannig erum við að vera slæleg hér og víkka villusviðið með stuðlinum 10.
        // þetta eykur falskt neikvætt hlutfall, en aðeins mjög,*mjög* lítillega;
        // það getur aðeins skipt máli áberandi þegar mantissa er stærri en 60 bitar.
        //
        // ÖRYGGI: `len=0`, svo skyldan til að frumstilla þetta minni er léttvæg.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // skila óaðskiljanlegum hlutum.
    // villan er að öllu leyti brot, svo við þurfum ekki að athuga hana í þessum hluta.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // tölustafir sem á eftir að skila
    loop {
        // við höfum alltaf að minnsta kosti einn tölustaf til að gera innflytjendur:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (það fylgir því að `remainder = vint % 10^(kappa+1)`)
        //
        //

        // deilið `remainder` með `10^kappa`.báðir eru minnkaðir með `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // er biðminni fullur?keyrðu hringpöntunina með afganginum.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // ÖRYGGI: við höfum frumstillt `len` mörg bæti.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // brjóta lykkjuna þegar við höfum gefið alla heildstafi.
        // nákvæmur fjöldi tölustafa er `max_kappa + 1` sem `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // endurheimta invariants
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // skila brotahlutum.
    //
    // í grundvallaratriðum getum við haldið áfram að síðasta tölustaf sem til er og athugað hvort nákvæmni sé.
    // því miður erum við að vinna með endanlegar stærðir, svo við þurfum einhver viðmiðun til að greina yfirfallið.
    // V8 notar `remainder > err`, sem verður rangt þegar fyrstu `i` marktæku tölustafir `v - 1 ulp` og `v` eru mismunandi.
    // þó þetta hafni of mörgum annars gildum inntakum.
    //
    // þar sem seinni áfanginn hefur rétta flæðisskynjun, notum við í staðinn þéttari viðmiðun:
    // við höldum áfram þar til `err` fer yfir `10^kappa / 2`, þannig að sviðið milli `v - 1 ulp` og `v + 1 ulp` inniheldur örugglega tvö eða fleiri ávalar myndir.
    //
    // þetta er það sama við fyrstu tvo samanburðina frá `possibly_round`, til viðmiðunar.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // invariants, þar sem `m = max_kappa + 1` (#tölustafir í óaðskiljanlegum hluta):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // mun ekki flæða yfir, `2^e * 10 < 2^64`
        err *= 10; // mun ekki flæða yfir, `err * 10 < 2^e * 5 < 2^64`

        // deilið `remainder` með `10^kappa`.
        // báðir eru stigstærðir með `2^e / 10^kappa`, svo hið síðarnefnda er óbeint hér.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // er biðminni fullur?keyrðu hringpöntunina með afganginum.
        if i == len {
            // ÖRYGGI: við höfum frumstillt `len` mörg bæti.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // endurheimta invariants
        remainder = r;
    }

    // frekari útreikningur er gagnslaus (`possibly_round` mistakast örugglega), svo við gefumst upp.
    return None;

    // við höfum búið til alla umbeðna tölustafi `v`, sem ætti einnig að vera sá sami og samsvarandi tölustafir `v - 1 ulp`.
    // nú athugum við hvort það sé einstök framsetning sem bæði `v - 1 ulp` og `v + 1 ulp` deila;þetta getur verið annaðhvort það sama við myndaða tölustafi, eða í samanteknu útgáfunni af þessum tölustöfum.
    //
    // ef sviðið inniheldur margar framsetningar af sömu lengd, getum við ekki verið viss og ættum að skila `None` í staðinn.
    //
    // öll rök hér eru stigstærð með algengu (en óbeinu) gildi `k`, þannig að:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // ÖRYGGI: fyrstu `len` bæti `buf` verður að vera frumstillt.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (til viðmiðunar gefur punktalínan til kynna nákvæm gildi fyrir mögulega framsetningu í gefnum fjölda tölustafa.)
        //
        //
        // villa er of stór að það eru að minnsta kosti þrjár mögulegar framsetningar á milli `v - 1 ulp` og `v + 1 ulp`.
        // við getum ekki ákveðið hver þeirra er rétt.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // í raun er 1/2 ulp nóg til að kynna tvær mögulegar framsetningar.
        // (mundu að við þurfum einstaka framsetningu fyrir bæði `v - 1 ulp` og `v + 1 ulp`.) Þetta flæðir ekki yfir, þar sem `ulp < ten_kappa` frá fyrstu athugun.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // ef `v + 1 ulp` er nær hringlaga framsetningunni (sem þegar er í `buf`), þá getum við örugglega snúið aftur.
        // athugaðu að `v - 1 ulp`*getur* verið minna en núverandi framsetning, en sem `1 ulp < 10^kappa / 2` er þetta ástand nóg:
        // fjarlægðin milli `v - 1 ulp` og núverandi framsetning getur ekki farið yfir `10^kappa / 2`.
        //
        // ástandið jafngildir `remainder + ulp < 10^kappa / 2`.
        // þar sem þetta getur auðveldlega flætt yfir, athugaðu fyrst hvort `remainder < 10^kappa / 2`.
        // við höfum þegar staðfest að `ulp < 10^kappa / 2`, svo framarlega sem `10^kappa` flæddi ekki yfir allt saman, þá er seinni athugunin í lagi.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // ÖRYGGI: kallinn okkar frumstillti það minni.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------afgangur------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // á hinn bóginn, ef `v - 1 ulp` er nær samantektinni, ættum við að fara saman og snúa aftur.
        // af sömu ástæðu þurfum við ekki að athuga `v + 1 ulp`.
        //
        // ástandið jafngildir `remainder - ulp >= 10^kappa / 2`.
        // aftur athugum við fyrst hvort `remainder > ulp` (athugaðu að þetta er ekki `remainder >= ulp`, þar sem `10^kappa` er aldrei núll).
        //
        // athugaðu líka að `remainder - ulp <= 10^kappa`, svo seinni ávísunin flæðir ekki yfir.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // ÖRYGGI: kallinn okkar hlýtur að hafa frumstillt það minni.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // bættu aðeins við viðbótar tölustaf þegar við höfum verið beðin um fasta nákvæmni.
                // við verðum líka að athuga að ef upprunalega biðminni var tómur er aðeins hægt að bæta við viðbótartölunni þegar `exp == limit` (edge tilfelli).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // ÖRYGGI: við og kallinn okkar frumstilltum það minni.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // annars erum við dæmd (þ.e. sum gildi milli `v - 1 ulp` og `v + 1 ulp` eru að ná saman og önnur eru að ná saman) og gefumst upp.
        //
        None
    }
}

/// Nákvæm og fastur háttur framkvæmd fyrir Grisu með Dragon fallback.
///
/// Þetta ætti að nota í flestum tilfellum.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // ÖRYGGI: Lánatékkarinn er ekki nógu klár til að leyfa okkur að nota `buf`
    // í seinni branch, svo við þvottum ævina hér.
    // En við notum bara `buf` aftur ef `format_exact_opt` skilaði `None` svo þetta er í lagi.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}