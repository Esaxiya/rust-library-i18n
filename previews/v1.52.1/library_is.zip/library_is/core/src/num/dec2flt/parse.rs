//! Staðfesting og niðurbrot aukastafs strengs formsins:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! Með öðrum orðum, venjuleg setningafræði flotpunkta, með tveimur undantekningum: Ekkert merki og engin meðhöndlun á "inf" og "NaN".Þetta er stjórnað af ökumannsaðgerðinni (super::dec2flt).
//!
//! Þó að viðurkenna gild aðföng er tiltölulega auðvelt, þá verður þessi eining einnig að hafna óteljandi ógildum afbrigðum, aldrei panic, og framkvæma fjölmargar athuganir sem aðrar einingar treysta á til að panic (eða flæða) ekki aftur á móti.
//!
//! Til að gera illt verra, allt sem gerist í einu framhjá inntakinu.
//! Svo vertu varkár þegar þú breytir einhverju og athugaðu með öðrum einingum.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// Athyglisverðir hlutar aukastafsstrengs.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// Tugastig veldisvísis, sem er örugglega með færri en 18 aukastafi.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// Athugar hvort innsláttarstrengurinn sé gild flotpunktur og ef svo er, finndu heildarhlutann, brothlutann og veldisfallið í honum.
/// Ræður ekki við skilti.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // Engir tölustafir fyrir 'e'
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // Við þurfum að minnsta kosti einn tölustaf fyrir eða eftir punktinn.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // Eftir drasl eftir brothluta
            }
        }
        _ => Invalid, // Slepandi rusl eftir fyrsta stafa streng
    }
}

/// Ristir aukastafstafi upp í fyrsta stafinn sem ekki er stafur.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// Útdráttur útrásar og villuleit.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // Eftir drasl eftir veldisvísis
    }
    if number.is_empty() {
        return Invalid; // Tóm veldisvísir
    }
    // Á þessum tímapunkti höfum við vissulega gildan tölustaf.Það getur verið of langt í `i64`, en ef það er svona mikið er inntakið vissulega núll eða óendanlegt.
    // Þar sem hvert núll í aukastafnum tölur aðlagar aðeins veldisvísitöluna með +/-1, við exp=10 ^ 18 þarf inntakið að vera 17 exabyte (!) núlla til að komast jafnvel fjarri því að vera endanlegt.
    //
    // Þetta er ekki nákvæmlega notkunarmál sem við þurfum að koma til móts við.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}