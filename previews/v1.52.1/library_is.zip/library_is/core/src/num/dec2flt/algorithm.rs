//! Hinar ýmsu reiknirit úr blaðinu.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Fjöldi merkisbita í Fp
const P: u32 = 64;

// Við geymum einfaldlega bestu nálgunina fyrir *alla* veldisvíkinga, svo hægt er að sleppa breytunni "h" og tilheyrandi aðstæðum.
// Þetta skiptir afköstum fyrir nokkur kílóbæti af plássi.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Í flestum arkitektúrum hafa flotpunktaaðgerðir beinlínis bitastærð, þess vegna er nákvæmni útreikningsins ákvörðuð á hverri aðgerð.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Á x86 er x87 FPU notað við flotaðgerðir ef SSE/SSE2 viðbætur eru ekki fáanlegar.
// x87 FPU vinnur með 80 bita nákvæmni sjálfgefið, sem þýðir að aðgerðir munu hringja í 80 bita sem veldur tvöföldu námundun þegar gildi eru að lokum táknað sem
//
// 32/64 hluti flotgildi.Til að vinna bug á þessu er hægt að stilla FPU stjórnunarorð þannig að útreikningarnir séu gerðir í þeirri nákvæmni sem óskað er eftir.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Uppbygging sem notuð er til að varðveita upphaflegt gildi FPU stjórnunarorðsins, svo að hægt sé að endurheimta það þegar uppbyggingin fellur niður.
    ///
    ///
    /// x87 FPU er 16 bita skrá sem hefur sviðin sem hér segir:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Skjalagerðin fyrir alla reitina er að finna í handbók IA-32 fyrir hugbúnaðargerð verktaka fyrir arkitektúr (1. bindi).
    ///
    /// Eini reiturinn sem skiptir máli fyrir eftirfarandi kóða er PC, Precision Control.
    /// Þessi reitur ákvarðar nákvæmni aðgerða sem FPU framkvæmir.
    /// Það er hægt að stilla það á:
    ///  - 0b00, ein nákvæmni þ.e. 32 bita
    ///  - 0b10, tvöföld nákvæmni þ.e 64 bita
    ///  - 0b11, tvöföld aukin nákvæmni þ.e. 80 bitar (sjálfgefið ástand) Gildið 0b01 er frátekið og ætti ekki að nota.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // ÖRYGGI: `fldcw` leiðbeiningin hefur verið endurskoðuð til að geta unnið rétt með
        // hvaða `u16` sem er
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Við erum að nota ATT setningafræði til að styðja LLVM 8 og LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Stillir nákvæmnisreit FPU á `T` og skilar `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Reiknið gildi fyrir Precision Control svæðið sem er viðeigandi fyrir `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 bitar
            8 => 0x0200, // 64 bitar
            _ => 0x0300, // sjálfgefið, 80 bitar
        };

        // Fáðu upphaflegt gildi stjórnunarorðsins til að endurheimta það seinna, þegar `FPUControlWord` uppbyggingin er látin falla ÖRYGGI: `fnstcw` leiðbeiningin hefur verið endurskoðuð til að geta unnið rétt með hvaða `u16` sem er
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Við erum að nota ATT setningafræði til að styðja LLVM 8 og LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Stilltu stjórnunarorðið á viðeigandi nákvæmni.
        // Þessu er náð með því að fela gömlu nákvæmnina (bit 8 og 9, 0x300) og skipta henni út fyrir nákvæmnisfánann sem reiknaður er hér að ofan.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Hraðbraut Bellerophon með því að nota heiltölur og flot í stærðum í vél.
///
/// Þetta er dregið út í aðskilda aðgerð svo að hægt sé að reyna áður en þú býrð til bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Við berum saman nákvæm gildi við MAX_SIG undir lokin, þetta er bara fljótleg, ódýr höfnun (og frelsar einnig restina af kóðanum frá því að hafa áhyggjur af undirstreymi).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Hraðbrautin er mjög háð því að reikningurinn er ávalinn að réttum fjölda bita án nokkurrar milliverðlu.
    // Á x86 (án SSE eða SSE2) þarf þetta að breyta nákvæmni x87 FPU stafla þannig að hann beinist beint að 64/32 hluti.
    // `set_precision` virknin sér um að stilla nákvæmni á arkitektúr sem þarfnast stillingar með því að breyta alþjóðlegu ástandi (eins og stjórnunarorð x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Ekki er hægt að brjóta málið e <0 yfir í hinn branch.
    // Neikvæð vald hafa í för með sér endurtekinn brothluta í tvöföldun, sem er ávöl, sem veldur raunverulegum (og stundum alveg marktækum!) Villum í lokaniðurstöðunni.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Reiknirit Bellerophon er léttvægur kóði réttlætanlegur með ómerkilegri tölugreiningu.
///
/// Það hringir " f` í flot með 64 bita merkingu og margfaldar það með bestu nálgun `10^e` (á sama flotpunkta sniði).Þetta er oft nóg til að ná réttri niðurstöðu.
/// Hins vegar, þegar niðurstaðan er nálægt hálfri milli tveggja aðliggjandi (ordinary) fljóta, þá þýðir samsetta villan frá því að margfalda tvö nálgun að niðurstaðan getur verið slökkt með nokkrum bitum.
/// Þegar þetta gerist lagar endurtekna reiknirit R hlutina.
///
/// Handbylgjandi "close to halfway" er nákvæmur með tölugreiningunni í blaðinu.
/// Með orðum Clinger:
///
/// > Slop, gefið upp í einingum með minnst marktækum bita, er innifalið bundið fyrir villuna
/// > safnað við flotpunktaútreikning á nálgun við f * 10 ^ e.(Slop er
/// > ekki bundinn fyrir hina sönnu villu, en takmarkar muninn á nálguninni z og
/// > besta mögulega nálgunin sem notar p bita af merkingu.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Mál abs(e) <log5(2^N) eru í fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Er brekkan nógu stór til að gera gæfumun þegar hringið er í n bita?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Ítrekunarreiknirit sem bætir nálgun á flotpunkti `f * 10^e`.
///
/// Hver endurtekning fær eina einingu í síðasta sæti nær, sem auðvitað tekur hræðilega langan tíma að renna saman ef `z0` er jafnvel vægt slökkt.
/// Sem betur fer, þegar það er notað sem bakslag fyrir Bellerophon, er byrjunaráætlunin í mesta lagi slökkt á einum ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Finndu jákvæðar heiltölur `x`, `y` þannig að `x / y` er nákvæmlega `(f *10^e) / (m* 2^k)`.
        // Þetta forðast ekki aðeins að takast á við tákn `e` og `k`, heldur útrýmum við einnig krafti tveggja sem eru sameiginlegir við `10^e` og `2^k` til að gera tölurnar minni.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Þetta er skrifað svolítið óþægilega vegna þess að bignum okkar styðja ekki neikvæðar tölur, þannig að við notum alger gildi + merkiupplýsingar.
        // Margföldunin með m_digits getur ekki flætt yfir.
        // Ef `x` eða `y` eru nógu stór til að við þurfum að hafa áhyggjur af flæði, þá eru þau líka nógu stór til að `make_ratio` hefur minnkað brotið með stuðlinum 2 ^ 64 eða meira.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Þarft ekki x lengur, sparaðu clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Vantar þig samt, gerðu afrit.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Að gefnu `x = f` og `y = m` þar sem `f` tákna aukatölustafatölur eins og venjulega og `m` er merking nálgunar á flotpunkti, gerðu hlutfallið `x / y` jafnt og `(f *10^e) / (m* 2^k)`, mögulega lækkað með krafti tveggja hafa báðir sameiginlegt.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, nema að við drögum úr brotinu um einhvern kraft af tveimur.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Þetta getur ekki flætt yfir vegna þess að það þarf jákvætt `e` og neikvætt `k`, sem getur aðeins gerst fyrir gildi mjög nálægt 1, sem þýðir að `e` og `k` verða tiltölulega pínulítil.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Þetta getur heldur ekki flætt yfir, sjá hér að ofan.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), aftur minnkandi með sameiginlegum krafti tveggja.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Hugmyndafræðilega er reiknirit M einfaldasta leiðin til að umbreyta aukastaf í flot.
///
/// Við myndum hlutfallið sem er jafnt `f * 10^e` og hendum síðan krafti tveggja þar til það gefur gildan flotvigt.
/// Tvíundar veldisvísirinn `k` er sá fjöldi skipta sem við margfölduðum teljara eða nefnara með tveimur, þ.e. á öllum tímum er `f *10^e` jafn `(u / v)* 2^k`.
/// Þegar við höfum fundið út mikilvægi, þá þurfum við aðeins að hringja með því að skoða afganginn af skiptingunni, sem er gert í hjálparstarfsemi neðar.
///
///
/// Þessi reiknirit er ofur hæg, jafnvel með hagræðingunni sem lýst er í `quick_start()`.
/// En það er einfaldast af reikniritunum að laga sig að niðurfalli, undirflæði og óeðlilegum árangri.
/// Þessi framkvæmd tekur við þegar Bellerophon og Algorithm R eru ofviða.
/// Auðvelt er að greina undirrennsli og flæði: Hlutfallið er samt ekki innan sviðs, en minimum/maximum veldisvísinum hefur verið náð.
/// Ef um flæði er að ræða, skilum við einfaldlega óendanleikanum.
///
/// Meðhöndlun undirstreymis og undirnáttúru er erfiðara.
/// Eitt stórt vandamál er að, með lágmarks veldisvísitölu, gæti hlutfallið samt verið of stórt fyrir þýðingu.
/// Sjá underflow() fyrir frekari upplýsingar.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME möguleg hagræðing: alhæfa big_to_fp svo að við getum gert samsvarandi fp_to_float(big_to_fp(u)) hér, aðeins án tvöfaldrar umferðar.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Við verðum að stoppa við lágmarks veldisvísitölu, ef við bíðum þangað til `k < T::MIN_EXP_INT`, þá værum við með stuðulinn tvö.
            // Því miður þýðir þetta að við verðum að sértaka venjulegar tölur með lágmarks veldisvísitölu.
            // FIXME finnur glæsilegri mótun en keyrðu `tiny-pow10` prófið til að ganga úr skugga um að það sé í raun rétt!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Skipt yfir flestar endurritunar M endurtekningar með því að athuga bitalengdina.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Bitalengd er mat á grunn tveimur lógaritma og log(u / v) = log(u), log(v).
    // Matið er í mesta lagi slökkt á 1, en alltaf vanmat, þannig að villan á log(u) og log(v) er af sama merki og fellur niður (ef bæði eru stór).
    // Þess vegna er villan fyrir log(u / v) í mesta lagi líka.
    // Markhlutfallið er hlutfall þar sem u/v er innan marka.Þannig er lúkningarástand okkar að log2(u / v) er mikilvægi bitinn, plus/minus einn.
    // FIXME Að horfa á seinni hlutann gæti bætt áætlunina og forðast fleiri skiptingar.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Undirflæði eða óeðlilegt.Láttu það vera aðaltilganginum.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Yfirfall.Láttu það liggja að aðalhlutverkinu.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Hlutfall er ekki merking innan sviðs með lágmarks veldisvísitölu, þannig að við þurfum að rúlla umfram bitum og stilla veldisvísinn í samræmi við það.
    // Raunverulegt gildi lítur nú svona út:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(fulltrúi rem)
    //
    // Þess vegna, þegar ávalar bitar eru!= 0.5 ULP, ákveða þeir rúnunina á eigin spýtur.
    // Þegar þau eru jöfn og afgangurinn er ekki núll, þarf samt að ná gildi upp.
    // Aðeins þegar ávalar bitar eru 1/2 og afgangurinn er núll, þá erum við með hálf-jafnt ástand.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Venjulegt kringlótt til jafnt, óskýrt með því að þurfa að rúnta út frá afganginum eftir skiptingu.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}