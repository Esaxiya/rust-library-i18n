//! Gagnsemi virka fyrir bignums sem gera ekki of mikið vit í að breyta í aðferðir.

// FIXME Nafn þessarar einingar er svolítið óheppilegt, þar sem aðrar einingar flytja einnig inn `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Prófaðu hvort að stytta alla bita sem eru minna marktækir en `ones_place` kynnir hlutfallslega villu minni, jafn eða meiri en 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Ef allir bitar sem eftir eru eru núll er það= 0.5 ULP, annars> 0.5 Ef það eru ekki fleiri bitar (half_bit==0), þá skilar hér að neðan rétt jafnt.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Breytir ASCII streng sem inniheldur aðeins aukastaf tölustafir í `u64`.
///
/// Framkvæmir ekki eftirlit með yfirfalli eða ógildum stöfum, þannig að ef sá sem hringir er ekki varkár er niðurstaðan svikin og getur panic (þó það verði ekki `unsafe`).
/// Að auki eru tómar strengir meðhöndlaðir sem núll.
/// Þessi aðgerð er til vegna
///
/// 1. að nota `FromStr` á `&[u8]` krefst `from_utf8_unchecked`, sem er slæmt, og
/// 2. að púsla saman niðurstöðum `integral.parse()` og `fractional.parse()` er flóknara en öll þessi aðgerð.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Breytir streng ASCII tölustafa í bignum.
///
/// Eins og `from_str_unchecked`, treystir þessi aðgerð þáttarann til að útrýma tölustöfum sem ekki eru tölustafir.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Afpakkar bignum í 64 bita heiltölu.Panics ef fjöldinn er of stór.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Útdráttur úrval af bitum.

/// Vísitala 0 er minnsta marktæki bitinn og sviðið er hálf opið eins og venjulega.
/// Panics ef beðið er um að draga út fleiri bita en passa inn í skilgerðina.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}