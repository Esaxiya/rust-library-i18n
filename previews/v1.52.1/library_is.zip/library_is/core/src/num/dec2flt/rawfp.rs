//! Svolítið að fikta í jákvæðum IEEE 754 flotum.Neikvæðar tölur eru ekki og þarf ekki að meðhöndla þær.
//! Venjulegar tölur fyrir fljótandi punkta eru með kanóníska framsetningu sem (frac, exp) þannig að gildið er 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)) þar sem N er fjöldi bita.
//!
//! Undirnáttúru eru aðeins öðruvísi og skrýtnir, en sama meginreglan á við.
//!
//! Hér táknum við þau hins vegar sem (sig, k) með f jákvæð, þannig að gildi er f *
//! 2 <sup>e</sup> .Auk þess að gera "hidden bit" skýran, þá breytir þetta veldisvísinum með svokallaðri mantissuvakt.
//!
//! Að öðru leyti, venjulega eru flot skrifuð sem (1) en hér eru þau skrifuð sem (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Við köllum (1)**brothlutfallið** og (2)**heildartengingu**.
//!
//! Margar aðgerðir í þessari einingu sinna aðeins venjulegum tölum.Dec2flt venjurnar fara varlega í gegnum alheims-rétta leið (Reiknirit M) fyrir mjög litlar og mjög stórar tölur.
//! Þessi reiknirit þarf aðeins next_float() sem sér um undirnáttúru og núll.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// Hjálparmaður trait til að forðast að tvöfalda í grundvallaratriðum allan umbreytingarkóða fyrir `f32` og `f64`.
///
/// Sjá umsögn foreldraeiningarinnar um af hverju þetta er nauðsynlegt.
///
/// Ætti **aldrei** að vera útfærð fyrir aðrar gerðir eða vera notuð utan dec2flt einingarinnar.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Tegund notuð af `to_bits` og `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Framkvæmir hráa umbreytingu í heiltölu.
    fn to_bits(self) -> Self::Bits;

    /// Framkvæmir hráa umbreytingu frá heiltölu.
    fn from_bits(v: Self::Bits) -> Self;

    /// Skilar flokknum sem þessi tala fellur í.
    fn classify(self) -> FpCategory;

    /// Skilar mantissunni, veldisvísinum og undirritar sem heiltölur.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Afkóðar flotið.
    fn unpack(self) -> Unpacked;

    /// Steypir úr lítilli heiltölu sem hægt er að tákna nákvæmlega.
    /// Panic ef ekki er hægt að tákna heiltöluna, hitt kóðinn í þessari einingu sér til þess að láta það aldrei gerast.
    fn from_int(x: u64) -> Self;

    /// Fær gildi 10 <sup>e</sup> úr forreiknuðum töflu.
    /// Panics fyrir `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Hvað nafnið segir.
    /// Það er auðveldara að harða kóða en að juggla innra með sér og vona að LLVM stöðugur brjóti það saman.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // Íhaldssamt bundið við aukastaf tölustafa aðföngs sem geta ekki framleitt yfirfall eða núll eða
    /// undirnáttúru.Sennilega aukastafsvísir hámarksgildis, þar af nafnið.
    const MAX_NORMAL_DIGITS: usize;

    /// Þegar merkasta aukastafstafurinn hefur meira en þetta staðargildi er fjöldinn vissulega ávöl til óendanleika.
    ///
    const INF_CUTOFF: i64;

    /// Þegar merkasta aukastafurinn hefur minna en þetta staðargildi er fjöldinn vissulega ávöl í núll.
    ///
    const ZERO_CUTOFF: i64;

    /// Fjöldi bita í veldisvísinum.
    const EXP_BITS: u8;

    /// Fjöldi bita í merkingunni,*þar á meðal* falinn hluti.
    const SIG_BITS: u8;

    /// Fjöldi bita í merkingunni,*að frátöldum* falna bitanum.
    const EXPLICIT_SIG_BITS: u8;

    /// Hámarks löglegur veldisvísir í brotafulltrúa.
    const MAX_EXP: i16;

    /// Lágmarks löglegur veldisvísir í hlutafulltrúa, að undanskildum undirnáttúru.
    const MIN_EXP: i16;

    /// `MAX_EXP` fyrir óaðskiljanlega framsetningu, þ.e. með breytingunni sem beitt er.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` kóðuð (þ.e. með offset hlutdrægni)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` fyrir óaðskiljanlega framsetningu, þ.e. með breytingunni sem beitt er.
    const MIN_EXP_INT: i16;

    /// Hámarks eðlileg merking í heildstæðri framsetningu.
    const MAX_SIG: u64;

    /// Lágmarks eðlileg merking í heildstæðri framsetningu.
    const MIN_SIG: u64;
}

// Aðallega lausn fyrir #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Skilar mantissunni, veldisvísinum og undirritar sem heiltölur.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Víðátta hlutdrægni + mantissa vakt
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe er óvíst hvort `as` snúist rétt á öllum pöllum.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Skilar mantissunni, veldisvísinum og undirritar sem heiltölur.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Víðátta hlutdrægni + mantissa vakt
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe er óvíst hvort `as` snúist rétt á öllum pöllum.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Breytir `Fp` í næstu vélflotategund.
/// Ræður ekki við óeðlilegar niðurstöður.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f er 64 bita, svo xe hefur mantissa vaktina 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Hringdu 64 bita merkið upp í T::SIG_BITS bita með hálf-jafnt.
/// Ræður ekki við veldisflæði.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Stilla mantissa vakt
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Andstæða `RawFloat::unpack()` fyrir eðlilegar tölur.
/// Panics ef merkingin eða veldisvísirinn gildir ekki fyrir eðlilegar tölur.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Fjarlægðu falinn hluti
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Aðlagaðu veldisvísirinn fyrir hlutdrægni veldisvísis og mantissuskipta
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Láttu skiltabitann vera 0 ("+"), tölurnar okkar eru allar jákvæðar
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Byggja upp óeðlilegt.Mantissa 0 er leyfð og smíðar núll.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Dulkóðuð veldisvísir er 0, táknbitinn er 0, svo við verðum bara að túlka bitana upp á nýtt.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Áætluð bignum með Fp.Hringir innan 0.5 ULP með hálf-jafnt.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Við skera burt alla bita fyrir vísitöluna `start`, þ.e.a.s., við hægrihreyfumst með `start`, þannig að þetta er líka veldisvísirinn sem við þurfum.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Round (half-to-even) eftir styttum bitum.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Finnur stærsta flotpunkt númer stranglega minni en rökin.
/// Ræður ekki við undirnáttúru, núll eða veldisflæði.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Finndu minnstu númerið á floti strangar en rökin.
// Þessi aðgerð er mettandi, þ.e. next_float(inf) ==inf.
// Ólíkt flestum kóða í þessari einingu, þá höndlar þessi aðgerð núll, undirnáttúru og óendanleika.
// Hins vegar, eins og allir aðrir kóðar hér, fjallar það ekki um NaN og neikvæðar tölur.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Þetta virðist of gott til að vera satt, en það virkar.
        // 0.0 er kóðað sem al-núll orð.Undirnætur eru 0x000m ... m þar sem m er mantissa.
        // Sérstaklega er minnsta undirnáttúru 0x0 ... 01 og sú stærsta 0x000F ... F.
        // Minnsta venjulega talan er 0x0010 ... 0, þannig að þetta hornhulstur virkar líka.
        // Ef aukningin flæðir yfir mantissuna hækkar burðarbitinn veldisvísitöluna eins og við viljum og mantissubitarnir verða núll.
        // Vegna falinn bitamótsins er þetta líka nákvæmlega það sem við viljum!
        // Að lokum, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}