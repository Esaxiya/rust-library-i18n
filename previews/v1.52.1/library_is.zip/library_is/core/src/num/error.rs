//! Villutegundir fyrir umbreytingu í heildgerðir.

use crate::convert::Infallible;
use crate::fmt;

/// Villutegundin skilaði sér þegar merkt heildargerð umbreyting mistókst.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Passaðu frekar en að neyða til að ganga úr skugga um að kóði eins og `From<Infallible> for TryFromIntError` hér að ofan muni halda áfram að virka þegar `Infallible` verður alias við `!`.
        //
        //
        match never {}
    }
}

/// Villa sem hægt er að skila við þáttun á heiltölu.
///
/// Þessi villa er notuð sem villutegund fyrir `from_str_radix()` aðgerðir á frumstæðum heiltölutegundum, svo sem [`i8::from_str_radix`].
///
/// # Hugsanlegar orsakir
///
/// Meðal annarra orsaka er hægt að fleygja `ParseIntError` vegna leiðandi eða eftirliggjandi hvítra svæða í strengnum, td þegar það er fengið frá venjulegu inntakinu.
///
/// Með því að nota [`str::trim()`] aðferðina er tryggt að ekkert hvítt svæði verði eftir áður en þáttun er gerð.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum til að geyma hinar ýmsu villur sem geta valdið því að þáttun heiltölu mistakist.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Gildið sem verið er að þátta er tómt.
    ///
    /// Meðal annarra orsaka verður þetta afbrigði smíðað við töku tóms strengs.
    Empty,
    /// Inniheldur ógilda tölu í samhengi sínu.
    ///
    /// Meðal annarra orsaka verður þetta afbrigði smíðað þegar þáttur er gerður á streng sem inniheldur bleikju sem ekki er ASCII.
    ///
    /// Þetta afbrigði er einnig smíðað þegar `+` eða `-` er rangt settur innan strengs annað hvort einn eða í miðri tölu.
    ///
    ///
    InvalidDigit,
    /// Heiltala er of stórt til að geyma í heiltölu gerð.
    PosOverflow,
    /// Heiltala er of lítið til að geyma í heiltölu gerð.
    NegOverflow,
    /// Gildi var núll
    ///
    /// Þetta afbrigði verður sent út þegar þáttunarstrengurinn hefur núllið, sem væri ólöglegt fyrir gerðir sem ekki eru núll.
    ///
    Zero,
}

impl ParseIntError {
    /// Framleiðir nákvæma orsök þess að þáttun heiltölu bilar.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}