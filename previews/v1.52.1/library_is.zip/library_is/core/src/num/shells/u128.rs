//! Fastar fyrir 128 bita óundirritaða heiltölu gerð.
//!
//! *[See also the `u128` primitive type][u128].*
//!
//! Nýr kóði ætti að nota tilheyrandi fasta beint á frumstæðri gerð.

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u128`"
)]

int_module! { u128, #[stable(feature = "i128", since="1.26.0")] }