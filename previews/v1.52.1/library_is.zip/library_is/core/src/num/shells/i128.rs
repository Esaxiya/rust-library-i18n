//! Stöðug fyrir 128 bita undirritaða heiltölu gerð.
//!
//! *[See also the `i128` primitive type][i128].*
//!
//! Nýr kóði ætti að nota tilheyrandi fasta beint á frumstæðri gerð.

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i128`"
)]

int_module! { i128, #[stable(feature = "i128", since="1.26.0")] }