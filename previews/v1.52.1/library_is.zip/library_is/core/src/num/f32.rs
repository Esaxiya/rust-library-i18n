//! Stöðugir sem eru sérstakir fyrir `f32` tegundina með nákvæmni fljótandi punkta.
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! Stærðfræðilega marktækar tölur eru í `consts` undireiningunni.
//!
//! Fyrir fastana sem eru skilgreindir beint í þessari einingu (frábrugðnir þeim sem eru skilgreindir í `consts` undirþáttinum), ætti nýr kóði í staðinn að nota tilheyrandi fasta sem eru skilgreindir beint á `f32` gerðinni.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// Radix eða grunnur innri fulltrúa `f32`.
/// Notaðu [`f32::RADIX`] í staðinn.
///
/// # Examples
///
/// ```rust
/// // úreltur háttur
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // ætlað leið
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// Fjöldi marktækra tölustafa í grunn 2.
/// Notaðu [`f32::MANTISSA_DIGITS`] í staðinn.
///
/// # Examples
///
/// ```rust
/// // úreltur háttur
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // ætlað leið
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// Áætlaður fjöldi marktækra tölustafa í grunn 10.
/// Notaðu [`f32::DIGITS`] í staðinn.
///
/// # Examples
///
/// ```rust
/// // úreltur háttur
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // ætlað leið
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] gildi fyrir `f32`.
/// Notaðu [`f32::EPSILON`] í staðinn.
///
/// Þetta er munurinn á `1.0` og næsta stærri tölu sem hægt er að tákna.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // úreltur háttur
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // ætlað leið
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// Minnsta endanlega `f32` gildi.
/// Notaðu [`f32::MIN`] í staðinn.
///
/// # Examples
///
/// ```rust
/// // úreltur háttur
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // ætlað leið
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// Minnsta jákvæða eðlilega `f32` gildi.
/// Notaðu [`f32::MIN_POSITIVE`] í staðinn.
///
/// # Examples
///
/// ```rust
/// // úreltur háttur
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // ætlað leið
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// Stærsta endanlega `f32` gildi.
/// Notaðu [`f32::MAX`] í staðinn.
///
/// # Examples
///
/// ```rust
/// // úreltur háttur
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // ætlað leið
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// Einn meiri en mögulegt lágmarks eðlilegt afl 2 veldisvísir.
/// Notaðu [`f32::MIN_EXP`] í staðinn.
///
/// # Examples
///
/// ```rust
/// // úreltur háttur
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // ætlað leið
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// Hámarks mögulegur kraftur 2 veldisvísir.
/// Notaðu [`f32::MAX_EXP`] í staðinn.
///
/// # Examples
///
/// ```rust
/// // úreltur háttur
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // ætlað leið
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// Lágmarks mögulegt eðlilegt afl 10 exponent.
/// Notaðu [`f32::MIN_10_EXP`] í staðinn.
///
/// # Examples
///
/// ```rust
/// // úreltur háttur
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // ætlað leið
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// Hámarks mögulegur kraftur 10 veldisvísir.
/// Notaðu [`f32::MAX_10_EXP`] í staðinn.
///
/// # Examples
///
/// ```rust
/// // úreltur háttur
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // ætlað leið
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// Ekki tala (NaN).
/// Notaðu [`f32::NAN`] í staðinn.
///
/// # Examples
///
/// ```rust
/// // úreltur háttur
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // ætlað leið
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// Infinity (∞).
/// Notaðu [`f32::INFINITY`] í staðinn.
///
/// # Examples
///
/// ```rust
/// // úreltur háttur
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // ætlað leið
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// Neikvætt óendanlegt (−∞).
/// Notaðu [`f32::NEG_INFINITY`] í staðinn.
///
/// # Examples
///
/// ```rust
/// // úreltur háttur
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // ætlað leið
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// Grunn stærðfræðilegir fastir.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: skipta um stærðfræðilega fasta frá cmath.

    /// Stöðugur (π) Archimedes
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// Hringurinn stöðugur (τ)
    ///
    /// Jafnt 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// Númer Eulers (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// Radix eða grunnur innri fulltrúa `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Fjöldi marktækra tölustafa í grunn 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// Áætlaður fjöldi marktækra tölustafa í grunn 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] gildi fyrir `f32`.
    ///
    /// Þetta er munurinn á `1.0` og næsta stærri tölu sem hægt er að tákna.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// Minnsta endanlega `f32` gildi.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// Minnsta jákvæða eðlilega `f32` gildi.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// Stærsta endanlega `f32` gildi.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// Einn meiri en mögulegt lágmarks eðlilegt afl 2 veldisvísir.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// Hámarks mögulegur kraftur 2 veldisvísir.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// Lágmarks mögulegt eðlilegt afl 10 exponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// Hámarks mögulegur kraftur 10 veldisvísir.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// Ekki tala (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// Infinity (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// Neikvætt óendanlegt (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// Skilar `true` ef þetta gildi er `NaN`.
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` er ekki tiltækt opinberlega í libcore vegna áhyggna af flutningi, þannig að þessi framkvæmd er til einkanota innanhúss.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// Skilar `true` ef þetta gildi er jákvætt óendanlegt eða neikvætt óendanlegt og `false` annars.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Skilar `true` ef þessi tala er hvorki óendanleg né `NaN`.
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // Það er engin þörf á að höndla NaN sérstaklega: ef sjálf er NaN er samanburðurinn ekki sannur, nákvæmlega eins og óskað er.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Skilar `true` ef talan er [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // Gildi milli `0` og `min` eru óeðlileg.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Skilar `true` ef talan er hvorki núll, óendanleg, [subnormal] eða `NaN`.
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // Gildi milli `0` og `min` eru óeðlileg.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Skilar flotpunktaflokki tölunnar.
    /// Ef aðeins einn eiginleiki verður prófaður er almennt fljótlegra að nota tiltekið forsendu í staðinn.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Skilar `true` ef `self` hefur jákvætt tákn, þar á meðal `+0.0`, `NaN`s með jákvæðu táknbita og jákvæðu óendanleika.
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// Skilar `true` ef `self` hefur neikvætt tákn, þar með talið `-0.0`, `NaN`s með neikvæðum táknbita og neikvæðum óendanleika.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // IEEE754 segir: isSignMinus(x) er satt ef og aðeins ef x hefur neikvætt tákn.
        // isSignMinus á við um núll og NaN líka.
        self.to_bits() & 0x8000_0000 != 0
    }

    /// Tekur gagnkvæm (inverse) af tölu, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// Breytir radíönum í gráður.
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // Notaðu fasta til að fá betri nákvæmni.
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// Breytir gráðum í radíana.
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// Skilar hámarki tveggja talna.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Ef eitt af rökunum er NaN, þá er hinum rökum skilað.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// Skilar lágmarki tveggja talna.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Ef eitt af rökunum er NaN, þá er hinum rökum skilað.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// Snúist í átt að núlli og breytist í hvaða frumstæða heiltölu gerð sem er, miðað við að gildið sé endanlegt og passi í þá gerð.
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Gildið verður að:
    ///
    /// * Ekki vera `NaN`
    /// * Ekki vera óendanlegur
    /// * Vertu táknrænn í skilgerð `Int`, eftir að þú hefur stytt af brotahluta hennar
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `FloatToInt::to_int_unchecked`.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Hrá umbreyting í `u32`.
    ///
    /// Þetta er eins og `transmute::<f32, u32>(self)` á öllum kerfum.
    ///
    /// Sjá `from_bits` fyrir nokkrar umræður um færanleika þessarar aðgerðar (það eru næstum engin vandamál).
    ///
    /// Athugaðu að þessi aðgerð er aðgreind frá `as` steypu, sem reynir að varðveita *tölulegt* gildi, en ekki bitagildi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() er ekki steypa!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // ÖRYGGI: `u32` er venjulegt gamalt gagnategund svo við getum alltaf umbreytt því
        unsafe { mem::transmute(self) }
    }

    /// Hrá umbreyting frá `u32`.
    ///
    /// Þetta er eins og `transmute::<u32, f32>(v)` á öllum kerfum.
    /// Það kemur í ljós að þetta er ótrúlega færanlegt af tveimur ástæðum:
    ///
    /// * Flot og Ints hafa sömu endi á öllum studdum pöllum.
    /// * IEEE-754 tilgreinir mjög nákvæmlega bitaskipan á flotum.
    ///
    /// Hins vegar er einn fyrirvari: fyrir 2008 útgáfuna af IEEE-754 var ekki raunverulega tilgreint hvernig ætti að túlka NaN merkjabitann.
    /// Flestir pallar (sérstaklega x86 og ARM) völdu túlkunina sem var að lokum stöðluð árið 2008, en sumir gerðu það ekki (sérstaklega MIPS).
    /// Fyrir vikið eru öll merki NaN á MIPS hljóðlát NaN á x86 og öfugt.
    ///
    /// Frekar en að reyna að varðveita merki-ness yfir pallur, er þessi framkvæmd ívilnandi að varðveita nákvæmlega bitana.
    /// Þetta þýðir að öll farmur sem kóðuð er í NaN verður varðveittur jafnvel þó niðurstaðan af þessari aðferð sé send yfir netið frá x86 vél til MIPS.
    ///
    ///
    /// Ef niðurstöður þessarar aðferðar eru aðeins meðhöndlaðar með sama arkitektúr og framleiddi þær, þá er engin áhyggjur af flutningi.
    ///
    /// Ef inntakið er ekki NaN, þá er það engin áhyggjur af flutningi.
    ///
    /// Ef þér er ekki sama um boðunargetu (mjög líklegt), þá er engin áhyggjur af flutningi.
    ///
    /// Athugaðu að þessi aðgerð er aðgreind frá `as` steypu, sem reynir að varðveita *tölulegt* gildi, en ekki bitagildi.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // ÖRYGGI: `u32` er venjulegt gamalt gagnategund svo við getum alltaf umbreytt frá því
        // Það kemur í ljós að öryggisvandamál með sNaN voru yfirdrifin!Húrra!
        unsafe { mem::transmute(v) }
    }

    /// Skilaðu minni framsetningu þessa flotpunkta sem bæti fylki í stór-endian (network) bæti röð.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// Skilaðu minni framsetningu þessa flotpunkta sem bæti fylki í litlu endian bæti röð.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// Skilaðu minni framsetningu þessa flotpunkta sem bæti fylki í innfæddri bæti röð.
    ///
    /// Þar sem innfædd endanleiki markpallsins er notaður ætti færanlegur kóði að nota [`to_be_bytes`] eða [`to_le_bytes`], eins og við á, í staðinn.
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// Skilaðu minni framsetningu þessa flotpunkta sem bæti fylki í innfæddri bæti röð.
    ///
    ///
    /// [`to_ne_bytes`] ætti að vera valinn fram yfir þetta þegar mögulegt er.
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // ÖRYGGI: `f32` er venjulegt gamalt gagnategund svo við getum alltaf umbreytt því
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Búðu til flotpunktargildi út frá framsetningu þess sem bæti fylki í stóru endían.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// Búðu til gildi fyrir flotpunkt út frá framsetningu þess sem bæti fylki í litlu endian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// Búðu til gildi fyrir flotpunkt út frá framsetningu þess sem bæti fylki í móðurmáli endíans.
    ///
    /// Þar sem innfædd endanleiki markpallsins er notaður vill færanlegur kóði líklega nota [`from_be_bytes`] eða [`from_le_bytes`], eins og við á í staðinn.
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// Skilar röðun milli sjálfs og annarra gilda.
    /// Ólíkt venjulegum hlutasamanburði milli flotpunkta, framleiðir þessi samanburður alltaf pöntun í samræmi við heildarfyrirmæli fyrirskipunar eins og skilgreint er í IEEE 754 (2008 endurskoðun) staðal fyrir flotpunkt.
    /// Gildin eru raðað í eftirfarandi röð:
    /// - Neikvætt rólegt NaN
    /// - Neikvæð merki NaN
    /// - Neikvætt óendanlegt
    /// - Neikvæðar tölur
    /// - Neikvæðar óeðlilegar tölur
    /// - Neikvætt núll
    /// - Jákvætt núll
    /// - Jákvæðar óeðlilegar tölur
    /// - Jákvæðar tölur
    /// - Jákvætt óendanlegt
    /// - Jákvæð merki NaN
    /// - Jákvætt rólegt NaN
    ///
    /// Athugaðu að þessi aðgerð er ekki alltaf sammála [`PartialOrd`] og [`PartialEq`] útfærslum á `f32`.Sérstaklega líta þeir á neikvætt og jákvætt núll sem jafnt en `total_cmp` ekki.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // Ef um er að ræða neikvætt, flettu öllum bitum nema skiltinu til að ná svipuðu skipulagi og viðbótartölur tveggja
        //
        // Af hverju virkar þetta?IEEE 754 flot samanstendur af þremur sviðum:
        // Sign bit, exponent og mantissa.Samstæðan veldisvísis-og mantissusviðanna í heild hafa þá eiginleika að bitur röð þeirra er jöfn tölustærðinni þar sem stærðin er skilgreind.
        // Stærðin er venjulega ekki skilgreind á NaN gildum, en IEEE 754 totalOrder skilgreinir NaN gildi einnig til að fylgja bitvísi röð.Þetta leiðir til skipunar sem útskýrt er í athugasemd doktorsins.
        // Framsetning stærðarinnar er hins vegar sú sama fyrir neikvæðar og jákvæðar tölur-aðeins táknbitinn er öðruvísi.
        // Til að bera saman flotana auðveldlega sem undirritaðar heiltölur verðum við að snúa veldisvísis-og mantissubitum ef um neikvæðar tölur er að ræða.
        // Við breytum tölunum í raun í "two's complement" form.
        //
        // Til að gera flippið smíðum við grímu og XOR gegn henni.
        // Við reiknum greinalaust "all-ones except for the sign bit" grímu út frá neikvæðum undirrituðum gildum: hægri breytingartáknið framlengir heiltöluna, þannig að við "fill" grímuna með táknbitum og breytum síðan í óundirritað til að ýta enn einum núllbita.
        //
        // Á jákvæðum gildum er gríman öll núll, svo það er neitun.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// Takmarkaðu gildi við ákveðið bil nema það sé NaN.
    ///
    /// Skilar `max` ef `self` er stærra en `max` og `min` ef `self` er minna en `min`.
    /// Annars skilar þetta `self`.
    ///
    /// Athugaðu að þessi aðgerð skilar NaN ef upphafsgildið var NaN líka.
    ///
    /// # Panics
    ///
    /// Panics ef `min > max`, `min` er NaN eða `max` er NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}