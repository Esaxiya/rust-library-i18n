#![stable(feature = "core_hint", since = "1.27.0")]

//! Vísbendingar til þýðanda sem hafa áhrif á hvernig kóða ætti að gefa út eða fínstilla.
//! Vísbendingar geta verið tímasetning eða keyrslutími.

use crate::intrinsics;

/// Tilkynnir þýðandanum að ekki sé hægt að ná þessum punkti í kóðanum, sem gerir frekari hagræðingu kleift.
///
/// # Safety
///
/// Að ná þessari aðgerð er alveg *óskilgreind hegðun*(UB).Sérstaklega gerir þýðandinn ráð fyrir að allt UB megi aldrei eiga sér stað og mun því útrýma öllum greinum sem ná til símtals í `unreachable_unchecked()`.
///
/// Eins og í öllum tilvikum UB, ef þessi forsenda reynist röng, þ.e. `unreachable_unchecked()` símtalið er í raun náðanlegt meðal alls mögulegs stjórnunarflæðis, mun þýðandinn beita röngri hagræðingarstefnu og getur stundum jafnvel skemmt að því er virðist ótengdan kóða, sem veldur erfið-vandamál til að kemba.
///
///
/// Notaðu þessa aðgerð aðeins þegar þú getur sannað að kóðinn kalli það aldrei.
/// Annars skaltu íhuga að nota [`unreachable!`] fjölvi, sem leyfir ekki hagræðingu en mun panic þegar það er keyrt.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` er alltaf jákvætt (ekki núll), þess vegna mun `checked_div` aldrei skila `None`.
/////
///     // Þess vegna er hitt branch ekki náð.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // ÖRYGGI: öryggissamningur fyrir `intrinsics::unreachable` verður að
    // vera staðfestur af þeim sem hringir.
    unsafe { intrinsics::unreachable() }
}

/// Sendir frá sér leiðbeiningar um vélar til að gefa örgjörva merki um að hann sé í gangi í upptekinni bið-snúningshring (" snúningslás`).
///
/// Við móttöku snúningshringamerkisins getur örgjörvinn hagrætt hegðun sinni með því til dæmis að spara orku eða skipta um hyper-þræði.
///
/// Þessi aðgerð er frábrugðin [`thread::yield_now`] sem skilar tímaáætlun kerfisins beint, en `spin_loop` hefur ekki samskipti við stýrikerfið.
///
/// Algengt notkunartilfelli fyrir `spin_loop` er að innleiða takmarkaðan bjartsýni snúning í CAS-lykkju í frumstillingu samstillingar.
/// Til að koma í veg fyrir vandamál eins og forgangsbreytingu er eindregið mælt með því að snúningshringnum sé slitið eftir endanlegt magn af endurtekningum og viðeigandi hindrunarávísun sé gerð.
///
///
/// **Athugið**: Á pöllum sem styðja ekki viðtökur við ábendingum um snúningshring gerir þessi aðgerð alls ekki neitt.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Sameiginlegt atómgildi sem þræðir munu nota til að samræma
/// let live = Arc::new(AtomicBool::new(false));
///
/// // Í bakgrunnsþráð setjum við að lokum gildi
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Gerðu smá vinnu og láttu verðmætin lifa
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Aftur á núverandi þráð okkar bíðum við eftir því að gildið verði stillt
/// while !live.load(Ordering::Acquire) {
///     // Snúningslykkjan er vísbending við örgjörvann um að við bíðum, en líklega ekki mjög lengi
/////
///     hint::spin_loop();
/// }
///
/// // Gildið er nú stillt
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // ÖRYGGI: `cfg` attr tryggir að við framkvæmum þetta aðeins á x86 skotmörkum.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // ÖRYGGI: `cfg` attr tryggir að við framkvæmum þetta aðeins á x86_64 skotmörkum.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // ÖRYGGI: `cfg` attr tryggir að við framkvæmum þetta aðeins á aarch64 skotmörkum.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // ÖRYGGI: `cfg` attr tryggir að við framkvæmum þetta aðeins á handleggsmarkmiðum
            // með stuðningi við v6 aðgerðina.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Sjálfsmyndaraðgerð sem *__ bendir __* við þýðandann til að vera sem mest svartsýnn á hvað `black_box` gæti gert.
///
/// Ólíkt [`std::convert::identity`] er Rust þýðandi hvattur til að gera ráð fyrir að `black_box` geti notað `dummy` á hvaða mögulegan gildan hátt sem Rust kóða er leyft að gera án þess að koma með óskilgreinda hegðun í símakóðanum.
///
/// Þessi eiginleiki gerir `black_box` gagnlegt til að skrifa kóða þar sem ekki er óskað eftir ákveðnum hagræðingum, svo sem viðmið.
///
/// Athugaðu þó að `black_box` er aðeins (og er aðeins hægt að veita) á "best-effort" grundvelli.Að hve miklu leyti það getur hindrað hagræðingu getur verið breytilegt eftir því hvaða vettvangur og kóðinn er notaður.
/// Forrit geta ekki reitt sig á `black_box` fyrir *réttmæti* á nokkurn hátt.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Við þurfum að "use" rökin á einhvern hátt LLVM getur ekki skoðað sjálf og á markmiðum sem styðja það getum við venjulega nýtt innbyggða samsetningu til að gera þetta.
    // Túlkun LLVM á línusamsetningu er sú að það er, ja, svartur kassi.
    // Þetta er ekki mesta útfærslan þar sem líklega deoptimalize meira en við viljum, en það er svo langt nógu gott.
    //
    //

    #[cfg(not(miri))] // Þetta er aðeins vísbending, svo það er fínt að sleppa í Miri.
    // ÖRYGGI: innbyggður samkoma er neikvæð.
    unsafe {
        // FIXME: Get ekki notað `asm!` vegna þess að það styður ekki MIPS og aðra arkitektúr.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}