//! Skilgreinir endurgerð í eigu `IntoIter` fyrir fylki.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// A-gildi [array] endurtekning.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Þetta er fylkingin sem við erum að endurtekna.
    ///
    /// Þættir með vísitölu `i` þar sem `alive.start <= i < alive.end` hefur ekki verið gefinn ennþá og eru gildar fylkisfærslur.
    /// Þættir með vísitölurnar `i < alive.start` eða `i >= alive.end` hafa þegar verið gefnir og ekki verður hægt að nálgast þær lengur!Þessir dauðu þættir gætu jafnvel verið í algjörlega einvígðu ástandi!
    ///
    ///
    /// Svo að innflytjendurnir eru:
    /// - `data[alive]` er lifandi (þ.e. inniheldur gild atriði)
    /// - `data[..alive.start]` og `data[alive.end..]` eru dauðir (þ.e. þættirnir voru þegar lesnir og má ekki snerta þær lengur!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Þættirnir í `data` sem ekki hafa verið gefnir ennþá.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Býr til nýjan endurtekning á tilteknum `array`.
    ///
    /// *Athugið*: þessi aðferð gæti verið úrelt í future, eftir [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Gerðin af `value` er `i32` hér, í staðinn fyrir `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // ÖRYGGI: Umbreytingin hér er í raun örugg.Skjölin í `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` er tryggt að hafa sömu stærð og aðlögun
        // > sem `T`.
        //
        // Skjölin sýna meira að segja breytu úr fylkingu `MaybeUninit<T>` í fylki `T`.
        //
        //
        // Þar með fullnægir þessi frumstilling innflytjendunum.

        // FIXME(LukasKalbertodt): nota í raun `mem::transmute` hér, þegar það virkar með const generics:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Þangað til getum við notað `mem::transmute_copy` til að búa til bitvis afrit sem aðra tegund, gleymdu síðan `array` svo að það falli ekki niður.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Skilar óbreytanlegri sneið af öllum þáttum sem ekki hefur verið gefinn ennþá.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // ÖRYGGI: Við vitum að allir þættir innan `alive` eru frumstilltir rétt.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Skilar breytanlegri sneið af öllum þáttum sem ekki hefur verið gefinn ennþá.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // ÖRYGGI: Við vitum að allir þættir innan `alive` eru frumstilltir rétt.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Fáðu næstu vísitölu að framan.
        //
        // Að hækka `alive.start` um 1 heldur viðbrigðinu varðandi `alive`.
        // Hins vegar, vegna þessarar breytingar, í stuttan tíma, er lifandi svæði ekki `data[alive]` lengur, heldur `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Lestu þáttinn úr fylkinu.
            // ÖRYGGI: `idx` er vísitala í fyrrum "alive" svæðið í
            // fylki.Að lesa þennan þátt þýðir að `data[idx]` er talinn dauður núna (þ.e. ekki snerta).
            // Þar sem `idx` var upphaf lifandi svæðisins er lifandi svæðið nú aftur `data[alive]` og endurheimtir alla innflytjendur.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Fáðu næstu vísitölu aftan frá.
        //
        // Að lækka `alive.end` um 1 viðheldur óbreyttu varðandi `alive`.
        // Hins vegar, vegna þessarar breytingar, í stuttan tíma, er lifandi svæði ekki `data[alive]` lengur, heldur `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Lestu þáttinn úr fylkinu.
            // ÖRYGGI: `idx` er vísitala í fyrrum "alive" svæðið í
            // fylki.Að lesa þennan þátt þýðir að `data[idx]` er talinn dauður núna (þ.e. ekki snerta).
            // Þar sem `idx` var endir lifandi svæðisins er lifandi svæðið nú `data[alive]` og endurheimtir alla innflytjendur.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // ÖRYGGI: Þetta er öruggt: `as_mut_slice` skilar nákvæmlega undir sneiðinni
        // af þáttum sem ekki hafa verið fluttir út enn og eftir er að fella.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Mun aldrei undirstreymi vegna óbreytanlegs " lifandi.starts <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Ítórinn skýrir örugglega frá réttri lengd.
// Fjöldi "alive" frumefna (sem samt verður gefinn) er lengd sviðsins `alive`.
// Þetta svið er minnkað að lengd í annað hvort `next` eða `next_back`.
// Það er alltaf minnkað með 1 í þessum aðferðum, en aðeins ef `Some(_)` er skilað.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Athugið, við þurfum í raun ekki að passa nákvæmlega sama lifandi svið, svo við getum bara klónað í móti 0 óháð því hvar `self` er.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Klóna alla lifandi þætti.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Skrifaðu klón í nýja fylkið og uppfærðu síðan lifandi svið þess.
            // Ef við einræktum panics sleppum við fyrri hlutum rétt.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Prentaðu aðeins þá þætti sem ekki var skilað ennþá: við höfum ekki aðgang að þeim þætti sem skilað er lengur.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}