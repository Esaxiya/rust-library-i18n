#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// A future táknar ósamstillta útreikninga.
///
/// A future er gildi sem er kannski ekki búið að reikna enn.
/// Þessi tegund af "asynchronous value" gerir það mögulegt fyrir þráð að halda áfram að vinna gagnlega vinnu meðan hann bíður eftir að verðmætið verði tiltækt.
///
///
/// # `poll` aðferðin
///
/// Kjarnaaðferð future, `poll`,*reynir* að leysa future í lokagildi.
/// Þessi aðferð hindrar ekki ef gildi er ekki tilbúið.
/// Í staðinn er áætlað að núverandi verkefni verði vaknað þegar mögulegt er að ná frekari framförum með því að " kjósa` aftur.
/// `context` sem sendur er til `poll` aðferðarinnar getur veitt [`Waker`], sem er handfang til að vekja núverandi verkefni.
///
/// Þegar þú notar future muntu almennt ekki hringja beint í `poll` heldur í staðinn `.await` gildið.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Tegund verðmætis sem framleidd er að loknu.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Reyndu að leysa future að lokagildi og skráðu núverandi verkefni fyrir vakningu ef gildi er ekki enn til staðar.
    ///
    /// # Skilagildi
    ///
    /// Þessi aðgerð skilar:
    ///
    /// - [`Poll::Pending`] ef future er ekki tilbúinn ennþá
    /// - [`Poll::Ready(val)`] með niðurstöðunni `val` af þessari future ef henni lauk með góðum árangri.
    ///
    /// Þegar future er lokið ættu viðskiptavinir ekki að `poll` það aftur.
    ///
    /// Þegar future er ekki tilbúinn ennþá skilar `poll` `Poll::Pending` og geymir klón af [`Waker`] afritað frá núverandi [`Context`].
    /// Þessi [`Waker`] er síðan vakinn þegar future getur náð framförum.
    /// Til dæmis, future sem bíður eftir að fals verði læsileg myndi hringja í `.clone()` á [`Waker`] og geyma það.
    /// Þegar merki berst annars staðar sem gefur til kynna að falsið sé læsilegt er kallað á [`Waker::wake`] og verkefni fals future er vakið.
    /// Þegar verkefni hefur verið vaknað, ætti það að reyna að `poll` future aftur, sem getur framleitt endanlega gildi eða ekki.
    ///
    /// Athugaðu að á mörgum símtölum til `poll` ætti aðeins að skipuleggja [`Waker`] frá [`Context`] sem var sent í síðasta símtal.
    ///
    /// # Runtime einkenni
    ///
    /// Futures einn er *óvirkur*;þau verða að vera *virk*'könnuð' til að ná framförum, sem þýðir að í hvert skipti sem núverandi verkefni er vaknað, þá ætti það að taka virkan þátt aftur í bið futures sem það hefur enn áhuga á.
    ///
    /// Aðgerðin `poll` er ekki kölluð ítrekað í þéttri lykkju-í staðinn ætti hún aðeins að hringja þegar future gefur til kynna að hún sé tilbúin til framfara (með því að hringja í `wake()`).
    /// Ef þú þekkir `poll(2)` eða `select(2)` syscalls á Unix er rétt að hafa í huga að futures þjáist venjulega *ekki* af sömu vandamálum og "all wakeups must poll all events";þeir eru meira eins og `epoll(4)`.
    ///
    /// Útfærsla `poll` ætti að leitast við að snúa aftur fljótt og ætti ekki að hindra það.Að snúa aftur kemur í veg fyrir að stíflar þræði eða atburðarlykkjur að óþörfu.
    /// Ef fyrirfram er vitað að símtal til `poll` gæti endað með því að taka smá tíma ætti að losa verkið í þráðlaug (eða eitthvað álíka) til að tryggja að `poll` geti snúið fljótt aftur.
    ///
    /// # Panics
    ///
    /// Þegar future er lokið (skilaði `Ready` frá `poll`), að hringja í `poll` aðferð sína aftur getur panic, lokast að eilífu eða valdið annars konar vandamálum;`Future` trait gerir engar kröfur um áhrif slíks símtals.
    /// Hins vegar, þar sem `poll` aðferðin er ekki merkt `unsafe`, gilda venjulegar reglur Rust: símtöl mega aldrei valda óskilgreindri hegðun (minnispilling, röng notkun `unsafe` aðgerða eða þess háttar), óháð stöðu future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}