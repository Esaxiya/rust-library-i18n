use crate::future::Future;

/// Umbreyting í `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// Framleiðslan sem future mun framleiða þegar henni er lokið.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// Hvers konar future erum við að breyta þessu í?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Býr til future úr gildi.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}