#![stable(feature = "futures_api", since = "1.36.0")]

//! Ósamstillt gildi.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// Þessa gerð er þörf vegna þess að:
///
/// a) Rafalar geta ekki innleitt `for<'a, 'b> Generator<&'a mut Context<'b>>` og því þurfum við að fara framhjá hráum bendli (sjá <https://github.com/rust-lang/rust/issues/68923>).
///
/// b) Hráir ábendingar og `NonNull` eru ekki `Send` eða `Sync`, þannig að það myndi gera hvern einasta future non-Send/Sync líka og við viljum það ekki.
///
/// Það einfaldar einnig HIR lækkun `.await`.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// Vefjaðu rafall í future.
///
/// Þessi aðgerð skilar `GenFuture` undir en felur hana í `impl Trait` til að gefa betri villuboð (`impl Future` frekar en `GenFuture<[closure.....]>`).
///
// Þetta er `const` til að forðast auka villur eftir að við náum okkur eftir `const async fn`
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // Við treystum á þá staðreynd að async/await futures eru ófærar til að búa til sjálfsvísandi lán í undirliggjandi rafall.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // ÖRYGGI: Öruggt vegna þess að við erum !Unpin + !Drop, og þetta er bara vörpun á sviði.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // Haltu áfram rafallinum og breyttu `&mut Context` í `NonNull` hráan bendil.
            // `.await` lækkunin mun örugglega varpa því aftur í `&mut Context`.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // ÖRYGGI: sá sem hringir þarf að ábyrgjast að `cx.0` sé gildur bendill
    // sem uppfyllir allar kröfur um breytanlega tilvísun.
    unsafe { &mut *cx.0.as_ptr().cast() }
}