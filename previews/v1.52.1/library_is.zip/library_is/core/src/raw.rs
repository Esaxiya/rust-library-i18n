#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Inniheldur struct skilgreiningar fyrir skipulag innbyggðra gerða þýðanda.
//!
//! Þeir geta verið notaðir sem skotmark umbreytinga í óöruggum kóða til að stjórna hráu framsetningunni beint.
//!
//!
//! Skilgreining þeirra ætti alltaf að passa við ABI sem skilgreind er í `rustc_middle::ty::layout`.
//!

/// Framsetning trait hlutar eins og `&dyn SomeTrait`.
///
/// Þessi uppbygging er með sama skipulag og gerðir eins og `&dyn SomeTrait` og `Box<dyn AnotherTrait>`.
///
/// `TraitObject` það er tryggt að það passi við skipulag, en það er ekki tegund trait hlutanna (td reitirnir eru ekki beint aðgengilegir á `&dyn SomeTrait`) né heldur stýrir það skipulagi (breyting á skilgreiningu mun ekki breyta skipulagi `&dyn SomeTrait`).
///
/// Það er aðeins hannað til að nota óöruggan kóða sem þarf að vinna með smáatriðin.
///
/// Það er engin leið að vísa til allra trait hlutanna almennt, þannig að eina leiðin til að búa til gildi af þessari gerð er með aðgerðum eins og [`std::mem::transmute`][transmute].
/// Á sama hátt er eina leiðin til að búa til sannan trait hlut úr `TraitObject` gildi með `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Að mynda trait hlut með ósamrýmanlegum gerðum-þar sem vtaflan samsvarar ekki gerð gildisins sem gagnabendillinn bendir á-er mjög líkleg til að leiða til óskilgreindrar hegðunar.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // dæmi trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // láttu þýðandann búa til trait hlut
/// let object: &dyn Foo = &value;
///
/// // líta á hráu framsetninguna
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // gagnabendillinn er heimilisfang `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // smíða nýjan hlut, benda á annan `i32`, vera varkár að nota `i32` vtable frá `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // það ætti að virka alveg eins og við hefðum smíðað trait hlut úr `other_value` beint
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}