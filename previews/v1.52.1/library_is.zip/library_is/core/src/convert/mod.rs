//! Traits fyrir viðskipti milli tegunda.
//!
//! traits í þessari einingu veitir leið til að umbreyta frá einni gerð í aðra gerð.
//! Hver trait þjónar öðrum tilgangi:
//!
//! - Framkvæmdu [`AsRef`] trait fyrir ódýr viðskipti tilvísunar
//! - Framkvæmdu [`AsMut`] trait fyrir ódýr umbreytanleg til breytanleg viðskipti
//! - Framkvæmdu [`From`] trait til að neyta verðmætis viðskipta
//! - Framkvæmdu [`Into`] trait til að neyta verðmætis viðskipta í gerðir utan núverandi crate
//! - [`TryFrom`] og [`TryInto`] traits haga sér eins og [`From`] og [`Into`], en ætti að hrinda í framkvæmd þegar umbreytingin getur mistekist.
//!
//! traits í þessari einingu eru oft notuð sem trait bounds fyrir almennar aðgerðir svo að rök af mörgum gerðum eru studd.Sjá skjöl hvers trait fyrir dæmi.
//!
//! Sem höfundur bókasafns ættirðu alltaf að kjósa að útfæra [`From<T>`][`From`] eða [`TryFrom<T>`][`TryFrom`] frekar en [`Into<U>`][`Into`] eða [`TryInto<U>`][`TryInto`], þar sem [`From`] og [`TryFrom`] veita meiri sveigjanleika og bjóða samsvarandi [`Into`] eða [`TryInto`] útfærslur ókeypis, þökk sé teppiútfærslu í venjulegu bókasafninu.
//! Þegar miðað er við útgáfu áður en Rust 1.41 getur verið nauðsynlegt að innleiða [`Into`] eða [`TryInto`] beint við umbreytingu í gerð utan núverandi crate.
//!
//! # Almennar útfærslur
//!
//! - [`AsRef`] og [`AsMut`] sjálfvirkur aðgreining ef innri gerðin er tilvísun
//! - [`Frá`]`<U>fyrir T` gefur til kynna [`Inn í]]`</u><T><U>fyrir U`</u>
//! - [`TryFrom`]`<U>fyrir T` gefur til kynna [`TryInto`]`</u><T><U>fyrir U`</u>
//! - [`From`] og [`Into`] eru viðbrögð, sem þýðir að allar gerðir geta `into` sjálfar og `from` sjálfar
//!
//! Sjá hvert trait fyrir dæmi um notkun.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Sjálfsmyndaraðgerðin.
///
/// Tvennt er mikilvægt að hafa í huga varðandi þessa aðgerð:
///
/// - Það jafngildir ekki alltaf lokun eins og `|x| x`, þar sem lokunin gæti þvingað `x` í aðra tegund.
///
/// - Það færir inntakið `x` framhjá aðgerðinni.
///
/// Þó að það gæti virst einkennilegt að hafa aðgerð sem skilar bara inntakinu, þá eru nokkur áhugaverð notkun.
///
///
/// # Examples
///
/// Notkun `identity` til að gera ekkert í röð annarra áhugaverðra aðgerða:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Við skulum láta eins og að bæta við einum sé áhugaverð aðgerð.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Notkun `identity` sem "do nothing" grunntösku í skilyrtu:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Gerðu meira áhugavert efni ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Notkun `identity` til að halda `Some` afbrigði af endurtekningu á `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Notað til að gera ódýra tilvísun til tilvísunar umbreytingar.
///
/// Þetta trait er svipað og [`AsMut`] sem er notað til að umbreyta á milli breytanlegra tilvísana.
/// Ef þú þarft að gera kostnaðarsama umbreytingu er betra að innleiða [`From`] með gerð `&T` eða skrifa sérsniðna aðgerð.
///
/// `AsRef` hefur sömu undirskrift og [`Borrow`], en [`Borrow`] er mismunandi í fáum atriðum:
///
/// - Ólíkt `AsRef` hefur [`Borrow`] teppi fyrir alla `T` og er hægt að nota til að samþykkja annað hvort tilvísun eða gildi.
/// - [`Borrow`] krefst þess einnig að [`Hash`], [`Eq`] og [`Ord`] fyrir lánt verðmæti séu jafngild þeim sem eru í eigu verðmætisins.
/// Af þessum sökum, ef þú vilt fá lánað aðeins eitt reit í uppbyggingu geturðu innleitt `AsRef`, en ekki [`Borrow`].
///
/// **Note: Þessi trait má ekki mistakast **.Ef umbreytingin getur mistekist skaltu nota sérstaka aðferð sem skilar [`Option<T>`] eða [`Result<T, E>`].
///
/// # Almennar útfærslur
///
/// - `AsRef` auto-dereferences ef innri gerðin er tilvísun eða breytileg tilvísun (td: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Með því að nota trait bounds getum við samþykkt rök af mismunandi gerðum svo framarlega sem hægt er að breyta þeim í tilgreinda gerð `T`.
///
/// Til dæmis: Með því að búa til almenna aðgerð sem tekur `AsRef<str>` tjáum við að við viljum samþykkja allar tilvísanir sem hægt er að breyta í [`&str`] sem rök.
/// Þar sem bæði [`String`] og [`&str`] innleiða `AsRef<str>` getum við samþykkt bæði sem inntaksrök.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Framkvæmir umbreytinguna.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Notað til að gera ódýran breytanlegan til breytanlegan viðmiðunarbreytingu.
///
/// Þessi trait er svipaður [`AsRef`] en notaður til að umbreyta á milli breytanlegra tilvísana.
/// Ef þú þarft að gera kostnaðarsama umbreytingu er betra að innleiða [`From`] með gerð `&mut T` eða skrifa sérsniðna aðgerð.
///
/// **Note: Þessi trait má ekki mistakast **.Ef umbreytingin getur mistekist skaltu nota sérstaka aðferð sem skilar [`Option<T>`] eða [`Result<T, E>`].
///
/// # Almennar útfærslur
///
/// - `AsMut` auto-dereferences ef innri gerðin er breytileg tilvísun (td: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Með því að nota `AsMut` sem trait bound fyrir almenna aðgerð getum við samþykkt allar breytilegar tilvísanir sem hægt er að breyta í gerð `&mut T`.
/// Vegna þess að [`Box<T>`] útfærir `AsMut<T>` getum við skrifað fall `add_one` sem tekur öll rök sem hægt er að breyta í `&mut u64`.
/// Vegna þess að [`Box<T>`] útfærir `AsMut<T>` samþykkir `add_one` einnig rök af gerðinni `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Framkvæmir umbreytinguna.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Gildi-til-gildi umbreyting sem eyðir inntaksgildinu.Andstæða [`From`].
///
/// Maður ætti að forðast að innleiða [`Into`] og innleiða [`From`] í staðinn.
/// Útfærsla [`From`] veitir sjálfkrafa útfærslu á [`Into`] þökk sé teppiútfærslunni í venjulegu bókasafninu.
///
/// Notaðu frekar [`Into`] umfram [`From`] þegar þú tilgreinir trait bounds á almennri aðgerð til að tryggja að einnig sé hægt að nota gerðir sem aðeins innleiða [`Into`].
///
/// **Note: Þessi trait má ekki mistakast **.Ef umbreytingin tekst ekki, notaðu [`TryInto`].
///
/// # Almennar útfærslur
///
/// - [`Frá`]`<T>fyrir U` felur í sér `Into<U> for T`
/// - [`Into`] er viðbragðs sem þýðir að `Into<T> for T` er útfærður
///
/// # Útfærsla [`Into`] fyrir viðskipti í ytri gerðir í gömlum útgáfum af Rust
///
/// Fyrir Rust 1.41, ef áfangastaðargerðin var ekki hluti af núverandi crate, þá gætirðu ekki innleitt [`From`] beint.
/// Tökum til dæmis þennan kóða:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Þetta tekst ekki að safna saman í eldri útgáfum af tungumálinu vegna þess að munaðarlausar reglur Rust voru áður aðeins strangari.
/// Til að komast framhjá þessu gætirðu innleitt [`Into`] beint:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Það er mikilvægt að skilja að [`Into`] veitir ekki [`From`] útfærslu (eins og [`From`] gerir með [`Into`]).
/// Þess vegna ættirðu alltaf að reyna að útfæra [`From`] og falla síðan aftur í [`Into`] ef ekki er hægt að útfæra [`From`].
///
/// # Examples
///
/// [`String`] útfærir [`inn`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Til að tjá að við viljum að almenn aðgerð taki öll rök sem hægt er að breyta í tilgreinda gerð `T`, getum við notað trait bound af [`Inn í]]`<T>`.
///
/// Til dæmis: Aðgerðin `is_hello` tekur öll rök sem hægt er að breyta í [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Framkvæmir umbreytinguna.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Notað til að gera gildi-til-gildi umbreytingar meðan neyslu inntaksgildisins er.Það er gagnkvæmt [`Into`].
///
/// Maður ætti alltaf að kjósa að útfæra `From` fram yfir [`Into`] því að innleiða `From` veitir manni sjálfkrafa útfærslu á [`Into`] þökk sé teppiútfærslunni í venjulegu bókasafninu.
///
///
/// Aðeins skal innleiða [`Into`] þegar þú miðar á útgáfu fyrir Rust 1.41 og breytir í gerð utan núverandi crate.
/// `From` gat ekki gert þessar tegundir viðskipta í fyrri útgáfum vegna munaðarlausar reglna Rust.
/// Sjá [`Into`] fyrir frekari upplýsingar.
///
/// Notaðu frekar [`Into`] en `From` þegar þú tilgreinir trait bounds á almennri aðgerð.
/// Þannig er hægt að nota gerðir sem beina [`Into`] beint sem rök líka.
///
/// `From` er einnig mjög gagnlegur þegar þú gerir villumeðferð.Þegar verið er að smíða aðgerð sem er fær um að mistakast, þá er skilagerðin venjulega af forminu `Result<T, E>`.
/// `From` trait einfaldar meðhöndlun villna með því að leyfa aðgerð að skila einni villutegund sem hylur margar villutegundir.Sjá "Examples" hlutann og [the book][book] fyrir frekari upplýsingar.
///
/// **Note: Þessi trait má ekki mistakast **.Ef umbreytingin tekst ekki, notaðu [`TryFrom`].
///
/// # Almennar útfærslur
///
/// - `From<T> for U` felur í sér [`Inn í] <U>fyrir T`</u>
/// - `From` er viðbragðs sem þýðir að `From<T> for T` er útfærður
///
/// # Examples
///
/// [`String`] útfærir `From<&str>`:
///
/// Skýr breyting frá `&str` í streng er gerð á eftirfarandi hátt:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Meðan á villuaðgerð stendur er oft gagnlegt að innleiða `From` fyrir þína eigin villutegund.
/// Með því að breyta undirliggjandi villutegundum í okkar sérsniðnu villutegund sem hylur undirliggjandi villutegund getum við skilað einni villutegund án þess að tapa upplýsingum um undirliggjandi orsök.
/// '?' rekstraraðilinn breytir sjálfkrafa undirliggjandi villutegund í sérsniðnu villutegund okkar með því að hringja í `Into<CliError>::into` sem er sjálfkrafa veitt þegar `From` er innleitt.
/// Þáttaraðilinn sér síðan um hvaða notkun `Into` ætti að nota.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Framkvæmir umbreytinguna.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Reynslu umbreytingar sem eyðir `self`, sem getur verið dýrt eða ekki.
///
/// Höfundar bókasafna ættu venjulega ekki að framkvæma þennan trait beint heldur ættu frekar að innleiða [`TryFrom`] trait, sem býður upp á meiri sveigjanleika og veitir samsvarandi `TryInto` útfærslu ókeypis, þökk sé teppiútfærslu í venjulegu bókasafninu.
/// Nánari upplýsingar um þetta er að finna í skjölunum fyrir [`Into`].
///
/// # Útfærsla `TryInto`
///
/// Þetta þjáist af sömu takmörkunum og rökstuðningi og að útfæra [`Into`], sjáðu nánar þar.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Tegundin sem skilað er ef umreikningsvilla verður.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Framkvæmir umbreytinguna.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Einföld og örugg gerð umbreytinga sem geta mistekist á stjórnandi hátt undir sumum kringumstæðum.Það er gagnkvæmt [`TryInto`].
///
/// Þetta er gagnlegt þegar þú ert að gera tegundbreytingu sem getur léttvægt náð en getur einnig þurft sérstaka meðhöndlun.
/// Til dæmis er engin leið að umbreyta [`i64`] í [`i32`] með því að nota [`From`] trait, því [`i64`] getur innihaldið gildi sem [`i32`] getur ekki táknað og því myndi viðskiptin tapa gögnum.
///
/// Þetta gæti verið meðhöndlað með því að stytta [`i64`] í [`i32`] (gefa í raun gildi [`i64`] gildi modulo [`i32::MAX`]) eða einfaldlega með því að skila [`i32::MAX`], eða með einhverri annarri aðferð.
/// [`From`] trait er ætlað til fullkominna viðskipta, þannig að `TryFrom` trait lætur forritarann vita þegar gerð umbreytingar gæti farið illa og leyfir þeim að ákveða hvernig á að höndla það.
///
/// # Almennar útfærslur
///
/// - `TryFrom<T> for U` gefur til kynna [`TryInto`]`<U>fyrir T`</u>
/// - [`try_from`] er viðbragð, sem þýðir að `TryFrom<T> for T` er útfært og getur ekki mistakast-tilheyrandi `Error` gerð til að hringja í `T::try_from()` á gildi af gerðinni `T` er [`Infallible`].
/// Þegar [`!`] gerð er stöðug verður [`Infallible`] og [`!`] jafngilt.
///
/// `TryFrom<T>` er hægt að útfæra sem hér segir:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Eins og lýst er útfærir [`i32`] `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Klæðir `big_number` hljóðlega, krefst þess að greina og meðhöndla styttinguna eftir staðreynd.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Skilar villu vegna þess að `big_number` er of stór til að passa í `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Skilar `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Tegundin sem skilað er ef umreikningsvilla verður.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Framkvæmir umbreytinguna.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// ALMENNT IMPLS
////////////////////////////////////////////////////////////////////////////////

// Sem lyftur yfir&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Sem lyftur yfir &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): skiptu um ofangreind tæki fyrir&/&mut með eftirfarandi almennari:
// // Sem lyftur yfir Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Stærð> AsRef <U>fyrir D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut lyftist yfir &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): skiptu um ofangreindu impl fyrir &mut með eftirfarandi almennari:
// // AsMut lyftist yfir DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Stærð> AsMut <U>fyrir D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Frá felur í sér
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Frá (og þar með inn í) er viðbragð
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Stöðugleikaskýring:** Þetta impl er ekki ennþá til, en við erum "reserving space" til að bæta því við future.
/// Sjá [rust-lang/rust#64715][#64715] fyrir frekari upplýsingar.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): gerðu prinsippfestu í staðinn.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom felur í sér TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Óbreytanleg viðskipti eru merkingarfræðilega jafngild falllausum viðskiptum með óbyggðri villutegund.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// STEYPTU IMPLS
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// ENGAN-VILLA TYPIN
////////////////////////////////////////////////////////////////////////////////

/// Villutegund fyrir villur sem geta aldrei gerst.
///
/// Þar sem þetta enum hefur ekkert afbrigði getur gildi af þessari gerð aldrei raunverulega verið til.
/// Þetta getur verið gagnlegt fyrir almenn API sem nota [`Result`] og stilla villutegundina til að gefa til kynna að niðurstaðan sé alltaf [`Ok`].
///
/// Til dæmis er [`TryFrom`] trait (umbreyting sem skilar [`Result`]) með teppi fyrir allar gerðir þar sem öfug [`Into`] útfærsla er til.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future eindrægni
///
/// Þetta enum hefur sama hlutverk og [the `!`“never”type][never], sem er óstöðugt í þessari útgáfu af Rust.
/// Þegar `!` er stöðugt ætlum við að gera `Infallible` að alias fyrir það:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... og að lokum fyrna `Infallible`.
///
/// Samt sem áður er eitt tilfelli þar sem hægt er að nota `!` setningafræði áður en `!` er komið á stöðugleika sem fullgild gerð: í stöðu afturgerð gerðarinnar.
/// Nánar tiltekið eru mögulegar útfærslur fyrir tvær mismunandi gerðir aðgerðarbendis:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Þar sem `Infallible` er enum er þessi kóði gildur.
/// Hins vegar þegar `Infallible` verður alias fyrir never type, þá byrja " impl`s` að skarast og verða því ekki leyfð af trait samhengisreglum tungumálsins.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}