//! Þetta er innri eining sem notuð er af ifmt!keyrslutími.Þessar mannvirki eru sendar út í kyrrstæðu fylki til að forsníða sniðstrengi fyrir tímann.
//!
//! Þessar skilgreiningar eru svipaðar `ct` ígildum þeirra, en eru mismunandi að því leyti að hægt er að úthluta þeim á statískan hátt og eru aðeins bjartsýni fyrir keyrslutímann
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Mögulegar uppstillingar sem hægt er að biðja um sem hluti af sniðtilskipun.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Vísbending um að innihald ætti að vera vinstra megin.
    Left,
    /// Vísbending um að innihald ætti að vera í réttri röð.
    Right,
    /// Vísbending um að innihald ætti að vera miðlægt.
    Center,
    /// Ekki var óskað eftir jöfnun.
    Unknown,
}

/// Notað af [width](https://doc.rust-lang.org/std/fmt/#width) og [precision](https://doc.rust-lang.org/std/fmt/#precision) skilgreiningum.
#[derive(Copy, Clone)]
pub enum Count {
    /// Tilgreint með bókstaflegri tölu, geymir gildi
    Is(usize),
    /// Tilgreint með `$` og `*` setningafræði, geymir vísitöluna í `args`
    Param(usize),
    /// Ekki tilgreint
    Implied,
}