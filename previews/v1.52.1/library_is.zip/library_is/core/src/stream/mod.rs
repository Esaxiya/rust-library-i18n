//! Samsettur ósamstilltur endurtekning.
//!
//! Ef futures eru ósamstillt gildi, þá eru straumar ósamstilldir endurtekningar.
//! Ef þú hefur fundið þig fyrir ósamstillt safn af einhverju tagi og þarft að framkvæma aðgerð á þáttum téðs safns lendirðu fljótt í 'streams'.
//! Straumar eru mikið notaðir í orðfræðilegum ósamstilltum Rust kóða, svo það er þess virði að kynnast þeim.
//!
//! Áður en við útskýrum meira skulum við ræða hvernig þessi eining er byggð upp:
//!
//! # Organization
//!
//! Þessi eining er að mestu raðað eftir tegundum:
//!
//! * [Traits] eru kjarnahlutinn: þessir traits skilgreina hvers konar læki er til og hvað þú getur gert með þeim.Aðferðir þessara traits eru þess virði að leggja smá auka námstíma í það.
//! * Aðgerðir veita nokkrar gagnlegar leiðir til að búa til nokkur grunnstraum.
//! * Structs eru oft skilategundir hinna ýmsu aðferða á traits þessa einingar.Þú vilt venjulega skoða aðferðina sem býr til `struct`, frekar en `struct` sjálft.
//! Nánari upplýsingar um hvers vegna, sjá '[Implementing Stream](#implement-stream)'.
//!
//! [Traits]: #traits
//!
//! Það er það!Grafum okkur í lækjum.
//!
//! # Stream
//!
//! Hjarta og sál þessa einingar er [`Stream`] trait.Kjarni [`Stream`] lítur svona út:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Ólíkt `Iterator` gerir `Stream` greinarmun á [`poll_next`] aðferðinni sem er notuð við útfærslu `Stream` og (to-be-implemented) `next` aðferð sem er notuð við neyslu á straumi.
//!
//! Neytendur `Stream` þurfa aðeins að huga að `next`, sem þegar kallað er, skilar future sem skilar `Option<Stream::Item>`.
//!
//! future sem `next` skilar mun skila `Some(Item)` svo framarlega sem til eru þættir, og þegar þeir eru allir búnir, mun það skila `None` til að gefa til kynna að endurgerð sé lokið.
//! Ef við erum að bíða eftir einhverju ósamstilltu til að leysa mun future bíða þar til straumurinn er tilbúinn að skila sér aftur.
//!
//! Einstök straumar geta valið að hefja endurtekningu og því að hringja í `next` aftur getur að lokum skilað `Some(Item)` aftur einhvern tíma.
//!
//! Full skilgreining [[Stream]] inniheldur fjölda annarra aðferða líka, en þær eru sjálfgefnar aðferðir, byggðar ofan á [`poll_next`], og svo færðu þær ókeypis.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Framkvæmd Stream
//!
//! Að búa til þinn eigin straum felur í sér tvö skref: að búa til `struct` til að halda ástandi straumsins og síðan útfæra [`Stream`] fyrir þann `struct`.
//!
//! Gerum straum sem heitir `Counter` og telur frá `1` til `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Í fyrsta lagi uppbyggingin:
//!
//! /// Straumur sem telur frá einum upp í fimm
//! struct Counter {
//!     count: usize,
//! }
//!
//! // við viljum að talning okkar byrji á einum, svo við skulum bæta við new() aðferð til að hjálpa.
//! // Þetta er ekki stranglega nauðsynlegt en er þægilegt.
//! // Athugaðu að við byrjum `count` á núlli, við sjáum af hverju í `poll_next()`'s útfærslu hér að neðan.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Síðan útfærum við `Stream` fyrir `Counter` okkar:
//!
//! impl Stream for Counter {
//!     // við munum telja með stærð
//!     type Item = usize;
//!
//!     // poll_next() er eina aðferðin sem krafist er
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Aukið talningu okkar.Þetta er ástæðan fyrir því að við byrjuðum á núlli.
//!         self.count += 1;
//!
//!         // Athugaðu hvort við erum búin að telja eða ekki.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Lækir eru *latir*.Þetta þýðir að bara að búa til straum er ekki _do_ mikið.Ekkert gerist í raun fyrr en þú hringir í `next`.
//! Þetta er stundum uppspretta ruglings þegar búið er til straum eingöngu vegna aukaverkana.
//! Safnarinn mun vara okkur við svona hegðun:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;