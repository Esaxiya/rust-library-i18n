use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// Skilar `true` ef bendillinn er enginn.
    ///
    /// Athugið að óstærðar gerðir hafa marga mögulega núllbendla, þar sem aðeins er tekið tillit til hráa gagnamerkisins, ekki lengd þeirra, vtable osfrv.
    /// Þess vegna geta tvö ábendingar sem eru engin, samt ekki jafnast á við hvort annað.
    ///
    /// ## Hegðun við const mat
    ///
    /// Þegar þessi aðgerð er notuð við konstmat, getur hún skilað `false` fyrir vísbendingar sem reynast vera ógildar við keyrslu.
    /// Nánar tiltekið, þegar vísir að einhverju minni er veginn út fyrir mörk þess á þann hátt að bendillinn sem myndast er enginn, mun aðgerðin samt skila `false`.
    ///
    /// Það er engin leið fyrir CTFE að þekkja algera stöðu þess minnis, þannig að við getum ekki sagt til um hvort bendillinn sé enginn eða ekki.
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Berðu saman í gegnum leikara við þunnan bendil, svo feitir ábendingar eru aðeins að íhuga "data" hlutann sinn fyrir núllleysi.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Varpar til bendis af annarri gerð.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// Niðurbrot (hugsanlega breiður) bendill í er heimilisfang og lýsigagnahluti.
    ///
    /// Síðan er hægt að endurgera bendilinn með [`from_raw_parts_mut`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// Skilar `None` ef bendillinn er enginn eða skilar sameiginlegri tilvísun í gildið sem er vafið í `Some`.Ef hugsanlega er uninitialized gildi verður að nota [`as_uninit_ref`] í staðinn.
    ///
    /// Fyrir breytanlegan hliðstæðu, sjá [`as_mut`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// Þegar þú hringir í þessa aðferð þarftu að ganga úr skugga um að *annað hvort* bendillinn sé NULL *eða* allt eftirfarandi er satt:
    ///
    /// * Bendillinn verður að vera rétt stilltur.
    ///
    /// * Það verður að vera "dereferencable" í þeim skilningi sem skilgreint er í [the module documentation].
    ///
    /// * Bendillinn verður að benda á frumstillt dæmi um `T`.
    ///
    /// * Þú verður að framfylgja alias reglum Rust, þar sem skilað líftími `'a` er valinn geðþótta og endurspeglar ekki endilega raunverulegan líftíma gagnanna.
    ///   Sérstaklega, meðan á þessari líftíma stendur, má minni sem bendillinn bendir á ekki verða stökkbreytt (nema inni í `UnsafeCell`).
    ///
    /// Þetta á við þó niðurstaðan af þessari aðferð sé ónotuð!
    /// (Hlutinn um frumstilling er ekki enn ákveðinn að fullu, en þangað til það er, er eina örugga leiðin að tryggja að þeir séu örugglega frumstilltir.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Útgáfa sem ekki er hakað við
    ///
    /// Ef þú ert viss um að bendillinn geti aldrei verið enginn og ert að leita að einhvers konar `as_ref_unchecked` sem skilar `&T` í stað `Option<&T>`, vitaðu að þú getur dregið bendilinn beint.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // ÖRYGGI: sá sem hringir þarf að ábyrgjast að `self` gildi fyrir a
        // tilvísun ef það er ekki núll.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Skilar `None` ef bendillinn er enginn, eða skilar sameiginlegri tilvísun í gildið sem er vafið í `Some`.
    /// Öfugt við [`as_ref`], þetta krefst ekki þess að upphafið verði.
    ///
    /// Fyrir breytanlegan hliðstæðu, sjá [`as_uninit_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// Þegar þú hringir í þessa aðferð þarftu að ganga úr skugga um að *annað hvort* bendillinn sé NULL *eða* allt eftirfarandi er satt:
    ///
    /// * Bendillinn verður að vera rétt stilltur.
    ///
    /// * Það verður að vera "dereferencable" í þeim skilningi sem skilgreint er í [the module documentation].
    ///
    /// * Þú verður að framfylgja alias reglum Rust, þar sem skilað líftími `'a` er valinn geðþótta og endurspeglar ekki endilega raunverulegan líftíma gagnanna.
    ///
    ///   Sérstaklega, meðan á þessari líftíma stendur, má minni sem bendillinn bendir á ekki verða stökkbreytt (nema inni í `UnsafeCell`).
    ///
    /// Þetta á við þó niðurstaðan af þessari aðferð sé ónotuð!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // ÖRYGGI: sá sem hringir þarf að ábyrgjast að `self` uppfylli öll
        // kröfur um tilvísun.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Reiknar frávik frá bendi.
    ///
    /// `count` er í einingum T;td, `count` af 3 táknar á móti `3 * size_of::<T>()` bæti.
    ///
    /// # Safety
    ///
    /// Ef einhver af eftirfarandi skilyrðum er brotin er niðurstaðan Óskilgreind hegðun:
    ///
    /// * Bæði upphafs bendillinn og sá sem myndast verður að vera annað hvort í mörkum eða einu bæti framhjá enda sama úthlutaðs hlutar.
    /// Athugaðu að í Rust er hver (stack-allocated) breyta talin sérstakt úthlutað hlut.
    ///
    /// * Reiknað offset,**í bæti**, getur ekki flætt yfir `isize`.
    ///
    /// * Jöfnunin sem er innan marka getur ekki reitt sig á "wrapping around" heimilisfangarýmið.Það er óendanlega nákvæmni summan,**í bæti**, verður að passa í stærð.
    ///
    /// Í þýðanda og venjulegu bókasafni er almennt reynt að tryggja að úthlutun nái aldrei stærð þar sem mótvægi er áhyggjuefni.
    /// Til dæmis, `Vec` og `Box` tryggja að þeir úthluta aldrei meira en `isize::MAX` bæti, svo `vec.as_ptr().add(vec.len())` er alltaf öruggur.
    ///
    /// Flestir pallar geta í grundvallaratriðum ekki einu sinni smíðað slíka úthlutun.
    /// Til dæmis, enginn þekktur 64-bita vettvangur getur nokkru sinni þjónað beiðni um 2 <sup>63</sup> bæti vegna takmarkana á blaðsíðutöflu eða sundurliðunar heimilisfangsrýmis.
    /// Hins vegar geta sumir 32-bita og 16-bita kerfi með góðum árangri þjónað beiðni um meira en `isize::MAX` bæti með hlutum eins og framlengingu á heimilisfangi.
    ///
    /// Sem slíkt getur minni sem er aflað beint frá úthlutunaraðilum eða minniskortaðar skrár *verið* of stórt til að takast á við þessa aðgerð.
    ///
    /// Íhugaðu að nota [`wrapping_offset`] í staðinn ef þessar skorður eru erfiðar að fullnægja.
    /// Eini kosturinn við þessa aðferð er að hún gerir grimmari hagræðingu þýðanda kleift.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `offset`.
        // Mæli sem fæst er gildur fyrir skrif þar sem hringirinn verður að ábyrgjast að hann vísi á sama úthlutaða hlut og `self`.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// Reiknar frávikið frá bendi með því að nota umbúðarreikning.
    /// `count` er í einingum T;td, `count` af 3 táknar á móti `3 * size_of::<T>()` bæti.
    ///
    /// # Safety
    ///
    /// Þessi aðgerð í sjálfu sér er alltaf örugg en með því að nota bendilinn sem myndast er það ekki.
    ///
    /// Bendillinn sem myndast er áfram festur við sama úthlutaða hlutinn og `self` bendir á.
    /// Það má *ekki* nota það til að fá aðgang að öðrum úthlutuðum hlut.Athugaðu að í Rust er hver (stack-allocated) breyta talin sérstakt úthlutað hlut.
    ///
    /// Með öðrum orðum, `let z = x.wrapping_offset((y as isize) - (x as isize))` gerir *ekki*`z` það sama og `y`, jafnvel þó við gerum ráð fyrir að `T` hafi stærð `1` og það er ekkert flæði: `z` er ennþá fest við hlutinn `x` er fest við, og aðferðir um það er óskilgreint hegðun nema `x` og `y` benda í sama úthlutaða hlut.
    ///
    /// Í samanburði við [`offset`] tefur þessi aðferð í grundvallaratriðum kröfuna um að vera innan sama úthlutaðs hlutar: [`offset`] er strax óskilgreind hegðun þegar farið er yfir hlutamörk;`wrapping_offset` framleiðir bendi en leiðir samt til Óskilgreindrar hegðunar ef bendir eru annars vísaðir þegar hann er utan marka hlutarins sem hann er festur við.
    /// [`offset`] hægt að fínstilla betur og er þannig æskilegra í frammistöðuviðkvæmum kóða.
    ///
    /// Seinkaða athugunin tekur aðeins mið af gildi bendilsins sem var vísað til annars en ekki milligildin sem notuð voru við útreikning á lokaniðurstöðunni.
    /// Til dæmis er `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` alltaf það sama og `x`.Með öðrum orðum, það er leyfilegt að yfirgefa hlutinn sem er úthlutað og fara aftur inn í hann síðar.
    ///
    /// Ef þú þarft að fara yfir hlutamörk skaltu kasta bendlinum að heiltölu og gera reikninginn þar.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// // Iterate með því að nota hráan bendil í þrepum tveggja þátta
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // ÖRYGGI: `arith_offset` innri hefur engar forsendur til að geta kallast á.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// Skilar `None` ef bendillinn er enginn, eða annars skilar einstök tilvísun í gildið sem er vafið í `Some`.Ef hugsanlega er uninitialized gildi verður að nota [`as_uninit_mut`] í staðinn.
    ///
    /// Fyrir hlutaðeigandi hliðstæðu sjá [`as_ref`].
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// Þegar þú hringir í þessa aðferð þarftu að ganga úr skugga um að *annað hvort* bendillinn sé NULL *eða* allt eftirfarandi er satt:
    ///
    /// * Bendillinn verður að vera rétt stilltur.
    ///
    /// * Það verður að vera "dereferencable" í þeim skilningi sem skilgreint er í [the module documentation].
    ///
    /// * Bendillinn verður að benda á frumstillt dæmi um `T`.
    ///
    /// * Þú verður að framfylgja alias reglum Rust, þar sem skilað líftími `'a` er valinn geðþótta og endurspeglar ekki endilega raunverulegan líftíma gagnanna.
    ///   Sérstaklega, meðan á þessari ævi stendur, má ekki nálgast (lesa eða skrifa) minnið sem bendillinn bendir á í gegnum neinn annan bendil.
    ///
    /// Þetta á við þó niðurstaðan af þessari aðferð sé ónotuð!
    /// (Hlutinn um frumstilling er ekki enn ákveðinn að fullu, en þangað til það er, er eina örugga leiðin að tryggja að þeir séu örugglega frumstilltir.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Það mun prenta: "[4, 2, 3]".
    /// ```
    ///
    /// # Útgáfa sem ekki er hakað við
    ///
    /// Ef þú ert viss um að bendillinn geti aldrei verið enginn og ert að leita að einhvers konar `as_mut_unchecked` sem skilar `&mut T` í stað `Option<&mut T>`, vitaðu að þú getur dregið bendilinn beint.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Það mun prenta: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // ÖRYGGI: sá sem hringir verður að ábyrgjast að `self` gildi fyrir
        // breytanleg tilvísun ef hún er ekki núll.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// Skilar `None` ef bendillinn er enginn, eða annars skilar einstök tilvísun í gildið sem er vafið í `Some`.
    /// Öfugt við [`as_mut`], þetta krefst ekki þess að upphafið verði.
    ///
    /// Fyrir hlutaðeigandi hliðstæðu sjá [`as_uninit_ref`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// Þegar þú hringir í þessa aðferð þarftu að ganga úr skugga um að *annað hvort* bendillinn sé NULL *eða* allt eftirfarandi er satt:
    ///
    /// * Bendillinn verður að vera rétt stilltur.
    ///
    /// * Það verður að vera "dereferencable" í þeim skilningi sem skilgreint er í [the module documentation].
    ///
    /// * Þú verður að framfylgja alias reglum Rust, þar sem skilað líftími `'a` er valinn geðþótta og endurspeglar ekki endilega raunverulegan líftíma gagnanna.
    ///
    ///   Sérstaklega, meðan á þessari ævi stendur, má ekki nálgast (lesa eða skrifa) minnið sem bendillinn bendir á í gegnum neinn annan bendil.
    ///
    /// Þetta á við þó niðurstaðan af þessari aðferð sé ónotuð!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // ÖRYGGI: sá sem hringir þarf að ábyrgjast að `self` uppfylli öll
        // kröfur um tilvísun.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// Skilar hvort tveir ábendingar séu tryggðir jafnir.
    ///
    /// Við keyrslu hegðar þessi aðgerð sig eins og `self == other`.
    /// Hins vegar er ekki alltaf hægt að ákvarða jafnrétti tveggja ábendinga í sumu samhengi (td mat á samantektartíma), þannig að þessi aðgerð getur falið að skila `false` fyrir ábendingar sem síðar reynast vera jafnar.
    ///
    /// En þegar það skilar `true` er víst að ábendingarnar eru jafnar.
    ///
    /// Þessi aðgerð er spegill [`guaranteed_ne`], en ekki andhverfur hennar.Það eru samanburðarbendir sem báðar aðgerðir skila `false` fyrir.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Skilagildið getur breyst eftir þýðandaútgáfunni og óöruggur kóði reiðir sig kannski ekki á niðurstöðuna af þessari aðgerð til að vera traustur.
    /// Mælt er með því að nota þessa aðgerð eingöngu til hagræðingar á frammistöðu þar sem svikin `false` skilagildi með þessari aðgerð hafa ekki áhrif á útkomuna, heldur bara árangurinn.
    /// Afleiðingar þess að nota þessa aðferð til að láta afturkreistingur og safna tíma kóða hegða sér öðruvísi hafa ekki verið kannaðir.
    /// Ekki ætti að nota þessa aðferð til að kynna slíkan mun og það ætti heldur ekki að koma á stöðugleika áður en við höfum betri skilning á þessu máli.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// Skilar hvort tveggja vísbendingar séu tryggðar misjafnar.
    ///
    /// Við keyrslu hegðar þessi aðgerð sig eins og `self != other`.
    /// Hins vegar er ekki alltaf hægt að ákvarða ójöfnuð tveggja vísbendinga í sumum samhengi (td mat á samantektartíma) og því getur þessi aðgerð skilað af sér `false` fyrir ábendingar sem síðar reynast vera misjafnar.
    ///
    /// En þegar það skilar `true` er víst að ábendingarnar eru misjafnar.
    ///
    /// Þessi aðgerð er spegill [`guaranteed_eq`], en ekki andhverfur hennar.Það eru samanburðarbendir sem báðar aðgerðir skila `false` fyrir.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Skilagildið getur breyst eftir þýðandaútgáfunni og óöruggur kóði reiðir sig kannski ekki á niðurstöðuna af þessari aðgerð til að vera traustur.
    /// Mælt er með því að nota þessa aðgerð eingöngu til hagræðingar á frammistöðu þar sem svikin `false` skilagildi með þessari aðgerð hafa ekki áhrif á útkomuna, heldur bara árangurinn.
    /// Afleiðingar þess að nota þessa aðferð til að láta afturkreistingur og safna tíma kóða hegða sér öðruvísi hafa ekki verið kannaðir.
    /// Ekki ætti að nota þessa aðferð til að kynna slíkan mun og það ætti heldur ekki að koma á stöðugleika áður en við höfum betri skilning á þessu máli.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// Reiknar fjarlægðina milli tveggja ábendinga.Skilað gildi er í einingum af T: fjarlægðin í bætum er deilt með `mem::size_of::<T>()`.
    ///
    /// Þessi aðgerð er andhverfa [`offset`].
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// Ef einhver af eftirfarandi skilyrðum er brotin er niðurstaðan Óskilgreind hegðun:
    ///
    /// * Bæði upphafs-og annar bendill verður að vera annað hvort í mörkum eða einu bæti framhjá enda sama úthlutaðs hlutar.
    /// Athugaðu að í Rust er hver (stack-allocated) breyta talin sérstakt úthlutað hlut.
    ///
    /// * Báðir ábendingar verða að vera *fengnar frá* bendi að sama hlutnum.
    ///   (Sjá dæmi hér að neðan.)
    ///
    /// * Fjarlægðin milli ábendinganna, í bætum, verður að vera nákvæm margfeldi af stærðinni `T`.
    ///
    /// * Fjarlægðin milli ábendinganna,**í bæti**, getur ekki flætt yfir `isize`.
    ///
    /// * Fjarlægðin sem er innan marka getur ekki reitt sig á "wrapping around" heimilisfangarýmið.
    ///
    /// Rust gerðir eru aldrei stærri en `isize::MAX` og Rust úthlutun vafast aldrei um heimilisfangsvæðið, þannig að tvö vísbendingar innan einhvers gildi hvers Rust gerð `T` uppfylla alltaf síðustu tvö skilyrði.
    ///
    /// Venjulegt bókasafn tryggir einnig almennt að úthlutun nái aldrei stærð þar sem offset er áhyggjuefni.
    /// Til dæmis, `Vec` og `Box` tryggja að þeir úthluta aldrei meira en `isize::MAX` bæti, þannig að `ptr_into_vec.offset_from(vec.as_ptr())` uppfyllir alltaf síðustu tvö skilyrði.
    ///
    /// Flestir pallar geta í grundvallaratriðum ekki einu sinni smíðað svo mikla úthlutun.
    /// Til dæmis, enginn þekktur 64-bita vettvangur getur nokkru sinni þjónað beiðni um 2 <sup>63</sup> bæti vegna takmarkana á blaðsíðutöflu eða sundurliðunar heimilisfangsrýmis.
    /// Hins vegar geta sumir 32-bita og 16-bita kerfi með góðum árangri þjónað beiðni um meira en `isize::MAX` bæti með hlutum eins og framlengingu á heimilisfangi.
    /// Sem slíkt getur minni sem er aflað beint frá úthlutunaraðilum eða minniskortaðar skrár *verið* of stórt til að takast á við þessa aðgerð.
    /// (Athugaðu að [`offset`] og [`add`] hafa einnig svipaða takmörkun og geta því ekki verið notaðar við svo stórar úthlutanir heldur.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Þessi aðgerð panics ef `T` er núllstærð gerð ("ZST").
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Rangt* notkun:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Gerðu ptr2_other að "alias" af ptr2, en dregið af ptr1.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Þar sem ptr2_other og ptr2 eru fengin frá ábendingum í mismunandi hluti, er útreikningur á móti þeirra óskilgreindur hegðun, jafnvel þó að þeir bendi á sama heimilisfang!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Óskilgreind hegðun
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `offset_from`.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Reiknar frávik frá bendi (þægindi fyrir `.offset(count as isize)`).
    ///
    /// `count` er í einingum T;td, `count` af 3 táknar á móti `3 * size_of::<T>()` bæti.
    ///
    /// # Safety
    ///
    /// Ef einhver af eftirfarandi skilyrðum er brotin er niðurstaðan Óskilgreind hegðun:
    ///
    /// * Bæði upphafs bendillinn og sá sem myndast verður að vera annað hvort í mörkum eða einu bæti framhjá enda sama úthlutaðs hlutar.
    /// Athugaðu að í Rust er hver (stack-allocated) breyta talin sérstakt úthlutað hlut.
    ///
    /// * Reiknað offset,**í bæti**, getur ekki flætt yfir `isize`.
    ///
    /// * Jöfnunin sem er innan marka getur ekki reitt sig á "wrapping around" heimilisfangarýmið.Það er, óendanlega nákvæmni summan verður að passa í `usize`.
    ///
    /// Í þýðanda og venjulegu bókasafni er almennt reynt að tryggja að úthlutun nái aldrei stærð þar sem mótvægi er áhyggjuefni.
    /// Til dæmis, `Vec` og `Box` tryggja að þeir úthluta aldrei meira en `isize::MAX` bæti, svo `vec.as_ptr().add(vec.len())` er alltaf öruggur.
    ///
    /// Flestir pallar geta í grundvallaratriðum ekki einu sinni smíðað slíka úthlutun.
    /// Til dæmis, enginn þekktur 64-bita vettvangur getur nokkru sinni þjónað beiðni um 2 <sup>63</sup> bæti vegna takmarkana á blaðsíðutöflu eða sundurliðunar heimilisfangsrýmis.
    /// Hins vegar geta sumir 32-bita og 16-bita kerfi með góðum árangri þjónað beiðni um meira en `isize::MAX` bæti með hlutum eins og framlengingu á heimilisfangi.
    ///
    /// Sem slíkt getur minni sem er aflað beint frá úthlutunaraðilum eða minniskortaðar skrár *verið* of stórt til að takast á við þessa aðgerð.
    ///
    /// Íhugaðu að nota [`wrapping_add`] í staðinn ef þessar skorður eru erfiðar að fullnægja.
    /// Eini kosturinn við þessa aðferð er að hún gerir grimmari hagræðingu þýðanda kleift.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Reiknar offsetið frá bendi (þægindi fyrir `. Offset ((teljist isize).wrapping_neg())`).
    ///
    /// `count` er í einingum T;td, `count` af 3 táknar á móti `3 * size_of::<T>()` bæti.
    ///
    /// # Safety
    ///
    /// Ef einhver af eftirfarandi skilyrðum er brotin er niðurstaðan Óskilgreind hegðun:
    ///
    /// * Bæði upphafs bendillinn og sá sem myndast verður að vera annað hvort í mörkum eða einu bæti framhjá enda sama úthlutaðs hlutar.
    /// Athugaðu að í Rust er hver (stack-allocated) breyta talin sérstakt úthlutað hlut.
    ///
    /// * Reiknað offset má ekki fara yfir `isize::MAX`**bæti**.
    ///
    /// * Jöfnunin sem er innan marka getur ekki reitt sig á "wrapping around" heimilisfangarýmið.Það er, óendanlega nákvæmni summan verður að passa í stærð.
    ///
    /// Í þýðanda og venjulegu bókasafni er almennt reynt að tryggja að úthlutun nái aldrei stærð þar sem mótvægi er áhyggjuefni.
    /// Til dæmis, `Vec` og `Box` tryggja að þeir úthluta aldrei meira en `isize::MAX` bæti, svo `vec.as_ptr().add(vec.len()).sub(vec.len())` er alltaf öruggur.
    ///
    /// Flestir pallar geta í grundvallaratriðum ekki einu sinni smíðað slíka úthlutun.
    /// Til dæmis, enginn þekktur 64-bita vettvangur getur nokkru sinni þjónað beiðni um 2 <sup>63</sup> bæti vegna takmarkana á blaðsíðutöflu eða sundurliðunar heimilisfangsrýmis.
    /// Hins vegar geta sumir 32-bita og 16-bita kerfi með góðum árangri þjónað beiðni um meira en `isize::MAX` bæti með hlutum eins og framlengingu á heimilisfangi.
    ///
    /// Sem slíkt getur minni sem er aflað beint frá úthlutunaraðilum eða minniskortaðar skrár *verið* of stórt til að takast á við þessa aðgerð.
    ///
    /// Íhugaðu að nota [`wrapping_sub`] í staðinn ef þessar skorður eru erfiðar að fullnægja.
    /// Eini kosturinn við þessa aðferð er að hún gerir grimmari hagræðingu þýðanda kleift.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Reiknar frávikið frá bendi með því að nota umbúðarreikning.
    /// (þægindi fyrir `.wrapping_offset(count as isize)`)
    ///
    /// `count` er í einingum T;td, `count` af 3 táknar á móti `3 * size_of::<T>()` bæti.
    ///
    /// # Safety
    ///
    /// Þessi aðgerð í sjálfu sér er alltaf örugg en með því að nota bendilinn sem myndast er það ekki.
    ///
    /// Bendillinn sem myndast er áfram festur við sama úthlutaða hlutinn og `self` bendir á.
    /// Það má *ekki* nota það til að fá aðgang að öðrum úthlutuðum hlut.Athugaðu að í Rust er hver (stack-allocated) breyta talin sérstakt úthlutað hlut.
    ///
    /// Með öðrum orðum, `let z = x.wrapping_add((y as usize) - (x as usize))` gerir *ekki*`z` það sama og `y`, jafnvel þó að við gerum ráð fyrir að `T` hafi stærð `1` og það er ekkert flæði: `z` er ennþá fest við hlutinn `x` er festur við, og aðferða það er óskilgreint hegðun nema `x` og `y` benda í sama úthlutaða hlut.
    ///
    /// Í samanburði við [`add`] tefur þessi aðferð í grundvallaratriðum kröfuna um að vera innan sama úthlutaðs hlutar: [`add`] er strax óskilgreind hegðun þegar farið er yfir hlutamörk;`wrapping_add` framleiðir bendi en leiðir samt til Óskilgreindrar hegðunar ef bendir eru annars vísaðir þegar hann er utan marka hlutarins sem hann er festur við.
    /// [`add`] hægt að fínstilla betur og er þannig æskilegra í frammistöðuviðkvæmum kóða.
    ///
    /// Seinkaða athugunin tekur aðeins mið af gildi bendilsins sem var vísað til annars en ekki milligildin sem notuð voru við útreikning á lokaniðurstöðunni.
    /// Til dæmis er `x.wrapping_add(o).wrapping_sub(o)` alltaf það sama og `x`.Með öðrum orðum, það er leyfilegt að yfirgefa hlutinn sem er úthlutað og fara aftur inn í hann síðar.
    ///
    /// Ef þú þarft að fara yfir hlutamörk skaltu kasta bendlinum að heiltölu og gera reikninginn þar.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// // Iterate með því að nota hráan bendil í þrepum tveggja þátta
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Þessi lykkja prentar "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Reiknar frávikið frá bendi með því að nota umbúðarreikning.
    /// (þægindi fyrir `.wrapping_offset ((teljist isize).wrapping_neg())`)
    ///
    /// `count` er í einingum T;td, `count` af 3 táknar á móti `3 * size_of::<T>()` bæti.
    ///
    /// # Safety
    ///
    /// Þessi aðgerð í sjálfu sér er alltaf örugg en með því að nota bendilinn sem myndast er það ekki.
    ///
    /// Bendillinn sem myndast er áfram festur við sama úthlutaða hlutinn og `self` bendir á.
    /// Það má *ekki* nota það til að fá aðgang að öðrum úthlutuðum hlut.Athugaðu að í Rust er hver (stack-allocated) breyta talin sérstakt úthlutað hlut.
    ///
    /// Með öðrum orðum, `let z = x.wrapping_sub((x as usize) - (y as usize))` gerir *ekki*`z` það sama og `y`, jafnvel þó við gerum ráð fyrir að `T` hafi stærð `1` og það er ekkert flæði: `z` er ennþá fest við hlutinn `x` er fest við, og aðferðir um það er óskilgreint hegðun nema `x` og `y` benda í sama úthlutaða hlut.
    ///
    /// Í samanburði við [`sub`] tefur þessi aðferð í grundvallaratriðum kröfuna um að vera innan sama úthlutaðs hlutar: [`sub`] er strax óskilgreind hegðun þegar farið er yfir hlutamörk;`wrapping_sub` framleiðir bendi en leiðir samt til Óskilgreindrar hegðunar ef bendir eru annars vísaðir þegar hann er utan marka hlutarins sem hann er festur við.
    /// [`sub`] hægt að fínstilla betur og er þannig æskilegra í frammistöðuviðkvæmum kóða.
    ///
    /// Seinkaða athugunin tekur aðeins mið af gildi bendilsins sem var vísað til annars en ekki milligildin sem notuð voru við útreikning á lokaniðurstöðunni.
    /// Til dæmis er `x.wrapping_add(o).wrapping_sub(o)` alltaf það sama og `x`.Með öðrum orðum, það er leyfilegt að yfirgefa hlutinn sem er úthlutað og fara aftur inn í hann síðar.
    ///
    /// Ef þú þarft að fara yfir hlutamörk skaltu kasta bendlinum að heiltölu og gera reikninginn þar.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Grunn notkun:
    ///
    /// ```
    /// // Iterate með því að nota hráan bendil í þrepum tveggja þátta (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Þessi lykkja prentar "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Stillir gildi bendilsins á `ptr`.
    ///
    /// Ef `self` er (fat) bendill af óstærðri gerð hefur þessi aðgerð aðeins áhrif á bendilhlutann, en fyrir (thin) vísbendingar í stærðar gerðir hefur þetta sömu áhrif og einfalt verkefni.
    ///
    /// Bendillinn sem myndast mun hafa uppruna `val`, þ.e. fyrir fitubendir, þessi aðgerð er merkingarlega sú sama og að búa til nýjan fitubendil með gagnabendigildið `val` en lýsigögnin `self`.
    ///
    ///
    /// # Examples
    ///
    /// Þessi aðgerð er fyrst og fremst gagnleg til að leyfa byte-vísu bendilreikninga á mögulega fitubindum:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // mun prenta "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // ÖRYGGI: Ef um þunnan bendil er að ræða er þessi aðgerð eins
        // að einföldu verkefni.
        // Ef um er að ræða fitubendil, með núverandi útfærslu fitubendis, er fyrsti reitur slíks bendis alltaf gagnabendillinn, sem er sömuleiðis úthlutað.
        //
        unsafe { *thin = val };
        self
    }

    /// Lestur gildi frá `self` án þess að færa það.
    /// Þetta skilur minnið eftir í `self` óbreytt.
    ///
    /// Sjá [`ptr::read`] varðandi öryggisatriði og dæmi.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir ``.
        unsafe { read(self) }
    }

    /// Framkvæmir sveiflukennda aflestur af gildinu frá `self` án þess að hreyfa það.Þetta skilur minnið eftir í `self` óbreytt.
    ///
    /// Rokgjarnar aðgerðir eru ætlaðar til að starfa á I/O minni og þær eru tryggðar að þeim verður ekki breytt eða endurraðað af þýðandanum yfir aðrar sveiflukenndar aðgerðir.
    ///
    ///
    /// Sjá [`ptr::read_volatile`] varðandi öryggisatriði og dæmi.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Lestur gildi frá `self` án þess að færa það.
    /// Þetta skilur minnið eftir í `self` óbreytt.
    ///
    /// Ólíkt `read` getur bendillinn verið ósamræmdur.
    ///
    /// Sjá [`ptr::read_unaligned`] varðandi öryggisatriði og dæmi.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Afritar `count * size_of<T>` bæti frá `self` til `dest`.
    /// Uppruni og ákvörðunarstaður geta skarast.
    ///
    /// NOTE: þetta hefur *sömu* rökröðun og [`ptr::copy`].
    ///
    /// Sjá [`ptr::copy`] varðandi öryggisatriði og dæmi.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Afritar `count * size_of<T>` bæti frá `self` til `dest`.
    /// Uppruni og ákvörðunarstaður mega *ekki* skarast.
    ///
    /// NOTE: þetta hefur *sömu* rökröðun og [`ptr::copy_nonoverlapping`].
    ///
    /// Sjá [`ptr::copy_nonoverlapping`] varðandi öryggisatriði og dæmi.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Afritar `count * size_of<T>` bæti frá `src` til `self`.
    /// Uppruni og ákvörðunarstaður geta skarast.
    ///
    /// NOTE: þetta hefur *andstæða* röksemdaröð [`ptr::copy`].
    ///
    /// Sjá [`ptr::copy`] varðandi öryggisatriði og dæmi.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `copy`.
        unsafe { copy(src, self, count) }
    }

    /// Afritar `count * size_of<T>` bæti frá `src` til `self`.
    /// Uppruni og ákvörðunarstaður mega *ekki* skarast.
    ///
    /// NOTE: þetta hefur *andstæða* röksemdaröð [`ptr::copy_nonoverlapping`].
    ///
    /// Sjá [`ptr::copy_nonoverlapping`] varðandi öryggisatriði og dæmi.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// Framkvæmir eyðileggjanda (ef einhver er) sem bent er á gildi.
    ///
    /// Sjá [`ptr::drop_in_place`] varðandi öryggisatriði og dæmi.
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `drop_in_place`.
        unsafe { drop_in_place(self) }
    }

    /// Yfirskrifar minni staðsetningu með gefnu gildi án þess að lesa eða sleppa gamla gildinu.
    ///
    ///
    /// Sjá [`ptr::write`] varðandi öryggisatriði og dæmi.
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `write`.
        unsafe { write(self, val) }
    }

    /// Kallar á memset á tilgreindum bendi og stillir `count * size_of::<T>()` bæti af minni sem byrjar á `self` til `val`.
    ///
    ///
    /// Sjá [`ptr::write_bytes`] varðandi öryggisatriði og dæmi.
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `write_bytes`.
        unsafe { write_bytes(self, val, count) }
    }

    /// Framkvæmir sveiflukenndan skrif af minnisstað með gefnu gildi án þess að lesa eða sleppa gamla gildinu.
    ///
    /// Rokgjarnar aðgerðir eru ætlaðar til að starfa á I/O minni og þær eru tryggðar að þeim verður ekki breytt eða endurraðað af þýðandanum yfir aðrar sveiflukenndar aðgerðir.
    ///
    ///
    /// Sjá [`ptr::write_volatile`] varðandi öryggisatriði og dæmi.
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `write_volatile`.
        unsafe { write_volatile(self, val) }
    }

    /// Yfirskrifar minni staðsetningu með gefnu gildi án þess að lesa eða sleppa gamla gildinu.
    ///
    ///
    /// Ólíkt `write` getur bendillinn verið ósamræmdur.
    ///
    /// Sjá [`ptr::write_unaligned`] varðandi öryggisatriði og dæmi.
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `write_unaligned`.
        unsafe { write_unaligned(self, val) }
    }

    /// Skiptir um gildi við `self` fyrir `src`, skilar gamla gildinu, án þess að detta niður.
    ///
    ///
    /// Sjá [`ptr::replace`] varðandi öryggisatriði og dæmi.
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `replace`.
        unsafe { replace(self, src) }
    }

    /// Skiptir um gildi á tveimur stökkbreytanlegum stöðum af sömu gerð, án þess að afnema hvort heldur.
    /// Þeir geta skarast, ólíkt `mem::swap` sem ella jafngildir.
    ///
    /// Sjá [`ptr::swap`] varðandi öryggisatriði og dæmi.
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `swap`.
        unsafe { swap(self, with) }
    }

    /// Reiknar offsetið sem þarf að beita á bendilinn til að gera það í takt við `align`.
    ///
    /// Ef ekki er hægt að stilla bendilinn skilar framkvæmdin `usize::MAX`.
    /// Leyfilegt er að útfærslan * skili alltaf `usize::MAX`.
    /// Aðeins árangur reikniritsins getur ráðist af því að fá nothæfan móti hér en ekki réttmæti hans.
    ///
    /// Jöfnunin er gefin upp í fjölda `T` þátta, en ekki bæti.Gildið sem skilað er er hægt að nota með `wrapping_add` aðferðinni.
    ///
    /// Það eru engar ábyrgðir yfir höfuð að mótvægi bendilsins flæðist ekki yfir eða fer umfram úthlutunina sem bendillinn bendir á.
    ///
    /// Það er hringjandans að sjá til þess að mótfallið sem er skilað sé rétt í öllum skilmálum öðrum en jöfnun.
    ///
    /// # Panics
    ///
    /// Aðgerðin panics ef `align` er ekki máttur tveggja.
    ///
    /// # Examples
    ///
    /// Aðgangur að aðliggjandi `u8` sem `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // meðan hægt er að stilla bendilinn í gegnum `offset`, þá myndi hann benda utan úthlutunarinnar
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // ÖRYGGI: `align` hefur verið merktur með styrk 2 hér að ofan
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// Skilar lengd hrárar sneiðar.
    ///
    /// Skilað gildi er fjöldi **þátta**, ekki fjöldi bæti.
    ///
    /// Þessi aðgerð er örugg, jafnvel þegar ekki er hægt að steypa hráu sneiðina í sneiðatilvísun vegna þess að bendillinn er enginn eða óbreyttur.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // ÖRYGGI: þetta er öruggt vegna þess að `*const [T]` og `FatPtr<T>` eru með sama skipulag.
            // Aðeins `std` getur veitt þessa ábyrgð.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Skilar hráum bendli í biðminni sneiðarinnar.
    ///
    /// Þetta jafngildir því að steypa `self` í `*mut T`, en meira gerðaröryggi.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// Skilar hráum músarbendi í frumefni eða undirþrep, án þess að gera mörkin.
    ///
    /// Að hringja í þessa aðferð með vísitölu utan marka eða þegar `self` er ekki hægt að vísa til er *[óskilgreint atferli]*, jafnvel þó bendillinn sem myndast er ekki notaður.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // ÖRYGGI: sá sem hringir tryggir að `self` sé færanlegur og `index` innan marka.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// Skilar `None` ef bendillinn er enginn, eða skilar sameiginlegri sneið að gildinu sem er vafið í `Some`.
    /// Öfugt við [`as_ref`], þetta krefst ekki þess að upphafið verði.
    ///
    /// Fyrir breytanlegan hliðstæðu, sjá [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Þegar þú hringir í þessa aðferð þarftu að ganga úr skugga um að *annað hvort* bendillinn sé NULL *eða* allt eftirfarandi er satt:
    ///
    /// * Bendillinn verður að vera [valid] til að lesa fyrir `ptr.len() * mem::size_of::<T>()` mörg bæti og hann verður að vera rétt stilltur.Þetta þýðir sérstaklega:
    ///
    ///     * Allt minnissvið þessarar sneiðar verður að vera innan eins úthlutaðs hlutar!
    ///       Sneiðar geta aldrei spannað yfir marga úthlutaða hluti.
    ///
    ///     * Bendillinn verður að vera samstilltur, jafnvel fyrir sneiðar í núlllengd.
    ///     Ein ástæðan fyrir þessu er sú að fínstillingar enum skipulags geta reitt sig á að tilvísanir (þ.m.t. sneiðar af hvaða lengd sem er) séu samstilltar og ekki núllar til að greina þær frá öðrum gögnum.
    ///
    ///     Þú getur fengið bendi sem er nothæfur sem `data` fyrir sneiðar án lengdar með því að nota [`NonNull::dangling()`].
    ///
    /// * Heildarstærð `ptr.len() * mem::size_of::<T>()` sneiðarinnar má ekki vera stærri en `isize::MAX`.
    ///   Sjá öryggisgögn [`pointer::offset`].
    ///
    /// * Þú verður að framfylgja alias reglum Rust, þar sem skilað líftími `'a` er valinn geðþótta og endurspeglar ekki endilega raunverulegan líftíma gagnanna.
    ///   Sérstaklega, meðan á þessari líftíma stendur, má minni sem bendillinn bendir á ekki verða stökkbreytt (nema inni í `UnsafeCell`).
    ///
    /// Þetta á við þó niðurstaðan af þessari aðferð sé ónotuð!
    ///
    /// Sjá einnig [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// Skilar `None` ef bendillinn er enginn, eða skilar einstökum sneið í gildið sem er vafið í `Some`.
    /// Öfugt við [`as_mut`], þetta krefst ekki þess að upphafið verði.
    ///
    /// Fyrir hlutaðeigandi hliðstæðu sjá [`as_uninit_slice`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// Þegar þú hringir í þessa aðferð þarftu að ganga úr skugga um að *annað hvort* bendillinn sé NULL *eða* allt eftirfarandi er satt:
    ///
    /// * Bendillinn verður að vera [valid] til að lesa og skrifa fyrir `ptr.len() * mem::size_of::<T>()` mörg bæti og hann verður að vera rétt stilltur.Þetta þýðir sérstaklega:
    ///
    ///     * Allt minnissvið þessarar sneiðar verður að vera innan eins úthlutaðs hlutar!
    ///       Sneiðar geta aldrei spannað yfir marga úthlutaða hluti.
    ///
    ///     * Bendillinn verður að vera samstilltur, jafnvel fyrir sneiðar í núlllengd.
    ///     Ein ástæðan fyrir þessu er sú að fínstillingar enum skipulags geta reitt sig á að tilvísanir (þ.m.t. sneiðar af hvaða lengd sem er) séu samstilltar og ekki núllar til að greina þær frá öðrum gögnum.
    ///
    ///     Þú getur fengið bendi sem er nothæfur sem `data` fyrir sneiðar án lengdar með því að nota [`NonNull::dangling()`].
    ///
    /// * Heildarstærð `ptr.len() * mem::size_of::<T>()` sneiðarinnar má ekki vera stærri en `isize::MAX`.
    ///   Sjá öryggisgögn [`pointer::offset`].
    ///
    /// * Þú verður að framfylgja alias reglum Rust, þar sem skilað líftími `'a` er valinn geðþótta og endurspeglar ekki endilega raunverulegan líftíma gagnanna.
    ///   Sérstaklega, meðan á þessari ævi stendur, má ekki nálgast (lesa eða skrifa) minnið sem bendillinn bendir á í gegnum neinn annan bendil.
    ///
    /// Þetta á við þó niðurstaðan af þessari aðferð sé ónotuð!
    ///
    /// Sjá einnig [`slice::from_raw_parts_mut`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `as_uninit_slice_mut`.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Jöfnuður fyrir ábendingar
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}