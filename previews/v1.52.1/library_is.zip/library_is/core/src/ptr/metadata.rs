#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Býður upp lýsigagnagerð bendilsins af hvaða tegund sem er bent á.
///
/// # Lýsigögn bendis
///
/// Hægt er að hugsa um hráar bendilategundir og viðmiðunartegundir í Rust sem gerðar eru úr tveimur hlutum:
/// gagnabendill sem inniheldur minni heimilisfang gildisins og nokkur lýsigögn.
///
/// Fyrir stöðluð stærðir (sem útfæra `Sized` traits) sem og fyrir `extern` gerðir eru ábendingar sagðar " þunnar`: lýsigögn eru núllstór og gerð þeirra er `()`.
///
///
/// Ábendingar í [dynamically-sized types][dst] eru sagðar " breiðar`eða " feitar`, þær hafa lýsigögn sem eru ekki núllstærð:
///
/// * Fyrir strúta þar sem síðasti reiturinn er DST eru lýsigögn lýsigögnin fyrir síðasta reitinn
/// * Fyrir `str` gerðina eru lýsigögn lengd í bæti sem `usize`
/// * Fyrir sneiðgerðir eins og `[T]` eru lýsigögn lengd hlutanna sem `usize`
/// * Fyrir trait hluti eins og `dyn SomeTrait` eru lýsigögn [`DynMetadata<Self>`][DynMetadata] (td `DynMetadata<dyn SomeTrait>`)
///
/// Í future getur Rust tungumálið fengið nýjar tegundir sem hafa mismunandi lýsigögn fyrir bendi.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// Aðalatriðið í þessari trait er `Metadata` tengd gerð þess, sem er `()` eða `usize` eða `DynMetadata<_>` eins og lýst er hér að ofan.
/// Það er sjálfkrafa útfært fyrir allar gerðir.
/// Ætla má að það sé útfært í almennu samhengi, jafnvel án samsvarandi takmarkana.
///
/// # Usage
///
/// Hráa ábendingar er hægt að brjóta niður í gögn heimilisfang og lýsigagna hluti með [`to_raw_parts`] aðferð sinni.
///
/// Að öðrum kosti er hægt að ná lýsigögnum einum saman með [`metadata`] aðgerðinni.
/// Tilvísun er hægt að senda til [`metadata`] og þvinguð með óbeinum hætti.
///
/// Hægt er að setja (possibly-wide) bendi saman frá heimilisfangi og lýsigögnum með [`from_raw_parts`] eða [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Tegund lýsigagna í ábendingum og tilvísanir í `Self`.
    #[lang = "metadata_type"]
    // NOTE: Haltu trait bounds í `static_assert_expected_bounds_for_metadata`
    //
    // í `library/core/src/ptr/metadata.rs` í takt við þá sem hér eru:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Ábendingar um gerðir sem útfæra þetta trait alias eru " þunnar`.
///
/// Þetta felur í sér staðbundnar 'Stærðar' gerðir og `extern` gerðir.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: ekki koma á stöðugleika í þessu áður en trait samnefni eru stöðug á tungumálinu?
pub trait Thin = Pointee<Metadata = ()>;

/// Taktu út lýsigagnahluta bendils.
///
/// Gildi af gerðinni `*mut T`, `&T` eða `&mut T` er hægt að fara beint í þessa aðgerð þar sem þau neyðast óbeint til `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // ÖRYGGI: Aðgangur að gildi frá `PtrRepr` sambandinu er öruggur þar sem * const T
    // og PtrComponents<T>hafa sömu minnisskipulag.
    // Aðeins std getur veitt þessa ábyrgð.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Myndar (possibly-wide) hráan bendil úr gagna heimilisfangi og lýsigögnum.
///
/// Þessi aðgerð er örugg en bendillinn sem skilað er er ekki endilega öruggur til aðgreiningar.
/// Fyrir sneiðar, sjá skjöl [`slice::from_raw_parts`] varðandi öryggiskröfur.
/// Fyrir trait hluti verða lýsigögnin að koma frá bendi í sömu undirliggjandi eytt gerð.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // ÖRYGGI: Aðgangur að gildi frá `PtrRepr` sambandinu er öruggur þar sem * const T
    // og PtrComponents<T>hafa sömu minnisskipulag.
    // Aðeins std getur veitt þessa ábyrgð.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Framkvæmir sömu virkni og [`from_raw_parts`], nema að hráum `*mut` mús er skilað, öfugt við hráan `* const` mús.
///
///
/// Sjá skjöl [`from_raw_parts`] fyrir frekari upplýsingar.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // ÖRYGGI: Aðgangur að gildi frá `PtrRepr` sambandinu er öruggur þar sem * const T
    // og PtrComponents<T>hafa sömu minnisskipulag.
    // Aðeins std getur veitt þessa ábyrgð.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Handbók nauðsynleg til að forðast `T: Copy` bundinn.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Handbók nauðsynleg til að forðast `T: Clone` bundinn.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Lýsigögnin fyrir `Dyn = dyn SomeTrait` trait hlutagerð.
///
/// Það er bendill á vtable (virtual call table) sem táknar allar nauðsynlegar upplýsingar til að vinna með steypusteypuna sem er geymd inni í trait hlut.
/// Taflan, sérstaklega hún inniheldur:
///
/// * tegundarstærð
/// * tegund jöfnun
/// * bendir á `drop_in_place` impl tegundina (getur verið ónot fyrir venjuleg-gömul gögn)
/// * ábendingar um allar aðferðir við gerð gerðarinnar á trait
///
/// Athugaðu að fyrstu þrír eru sérstakir vegna þess að þeir eru nauðsynlegir til að úthluta, sleppa og framselja hvaða trait hlut sem er.
///
/// Það er mögulegt að nefna þennan strúktúr með gerð breytu sem er ekki `dyn` trait hlutur (til dæmis `DynMetadata<u64>`) en ekki til að fá þroskandi gildi þess strúts.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Sameiginlegt forskeyti allra vtabla.Það er fylgt eftir með fallbendingum fyrir trait aðferðir.
///
/// Upplýsingar um einkaframkvæmd `DynMetadata::size_of` o.fl.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Skilar stærð þeirrar gerðar sem tengd er þessari töflu.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Skilar röðun þeirrar gerðar sem tengist þessari vtöflu.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Skilar stærð og röðun saman sem `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // ÖRYGGI: þýðandinn sendi frá sér þessa töflu fyrir steypu Rust gerð sem
        // er þekkt fyrir að hafa gilt skipulag.Sama rök og í `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Handvirkar tækjabúnaður þarf til að forðast `Dyn: $Trait` mörk.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}