//! Stjórnaðu minni handvirkt með hráum ábendingum.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Margar aðgerðir í þessari einingu taka hráar ábendingar sem rök og lesa úr þeim eða skrifa til þeirra.Til að þetta sé öruggt verða þessar ábendingar að vera *gildar*.
//! Hvort bendill er gildur fer eftir aðgerðinni sem hann er notaður við (lesa eða skrifa) og umfangi minni sem er opnað (þ.e. hversu mörg bæti eru read/written).
//! Flestar aðgerðir nota `*mut T` og `* const T` til að fá aðgang að aðeins einu gildi, en þá er í skjölunum sleppt stærðinni og óbeint gert ráð fyrir að það sé `size_of::<T>()` bæti.
//!
//! Nákvæmar reglur um gildi eru ekki ákveðnar ennþá.Ábyrgðin sem veitt er á þessum tímapunkti er mjög lítil:
//!
//! * [null] bendill er *aldrei* gildur, ekki einu sinni fyrir aðgang að [size zero][zst].
//! * Til þess að bendill sé gildur er nauðsynlegt, en ekki alltaf nægilegt, að bendillinn sé *dereferenceable*: minnissvið viðkomandi stærðar sem byrjar á bendinu verður að vera innan marka eins úthlutaðs hlutar.
//!
//! Athugaðu að í Rust er hver (stack-allocated) breyta talin sérstakt úthlutað hlut.
//! * Jafnvel fyrir aðgerðir á [size zero][zst] má bendillinn ekki vera að benda á úthlutað minni, það er að segja að samningur um staðsetningu gerir bendi ógildar jafnvel fyrir aðgerðir í núllstærð.
//! Hins vegar er það að gilda hvaða númer sem er ekki núll *bókstaflega* í bendi fyrir núllstóran aðgang, jafnvel þó að eitthvað minni sé til staðar á því heimilisfangi og fær það aftur.
//! Þetta samsvarar því að skrifa eigin úthlutunaraðila: að úthluta hlutum í núllstærð er ekki mjög erfitt.
//! Canonical leiðin til að fá bendi sem gildir fyrir núllstærð aðgang er [`NonNull::dangling`].
//! * Allur aðgangur sem gerður er af aðgerðum í þessari einingu er *ekki atóm* í skilningi [atomic operations] sem notaður er til að samstilla milli þráða.
//! Þetta þýðir að það er óskilgreind hegðun að framkvæma tvo samhliða aðgang að sama stað frá mismunandi þráðum nema báðir aðgangirnir lesist aðeins úr minni.
//! Takið eftir að þetta felur sérstaklega í sér [`read_volatile`] og [`write_volatile`]: Ekki er hægt að nota rokgjarnan aðgang til samstillingar milli þráða.
//! * Niðurstaðan af því að varpa tilvísun í bendi gildir svo lengi sem undirliggjandi hlutur er lifandi og engin tilvísun (bara hráir vísar) er notaður til að fá aðgang að sama minni.
//!
//! Þessar axioms, ásamt vandlegri notkun [`offset`] til að reikna bendi, eru nóg til að rétt framkvæma marga gagnlega hluti í óöruggum kóða.
//! Sterkari ábyrgðir verða að lokum veittar þar sem verið er að ákvarða [aliasing] reglurnar.
//! Fyrir frekari upplýsingar, sjá [book] sem og hlutann í tilvísuninni sem varið er til [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Gild hrá bendingar eins og skilgreindar eru hér að ofan eru ekki endilega rétt stilltar (þar sem "proper" röðun er skilgreind með vísbendingargerðinni, þ.e. `*const T` verður að vera samstillt við `mem::align_of::<T>()`).
//! Flestar aðgerðir krefjast þess þó að rök þeirra séu rétt samstillt og munu taka sérstaklega fram þessa kröfu í skjölum sínum.
//! Athyglisverðar undantekningar frá þessu eru [`read_unaligned`] og [`write_unaligned`].
//!
//! Þegar aðgerð krefst réttrar aðlögunar gerir hún það jafnvel þó að aðgangurinn hafi stærð 0, þ.e. jafnvel þó að í raun sé ekki snert á minni.Íhugaðu að nota [`NonNull::dangling`] í slíkum tilvikum.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Framkvæmir eyðileggjanda (ef einhver er) sem bent er á gildi.
///
/// Þetta jafngildir merkingarfræðilega því að hringja í [`ptr::read`] og fleygja niðurstöðunni en hefur eftirfarandi kosti:
///
/// * Það er *krafist* að nota `drop_in_place` til að sleppa óstærðum gerðum eins og trait hlutum, vegna þess að þeir geta ekki verið lesnir upp á stafla og fallið venjulega.
///
/// * Það er hagkvæmara fyrir fínstillandann að gera þetta yfir [`ptr::read`] þegar hent er minni sem er úthlutað handvirkt (td í útfærslum á `Box`/`Rc`/`Vec`), þar sem þýðandinn þarf ekki að sanna að það sé hljóð að fella afritið.
///
///
/// * Það er hægt að nota til að sleppa [pinned] gögnum þegar `T` er ekki `repr(packed)` (ekki má færa pinnagögn áður en þeim er sleppt).
///
/// Ekki er hægt að sleppa gildum sem ekki hafa verið stillt á staðinn, þau verða að afrita á takta staðsetningu fyrst með [`ptr::read_unaligned`].Fyrir pakkaða strúta er þýðingin gerð sjálfkrafa af þýðandanum.
/// Þetta þýðir að reitir pakkaðra strata falla ekki á sinn stað.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Hegðun er óskilgreind ef brotið er á eftirfarandi skilyrðum:
///
/// * `to_drop` verður að vera [valid] bæði fyrir lestur og ritun.
///
/// * `to_drop` verður að vera rétt samstillt.
///
/// * Gildið `to_drop` bendir á verður að vera gilt til að sleppa, sem getur þýtt að það verði að halda uppi viðbótar innflytjendum, þetta er háð tegund.
///
/// Að auki, ef `T` er ekki [`Copy`], getur það að nota bentu gildi eftir að hafa hringt í `drop_in_place` valdið óskilgreindri hegðun.Athugaðu að `*to_drop = foo` telst til notkunar vegna þess að það veldur því að gildið lækkar aftur.
/// [`write()`] hægt að nota til að skrifa yfir gögn án þess að láta þau falla.
///
/// Athugaðu að jafnvel þó `T` hafi stærð `0`, verður bendillinn að vera ekki NULL og rétt stilltur.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Fjarlægðu síðasta hlutinn handvirkt úr vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Fáðu hráan bendil á síðasta þáttinn í `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Styttu `v` til að koma í veg fyrir að síðasti hluturinn falli niður.
///     // Við gerum það fyrst, til að koma í veg fyrir vandamál ef `drop_in_place` fyrir neðan panics.
///     v.set_len(1);
///     // Án símtals `drop_in_place` myndi síðasta hlutnum aldrei sleppa og minni sem það stýrir myndi leka.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Gakktu úr skugga um að síðasta hlutnum hafi verið sleppt.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Taktu eftir því að þýðandinn framkvæmir þetta afrit sjálfkrafa þegar slepptum pakkningum er sleppt, þ.e. þú þarft venjulega ekki að hafa áhyggjur af slíkum málum nema þú hringir í `drop_in_place` handvirkt.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Kóði hér skiptir ekki máli, það er skipt út fyrir raunverulegt dropalím af þýðandanum.
    //

    // ÖRYGGI: sjá athugasemd hér að ofan
    unsafe { drop_in_place(to_drop) }
}

/// Býr til núll hráan bendil.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Býr til núll breytanlegan hráan bendil.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Handbók nauðsynleg til að forðast `T: Clone` bundinn.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Handbók nauðsynleg til að forðast `T: Copy` bundinn.
impl<T> Copy for FatPtr<T> {}

/// Myndar hráa sneið úr bendi og lengd.
///
/// `len` rökin eru fjöldi **þátta**, ekki fjöldi bæti.
///
/// Þessi aðgerð er örugg en í raun að nota skilagildið er óöruggt.
/// Sjá skjöl [`slice::from_raw_parts`] varðandi öryggiskröfur um sneiðar.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // búðu til sneiðabend þegar þú byrjar með bendi á fyrsta þáttinn
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // ÖRYGGI: Aðgangur að gildi frá `Repr` sambandinu er öruggur þar sem * const [T]
        //
        // og FatPtr hafa sömu minnisskipulag.Aðeins std getur veitt þessa ábyrgð.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Framkvæmir sömu virkni og [`slice_from_raw_parts`], nema að hrá breytileg sneið er skilað, öfugt við hrá óbreytanleg sneið.
///
///
/// Sjá skjöl [`slice_from_raw_parts`] fyrir frekari upplýsingar.
///
/// Þessi aðgerð er örugg en í raun að nota skilagildið er óöruggt.
/// Sjá skjöl [`slice::from_raw_parts_mut`] varðandi öryggiskröfur um sneiðar.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // úthluta gildi við vísitölu í sneiðinni
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // ÖRYGGI: Aðgangur að gildi frá `Repr` sambandinu er öruggur þar sem * mut [T]
        // og FatPtr hafa sömu minnisskipulag
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Skiptir um gildi á tveimur stökkbreytanlegum stöðum af sömu gerð, án þess að afnema hvort heldur.
///
/// En fyrir eftirfarandi tvær undantekningar jafngildir þessi aðgerð merkingarlega [`mem::swap`]:
///
///
/// * Það starfar á hráum ábendingum í stað tilvísana.
/// Þegar tilvísanir eru fáanlegar ætti [`mem::swap`] að vera valinn.
///
/// * Gildin tvö sem vísað er til geta skarast.
/// Ef gildin skarast, þá verður skörun minni `x` notað.
/// Þetta er sýnt fram á í seinna dæminu hér að neðan.
///
/// # Safety
///
/// Hegðun er óskilgreind ef brotið er á eftirfarandi skilyrðum:
///
/// * Bæði `x` og `y` verða að vera [valid] bæði fyrir lestur og ritun.
///
/// * Bæði `x` og `y` verða að vera rétt samstillt.
///
/// Athugaðu að jafnvel þó `T` sé með stærð `0`, þá verða ábendingar að vera ekki NULL og rétt stilltar.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Skipta um tvö svæði sem ekki skarast:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // þetta er `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // þetta er `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Skipta um tvö svæði sem skarast:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // þetta er `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // þetta er `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Vísitölurnar `1..3` sneiðarinnar skarast á milli `x` og `y`.
///     // Sanngjörn árangur væri fyrir þá að vera `[2, 3]`, þannig að vísitölur `0..3` eru `[1, 2, 3]` (passa við `y` fyrir `swap`);eða að þeir séu `[0, 1]` þannig að vísitölur `1..4` séu `[0, 1, 2]` (passar við `x` fyrir `swap`).
/////
///     // Þessi útfærsla er skilgreind til að velja hið síðarnefnda.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Gefum okkur smá klórapláss til að vinna með.
    // Við þurfum ekki að hafa áhyggjur af dropum: `MaybeUninit` gerir ekkert þegar honum er sleppt.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Skiptu um ÖRYGGI: sá sem hringir þarf að ábyrgjast að `x` og `y` séu gild fyrir skrif og rétt stillt.
    // `tmp` getur ekki verið skarast annaðhvort `x` eða `y` vegna þess að `tmp` var bara úthlutað á staflinum sem sérstökum úthlutuðum hlut.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` og `y` geta skarast
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Skiptir um `count * size_of::<T>()` bæti milli tveggja svæða minni sem byrja á `x` og `y`.
/// Svæðin tvö mega *ekki* skarast.
///
/// # Safety
///
/// Hegðun er óskilgreind ef brotið er á eftirfarandi skilyrðum:
///
/// * Bæði `x` og `y` verða að vera [valid] til að bæði lesa og skrifa um 'telja *
///   stærð_ af: :<T>() `bæti.
///
/// * Bæði `x` og `y` verða að vera rétt samstillt.
///
/// * Svæðið um minni sem byrjar á `x` með stærðina 'telja *
///   stærð_ af: :<T>() `bæti mega *ekki* skarast við það svæði minni sem byrjar á `y` af sömu stærð.
///
/// Athugaðu að jafnvel þótt afritaða stærðin sé virk (`telja * stærð_of: :<T>()`) er `0`, ábendingar verða að vera ekki NULL og rétt stilltar.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Grunn notkun:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // ÖRYGGI: sá sem hringir þarf að ábyrgjast að `x` og `y` séu það
    // gild fyrir skrif og rétt stillt.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Fyrir gerðir sem eru minni en hagræðingin fyrir neðan skaltu bara skipta beint til að forðast svartsýni á kógen.
    //
    if mem::size_of::<T>() < 32 {
        // ÖRYGGI: sá sem hringir þarf að ábyrgjast að `x` og `y` séu í gildi
        // fyrir skrif, rétt stillt og skarast ekki.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Aðferðin hér er að nota simd til að skipta x&y á skilvirkan hátt.
    // Prófun leiðir í ljós að skipting annaðhvort 32 bæti eða 64 bæti í einu er skilvirkust fyrir Intel Haswell E örgjörva.
    // LLVM er færari um að hagræða ef við gefum strúktúr #[repr(simd)], jafnvel þó við notum í raun ekki þennan strik beint.
    //
    //
    // FIXME repr(simd) brotinn á emscripten og redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Lukkaðu í gegnum x&y, afritaðu þá `Block` í einu Hagræðingaraðilinn ætti að skrúfa lykkjuna að fullu fyrir flestar gerðir NB
    // Við getum ekki notað for lykkju þar sem `range` impl kallar `mem::swap` endurtekið
    //
    let mut i = 0;
    while i + block_size <= len {
        // Búðu til eitthvað óafgreitt minni þar sem klórapláss Með því að lýsa yfir `t` hér er forðast að stilla stafla þegar þessi lykkja er ónotuð
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // ÖRYGGI: Sem `i < len`, og sem hringir verður að ábyrgjast að `x` og `y` séu gild
        // fyrir `len` bæti, `x + i` og `y + i` verða að vera gild heimilisfang, sem uppfylla öryggissamninginn fyrir `add`.
        //
        // Einnig verður sá sem hringir að ábyrgjast að `x` og `y` gildi fyrir skrif, rétt stillt og skarast ekki, sem uppfyllir öryggissamninginn fyrir `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Skiptu um reit af bæti af x&y og notaðu t sem tímabundinn biðminni. Þetta ætti að vera fínstillt í skilvirka SIMD aðgerð þar sem það er í boði
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Skiptu um öll bæti sem eftir eru
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // ÖRYGGI: sjá fyrri athugasemd um öryggi.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Færir `src` í bent `dst` og skilar fyrra `dst` gildi.
///
/// Hvorugt gildið fellur niður.
///
/// Þessi aðgerð jafngildir merkingarfræðilega [`mem::replace`] nema að hún starfar á hráum ábendingum í stað tilvísana.
/// Þegar tilvísanir eru fáanlegar ætti [`mem::replace`] að vera valinn.
///
/// # Safety
///
/// Hegðun er óskilgreind ef brotið er á eftirfarandi skilyrðum:
///
/// * `dst` verður að vera [valid] bæði fyrir lestur og ritun.
///
/// * `dst` verður að vera rétt samstillt.
///
/// * `dst` verður að benda á rétt upphafsgildi af gerðinni `T`.
///
/// Athugaðu að jafnvel þó `T` hafi stærð `0`, verður bendillinn að vera ekki NULL og rétt stilltur.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` hefði sömu áhrif án þess að krefjast óöruggrar lokunar.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // ÖRYGGI: sá sem hringir þarf að ábyrgjast að `dst` sé réttmætur
    // kastað til breytanlegrar tilvísunar (gild fyrir skrif, stillt, frumstillt) og getur ekki skarast `src` þar sem `dst` verður að benda á sérstakan úthlutaðan hlut.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // getur ekki skarast
    }
    src
}

/// Lestur gildi frá `src` án þess að færa það.Þetta skilur minnið eftir í `src` óbreytt.
///
/// # Safety
///
/// Hegðun er óskilgreind ef brotið er á eftirfarandi skilyrðum:
///
/// * `src` verður að vera [valid] fyrir lestur.
///
/// * `src` verður að vera rétt samstillt.Notaðu [`read_unaligned`] ef þetta er ekki raunin.
///
/// * `src` verður að benda á rétt upphafsgildi af gerðinni `T`.
///
/// Athugaðu að jafnvel þó `T` hafi stærð `0`, verður bendillinn að vera ekki NULL og rétt stilltur.
///
/// # Examples
///
/// Grunn notkun:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Útfærðu [`mem::swap`] handvirkt:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Búðu til bitvis afrit af gildinu við `a` í `tmp`.
///         let tmp = ptr::read(a);
///
///         // Hætta á þessum tímapunkti (annað hvort með því að skila gagngert eða með því að hringja í aðgerð sem panics) myndi valda því að gildi í `tmp` lækkaði meðan sama gildi er enn vísað til af `a`.
///         // Þetta gæti komið af stað óskilgreindri hegðun ef `T` er ekki `Copy`.
/////
/////
///
///         // Búðu til bitvis afrit af gildinu við `b` í `a`.
///         // Þetta er öruggt vegna þess að breyttar tilvísanir geta ekki alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Eins og að ofan, að hætta hér gæti komið af stað óskilgreindri hegðun vegna þess að sama gildi er vísað til af `a` og `b`.
/////
///
///         // Færðu `tmp` í `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` hefur verið flutt (`write` tekur eignarhald á annarri röksemdafærslu sinni), svo ekkert er látið falla hér óbeint.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Eignarhald á skiluðu gildi
///
/// `read` býr til bitvis afrit af `T`, óháð því hvort `T` er [`Copy`].
/// Ef `T` er ekki [`Copy`] getur notkun á skiluðu gildi og gildi `*src` brotið gegn öryggi minni.
/// Athugaðu að úthlutun til `*src` telst sem notkun vegna þess að það mun reyna að sleppa gildinu við `* src`.
///
/// [`write()`] hægt að nota til að skrifa yfir gögn án þess að láta þau falla.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` bendir nú á sömu undirliggjandi minni og `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Að úthluta `s2` veldur því að upphaflegt gildi þess fellur niður.
///     // Fyrir utan þennan punkt má ekki lengur nota `s` þar sem undirliggjandi minni hefur verið losað.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Að úthluta `s` myndi leiða til þess að gamla gildi lækkaði aftur og það hefði óskilgreind hegðun í för með sér.
/////
///     // s= String::from("bar");//VILLA
///
///     // `ptr::write` hægt að nota til að yfirskrifa gildi án þess að láta það falla.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // ÖRYGGI: sá sem hringir þarf að ábyrgjast að `src` sé gilt fyrir lestur.
    // `src` getur ekki skarast `tmp` vegna þess að `tmp` var bara úthlutað á stafla sem sérstökum úthlutuðum hlut.
    //
    //
    // Einnig, þar sem við skrifuðum réttmæt gildi í `tmp`, er það örugglega rétt frumstillt.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Lestur gildi frá `src` án þess að færa það.Þetta skilur minnið eftir í `src` óbreytt.
///
/// Ólíkt [`read`] vinnur `read_unaligned` með ójöfnum ábendingum.
///
/// # Safety
///
/// Hegðun er óskilgreind ef brotið er á eftirfarandi skilyrðum:
///
/// * `src` verður að vera [valid] fyrir lestur.
///
/// * `src` verður að benda á rétt upphafsgildi af gerðinni `T`.
///
/// Eins og [`read`] býr `read_unaligned` til bitvis afrit af `T`, óháð því hvort `T` er [`Copy`].
/// Ef `T` er ekki [`Copy`], getur bæði skilað gildi og gildi `*src` notað [violate memory safety][read-ownership].
///
/// Athugaðu að jafnvel þó `T` sé með stærð `0`, verður bendillinn að vera ekki NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Á `packed` strigum
///
/// Eins og er er ómögulegt að búa til hráar ábendingar á ósamræmda reiti í fullri uppbyggingu.
///
/// Tilraun til að búa til hráan bendil í `unaligned` uppbyggingarreit með tjáningu eins og `&packed.unaligned as *const FieldType` skapar milliliðalausa tilvísun áður en því er breytt í hráan bendil.
///
/// Að þessi tilvísun sé tímabundin og strax kastað skiptir ekki máli þar sem þýðandinn ætlast alltaf til að tilvísanir séu rétt samstilltar.
/// Þess vegna veldur notkun `&packed.unaligned as *const FieldType` strax* óskilgreindri hegðun * í forritinu þínu.
///
/// Dæmi um hvað má ekki gera og hvernig þetta tengist `read_unaligned` er:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Hér reynum við að taka heimilisfang 32-bita heiltölu sem er ekki samstillt.
///     let unaligned =
///         // Hér er búin til tímabundin ósamstillt tilvísun sem leiðir til óskilgreindrar hegðunar óháð því hvort tilvísunin er notuð eða ekki.
/////
///         &packed.unaligned
///         // Það hjálpar ekki að steypa í hráan bendil;mistökin gerðust þegar.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Aðgangur að ósamræmdum reitum beint með td `packed.unaligned` er þó öruggur.
///
///
///
///
///
///
// FIXME: Uppfærðu skjöl byggð á niðurstöðu RFC #2582 og vina.
/// # Examples
///
/// Lestu notkunargildi úr bæti biðminni:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // ÖRYGGI: sá sem hringir þarf að ábyrgjast að `src` sé gilt fyrir lestur.
    // `src` getur ekki skarast `tmp` vegna þess að `tmp` var bara úthlutað á stafla sem sérstökum úthlutuðum hlut.
    //
    //
    // Einnig, þar sem við skrifuðum réttmæt gildi í `tmp`, er það örugglega rétt frumstillt.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Yfirskrifar minni staðsetningu með gefnu gildi án þess að lesa eða sleppa gamla gildinu.
///
/// `write` sleppir ekki innihaldi `dst`.
/// Þetta er öruggt, en það gæti lekið úthlutun eða auðlindum, svo að gæta skal þess að skrifa ekki niður hlut sem ætti að sleppa.
///
///
/// Að auki fellur það ekki `src`.Merkingarlega er `src` flutt inn á staðinn sem `dst` bendir á.
///
/// Þetta er viðeigandi til að frumstilla óinnstillt minni eða skrifa yfir minni sem áður hefur verið [`read`] frá.
///
/// # Safety
///
/// Hegðun er óskilgreind ef brotið er á eftirfarandi skilyrðum:
///
/// * `dst` verður að vera [valid] fyrir skrif.
///
/// * `dst` verður að vera rétt samstillt.Notaðu [`write_unaligned`] ef þetta er ekki raunin.
///
/// Athugaðu að jafnvel þó `T` hafi stærð `0`, verður bendillinn að vera ekki NULL og rétt stilltur.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Grunn notkun:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Útfærðu [`mem::swap`] handvirkt:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Búðu til bitvis afrit af gildinu við `a` í `tmp`.
///         let tmp = ptr::read(a);
///
///         // Hætta á þessum tímapunkti (annað hvort með því að skila gagngert eða með því að hringja í aðgerð sem panics) myndi valda því að gildi í `tmp` lækkaði meðan sama gildi er enn vísað til af `a`.
///         // Þetta gæti komið af stað óskilgreindri hegðun ef `T` er ekki `Copy`.
/////
/////
///
///         // Búðu til bitvis afrit af gildinu við `b` í `a`.
///         // Þetta er öruggt vegna þess að breyttar tilvísanir geta ekki alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Eins og að ofan, að hætta hér gæti komið af stað óskilgreindri hegðun vegna þess að sama gildi er vísað til af `a` og `b`.
/////
///
///         // Færðu `tmp` í `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` hefur verið flutt (`write` tekur eignarhald á annarri röksemdafærslu sinni), svo ekkert er látið falla hér óbeint.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Við erum að hringja í innri hlutina beint til að forðast aðgerðarsímtöl í myndaða kóðanum þar sem `intrinsics::copy_nonoverlapping` er umbúðaraðgerð.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // ÖRYGGI: sá sem hringir verður að ábyrgjast að `dst` gildi fyrir skrif.
    // `dst` getur ekki skarað `src` vegna þess að sá sem hringir hefur breytanlegan aðgang að `dst` meðan `src` er í eigu þessarar aðgerð.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Yfirskrifar minni staðsetningu með gefnu gildi án þess að lesa eða sleppa gamla gildinu.
///
/// Ólíkt [`write()`] getur bendillinn verið ósamræmdur.
///
/// `write_unaligned` sleppir ekki innihaldi `dst`.Þetta er öruggt, en það gæti lekið úthlutun eða auðlindum, svo að gæta skal þess að skrifa ekki niður hlut sem ætti að sleppa.
///
/// Að auki fellur það ekki `src`.Merkingarlega er `src` flutt inn á staðinn sem `dst` bendir á.
///
/// Þetta er viðeigandi til að frumstilla óforvarið minni eða skrifa yfir minni sem áður hefur verið lesið með [`read_unaligned`].
///
/// # Safety
///
/// Hegðun er óskilgreind ef brotið er á eftirfarandi skilyrðum:
///
/// * `dst` verður að vera [valid] fyrir skrif.
///
/// Athugaðu að jafnvel þó `T` sé með stærð `0`, verður bendillinn að vera ekki NULL.
///
/// [valid]: self#safety
///
/// ## Á `packed` strigum
///
/// Eins og er er ómögulegt að búa til hráar ábendingar á ósamræmda reiti í fullri uppbyggingu.
///
/// Tilraun til að búa til hráan bendil í `unaligned` uppbyggingarreit með tjáningu eins og `&packed.unaligned as *const FieldType` skapar milliliðalausa tilvísun áður en því er breytt í hráan bendil.
///
/// Að þessi tilvísun sé tímabundin og strax kastað skiptir ekki máli þar sem þýðandinn ætlast alltaf til að tilvísanir séu rétt samstilltar.
/// Þess vegna veldur notkun `&packed.unaligned as *const FieldType` strax* óskilgreindri hegðun * í forritinu þínu.
///
/// Dæmi um hvað má ekki gera og hvernig þetta tengist `write_unaligned` er:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Hér reynum við að taka heimilisfang 32-bita heiltölu sem er ekki samstillt.
///     let unaligned =
///         // Hér er búin til tímabundin ósamstillt tilvísun sem leiðir til óskilgreindrar hegðunar óháð því hvort tilvísunin er notuð eða ekki.
/////
///         &mut packed.unaligned
///         // Það hjálpar ekki að steypa í hráan bendil;mistökin gerðust þegar.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Aðgangur að ósamræmdum reitum beint með td `packed.unaligned` er þó öruggur.
///
///
///
///
///
///
///
///
///
// FIXME: Uppfærðu skjöl byggð á niðurstöðu RFC #2582 og vina.
/// # Examples
///
/// Skrifaðu notkunargildi í bæti biðminni:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // ÖRYGGI: sá sem hringir verður að ábyrgjast að `dst` gildi fyrir skrif.
    // `dst` getur ekki skarað `src` vegna þess að sá sem hringir hefur breytanlegan aðgang að `dst` meðan `src` er í eigu þessarar aðgerð.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Við erum að hringja beint í innri hlutann til að forðast símtöl í myndaða kóðanum.
        intrinsics::forget(src);
    }
}

/// Framkvæmir sveiflukennda aflestur af gildinu frá `src` án þess að hreyfa það.Þetta skilur minnið eftir í `src` óbreytt.
///
/// Rokgjarnar aðgerðir eru ætlaðar til að starfa á I/O minni og þær eru tryggðar að þeim verður ekki breytt eða endurraðað af þýðandanum yfir aðrar sveiflukenndar aðgerðir.
///
/// # Notes
///
/// Rust er ekki með eins og er nákvæmlega og formlega skilgreint minni líkan, þannig að nákvæm merkingarfræði hvað "volatile" þýðir hér er háð breytingum með tímanum.
/// Sem sagt, merkingarfræði mun næstum alltaf enda frekar svipuð [C11's definition of volatile][c11].
///
/// Þáttaraðili ætti ekki að breyta hlutfallslegri röð eða fjölda sveiflukenndra minniaðgerða.
/// Hins vegar eru sveiflukenndar minnisaðgerðir á núllstærðum gerðum (td ef núllstærð er sendar til `read_volatile`) engar og hægt er að hunsa þær.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Hegðun er óskilgreind ef brotið er á eftirfarandi skilyrðum:
///
/// * `src` verður að vera [valid] fyrir lestur.
///
/// * `src` verður að vera rétt samstillt.
///
/// * `src` verður að benda á rétt upphafsgildi af gerðinni `T`.
///
/// Eins og [`read`] býr `read_volatile` til bitvis afrit af `T`, óháð því hvort `T` er [`Copy`].
/// Ef `T` er ekki [`Copy`], getur bæði skilað gildi og gildi `*src` notað [violate memory safety][read-ownership].
/// Hins vegar er nánast ekki rétt að geyma tegundir sem ekki eru [" Afrita`] í rokgjarnri minni.
///
/// Athugaðu að jafnvel þó `T` hafi stærð `0`, verður bendillinn að vera ekki NULL og rétt stilltur.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Rétt eins og í C, hvort aðgerðir eru sveiflukenndar, hefur engin áhrif á spurningar sem fela í sér samhliða aðgang frá mörgum þráðum.Rokgjörn aðgangur hegðar sér nákvæmlega eins og aðgangur sem ekki er atóm í þeim efnum.
///
/// Sérstaklega er kapphlaup milli `read_volatile` og hvaða skrifaðgerðar sem er á sama stað óskilgreind hegðun.
///
/// # Examples
///
/// Grunn notkun:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Ekki læti til að halda áhrifum á codegen minni.
        abort();
    }
    // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Framkvæmir sveiflukenndan skrif af minnisstað með gefnu gildi án þess að lesa eða sleppa gamla gildinu.
///
/// Rokgjarnar aðgerðir eru ætlaðar til að starfa á I/O minni og þær eru tryggðar að þeim verður ekki breytt eða endurraðað af þýðandanum yfir aðrar sveiflukenndar aðgerðir.
///
/// `write_volatile` sleppir ekki innihaldi `dst`.Þetta er öruggt, en það gæti lekið úthlutun eða auðlindum, svo að gæta skal þess að skrifa ekki niður hlut sem ætti að sleppa.
///
/// Að auki fellur það ekki `src`.Merkingarlega er `src` flutt inn á staðinn sem `dst` bendir á.
///
/// # Notes
///
/// Rust er ekki með eins og er nákvæmlega og formlega skilgreint minni líkan, þannig að nákvæm merkingarfræði hvað "volatile" þýðir hér er háð breytingum með tímanum.
/// Sem sagt, merkingarfræði mun næstum alltaf enda frekar svipuð [C11's definition of volatile][c11].
///
/// Þáttaraðili ætti ekki að breyta hlutfallslegri röð eða fjölda sveiflukenndra minniaðgerða.
/// Hins vegar eru sveiflukenndar minnisaðgerðir á núllstærðum gerðum (td ef núllstærð er sendar til `write_volatile`) engar og hægt er að hunsa þær.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Hegðun er óskilgreind ef brotið er á eftirfarandi skilyrðum:
///
/// * `dst` verður að vera [valid] fyrir skrif.
///
/// * `dst` verður að vera rétt samstillt.
///
/// Athugaðu að jafnvel þó `T` hafi stærð `0`, verður bendillinn að vera ekki NULL og rétt stilltur.
///
/// [valid]: self#safety
///
/// Rétt eins og í C, hvort aðgerðir eru sveiflukenndar, hefur engin áhrif á spurningar sem fela í sér samhliða aðgang frá mörgum þráðum.Rokgjörn aðgangur hegðar sér nákvæmlega eins og aðgangur sem ekki er atóm í þeim efnum.
///
/// Sérstaklega er kapphlaup milli `write_volatile` og annarra aðgerða (lestur eða ritun) á sama stað óskilgreind hegðun.
///
/// # Examples
///
/// Grunn notkun:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Ekki læti til að halda áhrifum á codegen minni.
        abort();
    }
    // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Réttu bendilinn `p`.
///
/// Reiknaðu móti (miðað við þætti `stride` skrefa) sem þarf að beita á bendi `p` svo að bendill `p` myndi aðlagast `a`.
///
/// Note: Þessi framkvæmd hefur verið vandlega sniðin að ekki panic.Það er UB fyrir þetta að panic.
/// Eina raunverulega breytingin sem hægt er að gera hér er breyting á `INV_TABLE_MOD_16` og tengdum fastum.
///
/// Ef við ákveðum einhvern tíma að gera það mögulegt að hringja í innra með `a` sem er ekki máttur af tveimur, þá verður líklega skynsamlegra að breyta bara í barnalegan útfærslu frekar en að reyna að laga þetta til að koma til móts við þá breytingu.
///
///
/// Allar spurningar fara á@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Bein notkun þessara eiginleika bætir codegen verulega á opt-level <=
    // 1, þar sem aðferðaútgáfur þessara aðgerða eru ekki í línu.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Reiknið margfalda módular andhverfu `x` modulo `m`.
    ///
    /// Þessi útfærsla er sérsniðin fyrir `align_offset` og hefur eftirfarandi forsendur:
    ///
    /// * `m` er máttur af tveimur;
    /// * `x < m`; (ef `x ≥ m` skaltu senda `x % m` í staðinn)
    ///
    /// Framkvæmd þessarar aðgerðar skal ekki panic.Alltaf.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Margföld módúral öfug tafla modulo 2⁴=16.
        ///
        /// Athugaðu að þessi tafla inniheldur ekki gildi þar sem andhverfa er ekki til (þ.e. fyrir `0⁻¹ mod 16`, `2⁻¹ mod 16` osfrv.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo sem `INV_TABLE_MOD_16` er ætlaður fyrir.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // ÖRYGGI: `m` þarf að vera máttur af tveimur og þess vegna ekki núll.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Við endurtekjum "up" með eftirfarandi formúlu:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // þar til 2²ⁿ ≥ m.Þá getum við minnkað niður í óskaðan `m` með því að taka niðurstöðuna `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Athugaðu að við notum umbúðir hér viljandi-upprunalega formúlan notar td frádrátt `mod n`.
                // Það er alveg í lagi að gera þá `mod usize::MAX` í staðinn, því við tökum niðurstöðuna `mod n` samt í lokin.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // ÖRYGGI: `a` er máttur tveggja og því ekki núll.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` tilfelli er hægt að reikna einfaldara í gegnum `-p (mod a)`, en það hindrar getu LLVM til að velja leiðbeiningar eins og `lea`.Í staðinn reiknum við
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // sem dreifir aðgerðum í kringum burðarþolið, en svartsýnir `and` nægilega til að LLVM geti nýtt sér hinar ýmsu hagræðingar sem það veit um.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Þegar samstillt.Yay!
        return 0;
    } else if stride == 0 {
        // Ef bendillinn er ekki samstilltur og frumefnið er núllstórt mun ekkert magn af þáttum nokkurn tíma stilla bendilinn.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // ÖRYGGI: a er máttur tveggja og þess vegna ekki núll.skref==0 mál er afgreitt hér að ofan.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // ÖRYGGI: gcdpow hefur efri mörk sem eru í mesta lagi fjöldi bita í stærð.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // ÖRYGGI: gcd er alltaf hærra eða jafnt og 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Þetta branch leysir eftirfarandi línulega samsvörunarjöfnu:
        //
        // ` p + so = 0 mod a `
        //
        // `p` hérna er bendisgildið, `s`, skref `T`, `o` móti í `T`s, og `a`, umbeðin jöfnun.
        //
        // Með `g = gcd(a, s)`, og ofangreint skilyrði sem fullyrðir að `p` sé einnig deilanlegt með `g`, getum við táknað `a' = a/g`, `s' = s/g`, `p' = p/g`, þá jafngildir þetta:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Fyrra hugtakið er "the relative alignment of `p` to `a`" (deilt með `g`), annað hugtakið er "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (aftur deilt með `g`).
        //
        // Skipting eftir `g` er nauðsynleg til að gera hið andhverfa vel mótað ef `a` og `s` eru ekki samprímun.
        //
        // Ennfremur er niðurstaðan sem þessi lausn framleiðir ekki "minimal" og því er nauðsynlegt að taka niðurstöðuna `o mod lcm(s, a)`.Við getum skipt um `lcm(s, a)` fyrir aðeins `a'`.
        //
        //
        //
        //
        //

        // ÖRYGGI: `gcdpow` hefur efri mörk sem eru ekki meiri en fjöldinn sem liggur á 0 bitum í `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // ÖRYGGI: `a2` er ekki núll.Breyting á `a` með `gcdpow` getur ekki fært út neina af föstu bitunum
        // í `a` (þar af er það nákvæmlega einn).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // ÖRYGGI: `gcdpow` hefur efri mörk sem eru ekki meiri en fjöldinn sem liggur á 0 bitum í `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // ÖRYGGI: `gcdpow` hefur efri mörk sem eru ekki meiri en fjöldinn sem liggur á 0 bitum í
        // `a`.
        // Ennfremur getur frádrátturinn ekki flætt yfir, því `a2 = a >> gcdpow` mun alltaf vera stranglega meiri en `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // ÖRYGGI: `a2` er máttur tveggja, eins og sannað er hér að ofan.`s2` er strangt til tekið minna en `a2`
        // vegna þess að `(s % a) >> gcdpow` er strangt til tekið minna en `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Getur alls ekki verið samstillt.
    usize::MAX
}

/// Ber saman hráar ábendingar til jafnréttis.
///
/// Þetta er það sama og að nota `==` símafyrirtækið, en minna almennt:
/// rökin verða að vera `*const T` hráir vísar, ekki neitt sem útfærir `PartialEq`.
///
/// Þetta er hægt að nota til að bera saman `&T` tilvísanir (sem neyðast óbeint við `*const T`) eftir heimilisfangi þeirra frekar en að bera saman gildin sem þeir benda á (það er það sem `PartialEq for &T` útfærslan gerir).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Sneiðar eru einnig bornir saman eftir lengd þeirra (fituábendingar):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits eru einnig bornar saman við framkvæmd þeirra:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Ábendingar hafa jöfn heimilisföng.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Hlutir hafa jöfn heimilisföng en `Trait` hefur mismunandi útfærslur.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Að breyta tilvísun í `*const u8` er borið saman við heimilisfang.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hass hrár ábending.
///
/// Þetta er hægt að nota til að kássa tilvísun `&T` (sem þvingast til `*const T` óbeint) með heimilisfangi frekar en gildinu sem það bendir á (það er það sem `Hash for &T` útfærslan gerir).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Útfærslur fyrir aðgerðarábendingar
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Millivirkið sem stærð er nauðsynlegt fyrir AVR
                // þannig að heimilisfangarheimildarbendillinn sé varðveittur í lokafallinu.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Millivirkið sem stærð er nauðsynlegt fyrir AVR
                // þannig að heimilisfangarheimildarbendillinn sé varðveittur í lokafallinu.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Engar breytistörf með 0 breytum
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Búðu til `const` hráan bendil á stað, án þess að búa til millivísun.
///
/// Að búa til tilvísun með `&`/`&mut` er aðeins leyfilegt ef bendillinn er rétt stilltur og vísar á upphafsgögn.
/// Í tilvikum þar sem þessar kröfur standast ekki, ætti að nota hráar ábendingar í staðinn.
/// `&expr as *const _` býr þó til tilvísun áður en það er varpað á hráan bendil og sú tilvísun lýtur sömu reglum og allar aðrar tilvísanir.
///
/// Þessi fjölvi getur búið til hráan bendil *án þess að* búi til tilvísun fyrst.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` myndi skapa ósamræmda tilvísun, og þannig vera Óskilgreind hegðun!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Búðu til `mut` hráan bendil á stað, án þess að búa til millivísun.
///
/// Að búa til tilvísun með `&`/`&mut` er aðeins leyfilegt ef bendillinn er rétt stilltur og vísar á upphafsgögn.
/// Í tilvikum þar sem þessar kröfur standast ekki, ætti að nota hráar ábendingar í staðinn.
/// `&mut expr as *mut _` býr þó til tilvísun áður en það er varpað á hráan bendil og sú tilvísun lýtur sömu reglum og allar aðrar tilvísanir.
///
/// Þessi fjölvi getur búið til hráan bendil *án þess að* búi til tilvísun fyrst.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` myndi skapa ósamræmda tilvísun, og þannig vera Óskilgreind hegðun!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` neyðir til að afrita reitinn í stað þess að búa til tilvísun.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}