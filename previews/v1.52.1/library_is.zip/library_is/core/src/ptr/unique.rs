use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Umbúðir utan um hráan `*mut T` sem ekki er núll sem gefur til kynna að handhafi þessa umbúða eigi tilvísunarmanninn.
/// Gagnlegt til að byggja upp ágrip eins og `Box<T>`, `Vec<T>`, `String` og `HashMap<K, V>`.
///
/// Ólíkt `*mut T`, hegðar `Unique<T>` sig "as if", það var dæmi um `T`.
/// Það útfærir `Send`/`Sync` ef `T` er `Send`/`Sync`.
/// Það felur einnig í sér hvers konar öflugt alias tryggir dæmi um `T` sem þú getur búist við:
/// ekki ætti að breyta tilvísan bendilsins án þess að hafa einstaka leið að því að eiga Unique.
///
/// Ef þú ert óviss um hvort það sé rétt að nota `Unique` í þínum tilgangi skaltu íhuga að nota `NonNull`, sem hefur veikari merkingarfræði.
///
///
/// Ólíkt `*mut T`, bendirinn verður alltaf að vera enginn, jafnvel þó að bendillinn sé aldrei annars vegar.
/// Þetta er til þess að enums geti notað þetta bannaða gildi sem mismunun-`Option<Unique<T>>` hefur sömu stærð og `Unique<T>`.
/// Hins vegar getur bendillinn samt dinglað ef ekki er vísað til hans.
///
/// Ólíkt `*mut T`, þá er `Unique<T>` breytilegt yfir `T`.
/// Þetta ætti alltaf að vera rétt fyrir allar tegundir sem standast samnefniskröfur Unique.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: þetta merki hefur engar afleiðingar fyrir dreifni, en er nauðsynlegt
    // fyrir dropck að skilja að við eigum rökrétt `T`.
    //
    // Sjá nánar:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` ábendingar eru `Send` ef `T` er `Send` vegna þess að gögnin sem þau vísa til eru ekki hliðholl.
/// Athugaðu að þetta alias alvarandi er óframfylgt af gerðarkerfinu;frádráttur með `Unique` verður að framfylgja því.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` ábendingar eru `Sync` ef `T` er `Sync` vegna þess að gögnin sem þau vísa til eru ekki hliðholl.
/// Athugaðu að þetta alias alvarandi er óframfylgt af gerðarkerfinu;frádráttur með `Unique` verður að framfylgja því.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Býr til nýjan `Unique` sem er dinglandi en vel stilltur.
    ///
    /// Þetta er gagnlegt til að frumstilla tegundir sem úthluta letilega, eins og `Vec::new` gerir.
    ///
    /// Athugaðu að bendilgildið getur hugsanlega táknað gildan bendil á `T`, sem þýðir að þetta má ekki nota sem "not yet initialized" sentinel gildi.
    /// Tegundir sem úthluta letilega verða að rekja frumstillingu með öðrum hætti.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // ÖRYGGI: mem::align_of() skilar gildum bendil sem ekki er núll.The
        // skilyrði til að hringja í new_unchecked() séu þannig virt.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Býr til nýjan `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` verður að vera ekki núll.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // ÖRYGGI: sá sem hringir verður að ábyrgjast að `ptr` sé ekki núll.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Býr til nýjan `Unique` ef `ptr` er ekki núll.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // ÖRYGGI: Bendillinn hefur þegar verið merktur og er ekki enginn.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Fær undirliggjandi `*mut` bendi.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Vísar til innihaldsins.
    ///
    /// Líftíminn sem myndast er bundinn við sjálfan sig svo þetta hegðar sér "as if" það var í raun dæmi um T sem er að fá lánað.
    /// Ef þörf er á lengri (unbound) líftíma skaltu nota `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // ÖRYGGI: sá sem hringir þarf að ábyrgjast að `self` uppfylli öll
        // kröfur um tilvísun.
        unsafe { &*self.as_ptr() }
    }

    /// Með breytilegum hætti er vísað frá innihaldinu.
    ///
    /// Líftíminn sem myndast er bundinn við sjálfan sig svo þetta hegðar sér "as if" það var í raun dæmi um T sem er að fá lánað.
    /// Ef þörf er á lengri (unbound) líftíma skaltu nota `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // ÖRYGGI: sá sem hringir þarf að ábyrgjast að `self` uppfylli öll
        // kröfur um breytanlega tilvísun.
        unsafe { &mut *self.as_ptr() }
    }

    /// Varpar til bendis af annarri gerð.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // ÖRYGGI: Unique::new_unchecked() skapar nýja sérstöðu og þarfir
        // gefinn bendill til að vera ekki núll.
        // Þar sem við erum að fara framhjá sjálfum okkur sem vísari getur það ekki verið null.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // ÖRYGGI: Breytileg tilvísun getur ekki verið engin
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}