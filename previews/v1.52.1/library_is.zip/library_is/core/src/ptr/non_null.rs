use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` en ekki núll og fylgibreytandi.
///
/// Þetta er oft rétti hluturinn til að nota þegar gagnauppbygging er notuð með hráum ábendingum, en er að lokum hættulegri í notkun vegna viðbótareiginleika þess.Ef þú ert ekki viss um hvort þú ættir að nota `NonNull<T>`, notaðu bara `*mut T`!
///
/// Ólíkt `*mut T`, bendirinn verður alltaf að vera enginn, jafnvel þó að bendillinn sé aldrei annars vegar.Þetta er til þess að enums geti notað þetta bannaða gildi sem mismunun-`Option<NonNull<T>>` hefur sömu stærð og `* mut T`.
/// Hins vegar getur bendillinn samt dinglað ef ekki er vísað til hans.
///
/// Ólíkt `*mut T` var `NonNull<T>` valinn til að vera samhliða `T`.Þetta gerir það mögulegt að nota `NonNull<T>` þegar verið er að byggja tegundir af breytum, en kynnir hættuna á óheilbrigði ef það er notað í gerð sem ætti í raun ekki að vera breytileg.
/// (Hið gagnstæða val var gert fyrir `*mut T` þó að tæknilega séð gæti óheiðarleiki aðeins stafað af því að kalla óörugga aðgerðir.)
///
/// Aðskilnaður er réttur fyrir flestar öruggar ágrip, svo sem `Box`, `Rc`, `Arc`, `Vec` og `LinkedList`.Þetta er tilfellið vegna þess að þeir bjóða upp á almennt API sem fylgir venjulegum sameiginlegum XOR breytilegum reglum Rust.
///
/// Ef tegund þín getur ekki verið meðfædd á öruggan hátt, verður þú að tryggja að hún innihaldi einhver viðbótarsvið til að veita óbreytileika.Oft verður þessi reitur af gerðinni [`PhantomData`] eins og `PhantomData<Cell<T>>` eða `PhantomData<&'a mut T>`.
///
/// Takið eftir að `NonNull<T>` hefur `From` dæmi fyrir `&T`.Þetta breytir þó ekki þeirri staðreynd að stökkbreyting í gegnum (bendi fengin frá a) sameiginlegri tilvísun er óskilgreind hegðun nema stökkbreytingin gerist inni í [`UnsafeCell<T>`].Sama gildir um að búa til breytanlega tilvísun úr sameiginlegri tilvísun.
///
/// Þegar þú notar þetta `From` dæmi án `UnsafeCell<T>` er það á þína ábyrgð að tryggja að aldrei sé hringt í `as_mut` og `as_ptr` er aldrei notað til stökkbreytingar.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` ábendingar eru ekki `Send` vegna þess að gögnin sem þau vísa til geta verið samhverf.
// NB, þetta impl er óþarfi en ætti að veita betri villuboð.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` ábendingar eru ekki `Sync` vegna þess að gögnin sem þau vísa til geta verið samhverf.
// NB, þetta impl er óþarfi en ætti að veita betri villuboð.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Býr til nýjan `NonNull` sem er dinglandi en vel stilltur.
    ///
    /// Þetta er gagnlegt til að frumstilla tegundir sem úthluta letilega, eins og `Vec::new` gerir.
    ///
    /// Athugaðu að bendilgildið getur hugsanlega táknað gildan bendil á `T`, sem þýðir að þetta má ekki nota sem "not yet initialized" sentinel gildi.
    /// Tegundir sem úthluta letilega verða að rekja frumstillingu með öðrum hætti.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // ÖRYGGI: mem::align_of() skilar stærð sem ekki er núll sem síðan er steypt
        // til a * mut T.
        // Þess vegna er `ptr` ekki null og skilyrðin til að hringja í new_unchecked() eru virt.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Skilar sameiginlegum tilvísunum í gildi.Öfugt við [`as_ref`], þetta krefst ekki þess að upphafið verði.
    ///
    /// Fyrir breytanlegan hliðstæðu, sjá [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Þegar þú hringir í þessa aðferð verður þú að tryggja að allt eftirfarandi sé satt:
    ///
    /// * Bendillinn verður að vera rétt stilltur.
    ///
    /// * Það verður að vera "dereferencable" í þeim skilningi sem skilgreint er í [the module documentation].
    ///
    /// * Þú verður að framfylgja alias reglum Rust, þar sem skilað líftími `'a` er valinn geðþótta og endurspeglar ekki endilega raunverulegan líftíma gagnanna.
    ///
    ///   Sérstaklega, meðan á þessari líftíma stendur, má minni sem bendillinn bendir á ekki verða stökkbreytt (nema inni í `UnsafeCell`).
    ///
    /// Þetta á við þó niðurstaðan af þessari aðferð sé ónotuð!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // ÖRYGGI: sá sem hringir þarf að ábyrgjast að `self` uppfylli öll
        // kröfur um tilvísun.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Skilar einstökum tilvísunum í gildi.Öfugt við [`as_mut`], þetta krefst ekki þess að upphafið verði.
    ///
    /// Fyrir hlutaðeigandi hliðstæðu sjá [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Þegar þú hringir í þessa aðferð verður þú að tryggja að allt eftirfarandi sé satt:
    ///
    /// * Bendillinn verður að vera rétt stilltur.
    ///
    /// * Það verður að vera "dereferencable" í þeim skilningi sem skilgreint er í [the module documentation].
    ///
    /// * Þú verður að framfylgja alias reglum Rust, þar sem skilað líftími `'a` er valinn geðþótta og endurspeglar ekki endilega raunverulegan líftíma gagnanna.
    ///
    ///   Sérstaklega, meðan á þessari ævi stendur, má ekki nálgast (lesa eða skrifa) minnið sem bendillinn bendir á í gegnum neinn annan bendil.
    ///
    /// Þetta á við þó niðurstaðan af þessari aðferð sé ónotuð!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // ÖRYGGI: sá sem hringir þarf að ábyrgjast að `self` uppfylli öll
        // kröfur um tilvísun.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Býr til nýjan `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` verður að vera ekki núll.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // ÖRYGGI: sá sem hringir verður að ábyrgjast að `ptr` sé ekki núll.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Býr til nýjan `NonNull` ef `ptr` er ekki núll.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // ÖRYGGI: Bendillinn er þegar merktur og er ekki enginn
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Framkvæmir sömu virkni og [`std::ptr::from_raw_parts`], nema að `NonNull` bendi er skilað, öfugt við hráan `*const` bendil.
    ///
    ///
    /// Sjá skjöl [`std::ptr::from_raw_parts`] fyrir frekari upplýsingar.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // ÖRYGGI: Niðurstaðan af `ptr::from::raw_parts_mut` er ekki núll vegna þess að `data_address` er.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Niðurbrot (hugsanlega breiður) bendill í er heimilisfang og lýsigagnahluti.
    ///
    /// Síðan er hægt að endurgera bendilinn með [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Fær undirliggjandi `*mut` bendi.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Skilar sameiginlegri tilvísun í gildi.Ef mögulega er uninitized gildi verður að nota [`as_uninit_ref`] í staðinn.
    ///
    /// Fyrir breytanlegan hliðstæðu, sjá [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Þegar þú hringir í þessa aðferð verður þú að tryggja að allt eftirfarandi sé satt:
    ///
    /// * Bendillinn verður að vera rétt stilltur.
    ///
    /// * Það verður að vera "dereferencable" í þeim skilningi sem skilgreint er í [the module documentation].
    ///
    /// * Bendillinn verður að benda á frumstillt dæmi um `T`.
    ///
    /// * Þú verður að framfylgja alias reglum Rust, þar sem skilað líftími `'a` er valinn geðþótta og endurspeglar ekki endilega raunverulegan líftíma gagnanna.
    ///
    ///   Sérstaklega, meðan á þessari líftíma stendur, má minni sem bendillinn bendir á ekki verða stökkbreytt (nema inni í `UnsafeCell`).
    ///
    /// Þetta á við þó niðurstaðan af þessari aðferð sé ónotuð!
    /// (Hlutinn um frumstilling er ekki enn ákveðinn að fullu, en þangað til það er, er eina örugga leiðin að tryggja að þeir séu örugglega frumstilltir.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // ÖRYGGI: sá sem hringir þarf að ábyrgjast að `self` uppfylli öll
        // kröfur um tilvísun.
        unsafe { &*self.as_ptr() }
    }

    /// Skilar einstakri tilvísun í gildi.Ef mögulega er uninitized gildi verður að nota [`as_uninit_mut`] í staðinn.
    ///
    /// Fyrir hlutaðeigandi hliðstæðu sjá [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Þegar þú hringir í þessa aðferð verður þú að tryggja að allt eftirfarandi sé satt:
    ///
    /// * Bendillinn verður að vera rétt stilltur.
    ///
    /// * Það verður að vera "dereferencable" í þeim skilningi sem skilgreint er í [the module documentation].
    ///
    /// * Bendillinn verður að benda á frumstillt dæmi um `T`.
    ///
    /// * Þú verður að framfylgja alias reglum Rust, þar sem skilað líftími `'a` er valinn geðþótta og endurspeglar ekki endilega raunverulegan líftíma gagnanna.
    ///
    ///   Sérstaklega, meðan á þessari ævi stendur, má ekki nálgast (lesa eða skrifa) minnið sem bendillinn bendir á í gegnum neinn annan bendil.
    ///
    /// Þetta á við þó niðurstaðan af þessari aðferð sé ónotuð!
    /// (Hlutinn um frumstilling er ekki enn ákveðinn að fullu, en þangað til það er, er eina örugga leiðin að tryggja að þeir séu örugglega frumstilltir.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // ÖRYGGI: sá sem hringir þarf að ábyrgjast að `self` uppfylli öll
        // kröfur um breytanlega tilvísun.
        unsafe { &mut *self.as_ptr() }
    }

    /// Varpar til bendis af annarri gerð.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // ÖRYGGI: `self` er `NonNull` bendill sem er endilega ekki núll
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Býr til hráa sneið sem ekki er núll úr þunnum bendli og lengd.
    ///
    /// `len` rökin eru fjöldi **þátta**, ekki fjöldi bæti.
    ///
    /// Þessi aðgerð er örugg, en aðferða skilagildið er óöruggt.
    /// Sjá skjöl [`slice::from_raw_parts`] varðandi öryggiskröfur um sneiðar.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // búðu til sneiðabend þegar þú byrjar með bendi á fyrsta þáttinn
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Athugið að þetta dæmi sýnir tilbúnar notkun þessarar aðferðar, en `let snittu= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // ÖRYGGI: `data` er `NonNull` bendill sem er endilega ekki núll
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Skilar lengd óunninnar sneiðar.
    ///
    /// Skilað gildi er fjöldi **þátta**, ekki fjöldi bæti.
    ///
    /// Þessi aðgerð er örugg, jafnvel þegar ekki er hægt að vísa hrá sneiðinni sem ekki er núll í sneið vegna þess að bendillinn hefur ekki gilt heimilisfang.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Skilar bendi sem ekki er núll í biðminni sneiðarinnar.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // ÖRYGGI: Við vitum að `self` er ekki núll.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Skilar hráum bendli í biðminni sneiðarinnar.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Skilar samnýttri tilvísun í sneið af mögulega ófrumgerðum gildum.Öfugt við [`as_ref`], þetta krefst ekki þess að upphafið verði.
    ///
    /// Fyrir breytanlegan hliðstæðu, sjá [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Þegar þú hringir í þessa aðferð verður þú að tryggja að allt eftirfarandi sé satt:
    ///
    /// * Bendillinn verður að vera [valid] til að lesa fyrir `ptr.len() * mem::size_of::<T>()` mörg bæti og hann verður að vera rétt stilltur.Þetta þýðir sérstaklega:
    ///
    ///     * Allt minnissvið þessarar sneiðar verður að vera innan eins úthlutaðs hlutar!
    ///       Sneiðar geta aldrei spannað yfir marga úthlutaða hluti.
    ///
    ///     * Bendillinn verður að vera samstilltur, jafnvel fyrir sneiðar í núlllengd.
    ///     Ein ástæðan fyrir þessu er sú að fínstillingar enum skipulags geta reitt sig á að tilvísanir (þ.m.t. sneiðar af hvaða lengd sem er) séu samstilltar og ekki núllar til að greina þær frá öðrum gögnum.
    ///
    ///     Þú getur fengið bendi sem er nothæfur sem `data` fyrir sneiðar án lengdar með því að nota [`NonNull::dangling()`].
    ///
    /// * Heildarstærð `ptr.len() * mem::size_of::<T>()` sneiðarinnar má ekki vera stærri en `isize::MAX`.
    ///   Sjá öryggisgögn [`pointer::offset`].
    ///
    /// * Þú verður að framfylgja alias reglum Rust, þar sem skilað líftími `'a` er valinn geðþótta og endurspeglar ekki endilega raunverulegan líftíma gagnanna.
    ///   Sérstaklega, meðan á þessari líftíma stendur, má minni sem bendillinn bendir á ekki verða stökkbreytt (nema inni í `UnsafeCell`).
    ///
    /// Þetta á við þó niðurstaðan af þessari aðferð sé ónotuð!
    ///
    /// Sjá einnig [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Skilar sérstæðri tilvísun í sneið af mögulega ófrumgerðum gildum.Öfugt við [`as_mut`], þetta krefst ekki þess að upphafið verði.
    ///
    /// Fyrir hlutaðeigandi hliðstæðu sjá [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Þegar þú hringir í þessa aðferð verður þú að tryggja að allt eftirfarandi sé satt:
    ///
    /// * Bendillinn verður að vera [valid] til að lesa og skrifa fyrir `ptr.len() * mem::size_of::<T>()` mörg bæti og hann verður að vera rétt stilltur.Þetta þýðir sérstaklega:
    ///
    ///     * Allt minnissvið þessarar sneiðar verður að vera innan eins úthlutaðs hlutar!
    ///       Sneiðar geta aldrei spannað yfir marga úthlutaða hluti.
    ///
    ///     * Bendillinn verður að vera samstilltur, jafnvel fyrir sneiðar í núlllengd.
    ///     Ein ástæðan fyrir þessu er sú að fínstillingar enum skipulags geta reitt sig á að tilvísanir (þ.m.t. sneiðar af hvaða lengd sem er) séu samstilltar og ekki núllar til að greina þær frá öðrum gögnum.
    ///
    ///     Þú getur fengið bendi sem er nothæfur sem `data` fyrir sneiðar án lengdar með því að nota [`NonNull::dangling()`].
    ///
    /// * Heildarstærð `ptr.len() * mem::size_of::<T>()` sneiðarinnar má ekki vera stærri en `isize::MAX`.
    ///   Sjá öryggisgögn [`pointer::offset`].
    ///
    /// * Þú verður að framfylgja alias reglum Rust, þar sem skilað líftími `'a` er valinn geðþótta og endurspeglar ekki endilega raunverulegan líftíma gagnanna.
    ///   Sérstaklega, meðan á þessari ævi stendur, má ekki nálgast (lesa eða skrifa) minnið sem bendillinn bendir á í gegnum neinn annan bendil.
    ///
    /// Þetta á við þó niðurstaðan af þessari aðferð sé ónotuð!
    ///
    /// Sjá einnig [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Þetta er öruggt þar sem `memory` gildir fyrir lestur og skrifun fyrir `memory.len()` mörg bæti.
    /// // Athugaðu að það er ekki leyfilegt að hringja í `memory.as_mut()` hér þar sem efnið gæti verið óupplýst.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // ÖRYGGI: sá sem hringir verður að standa við öryggissamninginn fyrir `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Skilar hráum músarbendi í frumefni eða undirþrep, án þess að gera mörkin.
    ///
    /// Að hringja í þessa aðferð með vísitölu utan marka eða þegar `self` er ekki hægt að vísa til er *[óskilgreint atferli]*, jafnvel þó bendillinn sem myndast er ekki notaður.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // ÖRYGGI: sá sem hringir tryggir að `self` sé færanlegur og `index` innan marka.
        // Sem afleiðing getur bendillinn sem myndast ekki verið NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // ÖRYGGI: Einstakur bendill getur ekki verið enginn, svo skilyrðin fyrir
        // new_unchecked() eru virt.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // ÖRYGGI: Breytileg tilvísun getur ekki verið engin.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // ÖRYGGI: Tilvísun getur ekki verið engin, svo skilyrðin fyrir
        // new_unchecked() eru virt.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}