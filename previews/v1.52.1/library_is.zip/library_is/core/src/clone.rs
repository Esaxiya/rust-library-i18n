//! `Clone` trait fyrir gerðir sem ekki er hægt að " afrita óbeint`.
//!
//! Í Rust eru nokkrar einfaldar gerðir "implicitly copyable" og þegar þú úthlutar þeim eða sendir þær sem rök fær móttakandinn afrit og skilur eftir upphaflegu gildi.
//! Þessar tegundir þurfa ekki úthlutun til að afrita og hafa ekki lokaafgerðir (þ.e. þær innihalda ekki kassa sem eru í eigu eða innleiða [`Drop`]), þannig að þýðandinn telur þá ódýra og óhætt að afrita.
//!
//! Fyrir aðrar gerðir verður að taka afrit skýrt með því að samþykkja [`Clone`] trait og kalla [`clone`] aðferðina.
//!
//! [`clone`]: Clone::clone
//!
//! Grunn notkunardæmi:
//!
//! ```
//! let s = String::new(); // Útfærslur á strengjategund Clone
//! let copy = s.clone(); // svo við getum klónað það
//! ```
//!
//! Til að auðvelda útfæra Clone trait geturðu líka notað `#[derive(Clone)]`.Dæmi:
//!
//! ```
//! #[derive(Clone)] // við bætum við klóninn trait við Morpheus struct
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // og nú getum við klónað það!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Algeng trait fyrir hæfileikann til að afrita hlut beinlínis.
///
/// Aðgreinir frá [`Copy`] að því leyti að [`Copy`] er óbeint og mjög ódýrt, á meðan `Clone` er alltaf skýrt og getur verið dýrt eða ekki.
/// Til að framfylgja þessum eiginleikum leyfir Rust þér ekki að endurútfæra [`Copy`], en þú getur endurútfært `Clone` og keyrt handahófskennda kóða.
///
/// Þar sem `Clone` er almennara en [`Copy`] geturðu sjálfkrafa látið allt [`Copy`] vera `Clone` líka.
///
/// ## Derivable
///
/// Þetta trait er hægt að nota með `#[derive]` ef allir reitir eru `Clone`.Útfærsla [`Clone`] kallar [`clone`] á hverju sviði.
///
/// [`clone`]: Clone::clone
///
/// Fyrir almenna uppbyggingu útfærir `#[derive]` `Clone` með skilyrðum með því að bæta bundnu `Clone` við almennar breytur.
///
/// ```
/// // `derive` útfærir Clone fyrir lestur<T>þegar T er klón.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Hvernig get ég útfært `Clone`?
///
/// Tegundir sem eru [`Copy`] ættu að hafa léttvæga útfærslu á `Clone`.Formlega:
/// ef `T: Copy`, `x: T` og `y: &T`, þá jafngildir `let x = y.clone();` `let x = *y;`.
/// Handvirkar útfærslur ættu að vera varkár til að viðhalda þessum óbreytileika;óöruggur kóði má þó ekki reiða sig á hann til að tryggja minni öryggi.
///
/// Dæmi er almenn uppbygging sem heldur á fallbendi.Í þessu tilfelli er ekki hægt að " innleiða` `Clone` heldur er hægt að útfæra það sem:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Viðbótar útfærsluaðilar
///
/// Auk [implementors listed below][impls] innleiða eftirfarandi gerðir einnig `Clone`:
///
/// * Gerðir hlutaliða (þ.e. skilgreindar gerðir skilgreindar fyrir hverja aðgerð)
/// * Gerðir bendipinna (td `fn() -> i32`)
/// * Fylkisgerðir, fyrir allar stærðir, ef vörutegundin útfærir einnig `Clone` (td `[i32; 123456]`)
/// * Tuple gerðir, ef hver hluti útfærir einnig `Clone` (td `()`, `(i32, bool)`)
/// * Lokunartegundir, ef þær fanga engin gildi úr umhverfinu eða ef öll slík fanga gildi innleiða `Clone` sjálf.
///   Athugaðu að breytur sem eru teknar með sameiginlegri tilvísun innleiða alltaf `Clone` (jafnvel þó að tilvísunin geri það ekki), en breytur sem eru teknar með breytilegri tilvísun innleiða aldrei `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Skilar afriti af gildinu.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str útfærir Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Framkvæmir afritaverkefni frá `source`.
    ///
    /// `a.clone_from(&b)` jafngildir `a = b.clone()` í virkni, en hægt er að hnekkja því til að endurnýta auðlindir `a` til að forðast óþarfa úthlutun.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Aflaðu makró sem myndar ígræðslu af trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): þessi lög eru eingöngu notuð af#[leiða] til að fullyrða að sérhver hluti af gerðinni útfærir klón eða afrit.
//
//
// Þessir strengir ættu aldrei að birtast í notendakóða.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Útfærsla `Clone` fyrir frumstæðar gerðir.
///
/// Útfærslur sem ekki er hægt að lýsa í Rust eru útfærðar í `traits::SelectionContext::copy_clone_conditions()` í `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Hægt er að klóna sameiginlegar tilvísanir en breytilegar tilvísanir *ekki*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Hægt er að klóna sameiginlegar tilvísanir en breytilegar tilvísanir *ekki*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}