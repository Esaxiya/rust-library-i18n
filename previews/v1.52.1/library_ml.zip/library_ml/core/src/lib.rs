//! # Rust കോർ ലൈബ്രറി
//!
//! [The Rust Standard Library](../std/index.html)-ന്റെ ഡിപൻഡൻസി-ഫ്രീ [^ സ] ജന്യ] അടിത്തറയാണ് Rust കോർ ലൈബ്രറി.
//! ഭാഷയും അതിന്റെ ലൈബ്രറികളും തമ്മിലുള്ള പോർട്ടബിൾ പശയാണ് ഇത്, എല്ലാ Rust കോഡുകളുടെയും ആന്തരികവും പ്രാകൃതവുമായ ബിൽഡിംഗ് ബ്ലോക്കുകൾ നിർവചിക്കുന്നു.
//!
//! ഇത് അപ്‌സ്ട്രീം ലൈബ്രറികളിലേക്കോ സിസ്റ്റം ലൈബ്രറികളിലേക്കോ ലിബ്‌സിയിലേക്കോ ലിങ്കുചെയ്യുന്നില്ല.
//!
//! [^free]: Strictly സംസാരിക്കുമ്പോൾ, ചില ചിഹ്നങ്ങൾ ആവശ്യമാണ്, പക്ഷേ
//!          അവ എല്ലായ്പ്പോഴും ആവശ്യമില്ല.
//!
//! കോർ ലൈബ്രറി *ചുരുങ്ങിയത്* ആണ്: ഇത് കൂമ്പാര വിഹിതത്തെക്കുറിച്ച് പോലും അറിയില്ല, മാത്രമല്ല ഇത് കൺകറൻസിയോ എക്സ് 100 എക്സോ നൽകുന്നില്ല.
//! ഈ കാര്യങ്ങൾക്ക് പ്ലാറ്റ്ഫോം സംയോജനം ആവശ്യമാണ്, ഈ ലൈബ്രറി പ്ലാറ്റ്ഫോം-അജ്ഞ്ഞേയവാദി ആണ്.
//!
//! # കോർ ലൈബ്രറി എങ്ങനെ ഉപയോഗിക്കാം
//!
//! ഈ വിശദാംശങ്ങളെല്ലാം നിലവിൽ സ്ഥിരതയായി കണക്കാക്കുന്നില്ലെന്നത് ശ്രദ്ധിക്കുക.
//!
//!
//!
// FIXME: ഇന്റർഫേസ് സെറ്റിൽ ചെയ്യുമ്പോൾ കൂടുതൽ വിശദമായി എന്നെ പൂരിപ്പിക്കുക
//! നിലവിലുള്ള കുറച്ച് ചിഹ്നങ്ങളുടെ അനുമാനത്തിലാണ് ഈ ലൈബ്രറി നിർമ്മിച്ചിരിക്കുന്നത്:
//!
//! * `memcpy`, `memcmp`, `memset`, ഇവ എൽ‌എൽ‌വി‌എം സൃഷ്ടിക്കുന്ന കോർ മെമ്മറി ദിനചര്യകളാണ്.
//! കൂടാതെ, ഈ ഫംഗ്ഷനുകളിലേക്ക് വ്യക്തമായ കോളുകൾ വിളിക്കാൻ ഈ ലൈബ്രറിക്ക് കഴിയും.
//! അവരുടെ ഒപ്പുകൾ സിയിൽ കാണുന്നതുപോലെയാണ്.
//!   ഈ ഫംഗ്ഷനുകൾ പലപ്പോഴും സിസ്റ്റം libc നൽകുന്നു, പക്ഷേ [compiler-builtins crate](https://crates.io/crates/compiler_builtins)-നും നൽകാം.
//!
//!
//! * `rust_begin_panic` - ഈ ഫംഗ്ഷന് നാല് ആർ‌ഗ്യുമെൻറുകൾ‌, ഒരു `fmt::Arguments`, ഒരു `&'static str`, രണ്ട് `u32` എന്നിവ എടുക്കുന്നു.
//! ഈ നാല് ആർ‌ഗ്യുമെൻറുകൾ‌panic സന്ദേശം, panic അഭ്യർ‌ത്ഥിച്ച ഫയൽ‌, ഫയലിനുള്ളിലെ വരിയും നിരയും നിർ‌ണ്ണയിക്കുന്നു.
//! ഈ panic ഫംഗ്ഷൻ നിർവചിക്കേണ്ടത് ഈ കോർ ലൈബ്രറിയിലെ ഉപഭോക്താക്കളാണ്;ഒരിക്കലും മടങ്ങിവരേണ്ടതില്ല.
//! ഇതിന് `panic_impl` എന്ന് പേരുള്ള `lang` ആട്രിബ്യൂട്ട് ആവശ്യമാണ്.
//!
//! * `rust_eh_personality` - കംപൈലറിന്റെ പരാജയ സംവിധാനങ്ങൾ ഉപയോഗിക്കുന്നു.
//! ഇത് പലപ്പോഴും GCC ന്റെ വ്യക്തിത്വ ഫംഗ്ഷനിലേക്ക് മാപ്പുചെയ്യുന്നു, പക്ഷേ panic പ്രവർത്തനക്ഷമമാക്കാത്ത crates ഈ ഫംഗ്ഷനെ ഒരിക്കലും വിളിക്കില്ലെന്ന് ഉറപ്പുനൽകുന്നു.
//! `lang` ആട്രിബ്യൂട്ടിനെ `eh_personality` എന്ന് വിളിക്കുന്നു.
//!
//!
//!

// നിരവധി അടിസ്ഥാന ലാംഗ് ഇനങ്ങളെ ലിബ്‌കോർ‌നിർ‌വ്വചിക്കുന്നതിനാൽ‌, വിചിത്രമായ പ്രശ്‌നങ്ങൾ‌ഒഴിവാക്കുന്നതിന് എല്ലാ ടെസ്റ്റുകളും ഒരു പ്രത്യേക crate, libcoretest ൽ‌താമസിക്കുന്നു.
//
// ഇവിടെ ഞങ്ങൾ വ്യക്തമായി#[cfg]-പരിശോധിക്കുമ്പോൾ ഈ crate മുഴുവനും.
// ഞങ്ങൾ ഇത് ചെയ്യുന്നില്ലെങ്കിൽ, ജനറേറ്റുചെയ്ത ടെസ്റ്റ് ആർട്ടിഫാക്റ്റും ലിങ്കുചെയ്ത ലിബ്റ്റെസ്റ്റും (അതിൽ ലിബ്കോർ ഉൾപ്പെടുന്നു) രണ്ടും ഒരേ ലാംഗ് ഇനങ്ങളെ നിർവചിക്കും, ഇത് E0152 "found duplicate lang item" പിശകിന് കാരണമാകും.
//
// വിശദാംശങ്ങൾക്ക് #50466-ലെ ചർച്ച കാണുക.
//
// ഈ cfg പ്രമാണ പരിശോധനകളെ ബാധിക്കില്ല.
//
//
#![cfg(not(test))]
#![stable(feature = "core", since = "1.6.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![no_core]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(asm)]
#![feature(cfg_target_has_atomic)]
#![feature(const_heap)]
#![feature(const_alloc_layout)]
#![feature(const_assert_type)]
#![feature(const_discriminant)]
#![feature(const_cell_into_inner)]
#![feature(const_intrinsic_copy)]
#![feature(const_intrinsic_forget)]
#![feature(const_float_classify)]
#![feature(const_float_bits_conv)]
#![feature(const_int_unchecked_arith)]
#![feature(const_mut_refs)]
#![feature(const_refs_to_cell)]
#![feature(const_cttz)]
#![feature(const_panic)]
#![feature(const_pin)]
#![feature(const_fn)]
#![feature(const_fn_union)]
#![feature(const_impl_trait)]
#![feature(const_fn_floating_point_arithmetic)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(const_option)]
#![feature(const_precise_live_drops)]
#![feature(const_ptr_offset)]
#![feature(const_ptr_offset_from)]
#![feature(const_ptr_read)]
#![feature(const_ptr_write)]
#![feature(const_raw_ptr_comparison)]
#![feature(const_raw_ptr_deref)]
#![feature(const_slice_from_raw_parts)]
#![feature(const_slice_ptr_len)]
#![feature(const_size_of_val)]
#![feature(const_swap)]
#![feature(const_align_of_val)]
#![feature(const_type_id)]
#![feature(const_type_name)]
#![feature(const_likely)]
#![feature(const_unreachable_unchecked)]
#![feature(const_maybe_uninit_assume_init)]
#![feature(const_maybe_uninit_as_ptr)]
#![feature(custom_inner_attributes)]
#![feature(decl_macro)]
#![feature(doc_cfg)]
#![feature(doc_spotlight)]
#![feature(duration_consts_2)]
#![feature(duration_saturating_ops)]
#![feature(extended_key_value_attributes)]
#![feature(extern_types)]
#![feature(fundamental)]
#![feature(intra_doc_pointers)]
#![feature(intrinsics)]
#![feature(lang_items)]
#![feature(link_llvm_intrinsics)]
#![feature(llvm_asm)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(exhaustive_patterns)]
#![feature(no_core)]
#![feature(auto_traits)]
#![feature(or_patterns)]
#![feature(prelude_import)]
#![cfg_attr(not(bootstrap), feature(ptr_metadata))]
#![feature(repr_simd, platform_intrinsics)]
#![feature(rustc_attrs)]
#![feature(simd_ffi)]
#![feature(min_specialization)]
#![feature(staged_api)]
#![feature(std_internals)]
#![feature(stmt_expr_attributes)]
#![feature(str_split_as_str)]
#![feature(str_split_inclusive_as_str)]
#![feature(trait_alias)]
#![feature(transparent_unions)]
#![feature(try_blocks)]
#![feature(unboxed_closures)]
#![feature(unsized_fn_params)]
#![feature(unwind_attributes)]
#![feature(variant_count)]
#![feature(tbm_target_feature)]
#![feature(sse4a_target_feature)]
#![feature(arm_target_feature)]
#![feature(powerpc_target_feature)]
#![feature(mips_target_feature)]
#![feature(aarch64_target_feature)]
#![feature(wasm_target_feature)]
#![feature(avx512_target_feature)]
#![feature(cmpxchg16b_target_feature)]
#![feature(rtm_target_feature)]
#![feature(f16c_target_feature)]
#![feature(hexagon_target_feature)]
#![feature(const_fn_transmute)]
#![feature(abi_unadjusted)]
#![feature(adx_target_feature)]
#![feature(external_doc)]
#![feature(associated_type_bounds)]
#![feature(const_caller_location)]
#![feature(slice_ptr_get)]
#![feature(no_niche)] // rust-lang/rust#68303
#![feature(int_error_matching)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![deny(unsafe_op_in_unsafe_fn)]

#[prelude_import]
#[allow(unused)]
use prelude::v1::*;

#[cfg(not(test))] // #65860 കാണുക
#[macro_use]
mod macros;

#[macro_use]
mod internal_macros;

#[path = "num/shells/int_macros.rs"]
#[macro_use]
mod int_macros;

#[path = "num/shells/i128.rs"]
pub mod i128;
#[path = "num/shells/i16.rs"]
pub mod i16;
#[path = "num/shells/i32.rs"]
pub mod i32;
#[path = "num/shells/i64.rs"]
pub mod i64;
#[path = "num/shells/i8.rs"]
pub mod i8;
#[path = "num/shells/isize.rs"]
pub mod isize;

#[path = "num/shells/u128.rs"]
pub mod u128;
#[path = "num/shells/u16.rs"]
pub mod u16;
#[path = "num/shells/u32.rs"]
pub mod u32;
#[path = "num/shells/u64.rs"]
pub mod u64;
#[path = "num/shells/u8.rs"]
pub mod u8;
#[path = "num/shells/usize.rs"]
pub mod usize;

#[path = "num/f32.rs"]
pub mod f32;
#[path = "num/f64.rs"]
pub mod f64;

#[macro_use]
pub mod num;

/* The libcore prelude, not as all-encompassing as the libstd prelude */

pub mod prelude;

/* Core modules for ownership management */

pub mod hint;
pub mod intrinsics;
pub mod mem;
pub mod ptr;

/* Core language traits */

pub mod borrow;
pub mod clone;
pub mod cmp;
pub mod convert;
pub mod default;
pub mod marker;
pub mod ops;

/* Core types and methods on primitives */

pub mod any;
pub mod array;
pub mod ascii;
pub mod cell;
pub mod char;
pub mod ffi;
pub mod iter;
#[unstable(feature = "once_cell", issue = "74465")]
pub mod lazy;
pub mod option;
pub mod panic;
pub mod panicking;
pub mod pin;
pub mod raw;
pub mod result;
#[unstable(feature = "async_stream", issue = "79024")]
pub mod stream;
pub mod sync;

pub mod fmt;
pub mod hash;
pub mod slice;
pub mod str;
pub mod time;

pub mod unicode;

/* Async */
pub mod future;
pub mod task;

/* Heap memory allocator trait */
#[allow(missing_docs)]
pub mod alloc;

// note: പൊതുവായിരിക്കേണ്ടതില്ല
mod bool;
mod tuple;
mod unit;

#[stable(feature = "core_primitive", since = "1.43.0")]
pub mod primitive;

// `core_arch` crate-ൽ നേരിട്ട് ലിബ്‌കോറിലേക്ക് വലിക്കുക.`core_arch`-ന്റെ ഉള്ളടക്കം മറ്റൊരു ശേഖരത്തിലാണ്: rust-lang/stdarch.
//
// `core_arch` ലിബ്കോറിനെ ആശ്രയിച്ചിരിക്കുന്നു, എന്നാൽ ഈ മൊഡ്യൂളിലെ ഉള്ളടക്കങ്ങൾ ഇവിടെ നേരിട്ട് വലിക്കുന്ന രീതിയിൽ സജ്ജീകരിച്ചിരിക്കുന്നു, അതായത് crate ഈ crate നെ അതിന്റെ ലിബ്കോറായി ഉപയോഗിക്കുന്നു.
//
//
//
#[path = "../../stdarch/crates/core_arch/src/mod.rs"]
#[allow(
    missing_docs,
    missing_debug_implementations,
    dead_code,
    unused_imports,
    unsafe_op_in_unsafe_fn
)]
#[cfg_attr(bootstrap, allow(non_autolinks))]
#[cfg_attr(not(bootstrap), allow(rustdoc::non_autolinks))]
// FIXME: Clashing_extern_declarations കഴിഞ്ഞാൽ ഈ വ്യാഖ്യാനം rust-lang/stdarch ലേക്ക് നീക്കണം
// ലയിപ്പിച്ചു.lint ഇതുവരെ നിർവചിച്ചിട്ടില്ലാത്തതിനാൽ ബൂട്ട്സ്ട്രാപ്പ് പരാജയപ്പെടുന്നതിനാൽ ഇതിന് നിലവിൽ കഴിയില്ല.
#[allow(clashing_extern_declarations)]
#[unstable(feature = "stdsimd", issue = "48556")]
mod core_arch;

#[stable(feature = "simd_arch", since = "1.27.0")]
pub use core_arch::arch;