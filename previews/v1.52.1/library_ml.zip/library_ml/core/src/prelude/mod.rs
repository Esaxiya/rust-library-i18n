//! ലിബ്കോർ prelude
//!
//! ഈ മൊഡ്യൂൾ libstd-ലേക്ക് ലിങ്കുചെയ്യാത്ത libcore ഉപയോക്താക്കൾക്കായി ഉദ്ദേശിച്ചുള്ളതാണ്.
//! സ്റ്റാൻഡേർഡ് ലൈബ്രറിയുടെ prelude-ന് സമാനമായ രീതിയിൽ `#![no_std]` ഉപയോഗിക്കുമ്പോൾ ഈ മൊഡ്യൂൾ സ്ഥിരസ്ഥിതിയായി ഇറക്കുമതി ചെയ്യുന്നു.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// കോർ prelude ന്റെ 2015 പതിപ്പ്.
///
/// കൂടുതൽ വിവരങ്ങൾക്ക് [module-level documentation](self) കാണുക.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// കോർ prelude-ന്റെ 2018 പതിപ്പ്.
///
/// കൂടുതൽ വിവരങ്ങൾക്ക് [module-level documentation](self) കാണുക.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// കോർ prelude-ന്റെ 2021 പതിപ്പ്.
///
/// കൂടുതൽ വിവരങ്ങൾക്ക് [module-level documentation](self) കാണുക.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: കൂടുതൽ കാര്യങ്ങൾ ചേർക്കുക.
}