//! ആറ്റോമിക് തരങ്ങൾ
//!
//! ആറ്റോമിക് തരങ്ങൾ ത്രെഡുകൾക്കിടയിൽ പ്രാകൃത പങ്കിട്ട-മെമ്മറി ആശയവിനിമയം നൽകുന്നു, മാത്രമല്ല മറ്റ് ഒരേസമയത്തെ നിർമാണ ബ്ലോക്കുകളുമാണ്.
//!
//! ഈ മൊഡ്യൂൾ [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`] മുതലായവ ഉൾപ്പെടെ തിരഞ്ഞെടുത്ത പ്രാകൃത തരങ്ങളുടെ ആറ്റോമിക് പതിപ്പുകൾ നിർവചിക്കുന്നു.
//! ശരിയായി ഉപയോഗിക്കുമ്പോൾ, ത്രെഡുകൾക്കിടയിൽ അപ്‌ഡേറ്റുകൾ സമന്വയിപ്പിക്കുന്ന പ്രവർത്തനങ്ങൾ ആറ്റോമിക് തരങ്ങൾ അവതരിപ്പിക്കുന്നു.
//!
//! ഓരോ രീതിയും ഒരു [`Ordering`] എടുക്കുന്നു, അത് ആ പ്രവർത്തനത്തിനുള്ള മെമ്മറി ബാരിയറിന്റെ ശക്തിയെ പ്രതിനിധീകരിക്കുന്നു.ഈ ഓർഡറുകൾ [C++20 atomic orderings][1]-ന് തുല്യമാണ്.കൂടുതൽ വിവരങ്ങൾക്ക് [nomicon][2] കാണുക.
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! ത്രെഡുകൾക്കിടയിൽ പങ്കിടുന്നതിന് ആറ്റോമിക് വേരിയബിളുകൾ സുരക്ഷിതമാണ് (അവ [`Sync`] നടപ്പിലാക്കുന്നു) എന്നാൽ അവ സ്വയം പങ്കിടുന്നതിനുള്ള സംവിധാനം നൽകുന്നില്ല, Rust ന്റെ [threading model](../../../std/thread/index.html#the-threading-model) പിന്തുടരുക.
//!
//! ഒരു ആറ്റോമിക് വേരിയബിൾ പങ്കിടാനുള്ള ഏറ്റവും സാധാരണമായ മാർഗ്ഗം അത് ഒരു [`Arc`][arc] (ആറ്റോമിക്കലി-റഫറൻസ്-കണക്കാക്കിയ പങ്കിട്ട പോയിന്റർ) ആക്കുക എന്നതാണ്.
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! ആറ്റോമിക് തരങ്ങൾ സ്റ്റാറ്റിക് വേരിയബിളുകളിൽ സംഭരിക്കാം, [`AtomicBool::new`] പോലുള്ള സ്ഥിരമായ ഇനീഷ്യലൈസറുകൾ ഉപയോഗിച്ച് സമാരംഭിക്കും.അലസമായ ആഗോള സമാരംഭത്തിനായി ആറ്റോമിക് സ്റ്റാറ്റിക്സ് പലപ്പോഴും ഉപയോഗിക്കുന്നു.
//!
//! # Portability
//!
//! ഈ മൊഡ്യൂളിലെ എല്ലാ ആറ്റോമിക് തരങ്ങളും ലഭ്യമാണെങ്കിൽ [lock-free] ആയിരിക്കുമെന്ന് ഉറപ്പുനൽകുന്നു.ഇതിനർത്ഥം അവർ ആന്തരികമായി ഒരു ആഗോള മ്യൂട്ടക്സ് സ്വന്തമാക്കുന്നില്ല എന്നാണ്.ആറ്റോമിക് തരങ്ങളും പ്രവർത്തനങ്ങളും കാത്തിരിപ്പ് രഹിതമാണെന്ന് ഉറപ്പില്ല.
//! ഇതിനർത്ഥം എക്സ്-00 എക്സ് പോലുള്ള പ്രവർത്തനങ്ങൾ താരതമ്യ-സ്വാപ്പ് ലൂപ്പ് ഉപയോഗിച്ച് നടപ്പിലാക്കാം.
//!
//! വലിയ വലിപ്പത്തിലുള്ള ആറ്റമിക്സ് ഉപയോഗിച്ച് ഇൻസ്ട്രക്ഷൻ ലെയറിൽ ആറ്റോമിക് പ്രവർത്തനങ്ങൾ നടപ്പിലാക്കാം.ഉദാഹരണത്തിന്, ചില പ്ലാറ്റ്ഫോമുകൾ `AtomicI8` നടപ്പിലാക്കാൻ 4-ബൈറ്റ് ആറ്റോമിക് നിർദ്ദേശങ്ങൾ ഉപയോഗിക്കുന്നു.
//! ഈ എമുലേഷൻ കോഡിന്റെ കൃത്യതയെ സ്വാധീനിക്കാൻ പാടില്ല എന്നത് ശ്രദ്ധിക്കുക, ഇത് അറിഞ്ഞിരിക്കേണ്ട ഒന്നാണ്.
//!
//! ഈ മൊഡ്യൂളിലെ ആറ്റോമിക് തരങ്ങൾ എല്ലാ പ്ലാറ്റ്ഫോമുകളിലും ലഭ്യമായേക്കില്ല.ഇവിടെയുള്ള ആറ്റോമിക് തരങ്ങളെല്ലാം വ്യാപകമായി ലഭ്യമാണ്, എന്നിരുന്നാലും നിലവിലുള്ളവയെ ആശ്രയിക്കാൻ കഴിയും.ശ്രദ്ധേയമായ ചില അപവാദങ്ങൾ ഇവയാണ്:
//!
//! * PowerPC 32-ബിറ്റ് പോയിന്ററുകളുള്ള MIPS പ്ലാറ്റ്ഫോമുകൾക്ക് `AtomicU64` അല്ലെങ്കിൽ `AtomicI64` തരങ്ങൾ ഇല്ല.
//! * ARM Linux-ന് അല്ലാത്ത `armv5te` പോലുള്ള പ്ലാറ്റ്‌ഫോമുകൾ `load`, `store` പ്രവർത്തനങ്ങൾ മാത്രം നൽകുന്നു, മാത്രമല്ല `swap`, `fetch_add` മുതലായ (CAS) പ്രവർത്തനങ്ങളെ താരതമ്യം ചെയ്ത് സ്വാപ്പ് ചെയ്യുന്നതിനെ പിന്തുണയ്‌ക്കുന്നില്ല.
//! കൂടാതെ Linux-ൽ, ഈ CAS പ്രവർത്തനങ്ങൾ [operating system support] വഴി നടപ്പിലാക്കുന്നു, ഇത് പ്രകടന പെനാൽറ്റിയുമായി വരാം.
//! * ARM `thumbv6m` ഉള്ള ടാർ‌ഗെറ്റുകൾ‌`load`, `store` പ്രവർ‌ത്തനങ്ങൾ‌മാത്രമേ നൽകുന്നുള്ളൂ, മാത്രമല്ല `swap`, `fetch_add` മുതലായവ താരതമ്യം ചെയ്ത് സ്വാപ്പ് (CAS) പ്രവർ‌ത്തനങ്ങളെ പിന്തുണയ്‌ക്കുന്നില്ല.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! ചില ആറ്റോമിക് പ്രവർത്തനങ്ങൾക്ക് പിന്തുണയില്ലാത്ത future പ്ലാറ്റ്ഫോമുകൾ ചേർക്കാമെന്നത് ശ്രദ്ധിക്കുക.ഏതൊക്കെ ആറ്റോമിക് തരങ്ങളാണ് ഉപയോഗിക്കുന്നതെന്ന് ശ്രദ്ധാപൂർവ്വം പോർട്ടബിൾ കോഡ് ആഗ്രഹിക്കുന്നു.
//! `AtomicUsize` `AtomicIsize` പൊതുവെ ഏറ്റവും പോർട്ടബിൾ ആണ്, പക്ഷേ അവ എല്ലായിടത്തും ലഭ്യമല്ല.
//! റഫറൻസിനായി, എക്സ് 00 എക്സ് ലൈബ്രറിക്ക് പോയിന്റർ-സൈസ് ആറ്റമിക്സ് ആവശ്യമാണ്, എന്നിരുന്നാലും എക്സ് 01 എക്സ് ആവശ്യമില്ല.
//!
//! നിലവിൽ ആറ്റോമിക്സുമായി കോഡിൽ സോപാധികമായി കംപൈൽ ചെയ്യുന്നതിന് നിങ്ങൾ പ്രാഥമികമായി `#[cfg(target_arch)]` ഉപയോഗിക്കേണ്ടതുണ്ട്.അസ്ഥിരമായ `#[cfg(target_has_atomic)]` ഉണ്ട്, അത് future-ൽ സ്ഥിരത കൈവരിക്കാം.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! ഒരു ലളിതമായ സ്പിൻ‌ലോക്ക്:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // മറ്റ് ത്രെഡ് ലോക്ക് റിലീസ് ചെയ്യുന്നതിനായി കാത്തിരിക്കുക
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! തത്സമയ ത്രെഡുകളുടെ ആഗോള എണ്ണം സൂക്ഷിക്കുക:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// ത്രെഡുകൾക്കിടയിൽ സുരക്ഷിതമായി പങ്കിടാൻ കഴിയുന്ന ഒരു ബൂളിയൻ തരം.
///
/// ഈ തരത്തിന് [`bool`]-ന് സമാനമായ മെമ്മറി പ്രാതിനിധ്യം ഉണ്ട്.
///
/// **കുറിപ്പ്**: `u8` ന്റെ ആറ്റോമിക് ലോഡുകളെയും സ്റ്റോറുകളെയും പിന്തുണയ്ക്കുന്ന പ്ലാറ്റ്ഫോമുകളിൽ മാത്രമേ ഈ തരം ലഭ്യമാകൂ.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// `false` ലേക്ക് സമാരംഭിച്ച ഒരു `AtomicBool` സൃഷ്ടിക്കുന്നു.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// അയയ്ക്കൽ ആറ്റോമിക്ബൂളിനായി വ്യക്തമായി നടപ്പിലാക്കുന്നു.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// ത്രെഡുകൾക്കിടയിൽ സുരക്ഷിതമായി പങ്കിടാൻ കഴിയുന്ന ഒരു റോ പോയിന്റർ തരം.
///
/// ഈ തരത്തിന് `*mut T`-ന് സമാനമായ മെമ്മറി പ്രാതിനിധ്യം ഉണ്ട്.
///
/// **കുറിപ്പ്**: ആറ്റോമിക് ലോഡുകളെയും പോയിന്ററുകളുടെ സ്റ്റോറുകളെയും പിന്തുണയ്ക്കുന്ന പ്ലാറ്റ്ഫോമുകളിൽ മാത്രമേ ഈ തരം ലഭ്യമാകൂ.
/// ടാർഗെറ്റ് പോയിന്ററിന്റെ വലുപ്പത്തെ ആശ്രയിച്ചിരിക്കും ഇതിന്റെ വലുപ്പം.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// ഒരു ശൂന്യമായ `AtomicPtr<T>` സൃഷ്ടിക്കുന്നു.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// ആറ്റോമിക് മെമ്മറി ക്രമങ്ങൾ
///
/// ആറ്റോമിക് പ്രവർത്തനങ്ങൾ മെമ്മറി സമന്വയിപ്പിക്കുന്ന രീതി മെമ്മറി ഓർഡറുകൾ വ്യക്തമാക്കുന്നു.
/// അതിന്റെ ഏറ്റവും ദുർബലമായ [`Ordering::Relaxed`]-ൽ, പ്രവർത്തനം നേരിട്ട് സ്പർശിച്ച മെമ്മറി മാത്രമേ സമന്വയിപ്പിക്കൂ.
/// മറുവശത്ത്, ഒരു സ്റ്റോർ-ലോഡ് ജോഡി [`Ordering::SeqCst`] പ്രവർത്തനങ്ങൾ മറ്റ് മെമ്മറിയെ സമന്വയിപ്പിക്കുകയും എല്ലാ ത്രെഡുകളിലുടനീളം അത്തരം പ്രവർത്തനങ്ങളുടെ ആകെ ക്രമം സംരക്ഷിക്കുകയും ചെയ്യുന്നു.
///
///
/// Rust-ന്റെ മെമ്മറി ഓർഡറുകൾ [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order) ആണ്.
///
/// കൂടുതൽ വിവരങ്ങൾക്ക് [nomicon] കാണുക.
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// ക്രമപ്പെടുത്തൽ നിയന്ത്രണങ്ങളൊന്നുമില്ല, ആറ്റോമിക് പ്രവർത്തനങ്ങൾ മാത്രം.
    ///
    /// C ++ 20 ലെ [`memory_order_relaxed`]-ന് യോജിക്കുന്നു.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// ഒരു സ്റ്റോറുമായി ചേരുമ്പോൾ, മുമ്പത്തെ എല്ലാ പ്രവർത്തനങ്ങളും ഈ മൂല്യത്തിന്റെ ഏതെങ്കിലും ലോഡിന് മുമ്പായി [`Acquire`] (അല്ലെങ്കിൽ ശക്തമായ) ഓർഡറിംഗ് ഉപയോഗിച്ച് ഓർഡർ ചെയ്യപ്പെടും.
    ///
    /// പ്രത്യേകിച്ചും, മുമ്പത്തെ എല്ലാ റൈറ്റുകളും ഈ മൂല്യത്തിന്റെ [`Acquire`] (അല്ലെങ്കിൽ ശക്തമായ) ലോഡ് ചെയ്യുന്ന എല്ലാ ത്രെഡുകൾക്കും ദൃശ്യമാകും.
    ///
    /// ലോഡുകളും സ്റ്റോറുകളും സംയോജിപ്പിക്കുന്ന ഒരു ഓപ്പറേഷനായി ഈ ഓർഡറിംഗ് ഉപയോഗിക്കുന്നത് ഒരു [`Relaxed`] ലോഡ് പ്രവർത്തനത്തിലേക്ക് നയിക്കുന്നു എന്നത് ശ്രദ്ധിക്കുക!
    ///
    /// ഒരു സ്റ്റോർ‌നിർ‌വ്വഹിക്കാൻ‌കഴിയുന്ന പ്രവർ‌ത്തനങ്ങൾ‌ക്ക് മാത്രമേ ഈ ഓർ‌ഡറിംഗ് ബാധകമാകൂ.
    ///
    /// C ++ 20 ലെ [`memory_order_release`]-ന് യോജിക്കുന്നു.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// ഒരു ലോഡിനൊപ്പം ചേരുമ്പോൾ, ലോഡ് ചെയ്ത മൂല്യം [`Release`] (അല്ലെങ്കിൽ ശക്തമായ) ഓർഡറിംഗ് ഉള്ള ഒരു സ്റ്റോർ ഓപ്പറേഷൻ എഴുതിയതാണെങ്കിൽ, തുടർന്നുള്ള എല്ലാ പ്രവർത്തനങ്ങളും ആ സ്റ്റോറിന് ശേഷം ഓർഡർ ആകും.
    /// പ്രത്യേകിച്ചും, തുടർന്നുള്ള എല്ലാ ലോഡുകളും സ്റ്റോറിന് മുമ്പായി എഴുതിയ ഡാറ്റ കാണും.
    ///
    /// ലോഡുകളും സ്റ്റോറുകളും സംയോജിപ്പിക്കുന്ന ഒരു ഓപ്പറേഷനായി ഈ ഓർഡറിംഗ് ഉപയോഗിക്കുന്നത് ഒരു [`Relaxed`] സ്റ്റോർ പ്രവർത്തനത്തിലേക്ക് നയിക്കുന്നു എന്നത് ശ്രദ്ധിക്കുക!
    ///
    /// ഒരു ലോഡ് ചെയ്യാൻ കഴിയുന്ന പ്രവർത്തനങ്ങൾക്ക് മാത്രമേ ഈ ഓർഡർ ബാധകമാകൂ.
    ///
    /// C ++ 20 ലെ [`memory_order_acquire`]-ന് യോജിക്കുന്നു.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// [`Acquire`], [`Release`] എന്നിവയുടെ ഇഫക്റ്റുകൾ ഒരുമിച്ച് ഉണ്ട്:
    /// ലോഡുകൾക്കായി ഇത് [`Acquire`] ഓർഡറിംഗ് ഉപയോഗിക്കുന്നു.സ്റ്റോറുകൾക്കായി ഇത് [`Release`] ഓർഡറിംഗ് ഉപയോഗിക്കുന്നു.
    ///
    /// `compare_and_swap`-ന്റെ കാര്യത്തിൽ, പ്രവർത്തനം ഒരു സ്റ്റോറും നടത്താതെ അവസാനിക്കാൻ സാധ്യതയുണ്ടെന്നും അതിനാൽ ഇതിന് [`Acquire`] ഓർഡറിംഗ് മാത്രമേ ഉള്ളൂവെന്നും ശ്രദ്ധിക്കുക.
    ///
    /// എന്നിരുന്നാലും, `AcqRel` ഒരിക്കലും [`Relaxed`] ആക്സസ് ചെയ്യില്ല.
    ///
    /// ലോഡുകളും സ്റ്റോറുകളും സംയോജിപ്പിക്കുന്ന പ്രവർത്തനങ്ങൾക്ക് മാത്രമേ ഈ ഓർഡർ ബാധകമാകൂ.
    ///
    /// C ++ 20 ലെ [`memory_order_acq_rel`]-ന് യോജിക്കുന്നു.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// എല്ലാ ത്രെഡുകളും തുടർച്ചയായി സ്ഥിരതയാർന്ന എല്ലാ പ്രവർത്തനങ്ങളും ഒരേ ക്രമത്തിൽ കാണുന്നുവെന്ന അധിക ഗ്യാരണ്ടിയോടെ [`നേടുക`]/[`റിലീസ്`]/[`അക്രെൽ`](യഥാക്രമം ലോഡ്, സ്റ്റോർ, ലോഡ്-വിത്ത് സ്റ്റോർ പ്രവർത്തനങ്ങൾക്കായി) പോലെ. .
    ///
    ///
    /// C ++ 20 ലെ [`memory_order_seq_cst`]-ന് യോജിക്കുന്നു.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// ഒരു [`AtomicBool`] `false`-ലേക്ക് സമാരംഭിച്ചു.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// ഒരു പുതിയ `AtomicBool` സൃഷ്ടിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// അന്തർലീനമായ [`bool`]-ലേക്ക് മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു.
    ///
    /// ഇത് സുരക്ഷിതമാണ്, കാരണം മറ്റ് ത്രെഡുകളൊന്നും ഒരേസമയം ആറ്റോമിക് ഡാറ്റയിലേക്ക് പ്രവേശിക്കുന്നില്ലെന്ന് മ്യൂട്ടബിൾ റഫറൻസ് ഉറപ്പുനൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // സുരക്ഷ: മ്യൂട്ടബിൾ റഫറൻസ് അദ്വിതീയ ഉടമസ്ഥാവകാശം ഉറപ്പുനൽകുന്നു.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// ഒരു `&mut bool`-ലേക്ക് ആറ്റോമിക് ആക്സസ് നേടുക.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // സുരക്ഷ: മ്യൂട്ടബിൾ റഫറൻസ് അദ്വിതീയ ഉടമസ്ഥാവകാശം ഉറപ്പുനൽകുന്നു, ഒപ്പം
        // `bool`, `Self` എന്നിവയുടെ വിന്യാസം 1 ആണ്.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// ആറ്റോമിക് ഉപയോഗിക്കുകയും അടങ്ങിയിരിക്കുന്ന മൂല്യം നൽകുകയും ചെയ്യുന്നു.
    ///
    /// ഇത് സുരക്ഷിതമാണ്, കാരണം `self` മൂല്യം അനുസരിച്ച് കടന്നുപോകുന്നത് മറ്റ് ത്രെഡുകളൊന്നും ഒരേസമയം ആറ്റോമിക് ഡാറ്റയിലേക്ക് പ്രവേശിക്കുന്നില്ലെന്ന് ഉറപ്പുനൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// bool-ൽ നിന്ന് ഒരു മൂല്യം ലോഡുചെയ്യുന്നു.
    ///
    /// `load` ഈ പ്രവർത്തനത്തിന്റെ മെമ്മറി ക്രമം വിവരിക്കുന്ന ഒരു [`Ordering`] ആർഗ്യുമെന്റ് എടുക്കുന്നു.
    /// സാധ്യമായ മൂല്യങ്ങൾ [`SeqCst`], [`Acquire`], [`Relaxed`] എന്നിവയാണ്.
    ///
    /// # Panics
    ///
    /// `order` [`Release`] അല്ലെങ്കിൽ [`AcqRel`] ആണെങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // സുരക്ഷ: ഏതെങ്കിലും ഡാറ്റാ റേസുകൾ ആറ്റോമിക് ആന്തരികവും അസംസ്കൃതവും തടയുന്നു
        // നൽകിയ റഫറൻസ് സാധുവായതിനാൽ ഞങ്ങൾക്ക് അത് ഒരു റഫറൻസിൽ നിന്ന് ലഭിച്ചു.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// bool-ലേക്ക് ഒരു മൂല്യം സംഭരിക്കുന്നു.
    ///
    /// `store` ഈ പ്രവർത്തനത്തിന്റെ മെമ്മറി ക്രമം വിവരിക്കുന്ന ഒരു [`Ordering`] ആർഗ്യുമെന്റ് എടുക്കുന്നു.
    /// സാധ്യമായ മൂല്യങ്ങൾ [`SeqCst`], [`Release`], [`Relaxed`] എന്നിവയാണ്.
    ///
    /// # Panics
    ///
    /// `order` [`Acquire`] അല്ലെങ്കിൽ [`AcqRel`] ആണെങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // സുരക്ഷ: ഏതെങ്കിലും ഡാറ്റാ റേസുകൾ ആറ്റോമിക് ആന്തരികവും അസംസ്കൃതവും തടയുന്നു
        // നൽകിയ റഫറൻസ് സാധുവായതിനാൽ ഞങ്ങൾക്ക് അത് ഒരു റഫറൻസിൽ നിന്ന് ലഭിച്ചു.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// bool-ലേക്ക് ഒരു മൂല്യം സംഭരിക്കുന്നു, മുമ്പത്തെ മൂല്യം നൽകുന്നു.
    ///
    /// `swap` ഈ പ്രവർത്തനത്തിന്റെ മെമ്മറി ക്രമം വിവരിക്കുന്ന ഒരു [`Ordering`] ആർഗ്യുമെന്റ് എടുക്കുന്നു.എല്ലാ ഓർഡറിംഗ് മോഡുകളും സാധ്യമാണ്.
    /// [`Acquire`] ഉപയോഗിക്കുന്നത് സ്റ്റോറിനെ ഈ പ്രവർത്തനത്തിന്റെ [`Relaxed`] ആക്കുന്നുവെന്നും [`Release`] ഉപയോഗിക്കുന്നത് ലോഡ് ഭാഗത്തെ [`Relaxed`] ആക്കുന്നുവെന്നും ശ്രദ്ധിക്കുക.
    ///
    ///
    /// **Note:** `u8`-ലെ ആറ്റോമിക് പ്രവർത്തനങ്ങളെ പിന്തുണയ്ക്കുന്ന പ്ലാറ്റ്ഫോമുകളിൽ മാത്രമേ ഈ രീതി ലഭ്യമാകൂ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // സുരക്ഷ: ഡാറ്റാ റേസുകൾ ആറ്റോമിക് ആന്തരികത തടയുന്നു.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// നിലവിലെ മൂല്യം `current` മൂല്യത്തിന് തുല്യമാണെങ്കിൽ [`bool`]-ലേക്ക് ഒരു മൂല്യം സംഭരിക്കുന്നു.
    ///
    /// റിട്ടേൺ മൂല്യം എല്ലായ്പ്പോഴും മുമ്പത്തെ മൂല്യമാണ്.ഇത് `current` ന് തുല്യമാണെങ്കിൽ, മൂല്യം അപ്‌ഡേറ്റുചെയ്‌തു.
    ///
    /// `compare_and_swap` ഈ പ്രവർത്തനത്തിന്റെ മെമ്മറി ക്രമം വിവരിക്കുന്ന ഒരു [`Ordering`] ആർഗ്യുമെന്റും എടുക്കുന്നു.
    /// [`AcqRel`] ഉപയോഗിക്കുമ്പോൾ പോലും, പ്രവർത്തനം പരാജയപ്പെട്ടേക്കാം, അതിനാൽ ഒരു `Acquire` ലോഡ് നടപ്പിലാക്കുക, പക്ഷേ `Release` സെമാന്റിക്‌സ് ഇല്ല എന്നത് ശ്രദ്ധിക്കുക.
    /// [`Acquire`] ഉപയോഗിക്കുന്നത് സ്റ്റോർ [`Relaxed`] സംഭവിക്കുകയാണെങ്കിൽ അത് സ്റ്റോറിന്റെ ഭാഗമാക്കുകയും [`Release`] ഉപയോഗിക്കുന്നത് ലോഡ് ഭാഗത്തെ [`Relaxed`] ആക്കുകയും ചെയ്യുന്നു.
    ///
    /// **Note:** `u8`-ലെ ആറ്റോമിക് പ്രവർത്തനങ്ങളെ പിന്തുണയ്ക്കുന്ന പ്ലാറ്റ്ഫോമുകളിൽ മാത്രമേ ഈ രീതി ലഭ്യമാകൂ.
    ///
    /// # `compare_exchange`, `compare_exchange_weak` എന്നിവയിലേക്ക് മൈഗ്രേറ്റുചെയ്യുന്നു
    ///
    /// `compare_and_swap` മെമ്മറി ഓർ‌ഡറിംഗിനായി ഇനിപ്പറയുന്ന മാപ്പിംഗിനൊപ്പം `compare_exchange` ന് തുല്യമാണ്:
    ///
    /// യഥാർത്ഥ |വിജയം |പരാജയം
    /// -------- | ------- | -------
    /// വിശ്രമിച്ചു |വിശ്രമിച്ചു |വിശ്രമിച്ച ഏറ്റെടുക്കൽ |നേടുക |റിലീസ് നേടുക |റിലീസ് |വിശ്രമിച്ച AcqRel |AcqRel |SeqCst നേടുക |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` താരതമ്യം വിജയിക്കുമ്പോഴും വ്യാജമായി പരാജയപ്പെടാൻ അനുവദിച്ചിരിക്കുന്നു, ഇത് ഒരു ലൂപ്പിൽ താരതമ്യവും സ്വാപ്പും ഉപയോഗിക്കുമ്പോൾ മികച്ച അസംബ്ലി കോഡ് സൃഷ്ടിക്കാൻ കമ്പൈലറിനെ അനുവദിക്കുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// നിലവിലെ മൂല്യം `current` മൂല്യത്തിന് തുല്യമാണെങ്കിൽ [`bool`]-ലേക്ക് ഒരു മൂല്യം സംഭരിക്കുന്നു.
    ///
    /// പുതിയ മൂല്യം എഴുതിയതാണോ അതോ മുമ്പത്തെ മൂല്യം ഉൾക്കൊള്ളുന്നുണ്ടോ എന്ന് സൂചിപ്പിക്കുന്ന ഫലമാണ് റിട്ടേൺ മൂല്യം.
    /// വിജയത്തിൽ ഈ മൂല്യം `current` ന് തുല്യമാണെന്ന് ഉറപ്പുനൽകുന്നു.
    ///
    /// `compare_exchange` ഈ പ്രവർത്തനത്തിന്റെ മെമ്മറി ക്രമം വിവരിക്കാൻ രണ്ട് [`Ordering`] ആർഗ്യുമെന്റുകൾ എടുക്കുന്നു.
    /// `success` `current` യുമായുള്ള താരതമ്യം വിജയിച്ചാൽ നടക്കുന്ന റീഡ്-മോഡിഫൈ-റൈറ്റ് ഓപ്പറേഷന് ആവശ്യമായ ഓർഡറിംഗ് വിവരിക്കുന്നു.
    /// `failure` താരതമ്യം പരാജയപ്പെടുമ്പോൾ നടക്കുന്ന ലോഡ് പ്രവർത്തനത്തിന് ആവശ്യമായ ക്രമം വിവരിക്കുന്നു.
    /// [`Acquire`] വിജയ ക്രമപ്പെടുത്തലായി ഉപയോഗിക്കുന്നത് [`Relaxed`] ഈ പ്രവർത്തനത്തിന്റെ ഭാഗമാക്കുന്നു, കൂടാതെ [`Release`] ഉപയോഗിക്കുന്നത് വിജയകരമായ ലോഡ് [`Relaxed`] ആക്കുന്നു.
    ///
    /// പരാജയ ക്രമപ്പെടുത്തൽ [`SeqCst`], [`Acquire`] അല്ലെങ്കിൽ [`Relaxed`] മാത്രമായിരിക്കാം, മാത്രമല്ല വിജയ ഓർ‌ഡറിംഗിനേക്കാൾ തുല്യമോ ദുർബലമോ ആയിരിക്കണം.
    ///
    /// **Note:** `u8`-ലെ ആറ്റോമിക് പ്രവർത്തനങ്ങളെ പിന്തുണയ്ക്കുന്ന പ്ലാറ്റ്ഫോമുകളിൽ മാത്രമേ ഈ രീതി ലഭ്യമാകൂ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // സുരക്ഷ: ഡാറ്റാ റേസുകൾ ആറ്റോമിക് ആന്തരികത തടയുന്നു.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// നിലവിലെ മൂല്യം `current` മൂല്യത്തിന് തുല്യമാണെങ്കിൽ [`bool`]-ലേക്ക് ഒരു മൂല്യം സംഭരിക്കുന്നു.
    ///
    /// [`AtomicBool::compare_exchange`]-ൽ നിന്ന് വ്യത്യസ്തമായി, താരതമ്യം വിജയിക്കുമ്പോഴും ഈ പ്രവർത്തനം വ്യാജമായി പരാജയപ്പെടാൻ അനുവദിച്ചിരിക്കുന്നു, ഇത് ചില പ്ലാറ്റ്ഫോമുകളിൽ കൂടുതൽ കാര്യക്ഷമമായ കോഡിന് കാരണമാകും.
    ///
    /// പുതിയ മൂല്യം എഴുതിയതാണോ അതോ മുമ്പത്തെ മൂല്യം ഉൾക്കൊള്ളുന്നുണ്ടോ എന്ന് സൂചിപ്പിക്കുന്ന ഫലമാണ് റിട്ടേൺ മൂല്യം.
    ///
    /// `compare_exchange_weak` ഈ പ്രവർത്തനത്തിന്റെ മെമ്മറി ക്രമം വിവരിക്കാൻ രണ്ട് [`Ordering`] ആർഗ്യുമെന്റുകൾ എടുക്കുന്നു.
    /// `success` `current` യുമായുള്ള താരതമ്യം വിജയിച്ചാൽ നടക്കുന്ന റീഡ്-മോഡിഫൈ-റൈറ്റ് ഓപ്പറേഷന് ആവശ്യമായ ഓർഡറിംഗ് വിവരിക്കുന്നു.
    /// `failure` താരതമ്യം പരാജയപ്പെടുമ്പോൾ നടക്കുന്ന ലോഡ് പ്രവർത്തനത്തിന് ആവശ്യമായ ക്രമം വിവരിക്കുന്നു.
    /// [`Acquire`] വിജയ ക്രമപ്പെടുത്തലായി ഉപയോഗിക്കുന്നത് [`Relaxed`] ഈ പ്രവർത്തനത്തിന്റെ ഭാഗമാക്കുന്നു, കൂടാതെ [`Release`] ഉപയോഗിക്കുന്നത് വിജയകരമായ ലോഡ് [`Relaxed`] ആക്കുന്നു.
    /// പരാജയ ക്രമപ്പെടുത്തൽ [`SeqCst`], [`Acquire`] അല്ലെങ്കിൽ [`Relaxed`] മാത്രമായിരിക്കാം, മാത്രമല്ല വിജയ ഓർ‌ഡറിംഗിനേക്കാൾ തുല്യമോ ദുർബലമോ ആയിരിക്കണം.
    ///
    /// **Note:** `u8`-ലെ ആറ്റോമിക് പ്രവർത്തനങ്ങളെ പിന്തുണയ്ക്കുന്ന പ്ലാറ്റ്ഫോമുകളിൽ മാത്രമേ ഈ രീതി ലഭ്യമാകൂ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // സുരക്ഷ: ഡാറ്റാ റേസുകൾ ആറ്റോമിക് ആന്തരികത തടയുന്നു.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// ഒരു ബൂളിയൻ മൂല്യമുള്ള ലോജിക്കൽ "and".
    ///
    /// നിലവിലെ മൂല്യത്തിലും ആർഗ്യുമെൻറ് `val`-ലും ഒരു ലോജിക്കൽ "and" പ്രവർത്തനം നടത്തുന്നു, കൂടാതെ ഫലത്തിലേക്ക് പുതിയ മൂല്യം സജ്ജമാക്കുന്നു.
    ///
    /// മുമ്പത്തെ മൂല്യം നൽകുന്നു.
    ///
    /// `fetch_and` ഈ പ്രവർത്തനത്തിന്റെ മെമ്മറി ക്രമം വിവരിക്കുന്ന ഒരു [`Ordering`] ആർഗ്യുമെന്റ് എടുക്കുന്നു.എല്ലാ ഓർഡറിംഗ് മോഡുകളും സാധ്യമാണ്.
    /// [`Acquire`] ഉപയോഗിക്കുന്നത് സ്റ്റോറിനെ ഈ പ്രവർത്തനത്തിന്റെ [`Relaxed`] ആക്കുന്നുവെന്നും [`Release`] ഉപയോഗിക്കുന്നത് ലോഡ് ഭാഗത്തെ [`Relaxed`] ആക്കുന്നുവെന്നും ശ്രദ്ധിക്കുക.
    ///
    ///
    /// **Note:** `u8`-ലെ ആറ്റോമിക് പ്രവർത്തനങ്ങളെ പിന്തുണയ്ക്കുന്ന പ്ലാറ്റ്ഫോമുകളിൽ മാത്രമേ ഈ രീതി ലഭ്യമാകൂ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // സുരക്ഷ: ഡാറ്റാ റേസുകൾ ആറ്റോമിക് ആന്തരികത തടയുന്നു.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// ഒരു ബൂളിയൻ മൂല്യമുള്ള ലോജിക്കൽ "nand".
    ///
    /// നിലവിലെ മൂല്യത്തിലും ആർഗ്യുമെൻറ് `val`-ലും ഒരു ലോജിക്കൽ "nand" പ്രവർത്തനം നടത്തുന്നു, കൂടാതെ ഫലത്തിലേക്ക് പുതിയ മൂല്യം സജ്ജമാക്കുന്നു.
    ///
    /// മുമ്പത്തെ മൂല്യം നൽകുന്നു.
    ///
    /// `fetch_nand` ഈ പ്രവർത്തനത്തിന്റെ മെമ്മറി ക്രമം വിവരിക്കുന്ന ഒരു [`Ordering`] ആർഗ്യുമെന്റ് എടുക്കുന്നു.എല്ലാ ഓർഡറിംഗ് മോഡുകളും സാധ്യമാണ്.
    /// [`Acquire`] ഉപയോഗിക്കുന്നത് സ്റ്റോറിനെ ഈ പ്രവർത്തനത്തിന്റെ [`Relaxed`] ആക്കുന്നുവെന്നും [`Release`] ഉപയോഗിക്കുന്നത് ലോഡ് ഭാഗത്തെ [`Relaxed`] ആക്കുന്നുവെന്നും ശ്രദ്ധിക്കുക.
    ///
    ///
    /// **Note:** `u8`-ലെ ആറ്റോമിക് പ്രവർത്തനങ്ങളെ പിന്തുണയ്ക്കുന്ന പ്ലാറ്റ്ഫോമുകളിൽ മാത്രമേ ഈ രീതി ലഭ്യമാകൂ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // ഞങ്ങൾക്ക് ഇവിടെ atomic_nand ഉപയോഗിക്കാൻ കഴിയില്ല കാരണം ഇത് അസാധുവായ മൂല്യമുള്ള bool ന് കാരണമാകാം.
        // ആന്തരികമായി 8-ബിറ്റ് സംഖ്യ ഉപയോഗിച്ചാണ് ആറ്റോമിക് പ്രവർത്തനം നടത്തുന്നത്, ഇത് മുകളിലുള്ള 7 ബിറ്റുകൾ സജ്ജമാക്കും.
        //
        // അതിനാൽ ഞങ്ങൾ പകരം fetch_xor അല്ലെങ്കിൽ സ്വാപ്പ് ഉപയോഗിക്കുന്നു.
        if val {
            // ! (x&true)== !x നമ്മൾ bool വിപരീതമാക്കണം.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==true നമ്മൾ bool true ആയി സജ്ജമാക്കണം.
            //
            self.swap(true, order)
        }
    }

    /// ഒരു ബൂളിയൻ മൂല്യമുള്ള ലോജിക്കൽ "or".
    ///
    /// നിലവിലെ മൂല്യത്തിലും ആർഗ്യുമെൻറ് `val`-ലും ഒരു ലോജിക്കൽ "or" പ്രവർത്തനം നടത്തുന്നു, കൂടാതെ ഫലത്തിലേക്ക് പുതിയ മൂല്യം സജ്ജമാക്കുന്നു.
    ///
    /// മുമ്പത്തെ മൂല്യം നൽകുന്നു.
    ///
    /// `fetch_or` ഈ പ്രവർത്തനത്തിന്റെ മെമ്മറി ക്രമം വിവരിക്കുന്ന ഒരു [`Ordering`] ആർഗ്യുമെന്റ് എടുക്കുന്നു.എല്ലാ ഓർഡറിംഗ് മോഡുകളും സാധ്യമാണ്.
    /// [`Acquire`] ഉപയോഗിക്കുന്നത് സ്റ്റോറിനെ ഈ പ്രവർത്തനത്തിന്റെ [`Relaxed`] ആക്കുന്നുവെന്നും [`Release`] ഉപയോഗിക്കുന്നത് ലോഡ് ഭാഗത്തെ [`Relaxed`] ആക്കുന്നുവെന്നും ശ്രദ്ധിക്കുക.
    ///
    ///
    /// **Note:** `u8`-ലെ ആറ്റോമിക് പ്രവർത്തനങ്ങളെ പിന്തുണയ്ക്കുന്ന പ്ലാറ്റ്ഫോമുകളിൽ മാത്രമേ ഈ രീതി ലഭ്യമാകൂ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // സുരക്ഷ: ഡാറ്റാ റേസുകൾ ആറ്റോമിക് ആന്തരികത തടയുന്നു.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// ഒരു ബൂളിയൻ മൂല്യമുള്ള ലോജിക്കൽ "xor".
    ///
    /// നിലവിലെ മൂല്യത്തിലും ആർഗ്യുമെൻറ് `val`-ലും ഒരു ലോജിക്കൽ "xor" പ്രവർത്തനം നടത്തുന്നു, കൂടാതെ ഫലത്തിലേക്ക് പുതിയ മൂല്യം സജ്ജമാക്കുന്നു.
    ///
    /// മുമ്പത്തെ മൂല്യം നൽകുന്നു.
    ///
    /// `fetch_xor` ഈ പ്രവർത്തനത്തിന്റെ മെമ്മറി ക്രമം വിവരിക്കുന്ന ഒരു [`Ordering`] ആർഗ്യുമെന്റ് എടുക്കുന്നു.എല്ലാ ഓർഡറിംഗ് മോഡുകളും സാധ്യമാണ്.
    /// [`Acquire`] ഉപയോഗിക്കുന്നത് സ്റ്റോറിനെ ഈ പ്രവർത്തനത്തിന്റെ [`Relaxed`] ആക്കുന്നുവെന്നും [`Release`] ഉപയോഗിക്കുന്നത് ലോഡ് ഭാഗത്തെ [`Relaxed`] ആക്കുന്നുവെന്നും ശ്രദ്ധിക്കുക.
    ///
    ///
    /// **Note:** `u8`-ലെ ആറ്റോമിക് പ്രവർത്തനങ്ങളെ പിന്തുണയ്ക്കുന്ന പ്ലാറ്റ്ഫോമുകളിൽ മാത്രമേ ഈ രീതി ലഭ്യമാകൂ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // സുരക്ഷ: ഡാറ്റാ റേസുകൾ ആറ്റോമിക് ആന്തരികത തടയുന്നു.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// അന്തർലീനമായ [`bool`]-ലേക്ക് ഒരു മ്യൂട്ടബിൾ പോയിന്റർ നൽകുന്നു.
    ///
    /// തത്ഫലമായുണ്ടാകുന്ന സംഖ്യയിൽ നോൺ-ആറ്റോമിക് റീഡുകളും റൈറ്റുകളും ചെയ്യുന്നത് ഒരു ഡാറ്റ റേസ് ആകാം.
    /// എഫ്‌എഫ്‌ഐയ്‌ക്ക് ഈ രീതി കൂടുതലും ഉപയോഗപ്രദമാണ്, ഇവിടെ ഫംഗ്ഷൻ സിഗ്നേച്ചർ എക്സ് 100 എക്‌സിനുപകരം എക്സ് 01 എക്സ് ഉപയോഗിക്കാം.
    ///
    /// ഈ ആറ്റോമിലേക്കുള്ള പങ്കിട്ട റഫറൻസിൽ നിന്ന് ഒരു എക്സ് 00 എക്സ് പോയിന്റർ നൽകുന്നത് സുരക്ഷിതമാണ്, കാരണം ആറ്റോമിക് തരങ്ങൾ ഇന്റീരിയർ മ്യൂട്ടബിലിറ്റിയുമായി പ്രവർത്തിക്കുന്നു.
    /// ഒരു ആറ്റോമിയുടെ എല്ലാ പരിഷ്‌ക്കരണങ്ങളും ഒരു പങ്കിട്ട റഫറൻസിലൂടെ മൂല്യം മാറ്റുന്നു, മാത്രമല്ല അവ ആറ്റോമിക് പ്രവർത്തനങ്ങൾ ഉപയോഗിക്കുന്നിടത്തോളം കാലം സുരക്ഷിതമായി ചെയ്യാനാകും.
    /// മടങ്ങിയ അസംസ്കൃത പോയിന്ററിന്റെ ഏത് ഉപയോഗത്തിനും ഒരു `unsafe` ബ്ലോക്ക് ആവശ്യമാണ്, ഇപ്പോഴും അതേ നിയന്ത്രണം പാലിക്കേണ്ടതുണ്ട്: ഇതിലെ പ്രവർത്തനങ്ങൾ ആറ്റോമിക് ആയിരിക്കണം.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// മൂല്യം നേടുന്നു, ഒപ്പം ഒരു ഓപ്‌ഷണൽ പുതിയ മൂല്യം നൽകുന്ന ഒരു ഫംഗ്ഷൻ പ്രയോഗിക്കുകയും ചെയ്യുന്നു.ഫംഗ്ഷൻ `Some(_)`, അല്ലെങ്കിൽ `Err(previous_value)` നൽകിയാൽ `Ok(previous_value)`-ന്റെ `Result` നൽകുന്നു.
    ///
    /// Note: `Some(_)` ഫംഗ്ഷൻ നൽകുന്നിടത്തോളം, മറ്റ് ത്രെഡുകളിൽ നിന്ന് മൂല്യം മാറ്റിയിട്ടുണ്ടെങ്കിൽ ഇത് ഒന്നിലധികം തവണ ഫംഗ്ഷനെ വിളിച്ചേക്കാം, പക്ഷേ സംഭരിച്ച മൂല്യത്തിലേക്ക് ഒരു തവണ മാത്രമേ ഫംഗ്ഷൻ പ്രയോഗിക്കുകയുള്ളൂ.
    ///
    ///
    /// `fetch_update` ഈ പ്രവർത്തനത്തിന്റെ മെമ്മറി ക്രമം വിവരിക്കാൻ രണ്ട് [`Ordering`] ആർഗ്യുമെന്റുകൾ എടുക്കുന്നു.
    /// ആദ്യത്തേത് പ്രവർത്തനം വിജയിക്കുമ്പോൾ ആവശ്യമായ ഓർഡറിംഗ് വിവരിക്കുമ്പോൾ രണ്ടാമത്തേത് ലോഡുകൾക്ക് ആവശ്യമായ ഓർഡറിംഗ് വിവരിക്കുന്നു.
    /// ഇവ യഥാക്രമം [`AtomicBool::compare_exchange`] ന്റെ വിജയ, പരാജയ ക്രമങ്ങളുമായി പൊരുത്തപ്പെടുന്നു.
    ///
    /// [`Acquire`] വിജയ ക്രമപ്പെടുത്തലായി ഉപയോഗിക്കുന്നത് ഈ പ്രവർത്തനത്തെ [`Relaxed`] ആക്കുന്നു, കൂടാതെ [`Release`] ഉപയോഗിക്കുന്നത് അവസാന വിജയകരമായ ലോഡ് [`Relaxed`] ആക്കുന്നു.
    /// (failed) ലോഡ് ഓർ‌ഡറിംഗ് [`SeqCst`], [`Acquire`] അല്ലെങ്കിൽ [`Relaxed`] മാത്രമേ ആകാവൂ, മാത്രമല്ല വിജയ ഓർ‌ഡറിംഗിനേക്കാൾ തുല്യമോ ദുർബലമോ ആയിരിക്കണം.
    ///
    /// **Note:** `u8`-ലെ ആറ്റോമിക് പ്രവർത്തനങ്ങളെ പിന്തുണയ്ക്കുന്ന പ്ലാറ്റ്ഫോമുകളിൽ മാത്രമേ ഈ രീതി ലഭ്യമാകൂ.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// ഒരു പുതിയ `AtomicPtr` സൃഷ്ടിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// അന്തർലീനമായ പോയിന്ററിലേക്ക് മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു.
    ///
    /// ഇത് സുരക്ഷിതമാണ്, കാരണം മറ്റ് ത്രെഡുകളൊന്നും ഒരേസമയം ആറ്റോമിക് ഡാറ്റയിലേക്ക് പ്രവേശിക്കുന്നില്ലെന്ന് മ്യൂട്ടബിൾ റഫറൻസ് ഉറപ്പുനൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// ഒരു പോയിന്ററിലേക്ക് ആറ്റോമിക് ആക്സസ് നേടുക.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - മ്യൂട്ടബിൾ റഫറൻസ് അദ്വിതീയ ഉടമസ്ഥാവകാശം ഉറപ്പുനൽകുന്നു.
        //  - മുകളിൽ പരിശോധിച്ചതുപോലെ, rust പിന്തുണയ്ക്കുന്ന എല്ലാ പ്ലാറ്റ്ഫോമുകളിലും `*mut T`, `Self` എന്നിവയുടെ വിന്യാസം സമാനമാണ്.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// ആറ്റോമിക് ഉപയോഗിക്കുകയും അടങ്ങിയിരിക്കുന്ന മൂല്യം നൽകുകയും ചെയ്യുന്നു.
    ///
    /// ഇത് സുരക്ഷിതമാണ്, കാരണം `self` മൂല്യം അനുസരിച്ച് കടന്നുപോകുന്നത് മറ്റ് ത്രെഡുകളൊന്നും ഒരേസമയം ആറ്റോമിക് ഡാറ്റയിലേക്ക് പ്രവേശിക്കുന്നില്ലെന്ന് ഉറപ്പുനൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// പോയിന്ററിൽ നിന്ന് ഒരു മൂല്യം ലോഡുചെയ്യുന്നു.
    ///
    /// `load` ഈ പ്രവർത്തനത്തിന്റെ മെമ്മറി ക്രമം വിവരിക്കുന്ന ഒരു [`Ordering`] ആർഗ്യുമെന്റ് എടുക്കുന്നു.
    /// സാധ്യമായ മൂല്യങ്ങൾ [`SeqCst`], [`Acquire`], [`Relaxed`] എന്നിവയാണ്.
    ///
    /// # Panics
    ///
    /// `order` [`Release`] അല്ലെങ്കിൽ [`AcqRel`] ആണെങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // സുരക്ഷ: ഡാറ്റാ റേസുകൾ ആറ്റോമിക് ആന്തരികത തടയുന്നു.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// പോയിന്ററിലേക്ക് ഒരു മൂല്യം സംഭരിക്കുന്നു.
    ///
    /// `store` ഈ പ്രവർത്തനത്തിന്റെ മെമ്മറി ക്രമം വിവരിക്കുന്ന ഒരു [`Ordering`] ആർഗ്യുമെന്റ് എടുക്കുന്നു.
    /// സാധ്യമായ മൂല്യങ്ങൾ [`SeqCst`], [`Release`], [`Relaxed`] എന്നിവയാണ്.
    ///
    /// # Panics
    ///
    /// `order` [`Acquire`] അല്ലെങ്കിൽ [`AcqRel`] ആണെങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // സുരക്ഷ: ഡാറ്റാ റേസുകൾ ആറ്റോമിക് ആന്തരികത തടയുന്നു.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// ഒരു മൂല്യം പോയിന്ററിലേക്ക് സംഭരിക്കുന്നു, മുമ്പത്തെ മൂല്യം നൽകുന്നു.
    ///
    /// `swap` ഈ പ്രവർത്തനത്തിന്റെ മെമ്മറി ക്രമം വിവരിക്കുന്ന ഒരു [`Ordering`] ആർഗ്യുമെന്റ് എടുക്കുന്നു.എല്ലാ ഓർഡറിംഗ് മോഡുകളും സാധ്യമാണ്.
    /// [`Acquire`] ഉപയോഗിക്കുന്നത് സ്റ്റോറിനെ ഈ പ്രവർത്തനത്തിന്റെ [`Relaxed`] ആക്കുന്നുവെന്നും [`Release`] ഉപയോഗിക്കുന്നത് ലോഡ് ഭാഗത്തെ [`Relaxed`] ആക്കുന്നുവെന്നും ശ്രദ്ധിക്കുക.
    ///
    ///
    /// **Note:** പോയിന്ററുകളിലെ ആറ്റോമിക് പ്രവർത്തനങ്ങളെ പിന്തുണയ്ക്കുന്ന പ്ലാറ്റ്ഫോമുകളിൽ മാത്രമേ ഈ രീതി ലഭ്യമാകൂ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // സുരക്ഷ: ഡാറ്റാ റേസുകൾ ആറ്റോമിക് ആന്തരികത തടയുന്നു.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// നിലവിലെ മൂല്യം `current` മൂല്യത്തിന് തുല്യമാണെങ്കിൽ പോയിന്ററിൽ ഒരു മൂല്യം സംഭരിക്കുന്നു.
    ///
    /// റിട്ടേൺ മൂല്യം എല്ലായ്പ്പോഴും മുമ്പത്തെ മൂല്യമാണ്.ഇത് `current` ന് തുല്യമാണെങ്കിൽ, മൂല്യം അപ്‌ഡേറ്റുചെയ്‌തു.
    ///
    /// `compare_and_swap` ഈ പ്രവർത്തനത്തിന്റെ മെമ്മറി ക്രമം വിവരിക്കുന്ന ഒരു [`Ordering`] ആർഗ്യുമെന്റും എടുക്കുന്നു.
    /// [`AcqRel`] ഉപയോഗിക്കുമ്പോൾ പോലും, പ്രവർത്തനം പരാജയപ്പെട്ടേക്കാം, അതിനാൽ ഒരു `Acquire` ലോഡ് നടപ്പിലാക്കുക, പക്ഷേ `Release` സെമാന്റിക്‌സ് ഇല്ല എന്നത് ശ്രദ്ധിക്കുക.
    /// [`Acquire`] ഉപയോഗിക്കുന്നത് സ്റ്റോർ [`Relaxed`] സംഭവിക്കുകയാണെങ്കിൽ അത് സ്റ്റോറിന്റെ ഭാഗമാക്കുകയും [`Release`] ഉപയോഗിക്കുന്നത് ലോഡ് ഭാഗത്തെ [`Relaxed`] ആക്കുകയും ചെയ്യുന്നു.
    ///
    /// **Note:** പോയിന്ററുകളിലെ ആറ്റോമിക് പ്രവർത്തനങ്ങളെ പിന്തുണയ്ക്കുന്ന പ്ലാറ്റ്ഫോമുകളിൽ മാത്രമേ ഈ രീതി ലഭ്യമാകൂ.
    ///
    /// # `compare_exchange`, `compare_exchange_weak` എന്നിവയിലേക്ക് മൈഗ്രേറ്റുചെയ്യുന്നു
    ///
    /// `compare_and_swap` മെമ്മറി ഓർ‌ഡറിംഗിനായി ഇനിപ്പറയുന്ന മാപ്പിംഗിനൊപ്പം `compare_exchange` ന് തുല്യമാണ്:
    ///
    /// യഥാർത്ഥ |വിജയം |പരാജയം
    /// -------- | ------- | -------
    /// വിശ്രമിച്ചു |വിശ്രമിച്ചു |വിശ്രമിച്ച ഏറ്റെടുക്കൽ |നേടുക |റിലീസ് നേടുക |റിലീസ് |വിശ്രമിച്ച AcqRel |AcqRel |SeqCst നേടുക |SeqCst |SeqCst
    ///
    /// `compare_exchange_weak` താരതമ്യം വിജയിക്കുമ്പോഴും വ്യാജമായി പരാജയപ്പെടാൻ അനുവദിച്ചിരിക്കുന്നു, ഇത് ഒരു ലൂപ്പിൽ താരതമ്യവും സ്വാപ്പും ഉപയോഗിക്കുമ്പോൾ മികച്ച അസംബ്ലി കോഡ് സൃഷ്ടിക്കാൻ കമ്പൈലറിനെ അനുവദിക്കുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// നിലവിലെ മൂല്യം `current` മൂല്യത്തിന് തുല്യമാണെങ്കിൽ പോയിന്ററിൽ ഒരു മൂല്യം സംഭരിക്കുന്നു.
    ///
    /// പുതിയ മൂല്യം എഴുതിയതാണോ അതോ മുമ്പത്തെ മൂല്യം ഉൾക്കൊള്ളുന്നുണ്ടോ എന്ന് സൂചിപ്പിക്കുന്ന ഫലമാണ് റിട്ടേൺ മൂല്യം.
    /// വിജയത്തിൽ ഈ മൂല്യം `current` ന് തുല്യമാണെന്ന് ഉറപ്പുനൽകുന്നു.
    ///
    /// `compare_exchange` ഈ പ്രവർത്തനത്തിന്റെ മെമ്മറി ക്രമം വിവരിക്കാൻ രണ്ട് [`Ordering`] ആർഗ്യുമെന്റുകൾ എടുക്കുന്നു.
    /// `success` `current` യുമായുള്ള താരതമ്യം വിജയിച്ചാൽ നടക്കുന്ന റീഡ്-മോഡിഫൈ-റൈറ്റ് ഓപ്പറേഷന് ആവശ്യമായ ഓർഡറിംഗ് വിവരിക്കുന്നു.
    /// `failure` താരതമ്യം പരാജയപ്പെടുമ്പോൾ നടക്കുന്ന ലോഡ് പ്രവർത്തനത്തിന് ആവശ്യമായ ക്രമം വിവരിക്കുന്നു.
    /// [`Acquire`] വിജയ ക്രമപ്പെടുത്തലായി ഉപയോഗിക്കുന്നത് [`Relaxed`] ഈ പ്രവർത്തനത്തിന്റെ ഭാഗമാക്കുന്നു, കൂടാതെ [`Release`] ഉപയോഗിക്കുന്നത് വിജയകരമായ ലോഡ് [`Relaxed`] ആക്കുന്നു.
    ///
    /// പരാജയ ക്രമപ്പെടുത്തൽ [`SeqCst`], [`Acquire`] അല്ലെങ്കിൽ [`Relaxed`] മാത്രമായിരിക്കാം, മാത്രമല്ല വിജയ ഓർ‌ഡറിംഗിനേക്കാൾ തുല്യമോ ദുർബലമോ ആയിരിക്കണം.
    ///
    /// **Note:** പോയിന്ററുകളിലെ ആറ്റോമിക് പ്രവർത്തനങ്ങളെ പിന്തുണയ്ക്കുന്ന പ്ലാറ്റ്ഫോമുകളിൽ മാത്രമേ ഈ രീതി ലഭ്യമാകൂ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // സുരക്ഷ: ഡാറ്റാ റേസുകൾ ആറ്റോമിക് ആന്തരികത തടയുന്നു.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// നിലവിലെ മൂല്യം `current` മൂല്യത്തിന് തുല്യമാണെങ്കിൽ പോയിന്ററിൽ ഒരു മൂല്യം സംഭരിക്കുന്നു.
    ///
    /// [`AtomicPtr::compare_exchange`]-ൽ നിന്ന് വ്യത്യസ്തമായി, താരതമ്യം വിജയിക്കുമ്പോഴും ഈ പ്രവർത്തനം വ്യാജമായി പരാജയപ്പെടാൻ അനുവദിച്ചിരിക്കുന്നു, ഇത് ചില പ്ലാറ്റ്ഫോമുകളിൽ കൂടുതൽ കാര്യക്ഷമമായ കോഡിന് കാരണമാകും.
    ///
    /// പുതിയ മൂല്യം എഴുതിയതാണോ അതോ മുമ്പത്തെ മൂല്യം ഉൾക്കൊള്ളുന്നുണ്ടോ എന്ന് സൂചിപ്പിക്കുന്ന ഫലമാണ് റിട്ടേൺ മൂല്യം.
    ///
    /// `compare_exchange_weak` ഈ പ്രവർത്തനത്തിന്റെ മെമ്മറി ക്രമം വിവരിക്കാൻ രണ്ട് [`Ordering`] ആർഗ്യുമെന്റുകൾ എടുക്കുന്നു.
    /// `success` `current` യുമായുള്ള താരതമ്യം വിജയിച്ചാൽ നടക്കുന്ന റീഡ്-മോഡിഫൈ-റൈറ്റ് ഓപ്പറേഷന് ആവശ്യമായ ഓർഡറിംഗ് വിവരിക്കുന്നു.
    /// `failure` താരതമ്യം പരാജയപ്പെടുമ്പോൾ നടക്കുന്ന ലോഡ് പ്രവർത്തനത്തിന് ആവശ്യമായ ക്രമം വിവരിക്കുന്നു.
    /// [`Acquire`] വിജയ ക്രമപ്പെടുത്തലായി ഉപയോഗിക്കുന്നത് [`Relaxed`] ഈ പ്രവർത്തനത്തിന്റെ ഭാഗമാക്കുന്നു, കൂടാതെ [`Release`] ഉപയോഗിക്കുന്നത് വിജയകരമായ ലോഡ് [`Relaxed`] ആക്കുന്നു.
    /// പരാജയ ക്രമപ്പെടുത്തൽ [`SeqCst`], [`Acquire`] അല്ലെങ്കിൽ [`Relaxed`] മാത്രമായിരിക്കാം, മാത്രമല്ല വിജയ ഓർ‌ഡറിംഗിനേക്കാൾ തുല്യമോ ദുർബലമോ ആയിരിക്കണം.
    ///
    /// **Note:** പോയിന്ററുകളിലെ ആറ്റോമിക് പ്രവർത്തനങ്ങളെ പിന്തുണയ്ക്കുന്ന പ്ലാറ്റ്ഫോമുകളിൽ മാത്രമേ ഈ രീതി ലഭ്യമാകൂ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // സുരക്ഷ: ഈ ആന്തരികം സുരക്ഷിതമല്ല കാരണം ഇത് ഒരു അസംസ്കൃത പോയിന്ററിൽ പ്രവർത്തിക്കുന്നു
        // എന്നാൽ പോയിന്റർ സാധുതയുള്ളതാണെന്ന് ഞങ്ങൾക്കറിയാം (റഫറൻസിലൂടെ ഞങ്ങൾക്ക് ലഭിച്ച ഒരു `UnsafeCell`-ൽ നിന്നാണ് ഞങ്ങൾ ഇത് നേടിയത്) കൂടാതെ ആറ്റോമിക് പ്രവർത്തനം തന്നെ `UnsafeCell` ഉള്ളടക്കങ്ങൾ സുരക്ഷിതമായി പരിവർത്തനം ചെയ്യാൻ ഞങ്ങളെ അനുവദിക്കുന്നു.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// മൂല്യം നേടുന്നു, ഒപ്പം ഒരു ഓപ്‌ഷണൽ പുതിയ മൂല്യം നൽകുന്ന ഒരു ഫംഗ്ഷൻ പ്രയോഗിക്കുകയും ചെയ്യുന്നു.ഫംഗ്ഷൻ `Some(_)`, അല്ലെങ്കിൽ `Err(previous_value)` നൽകിയാൽ `Ok(previous_value)`-ന്റെ `Result` നൽകുന്നു.
    ///
    /// Note: `Some(_)` ഫംഗ്ഷൻ നൽകുന്നിടത്തോളം, മറ്റ് ത്രെഡുകളിൽ നിന്ന് മൂല്യം മാറ്റിയിട്ടുണ്ടെങ്കിൽ ഇത് ഒന്നിലധികം തവണ ഫംഗ്ഷനെ വിളിച്ചേക്കാം, പക്ഷേ സംഭരിച്ച മൂല്യത്തിലേക്ക് ഒരു തവണ മാത്രമേ ഫംഗ്ഷൻ പ്രയോഗിക്കുകയുള്ളൂ.
    ///
    ///
    /// `fetch_update` ഈ പ്രവർത്തനത്തിന്റെ മെമ്മറി ക്രമം വിവരിക്കാൻ രണ്ട് [`Ordering`] ആർഗ്യുമെന്റുകൾ എടുക്കുന്നു.
    /// ആദ്യത്തേത് പ്രവർത്തനം വിജയിക്കുമ്പോൾ ആവശ്യമായ ഓർഡറിംഗ് വിവരിക്കുമ്പോൾ രണ്ടാമത്തേത് ലോഡുകൾക്ക് ആവശ്യമായ ഓർഡറിംഗ് വിവരിക്കുന്നു.
    /// ഇവ യഥാക്രമം [`AtomicPtr::compare_exchange`] ന്റെ വിജയ, പരാജയ ക്രമങ്ങളുമായി പൊരുത്തപ്പെടുന്നു.
    ///
    /// [`Acquire`] വിജയ ക്രമപ്പെടുത്തലായി ഉപയോഗിക്കുന്നത് ഈ പ്രവർത്തനത്തെ [`Relaxed`] ആക്കുന്നു, കൂടാതെ [`Release`] ഉപയോഗിക്കുന്നത് അവസാന വിജയകരമായ ലോഡ് [`Relaxed`] ആക്കുന്നു.
    /// (failed) ലോഡ് ഓർ‌ഡറിംഗ് [`SeqCst`], [`Acquire`] അല്ലെങ്കിൽ [`Relaxed`] മാത്രമേ ആകാവൂ, മാത്രമല്ല വിജയ ഓർ‌ഡറിംഗിനേക്കാൾ തുല്യമോ ദുർബലമോ ആയിരിക്കണം.
    ///
    /// **Note:** പോയിന്ററുകളിലെ ആറ്റോമിക് പ്രവർത്തനങ്ങളെ പിന്തുണയ്ക്കുന്ന പ്ലാറ്റ്ഫോമുകളിൽ മാത്രമേ ഈ രീതി ലഭ്യമാകൂ.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// ഒരു `bool`-നെ `AtomicBool`-ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // ഈ മാക്രോ ചില ആർക്കിടെക്ചറുകളിൽ ഉപയോഗിക്കാതെ പോകുന്നു.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// ത്രെഡുകൾക്കിടയിൽ സുരക്ഷിതമായി പങ്കിടാൻ കഴിയുന്ന ഒരു സംഖ്യ തരം.
        ///
        /// ഈ തരത്തിന് അന്തർലീനമായ സംഖ്യ തരത്തിന് സമാനമായ മെമ്മറി പ്രാതിനിധ്യം ഉണ്ട്, [`
        ///
        #[doc = $s_int_type]
        /// `].
        /// ആറ്റോമിക് തരങ്ങളും നോൺ-ആറ്റോമിക് തരങ്ങളും തമ്മിലുള്ള വ്യത്യാസങ്ങളെക്കുറിച്ചും ഈ തരത്തിലുള്ള പോർട്ടബിലിറ്റിയെക്കുറിച്ചും കൂടുതൽ വിവരങ്ങൾക്ക്, ദയവായി എക്സ് 00 എക്സ് കാണുക.
        ///
        ///
        /// **Note:** [`ന്റെ ആറ്റോമിക് ലോഡുകളെയും സ്റ്റോറുകളെയും പിന്തുണയ്ക്കുന്ന പ്ലാറ്റ്ഫോമുകളിൽ മാത്രമേ ഈ തരം ലഭ്യമാകൂ
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// `0`-ലേക്ക് സമാരംഭിച്ച ഒരു ആറ്റോമിക് സംഖ്യ.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // അയയ്‌ക്കുന്നത് വ്യക്തമായി നടപ്പിലാക്കുന്നു.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// ഒരു പുതിയ ആറ്റോമിക് സംഖ്യ സൃഷ്ടിക്കുന്നു.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// അന്തർലീനമായ സംഖ്യയിലേക്ക് ഒരു മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു.
            ///
            /// ഇത് സുരക്ഷിതമാണ്, കാരണം മറ്റ് ത്രെഡുകളൊന്നും ഒരേസമയം ആറ്റോമിക് ഡാറ്റയിലേക്ക് പ്രവേശിക്കുന്നില്ലെന്ന് മ്യൂട്ടബിൾ റഫറൻസ് ഉറപ്പുനൽകുന്നു.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// mut some_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (some_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - മ്യൂട്ടബിൾ റഫറൻസ് അദ്വിതീയ ഉടമസ്ഥാവകാശം ഉറപ്പുനൽകുന്നു.
                //  - `$int_type`, `Self` എന്നിവയുടെ വിന്യാസം സമാനമാണ്, $cfg_align വാഗ്ദാനം ചെയ്തതും മുകളിൽ പരിശോധിച്ചതും.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// ആറ്റോമിക് ഉപയോഗിക്കുകയും അടങ്ങിയിരിക്കുന്ന മൂല്യം നൽകുകയും ചെയ്യുന്നു.
            ///
            /// ഇത് സുരക്ഷിതമാണ്, കാരണം `self` മൂല്യം അനുസരിച്ച് കടന്നുപോകുന്നത് മറ്റ് ത്രെഡുകളൊന്നും ഒരേസമയം ആറ്റോമിക് ഡാറ്റയിലേക്ക് പ്രവേശിക്കുന്നില്ലെന്ന് ഉറപ്പുനൽകുന്നു.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// ആറ്റോമിക് സംഖ്യയിൽ നിന്ന് ഒരു മൂല്യം ലോഡുചെയ്യുന്നു.
            ///
            /// `load` ഈ പ്രവർത്തനത്തിന്റെ മെമ്മറി ക്രമം വിവരിക്കുന്ന ഒരു [`Ordering`] ആർഗ്യുമെന്റ് എടുക്കുന്നു.
            /// സാധ്യമായ മൂല്യങ്ങൾ [`SeqCst`], [`Acquire`], [`Relaxed`] എന്നിവയാണ്.
            ///
            /// # Panics
            ///
            /// `order` [`Release`] അല്ലെങ്കിൽ [`AcqRel`] ആണെങ്കിൽ Panics.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // സുരക്ഷ: ഡാറ്റാ റേസുകൾ ആറ്റോമിക് ആന്തരികത തടയുന്നു.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// ആറ്റോമിക് സംഖ്യയിലേക്ക് ഒരു മൂല്യം സംഭരിക്കുന്നു.
            ///
            /// `store` ഈ പ്രവർത്തനത്തിന്റെ മെമ്മറി ക്രമം വിവരിക്കുന്ന ഒരു [`Ordering`] ആർഗ്യുമെന്റ് എടുക്കുന്നു.
            ///  സാധ്യമായ മൂല്യങ്ങൾ [`SeqCst`], [`Release`], [`Relaxed`] എന്നിവയാണ്.
            ///
            /// # Panics
            ///
            /// `order` [`Acquire`] അല്ലെങ്കിൽ [`AcqRel`] ആണെങ്കിൽ Panics.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // സുരക്ഷ: ഡാറ്റാ റേസുകൾ ആറ്റോമിക് ആന്തരികത തടയുന്നു.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// ഒരു മൂല്യം ആറ്റോമിക് സംഖ്യയിലേക്ക് സംഭരിക്കുന്നു, മുമ്പത്തെ മൂല്യം നൽകുന്നു.
            ///
            /// `swap` ഈ പ്രവർത്തനത്തിന്റെ മെമ്മറി ക്രമം വിവരിക്കുന്ന ഒരു [`Ordering`] ആർഗ്യുമെന്റ് എടുക്കുന്നു.എല്ലാ ഓർഡറിംഗ് മോഡുകളും സാധ്യമാണ്.
            /// [`Acquire`] ഉപയോഗിക്കുന്നത് സ്റ്റോറിനെ ഈ പ്രവർത്തനത്തിന്റെ [`Relaxed`] ആക്കുന്നുവെന്നും [`Release`] ഉപയോഗിക്കുന്നത് ലോഡ് ഭാഗത്തെ [`Relaxed`] ആക്കുന്നുവെന്നും ശ്രദ്ധിക്കുക.
            ///
            ///
            /// **കുറിപ്പ്**: ആറ്റോമിക് പ്രവർത്തനങ്ങളെ പിന്തുണയ്ക്കുന്ന പ്ലാറ്റ്ഫോമുകളിൽ മാത്രമേ ഈ രീതി ലഭ്യമാകൂ
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // സുരക്ഷ: ഡാറ്റാ റേസുകൾ ആറ്റോമിക് ആന്തരികത തടയുന്നു.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// നിലവിലെ മൂല്യം `current` മൂല്യത്തിന് തുല്യമാണെങ്കിൽ ആറ്റോമിക് സംഖ്യയിലേക്ക് ഒരു മൂല്യം സംഭരിക്കുന്നു.
            ///
            /// റിട്ടേൺ മൂല്യം എല്ലായ്പ്പോഴും മുമ്പത്തെ മൂല്യമാണ്.ഇത് `current` ന് തുല്യമാണെങ്കിൽ, മൂല്യം അപ്‌ഡേറ്റുചെയ്‌തു.
            ///
            /// `compare_and_swap` ഈ പ്രവർത്തനത്തിന്റെ മെമ്മറി ക്രമം വിവരിക്കുന്ന ഒരു [`Ordering`] ആർഗ്യുമെന്റും എടുക്കുന്നു.
            /// [`AcqRel`] ഉപയോഗിക്കുമ്പോൾ പോലും, പ്രവർത്തനം പരാജയപ്പെട്ടേക്കാം, അതിനാൽ ഒരു `Acquire` ലോഡ് നടപ്പിലാക്കുക, പക്ഷേ `Release` സെമാന്റിക്‌സ് ഇല്ല എന്നത് ശ്രദ്ധിക്കുക.
            ///
            /// [`Acquire`] ഉപയോഗിക്കുന്നത് സ്റ്റോർ [`Relaxed`] സംഭവിക്കുകയാണെങ്കിൽ അത് സ്റ്റോറിന്റെ ഭാഗമാക്കുകയും [`Release`] ഉപയോഗിക്കുന്നത് ലോഡ് ഭാഗത്തെ [`Relaxed`] ആക്കുകയും ചെയ്യുന്നു.
            ///
            /// **കുറിപ്പ്**: ആറ്റോമിക് പ്രവർത്തനങ്ങളെ പിന്തുണയ്ക്കുന്ന പ്ലാറ്റ്ഫോമുകളിൽ മാത്രമേ ഈ രീതി ലഭ്യമാകൂ
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # `compare_exchange`, `compare_exchange_weak` എന്നിവയിലേക്ക് മൈഗ്രേറ്റുചെയ്യുന്നു
            ///
            /// `compare_and_swap` മെമ്മറി ഓർ‌ഡറിംഗിനായി ഇനിപ്പറയുന്ന മാപ്പിംഗിനൊപ്പം `compare_exchange` ന് തുല്യമാണ്:
            ///
            /// യഥാർത്ഥ |വിജയം |പരാജയം
            /// -------- | ------- | -------
            /// വിശ്രമിച്ചു |വിശ്രമിച്ചു |വിശ്രമിച്ച ഏറ്റെടുക്കൽ |നേടുക |റിലീസ് നേടുക |റിലീസ് |വിശ്രമിച്ച AcqRel |AcqRel |SeqCst നേടുക |SeqCst |SeqCst
            ///
            /// `compare_exchange_weak` താരതമ്യം വിജയിക്കുമ്പോഴും വ്യാജമായി പരാജയപ്പെടാൻ അനുവദിച്ചിരിക്കുന്നു, ഇത് ഒരു ലൂപ്പിൽ താരതമ്യവും സ്വാപ്പും ഉപയോഗിക്കുമ്പോൾ മികച്ച അസംബ്ലി കോഡ് സൃഷ്ടിക്കാൻ കമ്പൈലറിനെ അനുവദിക്കുന്നു.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// നിലവിലെ മൂല്യം `current` മൂല്യത്തിന് തുല്യമാണെങ്കിൽ ആറ്റോമിക് സംഖ്യയിലേക്ക് ഒരു മൂല്യം സംഭരിക്കുന്നു.
            ///
            /// പുതിയ മൂല്യം എഴുതിയതാണോ അതോ മുമ്പത്തെ മൂല്യം ഉൾക്കൊള്ളുന്നുണ്ടോ എന്ന് സൂചിപ്പിക്കുന്ന ഫലമാണ് റിട്ടേൺ മൂല്യം.
            /// വിജയത്തിൽ ഈ മൂല്യം `current` ന് തുല്യമാണെന്ന് ഉറപ്പുനൽകുന്നു.
            ///
            /// `compare_exchange` ഈ പ്രവർത്തനത്തിന്റെ മെമ്മറി ക്രമം വിവരിക്കാൻ രണ്ട് [`Ordering`] ആർഗ്യുമെന്റുകൾ എടുക്കുന്നു.
            /// `success` `current` യുമായുള്ള താരതമ്യം വിജയിച്ചാൽ നടക്കുന്ന റീഡ്-മോഡിഫൈ-റൈറ്റ് ഓപ്പറേഷന് ആവശ്യമായ ഓർഡറിംഗ് വിവരിക്കുന്നു.
            /// `failure` താരതമ്യം പരാജയപ്പെടുമ്പോൾ നടക്കുന്ന ലോഡ് പ്രവർത്തനത്തിന് ആവശ്യമായ ക്രമം വിവരിക്കുന്നു.
            /// [`Acquire`] വിജയ ക്രമപ്പെടുത്തലായി ഉപയോഗിക്കുന്നത് [`Relaxed`] ഈ പ്രവർത്തനത്തിന്റെ ഭാഗമാക്കുന്നു, കൂടാതെ [`Release`] ഉപയോഗിക്കുന്നത് വിജയകരമായ ലോഡ് [`Relaxed`] ആക്കുന്നു.
            ///
            /// പരാജയ ക്രമപ്പെടുത്തൽ [`SeqCst`], [`Acquire`] അല്ലെങ്കിൽ [`Relaxed`] മാത്രമായിരിക്കാം, മാത്രമല്ല വിജയ ഓർ‌ഡറിംഗിനേക്കാൾ തുല്യമോ ദുർബലമോ ആയിരിക്കണം.
            ///
            /// **കുറിപ്പ്**: ആറ്റോമിക് പ്രവർത്തനങ്ങളെ പിന്തുണയ്ക്കുന്ന പ്ലാറ്റ്ഫോമുകളിൽ മാത്രമേ ഈ രീതി ലഭ്യമാകൂ
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // സുരക്ഷ: ഡാറ്റാ റേസുകൾ ആറ്റോമിക് ആന്തരികത തടയുന്നു.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// നിലവിലെ മൂല്യം `current` മൂല്യത്തിന് തുല്യമാണെങ്കിൽ ആറ്റോമിക് സംഖ്യയിലേക്ക് ഒരു മൂല്യം സംഭരിക്കുന്നു.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// താരതമ്യം വിജയിക്കുമ്പോഴും ഈ പ്രവർത്തനം വ്യാജമായി പരാജയപ്പെടാൻ അനുവദിച്ചിരിക്കുന്നു, ഇത് ചില പ്ലാറ്റ്ഫോമുകളിൽ കൂടുതൽ കാര്യക്ഷമമായ കോഡിന് കാരണമാകും.
            /// പുതിയ മൂല്യം എഴുതിയതാണോ അതോ മുമ്പത്തെ മൂല്യം ഉൾക്കൊള്ളുന്നുണ്ടോ എന്ന് സൂചിപ്പിക്കുന്ന ഫലമാണ് റിട്ടേൺ മൂല്യം.
            ///
            /// `compare_exchange_weak` ഈ പ്രവർത്തനത്തിന്റെ മെമ്മറി ക്രമം വിവരിക്കാൻ രണ്ട് [`Ordering`] ആർഗ്യുമെന്റുകൾ എടുക്കുന്നു.
            /// `success` `current` യുമായുള്ള താരതമ്യം വിജയിച്ചാൽ നടക്കുന്ന റീഡ്-മോഡിഫൈ-റൈറ്റ് ഓപ്പറേഷന് ആവശ്യമായ ഓർഡറിംഗ് വിവരിക്കുന്നു.
            /// `failure` താരതമ്യം പരാജയപ്പെടുമ്പോൾ നടക്കുന്ന ലോഡ് പ്രവർത്തനത്തിന് ആവശ്യമായ ക്രമം വിവരിക്കുന്നു.
            /// [`Acquire`] വിജയ ക്രമപ്പെടുത്തലായി ഉപയോഗിക്കുന്നത് [`Relaxed`] ഈ പ്രവർത്തനത്തിന്റെ ഭാഗമാക്കുന്നു, കൂടാതെ [`Release`] ഉപയോഗിക്കുന്നത് വിജയകരമായ ലോഡ് [`Relaxed`] ആക്കുന്നു.
            ///
            /// പരാജയ ക്രമപ്പെടുത്തൽ [`SeqCst`], [`Acquire`] അല്ലെങ്കിൽ [`Relaxed`] മാത്രമായിരിക്കാം, മാത്രമല്ല വിജയ ഓർ‌ഡറിംഗിനേക്കാൾ തുല്യമോ ദുർബലമോ ആയിരിക്കണം.
            ///
            /// **കുറിപ്പ്**: ആറ്റോമിക് പ്രവർത്തനങ്ങളെ പിന്തുണയ്ക്കുന്ന പ്ലാറ്റ്ഫോമുകളിൽ മാത്രമേ ഈ രീതി ലഭ്യമാകൂ
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// mut old= val.load(Ordering::Relaxed);
            /// ലൂപ്പ് new പുതിയത്=പഴയത് * 2;
            ///     പൊരുത്തം val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // സുരക്ഷ: ഡാറ്റാ റേസുകൾ ആറ്റോമിക് ആന്തരികത തടയുന്നു.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// നിലവിലെ മൂല്യത്തിലേക്ക് ചേർക്കുന്നു, മുമ്പത്തെ മൂല്യം നൽകുന്നു.
            ///
            /// ഈ പ്രവർത്തനം ഓവർഫ്ലോയിൽ ചുറ്റുന്നു.
            ///
            /// `fetch_add` ഈ പ്രവർത്തനത്തിന്റെ മെമ്മറി ക്രമം വിവരിക്കുന്ന ഒരു [`Ordering`] ആർഗ്യുമെന്റ് എടുക്കുന്നു.എല്ലാ ഓർഡറിംഗ് മോഡുകളും സാധ്യമാണ്.
            /// [`Acquire`] ഉപയോഗിക്കുന്നത് സ്റ്റോറിനെ ഈ പ്രവർത്തനത്തിന്റെ [`Relaxed`] ആക്കുന്നുവെന്നും [`Release`] ഉപയോഗിക്കുന്നത് ലോഡ് ഭാഗത്തെ [`Relaxed`] ആക്കുന്നുവെന്നും ശ്രദ്ധിക്കുക.
            ///
            ///
            /// **കുറിപ്പ്**: ആറ്റോമിക് പ്രവർത്തനങ്ങളെ പിന്തുണയ്ക്കുന്ന പ്ലാറ്റ്ഫോമുകളിൽ മാത്രമേ ഈ രീതി ലഭ്യമാകൂ
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // സുരക്ഷ: ഡാറ്റാ റേസുകൾ ആറ്റോമിക് ആന്തരികത തടയുന്നു.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// നിലവിലെ മൂല്യത്തിൽ നിന്ന് കുറയ്ക്കുന്നു, മുമ്പത്തെ മൂല്യം നൽകുന്നു.
            ///
            /// ഈ പ്രവർത്തനം ഓവർഫ്ലോയിൽ ചുറ്റുന്നു.
            ///
            /// `fetch_sub` ഈ പ്രവർത്തനത്തിന്റെ മെമ്മറി ക്രമം വിവരിക്കുന്ന ഒരു [`Ordering`] ആർഗ്യുമെന്റ് എടുക്കുന്നു.എല്ലാ ഓർഡറിംഗ് മോഡുകളും സാധ്യമാണ്.
            /// [`Acquire`] ഉപയോഗിക്കുന്നത് സ്റ്റോറിനെ ഈ പ്രവർത്തനത്തിന്റെ [`Relaxed`] ആക്കുന്നുവെന്നും [`Release`] ഉപയോഗിക്കുന്നത് ലോഡ് ഭാഗത്തെ [`Relaxed`] ആക്കുന്നുവെന്നും ശ്രദ്ധിക്കുക.
            ///
            ///
            /// **കുറിപ്പ്**: ആറ്റോമിക് പ്രവർത്തനങ്ങളെ പിന്തുണയ്ക്കുന്ന പ്ലാറ്റ്ഫോമുകളിൽ മാത്രമേ ഈ രീതി ലഭ്യമാകൂ
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // സുരക്ഷ: ഡാറ്റാ റേസുകൾ ആറ്റോമിക് ആന്തരികത തടയുന്നു.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// നിലവിലെ മൂല്യത്തോടുകൂടിയ ബിറ്റ്‌വൈസ് "and".
            ///
            /// നിലവിലെ മൂല്യത്തിലും ആർ‌ഗ്യുമെൻറ് `val` ലും ബിറ്റ്‌വൈസ് "and" പ്രവർ‌ത്തനം നടത്തുന്നു, കൂടാതെ ഫലത്തിലേക്ക് പുതിയ മൂല്യം സജ്ജമാക്കുന്നു.
            ///
            /// മുമ്പത്തെ മൂല്യം നൽകുന്നു.
            ///
            /// `fetch_and` ഈ പ്രവർത്തനത്തിന്റെ മെമ്മറി ക്രമം വിവരിക്കുന്ന ഒരു [`Ordering`] ആർഗ്യുമെന്റ് എടുക്കുന്നു.എല്ലാ ഓർഡറിംഗ് മോഡുകളും സാധ്യമാണ്.
            /// [`Acquire`] ഉപയോഗിക്കുന്നത് സ്റ്റോറിനെ ഈ പ്രവർത്തനത്തിന്റെ [`Relaxed`] ആക്കുന്നുവെന്നും [`Release`] ഉപയോഗിക്കുന്നത് ലോഡ് ഭാഗത്തെ [`Relaxed`] ആക്കുന്നുവെന്നും ശ്രദ്ധിക്കുക.
            ///
            ///
            /// **കുറിപ്പ്**: ആറ്റോമിക് പ്രവർത്തനങ്ങളെ പിന്തുണയ്ക്കുന്ന പ്ലാറ്റ്ഫോമുകളിൽ മാത്രമേ ഈ രീതി ലഭ്യമാകൂ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // സുരക്ഷ: ഡാറ്റാ റേസുകൾ ആറ്റോമിക് ആന്തരികത തടയുന്നു.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// നിലവിലെ മൂല്യത്തോടുകൂടിയ ബിറ്റ്‌വൈസ് "nand".
            ///
            /// നിലവിലെ മൂല്യത്തിലും ആർ‌ഗ്യുമെൻറ് `val` ലും ബിറ്റ്‌വൈസ് "nand" പ്രവർ‌ത്തനം നടത്തുന്നു, കൂടാതെ ഫലത്തിലേക്ക് പുതിയ മൂല്യം സജ്ജമാക്കുന്നു.
            ///
            /// മുമ്പത്തെ മൂല്യം നൽകുന്നു.
            ///
            /// `fetch_nand` ഈ പ്രവർത്തനത്തിന്റെ മെമ്മറി ക്രമം വിവരിക്കുന്ന ഒരു [`Ordering`] ആർഗ്യുമെന്റ് എടുക്കുന്നു.എല്ലാ ഓർഡറിംഗ് മോഡുകളും സാധ്യമാണ്.
            /// [`Acquire`] ഉപയോഗിക്കുന്നത് സ്റ്റോറിനെ ഈ പ്രവർത്തനത്തിന്റെ [`Relaxed`] ആക്കുന്നുവെന്നും [`Release`] ഉപയോഗിക്കുന്നത് ലോഡ് ഭാഗത്തെ [`Relaxed`] ആക്കുന്നുവെന്നും ശ്രദ്ധിക്കുക.
            ///
            ///
            /// **കുറിപ്പ്**: ആറ്റോമിക് പ്രവർത്തനങ്ങളെ പിന്തുണയ്ക്കുന്ന പ്ലാറ്റ്ഫോമുകളിൽ മാത്രമേ ഈ രീതി ലഭ്യമാകൂ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // സുരക്ഷ: ഡാറ്റാ റേസുകൾ ആറ്റോമിക് ആന്തരികത തടയുന്നു.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// നിലവിലെ മൂല്യത്തോടുകൂടിയ ബിറ്റ്‌വൈസ് "or".
            ///
            /// നിലവിലെ മൂല്യത്തിലും ആർ‌ഗ്യുമെൻറ് `val` ലും ബിറ്റ്‌വൈസ് "or" പ്രവർ‌ത്തനം നടത്തുന്നു, കൂടാതെ ഫലത്തിലേക്ക് പുതിയ മൂല്യം സജ്ജമാക്കുന്നു.
            ///
            /// മുമ്പത്തെ മൂല്യം നൽകുന്നു.
            ///
            /// `fetch_or` ഈ പ്രവർത്തനത്തിന്റെ മെമ്മറി ക്രമം വിവരിക്കുന്ന ഒരു [`Ordering`] ആർഗ്യുമെന്റ് എടുക്കുന്നു.എല്ലാ ഓർഡറിംഗ് മോഡുകളും സാധ്യമാണ്.
            /// [`Acquire`] ഉപയോഗിക്കുന്നത് സ്റ്റോറിനെ ഈ പ്രവർത്തനത്തിന്റെ [`Relaxed`] ആക്കുന്നുവെന്നും [`Release`] ഉപയോഗിക്കുന്നത് ലോഡ് ഭാഗത്തെ [`Relaxed`] ആക്കുന്നുവെന്നും ശ്രദ്ധിക്കുക.
            ///
            ///
            /// **കുറിപ്പ്**: ആറ്റോമിക് പ്രവർത്തനങ്ങളെ പിന്തുണയ്ക്കുന്ന പ്ലാറ്റ്ഫോമുകളിൽ മാത്രമേ ഈ രീതി ലഭ്യമാകൂ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // സുരക്ഷ: ഡാറ്റാ റേസുകൾ ആറ്റോമിക് ആന്തരികത തടയുന്നു.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// നിലവിലെ മൂല്യത്തോടുകൂടിയ ബിറ്റ്‌വൈസ് "xor".
            ///
            /// നിലവിലെ മൂല്യത്തിലും ആർ‌ഗ്യുമെൻറ് `val` ലും ബിറ്റ്‌വൈസ് "xor" പ്രവർ‌ത്തനം നടത്തുന്നു, കൂടാതെ ഫലത്തിലേക്ക് പുതിയ മൂല്യം സജ്ജമാക്കുന്നു.
            ///
            /// മുമ്പത്തെ മൂല്യം നൽകുന്നു.
            ///
            /// `fetch_xor` ഈ പ്രവർത്തനത്തിന്റെ മെമ്മറി ക്രമം വിവരിക്കുന്ന ഒരു [`Ordering`] ആർഗ്യുമെന്റ് എടുക്കുന്നു.എല്ലാ ഓർഡറിംഗ് മോഡുകളും സാധ്യമാണ്.
            /// [`Acquire`] ഉപയോഗിക്കുന്നത് സ്റ്റോറിനെ ഈ പ്രവർത്തനത്തിന്റെ [`Relaxed`] ആക്കുന്നുവെന്നും [`Release`] ഉപയോഗിക്കുന്നത് ലോഡ് ഭാഗത്തെ [`Relaxed`] ആക്കുന്നുവെന്നും ശ്രദ്ധിക്കുക.
            ///
            ///
            /// **കുറിപ്പ്**: ആറ്റോമിക് പ്രവർത്തനങ്ങളെ പിന്തുണയ്ക്കുന്ന പ്ലാറ്റ്ഫോമുകളിൽ മാത്രമേ ഈ രീതി ലഭ്യമാകൂ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // സുരക്ഷ: ഡാറ്റാ റേസുകൾ ആറ്റോമിക് ആന്തരികത തടയുന്നു.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// മൂല്യം നേടുന്നു, ഒപ്പം ഒരു ഓപ്‌ഷണൽ പുതിയ മൂല്യം നൽകുന്ന ഒരു ഫംഗ്ഷൻ പ്രയോഗിക്കുകയും ചെയ്യുന്നു.ഫംഗ്ഷൻ `Some(_)`, അല്ലെങ്കിൽ `Err(previous_value)` നൽകിയാൽ `Ok(previous_value)`-ന്റെ `Result` നൽകുന്നു.
            ///
            /// Note: `Some(_)` ഫംഗ്ഷൻ നൽകുന്നിടത്തോളം, മറ്റ് ത്രെഡുകളിൽ നിന്ന് മൂല്യം മാറ്റിയിട്ടുണ്ടെങ്കിൽ ഇത് ഒന്നിലധികം തവണ ഫംഗ്ഷനെ വിളിച്ചേക്കാം, പക്ഷേ സംഭരിച്ച മൂല്യത്തിലേക്ക് ഒരു തവണ മാത്രമേ ഫംഗ്ഷൻ പ്രയോഗിക്കുകയുള്ളൂ.
            ///
            ///
            /// `fetch_update` ഈ പ്രവർത്തനത്തിന്റെ മെമ്മറി ക്രമം വിവരിക്കാൻ രണ്ട് [`Ordering`] ആർഗ്യുമെന്റുകൾ എടുക്കുന്നു.
            /// ആദ്യത്തേത് പ്രവർത്തനം വിജയിക്കുമ്പോൾ ആവശ്യമായ ഓർഡറിംഗ് വിവരിക്കുമ്പോൾ രണ്ടാമത്തേത് ലോഡുകൾക്ക് ആവശ്യമായ ഓർഡറിംഗ് വിവരിക്കുന്നു.ഇവയുടെ വിജയത്തിനും പരാജയ ക്രമത്തിനും യോജിക്കുന്നു
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// [`Acquire`] വിജയ ക്രമപ്പെടുത്തലായി ഉപയോഗിക്കുന്നത് ഈ പ്രവർത്തനത്തെ [`Relaxed`] ആക്കുന്നു, കൂടാതെ [`Release`] ഉപയോഗിക്കുന്നത് അവസാന വിജയകരമായ ലോഡ് [`Relaxed`] ആക്കുന്നു.
            /// (failed) ലോഡ് ഓർ‌ഡറിംഗ് [`SeqCst`], [`Acquire`] അല്ലെങ്കിൽ [`Relaxed`] മാത്രമേ ആകാവൂ, മാത്രമല്ല വിജയ ഓർ‌ഡറിംഗിനേക്കാൾ തുല്യമോ ദുർബലമോ ആയിരിക്കണം.
            ///
            /// **കുറിപ്പ്**: ആറ്റോമിക് പ്രവർത്തനങ്ങളെ പിന്തുണയ്ക്കുന്ന പ്ലാറ്റ്ഫോമുകളിൽ മാത്രമേ ഈ രീതി ലഭ്യമാകൂ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (ക്രമപ്പെടുത്തുന്നു: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (ക്രമപ്പെടുത്തുന്നു: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// നിലവിലെ മൂല്യത്തിനൊപ്പം പരമാവധി.
            ///
            /// നിലവിലെ മൂല്യത്തിന്റെയും ആർ‌ഗ്യുമെൻറ് `val` ന്റെയും പരമാവധി കണ്ടെത്തുകയും ഫലത്തിലേക്ക് പുതിയ മൂല്യം സജ്ജമാക്കുകയും ചെയ്യുന്നു.
            ///
            /// മുമ്പത്തെ മൂല്യം നൽകുന്നു.
            ///
            /// `fetch_max` ഈ പ്രവർത്തനത്തിന്റെ മെമ്മറി ക്രമം വിവരിക്കുന്ന ഒരു [`Ordering`] ആർഗ്യുമെന്റ് എടുക്കുന്നു.എല്ലാ ഓർഡറിംഗ് മോഡുകളും സാധ്യമാണ്.
            /// [`Acquire`] ഉപയോഗിക്കുന്നത് സ്റ്റോറിനെ ഈ പ്രവർത്തനത്തിന്റെ [`Relaxed`] ആക്കുന്നുവെന്നും [`Release`] ഉപയോഗിക്കുന്നത് ലോഡ് ഭാഗത്തെ [`Relaxed`] ആക്കുന്നുവെന്നും ശ്രദ്ധിക്കുക.
            ///
            ///
            /// **കുറിപ്പ്**: ആറ്റോമിക് പ്രവർത്തനങ്ങളെ പിന്തുണയ്ക്കുന്ന പ്ലാറ്റ്ഫോമുകളിൽ മാത്രമേ ഈ രീതി ലഭ്യമാകൂ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// ബാർ അനുവദിക്കുക=42;
            /// max_foo=foo.fetch_max (ബാർ, Ordering::SeqCst).max(bar);
            /// ഉറപ്പിക്കുക! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // സുരക്ഷ: ഡാറ്റാ റേസുകൾ ആറ്റോമിക് ആന്തരികത തടയുന്നു.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// നിലവിലെ മൂല്യത്തിനൊപ്പം കുറഞ്ഞത്.
            ///
            /// നിലവിലെ മൂല്യത്തിന്റെ ഏറ്റവും കുറഞ്ഞതും ആർ‌ഗ്യുമെൻറ് `val` ഉം കണ്ടെത്തുകയും ഫലത്തിലേക്ക് പുതിയ മൂല്യം സജ്ജമാക്കുകയും ചെയ്യുന്നു.
            ///
            /// മുമ്പത്തെ മൂല്യം നൽകുന്നു.
            ///
            /// `fetch_min` ഈ പ്രവർത്തനത്തിന്റെ മെമ്മറി ക്രമം വിവരിക്കുന്ന ഒരു [`Ordering`] ആർഗ്യുമെന്റ് എടുക്കുന്നു.എല്ലാ ഓർഡറിംഗ് മോഡുകളും സാധ്യമാണ്.
            /// [`Acquire`] ഉപയോഗിക്കുന്നത് സ്റ്റോറിനെ ഈ പ്രവർത്തനത്തിന്റെ [`Relaxed`] ആക്കുന്നുവെന്നും [`Release`] ഉപയോഗിക്കുന്നത് ലോഡ് ഭാഗത്തെ [`Relaxed`] ആക്കുന്നുവെന്നും ശ്രദ്ധിക്കുക.
            ///
            ///
            /// **കുറിപ്പ്**: ആറ്റോമിക് പ്രവർത്തനങ്ങളെ പിന്തുണയ്ക്കുന്ന പ്ലാറ്റ്ഫോമുകളിൽ മാത്രമേ ഈ രീതി ലഭ്യമാകൂ
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// ബാർ അനുവദിക്കുക=12;
            /// min_foo=foo.fetch_min (ബാർ, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // സുരക്ഷ: ഡാറ്റാ റേസുകൾ ആറ്റോമിക് ആന്തരികത തടയുന്നു.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// അന്തർലീനമായ സംഖ്യയിലേക്ക് ഒരു മ്യൂട്ടബിൾ പോയിന്റർ നൽകുന്നു.
            ///
            /// തത്ഫലമായുണ്ടാകുന്ന സംഖ്യയിൽ നോൺ-ആറ്റോമിക് റീഡുകളും റൈറ്റുകളും ചെയ്യുന്നത് ഒരു ഡാറ്റ റേസ് ആകാം.
            /// ഫംഗ്ഷൻ സിഗ്നേച്ചർ ഉപയോഗിച്ചേക്കാവുന്ന എഫ്എഫ്‌ഐക്ക് ഈ രീതി കൂടുതലും ഉപയോഗപ്രദമാണ്
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// ഈ ആറ്റോമിലേക്കുള്ള പങ്കിട്ട റഫറൻസിൽ നിന്ന് ഒരു എക്സ് 00 എക്സ് പോയിന്റർ നൽകുന്നത് സുരക്ഷിതമാണ്, കാരണം ആറ്റോമിക് തരങ്ങൾ ഇന്റീരിയർ മ്യൂട്ടബിലിറ്റിയുമായി പ്രവർത്തിക്കുന്നു.
            /// ഒരു ആറ്റോമിയുടെ എല്ലാ പരിഷ്‌ക്കരണങ്ങളും ഒരു പങ്കിട്ട റഫറൻസിലൂടെ മൂല്യം മാറ്റുന്നു, മാത്രമല്ല അവ ആറ്റോമിക് പ്രവർത്തനങ്ങൾ ഉപയോഗിക്കുന്നിടത്തോളം കാലം സുരക്ഷിതമായി ചെയ്യാനാകും.
            /// മടങ്ങിയ അസംസ്കൃത പോയിന്ററിന്റെ ഏത് ഉപയോഗത്തിനും ഒരു `unsafe` ബ്ലോക്ക് ആവശ്യമാണ്, ഇപ്പോഴും അതേ നിയന്ത്രണം പാലിക്കേണ്ടതുണ്ട്: ഇതിലെ പ്രവർത്തനങ്ങൾ ആറ്റോമിക് ആയിരിക്കണം.
            ///
            ///
            /// # Examples
            ///
            /// `` (extern-declaration) അവഗണിക്കുക
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// ബാഹ്യ "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // സുരക്ഷ: `my_atomic_op` ആറ്റോമിക് ഉള്ളിടത്തോളം സുരക്ഷിതം.
            /// സുരക്ഷിതമല്ലാത്ത {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // സുരക്ഷ: വിളിക്കുന്നയാൾ `atomic_store`-നായുള്ള സുരക്ഷാ കരാർ പാലിക്കണം.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // സുരക്ഷ: വിളിക്കുന്നയാൾ `atomic_load`-നായുള്ള സുരക്ഷാ കരാർ പാലിക്കണം.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // സുരക്ഷ: വിളിക്കുന്നയാൾ `atomic_swap`-നായുള്ള സുരക്ഷാ കരാർ പാലിക്കണം.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// മുമ്പത്തെ മൂല്യം നൽകുന്നു (__sync_fetch_and_add പോലെ).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // സുരക്ഷ: വിളിക്കുന്നയാൾ `atomic_add`-നായുള്ള സുരക്ഷാ കരാർ പാലിക്കണം.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// മുമ്പത്തെ മൂല്യം നൽകുന്നു (__sync_fetch_and_sub പോലെ).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // സുരക്ഷ: വിളിക്കുന്നയാൾ `atomic_sub`-നായുള്ള സുരക്ഷാ കരാർ പാലിക്കണം.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // സുരക്ഷ: വിളിക്കുന്നയാൾ `atomic_compare_exchange`-നായുള്ള സുരക്ഷാ കരാർ പാലിക്കണം.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // സുരക്ഷ: വിളിക്കുന്നയാൾ `atomic_compare_exchange_weak`-നായുള്ള സുരക്ഷാ കരാർ പാലിക്കണം.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // സുരക്ഷ: വിളിക്കുന്നയാൾ `atomic_and`-നായുള്ള സുരക്ഷാ കരാർ പാലിക്കണം
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // സുരക്ഷ: വിളിക്കുന്നയാൾ `atomic_nand`-നായുള്ള സുരക്ഷാ കരാർ പാലിക്കണം
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // സുരക്ഷ: വിളിക്കുന്നയാൾ `atomic_or`-നായുള്ള സുരക്ഷാ കരാർ പാലിക്കണം
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // സുരക്ഷ: വിളിക്കുന്നയാൾ `atomic_xor`-നായുള്ള സുരക്ഷാ കരാർ പാലിക്കണം
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// പരമാവധി മൂല്യം നൽകുന്നു (ഒപ്പിട്ട താരതമ്യം)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // സുരക്ഷ: വിളിക്കുന്നയാൾ `atomic_max`-നായുള്ള സുരക്ഷാ കരാർ പാലിക്കണം
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// കുറഞ്ഞ മൂല്യം നൽകുന്നു (ഒപ്പിട്ട താരതമ്യം)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // സുരക്ഷ: വിളിക്കുന്നയാൾ `atomic_min`-നായുള്ള സുരക്ഷാ കരാർ പാലിക്കണം
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// പരമാവധി മൂല്യം നൽകുന്നു (ഒപ്പിടാത്ത താരതമ്യം)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // സുരക്ഷ: വിളിക്കുന്നയാൾ `atomic_umax`-നായുള്ള സുരക്ഷാ കരാർ പാലിക്കണം
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// കുറഞ്ഞ മൂല്യം നൽകുന്നു (ഒപ്പിടാത്ത താരതമ്യം)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // സുരക്ഷ: വിളിക്കുന്നയാൾ `atomic_umin`-നായുള്ള സുരക്ഷാ കരാർ പാലിക്കണം
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// ഒരു ആറ്റോമിക് വേലി.
///
/// നിർദ്ദിഷ്ട ഓർഡറിനെ ആശ്രയിച്ച്, കമ്പൈലറിനെയും സിപിയുവിനെയും ചുറ്റുമുള്ള ചില തരം മെമ്മറി പ്രവർത്തനങ്ങൾ പുന ord ക്രമീകരിക്കുന്നതിൽ നിന്ന് ഒരു വേലി തടയുന്നു.
/// അത് സമന്വയിപ്പിക്കുന്നു-അതും ആറ്റോമിക് പ്രവർത്തനങ്ങളും അല്ലെങ്കിൽ മറ്റ് ത്രെഡുകളിലെ വേലികളും തമ്മിലുള്ള ബന്ധവുമായി.
///
/// (കുറഞ്ഞത്) [`Release`] ഓർഡറിംഗ് സെമാന്റിക്‌സ് ഉള്ള ഒരു വേലി X002, (കുറഞ്ഞത്) [`Acquire`] സെമാന്റിക്‌സുമായി ഒരു വേലി 'B'-മായി സമന്വയിപ്പിക്കുന്നു, X, Y പ്രവർത്തനങ്ങൾ ഉണ്ടെങ്കിൽ മാത്രം, രണ്ടും ചില ആറ്റോമിക് ഒബ്‌ജക്റ്റായ 'M'-ൽ പ്രവർത്തിക്കുന്നു. ബി, വൈ എം എന്നിവയിലേക്കുള്ള മാറ്റം നിരീക്ഷിക്കുന്നതിന് മുമ്പ് എക്സ്, വൈ സമന്വയിപ്പിക്കുന്നു.
/// ഇത് എയും ബി യും തമ്മിലുള്ള ആശ്രിതത്വം സംഭവിക്കുന്നു.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// [`Release`] അല്ലെങ്കിൽ [`Acquire`] സെമാന്റിക്‌സ് ഉപയോഗിച്ചുള്ള ആറ്റോമിക് പ്രവർത്തനങ്ങൾക്കും വേലി ഉപയോഗിച്ച് സമന്വയിപ്പിക്കാൻ കഴിയും.
///
/// [`Acquire`], [`Release`] സെമാന്റിക്‌സ് എന്നിവയ്‌ക്ക് പുറമേ, [`SeqCst`] ഓർഡറിംഗ് ഉള്ള ഒരു വേലി, മറ്റ് [`SeqCst`] പ്രവർത്തനങ്ങളുടെയും/അല്ലെങ്കിൽ വേലികളുടെയും ആഗോള പ്രോഗ്രാം ക്രമത്തിൽ പങ്കെടുക്കുന്നു.
///
/// [`Acquire`], [`Release`], [`AcqRel`], [`SeqCst`] ഓർഡറുകൾ സ്വീകരിക്കുന്നു.
///
/// # Panics
///
/// `order` [`Relaxed`] ആണെങ്കിൽ Panics.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // സ്പിൻ‌ലോക്കിനെ അടിസ്ഥാനമാക്കിയുള്ള പരസ്പര ഒഴിവാക്കൽ പ്രാകൃതം.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // പഴയ മൂല്യം `false` ആകുന്നതുവരെ കാത്തിരിക്കുക.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // ഈ വേലി `unlock`-ൽ സ്റ്റോറുമായി സമന്വയിപ്പിക്കുന്നു.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // സുരക്ഷ: ഒരു ആറ്റോമിക് വേലി ഉപയോഗിക്കുന്നത് സുരക്ഷിതമാണ്.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// ഒരു കംപൈലർ മെമ്മറി വേലി.
///
/// `compiler_fence` ഒരു മെഷീൻ കോഡും പുറത്തുവിടുന്നില്ല, പക്ഷേ കംപൈലർ ചെയ്യാൻ അനുവദിച്ചിരിക്കുന്ന മെമ്മറി പുന-ക്രമീകരിക്കുന്നതിനെ നിയന്ത്രിക്കുന്നു.പ്രത്യേകിച്ചും, തന്നിരിക്കുന്ന [`Ordering`] സെമാന്റിക്‌സിനെ ആശ്രയിച്ച്, കോളിന് `compiler_fence`-ലേക്ക് കോളിന്റെ മറുവശത്തേക്കുള്ള കോളിന് മുമ്പോ ശേഷമോ റീഡുകൾ അല്ലെങ്കിൽ റൈറ്റുകൾ നീക്കുന്നതിൽ നിന്ന് കംപൈലറിനെ അനുവദിക്കില്ല.അത്തരം പുന-ക്രമീകരണം *ഹാർഡ്‌വെയറിനെ* ഇത് ** തടയുന്നില്ലെന്നത് ശ്രദ്ധിക്കുക.
///
/// സിംഗിൾ-ത്രെഡ്, എക്സിക്യൂഷൻ സന്ദർഭത്തിൽ ഇത് ഒരു പ്രശ്നമല്ല, എന്നാൽ മറ്റ് ത്രെഡുകൾ ഒരേ സമയം മെമ്മറിയിൽ മാറ്റം വരുത്തുമ്പോൾ, [`fence`] പോലുള്ള ശക്തമായ സമന്വയ പ്രൈമിറ്റീവുകൾ ആവശ്യമാണ്.
///
/// വ്യത്യസ്‌ത ഓർ‌ഡറിംഗ് സെമാന്റിക്‌സ് തടഞ്ഞ പുന-ക്രമീകരണം ഇവയാണ്:
///
///  - [`SeqCst`] ഉപയോഗിച്ച്, ഈ പോയിന്റിലുടനീളം റീഡുകളുടെയും റൈറ്റുകളുടെയും പുന order ക്രമീകരണം അനുവദനീയമല്ല.
///  - [`Release`] ഉപയോഗിച്ച്, മുമ്പത്തെ റീഡുകളും റൈറ്റുകളും മുമ്പത്തെ റൈറ്റുകളെ നീക്കാൻ കഴിയില്ല.
///  - [`Acquire`] ഉപയോഗിച്ച്, തുടർന്നുള്ള റീഡുകളും റൈറ്റുകളും മുമ്പത്തെ റീഡുകളേക്കാൾ മുന്നോട്ട് നീക്കാൻ കഴിയില്ല.
///  - [`AcqRel`] ഉപയോഗിച്ച്, മുകളിലുള്ള രണ്ട് നിയമങ്ങളും നടപ്പിലാക്കുന്നു.
///
/// `compiler_fence` ഒരു ത്രെഡ് റേസിംഗിൽ നിന്ന് തടയാൻ *സാധാരണയായി ഉപയോഗപ്രദമാണ്*.അതായത്, തന്നിരിക്കുന്ന ത്രെഡ് ഒരു കോഡ് കോഡ് എക്സിക്യൂട്ട് ചെയ്യുകയും പിന്നീട് തടസ്സപ്പെടുത്തുകയും മറ്റെവിടെയെങ്കിലും കോഡ് എക്സിക്യൂട്ട് ചെയ്യാൻ ആരംഭിക്കുകയും ചെയ്യുന്നുവെങ്കിൽ (അതേ ത്രെഡിലായിരിക്കുമ്പോഴും ആശയപരമായി ഇപ്പോഴും അതേ കാമ്പിൽ തന്നെ).പരമ്പരാഗത പ്രോഗ്രാമുകളിൽ, ഒരു സിഗ്നൽ ഹാൻഡ്‌ലർ രജിസ്റ്റർ ചെയ്യുമ്പോൾ മാത്രമേ ഇത് സംഭവിക്കൂ.
/// കൂടുതൽ താഴ്ന്ന നിലയിലുള്ള കോഡിൽ, തടസ്സങ്ങൾ കൈകാര്യം ചെയ്യുമ്പോഴും, പ്രീ-എംപ്ഷൻ ഉപയോഗിച്ച് പച്ച ത്രെഡുകൾ നടപ്പിലാക്കുമ്പോഴും അത്തരം സാഹചര്യങ്ങൾ ഉണ്ടാകാം.
/// [memory barriers] നെക്കുറിച്ചുള്ള Linux കേർണലിന്റെ ചർച്ച വായിക്കാൻ ജിജ്ഞാസയുള്ള വായനക്കാരെ പ്രോത്സാഹിപ്പിക്കുന്നു.
///
/// # Panics
///
/// `order` [`Relaxed`] ആണെങ്കിൽ Panics.
///
/// # Examples
///
/// `compiler_fence` ഇല്ലാതെ, ഒരു ത്രെഡിൽ എല്ലാം നടക്കുന്നുണ്ടെങ്കിലും, ഇനിപ്പറയുന്ന കോഡിലെ `assert_eq!` വിജയിക്കുമെന്ന് * ഉറപ്പുനൽകുന്നില്ല.
/// എന്തുകൊണ്ടാണെന്നറിയാൻ, സ്റ്റോറുകൾ `Ordering::Relaxed`, `IS_READ` എന്നിവയിലേക്ക് സ്വാപ്പ് ചെയ്യാൻ കംപൈലർ സ is ജന്യമാണെന്ന് ഓർമ്മിക്കുക.അങ്ങനെയാണെങ്കിൽ, `IS_READY` അപ്‌ഡേറ്റുചെയ്‌ത ഉടൻ തന്നെ സിഗ്നൽ ഹാൻഡ്‌ലർ അഭ്യർത്ഥിക്കുന്നുവെങ്കിൽ, സിഗ്നൽ ഹാൻഡ്‌ലർ `IS_READY=1` കാണും, പക്ഷേ `IMPORTANT_VARIABLE=0`.
/// ഒരു `compiler_fence` പരിഹാരങ്ങൾ ഉപയോഗിക്കുന്നത് ഈ അവസ്ഥയ്ക്ക് പരിഹാരമാണ്.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // മുമ്പത്തെ റൈറ്റുകൾ ഈ പോയിന്റിനപ്പുറത്തേക്ക് നീക്കുന്നത് തടയുക
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // സുരക്ഷ: ഒരു ആറ്റോമിക് വേലി ഉപയോഗിക്കുന്നത് സുരക്ഷിതമാണ്.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// പ്രോസസ്സർ തിരക്കുള്ള-കാത്തിരിപ്പ് സ്പിൻ-ലൂപ്പിനുള്ളിലാണെന്ന് ("സ്പിൻ ലോക്ക്") സിഗ്നൽ ചെയ്യുന്നു.
///
/// ഈ പ്രവർത്തനം [`hint::spin_loop`] ന് അനുകൂലമായി ഒഴിവാക്കി.
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}