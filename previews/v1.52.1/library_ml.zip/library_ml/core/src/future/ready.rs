use crate::future::Future;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// ഒരു മൂല്യത്തിനൊപ്പം ഉടനടി തയ്യാറായ ഒരു future സൃഷ്ടിക്കുന്നു.
///
/// ഈ `struct` സൃഷ്ടിച്ചത് [`ready()`] ആണ്.
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
#[derive(Debug, Clone)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
pub struct Ready<T>(Option<T>);

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
impl<T> Unpin for Ready<T> {}

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
impl<T> Future for Ready<T> {
    type Output = T;

    #[inline]
    fn poll(mut self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<T> {
        Poll::Ready(self.0.take().expect("Ready polled after completion"))
    }
}

/// ഒരു മൂല്യത്തിനൊപ്പം ഉടനടി തയ്യാറായ ഒരു future സൃഷ്ടിക്കുന്നു.
///
/// ഈ ഫംഗ്ഷനിലൂടെ സൃഷ്ടിച്ച Futures, `async {}` വഴി സൃഷ്ടിച്ചതിന് സമാനമാണ്.
/// ഈ ഫംഗ്ഷനിലൂടെ സൃഷ്ടിച്ച futures ന് പേര് നൽകി `Unpin` നടപ്പിലാക്കുക എന്നതാണ് പ്രധാന വ്യത്യാസം.
///
/// # Examples
///
/// ```
/// use std::future;
///
/// # async fn run() {
/// let a = future::ready(1);
/// assert_eq!(a.await, 1);
/// # }
/// ```
///
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub fn ready<T>(t: T) -> Ready<T> {
    Ready(Some(t))
}