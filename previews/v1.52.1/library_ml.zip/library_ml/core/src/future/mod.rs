#![stable(feature = "futures_api", since = "1.36.0")]

//! അസമന്വിത മൂല്യങ്ങൾ.

use crate::{
    ops::{Generator, GeneratorState},
    pin::Pin,
    ptr::NonNull,
    task::{Context, Poll},
};

mod future;
mod into_future;
mod pending;
mod poll_fn;
mod ready;

#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::future::Future;

#[unstable(feature = "into_future", issue = "67644")]
pub use into_future::IntoFuture;

#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use pending::{pending, Pending};
#[stable(feature = "future_readiness_fns", since = "1.48.0")]
pub use ready::{ready, Ready};

#[unstable(feature = "future_poll_fn", issue = "72302")]
pub use poll_fn::{poll_fn, PollFn};

/// ഈ തരം ആവശ്യമാണ് കാരണം:
///
/// a) ജനറേറ്ററുകൾക്ക് `for<'a, 'b> Generator<&'a mut Context<'b>>` നടപ്പിലാക്കാൻ കഴിയില്ല, അതിനാൽ ഞങ്ങൾക്ക് ഒരു റോ പോയിന്റർ നൽകേണ്ടതുണ്ട് (<https://github.com/rust-lang/rust/issues/68923> കാണുക).
///
/// b) അസംസ്കൃത പോയിന്ററുകളും `NonNull` ഉം `Send` അല്ലെങ്കിൽ `Sync` അല്ല, അതിനാൽ ഇത് ഓരോ future non-Send/Sync-ഉം ഉണ്ടാക്കും, ഞങ്ങൾക്ക് അത് ആവശ്യമില്ല.
///
/// എക്സ് 100 എക്‌സിന്റെ എച്ച്ഐആർ കുറയ്ക്കുന്നതും ഇത് ലളിതമാക്കുന്നു.
///
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[derive(Debug, Copy, Clone)]
pub struct ResumeTy(NonNull<Context<'static>>);

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Send for ResumeTy {}

#[unstable(feature = "gen_future", issue = "50547")]
unsafe impl Sync for ResumeTy {}

/// ഒരു future-ൽ ഒരു ജനറേറ്റർ പൊതിയുക.
///
/// ഈ ഫംഗ്ഷൻ ചുവടെ ഒരു `GenFuture` നൽകുന്നു, പക്ഷേ മികച്ച പിശക് സന്ദേശങ്ങൾ നൽകുന്നതിന് ഇത് `impl Trait` ൽ മറയ്ക്കുന്നു (`GenFuture<[closure.....]>` എന്നതിനേക്കാൾ `impl Future`).
///
// ഞങ്ങൾ `const async fn`-ൽ നിന്ന് വീണ്ടെടുത്ത ശേഷം അധിക പിശകുകൾ ഒഴിവാക്കാൻ ഇത് `const` ആണ്
#[lang = "from_generator"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[rustc_const_unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub const fn from_generator<T>(gen: T) -> impl Future<Output = T::Return>
where
    T: Generator<ResumeTy, Yield = ()>,
{
    #[rustc_diagnostic_item = "gen_future"]
    struct GenFuture<T: Generator<ResumeTy, Yield = ()>>(T);

    // അന്തർലീനമായ ജനറേറ്ററിൽ സ്വയം റഫറൻഷ്യൽ വായ്പകൾ സൃഷ്ടിക്കുന്നതിന് async/await futures സ്ഥാവരമാണെന്ന വസ്തുതയെ ഞങ്ങൾ ആശ്രയിക്കുന്നു.
    //
    impl<T: Generator<ResumeTy, Yield = ()>> !Unpin for GenFuture<T> {}

    impl<T: Generator<ResumeTy, Yield = ()>> Future for GenFuture<T> {
        type Output = T::Return;
        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
            // സുരക്ഷ: സുരക്ഷിതം കാരണം ഞങ്ങൾ !Unpin + !Drop ആണ്, ഇത് ഒരു ഫീൽഡ് പ്രൊജക്ഷൻ മാത്രമാണ്.
            let gen = unsafe { Pin::map_unchecked_mut(self, |s| &mut s.0) };

            // ജനറേറ്റർ പുനരാരംഭിക്കുക, `&mut Context` ഒരു `NonNull` റോ പോയിന്ററായി മാറ്റുന്നു.
            // `.await` താഴ്ത്തൽ സുരക്ഷിതമായി `&mut Context`-ലേക്ക് കാസ്റ്റുചെയ്യും.
            match gen.resume(ResumeTy(NonNull::from(cx).cast::<Context<'static>>())) {
                GeneratorState::Yielded(()) => Poll::Pending,
                GeneratorState::Complete(x) => Poll::Ready(x),
            }
        }
    }

    GenFuture(gen)
}

#[lang = "get_context"]
#[doc(hidden)]
#[unstable(feature = "gen_future", issue = "50547")]
#[inline]
pub unsafe fn get_context<'a, 'b>(cx: ResumeTy) -> &'a mut Context<'b> {
    // സുരക്ഷ: `cx.0` ഒരു സാധുവായ പോയിന്ററാണെന്ന് വിളിക്കുന്നയാൾ ഉറപ്പുനൽകണം
    // മ്യൂട്ടബിൾ റഫറൻസിനായുള്ള എല്ലാ ആവശ്യകതകളും അത് നിറവേറ്റുന്നു.
    unsafe { &mut *cx.0.as_ptr().cast() }
}