//! ഓപ്ഷണൽ മൂല്യങ്ങൾ.
//!
//! തരം [`Option`] ഒരു ഓപ്‌ഷണൽ മൂല്യത്തെ പ്രതിനിധീകരിക്കുന്നു: ഓരോ [`Option`]-ഉം [`Some`] ആണ്, അതിൽ ഒരു മൂല്യം അല്ലെങ്കിൽ [`None`] അടങ്ങിയിരിക്കുന്നു, ഇല്ല.
//! [`Option`] Rust കോഡിൽ തരങ്ങൾ വളരെ സാധാരണമാണ്, കാരണം അവയ്ക്ക് ധാരാളം ഉപയോഗങ്ങളുണ്ട്:
//!
//! * പ്രാരംഭ മൂല്യങ്ങൾ
//! * മുഴുവൻ ഇൻപുട്ട് ശ്രേണിയിലും നിർവചിച്ചിട്ടില്ലാത്ത ഫംഗ്ഷനുകൾക്കായുള്ള റിട്ടേൺ മൂല്യങ്ങൾ (ഭാഗിക പ്രവർത്തനങ്ങൾ)
//! * ലളിതമായ പിശകുകൾ റിപ്പോർട്ടുചെയ്യുന്നതിനുള്ള മൂല്യം നൽകുക, അവിടെ [`None`] പിശകായി മടക്കിനൽകുന്നു
//! * ഓപ്ഷണൽ സ്ട്രക്റ്റ് ഫീൽഡുകൾ
//! * വായ്പയെടുക്കാവുന്ന ഫീൽഡുകൾ അല്ലെങ്കിൽ എക്സ് 100 എക്സ്
//! * ഓപ്ഷണൽ ഫംഗ്ഷൻ ആർഗ്യുമെന്റുകൾ
//! * അസാധുവായ പോയിന്ററുകൾ
//! * വിഷമകരമായ സാഹചര്യങ്ങളിൽ നിന്ന് കാര്യങ്ങൾ മാറ്റുന്നു
//!
//! [`ഓപ്ഷൻ`] സാധാരണയായി ഒരു മൂല്യത്തിന്റെ സാന്നിധ്യം അന്വേഷിക്കുന്നതിനും നടപടിയെടുക്കുന്നതിനുമുള്ള പാറ്റേൺ പൊരുത്തവുമായി ജോടിയാക്കുന്നു, എല്ലായ്പ്പോഴും [`None`] കേസ് കണക്കാക്കുന്നു.
//!
//!
//! ```
//! fn divide(numerator: f64, denominator: f64) -> Option<f64> {
//!     if denominator == 0.0 {
//!         None
//!     } else {
//!         Some(numerator / denominator)
//!     }
//! }
//!
//! // ഫംഗ്ഷന്റെ റിട്ടേൺ മൂല്യം ഒരു ഓപ്ഷനാണ്
//! let result = divide(2.0, 3.0);
//!
//! // മൂല്യം വീണ്ടെടുക്കുന്നതിനുള്ള പാറ്റേൺ പൊരുത്തം
//! match result {
//!     // ഡിവിഷൻ സാധുവായിരുന്നു
//!     Some(x) => println!("Result: {}", x),
//!     // വിഭജനം അസാധുവായിരുന്നു
//!     None    => println!("Cannot divide by 0"),
//! }
//! ```
//!
//!
//!
//!
//!
// FIXME: ധാരാളം രീതികൾ ഉപയോഗിച്ച് `Option` എങ്ങനെയാണ് പ്രായോഗികമായി ഉപയോഗിക്കുന്നതെന്ന് കാണിക്കുക
//
//! # ഓപ്ഷനുകളും പോയിന്ററുകളും ("nullable" പോയിന്ററുകൾ)
//!
//! Rust ന്റെ പോയിന്റർ തരങ്ങൾ എല്ലായ്പ്പോഴും സാധുവായ ഒരു സ്ഥാനത്തേക്ക് പോയിന്റുചെയ്യണം;"null" റഫറൻസുകളൊന്നുമില്ല.പകരം, Rust ന് ഓപ്‌ഷണൽ ഉടമസ്ഥതയിലുള്ള ബോക്സ് പോലെ *ഓപ്‌ഷണൽ* പോയിന്ററുകൾ ഉണ്ട്, [`ഓപ്ഷൻ`]`<`[`ബോക്സ്<T>`]`>`.
//!
//! [`i32`]-ന്റെ ഒരു ഓപ്‌ഷണൽ ബോക്സ് സൃഷ്‌ടിക്കുന്നതിന് ഇനിപ്പറയുന്ന ഉദാഹരണം [`Option`] ഉപയോഗിക്കുന്നു.
//! ആദ്യം ആന്തരിക [`i32`] മൂല്യം ഉപയോഗിക്കുന്നതിന്, ബോക്സിന് ഒരു മൂല്യമുണ്ടോ എന്ന് നിർണ്ണയിക്കാൻ `check_optional` ഫംഗ്ഷൻ പാറ്റേൺ പൊരുത്തപ്പെടുത്തൽ ഉപയോഗിക്കേണ്ടതുണ്ട് (അതായത്, ഇത് [`Some(...)`][`Some`]) അല്ലെങ്കിൽ ([`None`]) അല്ല.
//!
//!
//! ```
//! let optional = None;
//! check_optional(optional);
//!
//! let optional = Some(Box::new(9000));
//! check_optional(optional);
//!
//! fn check_optional(optional: Option<Box<i32>>) {
//!     match optional {
//!         Some(p) => println!("has value {}", p),
//!         None => println!("has no value"),
//!     }
//! }
//! ```
//!
//! # Representation
//!
//! ഇനിപ്പറയുന്ന തരത്തിലുള്ള `T` ഒപ്റ്റിമൈസ് ചെയ്യുന്നതിന് Rust ഗ്യാരണ്ടി നൽകുന്നു, അതായത് [`Option<T>`] ന് `T`-ന് തുല്യമായ വലുപ്പമുണ്ട്:
//!
//! * [`Box<U>`]
//! * `&U`
//! * `&mut U`
//! * `fn`, `extern "C" fn`
//! * [`num::NonZero*`]
//! * [`ptr::NonNull<U>`]
//! * `#[repr(transparent)]` ഈ ലിസ്റ്റിലെ ഒരു തരത്തെ ചുറ്റിപ്പറ്റിയുള്ള ഘടന.
//!
//! മുകളിലുള്ള കേസുകൾ‌ക്ക്, ഒരാൾ‌ക്ക് `T` ന്റെ എല്ലാ സാധുവായ മൂല്യങ്ങളിൽ‌നിന്നും `Some::<T>(_)` മുതൽ `T` വരെ [`mem::transmute`] ചെയ്യാൻ‌കഴിയും (പക്ഷേ `None::<T>` മുതൽ `T` ലേക്ക് പരിവർത്തനം ചെയ്യുന്നത് നിർ‌വ്വചിക്കാത്ത സ്വഭാവമാണ്).
//!
//! # Examples
//!
//! [`Option`]-ൽ അടിസ്ഥാന പാറ്റേൺ പൊരുത്തപ്പെടുത്തൽ:
//!
//! ```
//! let msg = Some("howdy");
//!
//! // അടങ്ങിയിരിക്കുന്ന സ്ട്രിംഗിലേക്ക് ഒരു റഫറൻസ് എടുക്കുക
//! if let Some(m) = &msg {
//!     println!("{}", *m);
//! }
//!
//! // ഓപ്ഷൻ നശിപ്പിച്ചുകൊണ്ട് അടങ്ങിയിരിക്കുന്ന സ്ട്രിംഗ് നീക്കംചെയ്യുക
//! let unwrapped_msg = msg.unwrap_or("default message");
//! ```
//!
//! ഒരു ലൂപ്പിന് മുമ്പ് [`None`] ലേക്ക് ഒരു ഫലം സമാരംഭിക്കുക:
//!
//! ```
//! enum Kingdom { Plant(u32, &'static str), Animal(u32, &'static str) }
//!
//! // തിരയേണ്ട ഡാറ്റയുടെ ഒരു പട്ടിക.
//! let all_the_big_things = [
//!     Kingdom::Plant(250, "redwood"),
//!     Kingdom::Plant(230, "noble fir"),
//!     Kingdom::Plant(229, "sugar pine"),
//!     Kingdom::Animal(25, "blue whale"),
//!     Kingdom::Animal(19, "fin whale"),
//!     Kingdom::Animal(15, "north pacific right whale"),
//! ];
//!
//! // ഞങ്ങൾ ഏറ്റവും വലിയ മൃഗത്തിന്റെ പേര് തിരയാൻ പോകുന്നു, പക്ഷേ ആരംഭിക്കാൻ ഞങ്ങൾക്ക് `None` ലഭിച്ചു.
//! //
//! let mut name_of_biggest_animal = None;
//! let mut size_of_biggest_animal = 0;
//! for big_thing in &all_the_big_things {
//!     match *big_thing {
//!         Kingdom::Animal(size, name) if size > size_of_biggest_animal => {
//!             // ഇപ്പോൾ ഞങ്ങൾ ചില വലിയ മൃഗങ്ങളുടെ പേര് കണ്ടെത്തി
//!             size_of_biggest_animal = size;
//!             name_of_biggest_animal = Some(name);
//!         }
//!         Kingdom::Animal(..) | Kingdom::Plant(..) => ()
//!     }
//! }
//!
//! match name_of_biggest_animal {
//!     Some(name) => println!("the biggest animal is {}", name),
//!     None => println!("there are no animals :("),
//! }
//! ```
//!
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Box<U>`]: ../../std/boxed/struct.Box.html
//! [`num::NonZero*`]: crate::num
//! [`ptr::NonNull<U>`]: crate::ptr::NonNull
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{FromIterator, FusedIterator, TrustedLen};
use crate::pin::Pin;
use crate::{
    fmt, hint, mem,
    ops::{self, Deref, DerefMut},
};

/// `Option` തരം.കൂടുതൽ വിവരങ്ങൾക്ക് [the module level documentation](self) കാണുക.
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[rustc_diagnostic_item = "option_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Option<T> {
    /// മൂല്യമില്ല
    #[lang = "None"]
    #[stable(feature = "rust1", since = "1.0.0")]
    None,
    /// ചില മൂല്യം `T`
    #[lang = "Some"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Some(#[stable(feature = "rust1", since = "1.0.0")] T),
}

/////////////////////////////////////////////////////////////////////////////
// ടൈപ്പ് നടപ്പിലാക്കൽ
/////////////////////////////////////////////////////////////////////////////

impl<T> Option<T> {
    /////////////////////////////////////////////////////////////////////////
    // അടങ്ങിയിരിക്കുന്ന മൂല്യങ്ങൾ അന്വേഷിക്കുന്നു
    /////////////////////////////////////////////////////////////////////////

    /// ഓപ്ഷൻ ഒരു [`Some`] മൂല്യമാണെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_some(), true);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_some(), false);
    /// ```
    #[must_use = "if you intended to assert that this has a value, consider `.unwrap()` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_some(&self) -> bool {
        matches!(*self, Some(_))
    }

    /// ഓപ്ഷൻ ഒരു [`None`] മൂല്യമാണെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.is_none(), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.is_none(), true);
    /// ```
    #[must_use = "if you intended to assert that this doesn't have a value, consider \
                  `.and_then(|| panic!(\"`Option` had a value when expected `None`\"))` instead"]
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_none(&self) -> bool {
        !self.is_some()
    }

    /// നൽകിയിരിക്കുന്ന മൂല്യം അടങ്ങിയ [`Some`] മൂല്യമാണെങ്കിൽ ഓപ്ഷൻ `true` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Option<u32> = Some(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Option<u32> = Some(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Some(y) => x == y,
            None => false,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // റഫറൻസുകളിൽ പ്രവർത്തിക്കുന്നതിനുള്ള അഡാപ്റ്റർ
    /////////////////////////////////////////////////////////////////////////

    /// `&Option<T>`-ൽ നിന്ന് `Option<&T>`-ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// # Examples
    ///
    /// ഒറിജിനൽ സംരക്ഷിച്ച് ഒരു `ഓപ്ഷൻ <` [`സ്ട്രിംഗ്`]`>`ഒരു`ഓപ്ഷനായി <`[`ഉപയോഗപ്പെടുത്തുക`] `>` പരിവർത്തനം ചെയ്യുന്നു.
    /// [`map`] രീതി `self` ആർഗ്യുമെന്റിനെ മൂല്യം അനുസരിച്ച് എടുക്കുന്നു, ഒറിജിനൽ ഉപയോഗിക്കുന്നു, അതിനാൽ ഈ സാങ്കേതികത `as_ref` ഉപയോഗിച്ച് ആദ്യം ഒറിജിനലിനുള്ളിലെ മൂല്യത്തെ സൂചിപ്പിക്കുന്നതിന് ഒരു `Option` എടുക്കുന്നു.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let text: Option<String> = Some("Hello, world!".to_string());
    /// // ആദ്യം, `as_ref` ഉപയോഗിച്ച് `Option<String>` ലേക്ക് `Option<&String>` ലേക്ക് കാസ്റ്റുചെയ്യുക, തുടർന്ന് `map` ഉപയോഗിച്ച് *അത്* ഉപയോഗിക്കുക, `text` സ്റ്റാക്കിൽ ഉപേക്ഷിക്കുക.
    /////
    /// let text_length: Option<usize> = text.as_ref().map(|s| s.len());
    /// println!("still can print text: {:?}", text);
    /// ```
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_option", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Option<&T> {
        match *self {
            Some(ref x) => Some(x),
            None => None,
        }
    }

    /// `&mut Option<T>`-ൽ നിന്ന് `Option<&mut T>`-ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// match x.as_mut() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Option<&mut T> {
        match *self {
            Some(ref mut x) => Some(x),
            None => None,
        }
    }

    /// [`പിൻ`]`<&ഓപ്ഷനിൽ നിന്ന് പരിവർത്തനം ചെയ്യുന്നു<T>>`ടു`ഓപ്ഷൻ <`[`പിൻ`] `<&ടി>>`.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_ref(self: Pin<&Self>) -> Option<Pin<&T>> {
        // സുരക്ഷ: `x` പിൻ ചെയ്യുമെന്ന് ഉറപ്പുനൽകുന്നു, കാരണം ഇത് `self`-ൽ നിന്ന് വരുന്നു
        // ഇത് പിൻ ചെയ്‌തു.
        unsafe { Pin::get_ref(self).as_ref().map(|x| Pin::new_unchecked(x)) }
    }

    /// [`പിൻ`]`<&മ്യൂട്ട് ഓപ്ഷനിൽ നിന്ന് പരിവർത്തനം ചെയ്യുന്നു<T>>`ടു`ഓപ്ഷൻ <`[`പിൻ`] `<&മ്യൂട്ട് ടി>>`.
    #[inline]
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn as_pin_mut(self: Pin<&mut Self>) -> Option<Pin<&mut T>> {
        // സുരക്ഷ: X002-നുള്ളിൽ `Option` നീക്കാൻ `get_unchecked_mut` ഒരിക്കലും ഉപയോഗിക്കില്ല.
        // `x` പിൻ ചെയ്യപ്പെടുമെന്ന് ഉറപ്പുനൽകുന്നു, കാരണം ഇത് പിൻ ചെയ്ത `self`-ൽ നിന്ന് വരുന്നു.
        unsafe { Pin::get_unchecked_mut(self).as_mut().map(|x| Pin::new_unchecked(x)) }
    }

    /////////////////////////////////////////////////////////////////////////
    // അടങ്ങിയിരിക്കുന്ന മൂല്യങ്ങളിലേക്ക് എത്തിച്ചേരുന്നു
    /////////////////////////////////////////////////////////////////////////

    /// അടങ്ങിയിരിക്കുന്ന [`Some`] മൂല്യം നൽകുന്നു, `self` മൂല്യം ഉപയോഗിക്കുന്നു.
    ///
    /// # Panics
    ///
    /// `msg` നൽകിയ ഇഷ്‌ടാനുസൃത panic സന്ദേശത്തോടുകൂടിയ [`None`] ആണ് മൂല്യം എങ്കിൽ Panics.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("value");
    /// assert_eq!(x.expect("fruits are healthy"), "value");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// x.expect("fruits are healthy"); // panics with `fruits are healthy`
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Some(val) => val,
            None => expect_failed(msg),
        }
    }

    /// അടങ്ങിയിരിക്കുന്ന [`Some`] മൂല്യം നൽകുന്നു, `self` മൂല്യം ഉപയോഗിക്കുന്നു.
    ///
    /// ഈ പ്രവർത്തനം panic ആയിരിക്കാം, ഇതിന്റെ ഉപയോഗം പൊതുവെ നിരുത്സാഹപ്പെടുത്തുന്നു.
    /// പകരം, പാറ്റേൺ പൊരുത്തപ്പെടുത്തൽ ഉപയോഗിക്കാനും [`None`] കേസ് വ്യക്തമായി കൈകാര്യം ചെയ്യാനും തിരഞ്ഞെടുക്കുക, അല്ലെങ്കിൽ [`unwrap_or`], [`unwrap_or_else`], അല്ലെങ്കിൽ [`unwrap_or_default`] എന്ന് വിളിക്കുക.
    ///
    ///
    /// [`unwrap_or`]: Option::unwrap_or
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    /// [`unwrap_or_default`]: Option::unwrap_or_default
    ///
    /// # Panics
    ///
    /// സ്വയം മൂല്യം [`None`] ന് തുല്യമാണെങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("air");
    /// assert_eq!(x.unwrap(), "air");
    /// ```
    ///
    /// ```should_panic
    /// let x: Option<&str> = None;
    /// assert_eq!(x.unwrap(), "air"); // fails
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn unwrap(self) -> T {
        match self {
            Some(val) => val,
            None => panic!("called `Option::unwrap()` on a `None` value"),
        }
    }

    /// അടങ്ങിയിരിക്കുന്ന [`Some`] മൂല്യം അല്ലെങ്കിൽ നൽകിയ സ്ഥിരസ്ഥിതി നൽകുന്നു.
    ///
    /// `unwrap_or`-ലേക്ക് കൈമാറിയ ആർഗ്യുമെന്റുകൾ ആകാംക്ഷയോടെ വിലയിരുത്തപ്പെടുന്നു;നിങ്ങൾ ഒരു ഫംഗ്ഷൻ കോളിന്റെ ഫലം കൈമാറുകയാണെങ്കിൽ, [`unwrap_or_else`] ഉപയോഗിക്കാൻ ശുപാർശചെയ്യുന്നു, അത് അലസമായി വിലയിരുത്തപ്പെടുന്നു.
    ///
    ///
    /// [`unwrap_or_else`]: Option::unwrap_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(Some("car").unwrap_or("bike"), "car");
    /// assert_eq!(None.unwrap_or("bike"), "bike");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Some(x) => x,
            None => default,
        }
    }

    /// അടങ്ങിയിരിക്കുന്ന [`Some`] മൂല്യം നൽകുന്നു അല്ലെങ്കിൽ ഒരു ക്ലോസറിൽ നിന്ന് കണക്കാക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 10;
    /// assert_eq!(Some(4).unwrap_or_else(|| 2 * k), 4);
    /// assert_eq!(None.unwrap_or_else(|| 2 * k), 20);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce() -> T>(self, f: F) -> T {
        match self {
            Some(x) => x,
            None => f(),
        }
    }

    /// മൂല്യം [`None`] അല്ലെന്ന് പരിശോധിക്കാതെ, `self` മൂല്യം ഉപയോഗിച്ചുകൊണ്ട് അടങ്ങിയിരിക്കുന്ന [`Some`] മൂല്യം നൽകുന്നു.
    ///
    ///
    /// # Safety
    ///
    /// [`None`]-ൽ ഈ രീതിയെ വിളിക്കുന്നത് *[നിർവചിക്കപ്പെടാത്ത പെരുമാറ്റം]* ആണ്.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x = Some("air");
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air");
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Option<&str> = None;
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, "air"); // നിർവചിക്കപ്പെടാത്ത പെരുമാറ്റം!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_some());
        match self {
            Some(val) => val,
            // സുരക്ഷ: സുരക്ഷാ കരാർ വിളിക്കുന്നയാൾ ശരിവെക്കണം.
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // അടങ്ങിയിരിക്കുന്ന മൂല്യങ്ങൾ പരിവർത്തനം ചെയ്യുന്നു
    /////////////////////////////////////////////////////////////////////////

    /// അടങ്ങിയിരിക്കുന്ന മൂല്യത്തിലേക്ക് ഒരു ഫംഗ്ഷൻ പ്രയോഗിച്ചുകൊണ്ട് ഒരു `Option<T>` മുതൽ `Option<U>` വരെ മാപ്പ് ചെയ്യുന്നു.
    ///
    /// # Examples
    ///
    /// ഒറിജിനൽ ഉപയോഗിച്ചുകൊണ്ട് ഒരു `ഓപ്ഷൻ <` [`സ്ട്രിംഗ്`]`>`ഒരു`ഓപ്ഷനായി <`[`ഉപയോഗപ്പെടുത്തുക`] `>` പരിവർത്തനം ചെയ്യുന്നു:
    ///
    /// [`String`]: ../../std/string/struct.String.html
    /// ```
    /// let maybe_some_string = Some(String::from("Hello, World!"));
    /// // `Option::map` `maybe_some_string` ഉപയോഗിക്കുന്ന, മൂല്യം *ഉപയോഗിച്ച് സ്വയം* എടുക്കുന്നു
    /// let maybe_some_len = maybe_some_string.map(|s| s.len());
    ///
    /// assert_eq!(maybe_some_len, Some(13));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, f: F) -> Option<U> {
        match self {
            Some(x) => Some(f(x)),
            None => None,
        }
    }

    /// അടങ്ങിയിരിക്കുന്ന മൂല്യത്തിലേക്ക് (എന്തെങ്കിലും ഉണ്ടെങ്കിൽ) ഒരു ഫംഗ്ഷൻ പ്രയോഗിക്കുന്നു, അല്ലെങ്കിൽ നൽകിയ സ്ഥിരസ്ഥിതി നൽകുന്നു (ഇല്ലെങ്കിൽ).
    ///
    /// `map_or`-ലേക്ക് കൈമാറിയ ആർഗ്യുമെന്റുകൾ ആകാംക്ഷയോടെ വിലയിരുത്തപ്പെടുന്നു;നിങ്ങൾ ഒരു ഫംഗ്ഷൻ കോളിന്റെ ഫലം കൈമാറുകയാണെങ്കിൽ, [`map_or_else`] ഉപയോഗിക്കാൻ ശുപാർശചെയ്യുന്നു, അത് അലസമായി വിലയിരുത്തപ്പെടുന്നു.
    ///
    ///
    /// [`map_or_else`]: Option::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default,
        }
    }

    /// അടങ്ങിയിരിക്കുന്ന മൂല്യത്തിലേക്ക് (എന്തെങ്കിലും ഉണ്ടെങ്കിൽ) ഒരു ഫംഗ്ഷൻ പ്രയോഗിക്കുന്നു, അല്ലെങ്കിൽ ഒരു സ്ഥിരസ്ഥിതി കണക്കാക്കുന്നു (ഇല്ലെങ്കിൽ).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x = Some("foo");
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 3);
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.map_or_else(|| 2 * k, |v| v.len()), 42);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_or_else<U, D: FnOnce() -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Some(t) => f(t),
            None => default(),
        }
    }

    /// `Option<T>` നെ [`Result<T, E>`] ആക്കി മാറ്റുന്നു, [`Some(v)`] മുതൽ [`Ok(v)`] വരെയും [`None`] മുതൽ [`Err(err)`] വരെയും മാപ്പുചെയ്യുന്നു.
    ///
    /// `ok_or`-ലേക്ക് കൈമാറിയ ആർഗ്യുമെന്റുകൾ ആകാംക്ഷയോടെ വിലയിരുത്തപ്പെടുന്നു;നിങ്ങൾ ഒരു ഫംഗ്ഷൻ കോളിന്റെ ഫലം കൈമാറുകയാണെങ്കിൽ, [`ok_or_else`] ഉപയോഗിക്കാൻ ശുപാർശചെയ്യുന്നു, അത് അലസമായി വിലയിരുത്തപ്പെടുന്നു.
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err)`]: Err
    /// [`Some(v)`]: Some
    /// [`ok_or_else`]: Option::ok_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or(0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or(0), Err(0));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or<E>(self, err: E) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err),
        }
    }

    /// `Option<T>` നെ [`Result<T, E>`] ആക്കി മാറ്റുന്നു, [`Some(v)`] മുതൽ [`Ok(v)`] വരെയും [`None`] മുതൽ [`Err(err())`] വരെയും മാപ്പുചെയ്യുന്നു.
    ///
    ///
    /// [`Ok(v)`]: Ok
    /// [`Err(err())`]: Err
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("foo");
    /// assert_eq!(x.ok_or_else(|| 0), Ok("foo"));
    ///
    /// let x: Option<&str> = None;
    /// assert_eq!(x.ok_or_else(|| 0), Err(0));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok_or_else<E, F: FnOnce() -> E>(self, err: F) -> Result<T, E> {
        match self {
            Some(v) => Ok(v),
            None => Err(err()),
        }
    }

    /// ഓപ്ഷനിലേക്ക് `value` തിരുകിയതിനുശേഷം അതിലേക്ക് ഒരു മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു.
    ///
    /// ഓപ്‌ഷനിൽ ഇതിനകം ഒരു മൂല്യം അടങ്ങിയിട്ടുണ്ടെങ്കിൽ, പഴയ മൂല്യം ഒഴിവാക്കി.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(option_insert)]
    ///
    /// let mut opt = None;
    /// let val = opt.insert(1);
    /// assert_eq!(*val, 1);
    /// assert_eq!(opt.unwrap(), 1);
    /// let val = opt.insert(2);
    /// assert_eq!(*val, 2);
    /// *val = 3;
    /// assert_eq!(opt.unwrap(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "option_insert", reason = "newly added", issue = "78271")]
    pub fn insert(&mut self, value: T) -> &mut T {
        *self = Some(value);

        match self {
            Some(v) => v,
            // സുരക്ഷ: മുകളിലുള്ള കോഡ് ഓപ്ഷൻ പൂരിപ്പിച്ചു
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // ആവർത്തന നിർമ്മാതാക്കൾ
    /////////////////////////////////////////////////////////////////////////

    /// അടങ്ങിയിരിക്കുന്ന മൂല്യത്തിന് മുകളിൽ ഒരു ഇറ്ററേറ്റർ നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(4);
    /// assert_eq!(x.iter().next(), Some(&4));
    ///
    /// let x: Option<u32> = None;
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn iter(&self) -> Iter<'_, T> {
        Iter { inner: Item { opt: self.as_ref() } }
    }

    /// അടങ്ങിയിരിക്കുന്ന മൂല്യത്തിന് മുകളിൽ ഒരു മ്യൂട്ടബിൾ ഇറ്ററേറ്റർ നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(4);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 42,
    ///     None => {},
    /// }
    /// assert_eq!(x, Some(42));
    ///
    /// let mut x: Option<u32> = None;
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: Item { opt: self.as_mut() } }
    }

    /////////////////////////////////////////////////////////////////////////
    // മൂല്യങ്ങളിൽ ബൂളിയൻ പ്രവർത്തനങ്ങൾ, ആകാംക്ഷയും മടിയനും
    /////////////////////////////////////////////////////////////////////////

    /// ഓപ്ഷൻ [`None`] ആണെങ്കിൽ [`None`] നൽകുന്നു, അല്ലാത്തപക്ഷം `optb` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), None);
    ///
    /// let x = Some(2);
    /// let y = Some("foo");
    /// assert_eq!(x.and(y), Some("foo"));
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<&str> = None;
    /// assert_eq!(x.and(y), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, optb: Option<U>) -> Option<U> {
        match self {
            Some(_) => optb,
            None => None,
        }
    }

    /// ഓപ്ഷൻ [`None`] ആണെങ്കിൽ [`None`] നൽകുന്നു, അല്ലാത്തപക്ഷം പൊതിഞ്ഞ മൂല്യത്തോടുകൂടിയ `f`-ലേക്ക് വിളിച്ച് ഫലം നൽകുന്നു.
    ///
    ///
    /// ചില ഭാഷകൾ ഈ പ്രവർത്തനത്തെ ഫ്ലാറ്റ്മാപ്പ് എന്ന് വിളിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// fn sq(x: u32) -> Option<u32> { Some(x * x) }
    /// fn nope(_: u32) -> Option<u32> { None }
    ///
    /// assert_eq!(Some(2).and_then(sq).and_then(sq), Some(16));
    /// assert_eq!(Some(2).and_then(sq).and_then(nope), None);
    /// assert_eq!(Some(2).and_then(nope).and_then(sq), None);
    /// assert_eq!(None.and_then(sq).and_then(sq), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Option<U>>(self, f: F) -> Option<U> {
        match self {
            Some(x) => f(x),
            None => None,
        }
    }

    /// ഓപ്ഷൻ [`None`] ആണെങ്കിൽ [`None`] നൽകുന്നു, അല്ലാത്തപക്ഷം പൊതിഞ്ഞ മൂല്യത്തോടുകൂടിയ `predicate`-നെ വിളിച്ച് മടങ്ങുന്നു:
    ///
    ///
    /// - [`Some(t)`] `predicate` `true` നൽകുന്നുവെങ്കിൽ (ഇവിടെ `t` പൊതിഞ്ഞ മൂല്യമാണ്), ഒപ്പം
    /// - [`None`] `predicate` `false` നൽകുന്നുവെങ്കിൽ.
    ///
    /// ഈ പ്രവർത്തനം [`Iterator::filter()`]-ന് സമാനമായി പ്രവർത്തിക്കുന്നു.
    /// ഒന്നോ അതിലധികമോ ഘടകങ്ങൾക്ക് മുകളിലുള്ള ഒരു ആവർത്തനമാണ് `Option<T>` എന്ന് നിങ്ങൾക്ക് imagine ഹിക്കാനാകും.
    /// `filter()` ഏതെല്ലാം ഘടകങ്ങൾ സൂക്ഷിക്കണമെന്ന് തീരുമാനിക്കാൻ നിങ്ങളെ അനുവദിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```rust
    /// fn is_even(n: &i32) -> bool {
    ///     n % 2 == 0
    /// }
    ///
    /// assert_eq!(None.filter(is_even), None);
    /// assert_eq!(Some(3).filter(is_even), None);
    /// assert_eq!(Some(4).filter(is_even), Some(4));
    /// ```
    ///
    /// [`Some(t)`]: Some
    ///
    #[inline]
    #[stable(feature = "option_filter", since = "1.27.0")]
    pub fn filter<P: FnOnce(&T) -> bool>(self, predicate: P) -> Self {
        if let Some(x) = self {
            if predicate(&x) {
                return Some(x);
            }
        }
        None
    }

    /// ഓപ്‌ഷനിൽ ഒരു മൂല്യം അടങ്ങിയിട്ടുണ്ടെങ്കിൽ അത് നൽകുന്നു, അല്ലാത്തപക്ഷം `optb` നൽകുന്നു.
    ///
    /// `or`-ലേക്ക് കൈമാറിയ ആർഗ്യുമെന്റുകൾ ആകാംക്ഷയോടെ വിലയിരുത്തപ്പെടുന്നു;നിങ്ങൾ ഒരു ഫംഗ്ഷൻ കോളിന്റെ ഫലം കൈമാറുകയാണെങ്കിൽ, [`or_else`] ഉപയോഗിക്കാൻ ശുപാർശചെയ്യുന്നു, അത് അലസമായി വിലയിരുത്തപ്പെടുന്നു.
    ///
    ///
    /// [`or_else`]: Option::or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y = None;
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x = None;
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(100));
    ///
    /// let x = Some(2);
    /// let y = Some(100);
    /// assert_eq!(x.or(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = None;
    /// assert_eq!(x.or(y), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or(self, optb: Option<T>) -> Option<T> {
        match self {
            Some(_) => self,
            None => optb,
        }
    }

    /// ഓപ്‌ഷനിൽ ഒരു മൂല്യം അടങ്ങിയിട്ടുണ്ടെങ്കിൽ അത് നൽകുന്നു, അല്ലാത്തപക്ഷം `f` എന്ന് വിളിച്ച് ഫലം നൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn nobody() -> Option<&'static str> { None }
    /// fn vikings() -> Option<&'static str> { Some("vikings") }
    ///
    /// assert_eq!(Some("barbarians").or_else(vikings), Some("barbarians"));
    /// assert_eq!(None.or_else(vikings), Some("vikings"));
    /// assert_eq!(None.or_else(nobody), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F: FnOnce() -> Option<T>>(self, f: F) -> Option<T> {
        match self {
            Some(_) => self,
            None => f(),
        }
    }

    /// `self`-ൽ ഒന്ന്, `optb` [`Some`] ആണെങ്കിൽ [`Some`] നൽകുന്നു, അല്ലാത്തപക്ഷം [`None`] നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(2);
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x: Option<u32> = None;
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), Some(2));
    ///
    /// let x = Some(2);
    /// let y = Some(2);
    /// assert_eq!(x.xor(y), None);
    ///
    /// let x: Option<u32> = None;
    /// let y: Option<u32> = None;
    /// assert_eq!(x.xor(y), None);
    /// ```
    #[inline]
    #[stable(feature = "option_xor", since = "1.37.0")]
    pub fn xor(self, optb: Option<T>) -> Option<T> {
        match (self, optb) {
            (Some(a), None) => Some(a),
            (None, Some(b)) => Some(b),
            _ => None,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // ഒന്നുമില്ലെങ്കിൽ തിരുകാനും ഒരു റഫറൻസ് നൽകാനുമുള്ള എൻട്രി പോലുള്ള പ്രവർത്തനങ്ങൾ
    /////////////////////////////////////////////////////////////////////////

    /// `value` ഓപ്ഷനായി `value` ചേർക്കുന്നു, തുടർന്ന് അടങ്ങിയിരിക്കുന്ന മൂല്യത്തിലേക്ക് ഒരു മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert(5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert(&mut self, value: T) -> &mut T {
        self.get_or_insert_with(|| value)
    }

    /// [`None`] ആണെങ്കിൽ സ്ഥിരസ്ഥിതി മൂല്യം ഓപ്‌ഷനിലേക്ക് തിരുകുന്നു, തുടർന്ന് അടങ്ങിയിരിക്കുന്ന മൂല്യത്തിലേക്ക് ഒരു മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_get_or_insert_default)]
    ///
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_default();
    ///     assert_eq!(y, &0);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[unstable(feature = "option_get_or_insert_default", issue = "82901")]
    pub fn get_or_insert_default(&mut self) -> &mut T
    where
        T: Default,
    {
        self.get_or_insert_with(Default::default)
    }

    /// `f` ൽ നിന്ന് കണക്കാക്കിയ ഒരു മൂല്യം [`None`] ആണെങ്കിൽ ഓപ്ഷനിലേക്ക് തിരുകുന്നു, തുടർന്ന് അടങ്ങിയിരിക്കുന്ന മൂല്യത്തിലേക്ക് ഒരു മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = None;
    ///
    /// {
    ///     let y: &mut u32 = x.get_or_insert_with(|| 5);
    ///     assert_eq!(y, &5);
    ///
    ///     *y = 7;
    /// }
    ///
    /// assert_eq!(x, Some(7));
    /// ```
    #[inline]
    #[stable(feature = "option_entry", since = "1.20.0")]
    pub fn get_or_insert_with<F: FnOnce() -> T>(&mut self, f: F) -> &mut T {
        if let None = *self {
            *self = Some(f());
        }

        match self {
            Some(v) => v,
            // സുരക്ഷ: `self`-നായുള്ള `None` വേരിയന്റിന് പകരം `Some` ഉപയോഗിക്കുമായിരുന്നു
            // മുകളിലുള്ള കോഡിലെ വേരിയൻറ്.
            None => unsafe { hint::unreachable_unchecked() },
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // Misc
    /////////////////////////////////////////////////////////////////////////

    /// ഓപ്‌ഷനിൽ നിന്ന് മൂല്യം എടുക്കുന്നു, ഒരു [`None`] അതിന്റെ സ്ഥാനത്ത് അവശേഷിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, Some(2));
    ///
    /// let mut x: Option<u32> = None;
    /// let y = x.take();
    /// assert_eq!(x, None);
    /// assert_eq!(y, None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self)
    }

    /// ഓപ്‌ഷനിലെ യഥാർത്ഥ മൂല്യം പാരാമീറ്ററിൽ നൽകിയിരിക്കുന്ന മൂല്യം ഉപയോഗിച്ച് മാറ്റിസ്ഥാപിക്കുന്നു, പഴയ മൂല്യം നിലവിലുണ്ടെങ്കിൽ അത് നൽകുന്നു, ഒന്നിനെയും നിർവചിക്കാതെ ഒരു [`Some`] അതിന്റെ സ്ഥാനത്ത് ഉപേക്ഷിക്കുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = Some(2);
    /// let old = x.replace(5);
    /// assert_eq!(x, Some(5));
    /// assert_eq!(old, Some(2));
    ///
    /// let mut x = None;
    /// let old = x.replace(3);
    /// assert_eq!(x, Some(3));
    /// assert_eq!(old, None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "option_replace", since = "1.31.0")]
    pub fn replace(&mut self, value: T) -> Option<T> {
        mem::replace(self, Some(value))
    }

    /// മറ്റൊരു `Option` ഉള്ള Zips `self`.
    ///
    /// `self` `Some(s)` ഉം `other` `Some(o)` ഉം ആണെങ്കിൽ, ഈ രീതി `Some((s, o))` നൽകുന്നു.
    /// അല്ലെങ്കിൽ, `None` മടക്കിനൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some(1);
    /// let y = Some("hi");
    /// let z = None::<u8>;
    ///
    /// assert_eq!(x.zip(y), Some((1, "hi")));
    /// assert_eq!(x.zip(z), None);
    /// ```
    #[stable(feature = "option_zip_option", since = "1.46.0")]
    pub fn zip<U>(self, other: Option<U>) -> Option<(T, U)> {
        match (self, other) {
            (Some(a), Some(b)) => Some((a, b)),
            _ => None,
        }
    }

    /// സിപ്സ് എക്സ് 01 എക്സ്, എക്സ് എക്സ് എക്സ് ഫംഗ്ഷനോടുകൂടിയ മറ്റൊരു എക്സ് 02 എക്സ്.
    ///
    /// `self` `Some(s)` ഉം `other` `Some(o)` ഉം ആണെങ്കിൽ, ഈ രീതി `Some(f(s, o))` നൽകുന്നു.
    /// അല്ലെങ്കിൽ, `None` മടക്കിനൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_zip)]
    ///
    /// #[derive(Debug, PartialEq)]
    /// struct Point {
    ///     x: f64,
    ///     y: f64,
    /// }
    ///
    /// impl Point {
    ///     fn new(x: f64, y: f64) -> Self {
    ///         Self { x, y }
    ///     }
    /// }
    ///
    /// let x = Some(17.5);
    /// let y = Some(42.7);
    ///
    /// assert_eq!(x.zip_with(y, Point::new), Some(Point { x: 17.5, y: 42.7 }));
    /// assert_eq!(x.zip_with(None, Point::new), None);
    /// ```
    #[unstable(feature = "option_zip", issue = "70086")]
    pub fn zip_with<U, F, R>(self, other: Option<U>, f: F) -> Option<R>
    where
        F: FnOnce(T, U) -> R,
    {
        Some(f(self?, other?))
    }
}

impl<T: Copy> Option<&T> {
    /// ഓപ്‌ഷനിലെ ഉള്ളടക്കങ്ങൾ‌പകർ‌ത്തിക്കൊണ്ട് ഒരു `Option<&T>` ഒരു `Option<T>` ലേക്ക് മാപ്പുചെയ്യുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&t| t)
    }
}

impl<T: Copy> Option<&mut T> {
    /// ഓപ്‌ഷനിലെ ഉള്ളടക്കങ്ങൾ‌പകർ‌ത്തിക്കൊണ്ട് ഒരു `Option<&mut T>` ഒരു `Option<T>` ലേക്ക് മാപ്പുചെയ്യുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let copied = opt_x.copied();
    /// assert_eq!(copied, Some(12));
    /// ```
    #[stable(feature = "copied", since = "1.35.0")]
    pub fn copied(self) -> Option<T> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone> Option<&T> {
    /// ഓപ്ഷന്റെ ഉള്ളടക്കങ്ങൾ ക്ലോൺ ചെയ്തുകൊണ്ട് ഒരു `Option<&T>` ഒരു `Option<T>` ലേക്ക് മാപ്പ് ചെയ്യുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = 12;
    /// let opt_x = Some(&x);
    /// assert_eq!(opt_x, Some(&12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone> Option<&mut T> {
    /// ഓപ്ഷന്റെ ഉള്ളടക്കങ്ങൾ ക്ലോൺ ചെയ്തുകൊണ്ട് ഒരു `Option<&mut T>` ഒരു `Option<T>` ലേക്ക് മാപ്പ് ചെയ്യുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x = 12;
    /// let opt_x = Some(&mut x);
    /// assert_eq!(opt_x, Some(&mut 12));
    /// let cloned = opt_x.cloned();
    /// assert_eq!(cloned, Some(12));
    /// ```
    #[stable(since = "1.26.0", feature = "option_ref_mut_cloned")]
    pub fn cloned(self) -> Option<T> {
        self.map(|t| t.clone())
    }
}

impl<T: fmt::Debug> Option<T> {
    /// [`None`] പ്രതീക്ഷിച്ച് ഒന്നും നൽകാതെ `self` ഉപയോഗിക്കുന്നു.
    ///
    /// # Panics
    ///
    /// Panics മൂല്യം ഒരു [`Some`] ആണെങ്കിൽ, കടന്നുപോയ സന്ദേശം ഉൾപ്പെടെ panic സന്ദേശവും [`Some`]-ന്റെ ഉള്ളടക്കവും.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // എല്ലാ കീകളും അദ്വിതീയമായതിനാൽ ഇത് panic ആയിരിക്കില്ല.
    ///     squares.insert(i, i * i).expect_none("duplicate key");
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_expect_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).expect_none("duplicate key");
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_expect_none", reason = "newly added", issue = "62633")]
    pub fn expect_none(self, msg: &str) {
        if let Some(val) = self {
            expect_none_failed(msg, &val);
        }
    }

    /// [`None`] പ്രതീക്ഷിച്ച് ഒന്നും നൽകാതെ `self` ഉപയോഗിക്കുന്നു.
    ///
    /// # Panics
    ///
    /// Panics മൂല്യം ഒരു [`Some`] ആണെങ്കിൽ, [`ചില`] ന്റെ മൂല്യം നൽകുന്ന ഒരു ഇച്ഛാനുസൃത panic സന്ദേശം.
    ///
    ///
    /// [`Some(v)`]: Some
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut squares = HashMap::new();
    /// for i in -10..=10 {
    ///     // എല്ലാ കീകളും അദ്വിതീയമായതിനാൽ ഇത് panic ആയിരിക്കില്ല.
    ///     squares.insert(i, i * i).unwrap_none();
    /// }
    /// ```
    ///
    /// ```should_panic
    /// #![feature(option_unwrap_none)]
    ///
    /// use std::collections::HashMap;
    /// let mut sqrts = HashMap::new();
    /// for i in -10..=10 {
    ///     // This will panic, since both negative and positive `i` will
    ///     // insert the same `i * i` key, returning the old `Some(i)`.
    ///     sqrts.insert(i * i, i).unwrap_none();
    /// }
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_unwrap_none", reason = "newly added", issue = "62633")]
    pub fn unwrap_none(self) {
        if let Some(val) = self {
            expect_none_failed("called `Option::unwrap_none()` on a `Some` value", &val);
        }
    }
}

impl<T: Default> Option<T> {
    /// അടങ്ങിയിരിക്കുന്ന [`Some`] മൂല്യം അല്ലെങ്കിൽ സ്ഥിരസ്ഥിതി നൽകുന്നു
    ///
    /// `self` ആർ‌ഗ്യുമെൻറ് ഉപയോഗിക്കുന്നു, [`Some`] ആണെങ്കിൽ‌, അടങ്ങിയിരിക്കുന്ന മൂല്യം നൽകുന്നു, അല്ലെങ്കിൽ‌[`None`] ആണെങ്കിൽ‌, ആ തരത്തിനായി [default value] നൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ഒരു സ്ട്രിംഗിനെ ഒരു പൂർണ്ണസംഖ്യയിലേക്ക് പരിവർത്തനം ചെയ്യുന്നു, മോശമായി രൂപംകൊണ്ട സ്ട്രിംഗുകളെ 0 ആക്കി മാറ്റുന്നു (പൂർണ്ണസംഖ്യകളുടെ സ്ഥിര മൂല്യം).
    /// [`parse`] [`FromStr`] നടപ്പിലാക്കുന്ന മറ്റേതെങ്കിലും തരത്തിലേക്ക് ഒരു സ്ട്രിംഗ് പരിവർത്തനം ചെയ്യുന്നു, പിശകിൽ [`None`] നൽകുന്നു.
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().ok().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().ok().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [default value]: Default::default
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Some(x) => x,
            None => Default::default(),
        }
    }
}

impl<T: Deref> Option<T> {
    /// `Option<T>` (അല്ലെങ്കിൽ `&Option<T>`) ൽ നിന്ന് `Option<&T::Target>` ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// ഒറിജിനൽ ഓപ്ഷൻ സ്ഥലത്ത് ഉപേക്ഷിച്ച്, ഒറിജിനലിനെ റഫറൻസ് ഉപയോഗിച്ച് പുതിയൊരെണ്ണം സൃഷ്ടിക്കുന്നു, കൂടാതെ എക്സ് 100 എക്സ് വഴി ഉള്ളടക്കങ്ങൾ നിർബന്ധിക്കുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref(), Some("hey"));
    ///
    /// let x: Option<String> = None;
    /// assert_eq!(x.as_deref(), None);
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref(&self) -> Option<&T::Target> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut> Option<T> {
    /// `Option<T>` (അല്ലെങ്കിൽ `&mut Option<T>`) ൽ നിന്ന് `Option<&mut T::Target>` ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// യഥാർത്ഥ `Option` സ്ഥലത്ത് ഉപേക്ഷിച്ച്, ആന്തരിക തരത്തിന്റെ `Deref::Target` തരത്തിലേക്ക് മ്യൂട്ടബിൾ റഫറൻസ് ഉൾക്കൊള്ളുന്ന പുതിയൊരെണ്ണം സൃഷ്‌ടിക്കുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut x: Option<String> = Some("hey".to_owned());
    /// assert_eq!(x.as_deref_mut().map(|x| {
    ///     x.make_ascii_uppercase();
    ///     x
    /// }), Some("HEY".to_owned().as_mut_str()));
    /// ```
    #[stable(feature = "option_deref", since = "1.40.0")]
    pub fn as_deref_mut(&mut self) -> Option<&mut T::Target> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Option<Result<T, E>> {
    /// ഒരു [`Result`]-ന്റെ `Option` ഒരു `Option`-ന്റെ [`Result`]-ലേക്ക് മാറ്റുന്നു.
    ///
    /// [`None`] [`ശരി`]`(`[`ഒന്നുമില്ല`] `)` എന്നതിലേക്ക് മാപ്പുചെയ്യും.
    /// [`ചിലത്`]`(`[`ശരി`] `(_))`, [`ചിലത്`]`(`[`പിശക്`] `(_))` എന്നിവ [`ശരി`]`(`[`ചില`] `(_))`, [`പിശക്`]`(_)`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x, y.transpose());
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn transpose(self) -> Result<Option<T>, E> {
        match self {
            Some(Ok(x)) => Ok(Some(x)),
            Some(Err(e)) => Err(e),
            None => Ok(None),
        }
    }
}

// .expect()-ന്റെ കോഡ് വലുപ്പം കുറയ്ക്കുന്നതിനുള്ള ഒരു പ്രത്യേക പ്രവർത്തനമാണിത്.
#[inline(never)]
#[cold]
#[track_caller]
fn expect_failed(msg: &str) -> ! {
    panic!("{}", msg)
}

// .expect_none()-ന്റെ കോഡ് വലുപ്പം കുറയ്ക്കുന്നതിനുള്ള ഒരു പ്രത്യേക പ്രവർത്തനമാണിത്.
#[inline(never)]
#[cold]
#[track_caller]
fn expect_none_failed(msg: &str, value: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, value)
}

/////////////////////////////////////////////////////////////////////////////
// Trait നടപ്പിലാക്കലുകൾ
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for Option<T> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Some(x) => Some(x.clone()),
            None => None,
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Some(to), Some(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Option<T> {
    /// [`None`][Option::None] നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let opt: Option<u32> = Option::default();
    /// assert!(opt.is_none());
    /// ```
    #[inline]
    fn default() -> Option<T> {
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for Option<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// അടങ്ങിയിരിക്കുന്ന മൂല്യത്തെക്കാൾ ഉപഭോഗ ഇറ്ററേറ്റർ നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Some("string");
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert_eq!(v, ["string"]);
    ///
    /// let x = None;
    /// let v: Vec<&str> = x.into_iter().collect();
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: Item { opt: self } }
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a Option<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "option_iter")]
impl<'a, T> IntoIterator for &'a mut Option<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(since = "1.12.0", feature = "option_from")]
impl<T> From<T> for Option<T> {
    /// `val` ഒരു പുതിയ `Some`-ലേക്ക് പകർത്തുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let o: Option<u8> = Option::from(67);
    ///
    /// assert_eq!(Some(67), o);
    /// ```
    fn from(val: T) -> Option<T> {
        Some(val)
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a Option<T>> for Option<&'a T> {
    /// `&Option<T>`-ൽ നിന്ന് `Option<&T>`-ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// # Examples
    ///
    /// ഒറിജിനൽ സംരക്ഷിച്ച് ഒരു `ഓപ്ഷൻ <` [`സ്ട്രിംഗ്`]`>`ഒരു`ഓപ്ഷനായി <`[`ഉപയോഗപ്പെടുത്തുക`] `>` പരിവർത്തനം ചെയ്യുന്നു.
    /// [`map`] രീതി `self` ആർഗ്യുമെന്റിനെ മൂല്യം അനുസരിച്ച് എടുക്കുന്നു, ഒറിജിനൽ ഉപയോഗിക്കുന്നു, അതിനാൽ ഈ സാങ്കേതികത `as_ref` ഉപയോഗിച്ച് ആദ്യം ഒറിജിനലിനുള്ളിലെ മൂല്യത്തെ സൂചിപ്പിക്കുന്നതിന് ഒരു `Option` എടുക്കുന്നു.
    ///
    ///
    /// [`map`]: Option::map
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// ```
    /// let s: Option<String> = Some(String::from("Hello, Rustaceans!"));
    /// let o: Option<usize> = Option::from(&s).map(|ss: &String| ss.len());
    ///
    /// println!("Can still print s: {:?}", s);
    ///
    /// assert_eq!(o, Some(18));
    /// ```
    ///
    fn from(o: &'a Option<T>) -> Option<&'a T> {
        o.as_ref()
    }
}

#[stable(feature = "option_ref_from_ref_option", since = "1.30.0")]
impl<'a, T> From<&'a mut Option<T>> for Option<&'a mut T> {
    /// `&mut Option<T>`-ൽ നിന്ന് `Option<&mut T>`-ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = Some(String::from("Hello"));
    /// let o: Option<&mut String> = Option::from(&mut s);
    ///
    /// match o {
    ///     Some(t) => *t = String::from("Hello, Rustaceans!"),
    ///     None => (),
    /// }
    ///
    /// assert_eq!(s, Some(String::from("Hello, Rustaceans!")));
    /// ```
    fn from(o: &'a mut Option<T>) -> Option<&'a mut T> {
        o.as_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// ഓപ്ഷൻ ഇറ്ററേറ്ററുകൾ
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
struct Item<A> {
    opt: Option<A>,
}

impl<A> Iterator for Item<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.opt.take()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        match self.opt {
            Some(_) => (1, Some(1)),
            None => (0, Some(0)),
        }
    }
}

impl<A> DoubleEndedIterator for Item<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.opt.take()
    }
}

impl<A> ExactSizeIterator for Item<A> {}
impl<A> FusedIterator for Item<A> {}
unsafe impl<A> TrustedLen for Item<A> {}

/// ഒരു [`Option`]-ന്റെ [`Some`] വേരിയന്റിലേക്കുള്ള റഫറൻസിനു മുകളിലുള്ള ഒരു ഇറ്ററേറ്റർ.
///
/// [`Option`] ഒരു [`Some`] ആണെങ്കിൽ ആവർത്തനം ഒരു മൂല്യം നൽകുന്നു, അല്ലാത്തപക്ഷം.
///
/// ഈ `struct` സൃഷ്ടിച്ചത് [`Option::iter`] ഫംഗ്ഷനാണ്.
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct Iter<'a, A: 'a> {
    inner: Item<&'a A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for Iter<'a, A> {
    type Item = &'a A;

    #[inline]
    fn next(&mut self) -> Option<&'a A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for Iter<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for Iter<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for Iter<'_, A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Clone for Iter<'_, A> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner.clone() }
    }
}

/// ഒരു [`Option`]-ന്റെ [`Some`] വേരിയന്റിലേക്കുള്ള മ്യൂട്ടബിൾ റഫറൻസിന് മുകളിലുള്ള ഒരു ഇറ്ററേറ്റർ.
///
/// [`Option`] ഒരു [`Some`] ആണെങ്കിൽ ആവർത്തനം ഒരു മൂല്യം നൽകുന്നു, അല്ലാത്തപക്ഷം.
///
/// ഈ `struct` സൃഷ്ടിച്ചത് [`Option::iter_mut`] ഫംഗ്ഷനാണ്.
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IterMut<'a, A: 'a> {
    inner: Item<&'a mut A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> Iterator for IterMut<'a, A> {
    type Item = &'a mut A;

    #[inline]
    fn next(&mut self) -> Option<&'a mut A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, A> DoubleEndedIterator for IterMut<'a, A> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IterMut<'_, A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IterMut<'_, A> {}
#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// ഒരു [`Option`]-ന്റെ [`Some`] വേരിയന്റിലെ മൂല്യത്തിന് മുകളിലുള്ള ഒരു ഇറ്ററേറ്റർ.
///
/// [`Option`] ഒരു [`Some`] ആണെങ്കിൽ ആവർത്തനം ഒരു മൂല്യം നൽകുന്നു, അല്ലാത്തപക്ഷം.
///
/// ഈ `struct` സൃഷ്ടിച്ചത് [`Option::into_iter`] ഫംഗ്ഷനാണ്.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<A> {
    inner: Item<A>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Iterator for IntoIter<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        self.inner.next()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> DoubleEndedIterator for IntoIter<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        self.inner.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> ExactSizeIterator for IntoIter<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A> FusedIterator for IntoIter<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, V: FromIterator<A>> FromIterator<Option<A>> for Option<V> {
    /// [`Iterator`]-ലെ ഓരോ ഘടകങ്ങളും എടുക്കുന്നു: അത് [`None`][Option::None] ആണെങ്കിൽ, കൂടുതൽ ഘടകങ്ങളൊന്നും എടുക്കുന്നില്ല, കൂടാതെ [`None`][Option::None] തിരികെ നൽകുന്നു.
    /// [`None`][Option::None] ഒന്നും സംഭവിച്ചില്ലെങ്കിൽ, ഓരോ [`Option`]-ന്റെയും മൂല്യങ്ങളുള്ള ഒരു കണ്ടെയ്നർ തിരികെ നൽകും.
    ///
    /// # Examples
    ///
    /// ഒരു vector ലെ എല്ലാ സംഖ്യകളും വർദ്ധിപ്പിക്കുന്ന ഒരു ഉദാഹരണം ഇതാ.
    /// `add` ന്റെ പരിശോധിച്ച വേരിയൻറ് ഞങ്ങൾ ഉപയോഗിക്കുന്നു, അത് കണക്കുകൂട്ടൽ ഒരു ഓവർഫ്ലോയ്ക്ക് കാരണമാകുമ്പോൾ `None` നൽകുന്നു.
    ///
    /// ```
    /// let items = vec![0_u16, 1, 2];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_add(1))
    ///     .collect();
    ///
    /// assert_eq!(res, Some(vec![1, 2, 3]));
    /// ```
    ///
    /// നിങ്ങൾക്ക് കാണാനാകുന്നതുപോലെ, ഇത് പ്രതീക്ഷിച്ചതും സാധുവായതുമായ ഇനങ്ങൾ നൽകും.
    ///
    /// പൂർണ്ണസംഖ്യകളുടെ മറ്റൊരു പട്ടികയിൽ നിന്ന് ഒന്ന് കുറയ്ക്കാൻ ശ്രമിക്കുന്ന മറ്റൊരു ഉദാഹരണം ഇതാ, ഈ സമയം അണ്ടർഫ്ലോയ്‌ക്കായി പരിശോധിക്കുന്നു:
    ///
    /// ```
    /// let items = vec![2_u16, 1, 0];
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| x.checked_sub(1))
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// ```
    ///
    /// അവസാന ഘടകം പൂജ്യമായതിനാൽ, അത് ഒഴുകും.അങ്ങനെ, ഫലമായി ലഭിക്കുന്ന മൂല്യം `None` ആണ്.
    ///
    /// മുമ്പത്തെ ഉദാഹരണത്തിലെ ഒരു വ്യതിയാനം ഇതാ, ആദ്യത്തെ `None` ന് ശേഷം `iter` ൽ നിന്ന് കൂടുതൽ ഘടകങ്ങളൊന്നും എടുക്കുന്നില്ലെന്ന് കാണിക്കുന്നു.
    ///
    /// ```
    /// let items = vec![3_u16, 2, 1, 10];
    ///
    /// let mut shared = 0;
    ///
    /// let res: Option<Vec<u16>> = items
    ///     .iter()
    ///     .map(|x| { shared += x; x.checked_sub(2) })
    ///     .collect();
    ///
    /// assert_eq!(res, None);
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// മൂന്നാമത്തെ ഘടകം ഒരു അണ്ടർഫ്ലോയ്ക്ക് കാരണമായതിനാൽ, കൂടുതൽ ഘടകങ്ങളൊന്നും എടുത്തില്ല, അതിനാൽ `shared`-ന്റെ അന്തിമ മൂല്യം 6 അല്ല (= `3 + 2 + 1`), 16 അല്ല.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Option<A>>>(iter: I) -> Option<V> {
        // FIXME(#11084): ഈ പ്രകടന ബഗ് അടയ്‌ക്കുമ്പോൾ ഇത് Iterator::scan ഉപയോഗിച്ച് മാറ്റിസ്ഥാപിക്കാം.
        //

        iter.into_iter().map(|x| x.ok_or(())).collect::<Result<_, _>>().ok()
    }
}

/// ട്രൈ ഓപ്പറേറ്റർ (`?`) ഒരു `None` മൂല്യത്തിലേക്ക് പ്രയോഗിക്കുന്നതിന്റെ ഫലമായുണ്ടാകുന്ന പിശക് തരം.
/// നിങ്ങളുടെ പിശക് തരത്തിലേക്ക് പരിവർത്തനം ചെയ്യാൻ `x?` (ഇവിടെ `x` ഒരു `Option<T>` ആണ്) അനുവദിക്കാൻ നിങ്ങൾ ആഗ്രഹിക്കുന്നുവെങ്കിൽ, നിങ്ങൾക്ക് `YourErrorType`-നായി `impl From<NoneError>` നടപ്പിലാക്കാൻ കഴിയും.
///
/// അത്തരം സന്ദർഭങ്ങളിൽ, `Result<_, YourErrorType>` നൽകുന്ന ഒരു ഫംഗ്ഷനുള്ളിലെ `x?` ഒരു `None` മൂല്യത്തെ `Err` ഫലത്തിലേക്ക് വിവർത്തനം ചെയ്യും.
#[rustc_diagnostic_item = "none_error"]
#[unstable(feature = "try_trait", issue = "42327")]
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
pub struct NoneError;

#[unstable(feature = "try_trait", issue = "42327")]
impl<T> ops::Try for Option<T> {
    type Ok = T;
    type Error = NoneError;

    #[inline]
    fn into_result(self) -> Result<T, NoneError> {
        self.ok_or(NoneError)
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Some(v)
    }

    #[inline]
    fn from_error(_: NoneError) -> Self {
        None
    }
}

impl<T> Option<Option<T>> {
    /// `Option<Option<T>>`-ൽ നിന്ന് `Option<T>`-ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let x: Option<Option<u32>> = Some(Some(6));
    /// assert_eq!(Some(6), x.flatten());
    ///
    /// let x: Option<Option<u32>> = Some(None);
    /// assert_eq!(None, x.flatten());
    ///
    /// let x: Option<Option<u32>> = None;
    /// assert_eq!(None, x.flatten());
    /// ```
    ///
    /// പരന്നത് ഒരു സമയം കൂടുണ്ടാക്കുന്നത് മാത്രമേ നീക്കംചെയ്യൂ:
    ///
    /// ```
    /// let x: Option<Option<Option<u32>>> = Some(Some(Some(6)));
    /// assert_eq!(Some(Some(6)), x.flatten());
    /// assert_eq!(Some(6), x.flatten().flatten());
    /// ```
    #[inline]
    #[stable(feature = "option_flattening", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_option", issue = "67441")]
    pub const fn flatten(self) -> Option<T> {
        match self {
            Some(inner) => inner,
            None => None,
        }
    }
}