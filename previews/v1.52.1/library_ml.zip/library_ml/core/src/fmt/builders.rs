#![allow(unused_imports)]

use crate::fmt::{self, Debug, Formatter};

struct PadAdapter<'buf, 'state> {
    buf: &'buf mut (dyn fmt::Write + 'buf),
    state: &'state mut PadAdapterState,
}

struct PadAdapterState {
    on_newline: bool,
}

impl Default for PadAdapterState {
    fn default() -> Self {
        PadAdapterState { on_newline: true }
    }
}

impl<'buf, 'state> PadAdapter<'buf, 'state> {
    fn wrap<'slot, 'fmt: 'buf + 'slot>(
        fmt: &'fmt mut fmt::Formatter<'_>,
        slot: &'slot mut Option<Self>,
        state: &'state mut PadAdapterState,
    ) -> fmt::Formatter<'slot> {
        fmt.wrap_buf(move |buf| {
            *slot = Some(PadAdapter { buf, state });
            slot.as_mut().unwrap()
        })
    }
}

impl fmt::Write for PadAdapter<'_, '_> {
    fn write_str(&mut self, mut s: &str) -> fmt::Result {
        while !s.is_empty() {
            if self.state.on_newline {
                self.buf.write_str("    ")?;
            }

            let split = match s.find('\n') {
                Some(pos) => {
                    self.state.on_newline = true;
                    pos + 1
                }
                None => {
                    self.state.on_newline = false;
                    s.len()
                }
            };
            self.buf.write_str(&s[..split])?;
            s = &s[split..];
        }

        Ok(())
    }
}

/// [`fmt::Debug`](Debug) നടപ്പിലാക്കലുകളെ സഹായിക്കുന്നതിനുള്ള ഒരു ഘടന.
///
/// നിങ്ങളുടെ [`Debug::fmt`] നടപ്പിലാക്കലിന്റെ ഭാഗമായി ഒരു ഫോർമാറ്റ് ചെയ്ത സ്ട്രക്റ്റ് output ട്ട്പുട്ട് ചെയ്യാൻ നിങ്ങൾ ആഗ്രഹിക്കുമ്പോൾ ഇത് ഉപയോഗപ്രദമാകും.
///
///
/// [`Formatter::debug_struct`] രീതി ഉപയോഗിച്ച് ഇത് നിർമ്മിക്കാൻ കഴിയും.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// struct Foo {
///     bar: i32,
///     baz: String,
/// }
///
/// impl fmt::Debug for Foo {
///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
///         fmt.debug_struct("Foo")
///            .field("bar", &self.bar)
///            .field("baz", &self.baz)
///            .finish()
///     }
/// }
///
/// assert_eq!(
///     format!("{:?}", Foo { bar: 10, baz: "Hello World".to_string() }),
///     "Foo { bar: 10, baz: \"Hello World\" }",
/// );
/// ```
#[must_use = "must eventually call `finish()` on Debug builders"]
#[allow(missing_debug_implementations)]
#[stable(feature = "debug_builders", since = "1.2.0")]
pub struct DebugStruct<'a, 'b: 'a> {
    fmt: &'a mut fmt::Formatter<'b>,
    result: fmt::Result,
    has_fields: bool,
}

pub(super) fn debug_struct_new<'a, 'b>(
    fmt: &'a mut fmt::Formatter<'b>,
    name: &str,
) -> DebugStruct<'a, 'b> {
    let result = fmt.write_str(name);
    DebugStruct { fmt, result, has_fields: false }
}

impl<'a, 'b: 'a> DebugStruct<'a, 'b> {
    /// ജനറേറ്റുചെയ്ത സ്ട്രക്റ്റ് .ട്ട്‌പുട്ടിലേക്ക് ഒരു പുതിയ ഫീൽഡ് ചേർക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Bar {
    ///     bar: i32,
    ///     another: String,
    /// }
    ///
    /// impl fmt::Debug for Bar {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_struct("Bar")
    ///            .field("bar", &self.bar) // ഞങ്ങൾ `bar` ഫീൽഡ് ചേർക്കുന്നു.
    ///            .field("another", &self.another) // ഞങ്ങൾ `another` ഫീൽഡ് ചേർക്കുന്നു.
    ///            // നിലവിലില്ലാത്ത ഒരു ഫീൽഡ് പോലും ഞങ്ങൾ ചേർക്കുന്നു (കാരണം എന്തുകൊണ്ട്?).
    ///            .field("not_existing_field", &1)
    ///            .finish() // ഞങ്ങൾ പോകുന്നത് നല്ലതാണ്!
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Bar { bar: 10, another: "Hello World".to_string() }),
    ///     "Bar { bar: 10, another: \"Hello World\", not_existing_field: 1 }",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn field(&mut self, name: &str, value: &dyn fmt::Debug) -> &mut Self {
        self.result = self.result.and_then(|_| {
            if self.is_pretty() {
                if !self.has_fields {
                    self.fmt.write_str(" {\n")?;
                }
                let mut slot = None;
                let mut state = Default::default();
                let mut writer = PadAdapter::wrap(&mut self.fmt, &mut slot, &mut state);
                writer.write_str(name)?;
                writer.write_str(": ")?;
                value.fmt(&mut writer)?;
                writer.write_str(",\n")
            } else {
                let prefix = if self.has_fields { ", " } else { " { " };
                self.fmt.write_str(prefix)?;
                self.fmt.write_str(name)?;
                self.fmt.write_str(": ")?;
                value.fmt(self.fmt)
            }
        });

        self.has_fields = true;
        self
    }

    /// ഡീബഗ് പ്രാതിനിധ്യത്തിൽ കാണിക്കാത്ത മറ്റ് ചില ഫീൽഡുകൾ ഉണ്ടെന്ന് വായനക്കാരനെ സൂചിപ്പിക്കുന്ന ഘടനയെ നോൺ-എക്‌സ്‌ഹോസീവ് എന്ന് അടയാളപ്പെടുത്തുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(debug_non_exhaustive)]
    /// use std::fmt;
    ///
    /// struct Bar {
    ///     bar: i32,
    ///     hidden: f32,
    /// }
    ///
    /// impl fmt::Debug for Bar {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_struct("Bar")
    ///            .field("bar", &self.bar)
    ///            .finish_non_exhaustive() // മറ്റ് ചില field(s) നിലവിലുണ്ടെന്ന് കാണിക്കുക.
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Bar { bar: 10, hidden: 1.0 }),
    ///     "Bar { bar: 10, .. }",
    /// );
    /// ```
    #[unstable(feature = "debug_non_exhaustive", issue = "67364")]
    pub fn finish_non_exhaustive(&mut self) -> fmt::Result {
        self.result = self.result.and_then(|_| {
            // എക്‌സ്‌ഹോസ്റ്റീവ് ഡോട്ടുകൾ (`..`) വരയ്‌ക്കുക, ആവശ്യമെങ്കിൽ ബ്രേസ് തുറക്കുക (ഫീൽഡുകൾ ഇല്ല).
            if self.is_pretty() {
                if !self.has_fields {
                    self.fmt.write_str(" {\n")?;
                }
                let mut slot = None;
                let mut state = Default::default();
                let mut writer = PadAdapter::wrap(&mut self.fmt, &mut slot, &mut state);
                writer.write_str("..\n")?;
            } else {
                if self.has_fields {
                    self.fmt.write_str(", ..")?;
                } else {
                    self.fmt.write_str(" { ..")?;
                }
            }
            if self.is_pretty() {
                self.fmt.write_str("}")?
            } else {
                self.fmt.write_str(" }")?;
            }
            Ok(())
        });
        self.result
    }

    /// Output ട്ട്‌പുട്ട് പൂർത്തിയാക്കി നേരിട്ട ഏത് പിശകും നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Bar {
    ///     bar: i32,
    ///     baz: String,
    /// }
    ///
    /// impl fmt::Debug for Bar {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_struct("Bar")
    ///            .field("bar", &self.bar)
    ///            .field("baz", &self.baz)
    ///            .finish() // നിങ്ങൾ ഇത് "finish"-ലേക്ക് വിളിക്കേണ്ടതുണ്ട്
    ///                      // സ്ട്രക്റ്റ് ഫോർമാറ്റിംഗ്.
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Bar { bar: 10, baz: "Hello World".to_string() }),
    ///     "Bar { bar: 10, baz: \"Hello World\" }",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn finish(&mut self) -> fmt::Result {
        if self.has_fields {
            self.result = self.result.and_then(|_| {
                if self.is_pretty() { self.fmt.write_str("}") } else { self.fmt.write_str(" }") }
            });
        }
        self.result
    }

    fn is_pretty(&self) -> bool {
        self.fmt.alternate()
    }
}

/// [`fmt::Debug`](Debug) നടപ്പിലാക്കലുകളെ സഹായിക്കുന്നതിനുള്ള ഒരു ഘടന.
///
/// നിങ്ങളുടെ [`Debug::fmt`] നടപ്പാക്കലിന്റെ ഭാഗമായി ഫോർമാറ്റുചെയ്‌ത ട്യൂപ്പിൾ output ട്ട്‌പുട്ട് ചെയ്യാൻ നിങ്ങൾ ആഗ്രഹിക്കുമ്പോൾ ഇത് ഉപയോഗപ്രദമാകും.
///
///
/// [`Formatter::debug_tuple`] രീതി ഉപയോഗിച്ച് ഇത് നിർമ്മിക്കാൻ കഴിയും.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// struct Foo(i32, String);
///
/// impl fmt::Debug for Foo {
///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
///         fmt.debug_tuple("Foo")
///            .field(&self.0)
///            .field(&self.1)
///            .finish()
///     }
/// }
///
/// assert_eq!(
///     format!("{:?}", Foo(10, "Hello World".to_string())),
///     "Foo(10, \"Hello World\")",
/// );
/// ```
#[must_use = "must eventually call `finish()` on Debug builders"]
#[allow(missing_debug_implementations)]
#[stable(feature = "debug_builders", since = "1.2.0")]
pub struct DebugTuple<'a, 'b: 'a> {
    fmt: &'a mut fmt::Formatter<'b>,
    result: fmt::Result,
    fields: usize,
    empty_name: bool,
}

pub(super) fn debug_tuple_new<'a, 'b>(
    fmt: &'a mut fmt::Formatter<'b>,
    name: &str,
) -> DebugTuple<'a, 'b> {
    let result = fmt.write_str(name);
    DebugTuple { fmt, result, fields: 0, empty_name: name.is_empty() }
}

impl<'a, 'b: 'a> DebugTuple<'a, 'b> {
    /// ജനറേറ്റുചെയ്‌ത ടുപ്പിൾ സ്ട്രക്റ്റ് .ട്ട്‌പുട്ടിലേക്ക് ഒരു പുതിയ ഫീൽഡ് ചേർക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32, String);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///            .field(&self.0) // ഞങ്ങൾ ആദ്യ ഫീൽഡ് ചേർക്കുന്നു.
    ///            .field(&self.1) // ഞങ്ങൾ രണ്ടാമത്തെ ഫീൽഡ് ചേർക്കുന്നു.
    ///            .finish() // ഞങ്ങൾ പോകുന്നത് നല്ലതാണ്!
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(10, "Hello World".to_string())),
    ///     "Foo(10, \"Hello World\")",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn field(&mut self, value: &dyn fmt::Debug) -> &mut Self {
        self.result = self.result.and_then(|_| {
            if self.is_pretty() {
                if self.fields == 0 {
                    self.fmt.write_str("(\n")?;
                }
                let mut slot = None;
                let mut state = Default::default();
                let mut writer = PadAdapter::wrap(&mut self.fmt, &mut slot, &mut state);
                value.fmt(&mut writer)?;
                writer.write_str(",\n")
            } else {
                let prefix = if self.fields == 0 { "(" } else { ", " };
                self.fmt.write_str(prefix)?;
                value.fmt(self.fmt)
            }
        });

        self.fields += 1;
        self
    }

    /// Output ട്ട്‌പുട്ട് പൂർത്തിയാക്കി നേരിട്ട ഏത് പിശകും നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32, String);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///            .field(&self.0)
    ///            .field(&self.1)
    ///            .finish() // നിങ്ങൾ ഇത് "finish"-ലേക്ക് വിളിക്കേണ്ടതുണ്ട്
    ///                      // ടുപ്പിൾ ഫോർമാറ്റിംഗ്.
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(10, "Hello World".to_string())),
    ///     "Foo(10, \"Hello World\")",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn finish(&mut self) -> fmt::Result {
        if self.fields > 0 {
            self.result = self.result.and_then(|_| {
                if self.fields == 1 && self.empty_name && !self.is_pretty() {
                    self.fmt.write_str(",")?;
                }
                self.fmt.write_str(")")
            });
        }
        self.result
    }

    fn is_pretty(&self) -> bool {
        self.fmt.alternate()
    }
}

struct DebugInner<'a, 'b: 'a> {
    fmt: &'a mut fmt::Formatter<'b>,
    result: fmt::Result,
    has_fields: bool,
}

impl<'a, 'b: 'a> DebugInner<'a, 'b> {
    fn entry(&mut self, entry: &dyn fmt::Debug) {
        self.result = self.result.and_then(|_| {
            if self.is_pretty() {
                if !self.has_fields {
                    self.fmt.write_str("\n")?;
                }
                let mut slot = None;
                let mut state = Default::default();
                let mut writer = PadAdapter::wrap(&mut self.fmt, &mut slot, &mut state);
                entry.fmt(&mut writer)?;
                writer.write_str(",\n")
            } else {
                if self.has_fields {
                    self.fmt.write_str(", ")?
                }
                entry.fmt(self.fmt)
            }
        });

        self.has_fields = true;
    }

    fn is_pretty(&self) -> bool {
        self.fmt.alternate()
    }
}

/// [`fmt::Debug`](Debug) നടപ്പിലാക്കലുകളെ സഹായിക്കുന്നതിനുള്ള ഒരു ഘടന.
///
/// നിങ്ങളുടെ [`Debug::fmt`] നടപ്പിലാക്കലിന്റെ ഭാഗമായി ഫോർമാറ്റുചെയ്‌ത ഒരു കൂട്ടം ഇനങ്ങൾ output ട്ട്‌പുട്ട് ചെയ്യാൻ നിങ്ങൾ ആഗ്രഹിക്കുമ്പോൾ ഇത് ഉപയോഗപ്രദമാകും.
///
///
/// [`Formatter::debug_set`] രീതി ഉപയോഗിച്ച് ഇത് നിർമ്മിക്കാൻ കഴിയും.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// struct Foo(Vec<i32>);
///
/// impl fmt::Debug for Foo {
///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
///         fmt.debug_set().entries(self.0.iter()).finish()
///     }
/// }
///
/// assert_eq!(
///     format!("{:?}", Foo(vec![10, 11])),
///     "{10, 11}",
/// );
/// ```
#[must_use = "must eventually call `finish()` on Debug builders"]
#[allow(missing_debug_implementations)]
#[stable(feature = "debug_builders", since = "1.2.0")]
pub struct DebugSet<'a, 'b: 'a> {
    inner: DebugInner<'a, 'b>,
}

pub(super) fn debug_set_new<'a, 'b>(fmt: &'a mut fmt::Formatter<'b>) -> DebugSet<'a, 'b> {
    let result = fmt.write_str("{");
    DebugSet { inner: DebugInner { fmt, result, has_fields: false } }
}

impl<'a, 'b: 'a> DebugSet<'a, 'b> {
    /// സെറ്റ് .ട്ട്‌പുട്ടിലേക്ക് ഒരു പുതിയ എൻ‌ട്രി ചേർക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>, Vec<u32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_set()
    ///            .entry(&self.0) // ആദ്യത്തെ "entry" ചേർക്കുന്നു.
    ///            .entry(&self.1) // രണ്ടാമത്തെ "entry" ചേർക്കുന്നു.
    ///            .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(vec![10, 11], vec![12, 13])),
    ///     "{[10, 11], [12, 13]}",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn entry(&mut self, entry: &dyn fmt::Debug) -> &mut Self {
        self.inner.entry(entry);
        self
    }

    /// സെറ്റ് .ട്ട്‌പുട്ടിലേക്ക് എൻട്രികളുടെ ഒരു ആവർത്തന ഉള്ളടക്കങ്ങൾ ചേർക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>, Vec<u32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_set()
    ///            .entries(self.0.iter()) // ആദ്യത്തെ "entry" ചേർക്കുന്നു.
    ///            .entries(self.1.iter()) // രണ്ടാമത്തെ "entry" ചേർക്കുന്നു.
    ///            .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(vec![10, 11], vec![12, 13])),
    ///     "{10, 11, 12, 13}",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn entries<D, I>(&mut self, entries: I) -> &mut Self
    where
        D: fmt::Debug,
        I: IntoIterator<Item = D>,
    {
        for entry in entries {
            self.entry(&entry);
        }
        self
    }

    /// Output ട്ട്‌പുട്ട് പൂർത്തിയാക്കി നേരിട്ട ഏത് പിശകും നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_set()
    ///            .entries(self.0.iter())
    ///            .finish() // സ്ട്രക്റ്റ് ഫോർമാറ്റിംഗ് അവസാനിപ്പിക്കുന്നു.
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(vec![10, 11])),
    ///     "{10, 11}",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn finish(&mut self) -> fmt::Result {
        self.inner.result.and_then(|_| self.inner.fmt.write_str("}"))
    }
}

/// [`fmt::Debug`](Debug) നടപ്പിലാക്കലുകളെ സഹായിക്കുന്നതിനുള്ള ഒരു ഘടന.
///
/// നിങ്ങളുടെ [`Debug::fmt`] നടപ്പിലാക്കലിന്റെ ഭാഗമായി ഫോർമാറ്റ് ചെയ്ത ഇനങ്ങളുടെ പട്ടിക output ട്ട്പുട്ട് ചെയ്യാൻ നിങ്ങൾ ആഗ്രഹിക്കുമ്പോൾ ഇത് ഉപയോഗപ്രദമാകും.
///
///
/// [`Formatter::debug_list`] രീതി ഉപയോഗിച്ച് ഇത് നിർമ്മിക്കാൻ കഴിയും.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// struct Foo(Vec<i32>);
///
/// impl fmt::Debug for Foo {
///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
///         fmt.debug_list().entries(self.0.iter()).finish()
///     }
/// }
///
/// assert_eq!(
///     format!("{:?}", Foo(vec![10, 11])),
///     "[10, 11]",
/// );
/// ```
#[must_use = "must eventually call `finish()` on Debug builders"]
#[allow(missing_debug_implementations)]
#[stable(feature = "debug_builders", since = "1.2.0")]
pub struct DebugList<'a, 'b: 'a> {
    inner: DebugInner<'a, 'b>,
}

pub(super) fn debug_list_new<'a, 'b>(fmt: &'a mut fmt::Formatter<'b>) -> DebugList<'a, 'b> {
    let result = fmt.write_str("[");
    DebugList { inner: DebugInner { fmt, result, has_fields: false } }
}

impl<'a, 'b: 'a> DebugList<'a, 'b> {
    /// ലിസ്റ്റ് .ട്ട്‌പുട്ടിലേക്ക് ഒരു പുതിയ എൻ‌ട്രി ചേർക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>, Vec<u32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_list()
    ///            .entry(&self.0) // ഞങ്ങൾ ആദ്യത്തെ "entry" ചേർക്കുന്നു.
    ///            .entry(&self.1) // ഞങ്ങൾ രണ്ടാമത്തെ "entry" ചേർക്കുന്നു.
    ///            .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(vec![10, 11], vec![12, 13])),
    ///     "[[10, 11], [12, 13]]",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn entry(&mut self, entry: &dyn fmt::Debug) -> &mut Self {
        self.inner.entry(entry);
        self
    }

    /// ലിസ്റ്റ് .ട്ട്‌പുട്ടിലേക്ക് എൻ‌ട്രികളുടെ ഒരു ആവർത്തന ഉള്ളടക്കങ്ങൾ ചേർക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>, Vec<u32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_list()
    ///            .entries(self.0.iter())
    ///            .entries(self.1.iter())
    ///            .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(vec![10, 11], vec![12, 13])),
    ///     "[10, 11, 12, 13]",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn entries<D, I>(&mut self, entries: I) -> &mut Self
    where
        D: fmt::Debug,
        I: IntoIterator<Item = D>,
    {
        for entry in entries {
            self.entry(&entry);
        }
        self
    }

    /// Output ട്ട്‌പുട്ട് പൂർത്തിയാക്കി നേരിട്ട ഏത് പിശകും നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_list()
    ///            .entries(self.0.iter())
    ///            .finish() // സ്ട്രക്റ്റ് ഫോർമാറ്റിംഗ് അവസാനിപ്പിക്കുന്നു.
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(vec![10, 11])),
    ///     "[10, 11]",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn finish(&mut self) -> fmt::Result {
        self.inner.result.and_then(|_| self.inner.fmt.write_str("]"))
    }
}

/// [`fmt::Debug`](Debug) നടപ്പിലാക്കലുകളെ സഹായിക്കുന്നതിനുള്ള ഒരു ഘടന.
///
/// നിങ്ങളുടെ [`Debug::fmt`] നടപ്പിലാക്കലിന്റെ ഭാഗമായി ഫോർമാറ്റ് ചെയ്ത മാപ്പ് output ട്ട്പുട്ട് ചെയ്യാൻ നിങ്ങൾ ആഗ്രഹിക്കുമ്പോൾ ഇത് ഉപയോഗപ്രദമാണ്.
///
///
/// [`Formatter::debug_map`] രീതി ഉപയോഗിച്ച് ഇത് നിർമ്മിക്കാൻ കഴിയും.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// struct Foo(Vec<(String, i32)>);
///
/// impl fmt::Debug for Foo {
///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
///     }
/// }
///
/// assert_eq!(
///     format!("{:?}", Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
///     "{\"A\": 10, \"B\": 11}",
/// );
/// ```
#[must_use = "must eventually call `finish()` on Debug builders"]
#[allow(missing_debug_implementations)]
#[stable(feature = "debug_builders", since = "1.2.0")]
pub struct DebugMap<'a, 'b: 'a> {
    fmt: &'a mut fmt::Formatter<'b>,
    result: fmt::Result,
    has_fields: bool,
    has_key: bool,
    // കീകൾക്കും മൂല്യങ്ങൾക്കുമിടയിൽ പുതിയ ലൈനുകളുടെ അവസ്ഥ ട്രാക്കുചെയ്യുന്നു
    state: PadAdapterState,
}

pub(super) fn debug_map_new<'a, 'b>(fmt: &'a mut fmt::Formatter<'b>) -> DebugMap<'a, 'b> {
    let result = fmt.write_str("{");
    DebugMap { fmt, result, has_fields: false, has_key: false, state: Default::default() }
}

impl<'a, 'b: 'a> DebugMap<'a, 'b> {
    /// മാപ്പ് .ട്ട്‌പുട്ടിലേക്ക് ഒരു പുതിയ എൻ‌ട്രി ചേർക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_map()
    ///            .entry(&"whole", &self.0) // ഞങ്ങൾ "whole" എൻ‌ട്രി ചേർക്കുന്നു.
    ///            .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     "{\"whole\": [(\"A\", 10), (\"B\", 11)]}",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn entry(&mut self, key: &dyn fmt::Debug, value: &dyn fmt::Debug) -> &mut Self {
        self.key(key).value(value)
    }

    /// മാപ്പ് .ട്ട്‌പുട്ടിലേക്ക് ഒരു പുതിയ എൻ‌ട്രിയുടെ പ്രധാന ഭാഗം ചേർക്കുന്നു.
    ///
    /// `value`-നൊപ്പം ഈ രീതി `entry`-ന് പകരമുള്ളതാണ്, പൂർണ്ണമായ എൻ‌ട്രി മുൻ‌കൂട്ടി അറിയാത്തപ്പോൾ ഇത് ഉപയോഗിക്കാൻ‌കഴിയും.
    ///
    /// ഉപയോഗിക്കാൻ കഴിയുമ്പോൾ `entry` രീതി തിരഞ്ഞെടുക്കുക.
    ///
    /// # Panics
    ///
    /// `key` `value`-ന് മുമ്പായി വിളിക്കുകയും `key`-ലേക്ക് ഓരോ കോളും `value`-ലേക്ക് അനുബന്ധ കോളും പിന്തുടരുകയും വേണം.
    /// അല്ലെങ്കിൽ ഈ രീതി panic ആയിരിക്കും.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_map()
    ///            .key(&"whole").value(&self.0) // ഞങ്ങൾ "whole" എൻ‌ട്രി ചേർക്കുന്നു.
    ///            .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     "{\"whole\": [(\"A\", 10), (\"B\", 11)]}",
    /// );
    /// ```
    #[stable(feature = "debug_map_key_value", since = "1.42.0")]
    pub fn key(&mut self, key: &dyn fmt::Debug) -> &mut Self {
        self.result = self.result.and_then(|_| {
            assert!(
                !self.has_key,
                "attempted to begin a new map entry \
                                    without completing the previous one"
            );

            if self.is_pretty() {
                if !self.has_fields {
                    self.fmt.write_str("\n")?;
                }
                let mut slot = None;
                self.state = Default::default();
                let mut writer = PadAdapter::wrap(&mut self.fmt, &mut slot, &mut self.state);
                key.fmt(&mut writer)?;
                writer.write_str(": ")?;
            } else {
                if self.has_fields {
                    self.fmt.write_str(", ")?
                }
                key.fmt(self.fmt)?;
                self.fmt.write_str(": ")?;
            }

            self.has_key = true;
            Ok(())
        });

        self
    }

    /// മാപ്പ് .ട്ട്‌പുട്ടിലേക്ക് ഒരു പുതിയ എൻ‌ട്രിയുടെ മൂല്യം ഭാഗം ചേർക്കുന്നു.
    ///
    /// `key`-നൊപ്പം ഈ രീതി `entry`-ന് പകരമുള്ളതാണ്, പൂർണ്ണമായ എൻ‌ട്രി മുൻ‌കൂട്ടി അറിയാത്തപ്പോൾ ഇത് ഉപയോഗിക്കാൻ‌കഴിയും.
    ///
    /// ഉപയോഗിക്കാൻ കഴിയുമ്പോൾ `entry` രീതി തിരഞ്ഞെടുക്കുക.
    ///
    /// # Panics
    ///
    /// `key` `value`-ന് മുമ്പായി വിളിക്കുകയും `key`-ലേക്ക് ഓരോ കോളും `value`-ലേക്ക് അനുബന്ധ കോളും പിന്തുടരുകയും വേണം.
    /// അല്ലെങ്കിൽ ഈ രീതി panic ആയിരിക്കും.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_map()
    ///            .key(&"whole").value(&self.0) // ഞങ്ങൾ "whole" എൻ‌ട്രി ചേർക്കുന്നു.
    ///            .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     "{\"whole\": [(\"A\", 10), (\"B\", 11)]}",
    /// );
    /// ```
    #[stable(feature = "debug_map_key_value", since = "1.42.0")]
    pub fn value(&mut self, value: &dyn fmt::Debug) -> &mut Self {
        self.result = self.result.and_then(|_| {
            assert!(self.has_key, "attempted to format a map value before its key");

            if self.is_pretty() {
                let mut slot = None;
                let mut writer = PadAdapter::wrap(&mut self.fmt, &mut slot, &mut self.state);
                value.fmt(&mut writer)?;
                writer.write_str(",\n")?;
            } else {
                value.fmt(self.fmt)?;
            }

            self.has_key = false;
            Ok(())
        });

        self.has_fields = true;
        self
    }

    /// മാപ്പ് .ട്ട്‌പുട്ടിലേക്ക് എൻട്രികളുടെ ഒരു ആവർത്തന ഉള്ളടക്കങ്ങൾ ചേർക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_map()
    ///            // ഞങ്ങൾ ഞങ്ങളുടെ വെക് മാപ്പ് ചെയ്യുന്നതിനാൽ ഓരോ എൻ‌ട്രിയുടെയും ആദ്യ ഫീൽ‌ഡ് "key" ആകും.
    /////
    ///            .entries(self.0.iter().map(|&(ref k, ref v)| (k, v)))
    ///            .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     "{\"A\": 10, \"B\": 11}",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn entries<K, V, I>(&mut self, entries: I) -> &mut Self
    where
        K: fmt::Debug,
        V: fmt::Debug,
        I: IntoIterator<Item = (K, V)>,
    {
        for (k, v) in entries {
            self.entry(&k, &v);
        }
        self
    }

    /// Output ട്ട്‌പുട്ട് പൂർത്തിയാക്കി നേരിട്ട ഏത് പിശകും നൽകുന്നു.
    ///
    /// # Panics
    ///
    /// `key` `value`-ന് മുമ്പായി വിളിക്കുകയും `key`-ലേക്ക് ഓരോ കോളും `value`-ലേക്ക് അനുബന്ധ കോളും പിന്തുടരുകയും വേണം.
    /// അല്ലെങ്കിൽ ഈ രീതി panic ആയിരിക്കും.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         fmt.debug_map()
    ///            .entries(self.0.iter().map(|&(ref k, ref v)| (k, v)))
    ///            .finish() // സ്ട്രക്റ്റ് ഫോർമാറ്റിംഗ് അവസാനിപ്പിക്കുന്നു.
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}", Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     "{\"A\": 10, \"B\": 11}",
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn finish(&mut self) -> fmt::Result {
        self.result.and_then(|_| {
            assert!(!self.has_key, "attempted to finish a map with a partial entry");

            self.fmt.write_str("}")
        })
    }

    fn is_pretty(&self) -> bool {
        self.fmt.alternate()
    }
}