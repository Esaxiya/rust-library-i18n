//! സ്ട്രിംഗുകൾ ഫോർമാറ്റുചെയ്യുന്നതിനും അച്ചടിക്കുന്നതിനുമുള്ള യൂട്ടിലിറ്റികൾ.

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::{Cell, Ref, RefCell, RefMut, UnsafeCell};
use crate::marker::PhantomData;
use crate::mem;
use crate::num::flt2dec;
use crate::ops::Deref;
use crate::result;
use crate::str;

mod builders;
mod float;
mod num;

#[stable(feature = "fmt_flags_align", since = "1.28.0")]
/// `Formatter::align` നൽകിയ സാധ്യമായ വിന്യാസങ്ങൾ
#[derive(Debug)]
pub enum Alignment {
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// ഉള്ളടക്കങ്ങൾ ഇടത്-വിന്യസിക്കണം എന്നതിന്റെ സൂചന.
    Left,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// ഉള്ളടക്കങ്ങൾ ശരിയായി വിന്യസിക്കണം എന്നതിന്റെ സൂചന.
    Right,
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    /// ഉള്ളടക്കങ്ങൾ മധ്യഭാഗത്ത് വിന്യസിക്കണം എന്നതിന്റെ സൂചന.
    Center,
}

#[stable(feature = "debug_builders", since = "1.2.0")]
pub use self::builders::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};

#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub mod rt {
    pub mod v1;
}

/// ഫോർമാറ്റർ രീതികളിലൂടെ മടക്കിയ തരം.
///
/// # Examples
///
/// ```
/// use std::fmt;
///
/// #[derive(Debug)]
/// struct Triangle {
///     a: f32,
///     b: f32,
///     c: f32
/// }
///
/// impl fmt::Display for Triangle {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {}, {})", self.a, self.b, self.c)
///     }
/// }
///
/// let pythagorean_triple = Triangle { a: 3.0, b: 4.0, c: 5.0 };
///
/// assert_eq!(format!("{}", pythagorean_triple), "(3, 4, 5)");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub type Result = result::Result<(), Error>;

/// ഒരു സന്ദേശം ഒരു സ്ട്രീമിലേക്ക് ഫോർമാറ്റ് ചെയ്യുന്നതിൽ നിന്ന് മടക്കിയ പിശക് തരം.
///
/// ഒരു പിശക് സംഭവിച്ചതല്ലാതെ ഒരു പിശക് കൈമാറുന്നതിനെ ഈ തരം പിന്തുണയ്ക്കുന്നില്ല.
/// ഏതെങ്കിലും അധിക വിവരങ്ങൾ മറ്റേതെങ്കിലും മാർഗങ്ങളിലൂടെ കൈമാറാൻ ക്രമീകരിക്കണം.
///
/// ഓർത്തിരിക്കേണ്ട ഒരു പ്രധാന കാര്യം, `fmt::Error` തരം [`std::io::Error`] അല്ലെങ്കിൽ [`std::error::Error`] എന്നിവയുമായി ആശയക്കുഴപ്പത്തിലാകരുത്, അത് നിങ്ങൾക്ക് സ്കോപ്പിലും ഉണ്ടായിരിക്കാം.
///
///
/// [`std::io::Error`]: ../../std/io/struct.Error.html
/// [`std::error::Error`]: ../../std/error/trait.Error.html
///
/// # Examples
///
/// ```rust
/// use std::fmt::{self, write};
///
/// let mut output = String::new();
/// if let Err(fmt::Error) = write(&mut output, format_args!("Hello {}!", "world")) {
///     panic!("An error occurred");
/// }
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Default, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct Error;

/// യൂണിക്കോഡ് സ്വീകരിക്കുന്ന ബഫറുകളിലേക്കോ സ്ട്രീമുകളിലേക്കോ എഴുതുന്നതിനോ ഫോർമാറ്റുചെയ്യുന്നതിനോ ഉള്ള ഒരു trait.
///
/// ഈ trait UTF-8-എൻ‌കോഡുചെയ്‌ത ഡാറ്റ മാത്രമേ സ്വീകരിക്കുകയുള്ളൂ, അത് [flushable] അല്ല.
/// നിങ്ങൾക്ക് യൂണിക്കോഡ് മാത്രമേ സ്വീകരിക്കൂ, നിങ്ങൾക്ക് ഫ്ലഷിംഗ് ആവശ്യമില്ലെങ്കിൽ, നിങ്ങൾ ഈ trait നടപ്പിലാക്കണം;
/// അല്ലെങ്കിൽ നിങ്ങൾ [`std::io::Write`] നടപ്പിലാക്കണം.
///
/// [`std::io::Write`]: ../../std/io/trait.Write.html
/// [flushable]: ../../std/io/trait.Write.html#tymethod.flush
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Write {
    /// ഈ എഴുത്തുകാരനിലേക്ക് ഒരു സ്ട്രിംഗ് സ്ലൈസ് എഴുതുന്നു, എഴുത്ത് വിജയിച്ചോ എന്ന് മടക്കിനൽകുന്നു.
    ///
    /// മുഴുവൻ സ്ട്രിംഗ് സ്ലൈസും വിജയകരമായി എഴുതിയെങ്കിൽ മാത്രമേ ഈ രീതി വിജയിക്കൂ, മാത്രമല്ല എല്ലാ ഡാറ്റയും എഴുതുന്നതുവരെ അല്ലെങ്കിൽ ഒരു പിശക് സംഭവിക്കുന്നതുവരെ ഈ രീതി മടങ്ങിവരില്ല.
    ///
    ///
    /// # Errors
    ///
    /// ഈ ഫംഗ്ഷൻ പിശകിൽ [`Error`] ന്റെ ഒരു ഉദാഹരണം നൽകും.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_str(s)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "hola").unwrap();
    /// assert_eq!(&buf, "hola");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_str(&mut self, s: &str) -> Result;

    /// ഈ എഴുത്തുകാരനിലേക്ക് ഒരു [`char`] എഴുതുന്നു, റൈറ്റ് വിജയിച്ചോ എന്ന് നൽകുന്നു.
    ///
    /// ഒരൊറ്റ [`char`] ഒന്നിൽ കൂടുതൽ ബൈറ്റുകളായി എൻ‌കോഡുചെയ്‌തേക്കാം.
    /// മുഴുവൻ ബൈറ്റ് സീക്വൻസും വിജയകരമായി എഴുതിയെങ്കിൽ മാത്രമേ ഈ രീതി വിജയിക്കൂ, മാത്രമല്ല എല്ലാ ഡാറ്റയും എഴുതുന്നതുവരെ അല്ലെങ്കിൽ ഒരു പിശക് സംഭവിക്കുന്നതുവരെ ഈ രീതി മടങ്ങിവരില്ല.
    ///
    ///
    /// # Errors
    ///
    /// ഈ ഫംഗ്ഷൻ പിശകിൽ [`Error`] ന്റെ ഒരു ഉദാഹരണം നൽകും.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, c: char) -> Result<(), Error> {
    ///     f.write_char(c)
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, 'a').unwrap();
    /// writer(&mut buf, 'b').unwrap();
    /// assert_eq!(&buf, "ab");
    /// ```
    ///
    #[stable(feature = "fmt_write_char", since = "1.1.0")]
    fn write_char(&mut self, c: char) -> Result {
        self.write_str(c.encode_utf8(&mut [0; 4]))
    }

    /// ഈ trait നടപ്പിലാക്കുന്നവരുമൊത്ത് [`write!`] മാക്രോ ഉപയോഗിക്കുന്നതിനുള്ള പശ.
    ///
    /// ഈ രീതി സാധാരണയായി സ്വമേധയാ ഉപയോഗിക്കരുത്, മറിച്ച് [`write!`] മാക്രോയിലൂടെയാണ്.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt::{Error, Write};
    ///
    /// fn writer<W: Write>(f: &mut W, s: &str) -> Result<(), Error> {
    ///     f.write_fmt(format_args!("{}", s))
    /// }
    ///
    /// let mut buf = String::new();
    /// writer(&mut buf, "world").unwrap();
    /// assert_eq!(&buf, "world");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn write_fmt(mut self: &mut Self, args: Arguments<'_>) -> Result {
        write(&mut self, args)
    }
}

#[stable(feature = "fmt_write_blanket_impl", since = "1.4.0")]
impl<W: Write + ?Sized> Write for &mut W {
    fn write_str(&mut self, s: &str) -> Result {
        (**self).write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        (**self).write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        (**self).write_fmt(args)
    }
}

/// ഫോർമാറ്റിംഗിനായുള്ള കോൺഫിഗറേഷൻ.
///
/// ഫോർമാറ്റിംഗുമായി ബന്ധപ്പെട്ട വിവിധ ഓപ്ഷനുകൾ ഒരു `Formatter` പ്രതിനിധീകരിക്കുന്നു.
/// ഉപയോക്താക്കൾ നേരിട്ട് `ഫോർമാറ്റർ` നിർമ്മിക്കുന്നില്ല;ഒന്നിനെക്കുറിച്ചുള്ള മ്യൂട്ടബിൾ റഫറൻസ് [`Debug`], [`Display`] എന്നിവ പോലുള്ള എല്ലാ ഫോർമാറ്റിംഗിന്റെയും traits ന്റെ `fmt` രീതിയിലേക്ക് കൈമാറി.
///
///
/// ഒരു `Formatter`-മായി സംവദിക്കുന്നതിന്, ഫോർമാറ്റിംഗുമായി ബന്ധപ്പെട്ട വിവിധ ഓപ്ഷനുകൾ മാറ്റുന്നതിന് നിങ്ങൾ വിവിധ രീതികളെ വിളിക്കും.
/// ഉദാഹരണങ്ങൾക്ക്, ചുവടെയുള്ള `Formatter`-ൽ നിർവചിച്ചിരിക്കുന്ന രീതികളുടെ ഡോക്യുമെന്റേഷൻ കാണുക.
///
#[allow(missing_debug_implementations)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Formatter<'a> {
    flags: u32,
    fill: char,
    align: rt::v1::Alignment,
    width: Option<usize>,
    precision: Option<usize>,

    buf: &'a mut (dyn Write + 'a),
}

// NB.
// ആർ‌ഗ്യുമെൻറ് അടിസ്ഥാനപരമായി `exists T.(&T, fn(&T, &mut Formatter<'_>) -> Result` ന് തുല്യമായ ഒപ്റ്റിമൈസ് ചെയ്ത ഭാഗികമായി പ്രയോഗിച്ച ഫോർമാറ്റിംഗ് ഫംഗ്ഷനാണ്.

extern "C" {
    type Opaque;
}

/// എക്സ്പ്രിന്റ് ഫാമിലി ഫംഗ്ഷനുകൾ എടുക്കുന്ന ജനറിക് എക്സ് 00 എക്സിനെ ഈ സ്ട്രക്റ്റ് പ്രതിനിധീകരിക്കുന്നു.തന്നിരിക്കുന്ന മൂല്യം ഫോർമാറ്റ് ചെയ്യുന്നതിനുള്ള ഒരു ഫംഗ്ഷൻ ഇതിൽ അടങ്ങിയിരിക്കുന്നു.
/// കംപൈൽ സമയത്ത് ഫംഗ്ഷനും മൂല്യത്തിനും ശരിയായ തരങ്ങളുണ്ടെന്ന് ഉറപ്പാക്കുന്നു, തുടർന്ന് ആർഗ്യുമെന്റുകളെ ഒരു തരത്തിലേക്ക് കാനോനൈസ് ചെയ്യുന്നതിന് ഈ സ്ട്രക്റ്റ് ഉപയോഗിക്കുന്നു.
///
///
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
#[doc(hidden)]
pub struct ArgumentV1<'a> {
    value: &'a Opaque,
    formatter: fn(&Opaque, &mut Formatter<'_>) -> Result,
}

// ഫോർമാറ്റിംഗ് ഇൻഫ്രാസ്ട്രക്ചറിലെ indices/counts-മായി ബന്ധപ്പെട്ട ഫംഗ്ഷൻ പോയിന്ററിനായി ഇത് ഒരൊറ്റ സ്ഥിരത മൂല്യം ഉറപ്പ് നൽകുന്നു.
//
// നിലവിലുള്ള എൽ‌എൽ‌വി‌എം ഐ‌ആറിലേക്ക് താഴ്ത്തിക്കൊണ്ട് ഫംഗ്ഷനുകൾ എല്ലായ്പ്പോഴും പേരിടാത്ത_അഡിആർ ടാഗുചെയ്യപ്പെടുന്നതിനാൽ നിർവചിച്ചിരിക്കുന്ന ഒരു ഫംഗ്ഷൻ ശരിയായിരിക്കില്ല, അതിനാൽ അവയുടെ വിലാസം എൽ‌എൽ‌വി‌എമ്മിന് പ്രധാനമായി കണക്കാക്കില്ല, അതുപോലെ തന്നെ as_usize കാസ്റ്റ് തെറ്റായി കംപൈൽ ചെയ്യാമായിരുന്നു.
//
// പ്രായോഗികമായി, ഉപയോഗയോഗ്യമല്ലാത്ത ഡാറ്റയെ ഞങ്ങൾ ഒരിക്കലും as_usize എന്ന് വിളിക്കില്ല (ഫോർമാറ്റിംഗ് ആർഗ്യുമെന്റുകളുടെ സ്റ്റാറ്റിക് ജനറേഷന്റെ കാര്യമായി), അതിനാൽ ഇത് ഒരു അധിക പരിശോധന മാത്രമാണ്.
//
// `USIZE_MARKER`-ലെ ഫംഗ്ഷൻ പോയിന്ററിന് `&usize`-ന്റെ ആദ്യ ആർഗ്യുമെന്റായി കണക്കാക്കുന്ന ഫംഗ്ഷനുകൾക്ക് *മാത്രം* വിലാസമുണ്ടെന്ന് ഉറപ്പാക്കാൻ ഞങ്ങൾ പ്രാഥമികമായി ആഗ്രഹിക്കുന്നു.
// കടന്നുപോയ റഫറൻസിൽ നിന്ന് ഞങ്ങൾക്ക് ഒരു ഉപയോഗത്തെ സുരക്ഷിതമായി തയ്യാറാക്കാൻ കഴിയുമെന്നും ഈ വിലാസം ഉപയോഗയോഗ്യമല്ലാത്ത ഒരു ഫംഗ്ഷനിലേക്ക് വിരൽ ചൂണ്ടുന്നില്ലെന്നും ഇവിടെയുള്ള റീഡ്_വൊളാറ്റൈൽ ഉറപ്പാക്കുന്നു.
//
//
//
//
//
//
//
#[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
static USIZE_MARKER: fn(&usize, &mut Formatter<'_>) -> Result = |ptr, _| {
    // സുരക്ഷ: ptr ഒരു റഫറൻസാണ്
    let _v: usize = unsafe { crate::ptr::read_volatile(ptr) };
    loop {}
};

impl<'a> ArgumentV1<'a> {
    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new<'b, T>(x: &'b T, f: fn(&T, &mut Formatter<'_>) -> Result) -> ArgumentV1<'b> {
        // സുരക്ഷ: കാരണം `mem::transmute(x)` സുരക്ഷിതമാണ്
        //     1. `&'b T` `'b`-ൽ നിന്ന് ഉത്ഭവിച്ച ആജീവനാന്തം നിലനിർത്തുന്നു (അതിരുകളില്ലാത്ത ജീവിതകാലം ഉണ്ടാകാതിരിക്കാൻ)
        //     2.
        //     `&'b T` ഒപ്പം `&'b Opaque`-നും ഒരേ മെമ്മറി ലേ layout ട്ട് ഉണ്ട് (`T` `Sized` ആയിരിക്കുമ്പോൾ, ഇവിടെയുള്ളതുപോലെ) `fn(&T, &mut Formatter<'_>) -> Result`, `fn(&Opaque, &mut Formatter<'_>) -> Result` എന്നിവയ്ക്ക് ഒരേ ABI ഉള്ളതിനാൽ `mem::transmute(f)` സുരക്ഷിതമാണ് (`T` `Sized` ഉള്ളിടത്തോളം)
        //
        //
        //
        //
        unsafe { ArgumentV1 { formatter: mem::transmute(f), value: mem::transmute(x) } }
    }

    #[doc(hidden)]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn from_usize(x: &usize) -> ArgumentV1<'_> {
        ArgumentV1::new(x, USIZE_MARKER)
    }

    fn as_usize(&self) -> Option<usize> {
        if self.formatter as usize == USIZE_MARKER as usize {
            // സുരക്ഷിതം: എങ്കിൽ `formatter` ഫീൽഡ് USIZE_MARKER എന്നായി മാത്രമേ സജ്ജമാക്കിയിട്ടുള്ളൂ
            // മൂല്യം ഒരു ഉപയോഗമാണ്, അതിനാൽ ഇത് സുരക്ഷിതമാണ്
            Some(unsafe { *(self.value as *const _ as *const usize) })
        } else {
            None
        }
    }
}

// ഫോർമാറ്റ്_അർഗുകളുടെ v1 ഫോർമാറ്റിൽ ഫ്ലാഗുകൾ ലഭ്യമാണ്
#[derive(Copy, Clone)]
enum FlagV1 {
    SignPlus,
    SignMinus,
    Alternate,
    SignAwareZeroPad,
    DebugLowerHex,
    DebugUpperHex,
}

impl<'a> Arguments<'a> {
    /// ഫോർമാറ്റ്_അർഗ്സ്! () മാക്രോ ഉപയോഗിക്കുമ്പോൾ, ആർഗ്യുമെൻറ് ഘടന സൃഷ്ടിക്കുന്നതിന് ഈ ഫംഗ്ഷൻ ഉപയോഗിക്കുന്നു.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1(pieces: &'a [&'static str], args: &'a [ArgumentV1<'a>]) -> Arguments<'a> {
        Arguments { pieces, fmt: None, args }
    }

    /// നിലവാരമില്ലാത്ത ഫോർമാറ്റിംഗ് പാരാമീറ്ററുകൾ വ്യക്തമാക്കാൻ ഈ ഫംഗ്ഷൻ ഉപയോഗിക്കുന്നു.
    /// സാധുവായ ഒരു ആർഗ്യുമെൻറ് ഘടന നിർമ്മിക്കുന്നതിന് `pieces` അറേയ്ക്ക് `fmt` വരെ നീളമുണ്ടായിരിക്കണം.
    /// കൂടാതെ, `fmt`-നുള്ള `CountIsParam` അല്ലെങ്കിൽ `CountIsNextParam` ഉള്ള `Count`, `argumentusize` ഉപയോഗിച്ച് സൃഷ്ടിച്ച ഒരു ആർഗ്യുമെന്റിലേക്ക് പോയിന്റുചെയ്യേണ്ടതുണ്ട്.
    ///
    /// എന്നിരുന്നാലും, അങ്ങനെ ചെയ്യുന്നതിൽ പരാജയപ്പെടുന്നത് സുരക്ഷിതത്വത്തിന് കാരണമാകില്ല, പക്ഷേ അസാധുവാണ്.
    ///
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn new_v1_formatted(
        pieces: &'a [&'static str],
        args: &'a [ArgumentV1<'a>],
        fmt: &'a [rt::v1::Argument],
    ) -> Arguments<'a> {
        Arguments { pieces, fmt: Some(fmt), args }
    }

    /// ഫോർമാറ്റുചെയ്‌ത വാചകത്തിന്റെ ദൈർഘ്യം കണക്കാക്കുന്നു.
    ///
    /// `format!` ഉപയോഗിക്കുമ്പോൾ പ്രാരംഭ `String` ശേഷി സജ്ജീകരിക്കുന്നതിന് ഇത് ഉപയോഗിക്കാൻ ഉദ്ദേശിച്ചുള്ളതാണ്.
    /// Note: ഇത് താഴ്ന്നതോ മുകളിലെതോ അല്ല.
    #[doc(hidden)]
    #[inline]
    #[unstable(feature = "fmt_internals", reason = "internal to format_args!", issue = "none")]
    pub fn estimated_capacity(&self) -> usize {
        let pieces_length: usize = self.pieces.iter().map(|x| x.len()).sum();

        if self.args.is_empty() {
            pieces_length
        } else if self.pieces[0] == "" && pieces_length < 16 {
            // ഫോർമാറ്റ് സ്ട്രിംഗ് ഒരു ആർഗ്യുമെന്റിൽ ആരംഭിക്കുന്നുവെങ്കിൽ, കഷണങ്ങളുടെ ദൈർഘ്യം പ്രാധാന്യമർഹിക്കുന്നില്ലെങ്കിൽ ഒന്നും മുൻകൂട്ടി നിശ്ചയിക്കരുത്.
            //
            //
            0
        } else {
            // ചില ആർ‌ഗ്യുമെൻറുകൾ‌ഉണ്ട്, അതിനാൽ‌ഏതെങ്കിലും അധിക പുഷ് സ്‌ട്രിംഗ് വീണ്ടും അനുവദിക്കും.
            //
            // അത് ഒഴിവാക്കാൻ, ഞങ്ങൾ ഇവിടെ ശേഷി "pre-doubling" ആണ്.
            pieces_length.checked_mul(2).unwrap_or(0)
        }
    }
}

/// ഈ ഘടന ഒരു ഫോർമാറ്റ് സ്ട്രിംഗിന്റെ സുരക്ഷിതമായി മുൻ‌കൂട്ടി തയ്യാറാക്കിയ പതിപ്പിനെയും അതിന്റെ ആർഗ്യുമെന്റുകളെയും പ്രതിനിധീകരിക്കുന്നു.
/// ഇത് റൺ‌ടൈമിൽ‌ജനറേറ്റുചെയ്യാൻ‌കഴിയില്ല കാരണം ഇത് സുരക്ഷിതമായി ചെയ്യാൻ‌കഴിയില്ല, അതിനാൽ‌കൺ‌സ്‌ട്രക്റ്റർ‌മാരെ നൽ‌കുന്നില്ല, കൂടാതെ പരിഷ്‌ക്കരണം തടയുന്നതിന് ഫീൽ‌ഡുകൾ‌സ്വകാര്യവുമാണ്.
///
///
/// [`format_args!`] മാക്രോ ഈ ഘടനയുടെ ഒരു ഉദാഹരണം സുരക്ഷിതമായി സൃഷ്ടിക്കും.
/// മാക്രോ ഫോർമാറ്റ് സ്ട്രിംഗിനെ കംപൈൽ സമയത്ത് സാധൂകരിക്കുന്നു, അതിനാൽ [`write()`], [`format()`] ഫംഗ്ഷനുകളുടെ ഉപയോഗം സുരക്ഷിതമായി നടപ്പിലാക്കാൻ കഴിയും.
///
/// ചുവടെ കാണുന്നതുപോലെ `Debug`, `Display` സന്ദർഭങ്ങളിൽ [`format_args!`] നൽകുന്ന `Arguments<'a>` നിങ്ങൾക്ക് ഉപയോഗിക്കാം.
/// `Debug`, `Display` ഫോർമാറ്റ് ഒരേ കാര്യത്തിലാണെന്നും ഉദാഹരണം കാണിക്കുന്നു: `format_args!`-ലെ ഇന്റർപോളേറ്റഡ് ഫോർമാറ്റ് സ്ട്രിംഗ്.
///
/// ```rust
/// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
/// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
/// assert_eq!("1 foo 2", display);
/// assert_eq!(display, debug);
/// ```
///
/// [`format()`]: ../../std/fmt/fn.format.html
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone)]
pub struct Arguments<'a> {
    // അച്ചടിക്കാൻ സ്‌ട്രിംഗ് പീസുകൾ ഫോർമാറ്റുചെയ്യുക.
    pieces: &'a [&'static str],

    // പ്ലെയ്‌സ്‌ഹോൾഡർ സ്‌പെസിഫിക്കേഷനുകൾ, അല്ലെങ്കിൽ എല്ലാ സ്‌പെസിഫിക്കുകളും സ്ഥിരസ്ഥിതിയാണെങ്കിൽ `None` ("{}{}" പോലെ).
    fmt: Option<&'a [rt::v1::Argument]>,

    // സ്ട്രിംഗ് പീസുകളുപയോഗിച്ച് ഇന്റർ‌പോളേഷനായി ഡൈനാമിക് ആർ‌ഗ്യുമെൻറുകൾ‌.
    // (എല്ലാ ആർഗ്യുമെന്റിനും മുമ്പുള്ളത് ഒരു സ്ട്രിംഗ് പീസാണ്.)
    args: &'a [ArgumentV1<'a>],
}

impl<'a> Arguments<'a> {
    /// ഫോർമാറ്റുചെയ്യാൻ ആർഗ്യുമെന്റുകളില്ലെങ്കിൽ ഫോർമാറ്റുചെയ്‌ത സ്‌ട്രിംഗ് നേടുക.
    ///
    /// ഏറ്റവും നിസ്സാരമായ കേസിൽ വിഹിതം ഒഴിവാക്കാൻ ഇത് ഉപയോഗിക്കാം.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt::Arguments;
    ///
    /// fn write_str(_: &str) { /* ... */ }
    ///
    /// fn write_fmt(args: &Arguments) {
    ///     if let Some(s) = args.as_str() {
    ///         write_str(s)
    ///     } else {
    ///         write_str(&args.to_string());
    ///     }
    /// }
    /// ```
    ///
    /// ```rust
    /// assert_eq!(format_args!("hello").as_str(), Some("hello"));
    /// assert_eq!(format_args!("").as_str(), Some(""));
    /// assert_eq!(format_args!("{}", 1).as_str(), None);
    /// ```
    #[stable(feature = "fmt_as_str", since = "1.52.0")]
    #[inline]
    pub fn as_str(&self) -> Option<&'static str> {
        match (self.pieces, self.args) {
            ([], []) => Some(""),
            ([s], []) => Some(s),
            _ => None,
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        Display::fmt(self, fmt)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Arguments<'_> {
    fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
        write(fmt.buf, *self)
    }
}

/// `?` formatting.
///
/// `Debug` പ്രോഗ്രാമർ അഭിമുഖീകരിക്കുന്ന, ഡീബഗ്ഗിംഗ് സന്ദർഭത്തിൽ output ട്ട്‌പുട്ട് ഫോർമാറ്റ് ചെയ്യണം.
///
/// പൊതുവായി പറഞ്ഞാൽ, നിങ്ങൾ `derive` ഒരു `Debug` നടപ്പിലാക്കണം.
///
/// ഇതര ഫോർമാറ്റ് സ്‌പെസിഫയർ `#?` ഉപയോഗിച്ച് ഉപയോഗിക്കുമ്പോൾ, output ട്ട്‌പുട്ട് മനോഹരമായി അച്ചടിക്കും.
///
/// ഫോർമാറ്ററുകളെക്കുറിച്ചുള്ള കൂടുതൽ വിവരങ്ങൾക്ക്, [the module-level documentation][module] കാണുക.
///
/// [module]: ../../std/fmt/index.html
///
/// എല്ലാ ഫീൽഡുകളും `Debug` നടപ്പിലാക്കുകയാണെങ്കിൽ ഈ trait `#[derive]` ഉപയോഗിച്ച് ഉപയോഗിക്കാൻ കഴിയും.
/// സ്ട്രക്റ്റുകൾക്കായി `ഡെറിവ്` ചെയ്യുമ്പോൾ, അത് `struct`, തുടർന്ന് `{`, തുടർന്ന് ഓരോ ഫീൽഡിന്റെയും പേരിന്റെ കോമയാൽ വേർതിരിച്ച ലിസ്റ്റ്, `Debug` മൂല്യം, തുടർന്ന് `}` എന്നിവ ഉപയോഗിക്കും.
/// `Enum`-കൾക്കായി, ഇത് വേരിയന്റിന്റെ പേരും ബാധകമെങ്കിൽ `(`, തുടർന്ന് ഫീൽഡുകളുടെ `Debug` മൂല്യങ്ങളും `)` ഉം ഉപയോഗിക്കും.
///
/// # Stability
///
/// ഉത്ഭവിച്ച `Debug` ഫോർമാറ്റുകൾ സ്ഥിരതയുള്ളതല്ല, അതിനാൽ future Rust പതിപ്പുകളിൽ മാറ്റം വരാം.
/// കൂടാതെ, സ്റ്റാൻ‌ഡേർഡ് ലൈബ്രറി (`libstd`, `libcore`, `liballoc`, മുതലായവ) നൽ‌കുന്ന തരങ്ങളുടെ `Debug` നടപ്പാക്കലുകൾ‌സുസ്ഥിരമല്ല, മാത്രമല്ല future Rust പതിപ്പുകളിലും മാറാം.
///
///
/// # Examples
///
/// നടപ്പിലാക്കൽ:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// സ്വമേധയാ നടപ്പിലാക്കുന്നു:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Debug for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         f.debug_struct("Point")
///          .field("x", &self.x)
///          .field("y", &self.y)
///          .finish()
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:?}", origin), "The origin is: Point { x: 0, y: 0 }");
/// ```
///
/// [`debug_struct`] പോലുള്ള സ്വമേധയാലുള്ള നടപ്പാക്കലുകൾക്ക് നിങ്ങളെ സഹായിക്കുന്നതിന് [`Formatter`] ഘടനയിൽ നിരവധി സഹായ രീതികളുണ്ട്.
///
/// `Debug` `derive` അല്ലെങ്കിൽ [`Formatter`]-ലെ ഡീബഗ് ബിൽഡർ API ഉപയോഗിച്ചുള്ള നടപ്പാക്കലുകൾ ഇതര ഫ്ലാഗ് ഉപയോഗിച്ച് പ്രെറ്റി-പ്രിന്റിംഗിനെ പിന്തുണയ്ക്കുന്നു: `{:#?}`.
///
/// [`debug_struct`]: Formatter::debug_struct
///
/// `#?` ഉപയോഗിച്ച് പ്രെറ്റി പ്രിന്റിംഗ്:
///
/// ```
/// #[derive(Debug)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {:#?}", origin),
/// "The origin is: Point {
///     x: 0,
///     y: 0,
/// }");
/// ```
///
///
///
///
///

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        crate_local,
        label = "`{Self}` cannot be formatted using `{{:?}}`",
        note = "add `#[derive(Debug)]` or manually implement `{Debug}`"
    ),
    message = "`{Self}` doesn't implement `{Debug}`",
    label = "`{Self}` cannot be formatted using `{{:?}}` because it doesn't implement `{Debug}`"
)]
#[doc(alias = "{:?}")]
#[rustc_diagnostic_item = "debug_trait"]
pub trait Debug {
    /// തന്നിരിക്കുന്ന ഫോർമാറ്റർ ഉപയോഗിച്ച് മൂല്യം ഫോർമാറ്റുചെയ്യുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Debug for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         f.debug_tuple("")
    ///          .field(&self.longitude)
    ///          .field(&self.latitude)
    ///          .finish()
    ///     }
    /// }
    ///
    /// let position = Position { longitude: 1.987, latitude: 2.983 };
    /// assert_eq!(format!("{:?}", position), "(1.987, 2.983)");
    ///
    /// assert_eq!(format!("{:#?}", position), "(
    ///     1.987,
    ///     2.983,
    /// )");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

// trait `Debug` ഇല്ലാതെ prelude-ൽ നിന്ന് മാക്രോ `Debug` വീണ്ടും കയറ്റുമതി ചെയ്യുന്നതിന് പ്രത്യേക മൊഡ്യൂൾ.
pub(crate) mod macros {
    /// trait `Debug`-ന്റെ ഒരു impl സൃഷ്ടിക്കുന്ന മാക്രോ ഡെറിവ് ചെയ്യുക.
    #[rustc_builtin_macro]
    #[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
    #[allow_internal_unstable(core_intrinsics)]
    pub macro Debug($item:item) {
        /* compiler built-in */
    }
}
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[doc(inline)]
pub use macros::Debug;

/// ശൂന്യമായ ഫോർമാറ്റിനായി trait ഫോർമാറ്റ് ചെയ്യുക, `{}`.
///
/// `Display` [`Debug`] ന് സമാനമാണ്, പക്ഷേ `Display` ഉപയോക്താവ് അഭിമുഖീകരിക്കുന്ന output ട്ട്‌പുട്ടിനുള്ളതാണ്, അതിനാൽ ഇത് നേടാനാവില്ല.
///
///
/// ഫോർമാറ്ററുകളെക്കുറിച്ചുള്ള കൂടുതൽ വിവരങ്ങൾക്ക്, [the module-level documentation][module] കാണുക.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// ഒരു തരത്തിൽ `Display` നടപ്പിലാക്കുന്നു:
///
/// ```
/// use std::fmt;
///
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl fmt::Display for Point {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         write!(f, "({}, {})", self.x, self.y)
///     }
/// }
///
/// let origin = Point { x: 0, y: 0 };
///
/// assert_eq!(format!("The origin is: {}", origin), "The origin is: (0, 0)");
/// ```
#[rustc_on_unimplemented(
    on(
        _Self = "std::path::Path",
        label = "`{Self}` cannot be formatted with the default formatter; call `.display()` on it",
        note = "call `.display()` or `.to_string_lossy()` to safely print paths, \
                as they may contain non-Unicode data"
    ),
    message = "`{Self}` doesn't implement `{Display}`",
    label = "`{Self}` cannot be formatted with the default formatter",
    note = "in format strings you may be able to use `{{:?}}` (or {{:#?}} for pretty-print) instead"
)]
#[doc(alias = "{}")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Display {
    /// തന്നിരിക്കുന്ന ഫോർമാറ്റർ ഉപയോഗിച്ച് മൂല്യം ഫോർമാറ്റുചെയ്യുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Position {
    ///     longitude: f32,
    ///     latitude: f32,
    /// }
    ///
    /// impl fmt::Display for Position {
    ///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
    ///         write!(f, "({}, {})", self.longitude, self.latitude)
    ///     }
    /// }
    ///
    /// assert_eq!("(1.987, 2.983)",
    ///            format!("{}", Position { longitude: 1.987, latitude: 2.983, }));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `o` formatting.
///
/// `Octal` trait അതിന്റെ output ട്ട്‌പുട്ടിനെ base-8-ൽ ഒരു സംഖ്യയായി ഫോർമാറ്റ് ചെയ്യണം.
///
/// പ്രാകൃത ഒപ്പിട്ട സംഖ്യകൾക്കായി (`i8` മുതൽ `i128`, `isize`), നെഗറ്റീവ് മൂല്യങ്ങൾ രണ്ടിന്റെയും പൂരക പ്രാതിനിധ്യമായി ഫോർമാറ്റുചെയ്യുന്നു.
///
///
/// ഇതര ഫ്ലാഗ്, `#`, X ട്ട്‌പുട്ടിന് മുന്നിൽ ഒരു `0o` ചേർക്കുന്നു.
///
/// ഫോർമാറ്ററുകളെക്കുറിച്ചുള്ള കൂടുതൽ വിവരങ്ങൾക്ക്, [the module-level documentation][module] കാണുക.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` ഉള്ള അടിസ്ഥാന ഉപയോഗം:
///
/// ```
/// let x = 42; // 42 ഒക്ടോബറിലെ '52' ആണ്
///
/// assert_eq!(format!("{:o}", x), "52");
/// assert_eq!(format!("{:#o}", x), "0o52");
///
/// assert_eq!(format!("{:o}", -16), "37777777760");
/// ```
///
/// ഒരു തരത്തിൽ `Octal` നടപ്പിലാക്കുന്നു:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Octal for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Octal::fmt(&val, f) // i32 നടപ്പിലാക്കുന്നതിന് നിയുക്തമാക്കുക
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as octal is: {:o}", l), "l as octal is: 11");
///
/// assert_eq!(format!("l as octal is: {:#06o}", l), "l as octal is: 0o0011");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Octal {
    /// തന്നിരിക്കുന്ന ഫോർമാറ്റർ ഉപയോഗിച്ച് മൂല്യം ഫോർമാറ്റുചെയ്യുന്നു.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `b` formatting.
///
/// `Binary` trait അതിന്റെ output ട്ട്‌പുട്ടിനെ ബൈനറിയിലെ ഒരു സംഖ്യയായി ഫോർമാറ്റ് ചെയ്യണം.
///
/// പ്രാകൃത ഒപ്പിട്ട സംഖ്യകൾക്കായി ([`i8`] മുതൽ [`i128`], [`isize`]), നെഗറ്റീവ് മൂല്യങ്ങൾ രണ്ടിന്റെയും പൂരക പ്രാതിനിധ്യമായി ഫോർമാറ്റുചെയ്യുന്നു.
///
///
/// ഇതര ഫ്ലാഗ്, `#`, X ട്ട്‌പുട്ടിന് മുന്നിൽ ഒരു `0b` ചേർക്കുന്നു.
///
/// ഫോർമാറ്ററുകളെക്കുറിച്ചുള്ള കൂടുതൽ വിവരങ്ങൾക്ക്, [the module-level documentation][module] കാണുക.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// [`i32`] ഉള്ള അടിസ്ഥാന ഉപയോഗം:
///
/// ```
/// let x = 42; // 42 ബൈനറിയിൽ '101010' ആണ്
///
/// assert_eq!(format!("{:b}", x), "101010");
/// assert_eq!(format!("{:#b}", x), "0b101010");
///
/// assert_eq!(format!("{:b}", -16), "11111111111111111111111111110000");
/// ```
///
/// ഒരു തരത്തിൽ `Binary` നടപ്പിലാക്കുന്നു:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Binary for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::Binary::fmt(&val, f) // i32 നടപ്പിലാക്കുന്നതിന് നിയുക്തമാക്കുക
///     }
/// }
///
/// let l = Length(107);
///
/// assert_eq!(format!("l as binary is: {:b}", l), "l as binary is: 1101011");
///
/// assert_eq!(
///     format!("l as binary is: {:#032b}", l),
///     "l as binary is: 0b000000000000000000000001101011"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Binary {
    /// തന്നിരിക്കുന്ന ഫോർമാറ്റർ ഉപയോഗിച്ച് മൂല്യം ഫോർമാറ്റുചെയ്യുന്നു.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `x` formatting.
///
/// `LowerHex` trait അതിന്റെ output ട്ട്‌പുട്ടിനെ ഹെക്‌സാഡെസിമലിലെ ഒരു സംഖ്യയായി ഫോർമാറ്റ് ചെയ്യണം, `a` മുതൽ `f` വരെ ചെറിയ അക്ഷരത്തിൽ.
///
/// പ്രാകൃത ഒപ്പിട്ട സംഖ്യകൾക്കായി (`i8` മുതൽ `i128`, `isize`), നെഗറ്റീവ് മൂല്യങ്ങൾ രണ്ടിന്റെയും പൂരക പ്രാതിനിധ്യമായി ഫോർമാറ്റുചെയ്യുന്നു.
///
///
/// ഇതര ഫ്ലാഗ്, `#`, X ട്ട്‌പുട്ടിന് മുന്നിൽ ഒരു `0x` ചേർക്കുന്നു.
///
/// ഫോർമാറ്ററുകളെക്കുറിച്ചുള്ള കൂടുതൽ വിവരങ്ങൾക്ക്, [the module-level documentation][module] കാണുക.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` ഉള്ള അടിസ്ഥാന ഉപയോഗം:
///
/// ```
/// let x = 42; // 42 ഹെക്സിൽ '2a' ആണ്
///
/// assert_eq!(format!("{:x}", x), "2a");
/// assert_eq!(format!("{:#x}", x), "0x2a");
///
/// assert_eq!(format!("{:x}", -16), "fffffff0");
/// ```
///
/// ഒരു തരത്തിൽ `LowerHex` നടപ്പിലാക്കുന്നു:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::LowerHex::fmt(&val, f) // i32 നടപ്പിലാക്കുന്നതിന് നിയുക്തമാക്കുക
///     }
/// }
///
/// let l = Length(9);
///
/// assert_eq!(format!("l as hex is: {:x}", l), "l as hex is: 9");
///
/// assert_eq!(format!("l as hex is: {:#010x}", l), "l as hex is: 0x00000009");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerHex {
    /// തന്നിരിക്കുന്ന ഫോർമാറ്റർ ഉപയോഗിച്ച് മൂല്യം ഫോർമാറ്റുചെയ്യുന്നു.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `X` formatting.
///
/// `UpperHex` trait അതിന്റെ output ട്ട്‌പുട്ടിനെ ഹെക്‌സാഡെസിമലിലെ ഒരു സംഖ്യയായി ഫോർമാറ്റ് ചെയ്യണം, `A` മുതൽ `F` വരെ വലിയ കേസിൽ.
///
/// പ്രാകൃത ഒപ്പിട്ട സംഖ്യകൾക്കായി (`i8` മുതൽ `i128`, `isize`), നെഗറ്റീവ് മൂല്യങ്ങൾ രണ്ടിന്റെയും പൂരക പ്രാതിനിധ്യമായി ഫോർമാറ്റുചെയ്യുന്നു.
///
///
/// ഇതര ഫ്ലാഗ്, `#`, X ട്ട്‌പുട്ടിന് മുന്നിൽ ഒരു `0x` ചേർക്കുന്നു.
///
/// ഫോർമാറ്ററുകളെക്കുറിച്ചുള്ള കൂടുതൽ വിവരങ്ങൾക്ക്, [the module-level documentation][module] കാണുക.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `i32` ഉള്ള അടിസ്ഥാന ഉപയോഗം:
///
/// ```
/// let x = 42; // 42 ഹെക്സിൽ '2A' ആണ്
///
/// assert_eq!(format!("{:X}", x), "2A");
/// assert_eq!(format!("{:#X}", x), "0x2A");
///
/// assert_eq!(format!("{:X}", -16), "FFFFFFF0");
/// ```
///
/// ഒരു തരത്തിൽ `UpperHex` നടപ്പിലാക്കുന്നു:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperHex for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = self.0;
///
///         fmt::UpperHex::fmt(&val, f) // i32 നടപ്പിലാക്കുന്നതിന് നിയുക്തമാക്കുക
///     }
/// }
///
/// let l = Length(i32::MAX);
///
/// assert_eq!(format!("l as hex is: {:X}", l), "l as hex is: 7FFFFFFF");
///
/// assert_eq!(format!("l as hex is: {:#010X}", l), "l as hex is: 0x7FFFFFFF");
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperHex {
    /// തന്നിരിക്കുന്ന ഫോർമാറ്റർ ഉപയോഗിച്ച് മൂല്യം ഫോർമാറ്റുചെയ്യുന്നു.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `p` formatting.
///
/// `Pointer` trait അതിന്റെ output ട്ട്‌പുട്ട് ഒരു മെമ്മറി ലൊക്കേഷനായി ഫോർമാറ്റ് ചെയ്യണം.
/// ഇത് സാധാരണയായി ഹെക്സാഡെസിമൽ ആയി അവതരിപ്പിക്കുന്നു.
///
/// ഫോർമാറ്ററുകളെക്കുറിച്ചുള്ള കൂടുതൽ വിവരങ്ങൾക്ക്, [the module-level documentation][module] കാണുക.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `&i32` ഉള്ള അടിസ്ഥാന ഉപയോഗം:
///
/// ```
/// let x = &42;
///
/// let address = format!("{:p}", x); // ഇത് '0x7f06092ac6d0' പോലുള്ള ഒന്ന് ഉൽ‌പാദിപ്പിക്കുന്നു
/// ```
///
/// ഒരു തരത്തിൽ `Pointer` നടപ്പിലാക്കുന്നു:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::Pointer for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         // ഒരു `*const T`-ലേക്ക് പരിവർത്തനം ചെയ്യാൻ `as` ഉപയോഗിക്കുക, അത് നമുക്ക് ഉപയോഗിക്കാൻ കഴിയുന്ന പോയിന്റർ നടപ്പിലാക്കുന്നു
///
///         let ptr = self as *const Self;
///         fmt::Pointer::fmt(&ptr, f)
///     }
/// }
///
/// let l = Length(42);
///
/// println!("l is in memory here: {:p}", l);
///
/// let l_ptr = format!("{:018p}", l);
/// assert_eq!(l_ptr.len(), 18);
/// assert_eq!(&l_ptr[..2], "0x");
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "pointer_trait"]
pub trait Pointer {
    /// തന്നിരിക്കുന്ന ഫോർമാറ്റർ ഉപയോഗിച്ച് മൂല്യം ഫോർമാറ്റുചെയ്യുന്നു.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "pointer_trait_fmt"]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `e` formatting.
///
/// `LowerExp` trait അതിന്റെ output ട്ട്‌പുട്ട് ശാസ്ത്രീയ നൊട്ടേഷനിൽ ലോവർ-കേസ് `e` ഉപയോഗിച്ച് ഫോർമാറ്റ് ചെയ്യണം.
///
/// ഫോർമാറ്ററുകളെക്കുറിച്ചുള്ള കൂടുതൽ വിവരങ്ങൾക്ക്, [the module-level documentation][module] കാണുക.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `f64` ഉള്ള അടിസ്ഥാന ഉപയോഗം:
///
/// ```
/// let x = 42.0; // 42.0 ശാസ്ത്ര നൊട്ടേഷനിൽ '4.2e1' ആണ്
///
/// assert_eq!(format!("{:e}", x), "4.2e1");
/// ```
///
/// ഒരു തരത്തിൽ `LowerExp` നടപ്പിലാക്കുന്നു:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::LowerExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::LowerExp::fmt(&val, f) // f64 നടപ്പിലാക്കുന്നതിന് നിയുക്തമാക്കുക
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:e}", l),
///     "l in scientific notation is: 1e2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05e}", l),
///     "l in scientific notation is: 001e2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait LowerExp {
    /// തന്നിരിക്കുന്ന ഫോർമാറ്റർ ഉപയോഗിച്ച് മൂല്യം ഫോർമാറ്റുചെയ്യുന്നു.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `E` formatting.
///
/// `UpperExp` trait അതിന്റെ output ട്ട്‌പുട്ട് ശാസ്ത്രീയ നൊട്ടേഷനിൽ ഒരു വലിയ കേസ് `E` ഉപയോഗിച്ച് ഫോർമാറ്റ് ചെയ്യണം.
///
/// ഫോർമാറ്ററുകളെക്കുറിച്ചുള്ള കൂടുതൽ വിവരങ്ങൾക്ക്, [the module-level documentation][module] കാണുക.
///
/// [module]: ../../std/fmt/index.html
///
/// # Examples
///
/// `f64` ഉള്ള അടിസ്ഥാന ഉപയോഗം:
///
/// ```
/// let x = 42.0; // 42.0 ശാസ്ത്ര നൊട്ടേഷനിൽ '4.2E1' ആണ്
///
/// assert_eq!(format!("{:E}", x), "4.2E1");
/// ```
///
/// ഒരു തരത്തിൽ `UpperExp` നടപ്പിലാക്കുന്നു:
///
/// ```
/// use std::fmt;
///
/// struct Length(i32);
///
/// impl fmt::UpperExp for Length {
///     fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
///         let val = f64::from(self.0);
///         fmt::UpperExp::fmt(&val, f) // f64 നടപ്പിലാക്കുന്നതിന് നിയുക്തമാക്കുക
///     }
/// }
///
/// let l = Length(100);
///
/// assert_eq!(
///     format!("l in scientific notation is: {:E}", l),
///     "l in scientific notation is: 1E2"
/// );
///
/// assert_eq!(
///     format!("l in scientific notation is: {:05E}", l),
///     "l in scientific notation is: 001E2"
/// );
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait UpperExp {
    /// തന്നിരിക്കുന്ന ഫോർമാറ്റർ ഉപയോഗിച്ച് മൂല്യം ഫോർമാറ്റുചെയ്യുന്നു.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result;
}

/// `write` ഫംഗ്ഷൻ ഒരു output ട്ട്‌പുട്ട് സ്ട്രീമും `format_args!` മാക്രോ ഉപയോഗിച്ച് പ്രീ കംപൈൽ ചെയ്യാൻ കഴിയുന്ന ഒരു `Arguments` സ്ട്രക്റ്റും എടുക്കുന്നു.
///
///
/// നൽകിയിരിക്കുന്ന output ട്ട്‌പുട്ട് സ്ട്രീമിലേക്ക് നിർദ്ദിഷ്ട ഫോർമാറ്റ് സ്‌ട്രിംഗ് അനുസരിച്ച് ആർഗ്യുമെന്റുകൾ ഫോർമാറ്റുചെയ്യും.
///
/// # Examples
///
/// അടിസ്ഥാന ഉപയോഗം:
///
/// ```
/// use std::fmt;
///
/// let mut output = String::new();
/// fmt::write(&mut output, format_args!("Hello {}!", "world"))
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///
/// [`write!`] ഉപയോഗിക്കുന്നത് അഭികാമ്യമാണെന്ന് ദയവായി ശ്രദ്ധിക്കുക.ഉദാഹരണം:
///
/// ```
/// use std::fmt::Write;
///
/// let mut output = String::new();
/// write!(&mut output, "Hello {}!", "world")
///     .expect("Error occurred while trying to write in String");
/// assert_eq!(output, "Hello world!");
/// ```
///  [`write!`]: crate::write!
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn write(output: &mut dyn Write, args: Arguments<'_>) -> Result {
    let mut formatter = Formatter {
        flags: 0,
        width: None,
        precision: None,
        buf: output,
        align: rt::v1::Alignment::Unknown,
        fill: ' ',
    };

    let mut idx = 0;

    match args.fmt {
        None => {
            // എല്ലാ ആർ‌ഗ്യുമെൻറുകൾ‌ക്കും സ്ഥിരസ്ഥിതി ഫോർ‌മാറ്റിംഗ് പാരാമീറ്ററുകൾ‌ഉപയോഗിക്കാൻ‌കഴിയും.
            for (arg, piece) in args.args.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                (arg.formatter)(arg.value, &mut formatter)?;
                idx += 1;
            }
        }
        Some(fmt) => {
            // ഓരോ സ്‌പെക്കിനും ഒരു സ്‌ട്രിംഗ് പെയ്‌സിന് മുമ്പുള്ള അനുബന്ധ ആർഗ്യുമെൻറ് ഉണ്ട്.
            //
            for (arg, piece) in fmt.iter().zip(args.pieces.iter()) {
                formatter.buf.write_str(*piece)?;
                // സുരക്ഷ: ആർഗും എക്സ് 00 എക്സും ഒരേ ആർഗ്യുമെന്റുകളിൽ നിന്നാണ് വരുന്നത്,
                // ഇത് സൂചികകൾ എല്ലായ്പ്പോഴും പരിധിക്കുള്ളിലാണെന്ന് ഉറപ്പുനൽകുന്നു.
                unsafe { run(&mut formatter, arg, &args.args) }?;
                idx += 1;
            }
        }
    }

    // ഒരു സ്‌ട്രിംഗ് പീസ് മാത്രമേ ശേഷിക്കുന്നുള്ളൂ.
    if let Some(piece) = args.pieces.get(idx) {
        formatter.buf.write_str(*piece)?;
    }

    Ok(())
}

unsafe fn run(fmt: &mut Formatter<'_>, arg: &rt::v1::Argument, args: &[ArgumentV1<'_>]) -> Result {
    fmt.fill = arg.format.fill;
    fmt.align = arg.format.align;
    fmt.flags = arg.format.flags;
    // സുരക്ഷ: ആർഗും ആർഗുകളും ഒരേ വാദങ്ങളിൽ നിന്നാണ് വരുന്നത്,
    // ഇത് സൂചികകൾ എല്ലായ്പ്പോഴും പരിധിക്കുള്ളിലാണെന്ന് ഉറപ്പുനൽകുന്നു.
    unsafe {
        fmt.width = getcount(args, &arg.format.width);
        fmt.precision = getcount(args, &arg.format.precision);
    }

    // ശരിയായ വാദം എക്‌സ്‌ട്രാക്റ്റുചെയ്യുക
    debug_assert!(arg.position < args.len());
    // സുരക്ഷ: ആർഗും ആർഗുകളും ഒരേ വാദങ്ങളിൽ നിന്നാണ് വരുന്നത്,
    // അതിന്റെ സൂചിക എല്ലായ്പ്പോഴും പരിധിക്കുള്ളിലാണെന്ന് ഇത് ഉറപ്പുനൽകുന്നു.
    let value = unsafe { args.get_unchecked(arg.position) };

    // പിന്നീട് കുറച്ച് പ്രിന്റിംഗ് നടത്തുക
    (value.formatter)(value.value, fmt)
}

unsafe fn getcount(args: &[ArgumentV1<'_>], cnt: &rt::v1::Count) -> Option<usize> {
    match *cnt {
        rt::v1::Count::Is(n) => Some(n),
        rt::v1::Count::Implied => None,
        rt::v1::Count::Param(i) => {
            debug_assert!(i < args.len());
            // സുരക്ഷ: cnt ഉം args ഉം ഒരേ വാദങ്ങളിൽ നിന്നാണ്,
            // ഈ സൂചിക എല്ലായ്പ്പോഴും പരിധിക്കുള്ളിലാണെന്ന് ഇത് ഉറപ്പുനൽകുന്നു.
            unsafe { args.get_unchecked(i).as_usize() }
        }
    }
}

/// എന്തെങ്കിലും അവസാനിച്ചതിന് ശേഷം പാഡിംഗ്.`Formatter::padding` നൽകി.
#[must_use = "don't forget to write the post padding"]
struct PostPadding {
    fill: char,
    padding: usize,
}

impl PostPadding {
    fn new(fill: char, padding: usize) -> PostPadding {
        PostPadding { fill, padding }
    }

    /// ഈ പോസ്റ്റ് പാഡിംഗ് എഴുതുക.
    fn write(self, buf: &mut dyn Write) -> Result {
        for _ in 0..self.padding {
            buf.write_char(self.fill)?;
        }
        Ok(())
    }
}

impl<'a> Formatter<'a> {
    fn wrap_buf<'b, 'c, F>(&'b mut self, wrap: F) -> Formatter<'c>
    where
        'b: 'c,
        F: FnOnce(&'b mut (dyn Write + 'b)) -> &'c mut (dyn Write + 'c),
    {
        Formatter {
            // ഇത് മാറ്റാൻ ഞങ്ങൾ ആഗ്രഹിക്കുന്നു
            buf: wrap(self.buf),

            // ഇവ സംരക്ഷിക്കുക
            flags: self.flags,
            fill: self.fill,
            align: self.align,
            width: self.width,
            precision: self.precision,
        }
    }

    // എല്ലാ ഫോർമാറ്റിംഗ് traits-നും ഉപയോഗിക്കാവുന്ന ഫോർമാറ്റിംഗ് ആർഗ്യുമെന്റുകൾ പാഡിംഗ് ചെയ്യുന്നതിനും പ്രോസസ്സ് ചെയ്യുന്നതിനും ഉപയോഗിക്കുന്ന സഹായ രീതികൾ.
    //

    /// ഇതിനകം ഒരു സ്ട്രിംഗിലേക്ക് പുറപ്പെടുവിച്ച ഒരു സംഖ്യയ്ക്കായി ശരിയായ പാഡിംഗ് നടത്തുന്നു.
    /// സ്ട്രിംഗിൽ *പൂർണ്ണസംഖ്യയ്ക്കുള്ള അടയാളം* അടങ്ങിയിരിക്കരുത്, അത് ഈ രീതി ഉപയോഗിച്ച് ചേർക്കും.
    ///
    /// # Arguments
    ///
    /// * is_nonnegative, യഥാർത്ഥ സംഖ്യ പോസിറ്റീവ് അല്ലെങ്കിൽ പൂജ്യമായിരുന്നോ എന്ന്.
    /// * പ്രിഫിക്‌സ്, '#' പ്രതീകം (Alternate) നൽകിയിട്ടുണ്ടെങ്കിൽ, നമ്പറിന് മുന്നിൽ വയ്ക്കാനുള്ള പ്രിഫിക്‌സ് ഇതാണ്.
    ///
    /// * buf, നമ്പർ ഫോർമാറ്റ് ചെയ്ത ബൈറ്റ് അറേ
    ///
    /// ഈ ഫംഗ്ഷൻ ശരിയായി നൽകിയ ഫ്ലാഗുകൾക്കും ഏറ്റവും കുറഞ്ഞ വീതിക്കും കാരണമാകും.
    /// ഇത് കൃത്യത കണക്കിലെടുക്കില്ല.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo { nb: i32 }
    ///
    /// impl Foo {
    ///     fn new(nb: i32) -> Foo {
    ///         Foo {
    ///             nb,
    ///         }
    ///     }
    /// }
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         // നമ്പർ .ട്ട്‌പുട്ടിൽ നിന്ന് ഞങ്ങൾ "-" നീക്കംചെയ്യേണ്ടതുണ്ട്.
    ///         let tmp = self.nb.abs().to_string();
    ///
    ///         formatter.pad_integral(self.nb > 0, "Foo ", &tmp)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo::new(2)), "2");
    /// assert_eq!(&format!("{}", Foo::new(-1)), "-1");
    /// assert_eq!(&format!("{:#}", Foo::new(-1)), "-Foo 1");
    /// assert_eq!(&format!("{:0>#8}", Foo::new(-1)), "00-Foo 1");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad_integral(&mut self, is_nonnegative: bool, prefix: &str, buf: &str) -> Result {
        let mut width = buf.len();

        let mut sign = None;
        if !is_nonnegative {
            sign = Some('-');
            width += 1;
        } else if self.sign_plus() {
            sign = Some('+');
            width += 1;
        }

        let prefix = if self.alternate() {
            width += prefix.chars().count();
            Some(prefix)
        } else {
            None
        };

        // ചിഹ്നം നിലവിലുണ്ടെങ്കിൽ അത് എഴുതുന്നു, തുടർന്ന് അത് ആവശ്യപ്പെട്ടാൽ പ്രിഫിക്‌സ് എഴുതുന്നു
        #[inline(never)]
        fn write_prefix(f: &mut Formatter<'_>, sign: Option<char>, prefix: Option<&str>) -> Result {
            if let Some(c) = sign {
                f.buf.write_char(c)?;
            }
            if let Some(prefix) = prefix { f.buf.write_str(prefix) } else { Ok(()) }
        }

        // ഈ ഘട്ടത്തിൽ ഒരു `min-width` പാരാമീറ്ററാണ് `width` ഫീൽഡ്.
        match self.width {
            // കുറഞ്ഞ ദൈർ‌ഘ്യ ആവശ്യകതകളൊന്നുമില്ലെങ്കിൽ‌ഞങ്ങൾ‌ക്ക് ബൈറ്റുകൾ‌എഴുതാൻ‌കഴിയും.
            //
            None => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // ഞങ്ങൾ ഏറ്റവും കുറഞ്ഞ വീതിയിലാണോയെന്ന് പരിശോധിക്കുക, അങ്ങനെയാണെങ്കിൽ നമുക്ക് ബൈറ്റുകളും എഴുതാം.
            //
            Some(min) if width >= min => {
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)
            }
            // പൂരിപ്പിക്കൽ പ്രതീകം പൂജ്യമാണെങ്കിൽ ചിഹ്നവും പ്രിഫിക്‌സും പാഡിംഗിന് മുമ്പായി പോകുന്നു
            //
            Some(min) if self.sign_aware_zero_pad() => {
                let old_fill = crate::mem::replace(&mut self.fill, '0');
                let old_align = crate::mem::replace(&mut self.align, rt::v1::Alignment::Right);
                write_prefix(self, sign, prefix)?;
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)?;
                self.fill = old_fill;
                self.align = old_align;
                Ok(())
            }
            // അല്ലെങ്കിൽ, ചിഹ്നവും പ്രിഫിക്‌സും പാഡിംഗിന് ശേഷം പോകുന്നു
            Some(min) => {
                let post_padding = self.padding(min - width, rt::v1::Alignment::Right)?;
                write_prefix(self, sign, prefix)?;
                self.buf.write_str(buf)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// ഈ ഫംഗ്ഷൻ ഒരു സ്ട്രിംഗ് സ്ലൈസ് എടുത്ത് വ്യക്തമാക്കിയ പ്രസക്തമായ ഫോർമാറ്റിംഗ് ഫ്ലാഗുകൾ പ്രയോഗിച്ച ശേഷം ആന്തരിക ബഫറിലേക്ക് പുറപ്പെടുവിക്കുന്നു.
    /// ജനറിക് സ്ട്രിംഗുകൾക്കായി അംഗീകരിച്ച ഫ്ലാഗുകൾ ഇവയാണ്:
    ///
    /// * വീതി, പുറത്തുവിടേണ്ടതിന്റെ ഏറ്റവും കുറഞ്ഞ വീതി
    /// * fill/align - നൽകിയിട്ടുള്ള സ്ട്രിംഗ് പാഡ് ചെയ്യണമെങ്കിൽ എന്ത് പുറപ്പെടുവിക്കണം, എവിടെ നിന്ന് പുറന്തള്ളണം
    /// * കൃത്യത, പുറത്തുവിടാനുള്ള പരമാവധി ദൈർഘ്യം, ഈ നീളത്തേക്കാൾ ദൈർഘ്യമേറിയതാണെങ്കിൽ സ്ട്രിംഗ് വെട്ടിച്ചുരുക്കുന്നു
    ///
    /// ഈ ഫംഗ്ഷൻ `flag` പാരാമീറ്ററുകൾ അവഗണിക്കുന്നു എന്നത് ശ്രദ്ധേയമാണ്.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.pad("Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<4}", Foo), "Foo ");
    /// assert_eq!(&format!("{:0>4}", Foo), "0Foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pad(&mut self, s: &str) -> Result {
        // മുന്നിൽ ഒരു അതിവേഗ പാത ഉണ്ടെന്ന് ഉറപ്പാക്കുക
        if self.width.is_none() && self.precision.is_none() {
            return self.buf.write_str(s);
        }
        // സ്‌ട്രിംഗ് ഫോർമാറ്റുചെയ്യുന്നതിനായി `precision` ഫീൽഡിനെ `max-width` ആയി വ്യാഖ്യാനിക്കാം.
        //
        let s = if let Some(max) = self.precision {
            // ഞങ്ങളുടെ സ്‌ട്രിംഗ് ദൈർഘ്യമേറിയതാണെങ്കിൽ, നമുക്ക് വെട്ടിച്ചുരുക്കൽ ഉണ്ടായിരിക്കണം.
            // എന്നിരുന്നാലും മറ്റ് ഫ്ലാഗുകൾ `fill`, `width`, `align` എന്നിവ എല്ലായ്പ്പോഴും പ്രവർത്തിക്കണം.
            //
            if let Some((i, _)) = s.char_indices().nth(max) {
                // `..i` panic `&s[..i]` ചെയ്യില്ലെന്ന് ഇവിടെ എൽ‌എൽ‌വി‌എമ്മിന് തെളിയിക്കാൻ കഴിയില്ല, പക്ഷേ ഇതിന് panic കഴിയില്ലെന്ന് ഞങ്ങൾക്കറിയാം.
                // `unsafe` ഒഴിവാക്കാൻ `get` + `unwrap_or` ഉപയോഗിക്കുക, അല്ലാത്തപക്ഷം ഇവിടെ panic-യുമായി ബന്ധപ്പെട്ട ഒരു കോഡും പുറത്തുവിടരുത്.
                //
                //
                s.get(..i).unwrap_or(&s)
            } else {
                &s
            }
        } else {
            &s
        };
        // ഈ ഘട്ടത്തിൽ ഒരു `min-width` പാരാമീറ്ററാണ് `width` ഫീൽഡ്.
        match self.width {
            // ഞങ്ങൾ‌പരമാവധി ദൈർ‌ഘ്യത്തിലാണെങ്കിൽ‌, കുറഞ്ഞ ദൈർ‌ഘ്യ ആവശ്യകതകളൊന്നുമില്ലെങ്കിൽ‌, ഞങ്ങൾ‌ക്ക് സ്‌ട്രിംഗ് പുറപ്പെടുവിക്കാൻ‌കഴിയും
            //
            None => self.buf.write_str(s),
            // ഞങ്ങൾ പരമാവധി വീതിയിലാണെങ്കിൽ, ഞങ്ങൾ ഏറ്റവും കുറഞ്ഞ വീതിയിലാണോയെന്ന് പരിശോധിക്കുക, അങ്ങനെയാണെങ്കിൽ അത് സ്ട്രിംഗ് പുറപ്പെടുവിക്കുന്നത് പോലെ എളുപ്പമാണ്.
            //
            Some(width) if s.chars().count() >= width => self.buf.write_str(s),
            // ഞങ്ങൾ പരമാവധി, കുറഞ്ഞ വീതിക്ക് കീഴിലാണെങ്കിൽ, നിർദ്ദിഷ്ട സ്ട്രിംഗ് + കുറച്ച് വിന്യാസം ഉപയോഗിച്ച് ഏറ്റവും കുറഞ്ഞ വീതി പൂരിപ്പിക്കുക.
            //
            Some(width) => {
                let align = rt::v1::Alignment::Left;
                let post_padding = self.padding(width - s.chars().count(), align)?;
                self.buf.write_str(s)?;
                post_padding.write(self.buf)
            }
        }
    }

    /// പ്രീ-പാഡിംഗ് എഴുതി അലിഖിത പോസ്റ്റ് പാഡിംഗ് തിരികെ നൽകുക.
    /// പാഡിംഗ് ചെയ്യുന്ന കാര്യത്തിന് ശേഷമാണ് പോസ്റ്റ്-പാഡിംഗ് എഴുതുന്നതെന്ന് ഉറപ്പാക്കാൻ കോളർമാർക്ക് ഉത്തരവാദിത്തമുണ്ട്.
    ///
    fn padding(
        &mut self,
        padding: usize,
        default: rt::v1::Alignment,
    ) -> result::Result<PostPadding, Error> {
        let align = match self.align {
            rt::v1::Alignment::Unknown => default,
            _ => self.align,
        };

        let (pre_pad, post_pad) = match align {
            rt::v1::Alignment::Left => (0, padding),
            rt::v1::Alignment::Right | rt::v1::Alignment::Unknown => (padding, 0),
            rt::v1::Alignment::Center => (padding / 2, (padding + 1) / 2),
        };

        for _ in 0..pre_pad {
            self.buf.write_char(self.fill)?;
        }

        Ok(PostPadding::new(self.fill, post_pad))
    }

    /// ഫോർമാറ്റുചെയ്‌ത ഭാഗങ്ങൾ എടുത്ത് പാഡിംഗ് പ്രയോഗിക്കുന്നു.
    /// ആവശ്യമുള്ള കൃത്യതയോടെ കോളർ ഇതിനകം ഭാഗങ്ങൾ റെൻഡർ ചെയ്‌തിട്ടുണ്ടെന്ന് കരുതുന്നു, അതിനാൽ `self.precision` അവഗണിക്കാൻ കഴിയും.
    ///
    fn pad_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        if let Some(mut width) = self.width {
            // ചിഹ്ന-ബോധമുള്ള സീറോ പാഡിംഗിനായി, ഞങ്ങൾ ആദ്യം ചിഹ്നം റെൻഡർ ചെയ്യുകയും തുടക്കം മുതൽ ഞങ്ങൾക്ക് അടയാളങ്ങളില്ലാത്തതുപോലെ പെരുമാറുകയും ചെയ്യുന്നു.
            //
            let mut formatted = formatted.clone();
            let old_fill = self.fill;
            let old_align = self.align;
            let mut align = old_align;
            if self.sign_aware_zero_pad() {
                // ഒരു അടയാളം എല്ലായ്പ്പോഴും ആദ്യം പോകുന്നു
                let sign = formatted.sign;
                self.buf.write_str(sign)?;

                // ഫോർമാറ്റുചെയ്‌ത ഭാഗങ്ങളിൽ നിന്ന് ചിഹ്നം നീക്കംചെയ്യുക
                formatted.sign = "";
                width = width.saturating_sub(sign.len());
                align = rt::v1::Alignment::Right;
                self.fill = '0';
                self.align = rt::v1::Alignment::Right;
            }

            // ശേഷിക്കുന്ന ഭാഗങ്ങൾ സാധാരണ പാഡിംഗ് പ്രക്രിയയിലൂടെ കടന്നുപോകുന്നു.
            let len = formatted.len();
            let ret = if width <= len {
                // പാഡിംഗ് ഇല്ല
                self.write_formatted_parts(&formatted)
            } else {
                let post_padding = self.padding(width - len, align)?;
                self.write_formatted_parts(&formatted)?;
                post_padding.write(self.buf)
            };
            self.fill = old_fill;
            self.align = old_align;
            ret
        } else {
            // ഇതാണ് സാധാരണ കേസ്, ഞങ്ങൾ ഒരു കുറുക്കുവഴി എടുക്കുന്നു
            self.write_formatted_parts(formatted)
        }
    }

    fn write_formatted_parts(&mut self, formatted: &flt2dec::Formatted<'_>) -> Result {
        fn write_bytes(buf: &mut dyn Write, s: &[u8]) -> Result {
            // സുരക്ഷ: ഇത് `flt2dec::Part::Num`, `flt2dec::Part::Copy` എന്നിവയ്‌ക്കായി ഉപയോഗിക്കുന്നു.
            // എല്ലാ ചാർ‌`c` ഉം `b'0'` നും `b'9'` നും ഇടയിലായതിനാൽ‌`flt2dec::Part::Num` നായി ഉപയോഗിക്കുന്നത് സുരക്ഷിതമാണ്, അതായത് `s` സാധുവായ UTF-8 ആണ്.
            // `buf` പ്ലെയിൻ ASCII ആയിരിക്കേണ്ടതിനാൽ `flt2dec::Part::Copy(buf)`-നായി ഉപയോഗിക്കുന്നത് പ്രായോഗികമായി സുരക്ഷിതമാണ്, പക്ഷേ `buf`-ന് ഒരു മോശം മൂല്യത്തിൽ `flt2dec::to_shortest_str`-ലേക്ക് കടക്കാൻ ഒരാൾക്ക് കഴിയും, കാരണം ഇത് ഒരു പൊതു പ്രവർത്തനമാണ്.
            //
            // FIXME: ഇത് യുബിക്ക് കാരണമാകുമോ എന്ന് നിർണ്ണയിക്കുക.
            //
            //
            //
            buf.write_str(unsafe { str::from_utf8_unchecked(s) })
        }

        if !formatted.sign.is_empty() {
            self.buf.write_str(formatted.sign)?;
        }
        for part in formatted.parts {
            match *part {
                flt2dec::Part::Zero(mut nzeroes) => {
                    const ZEROES: &str = // 64 പൂജ്യങ്ങൾ
                        "0000000000000000000000000000000000000000000000000000000000000000";
                    while nzeroes > ZEROES.len() {
                        self.buf.write_str(ZEROES)?;
                        nzeroes -= ZEROES.len();
                    }
                    if nzeroes > 0 {
                        self.buf.write_str(&ZEROES[..nzeroes])?;
                    }
                }
                flt2dec::Part::Num(mut v) => {
                    let mut s = [0; 5];
                    let len = part.len();
                    for c in s[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                    write_bytes(self.buf, &s[..len])?;
                }
                flt2dec::Part::Copy(buf) => {
                    write_bytes(self.buf, buf)?;
                }
            }
        }
        Ok(())
    }

    /// ഈ ഫോർ‌മാറ്ററിനുള്ളിൽ‌അടങ്ങിയിരിക്കുന്ന ബഫറിലേക്ക് കുറച്ച് ഡാറ്റ എഴുതുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_str("Foo")
    ///         // ഇത് ഇതിന് തുല്യമാണ്:
    ///         // എഴുതുക! (ഫോർമാറ്റർ, "Foo")
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo), "Foo");
    /// assert_eq!(&format!("{:0>8}", Foo), "Foo");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_str(&mut self, data: &str) -> Result {
        self.buf.write_str(data)
    }

    /// ഫോർമാറ്റുചെയ്‌ത ചില വിവരങ്ങൾ ഈ സന്ദർഭത്തിലേക്ക് എഴുതുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         formatter.write_fmt(format_args!("Foo {}", self.0))
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{}", Foo(-1)), "Foo -1");
    /// assert_eq!(&format!("{:0>8}", Foo(2)), "Foo 2");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn write_fmt(&mut self, fmt: Arguments<'_>) -> Result {
        write(self.buf, fmt)
    }

    /// ഫോർമാറ്റിംഗിനായുള്ള ഫ്ലാഗുകൾ
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.24.0",
        reason = "use the `sign_plus`, `sign_minus`, `alternate`, \
                  or `sign_aware_zero_pad` methods instead"
    )]
    pub fn flags(&self) -> u32 {
        self.flags
    }

    /// വിന്യാസം ഉണ്ടാകുമ്പോഴെല്ലാം 'fill' ആയി ഉപയോഗിക്കുന്ന പ്രതീകം.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let c = formatter.fill();
    ///         if let Some(width) = formatter.width() {
    ///             for _ in 0..width {
    ///                 write!(formatter, "{}", c)?;
    ///             }
    ///             Ok(())
    ///         } else {
    ///             write!(formatter, "{}", c)
    ///         }
    ///     }
    /// }
    ///
    /// // ">" ഉപയോഗിച്ച് ഞങ്ങൾ വലതുവശത്ത് വിന്യാസം സജ്ജമാക്കി.
    /// assert_eq!(&format!("{:G>3}", Foo), "GGG");
    /// assert_eq!(&format!("{:t>6}", Foo), "tttttt");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn fill(&self) -> char {
        self.fill
    }

    /// ഏത് തരത്തിലുള്ള വിന്യാസമാണ് അഭ്യർത്ഥിച്ചതെന്ന് സൂചിപ്പിക്കുന്ന ഫ്ലാഗ്.
    ///
    /// # Examples
    ///
    /// ```
    /// extern crate core;
    ///
    /// use std::fmt::{self, Alignment};
    ///
    /// struct Foo;
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         let s = if let Some(s) = formatter.align() {
    ///             match s {
    ///                 Alignment::Left    => "left",
    ///                 Alignment::Right   => "right",
    ///                 Alignment::Center  => "center",
    ///             }
    ///         } else {
    ///             "into the void"
    ///         };
    ///         write!(formatter, "{}", s)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:<}", Foo), "left");
    /// assert_eq!(&format!("{:>}", Foo), "right");
    /// assert_eq!(&format!("{:^}", Foo), "center");
    /// assert_eq!(&format!("{}", Foo), "into the void");
    /// ```
    #[stable(feature = "fmt_flags_align", since = "1.28.0")]
    pub fn align(&self) -> Option<Alignment> {
        match self.align {
            rt::v1::Alignment::Left => Some(Alignment::Left),
            rt::v1::Alignment::Right => Some(Alignment::Right),
            rt::v1::Alignment::Center => Some(Alignment::Center),
            rt::v1::Alignment::Unknown => None,
        }
    }

    /// Output ട്ട്‌പുട്ട് ആയിരിക്കണമെന്ന് ഓപ്‌ഷണലായി വ്യക്തമാക്കിയ പൂർണ്ണസംഖ്യ വീതി.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(width) = formatter.width() {
    ///             // ഞങ്ങൾക്ക് ഒരു വീതി ലഭിച്ചിട്ടുണ്ടെങ്കിൽ, ഞങ്ങൾ അത് ഉപയോഗിക്കുന്നു
    ///             write!(formatter, "{:width$}", &format!("Foo({})", self.0), width = width)
    ///         } else {
    ///             // അല്ലെങ്കിൽ ഞങ്ങൾ പ്രത്യേകമായി ഒന്നും ചെയ്യുന്നില്ല
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:10}", Foo(23)), "Foo(23)   ");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn width(&self) -> Option<usize> {
        self.width
    }

    /// സംഖ്യാ തരങ്ങൾക്കായി ഓപ്‌ഷണലായി വ്യക്തമാക്കിയ കൃത്യത.
    /// പകരമായി, സ്ട്രിംഗ് തരങ്ങളുടെ പരമാവധി വീതി.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(f32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if let Some(precision) = formatter.precision() {
    ///             // ഞങ്ങൾക്ക് ഒരു കൃത്യത ലഭിക്കുകയാണെങ്കിൽ, ഞങ്ങൾ അത് ഉപയോഗിക്കുന്നു.
    ///             write!(formatter, "Foo({1:.*})", precision, self.0)
    ///         } else {
    ///             // അല്ലെങ്കിൽ ഞങ്ങൾ സ്ഥിരസ്ഥിതിയായി 2 ആയി.
    ///             write!(formatter, "Foo({:.2})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:.4}", Foo(23.2)), "Foo(23.2000)");
    /// assert_eq!(&format!("{}", Foo(23.2)), "Foo(23.20)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn precision(&self) -> Option<usize> {
        self.precision
    }

    /// `+` ഫ്ലാഗ് വ്യക്തമാക്കിയിട്ടുണ്ടോ എന്ന് നിർണ്ണയിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_plus() {
    ///             write!(formatter,
    ///                    "Foo({}{})",
    ///                    if self.0 < 0 { '-' } else { '+' },
    ///                    self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:+}", Foo(23)), "Foo(+23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_plus(&self) -> bool {
        self.flags & (1 << FlagV1::SignPlus as u32) != 0
    }

    /// `-` ഫ്ലാഗ് വ്യക്തമാക്കിയിട്ടുണ്ടോ എന്ന് നിർണ്ണയിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.sign_minus() {
    ///             // നിങ്ങൾക്ക് ഒരു മൈനസ് ചിഹ്നം ആവശ്യമുണ്ടോ?ഒരെണ്ണം!
    ///             write!(formatter, "-Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "Foo({})", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:-}", Foo(23)), "-Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "Foo(23)");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_minus(&self) -> bool {
        self.flags & (1 << FlagV1::SignMinus as u32) != 0
    }

    /// `#` ഫ്ലാഗ് വ്യക്തമാക്കിയിട്ടുണ്ടോ എന്ന് നിർണ്ണയിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         if formatter.alternate() {
    ///             write!(formatter, "Foo({})", self.0)
    ///         } else {
    ///             write!(formatter, "{}", self.0)
    ///         }
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:#}", Foo(23)), "Foo(23)");
    /// assert_eq!(&format!("{}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn alternate(&self) -> bool {
        self.flags & (1 << FlagV1::Alternate as u32) != 0
    }

    /// `0` ഫ്ലാഗ് വ്യക്തമാക്കിയിട്ടുണ്ടോ എന്ന് നിർണ്ണയിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// struct Foo(i32);
    ///
    /// impl fmt::Display for Foo {
    ///     fn fmt(&self, formatter: &mut fmt::Formatter) -> fmt::Result {
    ///         assert!(formatter.sign_aware_zero_pad());
    ///         assert_eq!(formatter.width(), Some(4));
    ///         // ഫോർമാറ്ററിന്റെ ഓപ്ഷനുകൾ ഞങ്ങൾ അവഗണിക്കുന്നു.
    ///         write!(formatter, "{}", self.0)
    ///     }
    /// }
    ///
    /// assert_eq!(&format!("{:04}", Foo(23)), "23");
    /// ```
    #[stable(feature = "fmt_flags", since = "1.5.0")]
    pub fn sign_aware_zero_pad(&self) -> bool {
        self.flags & (1 << FlagV1::SignAwareZeroPad as u32) != 0
    }

    // FIXME: ഈ രണ്ട് ഫ്ലാഗുകൾക്കായി ഞങ്ങൾക്ക് എന്ത് പൊതു API വേണമെന്ന് തീരുമാനിക്കുക.
    // https://github.com/rust-lang/rust/issues/48584
    fn debug_lower_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugLowerHex as u32) != 0
    }

    fn debug_upper_hex(&self) -> bool {
        self.flags & (1 << FlagV1::DebugUpperHex as u32) != 0
    }

    /// സ്ട്രക്റ്റുകൾക്കായി എക്സ് 01 എക്സ് ഇംപ്ലിമെൻറേഷനുകൾ സൃഷ്ടിക്കുന്നതിന് സഹായിക്കുന്നതിന് രൂപകൽപ്പന ചെയ്ത ഒരു എക്സ് 00 എക്സ് ബിൽഡർ സൃഷ്ടിക്കുന്നു.
    ///
    ///
    /// [`fmt::Debug`]: self::Debug
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::net::Ipv4Addr;
    ///
    /// struct Foo {
    ///     bar: i32,
    ///     baz: String,
    ///     addr: Ipv4Addr,
    /// }
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_struct("Foo")
    ///             .field("bar", &self.bar)
    ///             .field("baz", &self.baz)
    ///             .field("addr", &format_args!("{}", self.addr))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo { bar: 10, baz: \"Hello World\", addr: 127.0.0.1 }",
    ///     format!("{:?}", Foo {
    ///         bar: 10,
    ///         baz: "Hello World".to_string(),
    ///         addr: Ipv4Addr::new(127, 0, 0, 1),
    ///     })
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_struct<'b>(&'b mut self, name: &str) -> DebugStruct<'b, 'a> {
        builders::debug_struct_new(self, name)
    }

    /// ടുപ്പിൾ സ്ട്രക്റ്റുകൾക്കായി എക്സ് 01 എക്സ് ഇംപ്ലിമെൻറേഷനുകൾ സൃഷ്ടിക്കുന്നതിന് സഹായിക്കുന്നതിന് രൂപകൽപ്പന ചെയ്ത ഒരു എക്സ് 00 എക്സ് ബിൽഡർ സൃഷ്ടിക്കുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    /// use std::marker::PhantomData;
    ///
    /// struct Foo<T>(i32, String, PhantomData<T>);
    ///
    /// impl<T> fmt::Debug for Foo<T> {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_tuple("Foo")
    ///             .field(&self.0)
    ///             .field(&self.1)
    ///             .field(&format_args!("_"))
    ///             .finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     "Foo(10, \"Hello\", _)",
    ///     format!("{:?}", Foo(10, "Hello".to_string(), PhantomData::<u8>))
    /// );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_tuple<'b>(&'b mut self, name: &str) -> DebugTuple<'b, 'a> {
        builders::debug_tuple_new(self, name)
    }

    /// ലിസ്റ്റ് പോലുള്ള ഘടനകൾക്കായി `fmt::Debug` നടപ്പിലാക്കലുകൾ സൃഷ്ടിക്കാൻ സഹായിക്കുന്നതിന് രൂപകൽപ്പന ചെയ്ത ഒരു `DebugList` ബിൽഡർ സൃഷ്ടിക്കുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_list().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "[10, 11]");
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_list<'b>(&'b mut self) -> DebugList<'b, 'a> {
        builders::debug_list_new(self)
    }

    /// സെറ്റ് പോലുള്ള ഘടനകൾക്കായി `fmt::Debug` നടപ്പിലാക്കലുകൾ സൃഷ്ടിക്കാൻ സഹായിക്കുന്നതിന് രൂപകൽപ്പന ചെയ്ത ഒരു `DebugSet` ബിൽഡർ സൃഷ്ടിക്കുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<i32>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set().entries(self.0.iter()).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(format!("{:?}", Foo(vec![10, 11])), "{10, 11}");
    /// ```
    ///
    /// [`format_args!`]: crate::format_args
    ///
    /// കൂടുതൽ സങ്കീർണ്ണമായ ഈ ഉദാഹരണത്തിൽ, മാച്ച് ആയുധങ്ങളുടെ ഒരു ലിസ്റ്റ് നിർമ്മിക്കാൻ ഞങ്ങൾ [`format_args!`], `.debug_set()` എന്നിവ ഉപയോഗിക്കുന്നു:
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Arm<'a, L: 'a, R: 'a>(&'a (L, R));
    /// struct Table<'a, K: 'a, V: 'a>(&'a [(K, V)], V);
    ///
    /// impl<'a, L, R> fmt::Debug for Arm<'a, L, R>
    /// where
    ///     L: 'a + fmt::Debug, R: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         L::fmt(&(self.0).0, fmt)?;
    ///         fmt.write_str(" => ")?;
    ///         R::fmt(&(self.0).1, fmt)
    ///     }
    /// }
    ///
    /// impl<'a, K, V> fmt::Debug for Table<'a, K, V>
    /// where
    ///     K: 'a + fmt::Debug, V: 'a + fmt::Debug
    /// {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_set()
    ///         .entries(self.0.iter().map(Arm))
    ///         .entry(&Arm(&(format_args!("_"), &self.1)))
    ///         .finish()
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_set<'b>(&'b mut self) -> DebugSet<'b, 'a> {
        builders::debug_set_new(self)
    }

    /// മാപ്പ് പോലുള്ള ഘടനകൾക്കായി `fmt::Debug` നടപ്പിലാക്കലുകൾ സൃഷ്ടിക്കുന്നതിന് സഹായിക്കുന്നതിന് രൂപകൽപ്പന ചെയ്ത ഒരു `DebugMap` ബിൽഡർ സൃഷ്ടിക്കുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::fmt;
    ///
    /// struct Foo(Vec<(String, i32)>);
    ///
    /// impl fmt::Debug for Foo {
    ///     fn fmt(&self, fmt: &mut fmt::Formatter) -> fmt::Result {
    ///         fmt.debug_map().entries(self.0.iter().map(|&(ref k, ref v)| (k, v))).finish()
    ///     }
    /// }
    ///
    /// assert_eq!(
    ///     format!("{:?}",  Foo(vec![("A".to_string(), 10), ("B".to_string(), 11)])),
    ///     r#"{"A": 10, "B": 11}"#
    ///  );
    /// ```
    #[stable(feature = "debug_builders", since = "1.2.0")]
    pub fn debug_map<'b>(&'b mut self) -> DebugMap<'b, 'a> {
        builders::debug_map_new(self)
    }
}

#[stable(since = "1.2.0", feature = "formatter_write")]
impl Write for Formatter<'_> {
    fn write_str(&mut self, s: &str) -> Result {
        self.buf.write_str(s)
    }

    fn write_char(&mut self, c: char) -> Result {
        self.buf.write_char(c)
    }

    fn write_fmt(&mut self, args: Arguments<'_>) -> Result {
        write(self.buf, args)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for Error {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt("an error occurred when formatting an argument", f)
    }
}

// കോർ ഫോർമാറ്റിംഗിന്റെ നടപ്പാക്കലുകൾ traits

macro_rules! fmt_refs {
    ($($tr:ident),*) => {
        $(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized + $tr> $tr for &mut T {
            fn fmt(&self, f: &mut Formatter<'_>) -> Result { $tr::fmt(&**self, f) }
        }
        )*
    }
}

fmt_refs! { Debug, Display, Octal, Binary, LowerHex, UpperHex, LowerExp, UpperExp }

#[unstable(feature = "never_type", issue = "35121")]
impl Debug for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl Display for ! {
    fn fmt(&self, _: &mut Formatter<'_>) -> Result {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for bool {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for bool {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Display::fmt(if *self { "true" } else { "false" }, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('"')?;
        let mut from = 0;
        for (i, c) in self.char_indices() {
            let esc = c.escape_debug();
            // ചാർ‌ക്ക് രക്ഷപ്പെടാൻ‌ആവശ്യമുണ്ടെങ്കിൽ‌, ഇതുവരെ ബാക്ക്‌ലോഗ് ഫ്ലഷ് ചെയ്‌ത് എഴുതുക, അല്ലെങ്കിൽ‌ഒഴിവാക്കുക
            if esc.len() != 1 {
                f.write_str(&self[from..i])?;
                for c in esc {
                    f.write_char(c)?;
                }
                from = i + c.len_utf8();
            }
        }
        f.write_str(&self[from..])?;
        f.write_char('"')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for str {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.write_char('\'')?;
        for c in self.escape_debug() {
            f.write_char(c)?
        }
        f.write_char('\'')
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Display for char {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        if f.width.is_none() && f.precision.is_none() {
            f.write_char(*self)
        } else {
            f.pad(self.encode_utf8(&mut [0; 4]))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        let old_width = f.width;
        let old_flags = f.flags;

        // ഇതര ഫ്ലാഗ് ഇതിനകം ലോവർഹെക്സ് പ്രത്യേകമായി കണക്കാക്കുന്നു-ഇത് 0x ഉപയോഗിച്ച് പ്രിഫിക്‌സ് ചെയ്യണമോ എന്ന് സൂചിപ്പിക്കുന്നു.
        // പൂജ്യം നീട്ടണോ വേണ്ടയോ എന്ന് പ്രവർത്തിക്കാൻ ഞങ്ങൾ ഇത് ഉപയോഗിക്കുന്നു, തുടർന്ന് പ്രിഫിക്‌സ് ലഭിക്കുന്നതിന് നിരുപാധികമായി സജ്ജമാക്കുക.
        //
        //
        if f.alternate() {
            f.flags |= 1 << (FlagV1::SignAwareZeroPad as u32);

            if f.width.is_none() {
                f.width = Some((usize::BITS / 4) as usize + 2);
            }
        }
        f.flags |= 1 << (FlagV1::Alternate as u32);

        let ret = LowerHex::fmt(&(*self as *const () as usize), f);

        f.width = old_width;
        f.flags = old_flags;

        ret
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(*self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Pointer for &mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(&(&**self as *const T), f)
    }
}

// വിവിധ കോർ തരങ്ങൾക്കായി Display/Debug നടപ്പിലാക്കൽ

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *const T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for *mut T {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Pointer::fmt(self, f)
    }
}

macro_rules! peel {
    ($name:ident, $($other:ident,)*) => (tuple! { $($other,)* })
}

macro_rules! tuple {
    () => ();
    ( $($name:ident,)+ ) => (
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<$($name:Debug),+> Debug for ($($name,)+) where last_type!($($name,)+): ?Sized {
            #[allow(non_snake_case, unused_assignments)]
            fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                let mut builder = f.debug_tuple("");
                let ($(ref $name,)+) = *self;
                $(
                    builder.field(&$name);
                )+

                builder.finish()
            }
        }
        peel! { $($name,)+ }
    )
}

macro_rules! last_type {
    ($a:ident,) => { $a };
    ($a:ident, $($rest_a:ident,)+) => { last_type!($($rest_a,)+) };
}

tuple! { T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, }

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for [T] {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Debug for () {
    #[inline]
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("()")
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Debug for PhantomData<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("PhantomData")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy + Debug> Debug for Cell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.debug_struct("Cell").field("value", &self.get()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_struct("RefCell").field("value", &borrow).finish(),
            Err(_) => {
                // RefCell പരസ്പരം കടമെടുത്തതിനാൽ ഞങ്ങൾക്ക് അതിന്റെ മൂല്യം ഇവിടെ നോക്കാൻ കഴിയില്ല.
                // പകരം ഒരു പ്ലെയ്‌സ്‌ഹോൾഡർ കാണിക്കുക.
                struct BorrowedPlaceholder;

                impl Debug for BorrowedPlaceholder {
                    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
                        f.write_str("<borrowed>")
                    }
                }

                f.debug_struct("RefCell").field("value", &BorrowedPlaceholder).finish()
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Debug> Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        Debug::fmt(&*(self.deref()), f)
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<T: ?Sized + Debug> Debug for UnsafeCell<T> {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        f.pad("UnsafeCell")
    }
}

// ടെസ്റ്റുകൾ ഇവിടെ ഉണ്ടെന്ന് നിങ്ങൾ പ്രതീക്ഷിച്ചിരുന്നെങ്കിൽ, പകരം core/tests/fmt.rs ഫയലിലേക്ക് നോക്കുക, ഇവിടെ എല്ലാ rt::Piece ഘടനകളും സൃഷ്ടിക്കുന്നതിനേക്കാൾ വളരെ എളുപ്പമാണ്.
//
// അലോക്കേഷൻ ആവശ്യമുള്ളവർക്ക് crate എന്ന അലോക്കേഷനിൽ ടെസ്റ്റുകളും ഉണ്ട്.