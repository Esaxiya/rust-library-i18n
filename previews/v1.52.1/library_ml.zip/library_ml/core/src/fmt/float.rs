use crate::fmt::{Debug, Display, Formatter, LowerExp, Result, UpperExp};
use crate::mem::MaybeUninit;
use crate::num::flt2dec;

// ഇത് ഇൻലൈൻ ചെയ്യരുത്, അതിനാൽ കോളർമാർക്ക് ഈ ഫംഗ്ഷന് ആവശ്യമുള്ള സ്റ്റാക്ക് സ്പേസ് ഉപയോഗിക്കരുത്.
//
#[inline(never)]
fn float_to_decimal_common_exact<T>(
    fmt: &mut Formatter<'_>,
    num: &T,
    sign: flt2dec::Sign,
    precision: usize,
) -> Result
where
    T: flt2dec::DecodableFloat,
{
    let mut buf: [MaybeUninit<u8>; 1024] = MaybeUninit::uninit_array(); // f32, f64 എന്നിവയ്‌ക്ക് മതി
    let mut parts: [MaybeUninit<flt2dec::Part<'_>>; 4] = MaybeUninit::uninit_array();
    let formatted = flt2dec::to_exact_fixed_str(
        flt2dec::strategy::grisu::format_exact,
        *num,
        sign,
        precision,
        &mut buf,
        &mut parts,
    );
    fmt.pad_formatted_parts(&formatted)
}

// ഇത് ഇൻലൈൻ ചെയ്യരുത്, അതിനാൽ ഇതിനെയും മുകളിലെയും വിളിക്കുന്ന കോളർമാർ ചില സന്ദർഭങ്ങളിൽ രണ്ട് ഫംഗ്ഷനുകളുടെയും സംയോജിത സ്റ്റാക്ക് സ്പേസ് ഉപയോഗിച്ച് അവസാനിപ്പിക്കില്ല.
//
#[inline(never)]
fn float_to_decimal_common_shortest<T>(
    fmt: &mut Formatter<'_>,
    num: &T,
    sign: flt2dec::Sign,
    precision: usize,
) -> Result
where
    T: flt2dec::DecodableFloat,
{
    // f32, f64 എന്നിവയ്‌ക്ക് മതി
    let mut buf: [MaybeUninit<u8>; flt2dec::MAX_SIG_DIGITS] = MaybeUninit::uninit_array();
    let mut parts: [MaybeUninit<flt2dec::Part<'_>>; 4] = MaybeUninit::uninit_array();
    let formatted = flt2dec::to_shortest_str(
        flt2dec::strategy::grisu::format_shortest,
        *num,
        sign,
        precision,
        &mut buf,
        &mut parts,
    );
    fmt.pad_formatted_parts(&formatted)
}

// ഫ്ലോട്ടിംഗ് പോയിൻറ് ഡീബഗിന്റെയും ഡിസ്പ്ലേയുടെയും സാധാരണ കോഡ്.
fn float_to_decimal_common<T>(
    fmt: &mut Formatter<'_>,
    num: &T,
    negative_zero: bool,
    min_precision: usize,
) -> Result
where
    T: flt2dec::DecodableFloat,
{
    let force_sign = fmt.sign_plus();
    let sign = match (force_sign, negative_zero) {
        (false, false) => flt2dec::Sign::Minus,
        (false, true) => flt2dec::Sign::MinusRaw,
        (true, false) => flt2dec::Sign::MinusPlus,
        (true, true) => flt2dec::Sign::MinusPlusRaw,
    };

    if let Some(precision) = fmt.precision {
        float_to_decimal_common_exact(fmt, num, sign, precision)
    } else {
        float_to_decimal_common_shortest(fmt, num, sign, min_precision)
    }
}

// ഇത് ഇൻലൈൻ ചെയ്യരുത്, അതിനാൽ കോളർമാർക്ക് ഈ ഫംഗ്ഷന് ആവശ്യമുള്ള സ്റ്റാക്ക് സ്പേസ് ഉപയോഗിക്കരുത്.
//
#[inline(never)]
fn float_to_exponential_common_exact<T>(
    fmt: &mut Formatter<'_>,
    num: &T,
    sign: flt2dec::Sign,
    precision: usize,
    upper: bool,
) -> Result
where
    T: flt2dec::DecodableFloat,
{
    let mut buf: [MaybeUninit<u8>; 1024] = MaybeUninit::uninit_array(); // f32, f64 എന്നിവയ്‌ക്ക് മതി
    let mut parts: [MaybeUninit<flt2dec::Part<'_>>; 6] = MaybeUninit::uninit_array();
    let formatted = flt2dec::to_exact_exp_str(
        flt2dec::strategy::grisu::format_exact,
        *num,
        sign,
        precision,
        upper,
        &mut buf,
        &mut parts,
    );
    fmt.pad_formatted_parts(&formatted)
}

// ഇത് ഇൻലൈൻ ചെയ്യരുത്, അതിനാൽ ഇതിനെയും മുകളിലെയും വിളിക്കുന്ന കോളർമാർ ചില സന്ദർഭങ്ങളിൽ രണ്ട് ഫംഗ്ഷനുകളുടെയും സംയോജിത സ്റ്റാക്ക് സ്പേസ് ഉപയോഗിച്ച് അവസാനിപ്പിക്കില്ല.
//
#[inline(never)]
fn float_to_exponential_common_shortest<T>(
    fmt: &mut Formatter<'_>,
    num: &T,
    sign: flt2dec::Sign,
    upper: bool,
) -> Result
where
    T: flt2dec::DecodableFloat,
{
    // f32, f64 എന്നിവയ്‌ക്ക് മതി
    let mut buf: [MaybeUninit<u8>; flt2dec::MAX_SIG_DIGITS] = MaybeUninit::uninit_array();
    let mut parts: [MaybeUninit<flt2dec::Part<'_>>; 6] = MaybeUninit::uninit_array();
    let formatted = flt2dec::to_shortest_exp_str(
        flt2dec::strategy::grisu::format_shortest,
        *num,
        sign,
        (0, 0),
        upper,
        &mut buf,
        &mut parts,
    );
    fmt.pad_formatted_parts(&formatted)
}

// ഫ്ലോട്ടിംഗ് പോയിന്റായ ലോവർഎക്സ്പി, അപ്പർഎക്സ്പി എന്നിവയുടെ സാധാരണ കോഡ്.
fn float_to_exponential_common<T>(fmt: &mut Formatter<'_>, num: &T, upper: bool) -> Result
where
    T: flt2dec::DecodableFloat,
{
    let force_sign = fmt.sign_plus();
    let sign = match force_sign {
        false => flt2dec::Sign::Minus,
        true => flt2dec::Sign::MinusPlus,
    };

    if let Some(precision) = fmt.precision {
        // 1 ഇന്റഗ്രൽ അക്ക + `precision` ഫ്രാക്ഷണൽ അക്കങ്ങൾ= `precision + 1` ആകെ അക്കങ്ങൾ
        float_to_exponential_common_exact(fmt, num, sign, precision + 1, upper)
    } else {
        float_to_exponential_common_shortest(fmt, num, sign, upper)
    }
}

macro_rules! floating {
    ($ty:ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Debug for $ty {
            fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
                float_to_decimal_common(fmt, self, true, 1)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl Display for $ty {
            fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
                float_to_decimal_common(fmt, self, false, 0)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl LowerExp for $ty {
            fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
                float_to_exponential_common(fmt, self, false)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl UpperExp for $ty {
            fn fmt(&self, fmt: &mut Formatter<'_>) -> Result {
                float_to_exponential_common(fmt, self, true)
            }
        }
    };
}

floating! { f32 }
floating! { f64 }