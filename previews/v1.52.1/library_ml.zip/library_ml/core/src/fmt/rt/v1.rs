//! ഇത് ifmt ഉപയോഗിക്കുന്ന ഒരു ആന്തരിക മൊഡ്യൂളാണ്!റൺടൈം.ഈ ഘടനകൾ സമയത്തിന് മുമ്പായി ഫോർമാറ്റ് സ്ട്രിംഗുകൾ പ്രീ കംപൈൽ ചെയ്യുന്നതിന് സ്റ്റാറ്റിക് അറേകളിലേക്ക് പുറപ്പെടുവിക്കുന്നു.
//!
//! ഈ നിർവചനങ്ങൾ അവയുടെ `ct` തുല്യതയ്ക്ക് സമാനമാണ്, എന്നാൽ ഇവ സ്റ്റാറ്റിക് ആയി അനുവദിക്കാമെന്നും റൺടൈമിനായി ചെറുതായി ഒപ്റ്റിമൈസ് ചെയ്യാമെന്നും വ്യത്യാസപ്പെട്ടിരിക്കുന്നു
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// ഒരു ഫോർമാറ്റിംഗ് നിർദ്ദേശത്തിന്റെ ഭാഗമായി അഭ്യർത്ഥിക്കാവുന്ന സാധ്യമായ വിന്യാസങ്ങൾ.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// ഉള്ളടക്കങ്ങൾ ഇടത്-വിന്യസിക്കണം എന്നതിന്റെ സൂചന.
    Left,
    /// ഉള്ളടക്കങ്ങൾ ശരിയായി വിന്യസിക്കണം എന്നതിന്റെ സൂചന.
    Right,
    /// ഉള്ളടക്കങ്ങൾ മധ്യഭാഗത്ത് വിന്യസിക്കണം എന്നതിന്റെ സൂചന.
    Center,
    /// വിന്യാസമൊന്നും അഭ്യർത്ഥിച്ചിട്ടില്ല.
    Unknown,
}

/// [width](https://doc.rust-lang.org/std/fmt/#width), [precision](https://doc.rust-lang.org/std/fmt/#precision) സ്‌പെസിഫയറുകൾ ഉപയോഗിക്കുന്നു.
#[derive(Copy, Clone)]
pub enum Count {
    /// ഒരു അക്ഷര നമ്പർ ഉപയോഗിച്ച് വ്യക്തമാക്കി, മൂല്യം സംഭരിക്കുന്നു
    Is(usize),
    /// `$`, `*` വാക്യഘടന ഉപയോഗിച്ച് വ്യക്തമാക്കിയ, സൂചിക `args`-ലേക്ക് സംഭരിക്കുന്നു
    Param(usize),
    /// വ്യക്തമാക്കിയിട്ടില്ല
    Implied,
}