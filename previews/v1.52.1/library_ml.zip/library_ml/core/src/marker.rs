//! പ്രാകൃത traits ഉം തരങ്ങളുടെ അടിസ്ഥാന സവിശേഷതകളെ പ്രതിനിധീകരിക്കുന്ന തരങ്ങളും.
//!
//! Rust തരങ്ങളെ അവയുടെ ആന്തരിക സ്വഭാവമനുസരിച്ച് വിവിധ ഉപയോഗപ്രദമായ രീതിയിൽ തരംതിരിക്കാം.
//! ഈ വർഗ്ഗീകരണങ്ങളെ traits ആയി പ്രതിനിധീകരിക്കുന്നു.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// ത്രെഡ് അതിരുകളിലൂടെ കൈമാറാൻ‌കഴിയുന്ന തരങ്ങൾ‌.
///
/// കംപൈലർ ഉചിതമാണെന്ന് നിർണ്ണയിക്കുമ്പോൾ ഈ trait യാന്ത്രികമായി നടപ്പിലാക്കുന്നു.
///
/// റഫറൻസ്-കൗണ്ടിംഗ് പോയിന്റർ [`rc::Rc`][`Rc`] ആണ് `അയയ്‌ക്കാത്ത` തരത്തിന്റെ ഉദാഹരണം.
/// ഒരേ റഫറൻസ് കണക്കാക്കിയ മൂല്യത്തിലേക്ക് പോയിന്റുചെയ്യുന്ന രണ്ട് ത്രെഡുകൾ [`Rc`] ക്ലോൺ ചെയ്യാൻ ശ്രമിക്കുകയാണെങ്കിൽ, അവ ഒരേ സമയം റഫറൻസ് എണ്ണം അപ്‌ഡേറ്റ് ചെയ്യാൻ ശ്രമിച്ചേക്കാം, ഇത് [undefined behavior][ub] ആണ്, കാരണം [`Rc`] ആറ്റോമിക് പ്രവർത്തനങ്ങൾ ഉപയോഗിക്കില്ല.
///
/// ഇതിന്റെ കസിൻ [`sync::Arc`][arc] ആറ്റോമിക് പ്രവർത്തനങ്ങൾ ഉപയോഗിക്കുന്നു (കുറച്ച് ഓവർഹെഡ് സംഭവിക്കുന്നു), അങ്ങനെ `Send`.
///
/// കൂടുതൽ വിവരങ്ങൾക്ക് [the Nomicon](../../nomicon/send-and-sync.html) കാണുക.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// കംപൈൽ സമയത്ത് അറിയപ്പെടുന്ന സ്ഥിരമായ വലുപ്പമുള്ള തരങ്ങൾ.
///
/// എല്ലാ തരം പാരാമീറ്ററുകൾക്കും `Sized`-ന്റെ വ്യക്തമായ പരിധി ഉണ്ട്.ഉചിതമല്ലെങ്കിൽ ഈ പരിധി നീക്കംചെയ്യാൻ പ്രത്യേക സിന്റാക്സ് `?Sized` ഉപയോഗിക്കാം.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//പിശക്: വലുപ്പം [i32]-നായി നടപ്പിലാക്കിയിട്ടില്ല
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// ഒരു അപവാദം ഒരു trait-ന്റെ വ്യക്തമായ `Self` തരം ആണ്.
/// [trait ഒബ്‌ജക്റ്റ്] യുമായി ഇത് പൊരുത്തപ്പെടാത്തതിനാൽ ഒരു trait ന് വ്യക്തമായ `Sized` ബന്ധമില്ല, നിർവചനം അനുസരിച്ച്, trait സാധ്യമായ എല്ലാ നടപ്പിലാക്കുന്നവരുമായും പ്രവർത്തിക്കേണ്ടതുണ്ട്, അതിനാൽ ഏത് വലുപ്പവും ആകാം.
///
///
/// Rust നിങ്ങളെ `Sized` നെ ഒരു trait ലേക്ക് ബന്ധിപ്പിക്കാൻ അനുവദിക്കുമെങ്കിലും, പിന്നീട് ഒരു trait ഒബ്ജക്റ്റ് രൂപീകരിക്കുന്നതിന് നിങ്ങൾക്ക് ഇത് ഉപയോഗിക്കാൻ കഴിയില്ല:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // y: &dyn ബാർ= &Impl;//പിശക്: trait `Bar` ഒരു ഒബ്‌ജക്റ്റാക്കി മാറ്റാൻ കഴിയില്ല
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // സ്ഥിരസ്ഥിതിക്കായി, ഉദാഹരണത്തിന്, `[T]: !Default` മൂല്യനിർണ്ണയം ചെയ്യേണ്ടതുണ്ട്
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// ചലനാത്മക വലുപ്പത്തിലുള്ള തരത്തിലേക്ക് "unsized" ആകാവുന്ന തരങ്ങൾ.
///
/// ഉദാഹരണത്തിന്, വലുപ്പത്തിലുള്ള അറേ തരം `[i8; 2]` `Unsize<[i8]>`, `Unsize<dyn fmt::Debug>` എന്നിവ നടപ്പിലാക്കുന്നു.
///
/// `Unsize`-ന്റെ എല്ലാ നടപ്പാക്കലുകളും കംപൈലർ സ്വപ്രേരിതമായി നൽകുന്നു.
///
/// `Unsize` ഇതിനായി നടപ്പിലാക്കുന്നു:
///
/// - `[T; N]` `Unsize<[T]>` ആണ്
/// - `T` `T: Trait` ആയിരിക്കുമ്പോൾ `Unsize<dyn Trait>` ആണ്
/// - `Foo<..., T, ...>` എങ്കിൽ `Unsize<Foo<..., U, ...>>` ആണ്:
///   - `T: Unsize<U>`
///   - Foo ഒരു ഘടനയാണ്
///   - `Foo`-ന്റെ അവസാന ഫീൽഡിന് മാത്രമേ `T` ഉൾപ്പെടുന്ന ഒരു തരം ഉള്ളൂ
///   - `T` മറ്റേതെങ്കിലും ഫീൽ‌ഡുകളുടെ ഭാഗമല്ല
///   - `Bar<T>: Unsize<Bar<U>>`, `Foo`-ന്റെ അവസാന ഫീൽഡിന് `Bar<T>` തരം ഉണ്ടെങ്കിൽ
///
/// `Unsize` [`Rc`] പോലുള്ള "user-defined" കണ്ടെയ്‌നറുകൾ ചലനാത്മക വലുപ്പത്തിലുള്ള തരങ്ങൾ ഉൾക്കൊള്ളാൻ അനുവദിക്കുന്നതിന് [`ops::CoerceUnsized`]-നൊപ്പം ഉപയോഗിക്കുന്നു.
/// കൂടുതൽ വിവരങ്ങൾക്ക് [DST coercion RFC][RFC982], [the nomicon entry on coercion][nomicon-coerce] എന്നിവ കാണുക.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// പാറ്റേൺ പൊരുത്തങ്ങളിൽ ഉപയോഗിക്കുന്ന സ്ഥിരാങ്കങ്ങൾക്ക് trait ആവശ്യമാണ്.
///
/// `PartialEq` ഉരുത്തിരിഞ്ഞ ഏത് തരവും ഈ trait സ്വപ്രേരിതമായി നടപ്പിലാക്കുന്നു, അതിന്റെ ടൈപ്പ്-പാരാമീറ്ററുകൾ `Eq` നടപ്പിലാക്കുന്നുണ്ടോ എന്നത് പരിഗണിക്കാതെ *.
///
/// ഒരു `const` ഇനത്തിൽ ഈ trait നടപ്പിലാക്കാത്ത ചില തരം അടങ്ങിയിട്ടുണ്ടെങ്കിൽ, ആ തരം (1.) `PartialEq` നടപ്പിലാക്കില്ല (അതിനർത്ഥം നിരന്തരമായ ആ താരതമ്യ രീതി നൽകില്ല, ഏത് കോഡ് ജനറേഷൻ ലഭ്യമാണെന്ന് അനുമാനിക്കുന്നു), അല്ലെങ്കിൽ (2.) അത് നടപ്പിലാക്കുന്നു * സ്വന്തമായി `PartialEq`-ന്റെ പതിപ്പ് (ഇത് ഘടനാപരമായ-സമത്വ താരതമ്യവുമായി പൊരുത്തപ്പെടുന്നില്ലെന്ന് ഞങ്ങൾ കരുതുന്നു).
///
///
/// മുകളിലുള്ള രണ്ട് സാഹചര്യങ്ങളിൽ, ഒരു പാറ്റേൺ പൊരുത്തത്തിൽ അത്തരമൊരു സ്ഥിരാങ്കത്തിന്റെ ഉപയോഗം ഞങ്ങൾ നിരസിക്കുന്നു.
///
/// ആട്രിബ്യൂട്ട് അധിഷ്ഠിത രൂപകൽപ്പനയിൽ നിന്ന് ഈ trait-ലേക്ക് മാറാൻ പ്രേരിപ്പിച്ച [structural match RFC][RFC1445], [issue 63438] എന്നിവയും കാണുക.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// പാറ്റേൺ പൊരുത്തങ്ങളിൽ ഉപയോഗിക്കുന്ന സ്ഥിരാങ്കങ്ങൾക്ക് trait ആവശ്യമാണ്.
///
/// `Eq` ഉരുത്തിരിഞ്ഞ ഏത് തരവും ഈ trait സ്വപ്രേരിതമായി നടപ്പിലാക്കുന്നു, അതിന്റെ തരം പാരാമീറ്ററുകൾ `Eq` നടപ്പിലാക്കുന്നുണ്ടോ എന്നത് പരിഗണിക്കാതെ *.
///
/// ഞങ്ങളുടെ ടൈപ്പ് സിസ്റ്റത്തിലെ ഒരു പരിമിതിയിൽ പ്രവർത്തിക്കാനുള്ള ഒരു ഹാക്കാണിത്.
///
/// # Background
///
/// പാറ്റേൺ പൊരുത്തങ്ങളിൽ ഉപയോഗിക്കുന്ന തരത്തിലുള്ള കോൺസ്റ്റുകൾക്ക് `#[derive(PartialEq, Eq)]` ആട്രിബ്യൂട്ട് ആവശ്യമാണെന്ന് ഞങ്ങൾ ആഗ്രഹിക്കുന്നു.
///
/// കൂടുതൽ‌അനുയോജ്യമായ ഒരു ലോകത്തിൽ‌, തന്നിരിക്കുന്ന തരം `StructuralPartialEq` trait *,*`Eq` trait എന്നിവ രണ്ടും നടപ്പിലാക്കുന്നുണ്ടോയെന്ന് പരിശോധിച്ചുകൊണ്ട് ഞങ്ങൾക്ക് ആ ആവശ്യകത പരിശോധിക്കാൻ‌കഴിയും.
/// എന്നിരുന്നാലും,*`derive(PartialEq, Eq)`* ചെയ്യുന്ന ADT-കൾ നിങ്ങൾക്ക് ഉണ്ടായിരിക്കാം, മാത്രമല്ല കംപൈലർ സ്വീകരിക്കാൻ ഞങ്ങൾ ആഗ്രഹിക്കുന്ന ഒരു കേസായിരിക്കാം, എന്നിട്ടും സ്ഥിരമായ തരം `Eq` നടപ്പിലാക്കുന്നതിൽ പരാജയപ്പെടുന്നു.
///
/// അതായത്, ഇതുപോലുള്ള ഒരു കേസ്:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (മുകളിലുള്ള കോഡിലെ പ്രശ്നം `Wrap<fn(&())>` `PartialEq` അല്ലെങ്കിൽ `Eq` നടപ്പിലാക്കുന്നില്ല എന്നതാണ്, കാരണം `for <'a> fn(&'a _)` does not implement those traits.)
///
/// അതിനാൽ, ഞങ്ങൾക്ക് `StructuralPartialEq`, വെറും `Eq` എന്നിവയ്‌ക്കായുള്ള നിഷ്കളങ്കമായ പരിശോധനയെ ആശ്രയിക്കാൻ കഴിയില്ല.
///
/// ഇത് പരിഹരിക്കുന്നതിനുള്ള ഒരു ഹാക്ക് എന്ന നിലയിൽ, ഞങ്ങൾ ഓരോരുത്തരും (`#[derive(PartialEq)]`, `#[derive(Eq)]`) എന്നിവയിൽ നിന്ന് കുത്തിവച്ച രണ്ട് വ്യത്യസ്ത traits ഉപയോഗിക്കുന്നു, ഒപ്പം ഘടനാപരമായ-പൊരുത്ത പരിശോധനയുടെ ഭാഗമായി ഇവ രണ്ടും ഉണ്ടോയെന്ന് പരിശോധിക്കുക.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// ബിറ്റുകൾ‌പകർ‌ത്തിക്കൊണ്ട് മൂല്യങ്ങൾ‌തനിപ്പകർ‌പ്പിക്കാൻ‌കഴിയുന്ന തരങ്ങൾ‌.
///
/// സ്ഥിരസ്ഥിതിയായി, വേരിയബിൾ ബൈൻഡിംഗുകൾക്ക് 'മൂവ് സെമാന്റിക്‌സ്' ഉണ്ട്.മറ്റൊരു വാക്കിൽ:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` `y`-ലേക്ക് നീക്കി, അതിനാൽ ഉപയോഗിക്കാൻ കഴിയില്ല
///
/// // println! ("{: ?}", x);//പിശക്: നീക്കിയ മൂല്യത്തിന്റെ ഉപയോഗം
/// ```
///
/// എന്നിരുന്നാലും, ഒരു തരം `Copy` നടപ്പിലാക്കുകയാണെങ്കിൽ, അതിന് 'കോപ്പി സെമാന്റിക്‌സ്' ഉണ്ട്:
///
/// ```
/// // ഞങ്ങൾക്ക് ഒരു `Copy` നടപ്പിലാക്കൽ നേടാനാകും.
/// // `Clone` ഇത് ആവശ്യമാണ്, കാരണം ഇത് `Copy`-ന്റെ സൂപ്പർട്രെയിറ്റ് ആണ്.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` `x`-ന്റെ ഒരു പകർപ്പാണ്
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// ഈ രണ്ട് ഉദാഹരണങ്ങളിൽ, അസൈൻമെന്റിനുശേഷം നിങ്ങൾക്ക് `x` ആക്സസ് ചെയ്യാൻ അനുവാദമുണ്ടോ എന്നതാണ് വ്യത്യാസം.
/// വികസിതമായ ഒരു പകർപ്പും നീക്കവും മെമ്മറിയിൽ ബിറ്റുകൾ പകർത്തുന്നതിന് കാരണമാകാം, എന്നിരുന്നാലും ഇത് ചിലപ്പോൾ ഒപ്റ്റിമൈസ് ചെയ്യപ്പെടും.
///
/// ## എനിക്ക് എങ്ങനെ `Copy` നടപ്പിലാക്കാൻ കഴിയും?
///
/// നിങ്ങളുടെ തരത്തിൽ `Copy` നടപ്പിലാക്കാൻ രണ്ട് വഴികളുണ്ട്.`derive` ഉപയോഗിക്കുന്നതാണ് ഏറ്റവും ലളിതം:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// നിങ്ങൾക്ക് സ്വമേധയാ `Copy`, `Clone` എന്നിവ നടപ്പിലാക്കാനും കഴിയും:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// ഇവ രണ്ടും തമ്മിൽ ഒരു ചെറിയ വ്യത്യാസമുണ്ട്: `derive` സ്ട്രാറ്റജി ടൈപ്പ് പാരാമീറ്ററുകളിൽ ബന്ധിപ്പിച്ചിരിക്കുന്ന `Copy` ഉം സ്ഥാപിക്കും, അത് എല്ലായ്പ്പോഴും ആവശ്യമില്ല.
///
/// ## `Copy` ഉം `Clone` ഉം തമ്മിലുള്ള വ്യത്യാസം എന്താണ്?
///
/// പകർപ്പുകൾ പരോക്ഷമായി സംഭവിക്കുന്നു, ഉദാഹരണത്തിന് ഒരു അസൈൻമെന്റിന്റെ ഭാഗമായി `y = x`.`Copy`-ന്റെ സ്വഭാവം അമിതഭാരമുള്ളതല്ല;ഇത് എല്ലായ്പ്പോഴും ലളിതമായ ബിറ്റ് തിരിച്ചുള്ള പകർപ്പാണ്.
///
/// ക്ലോണിംഗ് ഒരു വ്യക്തമായ പ്രവർത്തനമാണ്, `x.clone()`.[`Clone`] നടപ്പിലാക്കുന്നതിലൂടെ മൂല്യങ്ങൾ‌സുരക്ഷിതമായി തനിപ്പകർ‌പ്പിക്കുന്നതിന് ആവശ്യമായ ഏത് തരം നിർ‌ദ്ദിഷ്‌ട സ്വഭാവവും നൽകാൻ‌കഴിയും.
/// ഉദാഹരണത്തിന്, [`String`]-നായി [`Clone`] നടപ്പിലാക്കുന്നതിന് കൂമ്പാരത്തിൽ പോയിന്റ്-ടു സ്ട്രിംഗ് ബഫർ പകർത്തേണ്ടതുണ്ട്.
/// എക്സ് 00 എക്സ് മൂല്യങ്ങളുടെ ലളിതമായ ബിറ്റ്വൈസ് പകർപ്പ് പോയിന്റർ പകർത്തുക മാത്രമാണ് ചെയ്യുന്നത്, ഇത് ഇരട്ട ഫ്രീ ലൈനിലേക്ക് നയിക്കും.
/// ഇക്കാരണത്താൽ, [`String`] [`Clone`] ആണെങ്കിലും `Copy` അല്ല.
///
/// [`Clone`] `Copy`-ന്റെ ഒരു സൂപ്പർട്രെയിറ്റാണ്, അതിനാൽ `Copy` ഉള്ളതെല്ലാം [`Clone`] നടപ്പിലാക്കണം.
/// ഒരു തരം `Copy` ആണെങ്കിൽ, അതിന്റെ [`Clone`] നടപ്പിലാക്കലിന് `*self` മാത്രം നൽകേണ്ടതുണ്ട് (മുകളിലുള്ള ഉദാഹരണം കാണുക).
///
/// ## എപ്പോഴാണ് എന്റെ തരം `Copy` ആകുക?
///
/// ഒരു തരത്തിന് അതിന്റെ എല്ലാ ഘടകങ്ങളും `Copy` നടപ്പിലാക്കുകയാണെങ്കിൽ `Copy` നടപ്പിലാക്കാൻ കഴിയും.ഉദാഹരണത്തിന്, ഈ സ്ട്രക്റ്റ് `Copy` ആകാം:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// ഒരു സ്ട്രക്റ്റ് `Copy` ആകാം, [`i32`] `Copy` ആണ്, അതിനാൽ `Point` `Copy` ആകാൻ യോഗ്യമാണ്.
/// നേരെമറിച്ച്, പരിഗണിക്കുക
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// `PointList` ന് `Copy` നടപ്പിലാക്കാൻ കഴിയില്ല, കാരണം [`Vec<T>`] `Copy` അല്ല.ഞങ്ങൾ ഒരു `Copy` നടപ്പിലാക്കാൻ ശ്രമിക്കുകയാണെങ്കിൽ, ഞങ്ങൾക്ക് ഒരു പിശക് ലഭിക്കും:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// പങ്കിട്ട റഫറൻസുകൾ (`&T`) ഉം `Copy` ആണ്, അതിനാൽ ഒരു തരം `Copy` ആകാം, അത് `T` തരങ്ങളുടെ പങ്കിട്ട റഫറൻസുകൾ കൈവശം വച്ചിരിക്കുമ്പോഴും * `Copy` അല്ല.
/// എക്സ് 100 എക്സ് നടപ്പിലാക്കാൻ കഴിയുന്ന ഇനിപ്പറയുന്ന സ്ട്രക്റ്റ് പരിഗണിക്കുക, കാരണം ഇത് മുകളിൽ നിന്ന് ഞങ്ങളുടെ 'കോപ്പി അല്ലാത്ത' തരം എക്സ് 01 എക്സിലേക്ക് *പങ്കിട്ട റഫറൻസ്* മാത്രമേ ഉള്ളൂ:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## എപ്പോഴാണ് എന്റെ തരം `Copy` ആകാൻ കഴിയാത്തത്?
///
/// ചില തരങ്ങൾ സുരക്ഷിതമായി പകർത്താൻ കഴിയില്ല.ഉദാഹരണത്തിന്, `&mut T` പകർത്തുന്നത് അപരനാമം മാറ്റാവുന്ന റഫറൻസ് സൃഷ്ടിക്കും.
/// [`String`] പകർത്തുന്നത് [`സ്ട്രിംഗ്`] ന്റെ ബഫർ കൈകാര്യം ചെയ്യുന്നതിനുള്ള ഉത്തരവാദിത്തത്തെ തനിപ്പകർപ്പാക്കുകയും ഇരട്ട സ .ജന്യത്തിലേക്ക് നയിക്കുകയും ചെയ്യും.
///
/// രണ്ടാമത്തെ കേസ് സാമാന്യവൽക്കരിക്കുന്നതിലൂടെ, [`Drop`] നടപ്പിലാക്കുന്ന ഏത് തരവും `Copy` ആകാൻ കഴിയില്ല, കാരണം ഇത് സ്വന്തം [`size_of::<T>`] ബൈറ്റുകൾക്ക് പുറമെ ചില വിഭവങ്ങൾ കൈകാര്യം ചെയ്യുന്നു.
///
/// `കോപ്പി` അല്ലാത്ത ഡാറ്റ അടങ്ങിയിരിക്കുന്ന ഒരു സ്ട്രക്റ്റ് അല്ലെങ്കിൽ എനുമിൽ നിങ്ങൾ `Copy` നടപ്പിലാക്കാൻ ശ്രമിച്ചാൽ, നിങ്ങൾക്ക് [E0204] പിശക് ലഭിക്കും.
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## എപ്പോൾ * എന്റെ തരം `Copy` ആയിരിക്കണം?
///
/// പൊതുവായി പറഞ്ഞാൽ, നിങ്ങളുടെ തരം _can_ `Copy` നടപ്പിലാക്കുകയാണെങ്കിൽ, അത് ചെയ്യണം.
/// എന്നിരുന്നാലും, `Copy` നടപ്പിലാക്കുന്നത് നിങ്ങളുടെ തരത്തിലുള്ള പൊതു API യുടെ ഭാഗമാണെന്ന് ഓർമ്മിക്കുക.
/// future-ൽ തരം നോൺ-കോപ്പി` ആയി മാറിയാൽ, എപി‌ഐ മാറ്റം ഒഴിവാക്കുന്നതിനായി, ഇപ്പോൾ എക്സ് 00 എക്സ് നടപ്പാക്കൽ ഒഴിവാക്കുന്നത് വിവേകപൂർവ്വം ആയിരിക്കും.
///
/// ## അധിക നടപ്പിലാക്കുന്നവർ
///
/// [implementors listed below][impls] ന് പുറമേ, ഇനിപ്പറയുന്ന തരങ്ങളും `Copy` നടപ്പിലാക്കുന്നു:
///
/// * പ്രവർത്തന ഇന തരങ്ങൾ (അതായത്, ഓരോ പ്രവർത്തനത്തിനും നിർവചിച്ചിരിക്കുന്ന വ്യത്യസ്ത തരം)
/// * ഫംഗ്ഷൻ പോയിന്റർ തരങ്ങൾ (ഉദാ. `fn() -> i32`)
/// * ഇന തരവും `Copy` (ഉദാ. `[i32; 123456]`) നടപ്പിലാക്കുകയാണെങ്കിൽ, എല്ലാ വലുപ്പങ്ങൾക്കും അറേ തരങ്ങൾ
/// * ടുപ്പിൾ തരങ്ങൾ, ഓരോ ഘടകവും `Copy` (ഉദാ. `()`, `(i32, bool)`) നടപ്പിലാക്കുകയാണെങ്കിൽ
/// * അടയ്ക്കൽ തരങ്ങൾ, അവ പരിസ്ഥിതിയിൽ നിന്ന് ഒരു മൂല്യവും പിടിച്ചെടുക്കുകയോ അല്ലെങ്കിൽ പിടിച്ചെടുത്ത എല്ലാ മൂല്യങ്ങളും `Copy` സ്വയം നടപ്പിലാക്കുകയോ ചെയ്താൽ.
///   പങ്കിട്ട റഫറൻസ് ഉപയോഗിച്ച് പിടിച്ചെടുത്ത വേരിയബിളുകൾ എല്ലായ്പ്പോഴും `Copy` നടപ്പിലാക്കുന്നു (റഫറൻസ് ഇല്ലെങ്കിലും), മ്യൂട്ടബിൾ റഫറൻസ് പിടിച്ചെടുത്ത വേരിയബിളുകൾ ഒരിക്കലും `Copy` നടപ്പിലാക്കില്ല.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) തൃപ്തികരമല്ലാത്ത ലൈഫ് ടൈം പരിധികൾ കാരണം `Copy` നടപ്പിലാക്കാത്ത ഒരു തരം പകർത്താൻ ഇത് അനുവദിക്കുന്നു (`A<'static>: Copy`, `A<'_>: Clone` എന്നിവ മാത്രം ഉള്ളപ്പോൾ `A<'_>` പകർത്തുന്നു).
// സ്റ്റാൻഡേർഡ് ലൈബ്രറിയിൽ ഇതിനകം തന്നെ `Copy`-ൽ നിലവിലുള്ള കുറച്ച് സ്പെഷ്യലൈസേഷനുകൾ ഉള്ളതിനാൽ മാത്രമാണ് ഞങ്ങൾക്ക് ഇപ്പോൾ ഈ ആട്രിബ്യൂട്ട് ഉള്ളത്, ഈ പെരുമാറ്റം സുരക്ഷിതമായി സൂക്ഷിക്കാൻ ഇപ്പോൾ ഒരു മാർഗവുമില്ല.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// trait `Copy`-ന്റെ ഒരു impl സൃഷ്ടിക്കുന്ന മാക്രോ ഡെറിവ് ചെയ്യുക.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// ത്രെഡുകൾക്കിടയിൽ റഫറൻസുകൾ പങ്കിടുന്നത് സുരക്ഷിതമായ തരങ്ങൾ.
///
/// കംപൈലർ ഉചിതമാണെന്ന് നിർണ്ണയിക്കുമ്പോൾ ഈ trait യാന്ത്രികമായി നടപ്പിലാക്കുന്നു.
///
/// കൃത്യമായ നിർവചനം ഇതാണ്: `T` ഒരു തരം [`Sync`] ആണെങ്കിൽ `&T` [`Send`] ആണെങ്കിൽ മാത്രം.
/// മറ്റൊരു വിധത്തിൽ പറഞ്ഞാൽ, ത്രെഡുകൾക്കിടയിൽ `&T` റഫറൻസുകൾ കൈമാറുമ്പോൾ [undefined behavior][ub] (ഡാറ്റാ റേസുകൾ ഉൾപ്പെടെ) സാധ്യതയില്ലെങ്കിൽ.
///
/// ഒരാൾ പ്രതീക്ഷിക്കുന്നതുപോലെ, പ്രാകൃത തരങ്ങളായ [`u8`], [`f64`] എന്നിവയെല്ലാം [`Sync`] ആണ്, അതുപോലെ തന്നെ ട്യൂപ്പിൾസ്, സ്ട്രക്റ്റുകൾ, enums എന്നിവ പോലുള്ള ലളിതമായ അഗ്രഗേറ്റ് തരങ്ങളും.
/// അടിസ്ഥാന [`Sync`] തരങ്ങളുടെ കൂടുതൽ ഉദാഹരണങ്ങളിൽ `&T` പോലുള്ള "immutable" തരങ്ങളും [`Box<T>`][box], [`Vec<T>`][vec] പോലുള്ള ലളിതമായ പാരമ്പര്യമായി പരിവർത്തനം ചെയ്യാവുന്നവയും മറ്റ് ശേഖരണ തരങ്ങളും ഉൾപ്പെടുന്നു.
///
/// (ജനറിക് പാരാമീറ്ററുകൾ അവയുടെ കണ്ടെയ്നർ [`സമന്വയം`] ആകുന്നതിന് [`Sync`] ആയിരിക്കണം.)
///
/// നിർവചനത്തിന്റെ അൽപ്പം ആശ്ചര്യകരമായ പരിണതഫലമായി, `&mut T` എന്നത് `Sync` ആണ് (`T` `Sync` ആണെങ്കിൽ) അത് സമന്വയിപ്പിക്കാത്ത മ്യൂട്ടേഷൻ നൽകുമെന്ന് തോന്നുന്നുവെങ്കിലും.
/// ഒരു പങ്കിട്ട റഫറൻസിന് (അതായത്, `& &mut T`) പിന്നിലുള്ള ഒരു മ്യൂട്ടബിൾ റഫറൻസ് ഒരു `& &T` പോലെ വായിക്കാൻ മാത്രമായി മാറുന്നു എന്നതാണ് തന്ത്രം.
/// അതിനാൽ ഒരു ഡാറ്റ റേസിന് അപകടസാധ്യതയില്ല.
///
/// `Sync` അല്ലാത്ത തരങ്ങളാണ് "interior mutability", ത്രെഡ്-സുരക്ഷിതമല്ലാത്ത രൂപത്തിൽ [`Cell`][cell], [`RefCell`][refcell] എന്നിവ.
/// മാറ്റമില്ലാത്തതും പങ്കിട്ടതുമായ ഒരു റഫറൻസിലൂടെ പോലും അവയുടെ ഉള്ളടക്കങ്ങൾ പരിവർത്തനം ചെയ്യാൻ ഈ തരങ്ങൾ അനുവദിക്കുന്നു.
/// ഉദാഹരണത്തിന്, [`Cell<T>`][cell]-ലെ `set` രീതി `&self` എടുക്കുന്നു, അതിനാൽ ഇതിന് ഒരു പങ്കിട്ട റഫറൻസ് [`&Cell<T>`][cell] മാത്രം ആവശ്യമാണ്.
/// രീതി സമന്വയമൊന്നും നടത്തുന്നില്ല, അതിനാൽ [`Cell`][cell] `Sync` ആകാൻ പാടില്ല.
///
/// `സിങ്ക്` അല്ലാത്തതിന്റെ മറ്റൊരു ഉദാഹരണം റഫറൻസ്-കൗണ്ടിംഗ് പോയിന്റർ [`Rc`][rc] ആണ്.
/// ഏതെങ്കിലും റഫറൻസ് [`&Rc<T>`][rc] നൽകിയാൽ, നിങ്ങൾക്ക് ഒരു പുതിയ [`Rc<T>`][rc] ക്ലോൺ ചെയ്യാൻ കഴിയും, റഫറൻസ് എണ്ണം നോൺ-ആറ്റോമിക് രീതിയിൽ പരിഷ്കരിക്കുന്നു.
///
/// ഒരാൾക്ക് ത്രെഡ്-സുരക്ഷിത ഇന്റീരിയർ മ്യൂട്ടബിലിറ്റി ആവശ്യമുള്ള സന്ദർഭങ്ങളിൽ, Rust, [atomic data types], ഒപ്പം [`sync::Mutex`][mutex], [`sync::RwLock`][rwlock] എന്നിവ വഴി വ്യക്തമായ ലോക്കിംഗും നൽകുന്നു.
/// ഏതൊരു മ്യൂട്ടേഷനും ഡാറ്റ റേസുകൾക്ക് കാരണമാകില്ലെന്ന് ഈ തരങ്ങൾ ഉറപ്പാക്കുന്നു, അതിനാൽ തരങ്ങൾ `Sync` ആണ്.
/// അതുപോലെ, [`sync::Arc`][arc], [`Rc`][rc]-ന്റെ ഒരു ത്രെഡ്-സുരക്ഷിത അനലോഗ് നൽകുന്നു.
///
/// ഇന്റീരിയർ മ്യൂട്ടബിലിറ്റി ഉള്ള ഏത് തരവും value(s) ന് ചുറ്റുമുള്ള [`cell::UnsafeCell`][unsafecell] റാപ്പർ ഉപയോഗിക്കണം, അത് പങ്കിട്ട റഫറൻസിലൂടെ പരിവർത്തനം ചെയ്യാനാകും.
/// ഇത് ചെയ്യുന്നതിൽ പരാജയപ്പെടുന്നത് [undefined behavior][ub] ആണ്.
/// ഉദാഹരണത്തിന്, [`ട്രാൻസ്മിറ്റ്`][ട്രാൻസ്മിറ്റ്]-ഇംഗ് `&T` മുതൽ `&mut T` വരെ അസാധുവാണ്.
///
/// `Sync` നെക്കുറിച്ചുള്ള കൂടുതൽ വിവരങ്ങൾക്ക് [the Nomicon][nomicon-send-and-sync] കാണുക.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): ബീറ്റയിലെ `rustc_on_unimplemented` ലാൻ‌ഡുകളിൽ‌കുറിപ്പുകൾ‌ചേർ‌ക്കുന്നതിന് ഒരിക്കൽ‌പിന്തുണ നൽ‌കിയാൽ‌, ആവശ്യകത ശൃംഖലയിൽ‌എവിടെയെങ്കിലും ഒരു അടയ്‌ക്കൽ‌ഉണ്ടോയെന്ന് പരിശോധിക്കുന്നതിന് ഇത് വിപുലീകരിച്ചു, അത്തരം (#48534) പോലെ വിപുലീകരിക്കുക:
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// "act like"-ന് ഒരു `T` സ്വന്തമായ കാര്യങ്ങൾ അടയാളപ്പെടുത്താൻ ഉപയോഗിക്കുന്ന സീറോ വലുപ്പത്തിലുള്ള തരം.
///
/// നിങ്ങളുടെ തരത്തിലേക്ക് ഒരു `PhantomData<T>` ഫീൽഡ് ചേർക്കുന്നത് കംപൈലറോട് നിങ്ങളുടെ തരം `T` തരത്തിന്റെ മൂല്യം സംഭരിക്കുന്നതുപോലെ പ്രവർത്തിക്കുന്നുവെന്ന് പറയുന്നു, അത് ശരിക്കും ഇല്ലെങ്കിലും.
/// ചില സുരക്ഷാ സവിശേഷതകൾ കണക്കാക്കുമ്പോൾ ഈ വിവരങ്ങൾ ഉപയോഗിക്കുന്നു.
///
/// `PhantomData<T>` എങ്ങനെ ഉപയോഗിക്കാമെന്നതിനെക്കുറിച്ചുള്ള കൂടുതൽ വിശദമായ വിശദീകരണത്തിന്, [the Nomicon](../../nomicon/phantom-data.html) കാണുക.
///
/// # ഭയാനകമായ കുറിപ്പ്
///
/// അവ രണ്ടിനും ഭയപ്പെടുത്തുന്ന പേരുകളുണ്ടെങ്കിലും, `PhantomData`, 'ഫാന്റം തരങ്ങൾ' എന്നിവ ബന്ധപ്പെട്ടിരിക്കുന്നു, പക്ഷേ സമാനമല്ല.ഫാന്റം തരം പാരാമീറ്റർ എന്നത് ഒരിക്കലും ഉപയോഗിക്കാത്ത ഒരു തരം പാരാമീറ്ററാണ്.
/// Rust-ൽ, ഇത് പലപ്പോഴും കംപൈലറിന് പരാതിപ്പെടാൻ ഇടയാക്കുന്നു, കൂടാതെ `PhantomData` വഴി "dummy" ഉപയോഗം ചേർക്കുന്നതാണ് പരിഹാരം.
///
/// # Examples
///
/// ## ഉപയോഗിക്കാത്ത ആജീവനാന്ത പാരാമീറ്ററുകൾ
///
/// ചില സുരക്ഷിതമല്ലാത്ത കോഡിന്റെ ഭാഗമായി, ഉപയോഗിക്കാത്ത ആജീവനാന്ത പാരാമീറ്റർ ഉള്ള ഒരു ഘടനയാണ് `PhantomData`-നുള്ള ഏറ്റവും സാധാരണമായ ഉപയോഗ കേസ്.
/// ഉദാഹരണത്തിന്, എക്സ് 100 എക്സ് തരം രണ്ട് പോയിന്ററുകളുള്ള ഒരു സ്ട്രക്റ്റ് എക്സ് 01 എക്സ് ഇവിടെയുണ്ട്, ഇത് എവിടെയെങ്കിലും ഒരു അറേയിലേക്ക് വിരൽ ചൂണ്ടുന്നു:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// `'a` എന്ന ആജീവനാന്തത്തിന് മാത്രമേ അടിസ്ഥാന ഡാറ്റ സാധുതയുള്ളൂ എന്നതാണ് ഉദ്ദേശ്യം, അതിനാൽ `Slice` `'a`-നെ മറികടക്കാൻ പാടില്ല.
/// എന്നിരുന്നാലും, `'a` ആജീവനാന്ത ഉപയോഗങ്ങളൊന്നും ഇല്ലാത്തതിനാൽ ഈ ഉദ്ദേശ്യം കോഡിൽ പ്രകടിപ്പിച്ചിട്ടില്ല, അതിനാൽ ഇത് ഏത് ഡാറ്റയ്ക്ക് ബാധകമാണെന്ന് വ്യക്തമല്ല.
/// *`Slice` ഘടനയിൽ ഒരു റഫറൻസ് `&'a T` അടങ്ങിയിരിക്കുന്നതുപോലെ* പ്രവർത്തിക്കാൻ കംപൈലറോട് പറഞ്ഞുകൊണ്ട് ഞങ്ങൾക്ക് ഇത് ശരിയാക്കാം:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// ഇതിനും `T: 'a` എന്ന വ്യാഖ്യാനം ആവശ്യമാണ്, ഇത് `T`-ലെ ഏതെങ്കിലും റഫറൻസുകൾ ആജീവനാന്ത `'a`-ന് സാധുതയുള്ളതാണെന്ന് സൂചിപ്പിക്കുന്നു.
///
/// ഒരു `Slice` സമാരംഭിക്കുമ്പോൾ നിങ്ങൾ `phantom` ഫീൽഡിനായി `PhantomData` മൂല്യം നൽകുന്നു:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## ഉപയോഗിക്കാത്ത തരം പാരാമീറ്ററുകൾ
///
/// നിങ്ങൾ‌ക്ക് ഉപയോഗിക്കാത്ത തരം പാരാമീറ്ററുകൾ‌ചിലപ്പോഴൊക്കെ സംഭവിക്കുന്നു, അത് ഒരു സ്ട്രക്റ്റ് എക്സ് 00 എക്സ് ഏത് തരം ഡാറ്റയാണെന്ന് സൂചിപ്പിക്കുന്നു, ആ ഡാറ്റ സ്ട്രക്റ്റിൽ‌തന്നെ യഥാർത്ഥത്തിൽ കണ്ടെത്തിയില്ലെങ്കിലും.
/// [FFI] ഉപയോഗിച്ച് ഇത് ഉണ്ടാകുന്ന ഒരു ഉദാഹരണം ഇതാ.
/// വിവിധ തരം Rust മൂല്യങ്ങളെ സൂചിപ്പിക്കുന്നതിന് വിദേശ ഇന്റർഫേസ് `*mut ()` തരം ഹാൻഡിലുകൾ ഉപയോഗിക്കുന്നു.
/// സ്ട്രക്റ്റ് `ExternalResource`-ലെ ഒരു ഫാന്റം തരം പാരാമീറ്റർ ഉപയോഗിച്ച് ഞങ്ങൾ Rust തരം ട്രാക്കുചെയ്യുന്നു, അത് ഒരു ഹാൻഡിൽ പൊതിയുന്നു.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## ഉടമസ്ഥാവകാശവും ഡ്രോപ്പ് ചെക്കും
///
/// `PhantomData<T>` തരം ഒരു ഫീൽഡ് ചേർക്കുന്നത് നിങ്ങളുടെ തരം `T` തരത്തിന്റെ ഡാറ്റയാണെന്ന് സൂചിപ്പിക്കുന്നു.നിങ്ങളുടെ തരം ഉപേക്ഷിക്കുമ്പോൾ, അത് `T` തരത്തിന്റെ ഒന്നോ അതിലധികമോ സംഭവങ്ങൾ ഉപേക്ഷിച്ചേക്കാം എന്നാണ് ഇത് സൂചിപ്പിക്കുന്നത്.
/// ഇത് Rust കംപൈലറിന്റെ [drop check] വിശകലനത്തെ ബാധിക്കുന്നു.
///
/// നിങ്ങളുടെ സ്ട്രക്റ്റ് വാസ്തവത്തിൽ `T` തരത്തിന്റെ ഡാറ്റ *സ്വന്തമാക്കിയിട്ടില്ലെങ്കിൽ, ഉടമസ്ഥാവകാശം സൂചിപ്പിക്കാതിരിക്കാൻ `PhantomData<&'a T>` (ideally) അല്ലെങ്കിൽ `PhantomData<* const T>` പോലുള്ള ഒരു റഫറൻസ് തരം ഉപയോഗിക്കുന്നതാണ് നല്ലത് (ആജീവനാന്തം ബാധകമല്ലെങ്കിൽ).
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// കംപൈലർ-ആന്തരിക trait, enum വിവേചനത്തിന്റെ തരം സൂചിപ്പിക്കാൻ ഉപയോഗിക്കുന്നു.
///
/// ഈ trait എല്ലാ തരത്തിനും യാന്ത്രികമായി നടപ്പിലാക്കുന്നു, മാത്രമല്ല [`mem::Discriminant`]-ലേക്ക് ഒരു ഗ്യാരന്റിയും ചേർക്കുന്നില്ല.
/// `DiscriminantKind::Discriminant` നും `mem::Discriminant` നും ഇടയിൽ പരിവർത്തനം ചെയ്യുന്നത് **നിർവചിക്കപ്പെടാത്ത പെരുമാറ്റം** ആണ്.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// വിവേചനത്തിന്റെ തരം, അത് `mem::Discriminant` ന് ആവശ്യമായ trait bounds നെ തൃപ്തിപ്പെടുത്തണം.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// ഒരു തരത്തിൽ ആന്തരികമായി ഏതെങ്കിലും `UnsafeCell` അടങ്ങിയിട്ടുണ്ടോ എന്ന് നിർണ്ണയിക്കാൻ കംപൈലർ-ആന്തരിക trait ഉപയോഗിക്കുന്നു, പക്ഷേ ഒരു വ്യതിചലനത്തിലൂടെയല്ല.
///
/// ഉദാഹരണത്തിന്, ആ തരത്തിലുള്ള ഒരു `static` വായന-മാത്രം സ്റ്റാറ്റിക് മെമ്മറിയിലോ റൈറ്റബിൾ സ്റ്റാറ്റിക് മെമ്മറിയിലോ സ്ഥാപിച്ചിട്ടുണ്ടോ എന്നതിനെ ഇത് ബാധിക്കുന്നു.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// പിൻ ചെയ്തതിനുശേഷം സുരക്ഷിതമായി നീക്കാൻ കഴിയുന്ന തരങ്ങൾ.
///
/// Rust ന് തന്നെ സ്ഥാവര തരങ്ങളെക്കുറിച്ച് ഒരു ധാരണയുമില്ല, മാത്രമല്ല നീക്കങ്ങൾ (ഉദാ. അസൈൻമെന്റ് അല്ലെങ്കിൽ [`mem::replace`] വഴി) എല്ലായ്പ്പോഴും സുരക്ഷിതമാണെന്ന് കരുതുന്നു.
///
/// ടൈപ്പ് സിസ്റ്റത്തിലൂടെയുള്ള നീക്കങ്ങൾ തടയുന്നതിന് പകരം [`Pin`][Pin] തരം ഉപയോഗിക്കുന്നു.[`Pin<P<T>>`][Pin] റാപ്പറിൽ പൊതിഞ്ഞ പോയിന്ററുകൾ `P<T>` പുറത്തേക്ക് നീക്കാൻ കഴിയില്ല.
/// പിൻ ചെയ്യുന്നതിനെക്കുറിച്ചുള്ള കൂടുതൽ വിവരങ്ങൾക്ക് [`pin` module] ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// `T`-നായി `Unpin` trait നടപ്പിലാക്കുന്നത് തരം പിൻ ചെയ്യുന്നതിനുള്ള നിയന്ത്രണങ്ങൾ നീക്കംചെയ്യുന്നു, ഇത് [`mem::replace`]-നെ [`Pin<P<T>>`][Pin]-ൽ നിന്ന് [`Pin<P<T>>`][Pin]-ൽ നിന്ന് [`mem::replace`] പോലുള്ള ഫംഗ്ഷനുകൾ ഉപയോഗിച്ച് നീക്കാൻ അനുവദിക്കുന്നു.
///
///
/// `Unpin` പിൻ ചെയ്യാത്ത ഡാറ്റയ്‌ക്ക് ഒരു പരിണതഫലവുമില്ല.
/// പ്രത്യേകിച്ചും, [`mem::replace`] സന്തോഷത്തോടെ `!Unpin` ഡാറ്റ നീക്കുന്നു (ഇത് `T: Unpin` ആയിരിക്കുമ്പോൾ മാത്രമല്ല, ഏത് `&mut T`-നും വേണ്ടി പ്രവർത്തിക്കുന്നു).
/// എന്നിരുന്നാലും, നിങ്ങൾക്ക് ഒരു [`Pin<P<T>>`][Pin]-നുള്ളിൽ പൊതിഞ്ഞ ഡാറ്റയിൽ [`mem::replace`] ഉപയോഗിക്കാൻ കഴിയില്ല, കാരണം നിങ്ങൾക്ക് ആവശ്യമായ `&mut T` നേടാൻ കഴിയില്ല, കൂടാതെ *അതാണ്* ഈ സിസ്റ്റം പ്രവർത്തിക്കുന്നത്.
///
/// ഉദാഹരണത്തിന്, `Unpin` നടപ്പിലാക്കുന്ന തരങ്ങളിൽ മാത്രമേ ഇത് ചെയ്യാൻ കഴിയൂ:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // `mem::replace`-ലേക്ക് വിളിക്കാൻ ഞങ്ങൾക്ക് ഒരു മ്യൂട്ടബിൾ റഫറൻസ് ആവശ്യമാണ്.
/// // `Pin::deref_mut` അഭ്യർത്ഥിച്ച് (implicitly) വഴി ഞങ്ങൾക്ക് അത്തരമൊരു റഫറൻസ് നേടാൻ കഴിയും, പക്ഷേ `String` `Unpin` നടപ്പിലാക്കുന്നതിനാൽ മാത്രമേ ഇത് സാധ്യമാകൂ.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// ഈ trait മിക്കവാറും എല്ലാ തരത്തിനും സ്വപ്രേരിതമായി നടപ്പിലാക്കുന്നു.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// `Unpin` നടപ്പിലാക്കാത്ത ഒരു മാർക്കർ തരം.
///
/// ഒരു തരത്തിൽ ഒരു `PhantomPinned` അടങ്ങിയിട്ടുണ്ടെങ്കിൽ, അത് സ്ഥിരസ്ഥിതിയായി `Unpin` നടപ്പിലാക്കില്ല.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// പ്രാകൃത തരങ്ങൾക്കായി `Copy` നടപ്പിലാക്കുന്നു.
///
/// Rust-ൽ വിവരിക്കാൻ കഴിയാത്ത നടപ്പാക്കലുകൾ `rustc_trait_selection`-ൽ `traits::SelectionContext::copy_clone_conditions()`-ൽ നടപ്പിലാക്കുന്നു.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// പങ്കിട്ട റഫറൻ‌സുകൾ‌പകർ‌ത്താൻ‌കഴിയും, പക്ഷേ മ്യൂട്ടബിൾ‌റഫറൻ‌സുകൾ‌ക്ക് *കഴിയില്ല*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}