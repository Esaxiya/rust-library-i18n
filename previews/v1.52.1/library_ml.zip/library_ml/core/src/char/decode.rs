//! UTF-8 ഒപ്പം UTF-16 ഡീകോഡിംഗ് ഇറ്ററേറ്ററുകളും

use crate::fmt;

use super::from_u32_unchecked;

/// `U16` ന്റെ ഒരു ഇറ്ററേറ്ററിൽ നിന്ന് UTF-16 എൻ‌കോഡുചെയ്‌ത കോഡ് പോയിന്റുകൾ ഡീകോഡ് ചെയ്യുന്ന ഒരു ഇറ്ററേറ്റർ.
#[stable(feature = "decode_utf16", since = "1.9.0")]
#[derive(Clone, Debug)]
pub struct DecodeUtf16<I>
where
    I: Iterator<Item = u16>,
{
    iter: I,
    buf: Option<u16>,
}

/// UTF-16 കോഡ് പോയിന്റുകൾ ഡീകോഡ് ചെയ്യുമ്പോൾ നൽകാവുന്ന ഒരു പിശക്.
#[stable(feature = "decode_utf16", since = "1.9.0")]
#[derive(Debug, Clone, Eq, PartialEq)]
pub struct DecodeUtf16Error {
    code: u16,
}

/// `iter`-ൽ UTF-16 എൻ‌കോഡുചെയ്‌ത കോഡ് പോയിൻറുകൾ‌ക്ക് മുകളിലൂടെ ഒരു ഇറ്ററേറ്റർ‌സൃഷ്‌ടിക്കുന്നു, ജോഡിയാക്കാത്ത സരോഗേറ്റുകളെ `Err`s ആയി നൽകുന്നു.
///
///
/// # Examples
///
/// അടിസ്ഥാന ഉപയോഗം:
///
/// ```
/// use std::char::decode_utf16;
///
/// // 𝄞mus<invalid>ic<invalid>
/// let v = [
///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
/// ];
///
/// assert_eq!(
///     decode_utf16(v.iter().cloned())
///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
///         .collect::<Vec<_>>(),
///     vec![
///         Ok('𝄞'),
///         Ok('m'), Ok('u'), Ok('s'),
///         Err(0xDD1E),
///         Ok('i'), Ok('c'),
///         Err(0xD834)
///     ]
/// );
/// ```
///
/// `Err` ഫലങ്ങൾ മാറ്റിസ്ഥാപിക്കുന്ന പ്രതീകം ഉപയോഗിച്ച് ഒരു നീണ്ട ഡീകോഡർ ലഭിക്കും:
///
/// ```
/// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
///
/// // 𝄞mus<invalid>ic<invalid>
/// let v = [
///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
/// ];
///
/// assert_eq!(
///     decode_utf16(v.iter().cloned())
///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
///        .collect::<String>(),
///     "𝄞mus�ic�"
/// );
/// ```
#[stable(feature = "decode_utf16", since = "1.9.0")]
#[inline]
pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
    DecodeUtf16 { iter: iter.into_iter(), buf: None }
}

#[stable(feature = "decode_utf16", since = "1.9.0")]
impl<I: Iterator<Item = u16>> Iterator for DecodeUtf16<I> {
    type Item = Result<char, DecodeUtf16Error>;

    fn next(&mut self) -> Option<Result<char, DecodeUtf16Error>> {
        let u = match self.buf.take() {
            Some(buf) => buf,
            None => self.iter.next()?,
        };

        if u < 0xD800 || 0xDFFF < u {
            // സുരക്ഷ: ഒരു വാടകക്കാരനല്ല
            Some(Ok(unsafe { from_u32_unchecked(u as u32) }))
        } else if u >= 0xDC00 {
            // പുറകിലുള്ള ഒരു സർറോഗേറ്റ്
            Some(Err(DecodeUtf16Error { code: u }))
        } else {
            let u2 = match self.iter.next() {
                Some(u2) => u2,
                // eof
                None => return Some(Err(DecodeUtf16Error { code: u })),
            };
            if u2 < 0xDC00 || u2 > 0xDFFF {
                // ഒരു സാധുവായ സറോഗേറ്റ് ജോഡിയല്ല, അതിനാൽ അടുത്ത തവണ u2 റെഡ്‌കോഡ് ചെയ്യുന്നതിന് റിവൈൻഡ് ചെയ്യുക.
                //
                self.buf = Some(u2);
                return Some(Err(DecodeUtf16Error { code: u }));
            }

            // എല്ലാം ശരിയാണ്, അതിനാൽ ഇത് ഡീകോഡ് ചെയ്യാൻ അനുവദിക്കുന്നു.
            let c = (((u - 0xD800) as u32) << 10 | (u2 - 0xDC00) as u32) + 0x1_0000;
            // സുരക്ഷ: ഇത് ഒരു നിയമപരമായ യൂണിക്കോഡ് മൂല്യമാണെന്ന് ഞങ്ങൾ പരിശോധിച്ചു
            Some(Ok(unsafe { from_u32_unchecked(c) }))
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let (low, high) = self.iter.size_hint();
        // ഞങ്ങൾ‌പൂർണമായും സാധുവായ സരോജേറ്റുകൾ‌(ചാർ‌ക്ക് 2 ഘടകങ്ങൾ‌) അല്ലെങ്കിൽ‌പൂർണ്ണമായും നോൺ‌സറോഗേറ്റുകൾ‌(ചാർ‌ക്ക് 1 ഘടകം)
        //
        (low / 2, high)
    }
}

impl DecodeUtf16Error {
    /// ഈ പിശകിന് കാരണമായ ജോടിയാക്കാത്ത സറോഗേറ്റ് നൽകുന്നു.
    #[stable(feature = "decode_utf16", since = "1.9.0")]
    pub fn unpaired_surrogate(&self) -> u16 {
        self.code
    }
}

#[stable(feature = "decode_utf16", since = "1.9.0")]
impl fmt::Display for DecodeUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "unpaired surrogate found: {:x}", self.code)
    }
}