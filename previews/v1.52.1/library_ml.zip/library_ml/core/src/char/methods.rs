//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// `char`-ന് ഉണ്ടാകാവുന്ന ഏറ്റവും ഉയർന്ന സാധുവായ കോഡ് പോയിന്റ്.
    ///
    /// ഒരു `char` എന്നത് ഒരു [Unicode Scalar Value] ആണ്, അതിനർത്ഥം ഇത് ഒരു [Code Point] ആണെന്നാണ്, എന്നാൽ ഒരു നിശ്ചിത പരിധിക്കുള്ളിലുള്ളവ മാത്രം.
    /// `MAX` സാധുവായ [Unicode Scalar Value] ആയ ഏറ്റവും ഉയർന്ന സാധുവായ കോഡ് പോയിന്റാണ്.
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` ഡീകോഡിംഗ് പിശകിനെ പ്രതിനിധീകരിക്കുന്നതിന് () യൂണിക്കോഡിൽ ഉപയോഗിക്കുന്നു.
    ///
    /// ഉദാഹരണത്തിന്, [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy)-ന് മോശമായി രൂപപ്പെട്ട UTF-8 ബൈറ്റുകൾ നൽകുമ്പോൾ ഇത് സംഭവിക്കാം.
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// `char`, `str` രീതികളുടെ യൂണികോഡ് ഭാഗങ്ങൾ അടിസ്ഥാനമാക്കിയുള്ള [Unicode](http://www.unicode.org/)-ന്റെ പതിപ്പ്.
    ///
    /// യൂണിക്കോഡിന്റെ പുതിയ പതിപ്പുകൾ പതിവായി പുറത്തിറങ്ങുന്നു, തുടർന്ന് യൂണിക്കോഡിനെ ആശ്രയിച്ച് സ്റ്റാൻഡേർഡ് ലൈബ്രറിയിലെ എല്ലാ രീതികളും അപ്‌ഡേറ്റുചെയ്യുന്നു.
    /// അതിനാൽ ചില `char`, `str` രീതികളുടെ സ്വഭാവവും കാലക്രമേണ ഈ സ്ഥിരമായ മാറ്റത്തിന്റെ മൂല്യവും മാറുന്നു.
    /// ഇത് * ഒരു തകർപ്പൻ മാറ്റമായി കണക്കാക്കില്ല.
    ///
    /// പതിപ്പ് നമ്പറിംഗ് സ്കീം [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) ൽ വിശദീകരിച്ചിരിക്കുന്നു.
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// `iter`-ൽ UTF-16 എൻ‌കോഡുചെയ്‌ത കോഡ് പോയിൻറുകൾ‌ക്ക് മുകളിലൂടെ ഒരു ഇറ്ററേറ്റർ‌സൃഷ്‌ടിക്കുന്നു, ജോഡിയാക്കാത്ത സരോഗേറ്റുകളെ `Err`s ആയി നൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// `Err` ഫലങ്ങൾ മാറ്റിസ്ഥാപിക്കുന്ന പ്രതീകം ഉപയോഗിച്ച് ഒരു നീണ്ട ഡീകോഡർ ലഭിക്കും:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// ഒരു `u32`-നെ `char`-ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// എല്ലാ `ചാർ‌'കളും സാധുവായ [` u32`] കൾ‌ആണെന്നും അവ ഒരെണ്ണം കാസ്റ്റുചെയ്യാമെന്നും ശ്രദ്ധിക്കുക
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// എന്നിരുന്നാലും, വിപരീതം ശരിയല്ല: എല്ലാ സാധുവായ [`u32`] കളും സാധുവായ`ചാർ`കളല്ല.
    /// `from_u32()` ഇൻപുട്ട് ഒരു `char`-ന് സാധുവായ മൂല്യമല്ലെങ്കിൽ `None` നൽകും.
    ///
    /// ഈ പരിശോധനകളെ അവഗണിക്കുന്ന ഈ ഫംഗ്ഷന്റെ സുരക്ഷിതമല്ലാത്ത പതിപ്പിനായി, [`from_u32_unchecked`] കാണുക.
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// ഇൻപുട്ട് സാധുവായ `char` അല്ലാത്തപ്പോൾ `None` നൽകുന്നു:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// സാധുത അവഗണിച്ച് ഒരു `u32`-നെ `char`-ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// എല്ലാ `ചാർ‌'കളും സാധുവായ [` u32`] കൾ‌ആണെന്നും അവ ഒരെണ്ണം കാസ്റ്റുചെയ്യാമെന്നും ശ്രദ്ധിക്കുക
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// എന്നിരുന്നാലും, വിപരീതം ശരിയല്ല: എല്ലാ സാധുവായ [`u32`] കളും സാധുവായ`ചാർ`കളല്ല.
    /// `from_u32_unchecked()` ഇത് അവഗണിക്കുകയും `char`-ലേക്ക് അന്ധമായി കാസ്റ്റുചെയ്യുകയും അസാധുവായ ഒന്ന് സൃഷ്ടിക്കുകയും ചെയ്യും.
    ///
    ///
    /// # Safety
    ///
    /// ഈ ഫംഗ്ഷൻ സുരക്ഷിതമല്ല, കാരണം ഇത് അസാധുവായ `char` മൂല്യങ്ങൾ നിർമ്മിച്ചേക്കാം.
    ///
    /// ഈ ഫംഗ്ഷന്റെ സുരക്ഷിത പതിപ്പിനായി, [`from_u32`] ഫംഗ്ഷൻ കാണുക.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // സുരക്ഷ: സുരക്ഷാ കരാർ വിളിക്കുന്നയാൾ ശരിവെക്കണം.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// തന്നിരിക്കുന്ന റാഡിക്സിലെ ഒരു അക്കത്തെ `char` ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// ഇവിടെ ഒരു 'radix' ചിലപ്പോൾ 'base' എന്നും വിളിക്കപ്പെടുന്നു.
    /// രണ്ടിന്റെ റാഡിക്സ് ചില ബൈനറി സംഖ്യയെ സൂചിപ്പിക്കുന്നു, പത്ത് റാഡിക്സ്, പത്ത്, ദശാംശ, പതിനാറിന്റെ റാഡിക്സ്, ഹെക്സാഡെസിമൽ, ചില പൊതു മൂല്യങ്ങൾ നൽകുന്നു.
    ///
    /// അനിയന്ത്രിതമായ റാഡിക്കുകളെ പിന്തുണയ്‌ക്കുന്നു.
    ///
    /// `from_digit()` തന്നിരിക്കുന്ന റാഡിക്സിലെ ഇൻപുട്ട് ഒരു അക്കമല്ലെങ്കിൽ `None` നൽകും.
    ///
    /// # Panics
    ///
    /// 36 നേക്കാൾ വലിയ റാഡിക്സ് നൽകിയാൽ Panics.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // അടിസ്ഥാന 16 ലെ ഒറ്റ അക്കമാണ് ഡെസിമൽ 11
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// ഇൻപുട്ട് ഒരു അക്കമല്ലാത്തപ്പോൾ `None` നൽകുന്നു:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// ഒരു വലിയ റാഡിക്സ് കടന്നുപോകുന്നു, ഇത് panic ന് കാരണമാകുന്നു:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// തന്നിരിക്കുന്ന റാഡിക്സിൽ ഒരു `char` ഒരു അക്കമാണോയെന്ന് പരിശോധിക്കുന്നു.
    ///
    /// ഇവിടെ ഒരു 'radix' ചിലപ്പോൾ 'base' എന്നും വിളിക്കപ്പെടുന്നു.
    /// രണ്ടിന്റെ റാഡിക്സ് ചില ബൈനറി സംഖ്യയെ സൂചിപ്പിക്കുന്നു, പത്ത് റാഡിക്സ്, പത്ത്, ദശാംശ, പതിനാറിന്റെ റാഡിക്സ്, ഹെക്സാഡെസിമൽ, ചില പൊതു മൂല്യങ്ങൾ നൽകുന്നു.
    ///
    /// അനിയന്ത്രിതമായ റാഡിക്കുകളെ പിന്തുണയ്‌ക്കുന്നു.
    ///
    /// [`is_numeric()`] മായി താരതമ്യപ്പെടുത്തുമ്പോൾ, ഈ ഫംഗ്ഷൻ `0-9`, `a-z`, `A-Z` എന്നീ പ്രതീകങ്ങളെ മാത്രമേ തിരിച്ചറിയൂ.
    ///
    /// 'Digit' ഇനിപ്പറയുന്ന പ്രതീകങ്ങൾ മാത്രമായി നിർവചിച്ചിരിക്കുന്നു:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// 'digit'-നെക്കുറിച്ചുള്ള കൂടുതൽ സമഗ്രമായ ധാരണയ്ക്ക്, [`is_numeric()`] കാണുക.
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// 36 നേക്കാൾ വലിയ റാഡിക്സ് നൽകിയാൽ Panics.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// ഒരു വലിയ റാഡിക്സ് കടന്നുപോകുന്നു, ഇത് panic ന് കാരണമാകുന്നു:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// തന്നിരിക്കുന്ന റാഡിക്സിൽ ഒരു `char` ഒരു അക്കത്തിലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// ഇവിടെ ഒരു 'radix' ചിലപ്പോൾ 'base' എന്നും വിളിക്കപ്പെടുന്നു.
    /// രണ്ടിന്റെ റാഡിക്സ് ചില ബൈനറി സംഖ്യയെ സൂചിപ്പിക്കുന്നു, പത്ത് റാഡിക്സ്, പത്ത്, ദശാംശ, പതിനാറിന്റെ റാഡിക്സ്, ഹെക്സാഡെസിമൽ, ചില പൊതു മൂല്യങ്ങൾ നൽകുന്നു.
    ///
    /// അനിയന്ത്രിതമായ റാഡിക്കുകളെ പിന്തുണയ്‌ക്കുന്നു.
    ///
    /// 'Digit' ഇനിപ്പറയുന്ന പ്രതീകങ്ങൾ മാത്രമായി നിർവചിച്ചിരിക്കുന്നു:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// തന്നിരിക്കുന്ന റാഡിക്സിലെ ഒരു അക്കത്തെ `char` പരാമർശിക്കുന്നില്ലെങ്കിൽ `None` നൽകുന്നു.
    ///
    /// # Panics
    ///
    /// 36 നേക്കാൾ വലിയ റാഡിക്സ് നൽകിയാൽ Panics.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// ഒരു അക്കമല്ലാത്തത് കടന്നുപോകുന്നത് പരാജയത്തിന് കാരണമാകുന്നു:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// ഒരു വലിയ റാഡിക്സ് കടന്നുപോകുന്നു, ഇത് panic ന് കാരണമാകുന്നു:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // `radix` സ്ഥിരവും 10 അല്ലെങ്കിൽ ചെറുതുമായ കേസുകളിൽ എക്സിക്യൂഷൻ വേഗത മെച്ചപ്പെടുത്തുന്നതിനായി കോഡ് ഇവിടെ വിഭജിച്ചിരിക്കുന്നു
        //
        let val = if likely(radix <= 10) {
            // ഒരു അക്കമല്ലെങ്കിൽ, റാഡിക്സിനേക്കാൾ വലിയ ഒരു സംഖ്യ സൃഷ്ടിക്കപ്പെടും.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// ഒരു പ്രതീകത്തിന്റെ ഹെക്‌സാഡെസിമൽ യൂണിക്കോഡ് രക്ഷപ്പെടലിനെ `ചാർ` ആയി നൽകുന്ന ഒരു ഇറ്ററേറ്റർ നൽകുന്നു.
    ///
    /// ഇത് `\u{NNNNNN}` ഫോമിന്റെ Rust വാക്യഘടനയുള്ള പ്രതീകങ്ങളിൽ നിന്ന് രക്ഷപ്പെടും, ഇവിടെ `NNNNNN` ഒരു ഹെക്സാഡെസിമൽ പ്രാതിനിധ്യമാണ്.
    ///
    ///
    /// # Examples
    ///
    /// ഒരു ആവർത്തനക്കാരൻ എന്ന നിലയിൽ:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` നേരിട്ട് ഉപയോഗിക്കുന്നു:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// രണ്ടും ഇതിന് തുല്യമാണ്:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// `to_string` ഉപയോഗിക്കുന്നു:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // or=ing 1, c==0 നായി കോഡ് ഒരു അക്കം അച്ചടിക്കണമെന്ന് കണക്കാക്കുന്നുവെന്നും (ഇത് സമാനമാണ്)(31, 32) അണ്ടർ‌ഫ്ലോ ഒഴിവാക്കുന്നു
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // ഏറ്റവും പ്രധാനപ്പെട്ട ഹെക്സ് അക്കത്തിന്റെ സൂചിക
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// വിപുലീകരിച്ച ഗ്രാഫിം കോഡ് പോയിന്റുകളിൽ നിന്ന് രക്ഷപ്പെടാൻ ഓപ്‌ഷണലായി അനുവദിക്കുന്ന `escape_debug`-ന്റെ വിപുലീകൃത പതിപ്പ്.
    /// സ്‌ട്രിംഗിന്റെ ആരംഭത്തിൽ നോൺസ്‌പെയ്‌സിംഗ് മാർക്ക് പോലുള്ള പ്രതീകങ്ങൾ മികച്ച രീതിയിൽ ഫോർമാറ്റുചെയ്യാൻ ഇത് ഞങ്ങളെ അനുവദിക്കുന്നു.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// ഒരു പ്രതീകത്തിന്റെ അക്ഷരീയ രക്ഷപ്പെടൽ കോഡ് `ചാർ` ആയി നൽകുന്ന ഒരു ഇറ്ററേറ്റർ നൽകുന്നു.
    ///
    /// ഇത് `str` അല്ലെങ്കിൽ `char`-ന്റെ `Debug` നടപ്പിലാക്കലിന് സമാനമായ പ്രതീകങ്ങളിൽ നിന്ന് രക്ഷപ്പെടും.
    ///
    ///
    /// # Examples
    ///
    /// ഒരു ആവർത്തനക്കാരൻ എന്ന നിലയിൽ:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` നേരിട്ട് ഉപയോഗിക്കുന്നു:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// രണ്ടും ഇതിന് തുല്യമാണ്:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// `to_string` ഉപയോഗിക്കുന്നു:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// ഒരു പ്രതീകത്തിന്റെ അക്ഷരീയ രക്ഷപ്പെടൽ കോഡ് `ചാർ` ആയി നൽകുന്ന ഒരു ഇറ്ററേറ്റർ നൽകുന്നു.
    ///
    /// C ++ 11 ഉം സമാനമായ സി-ഫാമിലി ഭാഷകളും ഉൾപ്പെടെ വിവിധ ഭാഷകളിൽ നിയമപരമായ അക്ഷരങ്ങൾ നിർമ്മിക്കുന്നതിനുള്ള പക്ഷപാതത്തോടെയാണ് സ്ഥിരസ്ഥിതി തിരഞ്ഞെടുക്കുന്നത്.
    /// കൃത്യമായ നിയമങ്ങൾ ഇവയാണ്:
    ///
    /// * ടാബ് `\t` ആയി രക്ഷപ്പെട്ടു.
    /// * കാരേജ് റിട്ടേൺ `\r` ആയി രക്ഷപ്പെട്ടു.
    /// * ലൈൻ ഫീഡ് `\n` ആയി രക്ഷപ്പെട്ടു.
    /// * ഒരൊറ്റ ഉദ്ധരണി `\'` ആയി രക്ഷപ്പെട്ടു.
    /// * ഇരട്ട ഉദ്ധരണി `\"` ആയി രക്ഷപ്പെട്ടു.
    /// * ബാക്ക്‌സ്ലാഷ് `\\` ആയി രക്ഷപ്പെട്ടു.
    /// * 'അച്ചടിക്കാവുന്ന ASCII' ശ്രേണിയിലെ `0x20` .. `0x7e` ഉൾക്കൊള്ളുന്ന ഏതെങ്കിലും പ്രതീകങ്ങൾ രക്ഷപ്പെടുന്നില്ല.
    /// * മറ്റെല്ലാ പ്രതീകങ്ങൾക്കും ഹെക്സാഡെസിമൽ യൂണിക്കോഡ് എസ്കേപ്പുകൾ നൽകിയിരിക്കുന്നു;[`escape_unicode`] കാണുക.
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// ഒരു ആവർത്തനക്കാരൻ എന്ന നിലയിൽ:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` നേരിട്ട് ഉപയോഗിക്കുന്നു:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// രണ്ടും ഇതിന് തുല്യമാണ്:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// `to_string` ഉപയോഗിക്കുന്നു:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// UTF-8 ൽ എൻ‌കോഡുചെയ്‌തിട്ടുണ്ടെങ്കിൽ ഈ `char` ന് ആവശ്യമായ ബൈറ്റുകളുടെ എണ്ണം നൽകുന്നു.
    ///
    /// ആ ബൈറ്റുകളുടെ എണ്ണം എല്ലായ്‌പ്പോഴും 1 നും 4 നും ഇടയിലാണ്.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// `&str` തരം അതിന്റെ ഉള്ളടക്കങ്ങൾ UTF-8 ആണെന്ന് ഉറപ്പുനൽകുന്നു, അതിനാൽ ഓരോ കോഡ് പോയിന്റും `&str`-ൽ തന്നെ `char` vs ആയി പ്രതിനിധീകരിച്ചിട്ടുണ്ടെങ്കിൽ എടുക്കുന്ന ദൈർഘ്യം താരതമ്യം ചെയ്യാം:
    ///
    ///
    /// ```
    /// // പ്രതീകങ്ങളായി
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // രണ്ടും മൂന്ന് ബൈറ്റുകളായി പ്രതിനിധീകരിക്കാം
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // ഒരു &str എന്ന നിലയിൽ, ഇവ രണ്ടും UTF-8-ൽ എൻ‌കോഡുചെയ്‌തു
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // ആകെ ആറ് ബൈറ്റുകൾ അവർ എടുക്കുന്നതായി നമുക്ക് കാണാം ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... &str പോലെ
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// UTF-16 ൽ എൻ‌കോഡുചെയ്‌താൽ ഈ `char` ന് ആവശ്യമായ 16-ബിറ്റ് കോഡ് യൂണിറ്റുകളുടെ എണ്ണം നൽകുന്നു.
    ///
    ///
    /// ഈ ആശയത്തിന്റെ കൂടുതൽ വിശദീകരണത്തിനായി [`len_utf8()`] നായുള്ള ഡോക്യുമെന്റേഷൻ കാണുക.
    /// ഈ പ്രവർത്തനം ഒരു മിററാണ്, പക്ഷേ UTF-8 ന് പകരം UTF-16 ന്.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// നൽകിയ ബൈറ്റ് ബഫറിലേക്ക് ഈ പ്രതീകത്തെ UTF-8 ആയി എൻ‌കോഡുചെയ്യുന്നു, തുടർന്ന് എൻ‌കോഡുചെയ്‌ത പ്രതീകം അടങ്ങിയിരിക്കുന്ന ബഫറിന്റെ സബ്‌ലൈസ് നൽകുന്നു.
    ///
    ///
    /// # Panics
    ///
    /// ബഫർ വേണ്ടത്ര വലുതല്ലെങ്കിൽ Panics.
    /// ഏത് `char` എൻ‌കോഡുചെയ്യാൻ‌പര്യാപ്‌തമായ നാല്‌നീളമുള്ള ബഫർ‌.
    ///
    /// # Examples
    ///
    /// ഈ രണ്ട് ഉദാഹരണങ്ങളിലും, എൻ‌കോഡുചെയ്യാൻ 'ß' രണ്ട് ബൈറ്റുകൾ എടുക്കുന്നു.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// വളരെ ചെറുതായ ഒരു ബഫർ:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // സുരക്ഷ: `char` ഒരു സർറോഗേറ്റ് അല്ല, അതിനാൽ ഇത് സാധുവായ UTF-8 ആണ്.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// നൽകിയ `u16` ബഫറിലേക്ക് ഈ പ്രതീകം UTF-16 ആയി എൻ‌കോഡുചെയ്യുന്നു, തുടർന്ന് എൻ‌കോഡുചെയ്‌ത പ്രതീകം അടങ്ങിയിരിക്കുന്ന ബഫറിന്റെ സബ്‌ലൈസ് നൽകുന്നു.
    ///
    ///
    /// # Panics
    ///
    /// ബഫർ വേണ്ടത്ര വലുതല്ലെങ്കിൽ Panics.
    /// ഏത് `char` എൻ‌കോഡുചെയ്യാൻ‌പര്യാപ്‌തമായ ദൈർ‌ഘ്യമുള്ള 2 ബഫർ‌.
    ///
    /// # Examples
    ///
    /// ഈ രണ്ട് ഉദാഹരണങ്ങളിലും, എൻ‌കോഡുചെയ്യാൻ '𝕊' രണ്ട് `u16` കൾ എടുക്കുന്നു.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// വളരെ ചെറുതായ ഒരു ബഫർ:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// ഈ `char` ന് `Alphabetic` പ്രോപ്പർട്ടി ഉണ്ടെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// `Alphabetic` [Unicode Standard]-ന്റെ അധ്യായം 4 (പ്രതീക സവിശേഷതകൾ) ൽ വിശദീകരിച്ചിരിക്കുന്നു കൂടാതെ [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] ൽ വ്യക്തമാക്കിയിരിക്കുന്നു.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // സ്നേഹം പലതും, പക്ഷേ അത് അക്ഷരമാലയല്ല
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// ഈ `char` ന് `Lowercase` പ്രോപ്പർട്ടി ഉണ്ടെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// `Lowercase` [Unicode Standard]-ന്റെ അധ്യായം 4 (പ്രതീക സവിശേഷതകൾ) ൽ വിശദീകരിച്ചിരിക്കുന്നു കൂടാതെ [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] ൽ വ്യക്തമാക്കിയിരിക്കുന്നു.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // വിവിധ ചൈനീസ് സ്ക്രിപ്റ്റുകൾക്കും ചിഹ്നനങ്ങൾക്കും കേസില്ല, അതിനാൽ:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// ഈ `char` ന് `Uppercase` പ്രോപ്പർട്ടി ഉണ്ടെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// `Uppercase` [Unicode Standard]-ന്റെ അധ്യായം 4 (പ്രതീക സവിശേഷതകൾ) ൽ വിശദീകരിച്ചിരിക്കുന്നു കൂടാതെ [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`] ൽ വ്യക്തമാക്കിയിരിക്കുന്നു.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // വിവിധ ചൈനീസ് സ്ക്രിപ്റ്റുകൾക്കും ചിഹ്നനങ്ങൾക്കും കേസില്ല, അതിനാൽ:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// ഈ `char` ന് `White_Space` പ്രോപ്പർട്ടി ഉണ്ടെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// `White_Space` [Unicode Character Database][ucd] [`PropList.txt`]-ൽ വ്യക്തമാക്കിയിരിക്കുന്നു.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // തകർക്കാത്ത ഇടം
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// ഈ `char` [`is_alphabetic()`] അല്ലെങ്കിൽ [`is_numeric()`] നെ തൃപ്തിപ്പെടുത്തുന്നുവെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// നിയന്ത്രണ കോഡുകൾക്കായി ഈ `char` ന് പൊതുവായ വിഭാഗം ഉണ്ടെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// നിയന്ത്രണ കോഡുകൾ (`Cc`-ന്റെ പൊതു വിഭാഗമുള്ള കോഡ് പോയിന്റുകൾ) [Unicode Standard]-ന്റെ അധ്യായം 4 (പ്രതീക സവിശേഷതകൾ) ൽ വിശദീകരിച്ചിരിക്കുന്നു കൂടാതെ [Unicode Character Database][ucd] [`UnicodeData.txt`]-ൽ വ്യക്തമാക്കിയിരിക്കുന്നു.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// // U + 009C, STRING TERMINATOR
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// ഈ `char` ന് `Grapheme_Extend` പ്രോപ്പർട്ടി ഉണ്ടെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// `Grapheme_Extend` [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29]-ൽ വിശദീകരിച്ച് [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`]-ൽ വ്യക്തമാക്കിയിരിക്കുന്നു.
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// ഈ `char` ന് അക്കങ്ങളുടെ പൊതുവായ വിഭാഗങ്ങളിലൊന്ന് ഉണ്ടെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// അക്കങ്ങൾക്കായുള്ള പൊതു വിഭാഗങ്ങൾ (ദശാംശ അക്കങ്ങൾക്ക് `Nd`, അക്ഷരം പോലുള്ള സംഖ്യാ പ്രതീകങ്ങൾക്ക് `Nl`, മറ്റ് സംഖ്യാ പ്രതീകങ്ങൾക്ക് `No`) [Unicode Character Database][ucd] [`UnicodeData.txt`]-ൽ വ്യക്തമാക്കിയിരിക്കുന്നു.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// ഈ `char`-ന്റെ ചെറിയക്ഷര മാപ്പിംഗ് ഒന്നോ അതിലധികമോ ആയി നൽകുന്ന ഒരു ഇറ്ററേറ്റർ നൽകുന്നു
    /// `char`s.
    ///
    /// ഈ `char`-ന് ചെറിയക്ഷര മാപ്പിംഗ് ഇല്ലെങ്കിൽ, ആവർത്തനം അതേ `char` നൽകുന്നു.
    ///
    /// ഈ `char` ന് [Unicode Character Database][ucd] [`UnicodeData.txt`] നൽകിയ വൺ-ടു-വൺ ലോവർ‌കേസ് മാപ്പിംഗ് ഉണ്ടെങ്കിൽ, ആവർത്തനം ആ `char` നൽകുന്നു.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// ഈ `char` ന് പ്രത്യേക പരിഗണനകൾ ആവശ്യമാണെങ്കിൽ (ഉദാ. ഒന്നിലധികം `ചാർ`കൾ) ആവർത്തനം [`SpecialCasing.txt`] നൽകിയ`ചാർ` (കൾ) നൽകുന്നു.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// ഈ പ്രവർത്തനം ടൈലറിംഗ് ഇല്ലാതെ നിരുപാധികമായ മാപ്പിംഗ് നടത്തുന്നു.അതായത്, പരിവർത്തനം സന്ദർഭത്തിൽ നിന്നും ഭാഷയിൽ നിന്നും സ്വതന്ത്രമാണ്.
    ///
    /// [Unicode Standard]-ൽ, ചാപ്റ്റർ 4 (ക്യാരക്ടർ പ്രോപ്പർട്ടികൾ) പൊതുവായി കേസ് മാപ്പിംഗിനെക്കുറിച്ചും അധ്യായം 3 (Conformance) കേസ് പരിവർത്തനത്തിനായുള്ള സ്ഥിരസ്ഥിതി അൽ‌ഗോരിതം ചർച്ചചെയ്യുന്നു.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// ഒരു ആവർത്തനക്കാരൻ എന്ന നിലയിൽ:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` നേരിട്ട് ഉപയോഗിക്കുന്നു:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// രണ്ടും ഇതിന് തുല്യമാണ്:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// `to_string` ഉപയോഗിക്കുന്നു:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // ചിലപ്പോൾ ഫലം ഒന്നിലധികം പ്രതീകങ്ങളായിരിക്കും:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // വലിയക്ഷരവും ചെറിയക്ഷരവും ഇല്ലാത്ത പ്രതീകങ്ങൾ സ്വയം പരിവർത്തനം ചെയ്യുന്നു.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// ഈ `char`-ന്റെ വലിയക്ഷര മാപ്പിംഗ് ഒന്നോ അതിലധികമോ ആയി നൽകുന്ന ഒരു ഇറ്ററേറ്റർ നൽകുന്നു
    /// `char`s.
    ///
    /// ഈ `char`-ന് ഒരു വലിയ മാപ്പിംഗ് ഇല്ലെങ്കിൽ, ആവർത്തനം അതേ `char` നൽകുന്നു.
    ///
    /// ഈ `char` ന് [Unicode Character Database][ucd] [`UnicodeData.txt`] നൽകിയ വൺ-ടു-വൺ അപ്പർ‌കേസ് മാപ്പിംഗ് ഉണ്ടെങ്കിൽ, ആവർത്തനം ആ `char` നൽകുന്നു.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// ഈ `char` ന് പ്രത്യേക പരിഗണനകൾ ആവശ്യമാണെങ്കിൽ (ഉദാ. ഒന്നിലധികം `ചാർ`കൾ) ആവർത്തനം [`SpecialCasing.txt`] നൽകിയ`ചാർ` (കൾ) നൽകുന്നു.
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// ഈ പ്രവർത്തനം ടൈലറിംഗ് ഇല്ലാതെ നിരുപാധികമായ മാപ്പിംഗ് നടത്തുന്നു.അതായത്, പരിവർത്തനം സന്ദർഭത്തിൽ നിന്നും ഭാഷയിൽ നിന്നും സ്വതന്ത്രമാണ്.
    ///
    /// [Unicode Standard]-ൽ, ചാപ്റ്റർ 4 (ക്യാരക്ടർ പ്രോപ്പർട്ടികൾ) പൊതുവായി കേസ് മാപ്പിംഗിനെക്കുറിച്ചും അധ്യായം 3 (Conformance) കേസ് പരിവർത്തനത്തിനായുള്ള സ്ഥിരസ്ഥിതി അൽ‌ഗോരിതം ചർച്ചചെയ്യുന്നു.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// ഒരു ആവർത്തനക്കാരൻ എന്ന നിലയിൽ:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// `println!` നേരിട്ട് ഉപയോഗിക്കുന്നു:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// രണ്ടും ഇതിന് തുല്യമാണ്:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// `to_string` ഉപയോഗിക്കുന്നു:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // ചിലപ്പോൾ ഫലം ഒന്നിലധികം പ്രതീകങ്ങളായിരിക്കും:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // വലിയക്ഷരവും ചെറിയക്ഷരവും ഇല്ലാത്ത പ്രതീകങ്ങൾ സ്വയം പരിവർത്തനം ചെയ്യുന്നു.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # ഭാഷയിലെ കുറിപ്പ്
    ///
    /// ടർക്കിഷ് ഭാഷയിൽ, ലാറ്റിനിലെ 'i' ന് തുല്യമായ രണ്ടിന് പകരം അഞ്ച് രൂപങ്ങളുണ്ട്:
    ///
    /// * 'Dotless': I/ı, ചിലപ്പോൾ എഴുതിയത്
    /// * 'Dotted': İ/i
    ///
    /// ചെറിയ ഡോട്ട് ഇട്ട 'i' ലാറ്റിന് തുല്യമാണെന്ന് ശ്രദ്ധിക്കുക.അതുകൊണ്ടു:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// ഇവിടെ `upper_i`-ന്റെ മൂല്യം വാചകത്തിന്റെ ഭാഷയെ ആശ്രയിച്ചിരിക്കുന്നു: ഞങ്ങൾ `en-US`-ൽ ആണെങ്കിൽ, അത് `"I"` ആയിരിക്കണം, പക്ഷേ ഞങ്ങൾ `tr_TR`-ൽ ആണെങ്കിൽ, അത് `"İ"` ആയിരിക്കണം.
    /// `to_uppercase()` ഇത് കണക്കിലെടുക്കുന്നില്ല, അതിനാൽ:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// ഭാഷകളിലുടനീളം ഉൾക്കൊള്ളുന്നു.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// മൂല്യം ASCII പരിധിക്കുള്ളിലാണോയെന്ന് പരിശോധിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// അതിന്റെ ASCII വലിയ കേസിലെ മൂല്യത്തിന്റെ ഒരു പകർപ്പ് തുല്യമാക്കുന്നു.
    ///
    /// ASCII അക്ഷരങ്ങൾ 'a' മുതൽ 'z' വരെ 'A' മുതൽ 'Z' വരെ മാപ്പുചെയ്‌തു, പക്ഷേ ASCII ഇതര അക്ഷരങ്ങൾക്ക് മാറ്റമില്ല.
    ///
    /// സ്ഥലത്ത് മൂല്യം വലിയക്ഷരമാക്കാൻ, [`make_ascii_uppercase()`] ഉപയോഗിക്കുക.
    ///
    /// ASCII ഇതര പ്രതീകങ്ങൾക്ക് പുറമേ ASCII പ്രതീകങ്ങൾ വലിയക്ഷരമാക്കാൻ, [`to_uppercase()`] ഉപയോഗിക്കുക.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// അതിന്റെ ASCII ലോവർ കെയ്‌സിലെ മൂല്യത്തിന്റെ ഒരു പകർപ്പ് തുല്യമാക്കുന്നു.
    ///
    /// ASCII അക്ഷരങ്ങൾ 'A' മുതൽ 'Z' വരെ 'a' മുതൽ 'z' വരെ മാപ്പുചെയ്‌തു, പക്ഷേ ASCII ഇതര അക്ഷരങ്ങൾക്ക് മാറ്റമില്ല.
    ///
    /// സ്ഥലത്ത് മൂല്യം കുറയ്‌ക്കാൻ, [`make_ascii_lowercase()`] ഉപയോഗിക്കുക.
    ///
    /// ASCII ഇതര പ്രതീകങ്ങൾക്ക് പുറമേ ASCII പ്രതീകങ്ങൾ ചെറിയക്ഷരമാക്കാൻ, [`to_lowercase()`] ഉപയോഗിക്കുക.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// രണ്ട് മൂല്യങ്ങൾ ഒരു ASCII കേസ്-സെൻസിറ്റീവ് പൊരുത്തമാണെന്ന് പരിശോധിക്കുന്നു.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)`-ന് തുല്യമാണ്.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// ഈ തരം അതിന്റെ ASCII അപ്പർ കേസ് തുല്യമായ സ്ഥലത്തേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// ASCII അക്ഷരങ്ങൾ 'a' മുതൽ 'z' വരെ 'A' മുതൽ 'Z' വരെ മാപ്പുചെയ്‌തു, പക്ഷേ ASCII ഇതര അക്ഷരങ്ങൾക്ക് മാറ്റമില്ല.
    ///
    /// നിലവിലുള്ള ഒരെണ്ണം പരിഷ്‌ക്കരിക്കാതെ ഒരു വലിയ വലിയ മൂല്യം നൽകാൻ, [`to_ascii_uppercase()`] ഉപയോഗിക്കുക.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// ഈ തരം അതിന്റെ ASCII ലോവർ കേസ് തുല്യമായ സ്ഥലത്തേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// ASCII അക്ഷരങ്ങൾ 'A' മുതൽ 'Z' വരെ 'a' മുതൽ 'z' വരെ മാപ്പുചെയ്‌തു, പക്ഷേ ASCII ഇതര അക്ഷരങ്ങൾക്ക് മാറ്റമില്ല.
    ///
    /// നിലവിലുള്ള ഒരെണ്ണം പരിഷ്‌ക്കരിക്കാതെ ഒരു ചെറിയ ചെറിയ മൂല്യം നൽകുന്നതിന്, [`to_ascii_lowercase()`] ഉപയോഗിക്കുക.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// മൂല്യം ഒരു ASCII അക്ഷരമാല പ്രതീകമാണോയെന്ന് പരിശോധിക്കുന്നു:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', അല്ലെങ്കിൽ
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// മൂല്യം ഒരു ASCII വലിയക്ഷരമാണോയെന്ന് പരിശോധിക്കുന്നു:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// മൂല്യം ഒരു ASCII ചെറിയക്ഷരമാണോയെന്ന് പരിശോധിക്കുന്നു:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// മൂല്യം ഒരു ASCII ആൽ‌ഫാന്യൂമെറിക് പ്രതീകമാണോയെന്ന് പരിശോധിക്കുന്നു:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', അല്ലെങ്കിൽ
    /// - U + 0061 'a' ..=U + 007A 'z', അല്ലെങ്കിൽ
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// മൂല്യം ഒരു ASCII ദശാംശ അക്കമാണോയെന്ന് പരിശോധിക്കുന്നു:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// മൂല്യം ഒരു ASCII ഹെക്സാഡെസിമൽ അക്കമാണോയെന്ന് പരിശോധിക്കുന്നു:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', അല്ലെങ്കിൽ
    /// - U + 0041 'A' ..=U + 0046 'F', അല്ലെങ്കിൽ
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// മൂല്യം ഒരു ASCII വിരാമചിഹ്ന പ്രതീകമാണോയെന്ന് പരിശോധിക്കുന്നു:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, അല്ലെങ്കിൽ
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, അല്ലെങ്കിൽ
    /// - U + 005B ..=U + 0060 ``[\] ^ _``, അല്ലെങ്കിൽ
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// മൂല്യം ഒരു ASCII ഗ്രാഫിക് പ്രതീകമാണോയെന്ന് പരിശോധിക്കുന്നു:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// മൂല്യം ഒരു ASCII വൈറ്റ്‌സ്‌പെയ്‌സ് പ്രതീകമാണോയെന്ന് പരിശോധിക്കുന്നു:
    /// U + 0020 SPACE, U + 0009 ഹൊറിസോണ്ടൽ ടാബ്, U + 000A ലൈൻ ഫീഡ്, U + 000C ഫോം ഫീഡ്, അല്ലെങ്കിൽ U + 000D കാരിയേജ് റിട്ടേൺ.
    ///
    /// Rust വാട്ട്ഡബ്ല്യുജി ഇൻഫ്രാ സ്റ്റാൻഡേർഡിന്റെ [definition of ASCII whitespace][infra-aw] ഉപയോഗിക്കുന്നു.വിശാലമായ ഉപയോഗത്തിൽ മറ്റ് നിരവധി നിർവചനങ്ങൾ ഉണ്ട്.
    /// ഉദാഹരണത്തിന്, [the POSIX locale][pct]-ൽ U + 000B വെർട്ടിക്കൽ ടാബും മുകളിലുള്ള എല്ലാ പ്രതീകങ്ങളും ഉൾപ്പെടുന്നു, എന്നാൽ-അതേ സവിശേഷതയിൽ നിന്ന് [[ബോർൺ shell-ലെ "field splitting"-ന്റെ സ്ഥിരസ്ഥിതി നിയമം][bfs]*മാത്രം* സ്‌പേസ്, ഹൊറിസോണ്ടൽ ടാബ്, വൈറ്റ്‌സ്‌പെയ്‌സായി LINE ഫീഡ്.
    ///
    ///
    /// നിലവിലുള്ള ഒരു ഫയൽ ഫോർമാറ്റ് പ്രോസസ്സ് ചെയ്യുന്ന ഒരു പ്രോഗ്രാം നിങ്ങൾ എഴുതുകയാണെങ്കിൽ, ഈ ഫംഗ്ഷൻ ഉപയോഗിക്കുന്നതിന് മുമ്പ് വൈറ്റ്സ്പേസ് എന്ന ഫോർമാറ്റിന്റെ നിർവചനം എന്താണെന്ന് പരിശോധിക്കുക.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// മൂല്യം ഒരു ASCII നിയന്ത്രണ പ്രതീകമാണോയെന്ന് പരിശോധിക്കുന്നു:
    /// U + 0000 NUL ..=U + 001F UNIT SEPARATOR, അല്ലെങ്കിൽ U + 007F DELETE.
    /// മിക്ക ASCII വൈറ്റ്‌സ്‌പെയ്‌സ് പ്രതീകങ്ങളും നിയന്ത്രണ പ്രതീകങ്ങളാണെന്നത് ശ്രദ്ധിക്കുക, പക്ഷേ SPACE അങ്ങനെയല്ല.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// നൽകിയ ബൈറ്റ് ബഫറിലേക്ക് ഒരു അസംസ്കൃത u32 മൂല്യം UTF-8 ആയി എൻ‌കോഡുചെയ്യുന്നു, തുടർന്ന് എൻ‌കോഡുചെയ്‌ത പ്രതീകം അടങ്ങിയിരിക്കുന്ന ബഫറിന്റെ സബ്‌ലൈസ് നൽകുന്നു.
///
///
/// `char::encode_utf8`-ൽ നിന്ന് വ്യത്യസ്തമായി, ഈ രീതി സരോജേറ്റ് ശ്രേണിയിലെ കോഡ് പോയിന്റുകളും കൈകാര്യം ചെയ്യുന്നു.
/// (സരോജേറ്റ് ശ്രേണിയിൽ ഒരു `char` സൃഷ്ടിക്കുന്നത് UB ആണ്.) ഫലം സാധുവായ [generalized UTF-8] ആണെങ്കിലും സാധുവായ UTF-8 അല്ല.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// ബഫർ വേണ്ടത്ര വലുതല്ലെങ്കിൽ Panics.
/// ഏത് `char` എൻ‌കോഡുചെയ്യാൻ‌പര്യാപ്‌തമായ നാല്‌നീളമുള്ള ബഫർ‌.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// നൽകിയ `u16` ബഫറിലേക്ക് ഒരു അസംസ്കൃത u32 മൂല്യം UTF-16 ആയി എൻ‌കോഡുചെയ്യുന്നു, തുടർന്ന് എൻ‌കോഡുചെയ്‌ത പ്രതീകം അടങ്ങിയിരിക്കുന്ന ബഫറിന്റെ സബ്‌ലൈസ് നൽകുന്നു.
///
///
/// `char::encode_utf16`-ൽ നിന്ന് വ്യത്യസ്തമായി, ഈ രീതി സരോജേറ്റ് ശ്രേണിയിലെ കോഡ് പോയിന്റുകളും കൈകാര്യം ചെയ്യുന്നു.
/// (സരോജേറ്റ് ശ്രേണിയിൽ ഒരു എക്സ് 00 എക്സ് സൃഷ്ടിക്കുന്നത് യുബി ആണ്.)
///
/// # Panics
///
/// ബഫർ വേണ്ടത്ര വലുതല്ലെങ്കിൽ Panics.
/// ഏത് `char` എൻ‌കോഡുചെയ്യാൻ‌പര്യാപ്‌തമായ ദൈർ‌ഘ്യമുള്ള 2 ബഫർ‌.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // സുരക്ഷ: ഓരോ കൈയും എഴുതാൻ ആവശ്യമായ ബിറ്റുകൾ ഉണ്ടോ എന്ന് പരിശോധിക്കുന്നു
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // ബി‌എം‌പി വീഴുന്നു
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // അനുബന്ധ വിമാനങ്ങൾ സറോഗേറ്റുകളായി വിഭജിക്കുന്നു.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}