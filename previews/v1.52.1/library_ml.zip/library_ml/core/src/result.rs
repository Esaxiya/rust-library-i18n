//! `Result` തരം ഉപയോഗിച്ച് കൈകാര്യം ചെയ്യുന്നതിൽ പിശക്.
//!
//! [`Result<T, E>`][`Result`] പിശകുകൾ മടക്കിനൽകുന്നതിനും പ്രചരിപ്പിക്കുന്നതിനും ഉപയോഗിക്കുന്ന തരം.
//! എക്സ് 100 എക്സ്, വിജയത്തെ പ്രതിനിധീകരിക്കുന്ന ഒരു മൂല്യം, എക്സ് 01 എക്സ്, പിശകുകളെ പ്രതിനിധീകരിക്കുന്നതും ഒരു പിശക് മൂല്യം അടങ്ങിയിരിക്കുന്നതുമായ ഒരു ഇനമാണ് ഇത്.
//!
//! ```
//! # #[allow(dead_code)]
//! enum Result<T, E> {
//!    Ok(T),
//!    Err(E),
//! }
//! ```
//!
//! പിശകുകൾ പ്രതീക്ഷിക്കുമ്പോഴും വീണ്ടെടുക്കാനാകുമ്പോഴും പ്രവർത്തനങ്ങൾ [`Result`] നൽകുന്നു.`std` crate-ൽ, [`Result`] ഏറ്റവും പ്രധാനമായി [I/O](../../std/io/index.html)-നായി ഉപയോഗിക്കുന്നു.
//!
//! [`Result`] നൽകുന്ന ലളിതമായ ഒരു ഫംഗ്ഷൻ നിർവചിക്കുകയും ഇതുപോലെ ഉപയോഗിക്കുകയും ചെയ്യാം:
//!
//! ```
//! #[derive(Debug)]
//! enum Version { Version1, Version2 }
//!
//! fn parse_version(header: &[u8]) -> Result<Version, &'static str> {
//!     match header.get(0) {
//!         None => Err("invalid header length"),
//!         Some(&1) => Ok(Version::Version1),
//!         Some(&2) => Ok(Version::Version2),
//!         Some(_) => Err("invalid version"),
//!     }
//! }
//!
//! let version = parse_version(&[1, 2, 3, 4]);
//! match version {
//!     Ok(v) => println!("working with version: {:?}", v),
//!     Err(e) => println!("error parsing header: {:?}", e),
//! }
//! ```
//!
//! [`റിസൾട്ടിന്റെ] പാറ്റേൺ പൊരുത്തപ്പെടുത്തൽ ലളിതമായ കേസുകളിൽ വ്യക്തവും നേരായതുമാണ്, എന്നാൽ എക്സ് 00 എക്സ് ചില സ methods കര്യപ്രദമായ രീതികളുമായി വരുന്നു, അത് പ്രവർത്തിക്കുന്നത് കൂടുതൽ സംക്ഷിപ്തമാക്കുന്നു.
//!
//! ```
//! let good_result: Result<i32, i32> = Ok(10);
//! let bad_result: Result<i32, i32> = Err(10);
//!
//! // `is_ok`, `is_err` രീതികൾ അവർ പറയുന്നത് ചെയ്യുന്നു.
//! assert!(good_result.is_ok() && !good_result.is_err());
//! assert!(bad_result.is_err() && !bad_result.is_ok());
//!
//! // `map` `Result` ഉപയോഗിക്കുകയും മറ്റൊന്ന് നിർമ്മിക്കുകയും ചെയ്യുന്നു.
//! let good_result: Result<i32, i32> = good_result.map(|i| i + 1);
//! let bad_result: Result<i32, i32> = bad_result.map(|i| i - 1);
//!
//! // കണക്കുകൂട്ടൽ തുടരാൻ `and_then` ഉപയോഗിക്കുക.
//! let good_result: Result<bool, i32> = good_result.and_then(|i| Ok(i == 11));
//!
//! // പിശക് കൈകാര്യം ചെയ്യാൻ `or_else` ഉപയോഗിക്കുക.
//! let bad_result: Result<i32, i32> = bad_result.or_else(|i| Ok(i + 20));
//!
//! // ഫലം ഉപയോഗിക്കുകയും `unwrap` ഉപയോഗിച്ച് ഉള്ളടക്കങ്ങൾ തിരികെ നൽകുകയും ചെയ്യുക.
//! let final_awesome_result = good_result.unwrap();
//! ```
//!
//! # ഫലങ്ങൾ ഉപയോഗിക്കണം
//!
//! പിശകുകൾ സൂചിപ്പിക്കുന്നതിന് റിട്ടേൺ മൂല്യങ്ങൾ ഉപയോഗിക്കുന്നതിലെ ഒരു പൊതു പ്രശ്നം, റിട്ടേൺ മൂല്യം അവഗണിക്കുന്നത് എളുപ്പമാണ്, അതിനാൽ പിശക് കൈകാര്യം ചെയ്യുന്നതിൽ പരാജയപ്പെടുന്നു.
//! [`Result`] `#[must_use]` ആട്രിബ്യൂട്ട് ഉപയോഗിച്ച് വ്യാഖ്യാനിച്ചിരിക്കുന്നു, ഇത് ഒരു ഫല മൂല്യം അവഗണിക്കുമ്പോൾ കംപൈലറിന് ഒരു മുന്നറിയിപ്പ് നൽകും.
//! പിശകുകൾ നേരിടാനിടയുള്ളതും എന്നാൽ ഉപയോഗപ്രദമായ മൂല്യം നൽകാത്തതുമായ ഫംഗ്ഷനുകളിൽ ഇത് [`Result`] പ്രത്യേകിച്ചും ഉപയോഗപ്രദമാക്കുന്നു.
//!
//! [`Write`] trait I/O തരങ്ങൾക്കായി നിർവചിച്ചിരിക്കുന്ന [`write_all`] രീതി പരിഗണിക്കുക:
//!
//! ```
//! use std::io;
//!
//! trait Write {
//!     fn write_all(&mut self, bytes: &[u8]) -> Result<(), io::Error>;
//! }
//! ```
//!
//! *Note: [`Write`]-ന്റെ യഥാർത്ഥ നിർവചനം [`io::Result`] ഉപയോഗിക്കുന്നു, ഇത് [`ഫലം`]`എന്നതിന്റെ പര്യായമാണ്<T,`[`io: :Error`]`>`.*
//!
//! ഈ രീതി ഒരു മൂല്യം സൃഷ്ടിക്കുന്നില്ല, പക്ഷേ റൈറ്റ് പരാജയപ്പെടാം.പിശക് കേസ് കൈകാര്യം ചെയ്യുന്നത് നിർണായകമാണ്, കൂടാതെ * ഇതുപോലൊന്ന് എഴുതരുത്:
//!
//! ```no_run
//! # #![allow(unused_must_use)] // \o/
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! // `write_all` പിശകുകളാണെങ്കിൽ, ഞങ്ങൾ ഒരിക്കലും അറിയുകയില്ല, കാരണം റിട്ടേൺ മൂല്യം അവഗണിക്കപ്പെടും.
//! //
//! file.write_all(b"important message");
//! ```
//!
//! Rust ൽ നിങ്ങൾ * എഴുതുകയാണെങ്കിൽ, കംപൈലർ നിങ്ങൾക്ക് ഒരു മുന്നറിയിപ്പ് നൽകും (സ്ഥിരസ്ഥിതിയായി, `unused_must_use` lint നിയന്ത്രിക്കുന്നത്).
//!
//! പകരം, നിങ്ങൾക്ക് പിശക് കൈകാര്യം ചെയ്യാൻ താൽപ്പര്യമില്ലെങ്കിൽ, [`expect`] ഉപയോഗിച്ച് വിജയം ഉറപ്പിക്കുക.
//! റൈറ്റ് പരാജയപ്പെട്ടാൽ ഇത് panic ആയിരിക്കും, എന്തുകൊണ്ടെന്ന് സൂചിപ്പിക്കുന്ന ഒരു ചെറിയ ഉപയോഗപ്രദമായ സന്ദേശം നൽകുന്നു:
//!
//! ```no_run
//! use std::fs::File;
//! use std::io::prelude::*;
//!
//! let mut file = File::create("valuable_data.txt").unwrap();
//! file.write_all(b"important message").expect("failed to write message");
//! ```
//!
//! നിങ്ങൾക്ക് വിജയം ഉറപ്പിക്കാം:
//!
//! ```no_run
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # let mut file = File::create("valuable_data.txt").unwrap();
//! assert!(file.write_all(b"important message").is_ok());
//! ```
//!
//! അല്ലെങ്കിൽ [`?`] ഉപയോഗിച്ച് കോൾ സ്റ്റാക്കിൽ പിശക് പ്രചരിപ്പിക്കുക:
//!
//! ```
//! # use std::fs::File;
//! # use std::io::prelude::*;
//! # use std::io;
//! # #[allow(dead_code)]
//! fn write_message() -> io::Result<()> {
//!     let mut file = File::create("valuable_data.txt")?;
//!     file.write_all(b"important message")?;
//!     Ok(())
//! }
//! ```
//!
//! # ചോദ്യചിഹ്ന ഓപ്പറേറ്റർ, `?`
//!
//! [`Result`] തരം മടക്കിനൽകുന്ന നിരവധി ഫംഗ്ഷനുകളെ വിളിക്കുന്ന കോഡ് എഴുതുമ്പോൾ, പിശക് കൈകാര്യം ചെയ്യുന്നത് ശ്രമകരമാണ്.
//! ചോദ്യചിഹ്ന ഓപ്പറേറ്ററായ എക്സ് 00 എക്സ് കോൾ സ്റ്റാക്ക് വരെ പിശകുകൾ പ്രചരിപ്പിക്കുന്ന ചില ബോയിലർ പ്ലേറ്റ് മറയ്ക്കുന്നു.
//!
//! ഇത് ഇത് മാറ്റിസ്ഥാപിക്കുന്നു:
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     // പിശകിന്റെ നേരത്തെയുള്ള വരുമാനം
//!     let mut file = match File::create("my_best_friends.txt") {
//!            Err(e) => return Err(e),
//!            Ok(f) => f,
//!     };
//!     if let Err(e) = file.write_all(format!("name: {}\n", info.name).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("age: {}\n", info.age).as_bytes()) {
//!         return Err(e)
//!     }
//!     if let Err(e) = file.write_all(format!("rating: {}\n", info.rating).as_bytes()) {
//!         return Err(e)
//!     }
//!     Ok(())
//! }
//! ```
//!
//! ഇതിനോടൊപ്പം:
//!
//! ```
//! # #![allow(dead_code)]
//! use std::fs::File;
//! use std::io::prelude::*;
//! use std::io;
//!
//! struct Info {
//!     name: String,
//!     age: i32,
//!     rating: i32,
//! }
//!
//! fn write_info(info: &Info) -> io::Result<()> {
//!     let mut file = File::create("my_best_friends.txt")?;
//!     // പിശകിന്റെ നേരത്തെയുള്ള വരുമാനം
//!     file.write_all(format!("name: {}\n", info.name).as_bytes())?;
//!     file.write_all(format!("age: {}\n", info.age).as_bytes())?;
//!     file.write_all(format!("rating: {}\n", info.rating).as_bytes())?;
//!     Ok(())
//! }
//! ```
//!
//! *ഇത് വളരെ നല്ലതാണ്!*
//!
//! [`?`] ഉപയോഗിച്ച് എക്‌സ്‌പ്രഷൻ അവസാനിപ്പിക്കുന്നത് ഫലം [`Err`] അല്ലാത്തപക്ഷം, അൺ‌റാപ്പ് ചെയ്യപ്പെടാത്ത വിജയത്തിന് കാരണമാകും, ഈ സാഹചര്യത്തിൽ [`Err`] എൻ‌ക്ലോസിംഗ് ഫംഗ്ഷനിൽ നിന്ന് നേരത്തേ മടക്കിനൽകുന്നു.
//!
//!
//! [`?`] [`Result`] നൽകുന്ന ഫംഗ്ഷനുകളിൽ മാത്രമേ ഇത് ഉപയോഗിക്കാൻ കഴിയൂ, കാരണം അത് നൽകുന്ന [`Err`] ന്റെ ആദ്യകാല വരുമാനം.
//!
//! [`expect`]: Result::expect
//! [`Write`]: ../../std/io/trait.Write.html
//! [`write_all`]: ../../std/io/trait.Write.html#method.write_all
//! [`io::Result`]: ../../std/io/type.Result.html
//! [`?`]: crate::ops::Try
//! [`Ok(T)`]: Ok
//! [`Err(E)`]: Err
//! [`io::Error`]: ../../std/io/struct.Error.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::iter::{self, FromIterator, FusedIterator, TrustedLen};
use crate::ops::{self, Deref, DerefMut};
use crate::{convert, fmt, hint};

/// `Result` ([`Ok`]) അല്ലെങ്കിൽ പരാജയം ([`Err`]) വിജയത്തെ പ്രതിനിധീകരിക്കുന്ന ഒരു തരമാണ്.
///
/// വിശദാംശങ്ങൾക്ക് [module documentation](self) കാണുക.
#[derive(Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[must_use = "this `Result` may be an `Err` variant, which should be handled"]
#[rustc_diagnostic_item = "result_type"]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Result<T, E> {
    /// വിജയ മൂല്യം അടങ്ങിയിരിക്കുന്നു
    #[lang = "Ok"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Ok(#[stable(feature = "rust1", since = "1.0.0")] T),

    /// പിശക് മൂല്യം അടങ്ങിയിരിക്കുന്നു
    #[lang = "Err"]
    #[stable(feature = "rust1", since = "1.0.0")]
    Err(#[stable(feature = "rust1", since = "1.0.0")] E),
}

/////////////////////////////////////////////////////////////////////////////
// ടൈപ്പ് നടപ്പിലാക്കൽ
/////////////////////////////////////////////////////////////////////////////

impl<T, E> Result<T, E> {
    /////////////////////////////////////////////////////////////////////////
    // അടങ്ങിയിരിക്കുന്ന മൂല്യങ്ങൾ അന്വേഷിക്കുന്നു
    /////////////////////////////////////////////////////////////////////////

    /// ഫലം [`Ok`] ആണെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_ok(), true);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_ok(), false);
    /// ```
    #[must_use = "if you intended to assert that this is ok, consider `.unwrap()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_ok(&self) -> bool {
        matches!(*self, Ok(_))
    }

    /// ഫലം [`Err`] ആണെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let x: Result<i32, &str> = Ok(-3);
    /// assert_eq!(x.is_err(), false);
    ///
    /// let x: Result<i32, &str> = Err("Some error message");
    /// assert_eq!(x.is_err(), true);
    /// ```
    #[must_use = "if you intended to assert that this is err, consider `.unwrap_err()` instead"]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn is_err(&self) -> bool {
        !self.is_ok()
    }

    /// തന്നിരിക്കുന്ന മൂല്യം അടങ്ങിയ [`Ok`] മൂല്യമാണെങ്കിൽ ഫലം `true` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_contains)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains(&2), true);
    ///
    /// let x: Result<u32, &str> = Ok(3);
    /// assert_eq!(x.contains(&2), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains(&2), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "option_result_contains", issue = "62358")]
    pub fn contains<U>(&self, x: &U) -> bool
    where
        U: PartialEq<T>,
    {
        match self {
            Ok(y) => x == y,
            Err(_) => false,
        }
    }

    /// തന്നിരിക്കുന്ന മൂല്യം അടങ്ങിയ [`Err`] മൂല്യമാണെങ്കിൽ ഫലം `true` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_contains_err)]
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    ///
    /// let x: Result<u32, &str> = Err("Some error message");
    /// assert_eq!(x.contains_err(&"Some error message"), true);
    ///
    /// let x: Result<u32, &str> = Err("Some other error message");
    /// assert_eq!(x.contains_err(&"Some error message"), false);
    /// ```
    #[must_use]
    #[inline]
    #[unstable(feature = "result_contains_err", issue = "62358")]
    pub fn contains_err<F>(&self, f: &F) -> bool
    where
        F: PartialEq<E>,
    {
        match self {
            Ok(_) => false,
            Err(e) => f == e,
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // ഓരോ വേരിയന്റിനുമുള്ള അഡാപ്റ്റർ
    /////////////////////////////////////////////////////////////////////////

    /// `Result<T, E>`-ൽ നിന്ന് [`Option<T>`]-ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// `self`-നെ [`Option<T>`]-ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു, `self` ഉപയോഗിക്കുന്നു, പിശക് ഉണ്ടെങ്കിൽ അവ ഉപേക്ഷിക്കുക.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.ok(), Some(2));
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.ok(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ok(self) -> Option<T> {
        match self {
            Ok(x) => Some(x),
            Err(_) => None,
        }
    }

    /// `Result<T, E>`-ൽ നിന്ന് [`Option<E>`]-ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// `self`-നെ [`Option<E>`]-ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു, `self` ഉപയോഗിക്കുന്നു, വിജയമൂല്യമുണ്ടെങ്കിൽ അവ ഉപേക്ഷിക്കുക.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.err(), None);
    ///
    /// let x: Result<u32, &str> = Err("Nothing here");
    /// assert_eq!(x.err(), Some("Nothing here"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn err(self) -> Option<E> {
        match self {
            Ok(_) => None,
            Err(x) => Some(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // റഫറൻസുകളിൽ പ്രവർത്തിക്കുന്നതിനുള്ള അഡാപ്റ്റർ
    /////////////////////////////////////////////////////////////////////////

    /// `&Result<T, E>`-ൽ നിന്ന് `Result<&T, &E>`-ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// ഒരു പുതിയ `Result` നിർമ്മിക്കുന്നു, ഒറിജിനലിലേക്ക് ഒരു റഫറൻസ് അടങ്ങിയിരിക്കുന്നു, ഒറിജിനലിനെ സ്ഥാനത്ത് നിർത്തുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.as_ref(), Ok(&2));
    ///
    /// let x: Result<u32, &str> = Err("Error");
    /// assert_eq!(x.as_ref(), Err(&"Error"));
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_result", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn as_ref(&self) -> Result<&T, &E> {
        match *self {
            Ok(ref x) => Ok(x),
            Err(ref x) => Err(x),
        }
    }

    /// `&mut Result<T, E>`-ൽ നിന്ന് `Result<&mut T, &mut E>`-ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// fn mutate(r: &mut Result<i32, i32>) {
    ///     match r.as_mut() {
    ///         Ok(v) => *v = 42,
    ///         Err(e) => *e = 0,
    ///     }
    /// }
    ///
    /// let mut x: Result<i32, i32> = Ok(2);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap(), 42);
    ///
    /// let mut x: Result<i32, i32> = Err(13);
    /// mutate(&mut x);
    /// assert_eq!(x.unwrap_err(), 0);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_mut(&mut self) -> Result<&mut T, &mut E> {
        match *self {
            Ok(ref mut x) => Ok(x),
            Err(ref mut x) => Err(x),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // അടങ്ങിയിരിക്കുന്ന മൂല്യങ്ങൾ പരിവർത്തനം ചെയ്യുന്നു
    /////////////////////////////////////////////////////////////////////////

    /// അടങ്ങിയിരിക്കുന്ന [`Ok`] മൂല്യത്തിലേക്ക് ഒരു ഫംഗ്ഷൻ പ്രയോഗിച്ചുകൊണ്ട് ഒരു `Result<T, E>` മുതൽ `Result<U, E>` വരെ മാപ്പ് ചെയ്യുന്നു, ഒരു [`Err`] മൂല്യം സ്പർശിക്കാതെ വിടുന്നു.
    ///
    ///
    /// രണ്ട് ഫംഗ്ഷനുകളുടെ ഫലങ്ങൾ രചിക്കാൻ ഈ ഫംഗ്ഷൻ ഉപയോഗിക്കാം.
    ///
    /// # Examples
    ///
    /// ഒരു സ്ട്രിംഗിന്റെ ഓരോ വരിയിലും രണ്ടായി ഗുണിച്ച അക്കങ്ങൾ അച്ചടിക്കുക.
    ///
    /// ```
    /// let line = "1\n2\n3\n4\n";
    ///
    /// for num in line.lines() {
    ///     match num.parse::<i32>().map(|i| i * 2) {
    ///         Ok(n) => println!("{}", n),
    ///         Err(..) => {}
    ///     }
    /// }
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map<U, F: FnOnce(T) -> U>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => Ok(op(t)),
            Err(e) => Err(e),
        }
    }

    /// അടങ്ങിയിരിക്കുന്ന മൂല്യത്തിലേക്ക് ([`Ok`] ആണെങ്കിൽ) ഒരു ഫംഗ്ഷൻ പ്രയോഗിക്കുന്നു, അല്ലെങ്കിൽ നൽകിയ സ്ഥിരസ്ഥിതി നൽകുന്നു ([`Err`] എങ്കിൽ).
    ///
    /// `map_or`-ലേക്ക് കൈമാറിയ ആർഗ്യുമെന്റുകൾ ആകാംക്ഷയോടെ വിലയിരുത്തപ്പെടുന്നു;നിങ്ങൾ ഒരു ഫംഗ്ഷൻ കോളിന്റെ ഫലം കൈമാറുകയാണെങ്കിൽ, [`map_or_else`] ഉപയോഗിക്കാൻ ശുപാർശചെയ്യുന്നു, അത് അലസമായി വിലയിരുത്തപ്പെടുന്നു.
    ///
    ///
    /// [`map_or_else`]: Result::map_or_else
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or(42, |v| v.len()), 3);
    ///
    /// let x: Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or(42, |v| v.len()), 42);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or", since = "1.41.0")]
    pub fn map_or<U, F: FnOnce(T) -> U>(self, default: U, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(_) => default,
        }
    }

    /// അടങ്ങിയിരിക്കുന്ന [`Ok`] മൂല്യത്തിലേക്ക് ഒരു ഫംഗ്ഷൻ പ്രയോഗിച്ചുകൊണ്ട് ഒരു `Result<T, E>` മുതൽ `U` വരെ മാപ്പ് ചെയ്യുക, അല്ലെങ്കിൽ അടങ്ങിയിരിക്കുന്ന [`Err`] മൂല്യത്തിലേക്ക് ഒരു ഫോൾബാക്ക് ഫംഗ്ഷൻ.
    ///
    ///
    /// ഒരു പിശക് കൈകാര്യം ചെയ്യുമ്പോൾ വിജയകരമായ ഫലം അൺപാക്ക് ചെയ്യുന്നതിന് ഈ ഫംഗ്ഷൻ ഉപയോഗിക്കാം.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let k = 21;
    ///
    /// let x : Result<_, &str> = Ok("foo");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 3);
    ///
    /// let x : Result<&str, _> = Err("bar");
    /// assert_eq!(x.map_or_else(|e| k * 2, |v| v.len()), 42);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_map_or_else", since = "1.41.0")]
    pub fn map_or_else<U, D: FnOnce(E) -> U, F: FnOnce(T) -> U>(self, default: D, f: F) -> U {
        match self {
            Ok(t) => f(t),
            Err(e) => default(e),
        }
    }

    /// അടങ്ങിയിരിക്കുന്ന [`Err`] മൂല്യത്തിലേക്ക് ഒരു ഫംഗ്ഷൻ പ്രയോഗിച്ചുകൊണ്ട് ഒരു `Result<T, E>` മുതൽ `Result<T, F>` വരെ മാപ്പ് ചെയ്യുന്നു, ഒരു [`Ok`] മൂല്യം സ്പർശിക്കാതെ വിടുന്നു.
    ///
    ///
    /// ഒരു പിശക് കൈകാര്യം ചെയ്യുമ്പോൾ വിജയകരമായ ഒരു ഫലത്തിലൂടെ കടന്നുപോകാൻ ഈ ഫംഗ്ഷൻ ഉപയോഗിക്കാം.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// fn stringify(x: u32) -> String { format!("error code: {}", x) }
    ///
    /// let x: Result<u32, u32> = Ok(2);
    /// assert_eq!(x.map_err(stringify), Ok(2));
    ///
    /// let x: Result<u32, u32> = Err(13);
    /// assert_eq!(x.map_err(stringify), Err("error code: 13".to_string()));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn map_err<F, O: FnOnce(E) -> F>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => Err(op(e)),
        }
    }

    /////////////////////////////////////////////////////////////////////////
    // ആവർത്തന നിർമ്മാതാക്കൾ
    /////////////////////////////////////////////////////////////////////////

    /// അടങ്ങിയിരിക്കുന്ന മൂല്യത്തിന് മുകളിൽ ഒരു ഇറ്ററേറ്റർ നൽകുന്നു.
    ///
    /// ഫലം [`Result::Ok`] ആണെങ്കിൽ ആവർത്തനം ഒരു മൂല്യം നൽകുന്നു, അല്ലാത്തപക്ഷം.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(7);
    /// assert_eq!(x.iter().next(), Some(&7));
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { inner: self.as_ref().ok() }
    }

    /// അടങ്ങിയിരിക്കുന്ന മൂല്യത്തിന് മുകളിൽ ഒരു മ്യൂട്ടബിൾ ഇറ്ററേറ്റർ നൽകുന്നു.
    ///
    /// ഫലം [`Result::Ok`] ആണെങ്കിൽ ആവർത്തനം ഒരു മൂല്യം നൽകുന്നു, അല്ലാത്തപക്ഷം.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let mut x: Result<u32, &str> = Ok(7);
    /// match x.iter_mut().next() {
    ///     Some(v) => *v = 40,
    ///     None => {},
    /// }
    /// assert_eq!(x, Ok(40));
    ///
    /// let mut x: Result<u32, &str> = Err("nothing!");
    /// assert_eq!(x.iter_mut().next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { inner: self.as_mut().ok() }
    }

    ////////////////////////////////////////////////////////////////////////
    // മൂല്യങ്ങളിൽ ബൂളിയൻ പ്രവർത്തനങ്ങൾ, ആകാംക്ഷയും മടിയനും
    /////////////////////////////////////////////////////////////////////////

    /// ഫലം [`Ok`] ആണെങ്കിൽ `res` നൽകുന്നു, അല്ലാത്തപക്ഷം `self`-ന്റെ [`Err`] മൂല്യം നൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<&str, &str> = Ok("foo");
    /// assert_eq!(x.and(y), Err("early error"));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<&str, &str> = Err("late error");
    /// assert_eq!(x.and(y), Err("not a 2"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<&str, &str> = Ok("different result type");
    /// assert_eq!(x.and(y), Ok("different result type"));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and<U>(self, res: Result<U, E>) -> Result<U, E> {
        match self {
            Ok(_) => res,
            Err(e) => Err(e),
        }
    }

    /// ഫലം [`Ok`] ആണെങ്കിൽ `op`-നെ വിളിക്കുന്നു, അല്ലാത്തപക്ഷം `self`-ന്റെ [`Err`] മൂല്യം നൽകുന്നു.
    ///
    ///
    /// `Result` മൂല്യങ്ങളെ അടിസ്ഥാനമാക്കിയുള്ള നിയന്ത്രണ പ്രവാഹത്തിനായി ഈ ഫംഗ്ഷൻ ഉപയോഗിക്കാം.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).and_then(sq).and_then(sq), Ok(16));
    /// assert_eq!(Ok(2).and_then(sq).and_then(err), Err(4));
    /// assert_eq!(Ok(2).and_then(err).and_then(sq), Err(2));
    /// assert_eq!(Err(3).and_then(sq).and_then(sq), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn and_then<U, F: FnOnce(T) -> Result<U, E>>(self, op: F) -> Result<U, E> {
        match self {
            Ok(t) => op(t),
            Err(e) => Err(e),
        }
    }

    /// ഫലം [`Err`] ആണെങ്കിൽ `res` നൽകുന്നു, അല്ലാത്തപക്ഷം `self`-ന്റെ [`Ok`] മൂല്യം നൽകുന്നു.
    ///
    /// `or`-ലേക്ക് കൈമാറിയ ആർഗ്യുമെന്റുകൾ ആകാംക്ഷയോടെ വിലയിരുത്തപ്പെടുന്നു;നിങ്ങൾ ഒരു ഫംഗ്ഷൻ കോളിന്റെ ഫലം കൈമാറുകയാണെങ്കിൽ, [`or_else`] ഉപയോഗിക്കാൻ ശുപാർശചെയ്യുന്നു, അത് അലസമായി വിലയിരുത്തപ്പെടുന്നു.
    ///
    ///
    /// [`or_else`]: Result::or_else
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("early error");
    /// let y: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.or(y), Ok(2));
    ///
    /// let x: Result<u32, &str> = Err("not a 2");
    /// let y: Result<u32, &str> = Err("late error");
    /// assert_eq!(x.or(y), Err("late error"));
    ///
    /// let x: Result<u32, &str> = Ok(2);
    /// let y: Result<u32, &str> = Ok(100);
    /// assert_eq!(x.or(y), Ok(2));
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or<F>(self, res: Result<T, F>) -> Result<T, F> {
        match self {
            Ok(v) => Ok(v),
            Err(_) => res,
        }
    }

    /// ഫലം [`Err`] ആണെങ്കിൽ `op`-നെ വിളിക്കുന്നു, അല്ലാത്തപക്ഷം `self`-ന്റെ [`Ok`] മൂല്യം നൽകുന്നു.
    ///
    ///
    /// ഫല മൂല്യങ്ങളെ അടിസ്ഥാനമാക്കിയുള്ള നിയന്ത്രണ പ്രവാഹത്തിനായി ഈ ഫംഗ്ഷൻ ഉപയോഗിക്കാം.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// fn sq(x: u32) -> Result<u32, u32> { Ok(x * x) }
    /// fn err(x: u32) -> Result<u32, u32> { Err(x) }
    ///
    /// assert_eq!(Ok(2).or_else(sq).or_else(sq), Ok(2));
    /// assert_eq!(Ok(2).or_else(err).or_else(sq), Ok(2));
    /// assert_eq!(Err(3).or_else(sq).or_else(err), Ok(9));
    /// assert_eq!(Err(3).or_else(err).or_else(err), Err(3));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_else<F, O: FnOnce(E) -> Result<T, F>>(self, op: O) -> Result<T, F> {
        match self {
            Ok(t) => Ok(t),
            Err(e) => op(e),
        }
    }

    /// അടങ്ങിയിരിക്കുന്ന [`Ok`] മൂല്യം അല്ലെങ്കിൽ നൽകിയ സ്ഥിരസ്ഥിതി നൽകുന്നു.
    ///
    /// `unwrap_or`-ലേക്ക് കൈമാറിയ ആർഗ്യുമെന്റുകൾ ആകാംക്ഷയോടെ വിലയിരുത്തപ്പെടുന്നു;നിങ്ങൾ ഒരു ഫംഗ്ഷൻ കോളിന്റെ ഫലം കൈമാറുകയാണെങ്കിൽ, [`unwrap_or_else`] ഉപയോഗിക്കാൻ ശുപാർശചെയ്യുന്നു, അത് അലസമായി വിലയിരുത്തപ്പെടുന്നു.
    ///
    ///
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let default = 2;
    /// let x: Result<u32, &str> = Ok(9);
    /// assert_eq!(x.unwrap_or(default), 9);
    ///
    /// let x: Result<u32, &str> = Err("error");
    /// assert_eq!(x.unwrap_or(default), default);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or(self, default: T) -> T {
        match self {
            Ok(t) => t,
            Err(_) => default,
        }
    }

    /// അടങ്ങിയിരിക്കുന്ന [`Ok`] മൂല്യം നൽകുന്നു അല്ലെങ്കിൽ ഒരു ക്ലോസറിൽ നിന്ന് കണക്കാക്കുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// fn count(x: &str) -> usize { x.len() }
    ///
    /// assert_eq!(Ok(2).unwrap_or_else(count), 2);
    /// assert_eq!(Err("foo").unwrap_or_else(count), 3);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_or_else<F: FnOnce(E) -> T>(self, op: F) -> T {
        match self {
            Ok(t) => t,
            Err(e) => op(e),
        }
    }

    /// മൂല്യം [`Err`] അല്ലെന്ന് പരിശോധിക്കാതെ, `self` മൂല്യം ഉപയോഗിക്കുന്ന [`Ok`] മൂല്യം നൽകുന്നു.
    ///
    ///
    /// # Safety
    ///
    /// [`Err`]-ൽ ഈ രീതിയെ വിളിക്കുന്നത് *[നിർവചിക്കപ്പെടാത്ത പെരുമാറ്റം]* ആണ്.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(unsafe { x.unwrap_unchecked() }, 2);
    /// ```
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// unsafe { x.unwrap_unchecked(); } // നിർവചിക്കപ്പെടാത്ത പെരുമാറ്റം!
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_unchecked(self) -> T {
        debug_assert!(self.is_ok());
        match self {
            Ok(t) => t,
            // സുരക്ഷ: സുരക്ഷാ കരാർ വിളിക്കുന്നയാൾ ശരിവെക്കണം.
            Err(_) => unsafe { hint::unreachable_unchecked() },
        }
    }

    /// മൂല്യം [`Ok`] അല്ലെന്ന് പരിശോധിക്കാതെ, `self` മൂല്യം ഉപയോഗിക്കുന്ന [`Err`] മൂല്യം നൽകുന്നു.
    ///
    ///
    /// # Safety
    ///
    /// [`Ok`]-ൽ ഈ രീതിയെ വിളിക്കുന്നത് *[നിർവചിക്കപ്പെടാത്ത പെരുമാറ്റം]* ആണ്.
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Ok(2);
    /// unsafe { x.unwrap_err_unchecked() }; // നിർവചിക്കപ്പെടാത്ത പെരുമാറ്റം!
    /// ```
    ///
    /// ```
    /// #![feature(option_result_unwrap_unchecked)]
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(unsafe { x.unwrap_err_unchecked() }, "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[unstable(feature = "option_result_unwrap_unchecked", reason = "newly added", issue = "81383")]
    pub unsafe fn unwrap_err_unchecked(self) -> E {
        debug_assert!(self.is_err());
        match self {
            // സുരക്ഷ: സുരക്ഷാ കരാർ വിളിക്കുന്നയാൾ ശരിവെക്കണം.
            Ok(_) => unsafe { hint::unreachable_unchecked() },
            Err(e) => e,
        }
    }
}

impl<T: Copy, E> Result<&T, E> {
    /// `Ok` ഭാഗത്തിന്റെ ഉള്ളടക്കങ്ങൾ‌പകർ‌ത്തി ഒരു `Result<&T, E>` ഒരു `Result<T, E>` ലേക്ക് മാപ്പുചെയ്യുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&t| t)
    }
}

impl<T: Copy, E> Result<&mut T, E> {
    /// `Ok` ഭാഗത്തിന്റെ ഉള്ളടക്കങ്ങൾ‌പകർ‌ത്തി ഒരു `Result<&mut T, E>` ഒരു `Result<T, E>` ലേക്ക് മാപ്പുചെയ്യുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_copied)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let copied = x.copied();
    /// assert_eq!(copied, Ok(12));
    /// ```
    #[unstable(feature = "result_copied", reason = "newly added", issue = "63168")]
    pub fn copied(self) -> Result<T, E> {
        self.map(|&mut t| t)
    }
}

impl<T: Clone, E> Result<&T, E> {
    /// `Ok` ഭാഗത്തിന്റെ ഉള്ളടക്കങ്ങൾ ക്ലോൺ ചെയ്തുകൊണ്ട് ഒരു `Result<&T, E>` മുതൽ `Result<T, E>` വരെ മാപ്പ് ചെയ്യുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let val = 12;
    /// let x: Result<&i32, i32> = Ok(&val);
    /// assert_eq!(x, Ok(&12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T: Clone, E> Result<&mut T, E> {
    /// `Ok` ഭാഗത്തിന്റെ ഉള്ളടക്കങ്ങൾ ക്ലോൺ ചെയ്തുകൊണ്ട് ഒരു `Result<&mut T, E>` മുതൽ `Result<T, E>` വരെ മാപ്പ് ചെയ്യുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_cloned)]
    /// let mut val = 12;
    /// let x: Result<&mut i32, i32> = Ok(&mut val);
    /// assert_eq!(x, Ok(&mut 12));
    /// let cloned = x.cloned();
    /// assert_eq!(cloned, Ok(12));
    /// ```
    #[unstable(feature = "result_cloned", reason = "newly added", issue = "63168")]
    pub fn cloned(self) -> Result<T, E> {
        self.map(|t| t.clone())
    }
}

impl<T, E: fmt::Debug> Result<T, E> {
    /// അടങ്ങിയിരിക്കുന്ന [`Ok`] മൂല്യം നൽകുന്നു, `self` മൂല്യം ഉപയോഗിക്കുന്നു.
    ///
    /// # Panics
    ///
    /// Panics മൂല്യം ഒരു [`Err`] ആണെങ്കിൽ, കടന്നുപോയ സന്ദേശം ഉൾപ്പെടെ panic സന്ദേശവും [`Err`]-ന്റെ ഉള്ളടക്കവും.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.expect("Testing expect"); // panics with `Testing expect: emergency failure`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect", since = "1.4.0")]
    pub fn expect(self, msg: &str) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed(msg, &e),
        }
    }

    /// അടങ്ങിയിരിക്കുന്ന [`Ok`] മൂല്യം നൽകുന്നു, `self` മൂല്യം ഉപയോഗിക്കുന്നു.
    ///
    /// ഈ പ്രവർത്തനം panic ആയിരിക്കാം, ഇതിന്റെ ഉപയോഗം പൊതുവെ നിരുത്സാഹപ്പെടുത്തുന്നു.
    /// പകരം, പാറ്റേൺ പൊരുത്തപ്പെടുത്തൽ ഉപയോഗിക്കാനും [`Err`] കേസ് വ്യക്തമായി കൈകാര്യം ചെയ്യാനും തിരഞ്ഞെടുക്കുക, അല്ലെങ്കിൽ [`unwrap_or`], [`unwrap_or_else`], അല്ലെങ്കിൽ [`unwrap_or_default`] എന്ന് വിളിക്കുക.
    ///
    ///
    /// [`unwrap_or`]: Result::unwrap_or
    /// [`unwrap_or_else`]: Result::unwrap_or_else
    /// [`unwrap_or_default`]: Result::unwrap_or_default
    ///
    /// # Panics
    ///
    /// Panics മൂല്യം ഒരു [`Err`] ആണെങ്കിൽ, [`Err`] ന്റെ മൂല്യം നൽകുന്ന panic സന്ദേശം.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(2);
    /// assert_eq!(x.unwrap(), 2);
    /// ```
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// x.unwrap(); // panics with `emergency failure`
    /// ```
    ///
    ///
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap(self) -> T {
        match self {
            Ok(t) => t,
            Err(e) => unwrap_failed("called `Result::unwrap()` on an `Err` value", &e),
        }
    }
}

impl<T: fmt::Debug, E> Result<T, E> {
    /// അടങ്ങിയിരിക്കുന്ന [`Err`] മൂല്യം നൽകുന്നു, `self` മൂല്യം ഉപയോഗിക്കുന്നു.
    ///
    /// # Panics
    ///
    /// Panics മൂല്യം ഒരു [`Ok`] ആണെങ്കിൽ, കടന്നുപോയ സന്ദേശം ഉൾപ്പെടെ panic സന്ദേശവും [`Ok`]-ന്റെ ഉള്ളടക്കവും.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(10);
    /// x.expect_err("Testing expect_err"); // panics with `Testing expect_err: 10`
    /// ```
    ///
    #[inline]
    #[track_caller]
    #[stable(feature = "result_expect_err", since = "1.17.0")]
    pub fn expect_err(self, msg: &str) -> E {
        match self {
            Ok(t) => unwrap_failed(msg, &t),
            Err(e) => e,
        }
    }

    /// അടങ്ങിയിരിക്കുന്ന [`Err`] മൂല്യം നൽകുന്നു, `self` മൂല്യം ഉപയോഗിക്കുന്നു.
    ///
    /// # Panics
    ///
    /// Panics മൂല്യം ഒരു [`Ok`] ആണെങ്കിൽ, [`ശരി`] ന്റെ മൂല്യം നൽകുന്ന ഒരു ഇച്ഛാനുസൃത panic സന്ദേശം.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// let x: Result<u32, &str> = Ok(2);
    /// x.unwrap_err(); // panics with `2`
    /// ```
    ///
    /// ```
    /// let x: Result<u32, &str> = Err("emergency failure");
    /// assert_eq!(x.unwrap_err(), "emergency failure");
    /// ```
    #[inline]
    #[track_caller]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn unwrap_err(self) -> E {
        match self {
            Ok(t) => unwrap_failed("called `Result::unwrap_err()` on an `Ok` value", &t),
            Err(e) => e,
        }
    }
}

impl<T: Default, E> Result<T, E> {
    /// അടങ്ങിയിരിക്കുന്ന [`Ok`] മൂല്യം അല്ലെങ്കിൽ സ്ഥിരസ്ഥിതി നൽകുന്നു
    ///
    /// `self` ആർ‌ഗ്യുമെൻറ് ഉപയോഗിക്കുന്നു, [`Ok`] ആണെങ്കിൽ‌, അടങ്ങിയിരിക്കുന്ന മൂല്യം നൽകുന്നു, അല്ലെങ്കിൽ‌[`Err`] ആണെങ്കിൽ‌, ആ തരത്തിനായി സ്ഥിര മൂല്യം നൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ഒരു സ്ട്രിംഗിനെ ഒരു പൂർണ്ണസംഖ്യയിലേക്ക് പരിവർത്തനം ചെയ്യുന്നു, മോശമായി രൂപംകൊണ്ട സ്ട്രിംഗുകളെ 0 ആക്കി മാറ്റുന്നു (പൂർണ്ണസംഖ്യകളുടെ സ്ഥിര മൂല്യം).
    /// [`parse`] [`FromStr`] നടപ്പിലാക്കുന്ന മറ്റേതെങ്കിലും തരത്തിലേക്ക് ഒരു സ്ട്രിംഗ് പരിവർത്തനം ചെയ്യുന്നു, പിശകിൽ ഒരു [`Err`] നൽകുന്നു.
    ///
    /// ```
    /// let good_year_from_input = "1909";
    /// let bad_year_from_input = "190blarg";
    /// let good_year = good_year_from_input.parse().unwrap_or_default();
    /// let bad_year = bad_year_from_input.parse().unwrap_or_default();
    ///
    /// assert_eq!(1909, good_year);
    /// assert_eq!(0, bad_year);
    /// ```
    ///
    /// [`parse`]: str::parse
    /// [`FromStr`]: crate::str::FromStr
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "result_unwrap_or_default", since = "1.16.0")]
    pub fn unwrap_or_default(self) -> T {
        match self {
            Ok(x) => x,
            Err(_) => Default::default(),
        }
    }
}

#[unstable(feature = "unwrap_infallible", reason = "newly added", issue = "61695")]
impl<T, E: Into<!>> Result<T, E> {
    /// അടങ്ങിയിരിക്കുന്ന [`Ok`] മൂല്യം നൽകുന്നു, പക്ഷേ ഒരിക്കലും panics.
    ///
    /// [`unwrap`]-ൽ നിന്ന് വ്യത്യസ്തമായി, ഈ രീതി നടപ്പിലാക്കിയ ഫല തരങ്ങളിൽ ഒരിക്കലും panic എന്ന് അറിയപ്പെടുന്നില്ല.
    /// അതിനാൽ,`unwrap`-ന് പകരമായി ഇത് നിലനിർത്താൻ കഴിയുന്ന ഒരു പരിരക്ഷണമായി ഉപയോഗിക്കാൻ കഴിയും, ഇത് `Result`-ന്റെ പിശക് തരം പിന്നീട് യഥാർത്ഥത്തിൽ സംഭവിക്കാവുന്ന ഒരു പിശകിലേക്ക് മാറ്റുകയാണെങ്കിൽ കംപൈൽ ചെയ്യുന്നതിൽ പരാജയപ്പെടും.
    ///
    ///
    /// [`unwrap`]: Result::unwrap
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// # #![feature(never_type)]
    /// # #![feature(unwrap_infallible)]
    ///
    /// fn only_good_news() -> Result<String, !> {
    ///     Ok("this is fine".into())
    /// }
    ///
    /// let s: String = only_good_news().into_ok();
    /// println!("{}", s);
    /// ```
    ///
    ///
    #[inline]
    pub fn into_ok(self) -> T {
        match self {
            Ok(x) => x,
            Err(e) => e.into(),
        }
    }
}

impl<T: Deref, E> Result<T, E> {
    /// `Result<T, E>` (അല്ലെങ്കിൽ `&Result<T, E>`) ൽ നിന്ന് `Result<&<T as Deref>::Target, &E>` ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// ഒറിജിനൽ [`Result`]-ന്റെ [`Ok`] വേരിയന്റിനെ [`Deref`](crate::ops::Deref) വഴി നിർബന്ധിച്ച് പുതിയ [`Result`] നൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&str, &u32> = Ok("hello");
    /// assert_eq!(x.as_deref(), y);
    ///
    /// let x: Result<String, u32> = Err(42);
    /// let y: Result<&str, &u32> = Err(&42);
    /// assert_eq!(x.as_deref(), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref(&self) -> Result<&T::Target, &E> {
        self.as_ref().map(|t| t.deref())
    }
}

impl<T: DerefMut, E> Result<T, E> {
    /// `Result<T, E>` (അല്ലെങ്കിൽ `&mut Result<T, E>`) ൽ നിന്ന് `Result<&mut <T as DerefMut>::Target, &mut E>` ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// ഒറിജിനൽ [`Result`]-ന്റെ [`Ok`] വേരിയന്റിനെ [`DerefMut`](crate::ops::DerefMut) വഴി നിർബന്ധിച്ച് പുതിയ [`Result`] നൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = "HELLO".to_string();
    /// let mut x: Result<String, u32> = Ok("hello".to_string());
    /// let y: Result<&mut str, &mut u32> = Ok(&mut s);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    ///
    /// let mut i = 42;
    /// let mut x: Result<String, u32> = Err(42);
    /// let y: Result<&mut str, &mut u32> = Err(&mut i);
    /// assert_eq!(x.as_deref_mut().map(|x| { x.make_ascii_uppercase(); x }), y);
    /// ```
    #[stable(feature = "inner_deref", since = "1.47.0")]
    pub fn as_deref_mut(&mut self) -> Result<&mut T::Target, &mut E> {
        self.as_mut().map(|t| t.deref_mut())
    }
}

impl<T, E> Result<Option<T>, E> {
    /// ഒരു `Option`-ന്റെ `Result` ഒരു `Result`-ന്റെ `Option`-ലേക്ക് മാറ്റുന്നു.
    ///
    /// `Ok(None)` `None` ലേക്ക് മാപ്പുചെയ്യും.
    /// `Ok(Some(_))` `Err(_)`, `Some(Ok(_))`, `Some(Err(_))` എന്നിവയിലേക്ക് മാപ്പുചെയ്യും.
    ///
    /// # Examples
    ///
    /// ```
    /// #[derive(Debug, Eq, PartialEq)]
    /// struct SomeErr;
    ///
    /// let x: Result<Option<i32>, SomeErr> = Ok(Some(5));
    /// let y: Option<Result<i32, SomeErr>> = Some(Ok(5));
    /// assert_eq!(x.transpose(), y);
    /// ```
    #[inline]
    #[stable(feature = "transpose_result", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_result", issue = "82814")]
    pub const fn transpose(self) -> Option<Result<T, E>> {
        match self {
            Ok(Some(x)) => Some(Ok(x)),
            Ok(None) => None,
            Err(e) => Some(Err(e)),
        }
    }
}

impl<T, E> Result<Result<T, E>, E> {
    /// `Result<Result<T, E>, E>`-ൽ നിന്ന് `Result<T, E>`-ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Ok("hello"));
    /// assert_eq!(Ok("hello"), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Ok(Err(6));
    /// assert_eq!(Err(6), x.flatten());
    ///
    /// let x: Result<Result<&'static str, u32>, u32> = Err(6);
    /// assert_eq!(Err(6), x.flatten());
    /// ```
    ///
    /// പരന്നത് ഒരു സമയം കൂടുണ്ടാക്കുന്നത് മാത്രമേ നീക്കംചെയ്യൂ:
    ///
    /// ```
    /// #![feature(result_flattening)]
    /// let x: Result<Result<Result<&'static str, u32>, u32>, u32> = Ok(Ok(Ok("hello")));
    /// assert_eq!(Ok(Ok("hello")), x.flatten());
    /// assert_eq!(Ok("hello"), x.flatten().flatten());
    /// ```
    #[inline]
    #[unstable(feature = "result_flattening", issue = "70142")]
    pub fn flatten(self) -> Result<T, E> {
        self.and_then(convert::identity)
    }
}

impl<T> Result<T, T> {
    /// `self` `Ok` ആണെങ്കിൽ [`Ok`] മൂല്യം നൽകുന്നു, `self` `Err` ആണെങ്കിൽ [`Err`] മൂല്യം നൽകുന്നു.
    ///
    /// മറ്റൊരു വിധത്തിൽ പറഞ്ഞാൽ, ഈ ഫലം `Ok` അല്ലെങ്കിൽ `Err` ആണോ ഇല്ലയോ എന്നത് പരിഗണിക്കാതെ തന്നെ, ഒരു `Result<T, T>` ന്റെ മൂല്യം (`T`) നൽകുന്നു.
    ///
    /// [`Atomic*::compare_exchange`], അല്ലെങ്കിൽ [`slice::binary_search`] പോലുള്ള API-കളുമായി ഇത് ഉപയോഗപ്രദമാകും, പക്ഷേ ഫലം `Ok` ആണോ ഇല്ലയോ എന്നത് നിങ്ങൾ ശ്രദ്ധിക്കാത്ത സന്ദർഭങ്ങളിൽ മാത്രം.
    ///
    ///
    /// [`Atomic*::compare_exchange`]: crate::sync::atomic::AtomicBool::compare_exchange
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(result_into_ok_or_err)]
    /// let ok: Result<u32, u32> = Ok(3);
    /// let err: Result<u32, u32> = Err(4);
    ///
    /// assert_eq!(ok.into_ok_or_err(), 3);
    /// assert_eq!(err.into_ok_or_err(), 4);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "result_into_ok_or_err", reason = "newly added", issue = "82223")]
    pub const fn into_ok_or_err(self) -> T {
        match self {
            Ok(v) => v,
            Err(v) => v,
        }
    }
}

// രീതികളുടെ കോഡ് വലുപ്പം കുറയ്ക്കുന്നതിനുള്ള ഒരു പ്രത്യേക പ്രവർത്തനമാണിത്
#[inline(never)]
#[cold]
#[track_caller]
fn unwrap_failed(msg: &str, error: &dyn fmt::Debug) -> ! {
    panic!("{}: {:?}", msg, error)
}

/////////////////////////////////////////////////////////////////////////////
// Trait നടപ്പിലാക്കലുകൾ
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, E: Clone> Clone for Result<T, E> {
    #[inline]
    fn clone(&self) -> Self {
        match self {
            Ok(x) => Ok(x.clone()),
            Err(x) => Err(x.clone()),
        }
    }

    #[inline]
    fn clone_from(&mut self, source: &Self) {
        match (self, source) {
            (Ok(to), Ok(from)) => to.clone_from(from),
            (Err(to), Err(from)) => to.clone_from(from),
            (to, from) => *to = from.clone(),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, E> IntoIterator for Result<T, E> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// അടങ്ങിയിരിക്കുന്ന മൂല്യത്തെക്കാൾ ഉപഭോഗ ഇറ്ററേറ്റർ നൽകുന്നു.
    ///
    /// ഫലം [`Result::Ok`] ആണെങ്കിൽ ആവർത്തനം ഒരു മൂല്യം നൽകുന്നു, അല്ലാത്തപക്ഷം.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let x: Result<u32, &str> = Ok(5);
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, [5]);
    ///
    /// let x: Result<u32, &str> = Err("nothing!");
    /// let v: Vec<u32> = x.into_iter().collect();
    /// assert_eq!(v, []);
    /// ```
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self.ok() }
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a Result<T, E> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(since = "1.4.0", feature = "result_iter")]
impl<'a, T, E> IntoIterator for &'a mut Result<T, E> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

/////////////////////////////////////////////////////////////////////////////
// ഫലം ആവർത്തിക്കുന്നവർ
/////////////////////////////////////////////////////////////////////////////

/// ഒരു [`Result`]-ന്റെ [`Ok`] വേരിയന്റിലേക്കുള്ള റഫറൻസിനു മുകളിലുള്ള ഒരു ഇറ്ററേറ്റർ.
///
/// ഫലം [`Ok`] ആണെങ്കിൽ ആവർത്തനം ഒരു മൂല്യം നൽകുന്നു, അല്ലാത്തപക്ഷം.
///
/// [`Result::iter`] സൃഷ്ടിച്ചത്.
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    inner: Option<&'a T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for Iter<'_, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    #[inline]
    fn clone(&self) -> Self {
        Iter { inner: self.inner }
    }
}

/// ഒരു [`Result`]-ന്റെ [`Ok`] വേരിയന്റിലേക്കുള്ള മ്യൂട്ടബിൾ റഫറൻസിന് മുകളിലുള്ള ഒരു ഇറ്ററേറ്റർ.
///
/// [`Result::iter_mut`] സൃഷ്ടിച്ചത്.
#[derive(Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    inner: Option<&'a mut T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IterMut<'_, A> {}

/// ഒരു [`Result`]-ന്റെ [`Ok`] വേരിയന്റിലെ മൂല്യത്തിന് മുകളിലുള്ള ഒരു ഇറ്ററേറ്റർ.
///
/// ഫലം [`Ok`] ആണെങ്കിൽ ആവർത്തനം ഒരു മൂല്യം നൽകുന്നു, അല്ലാത്തപക്ഷം.
///
/// [`Result`]-ലെ [`into_iter`] രീതി ഉപയോഗിച്ചാണ് ഈ ഘടന സൃഷ്ടിച്ചിരിക്കുന്നത് ([`IntoIterator`] trait നൽകിയതാണ്).
///
///
/// [`into_iter`]: IntoIterator::into_iter
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    inner: Option<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.take()
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let n = if self.inner.is_some() { 1 } else { 0 };
        (n, Some(n))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.inner.take()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A> TrustedLen for IntoIter<A> {}

/////////////////////////////////////////////////////////////////////////////
// FromIterator
/////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, E, V: FromIterator<A>> FromIterator<Result<A, E>> for Result<V, E> {
    /// `Iterator`-ലെ ഓരോ ഘടകങ്ങളും എടുക്കുന്നു: ഇത് ഒരു `Err` ആണെങ്കിൽ, കൂടുതൽ ഘടകങ്ങളൊന്നും എടുക്കുന്നില്ല, കൂടാതെ `Err` തിരികെ നൽകുന്നു.
    /// `Err` ഒന്നും സംഭവിച്ചില്ലെങ്കിൽ, ഓരോ `Result`-ന്റെയും മൂല്യങ്ങളുള്ള ഒരു കണ്ടെയ്നർ തിരികെ നൽകും.
    ///
    /// ഒരു vector-ലെ ഓരോ സംഖ്യയും വർദ്ധിപ്പിക്കുന്ന ഒരു ഉദാഹരണം ഇതാ, ഓവർഫ്ലോ പരിശോധിക്കുന്നു:
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_add(1).ok_or("Overflow!")
    /// ).collect();
    /// assert_eq!(res, Ok(vec![2, 3]));
    /// ```
    ///
    /// പൂർണ്ണസംഖ്യകളുടെ മറ്റൊരു പട്ടികയിൽ നിന്ന് ഒന്ന് കുറയ്ക്കാൻ ശ്രമിക്കുന്ന മറ്റൊരു ഉദാഹരണം ഇതാ, ഈ സമയം അണ്ടർഫ്ലോയ്‌ക്കായി പരിശോധിക്കുന്നു:
    ///
    /// ```
    /// let v = vec![1, 2, 0];
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32|
    ///     x.checked_sub(1).ok_or("Underflow!")
    /// ).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// ```
    ///
    /// മുമ്പത്തെ ഉദാഹരണത്തിലെ ഒരു വ്യതിയാനം ഇതാ, ആദ്യത്തെ `Err` ന് ശേഷം `iter` ൽ നിന്ന് കൂടുതൽ ഘടകങ്ങളൊന്നും എടുക്കുന്നില്ലെന്ന് കാണിക്കുന്നു.
    ///
    /// ```
    /// let v = vec![3, 2, 1, 10];
    /// let mut shared = 0;
    /// let res: Result<Vec<u32>, &'static str> = v.iter().map(|x: &u32| {
    ///     shared += x;
    ///     x.checked_sub(2).ok_or("Underflow!")
    /// }).collect();
    /// assert_eq!(res, Err("Underflow!"));
    /// assert_eq!(shared, 6);
    /// ```
    ///
    /// മൂന്നാമത്തെ ഘടകം ഒരു അണ്ടർഫ്ലോയ്ക്ക് കാരണമായതിനാൽ, കൂടുതൽ ഘടകങ്ങളൊന്നും എടുത്തില്ല, അതിനാൽ `shared`-ന്റെ അന്തിമ മൂല്യം 6 അല്ല (= `3 + 2 + 1`), 16 അല്ല.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn from_iter<I: IntoIterator<Item = Result<A, E>>>(iter: I) -> Result<V, E> {
        // FIXME(#11084): ഈ പ്രകടന ബഗ് അടയ്‌ക്കുമ്പോൾ ഇത് Iterator::scan ഉപയോഗിച്ച് മാറ്റിസ്ഥാപിക്കാം.
        //

        iter::process_results(iter.into_iter(), |i| i.collect())
    }
}

#[unstable(feature = "try_trait", issue = "42327")]
impl<T, E> ops::Try for Result<T, E> {
    type Ok = T;
    type Error = E;

    #[inline]
    fn into_result(self) -> Self {
        self
    }

    #[inline]
    fn from_ok(v: T) -> Self {
        Ok(v)
    }

    #[inline]
    fn from_error(v: E) -> Self {
        Err(v)
    }
}