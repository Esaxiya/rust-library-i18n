//! 'വ്യക്തമായി പകർ‌ത്താൻ‌കഴിയാത്ത' തരങ്ങൾ‌ക്കായുള്ള `Clone` trait.
//!
//! Rust-ൽ, ചില ലളിതമായ തരങ്ങൾ "implicitly copyable" ആണ്, നിങ്ങൾ അവ നൽകുമ്പോഴോ അവ ആർഗ്യുമെന്റുകളായി നൽകുമ്പോഴോ, സ്വീകർത്താവിന് ഒരു പകർപ്പ് ലഭിക്കും, യഥാർത്ഥ മൂല്യം അവശേഷിക്കുന്നു.
//! ഈ തരങ്ങൾ‌ക്ക് പകർ‌ത്തുന്നതിന് അലോക്കേഷൻ‌ആവശ്യമില്ല, കൂടാതെ ഫൈനലൈസറുകൾ‌ഇല്ല (അതായത്, അവയിൽ‌ഉടമസ്ഥതയിലുള്ള ബോക്സുകൾ‌അടങ്ങിയിട്ടില്ല അല്ലെങ്കിൽ‌എക്സ് 100 എക്സ് നടപ്പിലാക്കുന്നു), അതിനാൽ‌കംപൈലർ‌അവ വിലകുറഞ്ഞതും പകർ‌ത്തുന്നതിന് സുരക്ഷിതവുമാണെന്ന് കണക്കാക്കുന്നു.
//!
//! കൺവെൻഷൻ [`Clone`] trait നടപ്പിലാക്കുകയും [`clone`] രീതി വിളിക്കുകയും ചെയ്യുന്നതിലൂടെ മറ്റ് തരങ്ങൾക്ക് പകർപ്പുകൾ വ്യക്തമായി നിർമ്മിക്കണം.
//!
//! [`clone`]: Clone::clone
//!
//! അടിസ്ഥാന ഉപയോഗ ഉദാഹരണം:
//!
//! ```
//! let s = String::new(); // സ്ട്രിംഗ് തരം ക്ലോൺ നടപ്പിലാക്കുന്നു
//! let copy = s.clone(); // അതിനാൽ നമുക്ക് അത് ക്ലോൺ ചെയ്യാൻ കഴിയും
//! ```
//!
//! trait ക്ലോൺ എളുപ്പത്തിൽ നടപ്പിലാക്കാൻ, നിങ്ങൾക്ക് `#[derive(Clone)]` ഉപയോഗിക്കാം.ഉദാഹരണം:
//!
//! ```
//! #[derive(Clone)] // ഞങ്ങൾ മോർഫിയസ് സ്ട്രക്റ്റിലേക്ക് trait ക്ലോൺ ചേർക്കുന്നു
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // ഇപ്പോൾ നമുക്ക് അത് ക്ലോൺ ചെയ്യാൻ കഴിയും!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// ഒബ്‌ജക്റ്റിനെ വ്യക്തമായി തനിപ്പകർപ്പാക്കാനുള്ള കഴിവിനുള്ള ഒരു പൊതു trait.
///
/// ആ [`Copy`]-ൽ [`Copy`]-ൽ നിന്ന് വ്യത്യസ്‌തമായത് വളരെ വ്യക്തവും വിലകുറഞ്ഞതുമാണ്, അതേസമയം `Clone` എല്ലായ്പ്പോഴും സ്‌പഷ്‌ടമാണ്, മാത്രമല്ല അവ വിലയേറിയതോ അല്ലാത്തതോ ആകാം.
/// ഈ സവിശേഷതകൾ നടപ്പിലാക്കുന്നതിന്, [`Copy`] വീണ്ടും നടപ്പിലാക്കാൻ Rust നിങ്ങളെ അനുവദിക്കുന്നില്ല, പക്ഷേ നിങ്ങൾക്ക് `Clone` വീണ്ടും നടപ്പിലാക്കുകയും അനിയന്ത്രിതമായ കോഡ് പ്രവർത്തിപ്പിക്കുകയും ചെയ്യാം.
///
/// `Clone`, [`Copy`] നേക്കാൾ പൊതുവായതിനാൽ, നിങ്ങൾക്ക് സ്വപ്രേരിതമായി [`Copy`]-നെ `Clone` ആക്കാനും കഴിയും.
///
/// ## Derivable
///
/// എല്ലാ ഫീൽഡുകളും `Clone` ആണെങ്കിൽ ഈ trait `#[derive]` ഉപയോഗിച്ച് ഉപയോഗിക്കാൻ കഴിയും.ഓരോ ഫീൽഡിലും [`Clone`] കോളുകളുടെ [`clone`]-ന്റെ `ഡെറിവ്` നടപ്പാക്കൽ.
///
/// [`clone`]: Clone::clone
///
/// ഒരു ജനറിക് സ്ട്രക്റ്റിനായി, ജനറിക് പാരാമീറ്ററുകളിൽ ബന്ധിത `Clone` ചേർത്ത് `#[derive]` സോപാധികമായി `Clone` നടപ്പിലാക്കുന്നു.
///
/// ```
/// // `derive` വായനയ്ക്കായി ക്ലോൺ നടപ്പിലാക്കുന്നു<T>ടി ക്ലോൺ ആയിരിക്കുമ്പോൾ.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## എനിക്ക് എങ്ങനെ `Clone` നടപ്പിലാക്കാൻ കഴിയും?
///
/// [`Copy`] ആയ തരങ്ങൾക്ക് `Clone`-ന്റെ നിസ്സാരമായ നടപ്പാക്കൽ ഉണ്ടായിരിക്കണം.കൂടുതൽ ly പചാരികമായി:
/// `T: Copy`, `x: T`, `y: &T` എന്നിവയാണെങ്കിൽ, `let x = y.clone();` എന്നത് `let x = *y;` ന് തുല്യമാണ്.
/// സ്വമേധയാലുള്ള നടപ്പാക്കലുകൾ ഈ മാറ്റത്തെ ഉയർത്തിപ്പിടിക്കാൻ ശ്രദ്ധിക്കണം;എന്നിരുന്നാലും, മെമ്മറി സുരക്ഷ ഉറപ്പാക്കാൻ സുരക്ഷിതമല്ലാത്ത കോഡ് അതിനെ ആശ്രയിക്കരുത്.
///
/// ഒരു ഫംഗ്ഷൻ പോയിന്റർ കൈവശമുള്ള ഒരു പൊതു ഘടനയാണ് ഒരു ഉദാഹരണം.ഈ സാഹചര്യത്തിൽ, `Clone` നടപ്പിലാക്കുന്നത് `ഡെറിവ്` ചെയ്യാൻ കഴിയില്ല, പക്ഷേ ഇത് ഇനിപ്പറയുന്ന രീതിയിൽ നടപ്പിലാക്കാൻ കഴിയും:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## അധിക നടപ്പിലാക്കുന്നവർ
///
/// [implementors listed below][impls] ന് പുറമേ, ഇനിപ്പറയുന്ന തരങ്ങളും `Clone` നടപ്പിലാക്കുന്നു:
///
/// * പ്രവർത്തന ഇന തരങ്ങൾ (അതായത്, ഓരോ പ്രവർത്തനത്തിനും നിർവചിച്ചിരിക്കുന്ന വ്യത്യസ്ത തരം)
/// * ഫംഗ്ഷൻ പോയിന്റർ തരങ്ങൾ (ഉദാ. `fn() -> i32`)
/// * ഇന തരവും `Clone` (ഉദാ. `[i32; 123456]`) നടപ്പിലാക്കുകയാണെങ്കിൽ, എല്ലാ വലുപ്പങ്ങൾക്കും അറേ തരങ്ങൾ
/// * ടുപ്പിൾ തരങ്ങൾ, ഓരോ ഘടകവും `Clone` (ഉദാ. `()`, `(i32, bool)`) നടപ്പിലാക്കുകയാണെങ്കിൽ
/// * അടയ്ക്കൽ തരങ്ങൾ, അവ പരിസ്ഥിതിയിൽ നിന്ന് ഒരു മൂല്യവും പിടിച്ചെടുക്കുകയോ അല്ലെങ്കിൽ പിടിച്ചെടുത്ത എല്ലാ മൂല്യങ്ങളും `Clone` സ്വയം നടപ്പിലാക്കുകയോ ചെയ്താൽ.
///   പങ്കിട്ട റഫറൻസ് ഉപയോഗിച്ച് പിടിച്ചെടുത്ത വേരിയബിളുകൾ എല്ലായ്പ്പോഴും `Clone` നടപ്പിലാക്കുന്നു (റഫറൻസ് ഇല്ലെങ്കിലും), മ്യൂട്ടബിൾ റഫറൻസ് പിടിച്ചെടുത്ത വേരിയബിളുകൾ ഒരിക്കലും `Clone` നടപ്പിലാക്കില്ല.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// മൂല്യത്തിന്റെ ഒരു പകർപ്പ് നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str ക്ലോൺ നടപ്പിലാക്കുന്നു
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// `source`-ൽ നിന്ന് കോപ്പി-അസൈൻമെന്റ് നടത്തുന്നു.
    ///
    /// `a.clone_from(&b)` പ്രവർത്തനത്തിലെ `a = b.clone()` ന് തുല്യമാണ്, പക്ഷേ അനാവശ്യമായ അലോക്കേഷനുകൾ ഒഴിവാക്കാൻ `a` ന്റെ വിഭവങ്ങൾ വീണ്ടും ഉപയോഗിക്കുന്നതിന് അസാധുവാക്കാം.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// trait `Clone`-ന്റെ ഒരു impl സൃഷ്ടിക്കുന്ന മാക്രോ ഡെറിവ് ചെയ്യുക.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): ഒരു തരം എല്ലാ ഘടകങ്ങളും ക്ലോൺ അല്ലെങ്കിൽ കോപ്പി നടപ്പിലാക്കുന്നുവെന്ന് ഉറപ്പിക്കാൻ ഈ സ്ട്രക്റ്റുകൾ#[ഡെറിവ്] മാത്രമാണ് ഉപയോഗിക്കുന്നത്.
//
//
// ഈ ഘടനകൾ ഒരിക്കലും ഉപയോക്തൃ കോഡിൽ ദൃശ്യമാകരുത്.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// പ്രാകൃത തരങ്ങൾക്കായി `Clone` നടപ്പിലാക്കുന്നു.
///
/// Rust-ൽ വിവരിക്കാൻ കഴിയാത്ത നടപ്പാക്കലുകൾ `rustc_trait_selection`-ൽ `traits::SelectionContext::copy_clone_conditions()`-ൽ നടപ്പിലാക്കുന്നു.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// പങ്കിട്ട റഫറൻ‌സുകൾ‌ക്ലോൺ‌ചെയ്യാൻ‌കഴിയും, പക്ഷേ മ്യൂട്ടബിൾ‌റഫറൻ‌സുകൾ‌ക്ക് *കഴിയില്ല*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// പങ്കിട്ട റഫറൻ‌സുകൾ‌ക്ലോൺ‌ചെയ്യാൻ‌കഴിയും, പക്ഷേ മ്യൂട്ടബിൾ‌റഫറൻ‌സുകൾ‌ക്ക് *കഴിയില്ല*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}