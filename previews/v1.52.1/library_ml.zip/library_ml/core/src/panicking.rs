//! ലിബ്‌കോറിനായുള്ള Panic പിന്തുണ
//!
//! കോർ ലൈബ്രറിക്ക് പരിഭ്രാന്തി നിർവചിക്കാൻ കഴിയില്ല, പക്ഷേ ഇത് പരിഭ്രാന്തി * പ്രഖ്യാപിക്കുന്നു.
//! ഇതിനർത്ഥം ലിബ്‌കോർ‌ക്കുള്ളിലെ ഫംഗ്ഷനുകൾ‌panic ലേക്ക് അനുവദനീയമാണെങ്കിലും ഉപയോഗപ്രദമാകുന്നതിന് ഒരു അപ്‌സ്ട്രീം crate ലിബ്‌കോർ‌ഉപയോഗിക്കുന്നതിന് പരിഭ്രാന്തി നിർ‌വ്വചിക്കണം.
//! പരിഭ്രാന്തരാകാനുള്ള നിലവിലെ ഇന്റർഫേസ് ഇതാണ്:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! ഈ നിർവചനം ഏതെങ്കിലും പൊതു സന്ദേശവുമായി പരിഭ്രാന്തരാകാൻ അനുവദിക്കുന്നു, പക്ഷേ ഇത് ഒരു `Box<Any>` മൂല്യം ഉപയോഗിച്ച് പരാജയപ്പെടാൻ അനുവദിക്കുന്നില്ല.
//! (`PanicInfo`-ൽ ഒരു `&(dyn Any + Send)` അടങ്ങിയിരിക്കുന്നു, ഇതിനായി ഞങ്ങൾ `PanicInfo: : internal_constructor` എന്നതിൽ ഒരു ഡമ്മി മൂല്യം പൂരിപ്പിക്കുന്നു.) ഇതിനുള്ള കാരണം ലിബ്കോർ അനുവദിക്കാൻ അനുവദിച്ചിട്ടില്ല എന്നതാണ്.
//!
//!
//! ഈ മൊഡ്യൂളിൽ മറ്റ് ചില പരിഭ്രാന്തി ഫംഗ്ഷനുകൾ അടങ്ങിയിരിക്കുന്നു, പക്ഷേ ഇവ കംപൈലറിന് ആവശ്യമായ ലാംഗ് ഇനങ്ങൾ മാത്രമാണ്.എല്ലാ panics ഉം ഈ ഒരു ഫംഗ്ഷനിലൂടെ പ്രവർത്തിക്കുന്നു.
//! `#[panic_handler]` ആട്രിബ്യൂട്ടിലൂടെ യഥാർത്ഥ ചിഹ്നം പ്രഖ്യാപിക്കുന്നു.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// ഫോർമാറ്റിംഗ് ഉപയോഗിക്കാത്തപ്പോൾ ലിബ്‌കോറിന്റെ `panic!` മാക്രോയുടെ അടിസ്ഥാനപരമായ നടപ്പാക്കൽ.
#[cold]
// കോൾ സൈറ്റുകളിൽ കോഡ് വീർക്കുന്നത് ഒഴിവാക്കാൻ panic_immediate_abort വരെ ഇൻ‌ലൈൻ ചെയ്യരുത്
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // ഓവർഫ്ലോയിലും മറ്റ് `Assert` MIR ടെർമിനേറ്ററുകളിലും panic-നായി കോഡ്‌ജെൻ ആവശ്യമാണ്
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // വലുപ്പം ഓവർഹെഡ് കുറയ്ക്കുന്നതിന് ഫോർമാറ്റ്_അർഗുകൾക്ക് പകരം Arguments::new_v1 ഉപയോഗിക്കുക! ("{}", Expr).
    // ഫോർമാറ്റ്_അർജുകൾ!എക്സ്പ്രർ എഴുതാൻ മാക്രോ സ്ട്രിന്റെ ഡിസ്പ്ലേ trait ഉപയോഗിക്കുന്നു, അത് എക്സ് 100 എക്സ് എന്ന് വിളിക്കുന്നു, അത് സ്ട്രിംഗ് വെട്ടിച്ചുരുക്കലും പാഡിംഗും ഉൾക്കൊള്ളണം (ഇവിടെ ഒന്നും ഉപയോഗിച്ചിട്ടില്ലെങ്കിലും).
    //
    // Arguments::new_v1 ഉപയോഗിക്കുന്നത് കംപൈലറിനെ X ട്ട്‌പുട്ട് ബൈനറിയിൽ നിന്ന് Formatter::pad ഒഴിവാക്കാൻ അനുവദിച്ചേക്കാം, ഇത് കുറച്ച് കിലോബൈറ്റുകൾ വരെ ലാഭിക്കുന്നു.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // സ്ഥിരമായി വിലയിരുത്തിയ panics-ന് ആവശ്യമാണ്
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // OOB array/slice ആക്‌സസ്സിൽ panic-നായി കോഡ്‌ജെൻ ആവശ്യമാണ്
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// ഫോർമാറ്റിംഗ് ഉപയോഗിക്കുമ്പോൾ ലിബ്കോറിന്റെ എക്സ് 00 എക്സ് മാക്രോയുടെ അടിസ്ഥാനപരമായ നടപ്പാക്കൽ.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // ശ്രദ്ധിക്കുക ഈ ഫംഗ്ഷൻ ഒരിക്കലും എഫ്എഫ്ഐ അതിർത്തി ലംഘിക്കുന്നില്ല;ഇത് ഒരു Rust-to-Rust കോളാണ്, അത് `#[panic_handler]` ഫംഗ്ഷനിൽ പരിഹരിക്കപ്പെടും.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // സുരക്ഷ: `panic_impl` സുരക്ഷിതമായ Rust കോഡിൽ നിർവചിച്ചിരിക്കുന്നതിനാൽ കോൾ ചെയ്യുന്നത് സുരക്ഷിതമാണ്.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// `assert_eq!`, `assert_ne!` മാക്രോകൾക്കുള്ള ആന്തരിക പ്രവർത്തനം
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}