#![stable(feature = "duration_core", since = "1.25.0")]

//! താൽക്കാലിക അളവ്.
//!
//! Example:
//!
//! ```
//! use std::time::Duration;
//!
//! let five_seconds = Duration::new(5, 0);
//! // രണ്ട് പ്രഖ്യാപനങ്ങളും തുല്യമാണ്
//! assert_eq!(Duration::new(5, 0), Duration::from_secs(5));
//! ```

use crate::fmt;
use crate::iter::Sum;
use crate::ops::{Add, AddAssign, Div, DivAssign, Mul, MulAssign, Sub, SubAssign};

const NANOS_PER_SEC: u32 = 1_000_000_000;
const NANOS_PER_MILLI: u32 = 1_000_000;
const NANOS_PER_MICRO: u32 = 1_000;
const MILLIS_PER_SEC: u64 = 1_000;
const MICROS_PER_SEC: u64 = 1_000_000;

/// സമയപരിധിയെ പ്രതിനിധീകരിക്കുന്നതിനുള്ള ഒരു `Duration` തരം, സാധാരണയായി സിസ്റ്റം കാലഹരണപ്പെടലിനായി ഉപയോഗിക്കുന്നു.
///
/// ഓരോ `Duration` ഉം മുഴുവൻ സെക്കൻഡുകളും നാനോസെക്കൻഡിൽ പ്രതിനിധീകരിക്കുന്ന ഒരു ഭിന്ന ഭാഗവും ഉൾക്കൊള്ളുന്നു.
/// അണ്ടര്ലയിംഗ് സിസ്റ്റം നാനോസെക്കൻഡ് ലെവൽ കൃത്യതയെ പിന്തുണയ്ക്കുന്നില്ലെങ്കിൽ, സിസ്റ്റം കാലഹരണപ്പെടുന്ന എപിഐകൾ സാധാരണയായി നാനോസെക്കൻഡുകളുടെ എണ്ണം വർദ്ധിപ്പിക്കും.
///
/// [`ദൈർഘ്യം] [`Add`], [`Sub`], മറ്റ് [`ops`] traits എന്നിവയുൾപ്പെടെ നിരവധി സാധാരണ traits നടപ്പിലാക്കുന്നു.പൂജ്യം നീളമുള്ള `Duration` നൽകിക്കൊണ്ട് ഇത് [`Default`] നടപ്പിലാക്കുന്നു.
///
/// [`ops`]: crate::ops
///
/// # Examples
///
/// ```
/// use std::time::Duration;
///
/// let five_seconds = Duration::new(5, 0);
/// let five_seconds_and_five_nanos = five_seconds + Duration::new(0, 5);
///
/// assert_eq!(five_seconds_and_five_nanos.as_secs(), 5);
/// assert_eq!(five_seconds_and_five_nanos.subsec_nanos(), 5);
///
/// let ten_millis = Duration::from_millis(10);
/// ```
///
/// # `Duration` മൂല്യങ്ങൾ ഫോർമാറ്റുചെയ്യുന്നു
///
/// `Duration` മന read പൂർവ്വം ഒരു `Display` impl ഇല്ല, കാരണം മനുഷ്യന്റെ വായനാക്ഷമതയ്ക്കായി സമയപരിധി ഫോർമാറ്റ് ചെയ്യുന്നതിന് വിവിധ മാർഗങ്ങളുണ്ട്.
/// `Duration` മൂല്യത്തിന്റെ പൂർണ്ണ കൃത്യത കാണിക്കുന്ന ഒരു `Debug` impl നൽകുന്നു.
///
/// `Debug` output ട്ട്‌പുട്ട് മൈക്രോസെക്കൻഡിനായി ASCII ഇതര "µs" സഫിക്‌സ് ഉപയോഗിക്കുന്നു.
/// നിങ്ങളുടെ പ്രോഗ്രാം output ട്ട്‌പുട്ട് പൂർണ്ണ യൂണികോഡ് അനുയോജ്യതയെ ആശ്രയിക്കാൻ കഴിയാത്ത സന്ദർഭങ്ങളിൽ ദൃശ്യമാകുകയാണെങ്കിൽ, നിങ്ങൾക്ക് `Duration` ഒബ്‌ജക്റ്റുകൾ സ്വയം ഫോർമാറ്റ് ചെയ്യാനോ അല്ലെങ്കിൽ അങ്ങനെ ചെയ്യാൻ crate ഉപയോഗിക്കാനോ ആഗ്രഹിക്കാം.
///
///
///
///
///
///
///
#[stable(feature = "duration", since = "1.3.0")]
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Default)]
pub struct Duration {
    secs: u64,
    nanos: u32, // എല്ലായ്പ്പോഴും 0 <=നാനോകൾ <NANOS_PER_SEC
}

impl Duration {
    /// ഒരു സെക്കൻഡ് ദൈർഘ്യം.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::SECOND, Duration::from_secs(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const SECOND: Duration = Duration::from_secs(1);

    /// ഒരു മില്ലിസെക്കൻഡിന്റെ കാലാവധി.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MILLISECOND, Duration::from_millis(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MILLISECOND: Duration = Duration::from_millis(1);

    /// ഒരു മൈക്രോസെക്കന്റിന്റെ കാലാവധി.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MICROSECOND, Duration::from_micros(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MICROSECOND: Duration = Duration::from_micros(1);

    /// ഒരു നാനോസെക്കണ്ടിന്റെ കാലാവധി.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::NANOSECOND, Duration::from_nanos(1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const NANOSECOND: Duration = Duration::from_nanos(1);

    /// പൂജ്യം സമയ ദൈർഘ്യം.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// let duration = Duration::ZERO;
    /// assert!(duration.is_zero());
    /// assert_eq!(duration.as_nanos(), 0);
    /// ```
    #[unstable(feature = "duration_zero", issue = "73544")]
    pub const ZERO: Duration = Duration::from_nanos(0);

    /// പരമാവധി ദൈർഘ്യം.
    ///
    /// ഇത് ഏകദേശം 584,942,417,355 വർഷത്തെ കാലാവധിക്കു തുല്യമാണ്.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::MAX, Duration::new(u64::MAX, 1_000_000_000 - 1));
    /// ```
    #[unstable(feature = "duration_constants", issue = "57391")]
    pub const MAX: Duration = Duration::new(u64::MAX, NANOS_PER_SEC - 1);

    /// നിർദ്ദിഷ്ട സെക്കൻഡിൽ നിന്നും അധിക നാനോസെക്കൻഡുകളിൽ നിന്നും ഒരു പുതിയ `Duration` സൃഷ്ടിക്കുന്നു.
    ///
    /// നാനോസെക്കൻഡുകളുടെ എണ്ണം 1 ബില്ല്യണിനേക്കാൾ കൂടുതലാണെങ്കിൽ (ഒരു സെക്കൻഡിൽ നാനോസെക്കൻഡുകളുടെ എണ്ണം), അത് നൽകിയ നിമിഷങ്ങളിലേക്ക് അത് കൊണ്ടുപോകും.
    ///
    ///
    /// # Panics
    ///
    /// നാനോസെക്കൻഡുകളിൽ നിന്നുള്ള കാരി സെക്കൻഡ് ക .ണ്ടറിൽ കവിഞ്ഞൊഴുകുകയാണെങ്കിൽ ഈ കൺ‌സ്‌ട്രക്റ്റർ‌panic ചെയ്യും.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let five_seconds = Duration::new(5, 0);
    /// ```
    ///
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn new(secs: u64, nanos: u32) -> Duration {
        let secs = match secs.checked_add((nanos / NANOS_PER_SEC) as u64) {
            Some(secs) => secs,
            None => panic!("overflow in Duration::new"),
        };
        let nanos = nanos % NANOS_PER_SEC;
        Duration { secs, nanos }
    }

    /// നിർദ്ദിഷ്ട സെക്കൻഡിൽ നിന്ന് ഒരു പുതിയ `Duration` സൃഷ്ടിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_secs(5);
    ///
    /// assert_eq!(5, duration.as_secs());
    /// assert_eq!(0, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_secs(secs: u64) -> Duration {
        Duration { secs, nanos: 0 }
    }

    /// നിർദ്ദിഷ്ട മില്ലിസെക്കൻഡിൽ നിന്ന് ഒരു പുതിയ `Duration` സൃഷ്ടിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(2569);
    ///
    /// assert_eq!(2, duration.as_secs());
    /// assert_eq!(569_000_000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_millis(millis: u64) -> Duration {
        Duration {
            secs: millis / MILLIS_PER_SEC,
            nanos: ((millis % MILLIS_PER_SEC) as u32) * NANOS_PER_MILLI,
        }
    }

    /// നിർദ്ദിഷ്ട മൈക്രോസെക്കൻഡിൽ നിന്ന് ഒരു പുതിയ `Duration` സൃഷ്ടിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_000_002);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(2000, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_from_micros", since = "1.27.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_micros(micros: u64) -> Duration {
        Duration {
            secs: micros / MICROS_PER_SEC,
            nanos: ((micros % MICROS_PER_SEC) as u32) * NANOS_PER_MICRO,
        }
    }

    /// നിർദ്ദിഷ്ട നാനോസെക്കൻഡുകളിൽ നിന്ന് ഒരു പുതിയ `Duration` സൃഷ്ടിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_nanos(1_000_000_123);
    ///
    /// assert_eq!(1, duration.as_secs());
    /// assert_eq!(123, duration.subsec_nanos());
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[inline]
    #[rustc_const_stable(feature = "duration_consts", since = "1.32.0")]
    pub const fn from_nanos(nanos: u64) -> Duration {
        Duration {
            secs: nanos / (NANOS_PER_SEC as u64),
            nanos: (nanos % (NANOS_PER_SEC as u64)) as u32,
        }
    }

    /// ഈ `Duration` സമയമില്ലെങ്കിൽ ശരിയാണെന്ന് നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// assert!(Duration::ZERO.is_zero());
    /// assert!(Duration::new(0, 0).is_zero());
    /// assert!(Duration::from_nanos(0).is_zero());
    /// assert!(Duration::from_secs(0).is_zero());
    ///
    /// assert!(!Duration::new(1, 1).is_zero());
    /// assert!(!Duration::from_nanos(1).is_zero());
    /// assert!(!Duration::from_secs(1).is_zero());
    /// ```
    #[unstable(feature = "duration_zero", issue = "73544")]
    #[inline]
    pub const fn is_zero(&self) -> bool {
        self.secs == 0 && self.nanos == 0
    }

    /// ഈ `Duration` അടങ്ങിയിരിക്കുന്ന _whole_ സെക്കൻഡുകളുടെ എണ്ണം നൽകുന്നു.
    ///
    /// മടക്കിയ മൂല്യത്തിൽ കാലാവധിയുടെ ഭിന്ന (nanosecond) ഭാഗം ഉൾപ്പെടുന്നില്ല, അത് [`subsec_nanos`] ഉപയോഗിച്ച് ലഭിക്കും.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_secs(), 5);
    /// ```
    ///
    /// `Duration` പ്രതിനിധീകരിക്കുന്ന മൊത്തം സെക്കൻഡുകളുടെ എണ്ണം നിർണ്ണയിക്കാൻ, [`subsec_nanos`]-നൊപ്പം `as_secs` ഉപയോഗിക്കുക:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    ///
    /// assert_eq!(5.730023852,
    ///            duration.as_secs() as f64
    ///            + duration.subsec_nanos() as f64 * 1e-9);
    /// ```
    ///
    /// [`subsec_nanos`]: Duration::subsec_nanos
    ///
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration", since = "1.32.0")]
    #[inline]
    pub const fn as_secs(&self) -> u64 {
        self.secs
    }

    /// ഈ `Duration`-ന്റെ ഭിന്ന ഭാഗം മുഴുവൻ മില്ലിസെക്കൻഡിൽ നൽകുന്നു.
    ///
    /// മില്ലിസെക്കൻഡിൽ പ്രതിനിധീകരിക്കുമ്പോൾ ഈ രീതി ** ദൈർഘ്യത്തിന്റെ ദൈർഘ്യം നൽകില്ല.
    /// മടങ്ങിയ നമ്പർ എല്ലായ്പ്പോഴും ഒരു സെക്കന്റിന്റെ ഒരു ഭാഗത്തെ പ്രതിനിധീകരിക്കുന്നു (അതായത്, ഇത് ആയിരത്തിൽ കുറവാണ്).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5432);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_millis(), 432);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_extras", since = "1.32.0")]
    #[inline]
    pub const fn subsec_millis(&self) -> u32 {
        self.nanos / NANOS_PER_MILLI
    }

    /// ഈ `Duration`-ന്റെ ഭിന്ന ഭാഗം മുഴുവൻ മൈക്രോസെക്കൻഡിൽ നൽകുന്നു.
    ///
    /// മൈക്രോസെക്കൻഡുകൾ പ്രതിനിധീകരിക്കുമ്പോൾ ഈ രീതി ** ദൈർഘ്യത്തിന്റെ ദൈർഘ്യം നൽകില്ല.
    /// മടങ്ങിയെത്തിയ നമ്പർ എല്ലായ്പ്പോഴും ഒരു സെക്കന്റിന്റെ ഒരു ഭാഗത്തെ പ്രതിനിധീകരിക്കുന്നു (അതായത്, ഇത് ഒരു ദശലക്ഷത്തിൽ കുറവാണ്).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_micros(1_234_567);
    /// assert_eq!(duration.as_secs(), 1);
    /// assert_eq!(duration.subsec_micros(), 234_567);
    /// ```
    #[stable(feature = "duration_extras", since = "1.27.0")]
    #[rustc_const_stable(feature = "duration_extras", since = "1.32.0")]
    #[inline]
    pub const fn subsec_micros(&self) -> u32 {
        self.nanos / NANOS_PER_MICRO
    }

    /// ഈ `Duration`-ന്റെ ഭിന്ന ഭാഗം നാനോസെക്കൻഡിൽ നൽകുന്നു.
    ///
    /// ഈ രീതി നാനോസെക്കൻഡുകൾ പ്രതിനിധീകരിക്കുമ്പോൾ ദൈർഘ്യത്തിന്റെ ദൈർഘ്യം ** നൽകില്ല.
    /// മടങ്ങിയെത്തിയ സംഖ്യ എല്ലായ്പ്പോഴും ഒരു സെക്കന്റിന്റെ ഒരു ഭാഗത്തെ പ്രതിനിധീകരിക്കുന്നു (അതായത്, ഇത് ഒരു ബില്ല്യണിൽ കുറവാണ്).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::from_millis(5010);
    /// assert_eq!(duration.as_secs(), 5);
    /// assert_eq!(duration.subsec_nanos(), 10_000_000);
    /// ```
    #[stable(feature = "duration", since = "1.3.0")]
    #[rustc_const_stable(feature = "duration", since = "1.32.0")]
    #[inline]
    pub const fn subsec_nanos(&self) -> u32 {
        self.nanos
    }

    /// ഈ `Duration` അടങ്ങിയിരിക്കുന്ന മൊത്തം മില്ലിസെക്കൻഡുകളുടെ എണ്ണം നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_millis(), 5730);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_millis(&self) -> u128 {
        self.secs as u128 * MILLIS_PER_SEC as u128 + (self.nanos / NANOS_PER_MILLI) as u128
    }

    /// ഈ `Duration` അടങ്ങിയിരിക്കുന്ന മൊത്തം മൈക്രോസെക്കൻഡുകളുടെ എണ്ണം നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_micros(), 5730023);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_micros(&self) -> u128 {
        self.secs as u128 * MICROS_PER_SEC as u128 + (self.nanos / NANOS_PER_MICRO) as u128
    }

    /// ഈ `Duration` അടങ്ങിയിരിക്കുന്ന മൊത്തം നാനോസെക്കൻഡുകളുടെ എണ്ണം നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let duration = Duration::new(5, 730023852);
    /// assert_eq!(duration.as_nanos(), 5730023852);
    /// ```
    #[stable(feature = "duration_as_u128", since = "1.33.0")]
    #[rustc_const_stable(feature = "duration_as_u128", since = "1.33.0")]
    #[inline]
    pub const fn as_nanos(&self) -> u128 {
        self.secs as u128 * NANOS_PER_SEC as u128 + self.nanos as u128
    }

    /// `Duration` സങ്കലനം പരിശോധിച്ചു.
    /// `self + other` കണക്കാക്കുന്നു, ഓവർഫ്ലോ സംഭവിച്ചാൽ [`None`] നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).checked_add(Duration::new(0, 1)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(1, 0).checked_add(Duration::new(u64::MAX, 0)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_add(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_add(rhs.secs) {
            let mut nanos = self.nanos + rhs.nanos;
            if nanos >= NANOS_PER_SEC {
                nanos -= NANOS_PER_SEC;
                if let Some(new_secs) = secs.checked_add(1) {
                    secs = new_secs;
                } else {
                    return None;
                }
            }
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// `Duration` സങ്കലനം പൂരിതമാക്കുന്നു.
    /// `self + other` കണക്കാക്കുന്നു, ഓവർഫ്ലോ സംഭവിച്ചാൽ [`Duration::MAX`] നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 0).saturating_add(Duration::new(0, 1)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(1, 0).saturating_add(Duration::new(u64::MAX, 0)), Duration::MAX);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_add(self, rhs: Duration) -> Duration {
        match self.checked_add(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// `Duration` കുറയ്ക്കൽ പരിശോധിച്ചു.
    /// `self - other` കണക്കാക്കുന്നു, ഫലം നെഗറ്റീവ് ആണെങ്കിലോ ഓവർഫ്ലോ സംഭവിച്ചെങ്കിലോ [`None`] നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).checked_sub(Duration::new(0, 0)), Some(Duration::new(0, 1)));
    /// assert_eq!(Duration::new(0, 0).checked_sub(Duration::new(0, 1)), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_sub(self, rhs: Duration) -> Option<Duration> {
        if let Some(mut secs) = self.secs.checked_sub(rhs.secs) {
            let nanos = if self.nanos >= rhs.nanos {
                self.nanos - rhs.nanos
            } else {
                if let Some(sub_secs) = secs.checked_sub(1) {
                    secs = sub_secs;
                    self.nanos + NANOS_PER_SEC - rhs.nanos
                } else {
                    return None;
                }
            };
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// പൂരിത `Duration` കുറയ്ക്കൽ.
    /// `self - other` കണക്കാക്കുന്നു, ഫലം നെഗറ്റീവ് ആണെങ്കിലോ ഓവർഫ്ലോ സംഭവിച്ചെങ്കിലോ [`Duration::ZERO`] നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_zero)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 1).saturating_sub(Duration::new(0, 0)), Duration::new(0, 1));
    /// assert_eq!(Duration::new(0, 0).saturating_sub(Duration::new(0, 1)), Duration::ZERO);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_sub(self, rhs: Duration) -> Duration {
        match self.checked_sub(rhs) {
            Some(res) => res,
            None => Duration::ZERO,
        }
    }

    /// `Duration` ഗുണനം പരിശോധിച്ചു.
    /// `self * other` കണക്കാക്കുന്നു, ഓവർഫ്ലോ സംഭവിച്ചാൽ [`None`] നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).checked_mul(2), Some(Duration::new(1, 2)));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).checked_mul(2), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_mul(self, rhs: u32) -> Option<Duration> {
        // നാനോസെക്കൻഡുകളെ u64 ആയി ഗുണിക്കുക, കാരണം അതിന് കവിഞ്ഞൊഴുകാൻ കഴിയില്ല.
        let total_nanos = self.nanos as u64 * rhs as u64;
        let extra_secs = total_nanos / (NANOS_PER_SEC as u64);
        let nanos = (total_nanos % (NANOS_PER_SEC as u64)) as u32;
        if let Some(s) = self.secs.checked_mul(rhs as u64) {
            if let Some(secs) = s.checked_add(extra_secs) {
                debug_assert!(nanos < NANOS_PER_SEC);
                return Some(Duration { secs, nanos });
            }
        }
        None
    }

    /// പൂരിത `Duration` ഗുണനം.
    /// `self * other` കണക്കാക്കുന്നു, ഓവർഫ്ലോ സംഭവിച്ചാൽ [`Duration::MAX`] നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(duration_saturating_ops)]
    /// #![feature(duration_constants)]
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(0, 500_000_001).saturating_mul(2), Duration::new(1, 2));
    /// assert_eq!(Duration::new(u64::MAX - 1, 0).saturating_mul(2), Duration::MAX);
    /// ```
    #[unstable(feature = "duration_saturating_ops", issue = "76416")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn saturating_mul(self, rhs: u32) -> Duration {
        match self.checked_mul(rhs) {
            Some(res) => res,
            None => Duration::MAX,
        }
    }

    /// `Duration` ഡിവിഷൻ പരിശോധിച്ചു.
    /// `self / other` കണക്കാക്കുന്നു, `other == 0` എങ്കിൽ [`None`] നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// assert_eq!(Duration::new(2, 0).checked_div(2), Some(Duration::new(1, 0)));
    /// assert_eq!(Duration::new(1, 0).checked_div(2), Some(Duration::new(0, 500_000_000)));
    /// assert_eq!(Duration::new(2, 0).checked_div(0), None);
    /// ```
    #[stable(feature = "duration_checked_ops", since = "1.16.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn checked_div(self, rhs: u32) -> Option<Duration> {
        if rhs != 0 {
            let secs = self.secs / (rhs as u64);
            let carry = self.secs - secs * (rhs as u64);
            let extra_nanos = carry * (NANOS_PER_SEC as u64) / (rhs as u64);
            let nanos = self.nanos / rhs + (extra_nanos as u32);
            debug_assert!(nanos < NANOS_PER_SEC);
            Some(Duration { secs, nanos })
        } else {
            None
        }
    }

    /// ഈ `Duration` അടങ്ങിയിരിക്കുന്ന സെക്കൻഡുകളുടെ എണ്ണം `f64` ആയി നൽകുന്നു.
    /// മടക്കിയ മൂല്യത്തിൽ കാലാവധിയുടെ ഭിന്ന (nanosecond) ഭാഗം ഉൾപ്പെടുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f64(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn as_secs_f64(&self) -> f64 {
        (self.secs as f64) + (self.nanos as f64) / (NANOS_PER_SEC as f64)
    }

    /// ഈ `Duration` അടങ്ങിയിരിക്കുന്ന സെക്കൻഡുകളുടെ എണ്ണം `f32` ആയി നൽകുന്നു.
    /// മടക്കിയ മൂല്യത്തിൽ കാലാവധിയുടെ ഭിന്ന (nanosecond) ഭാഗം ഉൾപ്പെടുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.as_secs_f32(), 2.7);
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn as_secs_f32(&self) -> f32 {
        (self.secs as f32) + (self.nanos as f32) / (NANOS_PER_SEC as f32)
    }

    /// `f64` എന്ന് പ്രതിനിധീകരിക്കുന്ന നിർദ്ദിഷ്ട സെക്കൻഡുകളിൽ നിന്ന് ഒരു പുതിയ `Duration` സൃഷ്ടിക്കുന്നു.
    ///
    /// # Panics
    /// `secs` പരിമിതമോ നെഗറ്റീവ് അല്ലെങ്കിൽ ഓവർഫ്ലോ `Duration` അല്ലെങ്കിലോ ഈ കൺ‌സ്‌ട്രക്റ്റർ‌panic ചെയ്യും.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::from_secs_f64(2.7);
    /// assert_eq!(dur, Duration::new(2, 700_000_000));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn from_secs_f64(secs: f64) -> Duration {
        const MAX_NANOS_F64: f64 = ((u64::MAX as u128 + 1) * (NANOS_PER_SEC as u128)) as f64;
        let nanos = secs * (NANOS_PER_SEC as f64);
        if !nanos.is_finite() {
            panic!("got non-finite value when converting float to duration");
        }
        if nanos >= MAX_NANOS_F64 {
            panic!("overflow when converting float to duration");
        }
        if nanos < 0.0 {
            panic!("underflow when converting float to duration");
        }
        let nanos = nanos as u128;
        Duration {
            secs: (nanos / (NANOS_PER_SEC as u128)) as u64,
            nanos: (nanos % (NANOS_PER_SEC as u128)) as u32,
        }
    }

    /// `f32` എന്ന് പ്രതിനിധീകരിക്കുന്ന നിർദ്ദിഷ്ട സെക്കൻഡുകളിൽ നിന്ന് ഒരു പുതിയ `Duration` സൃഷ്ടിക്കുന്നു.
    ///
    /// # Panics
    /// `secs` പരിമിതമോ നെഗറ്റീവ് അല്ലെങ്കിൽ ഓവർഫ്ലോ `Duration` അല്ലെങ്കിലോ ഈ കൺ‌സ്‌ട്രക്റ്റർ‌panic ചെയ്യും.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::from_secs_f32(2.7);
    /// assert_eq!(dur, Duration::new(2, 700_000_000));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn from_secs_f32(secs: f32) -> Duration {
        const MAX_NANOS_F32: f32 = ((u64::MAX as u128 + 1) * (NANOS_PER_SEC as u128)) as f32;
        let nanos = secs * (NANOS_PER_SEC as f32);
        if !nanos.is_finite() {
            panic!("got non-finite value when converting float to duration");
        }
        if nanos >= MAX_NANOS_F32 {
            panic!("overflow when converting float to duration");
        }
        if nanos < 0.0 {
            panic!("underflow when converting float to duration");
        }
        let nanos = nanos as u128;
        Duration {
            secs: (nanos / (NANOS_PER_SEC as u128)) as u64,
            nanos: (nanos % (NANOS_PER_SEC as u128)) as u32,
        }
    }

    /// `Duration` നെ `f64` കൊണ്ട് ഗുണിക്കുന്നു.
    /// # Panics
    /// ഫലം പരിമിതമോ നെഗറ്റീവ് അല്ലെങ്കിൽ ഓവർഫ്ലോ എക്സ് 00 എക്സ് അല്ലെങ്കിലോ ഈ രീതി panic ആയിരിക്കും.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.mul_f64(3.14), Duration::new(8, 478_000_000));
    /// assert_eq!(dur.mul_f64(3.14e5), Duration::new(847_800, 0));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn mul_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(rhs * self.as_secs_f64())
    }

    /// `Duration` നെ `f32` കൊണ്ട് ഗുണിക്കുന്നു.
    /// # Panics
    /// ഫലം പരിമിതമോ നെഗറ്റീവ് അല്ലെങ്കിൽ ഓവർഫ്ലോ എക്സ് 00 എക്സ് അല്ലെങ്കിലോ ഈ രീതി panic ആയിരിക്കും.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // റൗണ്ടിംഗ് പിശകുകൾ കാരണം 8.478, 847800.0 എന്നിവയിൽ നിന്ന് അല്പം വ്യത്യാസമുണ്ട്
    /////
    /// assert_eq!(dur.mul_f32(3.14), Duration::new(8, 478_000_640));
    /// assert_eq!(dur.mul_f32(3.14e5), Duration::new(847799, 969_120_256));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn mul_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(rhs * self.as_secs_f32())
    }

    /// `Duration` നെ `f64` കൊണ്ട് ഹരിക്കുക.
    /// # Panics
    /// ഫലം പരിമിതമോ നെഗറ്റീവ് അല്ലെങ്കിൽ ഓവർഫ്ലോ എക്സ് 00 എക്സ് അല്ലെങ്കിലോ ഈ രീതി panic ആയിരിക്കും.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// assert_eq!(dur.div_f64(3.14), Duration::new(0, 859_872_611));
    /// // വെട്ടിച്ചുരുക്കലല്ല, വെട്ടിച്ചുരുക്കലാണ് ഉപയോഗിക്കുന്നതെന്ന് ശ്രദ്ധിക്കുക
    /// assert_eq!(dur.div_f64(3.14e5), Duration::new(0, 8_598));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_f64(self, rhs: f64) -> Duration {
        Duration::from_secs_f64(self.as_secs_f64() / rhs)
    }

    /// `Duration` നെ `f32` കൊണ്ട് ഹരിക്കുക.
    /// # Panics
    /// ഫലം പരിമിതമോ നെഗറ്റീവ് അല്ലെങ്കിൽ ഓവർഫ്ലോ എക്സ് 00 എക്സ് അല്ലെങ്കിലോ ഈ രീതി panic ആയിരിക്കും.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::Duration;
    ///
    /// let dur = Duration::new(2, 700_000_000);
    /// // റൗണ്ടിംഗ് പിശകുകൾ കാരണം 0.859_872_611-ൽ നിന്ന് അല്പം വ്യത്യാസമുണ്ട്
    /////
    /// assert_eq!(dur.div_f32(3.14), Duration::new(0, 859_872_576));
    /// // വെട്ടിച്ചുരുക്കലല്ല, വെട്ടിച്ചുരുക്കലാണ് ഉപയോഗിക്കുന്നതെന്ന് ശ്രദ്ധിക്കുക
    /// assert_eq!(dur.div_f32(3.14e5), Duration::new(0, 8_598));
    /// ```
    #[stable(feature = "duration_float", since = "1.38.0")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_f32(self, rhs: f32) -> Duration {
        Duration::from_secs_f32(self.as_secs_f32() / rhs)
    }

    /// `Duration` നെ `Duration` കൊണ്ട് ഹരിക്കുക, `f64` മടങ്ങുക.
    /// # Examples
    ///
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f64(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_duration_f64(self, rhs: Duration) -> f64 {
        self.as_secs_f64() / rhs.as_secs_f64()
    }

    /// `Duration` നെ `Duration` കൊണ്ട് ഹരിക്കുക, `f32` മടങ്ങുക.
    /// # Examples
    ///
    /// ```
    /// #![feature(div_duration)]
    /// use std::time::Duration;
    ///
    /// let dur1 = Duration::new(2, 700_000_000);
    /// let dur2 = Duration::new(5, 400_000_000);
    /// assert_eq!(dur1.div_duration_f32(dur2), 0.5);
    /// ```
    #[unstable(feature = "div_duration", issue = "63139")]
    #[inline]
    #[rustc_const_unstable(feature = "duration_consts_2", issue = "72440")]
    pub const fn div_duration_f32(self, rhs: Duration) -> f32 {
        self.as_secs_f32() / rhs.as_secs_f32()
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Add for Duration {
    type Output = Duration;

    fn add(self, rhs: Duration) -> Duration {
        self.checked_add(rhs).expect("overflow when adding durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl AddAssign for Duration {
    fn add_assign(&mut self, rhs: Duration) {
        *self = *self + rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Sub for Duration {
    type Output = Duration;

    fn sub(self, rhs: Duration) -> Duration {
        self.checked_sub(rhs).expect("overflow when subtracting durations")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl SubAssign for Duration {
    fn sub_assign(&mut self, rhs: Duration) {
        *self = *self - rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Mul<u32> for Duration {
    type Output = Duration;

    fn mul(self, rhs: u32) -> Duration {
        self.checked_mul(rhs).expect("overflow when multiplying duration by scalar")
    }
}

#[stable(feature = "symmetric_u32_duration_mul", since = "1.31.0")]
impl Mul<Duration> for u32 {
    type Output = Duration;

    fn mul(self, rhs: Duration) -> Duration {
        rhs * self
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl MulAssign<u32> for Duration {
    fn mul_assign(&mut self, rhs: u32) {
        *self = *self * rhs;
    }
}

#[stable(feature = "duration", since = "1.3.0")]
impl Div<u32> for Duration {
    type Output = Duration;

    fn div(self, rhs: u32) -> Duration {
        self.checked_div(rhs).expect("divide by zero error when dividing duration by scalar")
    }
}

#[stable(feature = "time_augmented_assignment", since = "1.9.0")]
impl DivAssign<u32> for Duration {
    fn div_assign(&mut self, rhs: u32) {
        *self = *self / rhs;
    }
}

macro_rules! sum_durations {
    ($iter:expr) => {{
        let mut total_secs: u64 = 0;
        let mut total_nanos: u64 = 0;

        for entry in $iter {
            total_secs =
                total_secs.checked_add(entry.secs).expect("overflow in iter::sum over durations");
            total_nanos = match total_nanos.checked_add(entry.nanos as u64) {
                Some(n) => n,
                None => {
                    total_secs = total_secs
                        .checked_add(total_nanos / NANOS_PER_SEC as u64)
                        .expect("overflow in iter::sum over durations");
                    (total_nanos % NANOS_PER_SEC as u64) + entry.nanos as u64
                }
            };
        }
        total_secs = total_secs
            .checked_add(total_nanos / NANOS_PER_SEC as u64)
            .expect("overflow in iter::sum over durations");
        total_nanos = total_nanos % NANOS_PER_SEC as u64;
        Duration { secs: total_secs, nanos: total_nanos as u32 }
    }};
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl Sum for Duration {
    fn sum<I: Iterator<Item = Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_sum", since = "1.16.0")]
impl<'a> Sum<&'a Duration> for Duration {
    fn sum<I: Iterator<Item = &'a Duration>>(iter: I) -> Duration {
        sum_durations!(iter)
    }
}

#[stable(feature = "duration_debug_impl", since = "1.27.0")]
impl fmt::Debug for Duration {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        /// ദശാംശ നൊട്ടേഷനിൽ ഒരു ഫ്ലോട്ടിംഗ് പോയിന്റ് നമ്പർ ഫോർമാറ്റ് ചെയ്യുന്നു.
        ///
        /// നമ്പർ `integer_part` ഉം ഒരു ഭാഗിക ഭാഗവുമായി നൽകിയിരിക്കുന്നു.
        /// ഭിന്ന ഭാഗത്തിന്റെ മൂല്യം `fractional_part / divisor` ആണ്.
        /// അതിനാൽ `integer_part` =3, `fractional_part` =12, `divisor` =100 എന്നിവ `3.012` സംഖ്യയെ പ്രതിനിധീകരിക്കുന്നു.
        /// പിന്നിലുള്ള പൂജ്യങ്ങൾ ഒഴിവാക്കി.
        ///
        /// `divisor` 100_000_000 ന് മുകളിലായിരിക്കരുത്.
        /// ഇത് 10 ന്റെ ശക്തിയായിരിക്കണം, മറ്റെല്ലാം അർത്ഥമാക്കുന്നില്ല.
        /// `fractional_part` `10 * divisor`-ൽ കുറവായിരിക്കണം!
        fn fmt_decimal(
            f: &mut fmt::Formatter<'_>,
            mut integer_part: u64,
            mut fractional_part: u32,
            mut divisor: u32,
        ) -> fmt::Result {
            // ഭിന്ന ഭാഗം ഒരു താൽ‌ക്കാലിക ബഫറിലേക്ക് എൻ‌കോഡുചെയ്യുക.
            // ബഫറിന് 9 ഘടകങ്ങൾ മാത്രമേ കൈവശം വയ്ക്കാവൂ, കാരണം `fractional_part` 10 ^ 9 നേക്കാൾ ചെറുതായിരിക്കണം.
            //
            // ചുവടെയുള്ള കോഡ് ലളിതമാക്കുന്നതിന് ബഫറിന് '0' അക്കങ്ങൾ ഉപയോഗിച്ച് പൂരിപ്പിച്ചിരിക്കുന്നു.
            let mut buf = [b'0'; 9];

            // അടുത്ത അക്കം ഈ സ്ഥാനത്ത് എഴുതിയിരിക്കുന്നു
            let mut pos = 0;

            // പൂജ്യമല്ലാത്ത അക്കങ്ങൾ അവശേഷിക്കുമ്പോൾ ഞങ്ങൾ ബഫറിലേക്ക് അക്കങ്ങൾ എഴുതുന്നു, ഞങ്ങൾ ഇതുവരെ വേണ്ടത്ര അക്കങ്ങൾ എഴുതിയിട്ടില്ല.
            //
            while fractional_part > 0 && pos < f.precision().unwrap_or(9) {
                // ബഫറിൽ പുതിയ അക്കം എഴുതുക
                buf[pos] = b'0' + (fractional_part / divisor) as u8;

                fractional_part %= divisor;
                divisor /= 10;
                pos += 1;
            }

            // ഒരു കൃത്യത <9 വ്യക്തമാക്കിയിട്ടുണ്ടെങ്കിൽ, ബഫറിൽ എഴുതിയിട്ടില്ലാത്ത ചില പൂജ്യമല്ലാത്ത അക്കങ്ങൾ അവശേഷിക്കുന്നു.
            // അത്തരം സന്ദർഭങ്ങളിൽ സാധാരണ ഫ്ലോട്ടിംഗ് പോയിൻറ് നമ്പറുകൾ അച്ചടിക്കുന്നതിന്റെ അർത്ഥവുമായി പൊരുത്തപ്പെടുന്നതിന് ഞങ്ങൾ റൗണ്ടിംഗ് നടത്തേണ്ടതുണ്ട്.
            // എന്നിരുന്നാലും, റൗണ്ട് അപ്പ് ചെയ്യുമ്പോൾ മാത്രമേ ഞങ്ങൾ ജോലി ചെയ്യാവൂ.
            // ശേഷിക്കുന്നവയുടെ ആദ്യ അക്കം>=5 ആണെങ്കിൽ ഇത് സംഭവിക്കുന്നു.
            //
            //
            if fractional_part > 0 && fractional_part >= divisor * 5 {
                // ബഫറിൽ അടങ്ങിയിരിക്കുന്ന നമ്പർ റൗണ്ട് അപ്പ് ചെയ്യുക.
                // ഞങ്ങൾ ബഫറിലൂടെ പിന്നിലേക്ക് പോയി കാരിയുടെ ട്രാക്ക് സൂക്ഷിക്കുന്നു.
                let mut rev_pos = pos;
                let mut carry = true;
                while carry && rev_pos > 0 {
                    rev_pos -= 1;

                    // ബഫറിലെ അക്കം '9' അല്ലെങ്കിൽ‌, ഞങ്ങൾ‌അത് വർദ്ധിപ്പിക്കേണ്ടതുണ്ട്, മാത്രമല്ല നിർ‌ത്താനും കഴിയും (ഞങ്ങൾക്ക് ഇനി ഒരു കാരിയും ഇല്ലാത്തതിനാൽ‌).
                    // അല്ലെങ്കിൽ, ഞങ്ങൾ ഇത് '0' (overflow) ആയി സജ്ജമാക്കി തുടരുക.
                    //
                    //
                    if buf[rev_pos] < b'9' {
                        buf[rev_pos] += 1;
                        carry = false;
                    } else {
                        buf[rev_pos] = b'0';
                    }
                }

                // ഞങ്ങൾക്ക് ഇപ്പോഴും കാരി ബിറ്റ് സെറ്റ് ഉണ്ടെങ്കിൽ, അതിനർത്ഥം ഞങ്ങൾ മുഴുവൻ ബഫറും '0'കളായി സജ്ജമാക്കി, ഒപ്പം പൂർണ്ണസംഖ്യ വർദ്ധിപ്പിക്കേണ്ടതുണ്ട്.
                //
                //
                if carry {
                    integer_part += 1;
                }
            }

            // ബഫറിന്റെ അവസാനം നിർണ്ണയിക്കുക: കൃത്യത സജ്ജമാക്കിയിട്ടുണ്ടെങ്കിൽ, ഞങ്ങൾ ബഫറിൽ നിന്നുള്ള അത്രയും അക്കങ്ങൾ ഉപയോഗിക്കുന്നു (9 ലേക്ക് അടച്ചിരിക്കുന്നു).
            // ഇത് സജ്ജമാക്കിയിട്ടില്ലെങ്കിൽ, അവസാന പൂജ്യമല്ലാത്ത ഒരെണ്ണം വരെ ഞങ്ങൾ എല്ലാ അക്കങ്ങളും ഉപയോഗിക്കുന്നു.
            //
            let end = f.precision().map(|p| crate::cmp::min(p, 9)).unwrap_or(pos);

            // ഞങ്ങൾ ഒരു ഭിന്നസംഖ്യ പുറപ്പെടുവിച്ചിട്ടില്ലെങ്കിൽ കൃത്യത പൂജ്യമല്ലാത്ത മൂല്യത്തിലേക്ക് സജ്ജമാക്കിയിട്ടില്ലെങ്കിൽ, ഞങ്ങൾ ദശാംശസ്ഥാനം അച്ചടിക്കുന്നില്ല.
            //
            if end == 0 {
                write!(f, "{}", integer_part)
            } else {
                // സുരക്ഷ: ഞങ്ങൾ ബഫറിലേക്ക് ASCII അക്കങ്ങൾ മാത്രമേ എഴുതുന്നുള്ളൂ
                // '0' ഉപയോഗിച്ച് സമാരംഭിച്ചതിനാൽ അതിൽ സാധുവായ UTF8 അടങ്ങിയിരിക്കുന്നു.
                let s = unsafe { crate::str::from_utf8_unchecked(&buf[..end]) };

                // ഉപയോക്താവ് ഒരു കൃത്യത> 9 അഭ്യർത്ഥിക്കുകയാണെങ്കിൽ, ഞങ്ങൾ പാഡ് 0 ന്റെ അവസാനം.
                let w = f.precision().unwrap_or(pos);
                write!(f, "{}.{:0<width$}", integer_part, s, width = w)
            }
        }

        // അഭ്യർത്ഥിച്ചാൽ പ്രമുഖ '+' ചിഹ്നം അച്ചടിക്കുക
        if f.sign_plus() {
            write!(f, "+")?;
        }

        if self.secs > 0 {
            fmt_decimal(f, self.secs, self.nanos, NANOS_PER_SEC / 10)?;
            f.write_str("s")
        } else if self.nanos >= NANOS_PER_MILLI {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MILLI) as u64,
                self.nanos % NANOS_PER_MILLI,
                NANOS_PER_MILLI / 10,
            )?;
            f.write_str("ms")
        } else if self.nanos >= NANOS_PER_MICRO {
            fmt_decimal(
                f,
                (self.nanos / NANOS_PER_MICRO) as u64,
                self.nanos % NANOS_PER_MICRO,
                NANOS_PER_MICRO / 10,
            )?;
            f.write_str("µs")
        } else {
            fmt_decimal(f, self.nanos as u64, 0, 1)?;
            f.write_str("ns")
        }
    }
}