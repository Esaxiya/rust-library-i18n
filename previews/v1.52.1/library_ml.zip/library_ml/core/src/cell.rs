//! പങ്കിടാവുന്ന മ്യൂട്ടബിൾ പാത്രങ്ങൾ.
//!
//! Rust മെമ്മറി സുരക്ഷ ഈ നിയമത്തെ അടിസ്ഥാനമാക്കിയുള്ളതാണ്: ഒരു ഒബ്ജക്റ്റ് `T` നൽകിയാൽ, ഇനിപ്പറയുന്നതിൽ ഒന്ന് മാത്രമേ സാധ്യമാകൂ:
//!
//! - ഒബ്‌ജക്റ്റിലേക്ക് മാറ്റാനാവാത്ത നിരവധി റഫറൻസുകൾ ഉള്ളത് (**അപരനാമം** എന്നും അറിയപ്പെടുന്നു).
//! - ഒബ്‌ജക്റ്റിലേക്ക് ഒരു മ്യൂട്ടബിൾ റഫറൻസ് (`&മ്യൂട്ട് ടി`) ഉള്ളത് (**മ്യൂട്ടബിലിറ്റി** എന്നും അറിയപ്പെടുന്നു).
//!
//! ഇത് നടപ്പിലാക്കുന്നത് Rust കംപൈലറാണ്.എന്നിരുന്നാലും, ഈ നിയമം വേണ്ടത്ര വഴങ്ങാത്ത സാഹചര്യങ്ങളുണ്ട്.ചിലപ്പോൾ ഒരു ഒബ്‌ജക്റ്റിനെക്കുറിച്ച് ഒന്നിലധികം റഫറൻസുകൾ ഉണ്ടായിരിക്കേണ്ടതുണ്ട്, എന്നിട്ടും അത് പരിവർത്തനം ചെയ്യുന്നു.
//!
//! അപരനാമത്തിന്റെ സാന്നിധ്യത്തിൽപ്പോലും, നിയന്ത്രിത രീതിയിൽ പരിവർത്തനം അനുവദിക്കുന്നതിന് പങ്കിടാൻ കഴിയുന്ന മ്യൂട്ടബിൾ കണ്ടെയ്‌നറുകൾ നിലവിലുണ്ട്.[`Cell<T>`], [`RefCell<T>`] എന്നിവ ഒറ്റ-ത്രെഡ് രീതിയിൽ ഇത് ചെയ്യാൻ അനുവദിക്കുന്നു.
//! എന്നിരുന്നാലും, `Cell<T>` അല്ലെങ്കിൽ `RefCell<T>` എന്നിവ ത്രെഡ് സുരക്ഷിതമല്ല (അവ [`Sync`] നടപ്പിലാക്കുന്നില്ല).
//! ഒന്നിലധികം ത്രെഡുകൾക്കിടയിൽ നിങ്ങൾക്ക് അപരനാമവും മ്യൂട്ടേഷനും ചെയ്യണമെങ്കിൽ [`Mutex<T>`], [`RwLock<T>`] അല്ലെങ്കിൽ [`atomic`] തരങ്ങൾ ഉപയോഗിക്കാൻ കഴിയും.
//!
//! `Cell<T>`, `RefCell<T>` തരങ്ങളുടെ മൂല്യങ്ങൾ പങ്കിട്ട റഫറൻസുകളിലൂടെ പരിവർത്തനം ചെയ്യാം (അതായത്
//! സാധാരണ `&T` തരം), അതേസമയം മിക്ക Rust തരങ്ങളും അദ്വിതീയ (`&മ്യൂട്ട് ടി`) റഫറൻസുകളിലൂടെ മാത്രമേ പരിവർത്തനം ചെയ്യാൻ കഴിയൂ.
//! 'പാരമ്പര്യമായി പരിവർത്തനം' കാണിക്കുന്ന സാധാരണ Rust തരങ്ങളിൽ നിന്ന് വ്യത്യസ്തമായി `Cell<T>`, `RefCell<T>` എന്നിവ 'ഇന്റീരിയർ മ്യൂട്ടബിലിറ്റി' നൽകുന്നുവെന്ന് ഞങ്ങൾ പറയുന്നു.
//!
//! സെൽ തരങ്ങൾ രണ്ട് സുഗന്ധങ്ങളിൽ വരുന്നു: `Cell<T>`, `RefCell<T>`.`Cell<T>`-ലും പുറത്തും മൂല്യങ്ങൾ നീക്കി `Cell<T>` ഇന്റീരിയർ മ്യൂട്ടബിലിറ്റി നടപ്പിലാക്കുന്നു.
//! മൂല്യങ്ങൾക്ക് പകരം റഫറൻസുകൾ ഉപയോഗിക്കുന്നതിന്, പരിവർത്തനം ചെയ്യുന്നതിന് മുമ്പ് ഒരു റൈറ്റ് ലോക്ക് സ്വന്തമാക്കി `RefCell<T>` തരം ഉപയോഗിക്കണം.നിലവിലെ ഇന്റീരിയർ മൂല്യം വീണ്ടെടുക്കാനും മാറ്റാനുമുള്ള രീതികൾ `Cell<T>` നൽകുന്നു:
//!
//!  - [`Copy`] നടപ്പിലാക്കുന്ന തരങ്ങൾക്കായി, [`get`](Cell::get) രീതി നിലവിലെ ഇന്റീരിയർ മൂല്യം വീണ്ടെടുക്കുന്നു.
//!  - [`Default`] നടപ്പിലാക്കുന്ന തരങ്ങൾക്കായി, [`take`](Cell::take) രീതി നിലവിലെ ഇന്റീരിയർ മൂല്യത്തെ [`Default::default()`] ഉപയോഗിച്ച് മാറ്റിസ്ഥാപിക്കുകയും മാറ്റിസ്ഥാപിച്ച മൂല്യം നൽകുകയും ചെയ്യുന്നു.
//!  - എല്ലാ തരത്തിനും, [`replace`](Cell::replace) രീതി നിലവിലെ ഇന്റീരിയർ മൂല്യത്തെ മാറ്റിസ്ഥാപിക്കുകയും മാറ്റിസ്ഥാപിച്ച മൂല്യം നൽകുകയും [`into_inner`](Cell::into_inner) രീതി `Cell<T>` ഉപയോഗിക്കുകയും ഇന്റീരിയർ മൂല്യം നൽകുകയും ചെയ്യുന്നു.
//!  കൂടാതെ, എക്സ് 00 എക്സ് രീതി ഇന്റീരിയർ മൂല്യത്തെ മാറ്റിസ്ഥാപിക്കുന്നു, മാറ്റിസ്ഥാപിച്ച മൂല്യം ഉപേക്ഷിക്കുന്നു.
//!
//! `RefCell<T>` ആന്തരിക മൂല്യത്തിലേക്ക് താൽക്കാലികവും എക്‌സ്‌ക്ലൂസീവും മ്യൂട്ടബിൾ ആക്‌സസ്സും അവകാശപ്പെടാൻ കഴിയുന്ന ഒരു പ്രക്രിയയായ 'ഡൈനാമിക് ലോറിംഗ്' നടപ്പിലാക്കാൻ Rust-ന്റെ ആയുസ്സ് ഉപയോഗിക്കുന്നു.
//! `RefCell 'നായുള്ള കടം<T>Rust-ന്റെ നേറ്റീവ് റഫറൻസ് തരങ്ങളിൽ നിന്ന് വ്യത്യസ്തമായി, കംപൈൽ സമയത്ത് സ്റ്റാറ്റിറ്റിക്കായി പൂർണ്ണമായും ട്രാക്കുചെയ്യപ്പെടുന്ന 'റൺടൈമിൽ' ട്രാക്കുചെയ്യുന്നു.
//! `RefCell<T>` വായ്പകൾ ചലനാത്മകമായതിനാൽ ഇതിനകം പരസ്പരം കടം വാങ്ങിയ ഒരു മൂല്യം കടമെടുക്കാൻ ശ്രമിക്കാം;ഇത് സംഭവിക്കുമ്പോൾ അത് panic ത്രെഡിൽ കലാശിക്കുന്നു.
//!
//! # ഇന്റീരിയർ മ്യൂട്ടബിലിറ്റി എപ്പോൾ തിരഞ്ഞെടുക്കണം
//!
//! ഒരു മൂല്യം പരിവർത്തനം ചെയ്യുന്നതിന് അദ്വിതീയമായ ആക്‌സസ് ഉണ്ടായിരിക്കേണ്ട കൂടുതൽ പാരമ്പര്യമായി ലഭിച്ച മ്യൂട്ടബിലിറ്റി, പോയിന്റർ അപരനാമത്തെക്കുറിച്ച് ശക്തമായി ന്യായീകരിക്കാൻ Rust നെ പ്രാപ്‌തമാക്കുന്ന പ്രധാന ഭാഷാ ഘടകങ്ങളിലൊന്നാണ്, ക്രാഷ് ബഗുകളെ സ്ഥിരമായി തടയുന്നു.
//! അതുകാരണം, പാരമ്പര്യമായി പരിവർത്തനം ചെയ്യപ്പെടുന്നതാണ് അഭികാമ്യം, ഇന്റീരിയർ മ്യൂട്ടബിലിറ്റി ഒരു അവസാന ആശ്രയമാണ്.
//! സെൽ‌തരങ്ങൾ‌മ്യൂട്ടേഷനെ പ്രാപ്‌തമാക്കുന്നതിനാൽ‌അത് അനുവദനീയമല്ലാത്തതിനാൽ‌, ഇന്റീരിയർ‌മ്യൂട്ടബിളിറ്റി ഉചിതമായിരിക്കാം, അല്ലെങ്കിൽ‌ *പോലും* ഉപയോഗിക്കേണ്ടതുണ്ട്, ഉദാ.
//!
//! * മാറ്റമില്ലാത്ത ഒന്നിന്റെ മ്യൂട്ടബിലിറ്റി 'inside' അവതരിപ്പിക്കുന്നു
//! * യുക്തിപരമായി മാറ്റമില്ലാത്ത രീതികളുടെ നടപ്പാക്കൽ വിശദാംശങ്ങൾ.
//! * [`Clone`]-ന്റെ പരിവർത്തനം നടപ്പിലാക്കൽ.
//!
//! ## മാറ്റമില്ലാത്ത ഒന്നിന്റെ മ്യൂട്ടബിലിറ്റി 'inside' അവതരിപ്പിക്കുന്നു
//!
//! [`Rc<T>`], [`Arc<T>`] എന്നിവയുൾപ്പെടെ നിരവധി പങ്കിട്ട സ്മാർട്ട് പോയിന്റർ തരങ്ങൾ ഒന്നിലധികം പാർട്ടികൾക്കിടയിൽ ക്ലോൺ ചെയ്യാനും പങ്കിടാനും കഴിയുന്ന കണ്ടെയ്‌നറുകൾ നൽകുന്നു.
//! അടങ്ങിയിരിക്കുന്ന മൂല്യങ്ങൾ ഗുണിത-അപരനാമം ആയതിനാൽ, അവ കടമെടുക്കാൻ കഴിയുന്നത് `&` അല്ല, `&mut` അല്ല.
//! സെല്ലുകൾ ഇല്ലാതെ ഈ സ്മാർട്ട് പോയിന്ററുകൾക്കുള്ളിൽ ഡാറ്റ പരിവർത്തനം ചെയ്യുന്നത് അസാധ്യമാണ്.
//!
//! മ്യൂട്ടബിലിറ്റി വീണ്ടും അവതരിപ്പിക്കുന്നതിന് പങ്കിട്ട പോയിന്റർ തരങ്ങൾക്കുള്ളിൽ ഒരു `RefCell<T>` ഇടുന്നത് വളരെ സാധാരണമാണ്:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // ചലനാത്മക വായ്പയുടെ വ്യാപ്തി പരിമിതപ്പെടുത്തുന്നതിന് ഒരു പുതിയ ബ്ലോക്ക് സൃഷ്ടിക്കുക
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // കാഷെയുടെ മുമ്പത്തെ കടം പരിധിക്ക് പുറത്താകാൻ ഞങ്ങൾ അനുവദിച്ചില്ലെങ്കിൽ, തുടർന്നുള്ള വായ്പ ഒരു ചലനാത്മക ത്രെഡിന് കാരണമാകും panic.
//!     //
//!     // `RefCell` ഉപയോഗിക്കുന്നതിനുള്ള പ്രധാന അപകടമാണിത്.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! ഈ ഉദാഹരണം `Rc<T>` ആണ് ഉപയോഗിക്കുന്നത്, `Arc<T>` അല്ല.`RefCell<T>സിംഗിൾ-ത്രെഡ് രംഗങ്ങൾക്കുള്ളതാണ്.ഒരു മൾട്ടി-ത്രെഡ് സാഹചര്യത്തിൽ നിങ്ങൾക്ക് പങ്കിട്ട മ്യൂട്ടബിലിറ്റി ആവശ്യമെങ്കിൽ [`RwLock<T>`] അല്ലെങ്കിൽ [`Mutex<T>`] ഉപയോഗിക്കുന്നത് പരിഗണിക്കുക.
//!
//! ## യുക്തിപരമായി മാറ്റമില്ലാത്ത രീതികളുടെ നടപ്പാക്കൽ വിശദാംശങ്ങൾ
//!
//! ഇടയ്ക്കിടെ "under the hood"-ൽ മ്യൂട്ടേഷൻ നടക്കുന്നുണ്ടെന്ന് ഒരു API-യിൽ വെളിപ്പെടുത്താതിരിക്കുന്നത് അഭികാമ്യമാണ്.
//! യുക്തിപരമായി പ്രവർത്തനം മാറ്റമില്ലാത്തതാകാം ഇതിന് കാരണം, ഉദാ. കാഷെചെയ്യൽ മ്യൂട്ടേഷൻ നടത്താൻ നടപ്പാക്കലിനെ പ്രേരിപ്പിക്കുന്നു;അല്ലെങ്കിൽ `&self` എടുക്കാൻ ആദ്യം നിർവചിച്ച ഒരു trait രീതി നടപ്പിലാക്കാൻ നിങ്ങൾ മ്യൂട്ടേഷൻ ഉപയോഗിക്കേണ്ടതുണ്ട്.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // ചെലവേറിയ കണക്കുകൂട്ടൽ ഇവിടെ പോകുന്നു
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## `Clone`-ന്റെ പരിവർത്തനം നടപ്പിലാക്കൽ
//!
//! ഇത് മുമ്പത്തെ ഒരു പ്രത്യേക, എന്നാൽ പൊതുവായ ഒരു കേസാണ്: മാറ്റമില്ലാത്തതായി തോന്നുന്ന പ്രവർത്തനങ്ങൾക്ക് പരിവർത്തനം മറയ്ക്കുന്നു.
//! [`clone`](Clone::clone) രീതി ഉറവിട മൂല്യം മാറ്റില്ലെന്ന് പ്രതീക്ഷിക്കുന്നു, മാത്രമല്ല `&mut self` അല്ല `&self` എടുക്കുമെന്ന് പ്രഖ്യാപിക്കുകയും ചെയ്യുന്നു.
//! അതിനാൽ, `clone` രീതിയിൽ സംഭവിക്കുന്ന ഏത് മ്യൂട്ടേഷനും സെൽ തരങ്ങൾ ഉപയോഗിക്കണം.
//! ഉദാഹരണത്തിന്, [`Rc<T>`] അതിന്റെ റഫറൻസ് എണ്ണം ഒരു `Cell<T>`-നുള്ളിൽ നിലനിർത്തുന്നു.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// മാറ്റാവുന്ന മെമ്മറി സ്ഥാനം.
///
/// # Examples
///
/// ഈ ഉദാഹരണത്തിൽ, മാറ്റമില്ലാത്ത ഒരു ഘടനയ്ക്കുള്ളിൽ മ്യൂട്ടേഷൻ `Cell<T>` പ്രാപ്തമാക്കുന്നത് നിങ്ങൾക്ക് കാണാം.
/// മറ്റൊരു വിധത്തിൽ പറഞ്ഞാൽ, ഇത് "interior mutability" പ്രവർത്തനക്ഷമമാക്കുന്നു.
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // പിശക്: `my_struct` മാറ്റമില്ലാത്തതാണ്
/// // my_struct.regular_field =പുതിയ_മൂല്യം;
///
/// // ജോലികൾ: `my_struct` മാറ്റമില്ലാത്തതാണെങ്കിലും, `special_field` ഒരു `Cell` ആണ്,
/// // അത് എല്ലായ്പ്പോഴും പരിവർത്തനം ചെയ്യാൻ കഴിയും
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// കൂടുതൽ വിവരങ്ങൾക്ക് [module-level documentation](self) കാണുക.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// ടി യ്ക്കുള്ള എക്സ് 01 എക്സ് മൂല്യം ഉപയോഗിച്ച് ഒരു എക്സ് 00 എക്സ് സൃഷ്ടിക്കുന്നു.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// തന്നിരിക്കുന്ന മൂല്യം ഉൾക്കൊള്ളുന്ന ഒരു പുതിയ `Cell` സൃഷ്ടിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// അടങ്ങിയിരിക്കുന്ന മൂല്യം സജ്ജമാക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// രണ്ട് സെല്ലുകളുടെ മൂല്യങ്ങൾ സ്വാപ്പ് ചെയ്യുന്നു.
    /// `std::mem::swap` യുമായുള്ള വ്യത്യാസം ഈ ഫംഗ്ഷന് `&mut` റഫറൻസ് ആവശ്യമില്ല എന്നതാണ്.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // സുരക്ഷ: പ്രത്യേക ത്രെഡുകളിൽ നിന്ന് വിളിച്ചാൽ ഇത് അപകടകരമാണ്, പക്ഷേ `Cell`
        // `!Sync` ആയതിനാൽ ഇത് സംഭവിക്കില്ല.
        // `Cell` ഈ `സെല്ലുകളിലൊന്നിലേക്ക് മറ്റൊന്നും ചൂണ്ടിക്കാണിക്കില്ലെന്ന് ഉറപ്പാക്കുന്നതിനാൽ ഇത് ഒരു പോയിന്ററുകളും അസാധുവാക്കില്ല.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// അടങ്ങിയിരിക്കുന്ന മൂല്യം `val` ഉപയോഗിച്ച് മാറ്റിസ്ഥാപിക്കുകയും പഴയ അടങ്ങിയിരിക്കുന്ന മൂല്യം നൽകുകയും ചെയ്യുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // സുരക്ഷ: ഒരു പ്രത്യേക ത്രെഡിൽ നിന്ന് വിളിച്ചാൽ ഇത് ഡാറ്റ റേസുകൾക്ക് കാരണമാകും,
        // എന്നാൽ `Cell` `!Sync` ആയതിനാൽ ഇത് സംഭവിക്കില്ല.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// മൂല്യം അൺ‌റാപ്പ് ചെയ്യുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// അടങ്ങിയിരിക്കുന്ന മൂല്യത്തിന്റെ ഒരു പകർപ്പ് നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // സുരക്ഷ: ഒരു പ്രത്യേക ത്രെഡിൽ നിന്ന് വിളിച്ചാൽ ഇത് ഡാറ്റ റേസുകൾക്ക് കാരണമാകും,
        // എന്നാൽ `Cell` `!Sync` ആയതിനാൽ ഇത് സംഭവിക്കില്ല.
        unsafe { *self.value.get() }
    }

    /// ഒരു ഫംഗ്ഷൻ ഉപയോഗിച്ച് അടങ്ങിയിരിക്കുന്ന മൂല്യം അപ്‌ഡേറ്റ് ചെയ്യുകയും പുതിയ മൂല്യം നൽകുകയും ചെയ്യുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// ഈ സെല്ലിലെ അടിസ്ഥാന ഡാറ്റയിലേക്ക് ഒരു റോ പോയിന്റർ നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// അടിസ്ഥാന ഡാറ്റയിലേക്ക് ഒരു മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു.
    ///
    /// ഈ കോൾ `Cell` പരസ്പരം കടമെടുക്കുന്നു (കംപൈൽ സമയത്ത്) ഞങ്ങൾക്ക് ഏക റഫറൻസ് ഉണ്ടെന്ന് ഉറപ്പുനൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// ഒരു `&mut T`-ൽ നിന്ന് ഒരു `&Cell<T>` നൽകുന്നു
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // സുരക്ഷ: എക്സ് 00 എക്സ് അദ്വിതീയ ആക്സസ് ഉറപ്പാക്കുന്നു.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// സെല്ലിന്റെ മൂല്യം എടുക്കുന്നു, `Default::default()` അതിന്റെ സ്ഥാനത്ത് ഉപേക്ഷിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// ഒരു `&Cell<[T]>`-ൽ നിന്ന് ഒരു `&[Cell<T>]` നൽകുന്നു
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // സുരക്ഷ: `Cell<T>` ന് `T`-ന് സമാനമായ മെമ്മറി ലേ layout ട്ട് ഉണ്ട്.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// ചലനാത്മകമായി പരിശോധിച്ച വായ്പ നിയമങ്ങളുള്ള ഒരു മ്യൂട്ടബിൾ മെമ്മറി സ്ഥാനം
///
/// കൂടുതൽ വിവരങ്ങൾക്ക് [module-level documentation](self) കാണുക.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// [`RefCell::try_borrow`] നൽകിയ ഒരു പിശക്.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// [`RefCell::try_borrow_mut`] നൽകിയ ഒരു പിശക്.
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// പോസിറ്റീവ് മൂല്യങ്ങൾ `Ref` സജീവമായ എണ്ണത്തെ പ്രതിനിധീകരിക്കുന്നു.നെഗറ്റീവ് മൂല്യങ്ങൾ `RefMut` സജീവമായ എണ്ണത്തെ പ്രതിനിധീകരിക്കുന്നു.
// ഒരു `RefCell`-ന്റെ വ്യതിരിക്തവും നോൺ‌ഓവർ‌ലാപ്പിംഗ് ഘടകങ്ങളും (ഉദാ. ഒരു സ്ലൈസിന്റെ വ്യത്യസ്ത ശ്രേണികൾ‌) പരാമർശിച്ചാൽ‌മാത്രമേ ഒന്നിലധികം `RefMut` കൾ‌സജീവമാകൂ.
//
// `Ref` ഒപ്പം `RefMut` രണ്ടും വലുപ്പത്തിലുള്ള രണ്ട് പദങ്ങളാണ്, അതിനാൽ `usize` ശ്രേണിയുടെ പകുതിയോളം കവിഞ്ഞൊഴുകാൻ പര്യാപ്തമായ `Ref` കളോ`RefMut`-കളോ ഒരിക്കലും ഉണ്ടാകില്ല.
// അതിനാൽ, ഒരു `BorrowFlag` ഒരിക്കലും കവിഞ്ഞൊഴുകുകയോ ഒഴുകുകയോ ചെയ്യില്ല.
// എന്നിരുന്നാലും, ഇത് ഒരു ഗ്യാരണ്ടിയല്ല, കാരണം ഒരു പാത്തോളജിക്കൽ പ്രോഗ്രാം ആവർത്തിച്ച് സൃഷ്ടിക്കുകയും തുടർന്ന് mem::forget `Ref`s അല്ലെങ്കിൽ`RefMut`s നൽകുകയും ചെയ്യും.
// അതിനാൽ, സുരക്ഷിതമല്ലാത്തത് ഒഴിവാക്കുന്നതിന് എല്ലാ കോഡുകളും ഓവർഫ്ലോയും അണ്ടർഫ്ലോയും വ്യക്തമായി പരിശോധിക്കണം, അല്ലെങ്കിൽ ഓവർഫ്ലോ അല്ലെങ്കിൽ അണ്ടർഫ്ലോ സംഭവിക്കുന്ന സാഹചര്യത്തിൽ ശരിയായി പെരുമാറണം (ഉദാ. BorrowRef::new കാണുക).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// `value` അടങ്ങിയ ഒരു പുതിയ `RefCell` സൃഷ്ടിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// പൊതിഞ്ഞ മൂല്യം നൽകിക്കൊണ്ട് `RefCell` ഉപയോഗിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // ഈ ഫംഗ്ഷൻ `self` (`RefCell`) മൂല്യം അനുസരിച്ച് എടുക്കുന്നതിനാൽ, കംപൈലർ ഇത് നിലവിൽ കടമെടുത്തിട്ടില്ലെന്ന് സ്ഥിരീകരിക്കുന്നു.
        //
        self.value.into_inner()
    }

    /// പൊതിഞ്ഞ മൂല്യം പുതിയൊരെണ്ണം ഉപയോഗിച്ച് മാറ്റി പഴയ മൂല്യം മടക്കിനൽകുന്നു.
    ///
    ///
    /// ഈ പ്രവർത്തനം [`std::mem::replace`](../mem/fn.replace.html)-ന് യോജിക്കുന്നു.
    ///
    /// # Panics
    ///
    /// മൂല്യം നിലവിൽ കടമെടുത്തതാണെങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// പൊതിഞ്ഞ മൂല്യം `f`-ൽ നിന്ന് കണക്കാക്കിയ പുതിയ ഒരെണ്ണം ഉപയോഗിച്ച് മാറ്റിസ്ഥാപിക്കുന്നു, പഴയ മൂല്യം മടക്കിനൽകുന്നു.
    ///
    ///
    /// # Panics
    ///
    /// മൂല്യം നിലവിൽ കടമെടുത്തതാണെങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// `self`-ന്റെ പൊതിഞ്ഞ മൂല്യം `other`-ന്റെ പൊതിഞ്ഞ മൂല്യം ഉപയോഗിച്ച് സ്വാപ്പ് ചെയ്യുന്നു.
    ///
    ///
    /// ഈ പ്രവർത്തനം [`std::mem::swap`](../mem/fn.swap.html)-ന് യോജിക്കുന്നു.
    ///
    /// # Panics
    ///
    /// `RefCell`-ലെ മൂല്യം നിലവിൽ കടമെടുത്തിട്ടുണ്ടെങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// പൊതിഞ്ഞ മൂല്യം മാറ്റമില്ലാതെ കടമെടുക്കുന്നു.
    ///
    /// മടങ്ങിയ `Ref` സ്കോപ്പിൽ നിന്ന് പുറത്തുകടക്കുന്നതുവരെ വായ്പ നീണ്ടുനിൽക്കും.
    /// ഒരേ സമയം ഒന്നിലധികം മാറ്റമില്ലാത്ത വായ്പകൾ എടുക്കാം.
    ///
    /// # Panics
    ///
    /// മൂല്യം നിലവിൽ പരസ്പരം കടമെടുത്തിട്ടുണ്ടെങ്കിൽ Panics.
    /// പരിഭ്രാന്തരാകാത്ത വേരിയന്റിനായി, [`try_borrow`](#method.try_borrow) ഉപയോഗിക്കുക.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// panic-ന്റെ ഒരു ഉദാഹരണം:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// പൊതിഞ്ഞ മൂല്യം മാറ്റമില്ലാതെ കടമെടുക്കുന്നു, മൂല്യം നിലവിൽ പരസ്പരം കടമെടുത്തിട്ടുണ്ടെങ്കിൽ ഒരു പിശക് നൽകുന്നു.
    ///
    ///
    /// മടങ്ങിയ `Ref` സ്കോപ്പിൽ നിന്ന് പുറത്തുകടക്കുന്നതുവരെ വായ്പ നീണ്ടുനിൽക്കും.
    /// ഒരേ സമയം ഒന്നിലധികം മാറ്റമില്ലാത്ത വായ്പകൾ എടുക്കാം.
    ///
    /// [`borrow`](#method.borrow)-ന്റെ പരിഭ്രാന്തരാകാത്ത വേരിയന്റാണിത്.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // സുരക്ഷ: മാറ്റമില്ലാത്ത ആക്സസ് മാത്രമേ ഉള്ളൂവെന്ന് `BorrowRef` ഉറപ്പാക്കുന്നു
            // കടമെടുക്കുമ്പോൾ മൂല്യത്തിലേക്ക്.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// പൊതിഞ്ഞ മൂല്യം പരസ്പരം കടമെടുക്കുന്നു.
    ///
    /// മടങ്ങിയെത്തിയ `RefMut` അല്ലെങ്കിൽ അതിൽ നിന്ന് ഉരുത്തിരിഞ്ഞ എല്ലാ `RefMut` കളും കടം പുറത്തുവരും.
    ///
    /// ഈ വായ്പ സജീവമായിരിക്കുമ്പോൾ മൂല്യം കടമെടുക്കാൻ കഴിയില്ല.
    ///
    /// # Panics
    ///
    /// മൂല്യം നിലവിൽ കടമെടുത്തതാണെങ്കിൽ Panics.
    /// പരിഭ്രാന്തരാകാത്ത വേരിയന്റിനായി, [`try_borrow_mut`](#method.try_borrow_mut) ഉപയോഗിക്കുക.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// panic-ന്റെ ഒരു ഉദാഹരണം:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// പൊതിഞ്ഞ മൂല്യം പരസ്പരം കടമെടുക്കുന്നു, മൂല്യം നിലവിൽ കടമെടുത്തിട്ടുണ്ടെങ്കിൽ ഒരു പിശക് നൽകുന്നു.
    ///
    ///
    /// മടങ്ങിയെത്തിയ `RefMut` അല്ലെങ്കിൽ അതിൽ നിന്ന് ഉരുത്തിരിഞ്ഞ എല്ലാ `RefMut` കളും കടം പുറത്തുവരും.
    /// ഈ വായ്പ സജീവമായിരിക്കുമ്പോൾ മൂല്യം കടമെടുക്കാൻ കഴിയില്ല.
    ///
    /// [`borrow_mut`](#method.borrow_mut)-ന്റെ പരിഭ്രാന്തരാകാത്ത വേരിയന്റാണിത്.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // സുരക്ഷ: എക്സ് 00 എക്സ് അദ്വിതീയ ആക്സസ് ഉറപ്പ് നൽകുന്നു.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// ഈ സെല്ലിലെ അടിസ്ഥാന ഡാറ്റയിലേക്ക് ഒരു റോ പോയിന്റർ നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// അടിസ്ഥാന ഡാറ്റയിലേക്ക് ഒരു മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു.
    ///
    /// ഈ കോൾ `RefCell` പരസ്പരം കടമെടുക്കുന്നു (കംപൈൽ സമയത്ത്) അതിനാൽ ഡൈനാമിക് ചെക്കുകളുടെ ആവശ്യമില്ല.
    ///
    /// എന്നിരുന്നാലും ജാഗ്രത പാലിക്കുക: ഈ രീതി `self` മ്യൂട്ടബിൾ ആയിരിക്കുമെന്ന് പ്രതീക്ഷിക്കുന്നു, ഇത് `RefCell` ഉപയോഗിക്കുമ്പോൾ സാധാരണയായി സംഭവിക്കില്ല.
    ///
    /// `self` മ്യൂട്ടബിൾ അല്ലെങ്കിൽ പകരം [`borrow_mut`] രീതി നോക്കുക.
    ///
    /// കൂടാതെ, ഈ രീതി പ്രത്യേക സാഹചര്യങ്ങളിൽ മാത്രമാണെന്നും സാധാരണയായി നിങ്ങൾ ആഗ്രഹിക്കുന്നതല്ലെന്നും മനസിലാക്കുക.
    /// സംശയമുണ്ടെങ്കിൽ, പകരം [`borrow_mut`] ഉപയോഗിക്കുക.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// ചോർന്ന ഗാർഡുകളുടെ സ്വാധീനം `RefCell`-ന്റെ വായ്പാ അവസ്ഥയിൽ പഴയപടിയാക്കുക.
    ///
    /// ഈ കോൾ [`get_mut`]-ന് സമാനമാണ്, പക്ഷേ കൂടുതൽ പ്രത്യേകതയുള്ളതാണ്.
    /// വായ്പകളൊന്നും നിലവിലില്ലെന്ന് ഉറപ്പുവരുത്താൻ ഇത് `RefCell` പരസ്പരം കടമെടുക്കുകയും തുടർന്ന് സംസ്ഥാന ട്രാക്കിംഗ് പങ്കിട്ട വായ്പകൾ പുന reset സജ്ജമാക്കുകയും ചെയ്യുന്നു.
    /// ചില `Ref` അല്ലെങ്കിൽ `RefMut` വായ്പകൾ ചോർന്നിട്ടുണ്ടെങ്കിൽ ഇത് പ്രസക്തമാണ്.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// പൊതിഞ്ഞ മൂല്യം മാറ്റമില്ലാതെ കടമെടുക്കുന്നു, മൂല്യം നിലവിൽ പരസ്പരം കടമെടുത്തിട്ടുണ്ടെങ്കിൽ ഒരു പിശക് നൽകുന്നു.
    ///
    /// # Safety
    ///
    /// `RefCell::borrow`-ൽ നിന്ന് വ്യത്യസ്തമായി, ഈ രീതി സുരക്ഷിതമല്ല, കാരണം ഇത് ഒരു `Ref` നൽകുന്നില്ല, അതിനാൽ വായ്പ പതാക തൊടുന്നില്ല.
    /// ഈ രീതി നൽകിയ റഫറൻസ് സജീവമായിരിക്കുമ്പോൾ `RefCell` കടമെടുക്കുന്നത് നിർവചിക്കപ്പെടാത്ത സ്വഭാവമാണ്.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // സുരക്ഷ: ആരും ഇപ്പോൾ സജീവമായി എഴുതുന്നില്ലെന്ന് ഞങ്ങൾ പരിശോധിക്കുന്നു, പക്ഷേ അത്
            // മടങ്ങിയ റഫറൻസ് ഇനിമുതൽ ഉപയോഗത്തിലാകുന്നത് വരെ ആരും എഴുതുന്നില്ലെന്ന് ഉറപ്പാക്കാനുള്ള കോളറുടെ ഉത്തരവാദിത്തം.
            // കൂടാതെ, `self.value.get()` എന്നത് `self` ന്റെ ഉടമസ്ഥതയിലുള്ള മൂല്യത്തെ സൂചിപ്പിക്കുന്നു, അതിനാൽ `self` ന്റെ ആജീവനാന്തത്തിന് സാധുതയുണ്ടെന്ന് ഉറപ്പുനൽകുന്നു.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// പൊതിഞ്ഞ മൂല്യം എടുക്കുന്നു, `Default::default()` അതിന്റെ സ്ഥാനത്ത് ഉപേക്ഷിക്കുന്നു.
    ///
    /// # Panics
    ///
    /// മൂല്യം നിലവിൽ കടമെടുത്തതാണെങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// മൂല്യം നിലവിൽ പരസ്പരം കടമെടുത്തിട്ടുണ്ടെങ്കിൽ Panics.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// ടി യ്ക്കുള്ള എക്സ് 01 എക്സ് മൂല്യം ഉപയോഗിച്ച് ഒരു എക്സ് 00 എക്സ് സൃഷ്ടിക്കുന്നു.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// `RefCell`-ലെ മൂല്യം നിലവിൽ കടമെടുത്തിട്ടുണ്ടെങ്കിൽ Panics.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// `RefCell`-ലെ മൂല്യം നിലവിൽ കടമെടുത്തിട്ടുണ്ടെങ്കിൽ Panics.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// `RefCell`-ലെ മൂല്യം നിലവിൽ കടമെടുത്തിട്ടുണ്ടെങ്കിൽ Panics.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// `RefCell`-ലെ മൂല്യം നിലവിൽ കടമെടുത്തിട്ടുണ്ടെങ്കിൽ Panics.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// `RefCell`-ലെ മൂല്യം നിലവിൽ കടമെടുത്തിട്ടുണ്ടെങ്കിൽ Panics.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// `RefCell`-ലെ മൂല്യം നിലവിൽ കടമെടുത്തിട്ടുണ്ടെങ്കിൽ Panics.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// `RefCell`-ലെ മൂല്യം നിലവിൽ കടമെടുത്തിട്ടുണ്ടെങ്കിൽ Panics.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // വായ്പ വർദ്ധിപ്പിക്കുന്നത് ഈ സന്ദർഭങ്ങളിൽ വായിക്കാത്ത മൂല്യത്തിന് (<=0) കാരണമാകും:
            // 1. ഇത് <0 ആയിരുന്നു, അതായത് എഴുതുന്ന വായ്പകളുണ്ട്, അതിനാൽ Rust ന്റെ റഫറൻസ് അപരനാമ നിയമങ്ങൾ കാരണം ഞങ്ങൾക്ക് ഒരു റീഡ് വായ്പ അനുവദിക്കാൻ കഴിയില്ല.
            // 2.
            // ഇത് എക്സ് 100 എക്സ് (വായനാ വായ്പകളുടെ പരമാവധി തുക) ആയിരുന്നു, അത് എക്സ് 01 എക്സിലേക്ക് കവിഞ്ഞൊഴുകി (എഴുത്ത് വായ്പകളുടെ പരമാവധി തുക) അതിനാൽ ഞങ്ങൾക്ക് ഒരു അധിക റീഡ് വായ്പ അനുവദിക്കാൻ കഴിയില്ല, കാരണം ഐസൈസിന് ധാരാളം റീഡ് വായ്പകളെ പ്രതിനിധീകരിക്കാൻ കഴിയില്ല (ഇത് സംഭവിക്കുകയാണെങ്കിൽ മാത്രം നിങ്ങൾ സ്ഥിരമായ ഒരു ചെറിയ റഫറിനേക്കാൾ mem::forget കൂടുതലാണ്, ഇത് നല്ല പരിശീലനമല്ല)
            //
            //
            //
            //
            None
        } else {
            // വായ്പ വർദ്ധിപ്പിക്കുന്നത് ഈ സന്ദർഭങ്ങളിൽ ഒരു വായനാ മൂല്യത്തിന് (> 0) കാരണമാകും:
            // 1. ഇത്=0 ആയിരുന്നു, അതായത് അത് കടമെടുത്തില്ല, ഞങ്ങൾ ആദ്യം വായിച്ച കടമെടുക്കുന്നു
            // 2. ഇത്> 0 ഉം <isize::MAX ഉം ആയിരുന്നു, അതായത്
            // റീഡ് വായ്പകൾ ഉണ്ടായിരുന്നു, കൂടാതെ ഒരു റീഡ് ലോൺ കൂടി ഉള്ളതായി പ്രതിനിധീകരിക്കുന്നതിന് ഐസൈസ് വലുതാണ്
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // ഈ റഫർ നിലനിൽക്കുന്നതിനാൽ, വായ്പ പതാക ഒരു വായനാ കടമാണെന്ന് ഞങ്ങൾക്കറിയാം.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // ഒരു എഴുത്ത് കടത്തിലേക്ക് കവിഞ്ഞൊഴുകുന്നത് തടയുക.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// ഒരു `RefCell` ബോക്സിലെ ഒരു മൂല്യത്തിലേക്ക് കടമെടുത്ത റഫറൻസ് പൊതിയുന്നു.
/// ഒരു `RefCell<T>`-ൽ നിന്ന് മാറ്റമില്ലാത്ത കടമെടുക്കുന്ന മൂല്യത്തിനായുള്ള ഒരു റാപ്പർ തരം.
///
/// കൂടുതൽ വിവരങ്ങൾക്ക് [module-level documentation](self) കാണുക.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// ഒരു `Ref` പകർത്തുന്നു.
    ///
    /// `RefCell` ഇതിനകം മാറ്റമില്ലാതെ കടമെടുത്തതിനാൽ ഇത് പരാജയപ്പെടാൻ കഴിയില്ല.
    ///
    /// ഇത് ഒരു അനുബന്ധ ഫംഗ്ഷനാണ്, അത് `Ref::clone(...)` ആയി ഉപയോഗിക്കേണ്ടതുണ്ട്.
    /// ഒരു `Clone` നടപ്പിലാക്കൽ അല്ലെങ്കിൽ ഒരു രീതി ഒരു `RefCell` ന്റെ ഉള്ളടക്കങ്ങൾ ക്ലോൺ ചെയ്യുന്നതിന് `r.borrow().clone()` ന്റെ വ്യാപകമായ ഉപയോഗത്തെ തടസ്സപ്പെടുത്തും.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// കടമെടുത്ത ഡാറ്റയുടെ ഒരു ഘടകത്തിനായി ഒരു പുതിയ `Ref` നിർമ്മിക്കുന്നു.
    ///
    /// `RefCell` ഇതിനകം മാറ്റമില്ലാതെ കടമെടുത്തതിനാൽ ഇത് പരാജയപ്പെടാൻ കഴിയില്ല.
    ///
    /// ഇത് ഒരു അനുബന്ധ ഫംഗ്ഷനാണ്, അത് `Ref::map(...)` ആയി ഉപയോഗിക്കേണ്ടതുണ്ട്.
    /// `Deref` വഴി ഉപയോഗിക്കുന്ന `RefCell` ന്റെ ഉള്ളടക്കങ്ങളിൽ ഒരേ പേരിലുള്ള രീതികളെ ഒരു രീതി തടസ്സപ്പെടുത്തും.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// കടമെടുത്ത ഡാറ്റയുടെ ഓപ്‌ഷണൽ ഘടകത്തിനായി ഒരു പുതിയ `Ref` നിർമ്മിക്കുന്നു.
    /// അടയ്‌ക്കൽ `None` നൽകിയാൽ യഥാർത്ഥ ഗാർഡ് `Err(..)` ആയി നൽകും.
    ///
    /// `RefCell` ഇതിനകം മാറ്റമില്ലാതെ കടമെടുത്തതിനാൽ ഇത് പരാജയപ്പെടാൻ കഴിയില്ല.
    ///
    /// ഇത് ഒരു അനുബന്ധ ഫംഗ്ഷനാണ്, അത് `Ref::filter_map(...)` ആയി ഉപയോഗിക്കേണ്ടതുണ്ട്.
    /// `Deref` വഴി ഉപയോഗിക്കുന്ന `RefCell` ന്റെ ഉള്ളടക്കങ്ങളിൽ ഒരേ പേരിലുള്ള രീതികളെ ഒരു രീതി തടസ്സപ്പെടുത്തും.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// കടമെടുത്ത ഡാറ്റയുടെ വ്യത്യസ്‌ത ഘടകങ്ങൾ‌ക്കായി ഒരു എക്സ് 100 എക്സ് ഒന്നിലധികം `റഫ'കളായി വിഭജിക്കുന്നു.
    ///
    /// `RefCell` ഇതിനകം മാറ്റമില്ലാതെ കടമെടുത്തതിനാൽ ഇത് പരാജയപ്പെടാൻ കഴിയില്ല.
    ///
    /// ഇത് ഒരു അനുബന്ധ ഫംഗ്ഷനാണ്, അത് `Ref::map_split(...)` ആയി ഉപയോഗിക്കേണ്ടതുണ്ട്.
    /// `Deref` വഴി ഉപയോഗിക്കുന്ന `RefCell` ന്റെ ഉള്ളടക്കങ്ങളിൽ ഒരേ പേരിലുള്ള രീതികളെ ഒരു രീതി തടസ്സപ്പെടുത്തും.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// അടിസ്ഥാന ഡാറ്റയിലേക്കുള്ള റഫറൻസിലേക്ക് പരിവർത്തനം ചെയ്യുക.
    ///
    /// അന്തർലീനമായ `RefCell` ഒരിക്കലും വീണ്ടും പരസ്പരം കടം വാങ്ങാൻ കഴിയില്ല, മാത്രമല്ല എല്ലായ്പ്പോഴും ഇതിനകം കടം വാങ്ങിയതായി ദൃശ്യമാകും.
    ///
    /// സ്ഥിരമായ റഫറൻസുകളേക്കാൾ കൂടുതൽ ചോർത്തുന്നത് നല്ല ആശയമല്ല.
    /// ആകെ കുറഞ്ഞ അളവിൽ‌ചോർച്ചകൾ‌സംഭവിച്ചിട്ടുണ്ടെങ്കിൽ‌, `RefCell` വീണ്ടും മാറ്റമില്ലാതെ കടമെടുക്കാൻ‌കഴിയും.
    ///
    /// ഇത് ഒരു അനുബന്ധ ഫംഗ്ഷനാണ്, അത് `Ref::leak(...)` ആയി ഉപയോഗിക്കേണ്ടതുണ്ട്.
    /// `Deref` വഴി ഉപയോഗിക്കുന്ന `RefCell` ന്റെ ഉള്ളടക്കങ്ങളിൽ ഒരേ പേരിലുള്ള രീതികളെ ഒരു രീതി തടസ്സപ്പെടുത്തും.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // ഈ റഫർ‌മറക്കുന്നതിലൂടെ, റെഫ്‌സെല്ലിലെ വായ്പ ക counter ണ്ടറിന് ആജീവനാന്ത `'b` നുള്ളിൽ‌UNUSED ലേക്ക് തിരികെ പോകാൻ‌കഴിയില്ലെന്ന് ഞങ്ങൾ‌ഉറപ്പാക്കുന്നു.
        // റഫറൻസ് ട്രാക്കിംഗ് നില പുന et സജ്ജമാക്കുന്നതിന് കടമെടുത്ത RefCell-ന് ഒരു അദ്വിതീയ റഫറൻസ് ആവശ്യമാണ്.
        // യഥാർത്ഥ സെല്ലിൽ നിന്ന് കൂടുതൽ മ്യൂട്ടബിൾ റഫറൻസുകൾ സൃഷ്ടിക്കാൻ കഴിയില്ല.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// കടമെടുത്ത ഡാറ്റയുടെ ഒരു ഘടകത്തിനായി ഒരു പുതിയ `RefMut` നിർമ്മിക്കുന്നു, ഉദാ. ഒരു enum വേരിയൻറ്.
    ///
    /// `RefCell` ഇതിനകം പരസ്പരം കടമെടുത്തതിനാൽ ഇത് പരാജയപ്പെടാൻ കഴിയില്ല.
    ///
    /// ഇത് ഒരു അനുബന്ധ ഫംഗ്ഷനാണ്, അത് `RefMut::map(...)` ആയി ഉപയോഗിക്കേണ്ടതുണ്ട്.
    /// `Deref` വഴി ഉപയോഗിക്കുന്ന `RefCell` ന്റെ ഉള്ളടക്കങ്ങളിൽ ഒരേ പേരിലുള്ള രീതികളെ ഒരു രീതി തടസ്സപ്പെടുത്തും.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): വായ്പ-പരിശോധന പരിഹരിക്കുക
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// കടമെടുത്ത ഡാറ്റയുടെ ഓപ്‌ഷണൽ ഘടകത്തിനായി ഒരു പുതിയ `RefMut` നിർമ്മിക്കുന്നു.
    /// അടയ്‌ക്കൽ `None` നൽകിയാൽ യഥാർത്ഥ ഗാർഡ് `Err(..)` ആയി നൽകും.
    ///
    /// `RefCell` ഇതിനകം പരസ്പരം കടമെടുത്തതിനാൽ ഇത് പരാജയപ്പെടാൻ കഴിയില്ല.
    ///
    /// ഇത് ഒരു അനുബന്ധ ഫംഗ്ഷനാണ്, അത് `RefMut::filter_map(...)` ആയി ഉപയോഗിക്കേണ്ടതുണ്ട്.
    /// `Deref` വഴി ഉപയോഗിക്കുന്ന `RefCell` ന്റെ ഉള്ളടക്കങ്ങളിൽ ഒരേ പേരിലുള്ള രീതികളെ ഒരു രീതി തടസ്സപ്പെടുത്തും.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): വായ്പ-പരിശോധന പരിഹരിക്കുക
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // സുരക്ഷ: ഫംഗ്ഷൻ ദൈർഘ്യത്തിനായുള്ള ഒരു എക്സ്ക്ലൂസീവ് റഫറൻസിൽ ഉൾക്കൊള്ളുന്നു
        // എക്സ് 00 എക്സ് വഴിയുള്ള അതിന്റെ കോളിന്റെ, കൂടാതെ ഫംഗ്ഷൻ കോളിനുള്ളിൽ മാത്രമേ പോയിന്റർ ഡി-റഫറൻസ് ചെയ്തിട്ടുള്ളൂ, എക്സ്ക്ലൂസീവ് റഫറൻസിനെ രക്ഷപ്പെടാൻ ഒരിക്കലും അനുവദിക്കുന്നില്ല.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // സുരക്ഷ: മുകളിൽ പറഞ്ഞതുപോലെ.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// കടമെടുത്ത ഡാറ്റയുടെ വ്യത്യസ്‌ത ഘടകങ്ങൾ‌ക്കായി ഒന്നിലധികം `RefMut` കളായി ഒരു `RefMut` വിഭജിക്കുന്നു.
    ///
    /// മടങ്ങിയെത്തിയ `RefMut`-ന്റെ പരിധിയിൽ നിന്ന് പുറത്തുപോകുന്നതുവരെ അന്തർലീനമായ `RefCell` പരസ്പരം കടമെടുത്തതായി തുടരും.
    ///
    /// `RefCell` ഇതിനകം പരസ്പരം കടമെടുത്തതിനാൽ ഇത് പരാജയപ്പെടാൻ കഴിയില്ല.
    ///
    /// ഇത് ഒരു അനുബന്ധ ഫംഗ്ഷനാണ്, അത് `RefMut::map_split(...)` ആയി ഉപയോഗിക്കേണ്ടതുണ്ട്.
    /// `Deref` വഴി ഉപയോഗിക്കുന്ന `RefCell` ന്റെ ഉള്ളടക്കങ്ങളിൽ ഒരേ പേരിലുള്ള രീതികളെ ഒരു രീതി തടസ്സപ്പെടുത്തും.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// അന്തർലീനമായ ഡാറ്റയിലേക്ക് ഒരു മ്യൂട്ടബിൾ റഫറൻസിലേക്ക് പരിവർത്തനം ചെയ്യുക.
    ///
    /// അന്തർലീനമായ `RefCell` വീണ്ടും കടമെടുക്കാൻ കഴിയില്ല, എല്ലായ്പ്പോഴും ഇതിനകം പരസ്പരം കടമെടുത്തതായി ദൃശ്യമാകും, ഇത് മടക്കിനൽകിയ റഫറൻസ് ഇന്റീരിയറിന് മാത്രമുള്ളതാക്കുന്നു.
    ///
    ///
    /// ഇത് ഒരു അനുബന്ധ ഫംഗ്ഷനാണ്, അത് `RefMut::leak(...)` ആയി ഉപയോഗിക്കേണ്ടതുണ്ട്.
    /// `Deref` വഴി ഉപയോഗിക്കുന്ന `RefCell` ന്റെ ഉള്ളടക്കങ്ങളിൽ ഒരേ പേരിലുള്ള രീതികളെ ഒരു രീതി തടസ്സപ്പെടുത്തും.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // ഈ BorrowRefMut മറക്കുന്നതിലൂടെ, RefCell ലെ വായ്പ ക counter ണ്ടറിന് `'b` ആജീവനാന്തത്തിൽ UNUSED ലേക്ക് തിരികെ പോകാൻ കഴിയില്ലെന്ന് ഞങ്ങൾ ഉറപ്പാക്കുന്നു.
        // റഫറൻസ് ട്രാക്കിംഗ് നില പുന et സജ്ജമാക്കുന്നതിന് കടമെടുത്ത RefCell-ന് ഒരു അദ്വിതീയ റഫറൻസ് ആവശ്യമാണ്.
        // ആ ജീവിതകാലത്തിനുള്ളിൽ യഥാർത്ഥ സെല്ലിൽ നിന്ന് കൂടുതൽ റഫറൻസുകളൊന്നും സൃഷ്ടിക്കാൻ കഴിയില്ല, ഇത് നിലവിലുള്ള വായ്പയെ ശേഷിക്കുന്ന ജീവിതകാലത്തെ ഏക റഫറൻസാക്കി മാറ്റുന്നു.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: BorrowRefMut::clone ൽ നിന്ന് വ്യത്യസ്തമായി, പ്രാരംഭം സൃഷ്ടിക്കാൻ പുതിയത് വിളിക്കുന്നു
        // മ്യൂട്ടബിൾ റഫറൻസ്, അതിനാൽ നിലവിൽ നിലവിലുള്ള റഫറൻസുകളൊന്നും ഉണ്ടാകരുത്.
        // അതിനാൽ, ക്ലോൺ മ്യൂട്ടബിൾ റീഫ ount ണ്ട് വർദ്ധിപ്പിക്കുമ്പോൾ, ഇവിടെ ഞങ്ങൾ വ്യക്തമായി UNUSED ൽ നിന്ന് UNUSED ലേക്ക് പോകാൻ അനുവദിക്കുന്നു, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // ഒരു `BorrowRefMut` ക്ലോൺ ചെയ്യുന്നു.
    //
    // ഒറിജിനൽ ഒബ്‌ജക്റ്റിന്റെ വ്യതിരിക്തവും നോൺ‌ഓവർലാപ്പിംഗ് ശ്രേണിയിലേക്കുള്ള മ്യൂട്ടബിൾ റഫറൻസ് ട്രാക്കുചെയ്യുന്നതിന് ഓരോ `BorrowRefMut` ഉപയോഗിച്ചാലും മാത്രമേ ഇത് സാധുതയുള്ളൂ.
    //
    // ഇത് ഒരു ക്ലോൺ ഇം‌പ്ലിൽ ഇല്ലാത്തതിനാൽ കോഡ് ഇതിനെ പരോക്ഷമായി വിളിക്കില്ല.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // കടമെടുക്കുന്ന ക counter ണ്ടർ ഒഴുകുന്നത് തടയുക.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// ഒരു `RefCell<T>`-ൽ നിന്ന് പരസ്പരം കടമെടുത്ത മൂല്യത്തിനായുള്ള ഒരു റാപ്പർ തരം.
///
/// കൂടുതൽ വിവരങ്ങൾക്ക് [module-level documentation](self) കാണുക.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Rust-ലെ ഇന്റീരിയർ മ്യൂട്ടബിലിറ്റിയുടെ പ്രധാന പ്രാകൃതം.
///
/// നിങ്ങൾക്ക് ഒരു റഫറൻസ് `&T` ഉണ്ടെങ്കിൽ, സാധാരണയായി Rust ൽ, കംപൈലർ മാറ്റമില്ലാത്ത ഡാറ്റയിലേക്ക് `&T` പോയിന്റ് ചെയ്യുന്ന അറിവിനെ അടിസ്ഥാനമാക്കി ഒപ്റ്റിമൈസേഷനുകൾ നടത്തുന്നു.ആ ഡാറ്റ പരിവർത്തനം ചെയ്യുന്നത്, ഉദാഹരണത്തിന് ഒരു അപരനാമത്തിലൂടെ അല്ലെങ്കിൽ ഒരു `&T` ഒരു `&mut T` ലേക്ക് പരിവർത്തനം ചെയ്യുന്നതിലൂടെ നിർവചിക്കപ്പെടാത്ത സ്വഭാവമായി കണക്കാക്കപ്പെടുന്നു.
/// `UnsafeCell<T>` `&T`-നായുള്ള മാറ്റമില്ലാത്ത ഗ്യാരണ്ടി ഒഴിവാക്കുന്നു: ഒരു പങ്കിട്ട റഫറൻസ് `&UnsafeCell<T>` പരിവർത്തനം ചെയ്യപ്പെടുന്ന ഡാറ്റയിലേക്ക് പോയിന്റുചെയ്യാം.ഇതിനെ "interior mutability" എന്ന് വിളിക്കുന്നു.
///
/// `Cell<T>`, `RefCell<T>` എന്നിവ പോലുള്ള ആന്തരിക മ്യൂട്ടബിലിറ്റി അനുവദിക്കുന്ന മറ്റെല്ലാ തരങ്ങളും അവരുടെ ഡാറ്റ പൊതിയാൻ ആന്തരികമായി `UnsafeCell` ഉപയോഗിക്കുന്നു.
///
/// പങ്കിട്ട റഫറൻസുകളുടെ മാറ്റമില്ലാത്ത ഗ്യാരണ്ടി മാത്രമേ `UnsafeCell` ബാധിക്കുകയുള്ളൂ എന്നത് ശ്രദ്ധിക്കുക.മ്യൂട്ടബിൾ റഫറൻസുകളുടെ അദ്വിതീയ ഗ്യാരണ്ടി ബാധിക്കില്ല.എക്സ് 00 എക്സ് എന്ന അപരനാമം ലഭിക്കുന്നതിന് * നിയമപരമായ മാർഗമില്ല.
///
/// `UnsafeCell` API തന്നെ സാങ്കേതികമായി വളരെ ലളിതമാണ്: [`.get()`] അതിന്റെ ഉള്ളടക്കങ്ങളിലേക്ക് ഒരു അസംസ്കൃത പോയിന്റർ `*mut T` നിങ്ങൾക്ക് നൽകുന്നു.ആ റോ പോയിന്റർ ശരിയായി ഉപയോഗിക്കുന്നതിന് അമൂർത്ത ഡിസൈനർ എന്ന നിലയിൽ _you_ വരെയാണ്.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// കൃത്യമായ Rust അപരനാമ നിയമങ്ങൾ‌ഒരു പരിധിവരെ ഫ്ലക്സിലാണ്, പക്ഷേ പ്രധാന പോയിന്റുകൾ‌വിവാദപരമല്ല:
///
/// - സുരക്ഷിത കോഡ് ഉപയോഗിച്ച് ആക്സസ് ചെയ്യാവുന്ന (ഉദാഹരണത്തിന്, നിങ്ങൾ അത് മടക്കിനൽകിയതിനാൽ) ആജീവനാന്ത `'a` (ഒരു `&T` അല്ലെങ്കിൽ `&mut T` റഫറൻസ്) ഉപയോഗിച്ച് നിങ്ങൾ ഒരു സുരക്ഷിത റഫറൻസ് സൃഷ്ടിക്കുകയാണെങ്കിൽ, ശേഷിക്കുന്ന ആ റഫറൻസിന് വിരുദ്ധമായ രീതിയിൽ നിങ്ങൾ ഡാറ്റ ആക്സസ് ചെയ്യരുത്. `'a` ന്റെ.
/// ഉദാഹരണത്തിന്, നിങ്ങൾ ഒരു `UnsafeCell<T>`-ൽ നിന്ന് `*mut T` എടുത്ത് ഒരു `&T`-ലേക്ക് കാസ്റ്റുചെയ്യുകയാണെങ്കിൽ, `T`-ലെ ഡാറ്റ മാറ്റമില്ലാതെ തുടരണം (`T`-ൽ കണ്ടെത്തിയ ഏതെങ്കിലും `UnsafeCell` ഡാറ്റ മൊഡ്യൂളോ, തീർച്ചയായും) ആ റഫറൻസിന്റെ ആയുസ്സ് അവസാനിക്കുന്നതുവരെ.
/// അതുപോലെ, നിങ്ങൾ സുരക്ഷിത കോഡിലേക്ക് റിലീസ് ചെയ്യുന്ന ഒരു `&mut T` റഫറൻസ് സൃഷ്ടിക്കുകയാണെങ്കിൽ, ആ റഫറൻസ് കാലഹരണപ്പെടുന്നതുവരെ നിങ്ങൾ `UnsafeCell`-നുള്ളിലെ ഡാറ്റ ആക്സസ് ചെയ്യരുത്.
///
/// - എല്ലായ്പ്പോഴും, നിങ്ങൾ ഡാറ്റ റേസുകൾ ഒഴിവാക്കണം.ഒന്നിലധികം ത്രെഡുകൾക്ക് ഒരേ `UnsafeCell`-ലേക്ക് ആക്സസ് ഉണ്ടെങ്കിൽ, മറ്റെല്ലാ ആക്സസുകളുമായും (അല്ലെങ്കിൽ ആറ്റമിക്സ് ഉപയോഗിക്കുക) ബന്ധപ്പെടുന്നതിന് മുമ്പ് ഏതൊരു റൈറ്റിനും ശരിയായ സംഭവമുണ്ടായിരിക്കണം.
///
/// ശരിയായ രൂപകൽപ്പനയെ സഹായിക്കുന്നതിന്, സിംഗിൾ-ത്രെഡ് കോഡിനായി ഇനിപ്പറയുന്ന സാഹചര്യങ്ങൾ നിയമപരമായി വ്യക്തമായി പ്രഖ്യാപിക്കുന്നു:
///
/// 1. ഒരു `&T` റഫറൻസ് സുരക്ഷിത കോഡിലേക്ക് റിലീസ് ചെയ്യാൻ കഴിയും, അവിടെ അത് മറ്റ് `&T` റഫറൻസുകളുമായി സഹവസിക്കാൻ കഴിയും, പക്ഷേ ഒരു `&mut T` ഉപയോഗിച്ച് അല്ല
///
/// 2. മറ്റ് `&mut T` അല്ലെങ്കിൽ `&T` എന്നിവ സഹവർത്തിക്കുന്നില്ലെങ്കിൽ സുരക്ഷിത കോഡിലേക്ക് ഒരു `&mut T` റഫറൻസ് റിലീസ് ചെയ്യാം.ഒരു `&mut T` എല്ലായ്പ്പോഴും അദ്വിതീയമായിരിക്കണം.
///
/// ഒരു `&UnsafeCell<T>`-ന്റെ ഉള്ളടക്കങ്ങൾ പരിവർത്തനം ചെയ്യുമ്പോൾ (സെല്ലിന്റെ അപരനാമം മറ്റ് `&UnsafeCell<T>` റഫറൻസുകൾ പോലും) ശരിയാണെന്നത് ശ്രദ്ധിക്കുക (മുകളിലുള്ള മാറ്റങ്ങളെ നിങ്ങൾ മറ്റേതെങ്കിലും രീതിയിൽ നടപ്പിലാക്കുകയാണെങ്കിൽ), ഒന്നിലധികം `&mut UnsafeCell<T>` അപരനാമങ്ങൾ ഉണ്ടായിരിക്കേണ്ടത് ഇപ്പോഴും നിർവചിക്കപ്പെട്ടിട്ടില്ല.
/// അതായത്, `&UnsafeCell<_>` റഫറൻസിലൂടെ _shared_ accesses (_i.e._-മായി ഒരു പ്രത്യേക ആശയവിനിമയം നടത്താൻ രൂപകൽപ്പന ചെയ്ത ഒരു റാപ്പറാണ് `UnsafeCell`);_exclusive_ accesses (_e.g._, `&mut UnsafeCell<_>` വഴി ഇടപെടുമ്പോൾ യാതൊരു ജാലവിദ്യയും ഇല്ല): ആ `&mut` വായ്പയുടെ കാലാവധിക്കായി സെല്ലോ പൊതിഞ്ഞ മൂല്യമോ അപരനാമമാകില്ല.
///
/// ഇത് [`.get_mut()`] ആക്സസ്സർ പ്രദർശിപ്പിച്ചിരിക്കുന്നു, ഇത് X002 ലഭിക്കുന്ന _safe_ getter ആണ്.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// സെല്ലിനെ അപരനാമമാക്കി ഒന്നിലധികം റഫറൻസുകൾ ഉണ്ടായിരുന്നിട്ടും ഒരു `UnsafeCell<_>`-ന്റെ ഉള്ളടക്കങ്ങൾ എങ്ങനെ പരിവർത്തനം ചെയ്യാമെന്ന് കാണിക്കുന്ന ഒരു ഉദാഹരണം ഇതാ:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // ഒരേ `x`-ലേക്ക് ഒന്നിലധികം/ഒരേസമയം/പങ്കിട്ട റഫറൻസുകൾ നേടുക.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // സുരക്ഷ: ഈ പരിധിക്കുള്ളിൽ `x` ന്റെ ഉള്ളടക്കത്തെക്കുറിച്ച് മറ്റ് പരാമർശങ്ങളൊന്നുമില്ല,
///     // അതിനാൽ നമ്മുടേത് ഫലപ്രദമായി അദ്വിതീയമാണ്.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- കടം വാങ്ങുക-+
///     *p1_exclusive += 27; // |
/// } // <---------- ഈ പോയിന്റിനപ്പുറം പോകാൻ കഴിയില്ല -------------------+
///
/// unsafe {
///     // സുരക്ഷ: ഈ പരിധിക്കുള്ളിൽ `x` ന്റെ ഉള്ളടക്കങ്ങളിലേക്ക് എക്‌സ്‌ക്ലൂസീവ് ആക്‌സസ് ഉണ്ടെന്ന് ആരും പ്രതീക്ഷിക്കുന്നില്ല,
///     // അതിനാൽ ഒരേസമയം ഒന്നിലധികം പങ്കിട്ട ആക്‌സസ്സുകൾ ഞങ്ങൾക്ക് നേടാനാകും.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// ഒരു എക്സ് 01 എക്സിലേക്കുള്ള എക്സ്ക്ലൂസീവ് ആക്സസ് അതിന്റെ എക്സ് 00 എക്സിലേക്കുള്ള എക്സ്ക്ലൂസീവ് ആക്സസ് സൂചിപ്പിക്കുന്നു എന്ന വസ്തുത ഇനിപ്പറയുന്ന ഉദാഹരണം കാണിക്കുന്നു:
///
/// ```rust
/// #![forbid(unsafe_code)] // എക്സ്ക്ലൂസീവ് ആക്സസ് ഉപയോഗിച്ച്,
///                         // `UnsafeCell` സുതാര്യമായ നോ-ഒപ്പ് റാപ്പർ ആണ്, അതിനാൽ ഇവിടെ `unsafe` ആവശ്യമില്ല.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // `x`-ലേക്ക് ഒരു കംപൈൽ-സമയം പരിശോധിച്ച അദ്വിതീയ റഫറൻസ് നേടുക.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // ഒരു എക്സ്ക്ലൂസീവ് റഫറൻസ് ഉപയോഗിച്ച്, ഞങ്ങൾക്ക് ഉള്ളടക്കങ്ങൾ സ mut ജന്യമായി പരിവർത്തനം ചെയ്യാൻ കഴിയും.
/// *p_unique.get_mut() = 0;
/// // അല്ലെങ്കിൽ, തുല്യമായി:
/// x = UnsafeCell::new(0);
///
/// // ഞങ്ങൾക്ക് മൂല്യം സ്വന്തമാകുമ്പോൾ, സ .ജന്യമായി ഉള്ളടക്കങ്ങൾ എക്‌സ്‌ട്രാക്റ്റുചെയ്യാനാകും.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// നിർദ്ദിഷ്ട മൂല്യത്തെ പൊതിയുന്ന `UnsafeCell`-ന്റെ ഒരു പുതിയ ഉദാഹരണം നിർമ്മിക്കുന്നു.
    ///
    ///
    /// രീതികളിലൂടെ ആന്തരിക മൂല്യത്തിലേക്കുള്ള എല്ലാ ആക്‌സസ്സും `unsafe` ആണ്.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// മൂല്യം അൺ‌റാപ്പ് ചെയ്യുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// പൊതിഞ്ഞ മൂല്യത്തിലേക്ക് ഒരു മ്യൂട്ടബിൾ പോയിന്റർ നേടുന്നു.
    ///
    /// ഇത് ഏത് തരത്തിലുള്ള പോയിന്ററിലേക്കും കാസ്റ്റുചെയ്യാം.
    /// `&mut T`-ലേക്ക് കാസ്റ്റുചെയ്യുമ്പോൾ ആക്‌സസ്സ് അദ്വിതീയമാണെന്ന് ഉറപ്പുവരുത്തുക (സജീവ റഫറൻസുകളില്ല, പരിവർത്തനം ചെയ്യാനാകില്ല അല്ലെങ്കിൽ ഇല്ല), ഒപ്പം `&T`-ലേക്ക് കാസ്റ്റുചെയ്യുമ്പോൾ മ്യൂട്ടേഷനുകളോ മ്യൂട്ടബിൾ അപരനാമങ്ങളോ നടക്കുന്നില്ലെന്ന് ഉറപ്പാക്കുക.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // #[repr(transparent)] കാരണം നമുക്ക് പോയിന്റർ `UnsafeCell<T>` മുതൽ `T` വരെ കാസ്റ്റുചെയ്യാനാകും.
        // ഇത് libstd-ന്റെ പ്രത്യേക നില പ്രയോജനപ്പെടുത്തുന്നു, ഇത് കംപൈലറിന്റെ future പതിപ്പുകളിൽ പ്രവർത്തിക്കുമെന്ന് ഉപയോക്തൃ കോഡിന് യാതൊരു ഉറപ്പുമില്ല!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// അടിസ്ഥാന ഡാറ്റയിലേക്ക് ഒരു മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു.
    ///
    /// ഈ കോൾ `UnsafeCell` പരസ്പരം കടമെടുക്കുന്നു (കംപൈൽ സമയത്ത്) ഞങ്ങൾക്ക് ഏക റഫറൻസ് ഉണ്ടെന്ന് ഉറപ്പുനൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// പൊതിഞ്ഞ മൂല്യത്തിലേക്ക് ഒരു മ്യൂട്ടബിൾ പോയിന്റർ നേടുന്നു.
    /// [`get`]-ലേക്കുള്ള വ്യത്യാസം, ഈ ഫംഗ്ഷൻ ഒരു റോ പോയിന്റർ സ്വീകരിക്കുന്നു എന്നതാണ്, ഇത് താൽക്കാലിക റഫറൻസുകൾ സൃഷ്ടിക്കുന്നത് ഒഴിവാക്കാൻ ഉപയോഗപ്രദമാണ്.
    ///
    /// ഫലം ഏതെങ്കിലും തരത്തിലുള്ള ഒരു പോയിന്ററിലേക്ക് കാസ്റ്റുചെയ്യാനാകും.
    /// `&mut T`-ലേക്ക് കാസ്റ്റുചെയ്യുമ്പോൾ ആക്‌സസ്സ് അദ്വിതീയമാണെന്ന് ഉറപ്പുവരുത്തുക (സജീവ റഫറൻസുകളില്ല, പരിവർത്തനം ചെയ്യാനാകില്ല അല്ലെങ്കിൽ ഇല്ല), ഒപ്പം `&T`-ലേക്ക് കാസ്റ്റുചെയ്യുമ്പോൾ മ്യൂട്ടേഷനുകളോ മ്യൂട്ടബിൾ അപരനാമങ്ങളോ നടക്കുന്നില്ലെന്ന് ഉറപ്പാക്കുക.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// `UnsafeCell` ക്രമേണ സമാരംഭിക്കുന്നതിന് `raw_get` ആവശ്യമാണ്, കാരണം `get` വിളിക്കുന്നത് ആരംഭിക്കാത്ത ഡാറ്റയിലേക്ക് ഒരു റഫറൻസ് സൃഷ്ടിക്കേണ്ടതുണ്ട്:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // #[repr(transparent)] കാരണം നമുക്ക് പോയിന്റർ `UnsafeCell<T>` മുതൽ `T` വരെ കാസ്റ്റുചെയ്യാനാകും.
        // ഇത് libstd-ന്റെ പ്രത്യേക നില പ്രയോജനപ്പെടുത്തുന്നു, ഇത് കംപൈലറിന്റെ future പതിപ്പുകളിൽ പ്രവർത്തിക്കുമെന്ന് ഉപയോക്തൃ കോഡിന് യാതൊരു ഉറപ്പുമില്ല!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// ടി യ്ക്കുള്ള എക്സ് 01 എക്സ് മൂല്യം ഉപയോഗിച്ച് ഒരു എക്സ് 00 എക്സ് സൃഷ്ടിക്കുന്നു.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}