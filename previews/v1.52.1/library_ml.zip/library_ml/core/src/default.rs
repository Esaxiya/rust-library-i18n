//! അർത്ഥവത്തായ സ്ഥിരസ്ഥിതി മൂല്യങ്ങളുള്ള തരങ്ങൾക്കായുള്ള `Default` trait.

#![stable(feature = "rust1", since = "1.0.0")]

/// ഒരു തരത്തിന് ഉപയോഗപ്രദമായ സ്ഥിര മൂല്യം നൽകുന്നതിനുള്ള trait.
///
/// ചില സമയങ്ങളിൽ, നിങ്ങൾ ഒരുതരം സ്ഥിരസ്ഥിതി മൂല്യത്തിലേക്ക് മടങ്ങാൻ ആഗ്രഹിക്കുന്നു, പ്രത്യേകിച്ചും അത് എന്താണെന്ന് ശ്രദ്ധിക്കരുത്.
/// ഒരു കൂട്ടം ഓപ്ഷനുകൾ നിർവചിക്കുന്ന `സ്ട്രക്റ്റ്`സുമായി ഇത് പലപ്പോഴും വരുന്നു:
///
/// ```
/// # #[allow(dead_code)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
/// ചില സ്ഥിരസ്ഥിതി മൂല്യങ്ങൾ എങ്ങനെ നിർവചിക്കാം?നിങ്ങൾക്ക് `Default` ഉപയോഗിക്കാം:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
///
/// fn main() {
///     let options: SomeOptions = Default::default();
/// }
/// ```
///
/// ഇപ്പോൾ, നിങ്ങൾക്ക് സ്ഥിരസ്ഥിതി മൂല്യങ്ങളെല്ലാം ലഭിക്കും.Rust വിവിധ പ്രൈമിറ്റീവ് തരങ്ങൾക്കായി `Default` നടപ്പിലാക്കുന്നു.
///
/// നിങ്ങൾക്ക് ഒരു പ്രത്യേക ഓപ്ഷൻ അസാധുവാക്കണമെങ്കിൽ, പക്ഷേ മറ്റ് സ്ഥിരസ്ഥിതികൾ നിലനിർത്തുക:
///
/// ```
/// # #[allow(dead_code)]
/// # #[derive(Default)]
/// # struct SomeOptions {
/// #     foo: i32,
/// #     bar: f32,
/// # }
/// fn main() {
///     let options = SomeOptions { foo: 42, ..Default::default() };
/// }
/// ```
///
/// ## Derivable
///
/// എല്ലാ തരത്തിലുള്ള ഫീൽഡുകളും `Default` നടപ്പിലാക്കുകയാണെങ്കിൽ ഈ trait `#[derive]` ഉപയോഗിച്ച് ഉപയോഗിക്കാൻ കഴിയും.
/// `ഡെറിവ്` ചെയ്യുമ്പോൾ, അത് ഓരോ ഫീൽഡിന്റെ തരത്തിനും സ്ഥിര മൂല്യം ഉപയോഗിക്കും.
///
/// ## എനിക്ക് എങ്ങനെ `Default` നടപ്പിലാക്കാൻ കഴിയും?
///
/// നിങ്ങളുടെ തരത്തിന്റെ മൂല്യം സ്ഥിരസ്ഥിതിയായി നൽകുന്ന `default()` രീതിക്കായി ഒരു നടപ്പാക്കൽ നൽകുക:
///
///
/// ```
/// # #![allow(dead_code)]
/// enum Kind {
///     A,
///     B,
///     C,
/// }
///
/// impl Default for Kind {
///     fn default() -> Self { Kind::A }
/// }
/// ```
///
/// # Examples
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Default)]
/// struct SomeOptions {
///     foo: i32,
///     bar: f32,
/// }
/// ```
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Default")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Default: Sized {
    /// ഒരു തരത്തിനായി "default value" നൽകുന്നു.
    ///
    /// സ്ഥിരസ്ഥിതി മൂല്യങ്ങൾ പലപ്പോഴും ഒരുതരം പ്രാരംഭ മൂല്യം, ഐഡന്റിറ്റി മൂല്യം അല്ലെങ്കിൽ സ്ഥിരസ്ഥിതിയായി അർത്ഥമാക്കുന്ന മറ്റെന്തെങ്കിലും എന്നിവയാണ്.
    ///
    ///
    /// # Examples
    ///
    /// അന്തർനിർമ്മിത സ്ഥിരസ്ഥിതി മൂല്യങ്ങൾ ഉപയോഗിക്കുന്നു:
    ///
    /// ```
    /// let i: i8 = Default::default();
    /// let (x, y): (Option<String>, f64) = Default::default();
    /// let (a, b, (c, d)): (i32, u32, (bool, bool)) = Default::default();
    /// ```
    ///
    /// നിങ്ങളുടേതാക്കുന്നു:
    ///
    /// ```
    /// # #[allow(dead_code)]
    /// enum Kind {
    ///     A,
    ///     B,
    ///     C,
    /// }
    ///
    /// impl Default for Kind {
    ///     fn default() -> Self { Kind::A }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn default() -> Self;
}

/// `Default` trait അനുസരിച്ച് ഒരു തരത്തിന്റെ സ്ഥിര മൂല്യം നൽകുക.
///
/// മടങ്ങേണ്ട തരം സന്ദർഭത്തിൽ നിന്ന് അനുമാനിക്കുന്നു;ഇത് `Default::default()` ന് തുല്യമാണ്, പക്ഷേ ടൈപ്പുചെയ്യാൻ ചെറുതാണ്.
///
/// ഉദാഹരണത്തിന്:
///
/// ```
/// #![feature(default_free_fn)]
///
/// use std::default::default;
///
/// #[derive(Default)]
/// struct AppConfig {
///     foo: FooConfig,
///     bar: BarConfig,
/// }
///
/// #[derive(Default)]
/// struct FooConfig {
///     foo: i32,
/// }
///
/// #[derive(Default)]
/// struct BarConfig {
///     bar: f32,
///     baz: u8,
/// }
///
/// fn main() {
///     let options = AppConfig {
///         foo: default(),
///         bar: BarConfig {
///             bar: 10.1,
///             ..default()
///         },
///     };
/// }
/// ```
#[unstable(feature = "default_free_fn", issue = "73014")]
#[inline]
pub fn default<T: Default>() -> T {
    Default::default()
}

/// trait `Default`-ന്റെ ഒരു impl സൃഷ്ടിക്കുന്ന മാക്രോ ഡെറിവ് ചെയ്യുക.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Default($item:item) {
    /* compiler built-in */
}

macro_rules! default_impl {
    ($t:ty, $v:expr, $doc:tt) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Default for $t {
            #[inline]
            #[doc = $doc]
            fn default() -> $t {
                $v
            }
        }
    };
}

default_impl! { (), (), "Returns the default value of `()`" }
default_impl! { bool, false, "Returns the default value of `false`" }
default_impl! { char, '\x00', "Returns the default value of `\\x00`" }

default_impl! { usize, 0, "Returns the default value of `0`" }
default_impl! { u8, 0, "Returns the default value of `0`" }
default_impl! { u16, 0, "Returns the default value of `0`" }
default_impl! { u32, 0, "Returns the default value of `0`" }
default_impl! { u64, 0, "Returns the default value of `0`" }
default_impl! { u128, 0, "Returns the default value of `0`" }

default_impl! { isize, 0, "Returns the default value of `0`" }
default_impl! { i8, 0, "Returns the default value of `0`" }
default_impl! { i16, 0, "Returns the default value of `0`" }
default_impl! { i32, 0, "Returns the default value of `0`" }
default_impl! { i64, 0, "Returns the default value of `0`" }
default_impl! { i128, 0, "Returns the default value of `0`" }

default_impl! { f32, 0.0f32, "Returns the default value of `0.0`" }
default_impl! { f64, 0.0f64, "Returns the default value of `0.0`" }