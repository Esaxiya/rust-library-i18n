use crate::fmt;

/// ഓരോ ആവർത്തനവും നൽകിയ ക്ലോസറിനെ `F: FnMut() -> Option<T>` എന്ന് വിളിക്കുന്ന ഒരു പുതിയ ഇറ്ററേറ്റർ സൃഷ്ടിക്കുന്നു.
///
/// ഒരു സമർപ്പിത തരം സൃഷ്ടിക്കുന്നതിനും അതിനായി [`Iterator`] trait നടപ്പിലാക്കുന്നതിനും കൂടുതൽ വെർബോസ് വാക്യഘടന ഉപയോഗിക്കാതെ ഏത് സ്വഭാവത്തിലും ഒരു ഇച്ഛാനുസൃത ഇറ്ററേറ്റർ സൃഷ്ടിക്കാൻ ഇത് അനുവദിക്കുന്നു.
///
/// `FromFn` ഇറ്ററേറ്റർ അടയ്‌ക്കലിന്റെ സ്വഭാവത്തെക്കുറിച്ച് അനുമാനങ്ങൾ നൽകുന്നില്ല, അതിനാൽ യാഥാസ്ഥിതികമായി [`FusedIterator`] നടപ്പിലാക്കുകയോ [`Iterator::size_hint()`] അതിന്റെ സ്ഥിരസ്ഥിതി `(0, None)`-ൽ നിന്ന് അസാധുവാക്കുകയോ ചെയ്യുന്നു.
///
///
/// ആവർത്തനങ്ങളിലുടനീളം അവസ്ഥ ട്രാക്കുചെയ്യുന്നതിന് അടയ്‌ക്കുന്നതിന് ക്യാപ്‌ചറുകളും അതിന്റെ പരിസ്ഥിതിയും ഉപയോഗിക്കാം.ഇറ്ററേറ്റർ എങ്ങനെ ഉപയോഗിക്കുന്നു എന്നതിനെ ആശ്രയിച്ച്, ഇതിന് അടയ്‌ക്കുന്നതിൽ [`move`] കീവേഡ് വ്യക്തമാക്കേണ്ടതുണ്ട്.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// [module-level documentation]-ൽ നിന്ന് ക counter ണ്ടർ ഇറ്ററേറ്റർ വീണ്ടും നടപ്പിലാക്കാം:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // ഞങ്ങളുടെ എണ്ണം വർദ്ധിപ്പിക്കുക.ഇതിനാലാണ് ഞങ്ങൾ പൂജ്യത്തിൽ ആരംഭിച്ചത്.
///     count += 1;
///
///     // ഞങ്ങൾ എണ്ണുന്നത് പൂർത്തിയാക്കിയിട്ടുണ്ടോ ഇല്ലയോ എന്ന് പരിശോധിക്കുക.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// ഓരോ ആവർത്തനവും നൽകിയ ക്ലോസറിനെ `F: FnMut() -> Option<T>` എന്ന് വിളിക്കുന്ന ഒരു ആവർത്തനം.
///
/// ഈ `struct` സൃഷ്ടിച്ചത് [`iter::from_fn()`] ഫംഗ്ഷനാണ്.
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}