use crate::{fmt, iter::FusedIterator};

/// മുമ്പത്തെ ഒരെണ്ണം അടിസ്ഥാനമാക്കി തുടർച്ചയായ ഓരോ ഇനങ്ങളും കണക്കാക്കുന്ന ഒരു പുതിയ ഇറ്ററേറ്റർ സൃഷ്ടിക്കുന്നു.
///
/// ആവർത്തനം നൽകിയ ആദ്യ ഇനത്തിൽ (എന്തെങ്കിലും ഉണ്ടെങ്കിൽ) ആരംഭിച്ച് ഓരോ ഇനത്തിന്റെയും പിൻഗാമിയെ കണക്കാക്കാൻ തന്നിരിക്കുന്ന `FnMut(&T) -> Option<T>` അടയ്ക്കൽ വിളിക്കുന്നു.
///
///
/// ```
/// use std::iter::successors;
///
/// let powers_of_10 = successors(Some(1_u16), |n| n.checked_mul(10));
/// assert_eq!(powers_of_10.collect::<Vec<_>>(), &[1, 10, 100, 1_000, 10_000]);
/// ```
#[stable(feature = "iter_successors", since = "1.34.0")]
pub fn successors<T, F>(first: Option<T>, succ: F) -> Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    // ഈ ഫംഗ്ഷൻ `impl Iterator<Item=T>` മടക്കിനൽകിയാൽ അത് `unfold` അടിസ്ഥാനമാക്കിയുള്ളതാകാം, മാത്രമല്ല ഒരു പ്രത്യേക തരം ആവശ്യമില്ല.
    //
    // എന്നിരുന്നാലും `T` ഉം `F` ഉം ആയിരിക്കുമ്പോൾ `Successors<T, F>` തരം ഉള്ളത് `Clone` ആകാൻ അനുവദിക്കുന്നു.
    Successors { next: first, succ }
}

/// മുമ്പത്തെ ഒരെണ്ണം അടിസ്ഥാനമാക്കി തുടർച്ചയായ ഓരോ ഇനങ്ങളും കണക്കാക്കുന്ന ഒരു പുതിയ ഇറ്ററേറ്റർ.
///
/// ഈ `struct` സൃഷ്ടിച്ചത് [`iter::successors()`] ഫംഗ്ഷനാണ്.
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// [`iter::successors()`]: successors
#[derive(Clone)]
#[stable(feature = "iter_successors", since = "1.34.0")]
pub struct Successors<T, F> {
    next: Option<T>,
    succ: F,
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> Iterator for Successors<T, F>
where
    F: FnMut(&T) -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        let item = self.next.take()?;
        self.next = (self.succ)(&item);
        Some(item)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.next.is_some() { (1, None) } else { (0, Some(0)) }
    }
}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T, F> FusedIterator for Successors<T, F> where F: FnMut(&T) -> Option<T> {}

#[stable(feature = "iter_successors", since = "1.34.0")]
impl<T: fmt::Debug, F> fmt::Debug for Successors<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Successors").field("next", &self.next).finish()
    }
}