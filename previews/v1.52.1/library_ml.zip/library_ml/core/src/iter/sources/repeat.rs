use crate::iter::{FusedIterator, TrustedLen};

/// ഒരൊറ്റ ഘടകം അനന്തമായി ആവർത്തിക്കുന്ന ഒരു പുതിയ ഇറ്ററേറ്റർ സൃഷ്ടിക്കുന്നു.
///
/// `repeat()` ഫംഗ്ഷൻ ഒരൊറ്റ മൂല്യം വീണ്ടും വീണ്ടും ആവർത്തിക്കുന്നു.
///
/// `repeat()` പോലുള്ള അനന്തമായ ഇറ്ററേറ്ററുകൾ പരിമിതപ്പെടുത്തുന്നതിനായി [`Iterator::take()`] പോലുള്ള അഡാപ്റ്ററുകളിൽ പലപ്പോഴും ഉപയോഗിക്കുന്നു.
///
/// നിങ്ങൾക്ക് ആവശ്യമുള്ള ഇറ്ററേറ്ററിന്റെ എലമെന്റ് തരം `Clone` നടപ്പിലാക്കുന്നില്ലെങ്കിലോ അല്ലെങ്കിൽ ആവർത്തിച്ചുള്ള ഘടകം മെമ്മറിയിൽ സൂക്ഷിക്കാൻ ആഗ്രഹിക്കുന്നില്ലെങ്കിലോ, പകരം നിങ്ങൾക്ക് [`repeat_with()`] ഫംഗ്ഷൻ ഉപയോഗിക്കാം.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// അടിസ്ഥാന ഉപയോഗം:
///
/// ```
/// use std::iter;
///
/// // നാലാം നമ്പർ 4 എവർ:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // അതെ, ഇപ്പോഴും നാല്
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// [`Iterator::take()`] ഉപയോഗിച്ച് പരിമിതപ്പെടുത്തുന്നു:
///
/// ```
/// use std::iter;
///
/// // അവസാനത്തെ ഉദാഹരണം വളരെയധികം ഫോറുകളായിരുന്നു.നമുക്ക് നാല് ഫോറുകൾ മാത്രമേ ഉണ്ടാകൂ.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... ഇപ്പോൾ ഞങ്ങൾ പൂർത്തിയാക്കി
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// ഒരു മൂലകം അനന്തമായി ആവർത്തിക്കുന്ന ഒരു ആവർത്തനം.
///
/// ഈ `struct` സൃഷ്ടിച്ചത് [`repeat()`] ഫംഗ്ഷനാണ്.കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}