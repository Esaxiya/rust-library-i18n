use crate::iter::{FusedIterator, TrustedLen};

/// നൽകിയ അടയ്‌ക്കൽ‌അഭ്യർ‌ത്ഥിച്ചുകൊണ്ട് കൃത്യമായി ഒരു തവണ അലസമായി ഒരു മൂല്യം സൃഷ്ടിക്കുന്ന ഒരു ഇറ്ററേറ്റർ‌സൃഷ്‌ടിക്കുന്നു.
///
/// ഒരൊറ്റ മൂല്യ ജനറേറ്ററിനെ മറ്റ് തരത്തിലുള്ള ആവർത്തനത്തിന്റെ [`chain()`]-ലേക്ക് പൊരുത്തപ്പെടുത്തുന്നതിന് ഇത് സാധാരണയായി ഉപയോഗിക്കുന്നു.
/// മിക്കവാറും എല്ലാം ഉൾക്കൊള്ളുന്ന ഒരു ഇറ്ററേറ്റർ നിങ്ങൾക്ക് ഉണ്ടായിരിക്കാം, പക്ഷേ നിങ്ങൾക്ക് ഒരു പ്രത്യേക പ്രത്യേക കേസ് ആവശ്യമാണ്.
/// ഒരുപക്ഷേ നിങ്ങൾക്ക് ഇറ്ററേറ്ററുകളിൽ പ്രവർത്തിക്കുന്ന ഒരു ഫംഗ്ഷൻ ഉണ്ടായിരിക്കാം, പക്ഷേ നിങ്ങൾ ഒരു മൂല്യം മാത്രമേ പ്രോസസ്സ് ചെയ്യാവൂ.
///
/// [`once()`]-ൽ നിന്ന് വ്യത്യസ്തമായി, ഈ ഫംഗ്ഷൻ അഭ്യർത്ഥനയുടെ അടിസ്ഥാനത്തിൽ അലസമായി മൂല്യം സൃഷ്ടിക്കും.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// അടിസ്ഥാന ഉപയോഗം:
///
/// ```
/// use std::iter;
///
/// // ഒന്ന് ഏകാന്ത സംഖ്യ
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // ഒന്ന്, ഞങ്ങൾക്ക് ലഭിക്കുന്നത് അത്രയേയുള്ളൂ
/// assert_eq!(None, one.next());
/// ```
///
/// മറ്റൊരു ഇറ്ററേറ്ററുമായി ചങ്ങലയ്ക്കുന്നു.
/// `.foo` ഡയറക്‌ടറിയുടെ ഓരോ ഫയലിലും ആവർത്തിക്കാൻ ഞങ്ങൾ ആഗ്രഹിക്കുന്നുവെന്ന് മാത്രമല്ല, ഒരു കോൺഫിഗറേഷൻ ഫയലും,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // ഞങ്ങൾ‌DirEntry-s ന്റെ ഒരു ഇറ്ററേറ്ററിൽ‌നിന്നും പാത്ത് ബഫുകളുടെ ഒരു ഇറ്ററേറ്ററിലേക്ക് പരിവർത്തനം ചെയ്യേണ്ടതുണ്ട്, അതിനാൽ‌ഞങ്ങൾ‌മാപ്പ് ഉപയോഗിക്കുന്നു
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // ഇപ്പോൾ, ഞങ്ങളുടെ കോൺഫിഗറേഷൻ ഫയലിനായി ഞങ്ങളുടെ ഇറ്ററേറ്റർ
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // രണ്ട് ആവർത്തനങ്ങളെ ഒന്നിച്ച് ഒരു വലിയ ആവർത്തനത്തിലേക്ക് ബന്ധിപ്പിക്കുക
/// let files = dirs.chain(config);
///
/// // ഇത് ഞങ്ങൾക്ക് .foo, .foorc എന്നിവയിലെ എല്ലാ ഫയലുകളും നൽകും
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// നൽകിയ ക്ലോഷർ `F: FnOnce() -> A` പ്രയോഗിച്ചുകൊണ്ട് `A` തരം ഒരൊറ്റ ഘടകം നൽകുന്ന ഒരു ആവർത്തനം.
///
///
/// ഈ `struct` സൃഷ്ടിച്ചത് [`once_with()`] ഫംഗ്ഷനാണ്.
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}