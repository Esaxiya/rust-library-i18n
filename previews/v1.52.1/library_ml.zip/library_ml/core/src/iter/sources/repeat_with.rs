use crate::iter::{FusedIterator, TrustedLen};

/// നൽകിയിരിക്കുന്ന അടയ്ക്കൽ, റിപ്പീറ്റർ, പ്രയോഗിച്ചുകൊണ്ട് `A` തരം ഘടകങ്ങൾ അനന്തമായി ആവർത്തിക്കുന്ന ഒരു പുതിയ ഇറ്ററേറ്റർ സൃഷ്ടിക്കുന്നു. `F: FnMut() -> A`.
///
/// `repeat_with()` ഫംഗ്ഷൻ റിപ്പീറ്ററിനെ വീണ്ടും വീണ്ടും വിളിക്കുന്നു.
///
/// `repeat_with()` പോലുള്ള അനന്തമായ ഇറ്ററേറ്ററുകൾ പരിമിതപ്പെടുത്തുന്നതിനായി [`Iterator::take()`] പോലുള്ള അഡാപ്റ്ററുകളിൽ പലപ്പോഴും ഉപയോഗിക്കുന്നു.
///
/// നിങ്ങൾക്ക് ആവശ്യമുള്ള ഇറ്ററേറ്ററിന്റെ എലമെന്റ് തരം [`Clone`] നടപ്പിലാക്കുകയും ഉറവിട ഘടകം മെമ്മറിയിൽ സൂക്ഷിക്കുകയും ചെയ്യുന്നത് ശരിയാണെങ്കിൽ, പകരം നിങ്ങൾ [`repeat()`] ഫംഗ്ഷൻ ഉപയോഗിക്കണം.
///
///
/// `repeat_with()` നിർമ്മിക്കുന്ന ഒരു ഇറ്ററേറ്റർ ഒരു [`DoubleEndedIterator`] അല്ല.
/// ഒരു [`DoubleEndedIterator`] മടക്കിനൽകാൻ നിങ്ങൾക്ക് `repeat_with()` ആവശ്യമുണ്ടെങ്കിൽ, നിങ്ങളുടെ ഉപയോഗ കേസ് വിശദീകരിക്കുന്ന ഒരു GitHub പ്രശ്നം തുറക്കുക.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// അടിസ്ഥാന ഉപയോഗം:
///
/// ```
/// use std::iter;
///
/// // `Clone` അല്ലാത്തതോ അല്ലെങ്കിൽ മെമ്മറിയിൽ വിലകൂടിയതിനാൽ ഇതുവരെയും മെമ്മറിയിൽ ആകാൻ ആഗ്രഹിക്കാത്തതോ ആയ ഒരു തരത്തിന്റെ ചില മൂല്യങ്ങൾ നമുക്കുണ്ടെന്ന് കരുതുക:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // ഒരു പ്രത്യേക മൂല്യം എന്നെന്നേക്കുമായി:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// മ്യൂട്ടേഷൻ ഉപയോഗിക്കുന്നതും പരിമിതപ്പെടുത്തുന്നതും:
///
/// ```rust
/// use std::iter;
///
/// // പൂജ്യത്തിൽ നിന്ന് മൂന്നാമത്തെ പവർ വരെ:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... ഇപ്പോൾ ഞങ്ങൾ പൂർത്തിയാക്കി
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// നൽകിയ ക്ലോഷർ `F: FnMut() -> A` പ്രയോഗിച്ചുകൊണ്ട് `A` തരം ഘടകങ്ങൾ അനന്തമായി ആവർത്തിക്കുന്ന ഒരു ഇറ്ററേറ്റർ.
///
///
/// ഈ `struct` സൃഷ്ടിച്ചത് [`repeat_with()`] ഫംഗ്ഷനാണ്.
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}