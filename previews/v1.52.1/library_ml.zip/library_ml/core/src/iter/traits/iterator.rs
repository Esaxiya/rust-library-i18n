// ign-tidy-filelength ഈ ഫയലിൽ എക്സ് എക്സ് എക്‌സിന്റെ നിർവചനം ഉൾക്കൊള്ളുന്നു.
// ഞങ്ങൾക്ക് അത് ഒന്നിലധികം ഫയലുകളായി വിഭജിക്കാൻ കഴിയില്ല.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// ഇറ്ററേറ്ററുകളുമായി ഇടപെടുന്നതിനുള്ള ഒരു ഇന്റർഫേസ്.
///
/// ഇതാണ് പ്രധാന ആവർത്തന trait.
/// ഇറ്ററേറ്ററുകളുടെ ആശയത്തെക്കുറിച്ച് കൂടുതലറിയാൻ, ദയവായി [module-level documentation] കാണുക.
/// പ്രത്യേകിച്ചും, [implement `Iterator`][impl] എങ്ങനെ ചെയ്യാമെന്ന് അറിയാൻ നിങ്ങൾ ആഗ്രഹിച്ചേക്കാം.
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// ആവർത്തിക്കുന്ന മൂലകങ്ങളുടെ തരം.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// ഇറ്ററേറ്റർ മുന്നേറുകയും അടുത്ത മൂല്യം നൽകുകയും ചെയ്യുന്നു.
    ///
    /// ആവർത്തനം പൂർത്തിയാകുമ്പോൾ [`None`] നൽകുന്നു.
    /// വ്യക്തിഗത ആവർത്തന നടപ്പാക്കലുകൾ ആവർത്തനം പുനരാരംഭിക്കാൻ തിരഞ്ഞെടുക്കാം, അതിനാൽ `next()`-നെ വീണ്ടും വിളിക്കുന്നത് ചില ഘട്ടങ്ങളിൽ [`Some(Item)`] തിരികെ നൽകാൻ ആരംഭിച്ചേക്കാം അല്ലെങ്കിൽ വരില്ല.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // next()-ലേക്കുള്ള ഒരു കോൾ അടുത്ത മൂല്യം നൽകുന്നു ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... എന്നിട്ട് ഒന്നും കഴിഞ്ഞാൽ ഒന്നുമില്ല.
    /// assert_eq!(None, iter.next());
    ///
    /// // കൂടുതൽ കോളുകൾ `None` നൽകാം അല്ലെങ്കിൽ നൽകില്ല.ഇവിടെ, അവർ എപ്പോഴും ചെയ്യും.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// ആവർത്തനത്തിന്റെ ശേഷിക്കുന്ന നീളത്തിന്റെ അതിരുകൾ നൽകുന്നു.
    ///
    /// പ്രത്യേകിച്ചും, എക്സ് 100 എക്സ് ഒരു ട്യൂപ്പിൾ നൽകുന്നു, അവിടെ ആദ്യ ഘടകം താഴ്ന്ന ബന്ധിതവും രണ്ടാമത്തെ ഘടകം മുകളിലെ ബന്ധിതവുമാണ്.
    ///
    /// മടക്കിനൽകുന്ന ട്യൂപ്പിളിന്റെ രണ്ടാം പകുതി ഒരു [`ഓപ്ഷൻ`]`<`[`ഉപയോഗപ്പെടുത്തുക]]`>` ആണ്.
    /// ഇവിടെ ഒരു [`None`] എന്നതിനർത്ഥം ഒന്നുകിൽ അറിയപ്പെടുന്ന അപ്പർ ബ bound ണ്ട് ഇല്ല, അല്ലെങ്കിൽ മുകളിലെ ബ X ണ്ട് [`usize`] നേക്കാൾ വലുതാണ്.
    ///
    /// # നടപ്പാക്കൽ കുറിപ്പുകൾ
    ///
    /// ഒരു ആവർത്തന നടപ്പാക്കൽ പ്രഖ്യാപിത ഘടകങ്ങളുടെ എണ്ണം നൽകുന്നുവെന്ന് ഇത് നടപ്പിലാക്കുന്നില്ല.ഒരു ബഗ്ഗി ഇറ്ററേറ്റർ താഴ്ന്ന പരിധിയേക്കാൾ കുറവോ മൂലകങ്ങളുടെ മുകളിലെ പരിധിയേക്കാൾ കൂടുതലോ നൽകാം.
    ///
    /// `size_hint()` ആവർത്തന ഘടകങ്ങളുടെ ഇടം റിസർവ് ചെയ്യുന്നത് പോലുള്ള ഒപ്റ്റിമൈസേഷനുകൾക്കായി പ്രാഥമികമായി ഉപയോഗിക്കാൻ ഉദ്ദേശിച്ചുള്ളതാണ്, പക്ഷേ ഉദാ. വിശ്വസനീയമായിരിക്കരുത്, സുരക്ഷിതമല്ലാത്ത കോഡിലെ പരിധി പരിശോധനകൾ ഒഴിവാക്കുക.
    /// `size_hint()` ന്റെ തെറ്റായ നടപ്പാക്കൽ മെമ്മറി സുരക്ഷാ ലംഘനങ്ങളിലേക്ക് നയിക്കരുത്.
    ///
    /// അതായത്, നടപ്പാക്കൽ ശരിയായ വിലയിരുത്തൽ നൽകണം, അല്ലാത്തപക്ഷം ഇത് trait ന്റെ പ്രോട്ടോക്കോളിന്റെ ലംഘനമായിരിക്കും.
    ///
    /// സ്ഥിരസ്ഥിതി നടപ്പിലാക്കൽ `(0,` [`ഒന്നുമില്ല`]`)`നൽകുന്നു, ഇത് ഏത് ആവർത്തനത്തിനും ശരിയാണ്.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// കൂടുതൽ സങ്കീർണ്ണമായ ഉദാഹരണം:
    ///
    /// ```
    /// // പൂജ്യം മുതൽ പത്ത് വരെയുള്ള ഇരട്ട സംഖ്യകൾ.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // ഞങ്ങൾ പൂജ്യത്തിൽ നിന്ന് പത്ത് തവണ ആവർത്തിക്കാം.
    /// // ഇത് അഞ്ച് ആണെന്ന് അറിയുന്നത് filter() എക്സിക്യൂട്ട് ചെയ്യാതെ സാധ്യമല്ല.
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // chain() ഉപയോഗിച്ച് അഞ്ച് നമ്പറുകൾ കൂടി ചേർക്കാം
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // ഇപ്പോൾ രണ്ട് അതിരുകളും അഞ്ചായി വർദ്ധിച്ചു
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// മുകളിലെ അതിർത്തിക്കായി `None` നൽകുന്നു:
    ///
    /// ```
    /// // അനന്തമായ ഇറ്ററേറ്ററിന് മുകളിലെ ബൗണ്ടും പരമാവധി ലോവർ ബൗണ്ടും ഇല്ല
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// ആവർത്തനത്തെ ഉപയോഗിക്കുന്നു, ആവർത്തനങ്ങളുടെ എണ്ണം കണക്കാക്കി അത് തിരികെ നൽകുന്നു.
    ///
    /// [`None`] നേരിടുന്നതുവരെ ഈ രീതി [`next`]-നെ ആവർത്തിച്ച് വിളിക്കും, ഇത് [`Some`] കണ്ടതിന്റെ എണ്ണം മടക്കിനൽകുന്നു.
    /// ഇറ്ററേറ്ററിന് ഘടകങ്ങളൊന്നുമില്ലെങ്കിലും [`next`] ഒരു തവണയെങ്കിലും വിളിക്കേണ്ടതുണ്ട്.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # ഓവർഫ്ലോ ബിഹേവിയർ
    ///
    /// ഈ രീതി ഓവർഫ്ലോകൾക്കെതിരെ കാവൽ നിൽക്കുന്നില്ല, അതിനാൽ [`usize::MAX`]-ൽ കൂടുതൽ ഘടകങ്ങളുള്ള ഒരു ഇറ്ററേറ്ററിന്റെ ഘടകങ്ങൾ എണ്ണുന്നത് തെറ്റായ ഫലം അല്ലെങ്കിൽ panics നൽകുന്നു.
    ///
    /// ഡീബഗ് അവകാശവാദങ്ങൾ പ്രാപ്തമാക്കിയിട്ടുണ്ടെങ്കിൽ, ഒരു panic ഉറപ്പുനൽകുന്നു.
    ///
    /// # Panics
    ///
    /// ആവർത്തനത്തിന് [`usize::MAX`]-ൽ കൂടുതൽ ഘടകങ്ങൾ ഉണ്ടെങ്കിൽ ഈ ഫംഗ്ഷൻ panic ആയിരിക്കാം.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// അവസാന ഘടകം മടക്കിനൽകുന്ന ഇറ്ററേറ്റർ ഉപയോഗിക്കുന്നു.
    ///
    /// [`None`] തിരികെ നൽകുന്നതുവരെ ഈ രീതി ആവർത്തനത്തെ വിലയിരുത്തും.
    /// അങ്ങനെ ചെയ്യുമ്പോൾ, അത് നിലവിലെ ഘടകത്തിന്റെ ട്രാക്ക് സൂക്ഷിക്കുന്നു.
    /// [`None`] മടക്കിനൽകിയ ശേഷം, `last()` അത് കണ്ട അവസാന ഘടകം തിരികെ നൽകും.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// `n` ഘടകങ്ങൾ ഉപയോഗിച്ച് ആവർത്തനത്തെ മുന്നോട്ട് നയിക്കുന്നു.
    ///
    /// [`None`] നേരിടുന്നതുവരെ [`next`] വരെ `n` വരെ വിളിച്ച് ഈ രീതി `n` ഘടകങ്ങളെ ആകാംക്ഷയോടെ ഒഴിവാക്കും.
    ///
    /// `advance_by(n)` `n` ഘടകങ്ങൾ വിജയകരമായി മുന്നേറുകയാണെങ്കിൽ [`Ok(())`][Ok], അല്ലെങ്കിൽ [`None`] നേരിട്ടാൽ [`Err(k)`][Err], ഇവിടെ `k` എന്നത് മൂലകങ്ങൾ തീരുന്നതിന് മുമ്പ് ആവർത്തനം വികസിപ്പിച്ച ഘടകങ്ങളുടെ എണ്ണമാണ് (അതായത്
    /// ആവർത്തനത്തിന്റെ നീളം).
    /// `k` എല്ലായ്പ്പോഴും `n` നേക്കാൾ കുറവാണെന്ന് ശ്രദ്ധിക്കുക.
    ///
    /// `advance_by(0)` എന്ന് വിളിക്കുന്നത് ഏതെങ്കിലും ഘടകങ്ങളെ ഉപയോഗിക്കുന്നില്ല, മാത്രമല്ല എല്ലായ്പ്പോഴും [`Ok(())`][Ok] നൽകുന്നു.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // `&4` മാത്രം ഒഴിവാക്കി
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// ഇറ്ററേറ്ററിന്റെ `n` മത്തെ ഘടകം നൽകുന്നു.
    ///
    /// മിക്ക ഇൻഡെക്സിംഗ് പ്രവർത്തനങ്ങളെയും പോലെ, എണ്ണം പൂജ്യത്തിൽ നിന്ന് ആരംഭിക്കുന്നു, അതിനാൽ `nth(0)` ആദ്യ മൂല്യം നൽകുന്നു, രണ്ടാമത്തേത് `nth(1)`, എന്നിങ്ങനെ.
    ///
    /// മുമ്പത്തെ എല്ലാ ഘടകങ്ങളും അതുപോലെ തന്നെ മടങ്ങിയ ഘടകവും ആവർത്തനത്തിൽ നിന്ന് ഉപയോഗിക്കും.
    /// അതിനർത്ഥം മുമ്പത്തെ ഘടകങ്ങൾ നിരസിക്കപ്പെടുമെന്നും ഒരേ ഇറ്ററേറ്ററിൽ `nth(0)` ഒന്നിലധികം തവണ വിളിക്കുന്നത് വ്യത്യസ്ത ഘടകങ്ങൾ നൽകുമെന്നും അർത്ഥമാക്കുന്നു.
    ///
    ///
    /// `nth()` `n` ആവർത്തനത്തിന്റെ നീളത്തേക്കാൾ വലുതോ തുല്യമോ ആണെങ്കിൽ [`None`] നൽകും.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// `nth()` നെ ഒന്നിലധികം തവണ വിളിക്കുന്നത് ആവർത്തനത്തെ റിവൈൻഡ് ചെയ്യുന്നില്ല:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// `n + 1`-ൽ താഴെ ഘടകങ്ങൾ ഉണ്ടെങ്കിൽ `None` നൽകുന്നു:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// ഒരേ പോയിന്റിൽ‌ആരംഭിക്കുന്ന ഒരു ഇറ്ററേറ്റർ‌സൃഷ്‌ടിക്കുന്നു, പക്ഷേ ഓരോ ആവർത്തനത്തിലും നൽകിയ തുകയനുസരിച്ച് ചുവടുവെക്കുന്നു.
    ///
    /// കുറിപ്പ് 1: നൽകിയിരിക്കുന്ന ഘട്ടം പരിഗണിക്കാതെ തന്നെ, ആവർത്തനത്തിന്റെ ആദ്യ ഘടകം എല്ലായ്പ്പോഴും മടക്കിനൽകും.
    ///
    /// കുറിപ്പ് 2: അവഗണിച്ച ഘടകങ്ങൾ വലിക്കുന്ന സമയം നിശ്ചയിച്ചിട്ടില്ല.
    /// `StepBy` `next(), nth(step-1), nth(step-1),…` സീക്വൻസ് പോലെ പ്രവർത്തിക്കുന്നു, പക്ഷേ സീക്വൻസ് പോലെ പെരുമാറാനും സ്വാതന്ത്ര്യമുണ്ട്
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// പ്രകടന കാരണങ്ങളാൽ ചില ഇറ്ററേറ്ററുകൾക്ക് ഏത് വഴിയാണ് ഉപയോഗിക്കേണ്ടത്.
    /// രണ്ടാമത്തെ വഴി നേരത്തെ ആവർത്തനത്തെ മുന്നോട്ട് നയിക്കുകയും കൂടുതൽ ഇനങ്ങൾ ഉപയോഗിക്കുകയും ചെയ്യാം.
    ///
    /// `advance_n_and_return_first` ഇതിന് തുല്യമാണ്:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// തന്നിരിക്കുന്ന ഘട്ടം `0` ആണെങ്കിൽ രീതി panic ആയിരിക്കും.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// രണ്ട് ഇറ്ററേറ്ററുകൾ എടുക്കുകയും രണ്ട് ശ്രേണിയിലും ഒരു പുതിയ ഇറ്ററേറ്റർ സൃഷ്ടിക്കുകയും ചെയ്യുന്നു.
    ///
    /// `chain()` ഒരു പുതിയ ഇറ്ററേറ്റർ തിരികെ നൽകും, അത് ആദ്യം ആദ്യത്തെ ഇറ്ററേറ്ററിൽ നിന്നുള്ള മൂല്യങ്ങളേയും രണ്ടാമത്തെ ഇറ്ററേറ്ററിൽ നിന്നുള്ള മൂല്യങ്ങളേയും ആവർത്തിക്കുന്നു.
    ///
    /// മറ്റൊരു വിധത്തിൽ പറഞ്ഞാൽ, ഇത് ഒരു ചെയിനിൽ രണ്ട് ഇറ്ററേറ്ററുകളെ പരസ്പരം ബന്ധിപ്പിക്കുന്നു.🔗
    ///
    /// [`once`] ഒരൊറ്റ മൂല്യത്തെ മറ്റ് തരത്തിലുള്ള ആവർത്തന ശൃംഖലയിലേക്ക് മാറ്റാൻ സാധാരണയായി ഉപയോഗിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `chain()` ലേക്കുള്ള ആർ‌ഗ്യുമെൻറ് [`IntoIterator`] ഉപയോഗിക്കുന്നതിനാൽ‌, ഒരു [`Iterator`] മാത്രമല്ല, [`Iterator`] ലേക്ക് പരിവർത്തനം ചെയ്യാൻ‌കഴിയുന്ന എന്തും നമുക്ക് കൈമാറാൻ‌കഴിയും.
    /// ഉദാഹരണത്തിന്, (`&[T]`) സ്ലൈസുകൾ [`IntoIterator`] നടപ്പിലാക്കുന്നു, അതിനാൽ നേരിട്ട് `chain()` ലേക്ക് കൈമാറാൻ കഴിയും:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// നിങ്ങൾ Windows API-യുമായി പ്രവർത്തിക്കുകയാണെങ്കിൽ, [`OsStr`]-നെ `Vec<u16>`-ലേക്ക് പരിവർത്തനം ചെയ്യാൻ നിങ്ങൾ ആഗ്രഹിച്ചേക്കാം:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// ജോഡികളുടെ ഒരൊറ്റ ആവർത്തനത്തിലേക്ക് രണ്ട് ഇറ്ററേറ്ററുകളെ 'സിപ്‌സ് അപ്പ്' ചെയ്യുക.
    ///
    /// `zip()` ഒരു പുതിയ ഇറ്ററേറ്റർ നൽകുന്നു, അത് മറ്റ് രണ്ട് ഇറ്ററേറ്ററുകളേക്കാൾ ആവർത്തിക്കുന്നു, ആദ്യ ഘടകം ആദ്യത്തെ ഇറ്ററേറ്ററിൽ നിന്ന് വരുന്ന ഒരു ട്യൂപ്പിൾ നൽകുന്നു, രണ്ടാമത്തെ ഘടകം രണ്ടാമത്തെ ഇറ്ററേറ്ററിൽ നിന്ന് വരുന്നു.
    ///
    ///
    /// മറ്റൊരു വിധത്തിൽ പറഞ്ഞാൽ, ഇത് രണ്ട് ഇറ്ററേറ്ററുകളെ ഒരുമിച്ച് ഒന്നിലേക്ക് സിപ്പ് ചെയ്യുന്നു.
    ///
    /// ഒന്നുകിൽ iterator [`None`] നൽകുന്നുവെങ്കിൽ, സിപ്പ് ചെയ്ത iterator ൽ നിന്നുള്ള [`next`] [`None`] നൽകും.
    /// ആദ്യ ഇറ്ററേറ്റർ [`None`] നൽകുന്നുവെങ്കിൽ, `zip` ഷോർട്ട് സർക്യൂട്ട് ചെയ്യും, രണ്ടാമത്തെ ഇറ്ററേറ്ററിൽ `next` വിളിക്കില്ല.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` ലേക്കുള്ള ആർ‌ഗ്യുമെൻറ് [`IntoIterator`] ഉപയോഗിക്കുന്നതിനാൽ‌, ഒരു [`Iterator`] മാത്രമല്ല, [`Iterator`] ലേക്ക് പരിവർത്തനം ചെയ്യാൻ‌കഴിയുന്ന എന്തും നമുക്ക് കൈമാറാൻ‌കഴിയും.
    /// ഉദാഹരണത്തിന്, (`&[T]`) സ്ലൈസുകൾ [`IntoIterator`] നടപ്പിലാക്കുന്നു, അതിനാൽ നേരിട്ട് `zip()` ലേക്ക് കൈമാറാൻ കഴിയും:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` പലപ്പോഴും അനന്തമായ ഒരു ആവർത്തനത്തെ പരിമിതത്തിലേക്ക് സിപ്പ് ചെയ്യാൻ ഉപയോഗിക്കുന്നു.
    /// ഇത് പ്രവർത്തിക്കുന്നു, കാരണം പരിമിത ഇറ്ററേറ്റർ ക്രമേണ [`None`] നൽകുന്നു, സിപ്പർ അവസാനിക്കും.`(0..)` ഉപയോഗിച്ച് സിപ്പ് ചെയ്യുന്നത് [`enumerate`] പോലെ കാണാനാകും:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// ഒറിജിനൽ ഇറ്ററേറ്ററിന്റെ അടുത്തുള്ള ഇനങ്ങൾക്കിടയിൽ `separator`-ന്റെ ഒരു പകർപ്പ് സ്ഥാപിക്കുന്ന ഒരു പുതിയ ഇറ്ററേറ്റർ സൃഷ്‌ടിക്കുന്നു.
    ///
    /// `separator` [`Clone`] നടപ്പിലാക്കുന്നില്ലെങ്കിലോ എല്ലാ സമയത്തും കണക്കുകൂട്ടേണ്ടതുണ്ടെങ്കിലോ, [`intersperse_with`] ഉപയോഗിക്കുക.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // `a`-ൽ നിന്നുള്ള ആദ്യ ഘടകം.
    /// assert_eq!(a.next(), Some(&100)); // സെപ്പറേറ്റർ.
    /// assert_eq!(a.next(), Some(&1));   // `a`-ൽ നിന്നുള്ള അടുത്ത ഘടകം.
    /// assert_eq!(a.next(), Some(&100)); // സെപ്പറേറ്റർ.
    /// assert_eq!(a.next(), Some(&2));   // `a`-ൽ നിന്നുള്ള അവസാന ഘടകം.
    /// assert_eq!(a.next(), None);       // ഇറ്ററേറ്റർ പൂർത്തിയായി.
    /// ```
    ///
    /// `intersperse` ഒരു പൊതു ഘടകം ഉപയോഗിച്ച് ഒരു ആവർത്തന ഇനത്തിൽ ചേരാൻ വളരെ ഉപയോഗപ്രദമാകും:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// ഒറിജിനൽ ഇറ്ററേറ്ററിന്റെ അടുത്തുള്ള ഇനങ്ങൾക്കിടയിൽ `separator` ജനറേറ്റുചെയ്‌ത ഒരു ഇനം സ്ഥാപിക്കുന്ന ഒരു പുതിയ ഇറ്ററേറ്റർ സൃഷ്‌ടിക്കുന്നു.
    ///
    /// അടിവരയിടുന്ന ഇറ്ററേറ്ററിൽ നിന്ന് അടുത്തുള്ള രണ്ട് ഇനങ്ങൾക്കിടയിൽ ഒരു ഇനം സ്ഥാപിക്കുമ്പോൾ ഓരോ തവണയും അടയ്ക്കൽ കൃത്യമായി വിളിക്കും;
    /// പ്രത്യേകിച്ചും, അന്തർലീനമായ ഇറ്ററേറ്റർ രണ്ട് ഇനങ്ങളിൽ കുറവാണെങ്കിൽ അവസാന ഇനം ലഭിച്ചതിന് ശേഷം അടയ്ക്കൽ വിളിക്കില്ല.
    ///
    ///
    /// ഇറ്ററേറ്ററിന്റെ ഇനം [`Clone`] നടപ്പിലാക്കുകയാണെങ്കിൽ, [`intersperse`] ഉപയോഗിക്കുന്നത് എളുപ്പമായിരിക്കും.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // `v`-ൽ നിന്നുള്ള ആദ്യ ഘടകം.
    /// assert_eq!(it.next(), Some(NotClone(99))); // സെപ്പറേറ്റർ.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // `v`-ൽ നിന്നുള്ള അടുത്ത ഘടകം.
    /// assert_eq!(it.next(), Some(NotClone(99))); // സെപ്പറേറ്റർ.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // `v`-ൽ നിന്നുള്ള അവസാന ഘടകം.
    /// assert_eq!(it.next(), None);               // ഇറ്ററേറ്റർ പൂർത്തിയായി.
    /// ```
    ///
    /// `intersperse_with` സെപ്പറേറ്റർ കണക്കുകൂട്ടേണ്ട സാഹചര്യങ്ങളിൽ ഇത് ഉപയോഗിക്കാൻ കഴിയും:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // ഒരു ഇനം സൃഷ്ടിക്കുന്നതിന് അടയ്ക്കൽ അതിന്റെ സന്ദർഭം കടമെടുക്കുന്നു.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// ഒരു അടയ്ക്കൽ എടുത്ത് ഓരോ ഘടകത്തിലും ആ അടയ്ക്കൽ എന്ന് വിളിക്കുന്ന ഒരു ഇറ്ററേറ്റർ സൃഷ്ടിക്കുന്നു.
    ///
    /// `map()` അതിന്റെ വാദം വഴി ഒരു ആവർത്തനത്തെ മറ്റൊന്നിലേക്ക് പരിവർത്തനം ചെയ്യുന്നു:
    /// [`FnMut`] നടപ്പിലാക്കുന്ന ഒന്ന്.ഇത് ഒരു പുതിയ ഇറ്ററേറ്റർ നിർമ്മിക്കുന്നു, ഇത് യഥാർത്ഥ ആവർത്തനത്തിന്റെ ഓരോ ഘടകത്തിലും ഈ അടയ്ക്കൽ വിളിക്കുന്നു.
    ///
    /// നിങ്ങൾക്ക് തരങ്ങളിൽ ചിന്തിക്കാൻ നല്ലതാണെങ്കിൽ, നിങ്ങൾക്ക് ഇതുപോലെയുള്ള `map()`-നെക്കുറിച്ച് ചിന്തിക്കാം:
    /// നിങ്ങൾക്ക് ചില തരം `A` ന്റെ ഘടകങ്ങൾ നൽകുന്ന ഒരു ഇറ്ററേറ്റർ ഉണ്ടെങ്കിൽ, നിങ്ങൾക്ക് മറ്റേതെങ്കിലും തരത്തിലുള്ള `B` ന്റെ ഒരു ഇറ്ററേറ്റർ വേണമെങ്കിൽ, നിങ്ങൾക്ക് `map()` ഉപയോഗിക്കാം, ഒരു ക്ലോഷർ കടന്ന് ഒരു `A` എടുത്ത് ഒരു `B` നൽകുന്നു.
    ///
    ///
    /// `map()` ആശയപരമായി ഒരു [`for`] ലൂപ്പിന് സമാനമാണ്.എന്നിരുന്നാലും, `map()` അലസമായതിനാൽ, നിങ്ങൾ ഇതിനകം മറ്റ് ആവർത്തനക്കാരുമായി പ്രവർത്തിക്കുമ്പോൾ ഇത് നന്നായി ഉപയോഗിക്കുന്നു.
    /// ഒരു പാർശ്വഫലത്തിനായി നിങ്ങൾ ഒരുതരം ലൂപ്പിംഗ് നടത്തുകയാണെങ്കിൽ, `map()`-നേക്കാൾ [`for`] ഉപയോഗിക്കുന്നത് കൂടുതൽ ഇഡ്യൂമാറ്റിക് ആയി കണക്കാക്കപ്പെടുന്നു.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// നിങ്ങൾ ഏതെങ്കിലും തരത്തിലുള്ള പാർശ്വഫലങ്ങൾ ചെയ്യുകയാണെങ്കിൽ, [`for`] മുതൽ `map()` വരെ തിരഞ്ഞെടുക്കുക:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // ഇത് ചെയ്യരുത്:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // അത് അലസമായതിനാൽ അത് നടപ്പിലാക്കുക പോലും ഇല്ല.Rust ഇതിനെക്കുറിച്ച് നിങ്ങൾക്ക് മുന്നറിയിപ്പ് നൽകും.
    ///
    /// // പകരം, ഇതിനായി ഉപയോഗിക്കുക:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// ഒരു ആവർത്തനത്തിന്റെ ഓരോ ഘടകത്തിലും ഒരു അടയ്‌ക്കൽ വിളിക്കുന്നു.
    ///
    /// ഇത് അടയ്‌ക്കുന്നതിൽ നിന്ന് `break`, `continue` എന്നിവ സാധ്യമല്ലെങ്കിലും, ഇറ്ററേറ്ററിൽ ഒരു [`for`] ലൂപ്പ് ഉപയോഗിക്കുന്നതിന് തുല്യമാണിത്.
    /// ഒരു `for` ലൂപ്പ് ഉപയോഗിക്കുന്നത് പൊതുവെ കൂടുതൽ ഐഡിയമാറ്റിക് ആണ്, എന്നാൽ ദൈർഘ്യമേറിയ ഇറ്ററേറ്റർ ശൃംഖലകളുടെ അവസാനം ഇനങ്ങൾ പ്രോസസ്സ് ചെയ്യുമ്പോൾ `for_each` കൂടുതൽ വ്യക്തമാകും.
    ///
    /// ചില സാഹചര്യങ്ങളിൽ `for_each` ഒരു ലൂപ്പിനേക്കാൾ വേഗതയുള്ളതാകാം, കാരണം ഇത് `Chain` പോലുള്ള അഡാപ്റ്ററുകളിൽ ആന്തരിക ആവർത്തനം ഉപയോഗിക്കും.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// അത്തരമൊരു ചെറിയ ഉദാഹരണത്തിനായി, ഒരു `for` ലൂപ്പ് ക്ലീനർ ആയിരിക്കാം, പക്ഷേ ദൈർഘ്യമേറിയ ആവർത്തനങ്ങളുള്ള ഒരു ഫംഗ്ഷണൽ ശൈലി നിലനിർത്തുന്നതിന് `for_each` നല്ലതാണ്:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// ഒരു മൂലകം നൽകണമോ എന്ന് നിർണ്ണയിക്കാൻ ഒരു അടയ്ക്കൽ ഉപയോഗിക്കുന്ന ഒരു ഇറ്ററേറ്റർ സൃഷ്ടിക്കുന്നു.
    ///
    /// ഒരു ഘടകം നൽകിയാൽ അടയ്‌ക്കൽ `true` അല്ലെങ്കിൽ `false` നൽകണം.അടച്ചത് ശരിയായി വരുന്ന ഘടകങ്ങൾ മാത്രമേ മടങ്ങിയ ഇറ്ററേറ്റർ നൽകൂ.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// കാരണം `filter()` ലേക്ക് അടച്ച അടയ്ക്കൽ ഒരു റഫറൻസ് എടുക്കുന്നു, കൂടാതെ നിരവധി ഇറ്ററേറ്ററുകൾ റഫറൻസുകളിലൂടെ ആവർത്തിക്കുന്നു, ഇത് ആശയക്കുഴപ്പമുണ്ടാക്കുന്ന ഒരു സാഹചര്യത്തിലേക്ക് നയിക്കുന്നു, ഇവിടെ അടയ്ക്കൽ തരം ഇരട്ട റഫറൻസാണ്:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // രണ്ട് * സെ!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ഒരെണ്ണം നീക്കംചെയ്യുന്നതിന് പകരം ആർഗ്യുമെന്റിന്റെ ഡിസ്ട്രക്ചറിംഗ് ഉപയോഗിക്കുന്നത് സാധാരണമാണ്:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // രണ്ടും ഒപ്പം *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// അല്ലെങ്കിൽ രണ്ടും:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // രണ്ട് &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ഈ പാളികളിൽ.
    ///
    /// `iter.filter(f).next()` എന്നത് `iter.find(f)` ന് തുല്യമാണെന്ന് ശ്രദ്ധിക്കുക.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// ഫിൽട്ടറുകളും മാപ്പുകളും ഒരു ഇറ്ററേറ്റർ സൃഷ്ടിക്കുന്നു.
    ///
    /// മടക്കിയ ഇറ്ററേറ്റർ, വിതരണം ചെയ്ത അടയ്ക്കൽ `Some(value)` നൽകുന്ന `മൂല്യം` മാത്രമേ നൽകുന്നുള്ളൂ.
    ///
    /// `filter_map` [`filter`], [`map`] എന്നിവയുടെ ശൃംഖലകൾ കൂടുതൽ സംക്ഷിപ്തമാക്കാൻ ഉപയോഗിക്കാം.
    /// ചുവടെയുള്ള ഉദാഹരണം ഒരു എക്സ് 01 എക്സ് എങ്ങനെയാണ് എക്സ് കോളിലേക്ക് ഒരൊറ്റ കോളിലേക്ക് ചുരുക്കാമെന്ന് കാണിക്കുന്നത്.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ഇതാ ഉദാഹരണം, പക്ഷേ [`filter`], [`map`] എന്നിവയ്ക്കൊപ്പം:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// നിലവിലെ ആവർത്തന എണ്ണവും അടുത്ത മൂല്യവും നൽകുന്ന ഒരു ഇറ്ററേറ്റർ സൃഷ്‌ടിക്കുന്നു.
    ///
    /// ആവർത്തന റിട്ടേൺ ലഭിച്ച ജോഡികളായ `(i, val)`, ഇവിടെ `i` എന്നത് ആവർത്തനത്തിന്റെ നിലവിലെ സൂചികയും `val` ആണ് ആവർത്തനത്തിന്റെ മൂല്യം.
    ///
    ///
    /// `enumerate()` അതിന്റെ എണ്ണം ഒരു [`usize`] ആയി സൂക്ഷിക്കുന്നു.
    /// നിങ്ങൾക്ക് മറ്റൊരു വലുപ്പത്തിലുള്ള സംഖ്യ ഉപയോഗിച്ച് കണക്കാക്കണമെങ്കിൽ, [`zip`] ഫംഗ്ഷൻ സമാന പ്രവർത്തനം നൽകുന്നു.
    ///
    /// # ഓവർഫ്ലോ ബിഹേവിയർ
    ///
    /// ഈ രീതി ഓവർഫ്ലോകളിൽ നിന്ന് കാവൽ നിൽക്കുന്നില്ല, അതിനാൽ [`usize::MAX`]-ൽ കൂടുതൽ ഘടകങ്ങൾ കണക്കാക്കുന്നത് തെറ്റായ ഫലം നൽകുന്നു അല്ലെങ്കിൽ panics.
    /// ഡീബഗ് അവകാശവാദങ്ങൾ പ്രാപ്തമാക്കിയിട്ടുണ്ടെങ്കിൽ, ഒരു panic ഉറപ്പുനൽകുന്നു.
    ///
    /// # Panics
    ///
    /// മടങ്ങിവരേണ്ട സൂചിക ഒരു [`usize`] കവിഞ്ഞൊഴുകുകയാണെങ്കിൽ മടങ്ങിയെത്തിയ ഇറ്ററേറ്റർ panic ആയിരിക്കാം.
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// ആവർത്തനത്തിന്റെ അടുത്ത ഘടകം ഉപയോഗിക്കാതെ തന്നെ നോക്കാൻ [`peek`] ഉപയോഗിക്കാൻ കഴിയുന്ന ഒരു ഇറ്ററേറ്റർ സൃഷ്ടിക്കുന്നു.
    ///
    /// ഒരു ആവർത്തനത്തിലേക്ക് ഒരു [`peek`] രീതി ചേർക്കുന്നു.കൂടുതൽ വിവരങ്ങൾക്ക് അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
    ///
    /// [`peek`] ആദ്യമായി വിളിക്കുമ്പോൾ അന്തർലീനമായ ഇറ്ററേറ്റർ ഇപ്പോഴും മുന്നേറുന്നുവെന്നത് ശ്രദ്ധിക്കുക: അടുത്ത ഘടകം വീണ്ടെടുക്കുന്നതിന്, [`next`] അണ്ടർലൈയിംഗ് ഇറ്ററേറ്ററിൽ വിളിക്കുന്നു, അതിനാൽ ഏതെങ്കിലും പാർശ്വഫലങ്ങൾ (അതായത്
    ///
    /// [`next`] രീതിയുടെ അടുത്ത മൂല്യം നേടുന്നതിനല്ലാതെ മറ്റെന്തെങ്കിലും സംഭവിക്കും.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() future-ലേക്ക് കാണാൻ ഞങ്ങളെ അനുവദിക്കുന്നു
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // നമുക്ക് ഒന്നിലധികം തവണ peek() ചെയ്യാൻ കഴിയും, ഇറ്ററേറ്റർ മുന്നേറില്ല
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // ഇറ്ററേറ്റർ പൂർത്തിയായ ശേഷം peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// ഒരു പ്രവചനത്തെ അടിസ്ഥാനമാക്കി [`ഒഴിവാക്കുക] ഘടകങ്ങൾ 'ഒരു ഇറ്ററേറ്റർ സൃഷ്‌ടിക്കുന്നു.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` ഒരു വാദം ഒരു അടയ്ക്കൽ എടുക്കുന്നു.ഇത് ആവർത്തനത്തിന്റെ ഓരോ ഘടകത്തിലും ഈ അടയ്‌ക്കലിനെ വിളിക്കുകയും `false` തിരികെ നൽകുന്നതുവരെ ഘടകങ്ങളെ അവഗണിക്കുകയും ചെയ്യും.
    ///
    /// `false` മടക്കിനൽകിയ ശേഷം, `skip_while()`'s ജോലി അവസാനിച്ചു, ബാക്കി ഘടകങ്ങൾ ലഭിക്കും.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// കാരണം `skip_while()`-ലേക്ക് അടച്ച അടയ്ക്കൽ ഒരു റഫറൻസ് എടുക്കുന്നു, കൂടാതെ നിരവധി ആവർത്തനങ്ങൾ റഫറൻസുകളിലൂടെ ആവർത്തിക്കുന്നു, ഇത് ആശയക്കുഴപ്പമുണ്ടാക്കുന്ന ഒരു സാഹചര്യത്തിലേക്ക് നയിക്കുന്നു, ഇവിടെ അടയ്ക്കൽ ആർഗ്യുമെന്റിന്റെ തരം ഇരട്ട റഫറൻസാണ്:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // രണ്ട് * സെ!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// പ്രാരംഭ `false`-ന് ശേഷം നിർത്തുന്നു:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // ഇത് തെറ്റായിരിക്കുമെങ്കിലും, ഞങ്ങൾക്ക് ഇതിനകം ഒരു തെറ്റ് ലഭിച്ചതിനാൽ, skip_while() ഇനി ഉപയോഗിക്കില്ല
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// ഒരു പ്രവചനത്തെ അടിസ്ഥാനമാക്കി ഘടകങ്ങൾ നൽകുന്ന ഒരു ഇറ്ററേറ്റർ സൃഷ്ടിക്കുന്നു.
    ///
    /// `take_while()` ഒരു വാദം ഒരു അടയ്ക്കൽ എടുക്കുന്നു.ഇത് ആവർത്തനത്തിന്റെ ഓരോ ഘടകത്തിലും ഈ അടയ്‌ക്കലിനെ വിളിക്കുകയും `true` നൽകുമ്പോൾ ഘടകങ്ങൾ നൽകുകയും ചെയ്യും.
    ///
    /// `false` മടക്കിനൽകിയ ശേഷം, `take_while()`'s ജോലി അവസാനിച്ചു, ബാക്കി ഘടകങ്ങൾ അവഗണിക്കപ്പെടും.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// കാരണം `take_while()` ലേക്ക് അടച്ച അടയ്ക്കൽ ഒരു റഫറൻസ് എടുക്കുന്നു, കൂടാതെ നിരവധി ഇറ്ററേറ്ററുകൾ റഫറൻസുകളിലൂടെ ആവർത്തിക്കുന്നു, ഇത് ആശയക്കുഴപ്പമുണ്ടാക്കുന്ന ഒരു സാഹചര്യത്തിലേക്ക് നയിക്കുന്നു, ഇവിടെ അടയ്ക്കൽ തരം ഇരട്ട റഫറൻസാണ്:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // രണ്ട് * സെ!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// പ്രാരംഭ `false`-ന് ശേഷം നിർത്തുന്നു:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // പൂജ്യത്തേക്കാൾ കുറവുള്ള കൂടുതൽ ഘടകങ്ങൾ ഞങ്ങളുടെ പക്കലുണ്ട്, പക്ഷേ ഞങ്ങൾക്ക് ഇതിനകം ഒരു തെറ്റ് ലഭിച്ചതിനാൽ, take_while() ഇനി ഉപയോഗിക്കില്ല
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take_while()` മൂല്യം ഉൾപ്പെടുത്തേണ്ടതുണ്ടോ ഇല്ലയോ എന്നറിയാൻ അത് നോക്കേണ്ടതുണ്ട്, ഉപഭോഗ ഇറ്ററേറ്ററുകൾ അത് നീക്കംചെയ്തതായി കാണും:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` ഇപ്പോൾ ഇല്ല, കാരണം ഇത് ആവർത്തനം നിർത്തണമോയെന്നറിയാൻ ഉപയോഗിച്ചതാണ്, പക്ഷേ അത് വീണ്ടും ആവർത്തനത്തിലേക്ക് മാറ്റിയില്ല.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// ഒരു പ്രവചനത്തെയും മാപ്പുകളെയും അടിസ്ഥാനമാക്കി ഘടകങ്ങൾ നൽകുന്ന ഒരു ഇറ്ററേറ്റർ സൃഷ്ടിക്കുന്നു.
    ///
    /// `map_while()` ഒരു വാദം ഒരു അടയ്ക്കൽ എടുക്കുന്നു.
    /// ഇത് ആവർത്തനത്തിന്റെ ഓരോ ഘടകത്തിലും ഈ അടയ്‌ക്കലിനെ വിളിക്കുകയും [`Some(_)`][`Some`] നൽകുമ്പോൾ ഘടകങ്ങൾ നൽകുകയും ചെയ്യും.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ഇതാ ഉദാഹരണം, പക്ഷേ [`take_while`], [`map`] എന്നിവയ്ക്കൊപ്പം:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// പ്രാരംഭ [`None`]-ന് ശേഷം നിർത്തുന്നു:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // u32 (4, 5) ൽ യോജിക്കുന്ന കൂടുതൽ ഘടകങ്ങൾ ഞങ്ങളുടെ പക്കലുണ്ട്, എന്നാൽ `map_while` `-3`-ന് `None` നൽകി (`predicate` `None` നൽകിയതുപോലെ), `collect` ആദ്യത്തെ `None` നേരിട്ടപ്പോൾ നിർത്തുന്നു.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// `map_while()` മൂല്യം ഉൾപ്പെടുത്തേണ്ടതുണ്ടോ ഇല്ലയോ എന്നറിയാൻ അത് നോക്കേണ്ടതുണ്ട്, ഉപഭോഗ ഇറ്ററേറ്ററുകൾ അത് നീക്കംചെയ്തതായി കാണും:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` ഇപ്പോൾ ഇല്ല, കാരണം ഇത് ആവർത്തനം നിർത്തണമോയെന്നറിയാൻ ഉപയോഗിച്ചതാണ്, പക്ഷേ അത് വീണ്ടും ആവർത്തനത്തിലേക്ക് മാറ്റിയില്ല.
    ///
    /// [`take_while`] ൽ നിന്ന് വ്യത്യസ്തമായി ഈ ഇറ്ററേറ്റർ **സംയോജിപ്പിച്ചിട്ടില്ല** എന്നത് ശ്രദ്ധിക്കുക.
    /// ആദ്യത്തെ [`None`] മടക്കിനൽകിയ ശേഷം ഈ ഇറ്ററേറ്റർ എന്ത് നൽകുന്നുവെന്നും വ്യക്തമാക്കിയിട്ടില്ല.
    /// നിങ്ങൾക്ക് ഫ്യൂസ്ഡ് ഇറ്ററേറ്റർ ആവശ്യമുണ്ടെങ്കിൽ, [`fuse`] ഉപയോഗിക്കുക.
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// ആദ്യത്തെ `n` ഘടകങ്ങൾ ഒഴിവാക്കുന്ന ഒരു ഇറ്ററേറ്റർ സൃഷ്ടിക്കുന്നു.
    ///
    /// അവ കഴിച്ച ശേഷം ബാക്കി മൂലകങ്ങൾ ലഭിക്കും.
    /// ഈ രീതി നേരിട്ട് അസാധുവാക്കുന്നതിനുപകരം, പകരം `nth` രീതി അസാധുവാക്കുക.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// ആദ്യത്തെ `n` ഘടകങ്ങൾ നൽകുന്ന ഒരു ഇറ്ററേറ്റർ സൃഷ്ടിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` ഇത് പരിമിതപ്പെടുത്തുന്നതിന് പലപ്പോഴും അനന്തമായ ആവർത്തന ഉപയോഗിച്ച് ഉപയോഗിക്കുന്നു:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `n`-ൽ താഴെയുള്ള ഘടകങ്ങൾ ലഭ്യമാണെങ്കിൽ, `take` സ്വയം അന്തർലീനമായ ആവർത്തനത്തിന്റെ വലുപ്പത്തിലേക്ക് പരിമിതപ്പെടുത്തും:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// [`fold`]-ന് സമാനമായ ഒരു ഇറ്ററേറ്റർ അഡാപ്റ്റർ ആന്തരിക അവസ്ഥ കൈവശം വയ്ക്കുകയും ഒരു പുതിയ ഇറ്ററേറ്റർ നിർമ്മിക്കുകയും ചെയ്യുന്നു.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` രണ്ട് ആർ‌ഗ്യുമെൻറുകൾ‌എടുക്കുന്നു: ആന്തരിക അവസ്ഥയെ വിത്തുപാകുന്ന ഒരു പ്രാരംഭ മൂല്യം, രണ്ട് ആർ‌ഗ്യുമെൻറുകൾ‌അടയ്‌ക്കൽ, ആദ്യത്തേത് ആന്തരിക അവസ്ഥയെ പരിവർത്തനം ചെയ്യാവുന്ന റഫറൻ‌സ്, രണ്ടാമത്തേത് ഒരു ഇറ്ററേറ്റർ‌എലമെൻറ്.
    ///
    /// ആവർത്തനങ്ങൾക്കിടയിൽ സംസ്ഥാനം പങ്കിടുന്നതിന് അടയ്‌ക്കൽ ആന്തരിക അവസ്ഥയിലേക്ക് നിയോഗിക്കാൻ കഴിയും.
    ///
    /// ആവർത്തന സമയത്ത്, അടയ്ക്കൽ ആവർത്തനത്തിന്റെ ഓരോ ഘടകത്തിലും പ്രയോഗിക്കുകയും അടയ്ക്കുന്നതിൽ നിന്നുള്ള റിട്ടേൺ മൂല്യം, [`Option`], ആവർത്തനക്കാരൻ നൽകുകയും ചെയ്യുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // ഓരോ ആവർത്തനവും, ഞങ്ങൾ മൂലകത്താൽ സംസ്ഥാനത്തെ ഗുണിക്കും
    ///     *state = *state * x;
    ///
    ///     // അപ്പോൾ, ഞങ്ങൾ സംസ്ഥാനത്തിന്റെ നിർദേശത്തിന് വഴങ്ങും
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// മാപ്പ് പോലെ പ്രവർത്തിക്കുന്ന ഒരു ഇറ്ററേറ്റർ സൃഷ്ടിക്കുന്നു, പക്ഷേ നെസ്റ്റഡ് ഘടന പരത്തുന്നു.
    ///
    /// [`map`] അഡാപ്റ്റർ വളരെ ഉപയോഗപ്രദമാണ്, പക്ഷേ അടയ്ക്കൽ ആർഗ്യുമെന്റ് മൂല്യങ്ങൾ സൃഷ്ടിക്കുമ്പോൾ മാത്രം.
    /// പകരം അത് ഒരു ഇറ്ററേറ്റർ നിർമ്മിക്കുകയാണെങ്കിൽ, ഇൻഡെറക്ഷന്റെ ഒരു അധിക പാളി ഉണ്ട്.
    /// `flat_map()` ഈ അധിക പാളി സ്വന്തമായി നീക്കംചെയ്യും.
    ///
    /// നിങ്ങൾക്ക് `flat_map(f)` നെ [`മാപ്പ്`] പിങ്ങിന് തുല്യമായ സെമാന്റിക് ആയി കണക്കാക്കാം, തുടർന്ന് `map(f).flatten()`-ലെ പോലെ [` പരത്തുക].
    ///
    /// `flat_map()`-നെക്കുറിച്ച് ചിന്തിക്കുന്നതിനുള്ള മറ്റൊരു മാർഗ്ഗം: [`മാപ്പ്`] അടയ്ക്കുന്നത് ഓരോ ഘടകത്തിനും ഒരു ഇനം നൽകുന്നു, ഒപ്പം `flat_map()`'s അടയ്ക്കൽ ഓരോ ഘടകത്തിനും ഒരു ഇറ്ററേറ്റർ നൽകുന്നു.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() ഒരു ഇറ്ററേറ്റർ നൽകുന്നു
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// നെസ്റ്റഡ് ഘടനയെ പരന്ന ഒരു ഇറ്ററേറ്റർ സൃഷ്ടിക്കുന്നു.
    ///
    /// നിങ്ങൾക്ക് ഇറ്ററേറ്ററുകളുടെ ഒരു ഇറ്ററേറ്റർ അല്ലെങ്കിൽ ഇറ്ററേറ്ററുകളാക്കി മാറ്റാൻ കഴിയുന്ന കാര്യങ്ങളുടെ ഒരു ഇറ്ററേറ്റർ ഉള്ളപ്പോൾ ഇത് ഉപയോഗപ്രദമാകും ഒപ്പം ഒരു ലെവൽ ഇൻഡെറക്ഷൻ നീക്കംചെയ്യാനും നിങ്ങൾ ആഗ്രഹിക്കുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// മാപ്പിംഗും തുടർന്ന് പരന്നതും:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() ഒരു ഇറ്ററേറ്റർ നൽകുന്നു
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// [`flat_map()`]-ന്റെ കാര്യത്തിലും നിങ്ങൾക്ക് ഇത് മാറ്റിയെഴുതാം, ഇത് ഉദ്ദേശ്യം കൂടുതൽ വ്യക്തമായി അറിയിക്കുന്നതിനാൽ ഈ സാഹചര്യത്തിൽ ഇത് നല്ലതാണ്:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() ഒരു ഇറ്ററേറ്റർ നൽകുന്നു
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// പരന്നത് ഒരു സമയം കൂടുണ്ടാക്കുന്നത് മാത്രമേ നീക്കംചെയ്യൂ:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// `flatten()` ഒരു "deep" പരന്ന പ്രകടനം നടത്തുന്നില്ലെന്ന് ഇവിടെ കാണാം.
    /// പകരം, ഒരു ലെവൽ നെസ്റ്റിംഗ് മാത്രമേ നീക്കംചെയ്യൂ.അതായത്, നിങ്ങൾ ത്രിമാന അറേ `flatten()` ആണെങ്കിൽ, ഫലം ദ്വിമാനമായിരിക്കും, ഒരു ഡൈമെൻഷനല്ല.
    /// ഒരു ഡൈമൻഷണൽ ഘടന ലഭിക്കാൻ, നിങ്ങൾ വീണ്ടും `flatten()` ചെയ്യണം.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// ആദ്യത്തെ [`None`] ന് ശേഷം അവസാനിക്കുന്ന ഒരു ഇറ്ററേറ്റർ സൃഷ്ടിക്കുന്നു.
    ///
    /// ഒരു ഇറ്ററേറ്റർ [`None`] നൽകിയ ശേഷം, future കോളുകൾ [`Some(T)`] വീണ്ടും നൽകാം അല്ലെങ്കിൽ നൽകില്ല.
    /// `fuse()` ഒരു ഇറ്ററേറ്ററിനെ പൊരുത്തപ്പെടുത്തുന്നു, ഒരു [`None`] നൽകിയ ശേഷം, അത് എല്ലായ്പ്പോഴും [`None`] എന്നെന്നേക്കുമായി നൽകുമെന്ന് ഉറപ്പാക്കുന്നു.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// // ചിലതിനും ഒന്നിനുമിടയിൽ മാറിമാറി വരുന്ന ഒരു ആവർത്തനം
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // അത് തുല്യമാണെങ്കിൽ, Some(i32), അല്ലെങ്കിൽ ഒന്നുമില്ല
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // ഞങ്ങളുടെ ഇറ്ററേറ്റർ അങ്ങോട്ടും ഇങ്ങോട്ടും പോകുന്നത് നമുക്ക് കാണാം
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // എന്നിരുന്നാലും, ഒരിക്കൽ ഞങ്ങൾ ഇത് ഫ്യൂസ് ചെയ്യുന്നു ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // ഇത് എല്ലായ്പ്പോഴും ആദ്യമായി `None` നൽകും.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// ഒരു ഇറ്ററേറ്ററിന്റെ ഓരോ ഘടകത്തിലും എന്തെങ്കിലും ചെയ്യുന്നു, മൂല്യം കൈമാറുന്നു.
    ///
    /// ഇറ്ററേറ്ററുകൾ‌ഉപയോഗിക്കുമ്പോൾ‌, നിങ്ങൾ‌അവയിൽ‌പലതും ഒന്നിച്ച് ബന്ധിപ്പിക്കും.
    /// അത്തരം കോഡിൽ പ്രവർത്തിക്കുമ്പോൾ, പൈപ്പ്ലൈനിലെ വിവിധ ഭാഗങ്ങളിൽ എന്താണ് സംഭവിക്കുന്നതെന്ന് പരിശോധിക്കാൻ നിങ്ങൾ ആഗ്രഹിച്ചേക്കാം.അത് ചെയ്യുന്നതിന്, `inspect()`-ലേക്ക് ഒരു കോൾ ചേർക്കുക.
    ///
    /// നിങ്ങളുടെ അന്തിമ കോഡിൽ നിലനിൽക്കുന്നതിനേക്കാൾ `inspect()` ഡീബഗ്ഗിംഗ് ഉപകരണമായി ഉപയോഗിക്കുന്നത് വളരെ സാധാരണമാണ്, പക്ഷേ നിരസിക്കുന്നതിന് മുമ്പ് പിശകുകൾ ലോഗിൻ ചെയ്യേണ്ടിവരുമ്പോൾ ചില സാഹചര്യങ്ങളിൽ അപ്ലിക്കേഷനുകൾ ഇത് ഉപയോഗപ്രദമാകും.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // ഈ ആവർത്തന ശ്രേണി സങ്കീർണ്ണമാണ്.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // എന്താണ് സംഭവിക്കുന്നതെന്ന് അന്വേഷിക്കുന്നതിന് നമുക്ക് ചില inspect() കോളുകൾ ചേർക്കാം
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// ഇത് അച്ചടിക്കും:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// പിശകുകൾ നിരസിക്കുന്നതിന് മുമ്പ് ലോഗിൻ ചെയ്യുന്നത്:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// ഇത് അച്ചടിക്കും:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// ഒരു ഇറ്ററേറ്റർ അത് ഉപയോഗിക്കുന്നതിനുപകരം കടം വാങ്ങുന്നു.
    ///
    /// യഥാർത്ഥ ആവർത്തനത്തിന്റെ ഉടമസ്ഥാവകാശം നിലനിർത്തിക്കൊണ്ടുതന്നെ ആവർത്തന അഡാപ്റ്ററുകൾ പ്രയോഗിക്കാൻ അനുവദിക്കുന്നതിന് ഇത് ഉപയോഗപ്രദമാണ്.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // ഞങ്ങൾ ഇത് വീണ്ടും ഉപയോഗിക്കാൻ ശ്രമിച്ചാൽ, അത് പ്രവർത്തിക്കില്ല.
    /// // ഇനിപ്പറയുന്ന വരി "പിശക്: നീക്കിയ മൂല്യത്തിന്റെ ഉപയോഗം: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // നമുക്ക് അത് വീണ്ടും ശ്രമിക്കാം
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // പകരം, ഞങ്ങൾ ഒരു .by_ref() ൽ ചേർക്കുന്നു
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // ഇപ്പോൾ ഇത് നല്ലതാണ്:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// ഒരു ആവർത്തനത്തെ ഒരു ശേഖരത്തിലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// `collect()` ആവർത്തിക്കാവുന്ന എന്തും എടുത്ത് പ്രസക്തമായ ശേഖരമാക്കി മാറ്റാൻ കഴിയും.
    /// സ്റ്റാൻഡേർഡ് ലൈബ്രറിയിലെ കൂടുതൽ ശക്തമായ രീതികളിൽ ഒന്നാണിത്, വിവിധ സന്ദർഭങ്ങളിൽ ഇത് ഉപയോഗിക്കുന്നു.
    ///
    /// `collect()` ഉപയോഗിക്കുന്ന ഏറ്റവും അടിസ്ഥാന പാറ്റേൺ ഒരു ശേഖരം മറ്റൊന്നിലേക്ക് മാറ്റുക എന്നതാണ്.
    /// നിങ്ങൾ ഒരു ശേഖരം എടുക്കുക, അതിൽ [`iter`]-ൽ വിളിക്കുക, ഒരു കൂട്ടം പരിവർത്തനങ്ങൾ ചെയ്യുക, തുടർന്ന് `collect()` അവസാനം.
    ///
    /// `collect()` സാധാരണ ശേഖരങ്ങളല്ലാത്ത തരങ്ങളുടെ ഉദാഹരണങ്ങളും സൃഷ്ടിക്കാൻ കഴിയും.
    /// ഉദാഹരണത്തിന്, [`char`] ൽ നിന്ന് ഒരു [`String`] നിർമ്മിക്കാൻ കഴിയും, കൂടാതെ [`Result<T, E>`][`Result`] ഇനങ്ങളുടെ ഒരു ഇറ്ററേറ്റർ `Result<Collection<T>, E>`-ലേക്ക് ശേഖരിക്കാനും കഴിയും.
    ///
    /// കൂടുതൽ വിവരങ്ങൾക്ക് ചുവടെയുള്ള ഉദാഹരണങ്ങൾ കാണുക.
    ///
    /// `collect()` വളരെ പൊതുവായതിനാൽ, ഇത് തരം അനുമാനത്തിൽ പ്രശ്നങ്ങൾ സൃഷ്ടിക്കും.
    /// അതുപോലെ, എക്സ് 00 എക്സ് എന്ന് സ്നേഹപൂർവ്വം അറിയപ്പെടുന്ന വാക്യഘടന നിങ്ങൾ കാണുന്ന ചുരുക്കം സമയങ്ങളിൽ ഒന്നാണ് എക്സ് 01 എക്സ്: `::<>`.
    /// ഏത് ശേഖരത്തിലാണ് നിങ്ങൾ ശേഖരിക്കാൻ ശ്രമിക്കുന്നതെന്ന് വ്യക്തമായി മനസ്സിലാക്കാൻ ഇത് അനുമാന അൽഗോരിതം സഹായിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// ഇടത് വശത്ത് ഞങ്ങൾക്ക് `: Vec<i32>` ആവശ്യമാണെന്ന് ശ്രദ്ധിക്കുക.കാരണം, പകരം ഒരു [`VecDeque<T>`]-ലേക്ക് ശേഖരിക്കാൻ ഞങ്ങൾക്ക് കഴിയും:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// `doubled` വ്യാഖ്യാനിക്കുന്നതിനുപകരം 'turbofish' ഉപയോഗിക്കുന്നു:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// `collect()` നിങ്ങൾ ശേഖരിക്കുന്നവയെക്കുറിച്ച് മാത്രം ശ്രദ്ധിക്കുന്നതിനാൽ, നിങ്ങൾക്ക് ഇപ്പോഴും ടർബോഫിഷിനൊപ്പം ഭാഗിക തരം സൂചനയായ `_` ഉപയോഗിക്കാം:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// ഒരു [`String`] നിർമ്മിക്കാൻ `collect()` ഉപയോഗിക്കുന്നു:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// നിങ്ങൾക്ക് [`ഫലത്തിന്റെ ഒരു ലിസ്റ്റ് ഉണ്ടെങ്കിൽ<T, E>`][`ഫലം`], അവയിലേതെങ്കിലും പരാജയപ്പെട്ടോ എന്ന് കാണാൻ നിങ്ങൾക്ക് `collect()` ഉപയോഗിക്കാം:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // ഞങ്ങൾക്ക് ആദ്യത്തെ പിശക് നൽകുന്നു
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // ഉത്തരങ്ങളുടെ പട്ടിക ഞങ്ങൾക്ക് നൽകുന്നു
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// ഒരു ഇറ്ററേറ്റർ ഉപയോഗിക്കുന്നു, അതിൽ നിന്ന് രണ്ട് ശേഖരങ്ങൾ സൃഷ്ടിക്കുന്നു.
    ///
    /// `partition()`-ലേക്ക് കൈമാറിയ പ്രവചനത്തിന് `true` അല്ലെങ്കിൽ `false` നൽകാനാകും.
    /// `partition()` ഒരു ജോഡി നൽകുന്നു, അത് `true` നൽകിയ എല്ലാ ഘടകങ്ങളും അത് `false` നൽകിയ എല്ലാ ഘടകങ്ങളും നൽകുന്നു.
    ///
    ///
    /// [`is_partitioned()`], [`partition_in_place()`] എന്നിവയും കാണുക.
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// തന്നിരിക്കുന്ന പ്രവചനമനുസരിച്ച് ഈ ഇറ്ററേറ്ററിന്റെ ഘടകങ്ങൾ *സ്ഥലത്ത്* പുന ers ക്രമീകരിക്കുന്നു, അതായത് `true` മടങ്ങിയെത്തുന്നവരെല്ലാം `false` മടങ്ങുന്ന എല്ലാത്തിനും മുമ്പായി.
    ///
    /// കണ്ടെത്തിയ `true` ഘടകങ്ങളുടെ എണ്ണം നൽകുന്നു.
    ///
    /// പാർട്ടീഷൻ ചെയ്ത ഇനങ്ങളുടെ ആപേക്ഷിക ക്രമം നിലനിർത്തുന്നില്ല.
    ///
    /// [`is_partitioned()`], [`partition()`] എന്നിവയും കാണുക.
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // വൈകുന്നേരവും വിചിത്രവും തമ്മിലുള്ള വിഭജനം
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: എണ്ണം കവിഞ്ഞൊഴുകുന്നതിനെക്കുറിച്ച് നാം വിഷമിക്കേണ്ടതുണ്ടോ?എന്നതിനേക്കാൾ കൂടുതൽ ഉള്ള ഏക മാർഗം
        // `usize::MAX` വിഭജനത്തിന് ഉപയോഗപ്രദമല്ലാത്ത ZST-കളിലാണ് മ്യൂട്ടബിൾ റഫറൻസുകൾ ...

        // `Self`-ലെ പൊതുവായത ഒഴിവാക്കാൻ ഈ അടയ്ക്കൽ "factory" ഫംഗ്ഷനുകൾ നിലവിലുണ്ട്.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // ആദ്യത്തെ `false` ആവർത്തിച്ച് കണ്ടെത്തി അവസാന `true` ഉപയോഗിച്ച് സ്വാപ്പ് ചെയ്യുക.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// തന്നിരിക്കുന്ന പ്രവചനമനുസരിച്ച് ഈ ഇറ്ററേറ്ററിന്റെ ഘടകങ്ങൾ പാർട്ടീഷൻ ചെയ്തിട്ടുണ്ടോയെന്ന് പരിശോധിക്കുന്നു, അതായത് `true` മടങ്ങിയെത്തുന്നവരെല്ലാം `false` മടക്കിനൽകുന്ന എല്ലാത്തിനും മുമ്പാണ്.
    ///
    ///
    /// [`partition()`], [`partition_in_place()`] എന്നിവയും കാണുക.
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // ഒന്നുകിൽ എല്ലാ ഇനങ്ങളും `true` പരിശോധിക്കുന്നു, അല്ലെങ്കിൽ ആദ്യ ക്ലോസ് `false` ൽ നിർത്തുന്നു, അതിനുശേഷം കൂടുതൽ `true` ഇനങ്ങൾ ഇല്ലെന്ന് ഞങ്ങൾ പരിശോധിക്കുന്നു.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// ഒരു ഫംഗ്ഷൻ വിജയകരമായി മടങ്ങിവരുന്നിടത്തോളം കാലം ഒരൊറ്റ അന്തിമ മൂല്യം സൃഷ്ടിക്കുന്ന ഒരു ആവർത്തന രീതി.
    ///
    /// `try_fold()` രണ്ട് ആർ‌ഗ്യുമെൻറുകൾ‌എടുക്കുന്നു: ഒരു പ്രാരംഭ മൂല്യം, രണ്ട് ആർ‌ഗ്യുമെൻറുകൾ‌അടയ്‌ക്കൽ: ഒരു 'accumulator', ഒരു ഘടകം.
    /// അടുത്ത ആവർത്തനത്തിനായി സഞ്ചിതർക്ക് ഉണ്ടായിരിക്കേണ്ട മൂല്യം ഉപയോഗിച്ച് അടയ്ക്കൽ വിജയകരമായി മടങ്ങുന്നു, അല്ലെങ്കിൽ അത് പരാജയം നൽകുന്നു, ഒരു പിശക് മൂല്യം ഉപയോഗിച്ച് കോളറിലേക്ക് ഉടൻ തന്നെ (short-circuiting) തിരികെ പ്രചരിപ്പിക്കുന്നു.
    ///
    ///
    /// ആദ്യ കോളിൽ സഞ്ചിതർക്ക് ഉണ്ടായിരിക്കേണ്ട മൂല്യമാണ് പ്രാരംഭ മൂല്യം.അടയ്ക്കൽ പ്രയോഗിക്കുന്നത് ആവർത്തനത്തിന്റെ എല്ലാ ഘടകങ്ങൾക്കും എതിരായി വിജയിച്ചാൽ, `try_fold()` അന്തിമ സഞ്ചയത്തെ വിജയമായി നൽകുന്നു.
    ///
    /// നിങ്ങൾക്ക് എന്തെങ്കിലും ശേഖരം ഉള്ളപ്പോഴെല്ലാം മടക്കിക്കളയൽ ഉപയോഗപ്രദമാണ്, അതിൽ നിന്ന് ഒരൊറ്റ മൂല്യം സൃഷ്ടിക്കാൻ ആഗ്രഹിക്കുന്നു.
    ///
    /// # നടപ്പിലാക്കുന്നവർക്കുള്ള കുറിപ്പ്
    ///
    /// മറ്റ് (forward) രീതികളിൽ പലതിനും സ്ഥിരസ്ഥിതി നടപ്പാക്കലുകൾ ഉണ്ട്, അതിനാൽ സ്ഥിരസ്ഥിതി `for` ലൂപ്പ് നടപ്പാക്കലിനേക്കാൾ മികച്ചത് ചെയ്യാൻ കഴിയുമെങ്കിൽ ഇത് വ്യക്തമായി നടപ്പിലാക്കാൻ ശ്രമിക്കുക.
    ///
    /// പ്രത്യേകിച്ചും, ഈ ഇറ്ററേറ്റർ രചിച്ച ആന്തരിക ഭാഗങ്ങളിൽ ഈ കോൾ `try_fold()` ഉപയോഗിക്കാൻ ശ്രമിക്കുക.
    /// ഒന്നിലധികം കോളുകൾ ആവശ്യമാണെങ്കിൽ, സഞ്ചിത മൂല്യത്തിനൊപ്പം ചങ്ങലയിടുന്നതിന് `?` ഓപ്പറേറ്റർ സൗകര്യപ്രദമായിരിക്കും, എന്നാൽ ആദ്യകാല വരുമാനത്തിന് മുമ്പായി ഉയർത്തിപ്പിടിക്കേണ്ട ഏതെങ്കിലും മാറ്റങ്ങളെ സൂക്ഷിക്കുക.
    /// ഇതൊരു `&mut self` രീതിയാണ്, അതിനാൽ ഇവിടെ ഒരു പിശക് സംഭവിച്ചതിന് ശേഷം ആവർത്തനം പുനരാരംഭിക്കേണ്ടതുണ്ട്.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // അറേയിലെ എല്ലാ ഘടകങ്ങളുടെയും പരിശോധിച്ച തുക
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // 100 ഘടകം ചേർക്കുമ്പോൾ ഈ തുക കവിഞ്ഞൊഴുകുന്നു
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // ഇത് ഷോർട്ട് സർക്യൂട്ട് ചെയ്തതിനാൽ, ശേഷിക്കുന്ന ഘടകങ്ങൾ ഇപ്പോഴും ആവർത്തനത്തിലൂടെ ലഭ്യമാണ്.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// ഇറ്ററേറ്ററിലെ ഓരോ ഇനത്തിനും തെറ്റായ പ്രവർത്തനം ബാധകമാക്കുന്ന ഒരു ഇറ്ററേറ്റർ രീതി, ആദ്യ പിശക് നിർത്തി ആ പിശക് നൽകുന്നു.
    ///
    ///
    /// ഇത് [`for_each()`]-ന്റെ തെറ്റായ രൂപമായോ [`try_fold()`]-ന്റെ സ്റ്റേറ്റ്‌ലെസ് പതിപ്പായോ കണക്കാക്കാം.
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // ഇത് ഷോർട്ട് സർക്യൂട്ട് ചെയ്തതിനാൽ ശേഷിക്കുന്ന ഇനങ്ങൾ ഇപ്പോഴും ഇറ്ററേറ്ററിൽ ഉണ്ട്:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// ഒരു പ്രവർത്തനം പ്രയോഗിച്ച് അന്തിമഫലം നൽകിക്കൊണ്ട് എല്ലാ ഘടകങ്ങളെയും ഒരു സഞ്ചയത്തിലേക്ക് മടക്കിക്കളയുന്നു.
    ///
    /// `fold()` രണ്ട് ആർ‌ഗ്യുമെൻറുകൾ‌എടുക്കുന്നു: ഒരു പ്രാരംഭ മൂല്യം, രണ്ട് ആർ‌ഗ്യുമെൻറുകൾ‌അടയ്‌ക്കൽ: ഒരു 'accumulator', ഒരു ഘടകം.
    /// അടുത്ത ആവർത്തനത്തിനായി സഞ്ചിതർക്ക് ഉണ്ടായിരിക്കേണ്ട മൂല്യം അടയ്ക്കൽ നൽകുന്നു.
    ///
    /// ആദ്യ കോളിൽ സഞ്ചിതർക്ക് ഉണ്ടായിരിക്കേണ്ട മൂല്യമാണ് പ്രാരംഭ മൂല്യം.
    ///
    /// ആവർത്തനത്തിന്റെ എല്ലാ ഘടകങ്ങളിലും ഈ അടയ്ക്കൽ പ്രയോഗിച്ചതിന് ശേഷം, `fold()` ശേഖരിക്കൽ നൽകുന്നു.
    ///
    /// ഈ പ്രവർത്തനത്തെ ചിലപ്പോൾ 'reduce' അല്ലെങ്കിൽ 'inject' എന്ന് വിളിക്കുന്നു.
    ///
    /// നിങ്ങൾക്ക് എന്തെങ്കിലും ശേഖരം ഉള്ളപ്പോഴെല്ലാം മടക്കിക്കളയൽ ഉപയോഗപ്രദമാണ്, അതിൽ നിന്ന് ഒരൊറ്റ മൂല്യം സൃഷ്ടിക്കാൻ ആഗ്രഹിക്കുന്നു.
    ///
    /// Note: എക്സ് 100 എക്സ്, മുഴുവൻ ഇറ്ററേറ്ററിലൂടെ സഞ്ചരിക്കുന്ന സമാന രീതികൾ, അനന്തമായ ഇറ്ററേറ്ററുകൾക്കായി, traits-ൽ പോലും അവസാനിപ്പിക്കാനിടയില്ല, അതിനുള്ള ഫലം പരിമിതമായ സമയത്ത് നിർണ്ണയിക്കാനാകും.
    ///
    /// Note: സഞ്ചിത തരവും ഇന തരവും ഒന്നുതന്നെയാണെങ്കിൽ, ആദ്യ മൂല്യം പ്രാരംഭ മൂല്യമായി ഉപയോഗിക്കാൻ [`reduce()`] ഉപയോഗിക്കാം.
    ///
    /// # നടപ്പിലാക്കുന്നവർക്കുള്ള കുറിപ്പ്
    ///
    /// മറ്റ് (forward) രീതികളിൽ പലതിനും സ്ഥിരസ്ഥിതി നടപ്പാക്കലുകൾ ഉണ്ട്, അതിനാൽ സ്ഥിരസ്ഥിതി `for` ലൂപ്പ് നടപ്പാക്കലിനേക്കാൾ മികച്ചത് ചെയ്യാൻ കഴിയുമെങ്കിൽ ഇത് വ്യക്തമായി നടപ്പിലാക്കാൻ ശ്രമിക്കുക.
    ///
    ///
    /// പ്രത്യേകിച്ചും, ഈ ഇറ്ററേറ്റർ രചിച്ച ആന്തരിക ഭാഗങ്ങളിൽ ഈ കോൾ `fold()` ഉപയോഗിക്കാൻ ശ്രമിക്കുക.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // അറേയിലെ എല്ലാ ഘടകങ്ങളുടെയും ആകെത്തുക
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// ആവർത്തനത്തിന്റെ ഓരോ ഘട്ടത്തിലൂടെയും നമുക്ക് ഇവിടെ നടക്കാം:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// അങ്ങനെ, ഞങ്ങളുടെ അന്തിമഫലം, `6`.
    ///
    /// ഇറ്ററേറ്ററുകൾ‌വളരെയധികം ഉപയോഗിക്കാത്ത ആളുകൾ‌ഒരു ഫലം സൃഷ്‌ടിക്കുന്നതിന് കാര്യങ്ങളുടെ ഒരു പട്ടികയുള്ള ഒരു `for` ലൂപ്പ് ഉപയോഗിക്കുന്നത് സാധാരണമാണ്.അവ `fold()`s ആയി മാറ്റാം:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // ലൂപ്പിനായി:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // അവ സമാനമാണ്
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// ഒരു കുറയ്‌ക്കൽ പ്രവർത്തനം ആവർത്തിച്ച് പ്രയോഗിക്കുന്നതിലൂടെ ഘടകങ്ങൾ ഒരൊറ്റതിലേക്ക് കുറയ്‌ക്കുന്നു.
    ///
    /// ഇറ്ററേറ്റർ ശൂന്യമാണെങ്കിൽ, [`None`] നൽകുന്നു;അല്ലെങ്കിൽ, കുറച്ചതിന്റെ ഫലം നൽകുന്നു.
    ///
    /// കുറഞ്ഞത് ഒരു ഘടകമെങ്കിലും ഉള്ള ഇറ്ററേറ്ററുകൾക്ക്, ഇത് പ്രാരംഭ മൂല്യമായി ആവർത്തനത്തിന്റെ ആദ്യ ഘടകമുള്ള [`fold()`] ന് തുല്യമാണ്, തുടർന്നുള്ള എല്ലാ ഘടകങ്ങളും അതിലേക്ക് മടക്കിക്കളയുന്നു.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// പരമാവധി മൂല്യം കണ്ടെത്തുക:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// ആവർത്തനത്തിന്റെ ഓരോ ഘടകവും ഒരു പ്രവചനവുമായി പൊരുത്തപ്പെടുന്നുണ്ടോയെന്ന് പരിശോധിക്കുന്നു.
    ///
    /// `all()` `true` അല്ലെങ്കിൽ `false` നൽകുന്ന ഒരു അടയ്ക്കൽ എടുക്കുന്നു.ഇത് ആവർത്തനത്തിന്റെ ഓരോ ഘടകത്തിനും ഈ അടയ്ക്കൽ ബാധകമാക്കുന്നു, അവയെല്ലാം `true` നൽകുന്നുവെങ്കിൽ, `all()` ഉം അങ്ങനെ തന്നെ ചെയ്യും.
    /// അവയിലേതെങ്കിലും `false` നൽകുന്നുവെങ്കിൽ, അത് `false` നൽകുന്നു.
    ///
    /// `all()` ഷോർട്ട് സർക്യൂട്ടിംഗ്;മറ്റൊരു വിധത്തിൽ പറഞ്ഞാൽ, ഒരു `false` കണ്ടെത്തിയ ഉടൻ തന്നെ ഇത് പ്രോസസ്സിംഗ് നിർത്തും, മറ്റെന്താണ് സംഭവിച്ചതെങ്കിലും, ഫലം `false` ആയിരിക്കും.
    ///
    ///
    /// ഒരു ശൂന്യ ഇറ്ററേറ്റർ `true` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// ആദ്യ `false`-ൽ നിർത്തുന്നു:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // കൂടുതൽ ഘടകങ്ങൾ ഉള്ളതിനാൽ ഞങ്ങൾക്ക് ഇപ്പോഴും `iter` ഉപയോഗിക്കാൻ കഴിയും.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// ആവർത്തനത്തിന്റെ ഏതെങ്കിലും ഘടകം ഒരു പ്രവചനവുമായി പൊരുത്തപ്പെടുന്നുണ്ടോയെന്ന് പരിശോധിക്കുന്നു.
    ///
    /// `any()` `true` അല്ലെങ്കിൽ `false` നൽകുന്ന ഒരു അടയ്ക്കൽ എടുക്കുന്നു.ഇത് ആവർത്തനത്തിന്റെ ഓരോ ഘടകത്തിനും ഈ അടയ്ക്കൽ ബാധകമാക്കുന്നു, അവയിലേതെങ്കിലും `true` നൽകുന്നുവെങ്കിൽ, അതുപോലെ തന്നെ `any()`.
    /// എല്ലാവരും `false` നൽകുന്നുവെങ്കിൽ, അത് `false` നൽകുന്നു.
    ///
    /// `any()` ഷോർട്ട് സർക്യൂട്ടിംഗ്;മറ്റൊരു വിധത്തിൽ പറഞ്ഞാൽ, ഒരു `true` കണ്ടെത്തിയ ഉടൻ തന്നെ ഇത് പ്രോസസ്സിംഗ് നിർത്തും, മറ്റെന്താണ് സംഭവിച്ചതെങ്കിലും, ഫലം `true` ആയിരിക്കും.
    ///
    ///
    /// ഒരു ശൂന്യ ഇറ്ററേറ്റർ `false` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// ആദ്യ `true`-ൽ നിർത്തുന്നു:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // കൂടുതൽ ഘടകങ്ങൾ ഉള്ളതിനാൽ ഞങ്ങൾക്ക് ഇപ്പോഴും `iter` ഉപയോഗിക്കാൻ കഴിയും.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// ഒരു പ്രവചനത്തെ തൃപ്‌തിപ്പെടുത്തുന്ന ഒരു ആവർത്തന ഘടകത്തിന്റെ തിരയലുകൾ.
    ///
    /// `find()` `true` അല്ലെങ്കിൽ `false` നൽകുന്ന ഒരു അടയ്ക്കൽ എടുക്കുന്നു.
    /// ഇത് ആവർത്തനത്തിന്റെ ഓരോ ഘടകത്തിനും ഈ അടയ്ക്കൽ ബാധകമാക്കുന്നു, അവയിലേതെങ്കിലും `true` നൽകുന്നുവെങ്കിൽ, `find()` [`Some(element)`] നൽകുന്നു.
    /// എല്ലാവരും `false` നൽകുന്നുവെങ്കിൽ, അത് [`None`] നൽകുന്നു.
    ///
    /// `find()` ഷോർട്ട് സർക്യൂട്ടിംഗ്;മറ്റൊരു വിധത്തിൽ പറഞ്ഞാൽ, അടയ്ക്കൽ `true` നൽകുമ്പോൾ തന്നെ ഇത് പ്രോസസ്സിംഗ് നിർത്തും.
    ///
    /// കാരണം `find()` ഒരു റഫറൻസ് എടുക്കുന്നു, കൂടാതെ നിരവധി ഇറ്ററേറ്ററുകൾ റഫറൻസുകളിൽ ആവർത്തിക്കുന്നു, ഇത് വാദം ഇരട്ട റഫറൻസായ ആശയക്കുഴപ്പത്തിലാക്കുന്ന സാഹചര്യത്തിലേക്ക് നയിക്കുന്നു.
    ///
    /// ചുവടെയുള്ള ഉദാഹരണങ്ങളിൽ, `&&x` ഉപയോഗിച്ച് നിങ്ങൾക്ക് ഈ പ്രഭാവം കാണാൻ കഴിയും.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// ആദ്യ `true`-ൽ നിർത്തുന്നു:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // കൂടുതൽ ഘടകങ്ങൾ ഉള്ളതിനാൽ ഞങ്ങൾക്ക് ഇപ്പോഴും `iter` ഉപയോഗിക്കാൻ കഴിയും.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// `iter.find(f)` എന്നത് `iter.filter(f).next()` ന് തുല്യമാണെന്ന് ശ്രദ്ധിക്കുക.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// ഇറ്ററേറ്ററിന്റെ ഘടകങ്ങളിലേക്ക് പ്രവർത്തനം പ്രയോഗിക്കുകയും ഒന്നുമില്ലാത്ത ആദ്യ ഫലം നൽകുകയും ചെയ്യുന്നു.
    ///
    ///
    /// `iter.find_map(f)` `iter.filter_map(f).next()` ന് തുല്യമാണ്.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// ഇറ്ററേറ്ററിന്റെ ഘടകങ്ങളിലേക്ക് പ്രവർത്തനം പ്രയോഗിക്കുകയും ആദ്യത്തെ യഥാർത്ഥ ഫലം അല്ലെങ്കിൽ ആദ്യത്തെ പിശക് നൽകുകയും ചെയ്യുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// ഒരു ആവർത്തന ഘടകത്തിലെ ഒരു ഘടകത്തിനായി തിരയുന്നു, അതിന്റെ സൂചിക നൽകുന്നു.
    ///
    /// `position()` `true` അല്ലെങ്കിൽ `false` നൽകുന്ന ഒരു അടയ്ക്കൽ എടുക്കുന്നു.
    /// ഇത് ആവർത്തനത്തിന്റെ ഓരോ ഘടകത്തിനും ഈ അടയ്ക്കൽ ബാധകമാക്കുന്നു, അവയിലൊന്ന് `true` നൽകുന്നുവെങ്കിൽ, `position()` [`Some(index)`] നൽകുന്നു.
    /// അവയെല്ലാം `false` നൽകുന്നുവെങ്കിൽ, അത് [`None`] നൽകുന്നു.
    ///
    /// `position()` ഷോർട്ട് സർക്യൂട്ടിംഗ്;മറ്റൊരു വിധത്തിൽ പറഞ്ഞാൽ, ഇത് ഒരു `true` കണ്ടെത്തിയ ഉടൻ തന്നെ പ്രോസസ്സിംഗ് നിർത്തും.
    ///
    /// # ഓവർഫ്ലോ ബിഹേവിയർ
    ///
    /// ഈ രീതി ഓവർഫ്ലോകൾക്കെതിരെ കാവൽ നിൽക്കുന്നില്ല, അതിനാൽ പൊരുത്തപ്പെടാത്ത [`usize::MAX`]-ൽ കൂടുതൽ ഘടകങ്ങൾ ഉണ്ടെങ്കിൽ, അത് തെറ്റായ ഫലം നൽകുന്നു അല്ലെങ്കിൽ panics.
    ///
    /// ഡീബഗ് അവകാശവാദങ്ങൾ പ്രാപ്തമാക്കിയിട്ടുണ്ടെങ്കിൽ, ഒരു panic ഉറപ്പുനൽകുന്നു.
    ///
    /// # Panics
    ///
    /// ആവർത്തനത്തിന് `usize::MAX`-ൽ കൂടുതൽ പൊരുത്തപ്പെടാത്ത ഘടകങ്ങൾ ഉണ്ടെങ്കിൽ ഈ ഫംഗ്ഷൻ panic ആയിരിക്കാം.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// ആദ്യ `true`-ൽ നിർത്തുന്നു:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // കൂടുതൽ ഘടകങ്ങൾ ഉള്ളതിനാൽ ഞങ്ങൾക്ക് ഇപ്പോഴും `iter` ഉപയോഗിക്കാൻ കഴിയും.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // മടങ്ങിയ സൂചിക ആവർത്തന നിലയെ ആശ്രയിച്ചിരിക്കുന്നു
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// വലതുവശത്ത് നിന്ന് ഒരു ഇറ്ററേറ്ററിലെ ഒരു ഘടകത്തിനായി തിരയുന്നു, അതിന്റെ സൂചിക നൽകുന്നു.
    ///
    /// `rposition()` `true` അല്ലെങ്കിൽ `false` നൽകുന്ന ഒരു അടയ്ക്കൽ എടുക്കുന്നു.
    /// ഇത് ആവർത്തനത്തിന്റെ ഓരോ ഘടകത്തിനും അവസാനം മുതൽ ആരംഭിക്കുന്നു, അവയിലൊന്ന് `true` നൽകുന്നുവെങ്കിൽ, `rposition()` [`Some(index)`] നൽകുന്നു.
    ///
    /// അവയെല്ലാം `false` നൽകുന്നുവെങ്കിൽ, അത് [`None`] നൽകുന്നു.
    ///
    /// `rposition()` ഷോർട്ട് സർക്യൂട്ടിംഗ്;മറ്റൊരു വിധത്തിൽ പറഞ്ഞാൽ, ഇത് ഒരു `true` കണ്ടെത്തിയ ഉടൻ തന്നെ പ്രോസസ്സിംഗ് നിർത്തും.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// ആദ്യ `true`-ൽ നിർത്തുന്നു:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // കൂടുതൽ ഘടകങ്ങൾ ഉള്ളതിനാൽ ഞങ്ങൾക്ക് ഇപ്പോഴും `iter` ഉപയോഗിക്കാൻ കഴിയും.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // ഇവിടെ ഒരു ഓവർഫ്ലോ പരിശോധന ആവശ്യമില്ല, കാരണം മൂലകങ്ങളുടെ എണ്ണം ഒരു `usize`-ലേക്ക് യോജിക്കുന്നുവെന്ന് `ExactSizeIterator` സൂചിപ്പിക്കുന്നു.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// ഒരു ആവർത്തനത്തിന്റെ പരമാവധി ഘടകം നൽകുന്നു.
    ///
    /// നിരവധി ഘടകങ്ങൾ തുല്യമായി പരമാവധി ആണെങ്കിൽ, അവസാന ഘടകം തിരികെ നൽകും.
    /// ഇറ്ററേറ്റർ ശൂന്യമാണെങ്കിൽ, [`None`] തിരികെ നൽകും.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// ഒരു ആവർത്തനത്തിന്റെ ഏറ്റവും കുറഞ്ഞ ഘടകം നൽകുന്നു.
    ///
    /// നിരവധി ഘടകങ്ങൾ തുല്യമായി മിനിമം ആണെങ്കിൽ, ആദ്യ ഘടകം മടക്കിനൽകുന്നു.
    /// ഇറ്ററേറ്റർ ശൂന്യമാണെങ്കിൽ, [`None`] തിരികെ നൽകും.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// നിർദ്ദിഷ്ട ഫംഗ്‌ഷനിൽ നിന്ന് പരമാവധി മൂല്യം നൽകുന്ന ഘടകം നൽകുന്നു.
    ///
    ///
    /// നിരവധി ഘടകങ്ങൾ തുല്യമായി പരമാവധി ആണെങ്കിൽ, അവസാന ഘടകം തിരികെ നൽകും.
    /// ഇറ്ററേറ്റർ ശൂന്യമാണെങ്കിൽ, [`None`] തിരികെ നൽകും.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// നിർദ്ദിഷ്ട താരതമ്യ പ്രവർത്തനവുമായി ബന്ധപ്പെട്ട് പരമാവധി മൂല്യം നൽകുന്ന ഘടകം നൽകുന്നു.
    ///
    ///
    /// നിരവധി ഘടകങ്ങൾ തുല്യമായി പരമാവധി ആണെങ്കിൽ, അവസാന ഘടകം തിരികെ നൽകും.
    /// ഇറ്ററേറ്റർ ശൂന്യമാണെങ്കിൽ, [`None`] തിരികെ നൽകും.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// നിർദ്ദിഷ്ട ഫംഗ്‌ഷനിൽ നിന്ന് ഏറ്റവും കുറഞ്ഞ മൂല്യം നൽകുന്ന ഘടകം നൽകുന്നു.
    ///
    ///
    /// നിരവധി ഘടകങ്ങൾ തുല്യമായി മിനിമം ആണെങ്കിൽ, ആദ്യ ഘടകം മടക്കിനൽകുന്നു.
    /// ഇറ്ററേറ്റർ ശൂന്യമാണെങ്കിൽ, [`None`] തിരികെ നൽകും.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// നിർദ്ദിഷ്ട താരതമ്യ പ്രവർത്തനവുമായി ബന്ധപ്പെട്ട് ഏറ്റവും കുറഞ്ഞ മൂല്യം നൽകുന്ന ഘടകം നൽകുന്നു.
    ///
    ///
    /// നിരവധി ഘടകങ്ങൾ തുല്യമായി മിനിമം ആണെങ്കിൽ, ആദ്യ ഘടകം മടക്കിനൽകുന്നു.
    /// ഇറ്ററേറ്റർ ശൂന്യമാണെങ്കിൽ, [`None`] തിരികെ നൽകും.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// ഒരു ഇറ്ററേറ്ററിന്റെ ദിശ വിപരീതമാക്കുന്നു.
    ///
    /// സാധാരണയായി, ഇറ്ററേറ്ററുകൾ ഇടത്തുനിന്ന് വലത്തോട്ട് ആവർത്തിക്കുന്നു.
    /// `rev()` ഉപയോഗിച്ചതിന് ശേഷം, ഒരു ഇറ്ററേറ്റർ പകരം വലത്ത് നിന്ന് ഇടത്തേക്ക് ആവർത്തിക്കും.
    ///
    /// ആവർത്തനത്തിന് ഒരു അവസാനമുണ്ടെങ്കിൽ മാത്രമേ ഇത് സാധ്യമാകൂ, അതിനാൽ `rev()` [`DoubleEndedIterator`] കളിൽ മാത്രമേ പ്രവർത്തിക്കൂ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// ജോഡികളുടെ ഒരു ആവർത്തനത്തെ ഒരു ജോഡി പാത്രങ്ങളാക്കി മാറ്റുന്നു.
    ///
    /// `unzip()` ജോഡികളുടെ മുഴുവൻ ഇറ്ററേറ്ററും ഉപയോഗിക്കുന്നു, രണ്ട് ശേഖരങ്ങൾ ഉൽ‌പാദിപ്പിക്കുന്നു: ഒന്ന് ജോഡികളുടെ ഇടത് ഘടകങ്ങളിൽ നിന്ന് ഒന്ന് വലത് മൂലകങ്ങളിൽ നിന്ന്.
    ///
    ///
    /// ഈ പ്രവർത്തനം, ഒരർത്ഥത്തിൽ, [`zip`]-ന് വിപരീതമാണ്.
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// അതിന്റെ എല്ലാ ഘടകങ്ങളും പകർത്തുന്ന ഒരു ഇറ്ററേറ്റർ സൃഷ്ടിക്കുന്നു.
    ///
    /// നിങ്ങൾക്ക് `&T`-ൽ ഒരു ഇറ്ററേറ്റർ ഉള്ളപ്പോൾ ഇത് ഉപയോഗപ്രദമാണ്, പക്ഷേ നിങ്ങൾക്ക് `T`-ൽ ഒരു ഇറ്ററേറ്റർ ആവശ്യമാണ്.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // പകർത്തിയത് .map(|&x| x) ന് തുല്യമാണ്
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// [`ക്ലോൺ`] അതിന്റെ എല്ലാ ഘടകങ്ങളും ഉൾക്കൊള്ളുന്ന ഒരു ഇറ്ററേറ്റർ സൃഷ്‌ടിക്കുന്നു.
    ///
    /// നിങ്ങൾക്ക് `&T`-ൽ ഒരു ഇറ്ററേറ്റർ ഉള്ളപ്പോൾ ഇത് ഉപയോഗപ്രദമാണ്, പക്ഷേ നിങ്ങൾക്ക് `T`-ൽ ഒരു ഇറ്ററേറ്റർ ആവശ്യമാണ്.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // പൂർണ്ണസംഖ്യകൾക്കായി ക്ലോൺ ചെയ്യുന്നത് .map(|&x| x) ന് തുല്യമാണ്
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// ഒരു ആവർത്തനത്തെ അനന്തമായി ആവർത്തിക്കുന്നു.
    ///
    /// [`None`]-ൽ നിർത്തുന്നതിനുപകരം, തുടക്കം മുതൽ വീണ്ടും ആവർത്തനം ആരംഭിക്കും.വീണ്ടും ആവർത്തിച്ചതിനുശേഷം, അത് തുടക്കത്തിൽ തന്നെ ആരംഭിക്കും.പിന്നെയും.
    /// പിന്നെയും.
    /// Forever.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// ഒരു ആവർത്തനത്തിന്റെ ഘടകങ്ങൾ സംഗ്രഹിക്കുന്നു.
    ///
    /// ഓരോ ഘടകവും എടുത്ത് അവയെ ഒന്നിച്ച് ചേർത്ത് ഫലം നൽകുന്നു.
    ///
    /// ഒരു ശൂന്യ ഇറ്ററേറ്റർ തരത്തിന്റെ പൂജ്യം മൂല്യം നൽകുന്നു.
    ///
    /// # Panics
    ///
    /// `sum()`-ലേക്ക് വിളിക്കുമ്പോൾ ഒരു പ്രാകൃത സംഖ്യ തരം തിരികെ നൽകുമ്പോൾ, കണക്കുകൂട്ടൽ ഓവർഫ്ലോകളും ഡീബഗ് അവകാശവാദങ്ങളും പ്രാപ്തമാക്കിയിട്ടുണ്ടെങ്കിൽ ഈ രീതി panic ആയിരിക്കും.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// എല്ലാ ഘടകങ്ങളെയും ഗുണിച്ച് മുഴുവൻ ആവർത്തനത്തിലും ആവർത്തിക്കുന്നു
    ///
    /// ഒരു ശൂന്യ ഇറ്ററേറ്റർ തരത്തിന്റെ ഒരു മൂല്യം നൽകുന്നു.
    ///
    /// # Panics
    ///
    /// `product()`-ലേക്ക് വിളിക്കുകയും ഒരു പ്രാകൃത സംഖ്യ തരം തിരികെ നൽകുകയും ചെയ്യുമ്പോൾ, കണക്കുകൂട്ടൽ ഓവർഫ്ലോകളും ഡീബഗ് അവകാശവാദങ്ങളും പ്രാപ്തമാക്കിയിട്ടുണ്ടെങ്കിൽ രീതി panic ആയിരിക്കും.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ഈ [`Iterator`] ന്റെ ഘടകങ്ങളെ മറ്റൊന്നുമായി താരതമ്യം ചെയ്യുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) നിർദ്ദിഷ്ട താരതമ്യ പ്രവർത്തനവുമായി ബന്ധപ്പെട്ട് ഈ [`Iterator`]-ന്റെ ഘടകങ്ങളെ മറ്റൊന്നുമായി താരതമ്യം ചെയ്യുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ഈ [`Iterator`] ന്റെ ഘടകങ്ങളെ മറ്റൊന്നുമായി താരതമ്യം ചെയ്യുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) നിർദ്ദിഷ്ട താരതമ്യ പ്രവർത്തനവുമായി ബന്ധപ്പെട്ട് ഈ [`Iterator`]-ന്റെ ഘടകങ്ങളെ മറ്റൊന്നുമായി താരതമ്യം ചെയ്യുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// ഈ [`Iterator`]-ന്റെ ഘടകങ്ങൾ മറ്റൊന്നിന് തുല്യമാണോ എന്ന് നിർണ്ണയിക്കുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// നിർദ്ദിഷ്ട സമത്വ പ്രവർത്തനവുമായി ബന്ധപ്പെട്ട് ഈ [`Iterator`] ന്റെ ഘടകങ്ങൾ മറ്റൊന്നിന് തുല്യമാണോ എന്ന് നിർണ്ണയിക്കുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// ഈ [`Iterator`]-ന്റെ ഘടകങ്ങൾ മറ്റൊന്നിന്റെ അസമമാണോ എന്ന് നിർണ്ണയിക്കുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// ഈ [`Iterator`]-ന്റെ ഘടകങ്ങൾ മറ്റൊന്നിനേക്കാൾ [lexicographically](Ord#lexicographical-comparison) കുറവാണോ എന്ന് നിർണ്ണയിക്കുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// ഈ [`Iterator`]-ന്റെ ഘടകങ്ങൾ [lexicographically](Ord#lexicographical-comparison) കുറവോ മറ്റൊന്നിന് തുല്യമോ എന്ന് നിർണ്ണയിക്കുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// ഈ [`Iterator`]-ന്റെ ഘടകങ്ങൾ മറ്റൊന്നിനേക്കാൾ [lexicographically](Ord#lexicographical-comparison) വലുതാണോ എന്ന് നിർണ്ണയിക്കുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// ഈ [`Iterator`]-ന്റെ ഘടകങ്ങൾ [lexicographically](Ord#lexicographical-comparison) മറ്റൊന്നിനേക്കാൾ വലുതോ തുല്യമോ ആണോ എന്ന് നിർണ്ണയിക്കുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// ഈ ആവർത്തനത്തിന്റെ ഘടകങ്ങൾ അടുക്കിയിട്ടുണ്ടോയെന്ന് പരിശോധിക്കുന്നു.
    ///
    /// അതായത്, ഓരോ ഘടകത്തിനും `a` നും അതിന്റെ ഇനിപ്പറയുന്ന ഘടകമായ `b` നും, `a <= b` കൈവശം വയ്ക്കണം.ആവർത്തനം കൃത്യമായി പൂജ്യമോ ഒരു ഘടകമോ നൽകുന്നുവെങ്കിൽ, `true` തിരികെ നൽകും.
    ///
    /// `Self::Item` എന്നത് `PartialOrd` മാത്രമാണെങ്കിലും `Ord` അല്ലെങ്കിൽ, മുകളിലുള്ള നിർവചനം സൂചിപ്പിക്കുന്നത് തുടർച്ചയായ രണ്ട് ഇനങ്ങളും താരതമ്യപ്പെടുത്താൻ കഴിയുന്നില്ലെങ്കിൽ ഈ ഫംഗ്ഷൻ `false` നൽകുന്നു എന്നാണ്.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// തന്നിരിക്കുന്ന താരതമ്യ പ്രവർത്തനം ഉപയോഗിച്ച് ഈ ആവർത്തനത്തിന്റെ ഘടകങ്ങൾ അടുക്കിയിട്ടുണ്ടോയെന്ന് പരിശോധിക്കുന്നു.
    ///
    /// `PartialOrd::partial_cmp` ഉപയോഗിക്കുന്നതിനുപകരം, രണ്ട് ഘടകങ്ങളുടെ ക്രമം നിർണ്ണയിക്കാൻ ഈ ഫംഗ്ഷൻ തന്നിരിക്കുന്ന `compare` ഫംഗ്ഷൻ ഉപയോഗിക്കുന്നു.
    /// അതിനുപുറമെ, ഇത് [`is_sorted`] ന് തുല്യമാണ്;കൂടുതൽ വിവരങ്ങൾക്ക് അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// തന്നിരിക്കുന്ന കീ എക്സ്ട്രാക്ഷൻ ഫംഗ്ഷൻ ഉപയോഗിച്ച് ഈ ഇറ്ററേറ്ററിന്റെ ഘടകങ്ങൾ അടുക്കിയിട്ടുണ്ടോയെന്ന് പരിശോധിക്കുന്നു.
    ///
    /// ഇറ്ററേറ്ററിന്റെ ഘടകങ്ങളെ നേരിട്ട് താരതമ്യം ചെയ്യുന്നതിനുപകരം, ഈ പ്രവർത്തനം മൂലകങ്ങളുടെ കീകളെ താരതമ്യം ചെയ്യുന്നു, `f` നിർണ്ണയിക്കുന്നു.
    /// അതിനുപുറമെ, ഇത് [`is_sorted`] ന് തുല്യമാണ്;കൂടുതൽ വിവരങ്ങൾക്ക് അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// [TrustedRandomAccess] കാണുക
    // രീതി റെസല്യൂഷനിൽ പേര് കൂട്ടിയിടി ഒഴിവാക്കുക എന്നതാണ് അസാധാരണമായ പേര് #76479 കാണുക.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}