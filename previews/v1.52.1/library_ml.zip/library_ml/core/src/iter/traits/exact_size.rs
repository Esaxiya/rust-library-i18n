/// അതിന്റെ കൃത്യമായ ദൈർഘ്യം അറിയുന്ന ഒരു ഇറ്ററേറ്റർ.
///
/// പല [`ഇറ്ററേറ്ററിനും] അവർ എത്ര തവണ ആവർത്തിക്കുമെന്ന് അറിയില്ല, പക്ഷേ ചിലത്.
/// ഒരു ആവർത്തനത്തിന് എത്ര തവണ ആവർത്തിക്കാമെന്ന് അറിയാമെങ്കിൽ, ആ വിവരങ്ങളിലേക്ക് പ്രവേശനം നൽകുന്നത് ഉപയോഗപ്രദമാകും.
/// ഉദാഹരണത്തിന്, നിങ്ങൾ‌ക്ക് പിന്നിലേക്ക്‌ആവർത്തിക്കാൻ‌താൽ‌പ്പര്യമുണ്ടെങ്കിൽ‌, അവസാനം എവിടെയാണെന്ന് അറിയുക എന്നതാണ് ഒരു നല്ല തുടക്കം.
///
/// ഒരു `ExactSizeIterator` നടപ്പിലാക്കുമ്പോൾ, നിങ്ങൾ [`Iterator`] ഉം നടപ്പിലാക്കണം.
/// അങ്ങനെ ചെയ്യുമ്പോൾ, [`Iterator::size_hint`]*നടപ്പിലാക്കുന്നത്* ആവർത്തനത്തിന്റെ കൃത്യമായ വലുപ്പം നൽകണം.
///
/// [`len`] രീതിക്ക് ഒരു സ്ഥിരസ്ഥിതി നടപ്പാക്കൽ ഉണ്ട്, അതിനാൽ നിങ്ങൾ സാധാരണയായി ഇത് നടപ്പിലാക്കരുത്.
/// എന്നിരുന്നാലും, സ്ഥിരസ്ഥിതിയേക്കാൾ കൂടുതൽ പ്രകടനം നടപ്പിലാക്കാൻ നിങ്ങൾക്ക് കഴിഞ്ഞേക്കും, അതിനാൽ ഈ സാഹചര്യത്തിൽ ഇത് അസാധുവാക്കുന്നത് അർത്ഥമാക്കുന്നു.
///
///
/// ഈ trait ഒരു സുരക്ഷിത trait ആണെന്നും അതിനാൽ മടക്കിനൽകിയ ദൈർഘ്യം ശരിയാണെന്ന് *ഉറപ്പുനൽകുന്നില്ലെന്നും* ഉറപ്പുനൽകുന്നില്ലെന്നും ശ്രദ്ധിക്കുക.
/// ഇതിനർത്ഥം `unsafe` കോഡ് **[`Iterator::size_hint`]-ന്റെ കൃത്യതയെ ആശ്രയിക്കരുത്** എന്നാണ്.
/// അസ്ഥിരവും സുരക്ഷിതമല്ലാത്തതുമായ [`TrustedLen`](super::marker::TrustedLen) trait ഈ അധിക ഗ്യാരണ്ടി നൽകുന്നു.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// അടിസ്ഥാന ഉപയോഗം:
///
/// ```
/// // ഒരു പരിധിക്ക് അത് എത്ര തവണ ആവർത്തിക്കുമെന്ന് കൃത്യമായി അറിയാം
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// [module-level docs]-ൽ, ഞങ്ങൾ ഒരു [`Iterator`] നടപ്പിലാക്കി, `Counter`.
/// ഇതിനായി `ExactSizeIterator` നടപ്പിലാക്കാം:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // ശേഷിക്കുന്ന ആവർത്തനങ്ങളുടെ എണ്ണം നമുക്ക് എളുപ്പത്തിൽ കണക്കാക്കാം.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // ഇപ്പോൾ നമുക്ക് ഇത് ഉപയോഗിക്കാൻ കഴിയും!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// ആവർത്തനത്തിന്റെ കൃത്യമായ ദൈർഘ്യം നൽകുന്നു.
    ///
    /// [`None`] മടങ്ങുന്നതിന് മുമ്പ്, ആവർത്തനം ഒരു [`Some(T)`] മൂല്യത്തിന്റെ `len()` മടങ്ങ് കൂടുതൽ മടക്കിനൽകുമെന്ന് നടപ്പാക്കൽ ഉറപ്പാക്കുന്നു.
    ///
    /// ഈ രീതിക്ക് ഒരു സ്ഥിരസ്ഥിതി നടപ്പാക്കൽ ഉണ്ട്, അതിനാൽ നിങ്ങൾ ഇത് നേരിട്ട് നടപ്പിലാക്കരുത്.
    /// എന്നിരുന്നാലും, നിങ്ങൾക്ക് കൂടുതൽ കാര്യക്ഷമമായ നടപ്പാക്കൽ നൽകാൻ കഴിയുമെങ്കിൽ, നിങ്ങൾക്ക് അത് ചെയ്യാൻ കഴിയും.
    /// ഒരു ഉദാഹരണത്തിനായി [trait-level] ഡോക്സ് കാണുക.
    ///
    /// ഈ ഫംഗ്ഷന് [`Iterator::size_hint`] ഫംഗ്ഷന് സമാനമായ സുരക്ഷാ ഗ്യാരണ്ടികളുണ്ട്.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// // ഒരു പരിധിക്ക് അത് എത്ര തവണ ആവർത്തിക്കുമെന്ന് കൃത്യമായി അറിയാം
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: ഈ വാദം അമിതമായി പ്രതിരോധാത്മകമാണ്, പക്ഷേ ഇത് മാറ്റത്തെ പരിശോധിക്കുന്നു
        // trait ഉറപ്പുനൽകുന്നു.
        // ഈ trait rust-ആന്തരികമാണെങ്കിൽ, ഞങ്ങൾക്ക് debug_assert ഉപയോഗിക്കാം;assert_eq!എല്ലാ Rust ഉപയോക്തൃ നടപ്പാക്കലുകളും പരിശോധിക്കും.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// ഇറ്ററേറ്റർ ശൂന്യമാണെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// ഈ രീതിക്ക് [`ExactSizeIterator::len()`] ഉപയോഗിച്ച് ഒരു സ്ഥിരസ്ഥിതി നടപ്പാക്കൽ ഉണ്ട്, അതിനാൽ നിങ്ങൾ ഇത് സ്വയം നടപ്പിലാക്കേണ്ടതില്ല.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}