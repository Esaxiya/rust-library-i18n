/// ഒരു [`Iterator`]-ൽ നിന്നുള്ള പരിവർത്തനം.
///
/// ഒരു തരത്തിനായി `FromIterator` നടപ്പിലാക്കുന്നതിലൂടെ, ഒരു ഇറ്ററേറ്ററിൽ നിന്ന് ഇത് എങ്ങനെ സൃഷ്ടിക്കപ്പെടുമെന്ന് നിങ്ങൾ നിർവചിക്കുന്നു.
/// ഏതെങ്കിലും തരത്തിലുള്ള ശേഖരം വിവരിക്കുന്ന തരങ്ങൾക്ക് ഇത് സാധാരണമാണ്.
///
/// [`FromIterator::from_iter()`] അപൂർവ്വമായി സ്പഷ്ടമായി വിളിക്കുന്നു, പകരം [`Iterator::collect()`] രീതിയിലൂടെ ഉപയോഗിക്കുന്നു.
///
/// കൂടുതൽ ഉദാഹരണങ്ങൾക്ക് [`Iterator::collect()`]'s ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// ഇതും കാണുക: [`IntoIterator`].
///
/// # Examples
///
/// അടിസ്ഥാന ഉപയോഗം:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// `FromIterator` എന്നത് വ്യക്തമായി ഉപയോഗിക്കുന്നതിന് [`Iterator::collect()`] ഉപയോഗിക്കുന്നു:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// നിങ്ങളുടെ തരത്തിനായി `FromIterator` നടപ്പിലാക്കുന്നു:
///
/// ```
/// use std::iter::FromIterator;
///
/// // ഒരു സാമ്പിൾ ശേഖരം, അത് വെക്കിനു മുകളിലുള്ള ഒരു റാപ്പർ മാത്രമാണ്<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // നമുക്ക് ഇതിന് ചില രീതികൾ നൽകാം, അതുവഴി നമുക്ക് ഒരെണ്ണം സൃഷ്ടിക്കാനും അതിലേക്ക് കാര്യങ്ങൾ ചേർക്കാനും കഴിയും.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ഞങ്ങൾ ഫ്രംഇറ്ററേറ്റർ നടപ്പിലാക്കും
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // ഇപ്പോൾ നമുക്ക് ഒരു പുതിയ ആവർത്തനമുണ്ടാക്കാം ...
/// let iter = (0..5).into_iter();
///
/// // ... അതിൽ നിന്ന് ഒരു മൈ ശേഖരം ഉണ്ടാക്കുക
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // സൃഷ്ടികളും ശേഖരിക്കുക!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// ഒരു ഇറ്ററേറ്ററിൽ നിന്ന് ഒരു മൂല്യം സൃഷ്ടിക്കുന്നു.
    ///
    /// കൂടുതൽ വിവരങ്ങൾക്ക് [module-level documentation] കാണുക.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// ഒരു [`Iterator`]-ലേക്ക് പരിവർത്തനം.
///
/// ഒരു തരത്തിനായി `IntoIterator` നടപ്പിലാക്കുന്നതിലൂടെ, ഇത് എങ്ങനെ ഒരു ഇറ്ററേറ്ററിലേക്ക് പരിവർത്തനം ചെയ്യുമെന്ന് നിങ്ങൾ നിർവചിക്കുന്നു.
/// ഏതെങ്കിലും തരത്തിലുള്ള ശേഖരം വിവരിക്കുന്ന തരങ്ങൾക്ക് ഇത് സാധാരണമാണ്.
///
/// `IntoIterator` നടപ്പിലാക്കുന്നതിന്റെ ഒരു പ്രയോജനം നിങ്ങളുടെ തരം [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator) ആയിരിക്കും എന്നതാണ്.
///
///
/// ഇതും കാണുക: [`FromIterator`].
///
/// # Examples
///
/// അടിസ്ഥാന ഉപയോഗം:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// നിങ്ങളുടെ തരത്തിനായി `IntoIterator` നടപ്പിലാക്കുന്നു:
///
/// ```
/// // ഒരു സാമ്പിൾ ശേഖരം, അത് വെക്കിനു മുകളിലുള്ള ഒരു റാപ്പർ മാത്രമാണ്<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // നമുക്ക് ഇതിന് ചില രീതികൾ നൽകാം, അതുവഴി നമുക്ക് ഒരെണ്ണം സൃഷ്ടിക്കാനും അതിലേക്ക് കാര്യങ്ങൾ ചേർക്കാനും കഴിയും.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ഞങ്ങൾ IntoIterator നടപ്പിലാക്കും
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // ഇപ്പോൾ നമുക്ക് ഒരു പുതിയ ശേഖരം സൃഷ്ടിക്കാൻ കഴിയും ...
/// let mut c = MyCollection::new();
///
/// // ... ഇതിലേക്ക് കുറച്ച് സ്റ്റഫ് ചേർക്കുക ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... എന്നിട്ട് അതിനെ ഒരു ഇറ്ററേറ്ററായി മാറ്റുക:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// `IntoIterator` ഒരു trait bound ആയി ഉപയോഗിക്കുന്നത് സാധാരണമാണ്.ഇൻപുട്ട് ശേഖരണ തരം മാറ്റാൻ ഇത് അനുവദിക്കുന്നു, അത് ഇപ്പോഴും ഒരു ആവർത്തനക്കാരനാണ്.
/// പരിമിതപ്പെടുത്തിക്കൊണ്ട് അധിക അതിർത്തികൾ വ്യക്തമാക്കാൻ കഴിയും
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// ആവർത്തിക്കുന്ന മൂലകങ്ങളുടെ തരം.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// ഏത് തരം ഇറ്ററേറ്ററാണ് ഞങ്ങൾ ഇത് മാറ്റുന്നത്?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// ഒരു മൂല്യത്തിൽ നിന്ന് ഒരു ഇറ്ററേറ്റർ സൃഷ്ടിക്കുന്നു.
    ///
    /// കൂടുതൽ വിവരങ്ങൾക്ക് [module-level documentation] കാണുക.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// ഒരു ആവർത്തനത്തിന്റെ ഉള്ളടക്കങ്ങൾ ഉപയോഗിച്ച് ഒരു ശേഖരം വിപുലീകരിക്കുക.
///
/// ഇറ്ററേറ്ററുകൾ മൂല്യങ്ങളുടെ ഒരു ശ്രേണി സൃഷ്ടിക്കുന്നു, മാത്രമല്ല ശേഖരങ്ങളെ മൂല്യങ്ങളുടെ ഒരു ശ്രേണിയായി കണക്കാക്കാം.
/// `Extend` trait ഈ വിടവ് നികത്തുന്നു, ആ ഇറ്ററേറ്ററിലെ ഉള്ളടക്കങ്ങൾ ഉൾപ്പെടുത്തി ഒരു ശേഖരം വിപുലീകരിക്കാൻ നിങ്ങളെ അനുവദിക്കുന്നു.
/// ഇതിനകം നിലവിലുള്ള ഒരു കീ ഉപയോഗിച്ച് ഒരു ശേഖരം വിപുലീകരിക്കുമ്പോൾ, ആ എൻ‌ട്രി അപ്‌ഡേറ്റുചെയ്യുന്നു അല്ലെങ്കിൽ തുല്യ കീകളുള്ള ഒന്നിലധികം എൻ‌ട്രികൾ‌അനുവദിക്കുന്ന ശേഖരങ്ങളുടെ കാര്യത്തിൽ, ആ എൻ‌ട്രി ചേർ‌ത്തു.
///
///
/// # Examples
///
/// അടിസ്ഥാന ഉപയോഗം:
///
/// ```
/// // ചില പ്രതീകങ്ങൾ ഉപയോഗിച്ച് നിങ്ങൾക്ക് ഒരു സ്ട്രിംഗ് വിപുലീകരിക്കാൻ കഴിയും:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// `Extend` നടപ്പിലാക്കുന്നു:
///
/// ```
/// // ഒരു സാമ്പിൾ ശേഖരം, അത് വെക്കിനു മുകളിലുള്ള ഒരു റാപ്പർ മാത്രമാണ്<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // നമുക്ക് ഇതിന് ചില രീതികൾ നൽകാം, അതുവഴി നമുക്ക് ഒരെണ്ണം സൃഷ്ടിക്കാനും അതിലേക്ക് കാര്യങ്ങൾ ചേർക്കാനും കഴിയും.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // MyCollection ന് i32-കളുടെ ഒരു ലിസ്റ്റ് ഉള്ളതിനാൽ, ഞങ്ങൾ i32-നായി വിപുലീകരിക്കുക നടപ്പിലാക്കുന്നു
/// impl Extend<i32> for MyCollection {
///
///     // കോൺക്രീറ്റ് ടൈപ്പ് സിഗ്‌നേച്ചർ ഉപയോഗിച്ച് ഇത് അൽപ്പം ലളിതമാണ്: നമുക്ക് ഒരു ഐറ്ററേറ്ററാക്കി മാറ്റാൻ കഴിയുന്ന എന്തിനേയും എക്സ്റ്റെൻഡഡ് എന്ന് വിളിക്കാം, അത് ഞങ്ങൾക്ക് i32s നൽകുന്നു.
///     // കാരണം MyCollection-ൽ ഉൾപ്പെടുത്താൻ ഞങ്ങൾക്ക് i32s ആവശ്യമാണ്.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // നടപ്പിലാക്കൽ വളരെ നേരായതാണ്: ഇറ്ററേറ്ററിലൂടെ ലൂപ്പ് ചെയ്യുക, ഓരോ ഘടകങ്ങളും എക്സ് 100 എക്സ്.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // മൂന്ന് എണ്ണം കൂടി ഉപയോഗിച്ച് ഞങ്ങളുടെ ശേഖരം വിപുലീകരിക്കാം
/// c.extend(vec![1, 2, 3]);
///
/// // ഞങ്ങൾ ഈ ഘടകങ്ങൾ അവസാനം ചേർത്തു
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// ഒരു ആവർത്തന ഉള്ളടക്കവുമായി ഒരു ശേഖരം വിപുലീകരിക്കുന്നു.
    ///
    /// ഈ trait-ന് ആവശ്യമായ ഒരേയൊരു രീതി ഇതാണ് എന്നതിനാൽ, [trait-level] ഡോക്സിൽ കൂടുതൽ വിശദാംശങ്ങൾ അടങ്ങിയിരിക്കുന്നു.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// // ചില പ്രതീകങ്ങൾ ഉപയോഗിച്ച് നിങ്ങൾക്ക് ഒരു സ്ട്രിംഗ് വിപുലീകരിക്കാൻ കഴിയും:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// കൃത്യമായി ഒരു ഘടകമുള്ള ഒരു ശേഖരം വിപുലീകരിക്കുന്നു.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// നൽകിയിരിക്കുന്ന അധിക ഘടകങ്ങളുടെ ശേഖരത്തിൽ ശേഷി കരുതിവച്ചിരിക്കുന്നു.
    ///
    /// സ്ഥിരസ്ഥിതി നടപ്പാക്കൽ ഒന്നും ചെയ്യുന്നില്ല.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}