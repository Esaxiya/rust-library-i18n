use crate::ops::{ControlFlow, Try};

/// രണ്ട് അറ്റത്തുനിന്നും ഘടകങ്ങൾ നൽകാൻ ഒരു ഇറ്ററേറ്ററിന് കഴിയും.
///
/// `DoubleEndedIterator` നടപ്പിലാക്കുന്ന എന്തെങ്കിലുമൊക്കെ [`Iterator`] നടപ്പിലാക്കുന്ന ഒന്നിനെക്കാൾ ഒരു അധിക ശേഷി ഉണ്ട്: `ഇനം` പുറകിൽ നിന്നും മുൻ‌ഭാഗത്തുനിന്നും എടുക്കാനുള്ള കഴിവ്.
///
///
/// മുന്നോട്ടും പിന്നോട്ടും ഒരേ ശ്രേണിയിൽ പ്രവർത്തിക്കുന്നുവെന്നത് ശ്രദ്ധിക്കേണ്ടതാണ്, അവ മറികടക്കരുത്: മധ്യത്തിൽ കണ്ടുമുട്ടുമ്പോൾ ആവർത്തനം അവസാനിക്കുന്നു.
///
/// [`Iterator`] പ്രോട്ടോക്കോളിന് സമാനമായ രീതിയിൽ, ഒരു `DoubleEndedIterator` ഒരു [`next_back()`]-ൽ നിന്ന് [`None`] മടക്കിനൽകുമ്പോൾ, അതിനെ വീണ്ടും വിളിക്കുന്നത് [`Some`] വീണ്ടും നൽകില്ല അല്ലെങ്കിൽ വരില്ല.
/// [`next()`] ഒപ്പം [`next_back()`] ഉം ഈ ആവശ്യത്തിനായി പരസ്പരം മാറ്റാവുന്നവയാണ്.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// അടിസ്ഥാന ഉപയോഗം:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// ആവർത്തനത്തിന്റെ അവസാനത്തിൽ നിന്ന് ഒരു ഘടകം നീക്കംചെയ്യുകയും തിരികെ നൽകുകയും ചെയ്യുന്നു.
    ///
    /// കൂടുതൽ ഘടകങ്ങളില്ലാത്തപ്പോൾ `None` നൽകുന്നു.
    ///
    /// [trait-level] ഡോക്സിൽ കൂടുതൽ വിശദാംശങ്ങൾ അടങ്ങിയിരിക്കുന്നു.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// `DoubleEndedIterator` ന്റെ രീതികൾ‌നൽ‌കുന്ന ഘടകങ്ങൾ‌[`Iterator`] ന്റെ രീതികളിൽ‌നിന്നും വ്യത്യസ്തമായിരിക്കും:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// `n` ഘടകങ്ങൾ പിന്നിൽ നിന്ന് ഇറ്ററേറ്ററിനെ മുന്നേറുന്നു.
    ///
    /// `advance_back_by` [`advance_by`]-ന്റെ വിപരീത പതിപ്പാണ്.[`None`] നേരിടുന്നതുവരെ [`next_back`] വരെ [`next_back`] വരെ വിളിച്ചുകൊണ്ട് `n` ഘടകങ്ങൾ പിന്നിൽ നിന്ന് ആരംഭിക്കുന്ന ഈ രീതി ആകാംക്ഷയോടെ ഒഴിവാക്കും.
    ///
    /// `advance_back_by(n)` `n` ഘടകങ്ങൾ വിജയകരമായി മുന്നേറുകയാണെങ്കിൽ [`Ok(())`], അല്ലെങ്കിൽ [`None`] നേരിട്ടാൽ [`Err(k)`], ഇവിടെ `k` എന്നത് മൂലകങ്ങൾ തീരുന്നതിന് മുമ്പ് ആവർത്തനം വികസിപ്പിച്ച ഘടകങ്ങളുടെ എണ്ണമാണ് (അതായത്
    /// ആവർത്തനത്തിന്റെ നീളം).
    /// `k` എല്ലായ്പ്പോഴും `n` നേക്കാൾ കുറവാണെന്ന് ശ്രദ്ധിക്കുക.
    ///
    /// `advance_back_by(0)` എന്ന് വിളിക്കുന്നത് ഏതെങ്കിലും ഘടകങ്ങളെ ഉപയോഗിക്കുന്നില്ല, മാത്രമല്ല എല്ലായ്പ്പോഴും [`Ok(())`] നൽകുന്നു.
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // `&3` മാത്രം ഒഴിവാക്കി
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// ആവർത്തനത്തിന്റെ അവസാനത്തിൽ നിന്ന് `n` മത്തെ ഘടകം നൽകുന്നു.
    ///
    /// ഇത് അടിസ്ഥാനപരമായി [`Iterator::nth()`]-ന്റെ വിപരീത പതിപ്പാണ്.
    /// മിക്ക ഇൻഡെക്സിംഗ് പ്രവർത്തനങ്ങളെയും പോലെ, എണ്ണം പൂജ്യത്തിൽ നിന്നാണ് ആരംഭിക്കുന്നത്, അതിനാൽ `nth_back(0)` ആദ്യ മൂല്യം അവസാനം മുതൽ നൽകുന്നു, രണ്ടാമത്തേത് `nth_back(1)`, അങ്ങനെ.
    ///
    ///
    /// മടങ്ങിയെത്തിയ മൂലകം ഉൾപ്പെടെ, അവസാനവും മടങ്ങിയ ഘടകവും തമ്മിലുള്ള എല്ലാ ഘടകങ്ങളും ഉപയോഗിക്കുമെന്ന് ശ്രദ്ധിക്കുക.
    /// ഒരേ ഇറ്ററേറ്ററിൽ `nth_back(0)` ഒന്നിലധികം തവണ വിളിക്കുന്നത് വ്യത്യസ്ത ഘടകങ്ങൾ നൽകുമെന്നും ഇതിനർത്ഥം.
    ///
    /// `nth_back()` `n` ആവർത്തനത്തിന്റെ നീളത്തേക്കാൾ വലുതോ തുല്യമോ ആണെങ്കിൽ [`None`] നൽകും.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// `nth_back()` നെ ഒന്നിലധികം തവണ വിളിക്കുന്നത് ആവർത്തനത്തെ റിവൈൻഡ് ചെയ്യുന്നില്ല:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// `n + 1`-ൽ താഴെ ഘടകങ്ങൾ ഉണ്ടെങ്കിൽ `None` നൽകുന്നു:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// ഇത് [`Iterator::try_fold()`]-ന്റെ വിപരീത പതിപ്പാണ്: ഇത് ആവർത്തനത്തിന്റെ പിന്നിൽ നിന്ന് ആരംഭിക്കുന്ന ഘടകങ്ങൾ എടുക്കുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // ഇത് ഷോർട്ട് സർക്യൂട്ട് ചെയ്തതിനാൽ, ശേഷിക്കുന്ന ഘടകങ്ങൾ ഇപ്പോഴും ആവർത്തനത്തിലൂടെ ലഭ്യമാണ്.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// പിന്നിൽ നിന്ന് ആരംഭിച്ച് ആവർത്തന ഘടകങ്ങളെ ഒരൊറ്റ അന്തിമ മൂല്യത്തിലേക്ക് കുറയ്ക്കുന്ന ഒരു ആവർത്തന രീതി.
    ///
    /// ഇത് [`Iterator::fold()`]-ന്റെ വിപരീത പതിപ്പാണ്: ഇത് ആവർത്തനത്തിന്റെ പിന്നിൽ നിന്ന് ആരംഭിക്കുന്ന ഘടകങ്ങൾ എടുക്കുന്നു.
    ///
    /// `rfold()` രണ്ട് ആർ‌ഗ്യുമെൻറുകൾ‌എടുക്കുന്നു: ഒരു പ്രാരംഭ മൂല്യം, രണ്ട് ആർ‌ഗ്യുമെൻറുകൾ‌അടയ്‌ക്കൽ: ഒരു 'accumulator', ഒരു ഘടകം.
    /// അടുത്ത ആവർത്തനത്തിനായി സഞ്ചിതർക്ക് ഉണ്ടായിരിക്കേണ്ട മൂല്യം അടയ്ക്കൽ നൽകുന്നു.
    ///
    /// ആദ്യ കോളിൽ സഞ്ചിതർക്ക് ഉണ്ടായിരിക്കേണ്ട മൂല്യമാണ് പ്രാരംഭ മൂല്യം.
    ///
    /// ആവർത്തനത്തിന്റെ എല്ലാ ഘടകങ്ങളിലും ഈ അടയ്ക്കൽ പ്രയോഗിച്ചതിന് ശേഷം, `rfold()` ശേഖരിക്കൽ നൽകുന്നു.
    ///
    /// ഈ പ്രവർത്തനത്തെ ചിലപ്പോൾ 'reduce' അല്ലെങ്കിൽ 'inject' എന്ന് വിളിക്കുന്നു.
    ///
    /// നിങ്ങൾക്ക് എന്തെങ്കിലും ശേഖരം ഉള്ളപ്പോഴെല്ലാം മടക്കിക്കളയൽ ഉപയോഗപ്രദമാണ്, അതിൽ നിന്ന് ഒരൊറ്റ മൂല്യം സൃഷ്ടിക്കാൻ ആഗ്രഹിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // a ന്റെ എല്ലാ ഘടകങ്ങളുടെയും ആകെത്തുക
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// ഈ ഉദാഹരണം ഒരു സ്‌ട്രിംഗ് നിർമ്മിക്കുന്നു, ഒരു പ്രാരംഭ മൂല്യത്തിൽ ആരംഭിച്ച് ഓരോ ഘടകവും പിന്നിൽ നിന്ന് മുൻവശത്തേക്ക് തുടരുന്നു:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// ഒരു പ്രവചനത്തെ തൃപ്‌തിപ്പെടുത്തുന്ന പിന്നിൽ നിന്ന് ഒരു ആവർത്തന ഘടകത്തിന്റെ തിരയലുകൾ.
    ///
    /// `rfind()` `true` അല്ലെങ്കിൽ `false` നൽകുന്ന ഒരു അടയ്ക്കൽ എടുക്കുന്നു.
    /// ഇത് ആവർത്തനത്തിന്റെ ഓരോ ഘടകത്തിനും അവസാനം മുതൽ ആരംഭിക്കുന്നു, അവയിലേതെങ്കിലും `true` നൽകുന്നുവെങ്കിൽ, `rfind()` [`Some(element)`] നൽകുന്നു.
    /// എല്ലാവരും `false` നൽകുന്നുവെങ്കിൽ, അത് [`None`] നൽകുന്നു.
    ///
    /// `rfind()` ഷോർട്ട് സർക്യൂട്ടിംഗ്;മറ്റൊരു വിധത്തിൽ പറഞ്ഞാൽ, അടയ്ക്കൽ `true` നൽകുമ്പോൾ തന്നെ ഇത് പ്രോസസ്സിംഗ് നിർത്തും.
    ///
    /// കാരണം `rfind()` ഒരു റഫറൻസ് എടുക്കുന്നു, കൂടാതെ നിരവധി ഇറ്ററേറ്ററുകൾ റഫറൻസുകളിൽ ആവർത്തിക്കുന്നു, ഇത് വാദം ഇരട്ട റഫറൻസായ ആശയക്കുഴപ്പത്തിലാക്കുന്ന സാഹചര്യത്തിലേക്ക് നയിക്കുന്നു.
    ///
    /// ചുവടെയുള്ള ഉദാഹരണങ്ങളിൽ, `&&x` ഉപയോഗിച്ച് നിങ്ങൾക്ക് ഈ പ്രഭാവം കാണാൻ കഴിയും.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// ആദ്യ `true`-ൽ നിർത്തുന്നു:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // കൂടുതൽ ഘടകങ്ങൾ ഉള്ളതിനാൽ ഞങ്ങൾക്ക് ഇപ്പോഴും `iter` ഉപയോഗിക്കാൻ കഴിയും.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}