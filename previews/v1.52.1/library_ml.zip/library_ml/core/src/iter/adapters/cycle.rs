use crate::{iter::FusedIterator, ops::Try};

/// അനന്തമായി ആവർത്തിക്കുന്ന ഒരു ആവർത്തനം.
///
/// [`Iterator`]-ലെ [`cycle`] രീതി ഉപയോഗിച്ചാണ് ഈ `struct` സൃഷ്ടിച്ചിരിക്കുന്നത്.
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// [`cycle`]: Iterator::cycle
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Cycle<I> {
    orig: I,
    iter: I,
}

impl<I: Clone> Cycle<I> {
    pub(in crate::iter) fn new(iter: I) -> Cycle<I> {
        Cycle { orig: iter.clone(), iter }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> Iterator for Cycle<I>
where
    I: Clone + Iterator,
{
    type Item = <I as Iterator>::Item;

    #[inline]
    fn next(&mut self) -> Option<<I as Iterator>::Item> {
        match self.iter.next() {
            None => {
                self.iter = self.orig.clone();
                self.iter.next()
            }
            y => y,
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        // സൈക്കിൾ ആവർത്തനം ശൂന്യമോ അനന്തമോ ആണ്
        match self.orig.size_hint() {
            sz @ (0, Some(0)) => sz,
            (0, _) => (0, None),
            _ => (usize::MAX, None),
        }
    }

    #[inline]
    fn try_fold<Acc, F, R>(&mut self, mut acc: Acc, mut f: F) -> R
    where
        F: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        // നിലവിലെ ആവർത്തനത്തെ പൂർണ്ണമായും ആവർത്തിക്കുക.
        // ഇത് ആവശ്യമാണ് കാരണം `self.orig` ഇല്ലാത്തപ്പോൾ പോലും `self.iter` ശൂന്യമായിരിക്കാം
        acc = self.iter.try_fold(acc, &mut f)?;
        self.iter = self.orig.clone();

        // സൈക്കിൾ ചെയ്ത ഇറ്ററേറ്റർ ശൂന്യമാണോ അല്ലയോ എന്ന് സൂക്ഷിച്ച് ഒരു പൂർണ്ണ ചക്രം പൂർത്തിയാക്കുക.
        // അനന്തമായ ലൂപ്പ് തടയുന്നതിന് ശൂന്യമായ ഇറ്ററേറ്ററിന്റെ കാര്യത്തിൽ ഞങ്ങൾ നേരത്തെ മടങ്ങേണ്ടതുണ്ട്
        //
        let mut is_empty = true;
        acc = self.iter.try_fold(acc, |acc, x| {
            is_empty = false;
            f(acc, x)
        })?;

        if is_empty {
            return try { acc };
        }

        loop {
            self.iter = self.orig.clone();
            acc = self.iter.try_fold(acc, &mut f)?;
        }
    }

    // `fold` ഓവർറൈഡ് ഇല്ല, കാരണം `fold` ന് `Cycle`-ന് കൂടുതൽ അർത്ഥമില്ല, മാത്രമല്ല സ്ഥിരസ്ഥിതിയേക്കാൾ മികച്ചതായി ഞങ്ങൾക്ക് ഒന്നും ചെയ്യാൻ കഴിയില്ല.
    //
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I> FusedIterator for Cycle<I> where I: Clone + Iterator {}