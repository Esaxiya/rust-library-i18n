use crate::iter::{adapters::SourceIter, FusedIterator, InPlaceIterable, TrustedLen};
use crate::ops::Try;

/// അടുത്ത ഘടകത്തിലേക്ക് ഒരു ഓപ്‌ഷണൽ റഫറൻസ് നൽകുന്ന `peek()` ഉള്ള ഒരു ഇറ്ററേറ്റർ.
///
///
/// [`Iterator`]-ലെ [`peekable`] രീതി ഉപയോഗിച്ചാണ് ഈ `struct` സൃഷ്ടിച്ചിരിക്കുന്നത്.
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// [`peekable`]: Iterator::peekable
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Peekable<I: Iterator> {
    iter: I,
    /// ഒന്നുമില്ലെങ്കിലും ഒരു എത്തിനോക്കിയ മൂല്യം ഓർക്കുക.
    peeked: Option<Option<I::Item>>,
}

impl<I: Iterator> Peekable<I> {
    pub(in crate::iter) fn new(iter: I) -> Peekable<I> {
        Peekable { iter, peeked: None }
    }
}

// `.peek()` രീതിയിൽ ഒന്നും കണ്ടില്ലെങ്കിൽ പീക്ക് ചെയ്യാവുന്ന കാര്യം ഓർമ്മിക്കേണ്ടതാണ്.
// ഇത് `.peek() എന്ന് ഉറപ്പാക്കുന്നു;.peek();` അല്ലെങ്കിൽ `.peek();.next();` അന്തർലീനമായ ഇറ്ററേറ്ററിനെ ഒരുതവണ മാത്രമേ മുന്നോട്ട് കൊണ്ടുപോകൂ.
// ഇത് സ്വയം ആവർത്തനത്തെ സംയോജിപ്പിക്കുന്നില്ല.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> Iterator for Peekable<I> {
    type Item = I::Item;

    #[inline]
    fn next(&mut self) -> Option<I::Item> {
        match self.peeked.take() {
            Some(v) => v,
            None => self.iter.next(),
        }
    }

    #[inline]
    #[rustc_inherit_overflow_checks]
    fn count(mut self) -> usize {
        match self.peeked.take() {
            Some(None) => 0,
            Some(Some(_)) => 1 + self.iter.count(),
            None => self.iter.count(),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        match self.peeked.take() {
            Some(None) => None,
            Some(v @ Some(_)) if n == 0 => v,
            Some(Some(_)) => self.iter.nth(n - 1),
            None => self.iter.nth(n),
        }
    }

    #[inline]
    fn last(mut self) -> Option<I::Item> {
        let peek_opt = match self.peeked.take() {
            Some(None) => return None,
            Some(v) => v,
            None => None,
        };
        self.iter.last().or(peek_opt)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let peek_len = match self.peeked {
            Some(None) => return (0, Some(0)),
            Some(Some(_)) => 1,
            None => 0,
        };
        let (lo, hi) = self.iter.size_hint();
        let lo = lo.saturating_add(peek_len);
        let hi = match hi {
            Some(x) => x.checked_add(peek_len),
            None => None,
        };
        (lo, hi)
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let acc = match self.peeked.take() {
            Some(None) => return try { init },
            Some(Some(v)) => f(init, v)?,
            None => init,
        };
        self.iter.try_fold(acc, f)
    }

    #[inline]
    fn fold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        let acc = match self.peeked {
            Some(None) => return init,
            Some(Some(v)) => fold(init, v),
            None => init,
        };
        self.iter.fold(acc, fold)
    }
}

#[stable(feature = "double_ended_peek_iterator", since = "1.38.0")]
impl<I> DoubleEndedIterator for Peekable<I>
where
    I: DoubleEndedIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<Self::Item> {
        match self.peeked.as_mut() {
            Some(v @ Some(_)) => self.iter.next_back().or_else(|| v.take()),
            Some(None) => None,
            None => self.iter.next_back(),
        }
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        match self.peeked.take() {
            Some(None) => try { init },
            Some(Some(v)) => match self.iter.try_rfold(init, &mut f).into_result() {
                Ok(acc) => f(acc, v),
                Err(e) => {
                    self.peeked = Some(Some(v));
                    Try::from_error(e)
                }
            },
            None => self.iter.try_rfold(init, f),
        }
    }

    #[inline]
    fn rfold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        match self.peeked {
            Some(None) => init,
            Some(Some(v)) => {
                let acc = self.iter.rfold(init, &mut fold);
                fold(acc, v)
            }
            None => self.iter.rfold(init, fold),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator> ExactSizeIterator for Peekable<I> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator> FusedIterator for Peekable<I> {}

impl<I: Iterator> Peekable<I> {
    /// ആവർത്തനത്തെ മുന്നോട്ട് കൊണ്ടുപോകാതെ next() മൂല്യത്തിലേക്ക് ഒരു റഫറൻസ് നൽകുന്നു.
    ///
    /// [`next`] പോലെ, ഒരു മൂല്യമുണ്ടെങ്കിൽ, അത് ഒരു `Some(T)`-ൽ പൊതിഞ്ഞ് നിൽക്കുന്നു.
    /// ആവർത്തനം അവസാനിച്ചാൽ, `None` തിരികെ നൽകും.
    ///
    /// [`next`]: Iterator::next
    ///
    /// കാരണം `peek()` ഒരു റഫറൻസ് നൽകുന്നു, കൂടാതെ നിരവധി ഇറ്ററേറ്ററുകൾ റഫറൻസുകളിൽ ആവർത്തിക്കുന്നു, റിട്ടേൺ മൂല്യം ഇരട്ട റഫറൻസായ ആശയക്കുഴപ്പമുണ്ടാക്കുന്ന ഒരു സാഹചര്യം ഉണ്ടാകാം.
    /// ചുവടെയുള്ള ഉദാഹരണങ്ങളിൽ നിങ്ങൾക്ക് ഈ പ്രഭാവം കാണാൻ കഴിയും.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() future-ലേക്ക് കാണാൻ ഞങ്ങളെ അനുവദിക്കുന്നു
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // നമ്മൾ ഒന്നിലധികം തവണ `peek` ആണെങ്കിലും ആവർത്തനം മുന്നേറുന്നില്ല
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // ഇറ്ററേറ്റർ പൂർത്തിയായ ശേഷം, `peek()` ഉം അങ്ങനെ തന്നെ
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&mut self) -> Option<&I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_ref()
    }

    /// ഇറ്ററേറ്റർ മുന്നോട്ട് പോകാതെ തന്നെ next() മൂല്യത്തിലേക്ക് മാറ്റാവുന്ന ഒരു റഫറൻസ് നൽകുന്നു.
    ///
    /// [`next`] പോലെ, ഒരു മൂല്യമുണ്ടെങ്കിൽ, അത് ഒരു `Some(T)`-ൽ പൊതിഞ്ഞ് നിൽക്കുന്നു.
    /// ആവർത്തനം അവസാനിച്ചാൽ, `None` തിരികെ നൽകും.
    ///
    /// കാരണം `peek_mut()` ഒരു റഫറൻസ് നൽകുന്നു, കൂടാതെ നിരവധി ഇറ്ററേറ്ററുകൾ റഫറൻസുകളിൽ ആവർത്തിക്കുന്നു, റിട്ടേൺ മൂല്യം ഇരട്ട റഫറൻസായ ആശയക്കുഴപ്പമുണ്ടാക്കുന്ന ഒരു സാഹചര്യം ഉണ്ടാകാം.
    /// ചുവടെയുള്ള ഉദാഹരണങ്ങളിൽ നിങ്ങൾക്ക് ഈ പ്രഭാവം കാണാൻ കഴിയും.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// #![feature(peekable_peek_mut)]
    /// let mut iter = [1, 2, 3].iter().peekable();
    ///
    /// // `peek()` പോലെ, ആവർത്തനത്തെ മുന്നോട്ട് കൊണ്ടുപോകാതെ തന്നെ നമുക്ക് future-ലേക്ക് കാണാൻ കഴിയും.
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // ഇറ്ററേറ്ററിലേക്ക് നോക്കുക, മ്യൂട്ടബിൾ റഫറൻസിന് പിന്നിലെ മൂല്യം സജ്ജമാക്കുക.
    /// if let Some(p) = iter.peek_mut() {
    ///     assert_eq!(*p, &2);
    ///     *p = &5;
    /// }
    ///
    /// // ഇറ്ററേറ്റർ തുടരുമ്പോൾ ഞങ്ങൾ ഇട്ട മൂല്യം വീണ്ടും ദൃശ്യമാകുന്നു.
    /// assert_eq!(iter.collect::<Vec<_>>(), vec![&5, &3]);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "peekable_peek_mut", issue = "78302")]
    pub fn peek_mut(&mut self) -> Option<&mut I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_mut()
    }

    /// ഒരു നിബന്ധന ശരിയാണെങ്കിൽ ഈ ഇറ്ററേറ്ററിന്റെ അടുത്ത മൂല്യം ഉപയോഗിക്കുകയും തിരികെ നൽകുകയും ചെയ്യുക.
    /// ഈ ഇറ്ററേറ്ററിന്റെ അടുത്ത മൂല്യത്തിനായി `func` `true` നൽകുന്നുവെങ്കിൽ, അത് കഴിച്ച് തിരികെ നൽകുക.
    /// അല്ലെങ്കിൽ, `None` നൽകുക.
    /// # Examples
    /// ഒരു സംഖ്യ 0 ന് തുല്യമാണെങ്കിൽ അത് ഉപയോഗിക്കുക.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // ആവർത്തനത്തിന്റെ ആദ്യ ഇനം 0;അത് കഴിക്കുക.
    /// assert_eq!(iter.next_if(|&x| x == 0), Some(0));
    /// // മടക്കിയ അടുത്ത ഇനം ഇപ്പോൾ 1 ആണ്, അതിനാൽ `consume` `false` നൽകും.
    /// assert_eq!(iter.next_if(|&x| x == 0), None);
    /// // `next_if` `expected`-ന് തുല്യമായിരുന്നില്ലെങ്കിൽ അടുത്ത ഇനത്തിന്റെ മൂല്യം സംരക്ഷിക്കുന്നു.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    ///
    /// 10 ൽ താഴെയുള്ള ഏത് നമ്പറും ഉപയോഗിക്കുക.
    ///
    /// ```
    /// let mut iter = (1..20).peekable();
    /// // 10 ൽ താഴെയുള്ള എല്ലാ അക്കങ്ങളും ഉപയോഗിക്കുക
    /// while iter.next_if(|&x| x < 10).is_some() {}
    /// // നൽകിയ അടുത്ത മൂല്യം 10 ആയിരിക്കും
    /// assert_eq!(iter.next(), Some(10));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if(&mut self, func: impl FnOnce(&I::Item) -> bool) -> Option<I::Item> {
        match self.next() {
            Some(matched) if func(&matched) => Some(matched),
            other => {
                // ഞങ്ങൾ `self.next()` എന്ന് വിളിച്ചതിനാൽ, ഞങ്ങൾ `self.peeked` ഉപയോഗിച്ചു.
                assert!(self.peeked.is_none());
                self.peeked = Some(other);
                None
            }
        }
    }

    /// അടുത്ത ഇനം `expected` ന് തുല്യമാണെങ്കിൽ അത് കഴിച്ച് തിരികെ നൽകുക.
    /// # Example
    /// ഒരു സംഖ്യ 0 ന് തുല്യമാണെങ്കിൽ അത് ഉപയോഗിക്കുക.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // ആവർത്തനത്തിന്റെ ആദ്യ ഇനം 0;അത് കഴിക്കുക.
    /// assert_eq!(iter.next_if_eq(&0), Some(0));
    /// // മടക്കിയ അടുത്ത ഇനം ഇപ്പോൾ 1 ആണ്, അതിനാൽ `consume` `false` നൽകും.
    /// assert_eq!(iter.next_if_eq(&0), None);
    /// // `next_if_eq` `expected`-ന് തുല്യമായിരുന്നില്ലെങ്കിൽ അടുത്ത ഇനത്തിന്റെ മൂല്യം സംരക്ഷിക്കുന്നു.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if_eq<T>(&mut self, expected: &T) -> Option<I::Item>
    where
        T: ?Sized,
        I::Item: PartialEq<T>,
    {
        self.next_if(|next| next == expected)
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I> TrustedLen for Peekable<I> where I: TrustedLen {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S: Iterator, I: Iterator> SourceIter for Peekable<I>
where
    I: SourceIter<Source = S>,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // സുരക്ഷ: സമാന ആവശ്യകതകളുള്ള സുരക്ഷിതമല്ലാത്ത ഫംഗ്ഷനിലേക്ക് സുരക്ഷിതമല്ലാത്ത പ്രവർത്തനം കൈമാറുന്നു
        unsafe { SourceIter::as_inner(&mut self.iter) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I: InPlaceIterable> InPlaceIterable for Peekable<I> {}