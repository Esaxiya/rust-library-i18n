use crate::fmt;
use crate::iter::{adapters::SourceIter, FusedIterator, InPlaceIterable};
use crate::ops::Try;

/// `iter` ന്റെ ഘടകങ്ങൾ `predicate` ഉപയോഗിച്ച് ഫിൽട്ടർ ചെയ്യുന്ന ഒരു ഇറ്ററേറ്റർ.
///
/// [`Iterator`]-ലെ [`filter`] രീതി ഉപയോഗിച്ചാണ് ഈ `struct` സൃഷ്ടിച്ചിരിക്കുന്നത്.
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// [`filter`]: Iterator::filter
/// [`Iterator`]: trait.Iterator.html
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct Filter<I, P> {
    // `SplitWhitespace`, `SplitAsciiWhitespace` `as_str` രീതികൾക്കായി ഉപയോഗിക്കുന്നു
    pub(crate) iter: I,
    predicate: P,
}
impl<I, P> Filter<I, P> {
    pub(in crate::iter) fn new(iter: I, predicate: P) -> Filter<I, P> {
        Filter { iter, predicate }
    }
}

#[stable(feature = "core_impl_debug", since = "1.9.0")]
impl<I: fmt::Debug, P> fmt::Debug for Filter<I, P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Filter").field("iter", &self.iter).finish()
    }
}

fn filter_fold<T, Acc>(
    mut predicate: impl FnMut(&T) -> bool,
    mut fold: impl FnMut(Acc, T) -> Acc,
) -> impl FnMut(Acc, T) -> Acc {
    move |acc, item| if predicate(&item) { fold(acc, item) } else { acc }
}

fn filter_try_fold<'a, T, Acc, R: Try<Ok = Acc>>(
    predicate: &'a mut impl FnMut(&T) -> bool,
    mut fold: impl FnMut(Acc, T) -> R + 'a,
) -> impl FnMut(Acc, T) -> R + 'a {
    move |acc, item| if predicate(&item) { fold(acc, item) } else { try { acc } }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator, P> Iterator for Filter<I, P>
where
    P: FnMut(&I::Item) -> bool,
{
    type Item = I::Item;

    #[inline]
    fn next(&mut self) -> Option<I::Item> {
        self.iter.find(&mut self.predicate)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let (_, upper) = self.iter.size_hint();
        (0, upper) // പ്രവചനം കാരണം താഴ്ന്ന പരിധി അറിയാൻ കഴിയില്ല
    }

    // ഈ പ്രത്യേക കേസ് കംപൈലറിനെ `.filter(_).count()` ശാഖകളില്ലാത്തതാക്കാൻ അനുവദിക്കുന്നു.
    // തികഞ്ഞ branch പ്രവചനം ഒഴികെ (പൊതുവായ സാഹചര്യത്തിൽ ഇത് നേടാനാകില്ല), ഇത്> 90% കേസുകളിൽ വളരെ വേഗത്തിലാകും (ഫലത്തിൽ എല്ലാ യഥാർത്ഥ ജോലിഭാരങ്ങളും അടങ്ങിയിരിക്കുന്നു), ബാക്കിയുള്ളവയിൽ വളരെ കുറച്ച് മാത്രമേ മന്ദഗതിയിലാകൂ.
    //
    // ഈ സ്പെഷ്യലൈസേഷൻ ഉള്ളതിനാൽ `.filter(p).count()` എഴുതാൻ ഞങ്ങളെ അനുവദിക്കുന്നു, അല്ലാത്തപക്ഷം ഞങ്ങൾ `.map(|x| p(x) as usize).sum()` എഴുതുന്നു, അത് വായിക്കാൻ കഴിയാത്തതും 1.10 ന് മുമ്പുള്ള Rust-ന് അനുയോജ്യവുമാണ്.
    //
    //
    // ബ്രാഞ്ചില്ലാത്ത പതിപ്പ് ഉപയോഗിക്കുന്നത് എൽ‌എൽ‌വി‌എം ബൈറ്റ് കോഡിനെ ലളിതമാക്കും, അങ്ങനെ എൽ‌എൽ‌വി‌എം ഒപ്റ്റിമൈസേഷനുകൾക്കായി കൂടുതൽ ബജറ്റ് നൽകും.
    //
    //
    //
    //
    #[inline]
    fn count(self) -> usize {
        #[inline]
        fn to_usize<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut(T) -> usize {
            move |x| predicate(&x) as usize
        }

        self.iter.map(to_usize(self.predicate)).sum()
    }

    #[inline]
    fn try_fold<Acc, Fold, R>(&mut self, init: Acc, fold: Fold) -> R
    where
        Self: Sized,
        Fold: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        self.iter.try_fold(init, filter_try_fold(&mut self.predicate, fold))
    }

    #[inline]
    fn fold<Acc, Fold>(self, init: Acc, fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        self.iter.fold(init, filter_fold(self.predicate, fold))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: DoubleEndedIterator, P> DoubleEndedIterator for Filter<I, P>
where
    P: FnMut(&I::Item) -> bool,
{
    #[inline]
    fn next_back(&mut self) -> Option<I::Item> {
        self.iter.rfind(&mut self.predicate)
    }

    #[inline]
    fn try_rfold<Acc, Fold, R>(&mut self, init: Acc, fold: Fold) -> R
    where
        Self: Sized,
        Fold: FnMut(Acc, Self::Item) -> R,
        R: Try<Ok = Acc>,
    {
        self.iter.try_rfold(init, filter_try_fold(&mut self.predicate, fold))
    }

    #[inline]
    fn rfold<Acc, Fold>(self, init: Acc, fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        self.iter.rfold(init, filter_fold(self.predicate, fold))
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator, P> FusedIterator for Filter<I, P> where P: FnMut(&I::Item) -> bool {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S: Iterator, P, I: Iterator> SourceIter for Filter<I, P>
where
    P: FnMut(&I::Item) -> bool,
    I: SourceIter<Source = S>,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // സുരക്ഷ: സമാന ആവശ്യകതകളുള്ള സുരക്ഷിതമല്ലാത്ത ഫംഗ്ഷനിലേക്ക് സുരക്ഷിതമല്ലാത്ത പ്രവർത്തനം കൈമാറുന്നു
        unsafe { SourceIter::as_inner(&mut self.iter) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I: InPlaceIterable, P> InPlaceIterable for Filter<I, P> where P: FnMut(&I::Item) -> bool {}