use crate::cmp;
use crate::fmt::{self, Debug};
use crate::iter::{DoubleEndedIterator, ExactSizeIterator, FusedIterator, Iterator};
use crate::iter::{InPlaceIterable, SourceIter, TrustedLen};

/// ഒരേസമയം മറ്റ് രണ്ട് ഇറ്ററേറ്ററുകളെ ആവർത്തിക്കുന്ന ഒരു ഇറ്ററേറ്റർ.
///
/// ഈ `struct` സൃഷ്ടിച്ചത് [`Iterator::zip`] ആണ്.
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
#[derive(Clone)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Zip<A, B> {
    a: A,
    b: B,
    // സൂചിക, ലെൻ, a_len എന്നിവ സിപ്പിന്റെ പ്രത്യേക പതിപ്പ് മാത്രമേ ഉപയോഗിക്കുന്നുള്ളൂ
    index: usize,
    len: usize,
    a_len: usize,
}
impl<A: Iterator, B: Iterator> Zip<A, B> {
    pub(in crate::iter) fn new(a: A, b: B) -> Zip<A, B> {
        ZipImpl::new(a, b)
    }
    fn super_nth(&mut self, mut n: usize) -> Option<(A::Item, B::Item)> {
        while let Some(x) = Iterator::next(self) {
            if n == 0 {
                return Some(x);
            }
            n -= 1;
        }
        None
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> Iterator for Zip<A, B>
where
    A: Iterator,
    B: Iterator,
{
    type Item = (A::Item, B::Item);

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        ZipImpl::next(self)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        ZipImpl::size_hint(self)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        ZipImpl::nth(self, n)
    }

    #[inline]
    unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        // സുരക്ഷ: `ZipImpl::__iterator_get_unchecked` ന് സമാന സുരക്ഷയുണ്ട്
        // `Iterator::__iterator_get_unchecked` ആയി ആവശ്യകതകൾ.
        unsafe { ZipImpl::get_unchecked(self, idx) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> DoubleEndedIterator for Zip<A, B>
where
    A: DoubleEndedIterator + ExactSizeIterator,
    B: DoubleEndedIterator + ExactSizeIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<(A::Item, B::Item)> {
        ZipImpl::next_back(self)
    }
}

// സിപ്പ് സ്പെഷ്യലൈസേഷൻ trait
#[doc(hidden)]
trait ZipImpl<A, B> {
    type Item;
    fn new(a: A, b: B) -> Self;
    fn next(&mut self) -> Option<Self::Item>;
    fn size_hint(&self) -> (usize, Option<usize>);
    fn nth(&mut self, n: usize) -> Option<Self::Item>;
    fn next_back(&mut self) -> Option<Self::Item>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator;
    // ഇതിന് `Iterator::__iterator_get_unchecked`-ന് സമാനമായ സുരക്ഷാ ആവശ്യകതകളുണ്ട്
    unsafe fn get_unchecked(&mut self, idx: usize) -> <Self as Iterator>::Item
    where
        Self: Iterator + TrustedRandomAccess;
}

// ജനറൽ സിപ്പ് impl
#[doc(hidden)]
impl<A, B> ZipImpl<A, B> for Zip<A, B>
where
    A: Iterator,
    B: Iterator,
{
    type Item = (A::Item, B::Item);
    default fn new(a: A, b: B) -> Self {
        Zip {
            a,
            b,
            index: 0, // unused
            len: 0,   // unused
            a_len: 0, // unused
        }
    }

    #[inline]
    default fn next(&mut self) -> Option<(A::Item, B::Item)> {
        let x = self.a.next()?;
        let y = self.b.next()?;
        Some((x, y))
    }

    #[inline]
    default fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.super_nth(n)
    }

    #[inline]
    default fn next_back(&mut self) -> Option<(A::Item, B::Item)>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator,
    {
        let a_sz = self.a.len();
        let b_sz = self.b.len();
        if a_sz != b_sz {
            // A, b എന്നിവ തുല്യ നീളത്തിൽ ക്രമീകരിക്കുക
            if a_sz > b_sz {
                for _ in 0..a_sz - b_sz {
                    self.a.next_back();
                }
            } else {
                for _ in 0..b_sz - a_sz {
                    self.b.next_back();
                }
            }
        }
        match (self.a.next_back(), self.b.next_back()) {
            (Some(x), Some(y)) => Some((x, y)),
            (None, None) => None,
            _ => unreachable!(),
        }
    }

    #[inline]
    default fn size_hint(&self) -> (usize, Option<usize>) {
        let (a_lower, a_upper) = self.a.size_hint();
        let (b_lower, b_upper) = self.b.size_hint();

        let lower = cmp::min(a_lower, b_lower);

        let upper = match (a_upper, b_upper) {
            (Some(x), Some(y)) => Some(cmp::min(x, y)),
            (Some(x), None) => Some(x),
            (None, Some(y)) => Some(y),
            (None, None) => None,
        };

        (lower, upper)
    }

    default unsafe fn get_unchecked(&mut self, _idx: usize) -> <Self as Iterator>::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[doc(hidden)]
impl<A, B> ZipImpl<A, B> for Zip<A, B>
where
    A: TrustedRandomAccess + Iterator,
    B: TrustedRandomAccess + Iterator,
{
    fn new(a: A, b: B) -> Self {
        let a_len = a.size();
        let len = cmp::min(a_len, b.size());
        Zip { a, b, index: 0, len, a_len }
    }

    #[inline]
    fn next(&mut self) -> Option<(A::Item, B::Item)> {
        if self.index < self.len {
            let i = self.index;
            self.index += 1;
            // സുരക്ഷ: `i` `self.len` നേക്കാൾ ചെറുതാണ്, അതിനാൽ `self.a.len()`, `self.b.len()` എന്നിവയേക്കാൾ ചെറുതാണ്
            unsafe {
                Some((self.a.__iterator_get_unchecked(i), self.b.__iterator_get_unchecked(i)))
            }
        } else if A::MAY_HAVE_SIDE_EFFECT && self.index < self.a_len {
            let i = self.index;
            self.index += 1;
            self.len += 1;
            // അടിസ്ഥാന നടപ്പാക്കലിന്റെ സാധ്യതയുള്ള പാർശ്വഫലങ്ങളുമായി പൊരുത്തപ്പെടുക സുരക്ഷിതം: ഞങ്ങൾ `i` <`self.a.len()` എന്ന് പരിശോധിച്ചു
            //
            unsafe {
                self.a.__iterator_get_unchecked(i);
            }
            None
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len - self.index;
        (len, Some(len))
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        let delta = cmp::min(n, self.len - self.index);
        let end = self.index + delta;
        while self.index < end {
            let i = self.index;
            self.index += 1;
            if A::MAY_HAVE_SIDE_EFFECT {
                // സുരക്ഷ: `delta` കണക്കാക്കാൻ `cmp::min` ഉപയോഗം
                // `end` `self.len` നേക്കാൾ ചെറുതോ തുല്യമോ ആണെന്ന് ഉറപ്പാക്കുന്നു, അതിനാൽ `i` `self.len` നേക്കാൾ ചെറുതാണ്.
                //
                unsafe {
                    self.a.__iterator_get_unchecked(i);
                }
            }
            if B::MAY_HAVE_SIDE_EFFECT {
                // സുരക്ഷ: മുകളിൽ പറഞ്ഞതുപോലെ.
                unsafe {
                    self.b.__iterator_get_unchecked(i);
                }
            }
        }

        self.super_nth(n - delta)
    }

    #[inline]
    fn next_back(&mut self) -> Option<(A::Item, B::Item)>
    where
        A: DoubleEndedIterator + ExactSizeIterator,
        B: DoubleEndedIterator + ExactSizeIterator,
    {
        if A::MAY_HAVE_SIDE_EFFECT || B::MAY_HAVE_SIDE_EFFECT {
            let sz_a = self.a.size();
            let sz_b = self.b.size();
            // A, b തുല്യ നീളത്തിൽ ക്രമീകരിക്കുക, `next_back`-ന്റെ ആദ്യ കോൾ മാത്രമേ ഇത് ചെയ്യുന്നുള്ളൂവെന്ന് ഉറപ്പാക്കുക, അല്ലാത്തപക്ഷം `get_unchecked()`-ലേക്ക് വിളിച്ചതിന് ശേഷം `self.next_back()`-ലേക്ക് വിളിക്കുന്നതിനുള്ള നിയന്ത്രണം ഞങ്ങൾ ലംഘിക്കും.
            //
            //
            if sz_a != sz_b {
                let sz_a = self.a.size();
                if A::MAY_HAVE_SIDE_EFFECT && sz_a > self.len {
                    for _ in 0..sz_a - self.len {
                        self.a.next_back();
                    }
                    self.a_len = self.len;
                }
                let sz_b = self.b.size();
                if B::MAY_HAVE_SIDE_EFFECT && sz_b > self.len {
                    for _ in 0..sz_b - self.len {
                        self.b.next_back();
                    }
                }
            }
        }
        if self.index < self.len {
            self.len -= 1;
            self.a_len -= 1;
            let i = self.len;
            // സുരക്ഷ: `i`, `self.len`-ന്റെ മുമ്പത്തെ മൂല്യത്തേക്കാൾ ചെറുതാണ്,
            // ഇത് `self.a.len()`, `self.b.len()` എന്നിവയേക്കാൾ ചെറുതോ തുല്യമോ ആണ്
            unsafe {
                Some((self.a.__iterator_get_unchecked(i), self.b.__iterator_get_unchecked(i)))
            }
        } else {
            None
        }
    }

    #[inline]
    unsafe fn get_unchecked(&mut self, idx: usize) -> <Self as Iterator>::Item {
        let idx = self.index + idx;
        // സുരക്ഷ: വിളിക്കുന്നയാൾ `Iterator::__iterator_get_unchecked`-നായുള്ള കരാർ ഉയർത്തിപ്പിടിക്കണം.
        //
        unsafe { (self.a.__iterator_get_unchecked(idx), self.b.__iterator_get_unchecked(idx)) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B> ExactSizeIterator for Zip<A, B>
where
    A: ExactSizeIterator,
    B: ExactSizeIterator,
{
}

#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
unsafe impl<A, B> TrustedRandomAccess for Zip<A, B>
where
    A: TrustedRandomAccess,
    B: TrustedRandomAccess,
{
    const MAY_HAVE_SIDE_EFFECT: bool = A::MAY_HAVE_SIDE_EFFECT || B::MAY_HAVE_SIDE_EFFECT;
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A, B> FusedIterator for Zip<A, B>
where
    A: FusedIterator,
    B: FusedIterator,
{
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, B> TrustedLen for Zip<A, B>
where
    A: TrustedLen,
    B: TrustedLen,
{
}

// എക്‌സ്‌ട്രാക്റ്റുചെയ്യാനാകുന്ന "source" ആയി സിപ്പ് ആവർത്തനത്തിന്റെ ഇടത് വശത്തെ ഏകപക്ഷീയമായി തിരഞ്ഞെടുക്കുന്നു, ഇത് രണ്ടും പരീക്ഷിക്കാൻ നെഗറ്റീവ് trait bounds ആവശ്യമാണ്.
//
#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S, A, B> SourceIter for Zip<A, B>
where
    A: SourceIter<Source = S>,
    B: Iterator,
    S: Iterator,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // സുരക്ഷ: സമാന ആവശ്യകതകളുള്ള സുരക്ഷിതമല്ലാത്ത ഫംഗ്ഷനിലേക്ക് സുരക്ഷിതമല്ലാത്ത പ്രവർത്തനം കൈമാറുന്നു
        unsafe { SourceIter::as_inner(&mut self.a) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
// ഇനത്തിലേക്ക് പരിമിതപ്പെടുത്തിയിരിക്കുന്നു: സിപ്പ് ട്രസ്റ്റഡ് റാൻഡം ആക്‌സസിന്റെ ഉപയോഗവും ഉറവിടത്തിന്റെ ഡ്രോപ്പ് നടപ്പാക്കലും തമ്മിലുള്ള ആശയവിനിമയം വ്യക്തമല്ലാത്തതിനാൽ പകർത്തുക.
//
// ഉറവിടം എത്ര തവണ യുക്തിസഹമായി മുന്നേറുന്നു എന്നതിന്റെ ഒരു അധിക രീതി (next()) വിളിക്കാതെ ഉറവിടത്തിന്റെ ബാക്കി ഭാഗം ശരിയായി ഉപേക്ഷിക്കുന്നതിന് ആവശ്യമാണ്.
//
//
unsafe impl<A: InPlaceIterable, B: Iterator> InPlaceIterable for Zip<A, B> where A::Item: Copy {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Debug, B: Debug> Debug for Zip<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        ZipFmt::fmt(self, f)
    }
}

trait ZipFmt<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result;
}

impl<A: Debug, B: Debug> ZipFmt<A, B> for Zip<A, B> {
    default fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Zip").field("a", &self.a).field("b", &self.b).finish()
    }
}

impl<A: Debug + TrustedRandomAccess, B: Debug + TrustedRandomAccess> ZipFmt<A, B> for Zip<A, B> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // അടങ്ങിയിരിക്കുന്ന ഇറ്ററേറ്ററുകളിൽ എഫ്‌എം‌ടി വിളിക്കുന്നത് *സുരക്ഷിതമല്ല*, കാരണം ഞങ്ങൾ‌ആവർത്തിക്കാൻ‌തുടങ്ങിയാൽ‌അവ വിചിത്രവും സുരക്ഷിതമല്ലാത്തതുമായ അവസ്ഥയിലാണെന്ന് പറയുന്നു.
        //
        f.debug_struct("Zip").finish()
    }
}

/// ഇനങ്ങൾ ക്രമരഹിതമായി ആക്‌സസ്സുചെയ്യാനാകുന്ന ഒരു ആവർത്തനം
///
/// # Safety
///
/// ഇറ്ററേറ്ററിന്റെ `size_hint` വിളിക്കാൻ കൃത്യവും വിലകുറഞ്ഞതുമായിരിക്കണം.
///
/// `size` അസാധുവാക്കിയേക്കില്ല.
///
/// `<Self as Iterator>::__iterator_get_unchecked` ഇനിപ്പറയുന്ന നിബന്ധനകൾ പാലിച്ചിട്ടുണ്ടെങ്കിൽ വിളിക്കാൻ സുരക്ഷിതമായിരിക്കണം.
///
/// 1. `0 <= idx` ഒപ്പം `idx < self.size()` ഉം.
/// 2. `self: !Clone` ആണെങ്കിൽ, `self`-നെ ഒരേ സൂചിക ഉപയോഗിച്ച് `self`-ൽ ഒന്നിലധികം തവണ വിളിക്കില്ല.
/// 3. `self.get_unchecked(idx)` വിളിച്ചതിനുശേഷം `next_back` പരമാവധി `self.size() - idx - 1` തവണ മാത്രമേ വിളിക്കൂ.
/// 4. `get_unchecked` വിളിച്ചതിന് ശേഷം, ഇനിപ്പറയുന്ന രീതികൾ മാത്രമേ `self`-ൽ വിളിക്കുകയുള്ളൂ:
///     * `std::clone::Clone::clone()`
///     * `std::iter::Iterator::size_hint()`
///     * `std::iter::Iterator::next_back()`
///     * `std::iter::Iterator::__iterator_get_unchecked()`
///     * `std::iter::TrustedRandomAccess::size()`
///
/// കൂടാതെ, ഈ നിബന്ധനകൾ പാലിച്ചിട്ടുണ്ടെങ്കിൽ, ഇത് ഇനിപ്പറയുന്നവ ഉറപ്പുനൽകണം:
///
/// * ഇത് `size_hint`-ൽ നിന്ന് ലഭിച്ച മൂല്യത്തെ മാറ്റില്ല
/// * ആവശ്യമുള്ള traits നടപ്പിലാക്കിയിട്ടുണ്ടെന്ന് കരുതി, `get_unchecked`-ലേക്ക് വിളിച്ചതിന് ശേഷം `self`-ൽ മുകളിൽ ലിസ്റ്റുചെയ്‌തിരിക്കുന്ന രീതികളെ വിളിക്കുന്നത് സുരക്ഷിതമായിരിക്കണം.
///
/// * `get_unchecked` വിളിച്ചതിന് ശേഷം `self` ഡ്രോപ്പ് ചെയ്യുന്നതും സുരക്ഷിതമായിരിക്കണം.
///
///
///
///
#[doc(hidden)]
#[unstable(feature = "trusted_random_access", issue = "none")]
#[rustc_specialization_trait]
pub unsafe trait TrustedRandomAccess: Sized {
    // സൗകര്യപ്രദമായ രീതി.
    fn size(&self) -> usize
    where
        Self: Iterator,
    {
        self.size_hint().0
    }
    /// `true` ഒരു ആവർത്തന ഘടകം ലഭിക്കുകയാണെങ്കിൽ പാർശ്വഫലങ്ങൾ ഉണ്ടായേക്കാം.
    /// ആന്തരിക ആവർത്തനങ്ങളെ കണക്കിലെടുക്കാൻ ഓർമ്മിക്കുക.
    const MAY_HAVE_SIDE_EFFECT: bool;
}

/// `Iterator::__iterator_get_unchecked` പോലെ, പക്ഷേ `U: TrustedRandomAccess` എന്ന് കംപൈലർ അറിയാൻ ആവശ്യമില്ല.
///
///
/// ## Safety
///
/// `get_unchecked` നെ നേരിട്ട് വിളിക്കുന്ന അതേ ആവശ്യകതകൾ.
#[doc(hidden)]
pub(in crate::iter::adapters) unsafe fn try_get_unchecked<I>(it: &mut I, idx: usize) -> I::Item
where
    I: Iterator,
{
    // സുരക്ഷ: വിളിക്കുന്നയാൾ `Iterator::__iterator_get_unchecked`-നായുള്ള കരാർ ഉയർത്തിപ്പിടിക്കണം.
    //
    unsafe { it.try_get_unchecked(idx) }
}

unsafe trait SpecTrustedRandomAccess: Iterator {
    /// `Self: TrustedRandomAccess` ആണെങ്കിൽ, ഒരു `Iterator::__iterator_get_unchecked(self, index)` വിളിക്കുന്നത് സുരക്ഷിതമായിരിക്കണം.
    ///
    unsafe fn try_get_unchecked(&mut self, index: usize) -> Self::Item;
}

unsafe impl<I: Iterator> SpecTrustedRandomAccess for I {
    default unsafe fn try_get_unchecked(&mut self, _: usize) -> Self::Item {
        panic!("Should only be called on TrustedRandomAccess iterators");
    }
}

unsafe impl<I: Iterator + TrustedRandomAccess> SpecTrustedRandomAccess for I {
    unsafe fn try_get_unchecked(&mut self, index: usize) -> Self::Item {
        // സുരക്ഷ: വിളിക്കുന്നയാൾ `Iterator::__iterator_get_unchecked`-നായുള്ള കരാർ ഉയർത്തിപ്പിടിക്കണം.
        //
        unsafe { self.__iterator_get_unchecked(index) }
    }
}