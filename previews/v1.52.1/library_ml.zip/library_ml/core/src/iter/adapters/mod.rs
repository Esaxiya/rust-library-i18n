use crate::iter::{InPlaceIterable, Iterator};
use crate::ops::{ControlFlow, Try};

mod chain;
mod cloned;
mod copied;
mod cycle;
mod enumerate;
mod filter;
mod filter_map;
mod flatten;
mod fuse;
mod inspect;
mod intersperse;
mod map;
mod map_while;
mod peekable;
mod rev;
mod scan;
mod skip;
mod skip_while;
mod step_by;
mod take;
mod take_while;
mod zip;

pub use self::{
    chain::Chain, cycle::Cycle, enumerate::Enumerate, filter::Filter, filter_map::FilterMap,
    flatten::FlatMap, fuse::Fuse, inspect::Inspect, map::Map, peekable::Peekable, rev::Rev,
    scan::Scan, skip::Skip, skip_while::SkipWhile, take::Take, take_while::TakeWhile, zip::Zip,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::cloned::Cloned;

#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::step_by::StepBy;

#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::flatten::Flatten;

#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::copied::Copied;

#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::intersperse::{Intersperse, IntersperseWith};

#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::map_while::MapWhile;

#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::zip::TrustedRandomAccess;

/// ഈ trait ഒരു നിബന്ധനകൾക്ക് വിധേയമായി ഒരു ഇന്ററേറ്റർ-അഡാപ്റ്റർ പൈപ്പ്ലൈനിൽ ഉറവിട-ഘട്ടത്തിലേക്ക് പരിവർത്തന ആക്സസ് നൽകുന്നു.
/// * ആവർത്തന ഉറവിടം `S` തന്നെ `SourceIter<Source = S>` നടപ്പിലാക്കുന്നു
/// * ഉറവിടവും പൈപ്പ്ലൈൻ ഉപഭോക്താവും തമ്മിലുള്ള പൈപ്പ്ലൈനിലെ ഓരോ അഡാപ്റ്ററിനും ഈ trait നിയുക്തമാക്കൽ നടപ്പാക്കലുണ്ട്.
///
/// ഉറവിടം ഒരു ഉടമസ്ഥതയിലുള്ള ഇറ്ററേറ്റർ സ്ട്രക്റ്റ് ആയിരിക്കുമ്പോൾ (സാധാരണയായി `IntoIter` എന്ന് വിളിക്കുന്നു), ഇത് [`FromIterator`] നടപ്പിലാക്കലുകൾ സ്പെഷ്യലൈസ് ചെയ്യുന്നതിനോ ഒരു ഇറ്ററേറ്റർ ഭാഗികമായി തീർന്നുപോയതിനുശേഷം ശേഷിക്കുന്ന ഘടകങ്ങൾ വീണ്ടെടുക്കുന്നതിനോ ഉപയോഗപ്രദമാകും.
///
///
/// നടപ്പാക്കലുകൾക്ക് ഒരു പൈപ്പ്ലൈനിന്റെ ഏറ്റവും ആന്തരിക സ്രോതസ്സിലേക്ക് പ്രവേശനം നൽകണമെന്നില്ല.ഒരു സ്റ്റേറ്റ്‌ഫുൾ ഇന്റർമീഡിയറ്റ് അഡാപ്റ്റർ പൈപ്പ്ലൈനിന്റെ ഒരു ഭാഗം ആകാംക്ഷയോടെ വിലയിരുത്തുകയും അതിന്റെ ആന്തരിക സംഭരണം ഉറവിടമായി തുറന്നുകാട്ടുകയും ചെയ്യും.
///
/// trait സുരക്ഷിതമല്ലാത്തതിനാൽ നടപ്പിലാക്കുന്നവർ അധിക സുരക്ഷാ സവിശേഷതകൾ ഉയർത്തിപ്പിടിക്കണം.
/// വിശദാംശങ്ങൾക്ക് [`as_inner`] കാണുക.
///
/// # Examples
///
/// ഭാഗികമായി ഉപയോഗിക്കുന്ന ഉറവിടം വീണ്ടെടുക്കുന്നു:
///
/// ```
/// # #![feature(inplace_iteration)]
/// # use std::iter::SourceIter;
///
/// let mut iter = vec![9, 9, 9].into_iter().map(|i| i * i);
/// let _ = iter.next();
/// let mut remainder = std::mem::replace(unsafe { iter.as_inner() }, Vec::new().into_iter());
/// println!("n = {} elements remaining", remainder.len());
/// ```
///
/// [`FromIterator`]: crate::iter::FromIterator
/// [`as_inner`]: SourceIter::as_inner
///
///
///
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait SourceIter {
    /// ഒരു ആവർത്തന പൈപ്പ്ലൈനിലെ ഒരു ഉറവിട ഘട്ടം.
    type Source: Iterator;

    /// ഒരു ആവർത്തന പൈപ്പ്ലൈനിന്റെ ഉറവിടം വീണ്ടെടുക്കുക.
    ///
    /// # Safety
    ///
    /// നടപ്പിലാക്കുന്നവർ‌ഒരു കോളർ‌മാറ്റിസ്ഥാപിച്ചില്ലെങ്കിൽ‌, അവരുടെ ജീവിതകാലത്തേക്ക്‌ഒരേ മ്യൂട്ടബിൾ‌റഫറൻ‌സ് നൽ‌കേണ്ടതുണ്ട്.
    /// ആവർത്തനം നിർത്തിയപ്പോൾ മാത്രമേ കോളർമാർ റഫറൻസ് മാറ്റിസ്ഥാപിക്കുകയും ഉറവിടം എക്‌സ്‌ട്രാക്റ്റുചെയ്‌തതിനുശേഷം ആവർത്തന പൈപ്പ്ലൈൻ ഉപേക്ഷിക്കുകയും ചെയ്യൂ.
    ///
    /// ഇതിനർത്ഥം, ആവർത്തന സമയത്ത് മാറാത്ത ഉറവിടത്തെ ആവർത്തന അഡാപ്റ്ററുകൾക്ക് ആശ്രയിക്കാമെങ്കിലും അവരുടെ ഡ്രോപ്പ് നടപ്പാക്കലുകളിൽ അവർക്ക് ഇതിനെ ആശ്രയിക്കാൻ കഴിയില്ല.
    ///
    /// ഈ രീതി നടപ്പിലാക്കുക എന്നതിനർത്ഥം അഡാപ്റ്ററുകൾ അവരുടെ ഉറവിടത്തിലേക്ക് സ്വകാര്യമായി മാത്രം പ്രവേശനം ഉപേക്ഷിക്കുന്നുവെന്നും രീതി റിസീവർ തരങ്ങളെ അടിസ്ഥാനമാക്കി നൽകിയ ഗ്യാരണ്ടികളെ മാത്രം ആശ്രയിക്കാമെന്നും അർത്ഥമാക്കുന്നു.
    /// നിയന്ത്രിത ആക്‌സസിന്റെ അഭാവത്തിന് അഡാപ്റ്ററുകൾ ഉറവിടത്തിന്റെ ഇന്റേണലുകളിലേക്ക് ആക്‌സസ്സ് ഉള്ളപ്പോഴും ഉറവിടത്തിന്റെ പൊതു API നിലനിർത്തേണ്ടതുണ്ട്.
    ///
    /// ഉറവിടത്തിനും അതിന്റെ ഉറവിടത്തിനുമിടയിൽ ഇരിക്കുന്ന അഡാപ്റ്ററുകൾക്ക് ഒരേ ആക്‌സസ് ഉള്ളതിനാൽ ഉറവിടം അതിന്റെ പൊതു API-യുമായി പൊരുത്തപ്പെടുന്ന ഏത് അവസ്ഥയിലായിരിക്കുമെന്ന് കോളർമാർ പ്രതീക്ഷിക്കണം.
    /// പ്രത്യേകിച്ചും ഒരു അഡാപ്റ്റർ കർശനമായി ആവശ്യമുള്ളതിനേക്കാൾ കൂടുതൽ ഘടകങ്ങൾ ഉപയോഗിച്ചിരിക്കാം.
    ///
    /// ഈ ആവശ്യകതകളുടെ മൊത്തത്തിലുള്ള ലക്ഷ്യം ഒരു പൈപ്പ്ലൈൻ ഉപയോഗിക്കാൻ ഉപഭോക്താവിനെ അനുവദിക്കുക എന്നതാണ്
    /// * ആവർത്തനം നിർത്തിയതിനുശേഷം ഉറവിടത്തിൽ അവശേഷിക്കുന്നവ
    /// * ഉപഭോഗ ആവർത്തനത്തെ മുന്നോട്ട് കൊണ്ടുപോകുന്നതിലൂടെ ഉപയോഗിക്കാത്ത മെമ്മറി
    ///
    /// [`next()`]: Iterator::next()
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn as_inner(&mut self) -> &mut Self::Source;
}

/// അന്തർലീനമായ ഇറ്ററേറ്റർ `Result::Ok` മൂല്യങ്ങൾ ഉൽ‌പാദിപ്പിക്കുന്നിടത്തോളം output ട്ട്‌പുട്ട് ഉൽ‌പാദിപ്പിക്കുന്ന ഒരു ഇറ്ററേറ്റർ അഡാപ്റ്റർ.
///
///
/// ഒരു പിശക് നേരിട്ടാൽ, ആവർത്തനം നിർത്തുകയും പിശക് സംഭരിക്കുകയും ചെയ്യുന്നു.
///
pub(crate) struct ResultShunt<'a, I, E> {
    iter: I,
    error: &'a mut Result<(), E>,
}

/// തന്നിരിക്കുന്ന ഇറ്ററേറ്റർ ഒരു `Result<T, _>` ന് പകരം `T` നൽകിയതുപോലെ പ്രോസസ്സ് ചെയ്യുക.
/// ഏതെങ്കിലും പിശകുകൾ ആന്തരിക ആവർത്തനത്തെ തടയും മൊത്തത്തിലുള്ള ഫലം ഒരു പിശകായിരിക്കും.
///
pub(crate) fn process_results<I, T, E, F, U>(iter: I, mut f: F) -> Result<U, E>
where
    I: Iterator<Item = Result<T, E>>,
    for<'a> F: FnMut(ResultShunt<'a, I, E>) -> U,
{
    let mut error = Ok(());
    let shunt = ResultShunt { iter, error: &mut error };
    let value = f(shunt);
    error.map(|()| value)
}

impl<I, T, E> Iterator for ResultShunt<'_, I, E>
where
    I: Iterator<Item = Result<T, E>>,
{
    type Item = T;

    fn next(&mut self) -> Option<Self::Item> {
        self.find(|_| true)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.error.is_err() {
            (0, Some(0))
        } else {
            let (_, upper) = self.iter.size_hint();
            (0, upper)
        }
    }

    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let error = &mut *self.error;
        self.iter
            .try_fold(init, |acc, x| match x {
                Ok(x) => ControlFlow::from_try(f(acc, x)),
                Err(e) => {
                    *error = Err(e);
                    ControlFlow::Break(try { acc })
                }
            })
            .into_try()
    }

    fn fold<B, F>(mut self, init: B, fold: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(fold)).unwrap()
    }
}