use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// *പിൻ‌ഗാമി*,*മുൻ‌ഗാമി* പ്രവർ‌ത്തനങ്ങളുടെ ഒരു സങ്കൽപ്പമുള്ള ഒബ്‌ജക്റ്റുകൾ‌.
///
/// *പിൻ‌ഗാമി* പ്രവർ‌ത്തനം കൂടുതൽ‌താരതമ്യം ചെയ്യുന്ന മൂല്യങ്ങളിലേക്ക് നീങ്ങുന്നു.
/// *മുൻഗാമിയായ* പ്രവർത്തനം കുറച്ച് താരതമ്യപ്പെടുത്തുന്ന മൂല്യങ്ങളിലേക്ക് നീങ്ങുന്നു.
///
/// # Safety
///
/// ഈ trait `unsafe` ആണ്, കാരണം ഇത് `unsafe trait TrustedLen` നടപ്പിലാക്കലുകളുടെ സുരക്ഷയ്ക്കായി ശരിയായിരിക്കണം, മാത്രമല്ല ഈ trait ഉപയോഗിക്കുന്നതിന്റെ ഫലങ്ങൾ ശരിയാണെന്നും ലിസ്റ്റുചെയ്ത ബാധ്യതകൾ നിറവേറ്റുന്നതിനും `unsafe` കോഡ് ഉപയോഗിച്ച് വിശ്വസിക്കാം.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// `start` മുതൽ `end` വരെ ലഭിക്കാൻ ആവശ്യമായ *പിൻഗാമിയുടെ* ഘട്ടങ്ങളുടെ എണ്ണം നൽകുന്നു.
    ///
    /// ഘട്ടങ്ങളുടെ എണ്ണം `usize` കവിഞ്ഞൊഴുകുകയാണെങ്കിൽ (അല്ലെങ്കിൽ അനന്തമാണ്, അല്ലെങ്കിൽ `end` ഒരിക്കലും എത്തിച്ചേരില്ലെങ്കിൽ) `None` നൽകുന്നു.
    ///
    ///
    /// # Invariants
    ///
    /// ഏത് `a`, `b`, `n` എന്നിവയ്‌ക്കും:
    ///
    /// * `steps_between(&a, &b) == Some(n)` എക്സ് 00 എക്സ് ആണെങ്കിൽ മാത്രം
    /// * `steps_between(&a, &b) == Some(n)` എക്സ് 00 എക്സ് ആണെങ്കിൽ മാത്രം
    /// * `steps_between(&a, &b) == Some(n)` `a <= b` ആണെങ്കിൽ മാത്രം
    ///   * കൊറോളറി: `steps_between(&a, &b) == Some(0)` എങ്കിൽ, `a == b` ആണെങ്കിൽ മാത്രം
    ///   * `a <= b` എന്നത് _not_ എന്നത് `steps_between(&a, &b) != None` സൂചിപ്പിക്കുന്നു;
    ///     `b`-ലേക്ക് പോകാൻ `usize::MAX`-ൽ കൂടുതൽ ഘട്ടങ്ങൾ ആവശ്യമായി വരുമ്പോഴാണ് ഇത് സംഭവിക്കുന്നത്
    /// * `steps_between(&a, &b) == None` `a > b` ആണെങ്കിൽ
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// `self` `count` തവണയുടെ *പിൻഗാമി* എടുക്കുന്നതിലൂടെ ലഭിക്കുന്ന മൂല്യം നൽകുന്നു.
    ///
    /// ഇത് `Self` പിന്തുണയ്ക്കുന്ന മൂല്യങ്ങളുടെ ശ്രേണി കവിഞ്ഞൊഴുകുകയാണെങ്കിൽ, `None` നൽകുന്നു.
    ///
    /// # Invariants
    ///
    /// ഏത് `a`, `n`, `m` എന്നിവയ്‌ക്കും:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// `n + m` കവിഞ്ഞൊഴുകാത്ത ഏതൊരു `a`, `n`, `m` എന്നിവയ്‌ക്കും:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// ഏത് `a`, `n` എന്നിവയ്‌ക്കും:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// `self` `count` തവണയുടെ *പിൻഗാമി* എടുക്കുന്നതിലൂടെ ലഭിക്കുന്ന മൂല്യം നൽകുന്നു.
    ///
    /// ഇത് `Self` പിന്തുണയ്ക്കുന്ന മൂല്യങ്ങളുടെ ശ്രേണി കവിഞ്ഞൊഴുകുകയാണെങ്കിൽ, ഈ ഫംഗ്ഷൻ panic, റാപ് അല്ലെങ്കിൽ പൂരിതമാക്കാൻ അനുവദിച്ചിരിക്കുന്നു.
    ///
    /// ഡീബഗ് അവകാശവാദങ്ങൾ പ്രാപ്തമാക്കുമ്പോൾ panic ആണ് നിർദ്ദേശിത സ്വഭാവം, അല്ലാത്തപക്ഷം പൊതിയുകയോ പൂരിതമാക്കുകയോ ചെയ്യുക.
    ///
    /// ഓവർഫ്ലോയ്ക്ക് ശേഷം സുരക്ഷിതമല്ലാത്ത കോഡ് പെരുമാറ്റത്തിന്റെ കൃത്യതയെ ആശ്രയിക്കരുത്.
    ///
    /// # Invariants
    ///
    /// ഓവർഫ്ലോ ഉണ്ടാകാത്ത ഏതെങ്കിലും `a`, `n`, `m` എന്നിവയ്‌ക്കായി:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// ഓവർഫ്ലോ ഉണ്ടാകാത്ത ഏതെങ്കിലും `a`, `n` എന്നിവയ്‌ക്കായി:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// `self` `count` തവണയുടെ *പിൻഗാമി* എടുക്കുന്നതിലൂടെ ലഭിക്കുന്ന മൂല്യം നൽകുന്നു.
    ///
    /// # Safety
    ///
    /// `Self` പിന്തുണയ്ക്കുന്ന മൂല്യങ്ങളുടെ ശ്രേണി കവിഞ്ഞൊഴുകുന്നത് ഈ പ്രവർത്തനത്തിന്റെ നിർവചിക്കപ്പെടാത്ത പെരുമാറ്റമാണ്.
    /// ഇത് കവിഞ്ഞൊഴുകില്ലെന്ന് നിങ്ങൾക്ക് ഉറപ്പുനൽകാൻ കഴിയുന്നില്ലെങ്കിൽ, പകരം `forward` അല്ലെങ്കിൽ `forward_checked` ഉപയോഗിക്കുക.
    ///
    /// # Invariants
    ///
    /// ഏത് `a`-നും:
    ///
    /// * `b > a` പോലുള്ള `b` നിലവിലുണ്ടെങ്കിൽ, `Step::forward_unchecked(a, 1)` എന്ന് വിളിക്കുന്നത് സുരക്ഷിതമാണ്
    /// * `steps_between(&a, &b) == Some(n)` പോലുള്ള `b`, `n` ഉണ്ടെങ്കിൽ, ഏത് `m <= n`-നും `Step::forward_unchecked(a, m)` എന്ന് വിളിക്കുന്നത് സുരക്ഷിതമാണ്.
    ///
    ///
    /// ഓവർഫ്ലോ ഉണ്ടാകാത്ത ഏതെങ്കിലും `a`, `n` എന്നിവയ്‌ക്കായി:
    ///
    /// * `Step::forward_unchecked(a, n)` `Step::forward(a, n)` ന് തുല്യമാണ്
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// `self` `count` തവണയുടെ *മുൻഗാമി* എടുക്കുന്നതിലൂടെ ലഭിക്കുന്ന മൂല്യം നൽകുന്നു.
    ///
    /// ഇത് `Self` പിന്തുണയ്ക്കുന്ന മൂല്യങ്ങളുടെ ശ്രേണി കവിഞ്ഞൊഴുകുകയാണെങ്കിൽ, `None` നൽകുന്നു.
    ///
    /// # Invariants
    ///
    /// ഏത് `a`, `n`, `m` എന്നിവയ്‌ക്കും:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// ഏത് `a`, `n` എന്നിവയ്‌ക്കും:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// `self` `count` തവണയുടെ *മുൻഗാമി* എടുക്കുന്നതിലൂടെ ലഭിക്കുന്ന മൂല്യം നൽകുന്നു.
    ///
    /// ഇത് `Self` പിന്തുണയ്ക്കുന്ന മൂല്യങ്ങളുടെ ശ്രേണി കവിഞ്ഞൊഴുകുകയാണെങ്കിൽ, ഈ ഫംഗ്ഷൻ panic, റാപ് അല്ലെങ്കിൽ പൂരിതമാക്കാൻ അനുവദിച്ചിരിക്കുന്നു.
    ///
    /// ഡീബഗ് അവകാശവാദങ്ങൾ പ്രാപ്തമാക്കുമ്പോൾ panic ആണ് നിർദ്ദേശിത സ്വഭാവം, അല്ലാത്തപക്ഷം പൊതിയുകയോ പൂരിതമാക്കുകയോ ചെയ്യുക.
    ///
    /// ഓവർഫ്ലോയ്ക്ക് ശേഷം സുരക്ഷിതമല്ലാത്ത കോഡ് പെരുമാറ്റത്തിന്റെ കൃത്യതയെ ആശ്രയിക്കരുത്.
    ///
    /// # Invariants
    ///
    /// ഓവർഫ്ലോ ഉണ്ടാകാത്ത ഏതെങ്കിലും `a`, `n`, `m` എന്നിവയ്‌ക്കായി:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// ഓവർഫ്ലോ ഉണ്ടാകാത്ത ഏതെങ്കിലും `a`, `n` എന്നിവയ്‌ക്കായി:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// `self` `count` തവണയുടെ *മുൻഗാമി* എടുക്കുന്നതിലൂടെ ലഭിക്കുന്ന മൂല്യം നൽകുന്നു.
    ///
    /// # Safety
    ///
    /// `Self` പിന്തുണയ്ക്കുന്ന മൂല്യങ്ങളുടെ ശ്രേണി കവിഞ്ഞൊഴുകുന്നത് ഈ പ്രവർത്തനത്തിന്റെ നിർവചിക്കപ്പെടാത്ത പെരുമാറ്റമാണ്.
    /// ഇത് കവിഞ്ഞൊഴുകില്ലെന്ന് നിങ്ങൾക്ക് ഉറപ്പുനൽകാൻ കഴിയുന്നില്ലെങ്കിൽ, പകരം `backward` അല്ലെങ്കിൽ `backward_checked` ഉപയോഗിക്കുക.
    ///
    /// # Invariants
    ///
    /// ഏത് `a`-നും:
    ///
    /// * `b < a` പോലുള്ള `b` നിലവിലുണ്ടെങ്കിൽ, `Step::backward_unchecked(a, 1)` എന്ന് വിളിക്കുന്നത് സുരക്ഷിതമാണ്
    /// * `steps_between(&b, &a) == Some(n)` പോലുള്ള `b`, `n` ഉണ്ടെങ്കിൽ, ഏത് `m <= n`-നും `Step::backward_unchecked(a, m)` എന്ന് വിളിക്കുന്നത് സുരക്ഷിതമാണ്.
    ///
    ///
    /// ഓവർഫ്ലോ ഉണ്ടാകാത്ത ഏതെങ്കിലും `a`, `n` എന്നിവയ്‌ക്കായി:
    ///
    /// * `Step::backward_unchecked(a, n)` `Step::backward(a, n)` ന് തുല്യമാണ്
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// ഇവ ഇപ്പോഴും മാക്രോ-ജനറേറ്റുചെയ്‌തതാണ്, കാരണം പൂർണ്ണസംഖ്യകൾ വ്യത്യസ്ത തരം പരിഹരിക്കുന്നു.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // സുരക്ഷ: `start + n` കവിഞ്ഞൊഴുകുന്നില്ലെന്ന് വിളിക്കുന്നയാൾ ഉറപ്പ് നൽകേണ്ടതുണ്ട്.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // സുരക്ഷ: `start - n` കവിഞ്ഞൊഴുകുന്നില്ലെന്ന് വിളിക്കുന്നയാൾ ഉറപ്പ് നൽകേണ്ടതുണ്ട്.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // ഡീബഗ് ബിൽഡുകളിൽ, ഓവർഫ്ലോയിൽ ഒരു panic പ്രവർത്തനക്ഷമമാക്കുക.
            // റിലീസ് ബിൽഡുകളിൽ ഇത് പൂർണ്ണമായും ഒപ്റ്റിമൈസ് ചെയ്യണം.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // ഉദാ. അനുവദിക്കുന്നതിന് കണക്ക് പൊതിയുക `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // ഡീബഗ് ബിൽഡുകളിൽ, ഓവർഫ്ലോയിൽ ഒരു panic പ്രവർത്തനക്ഷമമാക്കുക.
            // റിലീസ് ബിൽഡുകളിൽ ഇത് പൂർണ്ണമായും ഒപ്റ്റിമൈസ് ചെയ്യണം.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // ഉദാ. അനുവദിക്കുന്നതിന് കണക്ക് പൊതിയുക `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // ഇത് $u_narrower <=ഉപയോഗത്തെ ആശ്രയിച്ചിരിക്കുന്നു
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // n പരിധിക്ക് പുറത്താണെങ്കിൽ, `unsigned_start + n` വളരെ കൂടുതലാണ്
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // n പരിധിക്ക് പുറത്താണെങ്കിൽ, `unsigned_start - n` വളരെ കൂടുതലാണ്
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // ഇത് $i_narrower <=ഉപയോഗത്തെ ആശ്രയിച്ചിരിക്കുന്നു
                        //
                        // ഐസൈസിലേക്ക് കാസ്റ്റുചെയ്യുന്നത് വീതി വിപുലീകരിക്കുന്നു, പക്ഷേ ചിഹ്നം സംരക്ഷിക്കുന്നു.
                        // ഐസൈസ് സ്‌പെയ്‌സിൽ റാപ്പിംഗ്_സബ് ഉപയോഗിക്കുക, ഐസൈസ് പരിധിക്കുള്ളിൽ ചേരാത്ത വ്യത്യാസം കണക്കാക്കാൻ ഉപയോഗിക്കുന്നതിന് കാസ്റ്റുചെയ്യുക.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // റാപ്പിംഗ് X001-ന് 200 പരിധിക്ക് പുറത്താണെങ്കിലും `Step::forward(-120_i8, 200) == Some(80_i8)` പോലുള്ള കേസുകൾ കൈകാര്യം ചെയ്യുന്നു.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // സങ്കലനം കവിഞ്ഞൊഴുകി
                            }
                        }
                        // N ന്റെ പരിധിക്ക് പുറത്താണെങ്കിൽ ഉദാ
                        // u8, i8-ന്റെ മുഴുവൻ ശ്രേണിയും വിശാലമായതിനേക്കാൾ വലുതാണ്, അതിനാൽ `any_i8 + n` i8-നെ കവിഞ്ഞൊഴുകുന്നു.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // റാപ്പിംഗ് X001-ന് 200 പരിധിക്ക് പുറത്താണെങ്കിലും `Step::forward(-120_i8, 200) == Some(80_i8)` പോലുള്ള കേസുകൾ കൈകാര്യം ചെയ്യുന്നു.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // കുറയ്ക്കൽ കവിഞ്ഞൊഴുകി
                            }
                        }
                        // N ന്റെ പരിധിക്ക് പുറത്താണെങ്കിൽ ഉദാ
                        // u8, i8-ന്റെ മുഴുവൻ ശ്രേണിയും വിശാലമായതിനേക്കാൾ വലുതാണ്, അതിനാൽ `any_i8 - n` i8-നെ കവിഞ്ഞൊഴുകുന്നു.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // വ്യത്യാസം വളരെ വലുതാണെങ്കിൽ ഉദാ
                            // i128, കുറച്ച് ബിറ്റുകൾ ഉപയോഗിച്ച് ഉപയോഗിക്കുന്നതിന് ഇത് വളരെ വലുതായിരിക്കും.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // സുരക്ഷ: റെസ് ഒരു സാധുവായ യൂണിക്കോഡ് സ്കെയിലറാണ്
            // (0x110000 ന് താഴെയല്ല 0xD800..0xE000 ൽ അല്ല)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // സുരക്ഷ: റെസ് ഒരു സാധുവായ യൂണിക്കോഡ് സ്കെയിലറാണ്
        // (0x110000 ന് താഴെയല്ല 0xD800..0xE000 ൽ അല്ല)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // സുരക്ഷ: ഇത് കവിഞ്ഞൊഴുകുന്നില്ലെന്ന് വിളിക്കുന്നയാൾ ഉറപ്പുനൽകണം
        // ഒരു ചാറിനുള്ള മൂല്യങ്ങളുടെ ശ്രേണി.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // സുരക്ഷ: ഇത് കവിഞ്ഞൊഴുകുന്നില്ലെന്ന് വിളിക്കുന്നയാൾ ഉറപ്പുനൽകണം
            // ഒരു ചാറിനുള്ള മൂല്യങ്ങളുടെ ശ്രേണി.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // സുരക്ഷ: മുമ്പത്തെ കരാർ കാരണം, ഇത് ഉറപ്പുനൽകുന്നു
        // ഒരു സാധുവായ ചാർ ആകാൻ കോളർ മുഖേന.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // സുരക്ഷ: ഇത് കവിഞ്ഞൊഴുകുന്നില്ലെന്ന് വിളിക്കുന്നയാൾ ഉറപ്പുനൽകണം
        // ഒരു ചാറിനുള്ള മൂല്യങ്ങളുടെ ശ്രേണി.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // സുരക്ഷ: ഇത് കവിഞ്ഞൊഴുകുന്നില്ലെന്ന് വിളിക്കുന്നയാൾ ഉറപ്പുനൽകണം
            // ഒരു ചാറിനുള്ള മൂല്യങ്ങളുടെ ശ്രേണി.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // സുരക്ഷ: മുമ്പത്തെ കരാർ കാരണം, ഇത് ഉറപ്പുനൽകുന്നു
        // ഒരു സാധുവായ ചാർ ആകാൻ കോളർ മുഖേന.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // സുരക്ഷ: മുൻ‌കരുതൽ പരിശോധിച്ചു
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // സുരക്ഷ: മുൻ‌കരുതൽ പരിശോധിച്ചു
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// ഈ മാക്രോകൾ വിവിധ ശ്രേണി തരങ്ങൾക്കായി `ExactSizeIterator` impls സൃഷ്ടിക്കുന്നു.
//
// * `ExactSizeIterator::len` എല്ലായ്പ്പോഴും കൃത്യമായ `usize` നൽകുന്നതിന് ആവശ്യമാണ്, അതിനാൽ ഒരു ശ്രേണിയും `usize::MAX` നേക്കാൾ കൂടുതലാകരുത്.
//
// * `Range<_>`-ലെ പൂർണ്ണസംഖ്യകൾക്കായി, `usize`-നേക്കാൾ ഇടുങ്ങിയതോ വീതിയുള്ളതോ ആയ തരങ്ങൾക്ക് ഇത് ബാധകമാണ്.
//   `RangeInclusive<_>`-ലെ പൂർണ്ണ സംഖ്യകൾക്ക് ഉദാ മുതൽ `usize` നേക്കാൾ *കർശനമായി ഇടുങ്ങിയ* തരങ്ങൾക്ക് ഇത് ബാധകമാണ്
//   `(0..=u64::MAX).len()` `u64::MAX + 1` ആയിരിക്കും.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // മുകളിലുള്ള യുക്തിക്ക് അനുസൃതമായി ഇവ കൃത്യതയില്ലാത്തവയാണ്, എന്നാൽ Rust 1.0.0-ൽ സ്ഥിരത കൈവരിക്കുന്നതിനാൽ അവ നീക്കംചെയ്യുന്നത് തകർക്കുന്ന മാറ്റമായിരിക്കും.
    // അതിനാൽ ഉദാ
    // `(0..66_000_u32).len()` ഉദാഹരണത്തിന്, 16-ബിറ്റ് പ്ലാറ്റ്ഫോമുകളിൽ പിശകുകളോ മുന്നറിയിപ്പുകളോ ഇല്ലാതെ കംപൈൽ ചെയ്യും, പക്ഷേ തെറ്റായ ഫലം നൽകുന്നത് തുടരുക.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // മുകളിലുള്ള യുക്തിക്ക് അനുസൃതമായി ഇവ കൃത്യതയില്ലാത്തവയാണ്, എന്നാൽ Rust 1.26.0-ൽ സ്ഥിരത കൈവരിക്കുന്നതിനാൽ അവ നീക്കംചെയ്യുന്നത് തകർക്കുന്ന മാറ്റമായിരിക്കും.
    // അതിനാൽ ഉദാ
    // `(0..=u16::MAX).len()` ഉദാഹരണത്തിന്, 16-ബിറ്റ് പ്ലാറ്റ്ഫോമുകളിൽ പിശകുകളോ മുന്നറിയിപ്പുകളോ ഇല്ലാതെ കംപൈൽ ചെയ്യും, പക്ഷേ തെറ്റായ ഫലം നൽകുന്നത് തുടരുക.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // സുരക്ഷ: മുൻ‌കരുതൽ പരിശോധിച്ചു
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // സുരക്ഷ: മുൻ‌കരുതൽ പരിശോധിച്ചു
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // സുരക്ഷ: മുൻ‌കരുതൽ പരിശോധിച്ചു
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // സുരക്ഷ: മുൻ‌കരുതൽ പരിശോധിച്ചു
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // സുരക്ഷ: മുൻ‌കരുതൽ പരിശോധിച്ചു
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // സുരക്ഷ: മുൻ‌കരുതൽ പരിശോധിച്ചു
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}