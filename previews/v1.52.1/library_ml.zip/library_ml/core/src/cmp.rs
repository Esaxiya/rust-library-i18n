//! ക്രമപ്പെടുത്തുന്നതിനും താരതമ്യപ്പെടുത്തുന്നതിനുമുള്ള പ്രവർത്തനം.
//!
//! മൂല്യങ്ങൾ ക്രമീകരിക്കുന്നതിനും താരതമ്യപ്പെടുത്തുന്നതിനുമുള്ള വിവിധ ഉപകരണങ്ങൾ ഈ മൊഡ്യൂളിൽ അടങ്ങിയിരിക്കുന്നു.ചുരുക്കത്തിൽ:
//!
//! * [`Eq`] ഒപ്പം [`PartialEq`] എന്നത് traits ആണ്, ഇത് യഥാക്രമം മൂല്യങ്ങൾ തമ്മിലുള്ള മൊത്തവും ഭാഗികവുമായ തുല്യത നിർവചിക്കാൻ നിങ്ങളെ അനുവദിക്കുന്നു.
//! അവ നടപ്പിലാക്കുന്നത് `==`, `!=` ഓപ്പറേറ്റർമാരെ ഓവർലോഡ് ചെയ്യുന്നു.
//! * [`Ord`] ഒപ്പം [`PartialOrd`] എന്നത് traits ആണ്, അവ യഥാക്രമം മൂല്യങ്ങൾക്കിടയിലുള്ള ഭാഗികവും ഭാഗികവുമായ ക്രമങ്ങൾ നിർവചിക്കാൻ നിങ്ങളെ അനുവദിക്കുന്നു.
//!
//! അവ നടപ്പിലാക്കുന്നത് `<`, `<=`, `>`, `>=` ഓപ്പറേറ്റർമാരെ ഓവർലോഡ് ചെയ്യുന്നു.
//! * [`Ordering`] [`Ord`], [`PartialOrd`] എന്നിവയുടെ പ്രധാന ഫംഗ്ഷനുകൾ‌നൽ‌കിയ ഒരു enum ആണ്, കൂടാതെ ഒരു ഓർ‌ഡറിംഗ് വിവരിക്കുന്നു.
//! * [`Reverse`] ഒരു ഓർഡറിംഗ് എളുപ്പത്തിൽ മാറ്റാൻ നിങ്ങളെ അനുവദിക്കുന്ന ഒരു ഘടനയാണ്.
//! * [`max`] ഒപ്പം [`min`] എന്നത് [`Ord`]-ൽ നിന്ന് നിർമ്മിക്കുകയും പരമാവധി അല്ലെങ്കിൽ കുറഞ്ഞത് രണ്ട് മൂല്യങ്ങൾ കണ്ടെത്താൻ നിങ്ങളെ അനുവദിക്കുകയും ചെയ്യുന്ന ഫംഗ്ഷനുകളാണ്.
//!
//! കൂടുതൽ വിവരങ്ങൾക്ക്, ലിസ്റ്റിലെ ഓരോ ഇനത്തിന്റെയും ബന്ധപ്പെട്ട ഡോക്യുമെന്റേഷൻ കാണുക.
//!
//! [`max`]: Ord::max
//! [`min`]: Ord::min
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use self::Ordering::*;

/// [partial equivalence relations](https://en.wikipedia.org/wiki/Partial_equivalence_relation) ആയ സമത്വ താരതമ്യങ്ങൾക്കായി Trait.
///
/// പൂർണ്ണമായ തുല്യതാ ബന്ധമില്ലാത്ത തരങ്ങൾക്ക് ഭാഗിക സമത്വം അനുവദിക്കുന്നതിന് ഈ trait അനുവദിക്കുന്നു.
/// ഉദാഹരണത്തിന്, ഫ്ലോട്ടിംഗ് പോയിൻറ് നമ്പറുകളായ `NaN != NaN` ൽ, അതിനാൽ ഫ്ലോട്ടിംഗ് പോയിൻറ് തരങ്ങൾ `PartialEq` നടപ്പിലാക്കുന്നു, പക്ഷേ [`trait@Eq`] അല്ല.
///
/// Mal പചാരികമായി, സമത്വം ആയിരിക്കണം (എല്ലാ `a`, `b`, `A` തരം `A`, `B`, `C`):
///
/// - **സമമിതി**: `A: PartialEq<B>` ഉം `B: PartialEq<A>` ഉം ആണെങ്കിൽ,**`a==b` എന്നത് സൂചിപ്പിക്കുന്നത്`b==a`**;ഒപ്പം
///
/// - **ട്രാൻസിറ്റീവ്**: `A: PartialEq<B>` ഉം `B: PartialEq<C>` ഉം `A ഉം ആണെങ്കിൽ:
///   ഭാഗിക എക്<C>`, തുടർന്ന് **` a==b`, `b == c` എന്നിവ`a==c`** സൂചിപ്പിക്കുന്നു.
///
/// `B: PartialEq<A>` (symmetric), `A: PartialEq<C>` (transitive) impls നിലവിലില്ലെന്ന് ശ്രദ്ധിക്കുക, എന്നാൽ ഈ ആവശ്യകതകൾ നിലനിൽക്കുമ്പോഴെല്ലാം അവ ബാധകമാണ്.
///
/// ## Derivable
///
/// ഈ trait `#[derive]` ഉപയോഗിച്ച് ഉപയോഗിക്കാം.സ്ട്രക്റ്റുകളിൽ `ഡെറിവ്` ചെയ്യുമ്പോൾ, എല്ലാ ഫീൽഡുകളും തുല്യമാണെങ്കിൽ രണ്ട് ഉദാഹരണങ്ങൾ തുല്യമാണ്, ഏതെങ്കിലും ഫീൽഡുകൾ തുല്യമല്ലെങ്കിൽ തുല്യമല്ല.ഇനാമുകളിൽ `ഡെറിവ്` ചെയ്യുമ്പോൾ, ഓരോ വേരിയന്റും തനിക്ക് തുല്യമാണ്, മറ്റ് വേരിയന്റുകൾക്ക് തുല്യമല്ല.
///
/// ## എനിക്ക് എങ്ങനെ `PartialEq` നടപ്പിലാക്കാൻ കഴിയും?
///
/// `PartialEq` [`eq`] രീതി നടപ്പിലാക്കാൻ മാത്രം ആവശ്യമാണ്;[`ne`] എന്നത് സ്ഥിരസ്ഥിതിയായി നിർവചിക്കപ്പെടുന്നു.[`ne`]*ന്റെ ഏതെങ്കിലും സ്വമേധയാലുള്ള നടപ്പാക്കൽ*[`eq`] എന്നത് [`ne`] ന്റെ കർശനമായ വിപരീതമാണെന്ന നിയമത്തെ മാനിക്കണം;അതായത്, `!(a == b)` എങ്കിൽ, `a != b` ആണെങ്കിൽ മാത്രം.
///
/// `PartialEq`, [`PartialOrd`], [`Ord`] * എന്നിവയുടെ നടപ്പാക്കലുകൾ‌പരസ്പരം യോജിപ്പിക്കണം.traits-ൽ ചിലത് നേടുകയും മറ്റുള്ളവ സ്വമേധയാ നടപ്പിലാക്കുകയും ചെയ്യുന്നതിലൂടെ ആകസ്മികമായി അവരെ വിയോജിക്കുന്നത് എളുപ്പമാണ്.
///
/// ഫോർ‌മാറ്റുകൾ‌വ്യത്യാസപ്പെട്ടിരിക്കുകയാണെങ്കിലും, രണ്ട് പുസ്‌തകങ്ങൾ‌അവരുടെ ഐ‌എസ്‌ബി‌എൻ‌പൊരുത്തപ്പെടുന്നുവെങ്കിൽ‌, ഒരേ പുസ്തകമായി കണക്കാക്കുന്ന ഒരു ഡൊമെയ്‌നിനായുള്ള ഒരു ഉദാഹരണം നടപ്പിലാക്കൽ:
///
/// ```
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
/// let b2 = Book { isbn: 3, format: BookFormat::Ebook };
/// let b3 = Book { isbn: 10, format: BookFormat::Paperback };
///
/// assert!(b1 == b2);
/// assert!(b1 != b3);
/// ```
///
/// ## എനിക്ക് രണ്ട് വ്യത്യസ്ത തരം എങ്ങനെ താരതമ്യം ചെയ്യാം?
///
/// നിങ്ങൾക്ക് താരതമ്യം ചെയ്യാൻ കഴിയുന്ന തരം നിയന്ത്രിക്കുന്നത് `ഭാഗിക എക്'യുടെ തരം പാരാമീറ്ററാണ്.
/// ഉദാഹരണത്തിന്, ഞങ്ങളുടെ മുമ്പത്തെ കോഡ് അൽപ്പം മാറ്റാം:
///
/// ```
/// // ഡെറിവ് ഉപകരണങ്ങൾ<BookFormat>==<BookFormat>താരതമ്യങ്ങൾ
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// // നടപ്പിലാക്കുക<Book>==<BookFormat>താരതമ്യങ്ങൾ
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// // നടപ്പിലാക്കുക<BookFormat>==<Book>താരതമ്യങ്ങൾ
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// let b1 = Book { isbn: 3, format: BookFormat::Paperback };
///
/// assert!(b1 == BookFormat::Paperback);
/// assert!(BookFormat::Ebook != b1);
/// ```
///
/// `impl PartialEq for Book`-നെ `impl PartialEq<BookFormat> for Book`-ലേക്ക് മാറ്റുന്നതിലൂടെ, `ബുക്ക് ഫോർമാറ്റിനെ` പുസ്തകവുമായി താരതമ്യം ചെയ്യാൻ ഞങ്ങൾ അനുവദിക്കുന്നു.
///
/// സ്ട്രക്റ്റിന്റെ ചില ഫീൽഡുകളെ അവഗണിക്കുന്ന മുകളിലുള്ളതുപോലുള്ള ഒരു താരതമ്യം അപകടകരമാണ്.ഭാഗിക തുല്യതാ ബന്ധത്തിന്റെ ആവശ്യകതകളുടെ ആസൂത്രിതമല്ലാത്ത ലംഘനത്തിലേക്ക് ഇത് എളുപ്പത്തിൽ നയിച്ചേക്കാം.
/// ഉദാഹരണത്തിന്, `BookFormat`-നായി ഞങ്ങൾ മുകളിൽ പറഞ്ഞ `PartialEq<Book>` നടപ്പിലാക്കുകയും `Book`-നായി `PartialEq<Book>`-ന്റെ ഒരു നടപ്പാക്കൽ ചേർക്കുകയും ചെയ്താൽ (ഒന്നുകിൽ `#[derive]` വഴിയോ അല്ലെങ്കിൽ ആദ്യത്തെ ഉദാഹരണത്തിൽ നിന്നുള്ള സ്വമേധയാലുള്ള നടപ്പാക്കൽ വഴിയോ) ഫലം ട്രാൻസിബിലിറ്റി ലംഘിക്കും:
///
///
/// ```should_panic
/// #[derive(PartialEq)]
/// enum BookFormat {
///     Paperback,
///     Hardback,
///     Ebook,
/// }
///
/// #[derive(PartialEq)]
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
///
/// impl PartialEq<BookFormat> for Book {
///     fn eq(&self, other: &BookFormat) -> bool {
///         self.format == *other
///     }
/// }
///
/// impl PartialEq<Book> for BookFormat {
///     fn eq(&self, other: &Book) -> bool {
///         *self == other.format
///     }
/// }
///
/// fn main() {
///     let b1 = Book { isbn: 1, format: BookFormat::Paperback };
///     let b2 = Book { isbn: 2, format: BookFormat::Paperback };
///
///     assert!(b1 == BookFormat::Paperback);
///     assert!(BookFormat::Paperback == b2);
///
///     // The following should hold by transitivity but doesn't.
///     assert!(b1 == b2); // <-- PANICS
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x: u32 = 0;
/// let y: u32 = 1;
///
/// assert_eq!(x == y, false);
/// assert_eq!(x.eq(&y), false);
/// ```
///
/// [`eq`]: PartialEq::eq
/// [`ne`]: PartialEq::ne
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "eq"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} == {Rhs}`"
)]
pub trait PartialEq<Rhs: ?Sized = Self> {
    /// ഈ രീതി `self`, `other` മൂല്യങ്ങൾ തുല്യമാണെന്ന് പരിശോധിക്കുന്നു, ഇത് `==` ഉപയോഗിക്കുന്നു.
    ///
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn eq(&self, other: &Rhs) -> bool;

    /// ഈ രീതി `!=`-നായി പരിശോധിക്കുന്നു.
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ne(&self, other: &Rhs) -> bool {
        !self.eq(other)
    }
}

/// trait `PartialEq`-ന്റെ ഒരു impl സൃഷ്ടിക്കുന്ന മാക്രോ ഡെറിവ് ചെയ്യുക.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, structural_match)]
pub macro PartialEq($item:item) {
    /* compiler built-in */
}

/// [equivalence relations](https://en.wikipedia.org/wiki/Equivalence_relation) ആയ സമത്വ താരതമ്യങ്ങൾക്കായി Trait.
///
/// ഇതിനർത്ഥം, `a == b`, `a != b` എന്നിവ കർശനമായ വിപരീതങ്ങളായതിനുപുറമെ, സമത്വം ആയിരിക്കണം (എല്ലാ `a`, `b`, `c` എന്നിവയ്ക്കും):
///
/// - reflexive: `a == a`;
/// - സമമിതി: `a == b` എന്നത് `b == a` സൂചിപ്പിക്കുന്നു;ഒപ്പം
/// - ട്രാൻസിറ്റീവ്: `a == b`, `b == c` എന്നിവ `a == c` സൂചിപ്പിക്കുന്നു.
///
/// ഈ പ്രോപ്പർ‌ട്ടി കംപൈലർ‌ക്ക് പരിശോധിക്കാൻ‌കഴിയില്ല, അതിനാൽ‌`Eq` എന്നത് [`PartialEq`] നെ സൂചിപ്പിക്കുന്നു, കൂടാതെ അധിക മാർ‌ഗ്ഗങ്ങളൊന്നുമില്ല.
///
/// ## Derivable
///
/// ഈ trait `#[derive]` ഉപയോഗിച്ച് ഉപയോഗിക്കാം.
/// `ഡെറിവ്` ചെയ്യുമ്പോൾ, `Eq`-ന് അധിക രീതികളില്ലാത്തതിനാൽ, ഇത് ഭാഗിക തുല്യതാ ബന്ധത്തേക്കാൾ ഒരു തുല്യതാ ബന്ധമാണെന്ന് കംപൈലറെ അറിയിക്കുക മാത്രമാണ് ചെയ്യുന്നത്.
///
/// `derive` തന്ത്രത്തിന് എല്ലാ ഫീൽഡുകളും `Eq` ആവശ്യമാണെന്ന് ശ്രദ്ധിക്കുക, അത് എല്ലായ്പ്പോഴും ആവശ്യമില്ല.
///
/// ## എനിക്ക് എങ്ങനെ `Eq` നടപ്പിലാക്കാൻ കഴിയും?
///
/// നിങ്ങൾക്ക് `derive` തന്ത്രം ഉപയോഗിക്കാൻ കഴിയുന്നില്ലെങ്കിൽ, നിങ്ങളുടെ തരം `Eq` നടപ്പിലാക്കുന്നുവെന്ന് വ്യക്തമാക്കുക, അതിന് രീതികളൊന്നുമില്ല:
///
/// ```
/// enum BookFormat { Paperback, Hardback, Ebook }
/// struct Book {
///     isbn: i32,
///     format: BookFormat,
/// }
/// impl PartialEq for Book {
///     fn eq(&self, other: &Self) -> bool {
///         self.isbn == other.isbn
///     }
/// }
/// impl Eq for Book {}
/// ```
///
///
///
///
///
#[doc(alias = "==")]
#[doc(alias = "!=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Eq: PartialEq<Self> {
    // ഒരു തരം എല്ലാ ഘടകങ്ങളും#[ഡെറിവിംഗ്] നടപ്പിലാക്കുന്നുവെന്ന് ഉറപ്പിക്കാൻ ഈ രീതി#[ഡെറിവിംഗ്] മാത്രമാണ് ഉപയോഗിക്കുന്നത്, നിലവിലെ ഡെറിവേറ്റിംഗ് ഇൻഫ്രാസ്ട്രക്ചർ എന്നതിനർത്ഥം ഈ trait-ൽ ഒരു രീതി ഉപയോഗിക്കാതെ ഈ വാദം നടത്തുന്നത് അസാധ്യമാണ്.
    //
    //
    // ഇത് ഒരിക്കലും കൈകൊണ്ട് നടപ്പാക്കരുത്.
    //
    //
    //
    #[doc(hidden)]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn assert_receiver_is_total_eq(&self) {}
}

/// trait `Eq`-ന്റെ ഒരു impl സൃഷ്ടിക്കുന്ന മാക്രോ ഡെറിവ് ചെയ്യുക.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_eq, structural_match)]
pub macro Eq($item:item) {
    /* compiler built-in */
}

// FIXME: ഈ സ്ട്രക്റ്റ് ഉപയോഗിക്കുന്നത്#[ഡെറിവ്] ടു മാത്രമാണ്
// ഒരു തരത്തിന്റെ എല്ലാ ഘടകങ്ങളും Eq നടപ്പിലാക്കുന്നുവെന്ന് വാദിക്കുക.
//
// ഈ ഘടന ഒരിക്കലും ഉപയോക്തൃ കോഡിൽ ദൃശ്യമാകരുത്.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(feature = "derive_eq", reason = "deriving hack, should not be public", issue = "none")]
pub struct AssertParamIsEq<T: Eq + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// രണ്ട് മൂല്യങ്ങൾ തമ്മിലുള്ള താരതമ്യത്തിന്റെ ഫലമാണ് ഒരു `Ordering`.
///
/// # Examples
///
/// ```
/// use std::cmp::Ordering;
///
/// let result = 1.cmp(&2);
/// assert_eq!(Ordering::Less, result);
///
/// let result = 1.cmp(&1);
/// assert_eq!(Ordering::Equal, result);
///
/// let result = 2.cmp(&1);
/// assert_eq!(Ordering::Greater, result);
/// ```
#[derive(Clone, Copy, PartialEq, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Ordering {
    /// താരതമ്യപ്പെടുത്തിയ മൂല്യം മറ്റൊന്നിനേക്കാൾ കുറവുള്ള ഒരു ക്രമം.
    #[stable(feature = "rust1", since = "1.0.0")]
    Less = -1,
    /// താരതമ്യപ്പെടുത്തുന്ന മൂല്യം മറ്റൊന്നിന് തുല്യമായ ഒരു ക്രമം.
    #[stable(feature = "rust1", since = "1.0.0")]
    Equal = 0,
    /// താരതമ്യപ്പെടുത്തുന്ന മൂല്യം മറ്റൊന്നിനേക്കാൾ വലുതായ ഒരു ക്രമം.
    #[stable(feature = "rust1", since = "1.0.0")]
    Greater = 1,
}

impl Ordering {
    /// ഓർ‌ഡറിംഗ് `Equal` വേരിയന്റാണെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_eq(), false);
    /// assert_eq!(Ordering::Equal.is_eq(), true);
    /// assert_eq!(Ordering::Greater.is_eq(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_eq(self) -> bool {
        matches!(self, Equal)
    }

    /// ഓർ‌ഡറിംഗ് `Equal` വേരിയന്റല്ലെങ്കിൽ‌`true` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ne(), true);
    /// assert_eq!(Ordering::Equal.is_ne(), false);
    /// assert_eq!(Ordering::Greater.is_ne(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ne(self) -> bool {
        !matches!(self, Equal)
    }

    /// ഓർ‌ഡറിംഗ് `Less` വേരിയന്റാണെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_lt(), true);
    /// assert_eq!(Ordering::Equal.is_lt(), false);
    /// assert_eq!(Ordering::Greater.is_lt(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_lt(self) -> bool {
        matches!(self, Less)
    }

    /// ഓർ‌ഡറിംഗ് `Greater` വേരിയന്റാണെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_gt(), false);
    /// assert_eq!(Ordering::Equal.is_gt(), false);
    /// assert_eq!(Ordering::Greater.is_gt(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_gt(self) -> bool {
        matches!(self, Greater)
    }

    /// ഓർഡറിംഗ് `Less` അല്ലെങ്കിൽ `Equal` വേരിയന്റാണെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_le(), true);
    /// assert_eq!(Ordering::Equal.is_le(), true);
    /// assert_eq!(Ordering::Greater.is_le(), false);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_le(self) -> bool {
        !matches!(self, Greater)
    }

    /// ഓർഡറിംഗ് `Greater` അല്ലെങ്കിൽ `Equal` വേരിയന്റാണെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(ordering_helpers)]
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.is_ge(), false);
    /// assert_eq!(Ordering::Equal.is_ge(), true);
    /// assert_eq!(Ordering::Greater.is_ge(), true);
    /// ```
    #[inline]
    #[must_use]
    #[unstable(feature = "ordering_helpers", issue = "79885")]
    pub const fn is_ge(self) -> bool {
        !matches!(self, Less)
    }

    /// `Ordering` വിപരീതമാക്കുന്നു.
    ///
    /// * `Less` `Greater` ആയി മാറുന്നു.
    /// * `Greater` `Less` ആയി മാറുന്നു.
    /// * `Equal` `Equal` ആയി മാറുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന സ്വഭാവം:
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(Ordering::Less.reverse(), Ordering::Greater);
    /// assert_eq!(Ordering::Equal.reverse(), Ordering::Equal);
    /// assert_eq!(Ordering::Greater.reverse(), Ordering::Less);
    /// ```
    ///
    /// ഒരു താരതമ്യം വിപരീതമാക്കാൻ ഈ രീതി ഉപയോഗിക്കാം:
    ///
    /// ```
    /// let data: &mut [_] = &mut [2, 10, 5, 8];
    ///
    /// // അറേ ഏറ്റവും വലുത് മുതൽ ചെറുത് വരെ അടുക്കുക.
    /// data.sort_by(|a, b| a.cmp(b).reverse());
    ///
    /// let b: &mut [_] = &mut [10, 8, 5, 2];
    /// assert!(data == b);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn reverse(self) -> Ordering {
        match self {
            Less => Greater,
            Equal => Equal,
            Greater => Less,
        }
    }

    /// ചങ്ങലകൾ രണ്ട് ക്രമങ്ങൾ.
    ///
    /// `Equal` അല്ലാത്തപ്പോൾ `self` നൽകുന്നു.അല്ലെങ്കിൽ `other` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then(Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then(Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then(Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then(x.1.cmp(&y.1)).then(x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[rustc_const_stable(feature = "const_ordering", since = "1.48.0")]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub const fn then(self, other: Ordering) -> Ordering {
        match self {
            Equal => other,
            _ => self,
        }
    }

    /// തന്നിരിക്കുന്ന ഫംഗ്ഷൻ ഉപയോഗിച്ച് ഓർഡറിംഗ് ചെയിൻ ചെയ്യുന്നു.
    ///
    /// `Equal` അല്ലാത്തപ്പോൾ `self` നൽകുന്നു.
    /// അല്ലെങ്കിൽ `f`-ലേക്ക് വിളിച്ച് ഫലം നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Less);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Less.then_with(|| Ordering::Greater);
    /// assert_eq!(result, Ordering::Less);
    ///
    /// let result = Ordering::Equal.then_with(|| Ordering::Equal);
    /// assert_eq!(result, Ordering::Equal);
    ///
    /// let x: (i64, i64, i64) = (1, 2, 7);
    /// let y: (i64, i64, i64) = (1, 5, 3);
    /// let result = x.0.cmp(&y.0).then_with(|| x.1.cmp(&y.1)).then_with(|| x.2.cmp(&y.2));
    ///
    /// assert_eq!(result, Ordering::Less);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "ordering_chaining", since = "1.17.0")]
    pub fn then_with<F: FnOnce() -> Ordering>(self, f: F) -> Ordering {
        match self {
            Equal => f(),
            _ => self,
        }
    }
}

/// റിവേഴ്സ് ഓർ‌ഡറിംഗിനായുള്ള ഒരു സഹായി ഘടന.
///
/// എക്സ് 100 എക്സ് പോലുള്ള ഫംഗ്ഷനുകൾക്കൊപ്പം ഉപയോഗിക്കേണ്ട ഒരു സഹായിയാണ് ഈ സ്ട്രക്റ്റ്, ഒരു കീയുടെ ഒരു ഭാഗം റിവേഴ്സ് ഓർഡർ ചെയ്യാൻ ഇത് ഉപയോഗിക്കാം.
///
///
/// [`Vec::sort_by_key`]: ../../std/vec/struct.Vec.html#method.sort_by_key
///
/// # Examples
///
/// ```
/// use std::cmp::Reverse;
///
/// let mut v = vec![1, 2, 3, 4, 5, 6];
/// v.sort_by_key(|&num| (num > 3, Reverse(num)));
/// assert_eq!(v, vec![3, 2, 1, 6, 5, 4]);
/// ```
#[derive(PartialEq, Eq, Debug, Copy, Clone, Default, Hash)]
#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
#[repr(transparent)]
pub struct Reverse<T>(#[stable(feature = "reverse_cmp_key", since = "1.19.0")] pub T);

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: PartialOrd> PartialOrd for Reverse<T> {
    #[inline]
    fn partial_cmp(&self, other: &Reverse<T>) -> Option<Ordering> {
        other.0.partial_cmp(&self.0)
    }

    #[inline]
    fn lt(&self, other: &Self) -> bool {
        other.0 < self.0
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        other.0 <= self.0
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        other.0 > self.0
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        other.0 >= self.0
    }
}

#[stable(feature = "reverse_cmp_key", since = "1.19.0")]
impl<T: Ord> Ord for Reverse<T> {
    #[inline]
    fn cmp(&self, other: &Reverse<T>) -> Ordering {
        other.0.cmp(&self.0)
    }
}

/// ഒരു [total order](https://en.wikipedia.org/wiki/Total_order) രൂപപ്പെടുന്ന തരങ്ങൾക്കായി Trait.
///
/// ഒരു ഓർഡർ ഉണ്ടെങ്കിൽ ആകെ ഓർഡറാണ് (എല്ലാ `a`, `b`, `c` എന്നിവയ്‌ക്കും):
///
/// - ആകെ, അസമമിതി: കൃത്യമായി `a < b`, `a == b` അല്ലെങ്കിൽ `a > b` എന്നിവയിൽ ഒന്ന് ശരിയാണ്;ഒപ്പം
/// - ട്രാൻസിറ്റീവ്, `a < b`, `b < c` എന്നിവ `a < c` സൂചിപ്പിക്കുന്നു.`==`, `>` എന്നിവയ്‌ക്കും ഇത് സമാനമായിരിക്കണം.
///
/// ## Derivable
///
/// ഈ trait `#[derive]` ഉപയോഗിച്ച് ഉപയോഗിക്കാം.
/// സ്ട്രക്റ്റുകളിൽ `ഡെറിവ്` ചെയ്യുമ്പോൾ, സ്ട്രക്റ്റ് അംഗങ്ങളുടെ മുകളിൽ നിന്ന് താഴേക്ക് ഡിക്ലറേഷൻ ഓർഡറിനെ അടിസ്ഥാനമാക്കി ഇത് ഒരു എക്സ് 00 എക്സ് ഓർഡറിംഗ് സൃഷ്ടിക്കും.
///
/// ഇനാമുകളിൽ `ഡെറിവ്` ചെയ്യുമ്പോൾ, വേരിയന്റുകൾ അവയുടെ മുകളിൽ നിന്ന് താഴേക്ക് വിവേചന ക്രമത്തിൽ ക്രമീകരിച്ചിരിക്കുന്നു.
///
/// ## ലെക്സിക്കോഗ്രാഫിക്കൽ താരതമ്യം
///
/// ഇനിപ്പറയുന്ന സവിശേഷതകളുള്ള ഒരു പ്രവർത്തനമാണ് ലെക്സിക്കോഗ്രാഫിക്കൽ താരതമ്യം:
///  - രണ്ട് സീക്വൻസുകളെ ഘടകത്തെ ഘടകവുമായി താരതമ്യം ചെയ്യുന്നു.
///  - പൊരുത്തപ്പെടാത്ത ആദ്യ ഘടകം ഏത് ശ്രേണിയെ നിഘണ്ടുവിൽ മറ്റൊന്നിനേക്കാൾ കുറവോ വലുതോ എന്ന് നിർവചിക്കുന്നു.
///  - ഒരു ശ്രേണി മറ്റൊന്നിന്റെ പ്രിഫിക്‌സാണെങ്കിൽ, ഹ്രസ്വ ശ്രേണി മറ്റേതിനേക്കാൾ നിഘണ്ടുവിൽ കുറവാണ്.
///  - രണ്ട് ശ്രേണിക്ക് തുല്യ ഘടകങ്ങളുണ്ടെങ്കിൽ ഒരേ നീളമുണ്ടെങ്കിൽ, സീക്വൻസുകൾ നിഘണ്ടുവിൽ തുല്യമാണ്.
///  - ശൂന്യമായ ഒരു ശ്രേണി ശൂന്യമല്ലാത്ത ഏതൊരു സീക്വൻസിനേക്കാളും കുറവാണ്.
///  - ശൂന്യമായ രണ്ട് സീക്വൻസുകൾ നിഘണ്ടുവിൽ തുല്യമാണ്.
///
/// ## എനിക്ക് എങ്ങനെ `Ord` നടപ്പിലാക്കാൻ കഴിയും?
///
/// `Ord` തരം [`PartialOrd`], [`Eq`] എന്നിവയും ആവശ്യമാണ് (ഇതിന് [`PartialEq`] ആവശ്യമാണ്).
///
/// തുടർന്ന് നിങ്ങൾ [`cmp`]-നായി ഒരു നടപ്പാക്കൽ നിർവചിക്കണം.നിങ്ങളുടെ തരം ഫീൽഡുകളിൽ [`cmp`] ഉപയോഗിക്കുന്നത് ഉപയോഗപ്രദമാകും.
///
/// [`PartialEq`], [`PartialOrd`], `Ord` * എന്നിവയുടെ നടപ്പാക്കലുകൾ‌പരസ്പരം യോജിപ്പിക്കണം.
/// അതായത്, എല്ലാ `a`, `b` എന്നിവയ്‌ക്കുമായി `a == b`, `Some(a.cmp(b)) == a.partial_cmp(b)` എന്നിവ ഉണ്ടെങ്കിൽ മാത്രം.
/// traits-ൽ ചിലത് നേടുകയും മറ്റുള്ളവ സ്വമേധയാ നടപ്പിലാക്കുകയും ചെയ്യുന്നതിലൂടെ ആകസ്മികമായി അവരെ വിയോജിക്കുന്നത് എളുപ്പമാണ്.
///
/// `id`, `name` എന്നിവ അവഗണിച്ച് ആളുകളെ ഉയരത്തിൽ മാത്രം അടുക്കാൻ നിങ്ങൾ ആഗ്രഹിക്കുന്ന ഒരു ഉദാഹരണം ഇതാ:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// [`cmp`]: Ord::cmp
///
///
///
#[doc(alias = "<")]
#[doc(alias = ">")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Ord: Eq + PartialOrd<Self> {
    /// ഈ രീതി `self` നും `other` നും ഇടയിൽ ഒരു [`Ordering`] നൽകുന്നു.
    ///
    /// കൺ‌വെൻഷൻ‌പ്രകാരം, ശരിയാണെങ്കിൽ‌`self <operator> other` എക്‌സ്‌പ്രഷനുമായി പൊരുത്തപ്പെടുന്ന ഓർ‌ഡറിംഗ് `self.cmp(&other)` നൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!(5.cmp(&10), Ordering::Less);
    /// assert_eq!(10.cmp(&5), Ordering::Greater);
    /// assert_eq!(5.cmp(&5), Ordering::Equal);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cmp(&self, other: &Self) -> Ordering;

    /// പരമാവധി രണ്ട് മൂല്യങ്ങൾ താരതമ്യപ്പെടുത്തി നൽകുന്നു.
    ///
    /// താരതമ്യം തുല്യമാണെന്ന് നിർണ്ണയിക്കുകയാണെങ്കിൽ രണ്ടാമത്തെ ആർഗ്യുമെൻറ് നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(2, 1.max(2));
    /// assert_eq!(2, 2.max(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn max(self, other: Self) -> Self
    where
        Self: Sized,
    {
        max_by(self, other, Ord::cmp)
    }

    /// ഏറ്റവും കുറഞ്ഞ രണ്ട് മൂല്യങ്ങളെ താരതമ്യപ്പെടുത്തി നൽകുന്നു.
    ///
    /// താരതമ്യം തുല്യമാണെന്ന് നിർണ്ണയിക്കുകയാണെങ്കിൽ ആദ്യ വാദം നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(1, 1.min(2));
    /// assert_eq!(2, 2.min(2));
    /// ```
    #[stable(feature = "ord_max_min", since = "1.21.0")]
    #[inline]
    #[must_use]
    fn min(self, other: Self) -> Self
    where
        Self: Sized,
    {
        min_by(self, other, Ord::cmp)
    }

    /// ഒരു നിശ്ചിത ഇടവേളയിലേക്ക് ഒരു മൂല്യം നിയന്ത്രിക്കുക.
    ///
    /// `self` `max` നേക്കാൾ വലുതാണെങ്കിൽ `max`, `self` `min` നേക്കാൾ കുറവാണെങ്കിൽ `min` എന്നിവ നൽകുന്നു.
    /// അല്ലെങ്കിൽ ഇത് `self` നൽകുന്നു.
    ///
    /// # Panics
    ///
    /// `min > max` എങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3).clamp(-2, 1) == -2);
    /// assert!(0.clamp(-2, 1) == 0);
    /// assert!(2.clamp(-2, 1) == 1);
    /// ```
    #[must_use]
    #[stable(feature = "clamp", since = "1.50.0")]
    fn clamp(self, min: Self, max: Self) -> Self
    where
        Self: Sized,
    {
        assert!(min <= max);
        if self < min {
            min
        } else if self > max {
            max
        } else {
            self
        }
    }
}

/// trait `Ord`-ന്റെ ഒരു impl സൃഷ്ടിക്കുന്ന മാക്രോ ഡെറിവ് ചെയ്യുക.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro Ord($item:item) {
    /* compiler built-in */
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for Ordering {}

#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for Ordering {
    #[inline]
    fn cmp(&self, other: &Ordering) -> Ordering {
        (*self as i32).cmp(&(*other as i32))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for Ordering {
    #[inline]
    fn partial_cmp(&self, other: &Ordering) -> Option<Ordering> {
        (*self as i32).partial_cmp(&(*other as i32))
    }
}

/// ഒരു സോർട്ട് ഓർഡറിനായി താരതമ്യപ്പെടുത്താവുന്ന മൂല്യങ്ങൾക്കായി Trait.
///
/// എല്ലാ `a`, `b`, `c` എന്നിവയ്‌ക്കും താരതമ്യം തൃപ്‌തിപ്പെടുത്തണം:
///
/// - അസമമിതി: `a < b` ആണെങ്കിൽ `!(a > b)`, `!(a < b)` സൂചിപ്പിക്കുന്ന `a > b`;ഒപ്പം
/// - ട്രാൻസിറ്റിവിറ്റി: `a < b`, `b < c` എന്നിവ `a < c` സൂചിപ്പിക്കുന്നു.`==`, `>` എന്നിവയ്‌ക്കും ഇത് സമാനമായിരിക്കണം.
///
/// ഈ ആവശ്യകതകൾ അർത്ഥമാക്കുന്നത് trait തന്നെ സമമിതിയിലും പരിവർത്തനപരമായും നടപ്പിലാക്കണം എന്നാണ്: `T: PartialOrd<U>`, `U: PartialOrd<V>` എന്നിവയാണെങ്കിൽ `U: PartialOrd<T>`, `T:
///
/// PartialOrd<V>`.
///
/// ## Derivable
///
/// ഈ trait `#[derive]` ഉപയോഗിച്ച് ഉപയോഗിക്കാം.സ്ട്രക്റ്റുകളിൽ `ഡെറിവ്` ചെയ്യുമ്പോൾ, സ്ട്രക്റ്റ് അംഗങ്ങളുടെ മുകളിൽ നിന്ന് താഴേക്ക് ഡിക്ലറേഷൻ ഓർഡറിനെ അടിസ്ഥാനമാക്കി ഇത് ഒരു നിഘണ്ടു ക്രമം സൃഷ്ടിക്കും.
/// ഇനാമുകളിൽ `ഡെറിവ്` ചെയ്യുമ്പോൾ, വേരിയന്റുകൾ അവയുടെ മുകളിൽ നിന്ന് താഴേക്ക് വിവേചന ക്രമത്തിൽ ക്രമീകരിച്ചിരിക്കുന്നു.
///
/// ## എനിക്ക് എങ്ങനെ `PartialOrd` നടപ്പിലാക്കാൻ കഴിയും?
///
/// `PartialOrd` സ്ഥിരസ്ഥിതി നടപ്പാക്കലുകളിൽ നിന്ന് ജനറേറ്റുചെയ്‌ത [`partial_cmp`] രീതി നടപ്പിലാക്കാൻ മാത്രമേ ആവശ്യമുള്ളൂ.
///
/// എന്നിരുന്നാലും മൊത്തം ഓർ‌ഡർ‌ഇല്ലാത്ത തരങ്ങൾ‌ക്കായി മറ്റുള്ളവ പ്രത്യേകമായി നടപ്പിലാക്കാൻ‌കഴിയും.
/// ഉദാഹരണത്തിന്, ഫ്ലോട്ടിംഗ് പോയിൻറ് നമ്പറുകൾക്കായി, `NaN < 0 == false`, `NaN >= 0 == false` (cf.
/// IEEE 754-2008 വിഭാഗം 5.11).
///
/// `PartialOrd` നിങ്ങളുടെ തരം [`PartialEq`] ആയിരിക്കണം.
///
/// [`PartialEq`], `PartialOrd`, [`Ord`] * എന്നിവയുടെ നടപ്പാക്കലുകൾ‌പരസ്പരം യോജിപ്പിക്കണം.
/// traits-ൽ ചിലത് നേടുകയും മറ്റുള്ളവ സ്വമേധയാ നടപ്പിലാക്കുകയും ചെയ്യുന്നതിലൂടെ ആകസ്മികമായി അവരെ വിയോജിക്കുന്നത് എളുപ്പമാണ്.
///
/// നിങ്ങളുടെ തരം [`Ord`] ആണെങ്കിൽ, [`cmp`] ഉപയോഗിച്ച് നിങ്ങൾക്ക് [`partial_cmp`] നടപ്പിലാക്കാൻ കഴിയും:
///
/// ```
/// use std::cmp::Ordering;
///
/// #[derive(Eq)]
/// struct Person {
///     id: u32,
///     name: String,
///     height: u32,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         Some(self.cmp(other))
///     }
/// }
///
/// impl Ord for Person {
///     fn cmp(&self, other: &Self) -> Ordering {
///         self.height.cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// നിങ്ങളുടെ തരം ഫീൽഡുകളിൽ [`partial_cmp`] ഉപയോഗിക്കുന്നതും നിങ്ങൾക്ക് ഉപയോഗപ്രദമാകും.
/// ഒരു ഫ്ലോട്ടിംഗ്-പോയിൻറ് `height` ഫീൽഡ് ഉള്ള `Person` തരങ്ങളുടെ ഒരു ഉദാഹരണം ഇതാ, ഇത് അടുക്കുന്നതിന് ഉപയോഗിക്കുന്ന ഒരേയൊരു ഫീൽഡ്:
///
/// ```
/// use std::cmp::Ordering;
///
/// struct Person {
///     id: u32,
///     name: String,
///     height: f64,
/// }
///
/// impl PartialOrd for Person {
///     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
///         self.height.partial_cmp(&other.height)
///     }
/// }
///
/// impl PartialEq for Person {
///     fn eq(&self, other: &Self) -> bool {
///         self.height == other.height
///     }
/// }
/// ```
///
/// # Examples
///
/// ```
/// let x : u32 = 0;
/// let y : u32 = 1;
///
/// assert_eq!(x < y, true);
/// assert_eq!(x.lt(&y), true);
/// ```
///
/// [`partial_cmp`]: PartialOrd::partial_cmp
/// [`cmp`]: Ord::cmp
///
///
///
///
#[lang = "partial_ord"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = ">")]
#[doc(alias = "<")]
#[doc(alias = "<=")]
#[doc(alias = ">=")]
#[rustc_on_unimplemented(
    message = "can't compare `{Self}` with `{Rhs}`",
    label = "no implementation for `{Self} < {Rhs}` and `{Self} > {Rhs}`"
)]
pub trait PartialOrd<Rhs: ?Sized = Self>: PartialEq<Rhs> {
    /// ഈ രീതി `self` നും `other` മൂല്യങ്ങൾക്കുമിടയിൽ ഒരു ക്രമം നൽകുന്നുവെങ്കിൽ.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// let result = 1.0.partial_cmp(&2.0);
    /// assert_eq!(result, Some(Ordering::Less));
    ///
    /// let result = 1.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Equal));
    ///
    /// let result = 2.0.partial_cmp(&1.0);
    /// assert_eq!(result, Some(Ordering::Greater));
    /// ```
    ///
    /// താരതമ്യം അസാധ്യമാകുമ്പോൾ:
    ///
    /// ```
    /// let result = f64::NAN.partial_cmp(&1.0);
    /// assert_eq!(result, None);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partial_cmp(&self, other: &Rhs) -> Option<Ordering>;

    /// ഈ രീതി (`self`, `other` എന്നിവയ്‌ക്ക്) കുറവാണ് പരിശോധിക്കുന്നത്, ഇത് `<` ഓപ്പറേറ്റർ ഉപയോഗിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 < 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 < 1.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn lt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less))
    }

    /// ഈ രീതി (`self`, `other` എന്നിവയ്‌ക്ക്) കുറവോ തുല്യമോ ആണെന്ന് പരിശോധിക്കുന്നു, ഇത് `<=` ഓപ്പറേറ്റർ ഉപയോഗിക്കുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 <= 2.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 <= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn le(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Less | Equal))
    }

    /// ഈ രീതി (`self`, `other` എന്നിവയ്‌ക്ക്) കൂടുതലാണെന്ന് പരിശോധിക്കുന്നു, ഇത് `>` ഓപ്പറേറ്റർ ഉപയോഗിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 1.0 > 2.0;
    /// assert_eq!(result, false);
    ///
    /// let result = 2.0 > 2.0;
    /// assert_eq!(result, false);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn gt(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater))
    }

    /// ഈ രീതി (`self`, `other` എന്നിവയ്‌ക്ക്) വലുതോ തുല്യമോ ആണെന്ന് പരിശോധിക്കുന്നു, ഇത് `>=` ഓപ്പറേറ്റർ ഉപയോഗിക്കുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let result = 2.0 >= 1.0;
    /// assert_eq!(result, true);
    ///
    /// let result = 2.0 >= 2.0;
    /// assert_eq!(result, true);
    /// ```
    #[inline]
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn ge(&self, other: &Rhs) -> bool {
        matches!(self.partial_cmp(other), Some(Greater | Equal))
    }
}

/// trait `PartialOrd`-ന്റെ ഒരു impl സൃഷ്ടിക്കുന്ന മാക്രോ ഡെറിവ് ചെയ്യുക.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics)]
pub macro PartialOrd($item:item) {
    /* compiler built-in */
}

/// ഏറ്റവും കുറഞ്ഞ രണ്ട് മൂല്യങ്ങളെ താരതമ്യപ്പെടുത്തി നൽകുന്നു.
///
/// താരതമ്യം തുല്യമാണെന്ന് നിർണ്ണയിക്കുകയാണെങ്കിൽ ആദ്യ വാദം നൽകുന്നു.
///
/// ആന്തരികമായി [`Ord::min`]-ലേക്ക് ഒരു അപരനാമം ഉപയോഗിക്കുന്നു.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(1, cmp::min(1, 2));
/// assert_eq!(2, cmp::min(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn min<T: Ord>(v1: T, v2: T) -> T {
    v1.min(v2)
}

/// നിർദ്ദിഷ്ട താരതമ്യ പ്രവർത്തനവുമായി ബന്ധപ്പെട്ട് കുറഞ്ഞത് രണ്ട് മൂല്യങ്ങൾ നൽകുന്നു.
///
/// താരതമ്യം തുല്യമാണെന്ന് നിർണ്ണയിക്കുകയാണെങ്കിൽ ആദ്യ വാദം നൽകുന്നു.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 1);
/// assert_eq!(cmp::min_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v1,
        Ordering::Greater => v2,
    }
}

/// നിർദ്ദിഷ്ട ഫംഗ്‌ഷനിൽ നിന്ന് ഏറ്റവും കുറഞ്ഞ മൂല്യം നൽകുന്ന ഘടകം നൽകുന്നു.
///
/// താരതമ്യം തുല്യമാണെന്ന് നിർണ്ണയിക്കുകയാണെങ്കിൽ ആദ്യ വാദം നൽകുന്നു.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::min_by_key(-2, 1, |x: &i32| x.abs()), 1);
/// assert_eq!(cmp::min_by_key(-2, 2, |x: &i32| x.abs()), -2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn min_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    min_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

/// പരമാവധി രണ്ട് മൂല്യങ്ങൾ താരതമ്യപ്പെടുത്തി നൽകുന്നു.
///
/// താരതമ്യം തുല്യമാണെന്ന് നിർണ്ണയിക്കുകയാണെങ്കിൽ രണ്ടാമത്തെ ആർഗ്യുമെൻറ് നൽകുന്നു.
///
/// ആന്തരികമായി [`Ord::max`]-ലേക്ക് ഒരു അപരനാമം ഉപയോഗിക്കുന്നു.
///
/// # Examples
///
/// ```
/// use std::cmp;
///
/// assert_eq!(2, cmp::max(1, 2));
/// assert_eq!(2, cmp::max(2, 2));
/// ```
#[inline]
#[must_use]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn max<T: Ord>(v1: T, v2: T) -> T {
    v1.max(v2)
}

/// നിർദ്ദിഷ്ട താരതമ്യ പ്രവർത്തനവുമായി ബന്ധപ്പെട്ട് പരമാവധി രണ്ട് മൂല്യങ്ങൾ നൽകുന്നു.
///
/// താരതമ്യം തുല്യമാണെന്ന് നിർണ്ണയിക്കുകയാണെങ്കിൽ രണ്ടാമത്തെ ആർഗ്യുമെൻറ് നൽകുന്നു.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by(-2, 1, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), -2);
/// assert_eq!(cmp::max_by(-2, 2, |x: &i32, y: &i32| x.abs().cmp(&y.abs())), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by<T, F: FnOnce(&T, &T) -> Ordering>(v1: T, v2: T, compare: F) -> T {
    match compare(&v1, &v2) {
        Ordering::Less | Ordering::Equal => v2,
        Ordering::Greater => v1,
    }
}

/// നിർദ്ദിഷ്ട ഫംഗ്‌ഷനിൽ നിന്ന് പരമാവധി മൂല്യം നൽകുന്ന ഘടകം നൽകുന്നു.
///
/// താരതമ്യം തുല്യമാണെന്ന് നിർണ്ണയിക്കുകയാണെങ്കിൽ രണ്ടാമത്തെ ആർഗ്യുമെൻറ് നൽകുന്നു.
///
/// # Examples
///
/// ```
/// #![feature(cmp_min_max_by)]
///
/// use std::cmp;
///
/// assert_eq!(cmp::max_by_key(-2, 1, |x: &i32| x.abs()), -2);
/// assert_eq!(cmp::max_by_key(-2, 2, |x: &i32| x.abs()), 2);
/// ```
#[inline]
#[must_use]
#[unstable(feature = "cmp_min_max_by", issue = "64460")]
pub fn max_by_key<T, F: FnMut(&T) -> K, K: Ord>(v1: T, v2: T, mut f: F) -> T {
    max_by(v1, v2, |v1, v2| f(v1).cmp(&f(v2)))
}

// പ്രാകൃത തരങ്ങൾക്കായി ഭാഗിക എക്, ഇക്, ഭാഗിക ഓർഡ്, ഓർഡ് എന്നിവ നടപ്പിലാക്കുന്നു
mod impls {
    use crate::cmp::Ordering::{self, Equal, Greater, Less};
    use crate::hint::unreachable_unchecked;

    macro_rules! partial_eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialEq for $t {
                #[inline]
                fn eq(&self, other: &$t) -> bool { (*self) == (*other) }
                #[inline]
                fn ne(&self, other: &$t) -> bool { (*self) != (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialEq for () {
        #[inline]
        fn eq(&self, _other: &()) -> bool {
            true
        }
        #[inline]
        fn ne(&self, _other: &()) -> bool {
            false
        }
    }

    partial_eq_impl! {
        bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64
    }

    macro_rules! eq_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl Eq for $t {}
        )*)
    }

    eq_impl! { () bool char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    macro_rules! partial_ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    match (self <= other, self >= other) {
                        (false, false) => None,
                        (false, true) => Some(Greater),
                        (true, false) => Some(Less),
                        (true, true) => Some(Equal),
                    }
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for () {
        #[inline]
        fn partial_cmp(&self, _: &()) -> Option<Ordering> {
            Some(Equal)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl PartialOrd for bool {
        #[inline]
        fn partial_cmp(&self, other: &bool) -> Option<Ordering> {
            Some(self.cmp(other))
        }
    }

    partial_ord_impl! { f32 f64 }

    macro_rules! ord_impl {
        ($($t:ty)*) => ($(
            #[stable(feature = "rust1", since = "1.0.0")]
            impl PartialOrd for $t {
                #[inline]
                fn partial_cmp(&self, other: &$t) -> Option<Ordering> {
                    Some(self.cmp(other))
                }
                #[inline]
                fn lt(&self, other: &$t) -> bool { (*self) < (*other) }
                #[inline]
                fn le(&self, other: &$t) -> bool { (*self) <= (*other) }
                #[inline]
                fn ge(&self, other: &$t) -> bool { (*self) >= (*other) }
                #[inline]
                fn gt(&self, other: &$t) -> bool { (*self) > (*other) }
            }

            #[stable(feature = "rust1", since = "1.0.0")]
            impl Ord for $t {
                #[inline]
                fn cmp(&self, other: &$t) -> Ordering {
                    // കൂടുതൽ ഒപ്റ്റിമൽ അസംബ്ലി സൃഷ്ടിക്കുന്നതിന് ഇവിടെ ഓർഡർ പ്രധാനമാണ്.
                    // കൂടുതൽ വിവരങ്ങൾക്ക് <https://github.com/rust-lang/rust/issues/63758> കാണുക.
                    if *self < *other { Less }
                    else if *self == *other { Equal }
                    else { Greater }
                }
            }
        )*)
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for () {
        #[inline]
        fn cmp(&self, _other: &()) -> Ordering {
            Equal
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl Ord for bool {
        #[inline]
        fn cmp(&self, other: &bool) -> Ordering {
            // I8-കളിലേക്ക് കാസ്റ്റുചെയ്യുന്നതും വ്യത്യാസം ഒരു ഓർഡറിംഗിലേക്ക് പരിവർത്തനം ചെയ്യുന്നതും കൂടുതൽ മികച്ച അസംബ്ലി സൃഷ്ടിക്കുന്നു.
            //
            // കൂടുതൽ വിവരങ്ങൾക്ക് <https://github.com/rust-lang/rust/issues/66780> കാണുക.
            match (*self as i8) - (*other as i8) {
                -1 => Less,
                0 => Equal,
                1 => Greater,
                // സുരക്ഷ: i8 ആയി bool 0 അല്ലെങ്കിൽ 1 നൽകുന്നു, അതിനാൽ വ്യത്യാസം മറ്റൊന്നാകരുത്
                _ => unsafe { unreachable_unchecked() },
            }
        }
    }

    ord_impl! { char usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialEq for ! {
        fn eq(&self, _: &!) -> bool {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Eq for ! {}

    #[unstable(feature = "never_type", issue = "35121")]
    impl PartialOrd for ! {
        fn partial_cmp(&self, _: &!) -> Option<Ordering> {
            *self
        }
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Ord for ! {
        fn cmp(&self, _: &!) -> Ordering {
            *self
        }
    }

    // &പോയിന്ററുകൾ

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&B> for &A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &A where A: Eq {}

    // &mut pointers

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialOrd<&mut B> for &mut A
    where
        A: PartialOrd<B>,
    {
        #[inline]
        fn partial_cmp(&self, other: &&mut B) -> Option<Ordering> {
            PartialOrd::partial_cmp(*self, *other)
        }
        #[inline]
        fn lt(&self, other: &&mut B) -> bool {
            PartialOrd::lt(*self, *other)
        }
        #[inline]
        fn le(&self, other: &&mut B) -> bool {
            PartialOrd::le(*self, *other)
        }
        #[inline]
        fn gt(&self, other: &&mut B) -> bool {
            PartialOrd::gt(*self, *other)
        }
        #[inline]
        fn ge(&self, other: &&mut B) -> bool {
            PartialOrd::ge(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Ord for &mut A
    where
        A: Ord,
    {
        #[inline]
        fn cmp(&self, other: &Self) -> Ordering {
            Ord::cmp(*self, *other)
        }
    }
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized> Eq for &mut A where A: Eq {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&mut B> for &A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&mut B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&mut B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A: ?Sized, B: ?Sized> PartialEq<&B> for &mut A
    where
        A: PartialEq<B>,
    {
        #[inline]
        fn eq(&self, other: &&B) -> bool {
            PartialEq::eq(*self, *other)
        }
        #[inline]
        fn ne(&self, other: &&B) -> bool {
            PartialEq::ne(*self, *other)
        }
    }
}