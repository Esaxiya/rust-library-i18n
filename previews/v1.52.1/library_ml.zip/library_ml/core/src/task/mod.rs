#![stable(feature = "futures_api", since = "1.36.0")]

//! അസിൻക്രണസ് ടാസ്‌ക്കുകളിൽ പ്രവർത്തിക്കുന്നതിനുള്ള തരങ്ങളും Traits ഉം.

mod poll;
#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::poll::Poll;

mod wake;
#[stable(feature = "futures_api", since = "1.36.0")]
pub use self::wake::{Context, RawWaker, RawWakerVTable, Waker};

mod ready;
#[unstable(feature = "ready_macro", issue = "70922")]
pub use ready::ready;