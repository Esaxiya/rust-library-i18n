#![unstable(feature = "unicode_internals", issue = "none")]
#![allow(missing_docs)]

pub(crate) mod printable;
mod unicode_data;

/// `char`, `str` രീതികളുടെ യൂണികോഡ് ഭാഗങ്ങൾ അടിസ്ഥാനമാക്കിയുള്ള [Unicode](http://www.unicode.org/)-ന്റെ പതിപ്പ്.
///
/// യൂണിക്കോഡിന്റെ പുതിയ പതിപ്പുകൾ പതിവായി പുറത്തിറങ്ങുന്നു, തുടർന്ന് യൂണിക്കോഡിനെ ആശ്രയിച്ച് സ്റ്റാൻഡേർഡ് ലൈബ്രറിയിലെ എല്ലാ രീതികളും അപ്‌ഡേറ്റുചെയ്യുന്നു.
/// അതിനാൽ ചില `char`, `str` രീതികളുടെ സ്വഭാവവും കാലക്രമേണ ഈ സ്ഥിരമായ മാറ്റത്തിന്റെ മൂല്യവും മാറുന്നു.
/// ഇത് * ഒരു തകർപ്പൻ മാറ്റമായി കണക്കാക്കില്ല.
///
/// പതിപ്പ് നമ്പറിംഗ് സ്കീം [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4) ൽ വിശദീകരിച്ചിരിക്കുന്നു.
///
///
///
#[stable(feature = "unicode_version", since = "1.45.0")]
pub const UNICODE_VERSION: (u8, u8, u8) = unicode_data::UNICODE_VERSION;

// Liballoc-ൽ ഉപയോഗിക്കുന്നതിന്, libstd-ൽ വീണ്ടും എക്‌സ്‌പോർട്ടുചെയ്യരുത്.
pub use unicode_data::{
    case_ignorable::lookup as Case_Ignorable, cased::lookup as Cased, conversions,
};

pub(crate) use unicode_data::alphabetic::lookup as Alphabetic;
pub(crate) use unicode_data::cc::lookup as Cc;
pub(crate) use unicode_data::grapheme_extend::lookup as Grapheme_Extend;
pub(crate) use unicode_data::lowercase::lookup as Lowercase;
pub(crate) use unicode_data::n::lookup as N;
pub(crate) use unicode_data::uppercase::lookup as Uppercase;
pub(crate) use unicode_data::white_space::lookup as White_Space;