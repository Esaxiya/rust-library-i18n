use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` എന്നാൽ പൂജ്യമല്ലാത്തതും കോവിയറന്റ്.
///
/// റോ പോയിന്ററുകൾ ഉപയോഗിച്ച് ഡാറ്റ ഘടനകൾ നിർമ്മിക്കുമ്പോൾ ഇത് പലപ്പോഴും ഉപയോഗിക്കേണ്ട ശരിയായ കാര്യമാണ്, പക്ഷേ ആത്യന്തികമായി അതിന്റെ അധിക സവിശേഷതകൾ കാരണം ഉപയോഗിക്കാൻ കൂടുതൽ അപകടകരമാണ്.നിങ്ങൾ `NonNull<T>` ഉപയോഗിക്കണമോ എന്ന് നിങ്ങൾക്ക് ഉറപ്പില്ലെങ്കിൽ, `*mut T` ഉപയോഗിക്കുക!
///
/// `*mut T`-ൽ നിന്ന് വ്യത്യസ്തമായി, പോയിന്റർ ഒരിക്കലും അസാധുവാക്കിയിട്ടില്ലെങ്കിലും, പോയിന്റർ എല്ലായ്പ്പോഴും ശൂന്യമായിരിക്കണം.ഈ വിലക്കപ്പെട്ട മൂല്യം വിവേചനാധികാരിയായി enums ഉപയോഗിച്ചേക്കാമെന്നതിനാലാണിത്-`Option<NonNull<T>>` ന് `* mut T` ന് സമാനമായ വലുപ്പമുണ്ട്.
/// എന്നിരുന്നാലും, പോയിന്റർ വ്യക്തമാക്കാതിരുന്നാൽ അത് തൂങ്ങിക്കിടക്കും.
///
/// `*mut T`-ൽ നിന്ന് വ്യത്യസ്തമായി, `T`-നെ `T`-നെക്കാൾ കോവിയറന്റായി തിരഞ്ഞെടുത്തു.കോവിയറന്റ് തരങ്ങൾ നിർമ്മിക്കുമ്പോൾ ഇത് `NonNull<T>` ഉപയോഗിക്കുന്നത് സാധ്യമാക്കുന്നു, പക്ഷേ യഥാർത്ഥത്തിൽ കോവിയറന്റ് ആകാൻ പാടില്ലാത്ത ഒരു തരത്തിൽ ഉപയോഗിച്ചാൽ അബോധാവസ്ഥയുടെ അപകടസാധ്യത അവതരിപ്പിക്കുന്നു.
/// (സുരക്ഷിതമല്ലാത്ത ഫംഗ്ഷനുകൾ‌വിളിക്കുന്നതിലൂടെ മാത്രമേ സാങ്കേതികമായി തെറ്റിദ്ധാരണയുണ്ടാകൂവെങ്കിലും `*mut T` നായി വിപരീത തിരഞ്ഞെടുപ്പ് നടത്തി.)
///
/// `Box`, `Rc`, `Arc`, `Vec`, `LinkedList` എന്നിവ പോലുള്ള ഏറ്റവും സുരക്ഷിതമായ അമൂർത്തങ്ങൾക്ക് കോവിയറൻസ് ശരിയാണ്.Rust-ന്റെ സാധാരണ പങ്കിട്ട XOR മ്യൂട്ടബിൾ നിയമങ്ങൾ പാലിക്കുന്ന ഒരു പൊതു API നൽകുന്നതിനാലാണ് ഇത് സംഭവിക്കുന്നത്.
///
/// നിങ്ങളുടെ തരം സുരക്ഷിതമായി കോവിയറന്റ് ആകാൻ‌കഴിയുന്നില്ലെങ്കിൽ‌, മാറ്റമില്ലായ്‌മ നൽ‌കുന്നതിന് അതിൽ‌ചില അധിക ഫീൽ‌ഡുകൾ‌അടങ്ങിയിരിക്കുന്നുവെന്ന് നിങ്ങൾ‌ഉറപ്പാക്കണം.മിക്കപ്പോഴും ഈ ഫീൽഡ് `PhantomData<Cell<T>>` അല്ലെങ്കിൽ `PhantomData<&'a mut T>` പോലുള്ള [`PhantomData`] തരം ആയിരിക്കും.
///
/// X002-ന് `NonNull<T>`-ന് `From` ഉദാഹരണമുണ്ടെന്ന് ശ്രദ്ധിക്കുക.എന്നിരുന്നാലും, ഒരു [`UnsafeCell<T>`]-നുള്ളിൽ മ്യൂട്ടേഷൻ സംഭവിച്ചില്ലെങ്കിൽ, ഒരു (പങ്കിട്ട റഫറൻസിൽ നിന്ന് ഉരുത്തിരിഞ്ഞത്) പങ്കിട്ട റഫറൻസിലൂടെ പരിവർത്തനം ചെയ്യുന്നത് നിർവചിക്കപ്പെടാത്ത സ്വഭാവമാണെന്ന വസ്തുതയെ ഇത് മാറ്റില്ല.പങ്കിട്ട റഫറൻസിൽ നിന്ന് മ്യൂട്ടബിൾ റഫറൻസ് സൃഷ്ടിക്കുന്നതിനും ഇത് ബാധകമാണ്.
///
/// `UnsafeCell<T>` ഇല്ലാതെ ഈ `From` ഇൻസ്റ്റൻസ് ഉപയോഗിക്കുമ്പോൾ, `as_mut` ഒരിക്കലും വിളിച്ചിട്ടില്ലെന്ന് ഉറപ്പാക്കേണ്ടത് നിങ്ങളുടെ ഉത്തരവാദിത്തമാണ്, കൂടാതെ `as_ptr` ഒരിക്കലും മ്യൂട്ടേഷനായി ഉപയോഗിക്കില്ല.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` പോയിന്ററുകൾ `Send` അല്ല കാരണം അവ പരാമർശിക്കുന്ന ഡാറ്റ അപരനാമമാകാം.
// NB, ഈ impl അനാവശ്യമാണ്, പക്ഷേ മികച്ച പിശക് സന്ദേശങ്ങൾ നൽകണം.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` പോയിന്ററുകൾ `Sync` അല്ല കാരണം അവ പരാമർശിക്കുന്ന ഡാറ്റ അപരനാമമാകാം.
// NB, ഈ impl അനാവശ്യമാണ്, പക്ഷേ മികച്ച പിശക് സന്ദേശങ്ങൾ നൽകണം.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// തൂങ്ങിക്കിടക്കുന്നതും എന്നാൽ നന്നായി വിന്യസിച്ചതുമായ ഒരു പുതിയ `NonNull` സൃഷ്ടിക്കുന്നു.
    ///
    /// `Vec::new` പോലെ അലസമായി അനുവദിക്കുന്ന തരങ്ങൾ സമാരംഭിക്കുന്നതിന് ഇത് ഉപയോഗപ്രദമാണ്.
    ///
    /// പോയിന്റർ മൂല്യം ഒരു `T`-ലേക്ക് സാധുവായ പോയിന്ററിനെ പ്രതിനിധീകരിക്കാൻ സാധ്യതയുണ്ട്, അതായത് ഇത് "not yet initialized" സെന്റിനൽ മൂല്യമായി ഉപയോഗിക്കരുത്.
    /// അലസമായി അനുവദിക്കുന്ന തരങ്ങൾ മറ്റ് മാർഗ്ഗങ്ങളിലൂടെ ഓർഗനൈസേഷൻ ട്രാക്കുചെയ്യണം.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // സുരക്ഷ: mem::align_of() പൂജ്യമല്ലാത്ത ഒരു ഉപയോഗം നൽകുന്നു, അത് കാസ്റ്റുചെയ്യുന്നു
        // ഒരു * മ്യൂട്ട് ടിയിലേക്ക്.
        // അതിനാൽ, `ptr` അസാധുവല്ല കൂടാതെ new_unchecked() വിളിക്കുന്നതിനുള്ള വ്യവസ്ഥകൾ മാനിക്കപ്പെടുന്നു.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// മൂല്യത്തിലേക്ക് പങ്കിട്ട റഫറൻസുകൾ നൽകുന്നു.[`as_ref`]-ന് വിപരീതമായി, മൂല്യം സമാരംഭിക്കേണ്ടതുണ്ട്.
    ///
    /// മ്യൂട്ടബിൾ ക p ണ്ടർപാർട്ടിനായി [`as_uninit_mut`] കാണുക.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// ഈ രീതി വിളിക്കുമ്പോൾ, ഇനിപ്പറയുന്നവയെല്ലാം ശരിയാണെന്ന് നിങ്ങൾ ഉറപ്പാക്കേണ്ടതുണ്ട്:
    ///
    /// * പോയിന്റർ ശരിയായി വിന്യസിക്കണം.
    ///
    /// * [the module documentation]-ൽ നിർവചിച്ചിരിക്കുന്ന അർത്ഥത്തിൽ ഇത് "dereferencable" ആയിരിക്കണം.
    ///
    /// * മടങ്ങിയെത്തിയ ആജീവനാന്ത `'a` ഏകപക്ഷീയമായി തിരഞ്ഞെടുക്കപ്പെട്ടതിനാൽ ഡാറ്റയുടെ യഥാർത്ഥ ആയുസ്സ് പ്രതിഫലിപ്പിക്കാത്തതിനാൽ നിങ്ങൾ Rust-ന്റെ അപരനാമ നിയമങ്ങൾ നടപ്പിലാക്കണം.
    ///
    ///   പ്രത്യേകിച്ചും, ഈ ജീവിതകാലത്തേക്ക്, പോയിന്റർ ചൂണ്ടിക്കാണിക്കുന്ന മെമ്മറി പരിവർത്തനം ചെയ്യരുത് (`UnsafeCell`-നുള്ളിൽ ഒഴികെ).
    ///
    /// ഈ രീതിയുടെ ഫലം ഉപയോഗിക്കാത്തതാണെങ്കിൽ പോലും ഇത് ബാധകമാണ്!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // സുരക്ഷ: `self` എല്ലാം പാലിക്കുന്നുവെന്ന് കോളർ ഉറപ്പ് നൽകണം
        // ഒരു റഫറൻസിനുള്ള ആവശ്യകതകൾ.
        unsafe { &*self.cast().as_ptr() }
    }

    /// മൂല്യത്തിലേക്ക് ഒരു അദ്വിതീയ റഫറൻസുകൾ നൽകുന്നു.[`as_mut`]-ന് വിപരീതമായി, മൂല്യം സമാരംഭിക്കേണ്ടതുണ്ട്.
    ///
    /// പങ്കിട്ട ക p ണ്ടർപാർട്ടിനായി [`as_uninit_ref`] കാണുക.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// ഈ രീതി വിളിക്കുമ്പോൾ, ഇനിപ്പറയുന്നവയെല്ലാം ശരിയാണെന്ന് നിങ്ങൾ ഉറപ്പാക്കേണ്ടതുണ്ട്:
    ///
    /// * പോയിന്റർ ശരിയായി വിന്യസിക്കണം.
    ///
    /// * [the module documentation]-ൽ നിർവചിച്ചിരിക്കുന്ന അർത്ഥത്തിൽ ഇത് "dereferencable" ആയിരിക്കണം.
    ///
    /// * മടങ്ങിയെത്തിയ ആജീവനാന്ത `'a` ഏകപക്ഷീയമായി തിരഞ്ഞെടുക്കപ്പെട്ടതിനാൽ ഡാറ്റയുടെ യഥാർത്ഥ ആയുസ്സ് പ്രതിഫലിപ്പിക്കാത്തതിനാൽ നിങ്ങൾ Rust-ന്റെ അപരനാമ നിയമങ്ങൾ നടപ്പിലാക്കണം.
    ///
    ///   പ്രത്യേകിച്ചും, ഈ ജീവിതകാലത്തേക്ക്, പോയിന്റർ ചൂണ്ടിക്കാണിക്കുന്ന മെമ്മറി മറ്റേതൊരു പോയിന്ററിലൂടെയും ആക്‌സസ് ചെയ്യരുത് (വായിക്കുകയോ എഴുതുകയോ ചെയ്യുക).
    ///
    /// ഈ രീതിയുടെ ഫലം ഉപയോഗിക്കാത്തതാണെങ്കിൽ പോലും ഇത് ബാധകമാണ്!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // സുരക്ഷ: `self` എല്ലാം പാലിക്കുന്നുവെന്ന് കോളർ ഉറപ്പ് നൽകണം
        // ഒരു റഫറൻസിനുള്ള ആവശ്യകതകൾ.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// ഒരു പുതിയ `NonNull` സൃഷ്ടിക്കുന്നു.
    ///
    /// # Safety
    ///
    /// `ptr` ശൂന്യമായിരിക്കണം.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // സുരക്ഷ: `ptr` ശൂന്യമല്ലെന്ന് കോളർ ഉറപ്പ് നൽകണം.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// `ptr` ശൂന്യമല്ലെങ്കിൽ ഒരു പുതിയ `NonNull` സൃഷ്ടിക്കുന്നു.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // സുരക്ഷ: പോയിന്റർ ഇതിനകം പരിശോധിച്ചു, അത് ശൂന്യമല്ല
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// ഒരു അസംസ്കൃത `*const` പോയിന്ററിന് വിപരീതമായി ഒരു `NonNull` പോയിന്റർ മടക്കിനൽകുന്നു എന്നതൊഴിച്ചാൽ [`std::ptr::from_raw_parts`]-ന്റെ അതേ പ്രവർത്തനം നിർവ്വഹിക്കുന്നു.
    ///
    ///
    /// കൂടുതൽ വിവരങ്ങൾക്ക് [`std::ptr::from_raw_parts`] ന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // സുരക്ഷ: `data_address` ആയതിനാൽ `ptr::from::raw_parts_mut` ന്റെ ഫലം അസാധുവാണ്.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// വിലാസവും മെറ്റാഡാറ്റ ഘടകങ്ങളുമാണ് (ഒരുപക്ഷേ വിശാലമായ) പോയിന്റർ വിഘടിപ്പിക്കുക.
    ///
    /// പോയിന്റർ പിന്നീട് [`NonNull::from_raw_parts`] ഉപയോഗിച്ച് പുനർനിർമ്മിക്കാൻ കഴിയും.
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// അന്തർലീനമായ `*mut` പോയിന്റർ നേടുന്നു.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// മൂല്യത്തിലേക്ക് ഒരു പങ്കിട്ട റഫറൻസ് നൽകുന്നു.മൂല്യം ആരംഭിക്കാത്തതാണെങ്കിൽ, പകരം [`as_uninit_ref`] ഉപയോഗിക്കണം.
    ///
    /// മ്യൂട്ടബിൾ ക p ണ്ടർപാർട്ടിനായി [`as_mut`] കാണുക.
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// ഈ രീതി വിളിക്കുമ്പോൾ, ഇനിപ്പറയുന്നവയെല്ലാം ശരിയാണെന്ന് നിങ്ങൾ ഉറപ്പാക്കേണ്ടതുണ്ട്:
    ///
    /// * പോയിന്റർ ശരിയായി വിന്യസിക്കണം.
    ///
    /// * [the module documentation]-ൽ നിർവചിച്ചിരിക്കുന്ന അർത്ഥത്തിൽ ഇത് "dereferencable" ആയിരിക്കണം.
    ///
    /// * പോയിന്റർ `T`-ന്റെ സമാരംഭിച്ച ഉദാഹരണത്തിലേക്ക് പോയിന്റുചെയ്യണം.
    ///
    /// * മടങ്ങിയെത്തിയ ആജീവനാന്ത `'a` ഏകപക്ഷീയമായി തിരഞ്ഞെടുക്കപ്പെട്ടതിനാൽ ഡാറ്റയുടെ യഥാർത്ഥ ആയുസ്സ് പ്രതിഫലിപ്പിക്കാത്തതിനാൽ നിങ്ങൾ Rust-ന്റെ അപരനാമ നിയമങ്ങൾ നടപ്പിലാക്കണം.
    ///
    ///   പ്രത്യേകിച്ചും, ഈ ജീവിതകാലത്തേക്ക്, പോയിന്റർ ചൂണ്ടിക്കാണിക്കുന്ന മെമ്മറി പരിവർത്തനം ചെയ്യരുത് (`UnsafeCell`-നുള്ളിൽ ഒഴികെ).
    ///
    /// ഈ രീതിയുടെ ഫലം ഉപയോഗിക്കാത്തതാണെങ്കിൽ പോലും ഇത് ബാധകമാണ്!
    /// (സമാരംഭിക്കുന്നതിനെക്കുറിച്ചുള്ള ഭാഗം ഇതുവരെ പൂർണ്ണമായി തീരുമാനിച്ചിട്ടില്ല, പക്ഷേ അത് വരെ, അവ യഥാർത്ഥത്തിൽ സമാരംഭിച്ചുവെന്ന് ഉറപ്പാക്കുക മാത്രമാണ് സുരക്ഷിതമായ സമീപനം.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // സുരക്ഷ: `self` എല്ലാം പാലിക്കുന്നുവെന്ന് കോളർ ഉറപ്പ് നൽകണം
        // ഒരു റഫറൻസിനുള്ള ആവശ്യകതകൾ.
        unsafe { &*self.as_ptr() }
    }

    /// മൂല്യത്തിലേക്ക് ഒരു അദ്വിതീയ റഫറൻസ് നൽകുന്നു.മൂല്യം ആരംഭിക്കാത്തതാണെങ്കിൽ, പകരം [`as_uninit_mut`] ഉപയോഗിക്കണം.
    ///
    /// പങ്കിട്ട ക p ണ്ടർപാർട്ടിനായി [`as_ref`] കാണുക.
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// ഈ രീതി വിളിക്കുമ്പോൾ, ഇനിപ്പറയുന്നവയെല്ലാം ശരിയാണെന്ന് നിങ്ങൾ ഉറപ്പാക്കേണ്ടതുണ്ട്:
    ///
    /// * പോയിന്റർ ശരിയായി വിന്യസിക്കണം.
    ///
    /// * [the module documentation]-ൽ നിർവചിച്ചിരിക്കുന്ന അർത്ഥത്തിൽ ഇത് "dereferencable" ആയിരിക്കണം.
    ///
    /// * പോയിന്റർ `T`-ന്റെ സമാരംഭിച്ച ഉദാഹരണത്തിലേക്ക് പോയിന്റുചെയ്യണം.
    ///
    /// * മടങ്ങിയെത്തിയ ആജീവനാന്ത `'a` ഏകപക്ഷീയമായി തിരഞ്ഞെടുക്കപ്പെട്ടതിനാൽ ഡാറ്റയുടെ യഥാർത്ഥ ആയുസ്സ് പ്രതിഫലിപ്പിക്കാത്തതിനാൽ നിങ്ങൾ Rust-ന്റെ അപരനാമ നിയമങ്ങൾ നടപ്പിലാക്കണം.
    ///
    ///   പ്രത്യേകിച്ചും, ഈ ജീവിതകാലത്തേക്ക്, പോയിന്റർ ചൂണ്ടിക്കാണിക്കുന്ന മെമ്മറി മറ്റേതൊരു പോയിന്ററിലൂടെയും ആക്‌സസ് ചെയ്യരുത് (വായിക്കുകയോ എഴുതുകയോ ചെയ്യുക).
    ///
    /// ഈ രീതിയുടെ ഫലം ഉപയോഗിക്കാത്തതാണെങ്കിൽ പോലും ഇത് ബാധകമാണ്!
    /// (സമാരംഭിക്കുന്നതിനെക്കുറിച്ചുള്ള ഭാഗം ഇതുവരെ പൂർണ്ണമായി തീരുമാനിച്ചിട്ടില്ല, പക്ഷേ അത് വരെ, അവ യഥാർത്ഥത്തിൽ സമാരംഭിച്ചുവെന്ന് ഉറപ്പാക്കുക മാത്രമാണ് സുരക്ഷിതമായ സമീപനം.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // സുരക്ഷ: `self` എല്ലാം പാലിക്കുന്നുവെന്ന് കോളർ ഉറപ്പ് നൽകണം
        // മ്യൂട്ടബിൾ റഫറൻസിനുള്ള ആവശ്യകതകൾ.
        unsafe { &mut *self.as_ptr() }
    }

    /// മറ്റൊരു തരത്തിലുള്ള പോയിന്ററിലേക്ക് കാസ്റ്റുചെയ്യുന്നു.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // സുരക്ഷ: എക്സ് 100 എക്സ് ഒരു എക്സ് 01 എക്സ് പോയിന്ററാണ്, അത് അസാധുവാണ്
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// നേർത്ത പോയിന്ററിൽ നിന്നും നീളത്തിൽ നിന്നും ശൂന്യമല്ലാത്ത അസംസ്കൃത സ്ലൈസ് സൃഷ്‌ടിക്കുന്നു.
    ///
    /// `len` ആർ‌ഗ്യുമെൻറ് **ഘടകങ്ങളുടെ** ആണ്, ബൈറ്റുകളുടെ എണ്ണമല്ല.
    ///
    /// ഈ പ്രവർത്തനം സുരക്ഷിതമാണ്, പക്ഷേ റിട്ടേൺ മൂല്യം വ്യതിചലിപ്പിക്കുന്നത് സുരക്ഷിതമല്ല.
    /// സ്ലൈസ് സുരക്ഷാ ആവശ്യകതകൾക്കായി [`slice::from_raw_parts`]-ന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // ആദ്യ ഘടകത്തിലേക്ക് ഒരു പോയിന്റർ ഉപയോഗിച്ച് ആരംഭിക്കുമ്പോൾ ഒരു സ്ലൈസ് പോയിന്റർ സൃഷ്ടിക്കുക
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (ഈ ഉദാഹരണം ഈ രീതിയുടെ ഉപയോഗത്തെ കൃത്രിമമായി കാണിക്കുന്നുവെന്നത് ശ്രദ്ധിക്കുക, പക്ഷേ `സ്ലൈസ്= NonNull::from(&x[..]);` would be a better way to write code like this.) അനുവദിക്കുക
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // സുരക്ഷ: എക്സ് 100 എക്സ് ഒരു എക്സ് 01 എക്സ് പോയിന്ററാണ്, അത് അസാധുവാണ്
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// ശൂന്യമല്ലാത്ത അസംസ്കൃത സ്ലൈസിന്റെ ദൈർഘ്യം നൽകുന്നു.
    ///
    /// നൽകിയ മൂല്യം **ഘടകങ്ങളുടെ** ആണ്, ബൈറ്റുകളുടെ എണ്ണമല്ല.
    ///
    /// പോയിന്ററിന് സാധുവായ വിലാസം ഇല്ലാത്തതിനാൽ ശൂന്യമല്ലാത്ത അസംസ്കൃത സ്ലൈസ് ഒരു സ്ലൈസിലേക്ക് മാറ്റാൻ കഴിയാത്തപ്പോൾ പോലും ഈ പ്രവർത്തനം സുരക്ഷിതമാണ്.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// സ്ലൈസിന്റെ ബഫറിലേക്ക് ഒരു ശൂന്യമല്ലാത്ത പോയിന്റർ നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // സുരക്ഷ: `self` ശൂന്യമല്ലെന്ന് ഞങ്ങൾക്കറിയാം.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// സ്ലൈസിന്റെ ബഫറിലേക്ക് ഒരു റോ പോയിന്റർ നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// ആരംഭിക്കാത്ത മൂല്യങ്ങളുടെ ഒരു സ്ലൈസിലേക്ക് പങ്കിട്ട റഫറൻസ് നൽകുന്നു.[`as_ref`]-ന് വിപരീതമായി, മൂല്യം സമാരംഭിക്കേണ്ടതുണ്ട്.
    ///
    /// മ്യൂട്ടബിൾ ക p ണ്ടർപാർട്ടിനായി [`as_uninit_slice_mut`] കാണുക.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// ഈ രീതി വിളിക്കുമ്പോൾ, ഇനിപ്പറയുന്നവയെല്ലാം ശരിയാണെന്ന് നിങ്ങൾ ഉറപ്പാക്കേണ്ടതുണ്ട്:
    ///
    /// * `ptr.len() * mem::size_of::<T>()` നിരവധി ബൈറ്റുകൾക്കായുള്ള റീഡറുകൾക്കായി പോയിന്റർ [valid] ആയിരിക്കണം, മാത്രമല്ല ഇത് ശരിയായി വിന്യസിക്കുകയും വേണം.ഇതിനർത്ഥം പ്രത്യേകിച്ചും:
    ///
    ///     * ഈ സ്ലൈസിന്റെ മുഴുവൻ മെമ്മറി ശ്രേണിയും അനുവദിച്ച ഒരൊറ്റ ഒബ്‌ജക്റ്റിനുള്ളിൽ അടങ്ങിയിരിക്കണം!
    ///       അനുവദിച്ച ഒന്നിലധികം ഒബ്‌ജക്റ്റുകളിൽ സ്ലൈസുകൾക്ക് ഒരിക്കലും വ്യാപിക്കാൻ കഴിയില്ല.
    ///
    ///     * പൂജ്യം നീളമുള്ള സ്ലൈസുകൾക്കുപോലും പോയിന്റർ വിന്യസിക്കണം.
    ///     ഇതിനുള്ള ഒരു കാരണം, enum ലേ layout ട്ട് ഒപ്റ്റിമൈസേഷനുകൾ മറ്റ് ഡാറ്റയിൽ നിന്ന് വേർതിരിച്ചറിയാൻ റഫറൻസുകളെ (ഏത് നീളത്തിലുള്ള കഷ്ണങ്ങൾ ഉൾപ്പെടെ) വിന്യസിക്കുകയും അസാധുവാക്കുകയും ചെയ്യും.
    ///
    ///     [`NonNull::dangling()`] ഉപയോഗിച്ച് പൂജ്യ-നീളമുള്ള സ്ലൈസുകൾക്കായി `data` ആയി ഉപയോഗിക്കാൻ കഴിയുന്ന ഒരു പോയിന്റർ നിങ്ങൾക്ക് ലഭിക്കും.
    ///
    /// * സ്ലൈസിന്റെ ആകെ വലുപ്പം `ptr.len() * mem::size_of::<T>()`, `isize::MAX` നേക്കാൾ വലുതായിരിക്കരുത്.
    ///   [`pointer::offset`]-ന്റെ സുരക്ഷാ ഡോക്യുമെന്റേഷൻ കാണുക.
    ///
    /// * മടങ്ങിയെത്തിയ ആജീവനാന്ത `'a` ഏകപക്ഷീയമായി തിരഞ്ഞെടുക്കപ്പെട്ടതിനാൽ ഡാറ്റയുടെ യഥാർത്ഥ ആയുസ്സ് പ്രതിഫലിപ്പിക്കാത്തതിനാൽ നിങ്ങൾ Rust-ന്റെ അപരനാമ നിയമങ്ങൾ നടപ്പിലാക്കണം.
    ///   പ്രത്യേകിച്ചും, ഈ ജീവിതകാലത്തേക്ക്, പോയിന്റർ ചൂണ്ടിക്കാണിക്കുന്ന മെമ്മറി പരിവർത്തനം ചെയ്യരുത് (`UnsafeCell`-നുള്ളിൽ ഒഴികെ).
    ///
    /// ഈ രീതിയുടെ ഫലം ഉപയോഗിക്കാത്തതാണെങ്കിൽ പോലും ഇത് ബാധകമാണ്!
    ///
    /// [`slice::from_raw_parts`] ഉം കാണുക.
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // സുരക്ഷ: വിളിക്കുന്നയാൾ `as_uninit_slice`-നായുള്ള സുരക്ഷാ കരാർ പാലിക്കണം.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// ആരംഭിക്കാത്ത മൂല്യങ്ങളുടെ ഒരു സ്ലൈസിലേക്ക് ഒരു അദ്വിതീയ റഫറൻസ് നൽകുന്നു.[`as_mut`]-ന് വിപരീതമായി, മൂല്യം സമാരംഭിക്കേണ്ടതുണ്ട്.
    ///
    /// പങ്കിട്ട ക p ണ്ടർപാർട്ടിനായി [`as_uninit_slice`] കാണുക.
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// ഈ രീതി വിളിക്കുമ്പോൾ, ഇനിപ്പറയുന്നവയെല്ലാം ശരിയാണെന്ന് നിങ്ങൾ ഉറപ്പാക്കേണ്ടതുണ്ട്:
    ///
    /// * `ptr.len() * mem::size_of::<T>()` നിരവധി ബൈറ്റുകൾക്കായി വായിക്കുന്നതിനും എഴുതുന്നതിനും പോയിന്റർ [valid] ആയിരിക്കണം, മാത്രമല്ല ഇത് ശരിയായി വിന്യസിക്കുകയും വേണം.ഇതിനർത്ഥം പ്രത്യേകിച്ചും:
    ///
    ///     * ഈ സ്ലൈസിന്റെ മുഴുവൻ മെമ്മറി ശ്രേണിയും അനുവദിച്ച ഒരൊറ്റ ഒബ്‌ജക്റ്റിനുള്ളിൽ അടങ്ങിയിരിക്കണം!
    ///       അനുവദിച്ച ഒന്നിലധികം ഒബ്‌ജക്റ്റുകളിൽ സ്ലൈസുകൾക്ക് ഒരിക്കലും വ്യാപിക്കാൻ കഴിയില്ല.
    ///
    ///     * പൂജ്യം നീളമുള്ള സ്ലൈസുകൾക്കുപോലും പോയിന്റർ വിന്യസിക്കണം.
    ///     ഇതിനുള്ള ഒരു കാരണം, enum ലേ layout ട്ട് ഒപ്റ്റിമൈസേഷനുകൾ മറ്റ് ഡാറ്റയിൽ നിന്ന് വേർതിരിച്ചറിയാൻ റഫറൻസുകളെ (ഏത് നീളത്തിലുള്ള കഷ്ണങ്ങൾ ഉൾപ്പെടെ) വിന്യസിക്കുകയും അസാധുവാക്കുകയും ചെയ്യും.
    ///
    ///     [`NonNull::dangling()`] ഉപയോഗിച്ച് പൂജ്യ-നീളമുള്ള സ്ലൈസുകൾക്കായി `data` ആയി ഉപയോഗിക്കാൻ കഴിയുന്ന ഒരു പോയിന്റർ നിങ്ങൾക്ക് ലഭിക്കും.
    ///
    /// * സ്ലൈസിന്റെ ആകെ വലുപ്പം `ptr.len() * mem::size_of::<T>()`, `isize::MAX` നേക്കാൾ വലുതായിരിക്കരുത്.
    ///   [`pointer::offset`]-ന്റെ സുരക്ഷാ ഡോക്യുമെന്റേഷൻ കാണുക.
    ///
    /// * മടങ്ങിയെത്തിയ ആജീവനാന്ത `'a` ഏകപക്ഷീയമായി തിരഞ്ഞെടുക്കപ്പെട്ടതിനാൽ ഡാറ്റയുടെ യഥാർത്ഥ ആയുസ്സ് പ്രതിഫലിപ്പിക്കാത്തതിനാൽ നിങ്ങൾ Rust-ന്റെ അപരനാമ നിയമങ്ങൾ നടപ്പിലാക്കണം.
    ///   പ്രത്യേകിച്ചും, ഈ ജീവിതകാലത്തേക്ക്, പോയിന്റർ ചൂണ്ടിക്കാണിക്കുന്ന മെമ്മറി മറ്റേതൊരു പോയിന്ററിലൂടെയും ആക്‌സസ് ചെയ്യരുത് (വായിക്കുകയോ എഴുതുകയോ ചെയ്യുക).
    ///
    /// ഈ രീതിയുടെ ഫലം ഉപയോഗിക്കാത്തതാണെങ്കിൽ പോലും ഇത് ബാധകമാണ്!
    ///
    /// [`slice::from_raw_parts_mut`] ഉം കാണുക.
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // X001 നിരവധി ബൈറ്റുകൾക്കായി വായിക്കുന്നതിനും എഴുതുന്നതിനും `memory` സാധുവായതിനാൽ ഇത് സുരക്ഷിതമാണ്.
    /// // ഉള്ളടക്കം ആരംഭിക്കാത്തതിനാൽ `memory.as_mut()` വിളിക്കുന്നത് ഇവിടെ അനുവദനീയമല്ല.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // സുരക്ഷ: വിളിക്കുന്നയാൾ `as_uninit_slice_mut`-നായുള്ള സുരക്ഷാ കരാർ പാലിക്കണം.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// അതിർത്തി പരിശോധന നടത്താതെ ഒരു ഘടകത്തിലേക്കോ സബ്‌ലൈസിലേക്കോ ഒരു റോ പോയിന്റർ നൽകുന്നു.
    ///
    /// Out ട്ട്-ബ ounds ണ്ട്സ് സൂചിക ഉപയോഗിച്ച് ഈ രീതിയെ വിളിക്കുന്നത് അല്ലെങ്കിൽ `self` നിർ‌വ്വഹിക്കാൻ‌കഴിയാത്തപ്പോൾ *[നിർ‌വ്വചിക്കാത്ത സ്വഭാവം]* ഫലമായുണ്ടാകുന്ന പോയിന്റർ ഉപയോഗിക്കുന്നില്ലെങ്കിലും.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // സുരക്ഷ: വിളിക്കുന്നയാൾ `self` അപലപനീയമാണെന്നും `index` ഇൻ-ബ .ണ്ട് ആണെന്നും ഉറപ്പാക്കുന്നു.
        // അനന്തരഫലമായി, ഫലമായുണ്ടാകുന്ന പോയിന്റർ NULL ആകാൻ കഴിയില്ല.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // സുരക്ഷ: ഒരു അദ്വിതീയ പോയിന്റർ അസാധുവാക്കാൻ കഴിയില്ല, അതിനാൽ ഇതിനുള്ള വ്യവസ്ഥകൾ
        // new_unchecked() ബഹുമാനിക്കപ്പെടുന്നു.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // സുരക്ഷ: പരിവർത്തനം ചെയ്യാവുന്ന ഒരു റഫറൻസ് അസാധുവാക്കാൻ കഴിയില്ല.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // സുരക്ഷ: ഒരു റഫറൻസ് അസാധുവാക്കാൻ കഴിയില്ല, അതിനാൽ ഇതിനുള്ള വ്യവസ്ഥകൾ
        // new_unchecked() ബഹുമാനിക്കപ്പെടുന്നു.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}