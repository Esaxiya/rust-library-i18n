#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// ഏതെങ്കിലും പോയിന്റ്-ടു തരത്തിന്റെ പോയിന്റർ മെറ്റാഡാറ്റ തരം നൽകുന്നു.
///
/// # പോയിന്റർ മെറ്റാഡാറ്റ
///
/// Rust-ലെ അസംസ്കൃത പോയിന്റർ തരങ്ങളും റഫറൻസ് തരങ്ങളും രണ്ട് ഭാഗങ്ങളാൽ നിർമ്മിച്ചതാണെന്ന് കരുതാം:
/// മൂല്യത്തിന്റെ മെമ്മറി വിലാസവും ചില മെറ്റാഡാറ്റയും അടങ്ങിയിരിക്കുന്ന ഒരു ഡാറ്റ പോയിന്റർ.
///
/// സ്റ്റാറ്റിക്ക്-സൈസ് തരങ്ങൾക്കും (`Sized` traits നടപ്പിലാക്കുന്ന) `extern` തരങ്ങൾക്കും പോയിന്ററുകൾ `നേർത്തതാണ്` എന്ന് പറയുന്നു: മെറ്റാഡാറ്റ പൂജ്യ വലുപ്പവും അതിന്റെ തരം `()` ഉം ആണ്.
///
///
/// [dynamically-sized types][dst]-ലേക്കുള്ള പോയിന്ററുകൾ `വൈഡ്` അല്ലെങ്കിൽ `കൊഴുപ്പ്` ആണെന്ന് പറയപ്പെടുന്നു, അവയ്ക്ക് പൂജ്യമല്ലാത്ത മെറ്റാഡാറ്റയുണ്ട്:
///
/// * അവസാന ഫീൽഡ് ഒരു ജിഎസ്ടി ആയ സ്ട്രക്റ്റുകൾക്ക്, മെറ്റാഡാറ്റയാണ് അവസാന ഫീൽഡിനുള്ള മെറ്റാഡാറ്റ
/// * `str` തരത്തിന്, `usize` ആയി ബൈറ്റുകളുടെ ദൈർഘ്യമാണ് മെറ്റാഡാറ്റ
/// * `[T]` പോലുള്ള സ്ലൈസ് തരങ്ങൾക്ക്, മെറ്റാഡാറ്റ എന്നത് ഇനങ്ങളുടെ നീളമാണ് `usize`
/// * `dyn SomeTrait` പോലുള്ള trait ഒബ്‌ജക്റ്റുകൾക്ക്, മെറ്റാഡാറ്റ [`DynMetadata<Self>`][DynMetadata] ആണ് (ഉദാ. `DynMetadata<dyn SomeTrait>`)
///
/// future-ൽ, വ്യത്യസ്ത പോയിന്റർ മെറ്റാഡാറ്റയുള്ള പുതിയ തരം തരം Rust ഭാഷ നേടിയേക്കാം.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// ഈ trait ന്റെ പോയിന്റ് അതിന്റെ `Metadata` അനുബന്ധ തരമാണ്, ഇത് മുകളിൽ വിവരിച്ചതുപോലെ `()` അല്ലെങ്കിൽ `usize` അല്ലെങ്കിൽ `DynMetadata<_>` ആണ്.
/// ഇത് എല്ലാ തരത്തിനും യാന്ത്രികമായി നടപ്പിലാക്കുന്നു.
/// അനുബന്ധ പരിധിയില്ലാതെ പോലും ഇത് ഒരു പൊതു സന്ദർഭത്തിൽ നടപ്പിലാക്കുമെന്ന് അനുമാനിക്കാം.
///
/// # Usage
///
/// അസംസ്കൃത പോയിന്ററുകൾ അവയുടെ [`to_raw_parts`] രീതി ഉപയോഗിച്ച് ഡാറ്റാ വിലാസത്തിലേക്കും മെറ്റാഡാറ്റ ഘടകങ്ങളിലേക്കും വിഘടിപ്പിക്കാൻ കഴിയും.
///
/// പകരമായി, [`metadata`] ഫംഗ്ഷൻ ഉപയോഗിച്ച് മെറ്റാഡാറ്റ മാത്രം എക്‌സ്‌ട്രാക്റ്റുചെയ്യാനാകും.
/// ഒരു റഫറൻസ് [`metadata`] ലേക്ക് കൈമാറുകയും വ്യക്തമായി നിർബന്ധിക്കുകയും ചെയ്യാം.
///
/// ഒരു (possibly-wide) പോയിന്റർ അതിന്റെ വിലാസത്തിൽ നിന്നും [`from_raw_parts`] അല്ലെങ്കിൽ [`from_raw_parts_mut`] ഉപയോഗിച്ച് മെറ്റാഡാറ്റയിൽ നിന്നും ഒരുമിച്ച് ചേർക്കാനാകും.
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// പോയിന്ററുകളിലെ മെറ്റാഡാറ്റയ്‌ക്കായുള്ള തരം, `Self`-ലേക്കുള്ള റഫറൻസുകൾ.
    #[lang = "metadata_type"]
    // NOTE: `static_assert_expected_bounds_for_metadata`-ൽ trait bounds സൂക്ഷിക്കുക
    //
    // `library/core/src/ptr/metadata.rs`-ൽ ഇവിടെയുള്ളവരുമായി സമന്വയിപ്പിക്കുന്നു:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// ഈ trait അപരനാമം നടപ്പിലാക്കുന്ന തരങ്ങളിലേക്കുള്ള പോയിന്ററുകൾ `നേർത്തതാണ്`.
///
/// ഇതിൽ സ്റ്റാറ്റിറ്റിക്കലി-വലുപ്പത്തിലുള്ള` തരങ്ങളും എക്സ് 100 എക്സ് തരങ്ങളും ഉൾപ്പെടുന്നു.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: trait അപരനാമങ്ങൾ ഭാഷയിൽ സ്ഥിരത കൈവരിക്കുന്നതിന് മുമ്പ് ഇത് സ്ഥിരീകരിക്കരുത്?
pub trait Thin = Pointee<Metadata = ()>;

/// ഒരു പോയിന്ററിന്റെ മെറ്റാഡാറ്റ ഘടകം എക്‌സ്‌ട്രാക്റ്റുചെയ്യുക.
///
/// `*mut T`, `&T`, അല്ലെങ്കിൽ `&mut T` തരം മൂല്യങ്ങൾ‌ഈ പ്രവർ‌ത്തനത്തിലേക്ക് നേരിട്ട് കൈമാറാൻ‌കഴിയും, കാരണം അവ `* const T` ലേക്ക്‌നിർബന്ധിതരാകുന്നു.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // സുരക്ഷ: * const T മുതൽ `PtrRepr` യൂണിയനിൽ നിന്ന് മൂല്യം ആക്സസ് ചെയ്യുന്നത് സുരക്ഷിതമാണ്
    // ഒപ്പം PtrComponents ഉം<T>സമാന മെമ്മറി ലേ .ട്ടുകൾ ഉണ്ട്.
    // std ന് മാത്രമേ ഈ ഉറപ്പ് നൽകാൻ കഴിയൂ.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// ഒരു ഡാറ്റ വിലാസത്തിൽ നിന്നും മെറ്റാഡാറ്റയിൽ നിന്നും ഒരു (possibly-wide) റോ പോയിന്റർ രൂപപ്പെടുത്തുന്നു.
///
/// ഈ ഫംഗ്ഷൻ സുരക്ഷിതമാണ്, പക്ഷേ മടങ്ങിയ പോയിന്റർ ഡീറെഫറൻസിന് സുരക്ഷിതമല്ല.
/// സ്ലൈസുകൾക്കായി, സുരക്ഷാ ആവശ്യകതകൾക്കായി [`slice::from_raw_parts`]-ന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
/// trait ഒബ്‌ജക്റ്റുകൾക്കായി, മെറ്റാഡാറ്റ ഒരു പോയിന്ററിൽ നിന്ന് അതേ അന്തർലീനമായ ereased തരത്തിലേക്ക് വരണം.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // സുരക്ഷ: * const T മുതൽ `PtrRepr` യൂണിയനിൽ നിന്ന് മൂല്യം ആക്സസ് ചെയ്യുന്നത് സുരക്ഷിതമാണ്
    // ഒപ്പം PtrComponents ഉം<T>സമാന മെമ്മറി ലേ .ട്ടുകൾ ഉണ്ട്.
    // std ന് മാത്രമേ ഈ ഉറപ്പ് നൽകാൻ കഴിയൂ.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// ഒരു അസംസ്കൃത `*const` പോയിന്ററിന് വിപരീതമായി ഒരു അസംസ്കൃത `* mut` പോയിന്റർ മടക്കിനൽകുന്നു എന്നതൊഴിച്ചാൽ [`from_raw_parts`]-ന്റെ അതേ പ്രവർത്തനം നിർവ്വഹിക്കുന്നു.
///
///
/// കൂടുതൽ വിവരങ്ങൾക്ക് [`from_raw_parts`] ന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // സുരക്ഷ: * const T മുതൽ `PtrRepr` യൂണിയനിൽ നിന്ന് മൂല്യം ആക്സസ് ചെയ്യുന്നത് സുരക്ഷിതമാണ്
    // ഒപ്പം PtrComponents ഉം<T>സമാന മെമ്മറി ലേ .ട്ടുകൾ ഉണ്ട്.
    // std ന് മാത്രമേ ഈ ഉറപ്പ് നൽകാൻ കഴിയൂ.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// `T: Copy` ബൗണ്ട് ഒഴിവാക്കാൻ സ്വമേധയാലുള്ള impl ആവശ്യമാണ്.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// `T: Clone` ബൗണ്ട് ഒഴിവാക്കാൻ സ്വമേധയാലുള്ള impl ആവശ്യമാണ്.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// `Dyn = dyn SomeTrait` trait ഒബ്‌ജക്റ്റ് തരത്തിനായുള്ള മെറ്റാഡാറ്റ.
///
/// ഒരു trait ഒബ്‌ജക്റ്റിനുള്ളിൽ സംഭരിച്ചിരിക്കുന്ന കോൺക്രീറ്റ് തരം കൈകാര്യം ചെയ്യുന്നതിന് ആവശ്യമായ എല്ലാ വിവരങ്ങളും പ്രതിനിധീകരിക്കുന്ന ഒരു vtable (വെർച്വൽ കോൾ ടേബിൾ) ലേക്കുള്ള പോയിന്ററാണ് ഇത്.
/// അതിൽ അടങ്ങിയിരിക്കുന്ന vtable:
///
/// * തരം വലുപ്പം
/// * വിന്യാസം ടൈപ്പുചെയ്യുക
/// * ടൈപ്പിന്റെ `drop_in_place` impl-ലേക്ക് ഒരു പോയിന്റർ (പ്ലെയിൻ-ഓൾഡ്-ഡാറ്റയ്‌ക്കായുള്ള ഒരു ഓപ്ഷനായിരിക്കില്ല)
/// * trait തരം നടപ്പിലാക്കുന്നതിനുള്ള എല്ലാ രീതികളിലേക്കും പോയിന്ററുകൾ
///
/// ഏതൊരു trait ഒബ്ജക്റ്റും അനുവദിക്കുന്നതിനും ഉപേക്ഷിക്കുന്നതിനും ഡീലോക്കേറ്റ് ചെയ്യുന്നതിനും ആവശ്യമായതിനാൽ ആദ്യത്തെ മൂന്ന് പ്രത്യേകതയുള്ളവയാണെന്ന കാര്യം ശ്രദ്ധിക്കുക.
///
/// `dyn` trait ഒബ്ജക്റ്റ് അല്ലാത്ത (ഉദാഹരണത്തിന് `DynMetadata<u64>`) ഒരു ടൈപ്പ് പാരാമീറ്റർ ഉപയോഗിച്ച് ഈ സ്ട്രക്റ്റിന് പേര് നൽകാൻ കഴിയും, പക്ഷേ ആ സ്ട്രക്റ്റിന്റെ അർത്ഥവത്തായ മൂല്യം നേടരുത്.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// എല്ലാ vtables ന്റെയും പൊതുവായ പ്രിഫിക്‌സ്.trait രീതികൾക്കായുള്ള ഫംഗ്ഷൻ പോയിന്ററുകൾ ഇത് പിന്തുടരുന്നു.
///
/// `DynMetadata::size_of` മുതലായവയുടെ സ്വകാര്യ നടപ്പാക്കൽ വിശദാംശങ്ങൾ.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// ഈ vtable മായി ബന്ധപ്പെട്ട തരത്തിന്റെ വലുപ്പം നൽകുന്നു.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// ഈ vtable മായി ബന്ധപ്പെട്ട തരത്തിന്റെ വിന്യാസം നൽകുന്നു.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// വലുപ്പവും വിന്യാസവും ഒരുമിച്ച് `Layout` ആയി നൽകുന്നു
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // സുരക്ഷ: ഒരു കോൺക്രീറ്റ് Rust തരത്തിനായി കംപൈലർ ഈ vtable പുറപ്പെടുവിച്ചു
        // സാധുവായ ലേ .ട്ട് ഉണ്ടെന്ന് അറിയപ്പെടുന്നു.`Layout::for_value`-ലെ അതേ യുക്തി.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// `Dyn: $Trait` പരിധി ഒഴിവാക്കാൻ സ്വമേധയാലുള്ള ഇം‌പ്ലുകൾ ആവശ്യമാണ്.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}