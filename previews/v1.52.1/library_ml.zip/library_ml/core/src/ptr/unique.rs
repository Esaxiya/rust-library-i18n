use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// ഈ റാപ്പറിന്റെ ഉടമസ്ഥന് റഫറൻസ് സ്വന്തമാണെന്ന് സൂചിപ്പിക്കുന്ന ഒരു അസംസ്കൃത നോൺ-എക്സ്-എക്സ് എക്‌സിന് ചുറ്റുമുള്ള ഒരു റാപ്പർ.
/// `Box<T>`, `Vec<T>`, `String`, `HashMap<K, V>` എന്നിവ പോലുള്ള അമൂർത്തങ്ങൾ നിർമ്മിക്കുന്നതിന് ഉപയോഗപ്രദമാണ്.
///
/// `*mut T` ൽ നിന്ന് വ്യത്യസ്തമായി, `Unique<T>` "as if"-ൽ പെരുമാറുന്നു, ഇത് `T`-ന്റെ ഒരു ഉദാഹരണമായിരുന്നു.
/// `T` `Send`/`Sync` ആണെങ്കിൽ ഇത് `Send`/`Sync` നടപ്പിലാക്കുന്നു.
/// `T`-ന്റെ ഒരു ഉദാഹരണം പ്രതീക്ഷിക്കാവുന്ന തരത്തിലുള്ള ശക്തമായ അപരനാമം ഉറപ്പ് നൽകുന്നുവെന്നും ഇത് സൂചിപ്പിക്കുന്നു:
/// പോയിന്ററിന്റെ റഫറൻസ് സ്വന്തമായ യുണിക്ക് ഒരു അദ്വിതീയ പാതയില്ലാതെ പരിഷ്കരിക്കരുത്.
///
/// നിങ്ങളുടെ ആവശ്യങ്ങൾക്കായി `Unique` ഉപയോഗിക്കുന്നത് ശരിയാണോയെന്ന് നിങ്ങൾക്ക് ഉറപ്പില്ലെങ്കിൽ, ദുർബലമായ അർത്ഥശാസ്ത്രമുള്ള `NonNull` ഉപയോഗിക്കുന്നത് പരിഗണിക്കുക.
///
///
/// `*mut T`-ൽ നിന്ന് വ്യത്യസ്തമായി, പോയിന്റർ ഒരിക്കലും അസാധുവാക്കിയിട്ടില്ലെങ്കിലും, പോയിന്റർ എല്ലായ്പ്പോഴും ശൂന്യമായിരിക്കണം.
/// ഈ വിലക്കപ്പെട്ട മൂല്യം വിവേചനാധികാരിയായി enums ഉപയോഗിച്ചേക്കാമെന്നതിനാലാണിത്-`Option<Unique<T>>` ന് `Unique<T>` ന് തുല്യമായ വലുപ്പമുണ്ട്.
/// എന്നിരുന്നാലും, പോയിന്റർ വ്യക്തമാക്കാതിരുന്നാൽ അത് തൂങ്ങിക്കിടക്കും.
///
/// `*mut T`-ൽ നിന്ന് വ്യത്യസ്തമായി, `Unique<T>`, `T`-നേക്കാൾ കോവിയറന്റാണ്.
/// യുണീക്കിന്റെ അപരനാമ ആവശ്യകതകൾ ഉയർത്തിപ്പിടിക്കുന്ന ഏത് തരത്തിനും ഇത് എല്ലായ്പ്പോഴും ശരിയായിരിക്കണം.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: ഈ മാർക്കറിന് വ്യത്യാസത്തിന് പരിണതഫലങ്ങളൊന്നുമില്ല, പക്ഷേ അത് ആവശ്യമാണ്
    // യുക്തിപരമായി ഞങ്ങൾക്ക് ഒരു `T` സ്വന്തമാണെന്ന് ഡ്രോപ്പ്ക്ക് മനസിലാക്കാൻ.
    //
    // വിശദാംശങ്ങൾക്ക്, കാണുക:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` `T` `Send` ആണെങ്കിൽ പോയിന്ററുകൾ `Send` ആണ്, കാരണം അവ പരാമർശിക്കുന്ന ഡാറ്റ ഏകീകൃതമല്ല.
/// ഈ അപരനാമം മാറ്റമില്ലാത്തത് ടൈപ്പ് സിസ്റ്റം നടപ്പിലാക്കുന്നില്ലെന്നത് ശ്രദ്ധിക്കുക;`Unique` ഉപയോഗിച്ചുള്ള സംഗ്രഹം അത് നടപ്പിലാക്കണം.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` `T` `Sync` ആണെങ്കിൽ പോയിന്ററുകൾ `Sync` ആണ്, കാരണം അവ പരാമർശിക്കുന്ന ഡാറ്റ ഏകീകൃതമല്ല.
/// ഈ അപരനാമം മാറ്റമില്ലാത്തത് ടൈപ്പ് സിസ്റ്റം നടപ്പിലാക്കുന്നില്ലെന്നത് ശ്രദ്ധിക്കുക;`Unique` ഉപയോഗിച്ചുള്ള സംഗ്രഹം അത് നടപ്പിലാക്കണം.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// തൂങ്ങിക്കിടക്കുന്നതും എന്നാൽ നന്നായി വിന്യസിച്ചതുമായ ഒരു പുതിയ `Unique` സൃഷ്ടിക്കുന്നു.
    ///
    /// `Vec::new` പോലെ അലസമായി അനുവദിക്കുന്ന തരങ്ങൾ സമാരംഭിക്കുന്നതിന് ഇത് ഉപയോഗപ്രദമാണ്.
    ///
    /// പോയിന്റർ മൂല്യം ഒരു `T`-ലേക്ക് സാധുവായ പോയിന്ററിനെ പ്രതിനിധീകരിക്കാൻ സാധ്യതയുണ്ട്, അതായത് ഇത് "not yet initialized" സെന്റിനൽ മൂല്യമായി ഉപയോഗിക്കരുത്.
    /// അലസമായി അനുവദിക്കുന്ന തരങ്ങൾ മറ്റ് മാർഗ്ഗങ്ങളിലൂടെ ഓർഗനൈസേഷൻ ട്രാക്കുചെയ്യണം.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // സുരക്ഷ: mem::align_of() സാധുവായതും അല്ലാത്തതുമായ ഒരു പോയിന്റർ നൽകുന്നു.ദി
        // new_unchecked()-ലേക്ക് വിളിക്കാനുള്ള വ്യവസ്ഥകൾ അങ്ങനെ മാനിക്കപ്പെടുന്നു.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// ഒരു പുതിയ `Unique` സൃഷ്ടിക്കുന്നു.
    ///
    /// # Safety
    ///
    /// `ptr` ശൂന്യമായിരിക്കണം.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // സുരക്ഷ: `ptr` ശൂന്യമല്ലെന്ന് കോളർ ഉറപ്പ് നൽകണം.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// `ptr` ശൂന്യമല്ലെങ്കിൽ ഒരു പുതിയ `Unique` സൃഷ്ടിക്കുന്നു.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // സുരക്ഷ: പോയിന്റർ ഇതിനകം പരിശോധിച്ചു, അത് ശൂന്യമല്ല.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// അന്തർലീനമായ `*mut` പോയിന്റർ നേടുന്നു.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// ഉള്ളടക്കത്തെ ഒഴിവാക്കുന്നു.
    ///
    /// തത്ഫലമായുണ്ടാകുന്ന ആജീവനാന്തം സ്വയം ബന്ധപ്പെട്ടിരിക്കുന്നു, അതിനാൽ ഇത് "as if" ആയി പെരുമാറുന്നു, ഇത് യഥാർത്ഥത്തിൽ കടമെടുക്കുന്ന ടി യുടെ ഒരു ഉദാഹരണമായിരുന്നു.
    /// ദൈർഘ്യമേറിയ (unbound) ആയുസ്സ് ആവശ്യമെങ്കിൽ, `&*my_ptr.as_ptr()` ഉപയോഗിക്കുക.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // സുരക്ഷ: `self` എല്ലാം പാലിക്കുന്നുവെന്ന് കോളർ ഉറപ്പ് നൽകണം
        // ഒരു റഫറൻസിനുള്ള ആവശ്യകതകൾ.
        unsafe { &*self.as_ptr() }
    }

    /// ഉള്ളടക്കത്തെ പരസ്പരം ഇല്ലാതാക്കുന്നു.
    ///
    /// തത്ഫലമായുണ്ടാകുന്ന ആജീവനാന്തം സ്വയം ബന്ധപ്പെട്ടിരിക്കുന്നു, അതിനാൽ ഇത് "as if" ആയി പെരുമാറുന്നു, ഇത് യഥാർത്ഥത്തിൽ കടമെടുക്കുന്ന ടി യുടെ ഒരു ഉദാഹരണമായിരുന്നു.
    /// ദൈർഘ്യമേറിയ (unbound) ആയുസ്സ് ആവശ്യമെങ്കിൽ, `&mut *my_ptr.as_ptr()` ഉപയോഗിക്കുക.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // സുരക്ഷ: `self` എല്ലാം പാലിക്കുന്നുവെന്ന് കോളർ ഉറപ്പ് നൽകണം
        // മ്യൂട്ടബിൾ റഫറൻസിനുള്ള ആവശ്യകതകൾ.
        unsafe { &mut *self.as_ptr() }
    }

    /// മറ്റൊരു തരത്തിലുള്ള പോയിന്ററിലേക്ക് കാസ്റ്റുചെയ്യുന്നു.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // സുരക്ഷ: Unique::new_unchecked() ഒരു പുതിയ അദ്വിതീയവും ആവശ്യങ്ങളും സൃഷ്ടിക്കുന്നു
        // നൽകിയ പോയിന്റർ അസാധുവാകരുത്.
        // നമ്മൾ സ്വയം ഒരു പോയിന്ററായി കടന്നുപോകുന്നതിനാൽ, അത് അസാധുവാകാൻ കഴിയില്ല.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // സുരക്ഷ: പരിവർത്തനം ചെയ്യാവുന്ന ഒരു റഫറൻസ് അസാധുവാക്കാൻ കഴിയില്ല
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}