//! ഈ മൊഡ്യൂൾ `Any` trait നടപ്പിലാക്കുന്നു, ഇത് റൺടൈം പ്രതിഫലനത്തിലൂടെ ഏത് `'static` തരത്തിന്റെയും ചലനാത്മക ടൈപ്പിംഗ് പ്രാപ്തമാക്കുന്നു.
//!
//! `Any` ഒരു `TypeId` ലഭിക്കാൻ തന്നെ ഉപയോഗിക്കാം, കൂടാതെ trait ഒബ്‌ജക്റ്റായി ഉപയോഗിക്കുമ്പോൾ കൂടുതൽ സവിശേഷതകളുമുണ്ട്.
//! `&dyn Any` (കടമെടുത്ത trait ഒബ്‌ജക്റ്റ്) എന്ന നിലയിൽ, ഇതിന് `is`, `downcast_ref` രീതികളുണ്ട്, അടങ്ങിയിരിക്കുന്ന മൂല്യം ഒരു പ്രത്യേക തരത്തിലാണോയെന്ന് പരിശോധിക്കുന്നതിനും ആന്തരിക മൂല്യത്തെ ഒരു തരമായി റഫറൻസ് നേടുന്നതിനും.
//! ആന്തരിക മൂല്യത്തിലേക്ക് മ്യൂട്ടബിൾ റഫറൻസ് ലഭിക്കുന്നതിന് `&mut dyn Any` എന്ന നിലയിൽ, `downcast_mut` രീതിയും ഉണ്ട്.
//! `Box<dyn Any>` `downcast` രീതി ചേർക്കുന്നു, അത് ഒരു `Box<T>` ലേക്ക് പരിവർത്തനം ചെയ്യാൻ ശ്രമിക്കുന്നു.
//! പൂർണ്ണ വിവരങ്ങൾക്കായി [`Box`] ഡോക്യുമെന്റേഷൻ കാണുക.
//!
//! ഒരു മൂല്യം ഒരു നിർദ്ദിഷ്ട കോൺക്രീറ്റ് തരമാണോയെന്ന് പരിശോധിക്കുന്നതിന് `&dyn Any` പരിമിതപ്പെടുത്തിയിരിക്കുന്നു, ഒരു തരം trait നടപ്പിലാക്കുന്നുണ്ടോയെന്ന് പരിശോധിക്കാൻ ഇത് ഉപയോഗിക്കാനാവില്ല.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # സ്മാർട്ട് പോയിന്ററുകളും `dyn Any` ഉം
//!
//! `Any` ഒരു trait ഒബ്‌ജക്റ്റായി ഉപയോഗിക്കുമ്പോൾ, പ്രത്യേകിച്ച് `Box<dyn Any>` അല്ലെങ്കിൽ `Arc<dyn Any>` പോലുള്ള തരങ്ങൾ ഉപയോഗിച്ച് മനസിലാക്കേണ്ട ഒരു പെരുമാറ്റം, മൂല്യത്തിൽ `.type_id()` എന്ന് വിളിക്കുന്നത് * കണ്ടെയ്‌നറിന്റെ `TypeId` ഉൽ‌പാദിപ്പിക്കും, മറിച്ച് trait ഒബ്‌ജക്റ്റല്ല.
//!
//! പകരം സ്മാർട്ട് പോയിന്റർ ഒരു `&dyn Any` ആക്കി മാറ്റുന്നതിലൂടെ ഇത് ഒഴിവാക്കാനാകും, അത് ഒബ്ജക്റ്റിന്റെ `TypeId` നൽകുന്നു.
//! ഉദാഹരണത്തിന്:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // നിങ്ങൾക്ക് ഇത് ആവശ്യപ്പെടാനുള്ള സാധ്യത കൂടുതലാണ്:
//! let actual_id = (&*boxed).type_id();
//! // ... ഇതിനേക്കാൾ:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! ഒരു ഫംഗ്ഷനിലേക്ക് കൈമാറിയ ഒരു മൂല്യം ലോഗ് out ട്ട് ചെയ്യാൻ ആഗ്രഹിക്കുന്ന ഒരു സാഹചര്യം പരിഗണിക്കുക.
//! ഡീബഗ് നടപ്പിലാക്കുന്നതിൽ ഞങ്ങൾ പ്രവർത്തിക്കുന്ന മൂല്യം ഞങ്ങൾക്കറിയാം, പക്ഷേ അതിന്റെ കോൺക്രീറ്റ് തരം ഞങ്ങൾക്ക് അറിയില്ല.ചില തരങ്ങൾക്ക് പ്രത്യേക ചികിത്സ നൽകാൻ ഞങ്ങൾ ആഗ്രഹിക്കുന്നു: ഈ സാഹചര്യത്തിൽ സ്ട്രിംഗ് മൂല്യങ്ങളുടെ ദൈർഘ്യം അവയുടെ മൂല്യത്തിന് മുമ്പായി അച്ചടിക്കുന്നു.
//! കംപൈൽ ചെയ്യുന്ന സമയത്ത് ഞങ്ങളുടെ മൂല്യത്തിന്റെ കോൺക്രീറ്റ് തരം ഞങ്ങൾക്ക് അറിയില്ല, അതിനാൽ പകരം റൺടൈം പ്രതിഫലനം ഉപയോഗിക്കേണ്ടതുണ്ട്.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // ഡീബഗ് നടപ്പിലാക്കുന്ന ഏത് തരത്തിലുമുള്ള ലോഗർ പ്രവർത്തനം.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // ഞങ്ങളുടെ മൂല്യം ഒരു `String` ലേക്ക് പരിവർത്തനം ചെയ്യാൻ ശ്രമിക്കുക.
//!     // വിജയകരമാണെങ്കിൽ, സ്‌ട്രിംഗിന്റെ നീളവും അതിന്റെ മൂല്യവും output ട്ട്‌പുട്ട് ചെയ്യാൻ ഞങ്ങൾ ആഗ്രഹിക്കുന്നു.
//!     // ഇല്ലെങ്കിൽ, ഇത് മറ്റൊരു തരം: അലങ്കരിക്കാതെ പ്രിന്റുചെയ്യുക.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // ഈ ഫംഗ്ഷൻ അതിന്റെ പാരാമീറ്റർ ഉപയോഗിച്ച് പ്രവർത്തിക്കുന്നതിന് മുമ്പ് ലോഗ് out ട്ട് ചെയ്യാൻ ആഗ്രഹിക്കുന്നു.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... മറ്റെന്തെങ്കിലും ജോലി ചെയ്യുക
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// ഏതെങ്കിലും trait
///////////////////////////////////////////////////////////////////////////////

/// ഡൈനാമിക് ടൈപ്പിംഗ് അനുകരിക്കുന്നതിനുള്ള ഒരു trait.
///
/// മിക്ക തരങ്ങളും `Any` നടപ്പിലാക്കുന്നു.എന്നിരുന്നാലും, ഒരു സ്റ്റാറ്റിക് അല്ലാത്ത റഫറൻസ് അടങ്ങിയിരിക്കുന്ന ഏത് തരത്തിലും ഉൾപ്പെടുന്നില്ല.
/// കൂടുതൽ വിവരങ്ങൾക്ക് [module-level documentation][mod] കാണുക.
///
/// [mod]: crate::any
// ഈ trait സുരക്ഷിതമല്ല, എന്നിരുന്നാലും സുരക്ഷിതമല്ലാത്ത കോഡിലെ (ഉദാ. `downcast`) ഏക ഇം‌പ്ലിന്റെ `type_id` ഫംഗ്ഷന്റെ സവിശേഷതകളെ ഞങ്ങൾ ആശ്രയിക്കുന്നു.സാധാരണയായി, അതൊരു പ്രശ്‌നമായിരിക്കും, പക്ഷേ `Any`-ന്റെ ഒരേയൊരു impl ഒരു പുതപ്പ് നടപ്പിലാക്കലായതിനാൽ, മറ്റൊരു കോഡിനും `Any` നടപ്പിലാക്കാൻ കഴിയില്ല.
//
// ഞങ്ങൾക്ക് ഈ trait സുരക്ഷിതമല്ലാത്തതാക്കാൻ കഴിയും-ഇത് എല്ലാ നടപ്പാക്കലുകളും ഞങ്ങൾ നിയന്ത്രിക്കുന്നതിനാൽ ഇത് തകരാറുണ്ടാക്കില്ല-എന്നാൽ ഇത് ശരിക്കും ആവശ്യമില്ലാത്തതിനാൽ ഞങ്ങൾ തിരഞ്ഞെടുക്കുന്നു, മാത്രമല്ല സുരക്ഷിതമല്ലാത്ത traits, സുരക്ഷിതമല്ലാത്ത രീതികൾ (അതായത്, `type_id` ഇപ്പോഴും വിളിക്കുന്നത് സുരക്ഷിതമായിരിക്കും, പക്ഷേ ഡോക്യുമെന്റേഷനിൽ സൂചിപ്പിക്കാൻ ഞങ്ങൾ ആഗ്രഹിക്കുന്നു).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// `self`-ന്റെ `TypeId` ലഭിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// ഏതെങ്കിലും trait ഒബ്‌ജക്റ്റുകൾക്കായുള്ള വിപുലീകരണ രീതികൾ.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// ഉദാ: ഒരു ത്രെഡിൽ ചേരുന്നത് ഫലം പ്രിന്റുചെയ്യാമെന്നും അതിനാൽ `unwrap` ഉപയോഗിച്ച് ഉപയോഗിക്കുമെന്നും ഉറപ്പാക്കുക.
// ഡിസ്‌പാച്ച് അപ്‌കാസ്റ്റിംഗിനൊപ്പം പ്രവർത്തിക്കുന്നുവെങ്കിൽ ഒടുവിൽ ആവശ്യമില്ല.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// ബോക്‌സുചെയ്‌ത തരം `T`-ന് തുല്യമാണെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // ഈ ഫംഗ്ഷൻ തൽക്ഷണം ചെയ്യുന്ന തരത്തിലുള്ള `TypeId` നേടുക.
        let t = TypeId::of::<T>();

        // trait ഒബ്‌ജക്റ്റ് (`self`)-ൽ തരത്തിലുള്ള `TypeId` നേടുക.
        let concrete = self.type_id();

        // സമത്വത്തെക്കുറിച്ചുള്ള `ടൈപ്പ്ഇഡ് 'രണ്ടും താരതമ്യം ചെയ്യുക.
        t == concrete
    }

    /// ബോക്സ് ചെയ്ത മൂല്യത്തിന് `T` തരം ആണെങ്കിൽ അല്ലെങ്കിൽ `None` ഇല്ലെങ്കിൽ കുറച്ച് റഫറൻസ് നൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // സുരക്ഷ: ഞങ്ങൾ ശരിയായ തരത്തിലേക്കാണോ വിരൽ ചൂണ്ടുന്നതെന്ന് പരിശോധിച്ചു, ഞങ്ങൾക്ക് ആശ്രയിക്കാനാകും
            // മെമ്മറി സുരക്ഷയ്ക്കായി ഇത് പരിശോധിക്കുന്നു, കാരണം ഞങ്ങൾ എല്ലാ തരത്തിലും എന്തും നടപ്പിലാക്കിയിട്ടുണ്ട്;ഞങ്ങളുടെ impl മായി പൊരുത്തപ്പെടുന്നതിനാൽ മറ്റ് impls നിലനിൽക്കില്ല.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// ബോക്സുചെയ്‌ത മൂല്യത്തിന് `T` തരം ആണെങ്കിൽ അല്ലെങ്കിൽ `None` ഇല്ലെങ്കിൽ ചില മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // സുരക്ഷ: ഞങ്ങൾ ശരിയായ തരത്തിലേക്കാണോ വിരൽ ചൂണ്ടുന്നതെന്ന് പരിശോധിച്ചു, ഞങ്ങൾക്ക് ആശ്രയിക്കാനാകും
            // മെമ്മറി സുരക്ഷയ്ക്കായി ഇത് പരിശോധിക്കുന്നു, കാരണം ഞങ്ങൾ എല്ലാ തരത്തിലും എന്തും നടപ്പിലാക്കിയിട്ടുണ്ട്;ഞങ്ങളുടെ impl മായി പൊരുത്തപ്പെടുന്നതിനാൽ മറ്റ് impls നിലനിൽക്കില്ല.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// `Any` തരത്തിൽ നിർവചിച്ചിരിക്കുന്ന രീതിയിലേക്ക് കൈമാറുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// `Any` തരത്തിൽ നിർവചിച്ചിരിക്കുന്ന രീതിയിലേക്ക് കൈമാറുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// `Any` തരത്തിൽ നിർവചിച്ചിരിക്കുന്ന രീതിയിലേക്ക് കൈമാറുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// `Any` തരത്തിൽ നിർവചിച്ചിരിക്കുന്ന രീതിയിലേക്ക് കൈമാറുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// `Any` തരത്തിൽ നിർവചിച്ചിരിക്കുന്ന രീതിയിലേക്ക് കൈമാറുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// `Any` തരത്തിൽ നിർവചിച്ചിരിക്കുന്ന രീതിയിലേക്ക് കൈമാറുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// ടൈപ്പ് ഐഡിയും അതിന്റെ രീതികളും
///////////////////////////////////////////////////////////////////////////////

/// ഒരു തരത്തിനായി ആഗോളതലത്തിൽ സവിശേഷമായ ഐഡന്റിഫയറിനെ ഒരു `TypeId` പ്രതിനിധീകരിക്കുന്നു.
///
/// ഓരോ എക്സ് 100 എക്സും അതാര്യമായ ഒബ്ജക്റ്റാണ്, അത് ഉള്ളിലുള്ളവ പരിശോധിക്കാൻ അനുവദിക്കുന്നില്ല, പക്ഷേ ക്ലോണിംഗ്, താരതമ്യം, അച്ചടി, കാണിക്കൽ തുടങ്ങിയ അടിസ്ഥാന പ്രവർത്തനങ്ങളെ അനുവദിക്കുന്നു.
///
///
/// `'static` എന്ന് സൂചിപ്പിക്കുന്ന തരങ്ങൾക്ക് മാത്രമേ ഒരു `TypeId` നിലവിൽ ലഭ്യമാകൂ, എന്നാൽ ഈ പരിധി future-ൽ നീക്കംചെയ്യാം.
///
/// `TypeId` `Hash`, `PartialOrd`, `Ord` എന്നിവ നടപ്പിലാക്കുമ്പോൾ, ഹാഷുകളും ഓർഡറിംഗും Rust റിലീസുകൾക്കിടയിൽ വ്യത്യാസപ്പെട്ടിരിക്കുമെന്നത് ശ്രദ്ധിക്കേണ്ടതാണ്.
/// നിങ്ങളുടെ കോഡിനുള്ളിൽ അവയെ ആശ്രയിക്കുന്നത് സൂക്ഷിക്കുക!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// ഈ ജനറിക് ഫംഗ്ഷൻ തൽക്ഷണം ചെയ്ത തരത്തിന്റെ `TypeId` നൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// ഒരു തരത്തിന്റെ പേര് സ്‌ട്രിംഗ് സ്ലൈസായി നൽകുന്നു.
///
/// # Note
///
/// ഇത് ഡയഗ്നോസ്റ്റിക് ഉപയോഗത്തിനായി ഉദ്ദേശിച്ചുള്ളതാണ്.
/// മടക്കിനൽകിയ സ്‌ട്രിംഗിന്റെ കൃത്യമായ ഉള്ളടക്കവും ഫോർമാറ്റും വ്യക്തമാക്കിയിട്ടില്ല, തരത്തിന്റെ മികച്ച ശ്രമം വിവരണമല്ലാതെ.
/// ഉദാഹരണത്തിന്, `type_name::<Option<String>>()` മടങ്ങിയെത്തുന്ന സ്ട്രിംഗുകളിൽ `"Option<String>"`, `"std::option::Option<std::string::String>"` എന്നിവ ഉൾപ്പെടുന്നു.
///
///
/// മടങ്ങിയെത്തിയ സ്‌ട്രിംഗ് ഒരു തരത്തിന്റെ അദ്വിതീയ ഐഡന്റിഫയറായി കണക്കാക്കരുത്, കാരണം ഒന്നിലധികം തരം ഒരേ തരത്തിലുള്ള നാമത്തിലേക്ക് മാപ്പ് ചെയ്യാം.
/// അതുപോലെ, മടങ്ങിയ സ്‌ട്രിംഗിൽ ഒരു തരത്തിന്റെ എല്ലാ ഭാഗങ്ങളും ദൃശ്യമാകുമെന്നതിന് യാതൊരു ഉറപ്പുമില്ല: ഉദാഹരണത്തിന്, ലൈഫ് ടൈം സ്‌പെസിഫയറുകൾ നിലവിൽ ഉൾപ്പെടുത്തിയിട്ടില്ല.
/// കൂടാതെ, കംപൈലറിന്റെ പതിപ്പുകൾക്കിടയിൽ output ട്ട്‌പുട്ട് മാറാം.
///
/// നിലവിലെ നടപ്പാക്കൽ കംപൈലർ ഡയഗ്നോസ്റ്റിക്സ്, ഡീബഗ്ഗിൻഫോ എന്നിവയ്ക്ക് സമാനമായ ഇൻഫ്രാസ്ട്രക്ചർ ഉപയോഗിക്കുന്നു, പക്ഷേ ഇത് ഉറപ്പില്ല.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// പോയിന്റ്-ടു മൂല്യത്തിന്റെ തരത്തിന്റെ പേര് ഒരു സ്ട്രിംഗ് സ്ലൈസായി നൽകുന്നു.
/// ഇത് `type_name::<T>()`-ന് തുല്യമാണ്, പക്ഷേ വേരിയബിളിന്റെ തരം എളുപ്പത്തിൽ ലഭ്യമല്ലാത്തയിടത്ത് ഇത് ഉപയോഗിക്കാൻ കഴിയും.
///
/// # Note
///
/// ഇത് ഡയഗ്നോസ്റ്റിക് ഉപയോഗത്തിനായി ഉദ്ദേശിച്ചുള്ളതാണ്.തരത്തിന്റെ മികച്ച ശ്രമ വിവരണമല്ലാതെ സ്‌ട്രിംഗിന്റെ കൃത്യമായ ഉള്ളടക്കവും ഫോർമാറ്റും വ്യക്തമാക്കിയിട്ടില്ല.
/// ഉദാഹരണത്തിന്, `type_name_of_val::<Option<String>>(None)` ന് `"Option<String>"` അല്ലെങ്കിൽ `"std::option::Option<std::string::String>"` നൽകാം, പക്ഷേ `"foobar"` അല്ല.
///
/// കൂടാതെ, കംപൈലറിന്റെ പതിപ്പുകൾക്കിടയിൽ output ട്ട്‌പുട്ട് മാറാം.
///
/// ഈ ഫംഗ്ഷൻ trait ഒബ്ജക്റ്റുകൾ പരിഹരിക്കുന്നില്ല, അതായത് `type_name_of_val(&7u32 as &dyn Debug)` `"dyn Debug"` നൽകാം, പക്ഷേ `"u32"` അല്ല.
///
/// ടൈപ്പ് നാമം ഒരു തരത്തിന്റെ അദ്വിതീയ ഐഡന്റിഫയറായി കണക്കാക്കരുത്;
/// ഒന്നിലധികം തരങ്ങൾ ഒരേ തരത്തിലുള്ള പേര് പങ്കിടാം.
///
/// നിലവിലെ നടപ്പാക്കൽ കംപൈലർ ഡയഗ്നോസ്റ്റിക്സ്, ഡീബഗ്ഗിൻഫോ എന്നിവയ്ക്ക് സമാനമായ ഇൻഫ്രാസ്ട്രക്ചർ ഉപയോഗിക്കുന്നു, പക്ഷേ ഇത് ഉറപ്പില്ല.
///
/// # Examples
///
/// സ്ഥിരസ്ഥിതി സംഖ്യയും ഫ്ലോട്ട് തരങ്ങളും അച്ചടിക്കുന്നു.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}