//! സ്റ്റാൻഡേർഡ് ലൈബ്രറിയിൽ Panic പിന്തുണ.

#![stable(feature = "core_panic_info", since = "1.41.0")]

use crate::any::Any;
use crate::fmt;

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2015_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2015 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($msg:literal $(,)?) => (
        $crate::panicking::panic($msg)
    ),
    ($msg:expr $(,)?) => (
        $crate::panicking::panic_str($msg)
    ),
    ($fmt:expr, $($arg:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($fmt, $($arg)+))
    ),
}

#[doc(hidden)]
#[unstable(feature = "edition_panic", issue = "none", reason = "use panic!() instead")]
#[allow_internal_unstable(core_panic)]
#[rustc_diagnostic_item = "core_panic_2021_macro"]
#[rustc_macro_transparency = "semitransparent"]
pub macro panic_2021 {
    () => (
        $crate::panicking::panic("explicit panic")
    ),
    ($($t:tt)+) => (
        $crate::panicking::panic_fmt($crate::format_args!($($t)+))
    ),
}

/// ഒരു panic നെക്കുറിച്ചുള്ള വിവരങ്ങൾ നൽകുന്ന ഒരു ഘടന.
///
/// `PanicInfo` ഘടന [`set_hook`] ഫംഗ്ഷൻ സജ്ജമാക്കിയ panic hook ലേക്ക് കൈമാറി.
///
///
/// [`set_hook`]: ../../std/panic/fn.set_hook.html
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
///         println!("panic occurred: {:?}", s);
///     } else {
///         println!("panic occurred");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
#[lang = "panic_info"]
#[stable(feature = "panic_hooks", since = "1.10.0")]
#[derive(Debug)]
pub struct PanicInfo<'a> {
    payload: &'a (dyn Any + Send),
    message: Option<&'a fmt::Arguments<'a>>,
    location: &'a Location<'a>,
}

impl<'a> PanicInfo<'a> {
    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn internal_constructor(
        message: Option<&'a fmt::Arguments<'a>>,
        location: &'a Location<'a>,
    ) -> Self {
        struct NoPayload;
        PanicInfo { location, message, payload: &NoPayload }
    }

    #[unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    #[inline]
    pub fn set_payload(&mut self, info: &'a (dyn Any + Send)) {
        self.payload = info;
    }

    /// panic-മായി ബന്ധപ്പെട്ട പേലോഡ് നൽകുന്നു.
    ///
    /// ഇത് സാധാരണയായി, പക്ഷേ എല്ലായ്പ്പോഴും അല്ല, ഒരു `&'static str` അല്ലെങ്കിൽ [`String`] ആയിരിക്കും.
    ///
    /// [`String`]: ../../std/string/struct.String.html
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(s) = panic_info.payload().downcast_ref::<&str>() {
    ///         println!("panic occurred: {:?}", s);
    ///     } else {
    ///         println!("panic occurred");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn payload(&self) -> &(dyn Any + Send) {
        self.payload
    }

    /// `core` crate-ൽ നിന്നുള്ള `panic!` മാക്രോ (`std`-ൽ നിന്ന് അല്ല) ഒരു ഫോർമാറ്റിംഗ് സ്‌ട്രിംഗും ചില അധിക ആർഗ്യുമെന്റുകളും ഉപയോഗിച്ച് ഉപയോഗിച്ചിട്ടുണ്ടെങ്കിൽ, ആ സന്ദേശം [`fmt::write`] ഉപയോഗിച്ച് ഉപയോഗിക്കാൻ തയ്യാറാണ്
    ///
    ///
    #[unstable(feature = "panic_info_message", issue = "66745")]
    pub fn message(&self) -> Option<&fmt::Arguments<'_>> {
        self.message
    }

    /// ലഭ്യമാണെങ്കിൽ, panic ഉത്ഭവിച്ച സ്ഥലത്തെക്കുറിച്ചുള്ള വിവരങ്ങൾ നൽകുന്നു.
    ///
    /// ഈ രീതി നിലവിൽ എല്ലായ്പ്പോഴും [`Some`] നൽകും, പക്ഷേ ഇത് future പതിപ്പുകളിൽ മാറിയേക്കാം.
    ///
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}' at line {}",
    ///             location.file(),
    ///             location.line(),
    ///         );
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn location(&self) -> Option<&Location<'_>> {
        // NOTE: ചിലപ്പോൾ ഒന്നും നൽകാതിരിക്കാൻ ഇത് മാറ്റുകയാണെങ്കിൽ,
        // std::panicking::default_hook, std::panicking::begin_panic_fmt എന്നിവയിൽ ആ കേസ് കൈകാര്യം ചെയ്യുക.
        Some(&self.location)
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for PanicInfo<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str("panicked at ")?;
        if let Some(message) = self.message {
            write!(formatter, "'{}', ", message)?
        } else if let Some(payload) = self.payload.downcast_ref::<&'static str>() {
            write!(formatter, "'{}', ", payload)?
        }
        // NOTE: ഞങ്ങൾക്ക് downcast_ref: : ഉപയോഗിക്കാൻ കഴിയില്ല<String>() ഇവിടെ
        // സ്ട്രിംഗ് ലിബ്കോറിൽ ലഭ്യമല്ലാത്തതിനാൽ!
        // ഒന്നിലധികം ആർ‌ഗ്യുമെൻറുകൾ‌ഉപയോഗിച്ച് `std::panic!` വിളിക്കുമ്പോൾ‌പേലോഡ് ഒരു സ്ട്രിംഗാണ്, പക്ഷേ അത്തരം സാഹചര്യത്തിൽ‌സന്ദേശവും ലഭ്യമാണ്.
        //

        self.location.fmt(formatter)
    }
}

/// ഒരു panic ന്റെ സ്ഥാനത്തെക്കുറിച്ചുള്ള വിവരങ്ങൾ‌അടങ്ങിയിരിക്കുന്ന ഒരു ഘടന.
///
/// ഈ ഘടന [`PanicInfo::location()`] സൃഷ്ടിച്ചതാണ്.
///
/// # Examples
///
/// ```should_panic
/// use std::panic;
///
/// panic::set_hook(Box::new(|panic_info| {
///     if let Some(location) = panic_info.location() {
///         println!("panic occurred in file '{}' at line {}", location.file(), location.line());
///     } else {
///         println!("panic occurred but can't get location information...");
///     }
/// }));
///
/// panic!("Normal panic");
/// ```
///
/// # Comparisons
///
/// സമത്വത്തിനും ക്രമപ്പെടുത്തലിനുമുള്ള താരതമ്യങ്ങൾ ഫയൽ, വരി, തുടർന്ന് നിര മുൻഗണന എന്നിവയിൽ നിർമ്മിക്കുന്നു.
/// ഫയലുകളെ സ്ട്രിംഗുകളായി താരതമ്യപ്പെടുത്തുന്നു, `Path` അല്ല, അത് അപ്രതീക്ഷിതമായിരിക്കാം.
/// കൂടുതൽ ചർച്ചയ്ക്ക് [`സ്ഥാനം: : ഫയൽ`] ന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
#[lang = "panic_location"]
#[derive(Copy, Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
#[stable(feature = "panic_hooks", since = "1.10.0")]
pub struct Location<'a> {
    file: &'a str,
    line: u32,
    col: u32,
}

impl<'a> Location<'a> {
    /// ഈ ഫംഗ്ഷന്റെ കോളറിന്റെ ഉറവിട സ്ഥാനം നൽകുന്നു.
    /// ആ ഫംഗ്ഷന്റെ കോളർ വ്യാഖ്യാനിച്ചിട്ടുണ്ടെങ്കിൽ, അതിന്റെ കോൾ സ്ഥാനം തിരികെ നൽകും, അങ്ങനെ ട്രാക്കുചെയ്യാത്ത ഫംഗ്ഷൻ ബോഡിയിലെ ആദ്യത്തെ കോളിലേക്ക് സ്റ്റാക്ക് അപ്പ് ചെയ്യുക.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::panic::Location;
    ///
    /// /// [`Location`] എന്ന് വിളിക്കുന്ന അത് നൽകുന്നു.
    /// #[track_caller]
    /// fn get_caller_location() -> &'static Location<'static> {
    ///     Location::caller()
    /// }
    ///
    /// /// ഈ ഫംഗ്ഷന്റെ നിർവചനത്തിനുള്ളിൽ നിന്ന് ഒരു [`Location`] നൽകുന്നു.
    /// fn get_just_one_location() -> &'static Location<'static> {
    ///     get_caller_location()
    /// }
    ///
    /// let fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), file!());
    /// assert_eq!(fixed_location.line(), 14);
    /// assert_eq!(fixed_location.column(), 5);
    ///
    /// // അൺട്രാക്ക് ചെയ്യാത്ത അതേ പ്രവർത്തനം മറ്റൊരു സ്ഥലത്ത് പ്രവർത്തിപ്പിക്കുന്നത് ഞങ്ങൾക്ക് സമാന ഫലം നൽകുന്നു
    /// let second_fixed_location = get_just_one_location();
    /// assert_eq!(fixed_location.file(), second_fixed_location.file());
    /// assert_eq!(fixed_location.line(), second_fixed_location.line());
    /// assert_eq!(fixed_location.column(), second_fixed_location.column());
    ///
    /// let this_location = get_caller_location();
    /// assert_eq!(this_location.file(), file!());
    /// assert_eq!(this_location.line(), 28);
    /// assert_eq!(this_location.column(), 21);
    ///
    /// // ട്രാക്കുചെയ്‌ത പ്രവർത്തനം മറ്റൊരു സ്ഥലത്ത് പ്രവർത്തിപ്പിക്കുന്നത് മറ്റൊരു മൂല്യം നൽകുന്നു
    /// let another_location = get_caller_location();
    /// assert_eq!(this_location.file(), another_location.file());
    /// assert_ne!(this_location.line(), another_location.line());
    /// assert_ne!(this_location.column(), another_location.column());
    /// ```
    #[stable(feature = "track_caller", since = "1.46.0")]
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    #[track_caller]
    pub const fn caller() -> &'static Location<'static> {
        crate::intrinsics::caller_location()
    }
}

impl<'a> Location<'a> {
    #![unstable(
        feature = "panic_internals",
        reason = "internal details of the implementation of the `panic!` and related macros",
        issue = "none"
    )]
    #[doc(hidden)]
    pub const fn internal_constructor(file: &'a str, line: u32, col: u32) -> Self {
        Location { file, line, col }
    }

    /// panic ഉത്ഭവിച്ച ഉറവിട ഫയലിന്റെ പേര് നൽകുന്നു.
    ///
    /// # `&str`, `&Path` അല്ല
    ///
    /// മടക്കിയ പേര് കംപൈലിംഗ് സിസ്റ്റത്തിലെ ഒരു ഉറവിട പാതയെ സൂചിപ്പിക്കുന്നു, പക്ഷേ ഇത് നേരിട്ട് ഒരു `&Path` ആയി പ്രതിനിധീകരിക്കുന്നതിന് സാധുതയില്ല.
    /// കംപൈൽ ചെയ്ത കോഡ് ഉള്ളടക്കങ്ങൾ നൽകുന്ന സിസ്റ്റത്തേക്കാൾ വ്യത്യസ്തമായ `Path` നടപ്പിലാക്കുന്ന മറ്റൊരു സിസ്റ്റത്തിൽ പ്രവർത്തിക്കാം, ഈ ലൈബ്രറിക്ക് നിലവിൽ മറ്റൊരു "host path" തരം ഇല്ല.
    ///
    /// മൊഡ്യൂൾ സിസ്റ്റത്തിലെ ഒന്നിലധികം പാതകളിലൂടെ (സാധാരണയായി `#[path = "..."]` ആട്രിബ്യൂട്ട് അല്ലെങ്കിൽ സമാനമായത് ഉപയോഗിച്ച്) "the same" ഫയൽ എത്തിച്ചേരുമ്പോഴാണ് ഏറ്റവും ആശ്ചര്യകരമായ പെരുമാറ്റം സംഭവിക്കുന്നത്, ഇത് സമാന കോഡായി തോന്നുന്നത് ഈ ഫംഗ്ഷനിൽ നിന്ന് വ്യത്യസ്ത മൂല്യങ്ങൾ നൽകുന്നതിന് കാരണമാകും.
    ///
    ///
    /// # Cross-compilation
    ///
    /// ഹോസ്റ്റ് പ്ലാറ്റ്‌ഫോമും ടാർഗെറ്റ് പ്ലാറ്റ്‌ഫോമും വ്യത്യാസപ്പെടുമ്പോൾ `Path::new` അല്ലെങ്കിൽ സമാന കൺസ്ട്രക്റ്ററുകളിലേക്ക് കടന്നുപോകുന്നതിന് ഈ മൂല്യം അനുയോജ്യമല്ല.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred in file '{}'", location.file());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn file(&self) -> &str {
        self.file
    }

    /// panic ഉത്ഭവിച്ച ലൈൻ നമ്പർ നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at line {}", location.line());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_hooks", since = "1.10.0")]
    pub fn line(&self) -> u32 {
        self.line
    }

    /// panic ഉത്ഭവിച്ച നിര നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```should_panic
    /// use std::panic;
    ///
    /// panic::set_hook(Box::new(|panic_info| {
    ///     if let Some(location) = panic_info.location() {
    ///         println!("panic occurred at column {}", location.column());
    ///     } else {
    ///         println!("panic occurred but can't get location information...");
    ///     }
    /// }));
    ///
    /// panic!("Normal panic");
    /// ```
    #[stable(feature = "panic_col", since = "1.25.0")]
    pub fn column(&self) -> u32 {
        self.col
    }
}

#[stable(feature = "panic_hook_display", since = "1.26.0")]
impl fmt::Display for Location<'_> {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}:{}:{}", self.file, self.line, self.col)
    }
}

/// Libstd-ൽ നിന്ന് `panic_unwind`-ലേക്കും മറ്റ് panic റൺടൈമുകളിലേക്കും ഡാറ്റ കൈമാറാൻ libstd ഉപയോഗിക്കുന്ന ഒരു ആന്തരിക trait.
/// എപ്പോൾ വേണമെങ്കിലും സ്ഥിരത കൈവരിക്കാൻ ഉദ്ദേശിച്ചിട്ടില്ല, ഉപയോഗിക്കരുത്.
///
#[unstable(feature = "std_internals", issue = "none")]
#[doc(hidden)]
pub unsafe trait BoxMeUp {
    /// ഉള്ളടക്കങ്ങളുടെ പൂർണ്ണ ഉടമസ്ഥാവകാശം നേടുക.
    /// റിട്ടേൺ തരം യഥാർത്ഥത്തിൽ `Box<dyn Any + Send>` ആണ്, പക്ഷേ ഞങ്ങൾക്ക് ലിബ്കോറിൽ `Box` ഉപയോഗിക്കാൻ കഴിയില്ല.
    ///
    /// ഈ രീതി വിളിച്ചതിനുശേഷം, `self`-ൽ ചില ഡമ്മി സ്ഥിരസ്ഥിതി മൂല്യം മാത്രമേ ശേഷിക്കുന്നുള്ളൂ.
    /// ഈ രീതിയെ രണ്ടുതവണ വിളിക്കുകയോ അല്ലെങ്കിൽ ഈ രീതി വിളിച്ചതിന് ശേഷം `get` എന്ന് വിളിക്കുകയോ ചെയ്യുന്നത് ഒരു പിശകാണ്.
    ///
    /// panic റൺ‌ടൈം (`__rust_start_panic`) ന് കടമെടുത്ത `dyn BoxMeUp` മാത്രമേ ലഭിക്കൂ എന്നതിനാൽ ആർ‌ഗ്യുമെൻറ് കടമെടുത്തു.
    ///
    fn take_box(&mut self) -> *mut (dyn Any + Send);

    /// ഉള്ളടക്കം കടമെടുക്കുക.
    fn get(&mut self) -> &(dyn Any + Send);
}