use crate::iter::FromIterator;

/// ഒരു യൂണിറ്ററിൽ നിന്ന് എല്ലാ യൂണിറ്റ് ഇനങ്ങളും ഒന്നായി ചുരുക്കുന്നു.
///
/// നിങ്ങൾ പിശകുകളെ മാത്രം ശ്രദ്ധിക്കുന്ന `Result<(), E>`-ലേക്ക് ശേഖരിക്കുന്നത് പോലുള്ള ഉയർന്ന തലത്തിലുള്ള അമൂർത്തങ്ങളുമായി സംയോജിപ്പിക്കുമ്പോൾ ഇത് കൂടുതൽ ഉപയോഗപ്രദമാണ്:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}