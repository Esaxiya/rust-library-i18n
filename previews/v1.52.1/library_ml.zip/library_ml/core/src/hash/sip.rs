//! SipHash നടപ്പിലാക്കൽ.

#![allow(deprecated)] // ഈ മൊഡ്യൂളിലെ തരങ്ങൾ‌ഒഴിവാക്കി

use crate::cmp;
use crate::marker::PhantomData;
use crate::mem;
use crate::ptr;

/// SipHash 1-3 നടപ്പിലാക്കൽ.
///
/// ഇത് നിലവിൽ സ്റ്റാൻഡേർഡ് ലൈബ്രറി ഉപയോഗിക്കുന്ന സ്ഥിരസ്ഥിതി ഹാഷിംഗ് ഫംഗ്ഷനാണ് (ഉദാ. `collections::HashMap` ഇത് സ്ഥിരസ്ഥിതിയായി ഉപയോഗിക്കുന്നു).
///
///
/// See: <https://131002.net/siphash>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
#[doc(hidden)]
pub struct SipHasher13 {
    hasher: Hasher<Sip13Rounds>,
}

/// SipHash 2-4 നടപ്പിലാക്കൽ.
///
/// See: <https://131002.net/siphash/>
#[unstable(feature = "hashmap_internals", issue = "none")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
struct SipHasher24 {
    hasher: Hasher<Sip24Rounds>,
}

/// SipHash 2-4 നടപ്പിലാക്കൽ.
///
/// See: <https://131002.net/siphash/>
///
/// സിപ് ഹാഷ് ഒരു പൊതു-ഉദ്ദേശ്യ ഹാഷിംഗ് ഫംഗ്ഷനാണ്: ഇത് നല്ല വേഗതയിൽ പ്രവർത്തിക്കുന്നു (സ്പൂക്കി, സിറ്റിയുമായി മത്സരിക്കുന്നു) കൂടാതെ ശക്തമായ എക്സ് 00 എക്സ് ഹാഷിംഗ് അനുവദിക്കുന്നു.
///
/// [`rand::os::OsRng`](https://doc.rust-lang.org/rand/rand/os/struct.OsRng.html) പോലുള്ള ശക്തമായ RNG യിൽ നിന്ന് നിങ്ങളുടെ ഹാഷ് പട്ടികകൾ കീ ചെയ്യാൻ ഇത് നിങ്ങളെ അനുവദിക്കുന്നു.
///
/// SipHash അൽഗോരിതം പൊതുവെ ശക്തമാണെന്ന് കണക്കാക്കപ്പെടുന്നുണ്ടെങ്കിലും, ഇത് ക്രിപ്റ്റോഗ്രാഫിക് ആവശ്യങ്ങൾക്കായി ഉദ്ദേശിച്ചുള്ളതല്ല.
/// അതുപോലെ, ഈ നടപ്പാക്കലിന്റെ എല്ലാ ക്രിപ്റ്റോഗ്രാഫിക് ഉപയോഗങ്ങളും _strongly discouraged_ ആണ്.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.13.0",
    reason = "use `std::collections::hash_map::DefaultHasher` instead"
)]
#[derive(Debug, Clone, Default)]
pub struct SipHasher(SipHasher24);

#[derive(Debug)]
struct Hasher<S: Sip> {
    k0: u64,
    k1: u64,
    length: usize, // ഞങ്ങൾ എത്ര ബൈറ്റുകൾ പ്രോസസ്സ് ചെയ്തു
    state: State,  // ഹാഷ് സ്റ്റേറ്റ്
    tail: u64,     // പ്രോസസ്സ് ചെയ്യാത്ത ബൈറ്റുകൾ ലെ
    ntail: usize,  // വാലിൽ എത്ര ബൈറ്റുകൾ സാധുവാണ്
    _marker: PhantomData<S>,
}

#[derive(Debug, Clone, Copy)]
#[repr(C)]
struct State {
    // v0, v2, v1, v3 എന്നിവ അൽ‌ഗോരിതം ജോഡികളായി കാണിക്കുന്നു, കൂടാതെ SipHash ന്റെ സിം‌ഡ് നടപ്പാക്കലുകൾ‌v02, v13 എന്നിവയുടെ vectors ഉപയോഗിക്കും.
    //
    // ഈ ക്രമത്തിൽ‌അവ ഘടനയിൽ‌സ്ഥാപിക്കുന്നതിലൂടെ, കംപൈലറിന് കുറച്ച് സിം‌ഡ് ഒപ്റ്റിമൈസേഷനുകൾ‌സ്വയമേവ എടുക്കാൻ‌കഴിയും.
    //
    v0: u64,
    v2: u64,
    v1: u64,
    v3: u64,
}

macro_rules! compress {
    ($state:expr) => {{ compress!($state.v0, $state.v1, $state.v2, $state.v3) }};
    ($v0:expr, $v1:expr, $v2:expr, $v3:expr) => {{
        $v0 = $v0.wrapping_add($v1);
        $v1 = $v1.rotate_left(13);
        $v1 ^= $v0;
        $v0 = $v0.rotate_left(32);
        $v2 = $v2.wrapping_add($v3);
        $v3 = $v3.rotate_left(16);
        $v3 ^= $v2;
        $v0 = $v0.wrapping_add($v3);
        $v3 = $v3.rotate_left(21);
        $v3 ^= $v0;
        $v2 = $v2.wrapping_add($v1);
        $v1 = $v1.rotate_left(17);
        $v1 ^= $v2;
        $v2 = $v2.rotate_left(32);
    }};
}

/// LE ക്രമത്തിൽ ഒരു ബൈറ്റ് സ്ട്രീമിൽ നിന്ന് ആവശ്യമുള്ള തരത്തിലുള്ള ഒരു സംഖ്യ ലോഡുചെയ്യുന്നു.
/// ക്രമീകരിക്കാത്ത വിലാസത്തിൽ നിന്ന് ലോഡുചെയ്യുന്നതിനുള്ള ഏറ്റവും കാര്യക്ഷമമായ മാർഗം സൃഷ്ടിക്കാൻ കമ്പൈലറിനെ അനുവദിക്കുന്നതിന് `copy_nonoverlapping` ഉപയോഗിക്കുന്നു.
///
///
/// സുരക്ഷിതമല്ലാത്തതിനാൽ: i..i+size_of(int_ty)-ൽ അൺചെക്കുചെയ്ത സൂചിക
macro_rules! load_int_le {
    ($buf:expr, $i:expr, $int_ty:ident) => {{
        debug_assert!($i + mem::size_of::<$int_ty>() <= $buf.len());
        let mut data = 0 as $int_ty;
        ptr::copy_nonoverlapping(
            $buf.as_ptr().add($i),
            &mut data as *mut _ as *mut u8,
            mem::size_of::<$int_ty>(),
        );
        data.to_le()
    }};
}

/// ഒരു ബൈറ്റ് സ്ലൈസിന്റെ 7 ബൈറ്റുകൾ വരെ ഒരു u64 ലോഡുചെയ്യുന്നു.
/// ഇത് വിചിത്രമായി കാണപ്പെടുന്നു, പക്ഷേ സംഭവിക്കുന്ന `copy_nonoverlapping` കോളുകൾക്ക് (`load_int_le!` വഴി) എല്ലാം നിശ്ചിത വലുപ്പമുള്ളതിനാൽ `memcpy` വിളിക്കുന്നത് ഒഴിവാക്കുക, ഇത് വേഗതയ്ക്ക് നല്ലതാണ്.
///
///
/// സുരക്ഷിതമല്ലാത്തതിനാൽ: ആരംഭത്തിൽ അൺചെക്കുചെയ്ത സൂചിക..സ്റ്റാർട്ട് + ലെൻ
#[inline]
unsafe fn u8to64_le(buf: &[u8], start: usize, len: usize) -> u64 {
    debug_assert!(len < 8);
    let mut i = 0; // 00 ട്ട്‌പുട്ടിലെ u64-ലെ നിലവിലെ ബൈറ്റ് സൂചിക (LSB-യിൽ നിന്ന്)
    let mut out = 0;
    if i + 3 < len {
        // സുരക്ഷ: `i`, `len` നേക്കാൾ വലുതായിരിക്കരുത്, കൂടാതെ കോളർ ഉറപ്പ് നൽകണം
        // സൂചിക ആരംഭിക്കുക..സ്റ്റാർട്ട് + ലെൻ അതിരുകളിലാണ്.
        out = unsafe { load_int_le!(buf, start + i, u32) } as u64;
        i += 4;
    }
    if i + 1 < len {
        // സുരക്ഷ: മുകളിൽ പറഞ്ഞതുപോലെ.
        out |= (unsafe { load_int_le!(buf, start + i, u16) } as u64) << (i * 8);
        i += 2
    }
    if i < len {
        // സുരക്ഷ: മുകളിൽ പറഞ്ഞതുപോലെ.
        out |= (unsafe { *buf.get_unchecked(start + i) } as u64) << (i * 8);
        i += 1;
    }
    debug_assert_eq!(i, len);
    out
}

impl SipHasher {
    /// രണ്ട് പ്രാരംഭ കീകൾ 0 ആയി സജ്ജമാക്കി ഒരു പുതിയ `SipHasher` സൃഷ്ടിക്കുന്നു.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher {
        SipHasher::new_with_keys(0, 0)
    }

    /// നൽകിയ കീകളിൽ നിന്ന് കീ ചെയ്ത ഒരു `SipHasher` സൃഷ്ടിക്കുന്നു.
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher {
        SipHasher(SipHasher24 { hasher: Hasher::new_with_keys(key0, key1) })
    }
}

impl SipHasher13 {
    /// രണ്ട് പ്രാരംഭ കീകൾ 0 ആയി സജ്ജമാക്കി ഒരു പുതിയ `SipHasher13` സൃഷ്ടിക്കുന്നു.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new() -> SipHasher13 {
        SipHasher13::new_with_keys(0, 0)
    }

    /// നൽകിയ കീകളിൽ നിന്ന് കീ ചെയ്ത ഒരു `SipHasher13` സൃഷ്ടിക്കുന്നു.
    #[inline]
    #[unstable(feature = "hashmap_internals", issue = "none")]
    #[rustc_deprecated(
        since = "1.13.0",
        reason = "use `std::collections::hash_map::DefaultHasher` instead"
    )]
    pub fn new_with_keys(key0: u64, key1: u64) -> SipHasher13 {
        SipHasher13 { hasher: Hasher::new_with_keys(key0, key1) }
    }
}

impl<S: Sip> Hasher<S> {
    #[inline]
    fn new_with_keys(key0: u64, key1: u64) -> Hasher<S> {
        let mut state = Hasher {
            k0: key0,
            k1: key1,
            length: 0,
            state: State { v0: 0, v1: 0, v2: 0, v3: 0 },
            tail: 0,
            ntail: 0,
            _marker: PhantomData,
        };
        state.reset();
        state
    }

    #[inline]
    fn reset(&mut self) {
        self.length = 0;
        self.state.v0 = self.k0 ^ 0x736f6d6570736575;
        self.state.v1 = self.k1 ^ 0x646f72616e646f6d;
        self.state.v2 = self.k0 ^ 0x6c7967656e657261;
        self.state.v3 = self.k1 ^ 0x7465646279746573;
        self.ntail = 0;
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl super::Hasher for SipHasher {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.0.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.0.hasher.finish()
    }
}

#[unstable(feature = "hashmap_internals", issue = "none")]
impl super::Hasher for SipHasher13 {
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        self.hasher.write(msg)
    }

    #[inline]
    fn finish(&self) -> u64 {
        self.hasher.finish()
    }
}

impl<S: Sip> super::Hasher for Hasher<S> {
    // Note: പൂർണ്ണ സംഖ്യ ഹാഷിംഗ് രീതികളൊന്നും (`റൈറ്റ്_യു *`, എക്സ് 00 എക്സ്) നിർവചിച്ചിട്ടില്ല
    // ഈ തരത്തിനായി.
    // ഞങ്ങൾക്ക് അവ ചേർക്കാനും librustc_data_structures/sip128.rs-ൽ `short_write` നടപ്പിലാക്കൽ പകർത്താനും `SipHasher`, `SipHasher13`, `DefaultHasher` എന്നിവയിലേക്ക് `write_u *`/`write_i*` രീതികൾ ചേർക്കാനും കഴിയും.
    //
    // ചില ബെഞ്ച്മാർക്കുകളിൽ കംപൈൽ വേഗത അൽപ്പം മന്ദഗതിയിലാക്കിക്കൊണ്ട്, ആ ഹാഷറുകൾ ഇന്റീരിയർ ഹാഷിംഗ് വളരെയധികം വേഗത്തിലാക്കും.
    // വിശദാംശങ്ങൾക്ക് #69152 കാണുക.
    //
    #[inline]
    fn write(&mut self, msg: &[u8]) {
        let length = msg.len();
        self.length += length;

        let mut needed = 0;

        if self.ntail != 0 {
            needed = 8 - self.ntail;
            // സുരക്ഷ: `cmp::min(length, needed)`, `length` ന് മുകളിലായിരിക്കില്ലെന്ന് ഉറപ്പുനൽകുന്നു
            self.tail |= unsafe { u8to64_le(msg, 0, cmp::min(length, needed)) } << (8 * self.ntail);
            if length < needed {
                self.ntail += length;
                return;
            } else {
                self.state.v3 ^= self.tail;
                S::c_rounds(&mut self.state);
                self.state.v0 ^= self.tail;
                self.ntail = 0;
            }
        }

        // ബഫർ‌ഡ് ടെയിൽ‌ഇപ്പോൾ‌ഫ്ലഷ് ചെയ്‌തു, പുതിയ ഇൻ‌പുട്ട് പ്രോസസ്സ് ചെയ്യുക.
        let len = length - needed;
        let left = len & 0x7; // ലെൻ% 8

        let mut i = needed;
        while i < len - left {
            // സുരക്ഷ: കാരണം 8 വയസ്സിന് താഴെയുള്ള ഏറ്റവും വലിയ ഗുണിതമാണ് `len - left`
            // `len`, `i` `needed`-ൽ ആരംഭിക്കുന്നതിനാൽ `len` `length - needed` ആയതിനാൽ, `i + 8` `length`-നേക്കാൾ കുറവോ തുല്യമോ ആണെന്ന് ഉറപ്പുനൽകുന്നു.
            //
            let mi = unsafe { load_int_le!(msg, i, u64) };

            self.state.v3 ^= mi;
            S::c_rounds(&mut self.state);
            self.state.v0 ^= mi;

            i += 8;
        }

        // സുരക്ഷ: `i` ഇപ്പോൾ `needed + len.div_euclid(8) * 8` ആണ്,
        // അതിനാൽ `i + left` = `needed + len` = `length`, നിർവചനം അനുസരിച്ച് `msg.len()` ന് തുല്യമാണ്.
        //
        self.tail = unsafe { u8to64_le(msg, i, left) };
        self.ntail = left;
    }

    #[inline]
    fn finish(&self) -> u64 {
        let mut state = self.state;

        let b: u64 = ((self.length as u64 & 0xff) << 56) | self.tail;

        state.v3 ^= b;
        S::c_rounds(&mut state);
        state.v0 ^= b;

        state.v2 ^= 0xff;
        S::d_rounds(&mut state);

        state.v0 ^ state.v1 ^ state.v2 ^ state.v3
    }
}

impl<S: Sip> Clone for Hasher<S> {
    #[inline]
    fn clone(&self) -> Hasher<S> {
        Hasher {
            k0: self.k0,
            k1: self.k1,
            length: self.length,
            state: self.state,
            tail: self.tail,
            ntail: self.ntail,
            _marker: self._marker,
        }
    }
}

impl<S: Sip> Default for Hasher<S> {
    /// 0 എന്ന് സജ്ജമാക്കിയ രണ്ട് പ്രാരംഭ കീകൾ ഉപയോഗിച്ച് ഒരു `Hasher<S>` സൃഷ്ടിക്കുന്നു.
    #[inline]
    fn default() -> Hasher<S> {
        Hasher::new_with_keys(0, 0)
    }
}

#[doc(hidden)]
trait Sip {
    fn c_rounds(_: &mut State);
    fn d_rounds(_: &mut State);
}

#[derive(Debug, Clone, Default)]
struct Sip13Rounds;

impl Sip for Sip13Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
    }
}

#[derive(Debug, Clone, Default)]
struct Sip24Rounds;

impl Sip for Sip24Rounds {
    #[inline]
    fn c_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
    }

    #[inline]
    fn d_rounds(state: &mut State) {
        compress!(state);
        compress!(state);
        compress!(state);
        compress!(state);
    }
}