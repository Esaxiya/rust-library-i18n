use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// `ടി` യുടെ ഡിസ്ട്രക്റ്റർ സ്വപ്രേരിതമായി വിളിക്കുന്നതിൽ നിന്ന് കംപൈലറെ തടയുന്നതിനുള്ള ഒരു റാപ്പർ.
/// ഈ റാപ്പർ 0-വിലയാണ്.
///
/// `ManuallyDrop<T>` `T`-ന്റെ അതേ ലേ layout ട്ട് ഒപ്റ്റിമൈസേഷനുകൾക്ക് വിധേയമാണ്.
/// അനന്തരഫലമായി, കംപൈലർ അതിന്റെ ഉള്ളടക്കത്തെക്കുറിച്ച് നടത്തുന്ന അനുമാനങ്ങളെ ഇത് ബാധിക്കുന്നില്ല.
/// ഉദാഹരണത്തിന്, [`mem::zeroed`] ഉപയോഗിച്ച് ഒരു `ManuallyDrop<&mut T>` സമാരംഭിക്കുന്നത് നിർവചിക്കപ്പെടാത്ത സ്വഭാവമാണ്.
/// ആരംഭിക്കാത്ത ഡാറ്റ കൈകാര്യം ചെയ്യണമെങ്കിൽ, പകരം [`MaybeUninit<T>`] ഉപയോഗിക്കുക.
///
/// ഒരു `ManuallyDrop<T>`-നുള്ളിൽ മൂല്യം ആക്സസ് ചെയ്യുന്നത് സുരക്ഷിതമാണെന്ന് ശ്രദ്ധിക്കുക.
/// ഇതിനർത്ഥം, ഉള്ളടക്കം ഉപേക്ഷിച്ച `ManuallyDrop<T>` ഒരു പൊതു സുരക്ഷിത API വഴി തുറന്നുകാട്ടാൻ പാടില്ല എന്നാണ്.
/// അതിനനുസരിച്ച്, `ManuallyDrop::drop` സുരക്ഷിതമല്ല.
///
/// # `ManuallyDrop` ഡ്രോപ്പ് ഓർഡർ.
///
/// Rust ന് നന്നായി നിർവചിക്കപ്പെട്ട [drop order] മൂല്യങ്ങളുണ്ട്.
/// ഫീൽ‌ഡുകളെയോ പ്രദേശവാസികളെയോ ഒരു നിർ‌ദ്ദിഷ്‌ട ക്രമത്തിൽ‌ഒഴിവാക്കിയിട്ടുണ്ടെന്ന് ഉറപ്പുവരുത്താൻ, വ്യക്തമായ ഡ്രോപ്പ് ഓർ‌ഡർ‌ശരിയായ ഒന്നാണെന്ന് പ്രഖ്യാപനങ്ങൾ‌പുന order ക്രമീകരിക്കുക.
///
/// ഡ്രോപ്പ് ഓർ‌ഡർ‌നിയന്ത്രിക്കുന്നതിന് `ManuallyDrop` ഉപയോഗിക്കാൻ‌കഴിയും, പക്ഷേ ഇതിന് സുരക്ഷിതമല്ലാത്ത കോഡ് ആവശ്യമാണ്, കൂടാതെ അൺ‌വൈൻ‌ഡിംഗിന്റെ സാന്നിധ്യത്തിൽ‌ശരിയായി ചെയ്യാൻ‌പ്രയാസമാണ്.
///
///
/// ഉദാഹരണത്തിന്, ഒരു നിർദ്ദിഷ്ട ഫീൽഡ് മറ്റുള്ളവർക്ക് ശേഷം ഉപേക്ഷിച്ചുവെന്ന് ഉറപ്പാക്കണമെങ്കിൽ, ഇത് ഒരു സ്ട്രക്റ്റിന്റെ അവസാന ഫീൽഡ് ആക്കുക:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` `children` ന് ശേഷം ഉപേക്ഷിക്കും.
///     // ഡിക്ലറേഷൻ ക്രമത്തിൽ ഫീൽഡുകൾ ഉപേക്ഷിക്കുമെന്ന് Rust ഉറപ്പ് നൽകുന്നു.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// സ്വമേധയാ ഉപേക്ഷിക്കേണ്ട ഒരു മൂല്യം പൊതിയുക.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // നിങ്ങൾക്ക് ഇപ്പോഴും മൂല്യത്തിൽ സുരക്ഷിതമായി പ്രവർത്തിക്കാൻ കഴിയും
    /// assert_eq!(*x, "Hello");
    /// // എന്നാൽ `Drop` ഇവിടെ പ്രവർത്തിക്കില്ല
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// `ManuallyDrop` കണ്ടെയ്നറിൽ നിന്ന് മൂല്യം വേർതിരിച്ചെടുക്കുന്നു.
    ///
    /// മൂല്യം വീണ്ടും ഉപേക്ഷിക്കാൻ ഇത് അനുവദിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // ഇത് `Box` കുറയുന്നു.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// `ManuallyDrop<T>` കണ്ടെയ്നറിൽ നിന്ന് മൂല്യം പുറത്തെടുക്കുന്നു.
    ///
    /// ഈ രീതി പ്രാഥമികമായി ഡ്രോപ്പിലെ മൂല്യങ്ങൾ നീക്കാൻ ഉദ്ദേശിച്ചുള്ളതാണ്.
    /// മൂല്യം സ്വമേധയാ ഉപേക്ഷിക്കുന്നതിന് [`ManuallyDrop::drop`] ഉപയോഗിക്കുന്നതിനുപകരം, നിങ്ങൾക്ക് ഈ രീതി ഉപയോഗിച്ച് മൂല്യം എടുത്ത് ആവശ്യമുള്ള രീതിയിൽ ഉപയോഗിക്കാം.
    ///
    /// സാധ്യമാകുമ്പോൾ, പകരം [`into_inner`][`ManuallyDrop::into_inner`] ഉപയോഗിക്കുന്നതാണ് നല്ലത്, ഇത് `ManuallyDrop<T>` ന്റെ ഉള്ളടക്കം തനിപ്പകർപ്പാക്കുന്നത് തടയുന്നു.
    ///
    ///
    /// # Safety
    ///
    /// കൂടുതൽ ഉപയോഗം തടയാതെ ഈ ഫംഗ്ഷൻ അർത്ഥവത്തായ മൂല്യം നീക്കുന്നു, ഈ കണ്ടെയ്നറിന്റെ അവസ്ഥയിൽ മാറ്റമില്ല.
    /// ഈ `ManuallyDrop` വീണ്ടും ഉപയോഗിക്കുന്നില്ലെന്ന് ഉറപ്പാക്കേണ്ടത് നിങ്ങളുടെ ഉത്തരവാദിത്തമാണ്.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // സുരക്ഷ: ഞങ്ങൾ ഒരു റഫറൻസിൽ നിന്ന് വായിക്കുന്നു, അത് ഉറപ്പുനൽകുന്നു
        // വായനയ്‌ക്ക് സാധുതയുള്ളതായിരിക്കും.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// അടങ്ങിയിരിക്കുന്ന മൂല്യം സ്വമേധയാ ഉപേക്ഷിക്കുന്നു.അടങ്ങിയിരിക്കുന്ന മൂല്യത്തിലേക്ക് ഒരു പോയിന്റർ ഉപയോഗിച്ച് [`ptr::drop_in_place`] എന്ന് വിളിക്കുന്നതിന് ഇത് തുല്യമാണ്.
    /// അതുപോലെ, അടങ്ങിയിരിക്കുന്ന മൂല്യം ഒരു പായ്ക്ക് ചെയ്ത ഘടനയല്ലെങ്കിൽ, മൂല്യം നീക്കാതെ തന്നെ ഡിസ്ട്രക്റ്ററെ സ്ഥലത്ത് വിളിക്കും, അതിനാൽ എക്സ് 100 എക്സ് ഡാറ്റ സുരക്ഷിതമായി ഉപേക്ഷിക്കാൻ ഇത് ഉപയോഗിക്കാം.
    ///
    /// നിങ്ങൾക്ക് മൂല്യത്തിന്റെ ഉടമസ്ഥാവകാശമുണ്ടെങ്കിൽ, പകരം നിങ്ങൾക്ക് [`ManuallyDrop::into_inner`] ഉപയോഗിക്കാം.
    ///
    /// # Safety
    ///
    /// ഈ ഫംഗ്ഷൻ അടങ്ങിയിരിക്കുന്ന മൂല്യത്തിന്റെ ഡിസ്ട്രക്റ്റർ പ്രവർത്തിപ്പിക്കുന്നു.
    /// ഡിസ്ട്രക്റ്റർ തന്നെ വരുത്തിയ മാറ്റങ്ങൾക്ക് പുറമെ, മെമ്മറി മാറ്റമില്ലാതെ തുടരുന്നു, മാത്രമല്ല കംപൈലറിനെ സംബന്ധിച്ചിടത്തോളം `T` തരത്തിന് സാധുതയുള്ള ഒരു ബിറ്റ്-പാറ്റേൺ ഇപ്പോഴും ഉണ്ട്.
    ///
    ///
    /// എന്നിരുന്നാലും, ഈ "zombie" മൂല്യം സുരക്ഷിത കോഡിന് വിധേയമാക്കരുത്, മാത്രമല്ല ഈ ഫംഗ്ഷനെ ഒന്നിലധികം തവണ വിളിക്കാൻ പാടില്ല.
    /// ഒരു മൂല്യം ഉപേക്ഷിച്ചതിന് ശേഷം അത് ഉപയോഗിക്കുന്നതിനോ അല്ലെങ്കിൽ ഒരു മൂല്യം ഒന്നിലധികം തവണ ഉപേക്ഷിക്കുന്നതിനോ നിർവചിക്കപ്പെടാത്ത പെരുമാറ്റത്തിന് കാരണമാകും (`drop` ചെയ്യുന്നതിനെ ആശ്രയിച്ച്).
    /// ഇത് സാധാരണയായി ടൈപ്പ് സിസ്റ്റം തടയുന്നു, പക്ഷേ `ManuallyDrop` ന്റെ ഉപയോക്താക്കൾ കംപൈലറിന്റെ സഹായമില്ലാതെ ആ ഗ്യാരണ്ടികൾ ഉയർത്തിപ്പിടിക്കണം.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // സുരക്ഷ: പരിവർത്തനം ചെയ്യാവുന്ന ഒരു റഫറൻസ് ചൂണ്ടിക്കാണിച്ച മൂല്യം ഞങ്ങൾ ഉപേക്ഷിക്കുന്നു
        // ഇത് റൈറ്റുകൾക്ക് സാധുതയുള്ളതാണെന്ന് ഉറപ്പുനൽകുന്നു.
        // `slot` വീണ്ടും ഉപേക്ഷിച്ചിട്ടില്ലെന്ന് ഉറപ്പാക്കേണ്ടത് കോളർ ആണ്.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}