use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// `T`-ന്റെ തുടക്കമിടാത്ത സംഭവങ്ങൾ നിർമ്മിക്കുന്നതിനുള്ള ഒരു റാപ്പർ തരം.
///
/// # സമാരംഭിക്കൽ മാറ്റമില്ലാത്തത്
///
/// കംപൈലർ പൊതുവേ, വേരിയബിളിന്റെ തരത്തിനനുസരിച്ച് ഒരു വേരിയബിൾ ശരിയായി സമാരംഭിച്ചുവെന്ന് അനുമാനിക്കുന്നു.ഉദാഹരണത്തിന്, റഫറൻസ് തരത്തിന്റെ വേരിയബിൾ വിന്യസിക്കുകയും NULL അല്ലാത്തതുമായിരിക്കണം.
/// സുരക്ഷിതമല്ലാത്ത കോഡിൽ പോലും *എല്ലായ്പ്പോഴും* ഉയർത്തിപ്പിടിക്കേണ്ട ഒരു മാറ്റമാണിത്.
/// അനന്തരഫലമായി, റഫറൻസ് തരത്തിന്റെ വേരിയബിൾ പൂജ്യം-സമാരംഭിക്കുന്നത് തൽക്ഷണ [undefined behavior][ub]-ന് കാരണമാകുന്നു, മെമ്മറി ആക്‌സസ് ചെയ്യുന്നതിന് ആ റഫറൻസ് എപ്പോഴെങ്കിലും ഉപയോഗിക്കുമോ എന്നത് പ്രശ്നമല്ല:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // നിർവചിക്കാത്ത പെരുമാറ്റം!⚠️
/// // `MaybeUninit<&i32>`-ന് തുല്യമായ കോഡ്:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // നിർവചിക്കാത്ത പെരുമാറ്റം!⚠️
/// ```
///
/// റൺ-ടൈം ചെക്കുകൾ ഒഴിവാക്കുക, `enum` ലേ .ട്ട് ഒപ്റ്റിമൈസ് ചെയ്യുക എന്നിങ്ങനെയുള്ള വിവിധ ഒപ്റ്റിമൈസേഷനുകൾക്കായി ഇത് കംപൈലർ ഉപയോഗപ്പെടുത്തുന്നു.
///
/// അതുപോലെ, പൂർണ്ണമായും ആരംഭിക്കാത്ത മെമ്മറിക്ക് ഏതെങ്കിലും ഉള്ളടക്കം ഉണ്ടായിരിക്കാം, അതേസമയം ഒരു `bool` എല്ലായ്പ്പോഴും `true` അല്ലെങ്കിൽ `false` ആയിരിക്കണം.അതിനാൽ, ആരംഭിക്കാത്ത `bool` സൃഷ്ടിക്കുന്നത് നിർവചിക്കപ്പെടാത്ത സ്വഭാവമാണ്:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // നിർവചിക്കാത്ത പെരുമാറ്റം!⚠️
/// // `MaybeUninit<bool>`-ന് തുല്യമായ കോഡ്:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // നിർവചിക്കാത്ത പെരുമാറ്റം!⚠️
/// ```
///
/// മാത്രമല്ല, നിശ്ചിത മൂല്യമില്ലാത്തതിനാൽ (ആരംഭിക്കാത്ത മെമ്മറി പ്രത്യേകമാണ് ("fixed" എന്നാൽ "it won't change without being written to").ആരംഭിക്കാത്ത ഒരേ ബൈറ്റ് ഒന്നിലധികം തവണ വായിക്കുന്നത് വ്യത്യസ്ത ഫലങ്ങൾ നൽകും.
/// ആ വേരിയബിളിന് ഒരു ഇൻറിജർ തരം ഉണ്ടെങ്കിൽപ്പോലും ഒരു വേരിയബിളിൽ തുടക്കമിടാത്ത ഡാറ്റ ഉണ്ടെന്നത് നിർവചിക്കാത്ത പെരുമാറ്റത്തെ ഇത് മാറ്റുന്നു, അല്ലാത്തപക്ഷം ഏതെങ്കിലും *നിശ്ചിത* ബിറ്റ് പാറ്റേൺ പിടിക്കാൻ കഴിയും:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // നിർവചിക്കാത്ത പെരുമാറ്റം!⚠️
/// // `MaybeUninit<i32>`-ന് തുല്യമായ കോഡ്:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // നിർവചിക്കാത്ത പെരുമാറ്റം!⚠️
/// ```
/// (ആരംഭിക്കാത്ത സംഖ്യകൾക്ക് ചുറ്റുമുള്ള നിയമങ്ങൾ ഇതുവരെ തീരുമാനിച്ചിട്ടില്ലെന്ന് ശ്രദ്ധിക്കുക, പക്ഷേ അവ ഉണ്ടാകുന്നതുവരെ അവ ഒഴിവാക്കുന്നത് നല്ലതാണ്.)
///
/// അതിനുമുകളിൽ, ടൈപ്പ് ലെവലിൽ സമാരംഭിച്ചതായി കണക്കാക്കുന്നതിനപ്പുറം മിക്ക തരങ്ങൾക്കും അധിക മാറ്റങ്ങളുണ്ടെന്ന് ഓർമ്മിക്കുക.
/// ഉദാഹരണത്തിന്, ഒരു `1`-സമാരംഭിച്ച [`Vec<T>`] സമാരംഭിച്ചതായി കണക്കാക്കപ്പെടുന്നു (നിലവിലെ നടപ്പാക്കലിനു കീഴിൽ; ഇത് സ്ഥിരമായ ഒരു ഗ്യാരണ്ടിയല്ല) കാരണം കംപൈലറിന് ഇതിനെക്കുറിച്ച് അറിയാവുന്ന ഒരേയൊരു ആവശ്യകത ഡാറ്റാ പോയിന്റർ ശൂന്യമായിരിക്കണം എന്നതാണ്.
/// അത്തരമൊരു `Vec<T>` സൃഷ്ടിക്കുന്നത് *ഉടനടി* നിർവചിക്കപ്പെടാത്ത പെരുമാറ്റത്തിന് കാരണമാകില്ല, പക്ഷേ ഏറ്റവും സുരക്ഷിതമായ പ്രവർത്തനങ്ങളിൽ (അത് ഉപേക്ഷിക്കുന്നത് ഉൾപ്പെടെ) നിർവചിക്കപ്പെടാത്ത പെരുമാറ്റത്തിന് കാരണമാകും.
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` ആരംഭിക്കാത്ത ഡാറ്റ കൈകാര്യം ചെയ്യുന്നതിന് സുരക്ഷിതമല്ലാത്ത കോഡ് പ്രാപ്തമാക്കുന്നതിന് സഹായിക്കുന്നു.
/// ഇത് കംപൈലറിലേക്കുള്ള ഒരു സിഗ്നലാണ്, ഇവിടെ ഡാറ്റ * സമാരംഭിക്കാനിടയില്ലെന്ന് സൂചിപ്പിക്കുന്നു:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // വ്യക്തമായി ആരംഭിക്കാത്ത റഫറൻസ് സൃഷ്ടിക്കുക.
/// // ഒരു `MaybeUninit<T>`-നുള്ളിലെ ഡാറ്റ അസാധുവായിരിക്കാമെന്ന് കംപൈലറിന് അറിയാം, അതിനാൽ ഇത് യുബി അല്ല:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // ഇത് സാധുവായ ഒരു മൂല്യത്തിലേക്ക് സജ്ജമാക്കുക.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // സമാരംഭിച്ച ഡാറ്റ എക്‌സ്‌ട്രാക്റ്റുചെയ്യുക-`x` ശരിയായി സമാരംഭിച്ചതിന് ശേഷം * മാത്രമേ ഇത് അനുവദിക്കൂ!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// ഈ കോഡിൽ തെറ്റായ അനുമാനങ്ങളോ ഒപ്റ്റിമൈസേഷനുകളോ നടത്തരുതെന്ന് കംപൈലറിന് അറിയാം.
///
/// നിങ്ങൾക്ക് `MaybeUninit<T>` എന്നത് `Option<T>` പോലെയാണെന്നും എന്നാൽ റൺ-ടൈം ട്രാക്കിംഗ് കൂടാതെ സുരക്ഷാ പരിശോധനകളൊന്നുമില്ലാതെയും നിങ്ങൾക്ക് ചിന്തിക്കാം.
///
/// ## out-pointers
///
/// "out-pointers" നടപ്പിലാക്കാൻ നിങ്ങൾക്ക് `MaybeUninit<T>` ഉപയോഗിക്കാം: ഒരു ഫംഗ്ഷനിൽ നിന്ന് ഡാറ്റ മടക്കിനൽകുന്നതിനുപകരം, ഫലം നൽകുന്നതിന് ചില (uninitialized) മെമ്മറിയിലേക്ക് ഒരു പോയിന്റർ കൈമാറുക.
/// ഫലം സംഭരിച്ചിരിക്കുന്ന മെമ്മറി എങ്ങനെയാണ് അനുവദിക്കുന്നതെന്ന് നിയന്ത്രിക്കാൻ കോളർക്ക് പ്രധാനമാകുമ്പോൾ ഇത് ഉപയോഗപ്രദമാകും, കൂടാതെ അനാവശ്യ നീക്കങ്ങൾ ഒഴിവാക്കാനും നിങ്ങൾ ആഗ്രഹിക്കുന്നു.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` പഴയ ഉള്ളടക്കങ്ങൾ ഉപേക്ഷിക്കുന്നില്ല, അത് പ്രധാനമാണ്.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // `v` സമാരംഭിച്ചതായി ഇപ്പോൾ നമുക്കറിയാം!vector ശരിയായി ഉപേക്ഷിക്കപ്പെട്ടുവെന്നും ഇത് ഉറപ്പാക്കുന്നു.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## എലമെൻറ്-ബൈ-എലമെൻറ് ഒരു അറേ സമാരംഭിക്കുന്നു
///
/// `MaybeUninit<T>` എലമെൻറ്-ബൈ-എലമെൻറ് ഒരു വലിയ അറേ സമാരംഭിക്കുന്നതിന് ഇത് ഉപയോഗിക്കാം:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // ആരംഭിക്കാത്ത `MaybeUninit` ശ്രേണി സൃഷ്ടിക്കുക.
///     // `assume_init` സുരക്ഷിതമാണ്, കാരണം ഞങ്ങൾ ഇവിടെ സമാരംഭിച്ചുവെന്ന് അവകാശപ്പെടുന്ന തരം `ഒരുപക്ഷേ യുനിനിറ്റിന്റെ` ഒരു കൂട്ടമാണ്, ഇതിന് ഓർഗനൈസേഷൻ ആവശ്യമില്ല.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // ഒരു `MaybeUninit` ഉപേക്ഷിക്കുന്നത് ഒന്നും ചെയ്യുന്നില്ല.
///     // അങ്ങനെ `ptr::write` ന് പകരം റോ പോയിന്റർ അസൈൻ‌മെന്റ് ഉപയോഗിക്കുന്നത് പഴയ തുടക്കമിടാത്ത മൂല്യം ഉപേക്ഷിക്കുന്നതിന് കാരണമാകില്ല.
/////
///     // ഈ ലൂപ്പിനിടെ ഒരു panic ഉണ്ടെങ്കിൽ, ഞങ്ങൾക്ക് ഒരു മെമ്മറി ലീക്ക് ഉണ്ട്, പക്ഷേ മെമ്മറി സുരക്ഷാ പ്രശ്‌നങ്ങളൊന്നുമില്ല.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // എല്ലാം സമാരംഭിച്ചു.
///     // സമാരംഭിച്ച തരത്തിലേക്ക് അറേ പരിവർത്തനം ചെയ്യുക.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// ഭാഗികമായി സമാരംഭിച്ച അറേകളുമായി നിങ്ങൾക്ക് പ്രവർത്തിക്കാനും കഴിയും, അത് താഴ്ന്ന നിലയിലുള്ള ഡാറ്റാസ്ട്രക്ചറുകളിൽ കണ്ടെത്താനാകും.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // ആരംഭിക്കാത്ത `MaybeUninit` ശ്രേണി സൃഷ്ടിക്കുക.
/// // `assume_init` സുരക്ഷിതമാണ്, കാരണം ഞങ്ങൾ ഇവിടെ സമാരംഭിച്ചുവെന്ന് അവകാശപ്പെടുന്ന തരം `ഒരുപക്ഷേ യുനിനിറ്റിന്റെ` ഒരു കൂട്ടമാണ്, ഇതിന് ഓർഗനൈസേഷൻ ആവശ്യമില്ല.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // ഞങ്ങൾ നിയോഗിച്ച ഘടകങ്ങളുടെ എണ്ണം എണ്ണുക.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // അറേയിലെ ഓരോ ഇനത്തിനും, ഞങ്ങൾ അത് അനുവദിച്ചിട്ടുണ്ടെങ്കിൽ ഡ്രോപ്പ് ചെയ്യുക.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## ഒരു സ്ട്രക്റ്റ് ഫീൽഡ്-ബൈ-ഫീൽഡ് സമാരംഭിക്കുന്നു
///
/// ഫീൽഡ് അനുസരിച്ച് സ്ട്രക്റ്റ്സ് ഫീൽഡ് സമാരംഭിക്കുന്നതിന് നിങ്ങൾക്ക് `MaybeUninit<T>`, [`std::ptr::addr_of_mut`] മാക്രോ എന്നിവ ഉപയോഗിക്കാം:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // `name` ഫീൽഡ് സമാരംഭിക്കുന്നു
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // `list` ഫീൽഡ് സമാരംഭിക്കുന്നു ഇവിടെ ഒരു panic ഉണ്ടെങ്കിൽ, `name` ഫീൽഡിലെ `String` ചോർന്നൊലിക്കുന്നു.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // എല്ലാ ഫീൽഡുകളും സമാരംഭിച്ചു, അതിനാൽ ഒരു പ്രാരംഭ ഫൂ ലഭിക്കാൻ ഞങ്ങൾ `assume_init` എന്ന് വിളിക്കുന്നു.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` `T`-ന് തുല്യമായ വലുപ്പം, വിന്യാസം, എ‌ബി‌ഐ എന്നിവ ഉണ്ടെന്ന് ഉറപ്പുനൽകുന്നു:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// എന്നിരുന്നാലും *ഒരു `MaybeUninit<T>` അടങ്ങിയ ഒരു തരം* ഒരേ ലേ layout ട്ട് ആയിരിക്കണമെന്നില്ല;`T`, `U` എന്നിവയ്ക്ക് ഒരേ വലുപ്പവും വിന്യാസവും ഉണ്ടെങ്കിലും `Foo<T>`-ന്റെ ഫീൽഡുകൾക്ക് `Foo<U>`-ന് സമാനമായ ക്രമമുണ്ടെന്ന് Rust പൊതുവേ ഉറപ്പുനൽകുന്നില്ല.
///
/// കൂടാതെ, ഒരു ബിറ്റ് മൂല്യം ഒരു `MaybeUninit<T>` ന് സാധുതയുള്ളതിനാൽ കംപൈലറിന് non-zero/niche-filling ഒപ്റ്റിമൈസേഷനുകൾ പ്രയോഗിക്കാൻ കഴിയില്ല, ഇത് വലിയ വലുപ്പത്തിന് കാരണമാകാം:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// `T` FFI-സുരക്ഷിതമാണെങ്കിൽ, `MaybeUninit<T>` ഉം അങ്ങനെ തന്നെ.
///
/// `MaybeUninit` `#[repr(transparent)]` ആണെങ്കിലും (ഇത് `T` എന്നതിന് സമാന വലുപ്പം, വിന്യാസം, ABI എന്നിവ ഉറപ്പുനൽകുന്നുവെന്ന് സൂചിപ്പിക്കുന്നു), ഇത് മുമ്പത്തെ മുന്നറിയിപ്പുകളിലൊന്നും * മാറ്റില്ല.
/// `Option<T>` ഒപ്പം `Option<MaybeUninit<T>>` ന് ഇപ്പോഴും വ്യത്യസ്ത വലുപ്പങ്ങളുണ്ടാകാം, കൂടാതെ `T` തരം ഫീൽഡ് അടങ്ങിയ തരങ്ങൾ ആ ഫീൽഡ് `MaybeUninit<T>` എന്നതിനേക്കാൾ വ്യത്യസ്തമായി (വലുപ്പത്തിലും) ക്രമീകരിക്കാം.
/// `MaybeUninit` ഒരു യൂണിയൻ തരമാണ്, യൂണിയനുകളിലെ `#[repr(transparent)]` അസ്ഥിരമാണ് ([the tracking issue](https://github.com/rust-lang/rust/issues/60405)) കാണുക.
/// കാലക്രമേണ, യൂണിയനുകളിൽ `#[repr(transparent)]` ന്റെ കൃത്യമായ ഗ്യാരൻറി വികസിച്ചേക്കാം, കൂടാതെ `MaybeUninit` `#[repr(transparent)]` ആയിരിക്കാം അല്ലെങ്കിൽ നിലനിൽക്കില്ല.
/// അതായത്, `MaybeUninit<T>` ന് `T` ന് സമാനമായ വലുപ്പവും വിന്യാസവും എ‌ബി‌ഐയും ഉണ്ടെന്ന് *എല്ലായ്പ്പോഴും* ഉറപ്പ് നൽകും;ഗ്യാരണ്ടി നൽകുന്ന `MaybeUninit` നടപ്പിലാക്കുന്ന രീതി വികസിച്ചേക്കാം.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// ലാംഗ് ഇനം അതിനാൽ ഞങ്ങൾക്ക് മറ്റ് തരങ്ങൾ പൊതിയാൻ കഴിയും.ജനറേറ്ററുകൾക്ക് ഇത് ഉപയോഗപ്രദമാണ്.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // `T::clone()`-ലേക്ക് വിളിക്കുന്നില്ല, അതിനായി വേണ്ടത്ര സമാരംഭിച്ചിട്ടുണ്ടോ എന്ന് ഞങ്ങൾക്ക് അറിയാൻ കഴിയില്ല.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// തന്നിരിക്കുന്ന മൂല്യത്തിനൊപ്പം സമാരംഭിച്ച ഒരു പുതിയ `MaybeUninit<T>` സൃഷ്ടിക്കുന്നു.
    /// ഈ ഫംഗ്ഷന്റെ റിട്ടേൺ മൂല്യത്തിൽ [`assume_init`]-ലേക്ക് വിളിക്കുന്നത് സുരക്ഷിതമാണ്.
    ///
    /// ഒരു `MaybeUninit<T>` ഉപേക്ഷിക്കുന്നത് ഒരിക്കലും `T` ന്റെ ഡ്രോപ്പ് കോഡിനെ വിളിക്കില്ലെന്നത് ശ്രദ്ധിക്കുക.
    /// സമാരംഭിച്ചാൽ `T` കുറയുന്നുവെന്ന് ഉറപ്പാക്കേണ്ടത് നിങ്ങളുടെ ഉത്തരവാദിത്തമാണ്.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// ആരംഭിക്കാത്ത അവസ്ഥയിൽ ഒരു പുതിയ `MaybeUninit<T>` സൃഷ്ടിക്കുന്നു.
    ///
    /// ഒരു `MaybeUninit<T>` ഉപേക്ഷിക്കുന്നത് ഒരിക്കലും `T` ന്റെ ഡ്രോപ്പ് കോഡിനെ വിളിക്കില്ലെന്നത് ശ്രദ്ധിക്കുക.
    /// സമാരംഭിച്ചാൽ `T` കുറയുന്നുവെന്ന് ഉറപ്പാക്കേണ്ടത് നിങ്ങളുടെ ഉത്തരവാദിത്തമാണ്.
    ///
    /// ചില ഉദാഹരണങ്ങൾക്ക് [type-level documentation][MaybeUninit] കാണുക.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// ആരംഭിക്കാത്ത അവസ്ഥയിൽ, `MaybeUninit<T>` ഇനങ്ങളുടെ ഒരു പുതിയ നിര സൃഷ്ടിക്കുക.
    ///
    /// Note: ഒരു future Rust പതിപ്പിൽ, അറേ ലിറ്ററൽ സിന്റാക്സ് [repeating const expressions](https://github.com/rust-lang/rust/issues/49147) അനുവദിക്കുമ്പോൾ ഈ രീതി അനാവശ്യമായി മാറിയേക്കാം.
    ///
    /// ചുവടെയുള്ള ഉദാഹരണത്തിന് `let mut buf = [MaybeUninit::<u8>::uninit(); 32];` ഉപയോഗിക്കാം.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// യഥാർത്ഥത്തിൽ വായിച്ച ഡാറ്റയുടെ (ഒരുപക്ഷേ ചെറുത്) സ്ലൈസ് നൽകുന്നു
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // സുരക്ഷ: ആരംഭിക്കാത്ത `[MaybeUninit<_>; LEN]` സാധുവാണ്.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// മെമ്മറി `0` ബൈറ്റുകൾ കൊണ്ട് നിറച്ചുകൊണ്ട്, ആരംഭിക്കാത്ത അവസ്ഥയിൽ ഒരു പുതിയ `MaybeUninit<T>` സൃഷ്ടിക്കുന്നു.ഇത് ശരിയായ ഓർഗനൈസേഷനായി ഇതിനകം തന്നെ ഉണ്ടാക്കുന്നുണ്ടോ എന്നത് `T` നെ ആശ്രയിച്ചിരിക്കുന്നു.
    ///
    /// ഉദാഹരണത്തിന്, `MaybeUninit<usize>::zeroed()` സമാരംഭിച്ചു, പക്ഷേ `MaybeUninit<&'static i32>::zeroed()` കാരണം റഫറൻ‌സുകൾ‌അസാധുവായിരിക്കരുത്.
    ///
    /// ഒരു `MaybeUninit<T>` ഉപേക്ഷിക്കുന്നത് ഒരിക്കലും `T` ന്റെ ഡ്രോപ്പ് കോഡിനെ വിളിക്കില്ലെന്നത് ശ്രദ്ധിക്കുക.
    /// സമാരംഭിച്ചാൽ `T` കുറയുന്നുവെന്ന് ഉറപ്പാക്കേണ്ടത് നിങ്ങളുടെ ഉത്തരവാദിത്തമാണ്.
    ///
    /// # Example
    ///
    /// ഈ ഫംഗ്ഷന്റെ ശരിയായ ഉപയോഗം: പൂജ്യത്തോടുകൂടിയ ഒരു സ്ട്രക്റ്റ് സമാരംഭിക്കുന്നു, അവിടെ സ്ട്രക്റ്റിന്റെ എല്ലാ ഫീൽഡുകൾക്കും ബിറ്റ്-പാറ്റേൺ 0 സാധുവായ മൂല്യമായി നിലനിർത്താൻ കഴിയും.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// ഈ ഫംഗ്ഷന്റെ *തെറ്റായ* ഉപയോഗം: `0` തരം സാധുവായ ബിറ്റ്-പാറ്റേൺ അല്ലാത്തപ്പോൾ `x.zeroed().assume_init()` എന്ന് വിളിക്കുന്നത്:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // ഒരു ജോഡിക്കുള്ളിൽ, സാധുവായ വിവേചനമില്ലാത്ത ഒരു `NotZero` ഞങ്ങൾ സൃഷ്ടിക്കുന്നു.
    /// // ഇത് നിർവചിക്കപ്പെടാത്ത സ്വഭാവമാണ്.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // സുരക്ഷ: അനുവദിച്ച മെമ്മറിയിലേക്ക് `u.as_mut_ptr()` പോയിന്റുകൾ.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// `MaybeUninit<T>`-ന്റെ മൂല്യം സജ്ജമാക്കുന്നു.
    /// ഇത് മുമ്പത്തെ ഏതെങ്കിലും മൂല്യം ഉപേക്ഷിക്കാതെ പുനരാലേഖനം ചെയ്യുന്നു, അതിനാൽ ഡിസ്ട്രക്റ്റർ പ്രവർത്തിപ്പിക്കുന്നത് ഒഴിവാക്കാൻ നിങ്ങൾ ആഗ്രഹിക്കുന്നില്ലെങ്കിൽ ഇത് രണ്ടുതവണ ഉപയോഗിക്കാതിരിക്കാൻ ശ്രദ്ധിക്കുക.
    ///
    /// നിങ്ങളുടെ സ For കര്യത്തിനായി, ഇത് `self`-ന്റെ (ഇപ്പോൾ സുരക്ഷിതമായി സമാരംഭിച്ച) ഉള്ളടക്കങ്ങളിലേക്ക് ഒരു മ്യൂട്ടബിൾ റഫറൻസും നൽകുന്നു.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // സുരക്ഷ: ഞങ്ങൾ ഈ മൂല്യം സമാരംഭിച്ചു.
        unsafe { self.assume_init_mut() }
    }

    /// അടങ്ങിയിരിക്കുന്ന മൂല്യത്തിലേക്ക് ഒരു പോയിന്റർ നേടുന്നു.
    /// `MaybeUninit<T>` സമാരംഭിച്ചില്ലെങ്കിൽ ഈ പോയിന്ററിൽ നിന്ന് വായിക്കുകയോ റഫറൻസായി മാറ്റുകയോ ചെയ്യുന്നത് നിർവചിക്കപ്പെടാത്ത സ്വഭാവമാണ്.
    /// ഈ പോയിന്റർ (non-transitively) ചൂണ്ടിക്കാണിക്കുന്ന മെമ്മറിയിലേക്ക് എഴുതുന്നത് നിർവചിക്കപ്പെടാത്ത പെരുമാറ്റമാണ് (ഒരു `UnsafeCell<T>` നുള്ളിൽ ഒഴികെ).
    ///
    /// # Examples
    ///
    /// ഈ രീതിയുടെ ശരിയായ ഉപയോഗം:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<T>`-ലേക്ക് ഒരു റഫറൻസ് സൃഷ്ടിക്കുക.ഞങ്ങൾ ഇത് സമാരംഭിച്ചതിനാൽ ഇത് കുഴപ്പമില്ല.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// ഈ രീതിയുടെ *തെറ്റായ* ഉപയോഗം:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // ആരംഭിക്കാത്ത vector-ലേക്ക് ഞങ്ങൾ ഒരു റഫറൻസ് സൃഷ്ടിച്ചു!ഇത് നിർവചിക്കപ്പെടാത്ത സ്വഭാവമാണ്.⚠️
    /// ```
    ///
    /// (ആരംഭിക്കാത്ത ഡാറ്റയെക്കുറിച്ചുള്ള റഫറൻ‌സുകൾ‌ക്ക് ചുറ്റുമുള്ള നിയമങ്ങൾ‌ഇതുവരെ അന്തിമമായിട്ടില്ലെന്ന് ശ്രദ്ധിക്കുക, പക്ഷേ അവ ഉണ്ടാകുന്നതുവരെ അവ ഒഴിവാക്കുന്നത് നല്ലതാണ്.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` ഒപ്പം `ManuallyDrop` രണ്ടും `repr(transparent)` ആയതിനാൽ നമുക്ക് പോയിന്റർ കാസ്റ്റുചെയ്യാനാകും.
        self as *const _ as *const T
    }

    /// അടങ്ങിയിരിക്കുന്ന മൂല്യത്തിലേക്ക് ഒരു മ്യൂട്ടബിൾ പോയിന്റർ നേടുന്നു.
    /// `MaybeUninit<T>` സമാരംഭിച്ചില്ലെങ്കിൽ ഈ പോയിന്ററിൽ നിന്ന് വായിക്കുകയോ റഫറൻസായി മാറ്റുകയോ ചെയ്യുന്നത് നിർവചിക്കപ്പെടാത്ത സ്വഭാവമാണ്.
    ///
    /// # Examples
    ///
    /// ഈ രീതിയുടെ ശരിയായ ഉപയോഗം:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // `MaybeUninit<Vec<u32>>`-ലേക്ക് ഒരു റഫറൻസ് സൃഷ്ടിക്കുക.
    /// // ഞങ്ങൾ ഇത് സമാരംഭിച്ചതിനാൽ ഇത് കുഴപ്പമില്ല.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// ഈ രീതിയുടെ *തെറ്റായ* ഉപയോഗം:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // ആരംഭിക്കാത്ത vector-ലേക്ക് ഞങ്ങൾ ഒരു റഫറൻസ് സൃഷ്ടിച്ചു!ഇത് നിർവചിക്കപ്പെടാത്ത സ്വഭാവമാണ്.⚠️
    /// ```
    ///
    /// (ആരംഭിക്കാത്ത ഡാറ്റയെക്കുറിച്ചുള്ള റഫറൻ‌സുകൾ‌ക്ക് ചുറ്റുമുള്ള നിയമങ്ങൾ‌ഇതുവരെ അന്തിമമായിട്ടില്ലെന്ന് ശ്രദ്ധിക്കുക, പക്ഷേ അവ ഉണ്ടാകുന്നതുവരെ അവ ഒഴിവാക്കുന്നത് നല്ലതാണ്.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` ഒപ്പം `ManuallyDrop` രണ്ടും `repr(transparent)` ആയതിനാൽ നമുക്ക് പോയിന്റർ കാസ്റ്റുചെയ്യാനാകും.
        self as *mut _ as *mut T
    }

    /// `MaybeUninit<T>` കണ്ടെയ്നറിൽ നിന്ന് മൂല്യം വേർതിരിച്ചെടുക്കുന്നു.ഡാറ്റ ഉപേക്ഷിക്കുമെന്ന് ഉറപ്പാക്കാനുള്ള മികച്ച മാർഗമാണിത്, കാരണം ഫലമായി ലഭിക്കുന്ന `T` സാധാരണ ഡ്രോപ്പ് കൈകാര്യം ചെയ്യലിന് വിധേയമാണ്.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` ശരിക്കും ഒരു പ്രാരംഭ അവസ്ഥയിലാണെന്ന് ഉറപ്പ് നൽകേണ്ടത് കോളർ ആണ്.ഉള്ളടക്കം ഇതുവരെ പൂർണ്ണമായി ആരംഭിച്ചിട്ടില്ലാത്തപ്പോൾ ഇത് വിളിക്കുന്നത് ഉടനടി നിർവചിക്കപ്പെടാത്ത സ്വഭാവത്തിന് കാരണമാകുന്നു.
    /// [type-level documentation][inv]-ൽ ഈ ഓർഗനൈസേഷൻ മാറ്റത്തെക്കുറിച്ച് കൂടുതൽ വിവരങ്ങൾ അടങ്ങിയിരിക്കുന്നു.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// അതിനുമുകളിൽ, ടൈപ്പ് ലെവലിൽ സമാരംഭിച്ചതായി കണക്കാക്കുന്നതിനപ്പുറം മിക്ക തരങ്ങൾക്കും അധിക മാറ്റങ്ങളുണ്ടെന്ന് ഓർമ്മിക്കുക.
    /// ഉദാഹരണത്തിന്, ഒരു `1`-സമാരംഭിച്ച [`Vec<T>`] സമാരംഭിച്ചതായി കണക്കാക്കപ്പെടുന്നു (നിലവിലെ നടപ്പാക്കലിനു കീഴിൽ; ഇത് സ്ഥിരമായ ഒരു ഗ്യാരണ്ടിയല്ല) കാരണം കംപൈലറിന് ഇതിനെക്കുറിച്ച് അറിയാവുന്ന ഒരേയൊരു ആവശ്യകത ഡാറ്റാ പോയിന്റർ ശൂന്യമായിരിക്കണം എന്നതാണ്.
    ///
    /// അത്തരമൊരു `Vec<T>` സൃഷ്ടിക്കുന്നത് *ഉടനടി* നിർവചിക്കപ്പെടാത്ത പെരുമാറ്റത്തിന് കാരണമാകില്ല, പക്ഷേ ഏറ്റവും സുരക്ഷിതമായ പ്രവർത്തനങ്ങളിൽ (അത് ഉപേക്ഷിക്കുന്നത് ഉൾപ്പെടെ) നിർവചിക്കപ്പെടാത്ത പെരുമാറ്റത്തിന് കാരണമാകും.
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// ഈ രീതിയുടെ ശരിയായ ഉപയോഗം:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// ഈ രീതിയുടെ *തെറ്റായ* ഉപയോഗം:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` ഇതുവരെ സമാരംഭിച്ചിട്ടില്ല, അതിനാൽ ഈ അവസാന വരി നിർവചിക്കപ്പെടാത്ത പെരുമാറ്റത്തിന് കാരണമായി.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // സുരക്ഷ: `self` സമാരംഭിച്ചുവെന്ന് കോളർ ഉറപ്പ് നൽകണം.
        // `self` ഒരു `value` വേരിയന്റായിരിക്കണം എന്നും ഇതിനർത്ഥം.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// `MaybeUninit<T>` കണ്ടെയ്നറിൽ നിന്ന് മൂല്യം വായിക്കുന്നു.തത്ഫലമായുണ്ടാകുന്ന `T` സാധാരണ ഡ്രോപ്പ് കൈകാര്യം ചെയ്യലിന് വിധേയമാണ്.
    ///
    /// സാധ്യമാകുമ്പോൾ, പകരം [`assume_init`] ഉപയോഗിക്കുന്നതാണ് നല്ലത്, ഇത് `MaybeUninit<T>` ന്റെ ഉള്ളടക്കം തനിപ്പകർപ്പാക്കുന്നത് തടയുന്നു.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` ശരിക്കും ഒരു പ്രാരംഭ അവസ്ഥയിലാണെന്ന് ഉറപ്പ് നൽകേണ്ടത് കോളർ ആണ്.ഉള്ളടക്കം ഇതുവരെ പൂർണ്ണമായി സമാരംഭിച്ചിട്ടില്ലാത്തപ്പോൾ ഇത് വിളിക്കുന്നത് നിർവചിക്കപ്പെടാത്ത സ്വഭാവത്തിന് കാരണമാകുന്നു.
    /// [type-level documentation][inv]-ൽ ഈ ഓർഗനൈസേഷൻ മാറ്റത്തെക്കുറിച്ച് കൂടുതൽ വിവരങ്ങൾ അടങ്ങിയിരിക്കുന്നു.
    ///
    /// മാത്രമല്ല, ഇത് അതേ ഡാറ്റയുടെ ഒരു പകർപ്പ് `MaybeUninit<T>`-ൽ ഉപേക്ഷിക്കുന്നു.
    /// ഡാറ്റയുടെ ഒന്നിലധികം പകർപ്പുകൾ ഉപയോഗിക്കുമ്പോൾ (`assume_init_read` നെ ഒന്നിലധികം തവണ വിളിക്കുകയോ അല്ലെങ്കിൽ ആദ്യം `assume_init_read`, തുടർന്ന് [`assume_init`] എന്ന് വിളിക്കുകയോ ചെയ്യുക), ആ ഡാറ്റ യഥാർത്ഥത്തിൽ തനിപ്പകർപ്പായിരിക്കുമെന്ന് ഉറപ്പാക്കേണ്ടത് നിങ്ങളുടെ ഉത്തരവാദിത്തമാണ്.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ഈ രീതിയുടെ ശരിയായ ഉപയോഗം:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` `Copy` ആണ്, അതിനാൽ ഞങ്ങൾ ഒന്നിലധികം തവണ വായിച്ചേക്കാം.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // ഒരു `None` മൂല്യം തനിപ്പകർപ്പാക്കുന്നത് ശരിയാണ്, അതിനാൽ ഞങ്ങൾ ഒന്നിലധികം തവണ വായിച്ചേക്കാം.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// ഈ രീതിയുടെ *തെറ്റായ* ഉപയോഗം:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // ഞങ്ങൾ ഇപ്പോൾ ഒരേ vector ന്റെ രണ്ട് പകർപ്പുകൾ സൃഷ്ടിച്ചു, ഇത് ഇരട്ട-രഹിതത്തിലേക്ക് നയിക്കുന്നു both അവ രണ്ടും ഉപേക്ഷിക്കുമ്പോൾ!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // സുരക്ഷ: `self` സമാരംഭിച്ചുവെന്ന് കോളർ ഉറപ്പ് നൽകണം.
        // `self` സമാരംഭിക്കേണ്ടതിനാൽ `self.as_ptr()`-ൽ നിന്നുള്ള വായന സുരക്ഷിതമാണ്.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// അടങ്ങിയിരിക്കുന്ന മൂല്യം സ്ഥലത്ത് ഉപേക്ഷിക്കുന്നു.
    ///
    /// നിങ്ങൾക്ക് `MaybeUninit` ന്റെ ഉടമസ്ഥാവകാശം ഉണ്ടെങ്കിൽ, പകരം നിങ്ങൾക്ക് [`assume_init`] ഉപയോഗിക്കാം.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` ശരിക്കും ഒരു പ്രാരംഭ അവസ്ഥയിലാണെന്ന് ഉറപ്പ് നൽകേണ്ടത് കോളർ ആണ്.ഉള്ളടക്കം ഇതുവരെ പൂർണ്ണമായി സമാരംഭിച്ചിട്ടില്ലാത്തപ്പോൾ ഇത് വിളിക്കുന്നത് നിർവചിക്കപ്പെടാത്ത സ്വഭാവത്തിന് കാരണമാകുന്നു.
    ///
    /// അതിനുമുകളിൽ, `T` തരത്തിന്റെ എല്ലാ അധിക മാറ്റങ്ങളും തൃപ്തിപ്പെടണം, കാരണം `T` (അല്ലെങ്കിൽ അതിന്റെ അംഗങ്ങൾ) ന്റെ `Drop` നടപ്പിലാക്കൽ ഇതിനെ ആശ്രയിച്ചിരിക്കും.
    /// ഉദാഹരണത്തിന്, ഒരു `1`-സമാരംഭിച്ച [`Vec<T>`] സമാരംഭിച്ചതായി കണക്കാക്കപ്പെടുന്നു (നിലവിലെ നടപ്പാക്കലിനു കീഴിൽ; ഇത് സ്ഥിരമായ ഒരു ഗ്യാരണ്ടിയല്ല) കാരണം കംപൈലറിന് ഇതിനെക്കുറിച്ച് അറിയാവുന്ന ഒരേയൊരു ആവശ്യകത ഡാറ്റാ പോയിന്റർ ശൂന്യമായിരിക്കണം എന്നതാണ്.
    ///
    /// എന്നിരുന്നാലും അത്തരമൊരു `Vec<T>` ഉപേക്ഷിക്കുന്നത് നിർവചിക്കപ്പെടാത്ത സ്വഭാവത്തിന് കാരണമാകും.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // സുരക്ഷ: `self` സമാരംഭിച്ചുവെന്ന് കോളർ ഉറപ്പ് നൽകണം
        // `T`-ന്റെ എല്ലാ മാറ്റങ്ങളെയും തൃപ്തിപ്പെടുത്തുന്നു.
        // അങ്ങനെയാണെങ്കിൽ മൂല്യം ഉപേക്ഷിക്കുന്നത് സുരക്ഷിതമാണ്.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// അടങ്ങിയിരിക്കുന്ന മൂല്യത്തിലേക്ക് ഒരു പങ്കിട്ട റഫറൻസ് നേടുന്നു.
    ///
    /// സമാരംഭിച്ചതും എന്നാൽ `MaybeUninit` ന്റെ ഉടമസ്ഥാവകാശമില്ലാത്തതുമായ `MaybeUninit` ആക്സസ് ചെയ്യാൻ ഞങ്ങൾ ആഗ്രഹിക്കുമ്പോൾ ഇത് ഉപയോഗപ്രദമാകും (`.assume_init()`) ഉപയോഗം തടയുന്നു.
    ///
    /// # Safety
    ///
    /// ഉള്ളടക്കം ഇതുവരെ പൂർണ്ണമായി സമാരംഭിച്ചിട്ടില്ലാത്തപ്പോൾ ഇത് വിളിക്കുന്നത് നിർവചിക്കപ്പെടാത്ത പെരുമാറ്റത്തിന് കാരണമാകുന്നു: `MaybeUninit<T>` ശരിക്കും ഒരു പ്രാരംഭ അവസ്ഥയിലാണെന്ന് ഉറപ്പ് നൽകേണ്ടത് കോളർ ആണ്.
    ///
    ///
    /// # Examples
    ///
    /// ### ഈ രീതിയുടെ ശരിയായ ഉപയോഗം:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // `x` സമാരംഭിക്കുക:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // ഇപ്പോൾ ഞങ്ങളുടെ `MaybeUninit<_>` സമാരംഭിച്ചതായി അറിയപ്പെടുന്നു, അതിനായി ഒരു പങ്കിട്ട റഫറൻസ് സൃഷ്ടിക്കുന്നതിൽ തെറ്റില്ല:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // സുരക്ഷ: `x` സമാരംഭിച്ചു.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### ഈ രീതിയുടെ *തെറ്റായ* ഉപയോഗങ്ങൾ‌:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // ആരംഭിക്കാത്ത vector-ലേക്ക് ഞങ്ങൾ ഒരു റഫറൻസ് സൃഷ്ടിച്ചു!ഇത് നിർവചിക്കപ്പെടാത്ത സ്വഭാവമാണ്.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // `Cell::set` ഉപയോഗിച്ച് `MaybeUninit` സമാരംഭിക്കുക:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // ആരംഭിക്കാത്ത `Cell<bool>`-ലേക്കുള്ള റഫറൻസ്: യുബി!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // സുരക്ഷ: `self` സമാരംഭിച്ചുവെന്ന് കോളർ ഉറപ്പ് നൽകണം.
        // `self` ഒരു `value` വേരിയന്റായിരിക്കണം എന്നും ഇതിനർത്ഥം.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// അടങ്ങിയിരിക്കുന്ന മൂല്യത്തിലേക്ക് മ്യൂട്ടബിൾ (unique) റഫറൻസ് നേടുന്നു.
    ///
    /// സമാരംഭിച്ചതും എന്നാൽ `MaybeUninit` ന്റെ ഉടമസ്ഥാവകാശമില്ലാത്തതുമായ `MaybeUninit` ആക്സസ് ചെയ്യാൻ ഞങ്ങൾ ആഗ്രഹിക്കുമ്പോൾ ഇത് ഉപയോഗപ്രദമാകും (`.assume_init()`) ഉപയോഗം തടയുന്നു.
    ///
    /// # Safety
    ///
    /// ഉള്ളടക്കം ഇതുവരെ പൂർണ്ണമായി സമാരംഭിച്ചിട്ടില്ലാത്തപ്പോൾ ഇത് വിളിക്കുന്നത് നിർവചിക്കപ്പെടാത്ത പെരുമാറ്റത്തിന് കാരണമാകുന്നു: `MaybeUninit<T>` ശരിക്കും ഒരു പ്രാരംഭ അവസ്ഥയിലാണെന്ന് ഉറപ്പ് നൽകേണ്ടത് കോളർ ആണ്.
    /// ഉദാഹരണത്തിന്, ഒരു `MaybeUninit` സമാരംഭിക്കുന്നതിന് `.assume_init_mut()` ഉപയോഗിക്കാൻ കഴിയില്ല.
    ///
    /// # Examples
    ///
    /// ### ഈ രീതിയുടെ ശരിയായ ഉപയോഗം:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// ഇൻപുട്ട് ബഫറിന്റെ *എല്ലാം* ബൈറ്റുകൾ സമാരംഭിക്കുന്നു.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // `buf` സമാരംഭിക്കുക:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // `buf` സമാരംഭിച്ചതായി ഇപ്പോൾ നമുക്കറിയാം, അതിനാൽ ഞങ്ങൾക്ക് ഇത് `.assume_init()` ചെയ്യാനാകും.
    /// // എന്നിരുന്നാലും, `.assume_init()` ഉപയോഗിക്കുന്നത് 2048 ബൈറ്റുകളുടെ `memcpy` പ്രവർത്തനക്ഷമമാക്കിയേക്കാം.
    /// // ഞങ്ങളുടെ ബഫർ പകർത്താതെ തന്നെ സമാരംഭിച്ചുവെന്ന് ഉറപ്പിക്കാൻ, ഞങ്ങൾ `&mut MaybeUninit<[u8; 2048]>` ഒരു `&mut [u8; 2048]` ലേക്ക് അപ്‌ഗ്രേഡുചെയ്യുന്നു:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // സുരക്ഷ: `buf` സമാരംഭിച്ചു.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // ഇപ്പോൾ നമുക്ക് ഒരു സാധാരണ സ്ലൈസായി `buf` ഉപയോഗിക്കാം:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### ഈ രീതിയുടെ *തെറ്റായ* ഉപയോഗങ്ങൾ‌:
    ///
    /// ഒരു മൂല്യം സമാരംഭിക്കുന്നതിന് നിങ്ങൾക്ക് `.assume_init_mut()` ഉപയോഗിക്കാൻ കഴിയില്ല:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // ആരംഭിക്കാത്ത `bool`-ലേക്ക് ഞങ്ങൾ ഒരു (mutable) റഫറൻസ് സൃഷ്ടിച്ചു!
    ///     // ഇത് നിർവചിക്കപ്പെടാത്ത സ്വഭാവമാണ്.⚠️
    /// }
    /// ```
    ///
    /// ഉദാഹരണത്തിന്, നിങ്ങൾക്ക് ആരംഭിക്കാത്ത ബഫറിലേക്ക് [`Read`] ചെയ്യാൻ കഴിയില്ല:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) ആരംഭിക്കാത്ത മെമ്മറിയിലേക്കുള്ള റഫറൻസ്!
    ///                             // ഇത് നിർവചിക്കപ്പെടാത്ത സ്വഭാവമാണ്.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// ഫീൽഡ്-ബൈ-ഫീൽഡ് ക്രമേണ സമാരംഭിക്കുന്നതിന് നിങ്ങൾക്ക് നേരിട്ടുള്ള ഫീൽഡ് ആക്സസ് ഉപയോഗിക്കാനും കഴിയില്ല:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) ആരംഭിക്കാത്ത മെമ്മറിയിലേക്കുള്ള റഫറൻസ്!
    ///                  // ഇത് നിർവചിക്കപ്പെടാത്ത സ്വഭാവമാണ്.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) ആരംഭിക്കാത്ത മെമ്മറിയിലേക്കുള്ള റഫറൻസ്!
    ///                  // ഇത് നിർവചിക്കപ്പെടാത്ത സ്വഭാവമാണ്.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): മേൽപ്പറഞ്ഞവ തെറ്റാണെന്ന് ഞങ്ങൾ നിലവിൽ ആശ്രയിക്കുന്നു, അതായത്, ആരംഭിക്കാത്ത ഡാറ്റയെക്കുറിച്ചുള്ള പരാമർശങ്ങൾ (ഉദാ. `libcore/fmt/float.rs`-ൽ).
    // സ്ഥിരീകരണത്തിന് മുമ്പ് നിയമങ്ങളെക്കുറിച്ച് അന്തിമ തീരുമാനം എടുക്കണം.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // സുരക്ഷ: `self` സമാരംഭിച്ചുവെന്ന് കോളർ ഉറപ്പ് നൽകണം.
        // `self` ഒരു `value` വേരിയന്റായിരിക്കണം എന്നും ഇതിനർത്ഥം.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// `MaybeUninit` കണ്ടെയ്‌നറുകളുടെ ഒരു നിരയിൽ നിന്ന് മൂല്യങ്ങൾ എക്‌സ്‌ട്രാക്റ്റുചെയ്യുന്നു.
    ///
    /// # Safety
    ///
    /// അറേയുടെ എല്ലാ ഘടകങ്ങളും ഒരു പ്രാരംഭ അവസ്ഥയിലാണെന്ന് ഉറപ്പുനൽകേണ്ടത് കോളർ ആണ്.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // സുരക്ഷ: ഞങ്ങൾ എല്ലാ ഘടകങ്ങളും സമാരംഭിച്ചതിനാൽ ഇപ്പോൾ സുരക്ഷിതമാണ്
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * അറേയുടെ എല്ലാ ഘടകങ്ങളും സമാരംഭിച്ചുവെന്ന് കോളർ ഉറപ്പുനൽകുന്നു
        // * `MaybeUninit<T>` ടിക്ക് ഒരേ ലേ .ട്ട് ഉണ്ടെന്ന് ഉറപ്പുനൽകുന്നു
        // * ഒരുപക്ഷേ യുണിന്റ് കുറയുന്നില്ല, അതിനാൽ ഇരട്ട-ഫ്രീകളില്ല, അതിനാൽ പരിവർത്തനം സുരക്ഷിതമാണ്
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// എല്ലാ ഘടകങ്ങളും സമാരംഭിച്ചുവെന്ന് കരുതുക, അവയിലേക്ക് ഒരു സ്ലൈസ് നേടുക.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` ഘടകങ്ങൾ ശരിക്കും ഒരു പ്രാരംഭ അവസ്ഥയിലാണെന്ന് ഉറപ്പുനൽകേണ്ടത് കോളർ ആണ്.
    ///
    /// ഉള്ളടക്കം ഇതുവരെ പൂർണ്ണമായി സമാരംഭിച്ചിട്ടില്ലാത്തപ്പോൾ ഇത് വിളിക്കുന്നത് നിർവചിക്കപ്പെടാത്ത സ്വഭാവത്തിന് കാരണമാകുന്നു.
    ///
    /// കൂടുതൽ വിശദാംശങ്ങൾക്കും ഉദാഹരണങ്ങൾക്കുമായി [`assume_init_ref`] കാണുക.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // സുരക്ഷ: വിളിക്കുന്നയാൾ ഉറപ്പുനൽകുന്നതിനാൽ `*const [T]`-ലേക്ക് സ്ലൈസ് കാസ്റ്റുചെയ്യുന്നത് സുരക്ഷിതമാണ്
        // `slice` സമാരംഭിച്ചു, ഒപ്പം `T`-ന് സമാനമായ ലേ layout ട്ട് ഉണ്ടെന്ന് `മെയ്ബ്യൂനിറ്റ്` ഉറപ്പുനൽകുന്നു.
        // ലഭിച്ച പോയിന്റർ `slice`-ന്റെ ഉടമസ്ഥതയിലുള്ള മെമ്മറിയെ സൂചിപ്പിക്കുന്നതിനാൽ സാധുവാണ്, അത് ഒരു റഫറൻസാണ്, അതിനാൽ ഇത് വായനയ്ക്ക് സാധുതയുള്ളതാണെന്ന് ഉറപ്പുനൽകുന്നു.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// എല്ലാ ഘടകങ്ങളും സമാരംഭിച്ചുവെന്ന് കരുതുക, അവയ്ക്ക് ഒരു മ്യൂട്ടബിൾ സ്ലൈസ് നേടുക.
    ///
    /// # Safety
    ///
    /// `MaybeUninit<T>` ഘടകങ്ങൾ ശരിക്കും ഒരു പ്രാരംഭ അവസ്ഥയിലാണെന്ന് ഉറപ്പുനൽകേണ്ടത് കോളർ ആണ്.
    ///
    /// ഉള്ളടക്കം ഇതുവരെ പൂർണ്ണമായി സമാരംഭിച്ചിട്ടില്ലാത്തപ്പോൾ ഇത് വിളിക്കുന്നത് നിർവചിക്കപ്പെടാത്ത സ്വഭാവത്തിന് കാരണമാകുന്നു.
    ///
    /// കൂടുതൽ വിശദാംശങ്ങൾക്കും ഉദാഹരണങ്ങൾക്കുമായി [`assume_init_mut`] കാണുക.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // സുരക്ഷ: `slice_get_ref`-നായുള്ള സുരക്ഷാ കുറിപ്പുകൾക്ക് സമാനമാണ്, പക്ഷേ ഞങ്ങൾക്ക് ഒരു
        // മ്യൂട്ടബിൾ റഫറൻസ്, ഇത് റൈറ്റുകൾക്ക് സാധുതയുള്ളതാണെന്ന് ഉറപ്പുനൽകുന്നു.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// അറേയുടെ ആദ്യ ഘടകത്തിലേക്ക് ഒരു പോയിന്റർ നേടുന്നു.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// അറേയുടെ ആദ്യ ഘടകത്തിലേക്ക് ഒരു മ്യൂട്ടബിൾ പോയിന്റർ നേടുന്നു.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// `src` മുതൽ `this` വരെയുള്ള ഘടകങ്ങൾ‌പകർ‌ത്തുന്നു, ഇപ്പോൾ‌`this` ന്റെ നിഷ്ക്രിയമാക്കിയ ഉള്ളടക്കങ്ങളിലേക്ക് ഒരു മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു.
    ///
    /// `T` `Copy` നടപ്പിലാക്കുന്നില്ലെങ്കിൽ, [`write_slice_cloned`] ഉപയോഗിക്കുക
    ///
    /// ഇത് [`slice::copy_from_slice`]-ന് സമാനമാണ്.
    ///
    /// # Panics
    ///
    /// രണ്ട് സ്ലൈസുകൾക്ക് വ്യത്യസ്ത നീളമുണ്ടെങ്കിൽ ഈ ഫംഗ്ഷൻ panic ആയിരിക്കും.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // സുരക്ഷ: ലെനിന്റെ എല്ലാ ഘടകങ്ങളും ഞങ്ങൾ സ്പെയർ കപ്പാസിറ്റിയിലേക്ക് പകർത്തി
    /// // വെക്കിന്റെ ആദ്യ src.len() ഘടകങ്ങൾ ഇപ്പോൾ സാധുവാണ്.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // സുരക്ഷ: &[ടി] കൂടാതെ&[ഒരുപക്ഷേ യുനിനിറ്റ്<T>] ന് സമാന ലേ .ട്ട് ഉണ്ട്
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // സുരക്ഷ: സാധുവായ ഘടകങ്ങൾ `this`-ലേക്ക് പകർത്തിയതിനാൽ അത് നിർജ്ജീവമാക്കി
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// `src` മുതൽ `this` വരെയുള്ള ഘടകങ്ങളെ ക്ലോൺ ചെയ്യുന്നു, ഇപ്പോൾ `this`-ന്റെ നിഷ്ക്രിയമാക്കിയ ഉള്ളടക്കങ്ങളിലേക്ക് ഒരു മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു.
    /// ഇതിനകം നിർജ്ജീവമാക്കിയ ഏതെങ്കിലും ഘടകങ്ങൾ ഉപേക്ഷിക്കില്ല.
    ///
    /// `T` `Copy` നടപ്പിലാക്കുകയാണെങ്കിൽ, [`write_slice`] ഉപയോഗിക്കുക
    ///
    /// ഇത് [`slice::clone_from_slice`]-ന് സമാനമാണെങ്കിലും നിലവിലുള്ള ഘടകങ്ങൾ ഉപേക്ഷിക്കുന്നില്ല.
    ///
    /// # Panics
    ///
    /// രണ്ട് സ്ലൈസുകൾക്ക് വ്യത്യസ്ത നീളമുണ്ടെങ്കിൽ അല്ലെങ്കിൽ `Clone` panics നടപ്പിലാക്കുകയാണെങ്കിൽ ഈ പ്രവർത്തനം panic ആയിരിക്കും.
    ///
    /// ഒരു panic ഉണ്ടെങ്കിൽ, ഇതിനകം ക്ലോൺ ചെയ്ത ഘടകങ്ങൾ ഉപേക്ഷിക്കപ്പെടും.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // സുരക്ഷ: ലെനിന്റെ എല്ലാ ഘടകങ്ങളും ഞങ്ങൾ സ്പെയർ കപ്പാസിറ്റിയിലേക്ക് ക്ലോൺ ചെയ്തു
    /// // വെക്കിന്റെ ആദ്യ src.len() ഘടകങ്ങൾ ഇപ്പോൾ സാധുവാണ്.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // Copy_from_slice ൽ നിന്ന് വ്യത്യസ്തമായി ഇത് സ്ലൈസിലെ ക്ലോൺ_ഫ്രോം_സ്ലൈസിനെ വിളിക്കില്ല, കാരണം `MaybeUninit<T: Clone>` ക്ലോൺ നടപ്പിലാക്കുന്നില്ല.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // സുരക്ഷ: ഈ അസംസ്കൃത സ്ലൈസിൽ സമാരംഭിച്ച ഒബ്‌ജക്റ്റുകൾ മാത്രമേ അടങ്ങിയിട്ടുള്ളൂ
                // അതുകൊണ്ടാണ്, ഇത് ഉപേക്ഷിക്കാൻ അനുവദിച്ചിരിക്കുന്നത്.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: ഒരേ നീളത്തിൽ‌ഞങ്ങൾ‌അവ വ്യക്തമായി മുറിക്കേണ്ടതുണ്ട്
        // അതിർത്തി പരിശോധന ഒഴിവാക്കുന്നതിനായി, ഒപ്റ്റിമൈസർ ലളിതമായ കേസുകൾക്കായി മെംക്പി സൃഷ്ടിക്കും (ഉദാഹരണത്തിന് T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // ഗാർഡ് ആവശ്യമാണ് b/c panic ഒരു ക്ലോൺ സമയത്ത് സംഭവിക്കാം
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // സുരക്ഷ: സാധുവായ ഘടകങ്ങൾ `this`-ലേക്ക് എഴുതിയതിനാൽ അത് നിർജ്ജീവമാക്കി
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}