//! അറേകൾക്കായി `IntoIter` ഉടമസ്ഥതയിലുള്ള ഇറ്ററേറ്റർ നിർവചിക്കുന്നു.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// ഒരു ബൈ-വാല്യു [array] ഇറ്ററേറ്റർ.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// ഇതാണ് ഞങ്ങൾ ആവർത്തിക്കുന്ന ശ്രേണി.
    ///
    /// `alive.start <= i < alive.end` സൂചിക `i` ഉള്ള ഘടകങ്ങൾ ഇതുവരെ നൽകിയിട്ടില്ല, അവ സാധുവായ അറേ എൻ‌ട്രികളാണ്.
    /// `i < alive.start` അല്ലെങ്കിൽ `i >= alive.end` സൂചികകളുള്ള ഘടകങ്ങൾ ഇതിനകം തന്നെ നൽകിയിട്ടുണ്ട്, ഇനി ആക്സസ് ചെയ്യാൻ പാടില്ല!ആ നിർജ്ജീവ ഘടകങ്ങൾ പൂർണ്ണമായും ആരംഭിക്കാത്ത അവസ്ഥയിലായിരിക്കാം!
    ///
    ///
    /// അതിനാൽ മാറ്റങ്ങളാണിവ:
    /// - `data[alive]` സജീവമാണ് (അതായത് സാധുവായ ഘടകങ്ങൾ അടങ്ങിയിരിക്കുന്നു)
    /// - `data[..alive.start]` ഒപ്പം `data[alive.end..]` മരിച്ചു (അതായത് ഘടകങ്ങൾ ഇതിനകം വായിച്ചിട്ടുണ്ട്, ഇനി തൊടരുത്!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// `data`-ലെ ഘടകങ്ങൾ ഇതുവരെ നൽകിയിട്ടില്ല.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// തന്നിരിക്കുന്ന `array`-ൽ ഒരു പുതിയ ഇറ്ററേറ്റർ സൃഷ്ടിക്കുന്നു.
    ///
    /// *കുറിപ്പ്*: ഈ രീതി [`IntoIterator` is implemented for arrays][array-into-iter] ന് ശേഷം future ൽ ഒഴിവാക്കാം.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // `&i32` എന്നതിനുപകരം ഇവിടെ `i32` ആണ് `value` തരം
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // സുരക്ഷ: ഇവിടെയുള്ള ട്രാൻസ്മിറ്റ് യഥാർത്ഥത്തിൽ സുരക്ഷിതമാണ്.`MaybeUninit`-ന്റെ ഡോക്സ്
        // promise:
        //
        // > `MaybeUninit<T>` ഒരേ വലുപ്പവും വിന്യാസവും ഉണ്ടെന്ന് ഉറപ്പുനൽകുന്നു
        // > `T` ആയി.
        //
        // ഡോക്സ് `MaybeUninit<T>` ന്റെ ഒരു അറേയിൽ നിന്ന് `T` ന്റെ ഒരു അറേയിലേക്ക് ഒരു ട്രാൻസ്മിറ്റ് പോലും കാണിക്കുന്നു.
        //
        //
        // അതോടെ, ഈ സമാരംഭം മാറ്റങ്ങളെ തൃപ്തിപ്പെടുത്തുന്നു.

        // FIXME(LukasKalbertodt): കോൺസ്റ്റ് ജനറിക്സുമായി പ്രവർത്തിച്ചുകഴിഞ്ഞാൽ യഥാർത്ഥത്തിൽ ഇവിടെ `mem::transmute` ഉപയോഗിക്കുക:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // അതുവരെ, മറ്റൊരു തരമായി ഒരു ബിറ്റ്വൈസ് കോപ്പി സൃഷ്ടിക്കാൻ ഞങ്ങൾക്ക് `mem::transmute_copy` ഉപയോഗിക്കാം, തുടർന്ന് `array` മറക്കുക, അങ്ങനെ അത് ഉപേക്ഷിക്കരുത്.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// ഇതുവരെ നൽകിയിട്ടില്ലാത്ത എല്ലാ ഘടകങ്ങളുടെയും മാറ്റമില്ലാത്ത ഒരു സ്ലൈസ് നൽകുന്നു.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // സുരക്ഷ: `alive`-ലെ എല്ലാ ഘടകങ്ങളും ശരിയായി സമാരംഭിച്ചതായി ഞങ്ങൾക്കറിയാം.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// ഇതുവരെ നൽകിയിട്ടില്ലാത്ത എല്ലാ ഘടകങ്ങളുടെയും മ്യൂട്ടബിൾ സ്ലൈസ് നൽകുന്നു.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // സുരക്ഷ: `alive`-ലെ എല്ലാ ഘടകങ്ങളും ശരിയായി സമാരംഭിച്ചതായി ഞങ്ങൾക്കറിയാം.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // മുന്നിൽ നിന്ന് അടുത്ത സൂചിക നേടുക.
        //
        // `alive.start` 1 വർദ്ധിപ്പിക്കുന്നത് `alive` സംബന്ധിച്ച മാറ്റത്തെ നിലനിർത്തുന്നു.
        // എന്നിരുന്നാലും, ഈ മാറ്റം കാരണം, ഒരു ഹ്രസ്വ സമയത്തേക്ക്, സജീവമായ മേഖല ഇനി `data[alive]` അല്ല, `data[idx..alive.end]` ആണ്.
        //
        self.alive.next().map(|idx| {
            // അറേയിൽ നിന്നുള്ള ഘടകം വായിക്കുക.
            // സുരക്ഷ: എക്സ് 00 എക്സ് എന്നത് മുൻ എക്സ് 01 എക്സ് മേഖലയിലേക്കുള്ള ഒരു സൂചികയാണ്
            // അറേ.ഈ ഘടകം വായിക്കുന്നതിലൂടെ `data[idx]` ഇപ്പോൾ മരിച്ചതായി കണക്കാക്കപ്പെടുന്നു (അതായത് തൊടരുത്).
            // `idx` ലൈവ് സോണിന്റെ തുടക്കമായതിനാൽ, സജീവമായ സോൺ ഇപ്പോൾ വീണ്ടും `data[alive]` ആണ്, ഇത് എല്ലാ മാറ്റങ്ങളും പുന oring സ്ഥാപിക്കുന്നു.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // പിന്നിൽ നിന്ന് അടുത്ത സൂചിക നേടുക.
        //
        // `alive.end` 1 കുറയ്‌ക്കുന്നത് `alive`-നെക്കുറിച്ചുള്ള മാറ്റത്തെ നിലനിർത്തുന്നു.
        // എന്നിരുന്നാലും, ഈ മാറ്റം കാരണം, ഒരു ഹ്രസ്വ സമയത്തേക്ക്, സജീവമായ മേഖല ഇനി `data[alive]` അല്ല, `data[alive.start..=idx]` ആണ്.
        //
        self.alive.next_back().map(|idx| {
            // അറേയിൽ നിന്നുള്ള ഘടകം വായിക്കുക.
            // സുരക്ഷ: എക്സ് 00 എക്സ് എന്നത് മുൻ എക്സ് 01 എക്സ് മേഖലയിലേക്കുള്ള ഒരു സൂചികയാണ്
            // അറേ.ഈ ഘടകം വായിക്കുന്നതിലൂടെ `data[idx]` ഇപ്പോൾ മരിച്ചതായി കണക്കാക്കപ്പെടുന്നു (അതായത് തൊടരുത്).
            // `idx` ലൈവ് സോണിന്റെ അവസാനമായതിനാൽ, സജീവമായ സോൺ ഇപ്പോൾ വീണ്ടും `data[alive]` ആണ്, ഇത് എല്ലാ മാറ്റങ്ങളും പുന oring സ്ഥാപിക്കുന്നു.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // സുരക്ഷ: ഇത് സുരക്ഷിതമാണ്: `as_mut_slice` കൃത്യമായി ഉപ-സ്ലൈസ് നൽകുന്നു
        // ഇതുവരെ നീക്കിയിട്ടില്ലാത്തതും ഉപേക്ഷിക്കപ്പെടാത്തതുമായ ഘടകങ്ങളുടെ.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // അസാധാരണമായ `ജീവനോടെയുള്ളതിനാൽ ഒരിക്കലും ഒഴുകില്ല. സ്റ്റാർട്ട് <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// ആവർത്തനം ശരിയായ ദൈർഘ്യം റിപ്പോർട്ടുചെയ്യുന്നു.
// "alive" മൂലകങ്ങളുടെ എണ്ണം (അത് ഇപ്പോഴും ലഭിക്കും) `alive` ശ്രേണിയുടെ ദൈർഘ്യമാണ്.
// ഈ ശ്രേണിയുടെ ദൈർഘ്യം `next` അല്ലെങ്കിൽ `next_back` ൽ കുറയുന്നു.
// ആ രീതികളിൽ ഇത് എല്ലായ്പ്പോഴും 1 കുറയുന്നു, പക്ഷേ `Some(_)` തിരികെ നൽകിയാൽ മാത്രം.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // ശ്രദ്ധിക്കുക, കൃത്യമായ അതേ ജീവനുള്ള ശ്രേണിയുമായി പൊരുത്തപ്പെടേണ്ട ആവശ്യമില്ല, അതിനാൽ `self` എവിടെയാണെങ്കിലും നമുക്ക് ഓഫ്‌സെറ്റ് 0 ലേക്ക് ക്ലോൺ ചെയ്യാൻ കഴിയും.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // സജീവമായ എല്ലാ ഘടകങ്ങളും ക്ലോൺ ചെയ്യുക.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // പുതിയ അറേയിലേക്ക് ഒരു ക്ലോൺ എഴുതുക, തുടർന്ന് അതിന്റെ സജീവമായ ശ്രേണി അപ്‌ഡേറ്റുചെയ്യുക.
            // panics ക്ലോൺ ചെയ്യുകയാണെങ്കിൽ, ഞങ്ങൾ മുമ്പത്തെ ഇനങ്ങൾ ശരിയായി ഉപേക്ഷിക്കും.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // ഇതുവരെ നൽകാത്ത ഘടകങ്ങൾ മാത്രം പ്രിന്റുചെയ്യുക: ഞങ്ങൾക്ക് ലഭിച്ച ഘടകങ്ങൾ ഇനി ആക്‌സസ് ചെയ്യാൻ കഴിയില്ല.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}