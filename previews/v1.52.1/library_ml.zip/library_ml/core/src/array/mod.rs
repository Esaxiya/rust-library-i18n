//! നിശ്ചിത ദൈർഘ്യമുള്ള അറേകൾക്കായി `Eq` പോലുള്ള കാര്യങ്ങളുടെ നടപ്പാക്കൽ.
//! ക്രമേണ, എല്ലാ നീളത്തിലും സാമാന്യവൽക്കരിക്കാൻ ഞങ്ങൾക്ക് കഴിയണം.
//!
//! *[See also the array primitive type](array).*
//!

#![stable(feature = "core_array", since = "1.36.0")]

use crate::borrow::{Borrow, BorrowMut};
use crate::cmp::Ordering;
use crate::convert::{Infallible, TryFrom};
use crate::fmt;
use crate::hash::{self, Hash};
use crate::iter::TrustedLen;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{Index, IndexMut};
use crate::slice::{Iter, IterMut};

mod iter;

#[stable(feature = "array_value_iter", since = "1.51.0")]
pub use iter::IntoIter;

/// `T`-ലേക്ക് ഒരു റഫറൻസ് നീളം 1 എന്ന ശ്രേണിയുടെ റഫറൻസായി പരിവർത്തനം ചെയ്യുന്നു (പകർത്താതെ).
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_ref<T>(s: &T) -> &[T; 1] {
    // സുരക്ഷ: `&T` നെ `&[T; 1]` ലേക്ക് പരിവർത്തനം ചെയ്യുന്നത് ശബ്‌ദമാണ്.
    unsafe { &*(s as *const T).cast::<[T; 1]>() }
}

/// `T`-ലേക്ക് ഒരു മ്യൂട്ടബിൾ റഫറൻസിനെ 1 ശ്രേണിയിലെ ഒരു പകർപ്പിലേക്ക് പരിവർത്തനം ചെയ്യാവുന്ന റഫറൻസായി പരിവർത്തനം ചെയ്യുന്നു (പകർത്താതെ).
#[unstable(feature = "array_from_ref", issue = "77101")]
pub fn from_mut<T>(s: &mut T) -> &mut [T; 1] {
    // സുരക്ഷ: `&mut T` നെ `&mut [T; 1]` ലേക്ക് പരിവർത്തനം ചെയ്യുന്നത് ശബ്‌ദമാണ്.
    unsafe { &mut *(s as *mut T).cast::<[T; 1]>() }
}

/// നിശ്ചിത വലുപ്പത്തിലുള്ള അറേകളിൽ മാത്രം യൂട്ടിലിറ്റി trait നടപ്പിലാക്കി
///
/// കൂടുതൽ മെറ്റാഡാറ്റ വീക്കം ഉണ്ടാക്കാതെ നിശ്ചിത വലുപ്പത്തിലുള്ള അറേകളിൽ മറ്റ് traits നടപ്പിലാക്കാൻ ഈ trait ഉപയോഗിക്കാം.
///
/// നിശ്ചിത വലുപ്പത്തിലുള്ള അറേകളിലേക്ക് നടപ്പിലാക്കുന്നവരെ നിയന്ത്രിക്കുന്നതിന് trait സുരക്ഷിതമല്ലെന്ന് അടയാളപ്പെടുത്തി.
/// ഈ trait ന്റെ ഒരു ഉപയോക്താവിന് ഒരു നിശ്ചിത വലുപ്പ അറേയുടെ മെമ്മറിയിൽ നടപ്പിലാക്കുന്നവർക്ക് കൃത്യമായ ലേ layout ട്ട് ഉണ്ടെന്ന് അനുമാനിക്കാം (ഉദാഹരണത്തിന്, സുരക്ഷിതമല്ലാത്ത സമാരംഭത്തിനായി).
///
///
/// നിശ്ചിത വലുപ്പത്തിലുള്ള അറേകളല്ലാത്ത തരങ്ങൾക്ക് traits [`AsRef`], [`AsMut`] എന്നിവ സമാന രീതികൾ നൽകുന്നുവെന്നത് ശ്രദ്ധിക്കുക.
/// നടപ്പിലാക്കുന്നവർ പകരം traits തിരഞ്ഞെടുക്കുക.
///
///
///
#[unstable(feature = "fixed_size_array", issue = "27778")]
pub unsafe trait FixedSizeArray<T> {
    /// നിരയെ മാറ്റമില്ലാത്ത സ്ലൈസിലേക്ക് പരിവർത്തനം ചെയ്യുന്നു
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_slice(&self) -> &[T];
    /// അറേയെ മ്യൂട്ടബിൾ സ്ലൈസിലേക്ക് പരിവർത്തനം ചെയ്യുന്നു
    #[unstable(feature = "fixed_size_array", issue = "27778")]
    fn as_mut_slice(&mut self) -> &mut [T];
}

#[unstable(feature = "fixed_size_array", issue = "27778")]
unsafe impl<T, A: Unsize<[T]>> FixedSizeArray<T> for A {
    #[inline]
    fn as_slice(&self) -> &[T] {
        self
    }
    #[inline]
    fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }
}

/// ഒരു സ്ലൈസിൽ നിന്ന് ഒരു അറേയിലേക്കുള്ള പരിവർത്തനം പരാജയപ്പെടുമ്പോൾ പിശക് തരം മടങ്ങി.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone)]
pub struct TryFromSliceError(());

#[stable(feature = "core_array", since = "1.36.0")]
impl fmt::Display for TryFromSliceError {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(self.__description(), f)
    }
}

impl TryFromSliceError {
    #[unstable(
        feature = "array_error_internals",
        reason = "available through Error trait and this method should not \
                     be exposed publicly",
        issue = "none"
    )]
    #[inline]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "could not convert slice to array"
    }
}

#[stable(feature = "try_from_slice_error", since = "1.36.0")]
impl From<Infallible> for TryFromSliceError {
    fn from(x: Infallible) -> TryFromSliceError {
        match x {}
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsRef<[T]> for [T; N] {
    #[inline]
    fn as_ref(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, const N: usize> AsMut<[T]> for [T; N] {
    #[inline]
    fn as_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> Borrow<[T]> for [T; N] {
    fn borrow(&self) -> &[T] {
        self
    }
}

#[stable(feature = "array_borrow", since = "1.4.0")]
impl<T, const N: usize> BorrowMut<[T]> for [T; N] {
    fn borrow_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<T, const N: usize> TryFrom<&[T]> for [T; N]
where
    T: Copy,
{
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<[T; N], TryFromSliceError> {
        <&Self>::try_from(slice).map(|r| *r)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a [T]> for &'a [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &[T]) -> Result<&[T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_ptr() as *const [T; N];
            // സുരക്ഷ: ശരി, കാരണം നീളം യോജിക്കുന്നുണ്ടോയെന്ന് ഞങ്ങൾ പരിശോധിച്ചു
            unsafe { Ok(&*ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl<'a, T, const N: usize> TryFrom<&'a mut [T]> for &'a mut [T; N] {
    type Error = TryFromSliceError;

    fn try_from(slice: &mut [T]) -> Result<&mut [T; N], TryFromSliceError> {
        if slice.len() == N {
            let ptr = slice.as_mut_ptr() as *mut [T; N];
            // സുരക്ഷ: ശരി, കാരണം നീളം യോജിക്കുന്നുണ്ടോയെന്ന് ഞങ്ങൾ പരിശോധിച്ചു
            unsafe { Ok(&mut *ptr) }
        } else {
            Err(TryFromSliceError(()))
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, const N: usize> Hash for [T; N] {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        Hash::hash(&self[..], state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for [T; N] {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&&self[..], f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a [T; N] {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, const N: usize> IntoIterator for &'a mut [T; N] {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> Index<I> for [T; N]
where
    [T]: Index<I>,
{
    type Output = <[T] as Index<I>>::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(self as &[T], index)
    }
}

#[stable(feature = "index_trait_on_arrays", since = "1.50.0")]
impl<T, I, const N: usize> IndexMut<I> for [T; N]
where
    [T]: IndexMut<I>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(self as &mut [T], index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B; N]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&[B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&[B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&[B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &[B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<&mut [B]> for [A; N]
where
    A: PartialEq<B>,
{
    #[inline]
    fn eq(&self, other: &&mut [B]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &&mut [B]) -> bool {
        self[..] != other[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A, B, const N: usize> PartialEq<[A; N]> for &mut [B]
where
    B: PartialEq<A>,
{
    #[inline]
    fn eq(&self, other: &[A; N]) -> bool {
        self[..] == other[..]
    }
    #[inline]
    fn ne(&self, other: &[A; N]) -> bool {
        self[..] != other[..]
    }
}

// NOTE: കോഡ് ഫ്ലോട്ട് കുറയ്ക്കുന്നതിന് കുറച്ച് പ്രാധാന്യമില്ലാത്ത ഇം‌പ്ലുകൾ‌ഒഴിവാക്കി
// __impl_slice_eq2!{ [A; $N], &'b [B; $N] } __impl_slice_eq2! { [A; $N], &'b mut [B; $N] }
//

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, const N: usize> Eq for [T; N] {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, const N: usize> PartialOrd for [T; N] {
    #[inline]
    fn partial_cmp(&self, other: &[T; N]) -> Option<Ordering> {
        PartialOrd::partial_cmp(&&self[..], &&other[..])
    }
    #[inline]
    fn lt(&self, other: &[T; N]) -> bool {
        PartialOrd::lt(&&self[..], &&other[..])
    }
    #[inline]
    fn le(&self, other: &[T; N]) -> bool {
        PartialOrd::le(&&self[..], &&other[..])
    }
    #[inline]
    fn ge(&self, other: &[T; N]) -> bool {
        PartialOrd::ge(&&self[..], &&other[..])
    }
    #[inline]
    fn gt(&self, other: &[T; N]) -> bool {
        PartialOrd::gt(&&self[..], &&other[..])
    }
}

/// [lexicographically](Ord#lexicographical-comparison) അറേകളുടെ താരതമ്യം നടപ്പിലാക്കുന്നു.
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, const N: usize> Ord for [T; N] {
    #[inline]
    fn cmp(&self, other: &[T; N]) -> Ordering {
        Ord::cmp(&&self[..], &&other[..])
    }
}

// സ്ഥിരസ്ഥിതി ഇം‌പ്ളുകൾ‌കോൺ‌സ്റ്റെർ‌ജനറിക്സ് ഉപയോഗിച്ച് ചെയ്യാൻ‌കഴിയില്ല, കാരണം `[T; 0]` ന് സ്ഥിരസ്ഥിതി നടപ്പിലാക്കാൻ‌ആവശ്യമില്ല, മാത്രമല്ല വ്യത്യസ്ത സംഖ്യകൾ‌ക്കായി വ്യത്യസ്ത ഇം‌പ്ലോക്ക് ബ്ലോക്കുകൾ‌ഇതുവരെ പിന്തുണയ്‌ക്കുന്നില്ല.
//
//

macro_rules! array_impl_default {
    {$n:expr, $t:ident $($ts:ident)*} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] where T: Default {
            fn default() -> [T; $n] {
                [$t::default(), $($ts::default()),*]
            }
        }
        array_impl_default!{($n - 1), $($ts)*}
    };
    {$n:expr,} => {
        #[stable(since = "1.4.0", feature = "array_default")]
        impl<T> Default for [T; $n] {
            fn default() -> [T; $n] { [] }
        }
    };
}

array_impl_default! {32, T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T T}

#[lang = "array"]
impl<T, const N: usize> [T; N] {
    /// ഓരോ ഘടകത്തിനും ക്രമത്തിൽ `f` ഫംഗ്ഷൻ ഉപയോഗിച്ച് `self`-ന് സമാനമായ വലുപ്പമുള്ള ഒരു ശ്രേണി നൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_map)]
    /// let x = [1, 2, 3];
    /// let y = x.map(|v| v + 1);
    /// assert_eq!(y, [2, 3, 4]);
    ///
    /// let x = [1, 2, 3];
    /// let mut temp = 0;
    /// let y = x.map(|v| { temp += 1; v * temp });
    /// assert_eq!(y, [1, 4, 9]);
    ///
    /// let x = ["Ferris", "Bueller's", "Day", "Off"];
    /// let y = x.map(|v| v.len());
    /// assert_eq!(y, [6, 9, 3, 3]);
    /// ```
    #[unstable(feature = "array_map", issue = "75243")]
    pub fn map<F, U>(self, f: F) -> [U; N]
    where
        F: FnMut(T) -> U,
    {
        // സുരക്ഷ: ഈ ഇറ്ററേറ്റർ കൃത്യമായി `N` നൽകുമെന്ന് ഞങ്ങൾക്കറിയാം
        // items.
        unsafe { collect_into_array_unchecked(&mut IntoIter::new(self).map(f)) }
    }

    /// ഒരു ജോഡി ജോഡികളായി രണ്ട് അറേകൾ 'സിപ്‌സ് അപ്പ്' ചെയ്യുക.
    ///
    /// `zip()` ഒരു പുതിയ അറേ നൽകുന്നു, അവിടെ എല്ലാ ഘടകങ്ങളും ഒരു ട്യൂപ്പിൾ ആണ്, അവിടെ ആദ്യ ഘടകം ആദ്യ അറേയിൽ നിന്ന് വരുന്നു, രണ്ടാമത്തെ ഘടകം രണ്ടാമത്തെ അറേയിൽ നിന്ന് വരുന്നു.
    ///
    /// മറ്റൊരു വിധത്തിൽ പറഞ്ഞാൽ, ഇത് രണ്ട് അറേകളെ ഒരുമിച്ച് ഒന്നായി സിപ്പ് ചെയ്യുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_zip)]
    /// let x = [1, 2, 3];
    /// let y = [4, 5, 6];
    /// let z = x.zip(y);
    /// assert_eq!(z, [(1, 4), (2, 5), (3, 6)]);
    /// ```
    ///
    #[unstable(feature = "array_zip", issue = "80094")]
    pub fn zip<U>(self, rhs: [U; N]) -> [(T, U); N] {
        let mut iter = IntoIter::new(self).zip(IntoIter::new(rhs));

        // സുരക്ഷ: ഈ ഇറ്ററേറ്റർ കൃത്യമായി `N` നൽകുമെന്ന് ഞങ്ങൾക്കറിയാം
        // items.
        unsafe { collect_into_array_unchecked(&mut iter) }
    }

    /// മുഴുവൻ അറേയും അടങ്ങിയ ഒരു സ്ലൈസ് നൽകുന്നു.`&s[..]`-ന് തുല്യമാണ്.
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// മുഴുവൻ അറേയും അടങ്ങിയ മ്യൂട്ടബിൾ സ്ലൈസ് നൽകുന്നു.
    /// `&mut s[..]`-ന് തുല്യമാണ്.
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// ഓരോ ഘടകങ്ങളും കടമെടുത്ത് `self`-ന് സമാനമായ വലുപ്പമുള്ള ഒരു കൂട്ടം റഫറൻസുകൾ നൽകുന്നു.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&f64; 3] = floats.each_ref();
    /// assert_eq!(float_refs, [&3.1, &2.7, &-1.0]);
    /// ```
    ///
    /// [`map`](#method.map) പോലുള്ള മറ്റ് രീതികളുമായി സംയോജിപ്പിച്ചാൽ ഈ രീതി പ്രത്യേകിച്ചും ഉപയോഗപ്രദമാണ്.
    /// ഇതുവഴി, യഥാർത്ഥ അറേയുടെ ഘടകങ്ങൾ `Copy` അല്ലെങ്കിൽ നിങ്ങൾക്ക് അത് നീക്കുന്നത് ഒഴിവാക്കാം.
    ///
    /// ```
    /// #![feature(array_methods, array_map)]
    ///
    /// let strings = ["Ferris".to_string(), "♥".to_string(), "Rust".to_string()];
    /// let is_ascii = strings.each_ref().map(|s| s.is_ascii());
    /// assert_eq!(is_ascii, [true, false, true]);
    ///
    /// // ഞങ്ങൾക്ക് ഇപ്പോഴും യഥാർത്ഥ അറേയിലേക്ക് പ്രവേശിക്കാൻ കഴിയും: ഇത് നീക്കിയിട്ടില്ല.
    /// assert_eq!(strings.len(), 3);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_ref(&self) -> [&T; N] {
        // സുരക്ഷ: ഈ ഇറ്ററേറ്റർ കൃത്യമായി `N` നൽകുമെന്ന് ഞങ്ങൾക്കറിയാം
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter()) }
    }

    /// ഓരോ ഘടകങ്ങളും പരസ്പരം കടമെടുക്കുകയും `self`-ന് സമാനമായ വലുപ്പമുള്ള മ്യൂട്ടബിൾ റഫറൻസുകളുടെ ഒരു നിര നൽകുകയും ചെയ്യുന്നു.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(array_methods)]
    ///
    /// let mut floats = [3.1, 2.7, -1.0];
    /// let float_refs: [&mut f64; 3] = floats.each_mut();
    /// *float_refs[0] = 0.0;
    /// assert_eq!(float_refs, [&mut 0.0, &mut 2.7, &mut -1.0]);
    /// assert_eq!(floats, [0.0, 2.7, -1.0]);
    /// ```
    ///
    #[unstable(feature = "array_methods", issue = "76118")]
    pub fn each_mut(&mut self) -> [&mut T; N] {
        // സുരക്ഷ: ഈ ഇറ്ററേറ്റർ കൃത്യമായി `N` നൽകുമെന്ന് ഞങ്ങൾക്കറിയാം
        // items.
        unsafe { collect_into_array_unchecked(&mut self.iter_mut()) }
    }
}

/// `iter`-ൽ നിന്ന് `N` ഇനങ്ങൾ വലിച്ചിട്ട് ഒരു അറേയായി നൽകുന്നു.
/// ആവർത്തനം `N` ഇനങ്ങളിൽ കുറവാണെങ്കിൽ, ഈ പ്രവർത്തനം നിർവചിക്കപ്പെടാത്ത സ്വഭാവം കാണിക്കുന്നു.
///
///
/// കൂടുതൽ വിവരങ്ങൾക്ക് [`collect_into_array`] കാണുക.
///
/// # Safety
///
/// `iter` കുറഞ്ഞത് `N` ഇനങ്ങളെങ്കിലും നൽകുന്നുവെന്ന് ഉറപ്പുനൽകേണ്ടത് കോളർ ആണ്.
/// ഈ അവസ്ഥ ലംഘിക്കുന്നത് നിർവചിക്കപ്പെടാത്ത പെരുമാറ്റത്തിന് കാരണമാകുന്നു.
unsafe fn collect_into_array_unchecked<I, const N: usize>(iter: &mut I) -> [I::Item; N]
where
    // Note: ഇവിടെ `TrustedLen` ഒരു പരിധിവരെ പരീക്ഷണമാണ്.ഇത് ഒരു
    // ആന്തരിക പ്രവർത്തനം, അതിനാൽ ഈ പരിധി ഒരു മോശം ആശയമായി മാറുകയാണെങ്കിൽ നീക്കംചെയ്യാൻ മടിക്കേണ്ട.
    // അത്തരം സാഹചര്യത്തിൽ, താഴെയുള്ള ബ bound ണ്ട് `debug_assert!` നീക്കംചെയ്യാനും ഓർമ്മിക്കുക!
    //
    I: Iterator + TrustedLen,
{
    debug_assert!(N <= iter.size_hint().1.unwrap_or(usize::MAX));
    debug_assert!(N <= iter.size_hint().0);

    match collect_into_array(iter) {
        Some(array) => array,
        // സുരക്ഷ: ഫംഗ്ഷൻ കരാറിന്റെ പരിധിയിൽ വരും.
        None => unsafe { crate::hint::unreachable_unchecked() },
    }
}

/// `iter`-ൽ നിന്ന് `N` ഇനങ്ങൾ വലിച്ചിട്ട് ഒരു അറേയായി നൽകുന്നു.ആവർത്തനം `N` ഇനങ്ങളിൽ കുറവാണെങ്കിൽ, `None` മടക്കിനൽകുകയും ഇതിനകം ലഭിച്ച എല്ലാ ഇനങ്ങളും ഉപേക്ഷിക്കുകയും ചെയ്യുന്നു.
///
/// ഇറ്ററേറ്റർ ഒരു മ്യൂട്ടബിൾ റഫറൻസായി കൈമാറുകയും ഈ ഫംഗ്ഷൻ `next` നെ ഏറ്റവും കൂടുതൽ `N` തവണ വിളിക്കുകയും ചെയ്യുന്നതിനാൽ, ശേഷിക്കുന്ന ഇനങ്ങൾ വീണ്ടെടുക്കുന്നതിന് ഇറ്ററേറ്റർ തുടർന്നും ഉപയോഗിക്കാം.
///
///
/// `iter.next()` പരിഭ്രാന്തിയിലാണെങ്കിൽ, ഇറ്ററേറ്റർ ഇതിനകം നൽകിയ എല്ലാ ഇനങ്ങളും ഉപേക്ഷിച്ചു.
///
///
///
///
fn collect_into_array<I, const N: usize>(iter: &mut I) -> Option<[I::Item; N]>
where
    I: Iterator,
{
    if N == 0 {
        // സുരക്ഷ: ഒരു ശൂന്യ അറേ എല്ലായ്‌പ്പോഴും വസിക്കുന്നു, മാത്രമല്ല സാധുതയുള്ള മാറ്റങ്ങളില്ല.
        return unsafe { Some(mem::zeroed()) };
    }

    struct Guard<T, const N: usize> {
        ptr: *mut T,
        initialized: usize,
    }

    impl<T, const N: usize> Drop for Guard<T, N> {
        fn drop(&mut self) {
            debug_assert!(self.initialized <= N);

            let initialized_part = crate::ptr::slice_from_raw_parts_mut(self.ptr, self.initialized);

            // സുരക്ഷ: ഈ അസംസ്കൃത സ്ലൈസിൽ സമാരംഭിച്ച ഒബ്‌ജക്റ്റുകൾ മാത്രമേ അടങ്ങിയിട്ടുള്ളൂ.
            unsafe {
                crate::ptr::drop_in_place(initialized_part);
            }
        }
    }

    let mut array = MaybeUninit::uninit_array::<N>();
    let mut guard: Guard<_, N> =
        Guard { ptr: MaybeUninit::slice_as_mut_ptr(&mut array), initialized: 0 };

    while let Some(item) = iter.next() {
        // സുരക്ഷ: `guard.initialized` 0 ൽ ആരംഭിക്കുന്നു, ഇതിൽ ഒരെണ്ണം വർദ്ധിക്കുന്നു
        // ലൂപ്പിൽ എത്തുമ്പോൾ ലൂപ്പ് നിർത്തലാക്കുന്നു (ഇത് `array.len()`) ആണ്.
        //
        unsafe {
            array.get_unchecked_mut(guard.initialized).write(item);
        }
        guard.initialized += 1;

        // മുഴുവൻ അറേയും സമാരംഭിച്ചിട്ടുണ്ടോയെന്ന് പരിശോധിക്കുക.
        if guard.initialized == N {
            mem::forget(guard);

            // സുരക്ഷ: മുകളിലുള്ള വ്യവസ്ഥ എല്ലാ ഘടകങ്ങളാണെന്ന് ഉറപ്പിക്കുന്നു
            // initialized.
            let out = unsafe { MaybeUninit::array_assume_init(array) };
            return Some(out);
        }
    }

    // `guard.initialized` `N` ൽ എത്തുന്നതിനുമുമ്പ് ആവർത്തനം തീർന്നുപോയാൽ മാത്രമേ ഇത് എത്തുകയുള്ളൂ.
    //
    // ഇതിനകം സമാരംഭിച്ച എല്ലാ ഘടകങ്ങളും ഉപേക്ഷിച്ച് `guard` ഇവിടെ ഉപേക്ഷിച്ചുവെന്നതും ശ്രദ്ധിക്കുക.
    None
}