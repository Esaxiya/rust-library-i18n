use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// ഈ ഫംഗ്ഷൻ ഒരിടത്ത് ഉപയോഗിക്കുകയും അത് നടപ്പിലാക്കുകയും ചെയ്യാമെങ്കിലും, മുമ്പത്തെ ശ്രമങ്ങൾ rustc മന്ദഗതിയിലാക്കി:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// മെമ്മറിയുടെ ഒരു ബ്ലോക്കിന്റെ ലേ Layout ട്ട്.
///
/// `Layout`-ന്റെ ഒരു ഉദാഹരണം മെമ്മറിയുടെ ഒരു പ്രത്യേക ലേ layout ട്ട് വിവരിക്കുന്നു.
/// ഒരു അലോക്കേറ്ററിന് നൽകാനായി നിങ്ങൾ ഒരു ഇൻപുട്ടായി ഒരു `Layout` അപ്പ് നിർമ്മിക്കുന്നു.
///
/// എല്ലാ ലേ outs ട്ടുകളിലും അനുബന്ധ വലുപ്പവും പവർ ഓഫ് ടു അലൈൻമെന്റും ഉണ്ട്.
///
/// (എല്ലാ മെമ്മറി അഭ്യർത്ഥനകളും പൂജ്യമല്ലാത്ത വലുപ്പമായിരിക്കണമെന്ന് `GlobalAlloc` ആവശ്യപ്പെടുന്നുണ്ടെങ്കിലും, ലേ outs ട്ടുകൾക്ക് പൂജ്യമല്ലാത്ത വലുപ്പം *ആവശ്യമില്ല*.
/// ഒരു കോളർ ഒന്നുകിൽ ഇതുപോലുള്ള നിബന്ധനകൾ പാലിക്കുന്നുണ്ടെന്ന് ഉറപ്പുവരുത്തണം, അയഞ്ഞ ആവശ്യകതകളുള്ള നിർദ്ദിഷ്ട അലോക്കേറ്ററുകൾ ഉപയോഗിക്കുക, അല്ലെങ്കിൽ കൂടുതൽ ശാന്തമായ `Allocator` ഇന്റർഫേസ് ഉപയോഗിക്കുക.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // അഭ്യർത്ഥിച്ച മെമ്മറിയുടെ വലുപ്പം, ബൈറ്റുകളിൽ അളക്കുന്നു.
    size_: usize,

    // അഭ്യർത്ഥിച്ച മെമ്മറി ബ്ലോക്കിന്റെ വിന്യാസം, ബൈറ്റുകളിൽ അളക്കുന്നു.
    // ഇത് എല്ലായ്പ്പോഴും ഒരു പവർ ഓഫ് ടു ആണെന്ന് ഞങ്ങൾ ഉറപ്പാക്കുന്നു, കാരണം എ‌പി‌ഐക്ക് `posix_memalign` പോലുള്ളവയ്ക്ക് ഇത് ആവശ്യമുണ്ട്, മാത്രമല്ല ലേ Layout ട്ട് കൺ‌സ്‌ട്രക്റ്റർ‌മാർ‌ക്ക് ഇത് ചുമത്തുന്നത് ന്യായമായ പരിമിതിയാണ്.
    //
    //
    // (എന്നിരുന്നാലും, ഞങ്ങൾക്ക് സമാനമായി `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.) ആവശ്യമില്ല
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// തന്നിരിക്കുന്ന `size`, `align` എന്നിവയിൽ നിന്ന് ഒരു `Layout` നിർമ്മിക്കുന്നു, അല്ലെങ്കിൽ ഇനിപ്പറയുന്ന ഏതെങ്കിലും നിബന്ധനകൾ പാലിച്ചില്ലെങ്കിൽ `LayoutError` നൽകുന്നു:
    ///
    /// * `align` പൂജ്യമായിരിക്കരുത്,
    ///
    /// * `align` രണ്ടിന്റെ ശക്തിയായിരിക്കണം,
    ///
    /// * `size`, `align`-ന്റെ ഏറ്റവും അടുത്തുള്ള മൾട്ടിപ്പിൾ വരെ റ ed ണ്ട് ചെയ്യുമ്പോൾ, കവിഞ്ഞൊഴുകരുത് (അതായത്, വൃത്താകൃതിയിലുള്ള മൂല്യം `usize::MAX`-നേക്കാൾ കുറവോ തുല്യമോ ആയിരിക്കണം).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (പവർ ഓഫ് ടു സൂചിപ്പിക്കുന്നത് വിന്യാസം!=0.)

        // വൃത്താകൃതിയിലുള്ള വലുപ്പം:
        //   size_rounded_up=(വലുപ്പം + വിന്യസിക്കുക, 1)&! (വിന്യസിക്കുക, 1);
        //
        // ആ വിന്യാസം മുകളിൽ നിന്ന് നമുക്കറിയാം!=0.
        // (വിന്യസിക്കുക, 1) ചേർക്കുന്നത് കവിഞ്ഞൊഴുകുന്നില്ലെങ്കിൽ, റൗണ്ട് അപ്പ് ചെയ്യുന്നത് നന്നായിരിക്കും.
        //
        // നേരെമറിച്ച്,&-മാസ്ക് ചെയ്യുന്നത്! (വിന്യസിക്കുക, 1) ലോ-ഓർഡർ-ബിറ്റുകൾ മാത്രം കുറയ്ക്കും.
        // അങ്ങനെ തുകയ്‌ക്കൊപ്പം ഓവർഫ്ലോ സംഭവിക്കുകയാണെങ്കിൽ,&-മാസ്കിന് ആ ഓവർഫ്ലോ പഴയപടിയാക്കാൻ പര്യാപ്തമല്ല.
        //
        //
        // മുകളിൽ സൂചിപ്പിക്കുന്നത് സമ്മേഷൻ ഓവർഫ്ലോ പരിശോധിക്കുന്നത് ആവശ്യവും പര്യാപ്തവുമാണ്.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // സുരക്ഷ: `from_size_align_unchecked`-നായുള്ള വ്യവസ്ഥകൾ
        // മുകളിൽ പരിശോധിച്ചു.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// എല്ലാ ചെക്കുകളും മറികടന്ന് ഒരു ലേ layout ട്ട് സൃഷ്ടിക്കുന്നു.
    ///
    /// # Safety
    ///
    /// [`Layout::from_size_align`]-ൽ നിന്നുള്ള മുൻ വ്യവസ്ഥകൾ പരിശോധിക്കാത്തതിനാൽ ഈ പ്രവർത്തനം സുരക്ഷിതമല്ല.
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // സുരക്ഷ: `align` പൂജ്യത്തേക്കാൾ വലുതാണെന്ന് കോളർ ഉറപ്പാക്കണം.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// ഈ ലേ .ട്ടിന്റെ മെമ്മറി ബ്ലോക്കിനായി ബൈറ്റുകളിലെ ഏറ്റവും കുറഞ്ഞ വലുപ്പം.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// ഈ ലേ .ട്ടിന്റെ മെമ്മറി ബ്ലോക്കിനായുള്ള ഏറ്റവും കുറഞ്ഞ ബൈറ്റ് വിന്യാസം.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// തരം `T` ന്റെ മൂല്യം കൈവശം വയ്ക്കാൻ അനുയോജ്യമായ ഒരു `Layout` നിർമ്മിക്കുന്നു.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // സുരക്ഷിതത്വം: വിന്യാസം Rust രണ്ട് ശക്തിയാണെന്നും ഉറപ്പാക്കുന്നു
        // വലുപ്പം + വിന്യസിക്കൽ കോംബോ ഞങ്ങളുടെ വിലാസ സ്ഥലത്ത് യോജിക്കുമെന്ന് ഉറപ്പുനൽകുന്നു.
        // ഫലമായി, ഒപ്റ്റിമൈസ് ചെയ്തിട്ടില്ലെങ്കിൽ panics കോഡ് ചേർക്കുന്നത് ഒഴിവാക്കാൻ ഇവിടെ അൺചെക്ക് ചെയ്ത കൺസ്ട്രക്റ്റർ ഉപയോഗിക്കുക.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T`-നായി ബാക്കിംഗ് ഘടന അനുവദിക്കുന്നതിന് ഉപയോഗിക്കാവുന്ന ഒരു റെക്കോർഡ് വിവരിക്കുന്ന ലേ layout ട്ട് നിർമ്മിക്കുന്നു (അത് ഒരു trait അല്ലെങ്കിൽ സ്ലൈസ് പോലുള്ള മറ്റ് വലുപ്പമില്ലാത്ത തരം ആകാം).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // സുരക്ഷ: എന്തുകൊണ്ടാണ് ഇത് സുരക്ഷിതമല്ലാത്ത വേരിയൻറ് ഉപയോഗിക്കുന്നതെന്ന് `new`-ൽ യുക്തി കാണുക
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// `T`-നായി ബാക്കിംഗ് ഘടന അനുവദിക്കുന്നതിന് ഉപയോഗിക്കാവുന്ന ഒരു റെക്കോർഡ് വിവരിക്കുന്ന ലേ layout ട്ട് നിർമ്മിക്കുന്നു (അത് ഒരു trait അല്ലെങ്കിൽ സ്ലൈസ് പോലുള്ള മറ്റ് വലുപ്പമില്ലാത്ത തരം ആകാം).
    ///
    /// # Safety
    ///
    /// ഇനിപ്പറയുന്ന നിബന്ധനകൾ ഉണ്ടെങ്കിൽ മാത്രമേ ഈ പ്രവർത്തനം വിളിക്കാൻ സുരക്ഷിതമാകൂ:
    ///
    /// - `T` `Sized` ആണെങ്കിൽ, ഈ പ്രവർത്തനം എല്ലായ്പ്പോഴും വിളിക്കുന്നത് സുരക്ഷിതമാണ്.
    /// - `T`-ന്റെ വലുപ്പം മാറ്റാത്ത വാൽ ആണെങ്കിൽ:
    ///     - ഒരു [slice], തുടർന്ന് സ്ലൈസ് വാലിന്റെ നീളം ഒരു സംയോജിത സംഖ്യയായിരിക്കണം, കൂടാതെ *മുഴുവൻ മൂല്യത്തിന്റെയും വലുപ്പം*(ഡൈനാമിക് ടെയിൽ നീളം + സ്റ്റാറ്റിറ്റിക്കൽ സൈസ് പ്രിഫിക്‌സ്) `isize`-ൽ യോജിക്കണം.
    ///     - ഒരു [trait object], തുടർന്ന് പോയിന്ററിന്റെ vtable ഭാഗം ഒരു വലുപ്പമില്ലാത്ത ഏകീകരണം വഴി നേടിയ `T` തരത്തിനായുള്ള സാധുവായ ഒരു vtable ലേക്ക് പോയിന്റുചെയ്യണം, കൂടാതെ *മുഴുവൻ മൂല്യത്തിന്റെയും വലുപ്പം*(ഡൈനാമിക് ടെയിൽ നീളം + സ്റ്റാറ്റിറ്റിക്കൽ സൈസ് പ്രിഫിക്‌സ്) `isize`-ൽ യോജിക്കണം.
    ///
    ///     - ഒരു (unstable) [extern type], തുടർന്ന് ഈ ഫംഗ്ഷൻ എല്ലായ്പ്പോഴും വിളിക്കുന്നത് സുരക്ഷിതമാണ്, പക്ഷേ ബാഹ്യ തരത്തിന്റെ ലേ layout ട്ട് അറിയാത്തതിനാൽ panic അല്ലെങ്കിൽ തെറ്റായ മൂല്യം നൽകാം.
    ///     ഒരു ബാഹ്യ തരം വാലിലേക്കുള്ള റഫറൻസിലെ [`Layout::for_value`]-ന്റെ അതേ സ്വഭാവമാണിത്.
    ///     - അല്ലെങ്കിൽ, ഈ ഫംഗ്ഷനെ വിളിക്കാൻ യാഥാസ്ഥിതികമായി അനുവദനീയമല്ല.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // സുരക്ഷ: ഈ ഫംഗ്ഷനുകളുടെ മുൻവ്യവസ്ഥകൾ ഞങ്ങൾ കോളറിലേക്ക് കൈമാറുന്നു
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // സുരക്ഷ: എന്തുകൊണ്ടാണ് ഇത് സുരക്ഷിതമല്ലാത്ത വേരിയൻറ് ഉപയോഗിക്കുന്നതെന്ന് `new`-ൽ യുക്തി കാണുക
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// അപകടകരമായ, പക്ഷേ ഈ ലേ .ട്ടിനായി നന്നായി വിന്യസിച്ചിരിക്കുന്ന ഒരു `NonNull` സൃഷ്ടിക്കുന്നു.
    ///
    /// പോയിന്റർ മൂല്യം സാധുവായ ഒരു പോയിന്ററിനെ പ്രതിനിധീകരിക്കാൻ സാധ്യതയുണ്ട്, അതായത് ഇത് "not yet initialized" സെന്റിനൽ മൂല്യമായി ഉപയോഗിക്കരുത്.
    /// അലസമായി അനുവദിക്കുന്ന തരങ്ങൾ മറ്റ് മാർഗ്ഗങ്ങളിലൂടെ ഓർഗനൈസേഷൻ ട്രാക്കുചെയ്യണം.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // സുരക്ഷ: വിന്യാസം പൂജ്യമല്ലാത്തതാണെന്ന് ഉറപ്പുനൽകുന്നു
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// `self`-ന് സമാനമായ ലേ layout ട്ടിന്റെ മൂല്യം നിലനിർത്താൻ കഴിയുന്ന റെക്കോർഡിനെ വിവരിക്കുന്ന ഒരു ലേ layout ട്ട് സൃഷ്ടിക്കുന്നു, പക്ഷേ ഇത് `align` (ബൈറ്റുകളിൽ അളക്കുന്നത്) വിന്യാസത്തിലേക്ക് വിന്യസിച്ചിരിക്കുന്നു.
    ///
    ///
    /// `self` ഇതിനകം നിശ്ചിത വിന്യാസം പാലിക്കുന്നുണ്ടെങ്കിൽ, `self` നൽകുന്നു.
    ///
    /// മടങ്ങിയെത്തിയ ലേ layout ട്ടിന് മറ്റൊരു വിന്യാസം ഉണ്ടോ എന്നത് പരിഗണിക്കാതെ തന്നെ, ഈ രീതി മൊത്തത്തിലുള്ള വലുപ്പത്തിലേക്ക് ഒരു പാഡിംഗും ചേർക്കുന്നില്ല.
    /// മറ്റൊരു വിധത്തിൽ പറഞ്ഞാൽ, `K` ന് വലുപ്പം 16 ഉണ്ടെങ്കിൽ, `K.align_to(32)` ന് *ഇപ്പോഴും* വലുപ്പം 16 ഉണ്ടാകും.
    ///
    /// `self.size()`-ഉം നൽകിയ `align`-ഉം സംയോജിപ്പിക്കുന്നത് [`Layout::from_size_align`]-ൽ ലിസ്റ്റുചെയ്‌തിരിക്കുന്ന വ്യവസ്ഥകളെ ലംഘിക്കുന്നുവെങ്കിൽ ഒരു പിശക് നൽകുന്നു.
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// ഇനിപ്പറയുന്ന വിലാസം `align` (ബൈറ്റുകളിൽ അളക്കുന്നത്) തൃപ്തിപ്പെടുത്തുമെന്ന് ഉറപ്പാക്കുന്നതിന് `self` ന് ശേഷം ഞങ്ങൾ ചേർക്കേണ്ട പാഡിംഗിന്റെ അളവ് നൽകുന്നു.
    ///
    /// ഉദാ., `self.size()` 9 ആണെങ്കിൽ, `self.padding_needed_for(4)` 3 നൽകുന്നു, കാരണം ഇത് 4-വിന്യസിച്ച വിലാസം ലഭിക്കാൻ ആവശ്യമായ പാഡിംഗിന്റെ ഏറ്റവും കുറഞ്ഞ ബൈറ്റുകളുടെ എണ്ണം (അനുബന്ധ മെമ്മറി ബ്ലോക്ക് 4-വിന്യസിച്ച വിലാസത്തിൽ ആരംഭിക്കുന്നുവെന്ന് കരുതുക).
    ///
    ///
    /// `align` ഒരു പവർ ഓഫ് ടു അല്ലെങ്കിൽ ഈ ഫംഗ്ഷന്റെ റിട്ടേൺ മൂല്യത്തിന് അർത്ഥമില്ല.
    ///
    /// മടക്കിയ മൂല്യത്തിന്റെ യൂട്ടിലിറ്റിക്ക് അനുവദിച്ച മെമ്മറി ബ്ലോക്കിനായി `align` ആരംഭ വിലാസത്തിന്റെ വിന്യാസത്തേക്കാൾ കുറവോ തുല്യമോ ആയിരിക്കണമെന്ന് ശ്രദ്ധിക്കുക.ഈ നിയന്ത്രണം തൃപ്തിപ്പെടുത്തുന്നതിനുള്ള ഒരു മാർഗം `align <= self.align()` ഉറപ്പാക്കുക എന്നതാണ്.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // വൃത്താകൃതിയിലുള്ള മൂല്യം:
        //   len_rounded_up=(len + align, 1)&! (align, 1);
        // തുടർന്ന് ഞങ്ങൾ പാഡിംഗ് വ്യത്യാസം നൽകുന്നു: `len_rounded_up - len`.
        //
        // ഞങ്ങൾ ഉടനീളം മോഡുലാർ അരിത്മെറ്റിക് ഉപയോഗിക്കുന്നു:
        //
        // 1. വിന്യാസം> 0 എന്ന് ഉറപ്പുനൽകുന്നു, അതിനാൽ വിന്യസിക്കുക, 1 എല്ലായ്പ്പോഴും സാധുവാണ്.
        //
        // 2.
        // `len + align - 1` പരമാവധി `align - 1` വഴി കവിഞ്ഞൊഴുകാൻ കഴിയും, അതിനാൽ `!(align - 1)` ഉള്ള&-മാസ്ക് ഓവർഫ്ലോയുടെ കാര്യത്തിൽ, `len_rounded_up` തന്നെ 0 ആയിരിക്കുമെന്ന് ഉറപ്പാക്കും.
        //
        //    അങ്ങനെ മടങ്ങിയ പാഡിംഗ്, `len` ലേക്ക് ചേർക്കുമ്പോൾ, 0 ലഭിക്കും, ഇത് `align` വിന്യാസത്തെ തുച്ഛമായി തൃപ്തിപ്പെടുത്തുന്നു.
        //
        // (തീർച്ചയായും, മുകളിലുള്ള രീതിയിൽ വലുപ്പവും പാഡിംഗ് ഓവർഫ്ലോയും ഉള്ള മെമ്മറി ബ്ലോക്കുകൾ അനുവദിക്കാനുള്ള ശ്രമം അലോക്കേറ്ററിന് എങ്ങനെയെങ്കിലും ഒരു പിശക് വരുത്താൻ കാരണമാകും.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// ഈ ലേ layout ട്ടിന്റെ വലുപ്പം ലേ layout ട്ടിന്റെ വിന്യാസത്തിന്റെ ഒന്നിലധികം എണ്ണം വരെ വട്ടമിട്ട് ഒരു ലേ layout ട്ട് സൃഷ്ടിക്കുന്നു.
    ///
    ///
    /// `padding_needed_for` ന്റെ ഫലം ലേ layout ട്ടിന്റെ നിലവിലെ വലുപ്പത്തിലേക്ക് ചേർക്കുന്നതിന് തുല്യമാണിത്.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // ഇത് കവിഞ്ഞൊഴുകാൻ കഴിയില്ല.ലേ Layout ട്ടിന്റെ മാറ്റത്തിൽ നിന്ന് ഉദ്ധരിക്കുന്നു:
        // > `size`, `align`-ന്റെ ഏറ്റവും അടുത്തുള്ള മൾട്ടിപ്പിൾ വരെ റ ed ണ്ട് ചെയ്യുമ്പോൾ,
        // > കവിഞ്ഞൊഴുകരുത് (അതായത്, വൃത്താകൃതിയിലുള്ള മൂല്യം ഇതിലും കുറവായിരിക്കണം
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// `self`-ന്റെ `n` സംഭവങ്ങളുടെ റെക്കോർഡ് വിവരിക്കുന്ന ഒരു ലേ layout ട്ട് സൃഷ്ടിക്കുന്നു, ഓരോ ഉദാഹരണത്തിനും അതിന്റെ ആവശ്യപ്പെട്ട വലുപ്പവും വിന്യാസവും നൽകിയിട്ടുണ്ടെന്ന് ഉറപ്പാക്കുന്നതിന് ഓരോന്നിനും ഇടയിൽ അനുയോജ്യമായ പാഡിംഗ്.
    /// വിജയത്തിൽ, `(k, offs)` നൽകുന്നു, അവിടെ `k` അറേയുടെ ലേ layout ട്ടും `offs` എന്നത് അറേയിലെ ഓരോ ഘടകത്തിന്റെയും ആരംഭം തമ്മിലുള്ള ദൂരമാണ്.
    ///
    /// ഗണിത ഓവർഫ്ലോയിൽ, `LayoutError` നൽകുന്നു.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // ഇത് കവിഞ്ഞൊഴുകാൻ കഴിയില്ല.ലേ Layout ട്ടിന്റെ മാറ്റത്തിൽ നിന്ന് ഉദ്ധരിക്കുന്നു:
        // > `size`, `align`-ന്റെ ഏറ്റവും അടുത്തുള്ള മൾട്ടിപ്പിൾ വരെ റ ed ണ്ട് ചെയ്യുമ്പോൾ,
        // > കവിഞ്ഞൊഴുകരുത് (അതായത്, വൃത്താകൃതിയിലുള്ള മൂല്യം ഇതിലും കുറവായിരിക്കണം
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // സുരക്ഷ: self.align ഇതിനകം തന്നെ സാധുതയുള്ളതാണെന്ന് അറിയപ്പെടുന്നു, കൂടാതെ അലോക്കേഷൻ_സൈസ്
        // ഇതിനകം പാഡ് ചെയ്തു.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// `next` ശരിയായി വിന്യസിക്കുമെന്ന് ഉറപ്പാക്കുന്നതിന് ആവശ്യമായ പാഡിംഗ് ഉൾപ്പെടെ, `self`-ന് ശേഷം `next`-നായുള്ള റെക്കോർഡ് വിവരിക്കുന്ന ഒരു ലേ layout ട്ട് സൃഷ്ടിക്കുന്നു, പക്ഷേ *ട്രെയിലിംഗ് പാഡിംഗ് ഇല്ല*.
    ///
    /// സി പ്രാതിനിധ്യ ലേ layout ട്ട് `repr(C)` മായി പൊരുത്തപ്പെടുന്നതിന്, എല്ലാ ഫീൽഡുകളിലും ലേ layout ട്ട് നീട്ടിയതിന് ശേഷം നിങ്ങൾ `pad_to_align`-ലേക്ക് വിളിക്കണം.
    /// (സ്ഥിരസ്ഥിതി Rust പ്രാതിനിധ്യ ലേ layout ട്ട് `repr(Rust)`, as it is unspecified.) മായി പൊരുത്തപ്പെടാൻ ഒരു വഴിയുമില്ല
    ///
    /// രണ്ട് ഭാഗങ്ങളുടെയും വിന്യാസം ഉറപ്പാക്കുന്നതിന് ഫലമായുണ്ടാകുന്ന ലേ layout ട്ടിന്റെ വിന്യാസം `self`, `next` എന്നിവയുടെ പരമാവധി ആയിരിക്കും.
    ///
    /// `Ok((k, offset))` നൽകുന്നു, ഇവിടെ `k` എന്നത് സംയോജിത റെക്കോർഡിന്റെ ലേ layout ട്ടും `offset` എന്നത് ബൈറ്റുകളിൽ, സംയോജിത റെക്കോർഡിനുള്ളിൽ ഉൾച്ചേർത്ത `next` ന്റെ ആപേക്ഷിക സ്ഥാനവുമാണ് (റെക്കോർഡ് ഓഫ്സെറ്റ് 0 ൽ ആരംഭിക്കുന്നുവെന്ന് കരുതുക).
    ///
    ///
    /// ഗണിത ഓവർഫ്ലോയിൽ, `LayoutError` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ഒരു എക്സ് 100 എക്സ് ഘടനയുടെ ലേ layout ട്ടും അതിന്റെ ഫീൽഡുകളുടെ ലേ outs ട്ടുകളിൽ നിന്നുള്ള ഫീൽഡുകളുടെ ഓഫ്സെറ്റുകളും കണക്കാക്കാൻ:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // `pad_to_align` ഉപയോഗിച്ച് അന്തിമമാക്കാൻ ഓർമ്മിക്കുക!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // ഇത് പ്രവർത്തിക്കുന്നുവെന്ന് പരിശോധിക്കുക
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// ഓരോ സംഭവത്തിനും ഇടയിൽ പാഡിംഗ് ഇല്ലാതെ, `self`-ന്റെ `n` സംഭവങ്ങളുടെ റെക്കോർഡ് വിവരിക്കുന്ന ഒരു ലേ layout ട്ട് സൃഷ്ടിക്കുന്നു.
    ///
    /// ശ്രദ്ധിക്കുക, `repeat` ൽ നിന്ന് വ്യത്യസ്തമായി, `self` ന്റെ ആവർത്തിച്ചുള്ള സംഭവങ്ങൾ ശരിയായി വിന്യസിക്കപ്പെടുമെന്ന് `repeat_packed` ഉറപ്പുനൽകുന്നില്ല.
    /// മറ്റൊരു വിധത്തിൽ പറഞ്ഞാൽ, ഒരു അറേ അനുവദിക്കുന്നതിന് `repeat_packed` നൽകിയ ലേ layout ട്ട് ഉപയോഗിക്കുകയാണെങ്കിൽ, അറേയിലെ എല്ലാ ഘടകങ്ങളും ശരിയായി വിന്യസിക്കുമെന്ന് ഉറപ്പില്ല.
    ///
    /// ഗണിത ഓവർഫ്ലോയിൽ, `LayoutError` നൽകുന്നു.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// `self`-നുള്ള റെക്കോർഡ് വിവരിക്കുന്ന ഒരു ലേ layout ട്ട് സൃഷ്ടിക്കുന്നു, തുടർന്ന് `next`-ന് ഇടയിൽ അധിക പാഡിംഗ് ഇല്ല.
    /// പാഡിംഗ് ഒന്നും ചേർത്തിട്ടില്ലാത്തതിനാൽ, `next` ന്റെ വിന്യാസം അപ്രസക്തമാണ്, മാത്രമല്ല ഫലമായുണ്ടാകുന്ന ലേ .ട്ടിലേക്ക് ഇത് * സംയോജിപ്പിച്ചിട്ടില്ല.
    ///
    ///
    /// ഗണിത ഓവർഫ്ലോയിൽ, `LayoutError` നൽകുന്നു.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// ഒരു `[T; n]`-നായുള്ള റെക്കോർഡ് വിവരിക്കുന്ന ഒരു ലേ layout ട്ട് സൃഷ്ടിക്കുന്നു.
    ///
    /// ഗണിത ഓവർഫ്ലോയിൽ, `LayoutError` നൽകുന്നു.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// `Layout::from_size_align` അല്ലെങ്കിൽ മറ്റേതെങ്കിലും `Layout` കൺ‌സ്‌ട്രക്റ്റർ‌ക്ക് നൽകിയിരിക്കുന്ന പാരാമീറ്ററുകൾ‌അതിന്റെ ഡോക്യുമെന്റഡ് പരിമിതികളെ തൃപ്തിപ്പെടുത്തുന്നില്ല.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (trait പിശകിന്റെ ഡ st ൺസ്ട്രീം ഇം‌പ്ലിംഗിനായി ഞങ്ങൾക്ക് ഇത് ആവശ്യമാണ്)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}