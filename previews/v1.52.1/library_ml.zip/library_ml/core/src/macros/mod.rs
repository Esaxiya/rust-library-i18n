#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // കോളറിന്റെ പതിപ്പിനെ ആശ്രയിച്ച് `$crate::panic::panic_2015` അല്ലെങ്കിൽ `$crate::panic::panic_2021` ലേക്ക് വികസിക്കുന്നു.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// രണ്ട് പദപ്രയോഗങ്ങൾ പരസ്പരം തുല്യമാണെന്ന് ([`PartialEq`] ഉപയോഗിക്കുന്നു).
///
/// panic-ൽ, ഈ മാക്രോ എക്‌സ്‌പ്രഷനുകളുടെ മൂല്യങ്ങൾ അവയുടെ ഡീബഗ് പ്രാതിനിധ്യങ്ങൾ ഉപയോഗിച്ച് പ്രിന്റുചെയ്യും.
///
///
/// [`assert!`] പോലെ, ഈ മാക്രോയ്ക്കും രണ്ടാമത്തെ ഫോം ഉണ്ട്, അവിടെ ഒരു ഇച്ഛാനുസൃത panic സന്ദേശം നൽകാൻ കഴിയും.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // ചുവടെയുള്ള റിബറോകൾ മന .പൂർവമാണ്.
                    // അവയില്ലാതെ, മൂല്യങ്ങൾ താരതമ്യം ചെയ്യുന്നതിന് മുമ്പുതന്നെ വായ്പയ്‌ക്കായുള്ള സ്റ്റാക്ക് സ്ലോട്ട് സമാരംഭിക്കുന്നു, ഇത് ശ്രദ്ധേയമായ വേഗതയിലേക്ക് നയിക്കുന്നു.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // ചുവടെയുള്ള റിബറോകൾ മന .പൂർവമാണ്.
                    // അവയില്ലാതെ, മൂല്യങ്ങൾ താരതമ്യം ചെയ്യുന്നതിന് മുമ്പുതന്നെ വായ്പയ്‌ക്കായുള്ള സ്റ്റാക്ക് സ്ലോട്ട് സമാരംഭിക്കുന്നു, ഇത് ശ്രദ്ധേയമായ വേഗതയിലേക്ക് നയിക്കുന്നു.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// രണ്ട് പദപ്രയോഗങ്ങൾ പരസ്പരം തുല്യമല്ലെന്ന് വാദിക്കുന്നു ([`PartialEq`] ഉപയോഗിക്കുന്നു).
///
/// panic-ൽ, ഈ മാക്രോ എക്‌സ്‌പ്രഷനുകളുടെ മൂല്യങ്ങൾ അവയുടെ ഡീബഗ് പ്രാതിനിധ്യങ്ങൾ ഉപയോഗിച്ച് പ്രിന്റുചെയ്യും.
///
///
/// [`assert!`] പോലെ, ഈ മാക്രോയ്ക്കും രണ്ടാമത്തെ ഫോം ഉണ്ട്, അവിടെ ഒരു ഇച്ഛാനുസൃത panic സന്ദേശം നൽകാൻ കഴിയും.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // ചുവടെയുള്ള റിബറോകൾ മന .പൂർവമാണ്.
                    // അവയില്ലാതെ, മൂല്യങ്ങൾ താരതമ്യം ചെയ്യുന്നതിന് മുമ്പുതന്നെ വായ്പയ്‌ക്കായുള്ള സ്റ്റാക്ക് സ്ലോട്ട് സമാരംഭിക്കുന്നു, ഇത് ശ്രദ്ധേയമായ വേഗതയിലേക്ക് നയിക്കുന്നു.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // ചുവടെയുള്ള റിബറോകൾ മന .പൂർവമാണ്.
                    // അവയില്ലാതെ, മൂല്യങ്ങൾ താരതമ്യം ചെയ്യുന്നതിന് മുമ്പുതന്നെ വായ്പയ്‌ക്കായുള്ള സ്റ്റാക്ക് സ്ലോട്ട് സമാരംഭിക്കുന്നു, ഇത് ശ്രദ്ധേയമായ വേഗതയിലേക്ക് നയിക്കുന്നു.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// റൺടൈമിൽ ഒരു ബൂലിയൻ എക്‌സ്‌പ്രഷൻ `true` ആണെന്ന് വാദിക്കുന്നു.
///
/// നൽകിയ എക്‌സ്‌പ്രഷൻ റൺടൈമിൽ `true` ലേക്ക് വിലയിരുത്താൻ കഴിയുന്നില്ലെങ്കിൽ ഇത് [`panic!`] മാക്രോയെ അഭ്യർത്ഥിക്കും.
///
/// [`assert!`] പോലെ, ഈ മാക്രോയ്ക്കും രണ്ടാമത്തെ പതിപ്പ് ഉണ്ട്, അവിടെ ഒരു ഇച്ഛാനുസൃത panic സന്ദേശം നൽകാൻ കഴിയും.
///
/// # Uses
///
/// [`assert!`]-ൽ നിന്ന് വ്യത്യസ്തമായി, സ്ഥിരസ്ഥിതിയായി ഒപ്റ്റിമൈസ് ചെയ്യാത്ത ബിൽഡുകളിൽ മാത്രമേ `debug_assert!` സ്റ്റേറ്റ്മെന്റുകൾ പ്രവർത്തനക്ഷമമാകൂ.
/// കംപൈലറിലേക്ക് `-C debug-assertions` കൈമാറുന്നില്ലെങ്കിൽ ഒപ്റ്റിമൈസ് ചെയ്ത ബിൽഡ് `debug_assert!` സ്റ്റേറ്റ്മെന്റുകൾ എക്സിക്യൂട്ട് ചെയ്യില്ല.
/// ഒരു റിലീസ് ബിൽഡിൽ ഹാജരാകാൻ വളരെ ചെലവേറിയതും എന്നാൽ വികസന സമയത്ത് സഹായകരവുമായ ചെക്കുകൾക്ക് ഇത് `debug_assert!` ഉപയോഗപ്രദമാക്കുന്നു.
/// `debug_assert!` വിപുലീകരിക്കുന്നതിന്റെ ഫലം എല്ലായ്പ്പോഴും തരം പരിശോധിക്കുന്നു.
///
/// അൺചെക്കുചെയ്യാത്ത ഒരു വാദം പൊരുത്തമില്ലാത്ത അവസ്ഥയിലുള്ള ഒരു പ്രോഗ്രാം പ്രവർത്തിക്കുന്നത് തുടരാൻ അനുവദിക്കുന്നു, ഇത് അപ്രതീക്ഷിത പ്രത്യാഘാതങ്ങൾ ഉണ്ടാക്കാം, പക്ഷേ ഇത് സുരക്ഷിത കോഡിൽ മാത്രം സംഭവിക്കുന്നിടത്തോളം സുരക്ഷിതത്വം അവതരിപ്പിക്കുന്നില്ല.
///
/// എന്നിരുന്നാലും, അവകാശവാദങ്ങളുടെ പ്രകടന ചെലവ് പൊതുവായി കണക്കാക്കാനാവില്ല.
/// സമഗ്രമായ പ്രൊഫൈലിംഗിന് ശേഷം മാത്രമേ [`assert!`] നെ `debug_assert!` ഉപയോഗിച്ച് മാറ്റിസ്ഥാപിക്കുകയുള്ളൂ, കൂടുതൽ പ്രധാനമായി, സുരക്ഷിത കോഡിൽ മാത്രം!
///
/// # Examples
///
/// ```
/// // ഈ അവകാശവാദങ്ങൾക്കായുള്ള panic സന്ദേശം നൽകിയിരിക്കുന്ന പദപ്രയോഗത്തിന്റെ കർശന മൂല്യമാണ്.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // വളരെ ലളിതമായ പ്രവർത്തനം
/// debug_assert!(some_expensive_computation());
///
/// // ഒരു ഇഷ്‌ടാനുസൃത സന്ദേശം ഉപയോഗിച്ച് ഉറപ്പിക്കുക
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// രണ്ട് പദപ്രയോഗങ്ങൾ പരസ്പരം തുല്യമാണെന്ന് വാദിക്കുന്നു.
///
/// panic-ൽ, ഈ മാക്രോ എക്‌സ്‌പ്രഷനുകളുടെ മൂല്യങ്ങൾ അവയുടെ ഡീബഗ് പ്രാതിനിധ്യങ്ങൾ ഉപയോഗിച്ച് പ്രിന്റുചെയ്യും.
///
/// [`assert_eq!`] ൽ നിന്ന് വ്യത്യസ്തമായി, `debug_assert_eq!` സ്റ്റേറ്റ്മെന്റുകൾ സ്ഥിരസ്ഥിതിയായി ഒപ്റ്റിമൈസ് ചെയ്യാത്ത ബിൽഡുകളിൽ മാത്രമേ പ്രാപ്തമാക്കൂ.
/// കംപൈലറിലേക്ക് `-C debug-assertions` കൈമാറുന്നില്ലെങ്കിൽ ഒപ്റ്റിമൈസ് ചെയ്ത ബിൽഡ് `debug_assert_eq!` സ്റ്റേറ്റ്മെന്റുകൾ എക്സിക്യൂട്ട് ചെയ്യില്ല.
/// ഒരു റിലീസ് ബിൽഡിൽ ഹാജരാകാൻ വളരെ ചെലവേറിയതും എന്നാൽ വികസന സമയത്ത് സഹായകരവുമായ ചെക്കുകൾക്ക് ഇത് `debug_assert_eq!` ഉപയോഗപ്രദമാക്കുന്നു.
///
/// `debug_assert_eq!` വിപുലീകരിക്കുന്നതിന്റെ ഫലം എല്ലായ്പ്പോഴും തരം പരിശോധിക്കുന്നു.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// രണ്ട് പദപ്രയോഗങ്ങൾ പരസ്പരം തുല്യമല്ലെന്ന് വാദിക്കുന്നു.
///
/// panic-ൽ, ഈ മാക്രോ എക്‌സ്‌പ്രഷനുകളുടെ മൂല്യങ്ങൾ അവയുടെ ഡീബഗ് പ്രാതിനിധ്യങ്ങൾ ഉപയോഗിച്ച് പ്രിന്റുചെയ്യും.
///
/// [`assert_ne!`] ൽ നിന്ന് വ്യത്യസ്തമായി, `debug_assert_ne!` സ്റ്റേറ്റ്മെന്റുകൾ സ്ഥിരസ്ഥിതിയായി ഒപ്റ്റിമൈസ് ചെയ്യാത്ത ബിൽഡുകളിൽ മാത്രമേ പ്രാപ്തമാക്കൂ.
/// കംപൈലറിലേക്ക് `-C debug-assertions` കൈമാറുന്നില്ലെങ്കിൽ ഒപ്റ്റിമൈസ് ചെയ്ത ബിൽഡ് `debug_assert_ne!` സ്റ്റേറ്റ്മെന്റുകൾ നടപ്പിലാക്കില്ല.
/// ഒരു റിലീസ് ബിൽഡിൽ ഹാജരാകാൻ വളരെ ചെലവേറിയതും എന്നാൽ വികസന സമയത്ത് സഹായകരവുമായ ചെക്കുകൾക്ക് ഇത് `debug_assert_ne!` ഉപയോഗപ്രദമാക്കുന്നു.
///
/// `debug_assert_ne!` വിപുലീകരിക്കുന്നതിന്റെ ഫലം എല്ലായ്പ്പോഴും തരം പരിശോധിക്കുന്നു.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// തന്നിരിക്കുന്ന പദപ്രയോഗം നൽകിയ ഏതെങ്കിലും പാറ്റേണുകളുമായി പൊരുത്തപ്പെടുന്നുണ്ടോ എന്ന് നൽകുന്നു.
///
/// ഒരു `match` എക്‌സ്‌പ്രഷനിലെന്നപോലെ, പാറ്റേണിനെ ഓപ്‌ഷണലായി `if`-ഉം പാറ്റേൺ ബന്ധിപ്പിച്ച പേരുകളിലേക്ക് ആക്‌സസ്സ് ഉള്ള ഒരു ഗാർഡ് എക്‌സ്‌പ്രഷനും പിന്തുടരാനാകും.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// ഒരു ഫലം അൺ‌റാപ്പ് ചെയ്യുക അല്ലെങ്കിൽ അതിന്റെ പിശക് പ്രചരിപ്പിക്കുക.
///
/// `try!` മാറ്റിസ്ഥാപിക്കുന്നതിനായി `?` ഓപ്പറേറ്റർ ചേർത്തു, പകരം അത് ഉപയോഗിക്കണം.
/// കൂടാതെ, `try` എന്നത് Rust 2018 ലെ ഒരു റിസർവ്ഡ് പദമാണ്, അതിനാൽ നിങ്ങൾ ഇത് ഉപയോഗിക്കേണ്ടതുണ്ടെങ്കിൽ, നിങ്ങൾ [raw-identifier syntax][ris] ഉപയോഗിക്കേണ്ടതുണ്ട്: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` തന്നിരിക്കുന്ന [`Result`] മായി പൊരുത്തപ്പെടുന്നു.`Ok` വേരിയന്റിന്റെ കാര്യത്തിൽ, എക്‌സ്‌പ്രഷന് പൊതിഞ്ഞ മൂല്യത്തിന്റെ മൂല്യമുണ്ട്.
///
/// `Err` വേരിയന്റിന്റെ കാര്യത്തിൽ, ഇത് ആന്തരിക പിശക് വീണ്ടെടുക്കുന്നു.`try!` തുടർന്ന് `From` ഉപയോഗിച്ച് പരിവർത്തനം നടത്തുന്നു.
/// പ്രത്യേക പിശകുകളും പൊതുവായവയും തമ്മിലുള്ള യാന്ത്രിക പരിവർത്തനം ഇത് നൽകുന്നു.
/// തത്ഫലമായുണ്ടാകുന്ന പിശക് ഉടൻ മടക്കിനൽകുന്നു.
///
/// നേരത്തെയുള്ള റിട്ടേൺ കാരണം, [`Result`] നൽകുന്ന ഫംഗ്ഷനുകളിൽ മാത്രമേ `try!` ഉപയോഗിക്കാൻ കഴിയൂ.
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // ദ്രുത റിട്ടേണിംഗ് പിശകുകളുടെ പ്രിയപ്പെട്ട രീതി
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // ദ്രുത റിട്ടേണിംഗ് പിശകുകളുടെ മുമ്പത്തെ രീതി
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // ഇത് ഇതിന് തുല്യമാണ്:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// ഫോർമാറ്റുചെയ്‌ത ഡാറ്റ ഒരു ബഫറിലേക്ക് എഴുതുന്നു.
///
/// ഈ മാക്രോ ഒരു 'writer', ഒരു ഫോർമാറ്റ് സ്ട്രിംഗ്, ആർഗ്യുമെന്റുകളുടെ പട്ടിക എന്നിവ സ്വീകരിക്കുന്നു.
/// നിർദ്ദിഷ്ട ഫോർമാറ്റ് സ്ട്രിംഗ് അനുസരിച്ച് ആർഗ്യുമെന്റുകൾ ഫോർമാറ്റുചെയ്യുകയും ഫലം എഴുത്തുകാരന് കൈമാറുകയും ചെയ്യും.
/// എഴുത്തുകാരൻ ഒരു എക്സ് 00 എക്സ് രീതി ഉപയോഗിച്ച് ഏതെങ്കിലും മൂല്യമായിരിക്കാം;സാധാരണയായി ഇത് വരുന്നത് [`fmt::Write`] അല്ലെങ്കിൽ [`io::Write`] trait നടപ്പിലാക്കുന്നതിലൂടെയാണ്.
/// `write_fmt` രീതി മടക്കിനൽകുന്നതെന്തും മാക്രോ നൽകുന്നു;സാധാരണയായി ഒരു [`fmt::Result`], അല്ലെങ്കിൽ [`io::Result`].
///
/// ഫോർമാറ്റ് സ്ട്രിംഗ് വാക്യഘടനയെക്കുറിച്ചുള്ള കൂടുതൽ വിവരങ്ങൾക്ക് [`std::fmt`] കാണുക.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// ഒരു മൊഡ്യൂളിന് `std::fmt::Write`, `std::io::Write` എന്നിവ ഇറക്കുമതി ചെയ്യാനും ഒബ്ജക്റ്റുകൾ സാധാരണയായി നടപ്പിലാക്കാത്തതിനാൽ `write!` നെ വിളിക്കാനും കഴിയും.
///
/// എന്നിരുന്നാലും, മൊഡ്യൂൾ traits യോഗ്യതയുള്ളവ ഇറക്കുമതി ചെയ്യേണ്ടതിനാൽ അവരുടെ പേരുകൾ പൊരുത്തപ്പെടുന്നില്ല:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt ഉപയോഗിക്കുന്നു
///     write!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt ഉപയോഗിക്കുന്നു
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: `no_std` സജ്ജീകരണങ്ങളിലും ഈ മാക്രോ ഉപയോഗിക്കാം.
/// ഒരു `no_std` സജ്ജീകരണത്തിൽ ഘടകങ്ങളുടെ നടപ്പാക്കൽ വിശദാംശങ്ങൾക്ക് നിങ്ങൾ ഉത്തരവാദിയാണ്.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// ഒരു പുതിയ ലൈൻ കൂട്ടിച്ചേർത്തുകൊണ്ട് ഫോർമാറ്റുചെയ്‌ത ഡാറ്റ ഒരു ബഫറിലേക്ക് എഴുതുക.
///
/// എല്ലാ പ്ലാറ്റ്ഫോമുകളിലും, പുതിയ ലൈൻ LINE FEED പ്രതീകം (`\n`/`U+000A`) മാത്രം (അധിക CARRIAGE RETURN (`\r`/`U+000D`) ഇല്ല.
///
/// കൂടുതൽ വിവരങ്ങൾക്ക്, [`write!`] കാണുക.ഫോർമാറ്റ് സ്ട്രിംഗ് വാക്യഘടനയെക്കുറിച്ചുള്ള കൂടുതൽ വിവരങ്ങൾക്ക്, [`std::fmt`] കാണുക.
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// ഒരു മൊഡ്യൂളിന് `std::fmt::Write`, `std::io::Write` എന്നിവ ഇറക്കുമതി ചെയ്യാനും ഒബ്ജക്റ്റുകൾ സാധാരണയായി നടപ്പിലാക്കാത്തതിനാൽ `write!` നെ വിളിക്കാനും കഴിയും.
/// എന്നിരുന്നാലും, മൊഡ്യൂൾ traits യോഗ്യതയുള്ളവ ഇറക്കുമതി ചെയ്യേണ്ടതിനാൽ അവരുടെ പേരുകൾ പൊരുത്തപ്പെടുന്നില്ല:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // fmt::Write::write_fmt ഉപയോഗിക്കുന്നു
///     writeln!(&mut v, "s = {:?}", s)?; // io::Write::write_fmt ഉപയോഗിക്കുന്നു
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// എത്തിച്ചേരാനാകാത്ത കോഡ് സൂചിപ്പിക്കുന്നു.
///
/// ചില കോഡുകളിൽ എത്തിച്ചേരാനാകില്ലെന്ന് കംപൈലറിന് നിർണ്ണയിക്കാൻ കഴിയാത്ത ഏത് സമയത്തും ഇത് ഉപയോഗപ്രദമാണ്.ഉദാഹരണത്തിന്:
///
/// * കാവൽ വ്യവസ്ഥകളുമായി ആയുധങ്ങളുമായി പൊരുത്തപ്പെടുക.
/// * ചലനാത്മകമായി അവസാനിപ്പിക്കുന്ന ലൂപ്പുകൾ.
/// * ചലനാത്മകമായി അവസാനിപ്പിക്കുന്ന ഇറ്ററേറ്ററുകൾ.
///
/// കോഡ് എത്തിച്ചേരാനാകില്ലെന്ന നിർണ്ണയം തെറ്റാണെന്ന് തെളിഞ്ഞാൽ, പ്രോഗ്രാം ഉടൻ തന്നെ ഒരു [`panic!`] ഉപയോഗിച്ച് അവസാനിപ്പിക്കും.
///
/// ഈ മാക്രോയുടെ സുരക്ഷിതമല്ലാത്ത ക p ണ്ടർ [`unreachable_unchecked`] ഫംഗ്ഷനാണ്, ഇത് കോഡ് എത്തിച്ചേർന്നാൽ നിർവചിക്കപ്പെടാത്ത സ്വഭാവത്തിന് കാരണമാകും.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// ഇത് എല്ലായ്പ്പോഴും [`panic!`] ആയിരിക്കും.
///
/// # Examples
///
/// ആയുധങ്ങൾ പൊരുത്തപ്പെടുത്തുക:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // അഭിപ്രായമിട്ടാൽ കംപൈൽ പിശക്
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // x/3-ന്റെ ഏറ്റവും ദരിദ്രമായ നടപ്പാക്കലുകളിൽ ഒന്ന്
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// "not implemented" സന്ദേശവുമായി പരിഭ്രാന്തരായി നടപ്പിലാക്കാത്ത കോഡ് സൂചിപ്പിക്കുന്നു.
///
/// ടൈപ്പ്-ചെക്ക് ചെയ്യാൻ ഇത് നിങ്ങളുടെ കോഡിനെ അനുവദിക്കുന്നു, നിങ്ങൾ ഒരു trait പ്രോട്ടോടൈപ്പ് ചെയ്യുകയോ നടപ്പിലാക്കുകയോ ചെയ്യുകയാണെങ്കിൽ ഇത് ഉപയോഗപ്രദമാകും, അതിന് ഒന്നിലധികം രീതികൾ ആവശ്യമാണ്.
///
/// `unimplemented!` ഉം [`todo!`] ഉം തമ്മിലുള്ള വ്യത്യാസം `todo!` പിന്നീട് പ്രവർത്തനം നടപ്പിലാക്കാനുള്ള ഉദ്ദേശ്യം അറിയിക്കുകയും സന്ദേശം "not yet implemented" ആണെങ്കിൽ, `unimplemented!` അത്തരം ക്ലെയിമുകളൊന്നും നൽകുന്നില്ല എന്നതാണ്.
/// അതിന്റെ സന്ദേശം "not implemented" ആണ്.
/// ചില IDE-കൾ `ടോഡോ! 'എന്ന് അടയാളപ്പെടുത്തും.
///
/// # Panics
///
/// ഇത് എല്ലായ്പ്പോഴും [`panic!`] ആയിരിക്കും, കാരണം `unimplemented!` എന്നത് ഒരു നിശ്ചിത, നിർദ്ദിഷ്ട സന്ദേശമുള്ള `panic!`-ന്റെ ഒരു ചുരുക്കെഴുത്ത് മാത്രമാണ്.
///
/// `panic!` പോലെ, ഇഷ്‌ടാനുസൃത മൂല്യങ്ങൾ പ്രദർശിപ്പിക്കുന്നതിന് ഈ മാക്രോയ്ക്ക് രണ്ടാമത്തെ ഫോം ഉണ്ട്.
///
/// # Examples
///
/// ഞങ്ങൾക്ക് ഒരു trait `Foo` ഉണ്ടെന്ന് പറയുക:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// 'MyStruct'-നായി `Foo` നടപ്പിലാക്കാൻ ഞങ്ങൾ ആഗ്രഹിക്കുന്നു, പക്ഷേ ചില കാരണങ്ങളാൽ `bar()` ഫംഗ്ഷൻ നടപ്പിലാക്കുന്നതിൽ അർത്ഥമുണ്ട്.
/// `baz()` ഞങ്ങളുടെ `Foo` നടപ്പിലാക്കുന്നതിൽ `qux()` നിർവചിക്കേണ്ടതുണ്ട്, പക്ഷേ ഞങ്ങളുടെ കോഡ് കംപൈൽ ചെയ്യാൻ അനുവദിക്കുന്നതിന് അവയുടെ നിർവചനങ്ങളിൽ ഞങ്ങൾക്ക് `unimplemented!` ഉപയോഗിക്കാം.
///
/// നടപ്പിലാക്കാത്ത രീതികൾ എത്തിയിട്ടുണ്ടെങ്കിൽ ഞങ്ങളുടെ പ്രോഗ്രാം പ്രവർത്തിക്കുന്നത് നിർത്താൻ ഞങ്ങൾ ഇപ്പോഴും ആഗ്രഹിക്കുന്നു.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // `baz` ഒരു `MyStruct` എന്നതിന് ഇത് അർത്ഥമാക്കുന്നില്ല, അതിനാൽ ഞങ്ങൾക്ക് ഇവിടെ ഒരു യുക്തിയും ഇല്ല.
/////
///         // ഇത് "thread 'main' panicked at 'not implemented'" പ്രദർശിപ്പിക്കും.
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // ഞങ്ങൾക്ക് ഇവിടെ ചില യുക്തികളുണ്ട്, നടപ്പിലാക്കാത്തവയിലേക്ക് ഞങ്ങൾക്ക് ഒരു സന്ദേശം ചേർക്കാൻ കഴിയും!ഞങ്ങളുടെ ഒഴിവാക്കൽ പ്രദർശിപ്പിക്കുന്നതിന്.
///         // ഇത് പ്രദർശിപ്പിക്കും: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// പൂർത്തിയാകാത്ത കോഡ് സൂചിപ്പിക്കുന്നു.
///
/// നിങ്ങൾ പ്രോട്ടോടൈപ്പിംഗ് നടത്തുകയും കോഡ് ടൈപ്പ് ചെക്ക് നേടാൻ നോക്കുകയും ചെയ്യുന്നുവെങ്കിൽ ഇത് ഉപയോഗപ്രദമാകും.
///
/// [`unimplemented!`] ഉം `todo!` ഉം തമ്മിലുള്ള വ്യത്യാസം `todo!` പിന്നീട് പ്രവർത്തനം നടപ്പിലാക്കാനുള്ള ഉദ്ദേശ്യം അറിയിക്കുകയും സന്ദേശം "not yet implemented" ആണെങ്കിൽ, `unimplemented!` അത്തരം ക്ലെയിമുകളൊന്നും നൽകുന്നില്ല എന്നതാണ്.
/// അതിന്റെ സന്ദേശം "not implemented" ആണ്.
/// ചില IDE-കൾ `ടോഡോ! 'എന്ന് അടയാളപ്പെടുത്തും.
///
/// # Panics
///
/// ഇത് എല്ലായ്പ്പോഴും [`panic!`] ആയിരിക്കും.
///
/// # Examples
///
/// പുരോഗതിയിലുള്ള ചില കോഡിന്റെ ഒരു ഉദാഹരണം ഇതാ.ഞങ്ങൾക്ക് ഒരു trait `Foo` ഉണ്ട്:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// ഞങ്ങളുടെ ഒരു തരത്തിൽ `Foo` നടപ്പിലാക്കാൻ ഞങ്ങൾ ആഗ്രഹിക്കുന്നു, പക്ഷേ ആദ്യം `bar()`-ൽ പ്രവർത്തിക്കാനും ഞങ്ങൾ ആഗ്രഹിക്കുന്നു.ഞങ്ങളുടെ കോഡ് കംപൈൽ ചെയ്യുന്നതിന്, ഞങ്ങൾ `baz()` നടപ്പിലാക്കേണ്ടതുണ്ട്, അതിനാൽ നമുക്ക് `todo!` ഉപയോഗിക്കാം:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // നടപ്പാക്കൽ ഇവിടെ പോകുന്നു
///     }
///
///     fn baz(&self) {
///         // ഇപ്പോൾ baz() നടപ്പിലാക്കുന്നതിനെക്കുറിച്ച് വിഷമിക്കേണ്ട
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // ഞങ്ങൾ baz() പോലും ഉപയോഗിക്കുന്നില്ല, അതിനാൽ ഇത് മികച്ചതാണ്.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// അന്തർനിർമ്മിത മാക്രോകളുടെ നിർവചനങ്ങൾ.
///
/// മിക്ക മാക്രോ പ്രോപ്പർട്ടികളും (സ്ഥിരത, ദൃശ്യപരത മുതലായവ) ഇവിടെയുള്ള സോഴ്‌സ് കോഡിൽ നിന്നാണ് എടുത്തത്, മാക്രോ ഇൻപുട്ടുകൾ p ട്ട്‌പുട്ടുകളായി പരിവർത്തനം ചെയ്യുന്ന വിപുലീകരണ പ്രവർത്തനങ്ങൾ ഒഴികെ, ആ പ്രവർത്തനങ്ങൾ കംപൈലർ നൽകുന്നു.
///
///
pub(crate) mod builtin {

    /// നേരിടുമ്പോൾ നൽകിയ പിശക് സന്ദേശവുമായി സമാഹാരം പരാജയപ്പെടാൻ കാരണമാകുന്നു.
    ///
    /// തെറ്റായ അവസ്ഥകൾ‌ക്കായി മികച്ച പിശക് സന്ദേശങ്ങൾ‌നൽ‌കുന്നതിന് ഒരു crate ഒരു സോപാധിക സമാഹരണ തന്ത്രം ഉപയോഗിക്കുമ്പോൾ‌ഈ മാക്രോ ഉപയോഗിക്കണം.
    ///
    /// ഇത് [`panic!`]-ന്റെ കംപൈലർ ലെവൽ രൂപമാണ്, പക്ഷേ *റൺടൈം* എന്നതിനേക്കാൾ *സമാഹരണ സമയത്ത്* ഒരു പിശക് പുറപ്പെടുവിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// മാക്രോകളും എക്സ് 100 എക്സ് പരിതസ്ഥിതികളും അത്തരം രണ്ട് ഉദാഹരണങ്ങളാണ്.
    ///
    /// ഒരു മാക്രോ അസാധുവായ മൂല്യങ്ങൾ കൈമാറുകയാണെങ്കിൽ മികച്ച കംപൈലർ പിശക് പുറപ്പെടുവിക്കുക.
    /// അവസാന branch ഇല്ലാതെ, കംപൈലർ ഇപ്പോഴും ഒരു പിശക് പുറപ്പെടുവിക്കും, പക്ഷേ പിശകിന്റെ സന്ദേശത്തിൽ സാധുവായ രണ്ട് മൂല്യങ്ങൾ പരാമർശിക്കില്ല.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// നിരവധി സവിശേഷതകളിലൊന്ന് ലഭ്യമല്ലെങ്കിൽ കംപൈലർ പിശക് പുറത്തുവിടുക.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// മറ്റ് സ്ട്രിംഗ്-ഫോർമാറ്റിംഗ് മാക്രോകൾക്കായി പാരാമീറ്ററുകൾ നിർമ്മിക്കുന്നു.
    ///
    /// കടന്നുപോയ ഓരോ അധിക ആർഗ്യുമെന്റിനും `{}` അടങ്ങിയ ഫോർമാറ്റിംഗ് സ്ട്രിംഗ് അക്ഷരാർത്ഥത്തിൽ എടുത്ത് ഈ മാക്രോ പ്രവർത്തിക്കുന്നു.
    /// `format_args!` output ട്ട്‌പുട്ടിനെ ഒരു സ്‌ട്രിംഗായി വ്യാഖ്യാനിക്കാൻ കഴിയുമെന്ന് ഉറപ്പാക്കുന്നതിന് അധിക പാരാമീറ്ററുകൾ തയ്യാറാക്കുകയും ആർഗ്യുമെന്റുകളെ ഒരൊറ്റ തരത്തിലേക്ക് കാനോനിക്കലൈസ് ചെയ്യുകയും ചെയ്യുന്നു.
    /// [`Display`] trait നടപ്പിലാക്കുന്ന ഏത് മൂല്യവും `format_args!` ലേക്ക് കൈമാറാൻ കഴിയും, അതുപോലെ തന്നെ [`Debug`] നടപ്പിലാക്കൽ ഫോർമാറ്റിംഗ് സ്ട്രിംഗിനുള്ളിൽ ഒരു `{:?}` ലേക്ക് കൈമാറാൻ കഴിയും.
    ///
    ///
    /// ഈ മാക്രോ തരം [`fmt::Arguments`] ന്റെ മൂല്യം ഉൽ‌പാദിപ്പിക്കുന്നു.ഉപയോഗപ്രദമായ റീഡയറക്ഷൻ ചെയ്യുന്നതിന് ഈ മൂല്യം [`std::fmt`]-നുള്ളിലെ മാക്രോകളിലേക്ക് കൈമാറാൻ കഴിയും.
    /// മറ്റെല്ലാ ഫോർമാറ്റിംഗ് മാക്രോകളും ([`ഫോർമാറ്റ്!`], [`write!`], [`println!`], മുതലായവ) ഇതിലൂടെ പ്രോക്സി ചെയ്യുന്നു.
    /// `format_args!`, അതിന്റെ മാക്രോകളിൽ നിന്ന് വ്യത്യസ്തമായി, കൂമ്പാര വിഹിതം ഒഴിവാക്കുന്നു.
    ///
    /// ചുവടെ കാണുന്നതുപോലെ `Debug`, `Display` സന്ദർഭങ്ങളിൽ `format_args!` നൽകുന്ന [`fmt::Arguments`] മൂല്യം നിങ്ങൾക്ക് ഉപയോഗിക്കാൻ കഴിയും.
    /// `Debug`, `Display` ഫോർമാറ്റ് ഒരേ കാര്യത്തിലാണെന്നും ഉദാഹരണം കാണിക്കുന്നു: `format_args!`-ലെ ഇന്റർപോളേറ്റഡ് ഫോർമാറ്റ് സ്ട്രിംഗ്.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// കൂടുതൽ വിവരങ്ങൾക്ക്, [`std::fmt`]-ലെ ഡോക്യുമെന്റേഷൻ കാണുക.
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// `format_args` പോലെ തന്നെ, പക്ഷേ അവസാനം ഒരു പുതിയ ലൈൻ ചേർക്കുന്നു.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// കംപൈൽ സമയത്ത് ഒരു പരിസ്ഥിതി വേരിയബിൾ പരിശോധിക്കുന്നു.
    ///
    /// ഈ മാക്രോ കംപൈൽ സമയത്ത് പേരിട്ട എൻവയോൺമെന്റ് വേരിയബിളിന്റെ മൂല്യത്തിലേക്ക് വികസിപ്പിക്കും, ഇത് `&'static str` തരം എക്സ്പ്രഷൻ നൽകുന്നു.
    ///
    ///
    /// എൻ‌വയോൺ‌മെൻറ് വേരിയബിൾ‌നിർ‌വ്വചിച്ചിട്ടില്ലെങ്കിൽ‌, ഒരു സമാഹരണ പിശക് പുറപ്പെടുവിക്കും.
    /// ഒരു കംപൈൽ പിശക് പുറത്തുവിടാതിരിക്കാൻ, പകരം [`option_env!`] മാക്രോ ഉപയോഗിക്കുക.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// രണ്ടാമത്തെ പാരാമീറ്ററായി ഒരു സ്ട്രിംഗ് നൽകി നിങ്ങൾക്ക് പിശക് സന്ദേശം ഇച്ഛാനുസൃതമാക്കാൻ കഴിയും:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// `documentation` എൻ‌വയോൺ‌മെൻറ് വേരിയബിൾ‌നിർ‌വ്വചിച്ചിട്ടില്ലെങ്കിൽ‌, നിങ്ങൾ‌ക്ക് ഇനിപ്പറയുന്ന പിശക് ലഭിക്കും:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// കംപൈൽ സമയത്ത് ഒരു എൻവയോൺമെന്റ് വേരിയബിൾ ഓപ്ഷണലായി പരിശോധിക്കുന്നു.
    ///
    /// കംപൈൽ സമയത്ത് പേരുള്ള എൻ‌വയോൺ‌മെൻറ് വേരിയബിൾ‌ഉണ്ടെങ്കിൽ‌, ഇത് എൻ‌വയോൺ‌മെൻറ് വേരിയബിളിന്റെ മൂല്യത്തിന്റെ `Some` ആയ `Option<&'static str>` തരം എക്സ്പ്രഷനായി വികസിക്കും.
    /// എൻ‌വയോൺ‌മെൻറ് വേരിയബിൾ‌ഇല്ലെങ്കിൽ‌, ഇത് `None` ലേക്ക് വികസിക്കും.
    /// ഈ തരത്തെക്കുറിച്ചുള്ള കൂടുതൽ വിവരങ്ങൾക്ക് [`Option<T>`][Option] കാണുക.
    ///
    /// പരിസ്ഥിതി വേരിയബിൾ ഉണ്ടോ ഇല്ലയോ എന്നത് പരിഗണിക്കാതെ ഈ മാക്രോ ഉപയോഗിക്കുമ്പോൾ ഒരു കംപൈൽ സമയ പിശക് ഒരിക്കലും പുറത്തുവിടില്ല.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ഐഡന്റിഫയറുകളെ ഒരു ഐഡന്റിഫയറിലേക്ക് സംയോജിപ്പിക്കുന്നു.
    ///
    /// ഈ മാക്രോ കോമയാൽ വേർതിരിച്ച എത്ര ഐഡന്റിഫയറുകളെ എടുക്കുകയും അവയെല്ലാം ഒന്നായി സംയോജിപ്പിക്കുകയും ചെയ്യുന്നു, ഇത് ഒരു പുതിയ ഐഡന്റിഫയറായ ഒരു പദപ്രയോഗം നൽകുന്നു.
    /// ഈ മാക്രോയ്ക്ക് ലോക്കൽ വേരിയബിളുകൾ പിടിച്ചെടുക്കാൻ കഴിയാത്തവിധം ശുചിത്വം അതിനെ സഹായിക്കുന്നു എന്നത് ശ്രദ്ധിക്കുക.
    /// കൂടാതെ, പൊതുവായ ചട്ടം പോലെ, ഇനം, പ്രസ്താവന അല്ലെങ്കിൽ എക്സ്പ്രഷൻ സ്ഥാനത്ത് മാത്രമേ മാക്രോകൾ അനുവദിക്കൂ.
    /// ഇതിനർത്ഥം നിലവിലുള്ള വേരിയബിളുകൾ‌, ഫംഗ്ഷനുകൾ‌അല്ലെങ്കിൽ‌മൊഡ്യൂളുകൾ‌എന്നിവ പരാമർശിക്കുന്നതിന് നിങ്ങൾ‌ഈ മാക്രോ ഉപയോഗിക്കുമെങ്കിലും, പുതിയൊരെണ്ണം നിർ‌വ്വചിക്കാൻ‌നിങ്ങൾ‌ക്ക് കഴിയില്ല.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (പുതിയത്, തമാശ, പേര്) { }//ഈ രീതിയിൽ ഉപയോഗയോഗ്യമല്ല!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// അക്ഷരത്തെ ഒരു സ്റ്റാറ്റിക് സ്‌ട്രിംഗ് സ്ലൈസായി സംയോജിപ്പിക്കുന്നു.
    ///
    /// ഈ മാക്രോ കോമയാൽ വേർതിരിച്ച ഏതൊരു ലിറ്ററലുകളെയും എടുക്കുന്നു, ഇത് `&'static str` തരം പ്രകടിപ്പിക്കുന്നു, ഇത് ഇടത്തോട്ടും വലത്തോട്ടും ഒത്തുചേർന്ന എല്ലാ അക്ഷരങ്ങളെയും പ്രതിനിധീകരിക്കുന്നു.
    ///
    ///
    /// സംയോജിതമാകുന്നതിന് ഇന്റീജറും ഫ്ലോട്ടിംഗ് പോയിൻറ് ലിറ്ററലുകളും കർശനമാക്കിയിരിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// അത് അഭ്യർത്ഥിച്ച ലൈൻ നമ്പറിലേക്ക് വികസിക്കുന്നു.
    ///
    /// [`column!`], [`file!`] എന്നിവ ഉപയോഗിച്ച്, ഈ മാക്രോകൾ ഡവലപ്പർമാർക്ക് ഉറവിടത്തിനുള്ളിലെ സ്ഥാനത്തെക്കുറിച്ച് ഡീബഗ്ഗിംഗ് വിവരങ്ങൾ നൽകുന്നു.
    ///
    /// വികസിപ്പിച്ച എക്‌സ്‌പ്രഷന് തരം `u32` ഉണ്ട്, അത് 1 അടിസ്ഥാനമാക്കിയുള്ളതാണ്, അതിനാൽ ഓരോ ഫയലിലെയും ആദ്യ വരി 1, രണ്ടാമത്തേത് 2 എന്നിങ്ങനെ വിലയിരുത്തുന്നു.
    /// സാധാരണ കംപൈലർമാരുടെയോ ജനപ്രിയ എഡിറ്റർമാരുടെയോ പിശക് സന്ദേശങ്ങളുമായി ഇത് പൊരുത്തപ്പെടുന്നു.
    /// മടങ്ങിയ വരി `line!` ഇൻവോക്കേഷന്റെ വരിയാണ് *ആവശ്യമില്ല*, മറിച്ച് `line!` മാക്രോയുടെ ഇൻവോക്കേഷനിലേയ്ക്ക് നയിക്കുന്ന ആദ്യത്തെ മാക്രോ ഇൻവോക്കേഷൻ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// അത് അഭ്യർത്ഥിച്ച നിര നമ്പറിലേക്ക് വികസിപ്പിക്കുന്നു.
    ///
    /// [`line!`], [`file!`] എന്നിവ ഉപയോഗിച്ച്, ഈ മാക്രോകൾ ഡവലപ്പർമാർക്ക് ഉറവിടത്തിനുള്ളിലെ സ്ഥാനത്തെക്കുറിച്ച് ഡീബഗ്ഗിംഗ് വിവരങ്ങൾ നൽകുന്നു.
    ///
    /// വികസിപ്പിച്ച എക്‌സ്‌പ്രഷന് തരം `u32` ഉണ്ട്, അത് 1 അടിസ്ഥാനമാക്കിയുള്ളതാണ്, അതിനാൽ ഓരോ വരിയിലെയും ആദ്യ നിര 1, രണ്ടാമത്തേത് 2 എന്നിങ്ങനെ വിലയിരുത്തുന്നു.
    /// സാധാരണ കംപൈലർമാരുടെയോ ജനപ്രിയ എഡിറ്റർമാരുടെയോ പിശക് സന്ദേശങ്ങളുമായി ഇത് പൊരുത്തപ്പെടുന്നു.
    /// മടങ്ങിയ നിര `column!` ഇൻ‌വോക്കേഷന്റെ വരി * ആയിരിക്കണമെന്നില്ല, മറിച്ച് `column!` മാക്രോയുടെ ഇൻ‌വോക്കേഷനിലേക്ക് നയിക്കുന്ന ആദ്യത്തെ മാക്രോ ഇൻ‌വോക്കേഷനാണ്.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// അത് അഭ്യർത്ഥിച്ച ഫയൽ നാമത്തിലേക്ക് വികസിപ്പിക്കുന്നു.
    ///
    /// [`line!`], [`column!`] എന്നിവ ഉപയോഗിച്ച്, ഈ മാക്രോകൾ ഡവലപ്പർമാർക്ക് ഉറവിടത്തിനുള്ളിലെ സ്ഥാനത്തെക്കുറിച്ച് ഡീബഗ്ഗിംഗ് വിവരങ്ങൾ നൽകുന്നു.
    ///
    /// വിപുലീകരിച്ച എക്‌സ്‌പ്രഷന് `&'static str` തരം ഉണ്ട്, മടങ്ങിയ ഫയൽ `file!` മാക്രോയുടെ തന്നെ അഭ്യർത്ഥനയല്ല, മറിച്ച് `file!` മാക്രോയുടെ അഭ്യർത്ഥനയിലേക്ക് നയിക്കുന്ന ആദ്യത്തെ മാക്രോ ഇൻവോക്കേഷനാണ്.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// അതിന്റെ വാദഗതികളെ ശക്തമാക്കുന്നു.
    ///
    /// ഈ മാക്രോ തരം `&'static str` ന്റെ ഒരു എക്സ്പ്രഷൻ നൽകും, ഇത് മാക്രോയിലേക്ക് കൈമാറിയ എല്ലാ tokens ന്റെയും സ്ട്രിഫിക്കേഷനാണ്.
    /// മാക്രോ ഇൻവോക്കേഷന്റെ വാക്യഘടനയിൽ തന്നെ നിയന്ത്രണങ്ങളൊന്നും ഏർപ്പെടുത്തിയിട്ടില്ല.
    ///
    /// tokens ഇൻ‌പുട്ടിന്റെ വിപുലീകരിച്ച ഫലങ്ങൾ‌future ൽ‌മാറിയേക്കാം.നിങ്ങൾ .ട്ട്‌പുട്ടിനെ ആശ്രയിക്കുന്നുവെങ്കിൽ നിങ്ങൾ ശ്രദ്ധിക്കണം.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// ഒരു സ്ട്രിംഗായി UTF-8 എൻ‌കോഡുചെയ്‌ത ഫയൽ ഉൾപ്പെടുന്നു.
    ///
    /// നിലവിലെ ഫയലുമായി താരതമ്യപ്പെടുത്തുമ്പോൾ ഫയൽ സ്ഥിതിചെയ്യുന്നു (മൊഡ്യൂളുകൾ എങ്ങനെ കണ്ടെത്തും എന്നതിന് സമാനമായി).
    /// നൽകിയ പാത്ത് കംപൈൽ സമയത്ത് ഒരു പ്ലാറ്റ്ഫോം നിർദ്ദിഷ്ട രീതിയിൽ വ്യാഖ്യാനിക്കുന്നു.
    /// അതിനാൽ, ഉദാഹരണത്തിന്, Windows ബാക്ക്‌സ്ലാഷുകൾ അടങ്ങിയ Windows പാത്ത് ഉള്ള ഒരു അഭ്യർത്ഥന Unix-ൽ ശരിയായി കംപൈൽ ചെയ്യില്ല.
    ///
    ///
    /// ഈ മാക്രോ ഫയലിന്റെ ഉള്ളടക്കമായ `&'static str` തരം എക്സ്പ്രഷൻ നൽകും.
    ///
    /// # Examples
    ///
    /// ഇനിപ്പറയുന്ന ഉള്ളടക്കങ്ങളുള്ള ഒരേ ഡയറക്ടറിയിൽ രണ്ട് ഫയലുകൾ ഉണ്ടെന്ന് കരുതുക:
    ///
    /// ഫയൽ 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// ഫയൽ 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// 'main.rs' കംപൈൽ ചെയ്യുകയും ഫലമായുണ്ടാകുന്ന ബൈനറി പ്രവർത്തിപ്പിക്കുകയും ചെയ്യുന്നത് "adiós" പ്രിന്റുചെയ്യും.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// ഒരു ബൈറ്റ് അറേയിലേക്കുള്ള റഫറൻസായി ഒരു ഫയൽ ഉൾപ്പെടുന്നു.
    ///
    /// നിലവിലെ ഫയലുമായി താരതമ്യപ്പെടുത്തുമ്പോൾ ഫയൽ സ്ഥിതിചെയ്യുന്നു (മൊഡ്യൂളുകൾ എങ്ങനെ കണ്ടെത്തും എന്നതിന് സമാനമായി).
    /// നൽകിയ പാത്ത് കംപൈൽ സമയത്ത് ഒരു പ്ലാറ്റ്ഫോം നിർദ്ദിഷ്ട രീതിയിൽ വ്യാഖ്യാനിക്കുന്നു.
    /// അതിനാൽ, ഉദാഹരണത്തിന്, Windows ബാക്ക്‌സ്ലാഷുകൾ അടങ്ങിയ Windows പാത്ത് ഉള്ള ഒരു അഭ്യർത്ഥന Unix-ൽ ശരിയായി കംപൈൽ ചെയ്യില്ല.
    ///
    ///
    /// ഈ മാക്രോ ഫയലിന്റെ ഉള്ളടക്കമായ `&'static [u8; N]` തരം എക്സ്പ്രഷൻ നൽകും.
    ///
    /// # Examples
    ///
    /// ഇനിപ്പറയുന്ന ഉള്ളടക്കങ്ങളുള്ള ഒരേ ഡയറക്ടറിയിൽ രണ്ട് ഫയലുകൾ ഉണ്ടെന്ന് കരുതുക:
    ///
    /// ഫയൽ 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// ഫയൽ 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// 'main.rs' കംപൈൽ ചെയ്യുകയും ഫലമായുണ്ടാകുന്ന ബൈനറി പ്രവർത്തിപ്പിക്കുകയും ചെയ്യുന്നത് "adiós" പ്രിന്റുചെയ്യും.
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// നിലവിലെ മൊഡ്യൂൾ പാതയെ പ്രതിനിധീകരിക്കുന്ന ഒരു സ്ട്രിംഗിലേക്ക് വികസിക്കുന്നു.
    ///
    /// നിലവിലെ മൊഡ്യൂൾ പാത crate root ലേക്ക് തിരികെ നയിക്കുന്ന മൊഡ്യൂളുകളുടെ ശ്രേണിയായി കണക്കാക്കാം.
    /// മടങ്ങിയെത്തിയ പാതയുടെ ആദ്യ ഘടകം നിലവിൽ സമാഹരിച്ച crate ന്റെ പേരാണ്.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// കംപൈൽ സമയത്ത് കോൺഫിഗറേഷൻ ഫ്ലാഗുകളുടെ ബൂളിയൻ കോമ്പിനേഷനുകൾ വിലയിരുത്തുന്നു.
    ///
    /// `#[cfg]` ആട്രിബ്യൂട്ടിന് പുറമേ, കോൺഫിഗറേഷൻ ഫ്ലാഗുകളുടെ ബൂലിയൻ എക്സ്പ്രഷൻ വിലയിരുത്തൽ അനുവദിക്കുന്നതിനാണ് ഈ മാക്രോ നൽകിയിരിക്കുന്നത്.
    /// ഇത് പതിവായി തനിപ്പകർപ്പ് കോഡിലേക്ക് നയിക്കുന്നു.
    ///
    /// ഈ മാക്രോയ്ക്ക് നൽകിയിരിക്കുന്ന വാക്യഘടന [`cfg`] ആട്രിബ്യൂട്ടിന്റെ അതേ വാക്യഘടനയാണ്.
    ///
    /// `cfg!`, `#[cfg]` ൽ നിന്ന് വ്യത്യസ്തമായി, ഒരു കോഡും നീക്കംചെയ്യുന്നില്ല, മാത്രമല്ല ശരി അല്ലെങ്കിൽ തെറ്റ് എന്ന് മാത്രം വിലയിരുത്തുകയും ചെയ്യുന്നു.
    /// ഉദാഹരണത്തിന്, `cfg!` മൂല്യനിർണ്ണയം എന്തുതന്നെയായാലും, X001 എക്‌സ്‌പ്രഷനിലെ എല്ലാ ബ്ലോക്കുകളും ഈ അവസ്ഥയ്ക്കായി `cfg!` ഉപയോഗിക്കുമ്പോൾ സാധുതയുള്ളതായിരിക്കണം.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// സന്ദർഭത്തിനനുസരിച്ച് ഒരു ഫയൽ എക്‌സ്‌പ്രഷനായി അല്ലെങ്കിൽ ഇനമായി പാഴ്‌സുചെയ്യുന്നു.
    ///
    /// നിലവിലെ ഫയലുമായി താരതമ്യപ്പെടുത്തുമ്പോൾ ഫയൽ സ്ഥിതിചെയ്യുന്നു (മൊഡ്യൂളുകൾ എങ്ങനെ കണ്ടെത്തും എന്നതിന് സമാനമായി).നൽകിയ പാത്ത് കംപൈൽ സമയത്ത് ഒരു പ്ലാറ്റ്ഫോം നിർദ്ദിഷ്ട രീതിയിൽ വ്യാഖ്യാനിക്കുന്നു.
    /// അതിനാൽ, ഉദാഹരണത്തിന്, Windows ബാക്ക്‌സ്ലാഷുകൾ അടങ്ങിയ Windows പാത്ത് ഉള്ള ഒരു അഭ്യർത്ഥന Unix-ൽ ശരിയായി കംപൈൽ ചെയ്യില്ല.
    ///
    /// ഈ മാക്രോ ഉപയോഗിക്കുന്നത് പലപ്പോഴും ഒരു മോശം ആശയമാണ്, കാരണം ഫയൽ ഒരു എക്‌സ്‌പ്രഷനായി പാഴ്‌സുചെയ്‌തിട്ടുണ്ടെങ്കിൽ, അത് ചുറ്റുമുള്ള കോഡിൽ വൃത്തിഹീനമായി സ്ഥാപിക്കാൻ പോകുന്നു.
    /// നിലവിലെ ഫയലിൽ ഒരേ പേരിലുള്ള വേരിയബിളുകളോ ഫംഗ്ഷനുകളോ ഉണ്ടെങ്കിൽ വേരിയബിളുകൾ അല്ലെങ്കിൽ ഫംഗ്ഷനുകൾ ഫയൽ പ്രതീക്ഷിച്ചതിൽ നിന്ന് വ്യത്യസ്തമാകാൻ ഇത് കാരണമാകും.
    ///
    ///
    /// # Examples
    ///
    /// ഇനിപ്പറയുന്ന ഉള്ളടക്കങ്ങളുള്ള ഒരേ ഡയറക്ടറിയിൽ രണ്ട് ഫയലുകൾ ഉണ്ടെന്ന് കരുതുക:
    ///
    /// ഫയൽ 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// ഫയൽ 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// 'main.rs' കംപൈൽ ചെയ്യുകയും ഫലമായുണ്ടാകുന്ന ബൈനറി പ്രവർത്തിപ്പിക്കുകയും ചെയ്യുന്നത് "🙈🙊🙉🙈🙊🙉" പ്രിന്റുചെയ്യും.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// റൺടൈമിൽ ഒരു ബൂലിയൻ എക്‌സ്‌പ്രഷൻ `true` ആണെന്ന് വാദിക്കുന്നു.
    ///
    /// നൽകിയ എക്‌സ്‌പ്രഷൻ റൺടൈമിൽ `true` ലേക്ക് വിലയിരുത്താൻ കഴിയുന്നില്ലെങ്കിൽ ഇത് [`panic!`] മാക്രോയെ അഭ്യർത്ഥിക്കും.
    ///
    /// # Uses
    ///
    /// ഡീബഗ്, റിലീസ് ബിൽഡുകൾ എന്നിവയിൽ എല്ലായ്‌പ്പോഴും അവകാശവാദങ്ങൾ പരിശോധിക്കുന്നു, അവ പ്രവർത്തനരഹിതമാക്കാനാവില്ല.
    /// സ്ഥിരസ്ഥിതിയായി റിലീസ് ബിൽഡുകളിൽ പ്രവർത്തനക്ഷമമല്ലാത്ത അവകാശവാദങ്ങൾക്കായി [`debug_assert!`] കാണുക.
    ///
    /// റൺ-ടൈം മാറ്റങ്ങൾ‌നടപ്പിലാക്കുന്നതിന് സുരക്ഷിതമല്ലാത്ത കോഡ് `assert!` നെ ആശ്രയിക്കാം, അത് ലംഘിച്ചാൽ‌സുരക്ഷിതത്വത്തിലേക്ക് നയിച്ചേക്കാം.
    ///
    /// `assert!`-ന്റെ മറ്റ് ഉപയോഗ കേസുകളിൽ റൺ-ടൈം മാറ്റങ്ങളെ സുരക്ഷിത കോഡിൽ പരീക്ഷിക്കുകയും നടപ്പിലാക്കുകയും ചെയ്യുന്നു (ഇവയുടെ ലംഘനം സുരക്ഷിതത്വത്തിന് കാരണമാകില്ല).
    ///
    ///
    /// # ഇഷ്‌ടാനുസൃത സന്ദേശങ്ങൾ
    ///
    /// ഈ മാക്രോയ്ക്ക് രണ്ടാമത്തെ ഫോം ഉണ്ട്, അവിടെ ഒരു ഇച്ഛാനുസൃത panic സന്ദേശം ഫോർമാറ്റിംഗിനായി ആർഗ്യുമെൻറുകളുമായോ അല്ലാതെയോ നൽകാം.
    /// ഈ ഫോമിനായി വാക്യഘടനയ്‌ക്കായി [`std::fmt`] കാണുക.
    /// വാദം പരാജയപ്പെട്ടാൽ മാത്രമേ ഫോർമാറ്റ് ആർഗ്യുമെന്റുകളായി ഉപയോഗിക്കുന്ന പദപ്രയോഗങ്ങൾ വിലയിരുത്തപ്പെടുകയുള്ളൂ.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // ഈ അവകാശവാദങ്ങൾക്കായുള്ള panic സന്ദേശം നൽകിയിരിക്കുന്ന പദപ്രയോഗത്തിന്റെ കർശന മൂല്യമാണ്.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // വളരെ ലളിതമായ പ്രവർത്തനം
    ///
    /// assert!(some_computation());
    ///
    /// // ഒരു ഇഷ്‌ടാനുസൃത സന്ദേശം ഉപയോഗിച്ച് ഉറപ്പിക്കുക
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// ഇൻലൈൻ അസംബ്ലി.
    ///
    /// ഉപയോഗത്തിനായി [unstable book] വായിക്കുക.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// എൽ‌എൽ‌വി‌എം-ശൈലിയിലുള്ള ഇൻ‌ലൈൻ അസംബ്ലി.
    ///
    /// ഉപയോഗത്തിനായി [unstable book] വായിക്കുക.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// മൊഡ്യൂൾ-ലെവൽ ഇൻലൈൻ അസംബ്ലി.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// സ്റ്റാൻഡേർഡ് .ട്ട്‌പുട്ടിലേക്ക് പ്രിന്റുകൾ tokens കടന്നു.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// മറ്റ് മാക്രോകൾ ഡീബഗ്ഗ് ചെയ്യുന്നതിന് ഉപയോഗിക്കുന്ന ട്രെയ്‌സിംഗ് പ്രവർത്തനം പ്രവർത്തനക്ഷമമാക്കുകയോ പ്രവർത്തനരഹിതമാക്കുകയോ ചെയ്യുന്നു.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// ഡെറിവ് മാക്രോകൾ പ്രയോഗിക്കാൻ ഉപയോഗിക്കുന്ന ആട്രിബ്യൂട്ട് മാക്രോ.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// ഒരു ഫംഗ്ഷനെ യൂണിറ്റ് ടെസ്റ്റാക്കി മാറ്റുന്നതിന് ആട്രിബ്യൂട്ട് മാക്രോ പ്രയോഗിച്ചു.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// ഒരു ഫംഗ്ഷനെ ഒരു ബെഞ്ച്മാർക്ക് ടെസ്റ്റാക്കി മാറ്റുന്നതിന് ആട്രിബ്യൂട്ട് മാക്രോ പ്രയോഗിച്ചു.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// `#[test]`, `#[bench]` മാക്രോകളുടെ നടപ്പാക്കൽ വിശദാംശങ്ങൾ.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// ഒരു ആഗോള അലോക്കേറ്ററായി രജിസ്റ്റർ ചെയ്യുന്നതിന് ആട്രിബ്യൂട്ട് മാക്രോ ഒരു സ്റ്റാറ്റിക്ക് പ്രയോഗിച്ചു.
    ///
    /// [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html) ഉം കാണുക.
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// കടന്നുപോയ പാത്ത് ആക്‌സസ് ചെയ്യാൻ കഴിയുമെങ്കിൽ അത് പ്രയോഗിച്ച ഇനം സൂക്ഷിക്കുന്നു, അല്ലെങ്കിൽ അത് നീക്കംചെയ്യുന്നു.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// ഇത് പ്രയോഗിച്ച കോഡ് ശകലത്തിലെ എല്ലാ `#[cfg]`, `#[cfg_attr]` ആട്രിബ്യൂട്ടുകളും വികസിപ്പിക്കുന്നു.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// `rustc` കംപൈലറിന്റെ അസ്ഥിരമായ നടപ്പാക്കൽ വിശദാംശങ്ങൾ ഉപയോഗിക്കരുത്.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// `rustc` കംപൈലറിന്റെ അസ്ഥിരമായ നടപ്പാക്കൽ വിശദാംശങ്ങൾ ഉപയോഗിക്കരുത്.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}