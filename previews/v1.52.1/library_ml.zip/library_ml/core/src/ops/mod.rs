//! ഓവർലോഡ് ചെയ്യാവുന്ന ഓപ്പറേറ്റർമാർ.
//!
//! ഈ traits നടപ്പിലാക്കുന്നത് ചില ഓപ്പറേറ്റർമാരെ ഓവർലോഡ് ചെയ്യാൻ നിങ്ങളെ അനുവദിക്കുന്നു.
//!
//! ഇവയിൽ ചില traits ഇറക്കുമതി ചെയ്യുന്നത് prelude ആണ്, അതിനാൽ അവ ഓരോ Rust പ്രോഗ്രാമിലും ലഭ്യമാണ്.traits ന്റെ പിന്തുണയുള്ള ഓപ്പറേറ്റർ‌മാർ‌ക്ക് മാത്രമേ ഓവർ‌ലോഡ് ചെയ്യാൻ‌കഴിയൂ.
//! ഉദാഹരണത്തിന്,(`+`) എന്ന സങ്കലന ഓപ്പറേറ്റർ [`Add`] trait വഴി ഓവർ‌ലോഡ് ചെയ്യാൻ‌കഴിയും, പക്ഷേ അസൈൻ‌മെന്റ് ഓപ്പറേറ്റർ‌(`=`) ന് trait ന്റെ പിന്തുണയില്ലാത്തതിനാൽ‌, അതിന്റെ സെമാന്റിക്സ് ഓവർ‌ലോഡ് ചെയ്യുന്നതിന് ഒരു വഴിയുമില്ല.
//! കൂടാതെ, പുതിയ ഓപ്പറേറ്റർമാരെ സൃഷ്ടിക്കുന്നതിനുള്ള ഒരു സംവിധാനവും ഈ മൊഡ്യൂൾ നൽകുന്നില്ല.
//! സ്വഭാവരഹിതമായ ഓവർലോഡിംഗ് അല്ലെങ്കിൽ ഇഷ്‌ടാനുസൃത ഓപ്പറേറ്റർമാർ ആവശ്യമാണെങ്കിൽ, Rust-ന്റെ വാക്യഘടന വിപുലീകരിക്കുന്നതിന് നിങ്ങൾ മാക്രോകൾ അല്ലെങ്കിൽ കംപൈലർ പ്ലഗിന്നുകളിലേക്ക് നോക്കണം.
//!
//! traits ഓപ്പറേറ്ററുടെ നടപ്പാക്കലുകൾ അതാത് സന്ദർഭങ്ങളിൽ ആശ്ചര്യകരമല്ല, അവയുടെ സാധാരണ അർത്ഥങ്ങളും [operator precedence] ഉം കണക്കിലെടുക്കുക.
//! ഉദാഹരണത്തിന്, [`Mul`] നടപ്പിലാക്കുമ്പോൾ, പ്രവർത്തനത്തിന് ഗുണനവുമായി ചില സാമ്യത ഉണ്ടായിരിക്കണം (കൂടാതെ അസോസിയേറ്റിവിറ്റി പോലുള്ള പ്രതീക്ഷിച്ച സവിശേഷതകൾ പങ്കിടുക).
//!
//! `&&`, `||` ഓപ്പറേറ്റർമാർ ഷോർട്ട് സർക്യൂട്ട് ശ്രദ്ധിക്കുക, അതായത്, ഫലത്തിൽ സംഭാവന നൽകിയാൽ മാത്രമേ അവരുടെ രണ്ടാമത്തെ പ്രവർത്തനം വിലയിരുത്തുകയുള്ളൂ.ഈ സ്വഭാവം traits നടപ്പിലാക്കാൻ കഴിയാത്തതിനാൽ, ഓവർലോഡ് ചെയ്യാവുന്ന ഓപ്പറേറ്റർമാരായി `&&`, `||` എന്നിവ പിന്തുണയ്ക്കുന്നില്ല.
//!
//! പല ഓപ്പറേറ്റർമാരും അവരുടെ പ്രവർത്തനങ്ങളെ മൂല്യത്തിനനുസരിച്ച് എടുക്കുന്നു.അന്തർനിർമ്മിത തരങ്ങൾ ഉൾപ്പെടുന്ന ജനറിക് അല്ലാത്ത സന്ദർഭങ്ങളിൽ, ഇത് സാധാരണയായി ഒരു പ്രശ്‌നമല്ല.
//! എന്നിരുന്നാലും, ഈ ഓപ്പറേറ്റർ‌മാരെ ജനറിക് കോഡിൽ‌ഉപയോഗിക്കുന്നതിന്, ഓപ്പറേറ്റർ‌മാർ‌അവ ഉപയോഗിക്കാൻ‌അനുവദിക്കുന്നതിന് വിരുദ്ധമായി മൂല്യങ്ങൾ‌വീണ്ടും ഉപയോഗിക്കേണ്ടതുണ്ടെങ്കിൽ‌കുറച്ച് ശ്രദ്ധ ആവശ്യമാണ്.ഇടയ്ക്കിടെ [`clone`] ഉപയോഗിക്കുക എന്നതാണ് ഒരു ഓപ്ഷൻ.
//! റഫറൻ‌സുകൾ‌ക്കായി അധിക ഓപ്പറേറ്റർ‌നടപ്പാക്കലുകൾ‌നൽ‌കുന്ന തരങ്ങളെ ആശ്രയിക്കുക എന്നതാണ് മറ്റൊരു ഓപ്ഷൻ.
//! ഉദാഹരണത്തിന്, കൂട്ടിച്ചേർക്കലിനെ പിന്തുണയ്‌ക്കേണ്ട ഉപയോക്തൃ-നിർവചിത തരം `T`-ന്, `T`, `&T` എന്നിവ traits [`Add<T>`][`Add`], [`Add<&T>`][`Add`] എന്നിവ നടപ്പിലാക്കുന്നത് നല്ലതാണ്, അതിനാൽ അനാവശ്യ ക്ലോണിംഗ് ഇല്ലാതെ ജനറിക് കോഡ് എഴുതാൻ കഴിയും.
//!
//!
//! # Examples
//!
//! ഈ ഉദാഹരണം [`Add`], [`Sub`] എന്നിവ നടപ്പിലാക്കുന്ന ഒരു `Point` സ്ട്രക്റ്റ് സൃഷ്ടിക്കുന്നു, തുടർന്ന് രണ്ട് `പോയിൻറുകൾ‌'ചേർക്കുന്നതും കുറയ്ക്കുന്നതും കാണിക്കുന്നു.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! ഒരു ഉദാഹരണ നടപ്പാക്കലിനായി ഓരോ trait നായുള്ള ഡോക്യുമെന്റേഷൻ കാണുക.
//!
//! [`Fn`], [`FnMut`], [`FnOnce`] traits എന്നിവ ഫംഗ്ഷനുകൾ പോലെ അഭ്യർത്ഥിക്കാൻ കഴിയുന്ന തരത്തിലാണ് നടപ്പിലാക്കുന്നത്.[`Fn`] `&self` ഉം [`FnMut`] `&mut self` ഉം [`FnOnce`] `self` ഉം എടുക്കുന്നു എന്നത് ശ്രദ്ധിക്കുക.
//! ഒരു ഉദാഹരണത്തിൽ അഭ്യർത്ഥിക്കാൻ കഴിയുന്ന മൂന്ന് തരം രീതികളുമായി ഇവ പൊരുത്തപ്പെടുന്നു: കോൾ-ബൈ-റഫറൻസ്, കോൾ-ബൈ-മ്യൂട്ടബിൾ-റഫറൻസ്, കോൾ-ബൈ-മൂല്യം.
//! ഈ traits ന്റെ ഏറ്റവും സാധാരണമായ ഉപയോഗം ഫംഗ്ഷനുകളോ ക്ലോസറുകളോ ആർഗ്യുമെന്റുകളായി എടുക്കുന്ന ഉയർന്ന ലെവൽ ഫംഗ്ഷനുകളുടെ അതിരുകളായി പ്രവർത്തിക്കുക എന്നതാണ്.
//!
//! ഒരു പാരാമീറ്ററായി [`Fn`] എടുക്കുന്നു:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! ഒരു പാരാമീറ്ററായി [`FnMut`] എടുക്കുന്നു:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! ഒരു പാരാമീറ്ററായി [`FnOnce`] എടുക്കുന്നു:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` പിടിച്ചെടുത്ത വേരിയബിളുകൾ ഉപയോഗിക്കുന്നു, അതിനാൽ ഇത് ഒന്നിലധികം തവണ പ്രവർത്തിപ്പിക്കാൻ കഴിയില്ല
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // `func()` വീണ്ടും അഭ്യർത്ഥിക്കാൻ ശ്രമിക്കുന്നത് `func`-നായി ഒരു `use of moved value` പിശക് എറിയും
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` ഈ സമയത്ത് മേലിൽ അഭ്യർത്ഥിക്കാൻ കഴിയില്ല
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;