/// മാറ്റമില്ലാത്ത സന്ദർഭങ്ങളിൽ (`container[index]`) പ്രവർത്തനങ്ങൾ സൂചികയിലാക്കാൻ ഉപയോഗിക്കുന്നു.
///
/// `container[index]` യഥാർത്ഥത്തിൽ `*container.index(index)`-നുള്ള വാക്യഘടന പഞ്ചസാരയാണ്, പക്ഷേ മാറ്റമില്ലാത്ത മൂല്യമായി ഉപയോഗിക്കുമ്പോൾ മാത്രം.
/// ഒരു മ്യൂട്ടബിൾ മൂല്യം അഭ്യർത്ഥിച്ചിട്ടുണ്ടെങ്കിൽ, പകരം [`IndexMut`] ഉപയോഗിക്കുന്നു.
/// `value` തരം [`Copy`] നടപ്പിലാക്കുകയാണെങ്കിൽ `let value = v[index]` പോലുള്ള നല്ല കാര്യങ്ങൾ ഇത് അനുവദിക്കുന്നു.
///
/// # Examples
///
/// ഇനിപ്പറയുന്ന ഉദാഹരണം ഒരു വായന-മാത്രം `NucleotideCount` കണ്ടെയ്നറിൽ `Index` നടപ്പിലാക്കുന്നു, ഇത് വ്യക്തിഗത എണ്ണം സൂചിക സിന്റാക്സ് ഉപയോഗിച്ച് വീണ്ടെടുക്കാൻ പ്രാപ്തമാക്കുന്നു.
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// സൂചികയിലാക്കിയ ശേഷം മടങ്ങിയ തരം.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// ഇൻഡെക്സിംഗ് (`container[index]`) പ്രവർത്തനം നടത്തുന്നു.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// പരിവർത്തനം ചെയ്യാവുന്ന സന്ദർഭങ്ങളിൽ (`container[index]`) പ്രവർത്തനങ്ങൾ സൂചികയിലാക്കാൻ ഉപയോഗിക്കുന്നു.
///
/// `container[index]` യഥാർത്ഥത്തിൽ `*container.index_mut(index)`-നുള്ള വാക്യഘടന പഞ്ചസാരയാണ്, പക്ഷേ ഒരു മ്യൂട്ടബിൾ മൂല്യമായി ഉപയോഗിക്കുമ്പോൾ മാത്രം.
/// മാറ്റമില്ലാത്ത മൂല്യം അഭ്യർത്ഥിക്കുകയാണെങ്കിൽ, പകരം [`Index`] trait ഉപയോഗിക്കുന്നു.
/// ഇത് `v[index] = value` പോലുള്ള നല്ല കാര്യങ്ങൾ അനുവദിക്കുന്നു.
///
/// # Examples
///
/// രണ്ട് വശങ്ങളുള്ള എക്സ് 100 എക്സ് സ്ട്രക്റ്റിന്റെ വളരെ ലളിതമായ നടപ്പാക്കൽ, അവിടെ ഓരോന്നിനും പരസ്പരം മാറ്റമില്ലാതെ സൂചികയിലാക്കാം.
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // ഈ സാഹചര്യത്തിൽ, `balance[Side::Right]` എന്നത് `*balance.index(Side::Right)`-നുള്ള പഞ്ചസാരയാണ്, കാരണം ഞങ്ങൾ* വായിക്കുന്നത് * `balance[Side::Right]` മാത്രമാണ്, ഇത് എഴുതുന്നില്ല.
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // എന്നിരുന്നാലും, ഈ സാഹചര്യത്തിൽ `balance[Side::Left]` എന്നത് `*balance.index_mut(Side::Left)`-നുള്ള പഞ്ചസാരയാണ്, കാരണം ഞങ്ങൾ `balance[Side::Left]` എഴുതുന്നു.
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// മ്യൂട്ടബിൾ ഇൻഡെക്സിംഗ് (`container[index]`) പ്രവർത്തനം നടത്തുന്നു.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}