use crate::fmt;
use crate::hash::Hash;

/// പരിധിയില്ലാത്ത പരിധി (`..`).
///
/// `RangeFull` പ്രാഥമികമായി ഒരു [slicing index] ആയി ഉപയോഗിക്കുന്നു, ഇതിന്റെ ചുരുക്കെഴുത്ത് `..` ആണ്.
/// ഇതിന് ഒരു [`Iterator`] ആയി സേവിക്കാൻ കഴിയില്ല കാരണം ഇതിന് ഒരു ആരംഭ പോയിന്റ് ഇല്ല.
///
/// # Examples
///
/// `..` വാക്യഘടന ഒരു `RangeFull` ആണ്:
///
/// ```
/// assert_eq!((..), std::ops::RangeFull);
/// ```
///
/// ഇതിന് ഒരു [`IntoIterator`] നടപ്പിലാക്കൽ ഇല്ല, അതിനാൽ നിങ്ങൾക്ക് ഇത് നേരിട്ട് ഒരു `for` ലൂപ്പിൽ ഉപയോഗിക്കാൻ കഴിയില്ല.
/// ഇത് കംപൈൽ ചെയ്യില്ല:
///
/// ```compile_fail,E0277
/// for i in .. {
///     // ...
/// }
/// ```
///
/// [slicing index] ആയി ഉപയോഗിക്കുന്ന, `RangeFull` ഒരു സ്ലൈസായി പൂർണ്ണ അറേ നിർമ്മിക്കുന്നു.
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]); // ഇതാണ് `RangeFull`
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
#[lang = "RangeFull"]
#[doc(alias = "..")]
#[derive(Copy, Clone, Default, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeFull;

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for RangeFull {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..")
    }
}

/// എക്സ് 100 എക്സ് പരിധി എക്സ്ക്ലൂസീവായി ചുവടെയും എക്സ് എക്സ് എക്സിനു മുകളിലുമാണ്.
///
///
/// `start..end` ശ്രേണിയിൽ `start <= x < end` ഉള്ള എല്ലാ മൂല്യങ്ങളും അടങ്ങിയിരിക്കുന്നു.
/// `start >= end` ആണെങ്കിൽ ഇത് ശൂന്യമാണ്.
///
/// # Examples
///
/// `start..end` വാക്യഘടന ഒരു `Range` ആണ്:
///
/// ```
/// assert_eq!((3..5), std::ops::Range { start: 3, end: 5 });
/// assert_eq!(3 + 4 + 5, (3..6).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]); // ഇതൊരു `Range` ആണ്
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
#[lang = "Range"]
#[doc(alias = "..")]
#[derive(Clone, Default, PartialEq, Eq, Hash)] // പകർത്തരുത്-#27186 കാണുക
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Range<Idx> {
    /// (inclusive) ശ്രേണിയുടെ താഴത്തെ പരിധി.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub start: Idx,
    /// (exclusive) ശ്രേണിയുടെ മുകളിലെ അതിർത്തി.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub end: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for Range<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> Range<Idx> {
    /// `item` ശ്രേണിയിൽ അടങ്ങിയിട്ടുണ്ടെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..5).contains(&2));
    /// assert!( (3..5).contains(&3));
    /// assert!( (3..5).contains(&4));
    /// assert!(!(3..5).contains(&5));
    ///
    /// assert!(!(3..3).contains(&3));
    /// assert!(!(3..2).contains(&3));
    ///
    /// assert!( (0.0..1.0).contains(&0.5));
    /// assert!(!(0.0..1.0).contains(&f32::NAN));
    /// assert!(!(0.0..f32::NAN).contains(&0.5));
    /// assert!(!(f32::NAN..1.0).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }

    /// ശ്രേണിയിൽ ഇനങ്ങളൊന്നുമില്ലെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..5).is_empty());
    /// assert!( (3..3).is_empty());
    /// assert!( (3..2).is_empty());
    /// ```
    ///
    /// ഇരുവശവും സമാനതകളില്ലെങ്കിൽ ശ്രേണി ശൂന്യമാണ്:
    ///
    /// ```
    /// assert!(!(3.0..5.0).is_empty());
    /// assert!( (3.0..f32::NAN).is_empty());
    /// assert!( (f32::NAN..5.0).is_empty());
    /// ```
    #[stable(feature = "range_is_empty", since = "1.47.0")]
    pub fn is_empty(&self) -> bool {
        !(self.start < self.end)
    }
}

/// എക്സ് 00 എക്‌സിനു താഴെയായി മാത്രം പരിമിതപ്പെടുത്തിയിരിക്കുന്ന ഒരു ശ്രേണി.
///
/// `RangeFrom` `start..`-ൽ `x >= start` ഉള്ള എല്ലാ മൂല്യങ്ങളും അടങ്ങിയിരിക്കുന്നു.
///
/// *കുറിപ്പ്*: [`Iterator`] നടപ്പിലാക്കലിലെ ഓവർഫ്ലോ (അടങ്ങിയിരിക്കുന്ന ഡാറ്റ തരം അതിന്റെ സംഖ്യാ പരിധിയിലെത്തുമ്പോൾ) panic, റാപ് അല്ലെങ്കിൽ പൂരിതമാക്കാൻ അനുവദിച്ചിരിക്കുന്നു.
/// [`Step`] trait നടപ്പിലാക്കുന്നതിലൂടെ ഈ സ്വഭാവം നിർവചിക്കപ്പെടുന്നു.
/// പ്രാകൃത സംഖ്യകൾക്കായി, ഇത് സാധാരണ നിയമങ്ങൾ പാലിക്കുന്നു, കൂടാതെ ഓവർഫ്ലോ ചെക്ക് പ്രൊഫൈലിനെ മാനിക്കുന്നു (ഡീബഗിലെ panic, റിലീസിൽ പൊതിയുക).
/// നിങ്ങൾ might ഹിച്ചതിലും നേരത്തെ ഓവർഫ്ലോ സംഭവിക്കുന്നുവെന്നതും ശ്രദ്ധിക്കുക: അടുത്ത മൂല്യം നൽകുന്നതിന് ശ്രേണി ഒരു അവസ്ഥയിലേക്ക് സജ്ജമാക്കേണ്ടതിനാൽ, പരമാവധി മൂല്യം നൽകുന്ന `next`-ലേക്കുള്ള കോളിൽ ഓവർഫ്ലോ സംഭവിക്കുന്നു.
///
///
/// [`Step`]: crate::iter::Step
///
/// # Examples
///
/// `start..` വാക്യഘടന ഒരു `RangeFrom` ആണ്:
///
/// ```
/// assert_eq!((2..), std::ops::RangeFrom { start: 2 });
/// assert_eq!(2 + 3 + 4, (2..).take(3).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]); // ഇതൊരു `RangeFrom` ആണ്
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
///
///
#[lang = "RangeFrom"]
#[doc(alias = "..")]
#[derive(Clone, PartialEq, Eq, Hash)] // പകർത്തരുത്-#27186 കാണുക
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeFrom<Idx> {
    /// (inclusive) ശ്രേണിയുടെ താഴത്തെ പരിധി.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub start: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeFrom<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..")?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeFrom<Idx> {
    /// `item` ശ്രേണിയിൽ അടങ്ങിയിട്ടുണ്ടെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..).contains(&2));
    /// assert!( (3..).contains(&3));
    /// assert!( (3..).contains(&1_000_000_000));
    ///
    /// assert!( (0.0..).contains(&0.5));
    /// assert!(!(0.0..).contains(&f32::NAN));
    /// assert!(!(f32::NAN..).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

/// ഒരു ശ്രേണി (`..end`) ന് മുകളിൽ മാത്രമായി പരിമിതപ്പെടുത്തിയിരിക്കുന്നു.
///
/// `RangeTo` `..end`-ൽ `x < end` ഉള്ള എല്ലാ മൂല്യങ്ങളും അടങ്ങിയിരിക്കുന്നു.
/// ഇതിന് ഒരു [`Iterator`] ആയി സേവിക്കാൻ കഴിയില്ല കാരണം ഇതിന് ഒരു ആരംഭ പോയിന്റ് ഇല്ല.
///
/// # Examples
///
/// `..end` വാക്യഘടന ഒരു `RangeTo` ആണ്:
///
/// ```
/// assert_eq!((..5), std::ops::RangeTo { end: 5 });
/// ```
///
/// ഇതിന് ഒരു [`IntoIterator`] നടപ്പിലാക്കൽ ഇല്ല, അതിനാൽ നിങ്ങൾക്ക് ഇത് നേരിട്ട് ഒരു `for` ലൂപ്പിൽ ഉപയോഗിക്കാൻ കഴിയില്ല.
/// ഇത് കംപൈൽ ചെയ്യില്ല:
///
/// ```compile_fail,E0277
/// // error[E0277]: the trait bound `std::ops::RangeTo<{integer}>:
/// // std::iter::Iterator` is not satisfied
/// for i in ..5 {
///     // ...
/// }
/// ```
///
/// [slicing index] ആയി ഉപയോഗിക്കുമ്പോൾ, `end` സൂചിപ്പിക്കുന്ന സൂചികയ്‌ക്ക് മുമ്പായി `RangeTo` എല്ലാ അറേ ഘടകങ്ങളുടെയും ഒരു സ്ലൈസ് നിർമ്മിക്കുന്നു.
///
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]); // ഇതൊരു `RangeTo` ആണ്
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
#[lang = "RangeTo"]
#[doc(alias = "..")]
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RangeTo<Idx> {
    /// (exclusive) ശ്രേണിയുടെ മുകളിലെ അതിർത്തി.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub end: Idx,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeTo<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeTo<Idx> {
    /// `item` ശ്രേണിയിൽ അടങ്ങിയിട്ടുണ്ടെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!( (..5).contains(&-1_000_000_000));
    /// assert!( (..5).contains(&4));
    /// assert!(!(..5).contains(&5));
    ///
    /// assert!( (..1.0).contains(&0.5));
    /// assert!(!(..1.0).contains(&f32::NAN));
    /// assert!(!(..f32::NAN).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

/// (`start..=end`)-ന് താഴെയും മുകളിലുമുള്ള ഒരു പരിധി.
///
/// `RangeInclusive` `start..=end`-ൽ `x >= start`, `x <= end` എന്നിവയുള്ള എല്ലാ മൂല്യങ്ങളും അടങ്ങിയിരിക്കുന്നു.`start <= end` ഇല്ലെങ്കിൽ ഇത് ശൂന്യമാണ്.
///
/// ഈ ഇറ്ററേറ്റർ [fused] ആണ്, എന്നാൽ ആവർത്തനം പൂർത്തിയായതിന് ശേഷം `start`, `end` എന്നിവയുടെ നിർദ്ദിഷ്ട മൂല്യങ്ങൾ **വ്യക്തമാക്കാത്തവയാണ്** ഒഴികെ [`.is_empty()`] `true` മടങ്ങും, കൂടുതൽ മൂല്യങ്ങൾ ഉൽ‌പാദിപ്പിക്കപ്പെടുന്നില്ല.
///
///
/// [fused]: crate::iter::FusedIterator
/// [`.is_empty()`]: RangeInclusive::is_empty
///
/// # Examples
///
/// `start..=end` വാക്യഘടന ഒരു `RangeInclusive` ആണ്:
///
/// ```
/// assert_eq!((3..=5), std::ops::RangeInclusive::new(3, 5));
/// assert_eq!(3 + 4 + 5, (3..=5).sum());
/// ```
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]);
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]); // ഇതൊരു `RangeInclusive` ആണ്
/// ```
///
///
#[lang = "RangeInclusive"]
#[doc(alias = "..=")]
#[derive(Clone, PartialEq, Eq, Hash)] // പകർത്തരുത്-#27186 കാണുക
#[stable(feature = "inclusive_range", since = "1.26.0")]
pub struct RangeInclusive<Idx> {
    // future-ൽ പ്രാതിനിധ്യം മാറ്റാൻ അനുവദിക്കുന്നതിന് ഇവിടെയുള്ള ഫീൽഡുകൾ പൊതുവായതല്ലെന്നത് ശ്രദ്ധിക്കുക;പ്രത്യേകിച്ചും, ഞങ്ങൾക്ക് start/end തുറന്നുകാട്ടാൻ കഴിയുമെങ്കിലും, (future/current) സ്വകാര്യ ഫീൽഡുകൾ മാറ്റാതെ അവ പരിഷ്‌ക്കരിക്കുന്നത് തെറ്റായ പെരുമാറ്റത്തിലേക്ക് നയിച്ചേക്കാം, അതിനാൽ ഞങ്ങൾ ആ മോഡിനെ പിന്തുണയ്ക്കാൻ ആഗ്രഹിക്കുന്നില്ല.
    //
    //
    //
    //
    pub(crate) start: Idx,
    pub(crate) end: Idx,

    // ഈ ഫീൽഡ് ഇതാണ്:
    //  - `false` നിർമ്മാണത്തിൽ
    //  - `false` ആവർത്തനം ഒരു മൂലകം നൽകുകയും ആവർത്തനം തീർന്നുപോകാതിരിക്കുകയും ചെയ്യുമ്പോൾ
    //  - `true` ആവർത്തനത്തെ തീർക്കാൻ ആവർത്തനം ഉപയോഗിക്കുമ്പോൾ
    //
    // ഒരു ഭാഗിക ഓർഡിനോ സ്പെഷ്യലൈസേഷനോ ഇല്ലാതെ ഭാഗിക എക്, ഹാഷ് എന്നിവ പിന്തുണയ്ക്കുന്നതിന് ഇത് ആവശ്യമാണ്.
    pub(crate) exhausted: bool,
}

impl<Idx> RangeInclusive<Idx> {
    /// ഒരു പുതിയ ഉൾക്കൊള്ളുന്ന ശ്രേണി സൃഷ്ടിക്കുന്നു.`start..=end` എഴുതുന്നതിന് തുല്യമാണ്.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ops::RangeInclusive;
    ///
    /// assert_eq!(3..=5, RangeInclusive::new(3, 5));
    /// ```
    #[lang = "range_inclusive_new"]
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[inline]
    #[rustc_promotable]
    #[rustc_const_stable(feature = "const_range_new", since = "1.32.0")]
    pub const fn new(start: Idx, end: Idx) -> Self {
        Self { start, end, exhausted: false }
    }

    /// (inclusive) ശ്രേണിയുടെ താഴത്തെ പരിധി നൽകുന്നു.
    ///
    /// ആവർത്തനത്തിനായി ഒരു ഉൾക്കൊള്ളുന്ന ശ്രേണി ഉപയോഗിക്കുമ്പോൾ, ആവർത്തനം അവസാനിച്ചതിന് ശേഷം `start()`, [`end()`] എന്നിവയുടെ മൂല്യങ്ങൾ വ്യക്തമാക്കില്ല.
    /// ഉൾക്കൊള്ളുന്ന ശ്രേണി ശൂന്യമാണോ എന്ന് നിർണ്ണയിക്കാൻ, `start() > end()` താരതമ്യപ്പെടുത്തുന്നതിന് പകരം [`is_empty()`] രീതി ഉപയോഗിക്കുക.
    ///
    /// Note: ശ്രേണി ക്ഷീണത്തിലേക്ക് ആവർത്തിച്ചതിനുശേഷം ഈ രീതി നൽകിയ മൂല്യം വ്യക്തമല്ല.
    ///
    /// [`end()`]: RangeInclusive::end
    /// [`is_empty()`]: RangeInclusive::is_empty
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).start(), &3);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_inclusive_range_methods", since = "1.32.0")]
    #[inline]
    pub const fn start(&self) -> &Idx {
        &self.start
    }

    /// (inclusive) ശ്രേണിയുടെ മുകളിലെ അതിർത്തി നൽകുന്നു.
    ///
    /// ആവർത്തനത്തിനായി ഒരു ഉൾക്കൊള്ളുന്ന ശ്രേണി ഉപയോഗിക്കുമ്പോൾ, ആവർത്തനം അവസാനിച്ചതിന് ശേഷം [`start()`], `end()` എന്നിവയുടെ മൂല്യങ്ങൾ വ്യക്തമാക്കില്ല.
    /// ഉൾക്കൊള്ളുന്ന ശ്രേണി ശൂന്യമാണോ എന്ന് നിർണ്ണയിക്കാൻ, `start() > end()` താരതമ്യപ്പെടുത്തുന്നതിന് പകരം [`is_empty()`] രീതി ഉപയോഗിക്കുക.
    ///
    /// Note: ശ്രേണി ക്ഷീണത്തിലേക്ക് ആവർത്തിച്ചതിനുശേഷം ഈ രീതി നൽകിയ മൂല്യം വ്യക്തമല്ല.
    ///
    /// [`start()`]: RangeInclusive::start
    /// [`is_empty()`]: RangeInclusive::is_empty
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).end(), &5);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_inclusive_range_methods", since = "1.32.0")]
    #[inline]
    pub const fn end(&self) -> &Idx {
        &self.end
    }

    /// `RangeInclusive`-ലേക്ക് (താഴ്ന്ന ബ bound ണ്ട്, അപ്പർ (inclusive) ബൗണ്ട്) നശിപ്പിക്കുന്നു.
    ///
    /// Note: ശ്രേണി ക്ഷീണത്തിലേക്ക് ആവർത്തിച്ചതിനുശേഷം ഈ രീതി നൽകിയ മൂല്യം വ്യക്തമല്ല.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!((3..=5).into_inner(), (3, 5));
    /// ```
    #[stable(feature = "inclusive_range_methods", since = "1.27.0")]
    #[inline]
    pub fn into_inner(self) -> (Idx, Idx) {
        (self.start, self.end)
    }
}

impl RangeInclusive<usize> {
    /// `SliceIndex` നടപ്പിലാക്കലുകൾക്കായി എക്‌സ്‌ക്ലൂസീവ് `Range`-ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    /// `end == usize::MAX` കൈകാര്യം ചെയ്യുന്നതിന് കോളറിന് ഉത്തരവാദിത്തമുണ്ട്.
    #[inline]
    pub(crate) fn into_slice_range(self) -> Range<usize> {
        // ഞങ്ങൾ തളർന്നില്ലെങ്കിൽ, `start..end + 1` സ്ലൈസ് ചെയ്യാൻ ഞങ്ങൾ ആഗ്രഹിക്കുന്നു.
        // ഞങ്ങൾ തളർന്നുപോയെങ്കിൽ, `end + 1..end + 1` ഉപയോഗിച്ച് സ്ലൈസ് ചെയ്യുന്നത് ഒരു ശൂന്യമായ ശ്രേണി നൽകുന്നു, അത് ഇപ്പോഴും ആ എൻ‌ഡ്‌പോയിന്റിനായുള്ള പരിധി പരിശോധനകൾക്ക് വിധേയമാണ്.
        //
        let exclusive_end = self.end + 1;
        let start = if self.exhausted { exclusive_end } else { self.start };
        start..exclusive_end
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeInclusive<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.start.fmt(fmt)?;
        write!(fmt, "..=")?;
        self.end.fmt(fmt)?;
        if self.exhausted {
            write!(fmt, " (exhausted)")?;
        }
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeInclusive<Idx> {
    /// `item` ശ്രേണിയിൽ അടങ്ങിയിട്ടുണ്ടെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..=5).contains(&2));
    /// assert!( (3..=5).contains(&3));
    /// assert!( (3..=5).contains(&4));
    /// assert!( (3..=5).contains(&5));
    /// assert!(!(3..=5).contains(&6));
    ///
    /// assert!( (3..=3).contains(&3));
    /// assert!(!(3..=2).contains(&3));
    ///
    /// assert!( (0.0..=1.0).contains(&1.0));
    /// assert!(!(0.0..=1.0).contains(&f32::NAN));
    /// assert!(!(0.0..=f32::NAN).contains(&0.0));
    /// assert!(!(f32::NAN..=1.0).contains(&1.0));
    /// ```
    ///
    /// ആവർത്തനം പൂർത്തിയായതിന് ശേഷം ഈ രീതി എല്ലായ്പ്പോഴും `false` നൽകുന്നു:
    ///
    /// ```
    /// let mut r = 3..=5;
    /// assert!(r.contains(&3) && r.contains(&5));
    /// for _ in r.by_ref() {}
    /// // കൃത്യമായ ഫീൽഡ് മൂല്യങ്ങൾ ഇവിടെ വ്യക്തമാക്കിയിട്ടില്ല
    /// assert!(!r.contains(&3) && !r.contains(&5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }

    /// ശ്രേണിയിൽ ഇനങ്ങളൊന്നുമില്ലെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!(!(3..=5).is_empty());
    /// assert!(!(3..=3).is_empty());
    /// assert!( (3..=2).is_empty());
    /// ```
    ///
    /// ഇരുവശവും സമാനതകളില്ലെങ്കിൽ ശ്രേണി ശൂന്യമാണ്:
    ///
    /// ```
    /// assert!(!(3.0..=5.0).is_empty());
    /// assert!( (3.0..=f32::NAN).is_empty());
    /// assert!( (f32::NAN..=5.0).is_empty());
    /// ```
    ///
    /// ആവർത്തനം പൂർത്തിയായതിന് ശേഷം ഈ രീതി `true` നൽകുന്നു:
    ///
    /// ```
    /// let mut r = 3..=5;
    /// for _ in r.by_ref() {}
    /// // കൃത്യമായ ഫീൽഡ് മൂല്യങ്ങൾ ഇവിടെ വ്യക്തമാക്കിയിട്ടില്ല
    /// assert!(r.is_empty());
    /// ```
    #[stable(feature = "range_is_empty", since = "1.47.0")]
    #[inline]
    pub fn is_empty(&self) -> bool {
        self.exhausted || !(self.start <= self.end)
    }
}

/// എക്സ് 00 എക്‌സിനു മുകളിൽ മാത്രമായി പരിമിതപ്പെടുത്തിയിരിക്കുന്ന ഒരു ശ്രേണി.
///
/// `RangeToInclusive` `..=end`-ൽ `x <= end` ഉള്ള എല്ലാ മൂല്യങ്ങളും അടങ്ങിയിരിക്കുന്നു.
/// ഇതിന് ഒരു [`Iterator`] ആയി സേവിക്കാൻ കഴിയില്ല കാരണം ഇതിന് ഒരു ആരംഭ പോയിന്റ് ഇല്ല.
///
/// # Examples
///
/// `..=end` വാക്യഘടന ഒരു `RangeToInclusive` ആണ്:
///
/// ```
/// assert_eq!((..=5), std::ops::RangeToInclusive{ end: 5 });
/// ```
///
/// ഇതിന് ഒരു [`IntoIterator`] നടപ്പിലാക്കൽ ഇല്ല, അതിനാൽ നിങ്ങൾക്ക് ഇത് നേരിട്ട് ഒരു `for` ലൂപ്പിൽ ഉപയോഗിക്കാൻ കഴിയില്ല.ഇത് കംപൈൽ ചെയ്യില്ല:
///
/// ```compile_fail,E0277
/// // error[E0277]: the trait bound `std::ops::RangeToInclusive<{integer}>:
/// // std::iter::Iterator` is not satisfied
/// for i in ..=5 {
///     // ...
/// }
/// ```
///
/// ഒരു [slicing index] ആയി ഉപയോഗിക്കുമ്പോൾ, X002 സൂചിപ്പിച്ചിരിക്കുന്ന സൂചിക ഉൾപ്പെടെ എല്ലാ അറേ ഘടകങ്ങളുടെയും ഒരു സ്ലൈസ് `RangeToInclusive` നിർമ്മിക്കുന്നു.
///
///
/// ```
/// let arr = [0, 1, 2, 3, 4];
/// assert_eq!(arr[ ..  ], [0, 1, 2, 3, 4]);
/// assert_eq!(arr[ .. 3], [0, 1, 2      ]);
/// assert_eq!(arr[ ..=3], [0, 1, 2, 3   ]); // ഇതൊരു `RangeToInclusive` ആണ്
/// assert_eq!(arr[1..  ], [   1, 2, 3, 4]);
/// assert_eq!(arr[1.. 3], [   1, 2      ]);
/// assert_eq!(arr[1..=3], [   1, 2, 3   ]);
/// ```
///
/// [slicing index]: crate::slice::SliceIndex
///
#[lang = "RangeToInclusive"]
#[doc(alias = "..=")]
#[derive(Copy, Clone, PartialEq, Eq, Hash)]
#[stable(feature = "inclusive_range", since = "1.26.0")]
pub struct RangeToInclusive<Idx> {
    /// (inclusive) ശ്രേണിയുടെ മുകളിലെ അതിർത്തി
    #[stable(feature = "inclusive_range", since = "1.26.0")]
    pub end: Idx,
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<Idx: fmt::Debug> fmt::Debug for RangeToInclusive<Idx> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(fmt, "..=")?;
        self.end.fmt(fmt)?;
        Ok(())
    }
}

impl<Idx: PartialOrd<Idx>> RangeToInclusive<Idx> {
    /// `item` ശ്രേണിയിൽ അടങ്ങിയിട്ടുണ്ടെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!( (..=5).contains(&-1_000_000_000));
    /// assert!( (..=5).contains(&5));
    /// assert!(!(..=5).contains(&6));
    ///
    /// assert!( (..=1.0).contains(&1.0));
    /// assert!(!(..=1.0).contains(&f32::NAN));
    /// assert!(!(..=f32::NAN).contains(&0.5));
    /// ```
    #[stable(feature = "range_contains", since = "1.35.0")]
    pub fn contains<U>(&self, item: &U) -> bool
    where
        Idx: PartialOrd<U>,
        U: ?Sized + PartialOrd<Idx>,
    {
        <Self as RangeBounds<Idx>>::contains(self, item)
    }
}

// RangeToInclusive<Idx>നിന്ന് impl ചെയ്യാൻ കഴിയില്ല <RangeTo<Idx>> കാരണം (..0).into() ഉപയോഗിച്ച് അണ്ടർ‌ഫ്ലോ സാധ്യമാകും
//

/// കീകളുടെ ശ്രേണിയുടെ അവസാന പോയിന്റ്.
///
/// # Examples
///
/// ശ്രേണി പരിധിയിലെ അവസാന പോയിന്റുകളാണ് `ബൗണ്ട്`:
///
/// ```
/// use std::ops::Bound::*;
/// use std::ops::RangeBounds;
///
/// assert_eq!((..100).start_bound(), Unbounded);
/// assert_eq!((1..12).start_bound(), Included(&1));
/// assert_eq!((1..12).end_bound(), Excluded(&12));
/// ```
///
/// [`BTreeMap::range`]-ന് ഒരു ആർഗ്യുമെൻറായി `ബൗണ്ട്`സ് ടുപ്പിൾ ഉപയോഗിക്കുന്നു.
/// മിക്ക കേസുകളിലും, പകരം റേഞ്ച് സിന്റാക്സ് എക്സ് 00 എക്സ് ഉപയോഗിക്കുന്നതാണ് നല്ലതെന്ന് ശ്രദ്ധിക്കുക.
///
/// ```
/// use std::collections::BTreeMap;
/// use std::ops::Bound::{Excluded, Included, Unbounded};
///
/// let mut map = BTreeMap::new();
/// map.insert(3, "a");
/// map.insert(5, "b");
/// map.insert(8, "c");
///
/// for (key, value) in map.range((Excluded(3), Included(8))) {
///     println!("{}: {}", key, value);
/// }
///
/// assert_eq!(Some((&3, &"a")), map.range((Unbounded, Included(5))).next());
/// ```
///
/// [`BTreeMap::range`]: ../../std/collections/btree_map/struct.BTreeMap.html#method.range
#[stable(feature = "collections_bound", since = "1.17.0")]
#[derive(Clone, Copy, Debug, Hash, PartialEq, Eq)]
pub enum Bound<T> {
    /// ഉൾക്കൊള്ളുന്ന ഒരു പരിധി.
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Included(#[stable(feature = "collections_bound", since = "1.17.0")] T),
    /// എക്‌സ്‌ക്ലൂസീവ് ബൗണ്ട്.
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Excluded(#[stable(feature = "collections_bound", since = "1.17.0")] T),
    /// അനന്തമായ അന്തിമ പോയിന്റ്.ഈ ദിശയിൽ പരിധിയൊന്നുമില്ലെന്ന് സൂചിപ്പിക്കുന്നു.
    #[stable(feature = "collections_bound", since = "1.17.0")]
    Unbounded,
}

#[unstable(feature = "bound_as_ref", issue = "80996")]
impl<T> Bound<T> {
    /// `&Bound<T>`-ൽ നിന്ന് `Bound<&T>`-ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    #[inline]
    pub fn as_ref(&self) -> Bound<&T> {
        match *self {
            Included(ref x) => Included(x),
            Excluded(ref x) => Excluded(x),
            Unbounded => Unbounded,
        }
    }

    /// `&mut Bound<T>`-ൽ നിന്ന് `Bound<&T>`-ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    #[inline]
    pub fn as_mut(&mut self) -> Bound<&mut T> {
        match *self {
            Included(ref mut x) => Included(x),
            Excluded(ref mut x) => Excluded(x),
            Unbounded => Unbounded,
        }
    }
}

impl<T: Clone> Bound<&T> {
    /// ബന്ധിത ഉള്ളടക്കങ്ങൾ ക്ലോൺ ചെയ്തുകൊണ്ട് ഒരു `Bound<&T>` മുതൽ `Bound<T>` വരെ മാപ്പ് ചെയ്യുക.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(bound_cloned)]
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((1..12).start_bound(), Included(&1));
    /// assert_eq!((1..12).start_bound().cloned(), Included(1));
    /// ```
    #[unstable(feature = "bound_cloned", issue = "61356")]
    pub fn cloned(self) -> Bound<T> {
        match self {
            Bound::Unbounded => Bound::Unbounded,
            Bound::Included(x) => Bound::Included(x.clone()),
            Bound::Excluded(x) => Bound::Excluded(x.clone()),
        }
    }
}

/// `RangeBounds` `..`, `a..`, `..b`, `..=c`, `d..e`, അല്ലെങ്കിൽ `f..=g` പോലുള്ള റേഞ്ച് സിന്റാക്സ് നിർമ്മിച്ച Rust-ന്റെ അന്തർനിർമ്മിത ശ്രേണി തരങ്ങൾ നടപ്പിലാക്കുന്നു.
///
#[stable(feature = "collections_range", since = "1.28.0")]
pub trait RangeBounds<T: ?Sized> {
    /// സൂചിക ബന്ധിതമാക്കുക.
    ///
    /// ആരംഭ മൂല്യം ഒരു `Bound` ആയി നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((..10).start_bound(), Unbounded);
    /// assert_eq!((3..10).start_bound(), Included(&3));
    /// # }
    /// ```
    #[stable(feature = "collections_range", since = "1.28.0")]
    fn start_bound(&self) -> Bound<&T>;

    /// അവസാന സൂചിക ബന്ധിച്ചിരിക്കുന്നു.
    ///
    /// അവസാന മൂല്യം ഒരു `Bound` ആയി നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// use std::ops::Bound::*;
    /// use std::ops::RangeBounds;
    ///
    /// assert_eq!((3..).end_bound(), Unbounded);
    /// assert_eq!((3..10).end_bound(), Excluded(&10));
    /// # }
    /// ```
    #[stable(feature = "collections_range", since = "1.28.0")]
    fn end_bound(&self) -> Bound<&T>;

    /// `item` ശ്രേണിയിൽ അടങ്ങിയിട്ടുണ്ടെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// ((3..5).contains(&4));
    /// assert!(!(3..5).contains(&2));
    ///
    /// ((0.0..1.0).contains(&0.5));
    /// assert!(!(0.0..1.0).contains(&f32::NAN));
    /// assert!(!(0.0..f32::NAN).contains(&0.5));
    /// assert!(!(f32::NAN..1.0).contains(&0.5));
    #[stable(feature = "range_contains", since = "1.35.0")]
    fn contains<U>(&self, item: &U) -> bool
    where
        T: PartialOrd<U>,
        U: ?Sized + PartialOrd<T>,
    {
        (match self.start_bound() {
            Included(ref start) => *start <= item,
            Excluded(ref start) => *start < item,
            Unbounded => true,
        }) && (match self.end_bound() {
            Included(ref end) => item <= *end,
            Excluded(ref end) => item < *end,
            Unbounded => true,
        })
    }
}

use self::Bound::{Excluded, Included, Unbounded};

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T: ?Sized> RangeBounds<T> for RangeFull {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeFrom<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeTo<T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for Range<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeInclusive<T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(&self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        if self.exhausted {
            // ഇറ്ററേറ്റർ തീർന്നുപോകുമ്പോൾ, ഞങ്ങൾക്ക് സാധാരണയായി ആരംഭം==അവസാനം ഉണ്ടാകും, പക്ഷേ ശ്രേണി ശൂന്യമായി കാണണമെന്ന് ഞങ്ങൾ ആഗ്രഹിക്കുന്നു, അതിൽ ഒന്നും അടങ്ങിയിട്ടില്ല.
            //
            Excluded(&self.end)
        } else {
            Included(&self.end)
        }
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeToInclusive<T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(&self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for (Bound<T>, Bound<T>) {
    fn start_bound(&self) -> Bound<&T> {
        match *self {
            (Included(ref start), _) => Included(start),
            (Excluded(ref start), _) => Excluded(start),
            (Unbounded, _) => Unbounded,
        }
    }

    fn end_bound(&self) -> Bound<&T> {
        match *self {
            (_, Included(ref end)) => Included(end),
            (_, Excluded(ref end)) => Excluded(end),
            (_, Unbounded) => Unbounded,
        }
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<'a, T: ?Sized + 'a> RangeBounds<T> for (Bound<&'a T>, Bound<&'a T>) {
    fn start_bound(&self) -> Bound<&T> {
        self.0
    }

    fn end_bound(&self) -> Bound<&T> {
        self.1
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeFrom<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Unbounded
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeTo<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for Range<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Excluded(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeInclusive<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Included(self.start)
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(self.end)
    }
}

#[stable(feature = "collections_range", since = "1.28.0")]
impl<T> RangeBounds<T> for RangeToInclusive<&T> {
    fn start_bound(&self) -> Bound<&T> {
        Unbounded
    }
    fn end_bound(&self) -> Bound<&T> {
        Included(self.end)
    }
}