/// സങ്കലന ഓപ്പറേറ്റർ `+`.
///
/// `Rhs` സ്ഥിരസ്ഥിതിയായി `Self` ആണെന്നത് ശ്രദ്ധിക്കുക, പക്ഷേ ഇത് നിർബന്ധമല്ല.
/// ഉദാഹരണത്തിന്, [`std::time::SystemTime`] `Add<Duration>` നടപ്പിലാക്കുന്നു, ഇത് `SystemTime = SystemTime + Duration` ഫോമിന്റെ പ്രവർത്തനങ്ങൾ അനുവദിക്കുന്നു.
///
///
/// [`std::time::SystemTime`]: ../../std/time/struct.SystemTime.html
///
/// # Examples
///
/// ## `ചേർക്കാവുന്ന` പോയിന്റുകൾ ചേർക്കുക
///
/// ```
/// use std::ops::Add;
///
/// #[derive(Debug, Copy, Clone, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl Add for Point {
///     type Output = Self;
///
///     fn add(self, other: Self) -> Self {
///         Self {
///             x: self.x + other.x,
///             y: self.y + other.y,
///         }
///     }
/// }
///
/// assert_eq!(Point { x: 1, y: 0 } + Point { x: 2, y: 3 },
///            Point { x: 3, y: 3 });
/// ```
///
/// ## ജനറിക്സിനൊപ്പം `Add` നടപ്പിലാക്കുന്നു
///
/// ജനറിക്സ് ഉപയോഗിച്ച് `Add` trait നടപ്പിലാക്കുന്ന അതേ `Point` ഘടനയുടെ ഒരു ഉദാഹരണം ഇതാ.
///
/// ```
/// use std::ops::Add;
///
/// #[derive(Debug, Copy, Clone, PartialEq)]
/// struct Point<T> {
///     x: T,
///     y: T,
/// }
///
/// // നടപ്പിലാക്കൽ അനുബന്ധ തരം `Output` ഉപയോഗിക്കുന്നുവെന്നത് ശ്രദ്ധിക്കുക.
/// impl<T: Add<Output = T>> Add for Point<T> {
///     type Output = Self;
///
///     fn add(self, other: Self) -> Self::Output {
///         Self {
///             x: self.x + other.x,
///             y: self.y + other.y,
///         }
///     }
/// }
///
/// assert_eq!(Point { x: 1, y: 0 } + Point { x: 2, y: 3 },
///            Point { x: 3, y: 3 });
/// ```
///
#[lang = "add"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(all(_Self = "{integer}", Rhs = "{float}"), message = "cannot add a float to an integer",),
    on(all(_Self = "{float}", Rhs = "{integer}"), message = "cannot add an integer to a float",),
    message = "cannot add `{Rhs}` to `{Self}`",
    label = "no implementation for `{Self} + {Rhs}`"
)]
#[doc(alias = "+")]
pub trait Add<Rhs = Self> {
    /// `+` ഓപ്പറേറ്റർ പ്രയോഗിച്ചതിനുശേഷം ലഭിക്കുന്ന തരം.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output;

    /// `+` പ്രവർത്തനം നടത്തുന്നു.
    ///
    /// # Example
    ///
    /// ```
    /// assert_eq!(12 + 1, 13);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn add(self, rhs: Rhs) -> Self::Output;
}

macro_rules! add_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Add for $t {
            type Output = $t;

            #[inline]
            #[rustc_inherit_overflow_checks]
            fn add(self, other: $t) -> $t { self + other }
        }

        forward_ref_binop! { impl Add, add for $t, $t }
    )*)
}

add_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64 }

/// കുറയ്ക്കൽ ഓപ്പറേറ്റർ `-`.
///
/// `Rhs` സ്ഥിരസ്ഥിതിയായി `Self` ആണെന്നത് ശ്രദ്ധിക്കുക, പക്ഷേ ഇത് നിർബന്ധമല്ല.
/// ഉദാഹരണത്തിന്, [`std::time::SystemTime`] `Sub<Duration>` നടപ്പിലാക്കുന്നു, ഇത് `SystemTime = SystemTime - Duration` ഫോമിന്റെ പ്രവർത്തനങ്ങൾ അനുവദിക്കുന്നു.
///
///
/// [`std::time::SystemTime`]: ../../std/time/struct.SystemTime.html
///
/// # Examples
///
/// ## `സബ്‌ട്രാക്റ്റബിൾ പോയിന്റുകൾ
///
/// ```
/// use std::ops::Sub;
///
/// #[derive(Debug, Copy, Clone, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl Sub for Point {
///     type Output = Self;
///
///     fn sub(self, other: Self) -> Self::Output {
///         Self {
///             x: self.x - other.x,
///             y: self.y - other.y,
///         }
///     }
/// }
///
/// assert_eq!(Point { x: 3, y: 3 } - Point { x: 2, y: 3 },
///            Point { x: 1, y: 0 });
/// ```
///
/// ## ജനറിക്സിനൊപ്പം `Sub` നടപ്പിലാക്കുന്നു
///
/// ജനറിക്സ് ഉപയോഗിച്ച് `Sub` trait നടപ്പിലാക്കുന്ന അതേ `Point` ഘടനയുടെ ഒരു ഉദാഹരണം ഇതാ.
///
/// ```
/// use std::ops::Sub;
///
/// #[derive(Debug, PartialEq)]
/// struct Point<T> {
///     x: T,
///     y: T,
/// }
///
/// // നടപ്പിലാക്കൽ അനുബന്ധ തരം `Output` ഉപയോഗിക്കുന്നുവെന്നത് ശ്രദ്ധിക്കുക.
/// impl<T: Sub<Output = T>> Sub for Point<T> {
///     type Output = Self;
///
///     fn sub(self, other: Self) -> Self::Output {
///         Point {
///             x: self.x - other.x,
///             y: self.y - other.y,
///         }
///     }
/// }
///
/// assert_eq!(Point { x: 2, y: 3 } - Point { x: 1, y: 0 },
///            Point { x: 1, y: 3 });
/// ```
///
#[lang = "sub"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "cannot subtract `{Rhs}` from `{Self}`",
    label = "no implementation for `{Self} - {Rhs}`"
)]
#[doc(alias = "-")]
pub trait Sub<Rhs = Self> {
    /// `-` ഓപ്പറേറ്റർ പ്രയോഗിച്ചതിനുശേഷം ലഭിക്കുന്ന തരം.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output;

    /// `-` പ്രവർത്തനം നടത്തുന്നു.
    ///
    /// # Example
    ///
    /// ```
    /// assert_eq!(12 - 1, 11);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn sub(self, rhs: Rhs) -> Self::Output;
}

macro_rules! sub_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Sub for $t {
            type Output = $t;

            #[inline]
            #[rustc_inherit_overflow_checks]
            fn sub(self, other: $t) -> $t { self - other }
        }

        forward_ref_binop! { impl Sub, sub for $t, $t }
    )*)
}

sub_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64 }

/// ഗുണന ഓപ്പറേറ്റർ `*`.
///
/// `Rhs` സ്ഥിരസ്ഥിതിയായി `Self` ആണെന്നത് ശ്രദ്ധിക്കുക, പക്ഷേ ഇത് നിർബന്ധമല്ല.
///
/// # Examples
///
/// ## `മുൾ‌ടൈപ്പ് ചെയ്യാവുന്ന യുക്തിസഹ സംഖ്യകൾ
///
/// ```
/// use std::ops::Mul;
///
/// // ഗണിതത്തിന്റെ അടിസ്ഥാന സിദ്ധാന്തമനുസരിച്ച്, ഏറ്റവും കുറഞ്ഞ പദങ്ങളിൽ യുക്തിസഹമായ സംഖ്യകൾ സവിശേഷമാണ്.
/// // അതിനാൽ, `യുക്തി'യെ കുറഞ്ഞ രൂപത്തിൽ സൂക്ഷിക്കുന്നതിലൂടെ, നമുക്ക് `Eq`, `PartialEq` എന്നിവ നേടാനാകും.
/////
/// #[derive(Debug, Eq, PartialEq)]
/// struct Rational {
///     numerator: usize,
///     denominator: usize,
/// }
///
/// impl Rational {
///     fn new(numerator: usize, denominator: usize) -> Self {
///         if denominator == 0 {
///             panic!("Zero is an invalid denominator!");
///         }
///
///         // ഏറ്റവും വലിയ കോമൺ ഹരിക്കൽ കൊണ്ട് ഹരിച്ചാൽ ഏറ്റവും കുറഞ്ഞ പദങ്ങളിലേക്ക് കുറയ്ക്കുക.
/////
///         let gcd = gcd(numerator, denominator);
///         Self {
///             numerator: numerator / gcd,
///             denominator: denominator / gcd,
///         }
///     }
/// }
///
/// impl Mul for Rational {
///     // യുക്തിസഹമായ സംഖ്യകളുടെ ഗുണനം ഒരു അടച്ച പ്രവർത്തനമാണ്.
///     type Output = Self;
///
///     fn mul(self, rhs: Self) -> Self {
///         let numerator = self.numerator * rhs.numerator;
///         let denominator = self.denominator * rhs.denominator;
///         Self::new(numerator, denominator)
///     }
/// }
///
/// // ഏറ്റവും വലിയ പൊതു വിഭജനം കണ്ടെത്തുന്നതിനുള്ള യൂക്ലിഡിന്റെ രണ്ടായിരം വർഷം പഴക്കമുള്ള അൽഗോരിതം.
/////
/// fn gcd(x: usize, y: usize) -> usize {
///     let mut x = x;
///     let mut y = y;
///     while y != 0 {
///         let t = y;
///         y = x % y;
///         x = t;
///     }
///     x
/// }
///
/// assert_eq!(Rational::new(1, 2), Rational::new(2, 4));
/// assert_eq!(Rational::new(2, 3) * Rational::new(3, 4),
///            Rational::new(1, 2));
/// ```
///
/// ## ലീനിയർ ആൾജിബ്രയിലെന്നപോലെ സ്കെയിലറുകളാൽ vectors ഗുണിക്കുന്നു
///
/// ```
/// use std::ops::Mul;
///
/// struct Scalar { value: usize }
///
/// #[derive(Debug, PartialEq)]
/// struct Vector { value: Vec<usize> }
///
/// impl Mul<Scalar> for Vector {
///     type Output = Self;
///
///     fn mul(self, rhs: Scalar) -> Self::Output {
///         Self { value: self.value.iter().map(|v| v * rhs.value).collect() }
///     }
/// }
///
/// let vector = Vector { value: vec![2, 4, 6] };
/// let scalar = Scalar { value: 3 };
/// assert_eq!(vector * scalar, Vector { value: vec![6, 12, 18] });
/// ```
#[lang = "mul"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "cannot multiply `{Self}` by `{Rhs}`",
    label = "no implementation for `{Self} * {Rhs}`"
)]
#[doc(alias = "*")]
pub trait Mul<Rhs = Self> {
    /// `*` ഓപ്പറേറ്റർ പ്രയോഗിച്ചതിനുശേഷം ലഭിക്കുന്ന തരം.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output;

    /// `*` പ്രവർത്തനം നടത്തുന്നു.
    ///
    /// # Example
    ///
    /// ```
    /// assert_eq!(12 * 2, 24);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn mul(self, rhs: Rhs) -> Self::Output;
}

macro_rules! mul_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Mul for $t {
            type Output = $t;

            #[inline]
            #[rustc_inherit_overflow_checks]
            fn mul(self, other: $t) -> $t { self * other }
        }

        forward_ref_binop! { impl Mul, mul for $t, $t }
    )*)
}

mul_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64 }

/// ഡിവിഷൻ ഓപ്പറേറ്റർ `/`.
///
/// `Rhs` സ്ഥിരസ്ഥിതിയായി `Self` ആണെന്നത് ശ്രദ്ധിക്കുക, പക്ഷേ ഇത് നിർബന്ധമല്ല.
///
/// # Examples
///
/// ## `ഹരിക്കാവുന്ന യുക്തിസഹ സംഖ്യകൾ
///
/// ```
/// use std::ops::Div;
///
/// // ഗണിതത്തിന്റെ അടിസ്ഥാന സിദ്ധാന്തമനുസരിച്ച്, ഏറ്റവും കുറഞ്ഞ പദങ്ങളിൽ യുക്തിസഹമായ സംഖ്യകൾ സവിശേഷമാണ്.
/// // അതിനാൽ, `യുക്തി'യെ കുറഞ്ഞ രൂപത്തിൽ സൂക്ഷിക്കുന്നതിലൂടെ, നമുക്ക് `Eq`, `PartialEq` എന്നിവ നേടാനാകും.
/////
/// #[derive(Debug, Eq, PartialEq)]
/// struct Rational {
///     numerator: usize,
///     denominator: usize,
/// }
///
/// impl Rational {
///     fn new(numerator: usize, denominator: usize) -> Self {
///         if denominator == 0 {
///             panic!("Zero is an invalid denominator!");
///         }
///
///         // ഏറ്റവും വലിയ കോമൺ ഹരിക്കൽ കൊണ്ട് ഹരിച്ചാൽ ഏറ്റവും കുറഞ്ഞ പദങ്ങളിലേക്ക് കുറയ്ക്കുക.
/////
///         let gcd = gcd(numerator, denominator);
///         Self {
///             numerator: numerator / gcd,
///             denominator: denominator / gcd,
///         }
///     }
/// }
///
/// impl Div for Rational {
///     // യുക്തിസഹമായ സംഖ്യകളുടെ വിഭജനം ഒരു അടച്ച പ്രവർത്തനമാണ്.
///     type Output = Self;
///
///     fn div(self, rhs: Self) -> Self::Output {
///         if rhs.numerator == 0 {
///             panic!("Cannot divide by zero-valued `Rational`!");
///         }
///
///         let numerator = self.numerator * rhs.denominator;
///         let denominator = self.denominator * rhs.numerator;
///         Self::new(numerator, denominator)
///     }
/// }
///
/// // ഏറ്റവും വലിയ പൊതു വിഭജനം കണ്ടെത്തുന്നതിനുള്ള യൂക്ലിഡിന്റെ രണ്ടായിരം വർഷം പഴക്കമുള്ള അൽഗോരിതം.
/////
/// fn gcd(x: usize, y: usize) -> usize {
///     let mut x = x;
///     let mut y = y;
///     while y != 0 {
///         let t = y;
///         y = x % y;
///         x = t;
///     }
///     x
/// }
///
/// assert_eq!(Rational::new(1, 2), Rational::new(2, 4));
/// assert_eq!(Rational::new(1, 2) / Rational::new(3, 4),
///            Rational::new(2, 3));
/// ```
///
/// ## ലീനിയർ ആൾജിബ്രയിലെന്നപോലെ സ്കെയിലറുകളാൽ vectors വിഭജിക്കുന്നു
///
/// ```
/// use std::ops::Div;
///
/// struct Scalar { value: f32 }
///
/// #[derive(Debug, PartialEq)]
/// struct Vector { value: Vec<f32> }
///
/// impl Div<Scalar> for Vector {
///     type Output = Self;
///
///     fn div(self, rhs: Scalar) -> Self::Output {
///         Self { value: self.value.iter().map(|v| v / rhs.value).collect() }
///     }
/// }
///
/// let scalar = Scalar { value: 2f32 };
/// let vector = Vector { value: vec![2f32, 4f32, 6f32] };
/// assert_eq!(vector / scalar, Vector { value: vec![1f32, 2f32, 3f32] });
/// ```
#[lang = "div"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "cannot divide `{Self}` by `{Rhs}`",
    label = "no implementation for `{Self} / {Rhs}`"
)]
#[doc(alias = "/")]
pub trait Div<Rhs = Self> {
    /// `/` ഓപ്പറേറ്റർ പ്രയോഗിച്ചതിനുശേഷം ലഭിക്കുന്ന തരം.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output;

    /// `/` പ്രവർത്തനം നടത്തുന്നു.
    ///
    /// # Example
    ///
    /// ```
    /// assert_eq!(12 / 2, 6);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn div(self, rhs: Rhs) -> Self::Output;
}

macro_rules! div_impl_integer {
    ($($t:ty)*) => ($(
        /// ഈ പ്രവർത്തനം പൂജ്യത്തിലേക്ക് തിരിയുന്നു, കൃത്യമായ ഫലത്തിന്റെ ഏതെങ്കിലും ഭാഗത്തെ വെട്ടിച്ചുരുക്കുന്നു.
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Div for $t {
            type Output = $t;

            #[inline]
            fn div(self, other: $t) -> $t { self / other }
        }

        forward_ref_binop! { impl Div, div for $t, $t }
    )*)
}

div_impl_integer! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

macro_rules! div_impl_float {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Div for $t {
            type Output = $t;

            #[inline]
            fn div(self, other: $t) -> $t { self / other }
        }

        forward_ref_binop! { impl Div, div for $t, $t }
    )*)
}

div_impl_float! { f32 f64 }

/// ശേഷിക്കുന്ന ഓപ്പറേറ്റർ `%`.
///
/// `Rhs` സ്ഥിരസ്ഥിതിയായി `Self` ആണെന്നത് ശ്രദ്ധിക്കുക, പക്ഷേ ഇത് നിർബന്ധമല്ല.
///
/// # Examples
///
/// ഈ ഉദാഹരണം ഒരു `SplitSlice` ഒബ്‌ജക്റ്റിൽ `Rem` നടപ്പിലാക്കുന്നു.
/// `Rem` നടപ്പിലാക്കിയ ശേഷം, ഒരു നിശ്ചിത നീളത്തിന്റെ തുല്യ കഷണങ്ങളായി വിഭജിച്ച ശേഷം സ്ലൈസിന്റെ ശേഷിക്കുന്ന ഘടകങ്ങൾ എന്താണെന്ന് കണ്ടെത്താൻ ഒരാൾക്ക് `%` ഓപ്പറേറ്റർ ഉപയോഗിക്കാം.
///
///
/// ```
/// use std::ops::Rem;
///
/// #[derive(PartialEq, Debug)]
/// struct SplitSlice<'a, T: 'a> {
///     slice: &'a [T],
/// }
///
/// impl<'a, T> Rem<usize> for SplitSlice<'a, T> {
///     type Output = Self;
///
///     fn rem(self, modulus: usize) -> Self::Output {
///         let len = self.slice.len();
///         let rem = len % modulus;
///         let start = len - rem;
///         Self {slice: &self.slice[start..]}
///     }
/// }
///
/// // &[0, 1, 2, 3, 4, 5, 6, 7] നെ 3 വലുപ്പമുള്ള കഷണങ്ങളായി വിഭജിക്കുകയാണെങ്കിൽ, ബാക്കിയുള്ളത്&[6, 7] ആയിരിക്കും.
/////
/// assert_eq!(SplitSlice { slice: &[0, 1, 2, 3, 4, 5, 6, 7] } % 3,
///            SplitSlice { slice: &[6, 7] });
/// ```
///
#[lang = "rem"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "cannot mod `{Self}` by `{Rhs}`",
    label = "no implementation for `{Self} % {Rhs}`"
)]
#[doc(alias = "%")]
pub trait Rem<Rhs = Self> {
    /// `%` ഓപ്പറേറ്റർ പ്രയോഗിച്ചതിനുശേഷം ലഭിക്കുന്ന തരം.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output;

    /// `%` പ്രവർത്തനം നടത്തുന്നു.
    ///
    /// # Example
    ///
    /// ```
    /// assert_eq!(12 % 10, 2);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rem(self, rhs: Rhs) -> Self::Output;
}

macro_rules! rem_impl_integer {
    ($($t:ty)*) => ($(
        /// ഈ പ്രവർത്തനം `n % d == n - (n / d) * d`-നെ തൃപ്തിപ്പെടുത്തുന്നു.
        /// ഫലത്തിന് ഇടത് ഓപ്പറാൻഡിന് സമാനമായ ചിഹ്നമുണ്ട്.
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Rem for $t {
            type Output = $t;

            #[inline]
            fn rem(self, other: $t) -> $t { self % other }
        }

        forward_ref_binop! { impl Rem, rem for $t, $t }
    )*)
}

rem_impl_integer! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 }

macro_rules! rem_impl_float {
    ($($t:ty)*) => ($(

        /// ബാക്കിയുള്ളത് രണ്ട് ഫ്ലോട്ടുകളുടെ വിഭജനത്തിൽ നിന്ന്.
        ///
        /// ബാക്കിയുള്ളവയ്ക്ക് ഡിവിഡന്റിന് സമാനമായ ചിഹ്നമുണ്ട്, ഇത് കണക്കാക്കുന്നത്: `x - (x / y).trunc() * y`.
        ///
        /// # Examples
        ///
        /// ```
        /// let x: f32 = 50.50;
        /// let y: f32 = 8.125;
        /// let remainder = x - (x / y).trunc() * y;
        ///
        /// // രണ്ട് പ്രവർത്തനങ്ങൾക്കും ഉത്തരം 1.75 ആണ്
        /// assert_eq!(x % y, remainder);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Rem for $t {
            type Output = $t;

            #[inline]
            fn rem(self, other: $t) -> $t { self % other }
        }

        forward_ref_binop! { impl Rem, rem for $t, $t }
    )*)
}

rem_impl_float! { f32 f64 }

/// ഏകീകൃത നിർദേശ ഓപ്പറേറ്റർ `-`.
///
/// # Examples
///
/// `Sign`-നായി `Neg` നടപ്പിലാക്കൽ, ഇത് `-` ന്റെ മൂല്യം നിരസിക്കാൻ അനുവദിക്കുന്നു.
///
///
/// ```
/// use std::ops::Neg;
///
/// #[derive(Debug, PartialEq)]
/// enum Sign {
///     Negative,
///     Zero,
///     Positive,
/// }
///
/// impl Neg for Sign {
///     type Output = Self;
///
///     fn neg(self) -> Self::Output {
///         match self {
///             Sign::Negative => Sign::Positive,
///             Sign::Zero => Sign::Zero,
///             Sign::Positive => Sign::Negative,
///         }
///     }
/// }
///
/// // ഒരു നെഗറ്റീവ് പോസിറ്റീവ് ഒരു നെഗറ്റീവ് ആണ്.
/// assert_eq!(-Sign::Positive, Sign::Negative);
/// // ഇരട്ട നെഗറ്റീവ് ഒരു പോസിറ്റീവ് ആണ്.
/// assert_eq!(-Sign::Negative, Sign::Positive);
/// // പൂജ്യം അതിന്റെ തന്നെ നിർദേശമാണ്.
/// assert_eq!(-Sign::Zero, Sign::Zero);
/// ```
#[lang = "neg"]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "-")]
pub trait Neg {
    /// `-` ഓപ്പറേറ്റർ പ്രയോഗിച്ചതിനുശേഷം ലഭിക്കുന്ന തരം.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output;

    /// ഏകീകൃത `-` പ്രവർത്തനം നടത്തുന്നു.
    ///
    /// # Example
    ///
    /// ```
    /// let x: i32 = 12;
    /// assert_eq!(-x, -12);
    /// ```
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn neg(self) -> Self::Output;
}

macro_rules! neg_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl Neg for $t {
            type Output = $t;

            #[inline]
            #[rustc_inherit_overflow_checks]
            fn neg(self) -> $t { -self }
        }

        forward_ref_unop! { impl Neg, neg for $t }
    )*)
}

neg_impl! { isize i8 i16 i32 i64 i128 f32 f64 }

/// സങ്കലന അസൈൻ‌മെന്റ് ഓപ്പറേറ്റർ‌`+=`.
///
/// # Examples
///
/// ഈ ഉദാഹരണം `AddAssign` trait നടപ്പിലാക്കുന്ന ഒരു `Point` സ്ട്രക്റ്റ് സൃഷ്ടിക്കുന്നു, തുടർന്ന് ഒരു മ്യൂട്ടബിൾ `Point`-ലേക്ക് ആഡ്-അസൈനിംഗ് കാണിക്കുന്നു.
///
///
/// ```
/// use std::ops::AddAssign;
///
/// #[derive(Debug, Copy, Clone, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl AddAssign for Point {
///     fn add_assign(&mut self, other: Self) {
///         *self = Self {
///             x: self.x + other.x,
///             y: self.y + other.y,
///         };
///     }
/// }
///
/// let mut point = Point { x: 1, y: 0 };
/// point += Point { x: 2, y: 3 };
/// assert_eq!(point, Point { x: 3, y: 3 });
/// ```
#[lang = "add_assign"]
#[stable(feature = "op_assign_traits", since = "1.8.0")]
#[rustc_on_unimplemented(
    message = "cannot add-assign `{Rhs}` to `{Self}`",
    label = "no implementation for `{Self} += {Rhs}`"
)]
#[doc(alias = "+")]
#[doc(alias = "+=")]
pub trait AddAssign<Rhs = Self> {
    /// `+=` പ്രവർത്തനം നടത്തുന്നു.
    ///
    /// # Example
    ///
    /// ```
    /// let mut x: u32 = 12;
    /// x += 1;
    /// assert_eq!(x, 13);
    /// ```
    #[stable(feature = "op_assign_traits", since = "1.8.0")]
    fn add_assign(&mut self, rhs: Rhs);
}

macro_rules! add_assign_impl {
    ($($t:ty)+) => ($(
        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl AddAssign for $t {
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn add_assign(&mut self, other: $t) { *self += other }
        }

        forward_ref_op_assign! { impl AddAssign, add_assign for $t, $t }
    )+)
}

add_assign_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64 }

/// കുറയ്ക്കൽ അസൈൻമെന്റ് ഓപ്പറേറ്റർ `-=`.
///
/// # Examples
///
/// ഈ ഉദാഹരണം `SubAssign` trait നടപ്പിലാക്കുന്ന ഒരു `Point` സ്ട്രക്റ്റ് സൃഷ്ടിക്കുന്നു, തുടർന്ന് ഒരു മ്യൂട്ടബിൾ `Point`-ലേക്ക് ഉപ-അസൈനിംഗ് കാണിക്കുന്നു.
///
///
/// ```
/// use std::ops::SubAssign;
///
/// #[derive(Debug, Copy, Clone, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32,
/// }
///
/// impl SubAssign for Point {
///     fn sub_assign(&mut self, other: Self) {
///         *self = Self {
///             x: self.x - other.x,
///             y: self.y - other.y,
///         };
///     }
/// }
///
/// let mut point = Point { x: 3, y: 3 };
/// point -= Point { x: 2, y: 3 };
/// assert_eq!(point, Point {x: 1, y: 0});
/// ```
#[lang = "sub_assign"]
#[stable(feature = "op_assign_traits", since = "1.8.0")]
#[rustc_on_unimplemented(
    message = "cannot subtract-assign `{Rhs}` from `{Self}`",
    label = "no implementation for `{Self} -= {Rhs}`"
)]
#[doc(alias = "-")]
#[doc(alias = "-=")]
pub trait SubAssign<Rhs = Self> {
    /// `-=` പ്രവർത്തനം നടത്തുന്നു.
    ///
    /// # Example
    ///
    /// ```
    /// let mut x: u32 = 12;
    /// x -= 1;
    /// assert_eq!(x, 11);
    /// ```
    #[stable(feature = "op_assign_traits", since = "1.8.0")]
    fn sub_assign(&mut self, rhs: Rhs);
}

macro_rules! sub_assign_impl {
    ($($t:ty)+) => ($(
        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl SubAssign for $t {
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn sub_assign(&mut self, other: $t) { *self -= other }
        }

        forward_ref_op_assign! { impl SubAssign, sub_assign for $t, $t }
    )+)
}

sub_assign_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64 }

/// ഗുണന അസൈൻമെന്റ് ഓപ്പറേറ്റർ `*=`.
///
/// # Examples
///
/// ```
/// use std::ops::MulAssign;
///
/// #[derive(Debug, PartialEq)]
/// struct Frequency { hertz: f64 }
///
/// impl MulAssign<f64> for Frequency {
///     fn mul_assign(&mut self, rhs: f64) {
///         self.hertz *= rhs;
///     }
/// }
///
/// let mut frequency = Frequency { hertz: 50.0 };
/// frequency *= 4.0;
/// assert_eq!(Frequency { hertz: 200.0 }, frequency);
/// ```
#[lang = "mul_assign"]
#[stable(feature = "op_assign_traits", since = "1.8.0")]
#[rustc_on_unimplemented(
    message = "cannot multiply-assign `{Self}` by `{Rhs}`",
    label = "no implementation for `{Self} *= {Rhs}`"
)]
#[doc(alias = "*")]
#[doc(alias = "*=")]
pub trait MulAssign<Rhs = Self> {
    /// `*=` പ്രവർത്തനം നടത്തുന്നു.
    ///
    /// # Example
    ///
    /// ```
    /// let mut x: u32 = 12;
    /// x *= 2;
    /// assert_eq!(x, 24);
    /// ```
    #[stable(feature = "op_assign_traits", since = "1.8.0")]
    fn mul_assign(&mut self, rhs: Rhs);
}

macro_rules! mul_assign_impl {
    ($($t:ty)+) => ($(
        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl MulAssign for $t {
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn mul_assign(&mut self, other: $t) { *self *= other }
        }

        forward_ref_op_assign! { impl MulAssign, mul_assign for $t, $t }
    )+)
}

mul_assign_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64 }

/// ഡിവിഷൻ അസൈൻമെന്റ് ഓപ്പറേറ്റർ `/=`.
///
/// # Examples
///
/// ```
/// use std::ops::DivAssign;
///
/// #[derive(Debug, PartialEq)]
/// struct Frequency { hertz: f64 }
///
/// impl DivAssign<f64> for Frequency {
///     fn div_assign(&mut self, rhs: f64) {
///         self.hertz /= rhs;
///     }
/// }
///
/// let mut frequency = Frequency { hertz: 200.0 };
/// frequency /= 4.0;
/// assert_eq!(Frequency { hertz: 50.0 }, frequency);
/// ```
#[lang = "div_assign"]
#[stable(feature = "op_assign_traits", since = "1.8.0")]
#[rustc_on_unimplemented(
    message = "cannot divide-assign `{Self}` by `{Rhs}`",
    label = "no implementation for `{Self} /= {Rhs}`"
)]
#[doc(alias = "/")]
#[doc(alias = "/=")]
pub trait DivAssign<Rhs = Self> {
    /// `/=` പ്രവർത്തനം നടത്തുന്നു.
    ///
    /// # Example
    ///
    /// ```
    /// let mut x: u32 = 12;
    /// x /= 2;
    /// assert_eq!(x, 6);
    /// ```
    #[stable(feature = "op_assign_traits", since = "1.8.0")]
    fn div_assign(&mut self, rhs: Rhs);
}

macro_rules! div_assign_impl {
    ($($t:ty)+) => ($(
        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl DivAssign for $t {
            #[inline]
            fn div_assign(&mut self, other: $t) { *self /= other }
        }

        forward_ref_op_assign! { impl DivAssign, div_assign for $t, $t }
    )+)
}

div_assign_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64 }

/// ശേഷിക്കുന്ന അസൈൻമെന്റ് ഓപ്പറേറ്റർ `%=`.
///
/// # Examples
///
/// ```
/// use std::ops::RemAssign;
///
/// struct CookieJar { cookies: u32 }
///
/// impl RemAssign<u32> for CookieJar {
///     fn rem_assign(&mut self, piles: u32) {
///         self.cookies %= piles;
///     }
/// }
///
/// let mut jar = CookieJar { cookies: 31 };
/// let piles = 4;
///
/// println!("Splitting up {} cookies into {} even piles!", jar.cookies, piles);
///
/// jar %= piles;
///
/// println!("{} cookies remain in the cookie jar!", jar.cookies);
/// ```
#[lang = "rem_assign"]
#[stable(feature = "op_assign_traits", since = "1.8.0")]
#[rustc_on_unimplemented(
    message = "cannot mod-assign `{Self}` by `{Rhs}``",
    label = "no implementation for `{Self} %= {Rhs}`"
)]
#[doc(alias = "%")]
#[doc(alias = "%=")]
pub trait RemAssign<Rhs = Self> {
    /// `%=` പ്രവർത്തനം നടത്തുന്നു.
    ///
    /// # Example
    ///
    /// ```
    /// let mut x: u32 = 12;
    /// x %= 10;
    /// assert_eq!(x, 2);
    /// ```
    #[stable(feature = "op_assign_traits", since = "1.8.0")]
    fn rem_assign(&mut self, rhs: Rhs);
}

macro_rules! rem_assign_impl {
    ($($t:ty)+) => ($(
        #[stable(feature = "op_assign_traits", since = "1.8.0")]
        impl RemAssign for $t {
            #[inline]
            fn rem_assign(&mut self, other: $t) { *self %= other }
        }

        forward_ref_op_assign! { impl RemAssign, rem_assign for $t, $t }
    )+)
}

rem_assign_impl! { usize u8 u16 u32 u64 u128 isize i8 i16 i32 i64 i128 f32 f64 }