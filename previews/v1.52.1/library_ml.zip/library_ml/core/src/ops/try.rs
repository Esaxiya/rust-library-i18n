/// `?` ഓപ്പറേറ്ററിന്റെ സ്വഭാവം ഇഷ്‌ടാനുസൃതമാക്കുന്നതിനുള്ള ഒരു trait.
///
/// `Try` നടപ്പിലാക്കുന്ന ഒരു തരം, success/failure ദ്വിരൂപത്തിന്റെ അടിസ്ഥാനത്തിൽ ഇത് കാണുന്നതിന് കാനോനിക്കൽ മാർഗമുണ്ട്.
/// നിലവിലുള്ള ഒരു ഉദാഹരണത്തിൽ നിന്ന് ആ വിജയമോ പരാജയ മൂല്യങ്ങളോ വേർതിരിച്ചെടുക്കാനും വിജയത്തിൽ നിന്നോ പരാജയ മൂല്യത്തിൽ നിന്നോ ഒരു പുതിയ ഉദാഹരണം സൃഷ്ടിക്കാനും ഈ trait അനുവദിക്കുന്നു.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// വിജയകരമായി കാണുമ്പോൾ ഈ മൂല്യത്തിന്റെ തരം.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// പരാജയപ്പെട്ടതായി കാണുമ്പോൾ ഈ മൂല്യത്തിന്റെ തരം.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// "?" ഓപ്പറേറ്റർ പ്രയോഗിക്കുന്നു.`Ok(t)` ന്റെ മടങ്ങിവരവ് അർത്ഥമാക്കുന്നത് എക്സിക്യൂഷൻ സാധാരണഗതിയിൽ തുടരണമെന്നാണ്, കൂടാതെ `?` ന്റെ ഫലം `t` മൂല്യം ആണ്.
    /// `Err(e)` ന്റെ മടങ്ങിവരവ് അർത്ഥമാക്കുന്നത് എക്സിക്യൂഷൻ branch ഉള്ളിലെ ഏറ്റവും അടുത്തുള്ള `catch` ലേക്ക് അല്ലെങ്കിൽ ഫംഗ്ഷനിൽ നിന്ന് മടങ്ങണം എന്നാണ്.
    ///
    /// ഒരു `Err(e)` ഫലം മടക്കിനൽകുകയാണെങ്കിൽ, എൻ‌ക്ലോസിംഗ് സ്കോപ്പിന്റെ റിട്ടേൺ തരത്തിൽ `e` മൂല്യം "wrapped" ആയിരിക്കും (അത് തന്നെ `Try` നടപ്പിലാക്കണം).
    ///
    /// പ്രത്യേകിച്ചും, `X::from_error(From::from(e))` മൂല്യം മടക്കിനൽകുന്നു, ഇവിടെ `X` എന്നത് എൻ‌ക്ലോസിംഗ് ഫംഗ്ഷന്റെ റിട്ടേൺ തരമാണ്.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// സംയോജിത ഫലം നിർമ്മിക്കുന്നതിന് ഒരു പിശക് മൂല്യം പൊതിയുക.
    /// ഉദാഹരണത്തിന്, `Result::Err(x)`, `Result::from_error(x)` എന്നിവ തുല്യമാണ്.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// സംയോജിത ഫലം നിർമ്മിക്കുന്നതിന് ഒരു ശരി മൂല്യം പൊതിയുക.
    /// ഉദാഹരണത്തിന്, `Result::Ok(x)`, `Result::from_ok(x)` എന്നിവ തുല്യമാണ്.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}