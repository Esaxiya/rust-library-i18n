use crate::marker::Unsize;

/// Trait ഇത് ഒരു പോയിന്റർ അല്ലെങ്കിൽ ഒന്നിനുള്ള റാപ്പർ ആണെന്ന് സൂചിപ്പിക്കുന്നു, അവിടെ പോയിന്റിൽ വലുപ്പം മാറ്റാൻ കഴിയും.
///
/// കൂടുതൽ വിവരങ്ങൾക്ക് [DST coercion RFC][dst-coerce], [the nomicon entry on coercion][nomicon-coerce] എന്നിവ കാണുക.
///
/// ബിൽഡിൻ പോയിന്റർ തരങ്ങൾക്കായി, നേർത്ത പോയിന്ററിൽ നിന്ന് കൊഴുപ്പ് പോയിന്ററിലേക്ക് പരിവർത്തനം ചെയ്യുന്നതിലൂടെ `T: Unsize<U>` ആണെങ്കിൽ `T`-ലേക്ക് പോയിന്ററുകൾ `U`-ലേക്ക് പോയിന്ററുകളിലേക്ക് നിർബന്ധിക്കും.
///
/// ഇഷ്‌ടാനുസൃത തരങ്ങൾക്കായി, `CoerceUnsized<Foo<U>> for Foo<T>`-ന്റെ ഒരു impl നിലവിലുണ്ടെങ്കിൽ `Foo<T>`-നെ `Foo<U>`-ലേക്ക് നിർബന്ധിച്ചുകൊണ്ട് ഇവിടെ നിർബ്ബന്ധം പ്രവർത്തിക്കുന്നു.
/// `Foo<T>`-ന് `T` ഉൾപ്പെടുന്ന ഒരു നോൺ-ഫാന്റംഡേറ്റ ഫീൽഡ് മാത്രമേ ഉള്ളൂവെങ്കിൽ മാത്രമേ അത്തരം ഒരു impl എഴുതാൻ കഴിയൂ.
/// ആ ഫീൽഡിന്റെ തരം `Bar<T>` ആണെങ്കിൽ, `CoerceUnsized<Bar<U>> for Bar<T>` നടപ്പിലാക്കൽ നിലനിൽക്കണം.
/// `Bar<T>` ഫീൽഡിനെ `Bar<U>`-ലേക്ക് നിർബന്ധിച്ച് `Foo<T>`-ൽ നിന്ന് ബാക്കി ഫീൽഡുകൾ പൂരിപ്പിച്ച് ഒരു `Foo<U>` സൃഷ്ടിക്കാൻ നിർബന്ധിതരാകും.
/// ഇത് ഫലപ്രദമായി ഒരു പോയിന്റർ ഫീൽഡിലേക്ക് തുരന്ന് അത് നിർബന്ധിക്കും.
///
/// സാധാരണയായി, സ്മാർട്ട് പോയിന്ററുകൾക്കായി നിങ്ങൾ `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized` നടപ്പിലാക്കും, ഓപ്ഷണൽ `?Sized` `T`-ൽ തന്നെ ബന്ധപ്പെട്ടിരിക്കുന്നു.
/// `Cell<T>`, `RefCell<T>` പോലുള്ള `T` നേരിട്ട് ഉൾച്ചേർക്കുന്ന റാപ്പർ തരങ്ങൾക്കായി, നിങ്ങൾക്ക് നേരിട്ട് `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` നടപ്പിലാക്കാൻ കഴിയും.
///
/// ഇത് `Cell<Box<T>>` പോലുള്ള തരത്തിലുള്ള നിർബന്ധിത പ്രവർത്തിക്കാൻ അനുവദിക്കും.
///
/// [`Unsize`][unsize] പോയിന്ററുകൾക്ക് പിന്നിലാണെങ്കിൽ ഡിഎസ്ടികളിലേക്ക് നിർബന്ധിക്കാൻ കഴിയുന്ന തരങ്ങൾ അടയാളപ്പെടുത്താൻ ഉപയോഗിക്കുന്നു.ഇത് കംപൈലർ യാന്ത്രികമായി നടപ്പിലാക്കുന്നു.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut ടി-> &mut യു
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut ടി-> എക്സ് 00 എക്സ്
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut ടി-> * മ്യൂട്ട് യു
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut ടി-> * const യു
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *const T->* const U.
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// ഒബ്ജക്റ്റ് സുരക്ഷയ്ക്കായി ഇത് ഉപയോഗിക്കുന്നു, ഒരു രീതിയുടെ റിസീവർ തരം അയയ്ക്കാൻ കഴിയുമോ എന്ന് പരിശോധിക്കാൻ.
///
/// trait നടപ്പിലാക്കുന്നതിനുള്ള ഒരു ഉദാഹരണം:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut ടി-> &mut യു
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *const T->* const U.
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U.
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}