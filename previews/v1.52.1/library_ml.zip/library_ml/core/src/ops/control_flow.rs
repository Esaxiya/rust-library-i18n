use crate::ops::Try;

/// ഒരു ഓപ്പറേഷൻ നേരത്തേ പുറത്തുകടക്കണോ അതോ പതിവുപോലെ പോകണോ എന്ന് പറയാൻ ഉപയോഗിക്കുന്നു.
///
/// നേരത്തേ പുറത്തുകടക്കണോ എന്ന് ഉപയോക്താവിന് തിരഞ്ഞെടുക്കണമെന്ന് നിങ്ങൾ ആഗ്രഹിക്കുന്നിടത്ത് (ഗ്രാഫ് ട്രാവെർസലുകൾ അല്ലെങ്കിൽ സന്ദർശകർ പോലുള്ളവ) കാര്യങ്ങൾ വെളിപ്പെടുത്തുമ്പോൾ ഇത് ഉപയോഗിക്കുന്നു.
/// ഇനീം ഉള്ളത് കൂടുതൽ വ്യക്തമാക്കുന്നു-അതിശയിക്കാനില്ലാത്ത "wait, what did `false` mean again?"-ഒരു മൂല്യം ഉൾപ്പെടുത്താൻ അനുവദിക്കുന്നു.
///
/// # Examples
///
/// [`Iterator::try_for_each`]-ൽ നിന്ന് നേരത്തേ പുറത്തുകടക്കുന്നു:
///
/// ```
/// #![feature(control_flow_enum)]
/// use std::ops::ControlFlow;
///
/// let r = (2..100).try_for_each(|x| {
///     if 403 % x == 0 {
///         return ControlFlow::Break(x)
///     }
///
///     ControlFlow::Continue(())
/// });
/// assert_eq!(r, ControlFlow::Break(13));
/// ```
///
/// ഒരു അടിസ്ഥാന ട്രീ ട്രാവെർസൽ:
///
/// ```no_run
/// #![feature(control_flow_enum)]
/// use std::ops::ControlFlow;
///
/// pub struct TreeNode<T> {
///     value: T,
///     left: Option<Box<TreeNode<T>>>,
///     right: Option<Box<TreeNode<T>>>,
/// }
///
/// impl<T> TreeNode<T> {
///     pub fn traverse_inorder<B>(&self, mut f: impl FnMut(&T) -> ControlFlow<B>) -> ControlFlow<B> {
///         if let Some(left) = &self.left {
///             left.traverse_inorder(&mut f)?;
///         }
///         f(&self.value)?;
///         if let Some(right) = &self.right {
///             right.traverse_inorder(&mut f)?;
///         }
///         ControlFlow::Continue(())
///     }
/// }
/// ```
#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum ControlFlow<B, C = ()> {
    /// പ്രവർത്തനത്തിന്റെ അടുത്ത ഘട്ടത്തിലേക്ക് സാധാരണപോലെ നീങ്ങുക.
    Continue(C),
    /// തുടർന്നുള്ള ഘട്ടങ്ങൾ പ്രവർത്തിപ്പിക്കാതെ പ്രവർത്തനത്തിൽ നിന്ന് പുറത്തുകടക്കുക.
    Break(B),
    // അതെ, വേരിയന്റുകളുടെ ക്രമം തരം പാരാമീറ്ററുകളുമായി പൊരുത്തപ്പെടുന്നില്ല.
    // അവർ ഈ ക്രമത്തിലാണ്, അതിനാൽ `ControlFlow<A, B>`<-> `Result<B, A>` എന്നത് `Try` നടപ്പിലാക്കലിലെ ഒരു നോ-ഒപ്പ് പരിവർത്തനമാണ്.
    //
}

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
impl<B, C> Try for ControlFlow<B, C> {
    type Ok = C;
    type Error = B;
    #[inline]
    fn into_result(self) -> Result<Self::Ok, Self::Error> {
        match self {
            ControlFlow::Continue(y) => Ok(y),
            ControlFlow::Break(x) => Err(x),
        }
    }
    #[inline]
    fn from_error(v: Self::Error) -> Self {
        ControlFlow::Break(v)
    }
    #[inline]
    fn from_ok(v: Self::Ok) -> Self {
        ControlFlow::Continue(v)
    }
}

impl<B, C> ControlFlow<B, C> {
    /// ഇതൊരു `Break` വേരിയന്റാണെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// assert!(ControlFlow::<i32, String>::Break(3).is_break());
    /// assert!(!ControlFlow::<String, i32>::Continue(3).is_break());
    /// ```
    #[inline]
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub fn is_break(&self) -> bool {
        matches!(*self, ControlFlow::Break(_))
    }

    /// ഇതൊരു `Continue` വേരിയന്റാണെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// assert!(!ControlFlow::<i32, String>::Break(3).is_continue());
    /// assert!(ControlFlow::<String, i32>::Continue(3).is_continue());
    /// ```
    #[inline]
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub fn is_continue(&self) -> bool {
        matches!(*self, ControlFlow::Continue(_))
    }

    /// `ControlFlow` നെ `Option` ആക്കി മാറ്റുന്നു, അത് `ControlFlow` `Break` ഉം `None` ഉം ആണെങ്കിൽ `Some` ആണ്.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// assert_eq!(ControlFlow::<i32, String>::Break(3).break_value(), Some(3));
    /// assert_eq!(ControlFlow::<String, i32>::Continue(3).break_value(), None);
    /// ```
    #[inline]
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub fn break_value(self) -> Option<B> {
        match self {
            ControlFlow::Continue(..) => None,
            ControlFlow::Break(x) => Some(x),
        }
    }

    /// ബ്രേക്ക് മൂല്യത്തിലാണെങ്കിൽ ഒരു ഫംഗ്ഷൻ പ്രയോഗിച്ചുകൊണ്ട് `ControlFlow<B, C>` മുതൽ `ControlFlow<T, C>` വരെ മാപ്പുകൾ.
    ///
    #[inline]
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub fn map_break<T, F>(self, f: F) -> ControlFlow<T, C>
    where
        F: FnOnce(B) -> T,
    {
        match self {
            ControlFlow::Continue(x) => ControlFlow::Continue(x),
            ControlFlow::Break(x) => ControlFlow::Break(f(x)),
        }
    }
}

impl<R: Try> ControlFlow<R, R::Ok> {
    /// `Try` നടപ്പിലാക്കുന്ന ഏത് തരത്തിൽ നിന്നും ഒരു `ControlFlow` സൃഷ്ടിക്കുക.
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    #[inline]
    pub fn from_try(r: R) -> Self {
        match Try::into_result(r) {
            Ok(v) => ControlFlow::Continue(v),
            Err(v) => ControlFlow::Break(Try::from_error(v)),
        }
    }

    /// `Try` നടപ്പിലാക്കുന്ന ഏത് തരത്തിലേക്കും ഒരു `ControlFlow` പരിവർത്തനം ചെയ്യുക;
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    #[inline]
    pub fn into_try(self) -> R {
        match self {
            ControlFlow::Continue(v) => Try::from_ok(v),
            ControlFlow::Break(v) => v,
        }
    }
}

impl<B> ControlFlow<B, ()> {
    /// `Continue`-ന് ഒരു മൂല്യവും ആവശ്യമില്ലെന്നത് പതിവായി സംഭവിക്കുന്നു, അതിനാൽ `(())` ടൈപ്പുചെയ്യുന്നത് ഒഴിവാക്കാൻ ഇത് ഒരു മാർഗ്ഗം നൽകുന്നു, നിങ്ങൾ ആഗ്രഹിക്കുന്നുവെങ്കിൽ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// let mut partial_sum = 0;
    /// let last_used = (1..10).chain(20..25).try_for_each(|x| {
    ///     partial_sum += x;
    ///     if partial_sum > 100 { ControlFlow::Break(x) }
    ///     else { ControlFlow::CONTINUE }
    /// });
    /// assert_eq!(last_used.break_value(), Some(22));
    /// ```
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub const CONTINUE: Self = ControlFlow::Continue(());
}

impl<C> ControlFlow<(), C> {
    /// `try_for_each` പോലുള്ള API-കൾക്ക് `Break`-നൊപ്പം മൂല്യങ്ങൾ ആവശ്യമില്ല, അതിനാൽ `(())` ടൈപ്പുചെയ്യുന്നത് ഒഴിവാക്കാൻ ഇത് ഒരു മാർഗ്ഗം നൽകുന്നു, നിങ്ങൾ ആഗ്രഹിക്കുന്നുവെങ്കിൽ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(control_flow_enum)]
    /// use std::ops::ControlFlow;
    ///
    /// let mut partial_sum = 0;
    /// (1..10).chain(20..25).try_for_each(|x| {
    ///     if partial_sum > 100 { ControlFlow::BREAK }
    ///     else { partial_sum += x; ControlFlow::CONTINUE }
    /// });
    /// assert_eq!(partial_sum, 108);
    /// ```
    #[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
    pub const BREAK: Self = ControlFlow::Break(());
}