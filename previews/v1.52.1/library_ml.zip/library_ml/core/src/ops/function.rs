/// മാറ്റമില്ലാത്ത റിസീവർ എടുക്കുന്ന കോൾ ഓപ്പറേറ്ററുടെ പതിപ്പ്.
///
/// `Fn` ന്റെ സംഭവങ്ങൾ പരിവർത്തനം ചെയ്യാതെ ആവർത്തിച്ച് വിളിക്കാം.
///
/// *ഈ trait (`Fn`), [function pointers] (`fn`) മായി തെറ്റിദ്ധരിക്കരുത്.*
///
/// `Fn` ക്യാപ്‌ചർ ചെയ്‌ത വേരിയബിളുകളിലേക്ക് മാറ്റമില്ലാത്ത റഫറൻസുകൾ മാത്രം എടുക്കുന്ന അല്ലെങ്കിൽ ഒന്നും പിടിച്ചെടുക്കാത്ത ക്ലോസറുകളിലൂടെ യാന്ത്രികമായി നടപ്പിലാക്കുന്നു, അതുപോലെ തന്നെ (safe) [function pointers] (ചില മുന്നറിയിപ്പുകൾക്കൊപ്പം, കൂടുതൽ വിശദാംശങ്ങൾക്കായി അവരുടെ ഡോക്യുമെന്റേഷൻ കാണുക).
///
/// കൂടാതെ, `Fn` നടപ്പിലാക്കുന്ന ഏത് തരം `F` നും, `&F`, `Fn` ഉം നടപ്പിലാക്കുന്നു.
///
/// [`FnMut`], [`FnOnce`] എന്നിവ രണ്ടും `Fn`-ന്റെ സൂപ്പർട്രെയ്റ്റുകളായതിനാൽ, `Fn`-ന്റെ ഏത് ഉദാഹരണവും [`FnMut`] അല്ലെങ്കിൽ [`FnOnce`] പ്രതീക്ഷിക്കുന്ന ഒരു പാരാമീറ്ററായി ഉപയോഗിക്കാൻ കഴിയും.
///
/// ഫംഗ്ഷൻ പോലുള്ള തരത്തിലുള്ള ഒരു പാരാമീറ്റർ സ്വീകരിക്കാൻ നിങ്ങൾ ആഗ്രഹിക്കുമ്പോഴും സംസ്ഥാനത്തെ പരിവർത്തനം ചെയ്യാതെയും ആവർത്തിച്ച് വിളിക്കേണ്ടതുണ്ടെങ്കിൽ (ഉദാ. ഒരേസമയം വിളിക്കുമ്പോൾ) `Fn` ഒരു ബൗണ്ടായി ഉപയോഗിക്കുക.
/// നിങ്ങൾക്ക് അത്തരം കർശനമായ ആവശ്യകതകൾ ആവശ്യമില്ലെങ്കിൽ, അതിരുകളായി [`FnMut`] അല്ലെങ്കിൽ [`FnOnce`] ഉപയോഗിക്കുക.
///
/// ഈ വിഷയത്തെക്കുറിച്ചുള്ള കൂടുതൽ വിവരങ്ങൾക്ക് [chapter on closures in *The Rust Programming Language*][book] കാണുക.
///
/// `Fn` traits-നുള്ള പ്രത്യേക വാക്യഘടനയും ശ്രദ്ധേയമാണ് (ഉദാ
/// `Fn(usize, bool) -> usize`).ഇതിന്റെ സാങ്കേതിക വിശദാംശങ്ങളിൽ‌താൽ‌പ്പര്യമുള്ളവർക്ക് [the relevant section in the *Rustonomicon*][nomicon] റഫർ‌ചെയ്യാൻ‌കഴിയും.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## ഒരു അടയ്ക്കൽ വിളിക്കുന്നു
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## ഒരു `Fn` പാരാമീറ്റർ ഉപയോഗിക്കുന്നു
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // അതിനാൽ regex ന് ആ `&str: !FnMut` നെ ആശ്രയിക്കാൻ കഴിയും
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// കോൾ പ്രവർത്തനം നടത്തുന്നു.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// മ്യൂട്ടബിൾ റിസീവർ എടുക്കുന്ന കോൾ ഓപ്പറേറ്ററുടെ പതിപ്പ്.
///
/// `FnMut`-ന്റെ സംഭവങ്ങളെ ആവർത്തിച്ച് വിളിക്കുകയും അവസ്ഥയെ പരിവർത്തനം ചെയ്യുകയും ചെയ്യാം.
///
/// `FnMut` ക്യാപ്‌ചർ ചെയ്‌ത വേരിയബിളുകളിലേക്ക് മ്യൂട്ടബിൾ റഫറൻസുകൾ എടുക്കുന്ന ക്ലോസറുകളും അതുപോലെ തന്നെ [`Fn`], ഉദാ. (safe) [function pointers] നടപ്പിലാക്കുന്ന എല്ലാ തരങ്ങളും സ്വപ്രേരിതമായി നടപ്പിലാക്കുന്നു (`FnMut` [`Fn`]-ന്റെ സൂപ്പർട്രെയിറ്റ് ആയതിനാൽ).
/// കൂടാതെ, `FnMut` നടപ്പിലാക്കുന്ന ഏത് തരം `F` നും, `&mut F`, `FnMut` ഉം നടപ്പിലാക്കുന്നു.
///
/// [`FnOnce`] എന്നത് `FnMut`-ന്റെ ഒരു സൂപ്പർട്രെയിറ്റ് ആയതിനാൽ, [`FnOnce`] പ്രതീക്ഷിക്കുന്നിടത്ത് `FnMut`-ന്റെ ഏത് ഉദാഹരണവും ഉപയോഗിക്കാൻ കഴിയും, കൂടാതെ [`Fn`] `FnMut`-ന്റെ ഒരു ഉപവിഭാഗമായതിനാൽ, `FnMut` പ്രതീക്ഷിക്കുന്നിടത്ത് [`Fn`]-ന്റെ ഏത് ഉദാഹരണവും ഉപയോഗിക്കാൻ കഴിയും.
///
/// ഫംഗ്ഷൻ പോലുള്ള തരത്തിന്റെ ഒരു പാരാമീറ്റർ സ്വീകരിക്കാൻ നിങ്ങൾ ആഗ്രഹിക്കുമ്പോൾ `FnMut` ഒരു ബൗണ്ടായി ഉപയോഗിക്കുക, അത് സംസ്ഥാനത്തെ പരിവർത്തനം ചെയ്യാൻ അനുവദിക്കുമ്പോൾ ആവർത്തിച്ച് വിളിക്കേണ്ടതുണ്ട്.
/// പാരാമീറ്റർ‌അവസ്ഥയെ പരിവർത്തനം ചെയ്യാൻ‌നിങ്ങൾ‌താൽ‌പ്പര്യപ്പെടുന്നില്ലെങ്കിൽ‌, [`Fn`] ഒരു ബ bound ണ്ടായി ഉപയോഗിക്കുക;നിങ്ങൾക്ക് ഇത് ആവർത്തിച്ച് വിളിക്കേണ്ട ആവശ്യമില്ലെങ്കിൽ, [`FnOnce`] ഉപയോഗിക്കുക.
///
/// ഈ വിഷയത്തെക്കുറിച്ചുള്ള കൂടുതൽ വിവരങ്ങൾക്ക് [chapter on closures in *The Rust Programming Language*][book] കാണുക.
///
/// `Fn` traits-നുള്ള പ്രത്യേക വാക്യഘടനയും ശ്രദ്ധേയമാണ് (ഉദാ
/// `Fn(usize, bool) -> usize`).ഇതിന്റെ സാങ്കേതിക വിശദാംശങ്ങളിൽ‌താൽ‌പ്പര്യമുള്ളവർക്ക് [the relevant section in the *Rustonomicon*][nomicon] റഫർ‌ചെയ്യാൻ‌കഴിയും.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## പരസ്പരം ക്യാപ്‌ചർ ചെയ്യുന്ന ക്ലോസറിനെ വിളിക്കുന്നു
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## ഒരു `FnMut` പാരാമീറ്റർ ഉപയോഗിക്കുന്നു
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // അതിനാൽ regex ന് ആ `&str: !FnMut` നെ ആശ്രയിക്കാൻ കഴിയും
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// കോൾ പ്രവർത്തനം നടത്തുന്നു.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// ഒരു ബൈ-വാല്യു റിസീവർ എടുക്കുന്ന കോൾ ഓപ്പറേറ്ററുടെ പതിപ്പ്.
///
/// `FnOnce` ന്റെ ഉദാഹരണങ്ങൾ‌വിളിക്കാൻ‌കഴിയും, പക്ഷേ ഒന്നിലധികം തവണ വിളിക്കാൻ‌കഴിയില്ല.ഇക്കാരണത്താൽ, ഒരു തരത്തെക്കുറിച്ച് അറിയാവുന്ന ഒരേയൊരു കാര്യം അത് `FnOnce` നടപ്പിലാക്കുന്നുവെങ്കിൽ, അതിനെ ഒരു തവണ മാത്രമേ വിളിക്കാൻ കഴിയൂ.
///
/// `FnOnce` ക്യാപ്‌ചർ ചെയ്‌ത വേരിയബിളുകളും [`FnMut`], ഉദാ. (safe) [function pointers] നടപ്പിലാക്കുന്ന എല്ലാ തരങ്ങളും അടയ്‌ക്കുന്ന ക്ലോസറുകൾ സ്വപ്രേരിതമായി നടപ്പിലാക്കുന്നു (`FnOnce` [`FnMut`]-ന്റെ സൂപ്പർട്രെയിറ്റ് ആയതിനാൽ).
///
///
/// [`Fn`], [`FnMut`] എന്നിവ രണ്ടും `FnOnce`-ന്റെ സബ്‌ട്രെയിറ്റുകളായതിനാൽ, `FnOnce` പ്രതീക്ഷിക്കുന്നിടത്ത് [`Fn`] അല്ലെങ്കിൽ [`FnMut`] ന്റെ ഏത് ഉദാഹരണവും ഉപയോഗിക്കാൻ കഴിയും.
///
/// ഫംഗ്ഷൻ പോലുള്ള തരത്തിലുള്ള ഒരു പാരാമീറ്റർ സ്വീകരിക്കാൻ നിങ്ങൾ ആഗ്രഹിക്കുമ്പോൾ `FnOnce` ഒരു ബൗണ്ടായി ഉപയോഗിക്കുക, ഒരു തവണ മാത്രം വിളിക്കേണ്ടതുണ്ട്.
/// നിങ്ങൾക്ക് പാരാമീറ്ററിനെ ആവർത്തിച്ച് വിളിക്കണമെങ്കിൽ, [`FnMut`] ഒരു ബൗണ്ടായി ഉപയോഗിക്കുക;അവസ്ഥ പരിവർത്തനം ചെയ്യാതിരിക്കാനും നിങ്ങൾക്കാവശ്യമുണ്ടെങ്കിൽ, [`Fn`] ഉപയോഗിക്കുക.
///
/// ഈ വിഷയത്തെക്കുറിച്ചുള്ള കൂടുതൽ വിവരങ്ങൾക്ക് [chapter on closures in *The Rust Programming Language*][book] കാണുക.
///
/// `Fn` traits-നുള്ള പ്രത്യേക വാക്യഘടനയും ശ്രദ്ധേയമാണ് (ഉദാ
/// `Fn(usize, bool) -> usize`).ഇതിന്റെ സാങ്കേതിക വിശദാംശങ്ങളിൽ‌താൽ‌പ്പര്യമുള്ളവർക്ക് [the relevant section in the *Rustonomicon*][nomicon] റഫർ‌ചെയ്യാൻ‌കഴിയും.
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## ഒരു `FnOnce` പാരാമീറ്റർ ഉപയോഗിക്കുന്നു
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` പിടിച്ചെടുത്ത വേരിയബിളുകൾ ഉപയോഗിക്കുന്നു, അതിനാൽ ഇത് ഒന്നിലധികം തവണ പ്രവർത്തിപ്പിക്കാൻ കഴിയില്ല.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // `func()` വീണ്ടും അഭ്യർത്ഥിക്കാൻ ശ്രമിക്കുന്നത് `func`-നായി ഒരു `use of moved value` പിശക് എറിയും.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` ഈ സമയത്ത് മേലിൽ അഭ്യർത്ഥിക്കാൻ കഴിയില്ല
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // അതിനാൽ regex ന് ആ `&str: !FnMut` നെ ആശ്രയിക്കാൻ കഴിയും
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// കോൾ ഓപ്പറേറ്റർ ഉപയോഗിച്ചതിന് ശേഷം മടങ്ങിയ തരം.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// കോൾ പ്രവർത്തനം നടത്തുന്നു.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}