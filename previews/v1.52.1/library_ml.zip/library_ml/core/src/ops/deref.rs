/// `*v` പോലുള്ള മാറ്റമില്ലാത്ത ഡീഫെറൻസിംഗ് പ്രവർത്തനങ്ങൾക്കായി ഉപയോഗിക്കുന്നു.
///
/// മാറ്റമില്ലാത്ത സന്ദർഭങ്ങളിൽ (unary) `*` ഓപ്പറേറ്ററുമൊത്തുള്ള വ്യക്തമായ ഡീഫറൻസിംഗ് പ്രവർത്തനങ്ങൾക്കായി ഉപയോഗിക്കുന്നതിനുപുറമെ, നിരവധി സാഹചര്യങ്ങളിൽ കംപൈലർ `Deref` വ്യക്തമായി ഉപയോഗിക്കുന്നു.
/// ഈ സംവിധാനത്തെ ['`Deref` coercion'][more] എന്ന് വിളിക്കുന്നു.
/// മ്യൂട്ടബിൾ സന്ദർഭങ്ങളിൽ, [`DerefMut`] ഉപയോഗിക്കുന്നു.
///
/// സ്മാർട്ട് പോയിന്ററുകൾക്കായി `Deref` നടപ്പിലാക്കുന്നത് അവരുടെ പിന്നിലുള്ള ഡാറ്റ ആക്‌സസ് ചെയ്യുന്നത് സൗകര്യപ്രദമാക്കുന്നു, അതിനാലാണ് അവർ `Deref` നടപ്പിലാക്കുന്നത്.
/// മറുവശത്ത്, എക്സ് 00 എക്സ്, എക്സ് 01 എക്സ് എന്നിവ സംബന്ധിച്ച നിയമങ്ങൾ സ്മാർട്ട് പോയിന്ററുകൾ ഉൾക്കൊള്ളുന്നതിനായി പ്രത്യേകം രൂപകൽപ്പന ചെയ്തിട്ടുണ്ട്.
/// ഇക്കാരണത്താൽ, ആശയക്കുഴപ്പം ഒഴിവാക്കാൻ **സ്മാർട്ട് പോയിന്ററുകൾക്ക് മാത്രമേ**`ഡെറെഫ്` നടപ്പിലാക്കാവൂ.
///
/// സമാന കാരണങ്ങളാൽ,**ഈ trait ഒരിക്കലും പരാജയപ്പെടരുത്**.എക്സ് 00 എക്സ് വ്യക്തമായി പ്രാവർത്തികമാക്കുമ്പോൾ ഡീഫെറൻസിംഗിലെ പരാജയം അങ്ങേയറ്റം ആശയക്കുഴപ്പത്തിലാക്കും.
///
/// # `Deref` ബലപ്രയോഗത്തിൽ കൂടുതൽ
///
/// `T` `Deref<Target = U>` നടപ്പിലാക്കുന്നുവെങ്കിൽ, `x` എന്നത് `T` തരത്തിന്റെ മൂല്യമാണെങ്കിൽ,
///
/// * മാറ്റമില്ലാത്ത സന്ദർഭങ്ങളിൽ, `*x` (ഇവിടെ `T` ഒരു റഫറൻസോ അസംസ്കൃത പോയിന്ററോ അല്ല) `* Deref::deref(&x)` ന് തുല്യമാണ്.
/// * `&T` തരം മൂല്യങ്ങൾ `&U` തരം മൂല്യങ്ങളിലേക്ക് നിർബന്ധിതമാണ്
/// * `T` `U` തരത്തിന്റെ എല്ലാ (immutable) രീതികളും വ്യക്തമായി നടപ്പിലാക്കുന്നു.
///
/// കൂടുതൽ വിവരങ്ങൾക്ക്, [the chapter in *The Rust Programming Language*][book], [the dereference operator][ref-deref-op], [method resolution], [type coercions] എന്നിവയിലെ റഫറൻസ് വിഭാഗങ്ങളും സന്ദർശിക്കുക.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// ഒരൊറ്റ ഫീൽഡുള്ള ഒരു സ്ട്രക്റ്റ്, അത് സ്ട്രക്റ്റ് ഡീഫെറൻസ് ചെയ്തുകൊണ്ട് ആക്സസ് ചെയ്യാൻ കഴിയും.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// ഡീഫെറൻസിംഗിന് ശേഷം ഉണ്ടാകുന്ന തരം.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// മൂല്യം ഇല്ലാതാക്കുന്നു.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// `*v = 1;` പോലെ, മ്യൂട്ടബിൾ ഡീഫറൻസിംഗ് പ്രവർത്തനങ്ങൾക്കായി ഉപയോഗിക്കുന്നു.
///
/// മ്യൂട്ടബിൾ സന്ദർഭങ്ങളിൽ (unary) `*` ഓപ്പറേറ്ററുമൊത്തുള്ള വ്യക്തമായ ഡീഫറൻസിംഗ് പ്രവർത്തനങ്ങൾക്കായി ഉപയോഗിക്കുന്നതിനുപുറമെ, പല സാഹചര്യങ്ങളിലും കംപൈലർ `DerefMut` വ്യക്തമായി ഉപയോഗിക്കുന്നു.
/// ഈ സംവിധാനത്തെ ['`Deref` coercion'][more] എന്ന് വിളിക്കുന്നു.
/// മാറ്റമില്ലാത്ത സന്ദർഭങ്ങളിൽ, [`Deref`] ഉപയോഗിക്കുന്നു.
///
/// സ്മാർട്ട് പോയിന്ററുകൾക്കായി `DerefMut` നടപ്പിലാക്കുന്നത് അവരുടെ പിന്നിലുള്ള ഡാറ്റ പരിവർത്തനം ചെയ്യുന്നത് സൗകര്യപ്രദമാക്കുന്നു, അതിനാലാണ് അവർ `DerefMut` നടപ്പിലാക്കുന്നത്.
/// മറുവശത്ത്, എക്സ് 00 എക്സ്, എക്സ് 01 എക്സ് എന്നിവ സംബന്ധിച്ച നിയമങ്ങൾ സ്മാർട്ട് പോയിന്ററുകൾ ഉൾക്കൊള്ളുന്നതിനായി പ്രത്യേകം രൂപകൽപ്പന ചെയ്തിട്ടുണ്ട്.
/// ഇക്കാരണത്താൽ, ആശയക്കുഴപ്പം ഒഴിവാക്കാൻ **സ്മാർട്ട് പോയിന്ററുകൾക്ക് മാത്രമേ**`ഡെറെഫ് മട്ട്` നടപ്പിലാക്കാവൂ.
///
/// സമാന കാരണങ്ങളാൽ,**ഈ trait ഒരിക്കലും പരാജയപ്പെടരുത്**.എക്സ് 00 എക്സ് വ്യക്തമായി പ്രാവർത്തികമാക്കുമ്പോൾ ഡീഫെറൻസിംഗിലെ പരാജയം അങ്ങേയറ്റം ആശയക്കുഴപ്പത്തിലാക്കും.
///
/// # `Deref` ബലപ്രയോഗത്തിൽ കൂടുതൽ
///
/// `T` `DerefMut<Target = U>` നടപ്പിലാക്കുന്നുവെങ്കിൽ, `x` എന്നത് `T` തരത്തിന്റെ മൂല്യമാണെങ്കിൽ,
///
/// * മ്യൂട്ടബിൾ സന്ദർഭങ്ങളിൽ, `*x` (ഇവിടെ `T` ഒരു റഫറൻസോ അസംസ്കൃത പോയിന്ററോ അല്ല) `* DerefMut::deref_mut(&mut x)` ന് തുല്യമാണ്.
/// * `&mut T` തരം മൂല്യങ്ങൾ `&mut U` തരം മൂല്യങ്ങളിലേക്ക് നിർബന്ധിതമാണ്
/// * `T` `U` തരത്തിന്റെ എല്ലാ (mutable) രീതികളും വ്യക്തമായി നടപ്പിലാക്കുന്നു.
///
/// കൂടുതൽ വിവരങ്ങൾക്ക്, [the chapter in *The Rust Programming Language*][book], [the dereference operator][ref-deref-op], [method resolution], [type coercions] എന്നിവയിലെ റഫറൻസ് വിഭാഗങ്ങളും സന്ദർശിക്കുക.
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// ഒരൊറ്റ ഫീൽ‌ഡുള്ള ഒരു സ്ട്രക്റ്റ്, സ്ട്രക്റ്റിനെ വ്യതിചലിപ്പിച്ച് പരിഷ്കരിക്കാനാകും.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// മൂല്യത്തെ പരസ്പരം ഇല്ലാതാക്കുന്നു.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// `arbitrary_self_types` സവിശേഷതയില്ലാതെ ഒരു സ്ട്രക്റ്റ് ഒരു രീതി റിസീവറായി ഉപയോഗിക്കാൻ കഴിയുമെന്ന് സൂചിപ്പിക്കുന്നു.
///
/// `Box<T>`, `Rc<T>`, `&T`, `Pin<P>` പോലുള്ള stdlib പോയിന്റർ തരങ്ങളാണ് ഇത് നടപ്പിലാക്കുന്നത്.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}