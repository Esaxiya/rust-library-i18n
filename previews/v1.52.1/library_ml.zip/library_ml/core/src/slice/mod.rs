// ignore-tidy-filelength

//! സ്ലൈസ് മാനേജുമെന്റും കൃത്രിമത്വവും.
//!
//! കൂടുതൽ വിവരങ്ങൾക്ക് [`std::slice`] കാണുക.
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// rust-memchr-ൽ നിന്ന് എടുത്ത ശുദ്ധ rust memchr നടപ്പിലാക്കൽ
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// യൂണിറ്റ് ടെസ്റ്റ് ഹീപ്‌സോർട്ടിന് മറ്റ് മാർഗങ്ങളില്ലാത്തതിനാൽ മാത്രമേ ഈ പ്രവർത്തനം പൊതുവായുള്ളൂ.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// സ്ലൈസിലെ ഘടകങ്ങളുടെ എണ്ണം നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // സേഫ്റ്റി: കോൺ‌സ്റ്റ് ശബ്‌ദം കാരണം ഞങ്ങൾ‌ദൈർ‌ഘ്യ ഫീൽ‌ഡ് ഒരു ഉപയോഗമായി പരിവർത്തനം ചെയ്യുന്നു (അത് ആയിരിക്കണം)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // സുരക്ഷ: `&[T]`, `FatPtr<T>` എന്നിവയ്ക്ക് ഒരേ ലേ .ട്ട് ഉള്ളതിനാൽ ഇത് സുരക്ഷിതമാണ്.
            // `std` ന് മാത്രമേ ഈ ഉറപ്പ് നൽകാൻ കഴിയൂ.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: അത് സ്ഥിരതയുള്ളപ്പോൾ `crate::ptr::metadata(self)` ഉപയോഗിച്ച് മാറ്റിസ്ഥാപിക്കുക.
            // ഈ എഴുത്ത് അനുസരിച്ച് ഇത് ഒരു "Const-stable functions can only call other const-stable functions" പിശകിന് കാരണമാകുന്നു.
            //

            // സുരക്ഷ: * const T മുതൽ `PtrRepr` യൂണിയനിൽ നിന്ന് മൂല്യം ആക്സസ് ചെയ്യുന്നത് സുരക്ഷിതമാണ്
            // ഒപ്പം PtrComponents ഉം<T>സമാന മെമ്മറി ലേ .ട്ടുകൾ ഉണ്ട്.
            // std ന് മാത്രമേ ഈ ഉറപ്പ് നൽകാൻ കഴിയൂ.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// സ്ലൈസിന്റെ ദൈർഘ്യം 0 ആണെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// സ്ലൈസിന്റെ ആദ്യ ഘടകം അല്ലെങ്കിൽ ശൂന്യമാണെങ്കിൽ `None` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// സ്ലൈസിന്റെ ആദ്യ ഘടകത്തിലേക്ക് ഒരു മ്യൂട്ടബിൾ പോയിന്റർ നൽകുന്നു, അല്ലെങ്കിൽ അത് ശൂന്യമാണെങ്കിൽ `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// സ്ലൈസിന്റെ ആദ്യത്തേതും ബാക്കിയുള്ളതുമായ എല്ലാ ഘടകങ്ങളും നൽകുന്നു, അല്ലെങ്കിൽ ശൂന്യമാണെങ്കിൽ `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// സ്ലൈസിന്റെ ആദ്യത്തേതും ബാക്കിയുള്ളതുമായ എല്ലാ ഘടകങ്ങളും നൽകുന്നു, അല്ലെങ്കിൽ ശൂന്യമാണെങ്കിൽ `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// സ്ലൈസിന്റെ അവസാനത്തേതും ബാക്കി എല്ലാ ഘടകങ്ങളും നൽകുന്നു, അല്ലെങ്കിൽ ശൂന്യമാണെങ്കിൽ `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// സ്ലൈസിന്റെ അവസാനത്തേതും ബാക്കി എല്ലാ ഘടകങ്ങളും നൽകുന്നു, അല്ലെങ്കിൽ ശൂന്യമാണെങ്കിൽ `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// സ്ലൈസിന്റെ അവസാന ഘടകം അല്ലെങ്കിൽ ശൂന്യമാണെങ്കിൽ `None` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// സ്ലൈസിലെ അവസാന ഇനത്തിലേക്ക് ഒരു മ്യൂട്ടബിൾ പോയിന്റർ നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// സൂചികയുടെ തരം അനുസരിച്ച് ഒരു ഘടകത്തിലേക്കോ സബ്‌ലൈസിലേക്കോ ഒരു റഫറൻസ് നൽകുന്നു.
    ///
    /// - ഒരു സ്ഥാനം നൽകിയിട്ടുണ്ടെങ്കിൽ, ആ സ്ഥാനത്തുള്ള ഘടകത്തിലേക്ക് ഒരു റഫറൻസ് നൽകുന്നു അല്ലെങ്കിൽ അതിരുകളില്ലെങ്കിൽ `None`.
    ///
    /// - ഒരു ശ്രേണി നൽകിയിട്ടുണ്ടെങ്കിൽ, ആ ശ്രേണിക്ക് അനുയോജ്യമായ സബ്‌ലൈസ് നൽകുന്നു, അല്ലെങ്കിൽ പരിധിക്ക് പുറത്താണെങ്കിൽ `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// സൂചികയുടെ പരിധിക്ക് പുറത്താണെങ്കിൽ സൂചികയുടെ തരം ([`get`] കാണുക) അല്ലെങ്കിൽ `None` അനുസരിച്ച് ഒരു ഘടകത്തിലേക്കോ സബ്‌ലൈസിലേക്കോ ഒരു മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// അതിർത്തി പരിശോധന നടത്താതെ ഒരു ഘടകത്തിലേക്കോ സബ്‌ലൈസിലേക്കോ ഒരു റഫറൻസ് നൽകുന്നു.
    ///
    /// സുരക്ഷിതമായ ബദലിനായി [`get`] കാണുക.
    ///
    /// # Safety
    ///
    /// ഫലമായുണ്ടാകുന്ന റഫറൻസ് ഉപയോഗിച്ചില്ലെങ്കിൽപ്പോലും ഈ രീതിയെ പരിധിക്ക് പുറത്തുള്ള സൂചിക ഉപയോഗിച്ച് വിളിക്കുന്നത് *[നിർവചിക്കപ്പെടാത്ത പെരുമാറ്റം]* ആണ്.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // സുരക്ഷ: `get_unchecked`-നായുള്ള മിക്ക സുരക്ഷാ ആവശ്യകതകളും കോളർ ഉയർത്തിപ്പിടിക്കണം;
        // `self` ഒരു സുരക്ഷിത റഫറൻസായതിനാൽ സ്ലൈസ് ഒഴിവാക്കാനാവില്ല.
        // മടങ്ങിയ പോയിന്റർ സുരക്ഷിതമാണ്, കാരണം `SliceIndex`-ന്റെ impls അത് ഉറപ്പുനൽകേണ്ടതുണ്ട്.
        unsafe { &*index.get_unchecked(self) }
    }

    /// അതിർത്തി പരിശോധന നടത്താതെ ഒരു ഘടകത്തിലേക്കോ സബ്‌ലൈസിലേക്കോ പരിവർത്തനം ചെയ്യാവുന്ന ഒരു റഫറൻസ് നൽകുന്നു.
    ///
    /// സുരക്ഷിതമായ ബദലിനായി [`get_mut`] കാണുക.
    ///
    /// # Safety
    ///
    /// ഫലമായുണ്ടാകുന്ന റഫറൻസ് ഉപയോഗിച്ചില്ലെങ്കിൽപ്പോലും ഈ രീതിയെ പരിധിക്ക് പുറത്തുള്ള സൂചിക ഉപയോഗിച്ച് വിളിക്കുന്നത് *[നിർവചിക്കപ്പെടാത്ത പെരുമാറ്റം]* ആണ്.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // സുരക്ഷ: വിളിക്കുന്നയാൾ `get_unchecked_mut`-ന്റെ സുരക്ഷാ ആവശ്യകതകൾ പാലിക്കണം;
        // `self` ഒരു സുരക്ഷിത റഫറൻസായതിനാൽ സ്ലൈസ് ഒഴിവാക്കാനാവില്ല.
        // മടങ്ങിയ പോയിന്റർ സുരക്ഷിതമാണ്, കാരണം `SliceIndex`-ന്റെ impls അത് ഉറപ്പുനൽകേണ്ടതുണ്ട്.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// സ്ലൈസിന്റെ ബഫറിലേക്ക് ഒരു റോ പോയിന്റർ നൽകുന്നു.
    ///
    /// ഈ ഫംഗ്ഷൻ നൽകുന്ന പോയിന്ററിനെ സ്ലൈസ് മറികടക്കുന്നുവെന്ന് കോളർ ഉറപ്പുവരുത്തണം, അല്ലെങ്കിൽ അത് മാലിന്യത്തിലേക്ക് വിരൽ ചൂണ്ടുന്നു.
    ///
    /// ഈ പോയിന്റർ അല്ലെങ്കിൽ അതിൽ നിന്ന് ഉരുത്തിരിഞ്ഞ ഏതെങ്കിലും പോയിന്റർ ഉപയോഗിച്ച് (non-transitively) പോയിന്റർ പോയിന്റർ മെമ്മറി ഒരിക്കലും (ഒരു `UnsafeCell` നുള്ളിൽ ഒഴികെ) എഴുതിയിട്ടില്ലെന്നും കോളർ ഉറപ്പാക്കണം.
    /// സ്ലൈസിന്റെ ഉള്ളടക്കങ്ങൾ പരിവർത്തനം ചെയ്യണമെങ്കിൽ, [`as_mut_ptr`] ഉപയോഗിക്കുക.
    ///
    /// ഈ സ്ലൈസ് പരാമർശിച്ച കണ്ടെയ്നർ പരിഷ്‌ക്കരിക്കുന്നത് അതിന്റെ ബഫർ വീണ്ടും അനുവദിക്കുന്നതിന് കാരണമായേക്കാം, ഇത് അതിലേക്കുള്ള ഏത് പോയിന്ററുകളും അസാധുവാക്കും.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// സ്ലൈസിന്റെ ബഫറിലേക്ക് സുരക്ഷിതമല്ലാത്ത മ്യൂട്ടബിൾ പോയിന്റർ നൽകുന്നു.
    ///
    /// ഈ ഫംഗ്ഷൻ നൽകുന്ന പോയിന്ററിനെ സ്ലൈസ് മറികടക്കുന്നുവെന്ന് കോളർ ഉറപ്പുവരുത്തണം, അല്ലെങ്കിൽ അത് മാലിന്യത്തിലേക്ക് വിരൽ ചൂണ്ടുന്നു.
    ///
    /// ഈ സ്ലൈസ് പരാമർശിച്ച കണ്ടെയ്നർ പരിഷ്‌ക്കരിക്കുന്നത് അതിന്റെ ബഫർ വീണ്ടും അനുവദിക്കുന്നതിന് കാരണമായേക്കാം, ഇത് അതിലേക്കുള്ള ഏത് പോയിന്ററുകളും അസാധുവാക്കും.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// സ്ലൈസിൽ വ്യാപിച്ചുകിടക്കുന്ന രണ്ട് റോ പോയിന്ററുകൾ നൽകുന്നു.
    ///
    /// മടങ്ങിയ ശ്രേണി പകുതി തുറന്നിരിക്കുന്നു, അതിനർത്ഥം അവസാന പോയിന്റർ സ്ലൈസിന്റെ അവസാന ഘടകം *ഒരു ഭൂതകാലത്തെ* സൂചിപ്പിക്കുന്നു.
    /// ഈ രീതിയിൽ, ഒരു ശൂന്യമായ സ്ലൈസിനെ രണ്ട് തുല്യ പോയിന്ററുകൾ പ്രതിനിധീകരിക്കുന്നു, രണ്ട് പോയിന്ററുകൾ തമ്മിലുള്ള വ്യത്യാസം സ്ലൈസിന്റെ വലുപ്പത്തെ പ്രതിനിധീകരിക്കുന്നു.
    ///
    /// ഈ പോയിന്ററുകൾ ഉപയോഗിക്കുന്നതിനുള്ള മുന്നറിയിപ്പുകൾക്കായി [`as_ptr`] കാണുക.അവസാന പോയിന്ററിന് സ്ലൈസിലെ സാധുവായ ഒരു ഘടകത്തിലേക്ക് പോയിന്റുചെയ്യാത്തതിനാൽ അധിക ജാഗ്രത ആവശ്യമാണ്.
    ///
    /// സി ++ ൽ സാധാരണയുള്ളതുപോലെ മെമ്മറിയിലെ ഘടകങ്ങളുടെ ഒരു ശ്രേണി സൂചിപ്പിക്കുന്നതിന് രണ്ട് പോയിന്ററുകൾ ഉപയോഗിക്കുന്ന വിദേശ ഇന്റർഫേസുകളുമായി സംവദിക്കുന്നതിന് ഈ ഫംഗ്ഷൻ ഉപയോഗപ്രദമാണ്.
    ///
    ///
    /// ഒരു ഘടകത്തിലേക്കുള്ള പോയിന്റർ ഈ സ്ലൈസിന്റെ ഒരു ഘടകത്തെ സൂചിപ്പിക്കുന്നുണ്ടോയെന്ന് പരിശോധിക്കാനും ഇത് ഉപയോഗപ്രദമാകും:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // സുരക്ഷ: ഇവിടെ `add` സുരക്ഷിതമാണ്, കാരണം:
        //
        //   - രണ്ട് പോയിന്ററുകളും ഒരേ ഒബ്ജക്റ്റിന്റെ ഭാഗമാണ്, കാരണം ഒബ്ജക്റ്റിനെ നേരിട്ട് മറികടക്കുന്നതും കണക്കാക്കുന്നു.
        //
        //   - സ്ലൈസിന്റെ വലുപ്പം ഒരിക്കലും isize::MAX ബൈറ്റുകളേക്കാൾ വലുതല്ല, ഇവിടെ സൂചിപ്പിച്ചത് പോലെ:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - വിലാസ ഇടത്തിന്റെ അവസാനഭാഗത്ത് കഷ്ണങ്ങൾ പൊതിയാത്തതിനാൽ, അതിൽ ചുറ്റിപ്പിടിക്കുന്നില്ല.
        //
        // pointer::add-ന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// സ്ലൈസിൽ വ്യാപിച്ചുകിടക്കുന്ന രണ്ട് സുരക്ഷിതമല്ലാത്ത മ്യൂട്ടബിൾ പോയിന്ററുകൾ നൽകുന്നു.
    ///
    /// മടങ്ങിയ ശ്രേണി പകുതി തുറന്നിരിക്കുന്നു, അതിനർത്ഥം അവസാന പോയിന്റർ സ്ലൈസിന്റെ അവസാന ഘടകം *ഒരു ഭൂതകാലത്തെ* സൂചിപ്പിക്കുന്നു.
    /// ഈ രീതിയിൽ, ഒരു ശൂന്യമായ സ്ലൈസിനെ രണ്ട് തുല്യ പോയിന്ററുകൾ പ്രതിനിധീകരിക്കുന്നു, രണ്ട് പോയിന്ററുകൾ തമ്മിലുള്ള വ്യത്യാസം സ്ലൈസിന്റെ വലുപ്പത്തെ പ്രതിനിധീകരിക്കുന്നു.
    ///
    /// ഈ പോയിന്ററുകൾ ഉപയോഗിക്കുന്നതിനുള്ള മുന്നറിയിപ്പുകൾക്കായി [`as_mut_ptr`] കാണുക.
    /// അവസാന പോയിന്ററിന് അധിക ജാഗ്രത ആവശ്യമാണ്, കാരണം ഇത് സ്ലൈസിലെ സാധുവായ ഒരു ഘടകത്തിലേക്ക് പോയിന്റുചെയ്യുന്നില്ല.
    ///
    /// സി ++ ൽ സാധാരണയുള്ളതുപോലെ മെമ്മറിയിലെ ഘടകങ്ങളുടെ ഒരു ശ്രേണി സൂചിപ്പിക്കുന്നതിന് രണ്ട് പോയിന്ററുകൾ ഉപയോഗിക്കുന്ന വിദേശ ഇന്റർഫേസുകളുമായി സംവദിക്കുന്നതിന് ഈ ഫംഗ്ഷൻ ഉപയോഗപ്രദമാണ്.
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // സുരക്ഷ: എന്തുകൊണ്ടാണ് ഇവിടെ `add` സുരക്ഷിതമെന്ന് മുകളിൽ as_ptr_range() കാണുക.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// സ്ലൈസിലെ രണ്ട് ഘടകങ്ങൾ സ്വാപ്പ് ചെയ്യുന്നു.
    ///
    /// # Arguments
    ///
    /// * a, ആദ്യ മൂലകത്തിന്റെ സൂചിക
    /// * b, രണ്ടാമത്തെ മൂലകത്തിന്റെ സൂചിക
    ///
    /// # Panics
    ///
    /// `a` അല്ലെങ്കിൽ `b` പരിധിക്ക് പുറത്താണെങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // ഒരു vector-ൽ നിന്ന് രണ്ട് മ്യൂട്ടബിൾ വായ്പകൾ എടുക്കാൻ കഴിയില്ല, അതിനാൽ റോ പോയിന്ററുകൾ ഉപയോഗിക്കുക.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // സുരക്ഷ: സുരക്ഷിതമായ മ്യൂട്ടബിൾ റഫറൻസുകളിൽ നിന്ന് `pa`, `pb` എന്നിവ സൃഷ്ടിച്ചു റഫർ ചെയ്യുക
        // സ്ലൈസിലെ ഘടകങ്ങളിലേക്ക്, അതിനാൽ സാധുതയുള്ളതും വിന്യസിക്കുന്നതും ഉറപ്പുനൽകുന്നു.
        // `a`, `b` എന്നിവയ്‌ക്ക് പിന്നിലുള്ള ഘടകങ്ങൾ ആക്‌സസ്സുചെയ്യുന്നത് പരിശോധിച്ചിട്ടുണ്ടെന്നും അതിർത്തിക്കപ്പുറത്ത് panic ചെയ്യുമെന്നും ശ്രദ്ധിക്കുക.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// സ്ലൈസിലെ ഘടകങ്ങളുടെ ക്രമം പഴയപടിയാക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // വളരെ ചെറിയ തരങ്ങൾക്ക്, സാധാരണ പാതയിലെ എല്ലാ വ്യക്തിഗത വായനകളും മോശമായി പ്രവർത്തിക്കുന്നു.
        // ഒരു വലിയ ചങ്ക് ലോഡുചെയ്‌ത് ഒരു രജിസ്റ്റർ വിപരീതമാക്കിക്കൊണ്ട്, കാര്യക്ഷമമായി ക്രമീകരിക്കാത്ത load/store നൽകിയാൽ ഞങ്ങൾക്ക് മികച്ചത് ചെയ്യാൻ കഴിയും.
        //

        // ക്രമീകരിക്കാത്ത വായനകൾ കാര്യക്ഷമമാണോയെന്നതിനേക്കാളും നന്നായി അറിയാമെന്നതിനാൽ (വ്യത്യസ്ത എആർ‌എം പതിപ്പുകൾക്കിടയിലുള്ള മാറ്റങ്ങൾ കാരണം, ഉദാഹരണത്തിന്) മികച്ച ചങ്ക് വലുപ്പം എന്തായിരിക്കുമെന്നതിനേക്കാൾ നന്നായി എൽ‌എൽ‌വി‌എം ഇത് ചെയ്യും.
        // നിർഭാഗ്യവശാൽ, LLVM 4.0 (2017-05) പോലെ ഇത് ലൂപ്പ് അൺറോൾ ചെയ്യുന്നു, അതിനാൽ ഇത് ഞങ്ങൾ സ്വയം ചെയ്യേണ്ടതുണ്ട്.
        // (പരികല്പന: വിപരീതം പ്രശ്‌നകരമാണ്, കാരണം വശങ്ങൾ വ്യത്യസ്തമായി വിന്യസിക്കാൻ കഴിയും-ദൈർഘ്യം വിചിത്രമാകുമ്പോൾ ആയിരിക്കും-അതിനാൽ മധ്യത്തിൽ പൂർണ്ണമായും വിന്യസിച്ച സിംഡി ഉപയോഗിക്കുന്നതിന് പ്രീ-പോസ്റ്റ്‌ലൂഡുകൾ പുറപ്പെടുവിക്കാൻ ഒരു വഴിയുമില്ല.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // ഒരു ഉപയോഗത്തിൽ u8s റിവേഴ്സ് ചെയ്യാൻ llvm.bswap ആന്തരികം ഉപയോഗിക്കുക
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // സുരക്ഷ: ഇവിടെ പരിശോധിക്കാൻ നിരവധി കാര്യങ്ങളുണ്ട്:
                //
                // - മുകളിലുള്ള cfg പരിശോധന കാരണം `chunk` 4 അല്ലെങ്കിൽ 8 ആണെന്ന് ശ്രദ്ധിക്കുക.അതിനാൽ `chunk - 1` പോസിറ്റീവ് ആണ്.
                // - ലൂപ്പ് ചെക്ക് ഉറപ്പുനൽകുന്നതിനാൽ സൂചിക `i` ഉള്ള സൂചിക മികച്ചതാണ്
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - സൂചിക `ln - i - chunk = ln - (i + chunk)` ഉപയോഗിച്ച് സൂചികയിലാക്കുന്നത് മികച്ചതാണ്:
                //   - `i + chunk > 0` നിസ്സാരമായി ശരിയാണ്.
                //   - ലൂപ്പ് പരിശോധന ഉറപ്പ് നൽകുന്നു:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, അതിനാൽ കുറയ്ക്കൽ ഒഴുകില്ല.
                // - `read_unaligned`, `write_unaligned` കോളുകൾ മികച്ചതാണ്:
                //   - `pa` സൂചിക `i` ലേക്ക് പോയിന്റുകൾ, അവിടെ `i < ln / 2 - (chunk - 1)` (മുകളിൽ കാണുക), `pb` സൂചിക `ln - i - chunk` ലേക്ക് പോയിന്റ് ചെയ്യുന്നു, അതിനാൽ ഇവ രണ്ടും `self` ന്റെ അവസാനത്തിൽ നിന്ന് കുറഞ്ഞത് `chunk` നിരവധി ബൈറ്റുകളെങ്കിലും അകലെയാണ്.
                //
                //   - സമാരംഭിച്ച ഏത് മെമ്മറിയും സാധുവായ `usize` ആണ്.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // ഒരു u32-ൽ u16s റിവേഴ്സ് ചെയ്യാൻ റൊട്ടേറ്റ്-ബൈ-16 ഉപയോഗിക്കുക
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // സുരക്ഷ: `i + 1 < ln` എങ്കിൽ `i`-ൽ നിന്ന് ക്രമീകരിക്കാത്ത u32 വായിക്കാൻ കഴിയും
                // (വ്യക്തമായും `i < ln`), കാരണം ഓരോ ഘടകവും 2 ബൈറ്റുകളാണ്, ഞങ്ങൾ 4 വായിക്കുന്നു.
                //
                // `i + chunk - 1 < ln / 2` # അവസ്ഥയിലായിരിക്കുമ്പോൾ
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // ഇത് 2 കൊണ്ട് ഹരിച്ച നീളത്തേക്കാൾ കുറവായതിനാൽ, അത് അതിരുകളിലായിരിക്കണം.
                //
                // ഇതിനർത്ഥം `0 < i + chunk <= ln` എന്ന അവസ്ഥ എല്ലായ്പ്പോഴും ബഹുമാനിക്കപ്പെടുന്നു, `pb` പോയിന്റർ സുരക്ഷിതമായി ഉപയോഗിക്കാമെന്ന് ഉറപ്പാക്കുന്നു.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // സുരക്ഷ: സ്ലൈസിന്റെ പകുതി നീളത്തേക്കാൾ `i` കുറവാണ്
            // `i`, `ln - i - 1` എന്നിവ ആക്സസ് ചെയ്യുന്നത് സുരക്ഷിതമാണ് (`i` 0 ൽ ആരംഭിക്കുന്നു, `ln / 2 - 1` നേക്കാൾ കൂടുതൽ പോകില്ല).
            // തത്ഫലമായുണ്ടാകുന്ന പോയിന്ററുകളായ `pa`, `pb` എന്നിവ സാധുവായതും വിന്യസിച്ചതുമാണ്, മാത്രമല്ല അവ വായിക്കാനും എഴുതാനും കഴിയും.
            //
            //
            unsafe {
                // സുരക്ഷിതമായ സ്വാപ്പിലെ അതിർത്തി പരിശോധന ഒഴിവാക്കാൻ സുരക്ഷിതമല്ലാത്ത സ്വാപ്പ്.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// സ്ലൈസിന് മുകളിൽ ഒരു ഇറ്ററേറ്റർ നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// ഓരോ മൂല്യവും പരിഷ്‌ക്കരിക്കാൻ അനുവദിക്കുന്ന ഒരു ഇറ്ററേറ്റർ നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// `size` നീളമുള്ള എല്ലാ windows നീളത്തിലും ഒരു ഇറ്ററേറ്റർ നൽകുന്നു.
    /// windows ഓവർലാപ്പ്.
    /// സ്ലൈസ് `size` നേക്കാൾ ചെറുതാണെങ്കിൽ, ഇറ്ററേറ്റർ മൂല്യങ്ങളൊന്നും നൽകുന്നില്ല.
    ///
    /// # Panics
    ///
    /// `size` 0 ആണെങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// സ്ലൈസ് `size` നേക്കാൾ ചെറുതാണെങ്കിൽ:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// സ്ലൈസിന്റെ തുടക്കത്തിൽ ആരംഭിച്ച് ഒരു സമയം സ്ലൈസിന്റെ `chunk_size` ഘടകങ്ങളിൽ ഒരു ഇറ്ററേറ്റർ നൽകുന്നു.
    ///
    /// കഷണങ്ങൾ കഷണങ്ങളായതിനാൽ ഓവർലാപ്പ് ചെയ്യരുത്.`chunk_size` സ്ലൈസിന്റെ നീളം വിഭജിക്കുന്നില്ലെങ്കിൽ, അവസാന ചങ്കിന് `chunk_size` നീളം ഉണ്ടാകില്ല.
    ///
    /// എല്ലായ്പ്പോഴും കൃത്യമായി `chunk_size` ഘടകങ്ങളുടെ കഷണങ്ങൾ നൽകുന്ന അതേ ഇറ്ററേറ്ററിന്റെ വേരിയന്റിനായി [`chunks_exact`], അതേ ഇറ്ററേറ്ററിനായി [`rchunks`] എന്നിവ കാണുക, എന്നാൽ സ്ലൈസിന്റെ അവസാനം ആരംഭിക്കുന്നു.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 ആണെങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// സ്ലൈസിന്റെ തുടക്കത്തിൽ ആരംഭിച്ച് ഒരു സമയം സ്ലൈസിന്റെ `chunk_size` ഘടകങ്ങളിൽ ഒരു ഇറ്ററേറ്റർ നൽകുന്നു.
    ///
    /// കഷണങ്ങൾ മ്യൂട്ടബിൾ സ്ലൈസുകളാണ്, അവ ഓവർലാപ്പ് ചെയ്യരുത്.`chunk_size` സ്ലൈസിന്റെ നീളം വിഭജിക്കുന്നില്ലെങ്കിൽ, അവസാന ചങ്കിന് `chunk_size` നീളം ഉണ്ടാകില്ല.
    ///
    /// എല്ലായ്പ്പോഴും കൃത്യമായി `chunk_size` ഘടകങ്ങളുടെ കഷണങ്ങൾ നൽകുന്ന അതേ ഇറ്ററേറ്ററിന്റെ വേരിയന്റിനായി [`chunks_exact_mut`], അതേ ഇറ്ററേറ്ററിനായി [`rchunks_mut`] എന്നിവ കാണുക, എന്നാൽ സ്ലൈസിന്റെ അവസാനം ആരംഭിക്കുന്നു.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 ആണെങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// സ്ലൈസിന്റെ തുടക്കത്തിൽ ആരംഭിച്ച് ഒരു സമയം സ്ലൈസിന്റെ `chunk_size` ഘടകങ്ങളിൽ ഒരു ഇറ്ററേറ്റർ നൽകുന്നു.
    ///
    /// കഷണങ്ങൾ കഷണങ്ങളായതിനാൽ ഓവർലാപ്പ് ചെയ്യരുത്.
    /// `chunk_size` സ്ലൈസിന്റെ ദൈർഘ്യം വിഭജിച്ചിട്ടില്ലെങ്കിൽ, അവസാനത്തെ `chunk_size-1` ഘടകങ്ങൾ ഒഴിവാക്കപ്പെടും, കൂടാതെ ആവർത്തനത്തിന്റെ `remainder` ഫംഗ്ഷനിൽ നിന്ന് വീണ്ടെടുക്കാനും കഴിയും.
    ///
    ///
    /// ഓരോ ചങ്കിലും കൃത്യമായി `chunk_size` ഘടകങ്ങൾ ഉള്ളതിനാൽ, കംപൈലറിന് [`chunks`]-നെ അപേക്ഷിച്ച് ഫലമായുണ്ടാകുന്ന കോഡ് ഒപ്റ്റിമൈസ് ചെയ്യാൻ കഴിയും.
    ///
    /// ഈ ഇറ്ററേറ്ററിന്റെ വേരിയന്റിനായി [`chunks`] കാണുക, ബാക്കിയുള്ളവയെ ചെറിയ ചങ്കായി നൽകുന്നു, അതേ ഇറ്ററേറ്ററിനായി [`rchunks_exact`] എന്നാൽ സ്ലൈസിന്റെ അവസാനം ആരംഭിക്കുന്നു.
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 ആണെങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// സ്ലൈസിന്റെ തുടക്കത്തിൽ ആരംഭിച്ച് ഒരു സമയം സ്ലൈസിന്റെ `chunk_size` ഘടകങ്ങളിൽ ഒരു ഇറ്ററേറ്റർ നൽകുന്നു.
    ///
    /// കഷണങ്ങൾ മ്യൂട്ടബിൾ സ്ലൈസുകളാണ്, അവ ഓവർലാപ്പ് ചെയ്യരുത്.
    /// `chunk_size` സ്ലൈസിന്റെ ദൈർഘ്യം വിഭജിച്ചിട്ടില്ലെങ്കിൽ, അവസാനത്തെ `chunk_size-1` ഘടകങ്ങൾ ഒഴിവാക്കപ്പെടും, കൂടാതെ ആവർത്തനത്തിന്റെ `into_remainder` ഫംഗ്ഷനിൽ നിന്ന് വീണ്ടെടുക്കാനും കഴിയും.
    ///
    ///
    /// ഓരോ ചങ്കിലും കൃത്യമായി `chunk_size` ഘടകങ്ങൾ ഉള്ളതിനാൽ, കംപൈലറിന് [`chunks_mut`]-നെ അപേക്ഷിച്ച് ഫലമായുണ്ടാകുന്ന കോഡ് ഒപ്റ്റിമൈസ് ചെയ്യാൻ കഴിയും.
    ///
    /// ഈ ഇറ്ററേറ്ററിന്റെ വേരിയന്റിനായി [`chunks_mut`] കാണുക, അത് ബാക്കിയുള്ളവയെ ചെറിയ ചങ്കായി നൽകുന്നു, അതേ ഇറ്ററേറ്ററിനായി [`rchunks_exact_mut`] എന്നാൽ സ്ലൈസിന്റെ അവസാനം ആരംഭിക്കുന്നു.
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 ആണെങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// ബാക്കിയുള്ളവയൊന്നുമില്ലെന്ന് കരുതി സ്ലൈസ് `N`-ഘടക അറേകളുടെ ഒരു സ്ലൈസായി വിഭജിക്കുന്നു.
    ///
    ///
    /// # Safety
    ///
    /// എപ്പോൾ എന്ന് മാത്രമേ ഇതിനെ വിളിക്കൂ
    /// - സ്ലൈസ് കൃത്യമായി `N`-ഘടക ഘടകങ്ങളായി വിഭജിക്കുന്നു (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // സുരക്ഷ: 1-ഘടക ഘടകങ്ങൾക്ക് ഒരിക്കലും ശേഷിക്കുന്നില്ല
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // സുരക്ഷ: സ്ലൈസ് നീളം (6) 3 ന്റെ ഗുണിതമാണ്
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // ഇവ ശരിയല്ല:
    /// // കഷണങ്ങൾ അനുവദിക്കുക: &[[_;5]]= slice.as_chunks_unchecked()//സ്ലൈസ് നീളം 5 ലെറ്റ് ചങ്കുകളുടെ ഗുണിതമല്ല:&[[_;0]]= slice.as_chunks_unchecked()//സീറോ-ലെങ്ത് കഷണങ്ങൾ ഒരിക്കലും അനുവദിക്കില്ല
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // സുരക്ഷ: ഇതിനെ വിളിക്കാൻ ഞങ്ങളുടെ മുൻ‌കരുതൽ കൃത്യമായി ആവശ്യമാണ്
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // സുരക്ഷ: ഞങ്ങൾ `new_len * N` ഘടകങ്ങളുടെ ഒരു സ്ലൈസ് ഇട്ടു
        // `new_len` ന്റെ ഒരു സ്ലൈസ് നിരവധി `N` ഘടക ഘടകങ്ങൾ.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// സ്ലൈസിന്റെ തുടക്കത്തിൽ ആരംഭിച്ച് `N`-മൂലക അറേകളുടെ ഒരു സ്ലൈസായി സ്ലൈസ് വിഭജിക്കുന്നു, ശേഷിക്കുന്ന സ്ലൈസ് `N`-നേക്കാൾ കുറവാണ്.
    ///
    ///
    /// # Panics
    ///
    /// `N` 0 ആണെങ്കിൽ Panics. ഈ രീതി സ്ഥിരത കൈവരിക്കുന്നതിന് മുമ്പ് ഈ പരിശോധന ഒരു കംപൈൽ സമയ പിശകിലേക്ക് മാറും.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // സുരക്ഷ: പൂജ്യത്തിനായി ഞങ്ങൾ ഇതിനകം പരിഭ്രാന്തരായി, നിർമ്മാണത്തിലൂടെ ഉറപ്പാക്കി
        // സബ്‌ലൈസിന്റെ ദൈർഘ്യം N ന്റെ ഗുണിതമാണെന്ന്.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// സ്ലൈസിന്റെ അവസാനത്തിൽ ആരംഭിച്ച് `N`-മൂലക അറേകളുടെ ഒരു സ്ലൈസായി സ്ലൈസും `N`-നേക്കാൾ കർശനമായി നീളമുള്ള ബാക്കി സ്ലൈസും വിഭജിക്കുന്നു.
    ///
    ///
    /// # Panics
    ///
    /// `N` 0 ആണെങ്കിൽ Panics. ഈ രീതി സ്ഥിരത കൈവരിക്കുന്നതിന് മുമ്പ് ഈ പരിശോധന ഒരു കംപൈൽ സമയ പിശകിലേക്ക് മാറും.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // സുരക്ഷ: പൂജ്യത്തിനായി ഞങ്ങൾ ഇതിനകം പരിഭ്രാന്തരായി, നിർമ്മാണത്തിലൂടെ ഉറപ്പാക്കി
        // സബ്‌ലൈസിന്റെ ദൈർഘ്യം N ന്റെ ഗുണിതമാണെന്ന്.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// സ്ലൈസിന്റെ തുടക്കത്തിൽ ആരംഭിച്ച് ഒരു സമയം സ്ലൈസിന്റെ `N` ഘടകങ്ങളിൽ ഒരു ഇറ്ററേറ്റർ നൽകുന്നു.
    ///
    /// കഷണങ്ങൾ അറേ റഫറൻസുകളാണ്, അവ ഓവർലാപ്പ് ചെയ്യരുത്.
    /// `N` സ്ലൈസിന്റെ ദൈർഘ്യം വിഭജിച്ചിട്ടില്ലെങ്കിൽ, അവസാനത്തെ `N-1` ഘടകങ്ങൾ ഒഴിവാക്കപ്പെടും, കൂടാതെ ആവർത്തനത്തിന്റെ `remainder` ഫംഗ്ഷനിൽ നിന്ന് വീണ്ടെടുക്കാനും കഴിയും.
    ///
    ///
    /// ഈ രീതി [`chunks_exact`]-ന് തുല്യമായ const generic തുല്യമാണ്.
    ///
    /// # Panics
    ///
    /// `N` 0 ആണെങ്കിൽ Panics. ഈ രീതി സ്ഥിരത കൈവരിക്കുന്നതിന് മുമ്പ് ഈ പരിശോധന ഒരു കംപൈൽ സമയ പിശകിലേക്ക് മാറും.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// ബാക്കിയുള്ളവയൊന്നുമില്ലെന്ന് കരുതി സ്ലൈസ് `N`-ഘടക അറേകളുടെ ഒരു സ്ലൈസായി വിഭജിക്കുന്നു.
    ///
    ///
    /// # Safety
    ///
    /// എപ്പോൾ എന്ന് മാത്രമേ ഇതിനെ വിളിക്കൂ
    /// - സ്ലൈസ് കൃത്യമായി `N`-ഘടക ഘടകങ്ങളായി വിഭജിക്കുന്നു (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // സുരക്ഷ: 1-ഘടക ഘടകങ്ങൾക്ക് ഒരിക്കലും ശേഷിക്കുന്നില്ല
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // സുരക്ഷ: സ്ലൈസ് നീളം (6) 3 ന്റെ ഗുണിതമാണ്
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // ഇവ ശരിയല്ല:
    /// // കഷണങ്ങൾ അനുവദിക്കുക: &[[_;5]]= slice.as_chunks_unchecked_mut()//സ്ലൈസ് നീളം 5 ലെറ്റ് ചങ്കുകളുടെ ഗുണിതമല്ല:&[[_;0]]= slice.as_chunks_unchecked_mut()//സീറോ-ലെങ്ത് കഷണങ്ങൾ ഒരിക്കലും അനുവദിക്കില്ല
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // സുരക്ഷ: ഇതിനെ വിളിക്കാൻ ഞങ്ങളുടെ മുൻ‌കരുതൽ കൃത്യമായി ആവശ്യമാണ്
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // സുരക്ഷ: ഞങ്ങൾ `new_len * N` ഘടകങ്ങളുടെ ഒരു സ്ലൈസ് ഇട്ടു
        // `new_len` ന്റെ ഒരു സ്ലൈസ് നിരവധി `N` ഘടക ഘടകങ്ങൾ.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// സ്ലൈസിന്റെ തുടക്കത്തിൽ ആരംഭിച്ച് `N`-മൂലക അറേകളുടെ ഒരു സ്ലൈസായി സ്ലൈസ് വിഭജിക്കുന്നു, ശേഷിക്കുന്ന സ്ലൈസ് `N`-നേക്കാൾ കുറവാണ്.
    ///
    ///
    /// # Panics
    ///
    /// `N` 0 ആണെങ്കിൽ Panics. ഈ രീതി സ്ഥിരത കൈവരിക്കുന്നതിന് മുമ്പ് ഈ പരിശോധന ഒരു കംപൈൽ സമയ പിശകിലേക്ക് മാറും.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // സുരക്ഷ: പൂജ്യത്തിനായി ഞങ്ങൾ ഇതിനകം പരിഭ്രാന്തരായി, നിർമ്മാണത്തിലൂടെ ഉറപ്പാക്കി
        // സബ്‌ലൈസിന്റെ ദൈർഘ്യം N ന്റെ ഗുണിതമാണെന്ന്.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// സ്ലൈസിന്റെ അവസാനത്തിൽ ആരംഭിച്ച് `N`-മൂലക അറേകളുടെ ഒരു സ്ലൈസായി സ്ലൈസും `N`-നേക്കാൾ കർശനമായി നീളമുള്ള ബാക്കി സ്ലൈസും വിഭജിക്കുന്നു.
    ///
    ///
    /// # Panics
    ///
    /// `N` 0 ആണെങ്കിൽ Panics. ഈ രീതി സ്ഥിരത കൈവരിക്കുന്നതിന് മുമ്പ് ഈ പരിശോധന ഒരു കംപൈൽ സമയ പിശകിലേക്ക് മാറും.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // സുരക്ഷ: പൂജ്യത്തിനായി ഞങ്ങൾ ഇതിനകം പരിഭ്രാന്തരായി, നിർമ്മാണത്തിലൂടെ ഉറപ്പാക്കി
        // സബ്‌ലൈസിന്റെ ദൈർഘ്യം N ന്റെ ഗുണിതമാണെന്ന്.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// സ്ലൈസിന്റെ തുടക്കത്തിൽ ആരംഭിച്ച് ഒരു സമയം സ്ലൈസിന്റെ `N` ഘടകങ്ങളിൽ ഒരു ഇറ്ററേറ്റർ നൽകുന്നു.
    ///
    /// കഷണങ്ങൾ മ്യൂട്ടബിൾ അറേ റഫറൻസുകളാണ്, അവ ഓവർലാപ്പ് ചെയ്യരുത്.
    /// `N` സ്ലൈസിന്റെ ദൈർഘ്യം വിഭജിച്ചിട്ടില്ലെങ്കിൽ, അവസാനത്തെ `N-1` ഘടകങ്ങൾ ഒഴിവാക്കപ്പെടും, കൂടാതെ ആവർത്തനത്തിന്റെ `into_remainder` ഫംഗ്ഷനിൽ നിന്ന് വീണ്ടെടുക്കാനും കഴിയും.
    ///
    ///
    /// ഈ രീതി [`chunks_exact_mut`]-ന് തുല്യമായ const generic തുല്യമാണ്.
    ///
    /// # Panics
    ///
    /// `N` 0 ആണെങ്കിൽ Panics. ഈ രീതി സ്ഥിരത കൈവരിക്കുന്നതിന് മുമ്പ് ഈ പരിശോധന ഒരു കംപൈൽ സമയ പിശകിലേക്ക് മാറും.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// സ്ലൈസിന്റെ തുടക്കത്തിൽ ആരംഭിക്കുന്ന ഒരു സ്ലൈസിന്റെ `N` ഘടകങ്ങളുടെ windows ഓവർലാപ്പുചെയ്യുന്നതിലൂടെ ഒരു ഇറ്ററേറ്റർ നൽകുന്നു.
    ///
    ///
    /// ഇതാണ് [`windows`]-ന് തുല്യമായ const generic.
    ///
    /// സ്ലൈസിന്റെ വലുപ്പത്തേക്കാൾ `N` വലുതാണെങ്കിൽ, അത് windows നൽകില്ല.
    ///
    /// # Panics
    ///
    /// `N` 0 ആണെങ്കിൽ Panics.
    /// ഈ രീതി സ്ഥിരത കൈവരിക്കുന്നതിന് മുമ്പ് ഈ പരിശോധന മിക്കവാറും ഒരു കംപൈൽ സമയ പിശകിലേക്ക് മാറും.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// സ്ലൈസിന്റെ അവസാനം മുതൽ ആരംഭിക്കുന്ന സ്ലൈസിന്റെ `chunk_size` ഘടകങ്ങളിൽ ഒരു ഇറ്ററേറ്റർ നൽകുന്നു.
    ///
    /// കഷണങ്ങൾ കഷണങ്ങളായതിനാൽ ഓവർലാപ്പ് ചെയ്യരുത്.`chunk_size` സ്ലൈസിന്റെ നീളം വിഭജിക്കുന്നില്ലെങ്കിൽ, അവസാന ചങ്കിന് `chunk_size` നീളം ഉണ്ടാകില്ല.
    ///
    /// എല്ലായ്പ്പോഴും കൃത്യമായി `chunk_size` ഘടകങ്ങളുടെ ഭാഗങ്ങൾ നൽകുന്ന അതേ ആവർത്തനത്തിന്റെ [`rchunks_exact`], അതേ ഇറ്ററേറ്ററിനായി [`chunks`] എന്നിവ കാണുക, എന്നാൽ സ്ലൈസിന്റെ തുടക്കത്തിൽ ആരംഭിക്കുക.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 ആണെങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// സ്ലൈസിന്റെ അവസാനം മുതൽ ആരംഭിക്കുന്ന സ്ലൈസിന്റെ `chunk_size` ഘടകങ്ങളിൽ ഒരു ഇറ്ററേറ്റർ നൽകുന്നു.
    ///
    /// കഷണങ്ങൾ മ്യൂട്ടബിൾ സ്ലൈസുകളാണ്, അവ ഓവർലാപ്പ് ചെയ്യരുത്.`chunk_size` സ്ലൈസിന്റെ നീളം വിഭജിക്കുന്നില്ലെങ്കിൽ, അവസാന ചങ്കിന് `chunk_size` നീളം ഉണ്ടാകില്ല.
    ///
    /// എല്ലായ്പ്പോഴും കൃത്യമായി `chunk_size` ഘടകങ്ങളുടെ ഭാഗങ്ങൾ നൽകുന്ന അതേ ആവർത്തനത്തിന്റെ [`rchunks_exact_mut`], അതേ ഇറ്ററേറ്ററിനായി [`chunks_mut`] എന്നിവ കാണുക, എന്നാൽ സ്ലൈസിന്റെ തുടക്കത്തിൽ ആരംഭിക്കുക.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 ആണെങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// സ്ലൈസിന്റെ അവസാനം മുതൽ ആരംഭിക്കുന്ന സ്ലൈസിന്റെ `chunk_size` ഘടകങ്ങളിൽ ഒരു ഇറ്ററേറ്റർ നൽകുന്നു.
    ///
    /// കഷണങ്ങൾ കഷണങ്ങളായതിനാൽ ഓവർലാപ്പ് ചെയ്യരുത്.
    /// `chunk_size` സ്ലൈസിന്റെ ദൈർഘ്യം വിഭജിച്ചിട്ടില്ലെങ്കിൽ, അവസാനത്തെ `chunk_size-1` ഘടകങ്ങൾ ഒഴിവാക്കപ്പെടും, കൂടാതെ ആവർത്തനത്തിന്റെ `remainder` ഫംഗ്ഷനിൽ നിന്ന് വീണ്ടെടുക്കാനും കഴിയും.
    ///
    /// ഓരോ ചങ്കിലും കൃത്യമായി `chunk_size` ഘടകങ്ങൾ ഉള്ളതിനാൽ, കംപൈലറിന് [`chunks`]-നെ അപേക്ഷിച്ച് ഫലമായുണ്ടാകുന്ന കോഡ് ഒപ്റ്റിമൈസ് ചെയ്യാൻ കഴിയും.
    ///
    /// ഈ ഇറ്ററേറ്ററിന്റെ ഒരു വേരിയന്റിനായി [`rchunks`] കാണുക, ബാക്കിയുള്ളവയെ ചെറിയ ചങ്കായി നൽകുന്നു, അതേ ഇറ്ററേറ്ററിനായി [`chunks_exact`] എന്നാൽ സ്ലൈസിന്റെ തുടക്കത്തിൽ ആരംഭിക്കുന്നു.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 ആണെങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// സ്ലൈസിന്റെ അവസാനം മുതൽ ആരംഭിക്കുന്ന സ്ലൈസിന്റെ `chunk_size` ഘടകങ്ങളിൽ ഒരു ഇറ്ററേറ്റർ നൽകുന്നു.
    ///
    /// കഷണങ്ങൾ മ്യൂട്ടബിൾ സ്ലൈസുകളാണ്, അവ ഓവർലാപ്പ് ചെയ്യരുത്.
    /// `chunk_size` സ്ലൈസിന്റെ ദൈർഘ്യം വിഭജിച്ചിട്ടില്ലെങ്കിൽ, അവസാനത്തെ `chunk_size-1` ഘടകങ്ങൾ ഒഴിവാക്കപ്പെടും, കൂടാതെ ആവർത്തനത്തിന്റെ `into_remainder` ഫംഗ്ഷനിൽ നിന്ന് വീണ്ടെടുക്കാനും കഴിയും.
    ///
    /// ഓരോ ചങ്കിലും കൃത്യമായി `chunk_size` ഘടകങ്ങൾ ഉള്ളതിനാൽ, കംപൈലറിന് [`chunks_mut`]-നെ അപേക്ഷിച്ച് ഫലമായുണ്ടാകുന്ന കോഡ് ഒപ്റ്റിമൈസ് ചെയ്യാൻ കഴിയും.
    ///
    /// ഈ ഇറ്ററേറ്ററിന്റെ ഒരു വേരിയന്റിനായി [`rchunks_mut`] കാണുക, ബാക്കിയുള്ളവയെ ചെറിയ ചങ്കായി നൽകുന്നു, അതേ ഇറ്ററേറ്ററിനായി [`chunks_exact_mut`] എന്നാൽ സ്ലൈസിന്റെ തുടക്കത്തിൽ ആരംഭിക്കുന്നു.
    ///
    ///
    /// # Panics
    ///
    /// `chunk_size` 0 ആണെങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// മൂലകങ്ങളെ വേർതിരിക്കുന്നതിന് പ്രവചിക്കുക ഉപയോഗിച്ച് ഓവർലാപ്പുചെയ്യാത്ത റൺസ് നിർമ്മിക്കുന്ന സ്ലൈസിന് മുകളിലൂടെ ഒരു ഇറ്ററേറ്റർ നൽകുന്നു.
    ///
    /// പ്രവചനത്തെ സ്വയം പിന്തുടരുന്ന രണ്ട് ഘടകങ്ങളിലേക്ക് വിളിക്കുന്നു, അതിനർത്ഥം `slice[0]`, `slice[1]` എന്നിവയിൽ XD2X, `slice[2]` എന്നിങ്ങനെ പ്രവചിക്കുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// അടുക്കിയ സബ്‌ലൈസുകൾ‌എക്‌സ്‌ട്രാക്റ്റുചെയ്യുന്നതിന് ഈ രീതി ഉപയോഗിക്കാം:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// മൂലകങ്ങളെ വേർതിരിക്കാനുള്ള പ്രവചനം ഉപയോഗിച്ച് ഓവർലാപ്പുചെയ്യാത്ത മ്യൂട്ടബിൾ റൺസ് ഉൽ‌പാദിപ്പിക്കുന്ന സ്ലൈസിന് മുകളിലൂടെ ഒരു ഇറ്ററേറ്റർ നൽകുന്നു.
    ///
    /// പ്രവചനത്തെ സ്വയം പിന്തുടരുന്ന രണ്ട് ഘടകങ്ങളിലേക്ക് വിളിക്കുന്നു, അതിനർത്ഥം `slice[0]`, `slice[1]` എന്നിവയിൽ XD2X, `slice[2]` എന്നിങ്ങനെ പ്രവചിക്കുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// അടുക്കിയ സബ്‌ലൈസുകൾ‌എക്‌സ്‌ട്രാക്റ്റുചെയ്യുന്നതിന് ഈ രീതി ഉപയോഗിക്കാം:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// ഒരു സൂചികയിൽ ഒരു സ്ലൈസ് രണ്ടായി വിഭജിക്കുന്നു.
    ///
    /// ആദ്യത്തേതിൽ `[0, mid)`-ൽ നിന്നുള്ള എല്ലാ സൂചികകളും (സൂചിക `mid` ഒഴികെ) രണ്ടാമത്തേതിൽ `[mid, len)`-ൽ നിന്നുള്ള എല്ലാ സൂചികകളും അടങ്ങിയിരിക്കും (`len` സൂചിക ഒഴികെ).
    ///
    ///
    /// # Panics
    ///
    /// `mid > len` എങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // സുരക്ഷ: `[ptr; mid]`, `[mid; len]` എന്നിവ `self`-നുള്ളിലാണ്, അത്
        // `from_raw_parts_mut`-ന്റെ ആവശ്യകതകൾ നിറവേറ്റുന്നു.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// ഒരു സൂചികയിൽ ഒരു മ്യൂട്ടബിൾ സ്ലൈസ് രണ്ടായി വിഭജിക്കുന്നു.
    ///
    /// ആദ്യത്തേതിൽ `[0, mid)`-ൽ നിന്നുള്ള എല്ലാ സൂചികകളും (സൂചിക `mid` ഒഴികെ) രണ്ടാമത്തേതിൽ `[mid, len)`-ൽ നിന്നുള്ള എല്ലാ സൂചികകളും അടങ്ങിയിരിക്കും (`len` സൂചിക ഒഴികെ).
    ///
    ///
    /// # Panics
    ///
    /// `mid > len` എങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // സുരക്ഷ: `[ptr; mid]`, `[mid; len]` എന്നിവ `self`-നുള്ളിലാണ്, അത്
        // `from_raw_parts_mut`-ന്റെ ആവശ്യകതകൾ നിറവേറ്റുന്നു.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// അതിർത്തി പരിശോധന നടത്താതെ ഒരു സൂചികയിൽ ഒരു സ്ലൈസ് രണ്ടായി വിഭജിക്കുന്നു.
    ///
    /// ആദ്യത്തേതിൽ `[0, mid)`-ൽ നിന്നുള്ള എല്ലാ സൂചികകളും (സൂചിക `mid` ഒഴികെ) രണ്ടാമത്തേതിൽ `[mid, len)`-ൽ നിന്നുള്ള എല്ലാ സൂചികകളും അടങ്ങിയിരിക്കും (`len` സൂചിക ഒഴികെ).
    ///
    ///
    /// സുരക്ഷിതമായ ബദലിനായി [`split_at`] കാണുക.
    ///
    /// # Safety
    ///
    /// ഫലമായുണ്ടാകുന്ന റഫറൻസ് ഉപയോഗിച്ചില്ലെങ്കിൽപ്പോലും ഈ രീതിയെ പരിധിക്ക് പുറത്തുള്ള സൂചിക ഉപയോഗിച്ച് വിളിക്കുന്നത് *[നിർവചിക്കപ്പെടാത്ത പെരുമാറ്റം]* ആണ്.വിളിക്കുന്നയാൾ `0 <= mid <= self.len()` ആണെന്ന് ഉറപ്പാക്കേണ്ടതുണ്ട്.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // സുരക്ഷ: കോളർ `0 <= mid <= self.len()` എന്ന് പരിശോധിക്കേണ്ടതുണ്ട്
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// അതിർത്തി പരിശോധന നടത്താതെ, ഒരു മ്യൂട്ടബിൾ സ്ലൈസ് ഒരു സൂചികയിൽ രണ്ടായി വിഭജിക്കുന്നു.
    ///
    /// ആദ്യത്തേതിൽ `[0, mid)`-ൽ നിന്നുള്ള എല്ലാ സൂചികകളും (സൂചിക `mid` ഒഴികെ) രണ്ടാമത്തേതിൽ `[mid, len)`-ൽ നിന്നുള്ള എല്ലാ സൂചികകളും അടങ്ങിയിരിക്കും (`len` സൂചിക ഒഴികെ).
    ///
    ///
    /// സുരക്ഷിതമായ ബദലിനായി [`split_at_mut`] കാണുക.
    ///
    /// # Safety
    ///
    /// ഫലമായുണ്ടാകുന്ന റഫറൻസ് ഉപയോഗിച്ചില്ലെങ്കിൽപ്പോലും ഈ രീതിയെ പരിധിക്ക് പുറത്തുള്ള സൂചിക ഉപയോഗിച്ച് വിളിക്കുന്നത് *[നിർവചിക്കപ്പെടാത്ത പെരുമാറ്റം]* ആണ്.വിളിക്കുന്നയാൾ `0 <= mid <= self.len()` ആണെന്ന് ഉറപ്പാക്കേണ്ടതുണ്ട്.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // സുരക്ഷ: കോളർ `0 <= mid <= self.len()` എന്ന് പരിശോധിക്കേണ്ടതുണ്ട്.
        //
        // `[ptr; mid]` ഒപ്പം `[mid; len]` ഓവർലാപ്പ് ചെയ്യുന്നില്ല, അതിനാൽ ഒരു മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നത് മികച്ചതാണ്.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// `pred`-മായി പൊരുത്തപ്പെടുന്ന ഘടകങ്ങളാൽ വേർതിരിച്ച സബ്‌ലൈസുകളിൽ ഒരു ഇറ്ററേറ്റർ നൽകുന്നു.
    /// പൊരുത്തപ്പെടുന്ന ഘടകം സബ്‌സ്‌ലൈസുകളിൽ അടങ്ങിയിട്ടില്ല.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// ആദ്യ ഘടകം പൊരുത്തപ്പെടുന്നുവെങ്കിൽ, ശൂന്യമായ സ്ലൈസ് ഇറ്ററേറ്റർ നൽകിയ ആദ്യ ഇനമായിരിക്കും.
    /// അതുപോലെ, സ്ലൈസിലെ അവസാന ഘടകം പൊരുത്തപ്പെടുന്നുവെങ്കിൽ, ശൂന്യമായ സ്ലൈസ് ഇറ്ററേറ്റർ നൽകിയ അവസാന ഇനമായിരിക്കും:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// പൊരുത്തപ്പെടുന്ന രണ്ട് ഘടകങ്ങൾ നേരിട്ട് തൊട്ടടുത്താണെങ്കിൽ, അവയ്ക്കിടയിൽ ഒരു ശൂന്യമായ സ്ലൈസ് ഉണ്ടാകും:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// `pred`-മായി പൊരുത്തപ്പെടുന്ന ഘടകങ്ങളാൽ വേർതിരിച്ച മ്യൂട്ടബിൾ സബ്‌ലൈസുകളിൽ ഒരു ഇറ്ററേറ്റർ നൽകുന്നു.
    /// പൊരുത്തപ്പെടുന്ന ഘടകം സബ്‌സ്‌ലൈസുകളിൽ അടങ്ങിയിട്ടില്ല.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// `pred`-മായി പൊരുത്തപ്പെടുന്ന ഘടകങ്ങളാൽ വേർതിരിച്ച സബ്‌ലൈസുകളിൽ ഒരു ഇറ്ററേറ്റർ നൽകുന്നു.
    /// പൊരുത്തപ്പെടുന്ന ഘടകം ഒരു ടെർമിനേറ്ററായി മുമ്പത്തെ സബ്‌ലൈസിന്റെ അവസാനത്തിൽ അടങ്ങിയിരിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// സ്ലൈസിന്റെ അവസാന ഘടകം പൊരുത്തപ്പെടുന്നുവെങ്കിൽ, ആ ഘടകം മുമ്പത്തെ സ്ലൈസിന്റെ ടെർമിനേറ്ററായി കണക്കാക്കും.
    ///
    /// ആ സ്ലൈസ് ഇറ്ററേറ്റർ നൽകിയ അവസാന ഇനമായിരിക്കും.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// `pred`-മായി പൊരുത്തപ്പെടുന്ന ഘടകങ്ങളാൽ വേർതിരിച്ച മ്യൂട്ടബിൾ സബ്‌ലൈസുകളിൽ ഒരു ഇറ്ററേറ്റർ നൽകുന്നു.
    /// പൊരുത്തപ്പെടുന്ന ഘടകം ഒരു ടെർമിനേറ്ററായി മുമ്പത്തെ സബ്‌ലൈസിൽ അടങ്ങിയിരിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// `pred`-മായി പൊരുത്തപ്പെടുന്ന ഘടകങ്ങളാൽ വേർതിരിച്ച സബ്‌ലൈസുകളിൽ ഒരു ഇറ്ററേറ്റർ നൽകുന്നു, സ്ലൈസിന്റെ അവസാനം മുതൽ പിന്നിലേക്ക് പ്രവർത്തിക്കുന്നു.
    /// പൊരുത്തപ്പെടുന്ന ഘടകം സബ്‌സ്‌ലൈസുകളിൽ അടങ്ങിയിട്ടില്ല.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `split()` പോലെ, ആദ്യത്തേതോ അവസാനത്തെയോ ഘടകം പൊരുത്തപ്പെടുന്നുവെങ്കിൽ, ശൂന്യമായ സ്ലൈസ് ഇറ്ററേറ്റർ നൽകിയ ആദ്യത്തെ (അല്ലെങ്കിൽ അവസാന) ഇനമായിരിക്കും.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// `pred`-മായി പൊരുത്തപ്പെടുന്ന ഘടകങ്ങളാൽ വേർതിരിച്ച മ്യൂട്ടബിൾ സബ്‌ലൈസുകളിൽ ഒരു ഇറ്ററേറ്റർ നൽകുന്നു, സ്ലൈസിന്റെ അവസാനം ആരംഭിച്ച് പിന്നിലേക്ക് പ്രവർത്തിക്കുന്നു.
    /// പൊരുത്തപ്പെടുന്ന ഘടകം സബ്‌സ്‌ലൈസുകളിൽ അടങ്ങിയിട്ടില്ല.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// `pred`-മായി പൊരുത്തപ്പെടുന്ന ഘടകങ്ങളാൽ വേർതിരിച്ച സബ്‌ലൈസുകളിലൂടെ ഒരു ഇറ്ററേറ്റർ നൽകുന്നു, മിക്ക `n` ഇനങ്ങളിലും മടങ്ങുന്നതിന് പരിമിതപ്പെടുത്തിയിരിക്കുന്നു.
    /// പൊരുത്തപ്പെടുന്ന ഘടകം സബ്‌സ്‌ലൈസുകളിൽ അടങ്ങിയിട്ടില്ല.
    ///
    /// മടങ്ങിയെത്തിയ അവസാന ഘടകം, എന്തെങ്കിലും ഉണ്ടെങ്കിൽ, സ്ലൈസിന്റെ ബാക്കി ഭാഗം അടങ്ങിയിരിക്കും.
    ///
    /// # Examples
    ///
    /// 3 കൊണ്ട് ഹരിക്കാവുന്ന സംഖ്യകളാൽ സ്ലൈസ് സ്പ്ലിറ്റ് ഒരിക്കൽ പ്രിന്റുചെയ്യുക (അതായത്, `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// `pred`-മായി പൊരുത്തപ്പെടുന്ന ഘടകങ്ങളാൽ വേർതിരിച്ച സബ്‌ലൈസുകളിലൂടെ ഒരു ഇറ്ററേറ്റർ നൽകുന്നു, മിക്ക `n` ഇനങ്ങളിലും മടങ്ങുന്നതിന് പരിമിതപ്പെടുത്തിയിരിക്കുന്നു.
    /// പൊരുത്തപ്പെടുന്ന ഘടകം സബ്‌സ്‌ലൈസുകളിൽ അടങ്ങിയിട്ടില്ല.
    ///
    /// മടങ്ങിയെത്തിയ അവസാന ഘടകം, എന്തെങ്കിലും ഉണ്ടെങ്കിൽ, സ്ലൈസിന്റെ ബാക്കി ഭാഗം അടങ്ങിയിരിക്കും.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// മിക്ക `n` ഇനങ്ങളിലും മടങ്ങുന്നതിന് പരിമിതപ്പെടുത്തിയിരിക്കുന്ന `pred`-മായി പൊരുത്തപ്പെടുന്ന ഘടകങ്ങളാൽ വേർതിരിച്ച സബ്‌ലൈസുകളിലൂടെ ഒരു ഇറ്ററേറ്റർ നൽകുന്നു.
    /// ഇത് സ്ലൈസിന്റെ അവസാനം ആരംഭിച്ച് പിന്നിലേക്ക് പ്രവർത്തിക്കുന്നു.
    /// പൊരുത്തപ്പെടുന്ന ഘടകം സബ്‌സ്‌ലൈസുകളിൽ അടങ്ങിയിട്ടില്ല.
    ///
    /// മടങ്ങിയെത്തിയ അവസാന ഘടകം, എന്തെങ്കിലും ഉണ്ടെങ്കിൽ, സ്ലൈസിന്റെ ബാക്കി ഭാഗം അടങ്ങിയിരിക്കും.
    ///
    /// # Examples
    ///
    /// സ്ലൈസ് സ്പ്ലിറ്റ് ഒരു തവണ അച്ചടിക്കുക, അവസാനം മുതൽ 3 കൊണ്ട് ഹരിക്കാവുന്ന സംഖ്യകൾ (അതായത്, `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// മിക്ക `n` ഇനങ്ങളിലും മടങ്ങുന്നതിന് പരിമിതപ്പെടുത്തിയിരിക്കുന്ന `pred`-മായി പൊരുത്തപ്പെടുന്ന ഘടകങ്ങളാൽ വേർതിരിച്ച സബ്‌ലൈസുകളിലൂടെ ഒരു ഇറ്ററേറ്റർ നൽകുന്നു.
    /// ഇത് സ്ലൈസിന്റെ അവസാനം ആരംഭിച്ച് പിന്നിലേക്ക് പ്രവർത്തിക്കുന്നു.
    /// പൊരുത്തപ്പെടുന്ന ഘടകം സബ്‌സ്‌ലൈസുകളിൽ അടങ്ങിയിട്ടില്ല.
    ///
    /// മടങ്ങിയെത്തിയ അവസാന ഘടകം, എന്തെങ്കിലും ഉണ്ടെങ്കിൽ, സ്ലൈസിന്റെ ബാക്കി ഭാഗം അടങ്ങിയിരിക്കും.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// തന്നിരിക്കുന്ന മൂല്യമുള്ള ഒരു ഘടകം സ്ലൈസിൽ അടങ്ങിയിട്ടുണ്ടെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// നിങ്ങൾക്ക് ഒരു `&T` ഇല്ലെങ്കിൽ, എന്നാൽ `T: Borrow<U>` പോലുള്ള ഒരു `&U` (ഉദാ
    /// `സ്ട്രിംഗ്: കടം വാങ്ങുക<str>`), നിങ്ങൾക്ക് `iter().any` ഉപയോഗിക്കാം:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // `String` സ്ലൈസ്
    /// assert!(v.iter().any(|e| e == "hello")); // `&str` ഉപയോഗിച്ച് തിരയുക
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// `needle` സ്ലൈസിന്റെ പ്രിഫിക്‌സാണെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// `needle` ഒരു ശൂന്യ സ്ലൈസാണെങ്കിൽ എല്ലായ്പ്പോഴും `true` നൽകുന്നു:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// `needle` സ്ലൈസിന്റെ സഫിക്‌സ് ആണെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// `needle` ഒരു ശൂന്യ സ്ലൈസാണെങ്കിൽ എല്ലായ്പ്പോഴും `true` നൽകുന്നു:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// നീക്കംചെയ്‌ത പ്രിഫിക്‌സിനൊപ്പം ഒരു സബ്‌ലൈസ് നൽകുന്നു.
    ///
    /// സ്ലൈസ് `prefix`-ൽ ആരംഭിക്കുകയാണെങ്കിൽ, `Some`-ൽ പൊതിഞ്ഞ് പ്രിഫിക്സിന് ശേഷം സബ്‌ലൈസ് നൽകുന്നു.
    /// `prefix` ശൂന്യമാണെങ്കിൽ, യഥാർത്ഥ സ്ലൈസ് നൽകുന്നു.
    ///
    /// സ്ലൈസ് `prefix`-ൽ ആരംഭിക്കുന്നില്ലെങ്കിൽ, `None` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // സ്ലൈസ് പാറ്റേൺ കൂടുതൽ സങ്കീർണ്ണമാകുമ്പോൾ ഈ ഫംഗ്ഷന് മാറ്റിയെഴുതേണ്ടതുണ്ട്.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// നീക്കംചെയ്‌ത സഫിക്‌സിനൊപ്പം ഒരു സബ്‌ലൈസ് നൽകുന്നു.
    ///
    /// സ്ലൈസ് `suffix`-ൽ അവസാനിക്കുകയാണെങ്കിൽ, `Some`-ൽ പൊതിഞ്ഞ് സഫിക്സിന് മുമ്പായി സബ്‌ലൈസ് നൽകുന്നു.
    /// `suffix` ശൂന്യമാണെങ്കിൽ, യഥാർത്ഥ സ്ലൈസ് നൽകുന്നു.
    ///
    /// സ്ലൈസ് `suffix` ൽ അവസാനിക്കുന്നില്ലെങ്കിൽ, `None` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // സ്ലൈസ് പാറ്റേൺ കൂടുതൽ സങ്കീർണ്ണമാകുമ്പോൾ ഈ ഫംഗ്ഷന് മാറ്റിയെഴുതേണ്ടതുണ്ട്.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// തന്നിരിക്കുന്ന ഘടകത്തിനായി ബൈനറി ഈ അടുക്കിയ സ്ലൈസ് തിരയുന്നു.
    ///
    /// മൂല്യം കണ്ടെത്തിയാൽ, പൊരുത്തപ്പെടുന്ന ഘടകത്തിന്റെ സൂചിക അടങ്ങിയ [`Result::Ok`] മടക്കിനൽകുന്നു.
    /// ഒന്നിലധികം മത്സരങ്ങളുണ്ടെങ്കിൽ, ഏതെങ്കിലും ഒരു മത്സരം മടക്കിനൽകാം.
    /// മൂല്യം കണ്ടെത്തിയില്ലെങ്കിൽ, അടുക്കിയ ക്രമം നിലനിർത്തിക്കൊണ്ട് പൊരുത്തപ്പെടുന്ന ഘടകം ഉൾപ്പെടുത്താൻ കഴിയുന്ന സൂചിക അടങ്ങിയ [`Result::Err`] മടക്കിനൽകുന്നു.
    ///
    ///
    /// [`binary_search_by`], [`binary_search_by_key`], [`partition_point`] എന്നിവയും കാണുക.
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// നാല് ഘടകങ്ങളുടെ ഒരു ശ്രേണി തിരയുന്നു.
    /// ആദ്യത്തേത് അദ്വിതീയമായി നിർണ്ണയിക്കപ്പെട്ട സ്ഥാനത്തോടെ കണ്ടെത്തി;രണ്ടാമത്തെയും മൂന്നാമത്തെയും കണ്ടെത്തിയില്ല;നാലാമത്തേതിന് `[1, 4]`-ലെ ഏത് സ്ഥാനവുമായും പൊരുത്തപ്പെടാം.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// അടുക്കിയ ക്രമം നിലനിർത്തിക്കൊണ്ടുതന്നെ, അടുക്കിയ vector-ലേക്ക് ഒരു ഇനം ചേർക്കാൻ നിങ്ങൾ ആഗ്രഹിക്കുന്നുവെങ്കിൽ:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// ഒരു താരതമ്യ ഫംഗ്ഷൻ ഉപയോഗിച്ച് ബൈനറി ഈ അടുക്കിയ സ്ലൈസ് തിരയുന്നു.
    ///
    /// താരതമ്യ ഫംഗ്ഷൻ അന്തർലീനമായ സ്ലൈസിന്റെ ക്രമ ക്രമത്തിന് അനുസൃതമായ ഒരു ഓർഡർ നടപ്പിലാക്കണം, അതിന്റെ ആർഗ്യുമെന്റ് `Less`, `Equal` അല്ലെങ്കിൽ `Greater` ആവശ്യമുള്ള ടാർഗെറ്റാണോ എന്ന് സൂചിപ്പിക്കുന്ന ഒരു ഓർഡർ കോഡ് നൽകുന്നു.
    ///
    ///
    /// മൂല്യം കണ്ടെത്തിയാൽ, പൊരുത്തപ്പെടുന്ന ഘടകത്തിന്റെ സൂചിക അടങ്ങിയ [`Result::Ok`] മടക്കിനൽകുന്നു.ഒന്നിലധികം മത്സരങ്ങളുണ്ടെങ്കിൽ, ഏതെങ്കിലും ഒരു മത്സരം മടക്കിനൽകാം.
    /// മൂല്യം കണ്ടെത്തിയില്ലെങ്കിൽ, അടുക്കിയ ക്രമം നിലനിർത്തിക്കൊണ്ട് പൊരുത്തപ്പെടുന്ന ഘടകം ഉൾപ്പെടുത്താൻ കഴിയുന്ന സൂചിക അടങ്ങിയ [`Result::Err`] മടക്കിനൽകുന്നു.
    ///
    /// [`binary_search`], [`binary_search_by_key`], [`partition_point`] എന്നിവയും കാണുക.
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// നാല് ഘടകങ്ങളുടെ ഒരു ശ്രേണി തിരയുന്നു.ആദ്യത്തേത് അദ്വിതീയമായി നിർണ്ണയിക്കപ്പെട്ട സ്ഥാനത്തോടെ കണ്ടെത്തി;രണ്ടാമത്തെയും മൂന്നാമത്തെയും കണ്ടെത്തിയില്ല;നാലാമത്തേതിന് `[1, 4]`-ലെ ഏത് സ്ഥാനവുമായും പൊരുത്തപ്പെടാം.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // സുരക്ഷ: ഇനിപ്പറയുന്ന മാറ്റങ്ങളാൽ കോൾ സുരക്ഷിതമാക്കി:
            // - `mid >= 0`
            // - `mid < size`: `mid` പരിമിതപ്പെടുത്തിയിരിക്കുന്നു `[left; right)`.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // പൊരുത്തത്തിനുപകരം ഞങ്ങൾ if/else നിയന്ത്രണ ഫ്ലോ ഉപയോഗിക്കുന്നതിനുള്ള കാരണം, പൊരുത്തപ്പെടുത്തൽ പ്രവർത്തനങ്ങളെ മാച്ച് പുന order ക്രമീകരിക്കുന്നു, ഇത് തികഞ്ഞ സെൻസിറ്റീവ് ആണ്.
            //
            // ഇത് u8-നായുള്ള x86 asm ആണ്: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// ഒരു കീ എക്സ്ട്രാക്ഷൻ ഫംഗ്ഷൻ ഉപയോഗിച്ച് ബൈനറി ഈ അടുക്കിയ സ്ലൈസ് തിരയുന്നു.
    ///
    /// സ്ലൈസ് കീ ഉപയോഗിച്ച് അടുക്കിയിട്ടുണ്ടെന്ന് അനുമാനിക്കുന്നു, ഉദാഹരണത്തിന് ഒരേ കീ എക്സ്ട്രാക്ഷൻ ഫംഗ്ഷൻ ഉപയോഗിച്ച് [`sort_by_key`] ഉപയോഗിച്ച്.
    ///
    /// മൂല്യം കണ്ടെത്തിയാൽ, പൊരുത്തപ്പെടുന്ന ഘടകത്തിന്റെ സൂചിക അടങ്ങിയ [`Result::Ok`] മടക്കിനൽകുന്നു.
    /// ഒന്നിലധികം മത്സരങ്ങളുണ്ടെങ്കിൽ, ഏതെങ്കിലും ഒരു മത്സരം മടക്കിനൽകാം.
    /// മൂല്യം കണ്ടെത്തിയില്ലെങ്കിൽ, അടുക്കിയ ക്രമം നിലനിർത്തിക്കൊണ്ട് പൊരുത്തപ്പെടുന്ന ഘടകം ഉൾപ്പെടുത്താൻ കഴിയുന്ന സൂചിക അടങ്ങിയ [`Result::Err`] മടക്കിനൽകുന്നു.
    ///
    ///
    /// [`binary_search`], [`binary_search_by`], [`partition_point`] എന്നിവയും കാണുക.
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// രണ്ടാമത്തെ ഘടകങ്ങളാൽ അടുക്കിയ ജോഡികളുടെ ഒരു സ്ലൈസിലെ നാല് ഘടകങ്ങളുടെ ഒരു ശ്രേണി തിരയുന്നു.
    /// ആദ്യത്തേത് അദ്വിതീയമായി നിർണ്ണയിക്കപ്പെട്ട സ്ഥാനത്തോടെ കണ്ടെത്തി;രണ്ടാമത്തെയും മൂന്നാമത്തെയും കണ്ടെത്തിയില്ല;നാലാമത്തേതിന് `[1, 4]`-ലെ ഏത് സ്ഥാനവുമായും പൊരുത്തപ്പെടാം.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // `slice::sort_by_key` crate `alloc`-ൽ ഉള്ളതിനാൽ Lint rustdoc::broken_intra_doc_links അനുവദനീയമാണ്, മാത്രമല്ല `core` നിർമ്മിക്കുമ്പോൾ ഇതുവരെയും നിലവിലില്ല.
    //
    // ഡ st ൺസ്ട്രീമിലേക്കുള്ള ലിങ്കുകൾ crate: #74481.പ്രൈമിറ്റീവുകൾ libstd (#73423) ൽ മാത്രമേ രേഖപ്പെടുത്തിയിട്ടുള്ളൂ എന്നതിനാൽ, ഇത് ഒരിക്കലും പ്രായോഗികമായി തകർന്ന ലിങ്കുകളിലേക്ക് നയിക്കുന്നില്ല.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// സ്ലൈസ് അടുക്കുന്നു, പക്ഷേ തുല്യ ഘടകങ്ങളുടെ ക്രമം സംരക്ഷിക്കാനിടയില്ല.
    ///
    /// ഈ തരം അസ്ഥിരമാണ് (അതായത്, തുല്യ ഘടകങ്ങൾ പുന order ക്രമീകരിക്കാം), സ്ഥലത്ത് (അതായത്, അനുവദിക്കുന്നില്ല),*O*(*n*\*log(* n*)) ഏറ്റവും മോശം അവസ്ഥ.
    ///
    /// # നിലവിലെ നടപ്പാക്കൽ
    ///
    /// നിലവിലെ അൽ‌ഗോരിതം ഓഴ്‌സൺ പീറ്റേഴ്‌സിന്റെ [pattern-defeating quicksort][pdqsort] അടിസ്ഥാനമാക്കിയുള്ളതാണ്, ഇത് ക്രമരഹിതമായ ക്വിസ്‌കോർട്ടിന്റെ വേഗത്തിലുള്ള ശരാശരി കേസ് ഹീപ്‌സോർട്ടിന്റെ ഏറ്റവും മോശം കേസുമായി സംയോജിപ്പിക്കുകയും ചില പാറ്റേണുകൾ ഉപയോഗിച്ച് സ്ലൈസുകളിൽ രേഖീയ സമയം നേടുകയും ചെയ്യുന്നു.
    /// അധ enera പതിച്ച കേസുകൾ ഒഴിവാക്കാൻ ഇത് ചില റാൻഡമൈസേഷൻ ഉപയോഗിക്കുന്നു, എന്നാൽ എല്ലായ്പ്പോഴും നിർണ്ണായക സ്വഭാവം നൽകുന്നതിന് ഒരു നിശ്ചിത seed ഉപയോഗിച്ച്.
    ///
    /// സ്ഥിരമായ തരംതിരിക്കലിനേക്കാൾ ഇത് വേഗതയേറിയതാണ്, ചില പ്രത്യേക സന്ദർഭങ്ങളിലൊഴികെ, ഉദാ. സ്ലൈസിൽ നിരവധി സംയോജിത തരംതിരിച്ച സീക്വൻസുകൾ അടങ്ങിയിരിക്കുമ്പോൾ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// ഒരു താരതമ്യ ഫംഗ്ഷൻ ഉപയോഗിച്ച് സ്ലൈസ് അടുക്കുന്നു, പക്ഷേ തുല്യ ഘടകങ്ങളുടെ ക്രമം സംരക്ഷിക്കാനിടയില്ല.
    ///
    /// ഈ തരം അസ്ഥിരമാണ് (അതായത്, തുല്യ ഘടകങ്ങൾ പുന order ക്രമീകരിക്കാം), സ്ഥലത്ത് (അതായത്, അനുവദിക്കുന്നില്ല),*O*(*n*\*log(* n*)) ഏറ്റവും മോശം അവസ്ഥ.
    ///
    /// സ്ലൈസിലെ ഘടകങ്ങൾക്കായുള്ള മൊത്തം ക്രമം താരതമ്യ ഫംഗ്ഷൻ നിർവചിക്കണം.ഓർ‌ഡറിംഗ് മൊത്തത്തിൽ‌ഇല്ലെങ്കിൽ‌, ഘടകങ്ങളുടെ ക്രമം വ്യക്തമാക്കിയിട്ടില്ല.ഒരു ഓർഡർ ഉണ്ടെങ്കിൽ ആകെ ഓർഡറാണ് (എല്ലാ `a`, `b`, `c` എന്നിവയ്‌ക്കും):
    ///
    /// * മൊത്തവും ആന്റിസിമമെട്രിക്കും: കൃത്യമായി `a < b`, `a == b` അല്ലെങ്കിൽ `a > b` എന്നിവയിൽ ഒന്ന് ശരിയാണ്, കൂടാതെ
    /// * ട്രാൻസിറ്റീവ്, `a < b`, `b < c` എന്നിവ `a < c` സൂചിപ്പിക്കുന്നു.`==`, `>` എന്നിവയ്‌ക്കും ഇത് സമാനമായിരിക്കണം.
    ///
    /// ഉദാഹരണത്തിന്, `NaN != NaN` [`Ord`] നടപ്പിലാക്കാത്തതിനാൽ `NaN != NaN`, സ്ലൈസിൽ ഒരു `NaN` അടങ്ങിയിട്ടില്ലെന്ന് അറിയുമ്പോൾ നമുക്ക് `partial_cmp` ഞങ്ങളുടെ സോർട്ട് ഫംഗ്ഷനായി ഉപയോഗിക്കാം.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # നിലവിലെ നടപ്പാക്കൽ
    ///
    /// നിലവിലെ അൽ‌ഗോരിതം ഓഴ്‌സൺ പീറ്റേഴ്‌സിന്റെ [pattern-defeating quicksort][pdqsort] അടിസ്ഥാനമാക്കിയുള്ളതാണ്, ഇത് ക്രമരഹിതമായ ക്വിസ്‌കോർട്ടിന്റെ വേഗത്തിലുള്ള ശരാശരി കേസ് ഹീപ്‌സോർട്ടിന്റെ ഏറ്റവും മോശം കേസുമായി സംയോജിപ്പിക്കുകയും ചില പാറ്റേണുകൾ ഉപയോഗിച്ച് സ്ലൈസുകളിൽ രേഖീയ സമയം നേടുകയും ചെയ്യുന്നു.
    /// അധ enera പതിച്ച കേസുകൾ ഒഴിവാക്കാൻ ഇത് ചില റാൻഡമൈസേഷൻ ഉപയോഗിക്കുന്നു, എന്നാൽ എല്ലായ്പ്പോഴും നിർണ്ണായക സ്വഭാവം നൽകുന്നതിന് ഒരു നിശ്ചിത seed ഉപയോഗിച്ച്.
    ///
    /// സ്ഥിരമായ തരംതിരിക്കലിനേക്കാൾ ഇത് വേഗതയേറിയതാണ്, ചില പ്രത്യേക സന്ദർഭങ്ങളിലൊഴികെ, ഉദാ. സ്ലൈസിൽ നിരവധി സംയോജിത തരംതിരിച്ച സീക്വൻസുകൾ അടങ്ങിയിരിക്കുമ്പോൾ.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // റിവേഴ്സ് സോർട്ടിംഗ്
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// ഒരു കീ എക്സ്ട്രാക്ഷൻ ഫംഗ്ഷൻ ഉപയോഗിച്ച് സ്ലൈസ് അടുക്കുന്നു, പക്ഷേ തുല്യ ഘടകങ്ങളുടെ ക്രമം സംരക്ഷിക്കാനിടയില്ല.
    ///
    /// ഈ തരം അസ്ഥിരമാണ് (അതായത്, തുല്യ ഘടകങ്ങൾ പുന order ക്രമീകരിക്കാം), സ്ഥലത്ത് (അതായത്, അനുവദിക്കുന്നില്ല),*O*(m\* * n *\* log(*n*)) ഏറ്റവും മോശം അവസ്ഥ, ഇവിടെ പ്രധാന പ്രവർത്തനം *O*(*മീ*).
    ///
    /// # നിലവിലെ നടപ്പാക്കൽ
    ///
    /// നിലവിലെ അൽ‌ഗോരിതം ഓഴ്‌സൺ പീറ്റേഴ്‌സിന്റെ [pattern-defeating quicksort][pdqsort] അടിസ്ഥാനമാക്കിയുള്ളതാണ്, ഇത് ക്രമരഹിതമായ ക്വിസ്‌കോർട്ടിന്റെ വേഗത്തിലുള്ള ശരാശരി കേസ് ഹീപ്‌സോർട്ടിന്റെ ഏറ്റവും മോശം കേസുമായി സംയോജിപ്പിക്കുകയും ചില പാറ്റേണുകൾ ഉപയോഗിച്ച് സ്ലൈസുകളിൽ രേഖീയ സമയം നേടുകയും ചെയ്യുന്നു.
    /// അധ enera പതിച്ച കേസുകൾ ഒഴിവാക്കാൻ ഇത് ചില റാൻഡമൈസേഷൻ ഉപയോഗിക്കുന്നു, എന്നാൽ എല്ലായ്പ്പോഴും നിർണ്ണായക സ്വഭാവം നൽകുന്നതിന് ഒരു നിശ്ചിത seed ഉപയോഗിച്ച്.
    ///
    /// കീ കോളിംഗ് തന്ത്രം കാരണം, കീ ഫംഗ്ഷൻ ചെലവേറിയ സന്ദർഭങ്ങളിൽ [`sort_unstable_by_key`](#method.sort_unstable_by_key) [`sort_by_cached_key`](#method.sort_by_cached_key) നേക്കാൾ മന്ദഗതിയിലാകാൻ സാധ്യതയുണ്ട്.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// സ്ലൈസ് പുന order ക്രമീകരിക്കുക, അങ്ങനെ `index` ലെ മൂലകം അതിന്റെ അന്തിമ അടുക്കിയ സ്ഥാനത്താണ്.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// സ്ലൈസ് ഒരു താരതമ്യ ഫംഗ്ഷൻ ഉപയോഗിച്ച് പുന order ക്രമീകരിക്കുക, അതായത് `index`-ലെ മൂലകം അതിന്റെ അന്തിമ അടുക്കിയ സ്ഥാനത്താണ്.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// ഒരു എക്സ്ട്രാക്ഷൻ ഫംഗ്ഷൻ ഉപയോഗിച്ച് സ്ലൈസ് പുന order ക്രമീകരിക്കുക, അതായത് `index`-ലെ മൂലകം അതിന്റെ അന്തിമ അടുക്കിയ സ്ഥാനത്താണ്.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// സ്ലൈസ് പുന order ക്രമീകരിക്കുക, അങ്ങനെ `index` ലെ മൂലകം അതിന്റെ അന്തിമ അടുക്കിയ സ്ഥാനത്താണ്.
    ///
    /// `i < index` സ്ഥാനത്തുള്ള ഏത് മൂല്യവും `j > index` സ്ഥാനത്ത് ഏത് മൂല്യത്തേക്കാളും കുറവോ തുല്യമോ ആകുന്ന അധിക സ്വത്ത് ഈ പുന ord ക്രമീകരണത്തിന് ഉണ്ട്.
    /// കൂടാതെ, ഈ പുന ord ക്രമീകരണം അസ്ഥിരമാണ് (അതായത്
    /// തുല്യ മൂലകങ്ങളുടെ എണ്ണം `index` സ്ഥാനത്ത് അവസാനിക്കും, സ്ഥലത്ത് (അതായത്
    /// അനുവദിക്കുന്നില്ല),*O*(*n*) ഏറ്റവും മോശം അവസ്ഥ.
    /// ഈ പ്രവർത്തനം മറ്റ് ലൈബ്രറികളിലും "kth element" എന്നും അറിയപ്പെടുന്നു.
    /// ഇത് ഇനിപ്പറയുന്ന മൂല്യങ്ങളുടെ മൂന്നിരട്ടി നൽകുന്നു: തന്നിരിക്കുന്ന സൂചികയിലെ ഒന്നിനേക്കാൾ കുറവാണ് എല്ലാ ഘടകങ്ങളും, തന്നിരിക്കുന്ന സൂചികയിലെ മൂല്യം, തന്നിരിക്കുന്ന സൂചികയിലെ ഒന്നിനേക്കാൾ വലുത്.
    ///
    ///
    /// # നിലവിലെ നടപ്പാക്കൽ
    ///
    /// നിലവിലെ അൽ‌ഗോരിതം [`sort_unstable`]-നായി ഉപയോഗിക്കുന്ന അതേ ക്വിക്സോർട്ട് അൽ‌ഗോരിത്തിന്റെ ക്വിക്ക്സെലക്റ്റ് ഭാഗത്തെ അടിസ്ഥാനമാക്കിയുള്ളതാണ്.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` ആയിരിക്കുമ്പോൾ Panics, അതായത് ശൂന്യമായ സ്ലൈസുകളിൽ എല്ലായ്പ്പോഴും panics എന്നാണ് അർത്ഥമാക്കുന്നത്.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // ശരാശരി കണ്ടെത്തുക
    /// v.select_nth_unstable(2);
    ///
    /// // നിർദ്ദിഷ്ട സൂചികയെക്കുറിച്ച് ഞങ്ങൾ അടുക്കുന്ന രീതിയെ അടിസ്ഥാനമാക്കി സ്ലൈസ് ഇനിപ്പറയുന്നതിൽ ഒന്നായിരിക്കുമെന്ന് ഞങ്ങൾക്ക് ഉറപ്പുണ്ട്.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// സ്ലൈസ് ഒരു താരതമ്യ ഫംഗ്ഷൻ ഉപയോഗിച്ച് പുന order ക്രമീകരിക്കുക, അതായത് `index`-ലെ മൂലകം അതിന്റെ അന്തിമ അടുക്കിയ സ്ഥാനത്താണ്.
    ///
    /// ഈ പുന ord ക്രമീകരണത്തിന് `i < index` സ്ഥാനത്തുള്ള ഏത് മൂല്യവും താരതമ്യ ഫംഗ്ഷൻ ഉപയോഗിച്ച് `j > index` സ്ഥാനത്ത് ഏത് മൂല്യത്തേക്കാളും കുറവോ തുല്യമോ ആയിരിക്കും എന്ന അധിക സ്വത്ത് ഉണ്ട്.
    /// കൂടാതെ, ഈ പുന ord ക്രമീകരണം അസ്ഥിരമാണ് (അതായത്, തുല്യ ഘടകങ്ങളുടെ എണ്ണം `index` സ്ഥാനത്ത് അവസാനിച്ചേക്കാം), സ്ഥലത്ത് (അതായത് അനുവദിക്കുന്നില്ല),*O*(*n*) ഏറ്റവും മോശം അവസ്ഥ.
    /// ഈ പ്രവർത്തനം മറ്റ് ലൈബ്രറികളിലും "kth element" എന്നും അറിയപ്പെടുന്നു.
    /// ഇത് ഇനിപ്പറയുന്ന മൂല്യങ്ങളുടെ മൂന്നിരട്ടി നൽകുന്നു: തന്നിരിക്കുന്ന സൂചികയിലെ ഒന്നിനേക്കാൾ കുറവുള്ള എല്ലാ ഘടകങ്ങളും, നൽകിയിരിക്കുന്ന സൂചികയിലെ മൂല്യം, നൽകിയിരിക്കുന്ന താരതമ്യ പ്രവർത്തനം ഉപയോഗിച്ച് തന്നിരിക്കുന്ന സൂചികയിലെ ഒന്നിനേക്കാൾ വലുത്.
    ///
    ///
    /// # നിലവിലെ നടപ്പാക്കൽ
    ///
    /// നിലവിലെ അൽ‌ഗോരിതം [`sort_unstable`]-നായി ഉപയോഗിക്കുന്ന അതേ ക്വിക്സോർട്ട് അൽ‌ഗോരിത്തിന്റെ ക്വിക്ക്സെലക്റ്റ് ഭാഗത്തെ അടിസ്ഥാനമാക്കിയുള്ളതാണ്.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` ആയിരിക്കുമ്പോൾ Panics, അതായത് ശൂന്യമായ സ്ലൈസുകളിൽ എല്ലായ്പ്പോഴും panics എന്നാണ് അർത്ഥമാക്കുന്നത്.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // സ്ലൈസ് അവരോഹണ ക്രമത്തിൽ അടുക്കിയതുപോലെ മീഡിയൻ കണ്ടെത്തുക.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // നിർദ്ദിഷ്ട സൂചികയെക്കുറിച്ച് ഞങ്ങൾ അടുക്കുന്ന രീതിയെ അടിസ്ഥാനമാക്കി സ്ലൈസ് ഇനിപ്പറയുന്നതിൽ ഒന്നായിരിക്കുമെന്ന് ഞങ്ങൾക്ക് ഉറപ്പുണ്ട്.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// ഒരു എക്സ്ട്രാക്ഷൻ ഫംഗ്ഷൻ ഉപയോഗിച്ച് സ്ലൈസ് പുന order ക്രമീകരിക്കുക, അതായത് `index`-ലെ മൂലകം അതിന്റെ അന്തിമ അടുക്കിയ സ്ഥാനത്താണ്.
    ///
    /// കീ എക്സ്ട്രാക്ഷൻ ഫംഗ്ഷൻ ഉപയോഗിച്ച് `i < index` സ്ഥാനത്തുള്ള ഏത് മൂല്യവും `j > index` സ്ഥാനത്ത് ഏത് മൂല്യത്തേക്കാളും കുറവോ തുല്യമോ ആകുന്ന അധിക സ്വത്ത് ഈ പുന ord ക്രമീകരണത്തിന് ഉണ്ട്.
    /// കൂടാതെ, ഈ പുന ord ക്രമീകരണം അസ്ഥിരമാണ് (അതായത്, തുല്യ ഘടകങ്ങളുടെ എണ്ണം `index` സ്ഥാനത്ത് അവസാനിച്ചേക്കാം), സ്ഥലത്ത് (അതായത് അനുവദിക്കുന്നില്ല),*O*(*n*) ഏറ്റവും മോശം അവസ്ഥ.
    /// ഈ പ്രവർത്തനം മറ്റ് ലൈബ്രറികളിലും "kth element" എന്നും അറിയപ്പെടുന്നു.
    /// ഇത് ഇനിപ്പറയുന്ന മൂല്യങ്ങളുടെ മൂന്നിരട്ടി നൽകുന്നു: നൽകിയിരിക്കുന്ന സൂചികയിലെ ഒന്നിനേക്കാൾ കുറവാണ് എല്ലാ ഘടകങ്ങളും, നൽകിയിരിക്കുന്ന സൂചികയിലെ മൂല്യം, നൽകിയിരിക്കുന്ന കീ എക്സ്ട്രാക്ഷൻ ഫംഗ്ഷൻ ഉപയോഗിച്ച് തന്നിരിക്കുന്ന സൂചികയിലെ ഒന്നിനേക്കാൾ വലുത്.
    ///
    ///
    /// # നിലവിലെ നടപ്പാക്കൽ
    ///
    /// നിലവിലെ അൽ‌ഗോരിതം [`sort_unstable`]-നായി ഉപയോഗിക്കുന്ന അതേ ക്വിക്സോർട്ട് അൽ‌ഗോരിത്തിന്റെ ക്വിക്ക്സെലക്റ്റ് ഭാഗത്തെ അടിസ്ഥാനമാക്കിയുള്ളതാണ്.
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// `index >= len()` ആയിരിക്കുമ്പോൾ Panics, അതായത് ശൂന്യമായ സ്ലൈസുകളിൽ എല്ലായ്പ്പോഴും panics എന്നാണ് അർത്ഥമാക്കുന്നത്.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // കേവല മൂല്യത്തിനനുസരിച്ച് അറേ അടുക്കിയതുപോലെ മീഡിയൻ മടങ്ങുക.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // നിർദ്ദിഷ്ട സൂചികയെക്കുറിച്ച് ഞങ്ങൾ അടുക്കുന്ന രീതിയെ അടിസ്ഥാനമാക്കി സ്ലൈസ് ഇനിപ്പറയുന്നതിൽ ഒന്നായിരിക്കുമെന്ന് ഞങ്ങൾക്ക് ഉറപ്പുണ്ട്.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// [`PartialEq`] trait നടപ്പിലാക്കൽ അനുസരിച്ച് തുടർച്ചയായി ആവർത്തിച്ചുള്ള എല്ലാ ഘടകങ്ങളും സ്ലൈസിന്റെ അവസാനത്തിലേക്ക് നീക്കുന്നു.
    ///
    ///
    /// രണ്ട് കഷ്ണങ്ങൾ നൽകുന്നു.ആദ്യത്തേതിൽ തുടർച്ചയായി ആവർത്തിച്ചുള്ള ഘടകങ്ങളൊന്നുമില്ല.
    /// രണ്ടാമത്തേതിൽ എല്ലാ തനിപ്പകർപ്പുകളും നിർദ്ദിഷ്ട ക്രമത്തിൽ അടങ്ങിയിട്ടില്ല.
    ///
    /// സ്ലൈസ് അടുക്കിയിട്ടുണ്ടെങ്കിൽ, ആദ്യം മടങ്ങിയ സ്ലൈസിൽ തനിപ്പകർപ്പുകളൊന്നുമില്ല.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// തന്നിരിക്കുന്ന തുല്യതാ ബന്ധത്തെ തൃപ്തിപ്പെടുത്തുന്ന സ്ലൈസിന്റെ അവസാനത്തിലേക്ക് തുടർച്ചയായ ഘടകങ്ങളിൽ ആദ്യത്തേത് ഒഴികെ എല്ലാം നീക്കുന്നു.
    ///
    /// രണ്ട് കഷ്ണങ്ങൾ നൽകുന്നു.ആദ്യത്തേതിൽ തുടർച്ചയായി ആവർത്തിച്ചുള്ള ഘടകങ്ങളൊന്നുമില്ല.
    /// രണ്ടാമത്തേതിൽ എല്ലാ തനിപ്പകർപ്പുകളും നിർദ്ദിഷ്ട ക്രമത്തിൽ അടങ്ങിയിട്ടില്ല.
    ///
    /// സ്ലൈസിൽ നിന്നുള്ള രണ്ട് ഘടകങ്ങളിലേക്ക് റഫറൻസുകൾ `same_bucket` ഫംഗ്ഷൻ കൈമാറി, ഘടകങ്ങൾ തുല്യമായി താരതമ്യം ചെയ്യുന്നുണ്ടോ എന്ന് നിർണ്ണയിക്കണം.
    /// ഘടകങ്ങൾ സ്ലൈസിലെ ക്രമത്തിൽ നിന്ന് വിപരീത ക്രമത്തിലാണ് കൈമാറുന്നത്, അതിനാൽ `same_bucket(a, b)` `true` നൽകുന്നുവെങ്കിൽ, സ്ലൈസിന്റെ അവസാനം `a` നീക്കുന്നു.
    ///
    ///
    /// സ്ലൈസ് അടുക്കിയിട്ടുണ്ടെങ്കിൽ, ആദ്യം മടങ്ങിയ സ്ലൈസിൽ തനിപ്പകർപ്പുകളൊന്നുമില്ല.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // ഞങ്ങൾക്ക് `self`-ലേക്ക് മ്യൂട്ടബിൾ റഫറൻസ് ഉണ്ടെങ്കിലും, ഞങ്ങൾക്ക് *അനിയന്ത്രിതമായ* മാറ്റങ്ങൾ വരുത്താൻ കഴിയില്ല.`same_bucket` കോളുകൾക്ക് panic ആകാം, അതിനാൽ സ്ലൈസ് എല്ലായ്‌പ്പോഴും സാധുവായ അവസ്ഥയിലാണെന്ന് ഞങ്ങൾ ഉറപ്പാക്കണം.
        //
        // സ്വാപ്പുകൾ ഉപയോഗിച്ചാണ് ഞങ്ങൾ ഇത് കൈകാര്യം ചെയ്യുന്ന രീതി;ഞങ്ങൾ എല്ലാ ഘടകങ്ങളെയും ആവർത്തിക്കുന്നു, ഞങ്ങൾ പോകുമ്പോൾ കൈമാറ്റം ചെയ്യുന്നു, അങ്ങനെ അവസാനം ഞങ്ങൾ സൂക്ഷിക്കാൻ ആഗ്രഹിക്കുന്ന ഘടകങ്ങൾ മുന്നിലുണ്ട്, ഞങ്ങൾ നിരസിക്കാൻ ആഗ്രഹിക്കുന്നവ പിന്നിലുണ്ട്.
        // നമുക്ക് പിന്നീട് സ്ലൈസ് വിഭജിക്കാം.
        // ഈ പ്രവർത്തനം ഇപ്പോഴും `O(n)` ആണ്.
        //
        // ഉദാഹരണം: `r` "അടുത്തത്" പ്രതിനിധീകരിക്കുന്ന ഈ അവസ്ഥയിലാണ് ഞങ്ങൾ ആരംഭിക്കുന്നത്
        // വായിക്കുക ", `w` അടുത്ത_റൈറ്റ്` പ്രതിനിധീകരിക്കുന്നു.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // സ്വയം [w-1] നെതിരായി self[r] നെ താരതമ്യം ചെയ്യുന്നത്, ഇത് ഒരു തനിപ്പകർപ്പല്ല, അതിനാൽ ഞങ്ങൾ self[r], self[w] എന്നിവ സ്വാപ്പ് ചെയ്യുന്നു (r==w ആയി യാതൊരു ഫലവുമില്ല), തുടർന്ന് r, w എന്നിവ വർദ്ധിപ്പിച്ച് ഞങ്ങളെ ഉപേക്ഷിക്കുന്നു:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // self[r] നെ സ്വയം [w-1] മായി താരതമ്യപ്പെടുത്തുമ്പോൾ, ഈ മൂല്യം ഒരു തനിപ്പകർപ്പാണ്, അതിനാൽ ഞങ്ങൾ `r` വർദ്ധിപ്പിക്കും, എന്നാൽ എല്ലാം മാറ്റമില്ലാതെ വിടുന്നു:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // സ്വയം [w-1] നെതിരെ self[r] നെ താരതമ്യം ചെയ്യുന്നത്, ഇത് ഒരു തനിപ്പകർപ്പല്ല, അതിനാൽ self[r], self[w] എന്നിവ സ്വാപ്പ് ചെയ്ത് അഡ്വാൻസ് r, w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // തനിപ്പകർപ്പല്ല, ആവർത്തിക്കുക:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // തനിപ്പകർപ്പ്, സ്ലൈസിന്റെ advance r. End.W-ൽ വിഭജിക്കുക.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // സുരക്ഷ: `while` അവസ്ഥ `next_read`, `next_write` എന്നിവ ഉറപ്പ് നൽകുന്നു
        // `len`-ൽ കുറവാണ്, അതിനാൽ `self`-നുള്ളിലാണ്.
        // `prev_ptr_write` `ptr_write` ന് മുമ്പായി ഒരു ഘടകത്തിലേക്ക് പോയിന്റുചെയ്യുന്നു, പക്ഷേ `next_write` 1 ൽ ആരംഭിക്കുന്നു, അതിനാൽ `prev_ptr_write` ഒരിക്കലും 0 ൽ കുറയാത്തതും സ്ലൈസിനുള്ളിലുമാണ്.
        // ഇത് `ptr_read`, `prev_ptr_write`, `ptr_write` എന്നിവ ഒഴിവാക്കുന്നതിനും `ptr.add(next_read)`, `ptr.add(next_write - 1)`, `prev_ptr_write.offset(1)` എന്നിവ ഉപയോഗിക്കുന്നതിനുമുള്ള ആവശ്യകതകൾ നിറവേറ്റുന്നു.
        //
        //
        // `next_write` ഒരു ലൂപ്പിന് ഒരു തവണയെങ്കിലും വർദ്ധിപ്പിക്കും, അതായത് സ്വാപ്പ് ചെയ്യേണ്ടിവരുമ്പോൾ ഒരു ഘടകവും ഒഴിവാക്കില്ല.
        //
        // `ptr_read` `prev_ptr_write` ഒരിക്കലും ഒരേ ഘടകത്തിലേക്ക് വിരൽ ചൂണ്ടുന്നില്ല.`&mut *ptr_read`, `&mut* prev_ptr_write` എന്നിവ സുരക്ഷിതമായിരിക്കാൻ ഇത് ആവശ്യമാണ്.
        // `next_read >= next_write` എല്ലായ്പ്പോഴും ശരിയാണെന്നതാണ് വിശദീകരണം, അതിനാൽ `next_read > next_write - 1` വളരെ കൂടുതലാണ്.
        //
        //
        //
        //
        //
        unsafe {
            // റോ പോയിന്ററുകൾ ഉപയോഗിച്ച് അതിർത്തി പരിശോധനകൾ ഒഴിവാക്കുക.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// ഒരേ കീയിലേക്ക് പരിഹരിക്കുന്ന സ്ലൈസിന്റെ അവസാനത്തിലേക്ക് തുടർച്ചയായ ഘടകങ്ങളിൽ ആദ്യത്തേത് ഒഴികെ എല്ലാം നീക്കുന്നു.
    ///
    ///
    /// രണ്ട് കഷ്ണങ്ങൾ നൽകുന്നു.ആദ്യത്തേതിൽ തുടർച്ചയായി ആവർത്തിച്ചുള്ള ഘടകങ്ങളൊന്നുമില്ല.
    /// രണ്ടാമത്തേതിൽ എല്ലാ തനിപ്പകർപ്പുകളും നിർദ്ദിഷ്ട ക്രമത്തിൽ അടങ്ങിയിട്ടില്ല.
    ///
    /// സ്ലൈസ് അടുക്കിയിട്ടുണ്ടെങ്കിൽ, ആദ്യം മടങ്ങിയ സ്ലൈസിൽ തനിപ്പകർപ്പുകളൊന്നുമില്ല.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// സ്ലൈസിന്റെ ആദ്യത്തെ `mid` ഘടകങ്ങൾ അവസാനത്തിലേക്കും അവസാന `self.len() - mid` ഘടകങ്ങൾ മുന്നിലേക്കും നീങ്ങുന്ന തരത്തിൽ സ്ലൈസ് സ്ഥലത്ത് തിരിക്കുന്നു.
    /// `rotate_left` എന്ന് വിളിച്ചതിന് ശേഷം, മുമ്പ് സൂചിക `mid` ലെ ഘടകം സ്ലൈസിലെ ആദ്യ ഘടകമായി മാറും.
    ///
    /// # Panics
    ///
    /// സ്ലൈസിന്റെ നീളത്തേക്കാൾ `mid` വലുതാണെങ്കിൽ ഈ പ്രവർത്തനം panic ആയിരിക്കും.`mid == self.len()` _not_ panic ചെയ്യുന്നുവെന്നും ഇത് ഒരു നോ-ഒപ്പ് റൊട്ടേഷനാണെന്നും ശ്രദ്ധിക്കുക.
    ///
    /// # Complexity
    ///
    /// ലീനിയർ എടുക്കുന്നു (`self.len()`) സമയത്ത്.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// ഒരു സബ്‌ലൈസ് തിരിക്കുന്നു:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // സുരക്ഷ: `[p.add(mid) - mid, p.add(mid) + k)` ശ്രേണി തുച്ഛമാണ്
        // `ptr_rotate` ആവശ്യപ്പെടുന്ന പ്രകാരം വായിക്കുന്നതിനും എഴുതുന്നതിനും സാധുതയുള്ളതാണ്.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// സ്ലൈസിന്റെ ആദ്യത്തെ `self.len() - k` ഘടകങ്ങൾ അവസാനത്തിലേക്കും അവസാന `k` ഘടകങ്ങൾ മുന്നിലേക്കും നീങ്ങുന്ന തരത്തിൽ സ്ലൈസ് സ്ഥലത്ത് തിരിക്കുന്നു.
    /// `rotate_right` എന്ന് വിളിച്ചതിന് ശേഷം, മുമ്പ് സൂചിക `self.len() - k` ലെ ഘടകം സ്ലൈസിലെ ആദ്യ ഘടകമായി മാറും.
    ///
    /// # Panics
    ///
    /// സ്ലൈസിന്റെ നീളത്തേക്കാൾ `k` വലുതാണെങ്കിൽ ഈ പ്രവർത്തനം panic ആയിരിക്കും.`k == self.len()` _not_ panic ചെയ്യുന്നുവെന്നും ഇത് ഒരു നോ-ഒപ്പ് റൊട്ടേഷനാണെന്നും ശ്രദ്ധിക്കുക.
    ///
    /// # Complexity
    ///
    /// ലീനിയർ എടുക്കുന്നു (`self.len()`) സമയത്ത്.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// ഒരു സബ്‌ലൈസ് തിരിക്കുക:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // സുരക്ഷ: `[p.add(mid) - mid, p.add(mid) + k)` ശ്രേണി തുച്ഛമാണ്
        // `ptr_rotate` ആവശ്യപ്പെടുന്ന പ്രകാരം വായിക്കുന്നതിനും എഴുതുന്നതിനും സാധുതയുള്ളതാണ്.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// `value` ക്ലോൺ ചെയ്യുന്നതിലൂടെ ഘടകങ്ങളുമായി `self` പൂരിപ്പിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// ഒരു അടയ്‌ക്കൽ ആവർത്തിച്ച് വിളിച്ച് നൽകിയ ഘടകങ്ങളുമായി `self` പൂരിപ്പിക്കുന്നു.
    ///
    /// പുതിയ മൂല്യങ്ങൾ സൃഷ്ടിക്കുന്നതിന് ഈ രീതി ഒരു അടയ്ക്കൽ ഉപയോഗിക്കുന്നു.തന്നിരിക്കുന്ന മൂല്യം [`Clone`] ചെയ്യാൻ നിങ്ങൾ ആഗ്രഹിക്കുന്നുവെങ്കിൽ, [`fill`] ഉപയോഗിക്കുക.
    /// മൂല്യങ്ങൾ സൃഷ്ടിക്കുന്നതിന് നിങ്ങൾക്ക് [`Default`] trait ഉപയോഗിക്കാൻ താൽപ്പര്യമുണ്ടെങ്കിൽ, നിങ്ങൾക്ക് ആർഗ്യുമെന്റായി [`Default::default`] കടന്നുപോകാൻ കഴിയും.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// `src`-ൽ നിന്ന് `self`-ലേക്ക് ഘടകങ്ങൾ പകർത്തുന്നു.
    ///
    /// `src` ന്റെ നീളം `self` ന് തുല്യമായിരിക്കണം.
    ///
    /// `T` `Copy` നടപ്പിലാക്കുകയാണെങ്കിൽ, [`copy_from_slice`] ഉപയോഗിക്കുന്നത് കൂടുതൽ പ്രകടനം കാഴ്ചവയ്ക്കാം.
    ///
    /// # Panics
    ///
    /// രണ്ട് സ്ലൈസുകൾക്ക് വ്യത്യസ്ത നീളമുണ്ടെങ്കിൽ ഈ ഫംഗ്ഷൻ panic ആയിരിക്കും.
    ///
    /// # Examples
    ///
    /// ഒരു സ്ലൈസിൽ നിന്ന് മറ്റൊന്നിലേക്ക് രണ്ട് ഘടകങ്ങൾ ക്ലോൺ ചെയ്യുന്നു:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // കഷ്ണങ്ങൾക്ക് ഒരേ നീളം ഉണ്ടായിരിക്കേണ്ടതിനാൽ, ഞങ്ങൾ ഉറവിട സ്ലൈസ് നാല് ഘടകങ്ങളിൽ നിന്ന് രണ്ടായി മുറിക്കുന്നു.
    /// // ഞങ്ങൾ ഇത് ചെയ്തില്ലെങ്കിൽ ഇത് panic ആയിരിക്കും.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// ഒരു പ്രത്യേക സ്കോപ്പിലെ ഒരു പ്രത്യേക ഡാറ്റയെക്കുറിച്ച് മാറ്റമില്ലാത്ത റഫറൻസുകളില്ലാത്ത ഒരു മ്യൂട്ടബിൾ റഫറൻസ് മാത്രമേ ഉണ്ടാകൂ എന്ന് Rust നടപ്പിലാക്കുന്നു.
    /// ഇക്കാരണത്താൽ, ഒരൊറ്റ സ്ലൈസിൽ `clone_from_slice` ഉപയോഗിക്കാൻ ശ്രമിക്കുന്നത് ഒരു കംപൈൽ പരാജയത്തിന് കാരണമാകും:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// ഇത് പരിഹരിക്കുന്നതിന്, ഒരു സ്ലൈസിൽ നിന്ന് രണ്ട് വ്യത്യസ്ത ഉപ-സ്ലൈസുകൾ സൃഷ്ടിക്കാൻ ഞങ്ങൾക്ക് [`split_at_mut`] ഉപയോഗിക്കാം:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// ഒരു മെംക്പി ഉപയോഗിച്ച് `src` മുതൽ `self` വരെ എല്ലാ ഘടകങ്ങളും പകർത്തുന്നു.
    ///
    /// `src` ന്റെ നീളം `self` ന് തുല്യമായിരിക്കണം.
    ///
    /// `T` `Copy` നടപ്പിലാക്കുന്നില്ലെങ്കിൽ, [`clone_from_slice`] ഉപയോഗിക്കുക.
    ///
    /// # Panics
    ///
    /// രണ്ട് സ്ലൈസുകൾക്ക് വ്യത്യസ്ത നീളമുണ്ടെങ്കിൽ ഈ ഫംഗ്ഷൻ panic ആയിരിക്കും.
    ///
    /// # Examples
    ///
    /// ഒരു സ്ലൈസിൽ നിന്ന് മറ്റൊന്നിലേക്ക് രണ്ട് ഘടകങ്ങൾ പകർത്തുന്നു:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // കഷ്ണങ്ങൾക്ക് ഒരേ നീളം ഉണ്ടായിരിക്കേണ്ടതിനാൽ, ഞങ്ങൾ ഉറവിട സ്ലൈസ് നാല് ഘടകങ്ങളിൽ നിന്ന് രണ്ടായി മുറിക്കുന്നു.
    /// // ഞങ്ങൾ ഇത് ചെയ്തില്ലെങ്കിൽ ഇത് panic ആയിരിക്കും.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// ഒരു പ്രത്യേക സ്കോപ്പിലെ ഒരു പ്രത്യേക ഡാറ്റയെക്കുറിച്ച് മാറ്റമില്ലാത്ത റഫറൻസുകളില്ലാത്ത ഒരു മ്യൂട്ടബിൾ റഫറൻസ് മാത്രമേ ഉണ്ടാകൂ എന്ന് Rust നടപ്പിലാക്കുന്നു.
    /// ഇക്കാരണത്താൽ, ഒരൊറ്റ സ്ലൈസിൽ `copy_from_slice` ഉപയോഗിക്കാൻ ശ്രമിക്കുന്നത് ഒരു കംപൈൽ പരാജയത്തിന് കാരണമാകും:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// ഇത് പരിഹരിക്കുന്നതിന്, ഒരു സ്ലൈസിൽ നിന്ന് രണ്ട് വ്യത്യസ്ത ഉപ-സ്ലൈസുകൾ സൃഷ്ടിക്കാൻ ഞങ്ങൾക്ക് [`split_at_mut`] ഉപയോഗിക്കാം:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // കോൾ സൈറ്റിനെ വീഴ്ത്താതിരിക്കാൻ panic കോഡ് പാത്ത് ഒരു തണുത്ത പ്രവർത്തനമാക്കി.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // സുരക്ഷ: നിർവചനം അനുസരിച്ച് `self.len()` ഘടകങ്ങൾക്ക് `self` സാധുവാണ്, കൂടാതെ `src` ആയിരുന്നു
        // ഒരേ നീളം ഉണ്ടെന്ന് പരിശോധിച്ചു.
        // സ്ലൈസുകൾ ഓവർലാപ്പ് ചെയ്യാൻ കഴിയില്ല കാരണം മ്യൂട്ടബിൾ റഫറൻസുകൾ എക്സ്ക്ലൂസീവ് ആണ്.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// സ്ലൈസിന്റെ ഒരു ഭാഗത്ത് നിന്ന് മറ്റൊരു ഭാഗത്തേക്ക് ഘടകങ്ങൾ ഒരു മെമ്മോവ് ഉപയോഗിച്ച് പകർത്തുന്നു.
    ///
    /// `src` എന്നത് പകർത്താനുള്ള `self`-നുള്ളിലുള്ള ശ്രേണിയാണ്.
    /// `dest` `self`-ലേക്ക് പകർത്താനുള്ള ശ്രേണിയുടെ ആരംഭ സൂചികയാണ്, ഇതിന് `src`-ന് തുല്യമായ നീളമുണ്ടാകും.
    /// രണ്ട് ശ്രേണികളും ഓവർലാപ്പുചെയ്യാം.
    /// രണ്ട് ശ്രേണികളുടെ അറ്റങ്ങൾ `self.len()`-ൽ കുറവോ തുല്യമോ ആയിരിക്കണം.
    ///
    /// # Panics
    ///
    /// ഒന്നുകിൽ ശ്രേണി സ്ലൈസിന്റെ അവസാനം കവിയുന്നുവെങ്കിൽ അല്ലെങ്കിൽ `src` ന്റെ അവസാനം ആരംഭിക്കുന്നതിന് മുമ്പാണെങ്കിൽ ഈ ഫംഗ്ഷൻ panic ആയിരിക്കും.
    ///
    ///
    /// # Examples
    ///
    /// ഒരു സ്ലൈസിനുള്ളിൽ നാല് ബൈറ്റുകൾ പകർത്തുന്നു:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // സുരക്ഷ: `ptr::copy`-നായുള്ള വ്യവസ്ഥകളെല്ലാം മുകളിൽ പരിശോധിച്ചു,
        // `ptr::add`-നുള്ളവ പോലെ.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// `self` ലെ എല്ലാ ഘടകങ്ങളും `other` ഉള്ളവ ഉപയോഗിച്ച് സ്വാപ്പ് ചെയ്യുന്നു.
    ///
    /// `other` ന്റെ ദൈർ‌ഘ്യം `self` ന് തുല്യമായിരിക്കണം.
    ///
    /// # Panics
    ///
    /// രണ്ട് സ്ലൈസുകൾക്ക് വ്യത്യസ്ത നീളമുണ്ടെങ്കിൽ ഈ ഫംഗ്ഷൻ panic ആയിരിക്കും.
    ///
    /// # Example
    ///
    /// സ്ലൈസുകളിലുടനീളം രണ്ട് ഘടകങ്ങൾ മാറ്റുന്നു:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// ഒരു പ്രത്യേക സ്കോപ്പിലെ ഒരു പ്രത്യേക ഡാറ്റയെക്കുറിച്ച് ഒരു മ്യൂട്ടബിൾ റഫറൻസ് മാത്രമേ ഉണ്ടാകൂ എന്ന് Rust നടപ്പിലാക്കുന്നു.
    ///
    /// ഇക്കാരണത്താൽ, ഒരൊറ്റ സ്ലൈസിൽ `swap_with_slice` ഉപയോഗിക്കാൻ ശ്രമിക്കുന്നത് ഒരു കംപൈൽ പരാജയത്തിന് കാരണമാകും:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// ഇത് പരിഹരിക്കുന്നതിന്, ഒരു സ്ലൈസിൽ നിന്ന് രണ്ട് വ്യത്യസ്ത മ്യൂട്ടബിൾ ഉപ-സ്ലൈസുകൾ സൃഷ്ടിക്കാൻ ഞങ്ങൾക്ക് [`split_at_mut`] ഉപയോഗിക്കാം:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // സുരക്ഷ: നിർവചനം അനുസരിച്ച് `self.len()` ഘടകങ്ങൾക്ക് `self` സാധുവാണ്, കൂടാതെ `src` ആയിരുന്നു
        // ഒരേ നീളം ഉണ്ടെന്ന് പരിശോധിച്ചു.
        // സ്ലൈസുകൾ ഓവർലാപ്പ് ചെയ്യാൻ കഴിയില്ല കാരണം മ്യൂട്ടബിൾ റഫറൻസുകൾ എക്സ്ക്ലൂസീവ് ആണ്.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// `align_to{,_mut}`-നായി മധ്യഭാഗത്തും പിന്നിലുമുള്ള സ്ലൈസിന്റെ ദൈർഘ്യം കണക്കാക്കാനുള്ള പ്രവർത്തനം.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // `rest`-നെക്കുറിച്ച് ഞങ്ങൾ എന്താണ് ചെയ്യാൻ പോകുന്നത്, ഏറ്റവും കുറഞ്ഞ എണ്ണം `T`-കളിൽ നമുക്ക് എത്രത്തോളം U`-കൾ ഉൾപ്പെടുത്താനാകുമെന്ന് കണ്ടെത്തുക എന്നതാണ്.
        //
        // അത്തരം ഓരോ "multiple"-നും നമുക്ക് എത്ര `ടി` ആവശ്യമാണ്.
        //
        // ഉദാഹരണത്തിന് T=u8 U=u16 പരിഗണിക്കുക.അപ്പോൾ നമുക്ക് 2 യുഎസിൽ 1 യു ഇടാം.ലളിതം.
        // ഇപ്പോൾ, ഉദാഹരണത്തിന് size_of: :<T>=16, size_of::<U>=24.</u>
        // `rest` സ്ലൈസിലെ ഓരോ 3 Ts-നും പകരം നമുക്ക് 2 Us സ്ഥാപിക്കാം.
        // കുറച്ചുകൂടി സങ്കീർണ്ണമാണ്.
        //
        // ഇത് കണക്കാക്കാനുള്ള ഫോർമുല ഇതാണ്:
        //
        // ഞങ്ങളെ= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // വിപുലീകരിച്ചതും ലളിതമാക്കിയതും:
        //
        // ഞങ്ങളെ=വലുപ്പം_: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // ഭാഗ്യവശാൽ ഇതെല്ലാം സ്ഥിരമായി വിലയിരുത്തപ്പെടുന്നതിനാൽ ... ഇവിടെ പ്രകടനം പ്രാധാന്യമർഹിക്കുന്നില്ല!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // ആവർത്തന സ്റ്റീനിന്റെ അൽ‌ഗോരിതം നമ്മൾ ഇപ്പോഴും ഈ `const fn` നിർമ്മിക്കണം (ഞങ്ങൾ അങ്ങനെ ചെയ്യുകയാണെങ്കിൽ ആവർത്തന അൽ‌ഗോരിതം പഴയപടിയാക്കണം) കാരണം llvm-നെ ആശ്രയിക്കുന്നത് ഇതെല്ലാം സമന്വയിപ്പിക്കുന്നതിനാണ്…നന്നായി, ഇത് എന്നെ അസ്വസ്ഥനാക്കുന്നു.
            //
            //

            // സുരക്ഷ: `a`, `b` എന്നിവ പൂജ്യമല്ലാത്ത മൂല്യങ്ങളാണെന്ന് പരിശോധിക്കുന്നു.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // 2 ന്റെ എല്ലാ ഘടകങ്ങളും b ൽ നിന്ന് നീക്കംചെയ്യുക
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // സുരക്ഷ: `b` പൂജ്യമല്ലാത്തതാണെന്ന് പരിശോധിച്ചു.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // ഈ അറിവ് ഉപയോഗിച്ച് സായുധരായ നമുക്ക് എത്ര യു'കൾ ഉൾക്കൊള്ളാൻ കഴിയുമെന്ന് കണ്ടെത്താനാകും!
        let us_len = self.len() / ts * us;
        // പിന്നിൽ സ്ലൈസിൽ എത്ര ടി ഉണ്ട്!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// സ്ലൈസ് മറ്റൊരു തരത്തിലുള്ള സ്ലൈസിലേക്ക് പരിവർത്തനം ചെയ്യുക, തരങ്ങളുടെ വിന്യാസം നിലനിർത്തുന്നുവെന്ന് ഉറപ്പാക്കുന്നു.
    ///
    /// ഈ രീതി സ്ലൈസിനെ മൂന്ന് വ്യത്യസ്ത കഷണങ്ങളായി വിഭജിക്കുന്നു: പ്രിഫിക്‌സ്, ശരിയായി വിന്യസിച്ച പുതിയ തരം മിഡിൽ സ്ലൈസ്, സഫിക്‌സ് സ്ലൈസ്.
    /// ഈ രീതി മധ്യ സ്ലൈസിനെ ഒരു തന്നിരിക്കുന്ന തരത്തിനും ഇൻപുട്ട് സ്ലൈസിനും സാധ്യമായ ഏറ്റവും വലിയ നീളമാക്കി മാറ്റാം, പക്ഷേ നിങ്ങളുടെ അൽഗോരിത്തിന്റെ പ്രകടനം മാത്രം അതിനെ ആശ്രയിച്ചിരിക്കും, അതിന്റെ കൃത്യതയല്ല.
    ///
    /// എല്ലാ ഇൻപുട്ട് ഡാറ്റയും പ്രിഫിക്‌സ് അല്ലെങ്കിൽ സഫിക്‌സ് സ്ലൈസായി മടക്കിനൽകുന്നത് അനുവദനീയമാണ്.
    ///
    /// ഇൻപുട്ട് എലമെന്റ് `T` അല്ലെങ്കിൽ output ട്ട്‌പുട്ട് എലമെന്റ് `U` പൂജ്യ വലുപ്പമുള്ളപ്പോൾ ഈ രീതിക്ക് ഒരു ലക്ഷ്യവുമില്ല, മാത്രമല്ല ഒന്നും വിഭജിക്കാതെ യഥാർത്ഥ സ്ലൈസ് തിരികെ നൽകും.
    ///
    /// # Safety
    ///
    /// മടങ്ങിയെത്തിയ മിഡിൽ സ്ലൈസിലെ ഘടകങ്ങളുമായി ബന്ധപ്പെട്ട് ഈ രീതി അടിസ്ഥാനപരമായി ഒരു എക്സ് 100 എക്സ് ആണ്, അതിനാൽ എക്സ് 01 എക്സുമായി ബന്ധപ്പെട്ട എല്ലാ സാധാരണ മുന്നറിയിപ്പുകളും ഇവിടെ ബാധകമാണ്.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // ഈ ഫംഗ്ഷന്റെ ഭൂരിഭാഗവും സ്ഥിരമായി വിലയിരുത്തപ്പെടുമെന്ന് ശ്രദ്ധിക്കുക,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // ZST-കൾ പ്രത്യേകമായി കൈകാര്യം ചെയ്യുക, അതായത്-അവയൊന്നും കൈകാര്യം ചെയ്യരുത്.
            return (self, &[], &[]);
        }

        // ആദ്യം, ഒന്നും രണ്ടും സ്ലൈസുകൾക്കിടയിൽ ഞങ്ങൾ ഏത് ഘട്ടത്തിലാണ് വിഭജിക്കുന്നതെന്ന് കണ്ടെത്തുക.
        // ptr.align_offset ഉപയോഗിച്ച് എളുപ്പമാണ്.
        let ptr = self.as_ptr();
        // സുരക്ഷ: വിശദമായ സുരക്ഷാ അഭിപ്രായത്തിനായി `align_to_mut` രീതി കാണുക.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // സുരക്ഷ: ഇപ്പോൾ `rest` തീർച്ചയായും വിന്യസിച്ചിരിക്കുന്നു, അതിനാൽ ചുവടെയുള്ള `from_raw_parts` കുഴപ്പമില്ല,
            // `T`-നെ `U`-ലേക്ക് സുരക്ഷിതമായി പരിവർത്തനം ചെയ്യാമെന്ന് കോളർ ഉറപ്പുനൽകുന്നതിനാൽ.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// സ്ലൈസ് മറ്റൊരു തരത്തിലുള്ള സ്ലൈസിലേക്ക് പരിവർത്തനം ചെയ്യുക, തരങ്ങളുടെ വിന്യാസം നിലനിർത്തുന്നുവെന്ന് ഉറപ്പാക്കുന്നു.
    ///
    /// ഈ രീതി സ്ലൈസിനെ മൂന്ന് വ്യത്യസ്ത കഷണങ്ങളായി വിഭജിക്കുന്നു: പ്രിഫിക്‌സ്, ശരിയായി വിന്യസിച്ച പുതിയ തരം മിഡിൽ സ്ലൈസ്, സഫിക്‌സ് സ്ലൈസ്.
    /// ഈ രീതി മധ്യ സ്ലൈസിനെ ഒരു തന്നിരിക്കുന്ന തരത്തിനും ഇൻപുട്ട് സ്ലൈസിനും സാധ്യമായ ഏറ്റവും വലിയ നീളമാക്കി മാറ്റാം, പക്ഷേ നിങ്ങളുടെ അൽഗോരിത്തിന്റെ പ്രകടനം മാത്രം അതിനെ ആശ്രയിച്ചിരിക്കും, അതിന്റെ കൃത്യതയല്ല.
    ///
    /// എല്ലാ ഇൻപുട്ട് ഡാറ്റയും പ്രിഫിക്‌സ് അല്ലെങ്കിൽ സഫിക്‌സ് സ്ലൈസായി മടക്കിനൽകുന്നത് അനുവദനീയമാണ്.
    ///
    /// ഇൻപുട്ട് എലമെന്റ് `T` അല്ലെങ്കിൽ output ട്ട്‌പുട്ട് എലമെന്റ് `U` പൂജ്യ വലുപ്പമുള്ളപ്പോൾ ഈ രീതിക്ക് ഒരു ലക്ഷ്യവുമില്ല, മാത്രമല്ല ഒന്നും വിഭജിക്കാതെ യഥാർത്ഥ സ്ലൈസ് തിരികെ നൽകും.
    ///
    /// # Safety
    ///
    /// മടങ്ങിയെത്തിയ മിഡിൽ സ്ലൈസിലെ ഘടകങ്ങളുമായി ബന്ധപ്പെട്ട് ഈ രീതി അടിസ്ഥാനപരമായി ഒരു എക്സ് 100 എക്സ് ആണ്, അതിനാൽ എക്സ് 01 എക്സുമായി ബന്ധപ്പെട്ട എല്ലാ സാധാരണ മുന്നറിയിപ്പുകളും ഇവിടെ ബാധകമാണ്.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // ഈ ഫംഗ്ഷന്റെ ഭൂരിഭാഗവും സ്ഥിരമായി വിലയിരുത്തപ്പെടുമെന്ന് ശ്രദ്ധിക്കുക,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // ZST-കൾ പ്രത്യേകമായി കൈകാര്യം ചെയ്യുക, അതായത്-അവയൊന്നും കൈകാര്യം ചെയ്യരുത്.
            return (self, &mut [], &mut []);
        }

        // ആദ്യം, ഒന്നും രണ്ടും സ്ലൈസുകൾക്കിടയിൽ ഞങ്ങൾ ഏത് ഘട്ടത്തിലാണ് വിഭജിക്കുന്നതെന്ന് കണ്ടെത്തുക.
        // ptr.align_offset ഉപയോഗിച്ച് എളുപ്പമാണ്.
        let ptr = self.as_ptr();
        // സുരക്ഷ: യു എന്നതിനായി വിന്യസിച്ച പോയിന്ററുകൾ ഉപയോഗിക്കുമെന്ന് ഇവിടെ ഞങ്ങൾ ഉറപ്പാക്കുന്നു
        // ബാക്കി രീതി.യു ലക്ഷ്യമാക്കി ഒരു വിന്യാസം ഉപയോഗിച്ച്&[T] ലേക്ക് ഒരു പോയിന്റർ കൈമാറിയാണ് ഇത് ചെയ്യുന്നത്.
        // `crate::ptr::align_offset` ശരിയായി വിന്യസിച്ചതും സാധുതയുള്ളതുമായ പോയിന്റർ `ptr` (ഇത് `self`-ലേക്കുള്ള ഒരു റഫറൻസിൽ നിന്നാണ് വരുന്നത്), ഒപ്പം രണ്ട് ശക്തിയുള്ള വലുപ്പം (U-നായുള്ള അലൈൻമെന്റിൽ നിന്ന് വരുന്നതിനാൽ), അതിന്റെ സുരക്ഷാ പരിമിതികൾ തൃപ്തിപ്പെടുത്തുന്നു.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // ഇതിന് ശേഷം ഞങ്ങൾക്ക് `rest` വീണ്ടും ഉപയോഗിക്കാൻ കഴിയില്ല, അത് അതിന്റെ അപരനാമമായ `mut_ptr` അസാധുവാക്കും!സുരക്ഷ: `align_to`-നായുള്ള അഭിപ്രായങ്ങൾ കാണുക.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// ഈ സ്ലൈസിന്റെ ഘടകങ്ങൾ അടുക്കിയിട്ടുണ്ടോയെന്ന് പരിശോധിക്കുന്നു.
    ///
    /// അതായത്, ഓരോ ഘടകത്തിനും `a` നും അതിന്റെ ഇനിപ്പറയുന്ന ഘടകമായ `b` നും, `a <= b` കൈവശം വയ്ക്കണം.സ്ലൈസ് കൃത്യമായി പൂജ്യമോ ഒരു ഘടകമോ നൽകുന്നുവെങ്കിൽ, `true` തിരികെ നൽകും.
    ///
    /// `Self::Item` എന്നത് `PartialOrd` മാത്രമാണെങ്കിലും `Ord` അല്ലെങ്കിൽ, മുകളിലുള്ള നിർവചനം സൂചിപ്പിക്കുന്നത് തുടർച്ചയായ രണ്ട് ഇനങ്ങളും താരതമ്യപ്പെടുത്താൻ കഴിയുന്നില്ലെങ്കിൽ ഈ ഫംഗ്ഷൻ `false` നൽകുന്നു എന്നാണ്.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// തന്നിരിക്കുന്ന താരതമ്യ പ്രവർത്തനം ഉപയോഗിച്ച് ഈ സ്ലൈസിന്റെ ഘടകങ്ങൾ അടുക്കിയിട്ടുണ്ടോയെന്ന് പരിശോധിക്കുന്നു.
    ///
    /// `PartialOrd::partial_cmp` ഉപയോഗിക്കുന്നതിനുപകരം, രണ്ട് ഘടകങ്ങളുടെ ക്രമം നിർണ്ണയിക്കാൻ ഈ ഫംഗ്ഷൻ തന്നിരിക്കുന്ന `compare` ഫംഗ്ഷൻ ഉപയോഗിക്കുന്നു.
    /// അതിനുപുറമെ, ഇത് [`is_sorted`] ന് തുല്യമാണ്;കൂടുതൽ വിവരങ്ങൾക്ക് അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// തന്നിരിക്കുന്ന കീ എക്സ്ട്രാക്ഷൻ ഫംഗ്ഷൻ ഉപയോഗിച്ച് ഈ സ്ലൈസിന്റെ ഘടകങ്ങൾ അടുക്കിയിട്ടുണ്ടോയെന്ന് പരിശോധിക്കുന്നു.
    ///
    /// സ്ലൈസിന്റെ ഘടകങ്ങളെ നേരിട്ട് താരതമ്യം ചെയ്യുന്നതിനുപകരം, ഈ പ്രവർത്തനം മൂലകങ്ങളുടെ കീകളെ താരതമ്യം ചെയ്യുന്നു, `f` നിർണ്ണയിക്കുന്നു.
    /// അതിനുപുറമെ, ഇത് [`is_sorted`] ന് തുല്യമാണ്;കൂടുതൽ വിവരങ്ങൾക്ക് അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// തന്നിരിക്കുന്ന പ്രവചനം അനുസരിച്ച് പാർട്ടീഷൻ പോയിന്റിന്റെ സൂചിക നൽകുന്നു (രണ്ടാമത്തെ പാർട്ടീഷന്റെ ആദ്യ ഘടകത്തിന്റെ സൂചിക).
    ///
    /// തന്നിരിക്കുന്ന പ്രവചനമനുസരിച്ച് സ്ലൈസ് വിഭജിക്കപ്പെടുമെന്ന് കണക്കാക്കപ്പെടുന്നു.
    /// ഇതിനർത്ഥം, പ്രവചനം ശരിയായി വരുന്ന എല്ലാ ഘടകങ്ങളും സ്ലൈസിന്റെ തുടക്കത്തിലാണെന്നും പ്രവചനാ തെറ്റായ വരുമാനം നൽകുന്ന എല്ലാ ഘടകങ്ങളും അവസാനം ആണെന്നും.
    ///
    /// ഉദാഹരണത്തിന്, [7, 15, 3, 5, 4, 12, 6] എന്നത് പ്രവചിച്ച x% 2!=0 ന് കീഴിലുള്ള ഒരു വിഭജനമാണ് (എല്ലാ വിചിത്ര സംഖ്യകളും ആരംഭത്തിലാണ്, എല്ലാം അവസാനം പോലും).
    ///
    /// ഈ സ്ലൈസ് പാർട്ടീഷൻ ചെയ്തിട്ടില്ലെങ്കിൽ, ലഭിച്ച ഫലം വ്യക്തമല്ലാത്തതും അർത്ഥരഹിതവുമാണ്, കാരണം ഈ രീതി ഒരുതരം ബൈനറി തിരയൽ നടത്തുന്നു.
    ///
    /// [`binary_search`], [`binary_search_by`], [`binary_search_by_key`] എന്നിവയും കാണുക.
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // സുരക്ഷ: `left < right` ആയിരിക്കുമ്പോൾ, `left <= mid < right`.
            // അതിനാൽ `left` എല്ലായ്പ്പോഴും വർദ്ധിക്കുകയും `right` എല്ലായ്പ്പോഴും കുറയുകയും ചെയ്യുന്നു, അവയിലേതെങ്കിലും തിരഞ്ഞെടുക്കപ്പെടുന്നു.രണ്ട് സാഹചര്യങ്ങളിലും `left <= right` സംതൃപ്തമാണ്.അതിനാൽ ഒരു ഘട്ടത്തിൽ `left < right` ആണെങ്കിൽ, അടുത്ത ഘട്ടത്തിൽ `left <= right` സംതൃപ്തനാണ്.
            //
            // അതിനാൽ `left != right` ഉള്ളിടത്തോളം, `0 <= left < right <= len` സംതൃപ്തമാണ്, ഈ കേസ് `0 <= mid < len` ഉം തൃപ്തികരമാണെങ്കിൽ.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: ഒരേ നീളത്തിൽ‌ഞങ്ങൾ‌അവ വ്യക്തമായി മുറിക്കേണ്ടതുണ്ട്
        // അതിർത്തി പരിശോധന ഒഴിവാക്കുന്നത് ഒപ്റ്റിമൈസറിന് എളുപ്പമാക്കുന്നതിന്.
        // എന്നാൽ ഇതിനെ ആശ്രയിക്കാൻ കഴിയാത്തതിനാൽ ടി: കോപ്പിക്കായി ഞങ്ങൾക്ക് വ്യക്തമായ ഒരു സ്പെഷ്യലൈസേഷനുമുണ്ട്.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// ഒരു ശൂന്യമായ സ്ലൈസ് സൃഷ്ടിക്കുന്നു.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// മാറ്റാവുന്ന ശൂന്യമായ സ്ലൈസ് സൃഷ്‌ടിക്കുന്നു.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// സ്ലൈസുകളിലെ പാറ്റേണുകൾ, നിലവിൽ, `strip_prefix`, `strip_suffix` എന്നിവ മാത്രം ഉപയോഗിക്കുന്നു.
/// ഒരു future പോയിന്റിൽ, `core::str::Pattern` (എഴുതുമ്പോൾ `str` ആയി പരിമിതപ്പെടുത്തിയിരിക്കുന്നു) കഷണങ്ങളായി സാമാന്യവൽക്കരിക്കുമെന്ന് ഞങ്ങൾ പ്രതീക്ഷിക്കുന്നു, തുടർന്ന് ഈ trait മാറ്റിസ്ഥാപിക്കുകയോ ഇല്ലാതാക്കുകയോ ചെയ്യും.
///
pub trait SlicePattern {
    /// സ്ലൈസിന്റെ ഘടക തരം പൊരുത്തപ്പെടുന്നു.
    type Item;

    /// നിലവിൽ, എക്സ് 00 എക്സ് ഉപഭോക്താക്കൾക്ക് ഒരു സ്ലൈസ് ആവശ്യമാണ്.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}