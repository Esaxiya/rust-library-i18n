// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// `[mid-left, mid+right)` ശ്രേണി തിരിക്കുന്നു, അതായത് `mid` ലെ മൂലകം ആദ്യത്തെ ഘടകമായി മാറുന്നു.തുല്യമായി, ശ്രേണി `left` ഘടകങ്ങൾ ഇടത്തേക്ക് അല്ലെങ്കിൽ `right` ഘടകങ്ങൾ വലത്തേക്ക് തിരിക്കുന്നു.
///
/// # Safety
///
/// നിർദ്ദിഷ്ട ശ്രേണി വായിക്കുന്നതിനും എഴുതുന്നതിനും സാധുതയുള്ളതായിരിക്കണം.
///
/// # Algorithm
///
/// `left + right` ന്റെ ചെറിയ മൂല്യങ്ങൾ‌ക്കോ വലിയ `T` നോ അൽ‌ഗോരിതം 1 ഉപയോഗിക്കുന്നു.
/// `mid - left`-ൽ ആരംഭിച്ച് `right` സ്റ്റെപ്പുകൾ മൊഡ്യൂളോ `left + right` ഉപയോഗിച്ച് മുന്നേറുന്ന ഘടകങ്ങളെ അവയുടെ അവസാന സ്ഥാനങ്ങളിലേക്ക് മാറ്റുന്നു, അതായത് ഒരു താൽക്കാലികം മാത്രം.
/// ക്രമേണ, ഞങ്ങൾ `mid - left`-ൽ തിരിച്ചെത്തും.
/// എന്നിരുന്നാലും, `gcd(left + right, right)` 1 അല്ലെങ്കിൽ, മുകളിലുള്ള ഘട്ടങ്ങൾ ഘടകങ്ങളെ മറികടക്കുന്നു.
/// ഉദാഹരണത്തിന്:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// ഭാഗ്യവശാൽ, അന്തിമ ഘടകങ്ങൾക്കിടയിൽ ഒഴിവാക്കിയ ഘടകങ്ങളുടെ എണ്ണം എല്ലായ്പ്പോഴും തുല്യമാണ്, അതിനാൽ നമുക്ക് ഞങ്ങളുടെ ആരംഭ സ്ഥാനം ഓഫ്സെറ്റ് ചെയ്യാനും കൂടുതൽ റ s ണ്ടുകൾ ചെയ്യാനും കഴിയും (ആകെ റ s ണ്ടുകളുടെ എണ്ണം `gcd(left + right, right)` value) ആണ്.
///
/// അന്തിമഫലം, എല്ലാ ഘടകങ്ങളും ഒരുതവണ മാത്രമേ തീരുമാനിച്ചിട്ടുള്ളൂ.
///
/// `left + right` വലുതാണെങ്കിലും `min(left, right)` ഒരു സ്റ്റാക്ക് ബഫറിലേക്ക് യോജിക്കുന്നത്ര ചെറുതാണെങ്കിൽ അൽഗോരിതം 2 ഉപയോഗിക്കുന്നു.
/// `min(left, right)` ഘടകങ്ങൾ ബഫറിലേക്ക് പകർത്തുന്നു, `memmove` മറ്റുള്ളവയിലേക്ക് പ്രയോഗിക്കുന്നു, കൂടാതെ ബഫറിലുള്ളവ അവ ഉത്ഭവിച്ച സ്ഥലത്തിന്റെ എതിർവശത്തുള്ള ദ്വാരത്തിലേക്ക് തിരികെ നീക്കുന്നു.
///
/// `left + right` ആവശ്യത്തിന് വലുതായിക്കഴിഞ്ഞാൽ വെക്റ്ററൈസ് ചെയ്യാൻ കഴിയുന്ന അൽഗോരിതങ്ങൾ മുകളിൽ പറഞ്ഞവയെ മറികടക്കുന്നു.
/// ഒരേസമയം നിരവധി റൗണ്ടുകൾ നടത്തിക്കൊണ്ട് അൽഗോരിതം 1 വെക്റ്ററൈസ് ചെയ്യാൻ കഴിയും, എന്നാൽ `left + right` വളരെ വലുതായിത്തീരുന്നതുവരെ ശരാശരി വളരെ കുറച്ച് റ s ണ്ടുകൾ മാത്രമേയുള്ളൂ, ഒരൊറ്റ റൗണ്ടിന്റെ ഏറ്റവും മോശം അവസ്ഥ എല്ലായ്പ്പോഴും അവിടെയുണ്ട്.
/// പകരം, അൽ‌ഗോരിതം 3 ഒരു ചെറിയ റൊട്ടേറ്റ് പ്രശ്‌നം അവശേഷിക്കുന്നതുവരെ `min(left, right)` ഘടകങ്ങൾ‌ആവർത്തിച്ച് കൈമാറ്റം ചെയ്യുന്നു.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// `left < right` ചെയ്യുമ്പോൾ ഇടത് വശത്ത് നിന്ന് സ്വാപ്പിംഗ് സംഭവിക്കുന്നു.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. ഈ കേസുകൾ‌പരിശോധിച്ചില്ലെങ്കിൽ‌ചുവടെയുള്ള അൽ‌ഗോരിതം പരാജയപ്പെടാം
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // അൽ‌ഗോരിതം 1 മൈക്രോബെഞ്ച്മാർക്കുകൾ സൂചിപ്പിക്കുന്നത് റാൻഡം ഷിഫ്റ്റുകളുടെ ശരാശരി പ്രകടനം ഏകദേശം `left + right == 32` വരെ മികച്ചതാണെന്നാണ്, എന്നാൽ ഏറ്റവും മോശം പ്രകടനം 16 ന് പോലും തകരുന്നു.
            // 24 മിഡിൽ ഗ്രൗണ്ടായി തിരഞ്ഞെടുത്തു.
            // `T` ന്റെ വലുപ്പം 4 `usize` നേക്കാൾ വലുതാണെങ്കിൽ, ഈ അൽ‌ഗോരിതം മറ്റ് അൽ‌ഗോരിതംസിനെ മറികടക്കുന്നു.
            //
            //
            let x = unsafe { mid.sub(left) };
            // ആദ്യ റൗണ്ടിന്റെ ആരംഭം
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` എക്സ് 00 എക്സ് കണക്കാക്കിക്കൊണ്ട് കൈയ്യിൽ കണ്ടെത്താനാകും, പക്ഷേ ഒരു ലൂപ്പ് ചെയ്യുന്നത് വേഗതയേറിയതാണ്, അത് ജിസിഡിയെ ഒരു പാർശ്വഫലമായി കണക്കാക്കുന്നു, തുടർന്ന് ബാക്കി ചങ്ക് ചെയ്യുന്നു
            //
            //
            let mut gcd = right;
            // ഒരു താൽ‌ക്കാലികം ഒരിക്കൽ വായിക്കുന്നതിനും പിന്നിലേക്ക്‌പകർ‌ത്തുന്നതിനും പകരം താൽ‌ക്കാലികം എഴുതുന്നതിനും പകരം താൽ‌ക്കാലികങ്ങൾ‌സ്വൈപ്പുചെയ്യുന്നത് വേഗത്തിലാണെന്ന് ബെഞ്ച്മാർക്കുകൾ‌വെളിപ്പെടുത്തുന്നു.
            // രണ്ടെണ്ണം മാനേജുചെയ്യേണ്ടതിനുപകരം താൽക്കാലികങ്ങൾ മാറ്റുകയോ മാറ്റിസ്ഥാപിക്കുകയോ ചെയ്യുന്നത് ലൂപ്പിൽ ഒരു മെമ്മറി വിലാസം മാത്രമേ ഉപയോഗിക്കുന്നുള്ളൂ എന്നതിനാലാകാം ഇത്.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // `i` വർദ്ധിപ്പിച്ച് അത് അതിരുകൾക്ക് പുറത്താണോ എന്ന് പരിശോധിക്കുന്നതിനുപകരം, അടുത്ത ഇൻക്രിമെന്റിൽ `i` അതിർത്തിക്ക് പുറത്താണോ എന്ന് ഞങ്ങൾ പരിശോധിക്കുന്നു.
                // ഇത് പോയിന്ററുകൾ അല്ലെങ്കിൽ എക്സ് 100 എക്സ് പൊതിയുന്നത് തടയുന്നു.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // ആദ്യ റൗണ്ടിന്റെ അവസാനം
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // `left + right >= 15` ആണെങ്കിൽ ഈ നിബന്ധന ഇവിടെ ഉണ്ടായിരിക്കണം
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // കൂടുതൽ റൗണ്ടുകൾ ഉപയോഗിച്ച് ചങ്ക് പൂർത്തിയാക്കുക
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` പൂജ്യ വലുപ്പത്തിലുള്ള തരമല്ല, അതിനാൽ അതിന്റെ വലുപ്പമനുസരിച്ച് വിഭജിക്കുന്നത് ശരിയാണ്.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // അൽ‌ഗോരിതം 2 ടി യ്ക്ക് ഇത് ഉചിതമായി വിന്യസിച്ചിട്ടുണ്ടെന്ന് ഉറപ്പുവരുത്തുന്നതിനാണ് ഇവിടത്തെ എക്സ് 00 എക്സ്
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // അൽ‌ഗോരിതം 3 ഈ അൽ‌ഗോരിത്തിന്റെ അവസാന സ്വാപ്പ് എവിടെയാണെന്ന് കണ്ടെത്തുന്നതും ഈ അൽ‌ഗോരിതം പോലുള്ള അടുത്തുള്ള കഷണങ്ങൾ‌മാറ്റുന്നതിനുപകരം അവസാനത്തെ ചങ്ക് ഉപയോഗിച്ച് സ്വാപ്പ് ചെയ്യുന്നതും ഉൾ‌ക്കൊള്ളുന്ന ഒരു ഇതര മാർ‌ഗ്ഗം ഉണ്ട്, പക്ഷേ ഈ വഴി ഇപ്പോഴും വേഗതയേറിയതാണ്.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // അൽഗോരിതം 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}