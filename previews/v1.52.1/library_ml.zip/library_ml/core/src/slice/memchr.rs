// rust-memchr-ൽ നിന്ന് എടുത്ത യഥാർത്ഥ നടപ്പാക്കൽ.
// പകർപ്പവകാശം 2015 ആൻഡ്രൂ ഗാലന്റ്, ബ്ലസ്, നിക്കോളാസ് കോച്ച്

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// വെട്ടിച്ചുരുക്കൽ ഉപയോഗിക്കുക.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// `x` ൽ ഏതെങ്കിലും പൂജ്യം ബൈറ്റ് ഉണ്ടെങ്കിൽ `true` നൽകുന്നു.
///
/// *മാറ്റേഴ്സ് കംപ്യൂട്ടേഷണൽ*, ജെ.
///
/// "ഓരോ ബൈറ്റുകളിൽ നിന്നും ഒരെണ്ണം കുറയ്ക്കുക, തുടർന്ന് കടം ഏറ്റവും പ്രധാനപ്പെട്ട രീതിയിൽ പ്രചരിപ്പിക്കുന്ന ബൈറ്റുകൾക്കായി തിരയുക എന്നതാണ് ആശയം.
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// `text`-ലെ ബൈറ്റ് `x`-മായി പൊരുത്തപ്പെടുന്ന ആദ്യ സൂചിക നൽകുന്നു.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // ചെറിയ കഷ്ണങ്ങൾക്കുള്ള അതിവേഗ പാത
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // ഒരു സമയം രണ്ട് `usize` വാക്കുകൾ വായിച്ച് ഒരൊറ്റ ബൈറ്റ് മൂല്യത്തിനായി സ്കാൻ ചെയ്യുക.
    //
    // `text` മൂന്ന് ഭാഗങ്ങളായി വിഭജിക്കുക
    // - ക്രമീകരിക്കാത്ത പ്രാരംഭ ഭാഗം, വാചകത്തിലെ ആദ്യ വാക്ക് വിന്യസിക്കുന്നതിന് മുമ്പ്
    // - ബോഡി, ഒരു സമയം 2 വാക്കുകൾ ഉപയോഗിച്ച് സ്കാൻ ചെയ്യുക
    // - ശേഷിക്കുന്ന അവസാന ഭാഗം, <2 പദ വലുപ്പം

    // വിന്യസിച്ച അതിർത്തി വരെ തിരയുക
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // വാചകത്തിന്റെ ബോഡി തിരയുക
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // സുരക്ഷ: സമയത്തിന്റെ പ്രവചനം കുറഞ്ഞത് 2 * usize_bytes ദൂരം ഉറപ്പുനൽകുന്നു
        // ഓഫ്‌സെറ്റിനും സ്ലൈസിന്റെ അവസാനത്തിനും ഇടയിൽ.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // പൊരുത്തപ്പെടുന്ന ബൈറ്റ് ഉണ്ടെങ്കിൽ ബ്രേക്ക് ചെയ്യുക
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // ബോഡി ലൂപ്പ് നിർത്തിയതിന് ശേഷം ബൈറ്റ് കണ്ടെത്തുക.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// `text`-ലെ ബൈറ്റ് `x`-മായി പൊരുത്തപ്പെടുന്ന അവസാന സൂചിക നൽകുന്നു.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // ഒരു സമയം രണ്ട് `usize` വാക്കുകൾ വായിച്ച് ഒരൊറ്റ ബൈറ്റ് മൂല്യത്തിനായി സ്കാൻ ചെയ്യുക.
    //
    // `text` മൂന്ന് ഭാഗങ്ങളായി വിഭജിക്കുക:
    // - ക്രമീകരിക്കാത്ത വാൽ, വാചകത്തിലെ അവസാന വാക്ക് വിന്യസിച്ചതിന് ശേഷം,
    // - ബോഡി, ഒരു സമയം 2 വാക്കുകൾ ഉപയോഗിച്ച് സ്കാൻ ചെയ്യുന്നു,
    // - ശേഷിക്കുന്ന ആദ്യത്തെ ബൈറ്റുകൾ, <2 പദ വലുപ്പം.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // പ്രിഫിക്സിന്റെയും സഫിക്സിന്റെയും ദൈർഘ്യം നേടുന്നതിനാണ് ഞങ്ങൾ ഇതിനെ വിളിക്കുന്നത്.
        // മധ്യത്തിൽ ഞങ്ങൾ എല്ലായ്പ്പോഴും ഒരേസമയം രണ്ട് കഷണങ്ങൾ പ്രോസസ്സ് ചെയ്യുന്നു.
        // സുരക്ഷ: `align_to` കൈകാര്യം ചെയ്യുന്ന വലുപ്പ വ്യത്യാസങ്ങൾ ഒഴികെ `[u8]`-ലേക്ക് `[usize]`-ലേക്ക് പരിവർത്തനം ചെയ്യുന്നത് സുരക്ഷിതമാണ്.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // ടെക്സ്റ്റിന്റെ ബോഡി തിരയുക, ഞങ്ങൾ min_aligned_offset കടക്കുന്നില്ലെന്ന് ഉറപ്പാക്കുക.
    // ഓഫ്‌സെറ്റ് എല്ലായ്പ്പോഴും വിന്യസിക്കപ്പെടുന്നു, അതിനാൽ `>` പരിശോധിക്കുന്നത് മാത്രം മതി, സാധ്യമായ ഓവർഫ്ലോ ഒഴിവാക്കുന്നു.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // സുരക്ഷ: ഓഫ്‌സെറ്റ് ലെൻ, എക്സ് 100 എക്‌സിൽ ആരംഭിക്കുന്നു, അതിനെക്കാൾ വലുതായിരിക്കുന്നിടത്തോളം
        // min_aligned_offset (prefix.len()) ശേഷിക്കുന്ന ദൂരം കുറഞ്ഞത് 2 * ചങ്ക്_ബൈറ്റുകളാണ്.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // പൊരുത്തപ്പെടുന്ന ബൈറ്റ് ഉണ്ടെങ്കിൽ ബ്രേക്ക് ചെയ്യുക.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // ബോഡി ലൂപ്പ് നിർത്തുന്നതിന് മുമ്പ് ബൈറ്റ് കണ്ടെത്തുക.
    text[..offset].iter().rposition(|elt| *elt == x)
}