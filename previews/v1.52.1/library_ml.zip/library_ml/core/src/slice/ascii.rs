//! ASCII `[u8]`-ലെ പ്രവർത്തനങ്ങൾ.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// ഈ സ്ലൈസിലെ എല്ലാ ബൈറ്റുകളും ASCII പരിധിക്കുള്ളിലാണോയെന്ന് പരിശോധിക്കുന്നു.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// രണ്ട് കഷ്ണങ്ങൾ ഒരു ASCII കേസ്-സെൻസിറ്റീവ് പൊരുത്തമാണെന്ന് പരിശോധിക്കുന്നു.
    ///
    /// `to_ascii_lowercase(a) == to_ascii_lowercase(b)` പോലെ തന്നെ, പക്ഷേ താൽക്കാലികങ്ങൾ അനുവദിക്കാതെ പകർത്താതെ.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// ഈ സ്ലൈസ് അതിന്റെ ASCII അപ്പർ‌കേസ് തുല്യമായ സ്ഥലത്തേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// ASCII അക്ഷരങ്ങൾ 'a' മുതൽ 'z' വരെ 'A' മുതൽ 'Z' വരെ മാപ്പുചെയ്‌തു, പക്ഷേ ASCII ഇതര അക്ഷരങ്ങൾക്ക് മാറ്റമില്ല.
    ///
    /// നിലവിലുള്ള ഒരെണ്ണം പരിഷ്‌ക്കരിക്കാതെ ഒരു വലിയ വലിയ മൂല്യം നൽകാൻ, [`to_ascii_uppercase`] ഉപയോഗിക്കുക.
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// ഈ സ്ലൈസ് അതിന്റെ ASCII ലോവർ കേസ് തുല്യമായ സ്ഥലത്തേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// ASCII അക്ഷരങ്ങൾ 'A' മുതൽ 'Z' വരെ 'a' മുതൽ 'z' വരെ മാപ്പുചെയ്‌തു, പക്ഷേ ASCII ഇതര അക്ഷരങ്ങൾക്ക് മാറ്റമില്ല.
    ///
    /// നിലവിലുള്ള ഒരെണ്ണം പരിഷ്‌ക്കരിക്കാതെ ഒരു ചെറിയ ചെറിയ മൂല്യം നൽകുന്നതിന്, [`to_ascii_lowercase`] ഉപയോഗിക്കുക.
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// `v` എന്ന പദത്തിലെ ഏതെങ്കിലും ബൈറ്റ് nonascii ആണെങ്കിൽ `true` നൽകുന്നു (>=128).
/// `../str/mod.rs`-ൽ നിന്നുള്ള സ്‌നാർഫെഡ്, ഇത് utf8 മൂല്യനിർണ്ണയത്തിന് സമാനമായ എന്തെങ്കിലും ചെയ്യുന്നു.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// ഒപ്റ്റിമൈസ് ചെയ്ത ASCII ടെസ്റ്റ്, അത് ബൈറ്റ്-അറ്റ്-എ-ടൈം ഓപ്പറേഷനുകൾക്ക് പകരം (സാധ്യമാകുമ്പോൾ) ഉപയോഗപ്പെടുത്താം.
///
/// ഞങ്ങൾ ഇവിടെ ഉപയോഗിക്കുന്ന അൽഗോരിതം വളരെ ലളിതമാണ്.`s` വളരെ ചെറുതാണെങ്കിൽ, ഞങ്ങൾ ഓരോ ബൈറ്റും പരിശോധിച്ച് അത് പൂർത്തിയാക്കും.അല്ലെങ്കിൽ:
///
/// - ക്രമീകരിക്കാത്ത ലോഡ് ഉപയോഗിച്ച് ആദ്യ പദം വായിക്കുക.
/// - പോയിന്റർ വിന്യസിക്കുക, വിന്യസിച്ച ലോഡുകൾ ഉപയോഗിച്ച് അവസാനം വരെ തുടർന്നുള്ള വാക്കുകൾ വായിക്കുക.
/// - ക്രമീകരിക്കാത്ത ലോഡ് ഉപയോഗിച്ച് `s`-ൽ നിന്നുള്ള അവസാന `usize` വായിക്കുക.
///
/// ഈ ലോഡുകളിലേതെങ്കിലും `contains_nonascii` (above) ശരിയായി വരുന്ന എന്തെങ്കിലും ഉൽ‌പാദിപ്പിക്കുന്നുവെങ്കിൽ‌, ഉത്തരം തെറ്റാണെന്ന് ഞങ്ങൾ‌ക്കറിയാം.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // വേഡ്-അറ്റ്-എ-ടൈം ഇംപ്ലിമെൻറേഷനിൽ നിന്ന് ഞങ്ങൾക്ക് ഒന്നും നേടാനായില്ലെങ്കിൽ, ഒരു സ്കെയിലർ ലൂപ്പിലേക്ക് മടങ്ങുക.
    //
    // `usize`-ന് `size_of::<usize>()` മതിയായ വിന്യാസം ഇല്ലാത്ത ആർക്കിടെക്ചറുകൾക്കും ഞങ്ങൾ ഇത് ചെയ്യുന്നു, കാരണം ഇത് വിചിത്രമായ edge കേസാണ്.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // ക്രമീകരിക്കാത്ത ആദ്യത്തെ പദം ഞങ്ങൾ എല്ലായ്പ്പോഴും വായിക്കുന്നു, അതായത് `align_offset` എന്നാണ്
    // 0, വിന്യസിച്ച വായനയ്‌ക്കായി ഞങ്ങൾ അതേ മൂല്യം വീണ്ടും വായിക്കും.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // സുരക്ഷ: മുകളിലുള്ള `len < USIZE_SIZE` ഞങ്ങൾ പരിശോധിക്കുന്നു.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // ഞങ്ങൾ‌ഇത്‌മുകളിൽ‌പരിശോധിച്ചു.
    // `offset_to_aligned` എന്നത് `align_offset` അല്ലെങ്കിൽ `USIZE_SIZE` ആണെന്ന് ശ്രദ്ധിക്കുക, രണ്ടും മുകളിൽ വ്യക്തമായി പരിശോധിക്കുന്നു.
    //
    debug_assert!(offset_to_aligned <= len);

    // സുരക്ഷ: word_ptr എന്നത് വായിക്കാൻ ഞങ്ങൾ ഉപയോഗിക്കുന്ന (ശരിയായി വിന്യസിച്ച) ഉപയോഗ ptr ആണ്
    // സ്ലൈസിന്റെ മധ്യഭാഗം.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` `word_ptr`-ന്റെ ബൈറ്റ് സൂചികയാണ് ലൂപ്പ് എൻഡ് ചെക്കുകൾക്കായി ഉപയോഗിക്കുന്നത്.
    let mut byte_pos = offset_to_aligned;

    // ക്രമീകരിക്കാത്ത ലോഡുകളുടെ ഒരു കൂട്ടം ഞങ്ങൾ ചെയ്യാൻ പോകുന്നതിനാൽ, വിന്യാസത്തെക്കുറിച്ച് പാരനോയ പരിശോധിക്കുക.
    // പ്രായോഗികമായി ഇത് `align_offset`-ൽ ഒരു ബഗ് ഒഴിവാക്കുന്നത് അസാധ്യമാണ്.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // അവസാനമായി വിന്യസിച്ച വാക്ക് വരെ തുടർന്നുള്ള വാക്കുകൾ വായിക്കുക, അവസാനമായി വിന്യസിച്ച വാക്ക് പിന്നീട് ടെയിൽ പരിശോധനയിൽ ചെയ്യണം, വാൽ എല്ലായ്പ്പോഴും ഒരു `usize` ആണെന്ന് ഉറപ്പുവരുത്താൻ branch `byte_pos == len` വരെ അധികമാണ്.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // വായന പരിധിയിലാണോയെന്ന് സാനിറ്റി പരിശോധന
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // `byte_pos` നെക്കുറിച്ചുള്ള ഞങ്ങളുടെ അനുമാനങ്ങൾ നിലനിൽക്കുന്നുവെന്നും.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // സുരക്ഷ: `word_ptr` ശരിയായി വിന്യസിച്ചിട്ടുണ്ടെന്ന് ഞങ്ങൾക്കറിയാം (കാരണം
        // `align_offset`), കൂടാതെ `word_ptr` നും അവസാനത്തിനും ഇടയിൽ മതിയായ ബൈറ്റുകൾ ഉണ്ടെന്ന് ഞങ്ങൾക്കറിയാം
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // സുരക്ഷ: `byte_pos <= len - USIZE_SIZE` എന്ന് ഞങ്ങൾക്കറിയാം, അതിനർത്ഥം
        // ഈ `add` ന് ശേഷം, `word_ptr` പരമാവധി അവസാനഭാഗത്തായിരിക്കും.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // ഒരു `usize` മാത്രമേ ശേഷിക്കുന്നുള്ളൂവെന്ന് ഉറപ്പുവരുത്തുന്നതിനുള്ള ശുചിത്വ പരിശോധന.
    // ഞങ്ങളുടെ ലൂപ്പ് അവസ്ഥ ഇത് ഉറപ്പാക്കണം.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // സുരക്ഷ: ഇത് തുടക്കത്തിൽ തന്നെ ഞങ്ങൾ പരിശോധിക്കുന്ന `len >= USIZE_SIZE`-നെ ആശ്രയിച്ചിരിക്കുന്നു.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}