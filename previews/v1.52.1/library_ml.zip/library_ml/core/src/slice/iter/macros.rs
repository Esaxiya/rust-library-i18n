//! സ്ലൈസിന്റെ ആവർത്തനക്കാർ ഉപയോഗിക്കുന്ന മാക്രോകൾ.

// Is_empty, len എന്നിവ ഇൻ‌ലൈൻ ചെയ്യുന്നത് ഒരു വലിയ പ്രകടന വ്യത്യാസമുണ്ടാക്കുന്നു
macro_rules! is_empty {
    // ഒരു ZST ആവർത്തനത്തിന്റെ ദൈർഘ്യം ഞങ്ങൾ എൻ‌കോഡുചെയ്യുന്ന രീതി, ഇത് ZST നും ZST ഇതരത്തിനും വേണ്ടി പ്രവർത്തിക്കുന്നു.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// ചില അതിർത്തി പരിശോധനകളിൽ നിന്ന് രക്ഷപ്പെടാൻ (`position` കാണുക), ഞങ്ങൾ ദൈർഘ്യം ഒരുവിധം അപ്രതീക്ഷിതമായി കണക്കാക്കുന്നു.
// (`കോഡ്‌ജെൻ/സ്ലൈസ്-പൊസിഷൻ-ബ ounds ണ്ട്സ് ചെക്ക്` പരിശോധിച്ചത്.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // ഞങ്ങൾ ചിലപ്പോൾ സുരക്ഷിതമല്ലാത്ത ഒരു ബ്ലോക്കിനുള്ളിൽ ഉപയോഗിക്കുന്നു

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // നീളമുള്ള ZST സ്ലൈസ് ഇറ്ററേറ്ററുകളുടെ ദൈർഘ്യത്തെ പ്രതിനിധീകരിക്കുന്നതിന് ഞങ്ങൾ റാപ്പിംഗിനെ ആശ്രയിച്ചിരിക്കുന്നതിനാൽ ഈ _cannot_ `unchecked_sub` ഉപയോഗിക്കുന്നു.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // `start <= end`, അതിനാൽ `offset_from` നേക്കാൾ മികച്ചത് ചെയ്യാൻ കഴിയുമെന്ന് ഞങ്ങൾക്കറിയാം, അത് ഒപ്പിട്ടവ കൈകാര്യം ചെയ്യേണ്ടതുണ്ട്.
            // ഉചിതമായ ഫ്ലാഗുകൾ ഇവിടെ സജ്ജീകരിക്കുന്നതിലൂടെ ഞങ്ങൾക്ക് ഇത് എൽ‌എൽ‌വി‌എമ്മിനോട് പറയാൻ കഴിയും, ഇത് അതിർത്തി പരിശോധനകൾ നീക്കംചെയ്യാൻ സഹായിക്കുന്നു.
            // സുരക്ഷ: മാറ്റമില്ലാത്ത തരം അനുസരിച്ച്, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // ടൈപ്പ് വലുപ്പത്തിന്റെ കൃത്യമായ ഗുണിതത്താൽ പോയിന്ററുകൾ വേറിട്ടതാണെന്ന് എൽ‌എൽ‌വി‌എമ്മിനോട് പറയുന്നതിലൂടെ, ഇതിന് `(end - start) < size` ന് പകരം `len() == 0` മുതൽ `start == end` വരെ ഒപ്റ്റിമൈസ് ചെയ്യാൻ കഴിയും.
            //
            // സുരക്ഷ: മാറ്റമില്ലാത്ത തരം അനുസരിച്ച്, പോയിന്ററുകൾ വിന്യസിക്കുന്നു അതിനാൽ
            //         അവ തമ്മിലുള്ള ദൂരം പോയിന്റിയുടെ വലുപ്പത്തിന്റെ ഗുണിതമായിരിക്കണം
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// `Iter`, `IterMut` ഇറ്ററേറ്ററുകളുടെ പങ്കിട്ട നിർവചനം
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // ആദ്യ ഘടകം മടക്കിനൽകുകയും ആവർത്തനത്തിന്റെ ആരംഭം 1 മുന്നോട്ട് നീക്കുകയും ചെയ്യുന്നു.
        // ഇൻലൈൻ ചെയ്ത ഫംഗ്ഷനുമായി താരതമ്യപ്പെടുത്തുമ്പോൾ പ്രകടനം വളരെയധികം മെച്ചപ്പെടുത്തുന്നു.
        // ഇറ്ററേറ്റർ ശൂന്യമായിരിക്കരുത്.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // അവസാന ഘടകം തിരികെ നൽകുകയും ആവർത്തനത്തിന്റെ അവസാനം 1 പിന്നിലേക്ക് നീക്കുകയും ചെയ്യുന്നു.
        // ഇൻലൈൻ ചെയ്ത ഫംഗ്ഷനുമായി താരതമ്യപ്പെടുത്തുമ്പോൾ പ്രകടനം വളരെയധികം മെച്ചപ്പെടുത്തുന്നു.
        // ഇറ്ററേറ്റർ ശൂന്യമായിരിക്കരുത്.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // T ഒരു ZST ആയിരിക്കുമ്പോൾ, ആവർത്തനത്തിന്റെ അവസാനം `n` വഴി പിന്നിലേക്ക് നീക്കുന്നതിലൂടെ ആവർത്തനത്തെ ചുരുക്കുന്നു.
        // `n` `self.len()` കവിയാൻ പാടില്ല.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // ഇറ്ററേറ്ററിൽ നിന്ന് ഒരു സ്ലൈസ് സൃഷ്ടിക്കുന്നതിനുള്ള സഹായ പ്രവർത്തനം.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // സുരക്ഷ: പോയിന്റർ ഉള്ള ഒരു സ്ലൈസിൽ നിന്നാണ് ആവർത്തനം സൃഷ്ടിച്ചത്
                // `self.ptr` ഒപ്പം നീളം `len!(self)`.
                // `from_raw_parts`-നായുള്ള എല്ലാ മുൻവ്യവസ്ഥകളും നിറവേറ്റുന്നുവെന്ന് ഇത് ഉറപ്പുനൽകുന്നു.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // ആവർത്തനത്തിന്റെ ആരംഭം `offset` ഘടകങ്ങൾ മുന്നോട്ട് കൊണ്ടുപോകുന്നതിനുള്ള സഹായ പ്രവർത്തനം, പഴയ തുടക്കം നൽകുന്നു.
            //
            // സുരക്ഷിതമല്ലാത്തതിനാൽ ഓഫ്‌സെറ്റ് `self.len()` കവിയാൻ പാടില്ല.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // സുരക്ഷ: `offset` `self.len()` കവിയരുത് എന്ന് കോളർ ഉറപ്പുനൽകുന്നു,
                    // അതിനാൽ ഈ പുതിയ പോയിന്റർ `self`-നുള്ളിലാണ്, അതിനാൽ ശൂന്യമല്ലെന്ന് ഉറപ്പുനൽകുന്നു.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // ആവർത്തനത്തിന്റെ അവസാനം `offset` ഘടകങ്ങൾ പിന്നിലേക്ക് നീക്കുന്നതിനുള്ള സഹായ പ്രവർത്തനം, പുതിയ അവസാനം നൽകുന്നു.
            //
            // സുരക്ഷിതമല്ലാത്തതിനാൽ ഓഫ്‌സെറ്റ് `self.len()` കവിയാൻ പാടില്ല.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // സുരക്ഷ: `offset` `self.len()` കവിയരുത് എന്ന് കോളർ ഉറപ്പുനൽകുന്നു,
                    // ഇത് ഒരു `isize` കവിഞ്ഞൊഴുകില്ലെന്ന് ഉറപ്പുനൽകുന്നു.
                    // കൂടാതെ, തത്ഫലമായുണ്ടാകുന്ന പോയിന്റർ `slice`-ന്റെ പരിധിക്കുള്ളിലാണ്, ഇത് `offset`-നുള്ള മറ്റ് ആവശ്യകതകൾ നിറവേറ്റുന്നു.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // കഷ്ണങ്ങൾ ഉപയോഗിച്ച് നടപ്പിലാക്കാൻ കഴിയും, പക്ഷേ ഇത് പരിധി പരിശോധന ഒഴിവാക്കുന്നു

                // സുരക്ഷ: ഒരു സ്ലൈസിന്റെ ആരംഭ പോയിന്റർ മുതൽ `assume` കോളുകൾ സുരക്ഷിതമാണ്
                // ശൂന്യമല്ലാത്തതായിരിക്കണം, കൂടാതെ ZST ഇതര കഷണങ്ങൾക്ക് മുകളിലുള്ള സ്ലൈസുകളിലും ശൂന്യമല്ലാത്ത അവസാന പോയിന്റർ ഉണ്ടായിരിക്കണം.
                // ഇറ്ററേറ്റർ ആദ്യം ശൂന്യമാണോയെന്ന് പരിശോധിക്കുന്നതിനാൽ `next_unchecked!`-ലേക്കുള്ള കോൾ സുരക്ഷിതമാണ്.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // ഈ ഇറ്ററേറ്റർ ഇപ്പോൾ ശൂന്യമാണ്.
                    if mem::size_of::<T>() == 0 {
                        // `ptr` ഒരിക്കലും 0 ആയിരിക്കില്ല, പക്ഷേ `end` ആകാം (പൊതിയുന്നത് കാരണം).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // സുരക്ഷ: ടി ZST അല്ലെങ്കിൽ അവസാനം 0 ആകാൻ കഴിയില്ല, കാരണം ptr 0 അല്ല, അവസാനം>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // സുരക്ഷ: ഞങ്ങൾ പരിധിയിലാണ്.ZST-കൾക്ക് പോലും `post_inc_start` ശരിയായ കാര്യം ചെയ്യുന്നു.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // `try_fold` ഉപയോഗിക്കുന്ന സ്ഥിരസ്ഥിതി നടപ്പാക്കലിനെ ഞങ്ങൾ അസാധുവാക്കുന്നു, കാരണം ഈ ലളിതമായ നടപ്പാക്കൽ കുറഞ്ഞ എൽ‌എൽ‌വി‌എം ഐ‌ആർ ഉൽ‌പാദിപ്പിക്കുകയും കംപൈൽ ചെയ്യാൻ വേഗതയുള്ളതുമാണ്.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // `try_fold` ഉപയോഗിക്കുന്ന സ്ഥിരസ്ഥിതി നടപ്പാക്കലിനെ ഞങ്ങൾ അസാധുവാക്കുന്നു, കാരണം ഈ ലളിതമായ നടപ്പാക്കൽ കുറഞ്ഞ എൽ‌എൽ‌വി‌എം ഐ‌ആർ ഉൽ‌പാദിപ്പിക്കുകയും കംപൈൽ ചെയ്യാൻ വേഗതയുള്ളതുമാണ്.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // `try_fold` ഉപയോഗിക്കുന്ന സ്ഥിരസ്ഥിതി നടപ്പാക്കലിനെ ഞങ്ങൾ അസാധുവാക്കുന്നു, കാരണം ഈ ലളിതമായ നടപ്പാക്കൽ കുറഞ്ഞ എൽ‌എൽ‌വി‌എം ഐ‌ആർ ഉൽ‌പാദിപ്പിക്കുകയും കംപൈൽ ചെയ്യാൻ വേഗതയുള്ളതുമാണ്.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // `try_fold` ഉപയോഗിക്കുന്ന സ്ഥിരസ്ഥിതി നടപ്പാക്കലിനെ ഞങ്ങൾ അസാധുവാക്കുന്നു, കാരണം ഈ ലളിതമായ നടപ്പാക്കൽ കുറഞ്ഞ എൽ‌എൽ‌വി‌എം ഐ‌ആർ ഉൽ‌പാദിപ്പിക്കുകയും കംപൈൽ ചെയ്യാൻ വേഗതയുള്ളതുമാണ്.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // `try_fold` ഉപയോഗിക്കുന്ന സ്ഥിരസ്ഥിതി നടപ്പാക്കലിനെ ഞങ്ങൾ അസാധുവാക്കുന്നു, കാരണം ഈ ലളിതമായ നടപ്പാക്കൽ കുറഞ്ഞ എൽ‌എൽ‌വി‌എം ഐ‌ആർ ഉൽ‌പാദിപ്പിക്കുകയും കംപൈൽ ചെയ്യാൻ വേഗതയുള്ളതുമാണ്.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // `try_fold` ഉപയോഗിക്കുന്ന സ്ഥിരസ്ഥിതി നടപ്പാക്കലിനെ ഞങ്ങൾ അസാധുവാക്കുന്നു, കാരണം ഈ ലളിതമായ നടപ്പാക്കൽ കുറഞ്ഞ എൽ‌എൽ‌വി‌എം ഐ‌ആർ ഉൽ‌പാദിപ്പിക്കുകയും കംപൈൽ ചെയ്യാൻ വേഗതയുള്ളതുമാണ്.
            // കൂടാതെ, `assume` ഒരു പരിധി പരിശോധന ഒഴിവാക്കുന്നു.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // സുരക്ഷ: ലൂപ്പ് മാറ്റമില്ലാത്തതിനാൽ ഞങ്ങൾക്ക് പരിധിയുണ്ടെന്ന് ഉറപ്പുനൽകുന്നു:
                        // `i >= n`, `self.next()` `None` നൽകുകയും ലൂപ്പ് തകരുകയും ചെയ്യുമ്പോൾ.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // `try_fold` ഉപയോഗിക്കുന്ന സ്ഥിരസ്ഥിതി നടപ്പാക്കലിനെ ഞങ്ങൾ അസാധുവാക്കുന്നു, കാരണം ഈ ലളിതമായ നടപ്പാക്കൽ കുറഞ്ഞ എൽ‌എൽ‌വി‌എം ഐ‌ആർ ഉൽ‌പാദിപ്പിക്കുകയും കംപൈൽ ചെയ്യാൻ വേഗതയുള്ളതുമാണ്.
            // കൂടാതെ, `assume` ഒരു പരിധി പരിശോധന ഒഴിവാക്കുന്നു.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // സുരക്ഷ: `i` `n`-ൽ ആരംഭിക്കുന്നതിനാൽ `n`-നേക്കാൾ കുറവായിരിക്കണം
                        // കുറയുന്നു.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // സുരക്ഷ: `i` അതിരുകളിലാണെന്ന് കോളർ ഉറപ്പ് നൽകണം
                // അന്തർലീനമായ സ്ലൈസ്, അതിനാൽ `i` ന് ഒരു `isize` കവിഞ്ഞൊഴുകാൻ കഴിയില്ല, കൂടാതെ മടങ്ങിയ റഫറൻസുകൾ സ്ലൈസിന്റെ ഒരു ഘടകത്തെ പരാമർശിക്കുമെന്ന് ഉറപ്പുനൽകുന്നു, അതിനാൽ ഇത് സാധുതയുള്ളതാണെന്ന് ഉറപ്പുനൽകുന്നു.
                //
                // ഇതേ സൂചിക ഉപയോഗിച്ച് ഞങ്ങൾ ഒരിക്കലും വിളിച്ചിട്ടില്ലെന്നും ഈ സബ്‌ലൈസ് ആക്‌സസ് ചെയ്യുന്ന മറ്റ് രീതികളൊന്നും വിളിക്കില്ലെന്നും കോളർ ഉറപ്പുനൽകുന്നുവെന്നതും ശ്രദ്ധിക്കുക, അതിനാൽ മടങ്ങിയെത്തിയ റഫറൻസിന് മ്യൂട്ടബിൾ ആകുന്നതിന് ഇത് സാധുതയുള്ളതാണ്
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // കഷ്ണങ്ങൾ ഉപയോഗിച്ച് നടപ്പിലാക്കാൻ കഴിയും, പക്ഷേ ഇത് പരിധി പരിശോധന ഒഴിവാക്കുന്നു

                // സുരക്ഷ: ഒരു സ്ലൈസിന്റെ ആരംഭ പോയിന്റർ ശൂന്യമല്ലാത്തതിനാൽ `assume` കോളുകൾ സുരക്ഷിതമാണ്,
                // കൂടാതെ ZST-കൾക്ക് മുകളിലുള്ള സ്ലൈസുകളിലും ശൂന്യമല്ലാത്ത അവസാന പോയിന്റർ ഉണ്ടായിരിക്കണം.
                // ഇറ്ററേറ്റർ ആദ്യം ശൂന്യമാണോയെന്ന് പരിശോധിക്കുന്നതിനാൽ `next_back_unchecked!`-ലേക്കുള്ള കോൾ സുരക്ഷിതമാണ്.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // ഈ ഇറ്ററേറ്റർ ഇപ്പോൾ ശൂന്യമാണ്.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // സുരക്ഷ: ഞങ്ങൾ പരിധിയിലാണ്.ZST-കൾക്ക് പോലും `pre_dec_end` ശരിയായ കാര്യം ചെയ്യുന്നു.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}