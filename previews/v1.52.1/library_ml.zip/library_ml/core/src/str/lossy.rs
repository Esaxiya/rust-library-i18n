use crate::char;
use crate::fmt::{self, Write};
use crate::mem;

use super::from_utf8_unchecked;
use super::validations::utf8_char_width;

/// നീണ്ട UTF-8 സ്ട്രിംഗ്.
#[unstable(feature = "str_internals", issue = "none")]
pub struct Utf8Lossy {
    bytes: [u8],
}

impl Utf8Lossy {
    pub fn from_str(s: &str) -> &Utf8Lossy {
        Utf8Lossy::from_bytes(s.as_bytes())
    }

    pub fn from_bytes(bytes: &[u8]) -> &Utf8Lossy {
        // സുരക്ഷ: രണ്ടും ഒരേ മെമ്മറി ലേ layout ട്ട് ഉപയോഗിക്കുന്നു, മാത്രമല്ല UTF-8 കൃത്യത ആവശ്യമില്ല.
        unsafe { mem::transmute(bytes) }
    }

    pub fn chunks(&self) -> Utf8LossyChunksIter<'_> {
        Utf8LossyChunksIter { source: &self.bytes }
    }
}

/// നഷ്ടപ്പെട്ട UTF-8 സ്‌ട്രിംഗിന് മുകളിലുള്ള ഇറ്ററേറ്റർ
#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_debug_implementations)]
pub struct Utf8LossyChunksIter<'a> {
    source: &'a [u8],
}

#[unstable(feature = "str_internals", issue = "none")]
#[derive(PartialEq, Eq, Debug)]
pub struct Utf8LossyChunk<'a> {
    /// സാധുവായ പ്രതീകങ്ങളുടെ അനുക്രമം.
    /// തകർന്ന UTF-8 പ്രതീകങ്ങൾക്കിടയിൽ ശൂന്യമായിരിക്കാം.
    pub valid: &'a str,
    /// ഒറ്റ തകർന്ന ചാർ, ഒന്നുമില്ലെങ്കിൽ ശൂന്യമാണ്.
    /// ശൂന്യമായ iff iterator ഇനം അവസാനമാണ്.
    pub broken: &'a [u8],
}

impl<'a> Iterator for Utf8LossyChunksIter<'a> {
    type Item = Utf8LossyChunk<'a>;

    fn next(&mut self) -> Option<Utf8LossyChunk<'a>> {
        if self.source.is_empty() {
            return None;
        }

        const TAG_CONT_U8: u8 = 128;
        fn safe_get(xs: &[u8], i: usize) -> u8 {
            *xs.get(i).unwrap_or(&0)
        }

        let mut i = 0;
        while i < self.source.len() {
            let i_ = i;

            // സുരക്ഷ: `i` `0` ൽ ആരംഭിക്കുന്നു, `self.source.len()` നേക്കാൾ കുറവാണ്, കൂടാതെ
            // വർദ്ധിക്കുന്നു, അതിനാൽ `0 <= i < self.source.len()`.
            let byte = unsafe { *self.source.get_unchecked(i) };
            i += 1;

            if byte < 128 {
            } else {
                let w = utf8_char_width(byte);

                macro_rules! error {
                    () => {{
                        // സുരക്ഷ: ഉറവിടം സാധുവായ UTF-8 ആണെന്ന് ഞങ്ങൾ `i` വരെ പരിശോധിച്ചു.
                        unsafe {
                            let r = Utf8LossyChunk {
                                valid: from_utf8_unchecked(&self.source[0..i_]),
                                broken: &self.source[i_..i],
                            };
                            self.source = &self.source[i..];
                            return Some(r);
                        }
                    }};
                }

                match w {
                    2 => {
                        if safe_get(self.source, i) & 192 != TAG_CONT_U8 {
                            error!();
                        }
                        i += 1;
                    }
                    3 => {
                        match (byte, safe_get(self.source, i)) {
                            (0xE0, 0xA0..=0xBF) => (),
                            (0xE1..=0xEC, 0x80..=0xBF) => (),
                            (0xED, 0x80..=0x9F) => (),
                            (0xEE..=0xEF, 0x80..=0xBF) => (),
                            _ => {
                                error!();
                            }
                        }
                        i += 1;
                        if safe_get(self.source, i) & 192 != TAG_CONT_U8 {
                            error!();
                        }
                        i += 1;
                    }
                    4 => {
                        match (byte, safe_get(self.source, i)) {
                            (0xF0, 0x90..=0xBF) => (),
                            (0xF1..=0xF3, 0x80..=0xBF) => (),
                            (0xF4, 0x80..=0x8F) => (),
                            _ => {
                                error!();
                            }
                        }
                        i += 1;
                        if safe_get(self.source, i) & 192 != TAG_CONT_U8 {
                            error!();
                        }
                        i += 1;
                        if safe_get(self.source, i) & 192 != TAG_CONT_U8 {
                            error!();
                        }
                        i += 1;
                    }
                    _ => {
                        error!();
                    }
                }
            }
        }

        let r = Utf8LossyChunk {
            // സുരക്ഷ: മുഴുവൻ ഉറവിടവും സാധുവായ UTF-8 ആണെന്ന് ഞങ്ങൾ പരിശോധിച്ചു.
            valid: unsafe { from_utf8_unchecked(self.source) },
            broken: &[],
        };
        self.source = &[];
        Some(r)
    }
}

impl fmt::Display for Utf8Lossy {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // ഞങ്ങൾ ശൂന്യമായ സ്‌ട്രിംഗ് ആണെങ്കിൽ ഞങ്ങളുടെ ഇറ്ററേറ്റർ യഥാർത്ഥത്തിൽ ഒന്നും നൽകില്ല, അതിനാൽ ഫോർമാറ്റിംഗ് സ്വമേധയാ നടപ്പിലാക്കുക
        //
        if self.bytes.is_empty() {
            return "".fmt(f);
        }

        for Utf8LossyChunk { valid, broken } in self.chunks() {
            // മുഴുവൻ ചങ്കും സാധുവായ ഒരു സ്ട്രിംഗായി ഡീകോഡ് ചെയ്താൽ, നമുക്ക് സ്ട്രിംഗിന്റെ നേരിട്ടുള്ള ഫോർമാറ്റിംഗ് മടക്കിനൽകാൻ കഴിയും, അത് സാധ്യമെങ്കിൽ വിവിധ ഫോർമാറ്റിംഗ് ഫ്ലാഗുകളെയും മാനിക്കും.
            //
            //
            if valid.len() == self.bytes.len() {
                assert!(broken.is_empty());
                return valid.fmt(f);
            }

            f.write_str(valid)?;
            if !broken.is_empty() {
                f.write_char(char::REPLACEMENT_CHARACTER)?;
            }
        }
        Ok(())
    }
}

impl fmt::Debug for Utf8Lossy {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_char('"')?;

        for Utf8LossyChunk { valid, broken } in self.chunks() {
            // സാധുവായ ഭാഗം.
            // ഇവിടെ ഞങ്ങൾ ഭാഗികമായി UTF-8 പാഴ്‌സുചെയ്യുന്നു, അത് ഉപോപ്റ്റിമൽ ആണ്.
            {
                let mut from = 0;
                for (i, c) in valid.char_indices() {
                    let esc = c.escape_debug();
                    // ചാർ‌ക്ക് രക്ഷപ്പെടാൻ‌ആവശ്യമുണ്ടെങ്കിൽ‌, ഇതുവരെ ബാക്ക്‌ലോഗ് ഫ്ലഷ് ചെയ്‌ത് എഴുതുക, അല്ലെങ്കിൽ‌ഒഴിവാക്കുക
                    if esc.len() != 1 {
                        f.write_str(&valid[from..i])?;
                        for c in esc {
                            f.write_char(c)?;
                        }
                        from = i + c.len_utf8();
                    }
                }
                f.write_str(&valid[from..])?;
            }

            // ഹെക്സ് എസ്‌കേപ്പ് ആയി സ്ട്രിംഗിന്റെ തകർന്ന ഭാഗങ്ങൾ.
            for &b in broken {
                write!(f, "\\x{:02x}", b)?;
            }
        }

        f.write_char('"')
    }
}