//! UTF-8 മൂല്യനിർണ്ണയവുമായി ബന്ധപ്പെട്ട പ്രവർത്തനങ്ങൾ.

use crate::mem;

use super::Utf8Error;

/// ആദ്യ ബൈറ്റിനായി പ്രാരംഭ കോഡ്പോയിന്റ് ശേഖരിക്കൽ നൽകുന്നു.
/// ആദ്യ ബൈറ്റ് സവിശേഷമാണ്, വീതി 2 ന് താഴെയുള്ള 5 ബിറ്റുകൾ, വീതി 3 ന് 4 ബിറ്റുകൾ, വീതി 4 ന് 3 ബിറ്റുകൾ എന്നിവ മാത്രം ആവശ്യമാണ്.
///
#[inline]
fn utf8_first_byte(byte: u8, width: u32) -> u32 {
    (byte & (0x7F >> width)) as u32
}

/// തുടർച്ചയായ ബൈറ്റ് `byte` ഉപയോഗിച്ച് അപ്‌ഡേറ്റുചെയ്‌ത `ch`-ന്റെ മൂല്യം നൽകുന്നു.
#[inline]
fn utf8_acc_cont_byte(ch: u32, byte: u8) -> u32 {
    (ch << 6) | (byte & CONT_MASK) as u32
}

/// ബൈറ്റ് ഒരു UTF-8 തുടര്ച്ചയുള്ള ബൈറ്റാണോയെന്ന് പരിശോധിക്കുന്നു (അതായത്, `10` ബിറ്റുകളിൽ ആരംഭിക്കുന്നു).
///
#[inline]
pub(super) fn utf8_is_cont_byte(byte: u8) -> bool {
    (byte & !CONT_MASK) == TAG_CONT_U8
}

#[inline]
fn unwrap_or_0(opt: Option<&u8>) -> u8 {
    match opt {
        Some(&byte) => byte,
        None => 0,
    }
}

/// ഒരു ബൈറ്റ് ഇറ്ററേറ്ററിൽ നിന്ന് അടുത്ത കോഡ് പോയിന്റ് വായിക്കുന്നു (യുടിഎഫ്-8 പോലുള്ള എൻകോഡിംഗ് എന്ന് കരുതുക).
///
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn next_code_point<'a, I: Iterator<Item = &'a u8>>(bytes: &mut I) -> Option<u32> {
    // UTF-8 ഡീകോഡ് ചെയ്യുക
    let x = *bytes.next()?;
    if x < 128 {
        return Some(x as u32);
    }

    // മൾട്ടിബൈറ്റ് കേസ് ഇനിപ്പറയുന്നതിൽ നിന്ന് ഒരു ബൈറ്റ് കോമ്പിനേഷനിൽ നിന്ന് ഡീകോഡ് ചെയ്യുന്നു: [[[x y] z] w]
    //
    // NOTE: പ്രകടനം ഇവിടെ കൃത്യമായ ഫോർമുലേഷനുമായി സംവേദനക്ഷമമാണ്
    let init = utf8_first_byte(x, 2);
    let y = unwrap_or_0(bytes.next());
    let mut ch = utf8_acc_cont_byte(init, y);
    if x >= 0xE0 {
        // [[x y z] w] കേസ്
        // 0xE0-ലെ അഞ്ചാമത്തെ ബിറ്റ് .. 0xEF എല്ലായ്പ്പോഴും വ്യക്തമാണ്, അതിനാൽ `init` ഇപ്പോഴും സാധുവാണ്
        let z = unwrap_or_0(bytes.next());
        let y_z = utf8_acc_cont_byte((y & CONT_MASK) as u32, z);
        ch = init << 12 | y_z;
        if x >= 0xF0 {
            // [x y z w] കേസ് `init`-ന്റെ താഴ്ന്ന 3 ബിറ്റുകൾ മാത്രം ഉപയോഗിക്കുക
            //
            let w = unwrap_or_0(bytes.next());
            ch = (init & 7) << 18 | utf8_acc_cont_byte(y_z, w);
        }
    }

    Some(ch)
}

/// ഒരു ബൈറ്റ് ഇറ്ററേറ്ററിലെ അവസാന കോഡ് പോയിന്റ് വായിക്കുന്നു (യുടിഎഫ്-8 പോലുള്ള എൻ‌കോഡിംഗ് അനുമാനിക്കുന്നു).
///
#[inline]
pub(super) fn next_code_point_reverse<'a, I>(bytes: &mut I) -> Option<u32>
where
    I: DoubleEndedIterator<Item = &'a u8>,
{
    // UTF-8 ഡീകോഡ് ചെയ്യുക
    let w = match *bytes.next_back()? {
        next_byte if next_byte < 128 => return Some(next_byte as u32),
        back_byte => back_byte,
    };

    // മൾട്ടിബൈറ്റ് കേസ് ഇനിപ്പറയുന്നതിൽ നിന്ന് ഒരു ബൈറ്റ് കോമ്പിനേഷനിൽ നിന്ന് ഡീകോഡ് ചെയ്യുന്നു: [x [y [z w]]]
    //
    let mut ch;
    let z = unwrap_or_0(bytes.next_back());
    ch = utf8_first_byte(z, 2);
    if utf8_is_cont_byte(z) {
        let y = unwrap_or_0(bytes.next_back());
        ch = utf8_first_byte(y, 3);
        if utf8_is_cont_byte(y) {
            let x = unwrap_or_0(bytes.next_back());
            ch = utf8_first_byte(x, 4);
            ch = utf8_acc_cont_byte(ch, y);
        }
        ch = utf8_acc_cont_byte(ch, z);
    }
    ch = utf8_acc_cont_byte(ch, w);

    Some(ch)
}

// ഉപയോഗത്തിലേക്ക് u64 ഘടിപ്പിക്കുന്നതിന് വെട്ടിച്ചുരുക്കൽ ഉപയോഗിക്കുക
const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;

/// `x` എന്ന പദത്തിലെ ഏതെങ്കിലും ബൈറ്റ് nonascii ആണെങ്കിൽ `true` നൽകുന്നു (>=128).
#[inline]
fn contains_nonascii(x: usize) -> bool {
    (x & NONASCII_MASK) != 0
}

/// ഇത് സാധുവായ UTF-8 സീക്വൻസാണോയെന്ന് `v` പരിശോധിക്കുന്നു, ആ സാഹചര്യത്തിൽ `Ok(())` നൽകുന്നു, അല്ലെങ്കിൽ അത് അസാധുവാണെങ്കിൽ, `Err(err)`.
///
#[inline(always)]
pub(super) fn run_utf8_validation(v: &[u8]) -> Result<(), Utf8Error> {
    let mut index = 0;
    let len = v.len();

    let usize_bytes = mem::size_of::<usize>();
    let ascii_block_size = 2 * usize_bytes;
    let blocks_end = if len >= ascii_block_size { len - ascii_block_size + 1 } else { 0 };
    let align = v.as_ptr().align_offset(usize_bytes);

    while index < len {
        let old_offset = index;
        macro_rules! err {
            ($error_len: expr) => {
                return Err(Utf8Error { valid_up_to: old_offset, error_len: $error_len })
            };
        }

        macro_rules! next {
            () => {{
                index += 1;
                // ഞങ്ങൾക്ക് ഡാറ്റ ആവശ്യമാണ്, പക്ഷേ ഒന്നും ഉണ്ടായിരുന്നില്ല: പിശക്!
                if index >= len {
                    err!(None)
                }
                v[index]
            }};
        }

        let first = v[index];
        if first >= 128 {
            let w = UTF8_CHAR_WIDTH[first as usize];
            // 2 ute 0080} മുതൽ\u {07ff} ആദ്യ C2 80 അവസാന DF BF വരെയുള്ള കോഡ് പോയിന്റുകൾക്കാണ് 2-ബൈറ്റ് എൻ‌കോഡിംഗ്
            // 3-ബൈറ്റ് എൻ‌കോഡിംഗ് code u {0800} മുതൽ\u {ffff} ആദ്യ E0 A0 80 വരെ അവസാനത്തെ EF BF BF, സറോഗേറ്റ് കോഡ് പോയിൻറുകൾ ഒഴികെ\u {d800} മുതൽ\u {dfff} ED A0 80 മുതൽ ED BF BF വരെ
            // 4-ബൈറ്റ് എൻ‌കോഡിംഗ് code u {1000} 0 മുതൽ\u {10ff} ff ആദ്യ F0 90 80 80 അവസാന F4 8F BF BF
            //
            // RFC-യിൽ നിന്നുള്ള UTF-8 വാക്യഘടന ഉപയോഗിക്കുക
            //
            // https://tools.ietf.org/html/rfc3629
            // UTF8-1=% x00-7F UTF8-2=% xC2-DF UTF8-ടെയിൽ UTF8-3= %xE0% xA0-BF UTF8-ടെയിൽ/% xE1-EC 2( UTF8-tail )/%xED% x80-9F UTF8-ടെയിൽ/% xEE-EF 2( UTF8-tail ) UTF8-4= %xF0% x90-BF 2( UTF8-tail )/% xF1-F3 3( UTF8-tail )/%xF4% x80-8F 2( UTF8-tail )
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            match w {
                2 => {
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(1))
                    }
                }
                3 => {
                    match (first, next!()) {
                        (0xE0, 0xA0..=0xBF)
                        | (0xE1..=0xEC, 0x80..=0xBF)
                        | (0xED, 0x80..=0x9F)
                        | (0xEE..=0xEF, 0x80..=0xBF) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                }
                4 => {
                    match (first, next!()) {
                        (0xF0, 0x90..=0xBF) | (0xF1..=0xF3, 0x80..=0xBF) | (0xF4, 0x80..=0x8F) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(3))
                    }
                }
                _ => err!(Some(1)),
            }
            index += 1;
        } else {
            // Ascii കേസ്, വേഗത്തിൽ മുന്നോട്ട് പോകാൻ ശ്രമിക്കുക.
            // പോയിന്റർ വിന്യസിക്കുമ്പോൾ, ഒരു ആസ്‌സി അല്ലാത്ത ബൈറ്റ് അടങ്ങിയിരിക്കുന്ന ഒരു വാക്ക് കണ്ടെത്തുന്നതുവരെ ഓരോ ആവർത്തനത്തിനും 2 പദങ്ങളുടെ ഡാറ്റ വായിക്കുക.
            //
            if align != usize::MAX && align.wrapping_sub(index) % usize_bytes == 0 {
                let ptr = v.as_ptr();
                while index < blocks_end {
                    // സുരക്ഷ: `align - index`, `ascii_block_size` എന്നിവ ആയതിനാൽ
                    // `usize_bytes`, `block = ptr.add(index)` എന്നിവയുടെ ഗുണിതങ്ങൾ എല്ലായ്പ്പോഴും ഒരു `usize`-മായി വിന്യസിക്കപ്പെടുന്നു, അതിനാൽ `block`, `block.offset(1)` എന്നിവ ഒഴിവാക്കുന്നത് സുരക്ഷിതമാണ്.
                    //
                    //
                    unsafe {
                        let block = ptr.add(index) as *const usize;
                        // ഒരു നോൺ‌സ്കൈ ബൈറ്റ് ഉണ്ടെങ്കിൽ ബ്രേക്ക് ചെയ്യുക
                        let zu = contains_nonascii(*block);
                        let zv = contains_nonascii(*block.offset(1));
                        if zu | zv {
                            break;
                        }
                    }
                    index += ascii_block_size;
                }
                // വേഡ്‌വൈസ് ലൂപ്പ് നിർത്തിയ സ്ഥാനത്ത് നിന്ന് ചുവടുവെക്കുക
                while index < len && v[index] < 128 {
                    index += 1;
                }
            } else {
                index += 1;
            }
        }
    }

    Ok(())
}

// https://tools.ietf.org/html/rfc3629
static UTF8_CHAR_WIDTH: [u8; 256] = [
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x1F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x3F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x5F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x7F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0x9F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0xBF
    0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, // 0xDF
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, // 0xEF
    4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 0xFF
];

/// ആദ്യ ബൈറ്റ് നൽകിയാൽ, ഈ UTF-8 പ്രതീകത്തിൽ എത്ര ബൈറ്റുകൾ ഉണ്ടെന്ന് നിർണ്ണയിക്കുന്നു.
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn utf8_char_width(b: u8) -> usize {
    UTF8_CHAR_WIDTH[b as usize] as usize
}

/// ഒരു തുടർച്ചയായ ബൈറ്റിന്റെ മൂല്യം ബിറ്റുകളുടെ മാസ്ക്.
const CONT_MASK: u8 = 0b0011_1111;
/// തുടർച്ചയായ ബൈറ്റിന്റെ ടാഗ് ബിറ്റുകളുടെ മൂല്യം (ടാഗ് മാസ്ക് !CONT_MASK ആണ്).
const TAG_CONT_U8: u8 = 0b1000_0000;

// വെട്ടിക്കുറച്ചതാണെങ്കിൽ `&str` നീളത്തിൽ നിന്ന് `max` റിട്ടേൺ `true` വരെ തുല്യമാക്കുക, പുതിയ സ്ട്രിംഗ്.
//
pub(super) fn truncate_to_char_boundary(s: &str, mut max: usize) -> (bool, &str) {
    if max >= s.len() {
        (false, s)
    } else {
        while !s.is_char_boundary(max) {
            max -= 1;
        }
        (true, &s[..max])
    }
}