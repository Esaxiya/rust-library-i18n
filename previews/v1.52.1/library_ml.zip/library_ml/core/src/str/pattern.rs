//! സ്ട്രിംഗ് പാറ്റേൺ API.
//!
//! ഒരു സ്ട്രിംഗിലൂടെ തിരയുമ്പോൾ വ്യത്യസ്ത പാറ്റേൺ തരങ്ങൾ ഉപയോഗിക്കുന്നതിനുള്ള ഒരു സാധാരണ സംവിധാനം പാറ്റേൺ API നൽകുന്നു.
//!
//! കൂടുതൽ വിവരങ്ങൾക്ക്, traits [`Pattern`], [`Searcher`], [`ReverseSearcher`], [`DoubleEndedSearcher`] എന്നിവ കാണുക.
//!
//! ഈ API അസ്ഥിരമാണെങ്കിലും, [`str`] തരത്തിലുള്ള സ്ഥിരതയുള്ള API-കൾ വഴി ഇത് തുറന്നുകാട്ടപ്പെടുന്നു.
//!
//! # Examples
//!
//! [`Pattern`] [`&str`][`str`], [`char`], [`char`] ന്റെ സ്ലൈസുകൾ, `FnMut(char) -> bool` നടപ്പിലാക്കുന്ന ഫംഗ്ഷനുകൾ, ക്ലോസറുകൾ എന്നിവയ്‌ക്കായുള്ള സ്ഥിരമായ API-ലെ [implemented][pattern-impls] ആണ്.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // ചാർ പാറ്റേൺ
//! assert_eq!(s.find('n'), Some(2));
//! // അക്ഷരങ്ങളുടെ പാറ്റേൺ
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // അടയ്ക്കൽ പാറ്റേൺ
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// ഒരു സ്ട്രിംഗ് പാറ്റേൺ.
///
/// ഒരു [`&'a str`][str]-ൽ തിരയുന്നതിനായി ഒരു സ്ട്രിംഗ് പാറ്റേണായി നടപ്പിലാക്കുന്ന തരം ഉപയോഗിക്കാമെന്ന് ഒരു `Pattern<'a>` പ്രകടിപ്പിക്കുന്നു.
///
/// ഉദാഹരണത്തിന്, `'a'`, `"aa"` എന്നിവ `"baaaab"` സ്ട്രിംഗിലെ സൂചിക `1`-മായി പൊരുത്തപ്പെടുന്ന പാറ്റേണുകളാണ്.
///
/// trait തന്നെ ഒരു അനുബന്ധ [`Searcher`] തരത്തിനായുള്ള ഒരു ബിൽഡറായി പ്രവർത്തിക്കുന്നു, ഇത് ഒരു സ്ട്രിംഗിൽ പാറ്റേണിന്റെ സംഭവങ്ങൾ കണ്ടെത്തുന്നതിനുള്ള യഥാർത്ഥ ജോലി ചെയ്യുന്നു.
///
///
/// പാറ്റേണിന്റെ തരം അനുസരിച്ച്, [`str::find`], [`str::contains`] പോലുള്ള രീതികളുടെ സ്വഭാവത്തിൽ മാറ്റം വരാം.
/// ചുവടെയുള്ള പട്ടിക അത്തരം ചില സ്വഭാവങ്ങളെ വിവരിക്കുന്നു.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// ഈ പാറ്റേണിനായി ബന്ധപ്പെട്ട തിരയൽ
    type Searcher: Searcher<'a>;

    /// തിരയുന്നതിനായി `self`, `haystack` എന്നിവയിൽ നിന്ന് അനുബന്ധ തിരയൽ നിർമ്മിക്കുന്നു.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// പാറ്റേൺ ഹെയ്‌സ്റ്റാക്കിൽ എവിടെയെങ്കിലും പൊരുത്തപ്പെടുന്നുണ്ടോയെന്ന് പരിശോധിക്കുന്നു
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// പുൽത്തകിടിയുടെ മുൻവശത്ത് പാറ്റേൺ പൊരുത്തപ്പെടുന്നുണ്ടോയെന്ന് പരിശോധിക്കുന്നു
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// പാറ്റേൺ പുൽത്തകിടിയുടെ പിൻഭാഗത്ത് പൊരുത്തപ്പെടുന്നുണ്ടോയെന്ന് പരിശോധിക്കുന്നു
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// പൊരുത്തപ്പെടുന്നെങ്കിൽ, ഹെയ്‌സ്റ്റാക്കിന്റെ മുൻഭാഗത്ത് നിന്ന് പാറ്റേൺ നീക്കംചെയ്യുന്നു.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // സുരക്ഷ: സാധുവായ സൂചികകൾ നൽകുന്നതിന് `Searcher` അറിയപ്പെടുന്നു.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// പൊരുത്തപ്പെടുന്നെങ്കിൽ, ഹെയ്‌സ്റ്റാക്കിന്റെ പിന്നിൽ നിന്ന് പാറ്റേൺ നീക്കംചെയ്യുന്നു.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // സുരക്ഷ: സാധുവായ സൂചികകൾ നൽകുന്നതിന് `Searcher` അറിയപ്പെടുന്നു.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// [`Searcher::next()`] അല്ലെങ്കിൽ [`ReverseSearcher::next_back()`] വിളിക്കുന്നതിന്റെ ഫലം.
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// പാറ്റേണിന്റെ പൊരുത്തം `haystack[a..b]`-ൽ കണ്ടെത്തിയതായി പ്രകടിപ്പിക്കുന്നു.
    ///
    Match(usize, usize),
    /// പാറ്റേണിന്റെ സാധ്യമായ പൊരുത്തമായി `haystack[a..b]` നിരസിക്കപ്പെട്ടുവെന്ന് പ്രകടിപ്പിക്കുന്നു.
    ///
    /// രണ്ട് `മാച്ച്`കൾക്കിടയിൽ ഒന്നിൽ കൂടുതൽ `Reject` ഉണ്ടായിരിക്കാമെന്നത് ശ്രദ്ധിക്കുക, അവ ഒന്നായി കൂട്ടിച്ചേർക്കേണ്ട ആവശ്യമില്ല.
    ///
    ///
    Reject(usize, usize),
    /// ആവർത്തനം അവസാനിപ്പിച്ച് പുൽക്കൊടിയിലെ ഓരോ ബൈറ്റും സന്ദർശിച്ചതായി പ്രകടിപ്പിക്കുന്നു.
    ///
    Done,
}

/// ഒരു സ്‌ട്രിംഗ് പാറ്റേണിനായുള്ള തിരയൽ.
///
/// ഈ trait ഒരു സ്ട്രിംഗിന്റെ മുൻ (left) മുതൽ ആരംഭിക്കുന്ന ഒരു പാറ്റേണിന്റെ ഓവർലാപ്പുചെയ്യാത്ത പൊരുത്തങ്ങൾക്കായി തിരയുന്നതിനുള്ള രീതികൾ നൽകുന്നു.
///
/// [`Pattern`] trait-ന്റെ അനുബന്ധ `Searcher` തരങ്ങൾ ഇത് നടപ്പിലാക്കും.
///
/// trait സുരക്ഷിതമല്ലാത്തതായി അടയാളപ്പെടുത്തിയിരിക്കുന്നു, കാരണം [`next()`][Searcher::next] രീതികളിലൂടെ മടങ്ങിയെത്തുന്ന സൂചികകൾ ഹെയ്‌സ്റ്റാക്കിലെ സാധുവായ utf8 അതിരുകളിൽ കിടക്കാൻ ആവശ്യമാണ്.
/// അധിക റൺടൈം പരിശോധനകളില്ലാതെ ഈ trait ന്റെ ഉപഭോക്താക്കളെ പുൽക്കൊടി മുറിക്കാൻ ഇത് പ്രാപ്തമാക്കുന്നു.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// തിരയേണ്ട അന്തർലീനമായ സ്‌ട്രിംഗിനായി Getter
    ///
    /// എല്ലായ്പ്പോഴും ഒരേ [`&str`][str] നൽകും.
    fn haystack(&self) -> &'a str;

    /// മുന്നിൽ നിന്ന് ആരംഭിക്കുന്ന അടുത്ത തിരയൽ ഘട്ടം നടപ്പിലാക്കുന്നു.
    ///
    /// - `haystack[a..b]` പാറ്റേണുമായി പൊരുത്തപ്പെടുന്നെങ്കിൽ [`Match(a, b)`][SearchStep::Match] നൽകുന്നു.
    /// - ഭാഗികമായിപ്പോലും `haystack[a..b]` പാറ്റേണുമായി പൊരുത്തപ്പെടാൻ കഴിയുന്നില്ലെങ്കിൽ [`Reject(a, b)`][SearchStep::Reject] നൽകുന്നു.
    /// - ഹെയ്‌സ്റ്റാക്കിന്റെ ഓരോ ബൈറ്റും സന്ദർശിച്ചിട്ടുണ്ടെങ്കിൽ [`Done`][SearchStep::Done] നൽകുന്നു.
    ///
    /// ഒരു [`Done`][SearchStep::Done] വരെയുള്ള [`Match`][SearchStep::Match], [`Reject`][SearchStep::Reject] മൂല്യങ്ങളുടെ സ്ട്രീമിൽ തൊട്ടടുത്തുള്ളതും ഓവർലാപ്പുചെയ്യാത്തതും മുഴുവൻ ഹെയ്സ്റ്റാക്കിനെ മൂടുന്നതും utf8 അതിരുകളിൽ കിടക്കുന്നതുമായ സൂചിക ശ്രേണികൾ അടങ്ങിയിരിക്കും.
    ///
    ///
    /// ഒരു [`Match`][SearchStep::Match] ഫലത്തിൽ പൊരുത്തപ്പെടുന്ന പാറ്റേൺ മുഴുവനും അടങ്ങിയിരിക്കണം, എന്നിരുന്നാലും [`Reject`][SearchStep::Reject] ഫലങ്ങൾ അനിയന്ത്രിതമായി സമീപത്തുള്ള പല ശകലങ്ങളായി വിഭജിക്കാം.രണ്ട് ശ്രേണികൾക്കും പൂജ്യം നീളം ഉണ്ടായിരിക്കാം.
    ///
    /// ഉദാഹരണമായി, `"aaa"` പാറ്റേണും ഹെയ്‌സ്റ്റാക്ക് `"cbaaaaab"` ഉം സ്ട്രീം സൃഷ്ടിച്ചേക്കാം
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// അടുത്ത [`Match`][SearchStep::Match] ഫലം കണ്ടെത്തുന്നു.[`next()`][Searcher::next] കാണുക.
    ///
    /// [`next()`][Searcher::next] ൽ നിന്ന് വ്യത്യസ്തമായി, ഇതിന്റെയും [`next_reject`][Searcher::next_reject] ന്റെയും റിട്ടേൺ ശ്രേണികൾ ഓവർലാപ്പ് ചെയ്യുമെന്നതിന് യാതൊരു ഉറപ്പുമില്ല.
    /// ഇത് `(start_match, end_match)` നൽകും, ഇവിടെ സ്റ്റാർട്ട്_മാച്ച് എന്നത് മത്സരം ആരംഭിക്കുന്നതിന്റെ സൂചികയാണ്, കൂടാതെ മത്സരം അവസാനിച്ചതിനുശേഷം സൂചികയാണ് എൻഡ്_മാച്ച്.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// അടുത്ത [`Reject`][SearchStep::Reject] ഫലം കണ്ടെത്തുന്നു.[`next()`][Searcher::next], [`next_match()`][Searcher::next_match] എന്നിവ കാണുക.
    ///
    /// [`next()`][Searcher::next] ൽ നിന്ന് വ്യത്യസ്തമായി, ഇതിന്റെയും [`next_match`][Searcher::next_match] ന്റെയും റിട്ടേൺ ശ്രേണികൾ ഓവർലാപ്പ് ചെയ്യുമെന്നതിന് യാതൊരു ഉറപ്പുമില്ല.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// ഒരു സ്‌ട്രിംഗ് പാറ്റേണിനായി ഒരു വിപരീത തിരയൽ.
///
/// ഒരു സ്ട്രിംഗിന്റെ (right) ന്റെ പിന്നിൽ നിന്ന് ആരംഭിക്കുന്ന ഒരു പാറ്റേണിന്റെ ഓവർലാപ്പുചെയ്യാത്ത പൊരുത്തങ്ങൾക്കായി തിരയുന്നതിനുള്ള രീതികൾ ഈ trait നൽകുന്നു.
///
/// പാറ്റേൺ പിന്നിൽ നിന്ന് തിരയുന്നത് പിന്തുണയ്ക്കുന്നുവെങ്കിൽ, [`Pattern`] trait-ന്റെ അനുബന്ധ [`Searcher`] തരം ഇത് നടപ്പിലാക്കും.
///
///
/// ഈ trait നൽകിയ സൂചിക ശ്രേണികൾ‌വിപരീത തിരയലുമായി പൊരുത്തപ്പെടുന്നതിന് ആവശ്യമില്ല.
///
/// ഈ trait സുരക്ഷിതമല്ലാത്തതായി അടയാളപ്പെടുത്തിയതിന്റെ കാരണത്താൽ, അവരെ രക്ഷാകർതൃ trait [`Searcher`] കാണുക.
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// പിന്നിൽ നിന്ന് ആരംഭിക്കുന്ന അടുത്ത തിരയൽ ഘട്ടം നടപ്പിലാക്കുന്നു.
    ///
    /// - `haystack[a..b]` പാറ്റേണുമായി പൊരുത്തപ്പെടുന്നെങ്കിൽ [`Match(a, b)`][SearchStep::Match] നൽകുന്നു.
    /// - ഭാഗികമായിപ്പോലും `haystack[a..b]` പാറ്റേണുമായി പൊരുത്തപ്പെടാൻ കഴിയുന്നില്ലെങ്കിൽ [`Reject(a, b)`][SearchStep::Reject] നൽകുന്നു.
    /// - ഹെയ്‌സ്റ്റാക്കിന്റെ ഓരോ ബൈറ്റും സന്ദർശിച്ചിട്ടുണ്ടെങ്കിൽ [`Done`][SearchStep::Done] നൽകുന്നു
    ///
    /// ഒരു [`Done`][SearchStep::Done] വരെയുള്ള [`Match`][SearchStep::Match], [`Reject`][SearchStep::Reject] മൂല്യങ്ങളുടെ സ്ട്രീമിൽ തൊട്ടടുത്തുള്ളതും ഓവർലാപ്പുചെയ്യാത്തതും മുഴുവൻ ഹെയ്സ്റ്റാക്കിനെ മൂടുന്നതും utf8 അതിരുകളിൽ കിടക്കുന്നതുമായ സൂചിക ശ്രേണികൾ അടങ്ങിയിരിക്കും.
    ///
    ///
    /// ഒരു [`Match`][SearchStep::Match] ഫലത്തിൽ പൊരുത്തപ്പെടുന്ന പാറ്റേൺ മുഴുവനും അടങ്ങിയിരിക്കണം, എന്നിരുന്നാലും [`Reject`][SearchStep::Reject] ഫലങ്ങൾ അനിയന്ത്രിതമായി സമീപത്തുള്ള പല ശകലങ്ങളായി വിഭജിക്കാം.രണ്ട് ശ്രേണികൾക്കും പൂജ്യം നീളം ഉണ്ടായിരിക്കാം.
    ///
    /// ഉദാഹരണമായി, `"aaa"` പാറ്റേണും ഹെയ്‌സ്റ്റാക്ക് `"cbaaaaab"` ഉം `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// അടുത്ത [`Match`][SearchStep::Match] ഫലം കണ്ടെത്തുന്നു.
    /// [`next_back()`][ReverseSearcher::next_back] കാണുക.
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// അടുത്ത [`Reject`][SearchStep::Reject] ഫലം കണ്ടെത്തുന്നു.
    /// [`next_back()`][ReverseSearcher::next_back] കാണുക.
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// [`DoubleEndedIterator`] നടപ്പിലാക്കലിനായി ഒരു [`ReverseSearcher`] ഉപയോഗിക്കാമെന്ന് പ്രകടിപ്പിക്കുന്നതിനുള്ള ഒരു മാർക്കർ trait.
///
/// ഇതിനായി, [`Searcher`], [`ReverseSearcher`] എന്നിവയുടെ impl ഈ നിബന്ധനകൾ പാലിക്കേണ്ടതുണ്ട്:
///
/// - `next()`-ന്റെ എല്ലാ ഫലങ്ങളും വിപരീത ക്രമത്തിൽ `next_back()` ന്റെ ഫലങ്ങൾക്ക് സമാനമായിരിക്കണം.
/// - `next()` ഒപ്പം `next_back()` മൂല്യങ്ങളുടെ ശ്രേണിയുടെ രണ്ട് അറ്റങ്ങളായി പെരുമാറേണ്ടതുണ്ട്, അതായത് അവയ്ക്ക് "walk past each other" ചെയ്യാൻ കഴിയില്ല.
///
/// # Examples
///
/// `char::Searcher` ഒരു `DoubleEndedSearcher` ആണ്, കാരണം ഒരു [`char`] തിരയുന്നതിന് ഒരു സമയം ഒരെണ്ണം മാത്രം നോക്കേണ്ടതുണ്ട്, അത് രണ്ട് അറ്റത്തുനിന്നും ഒരേപോലെ പ്രവർത്തിക്കുന്നു.
///
/// `(&str)::Searcher` `DoubleEndedSearcher` അല്ല കാരണം ഹെയ്‌സ്റ്റാക്കിലെ `"aa"` പാറ്റേൺ `"aaa"` അല്ലെങ്കിൽ `"a[aa]"` ആയി പൊരുത്തപ്പെടുന്നു, ഏത് ഭാഗത്ത് നിന്ന് തിരഞ്ഞു എന്നതിനെ ആശ്രയിച്ചിരിക്കുന്നു.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// ചാർ‌ട്ടറിനായി ഇം‌പ്ൾ‌ചെയ്യുക
/////////////////////////////////////////////////////////////////////////////

/// `<char as Pattern<'a>>::Searcher`-നായുള്ള അനുബന്ധ തരം.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // സുരക്ഷാ മാറ്റമില്ലാത്തത്: `finger`/`finger_back` `haystack` ന്റെ സാധുവായ utf8 ബൈറ്റ് സൂചിക ആയിരിക്കണം ഈ മാറ്റത്തെ *അടുത്ത_മാച്ചിലും അടുത്ത_മാച്ച്_ബാക്കിലും* തകർക്കാൻ കഴിയും, എന്നിരുന്നാലും അവ സാധുവായ കോഡ് പോയിന്റ് അതിർത്തികളിൽ വിരലുകൊണ്ട് പുറത്തുകടക്കണം.
    //
    //
    /// `finger` ഫോർവേഡ് തിരയലിന്റെ നിലവിലെ ബൈറ്റ് സൂചികയാണ്.
    /// അതിന്റെ സൂചികയിലെ ബൈറ്റിന് മുമ്പായി ഇത് നിലവിലുണ്ടെന്ന് സങ്കൽപ്പിക്കുക, അതായത്
    /// `haystack[finger]` ഫോർവേഡ് തിരയൽ സമയത്ത് ഞങ്ങൾ പരിശോധിക്കേണ്ട സ്ലൈസിന്റെ ആദ്യ ബൈറ്റാണ്
    ///
    finger: usize,
    /// `finger_back` വിപരീത തിരയലിന്റെ നിലവിലെ ബൈറ്റ് സൂചികയാണ്.
    /// അതിന്റെ സൂചികയിലെ ബൈറ്റിന് ശേഷം അത് നിലവിലുണ്ടെന്ന് സങ്കൽപ്പിക്കുക, അതായത്
    /// ഫോർ‌വേർ‌ഡ് തിരയൽ‌സമയത്ത്‌ഞങ്ങൾ‌പരിശോധിക്കേണ്ട സ്ലൈസിന്റെ അവസാന ബൈറ്റാണ് ഹെയ്‌സ്റ്റാക്ക് [ഫിംഗർ‌ബാക്ക്, 1](അതിനാൽ‌next_back()) ലേക്ക് വിളിക്കുമ്പോൾ‌പരിശോധിക്കുന്ന ആദ്യ ബൈറ്റ്‌.
    ///
    finger_back: usize,
    /// തിരയുന്ന പ്രതീകം
    needle: char,

    // സുരക്ഷാ മാറ്റം: `utf8_size` 5-ൽ കുറവായിരിക്കണം
    /// utf8 ൽ എൻ‌കോഡുചെയ്യുമ്പോൾ `needle` ബൈറ്റുകളുടെ എണ്ണം എടുക്കുന്നു.
    utf8_size: usize,
    /// `needle`-ന്റെ utf8 എൻ‌കോഡുചെയ്‌ത പകർപ്പ്
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // സുരക്ഷ: `get_unchecked`-ന്റെ 1-4 ഗ്യാരണ്ടി സുരക്ഷ
        // 1. `self.finger` ഒപ്പം `self.finger_back` യൂണികോഡ് അതിർത്തികളിൽ സൂക്ഷിക്കുന്നു (ഇത് മാറ്റമില്ലാത്തതാണ്)
        // 2. `self.finger >= 0` കാരണം ഇത് 0 ൽ ആരംഭിച്ച് വർദ്ധിക്കുന്നു
        // 3. `self.finger < self.finger_back` അല്ലാത്തപക്ഷം `iter` ചാർജർ `SearchStep::Done` നൽകും
        // 4.
        // `self.finger` `self.finger_back` അവസാനം ആരംഭിക്കുകയും കുറയുകയും ചെയ്യുന്നതിനാൽ ഹെയ്‌സ്റ്റാക്കിന്റെ അവസാനത്തിന് മുമ്പായി വരുന്നു
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // utf-8 ആയി വീണ്ടും എൻ‌കോഡുചെയ്യാതെ നിലവിലെ പ്രതീകത്തിന്റെ ബൈറ്റ് ഓഫ്‌സെറ്റ് ചേർക്കുക
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // അവസാന പ്രതീകം കണ്ടെത്തിയതിനുശേഷം ഹെയ്‌സ്റ്റാക്ക് നേടുക
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // utf8 എൻ‌കോഡുചെയ്‌ത സൂചിയുടെ അവസാന ബൈറ്റ് സുരക്ഷിതം: ഞങ്ങൾക്ക് `utf8_size < 5` എന്ന ഒരു മാറ്റമില്ല
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // പ്രതീകത്തിന്റെ അവസാന ബൈറ്റിനായി ഞങ്ങൾ മെംക്രഡ് ചെയ്തതിനാൽ പുതിയ വിരൽ ഞങ്ങൾ കണ്ടെത്തിയ ബൈറ്റിന്റെ സൂചികയാണ്, പ്ലസ് വൺ.
                //
                // ഇത് എല്ലായ്പ്പോഴും ഒരു UTF8 അതിർത്തിയിൽ ഒരു വിരൽ നൽകില്ലെന്നത് ശ്രദ്ധിക്കുക.
                // ഞങ്ങളുടെ പ്രതീകം * കണ്ടെത്തിയില്ലെങ്കിൽ, 3-ബൈറ്റ് അല്ലെങ്കിൽ 4-ബൈറ്റ് പ്രതീകത്തിന്റെ അവസാനത്തെ ബൈറ്റിലേക്ക് ഞങ്ങൾ സൂചികയിലാക്കിയിരിക്കാം.
                // സാധുവായ അടുത്ത ആരംഭ ബൈറ്റിലേക്ക് പോകാൻ ഞങ്ങൾക്ക് കഴിയില്ല, കാരണം character (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81` പോലുള്ള ഒരു പ്രതീകം മൂന്നാമത്തേത് തിരയുമ്പോൾ എല്ലായ്പ്പോഴും രണ്ടാമത്തെ ബൈറ്റ് കണ്ടെത്തും.
                //
                //
                // എന്നിരുന്നാലും, ഇത് പൂർണ്ണമായും കുഴപ്പമില്ല.
                // self.finger ഒരു UTF8 അതിർത്തിയിലാണെന്നത് ഞങ്ങൾക്ക് മാറ്റമില്ലാത്തപ്പോൾ, ഈ രീതി ഈ രീതിയെ ആശ്രയിക്കുന്നില്ല (ഇത് CharSearcher::next())-നെ ആശ്രയിച്ചിരിക്കുന്നു.
                //
                // സ്‌ട്രിംഗിന്റെ അവസാനത്തിൽ എത്തുമ്പോഴോ എന്തെങ്കിലും കണ്ടെത്തിയാൽ മാത്രമേ ഞങ്ങൾ ഈ രീതിയിൽ നിന്ന് പുറത്തുകടക്കുകയുള്ളൂ.ഞങ്ങൾ എന്തെങ്കിലും കണ്ടെത്തുമ്പോൾ `finger` ഒരു UTF8 അതിർത്തിയിലേക്ക് സജ്ജമാക്കും.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // ഒന്നും കണ്ടെത്തിയില്ല, പുറത്തുകടക്കുക
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // തിരയൽ trait-ൽ നിന്നുള്ള സ്ഥിരസ്ഥിതി നടപ്പാക്കൽ ഉപയോഗിക്കാൻ അടുത്ത_റജക്റ്റ് അനുവദിക്കുക
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // സുരക്ഷ: മുകളിലുള്ള next() നായുള്ള അഭിപ്രായം കാണുക
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // utf-8 ആയി വീണ്ടും എൻ‌കോഡുചെയ്യാതെ നിലവിലെ പ്രതീകത്തിന്റെ ബൈറ്റ് ഓഫ്‌സെറ്റ് കുറയ്ക്കുക
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // അവസാനം തിരഞ്ഞ പ്രതീകം ഉൾപ്പെടുത്താതെ ഹെയ്‌സ്റ്റാക്ക് നേടുക
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // utf8 എൻ‌കോഡുചെയ്‌ത സൂചിയുടെ അവസാന ബൈറ്റ് സുരക്ഷിതം: ഞങ്ങൾക്ക് `utf8_size < 5` എന്ന ഒരു മാറ്റമില്ല
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // self.finger ഓഫ്‌സെറ്റ് ചെയ്ത ഒരു സ്ലൈസ് ഞങ്ങൾ തിരഞ്ഞു, യഥാർത്ഥ സൂചിക വീണ്ടെടുക്കുന്നതിന് self.finger ചേർക്കുക
                //
                let index = self.finger + index;
                // ഞങ്ങൾ കണ്ടെത്താൻ ആഗ്രഹിക്കുന്ന ബൈറ്റിന്റെ സൂചിക memrchr നൽകും.
                // ഒരു ASCII പ്രതീകത്തിന്റെ കാര്യത്തിൽ, ഇത് തീർച്ചയായും ഞങ്ങളുടെ പുതിയ വിരൽ ആയിരിക്കണമെന്ന് ഞങ്ങൾ ആഗ്രഹിക്കുന്നു (റിവേഴ്സ് ആവർത്തനത്തിന്റെ മാതൃകയിൽ കണ്ടെത്തിയ "after" ചാർ‌).
                //
                // മൾട്ടിബൈറ്റ് പ്രതീകങ്ങൾക്കായി, ASCII നേക്കാൾ കൂടുതൽ ബൈറ്റുകളുടെ എണ്ണം ഞങ്ങൾ ഒഴിവാക്കേണ്ടതുണ്ട്
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // പ്രതീകം കണ്ടെത്തുന്നതിനുമുമ്പ് വിരൽ നീക്കുക (അതായത്, അതിന്റെ ആരംഭ സൂചികയിൽ)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // ഞങ്ങൾക്ക് ഇവിടെ ഫിംഗർ_ബാക്ക്=സൂചിക, വലുപ്പം + 1 ഉപയോഗിക്കാൻ കഴിയില്ല.
                // വ്യത്യസ്‌ത വലുപ്പത്തിലുള്ള പ്രതീകത്തിന്റെ അവസാന ചാർ‌(അല്ലെങ്കിൽ‌മറ്റൊരു പ്രതീകത്തിന്റെ മധ്യ ബൈറ്റ്‌) ഞങ്ങൾ‌കണ്ടെത്തിയാൽ‌, ഫിംഗർ‌ബാക്ക് `index` ലേക്ക് താഴ്‌ത്തേണ്ടതുണ്ട്.
                // ഇത് സമാനമായി `finger_back` ന് ഇനി ഒരു അതിർത്തിയിൽ വരാനുള്ള സാധ്യതയില്ല, പക്ഷേ ഞങ്ങൾ ഈ ഫംഗ്ഷനിൽ നിന്ന് ഒരു അതിർത്തിയിൽ നിന്ന് പുറത്തുകടക്കുന്നതിനാലോ അല്ലെങ്കിൽ ഹെയ്സ്റ്റാക്ക് പൂർണ്ണമായും തിരഞ്ഞപ്പോഴോ ഇത് ശരിയാണ്.
                //
                //
                // നെക്സ്റ്റ്_മാച്ചിൽ നിന്ന് വ്യത്യസ്തമായി ഇതിന് utf-8-ൽ ആവർത്തിച്ചുള്ള ബൈറ്റുകളുടെ പ്രശ്‌നമില്ല, കാരണം ഞങ്ങൾ അവസാന ബൈറ്റിനായി തിരയുന്നു, വിപരീതമായി തിരയുമ്പോൾ മാത്രമേ ഞങ്ങൾക്ക് അവസാന ബൈറ്റ് കണ്ടെത്താൻ കഴിയൂ.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // ഒന്നും കണ്ടെത്തിയില്ല, പുറത്തുകടക്കുക
                return None;
            }
        }
    }

    // തിരയൽ trait-ൽ നിന്നുള്ള സ്ഥിരസ്ഥിതി നടപ്പാക്കൽ ഉപയോഗിക്കാൻ next_reject_back അനുവദിക്കുക
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// തന്നിരിക്കുന്ന [`char`] ന് തുല്യമായ പ്രതീകങ്ങൾക്കായുള്ള തിരയലുകൾ.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// ഒരു മൾട്ടിചാർക് റാപ്പറിനായി ഇംപ്ലി ചെയ്യുക
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // നിലവിലെ ചാർ‌ട്ടിന്റെ ദൈർ‌ഘ്യം കണ്ടെത്തുന്നതിന് ആന്തരിക ബൈറ്റ് സ്ലൈസ് ഇറ്ററേറ്ററിന്റെ ദൈർ‌ഘ്യം താരതമ്യം ചെയ്യുക
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // നിലവിലെ ചാർ‌ട്ടിന്റെ ദൈർ‌ഘ്യം കണ്ടെത്തുന്നതിന് ആന്തരിക ബൈറ്റ് സ്ലൈസ് ഇറ്ററേറ്ററിന്റെ ദൈർ‌ഘ്യം താരതമ്യം ചെയ്യുക
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// &[Char] എന്നതിനായുള്ള Impl
/////////////////////////////////////////////////////////////////////////////

// Todo: അർത്ഥത്തിലെ അവ്യക്തത കാരണം മാറ്റുക/നീക്കംചെയ്യുക.

/// `<&[char] as Pattern<'a>>::Searcher`-നായുള്ള അനുബന്ധ തരം.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// സ്ലൈസിലെ ഏതെങ്കിലും [`ചാർ`] ന് തുല്യമായ പ്രതീകങ്ങൾക്കായുള്ള തിരയലുകൾ.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// F: FnMut(char)-> bool എന്നതിനായുള്ള Impl
/////////////////////////////////////////////////////////////////////////////

/// `<F as Pattern<'a>>::Searcher`-നായുള്ള അനുബന്ധ തരം.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// തന്നിരിക്കുന്ന പ്രവചനവുമായി പൊരുത്തപ്പെടുന്ന [`ചാർ`] കൾക്കായി തിരയുന്നു.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// &&സ്ട്രിംഗിനായുള്ള Impl
/////////////////////////////////////////////////////////////////////////////

/// `&str` impl-ലേക്ക് പ്രതിനിധികൾ.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// &str-നായുള്ള Impl
/////////////////////////////////////////////////////////////////////////////

/// അനുവദിക്കാത്ത സബ്‌സ്ട്രിംഗ് തിരയൽ.
///
/// ഓരോ പ്രതീക അതിർത്തിയിലും ശൂന്യമായ പൊരുത്തങ്ങൾ നൽകുന്നതുപോലെ `""` പാറ്റേൺ കൈകാര്യം ചെയ്യും.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// പുൽത്തകിടിയുടെ മുൻവശത്ത് പാറ്റേൺ പൊരുത്തപ്പെടുന്നുണ്ടോയെന്ന് പരിശോധിക്കുന്നു.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// പൊരുത്തപ്പെടുന്നെങ്കിൽ, ഹെയ്‌സ്റ്റാക്കിന്റെ മുൻഭാഗത്ത് നിന്ന് പാറ്റേൺ നീക്കംചെയ്യുന്നു.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // സുരക്ഷ: പ്രിഫിക്‌സ് നിലവിലുണ്ടെന്ന് സ്ഥിരീകരിച്ചു.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// പാറ്റേൺ പുൽത്തകിടിയുടെ പിൻഭാഗത്ത് പൊരുത്തപ്പെടുന്നുണ്ടോയെന്ന് പരിശോധിക്കുന്നു.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// പൊരുത്തപ്പെടുന്നെങ്കിൽ, ഹെയ്‌സ്റ്റാക്കിന്റെ പിന്നിൽ നിന്ന് പാറ്റേൺ നീക്കംചെയ്യുന്നു.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // സുരക്ഷ: സഫിക്‌സ് നിലവിലുണ്ടെന്ന് സ്ഥിരീകരിച്ചു.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// ടു വേ സബ്‌സ്ട്രിംഗ് തിരയൽ
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// `<&str as Pattern<'a>>::Searcher`-നായുള്ള അനുബന്ധ തരം.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // ശൂന്യ സൂചി എല്ലാ ചാർ‌ട്ടുകളും നിരസിക്കുകയും അവയ്ക്കിടയിലുള്ള എല്ലാ ശൂന്യമായ സ്ട്രിംഗുമായി പൊരുത്തപ്പെടുകയും ചെയ്യുന്നു
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // ശരിയായ പൊരുത്തപ്പെടുത്തൽ ഉള്ളിടത്തോളം കാലം ചാർ അതിർത്തികളിൽ വിഭജിക്കുന്ന സാധുവായ *മാച്ച്* സൂചികകൾ ടു വേസർച്ചർ നിർമ്മിക്കുന്നു, കൂടാതെ ഹെയ്സ്റ്റാക്കും സൂചിയും സാധുവായ UTF-8 *അൽഗോരിതത്തിൽ നിന്നുള്ള നിരസിക്കുന്നു* ഏത് സൂചികകളിലും വീഴാം, പക്ഷേ ഞങ്ങൾ അവയെ സ്വമേധയാ അടുത്ത പ്രതീക അതിർത്തിയിലേക്ക് കൊണ്ടുപോകും അതിനാൽ അവ utf-8 സുരക്ഷിതമാണ്.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // അടുത്ത ചാർ അതിർത്തിയിലേക്ക് പോകുക
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // രണ്ട് കേസുകളും പ്രത്യേകമായി സ്പെഷ്യലൈസ് ചെയ്യാൻ കംപൈലറെ പ്രോത്സാഹിപ്പിക്കുന്നതിന് `true`, `false` കേസുകൾ എഴുതുക.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // അടുത്ത ചാർ അതിർത്തിയിലേക്ക് പോകുക
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // `next_match` പോലെ `true`, `false` എന്നിവ എഴുതുക
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// ടു-വേ സബ്‌സ്ട്രിംഗ് തിരയൽ അൽ‌ഗോരിത്തിന്റെ ആന്തരിക അവസ്ഥ.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// നിർണായക ഫാക്ടറൈസേഷൻ സൂചിക
    crit_pos: usize,
    /// വിപരീത സൂചിക്ക് നിർണായക ഫാക്ടറൈസേഷൻ സൂചിക
    crit_pos_back: usize,
    period: usize,
    /// `byteset` ഒരു വിപുലീകരണമാണ് (ടു വേ അൽ‌ഗോരിത്തിന്റെ ഭാഗമല്ല);
    /// ഇത് 64-ബിറ്റ് "fingerprint" ആണ്, അവിടെ ഓരോ സെറ്റ് ബിറ്റ് `j` സൂചിയിലുള്ള ഒരു (ബൈറ്റ്&63)==j എന്നതിന് സമാനമാണ്.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// സൂചിയിലേക്കുള്ള സൂചിക ഞങ്ങൾ മുമ്പ് പൊരുത്തപ്പെട്ടു
    memory: usize,
    /// സൂചി സൂചികയിലേക്ക് സൂചിപ്പിക്കുക, അതിനുശേഷം ഞങ്ങൾ ഇതിനകം പൊരുത്തപ്പെട്ടു
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // ഇവിടെ എന്താണ് നടക്കുന്നത് എന്നതിനെക്കുറിച്ച് പ്രത്യേകിച്ച് വായിക്കാവുന്ന ഒരു വിശദീകരണം ക്രോച്ചെമോർ, റൈറ്ററുടെ പുസ്തകം "Text Algorithms", ch 13 എന്നിവയിൽ കാണാം.
        // P-ൽ "Algorithm CP"-നുള്ള കോഡ് പ്രത്യേകമായി കാണുക.
        // 323.
        //
        // എന്താണ് സംഭവിക്കുന്നത് എന്നത് നമുക്ക് സൂചിയുടെ ചില നിർണായക ഫാക്ടറൈസേഷൻ (u, v) ഉണ്ട്, ഒപ്പം u&v [.. period] ന്റെ സഫിക്‌സ് ആണോ എന്ന് നിർണ്ണയിക്കാൻ ഞങ്ങൾ ആഗ്രഹിക്കുന്നു.
        // അങ്ങനെയാണെങ്കിൽ, ഞങ്ങൾ "Algorithm CP1" ഉപയോഗിക്കുന്നു.
        // അല്ലെങ്കിൽ ഞങ്ങൾ "Algorithm CP2" ഉപയോഗിക്കുന്നു, ഇത് സൂചിയുടെ കാലയളവ് വലുതാകുമ്പോൾ ഒപ്റ്റിമൈസ് ചെയ്യുന്നു.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // ഹ്രസ്വ കാലയളവ് കേസ്-വിപരീത സൂചി x=u 'v' എവിടെ | v '|<period(x).
            //
            // ഇതിനകം അറിയപ്പെടുന്ന കാലയളവിൽ ഇത് വേഗത്തിലാക്കുന്നു.
            // X= "acba" പോലുള്ള ഒരു കേസ് വിപരീതമായി ഫാക്റ്ററേറ്റ് ചെയ്യപ്പെടുമെന്നത് ശ്രദ്ധിക്കുക (ക്രിട്ട്_പോസ്=1, പിരീഡ്=3) റിവേഴ്‌സിലെ ഏകദേശ കാലയളവിൽ ഫാക്റ്ററേറ്റ് ചെയ്യുമ്പോൾ (ക്രിട്ട്_പോസ്=2, പിരീഡ്=2).
            // തന്നിരിക്കുന്ന റിവേഴ്സ് ഫാക്ടറൈസേഷൻ ഞങ്ങൾ ഉപയോഗിക്കുന്നു, പക്ഷേ കൃത്യമായ കാലയളവ് നിലനിർത്തുന്നു.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // ദൈർഘ്യമേറിയ കേസ്-ഞങ്ങൾക്ക് യഥാർത്ഥ കാലയളവിലേക്ക് ഒരു ഏകദേശ കണക്കുണ്ട്, മന or പാഠമാക്കരുത്.
            //
            //
            // കുറഞ്ഞ പരിധിയിലുള്ള max(|u|, |v|) + 1 പ്രകാരം കാലയളവ് ഏകദേശം കണക്കാക്കുക.
            // മുന്നോട്ടും പിന്നോട്ടും തിരയുന്നതിനായി നിർണായക ഫാക്ടറൈസേഷൻ കാര്യക്ഷമമാണ്.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // കാലയളവ് ദൈർഘ്യമേറിയതാണെന്ന് സൂചിപ്പിക്കുന്നതിനുള്ള ഡമ്മി മൂല്യം
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // ടു-വേയുടെ പ്രധാന ആശയങ്ങളിലൊന്ന്, ഞങ്ങൾ സൂചി രണ്ട് ഭാഗങ്ങളായി (u, v) ഫാക്ടറൈസ് ചെയ്യുകയും ഇടത്തുനിന്ന് വലത്തോട്ട് സ്കാൻ ചെയ്ത് പുൽക്കൊടിയിൽ v കണ്ടെത്താൻ ശ്രമിക്കുകയും ചെയ്യുന്നു എന്നതാണ്.
    // V പൊരുത്തപ്പെടുന്നുവെങ്കിൽ, വലത്തോട്ടും ഇടത്തോട്ടും സ്കാൻ ചെയ്തുകൊണ്ട് ഞങ്ങൾ നിങ്ങളെ പൊരുത്തപ്പെടുത്താൻ ശ്രമിക്കുന്നു.
    // ഒരു പൊരുത്തക്കേട് നേരിടുമ്പോൾ നമുക്ക് എത്ര ദൂരം ചാടാം എന്നത് എല്ലാം (u, v) സൂചിക്ക് ഒരു നിർണായക ഘടകമാണ് എന്ന വസ്തുതയെ അടിസ്ഥാനമാക്കിയുള്ളതാണ്.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` `self.position` അതിന്റെ കഴ്‌സറായി ഉപയോഗിക്കുന്നു
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // സ്ഥാനത്ത് തിരയാൻ ഞങ്ങൾക്ക് ഇടമുണ്ടോയെന്ന് പരിശോധിക്കുക + സ്ലൈസുകൾ ഐസൈസിന്റെ പരിധിയാൽ പരിമിതപ്പെടുത്തിയിട്ടുണ്ടെന്ന് ഞങ്ങൾ കരുതുന്നുവെങ്കിൽ സൂചി_ലാസ്റ്റിന് കവിഞ്ഞൊഴുകാൻ കഴിയില്ല.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // ഞങ്ങളുടെ സബ്‌സ്ട്രിംഗുമായി ബന്ധമില്ലാത്ത വലിയ ഭാഗങ്ങൾ വേഗത്തിൽ ഒഴിവാക്കുക
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // സൂചിയുടെ വലത് ഭാഗം പൊരുത്തപ്പെടുന്നുണ്ടോയെന്ന് കാണുക
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // സൂചിയുടെ ഇടത് ഭാഗം പൊരുത്തപ്പെടുന്നുണ്ടോയെന്ന് കാണുക
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // ഞങ്ങൾ ഒരു പൊരുത്തം കണ്ടെത്തി!
            let match_pos = self.position;

            // Note: ഓവർലാപ്പിംഗ് പൊരുത്തങ്ങൾ ഉണ്ടാകുന്നതിന് needle.len() ന് പകരം self.period ചേർക്കുക
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // ഓവർലാപ്പുചെയ്യുന്ന മത്സരങ്ങൾക്കായി needle.len(), self.period എന്ന് സജ്ജമാക്കുക
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // `next()`-ലെ ആശയങ്ങൾ പിന്തുടരുന്നു.
    //
    // നിർവചനങ്ങൾ സമമിതിയാണ്, period(x) = period(reverse(x)), local_period(u, v) = local_period(reverse(v), reverse(u)), അതിനാൽ (u, v) ഒരു നിർണായക ഫാക്ടറൈസേഷനാണെങ്കിൽ, (reverse(v), reverse(u)).
    //
    //
    // വിപരീത കേസിനായി ഞങ്ങൾ x=u 'v' (ഫീൽഡ് `crit_pos_back`) എന്ന നിർണ്ണായക ഫാക്ടറൈസേഷൻ കണക്കുകൂട്ടി.ഞങ്ങൾക്ക് | u | ആവശ്യമാണ്ഫോർവേഡ് കേസിനായി <period(x), അങ്ങനെ | v '|വിപരീതത്തിനായി <period(x).
    //
    // ഹെയ്‌സ്റ്റാക്കിലൂടെ വിപരീതമായി തിരയുന്നതിന്, വിപരീത സൂചി ഉപയോഗിച്ച് വിപരീത ഹേസ്റ്റാക്കിലൂടെ ഞങ്ങൾ മുന്നോട്ട് തിരയുന്നു, ആദ്യം യു ', തുടർന്ന് വി' എന്നിവയുമായി പൊരുത്തപ്പെടുന്നു.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` `self.end` അതിന്റെ കഴ്‌സറായി ഉപയോഗിക്കുന്നു-അതിനാൽ `next()`, `next_back()` എന്നിവ സ്വതന്ത്രമാണ്.
        //
        let old_end = self.end;
        'search: loop {
            // അവസാനം തിരയാൻ ഞങ്ങൾക്ക് ഇടമുണ്ടോയെന്ന് പരിശോധിക്കുക, കൂടുതൽ ഇടമില്ലാത്തപ്പോൾ needle.len() ചുറ്റിക്കറങ്ങും, പക്ഷേ സ്ലൈസ് ദൈർഘ്യ പരിധി കാരണം ഇതിന് ഒരിക്കലും ഹെയ്‌സ്റ്റാക്കിന്റെ നീളത്തിലേക്ക് പൊതിയാൻ കഴിയില്ല.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // ഞങ്ങളുടെ സബ്‌സ്ട്രിംഗുമായി ബന്ധമില്ലാത്ത വലിയ ഭാഗങ്ങൾ വേഗത്തിൽ ഒഴിവാക്കുക
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // സൂചിയുടെ ഇടത് ഭാഗം പൊരുത്തപ്പെടുന്നുണ്ടോയെന്ന് കാണുക
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // സൂചിയുടെ വലത് ഭാഗം പൊരുത്തപ്പെടുന്നുണ്ടോയെന്ന് കാണുക
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // ഞങ്ങൾ ഒരു പൊരുത്തം കണ്ടെത്തി!
            let match_pos = self.end - needle.len();
            // Note: ഓവർലാപ്പിംഗ് പൊരുത്തങ്ങൾ ഉണ്ടാകുന്നതിന് needle.len()-ന് പകരം ഉപ self.period
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // `arr`-ന്റെ പരമാവധി സഫിക്‌സ് കണക്കുകൂട്ടുക.
    //
    // `arr`-ന്റെ സാധ്യമായ നിർണായക ഫാക്ടറൈസേഷനാണ് (u, v) പരമാവധി സഫിക്‌സ്.
    //
    // റിട്ടേൺസ് (`i`, `p`), ഇവിടെ `i` എന്നത് v യുടെ ആരംഭ സൂചികയും `p` എന്നത് v യുടെ കാലഘട്ടവുമാണ്.
    //
    // `order_greater` ലെക്സിക്കൽ ഓർഡർ `<` അല്ലെങ്കിൽ `>` ആണോ എന്ന് നിർണ്ണയിക്കുന്നു.
    // രണ്ട് ഓർഡറുകളും കണക്കാക്കണം-ഏറ്റവും വലിയ `i` ഉള്ള ഓർഡറിംഗ് ഒരു നിർണായക ഫാക്ടറൈസേഷൻ നൽകുന്നു.
    //
    //
    // ദീർഘകാല കേസുകളിൽ, ഫലമായുണ്ടാകുന്ന കാലയളവ് കൃത്യമല്ല (ഇത് വളരെ ചെറുതാണ്).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // പേപ്പറിലെ i യുമായി യോജിക്കുന്നു
        let mut right = 1; // പേപ്പറിൽ ജെ
        let mut offset = 0; // പേപ്പറിൽ k ന് യോജിക്കുന്നു, പക്ഷേ 0 മുതൽ ആരംഭിക്കുന്നു
        // 0 അടിസ്ഥാനമാക്കിയുള്ള സൂചികയുമായി പൊരുത്തപ്പെടുന്നതിന്.
        let mut period = 1; // പേപ്പറിൽ പി

        while let Some(&a) = arr.get(right + offset) {
            // `left` `right` ആയിരിക്കുമ്പോൾ ഇൻ‌ബ ounds ണ്ട് ആകും.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // സഫിക്‌സ് ചെറുതാണ്, കാലയളവ് ഇതുവരെ പൂർ‌വ്വപ്രത്യയമാണ്.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // നിലവിലെ കാലയളവ് ആവർത്തിക്കുന്നതിലൂടെ മുന്നേറുക.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // സഫിക്‌സ് വലുതാണ്, നിലവിലെ സ്ഥാനത്ത് നിന്ന് ആരംഭിക്കുക.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // `arr` ന്റെ വിപരീതത്തിന്റെ പരമാവധി സഫിക്‌സ് കണക്കുകൂട്ടുക.
    //
    // `arr`-ന്റെ സാധ്യമായ നിർണായക ഫാക്ടറൈസേഷനാണ് (u ', v') പരമാവധി സഫിക്‌സ്.
    //
    // `i` നൽകുന്നു, അവിടെ `i` എന്നത് v 'ന്റെ ആരംഭ സൂചികയാണ്, പിന്നിൽ നിന്ന്;
    // `known_period` കാലയളവ് എത്തുമ്പോൾ ഉടൻ മടങ്ങുന്നു.
    //
    // `order_greater` ലെക്സിക്കൽ ഓർഡർ `<` അല്ലെങ്കിൽ `>` ആണോ എന്ന് നിർണ്ണയിക്കുന്നു.
    // രണ്ട് ഓർഡറുകളും കണക്കാക്കണം-ഏറ്റവും വലിയ `i` ഉള്ള ഓർഡറിംഗ് ഒരു നിർണായക ഫാക്ടറൈസേഷൻ നൽകുന്നു.
    //
    //
    // ദീർഘകാല കേസുകളിൽ, ഫലമായുണ്ടാകുന്ന കാലയളവ് കൃത്യമല്ല (ഇത് വളരെ ചെറുതാണ്).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // പേപ്പറിലെ i യുമായി യോജിക്കുന്നു
        let mut right = 1; // പേപ്പറിൽ ജെ
        let mut offset = 0; // പേപ്പറിൽ k ന് യോജിക്കുന്നു, പക്ഷേ 0 മുതൽ ആരംഭിക്കുന്നു
        // 0 അടിസ്ഥാനമാക്കിയുള്ള സൂചികയുമായി പൊരുത്തപ്പെടുന്നതിന്.
        let mut period = 1; // പേപ്പറിൽ പി
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // സഫിക്‌സ് ചെറുതാണ്, കാലയളവ് ഇതുവരെ പൂർ‌വ്വപ്രത്യയമാണ്.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // നിലവിലെ കാലയളവ് ആവർത്തിക്കുന്നതിലൂടെ മുന്നേറുക.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // സഫിക്‌സ് വലുതാണ്, നിലവിലെ സ്ഥാനത്ത് നിന്ന് ആരംഭിക്കുക.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// പൊരുത്തപ്പെടാത്തവയെ എത്രയും വേഗം ഒഴിവാക്കാനോ അല്ലെങ്കിൽ നിരസിക്കുന്നവ താരതമ്യേന വേഗത്തിൽ വേഗത്തിൽ പുറപ്പെടുവിക്കുന്ന മോഡിൽ പ്രവർത്തിക്കാനോ ടുവേ വേ സ്ട്രാറ്റജി അൽഗോരിതം അനുവദിക്കുന്നു.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// കഴിയുന്നത്ര വേഗത്തിൽ ഇടവേളകൾ പൊരുത്തപ്പെടുത്തുന്നതിന് ഒഴിവാക്കുക
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// പതിവായി നിരസിക്കുക
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}