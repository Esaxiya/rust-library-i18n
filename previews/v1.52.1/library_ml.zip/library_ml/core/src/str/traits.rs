//! `str`-നായുള്ള Trait നടപ്പിലാക്കലുകൾ.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// സ്ട്രിംഗുകളുടെ ക്രമം നടപ്പിലാക്കുന്നു.
///
/// സ്ട്രിംഗുകളെ അവയുടെ ബൈറ്റ് മൂല്യങ്ങൾ ഉപയോഗിച്ച് [lexicographically](Ord#lexicographical-comparison) ക്രമീകരിച്ചിരിക്കുന്നു.
/// ഇത് കോഡ് ചാർട്ടുകളിലെ സ്ഥാനങ്ങളെ അടിസ്ഥാനമാക്കി യൂണിക്കോഡ് കോഡ് പോയിന്റുകൾ ഓർഡർ ചെയ്യുന്നു.
/// ഇത് "alphabetical" ഓർഡറിന് തുല്യമായിരിക്കണമെന്നില്ല, ഇത് ഭാഷയും ഭാഷയും അനുസരിച്ച് വ്യത്യാസപ്പെടുന്നു.
/// സാംസ്കാരികമായി അംഗീകരിച്ച മാനദണ്ഡങ്ങൾക്കനുസരിച്ച് സ്ട്രിംഗുകൾ അടുക്കുന്നതിന് `str` തരത്തിന്റെ പരിധിക്ക് പുറത്തുള്ള ലോക്കൽ-നിർദ്ദിഷ്ട ഡാറ്റ ആവശ്യമാണ്.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// സ്ട്രിംഗുകളിൽ താരതമ്യ പ്രവർത്തനങ്ങൾ നടപ്പിലാക്കുന്നു.
///
/// സ്ട്രിംഗുകളെ അവയുടെ ബൈറ്റ് മൂല്യങ്ങളാൽ [lexicographically](Ord#lexicographical-comparison) താരതമ്യം ചെയ്യുന്നു.
/// ഇത് കോഡ് ചാർട്ടുകളിലെ സ്ഥാനങ്ങളെ അടിസ്ഥാനമാക്കി യൂണിക്കോഡ് കോഡ് പോയിന്റുകളെ താരതമ്യം ചെയ്യുന്നു.
/// ഇത് "alphabetical" ഓർഡറിന് തുല്യമായിരിക്കണമെന്നില്ല, ഇത് ഭാഷയും ഭാഷയും അനുസരിച്ച് വ്യത്യാസപ്പെടുന്നു.
/// സാംസ്കാരികമായി അംഗീകരിച്ച മാനദണ്ഡങ്ങൾക്കനുസൃതമായി സ്ട്രിംഗുകൾ താരതമ്യം ചെയ്യുന്നതിന് `str` തരത്തിന്റെ പരിധിക്ക് പുറത്തുള്ള ലോക്കൽ-നിർദ്ദിഷ്ട ഡാറ്റ ആവശ്യമാണ്.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// സിന്റാക്സ് `&self[..]` അല്ലെങ്കിൽ `&mut self[..]` ഉപയോഗിച്ച് സബ്സ്ട്രിംഗ് സ്ലൈസിംഗ് നടപ്പിലാക്കുന്നു.
///
/// മുഴുവൻ സ്‌ട്രിംഗിന്റെയും ഒരു സ്ലൈസ് നൽകുന്നു, അതായത്, `&self` അല്ലെങ്കിൽ `&mut self` നൽകുന്നു.`&സ്വയം [0 ..
/// len] `അല്ലെങ്കിൽ`&മ്യൂട്ട് സെൽഫ് [0 ..
/// len]`.
/// മറ്റ് ഇൻഡെക്സിംഗ് പ്രവർത്തനങ്ങളിൽ നിന്ന് വ്യത്യസ്തമായി, ഇത് ഒരിക്കലും panic ചെയ്യാൻ കഴിയില്ല.
///
/// ഈ പ്രവർത്തനം *O*(1) ആണ്.
///
/// 1.20.0-ന് മുമ്പ്, `Index`, `IndexMut` എന്നിവ നേരിട്ട് നടപ്പിലാക്കുന്നതിലൂടെ ഈ ഇൻഡെക്സിംഗ് പ്രവർത്തനങ്ങളെ ഇപ്പോഴും പിന്തുണച്ചിരുന്നു.
///
/// `&self[0 .. len]` അല്ലെങ്കിൽ `&mut self[0 .. len]` ന് തുല്യമാണ്.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// സിന്റാക്സ് `&self[begin .. end]` അല്ലെങ്കിൽ `&mut self[begin .. end]` ഉപയോഗിച്ച് സബ്സ്ട്രിംഗ് സ്ലൈസിംഗ് നടപ്പിലാക്കുന്നു.
///
/// ബൈറ്റ് ശ്രേണിയിൽ നിന്ന് നൽകിയ സ്‌ട്രിംഗിന്റെ ഒരു സ്ലൈസ് നൽകുന്നു [`ആരംഭിക്കുക`, `end`).
///
/// ഈ പ്രവർത്തനം *O*(1) ആണ്.
///
/// 1.20.0-ന് മുമ്പ്, `Index`, `IndexMut` എന്നിവ നേരിട്ട് നടപ്പിലാക്കുന്നതിലൂടെ ഈ ഇൻഡെക്സിംഗ് പ്രവർത്തനങ്ങളെ ഇപ്പോഴും പിന്തുണച്ചിരുന്നു.
///
/// # Panics
///
/// `begin` അല്ലെങ്കിൽ `end` ഒരു പ്രതീകത്തിന്റെ ആരംഭ ബൈറ്റ് ഓഫ്‌സെറ്റിലേക്ക് (`is_char_boundary` നിർവചിച്ചിരിക്കുന്നത് പോലെ), `begin > end` ആണെങ്കിൽ, അല്ലെങ്കിൽ `end > len` ആണെങ്കിൽ Panics.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // ഇവ panic ചെയ്യും:
/// // ബൈറ്റ് 2 `ö`-ൽ സ്ഥിതിചെയ്യുന്നു:
/// // &s [2 ..3];
///
/// // ബൈറ്റ് 8 `老`&s [1 ..
/// // 8];
///
/// // ബൈറ്റ് 100 സ്ട്രിംഗിന് പുറത്താണ് [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // സുരക്ഷ: `start`, `end` എന്നിവ ഒരു ചാർ‌അതിർത്തിയിലാണെന്ന് പരിശോധിച്ചു,
            // ഞങ്ങൾ ഒരു സുരക്ഷിത റഫറൻസിലാണ് കടന്നുപോകുന്നത്, അതിനാൽ വരുമാന മൂല്യവും ഒന്നായിരിക്കും.
            // ഞങ്ങൾ ചാർ അതിർത്തികളും പരിശോധിച്ചു, അതിനാൽ ഇത് സാധുവായ UTF-8 ആണ്.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // സുരക്ഷ: `start`, `end` എന്നിവ ഒരു ചാർ അതിർത്തിയിലാണെന്ന് പരിശോധിച്ചു.
            // `slice`-ൽ നിന്ന് ഞങ്ങൾക്ക് ലഭിച്ചതിനാൽ പോയിന്റർ അദ്വിതീയമാണെന്ന് ഞങ്ങൾക്കറിയാം.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // സുരക്ഷ: `self` `slice` ന്റെ പരിധിയിലാണെന്ന് കോളർ ഉറപ്പുനൽകുന്നു
        // ഇത് `add`-നായുള്ള എല്ലാ വ്യവസ്ഥകളെയും തൃപ്തിപ്പെടുത്തുന്നു.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // സുരക്ഷ: `get_unchecked`-നായുള്ള അഭിപ്രായങ്ങൾ കാണുക.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // എൻ‌എൽ‌എൽ പ്രശ്‌നം കാരണം സൂചിക [0, .len()] ന് മുകളിലുള്ളതുപോലെ `get` വീണ്ടും ഉപയോഗിക്കാൻ കഴിയില്ലെന്ന് is_char_boundary പരിശോധിക്കുന്നു
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // സുരക്ഷ: `start`, `end` എന്നിവ ഒരു ചാർ‌അതിർത്തിയിലാണെന്ന് പരിശോധിച്ചു,
            // ഞങ്ങൾ ഒരു സുരക്ഷിത റഫറൻസിലാണ് കടന്നുപോകുന്നത്, അതിനാൽ വരുമാന മൂല്യവും ഒന്നായിരിക്കും.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// സിന്റാക്സ് `&self[.. end]` അല്ലെങ്കിൽ `&mut self[.. end]` ഉപയോഗിച്ച് സബ്സ്ട്രിംഗ് സ്ലൈസിംഗ് നടപ്പിലാക്കുന്നു.
///
/// [`0`, `end`) ബൈറ്റ് ശ്രേണിയിൽ നിന്ന് നൽകിയ സ്‌ട്രിംഗിന്റെ ഒരു സ്ലൈസ് നൽകുന്നു.
/// `&self[0 .. end]` അല്ലെങ്കിൽ `&mut self[0 .. end]` ന് തുല്യമാണ്.
///
/// ഈ പ്രവർത്തനം *O*(1) ആണ്.
///
/// 1.20.0-ന് മുമ്പ്, `Index`, `IndexMut` എന്നിവ നേരിട്ട് നടപ്പിലാക്കുന്നതിലൂടെ ഈ ഇൻഡെക്സിംഗ് പ്രവർത്തനങ്ങളെ ഇപ്പോഴും പിന്തുണച്ചിരുന്നു.
///
/// # Panics
///
/// `end` ഒരു പ്രതീകത്തിന്റെ ആരംഭ ബൈറ്റ് ഓഫ്‌സെറ്റിലേക്ക് (`is_char_boundary` നിർവചിച്ചിരിക്കുന്നത് പോലെ) അല്ലെങ്കിൽ `end > len` ആണെങ്കിൽ Panics.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // സുരക്ഷ: `end` ഒരു ചാർ‌അതിർത്തിയിലാണെന്ന് പരിശോധിച്ചു,
            // ഞങ്ങൾ ഒരു സുരക്ഷിത റഫറൻസിലാണ് കടന്നുപോകുന്നത്, അതിനാൽ വരുമാന മൂല്യവും ഒന്നായിരിക്കും.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // സുരക്ഷ: `end` ഒരു ചാർ‌അതിർത്തിയിലാണെന്ന് പരിശോധിച്ചു,
            // ഞങ്ങൾ ഒരു സുരക്ഷിത റഫറൻസിലാണ് കടന്നുപോകുന്നത്, അതിനാൽ വരുമാന മൂല്യവും ഒന്നായിരിക്കും.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // സുരക്ഷ: `end` ഒരു ചാർ‌അതിർത്തിയിലാണെന്ന് പരിശോധിച്ചു,
            // ഞങ്ങൾ ഒരു സുരക്ഷിത റഫറൻസിലാണ് കടന്നുപോകുന്നത്, അതിനാൽ വരുമാന മൂല്യവും ഒന്നായിരിക്കും.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// സിന്റാക്സ് `&self[begin ..]` അല്ലെങ്കിൽ `&mut self[begin ..]` ഉപയോഗിച്ച് സബ്സ്ട്രിംഗ് സ്ലൈസിംഗ് നടപ്പിലാക്കുന്നു.
///
/// ബൈറ്റ് ശ്രേണിയിൽ നിന്ന് നൽകിയ സ്‌ട്രിംഗിന്റെ ഒരു സ്ലൈസ് നൽകുന്നു [`ആരംഭിക്കുക`, `len`).`&സ്വയം [ആരംഭിക്കുക ..
/// len] `അല്ലെങ്കിൽ`&മ്യൂട്ട് സെൽഫ് [ആരംഭിക്കുക ..
/// len]`.
///
/// ഈ പ്രവർത്തനം *O*(1) ആണ്.
///
/// 1.20.0-ന് മുമ്പ്, `Index`, `IndexMut` എന്നിവ നേരിട്ട് നടപ്പിലാക്കുന്നതിലൂടെ ഈ ഇൻഡെക്സിംഗ് പ്രവർത്തനങ്ങളെ ഇപ്പോഴും പിന്തുണച്ചിരുന്നു.
///
/// # Panics
///
/// `begin` ഒരു പ്രതീകത്തിന്റെ ആരംഭ ബൈറ്റ് ഓഫ്‌സെറ്റിലേക്ക് (`is_char_boundary` നിർവചിച്ചിരിക്കുന്നത് പോലെ) അല്ലെങ്കിൽ `begin > len` ആണെങ്കിൽ Panics.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // സുരക്ഷ: `start` ഒരു ചാർ‌അതിർത്തിയിലാണെന്ന് പരിശോധിച്ചു,
            // ഞങ്ങൾ ഒരു സുരക്ഷിത റഫറൻസിലാണ് കടന്നുപോകുന്നത്, അതിനാൽ വരുമാന മൂല്യവും ഒന്നായിരിക്കും.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // സുരക്ഷ: `start` ഒരു ചാർ‌അതിർത്തിയിലാണെന്ന് പരിശോധിച്ചു,
            // ഞങ്ങൾ ഒരു സുരക്ഷിത റഫറൻസിലാണ് കടന്നുപോകുന്നത്, അതിനാൽ വരുമാന മൂല്യവും ഒന്നായിരിക്കും.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // സുരക്ഷ: `self` `slice` ന്റെ പരിധിയിലാണെന്ന് കോളർ ഉറപ്പുനൽകുന്നു
        // ഇത് `add`-നായുള്ള എല്ലാ വ്യവസ്ഥകളെയും തൃപ്തിപ്പെടുത്തുന്നു.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // സുരക്ഷ: `get_unchecked`-ന് സമാനമാണ്.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // സുരക്ഷ: `start` ഒരു ചാർ‌അതിർത്തിയിലാണെന്ന് പരിശോധിച്ചു,
            // ഞങ്ങൾ ഒരു സുരക്ഷിത റഫറൻസിലാണ് കടന്നുപോകുന്നത്, അതിനാൽ വരുമാന മൂല്യവും ഒന്നായിരിക്കും.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// സിന്റാക്സ് `&self[begin ..= end]` അല്ലെങ്കിൽ `&mut self[begin ..= end]` ഉപയോഗിച്ച് സബ്സ്ട്രിംഗ് സ്ലൈസിംഗ് നടപ്പിലാക്കുന്നു.
///
/// [`begin`, `end`] എന്ന ബൈറ്റ് ശ്രേണിയിൽ നിന്ന് നൽകിയ സ്ട്രിംഗിന്റെ ഒരു സ്ലൈസ് നൽകുന്നു.`&self [begin .. end + 1]` അല്ലെങ്കിൽ `&mut self[begin .. end + 1]` ന് തുല്യമാണ്, `end` ന് `usize`-ന്റെ പരമാവധി മൂല്യം ഉണ്ടെങ്കിൽ ഒഴികെ.
///
/// ഈ പ്രവർത്തനം *O*(1) ആണ്.
///
/// # Panics
///
/// `begin` ഒരു പ്രതീകത്തിന്റെ ആരംഭ ബൈറ്റ് ഓഫ്‌സെറ്റിലേക്ക് (`is_char_boundary` നിർവചിച്ചിരിക്കുന്നത് പോലെ) വിരൽ ചൂണ്ടുന്നില്ലെങ്കിൽ, `end` ഒരു പ്രതീകത്തിന്റെ അവസാനിക്കുന്ന ബൈറ്റ് ഓഫ്സെറ്റിലേക്ക് വിരൽ ചൂണ്ടുന്നില്ലെങ്കിൽ (`end + 1` ഒന്നുകിൽ ആരംഭ ബൈറ്റ് ഓഫ്സെറ്റ് അല്ലെങ്കിൽ `len` ന് തുല്യമാണ്), `begin > end` ആണെങ്കിൽ, അല്ലെങ്കിൽ `end >= len` ആണെങ്കിൽ.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // സുരക്ഷ: വിളിക്കുന്നയാൾ `get_unchecked`-നായുള്ള സുരക്ഷാ കരാർ പാലിക്കണം.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // സുരക്ഷ: വിളിക്കുന്നയാൾ `get_unchecked_mut`-നായുള്ള സുരക്ഷാ കരാർ പാലിക്കണം.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// സിന്റാക്സ് `&self[..= end]` അല്ലെങ്കിൽ `&mut self[..= end]` ഉപയോഗിച്ച് സബ്സ്ട്രിംഗ് സ്ലൈസിംഗ് നടപ്പിലാക്കുന്നു.
///
/// [0, `end`] എന്ന ബൈറ്റ് ശ്രേണിയിൽ നിന്ന് നൽകിയ സ്ട്രിംഗിന്റെ ഒരു സ്ലൈസ് നൽകുന്നു.
/// `&self [0 .. end + 1]`-ന് തുല്യമാണ്, `end`-ന് `usize`-ന്റെ പരമാവധി മൂല്യം ഉണ്ടെങ്കിൽ ഒഴികെ.
///
/// ഈ പ്രവർത്തനം *O*(1) ആണ്.
///
/// # Panics
///
/// ഒരു പ്രതീകത്തിന്റെ അവസാനിക്കുന്ന ബൈറ്റ് ഓഫ്‌സെറ്റിലേക്ക് `end` വിരൽ ചൂണ്ടുന്നില്ലെങ്കിൽ Panics (`end + 1` ഒന്നുകിൽ `is_char_boundary` നിർവചിച്ചിരിക്കുന്ന ഒരു ആരംഭ ബൈറ്റ് ഓഫ്‌സെറ്റ് അല്ലെങ്കിൽ `len` ന് തുല്യമാണ്), അല്ലെങ്കിൽ `end >= len` ആണെങ്കിൽ.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // സുരക്ഷ: വിളിക്കുന്നയാൾ `get_unchecked`-നായുള്ള സുരക്ഷാ കരാർ പാലിക്കണം.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // സുരക്ഷ: വിളിക്കുന്നയാൾ `get_unchecked_mut`-നായുള്ള സുരക്ഷാ കരാർ പാലിക്കണം.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// ഒരു സ്‌ട്രിംഗിൽ നിന്ന് ഒരു മൂല്യം പാഴ്‌സുചെയ്യുക
///
/// [From str] ന്റെ [`parse`] രീതിയിലൂടെ `FromStr` ന്റെ [`from_str`] രീതി പലപ്പോഴും വ്യക്തമായി ഉപയോഗിക്കുന്നു.
/// ഉദാഹരണങ്ങൾക്കായി [`പാഴ്‌സ്`] ന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` ഒരു ആജീവനാന്ത പാരാമീറ്റർ ഇല്ല, അതിനാൽ നിങ്ങൾക്ക് ഒരു ആജീവനാന്ത പാരാമീറ്റർ അടങ്ങിയിട്ടില്ലാത്ത തരങ്ങൾ മാത്രമേ പാഴ്‌സ് ചെയ്യാൻ കഴിയൂ.
///
/// മറ്റൊരു വിധത്തിൽ പറഞ്ഞാൽ, നിങ്ങൾക്ക് `i32` ഉപയോഗിച്ച് `FromStr` ഉപയോഗിച്ച് പാഴ്‌സ് ചെയ്യാൻ കഴിയും, പക്ഷേ ഒരു `&i32` അല്ല.
/// നിങ്ങൾക്ക് ഒരു `i32` അടങ്ങിയിരിക്കുന്ന ഒരു സ്ട്രക്റ്റ് പാഴ്‌സുചെയ്യാൻ കഴിയും, എന്നാൽ ഒരു `&i32` അടങ്ങിയിരിക്കുന്ന ഒന്നല്ല.
///
/// # Examples
///
/// ഒരു ഉദാഹരണത്തിൽ `FromStr`-ന്റെ അടിസ്ഥാന നടപ്പാക്കൽ `Point` തരം:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// പാഴ്‌സിംഗിൽ നിന്ന് തിരികെ നൽകാനാകുന്ന അനുബന്ധ പിശക്.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// ഈ തരത്തിലുള്ള ഒരു മൂല്യം നൽകുന്നതിന് ഒരു സ്ട്രിംഗ് `s` പാഴ്‌സുചെയ്യുന്നു.
    ///
    /// പാഴ്‌സിംഗ് വിജയിക്കുകയാണെങ്കിൽ, [`Ok`]-നുള്ളിൽ മൂല്യം നൽകുക, അല്ലാത്തപക്ഷം സ്‌ട്രിംഗ് മോശമായി ഫോർമാറ്റുചെയ്‌തിരിക്കുമ്പോൾ [`Err`]-നുള്ളിൽ ഒരു പിശക് നൽകുക.
    /// trait നടപ്പിലാക്കുന്നതിന് പിശക് തരം നിർദ്ദിഷ്ടമാണ്.
    ///
    /// # Examples
    ///
    /// `FromStr` നടപ്പിലാക്കുന്ന ഒരു തരം [`i32`] ഉള്ള അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// ഒരു സ്‌ട്രിംഗിൽ നിന്ന് ഒരു `bool` പാഴ്‌സുചെയ്യുക.
    ///
    /// ഒരു `Result<bool, ParseBoolError>` നൽകുന്നു, കാരണം `s` യഥാർത്ഥത്തിൽ പാഴ്‌സബിൾ ആകാം അല്ലെങ്കിൽ വരില്ല.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// ശ്രദ്ധിക്കുക, മിക്ക കേസുകളിലും, `str`-ലെ `.parse()` രീതി കൂടുതൽ ഉചിതമാണ്.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}