//! utf8 പിശക് തരം നിർവചിക്കുന്നു.

use crate::fmt;

/// [`u8`] ന്റെ ഒരു ശ്രേണി ഒരു സ്ട്രിംഗായി വ്യാഖ്യാനിക്കാൻ ശ്രമിക്കുമ്പോൾ ഉണ്ടാകാവുന്ന പിശകുകൾ.
///
/// അതുപോലെ, [`സ്ട്രിംഗ്`], [`&സ്ട്രിംഗ്] എന്നിവയ്ക്കായുള്ള ഫംഗ്ഷനുകളുടെയും രീതികളുടെയും `from_utf8` കുടുംബം ഈ പിശക് ഉപയോഗിക്കുന്നു, ഉദാഹരണത്തിന്.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// ഹീപ്പ് മെമ്മറി അനുവദിക്കാതെ `String::from_utf8_lossy` ന് സമാനമായ പ്രവർത്തനം സൃഷ്ടിക്കാൻ ഈ പിശക് തരത്തിന്റെ രീതികൾ ഉപയോഗിക്കാം:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// സാധുവായ UTF-8 പരിശോധിച്ചുറപ്പിച്ച തന്നിരിക്കുന്ന സ്‌ട്രിംഗിലെ സൂചിക നൽകുന്നു.
    ///
    /// `from_utf8(&input[..index])` `Ok(_)` മടക്കിനൽകുന്ന പരമാവധി സൂചികയാണിത്.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::str;
    ///
    /// // ഒരു vector-ൽ ചില അസാധുവായ ബൈറ്റുകൾ
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 ഒരു Utf8 പിശക് നൽകുന്നു
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // രണ്ടാമത്തെ ബൈറ്റ് ഇവിടെ അസാധുവാണ്
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// പരാജയത്തെക്കുറിച്ച് കൂടുതൽ വിവരങ്ങൾ നൽകുന്നു:
    ///
    /// * `None`: ഇൻപുട്ടിന്റെ അവസാനം അപ്രതീക്ഷിതമായി എത്തി.
    ///   `self.valid_up_to()` ഇൻപുട്ടിന്റെ അവസാനം മുതൽ 1 മുതൽ 3 ബൈറ്റുകൾ വരെ.
    ///   ഒരു ബൈറ്റ് സ്ട്രീം (ഒരു ഫയൽ അല്ലെങ്കിൽ ഒരു നെറ്റ്‌വർക്ക് സോക്കറ്റ് പോലുള്ളവ) ക്രമാതീതമായി ഡീകോഡ് ചെയ്യുകയാണെങ്കിൽ, ഇത് സാധുവായ `char` ആകാം, അതിന്റെ UTF-8 ബൈറ്റ് സീക്വൻസ് ഒന്നിലധികം ഭാഗങ്ങളായി വ്യാപിക്കുന്നു.
    ///
    ///
    /// * `Some(len)`: ഒരു അപ്രതീക്ഷിത ബൈറ്റ് നേരിട്ടു.
    ///   `valid_up_to()` നൽകിയ സൂചികയിൽ‌ആരംഭിക്കുന്ന അസാധുവായ ബൈറ്റ് സീക്വൻസിന്റെ ദൈർ‌ഘ്യം.
    ///   നഷ്‌ടമായ ഡീകോഡിംഗിന്റെ കാര്യത്തിൽ ആ ശ്രേണിക്ക് ശേഷം (ഒരു [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] ചേർത്തതിന് ശേഷം) ഡീകോഡിംഗ് പുനരാരംഭിക്കണം.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// [`from_str`] ഉപയോഗിച്ച് `bool` പാഴ്‌സുചെയ്യുമ്പോൾ ഒരു പിശക് ലഭിച്ചു
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}