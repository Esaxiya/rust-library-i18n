//! അലസമായ മൂല്യങ്ങളും സ്റ്റാറ്റിക് ഡാറ്റയുടെ ഒറ്റത്തവണ സമാരംഭവും.

use crate::cell::{Cell, UnsafeCell};
use crate::fmt;
use crate::mem;
use crate::ops::Deref;

/// ഒരു സെൽ‌മാത്രം എഴുതാൻ‌കഴിയുന്ന ഒരു സെൽ‌.
///
/// `RefCell`-ൽ നിന്ന് വ്യത്യസ്തമായി, ഒരു `OnceCell` അതിന്റെ മൂല്യത്തിലേക്ക് പങ്കിട്ട `&T` റഫറൻസുകൾ മാത്രമേ നൽകുന്നുള്ളൂ.
/// `Cell`-ൽ നിന്ന് വ്യത്യസ്തമായി, ഒരു `OnceCell`-ന് ആക്സസ് ചെയ്യുന്നതിന് മൂല്യം പകർത്താനോ മാറ്റിസ്ഥാപിക്കാനോ ആവശ്യമില്ല.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::OnceCell;
///
/// let cell = OnceCell::new();
/// assert!(cell.get().is_none());
///
/// let value: &String = cell.get_or_init(|| {
///     "Hello, World!".to_string()
/// });
/// assert_eq!(value, "Hello, World!");
/// assert!(cell.get().is_some());
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct OnceCell<T> {
    // മാറ്റമില്ലാത്തത്: ഒറ്റയടിക്ക് എഴുതി.
    inner: UnsafeCell<Option<T>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> Default for OnceCell<T> {
    fn default() -> Self {
        Self::new()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug> fmt::Debug for OnceCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.get() {
            Some(v) => f.debug_tuple("OnceCell").field(v).finish(),
            None => f.write_str("OnceCell(Uninit)"),
        }
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Clone> Clone for OnceCell<T> {
    fn clone(&self) -> OnceCell<T> {
        let res = OnceCell::new();
        if let Some(value) = self.get() {
            match res.set(value.clone()) {
                Ok(()) => (),
                Err(_) => unreachable!(),
            }
        }
        res
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: PartialEq> PartialEq for OnceCell<T> {
    fn eq(&self, other: &Self) -> bool {
        self.get() == other.get()
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Eq> Eq for OnceCell<T> {}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T> From<T> for OnceCell<T> {
    fn from(value: T) -> Self {
        OnceCell { inner: UnsafeCell::new(Some(value)) }
    }
}

impl<T> OnceCell<T> {
    /// ഒരു പുതിയ ശൂന്യ സെൽ സൃഷ്ടിക്കുന്നു.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new() -> OnceCell<T> {
        OnceCell { inner: UnsafeCell::new(None) }
    }

    /// അടിസ്ഥാന മൂല്യത്തിലേക്ക് റഫറൻസ് നേടുന്നു.
    ///
    /// സെൽ ശൂന്യമാണെങ്കിൽ `None` നൽകുന്നു.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get(&self) -> Option<&T> {
        // സുരക്ഷ: `ആന്തരിക'ത്തിന്റെ മാറ്റമില്ലാത്തതിനാൽ സുരക്ഷിതം
        unsafe { &*self.inner.get() }.as_ref()
    }

    /// അടിസ്ഥാന മൂല്യത്തിലേക്ക് മ്യൂട്ടബിൾ റഫറൻസ് നേടുന്നു.
    ///
    /// സെൽ ശൂന്യമാണെങ്കിൽ `None` നൽകുന്നു.
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_mut(&mut self) -> Option<&mut T> {
        // സുരക്ഷ: ഞങ്ങൾക്ക് അദ്വിതീയ ആക്‌സസ് ഉള്ളതിനാൽ സുരക്ഷിതം
        unsafe { &mut *self.inner.get() }.as_mut()
    }

    /// സെല്ലിന്റെ ഉള്ളടക്കങ്ങൾ `value` ലേക്ക് സജ്ജമാക്കുന്നു.
    ///
    /// # Errors
    ///
    /// സെൽ ശൂന്യമായിരുന്നെങ്കിൽ ഈ രീതി `Ok(())` ഉം അത് നിറഞ്ഞിട്ടുണ്ടെങ്കിൽ `Err(value)` ഉം നൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert!(cell.get().is_none());
    ///
    /// assert_eq!(cell.set(92), Ok(()));
    /// assert_eq!(cell.set(62), Err(62));
    ///
    /// assert!(cell.get().is_some());
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn set(&self, value: T) -> Result<(), T> {
        // സുരക്ഷ: സുരക്ഷിതമായതിനാൽ ഞങ്ങൾക്ക് പരസ്പരം കടമെടുക്കാൻ കഴിയില്ല
        let slot = unsafe { &*self.inner.get() };
        if slot.is_some() {
            return Err(value);
        }

        // സുരക്ഷ: ഞങ്ങൾ സ്ലോട്ട് സജ്ജമാക്കിയ ഒരേയൊരു സ്ഥലമാണിത്, മൽസരങ്ങളൊന്നുമില്ല
        // reentrancy/concurrency കാരണം സാധ്യമാണ്, കൂടാതെ സ്ലോട്ട് നിലവിൽ `None` ആണെന്ന് ഞങ്ങൾ പരിശോധിച്ചു, അതിനാൽ ഈ റൈറ്റ് `ആന്തരിക'ത്തിന്റെ മാറ്റത്തെ നിലനിർത്തുന്നു.
        //
        //
        let slot = unsafe { &mut *self.inner.get() };
        *slot = Some(value);
        Ok(())
    }

    /// സെൽ ശൂന്യമാണെങ്കിൽ `f` ഉപയോഗിച്ച് സമാരംഭിച്ച് സെല്ലിന്റെ ഉള്ളടക്കങ്ങൾ നേടുന്നു.
    ///
    /// # Panics
    ///
    /// `f` panics ആണെങ്കിൽ, panic കോളറിലേക്ക് പ്രചരിപ്പിക്കപ്പെടുന്നു, കൂടാതെ സെൽ ആരംഭിക്കാതെ തന്നെ തുടരുന്നു.
    ///
    ///
    /// `f`-ൽ നിന്ന് സെൽ വീണ്ടും ആരംഭിക്കുന്നത് ഒരു പിശകാണ്.അങ്ങനെ ചെയ്യുന്നത് panic-ൽ കലാശിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// let value = cell.get_or_init(|| 92);
    /// assert_eq!(value, &92);
    /// let value = cell.get_or_init(|| unreachable!());
    /// assert_eq!(value, &92);
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_init<F>(&self, f: F) -> &T
    where
        F: FnOnce() -> T,
    {
        match self.get_or_try_init(|| Ok::<T, !>(f())) {
            Ok(val) => val,
        }
    }

    /// സെൽ ശൂന്യമാണെങ്കിൽ `f` ഉപയോഗിച്ച് സമാരംഭിച്ച് സെല്ലിന്റെ ഉള്ളടക്കങ്ങൾ നേടുന്നു.
    /// സെൽ ശൂന്യവും `f` പരാജയപ്പെട്ടതുമാണെങ്കിൽ, ഒരു പിശക് മടക്കിനൽകുന്നു.
    ///
    /// # Panics
    ///
    /// `f` panics ആണെങ്കിൽ, panic കോളറിലേക്ക് പ്രചരിപ്പിക്കപ്പെടുന്നു, കൂടാതെ സെൽ ആരംഭിക്കാതെ തന്നെ തുടരുന്നു.
    ///
    ///
    /// `f`-ൽ നിന്ന് സെൽ വീണ്ടും ആരംഭിക്കുന്നത് ഒരു പിശകാണ്.അങ്ങനെ ചെയ്യുന്നത് panic-ൽ കലാശിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell = OnceCell::new();
    /// assert_eq!(cell.get_or_try_init(|| Err(())), Err(()));
    /// assert!(cell.get().is_none());
    /// let value = cell.get_or_try_init(|| -> Result<i32, ()> {
    ///     Ok(92)
    /// });
    /// assert_eq!(value, Ok(&92));
    /// assert_eq!(cell.get(), Some(&92))
    /// ```
    ///
    ///
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn get_or_try_init<F, E>(&self, f: F) -> Result<&T, E>
    where
        F: FnOnce() -> Result<T, E>,
    {
        if let Some(val) = self.get() {
            return Ok(val);
        }
        let val = f()?;
        // *ചില* പുനർ‌പ്രവേശന സമാരംഭങ്ങൾ‌യു‌ബിയിലേക്ക് നയിച്ചേക്കാമെന്നത് ശ്രദ്ധിക്കുക (`reentrant_init` ടെസ്റ്റ് കാണുക).
        // `set/get` സൂക്ഷിക്കുമ്പോൾ ഈ `assert` നീക്കംചെയ്യുന്നത് മികച്ചതായിരിക്കുമെന്ന് ഞാൻ വിശ്വസിക്കുന്നു, പക്ഷേ പഴയ മൂല്യം നിശബ്ദമായി ഉപയോഗിക്കുന്നതിനേക്കാൾ panic ന് ഇത് നല്ലതാണെന്ന് തോന്നുന്നു.
        //
        //
        assert!(self.set(val).is_ok(), "reentrant init");
        Ok(self.get().unwrap())
    }

    /// പൊതിഞ്ഞ മൂല്യം നൽകിക്കൊണ്ട് സെൽ ഉപയോഗിക്കുന്നു.
    ///
    /// സെൽ ശൂന്യമാണെങ്കിൽ `None` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.into_inner(), None);
    ///
    /// let cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.into_inner(), Some("hello".to_string()));
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn into_inner(self) -> Option<T> {
        // `into_inner` `self` മൂല്യം അനുസരിച്ച് എടുക്കുന്നതിനാൽ, കംപൈലർ നിലവിൽ കടമെടുത്തിട്ടില്ലെന്ന് സ്ഥിരീകരിക്കുന്നു.
        // അതിനാൽ `Option<T>` പുറത്തേക്ക് നീക്കുന്നത് സുരക്ഷിതമാണ്.
        self.inner.into_inner()
    }

    /// ഈ `OnceCell`-ൽ നിന്ന് മൂല്യം പുറത്തെടുത്ത്, അത് ആരംഭിക്കാത്ത അവസ്ഥയിലേക്ക് തിരികെ നീക്കുന്നു.
    ///
    /// `OnceCell` സമാരംഭിച്ചിട്ടില്ലെങ്കിൽ ഒരു ഫലവുമില്ല കൂടാതെ `None` നൽകുന്നു.
    ///
    /// മ്യൂട്ടബിൾ റഫറൻസ് ആവശ്യപ്പെടുന്നതിലൂടെ സുരക്ഷ ഉറപ്പുനൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::OnceCell;
    ///
    /// let mut cell: OnceCell<String> = OnceCell::new();
    /// assert_eq!(cell.take(), None);
    ///
    /// let mut cell = OnceCell::new();
    /// cell.set("hello".to_string()).unwrap();
    /// assert_eq!(cell.take(), Some("hello".to_string()));
    /// assert_eq!(cell.get(), None);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn take(&mut self) -> Option<T> {
        mem::take(self).into_inner()
    }
}

/// ആദ്യ ആക്‌സസ്സിൽ സമാരംഭിച്ച ഒരു മൂല്യം.
///
/// # Examples
///
/// ```
/// #![feature(once_cell)]
///
/// use std::lazy::Lazy;
///
/// let lazy: Lazy<i32> = Lazy::new(|| {
///     println!("initializing");
///     92
/// });
/// println!("ready");
/// println!("{}", *lazy);
/// println!("{}", *lazy);
///
/// // Prints:
/// //   സമാരംഭിക്കാൻ തയ്യാറാണ്
/////
/// //   92
/// //   92
/// ```
#[unstable(feature = "once_cell", issue = "74465")]
pub struct Lazy<T, F = fn() -> T> {
    cell: OnceCell<T>,
    init: Cell<Option<F>>,
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: fmt::Debug, F> fmt::Debug for Lazy<T, F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Lazy").field("cell", &self.cell).field("init", &"..").finish()
    }
}

impl<T, F> Lazy<T, F> {
    /// തന്നിരിക്കുന്ന ഓർഗനൈസേഷൻ ഫംഗ്ഷൻ ഉപയോഗിച്ച് ഒരു പുതിയ അലസമായ മൂല്യം സൃഷ്ടിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// # fn main() {
    /// use std::lazy::Lazy;
    ///
    /// let hello = "Hello, World!".to_string();
    ///
    /// let lazy = Lazy::new(|| hello.to_uppercase());
    ///
    /// assert_eq!(&*lazy, "HELLO, WORLD!");
    /// # }
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub const fn new(init: F) -> Lazy<T, F> {
        Lazy { cell: OnceCell::new(), init: Cell::new(Some(init)) }
    }
}

impl<T, F: FnOnce() -> T> Lazy<T, F> {
    /// ഈ അലസമായ മൂല്യത്തിന്റെ വിലയിരുത്തൽ നിർബ്ബന്ധിക്കുകയും ഫലത്തിലേക്ക് ഒരു റഫറൻസ് നൽകുകയും ചെയ്യുന്നു.
    ///
    ///
    /// ഇത് `Deref` impl ന് തുല്യമാണ്, പക്ഷേ ഇത് വ്യക്തമാണ്.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(once_cell)]
    ///
    /// use std::lazy::Lazy;
    ///
    /// let lazy = Lazy::new(|| 92);
    ///
    /// assert_eq!(Lazy::force(&lazy), &92);
    /// assert_eq!(&*lazy, &92);
    /// ```
    #[unstable(feature = "once_cell", issue = "74465")]
    pub fn force(this: &Lazy<T, F>) -> &T {
        this.cell.get_or_init(|| match this.init.take() {
            Some(f) => f(),
            None => panic!("`Lazy` instance has previously been poisoned"),
        })
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T, F: FnOnce() -> T> Deref for Lazy<T, F> {
    type Target = T;
    fn deref(&self) -> &T {
        Lazy::force(self)
    }
}

#[unstable(feature = "once_cell", issue = "74465")]
impl<T: Default> Default for Lazy<T> {
    /// സമാരംഭിക്കുന്ന പ്രവർത്തനമായി `Default` ഉപയോഗിച്ച് ഒരു പുതിയ അലസ മൂല്യം സൃഷ്ടിക്കുന്നു.
    fn default() -> Lazy<T> {
        Lazy::new(T::default)
    }
}