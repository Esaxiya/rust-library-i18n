#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! വിദേശ ഫംഗ്ഷൻ ഇന്റർഫേസുമായി ബന്ധപ്പെട്ട യൂട്ടിലിറ്റികൾ (FFI) ബൈൻഡിംഗുകൾ.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// [pointer] ആയി ഉപയോഗിക്കുമ്പോൾ സി യുടെ `void` തരത്തിന് തുല്യമാണ്.
///
/// ചുരുക്കത്തിൽ, `*const c_void` എന്നത് C യുടെ `const void*` ന് തുല്യവും `*mut c_void` C ന്റെ `void*` ന് തുല്യവുമാണ്.
/// അതായത്, ഇത് സി യുടെ `void` റിട്ടേൺ തരത്തിന് തുല്യമല്ല, ഇത് Rust ന്റെ `()` തരം ആണ്.
///
/// എഫ്‌എഫ്‌ഐയിലെ അതാര്യമായ തരങ്ങളിലേക്ക് പോയിന്ററുകൾ മാതൃകയാക്കാൻ, എക്സ് 100 എക്സ് സ്ഥിരത കൈവരിക്കുന്നതുവരെ, ശൂന്യമായ ബൈറ്റ് അറേയ്‌ക്ക് ചുറ്റും ഒരു Newtype റാപ്പർ ഉപയോഗിക്കാൻ ശുപാർശ ചെയ്യുന്നു.
///
/// വിശദാംശങ്ങൾക്ക് [Nomicon] കാണുക.
///
/// 1.1.0 വരെ പഴയ Rust കംപൈലറിനെ പിന്തുണയ്ക്കണമെങ്കിൽ ഒരാൾക്ക് `std::os::raw::c_void` ഉപയോഗിക്കാം.
/// Rust 1.30.0 ന് ശേഷം, ഈ നിർവചനം ഉപയോഗിച്ച് ഇത് വീണ്ടും എക്‌സ്‌പോർട്ടുചെയ്‌തു.
/// കൂടുതൽ വിവരങ്ങൾക്ക്, ദയവായി [RFC 2521] വായിക്കുക.
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// എൻ‌ബി, എൽ‌എൽ‌വി‌എമ്മിന് അസാധുവായ പോയിന്റർ തരം തിരിച്ചറിയുന്നതിനും എക്സ് 100 എക്സ് പോലുള്ള വിപുലീകരണ ഫംഗ്ഷനുകൾ‌ക്കും, എൽ‌എൽ‌വി‌എം ബിറ്റ്കോഡിൽ‌i8 * ആയി പ്രതിനിധീകരിക്കേണ്ടതുണ്ട്.
// ഇവിടെ ഉപയോഗിക്കുന്ന enum ഇത് ഉറപ്പാക്കുകയും സ്വകാര്യ വേരിയന്റുകൾ മാത്രം ഉപയോഗിച്ച് "raw" തരം ദുരുപയോഗം ചെയ്യുന്നത് തടയുകയും ചെയ്യുന്നു.
// ഞങ്ങൾക്ക് രണ്ട് വകഭേദങ്ങൾ ആവശ്യമാണ്, കാരണം കംപൈലർ repr ആട്രിബ്യൂട്ടിനെക്കുറിച്ച് പരാതിപ്പെടുന്നു, കൂടാതെ ഞങ്ങൾക്ക് കുറഞ്ഞത് ഒരു വേരിയന്റെങ്കിലും ആവശ്യമാണ്, അല്ലാത്തപക്ഷം enum ജനവാസമില്ലാത്തതും കുറഞ്ഞത് അത്തരം പോയിന്ററുകൾ ഡീഫറൻസ് ചെയ്യുന്നത് UB ആയിരിക്കും.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// ഒരു `va_list`-ന്റെ അടിസ്ഥാന നടപ്പാക്കൽ.
// ഇപ്പോൾ W00 എന്നാണ് പേര്, ഇപ്പോൾ `VaListImpl` ഉപയോഗിക്കുന്നു.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // `'f`-ന് മുകളിലുള്ള മാറ്റമില്ലാത്തതിനാൽ ഓരോ `VaListImpl<'f>` ഒബ്‌ജക്റ്റും നിർവചിച്ചിരിക്കുന്ന ഫംഗ്ഷന്റെ പ്രദേശവുമായി ബന്ധിപ്പിച്ചിരിക്കുന്നു
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 ഒരു `va_list`-ന്റെ ABI നടപ്പാക്കൽ.
/// കൂടുതൽ വിവരങ്ങൾക്ക് [AArch64 Procedure Call Standard] കാണുക.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC ഒരു `va_list`-ന്റെ ABI നടപ്പാക്കൽ.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 ഒരു `va_list`-ന്റെ ABI നടപ്പാക്കൽ.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// ഒരു `va_list`-നുള്ള ഒരു റാപ്പർ
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// C യുടെ `va_list`-യുമായി ബൈനറി അനുയോജ്യമായ ഒരു `VaListImpl`-നെ `VaList`-ലേക്ക് പരിവർത്തനം ചെയ്യുക.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// C യുടെ `va_list`-യുമായി ബൈനറി അനുയോജ്യമായ ഒരു `VaListImpl`-നെ `VaList`-ലേക്ക് പരിവർത്തനം ചെയ്യുക.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// VaArgSafe trait പൊതു ഇന്റർഫേസുകളിൽ ഉപയോഗിക്കേണ്ടതുണ്ട്, എന്നിരുന്നാലും, trait തന്നെ ഈ മൊഡ്യൂളിന് പുറത്ത് ഉപയോഗിക്കാൻ അനുവദിക്കരുത്.
// ഒരു പുതിയ തരത്തിനായി trait നടപ്പിലാക്കാൻ ഉപയോക്താക്കളെ അനുവദിക്കുന്നത് (അതുവഴി va_arg ആന്തരികമായി ഒരു പുതിയ തരത്തിൽ ഉപയോഗിക്കാൻ അനുവദിക്കുന്നു) നിർവചിക്കപ്പെടാത്ത പെരുമാറ്റത്തിന് കാരണമാകും.
//
// FIXME(dlrobertson): ഒരു പൊതു ഇന്റർ‌ഫേസിൽ‌VaArgSafe trait ഉപയോഗിക്കുന്നതിനും അത് മറ്റെവിടെയെങ്കിലും ഉപയോഗിക്കാൻ‌കഴിയില്ലെന്ന് ഉറപ്പുവരുത്തുന്നതിനും, trait ഒരു സ്വകാര്യ മൊഡ്യൂളിനുള്ളിൽ‌പൊതുവായിരിക്കേണ്ടതുണ്ട്.
// ആർ‌എഫ്‌സി 2145 നടപ്പിലാക്കി കഴിഞ്ഞാൽ ഇത് മെച്ചപ്പെടുത്തുന്നതിനായി നോക്കുക.
//
//
//
//
mod sealed_trait {
    /// അനുവദനീയമായ തരങ്ങൾ [super::VaListImpl::arg] ഉപയോഗിച്ച് ഉപയോഗിക്കാൻ അനുവദിക്കുന്ന Trait.
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// അടുത്ത ആർഗിലേക്കുള്ള മുന്നേറ്റം.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // സുരക്ഷ: വിളിക്കുന്നയാൾ `va_arg`-നായുള്ള സുരക്ഷാ കരാർ പാലിക്കണം.
        unsafe { va_arg(self) }
    }

    /// നിലവിലെ സ്ഥലത്ത് `va_list` പകർത്തുന്നു.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // സുരക്ഷ: വിളിക്കുന്നയാൾ `va_end`-നായുള്ള സുരക്ഷാ കരാർ പാലിക്കണം.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // സുരക്ഷ: ഞങ്ങൾ `MaybeUninit`-ലേക്ക് എഴുതുന്നു, അതിനാൽ ഇത് സമാരംഭിക്കുകയും `assume_init` നിയമപരവുമാണ്
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: ഇത് `va_end` എന്ന് വിളിക്കണം, പക്ഷേ ഇതിലേക്ക് ശുദ്ധമായ മാർഗമില്ല
        // `drop` എല്ലായ്പ്പോഴും അതിന്റെ കോളറിലേക്ക് ഇൻലൈൻ ചെയ്യപ്പെടുമെന്ന് ഉറപ്പുനൽകുന്നു, അതിനാൽ `va_end` അനുബന്ധ `va_copy`-ന്റെ അതേ ഫംഗ്ഷനിൽ നിന്ന് നേരിട്ട് വിളിക്കും.
        // `man va_end` സിക്ക് ഇത് ആവശ്യമാണെന്ന് പ്രസ്താവിക്കുന്നു, എൽ‌എൽ‌വി‌എം അടിസ്ഥാനപരമായി സി സെമാന്റിക്‌സിനെ പിന്തുടരുന്നു, അതിനാൽ എക്സ് 100 എക്സ് എല്ലായ്‌പ്പോഴും എക്സ് 00 എക്സ് എന്ന അതേ ഫംഗ്ഷനിൽ നിന്നാണ് വിളിക്കുന്നതെന്ന് ഉറപ്പാക്കേണ്ടതുണ്ട്.
        //
        // കൂടുതൽ വിവരങ്ങൾക്ക്, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // നിലവിലുള്ള എല്ലാ എൽ‌എൽ‌വി‌എം ടാർ‌ഗെറ്റുകളിലും എക്സ് 00 എക്സ് ഒരു നോ-ഒപ്പ് ആയതിനാൽ ഇത് ഇപ്പോൾ പ്രവർത്തിക്കുന്നു.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// `va_start` അല്ലെങ്കിൽ `va_copy` ഉപയോഗിച്ച് സമാരംഭിച്ചതിന് ശേഷം ആർഗ്‌ലിസ്റ്റ് `ap` നശിപ്പിക്കുക.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// ആർ‌ഗ്‌ലിസ്റ്റ് `src` ന്റെ നിലവിലെ സ്ഥാനം ആർ‌ഗ്ലിസ്റ്റ് `dst` ലേക്ക് പകർ‌ത്തുന്നു.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// `va_list` `ap`-ൽ നിന്ന് `T` തരം ആർഗ്യുമെന്റ് ലോഡുചെയ്യുകയും `ap` പോയിന്റിലേക്ക് ആർഗ്യുമെന്റ് വർദ്ധിപ്പിക്കുകയും ചെയ്യുക.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}