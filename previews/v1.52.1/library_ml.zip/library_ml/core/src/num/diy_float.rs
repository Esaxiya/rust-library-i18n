//! ആന്തരിക ഉപയോഗത്തിനായി മാത്രം വിപുലീകരിച്ച കൃത്യത "soft float".

// ഈ മൊഡ്യൂൾ‌dec2flt, flt2dec എന്നിവയ്‌ക്ക് മാത്രമുള്ളതാണ്, മാത്രമല്ല കോർ‌ടെസ്റ്റുകൾ‌കാരണം പൊതുവായതും.
// ഇത് ഒരിക്കലും സ്ഥിരത കൈവരിക്കാൻ ഉദ്ദേശിച്ചുള്ളതല്ല.
#![doc(hidden)]
#![unstable(
    feature = "core_private_diy_float",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

/// `f * 2^e` പ്രതിനിധീകരിക്കുന്ന ഒരു ഇഷ്‌ടാനുസൃത 64-ബിറ്റ് ഫ്ലോട്ടിംഗ് പോയിന്റ് തരം.
#[derive(Copy, Clone, Debug)]
#[doc(hidden)]
pub struct Fp {
    /// പൂർണ്ണസംഖ്യ മാന്റിസ.
    pub f: u64,
    /// ബേസ് 2 ലെ എക്‌സ്‌പോണന്റ്.
    pub e: i16,
}

impl Fp {
    /// തന്റെയും `other` ന്റെയും ശരിയായി വൃത്താകൃതിയിലുള്ള ഉൽപ്പന്നം നൽകുന്നു.
    pub fn mul(&self, other: &Fp) -> Fp {
        const MASK: u64 = 0xffffffff;
        let a = self.f >> 32;
        let b = self.f & MASK;
        let c = other.f >> 32;
        let d = other.f & MASK;
        let ac = a * c;
        let bc = b * c;
        let ad = a * d;
        let bd = b * d;
        let tmp = (bd >> 32) + (ad & MASK) + (bc & MASK) + (1 << 31) /* round */;
        let f = ac + (ad >> 32) + (bc >> 32) + (tmp >> 32);
        let e = self.e + other.e + 64;
        Fp { f, e }
    }

    /// തത്ഫലമായുണ്ടാകുന്ന മാന്റിസ കുറഞ്ഞത് `2^63` എങ്കിലും സ്വയം നോർമലൈസ് ചെയ്യുന്നു.
    pub fn normalize(&self) -> Fp {
        let mut f = self.f;
        let mut e = self.e;
        if f >> (64 - 32) == 0 {
            f <<= 32;
            e -= 32;
        }
        if f >> (64 - 16) == 0 {
            f <<= 16;
            e -= 16;
        }
        if f >> (64 - 8) == 0 {
            f <<= 8;
            e -= 8;
        }
        if f >> (64 - 4) == 0 {
            f <<= 4;
            e -= 4;
        }
        if f >> (64 - 2) == 0 {
            f <<= 2;
            e -= 2;
        }
        if f >> (64 - 1) == 0 {
            f <<= 1;
            e -= 1;
        }
        debug_assert!(f >= (1 >> 63));
        Fp { f, e }
    }

    /// പങ്കിട്ട എക്‌സ്‌പോണന്റ് ലഭിക്കുന്നതിന് സ്വയം നോർമലൈസ് ചെയ്യുന്നു.
    /// ഇതിന് എക്‌സ്‌പോണന്റ് കുറയ്‌ക്കാൻ മാത്രമേ കഴിയൂ (അങ്ങനെ മാന്റിസ വർദ്ധിപ്പിക്കും).
    pub fn normalize_to(&self, e: i16) -> Fp {
        let edelta = self.e - e;
        assert!(edelta >= 0);
        let edelta = edelta as usize;
        assert_eq!(self.f << edelta >> edelta, self.f);
        Fp { f: self.f << edelta, e }
    }
}