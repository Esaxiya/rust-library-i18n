//! പൂജ്യത്തിന് തുല്യമല്ലെന്ന് അറിയപ്പെടുന്ന പൂർണ്ണസംഖ്യയുടെ നിർവചനങ്ങൾ.

use crate::fmt;
use crate::ops::{BitOr, BitOrAssign, Div, Rem};
use crate::str::FromStr;

use super::from_str_radix;
use super::{IntErrorKind, ParseIntError};
use crate::intrinsics;

macro_rules! impl_nonzero_fmt {
    ( #[$stability: meta] ( $( $Trait: ident ),+ ) for $Ty: ident ) => {
        $(
            #[$stability]
            impl fmt::$Trait for $Ty {
                #[inline]
                fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                    self.get().fmt(f)
                }
            }
        )+
    }
}

macro_rules! nonzero_integers {
    ( $( #[$stability: meta] $Ty: ident($Int: ty); )+ ) => {
        $(
            /// പൂജ്യത്തിന് തുല്യമല്ലെന്ന് അറിയപ്പെടുന്ന ഒരു സംഖ്യ.
            ///
            /// ഇത് ചില മെമ്മറി ലേ layout ട്ട് ഒപ്റ്റിമൈസേഷൻ പ്രാപ്തമാക്കുന്നു.
            #[doc = concat!("For example, `Option<", stringify!($Ty), ">` is the same size as `", stringify!($Int), "`:")]
            /// ```rust
            /// std::mem::size_of ഉപയോഗിക്കുക;
            #[doc = concat!("assert_eq!(size_of::<Option<core::num::", stringify!($Ty), ">>(), size_of::<", stringify!($Int), ">());")]
            /// ```
            #[$stability]
            #[derive(Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
            #[repr(transparent)]
            #[rustc_layout_scalar_valid_range_start(1)]
            #[rustc_nonnull_optimization_guaranteed]
            pub struct $Ty($Int);

            impl $Ty {
                /// മൂല്യം പരിശോധിക്കാതെ പൂജ്യമല്ലാത്തത് സൃഷ്ടിക്കുന്നു.
                ///
                /// # Safety
                ///
                /// മൂല്യം പൂജ്യമായിരിക്കരുത്.
                #[$stability]
                #[rustc_const_stable(feature = "nonzero", since = "1.34.0")]
                #[inline]
                pub const unsafe fn new_unchecked(n: $Int) -> Self {
                    // സുരക്ഷ: ഇത് വിളിക്കുന്നയാൾ സുരക്ഷിതമാണെന്ന് ഉറപ്പുനൽകുന്നു.
                    unsafe { Self(n) }
                }

                /// തന്നിരിക്കുന്ന മൂല്യം പൂജ്യമല്ലെങ്കിൽ പൂജ്യമല്ലാത്തത് സൃഷ്ടിക്കുന്നു.
                #[$stability]
                #[rustc_const_stable(feature = "const_nonzero_int_methods", since = "1.47.0")]
                #[inline]
                pub const fn new(n: $Int) -> Option<Self> {
                    if n != 0 {
                        // സുരക്ഷ: `0` ഇല്ലെന്ന് ഞങ്ങൾ പരിശോധിച്ചു
                        Some(unsafe { Self(n) })
                    } else {
                        None
                    }
                }

                /// മൂല്യം ഒരു പ്രാകൃത തരമായി നൽകുന്നു.
                #[$stability]
                #[inline]
                #[rustc_const_stable(feature = "nonzero", since = "1.34.0")]
                pub const fn get(self) -> $Int {
                    self.0
                }

            }

            #[stable(feature = "from_nonzero", since = "1.31.0")]
            impl From<$Ty> for $Int {
                #[doc = concat!("Converts a `", stringify!($Ty), "` into an `", stringify!($Int), "`")]
                #[inline]
                fn from(nonzero: $Ty) -> Self {
                    nonzero.0
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOr for $Ty {
                type Output = Self;
                #[inline]
                fn bitor(self, rhs: Self) -> Self::Output {
                    // സുരക്ഷ: `self`, `rhs` എന്നിവ രണ്ടും നോൺ‌ജെറോ ആയതിനാൽ,
                    // ബിറ്റ്‌വൈസ്-അല്ലെങ്കിൽ‌നോൺ‌ജെറോ ആയിരിക്കും.
                    unsafe { $Ty::new_unchecked(self.get() | rhs.get()) }
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOr<$Int> for $Ty {
                type Output = Self;
                #[inline]
                fn bitor(self, rhs: $Int) -> Self::Output {
                    // സുരക്ഷ: `self` നോൺ‌ജെറോ ആയതിനാൽ‌, അതിന്റെ ഫലം
                    // ബിറ്റ്വൈസ്-അല്ലെങ്കിൽ `rhs`-ന്റെ മൂല്യം പരിഗണിക്കാതെ നോൺ‌ജെറോ ആയിരിക്കും.
                    //
                    unsafe { $Ty::new_unchecked(self.get() | rhs) }
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOr<$Ty> for $Int {
                type Output = $Ty;
                #[inline]
                fn bitor(self, rhs: $Ty) -> Self::Output {
                    // സുരക്ഷ: `rhs` നോൺ‌ജെറോ ആയതിനാൽ‌, അതിന്റെ ഫലം
                    // ബിറ്റ്വൈസ്-അല്ലെങ്കിൽ `self`-ന്റെ മൂല്യം പരിഗണിക്കാതെ നോൺ‌ജെറോ ആയിരിക്കും.
                    //
                    unsafe { $Ty::new_unchecked(self | rhs.get()) }
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOrAssign for $Ty {
                #[inline]
                fn bitor_assign(&mut self, rhs: Self) {
                    *self = *self | rhs;
                }
            }

            #[stable(feature = "nonzero_bitor", since = "1.45.0")]
            impl BitOrAssign<$Int> for $Ty {
                #[inline]
                fn bitor_assign(&mut self, rhs: $Int) {
                    *self = *self | rhs;
                }
            }

            impl_nonzero_fmt! {
                #[$stability] (Debug, Display, Binary, Octal, LowerHex, UpperHex) for $Ty
            }
        )+
    }
}

nonzero_integers! {
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU8(u8);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU16(u16);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU32(u32);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU64(u64);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroU128(u128);
    #[stable(feature = "nonzero", since = "1.28.0")] NonZeroUsize(usize);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI8(i8);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI16(i16);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI32(i32);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI64(i64);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroI128(i128);
    #[stable(feature = "signed_nonzero", since = "1.34.0")] NonZeroIsize(isize);
}

macro_rules! from_str_radix_nzint_impl {
    ($($t:ty)*) => {$(
        #[stable(feature = "nonzero_parse", since = "1.35.0")]
        impl FromStr for $t {
            type Err = ParseIntError;
            fn from_str(src: &str) -> Result<Self, Self::Err> {
                Self::new(from_str_radix(src, 10)?)
                    .ok_or(ParseIntError {
                        kind: IntErrorKind::Zero
                    })
            }
        }
    )*}
}

from_str_radix_nzint_impl! { NonZeroU8 NonZeroU16 NonZeroU32 NonZeroU64 NonZeroU128 NonZeroUsize
NonZeroI8 NonZeroI16 NonZeroI32 NonZeroI64 NonZeroI128 NonZeroIsize }

macro_rules! nonzero_leading_trailing_zeros {
    ( $( $Ty: ident($Uint: ty) , $LeadingTestExpr:expr ;)+ ) => {
        $(
            impl $Ty {
                /// `self`-ന്റെ ബൈനറി പ്രാതിനിധ്യത്തിലെ പ്രമുഖ പൂജ്യങ്ങളുടെ എണ്ണം നൽകുന്നു.
                ///
                /// പല ആർക്കിടെക്ചറുകളിലും, ഈ ഫംഗ്ഷന് അന്തർലീനമായ ഇന്റീരിയർ തരത്തിൽ `leading_zeros()` നേക്കാൾ മികച്ച പ്രകടനം നടത്താൻ കഴിയും, കാരണം പൂജ്യത്തിന്റെ പ്രത്യേക കൈകാര്യം ചെയ്യൽ ഒഴിവാക്കാനാകും.
                ///
                /// # Examples
                ///
                /// അടിസ്ഥാന ഉപയോഗം:
                ///
                /// ```
                /// #![feature(nonzero_leading_trailing_zeros)]
                #[doc = concat!("let n = std::num::", stringify!($Ty), "::new(", stringify!($LeadingTestExpr), ").unwrap();")]
                /// assert_eq!(n.leading_zeros(), 0);
                /// ```
                #[unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[rustc_const_unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[inline]
                pub const fn leading_zeros(self) -> u32 {
                    // സുരക്ഷ: `self` പൂജ്യമാകാൻ കഴിയാത്തതിനാൽ ctlz_nonzero എന്ന് വിളിക്കുന്നത് സുരക്ഷിതമാണ്
                    unsafe { intrinsics::ctlz_nonzero(self.0 as $Uint) as u32 }
                }

                /// `self`-ന്റെ ബൈനറി പ്രാതിനിധ്യത്തിൽ പിന്തുടരുന്ന പൂജ്യങ്ങളുടെ എണ്ണം നൽകുന്നു.
                ///
                /// പല ആർക്കിടെക്ചറുകളിലും, ഈ ഫംഗ്ഷന് അന്തർലീനമായ ഇന്റീരിയർ തരത്തിൽ `trailing_zeros()` നേക്കാൾ മികച്ച പ്രകടനം നടത്താൻ കഴിയും, കാരണം പൂജ്യത്തിന്റെ പ്രത്യേക കൈകാര്യം ചെയ്യൽ ഒഴിവാക്കാനാകും.
                ///
                ///
                /// # Examples
                ///
                /// അടിസ്ഥാന ഉപയോഗം:
                ///
                /// ```
                /// #![feature(nonzero_leading_trailing_zeros)]
                #[doc = concat!("let n = std::num::", stringify!($Ty), "::new(0b0101000).unwrap();")]
                /// assert_eq!(n.trailing_zeros(), 3);
                /// ```
                #[unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[rustc_const_unstable(feature = "nonzero_leading_trailing_zeros", issue = "79143")]
                #[inline]
                pub const fn trailing_zeros(self) -> u32 {
                    // സുരക്ഷ: `self` പൂജ്യമാകാൻ കഴിയാത്തതിനാൽ cttz_nonzero എന്ന് വിളിക്കുന്നത് സുരക്ഷിതമാണ്
                    unsafe { intrinsics::cttz_nonzero(self.0 as $Uint) as u32 }
                }

            }
        )+
    }
}

nonzero_leading_trailing_zeros! {
    NonZeroU8(u8), u8::MAX;
    NonZeroU16(u16), u16::MAX;
    NonZeroU32(u32), u32::MAX;
    NonZeroU64(u64), u64::MAX;
    NonZeroU128(u128), u128::MAX;
    NonZeroUsize(usize), usize::MAX;
    NonZeroI8(u8), -1i8;
    NonZeroI16(u16), -1i16;
    NonZeroI32(u32), -1i32;
    NonZeroI64(u64), -1i64;
    NonZeroI128(u128), -1i128;
    NonZeroIsize(usize), -1isize;
}

macro_rules! nonzero_integers_div {
    ( $( $Ty: ident($Int: ty); )+ ) => {
        $(
            #[stable(feature = "nonzero_div", since = "1.51.0")]
            impl Div<$Ty> for $Int {
                type Output = $Int;
                /// ഈ പ്രവർത്തനം പൂജ്യത്തിലേക്ക് തിരിയുന്നു, കൃത്യമായ ഫലത്തിന്റെ ഏതെങ്കിലും ഭാഗത്തെ വെട്ടിച്ചുരുക്കുന്നു, കൂടാതെ panic ന് കഴിയില്ല.
                ///
                #[inline]
                fn div(self, other: $Ty) -> $Int {
                    // സുരക്ഷ: `other` ഒരു നോൺ‌ജെറോ ആയതിനാൽ പൂജ്യം പ്രകാരം ഒഴിവ് പരിശോധിക്കുന്നു,
                    // കൂടാതെ MIN/-1 പരിശോധിക്കുന്നത് `self` സൈൻ ചെയ്യാത്ത ഒരു int ആണ്.
                    unsafe { crate::intrinsics::unchecked_div(self, other.get()) }
                }
            }

            #[stable(feature = "nonzero_div", since = "1.51.0")]
            impl Rem<$Ty> for $Int {
                type Output = $Int;
                /// ഈ പ്രവർത്തനം `n % d == n - (n / d) * d` നെ തൃപ്തിപ്പെടുത്തുന്നു, മാത്രമല്ല panic ന് കഴിയില്ല.
                #[inline]
                fn rem(self, other: $Ty) -> $Int {
                    // സുരക്ഷ: `other` ഒരു നോൺ‌ജെറോ ആയതിനാൽ പൂജ്യം ഉപയോഗിച്ച് റിം പരിശോധിക്കുന്നു,
                    // കൂടാതെ MIN/-1 പരിശോധിക്കുന്നത് `self` സൈൻ ചെയ്യാത്ത ഒരു int ആണ്.
                    unsafe { crate::intrinsics::unchecked_rem(self, other.get()) }
                }
            }
        )+
    }
}

nonzero_integers_div! {
    NonZeroU8(u8);
    NonZeroU16(u16);
    NonZeroU32(u32);
    NonZeroU64(u64);
    NonZeroU128(u128);
    NonZeroUsize(usize);
}

macro_rules! nonzero_unsigned_is_power_of_two {
    ( $( $Ty: ident )+ ) => {
        $(
            impl $Ty {

                /// ചില `k`-ന് `self == (1 << k)` ആണെങ്കിൽ മാത്രം `true` നൽകുന്നു.
                ///
                /// പല ആർക്കിടെക്ചറുകളിലും, ഈ ഫംഗ്ഷന് അന്തർലീനമായ ഇന്റീരിയർ തരത്തിൽ `is_power_of_two()` നേക്കാൾ മികച്ച പ്രകടനം നടത്താൻ കഴിയും, കാരണം പൂജ്യത്തിന്റെ പ്രത്യേക കൈകാര്യം ചെയ്യൽ ഒഴിവാക്കാനാകും.
                ///
                ///
                /// # Examples
                ///
                /// അടിസ്ഥാന ഉപയോഗം:
                ///
                /// ```
                /// #![feature(nonzero_is_power_of_two)]
                ///
                #[doc = concat!("let eight = std::num::", stringify!($Ty), "::new(8).unwrap();")]
                /// assert!(eight.is_power_of_two());
                #[doc = concat!("let ten = std::num::", stringify!($Ty), "::new(10).unwrap();")]
                /// assert!(!ten.is_power_of_two());
                /// ```
                #[unstable(feature = "nonzero_is_power_of_two", issue = "81106")]
                #[inline]
                pub const fn is_power_of_two(self) -> bool {
                    // ഇവിടെ കാണുന്ന നടപ്പാക്കലിലേക്ക് എൽ‌എൽ‌വി‌എം 11 എക്സ് 00 എക്സ് നോർമലൈസ് ചെയ്യുന്നു.
                    // അടിസ്ഥാന x86-64 ടാർഗെറ്റിൽ, ഇത് പൂജ്യം പരിശോധനയ്ക്കായി 3 നിർദ്ദേശങ്ങൾ സംരക്ഷിക്കുന്നു.
                    // BMI1 ഉള്ള x86_64-ൽ, നോൺ‌ജെറോ ആയിരിക്കുന്നത് `BLSR`-ലേക്ക് കോഡ്ജെൻ ചെയ്യാൻ അനുവദിക്കുന്നു, ഇത് അന്തർലീനമായ ഇന്റീരിയർ തരത്തിലെ `POPCNT` നടപ്പിലാക്കലുമായി താരതമ്യപ്പെടുത്തുമ്പോൾ ഒരു നിർദ്ദേശം സംരക്ഷിക്കുന്നു.
                    //

                    intrinsics::ctpop(self.get()) < 2
                }

            }
        )+
    }
}

nonzero_unsigned_is_power_of_two! { NonZeroU8 NonZeroU16 NonZeroU32 NonZeroU64 NonZeroU128 NonZeroUsize }