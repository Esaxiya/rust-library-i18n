//! `f32` സിംഗിൾ പ്രിസിഷൻ ഫ്ലോട്ടിംഗ് പോയിൻറ് തരത്തിന് പ്രത്യേകമായുള്ള സ്ഥിരത.
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! `consts` സബ് മൊഡ്യൂളിൽ ഗണിതശാസ്ത്രപരമായി പ്രധാനപ്പെട്ട നമ്പറുകൾ നൽകിയിരിക്കുന്നു.
//!
//! ഈ മൊഡ്യൂളിൽ നേരിട്ട് നിർവചിച്ചിരിക്കുന്ന സ്ഥിരാങ്കങ്ങൾക്ക് (`consts` ഉപ-മൊഡ്യൂളിൽ നിർവചിച്ചിരിക്കുന്നതിൽ നിന്ന് വ്യത്യസ്തമായി), പുതിയ കോഡ് പകരം `f32` തരത്തിൽ നേരിട്ട് നിർവചിച്ചിരിക്കുന്ന അനുബന്ധ സ്ഥിരതകൾ ഉപയോഗിക്കണം.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// `f32`-ന്റെ ആന്തരിക പ്രാതിനിധ്യത്തിന്റെ റാഡിക്സ് അല്ലെങ്കിൽ അടിസ്ഥാനം.
/// പകരം [`f32::RADIX`] ഉപയോഗിക്കുക.
///
/// # Examples
///
/// ```rust
/// // ഒഴിവാക്കിയ വഴി
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // ഉദ്ദേശിച്ച വഴി
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// അടിസ്ഥാന 2 ലെ പ്രധാനപ്പെട്ട അക്കങ്ങളുടെ എണ്ണം.
/// പകരം [`f32::MANTISSA_DIGITS`] ഉപയോഗിക്കുക.
///
/// # Examples
///
/// ```rust
/// // ഒഴിവാക്കിയ വഴി
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // ഉദ്ദേശിച്ച വഴി
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// അടിസ്ഥാന 10 ലെ പ്രധാനപ്പെട്ട അക്കങ്ങളുടെ ഏകദേശ എണ്ണം.
/// പകരം [`f32::DIGITS`] ഉപയോഗിക്കുക.
///
/// # Examples
///
/// ```rust
/// // ഒഴിവാക്കിയ വഴി
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // ഉദ്ദേശിച്ച വഴി
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] `f32`-നായുള്ള മൂല്യം.
/// പകരം [`f32::EPSILON`] ഉപയോഗിക്കുക.
///
/// `1.0`-ഉം അടുത്ത വലിയ പ്രതിനിധീകരിക്കാവുന്ന നമ്പറും തമ്മിലുള്ള വ്യത്യാസമാണിത്.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // ഒഴിവാക്കിയ വഴി
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // ഉദ്ദേശിച്ച വഴി
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// ഏറ്റവും ചെറിയ പരിമിത `f32` മൂല്യം.
/// പകരം [`f32::MIN`] ഉപയോഗിക്കുക.
///
/// # Examples
///
/// ```rust
/// // ഒഴിവാക്കിയ വഴി
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // ഉദ്ദേശിച്ച വഴി
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// ഏറ്റവും ചെറിയ പോസിറ്റീവ് സാധാരണ `f32` മൂല്യം.
/// പകരം [`f32::MIN_POSITIVE`] ഉപയോഗിക്കുക.
///
/// # Examples
///
/// ```rust
/// // ഒഴിവാക്കിയ വഴി
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // ഉദ്ദേശിച്ച വഴി
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// ഏറ്റവും വലിയ പരിമിത `f32` മൂല്യം.
/// പകരം [`f32::MAX`] ഉപയോഗിക്കുക.
///
/// # Examples
///
/// ```rust
/// // ഒഴിവാക്കിയ വഴി
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // ഉദ്ദേശിച്ച വഴി
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// 2 എക്‌സ്‌പോണന്റിലെ സാധ്യമായ ഏറ്റവും കുറഞ്ഞ സാധാരണ ശക്തിയെക്കാൾ വലുത്.
/// പകരം [`f32::MIN_EXP`] ഉപയോഗിക്കുക.
///
/// # Examples
///
/// ```rust
/// // ഒഴിവാക്കിയ വഴി
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // ഉദ്ദേശിച്ച വഴി
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// 2 എക്‌സ്‌പോണന്റിന്റെ പരമാവധി പവർ.
/// പകരം [`f32::MAX_EXP`] ഉപയോഗിക്കുക.
///
/// # Examples
///
/// ```rust
/// // ഒഴിവാക്കിയ വഴി
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // ഉദ്ദേശിച്ച വഴി
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// 10 എക്‌സ്‌പോണന്റുകളുടെ സാധ്യമായ ഏറ്റവും കുറഞ്ഞ സാധാരണ പവർ.
/// പകരം [`f32::MIN_10_EXP`] ഉപയോഗിക്കുക.
///
/// # Examples
///
/// ```rust
/// // ഒഴിവാക്കിയ വഴി
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // ഉദ്ദേശിച്ച വഴി
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// 10 എക്‌സ്‌പോണന്റുകളുടെ പരമാവധി പവർ.
/// പകരം [`f32::MAX_10_EXP`] ഉപയോഗിക്കുക.
///
/// # Examples
///
/// ```rust
/// // ഒഴിവാക്കിയ വഴി
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // ഉദ്ദേശിച്ച വഴി
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// ഒരു നമ്പർ (NaN) അല്ല.
/// പകരം [`f32::NAN`] ഉപയോഗിക്കുക.
///
/// # Examples
///
/// ```rust
/// // ഒഴിവാക്കിയ വഴി
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // ഉദ്ദേശിച്ച വഴി
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// ഇൻഫിനിറ്റി (∞).
/// പകരം [`f32::INFINITY`] ഉപയോഗിക്കുക.
///
/// # Examples
///
/// ```rust
/// // ഒഴിവാക്കിയ വഴി
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // ഉദ്ദേശിച്ച വഴി
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// നെഗറ്റീവ് അനന്തത (−∞).
/// പകരം [`f32::NEG_INFINITY`] ഉപയോഗിക്കുക.
///
/// # Examples
///
/// ```rust
/// // ഒഴിവാക്കിയ വഴി
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // ഉദ്ദേശിച്ച വഴി
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// അടിസ്ഥാന ഗണിത സ്ഥിരത.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: cmath ൽ നിന്ന് ഗണിത സ്ഥിരത ഉപയോഗിച്ച് മാറ്റിസ്ഥാപിക്കുക.

    /// ആർക്കിമിഡീസിന്റെ സ്ഥിരമായ (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// പൂർണ്ണ സർക്കിൾ സ്ഥിരാങ്കം (τ)
    ///
    /// 2π ന് തുല്യമാണ്.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// യൂലറിന്റെ നമ്പർ (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// `f32`-ന്റെ ആന്തരിക പ്രാതിനിധ്യത്തിന്റെ റാഡിക്സ് അല്ലെങ്കിൽ അടിസ്ഥാനം.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// അടിസ്ഥാന 2 ലെ പ്രധാനപ്പെട്ട അക്കങ്ങളുടെ എണ്ണം.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// അടിസ്ഥാന 10 ലെ പ്രധാനപ്പെട്ട അക്കങ്ങളുടെ ഏകദേശ എണ്ണം.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] `f32`-നായുള്ള മൂല്യം.
    ///
    /// `1.0`-ഉം അടുത്ത വലിയ പ്രതിനിധീകരിക്കാവുന്ന നമ്പറും തമ്മിലുള്ള വ്യത്യാസമാണിത്.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// ഏറ്റവും ചെറിയ പരിമിത `f32` മൂല്യം.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// ഏറ്റവും ചെറിയ പോസിറ്റീവ് സാധാരണ `f32` മൂല്യം.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// ഏറ്റവും വലിയ പരിമിത `f32` മൂല്യം.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// 2 എക്‌സ്‌പോണന്റിലെ സാധ്യമായ ഏറ്റവും കുറഞ്ഞ സാധാരണ ശക്തിയെക്കാൾ വലുത്.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// 2 എക്‌സ്‌പോണന്റിന്റെ പരമാവധി പവർ.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// 10 എക്‌സ്‌പോണന്റുകളുടെ സാധ്യമായ ഏറ്റവും കുറഞ്ഞ സാധാരണ പവർ.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// 10 എക്‌സ്‌പോണന്റുകളുടെ പരമാവധി പവർ.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// ഒരു നമ്പർ (NaN) അല്ല.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// ഇൻഫിനിറ്റി (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// നെഗറ്റീവ് അനന്തത (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// ഈ മൂല്യം `NaN` ആണെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): പോർട്ടബിലിറ്റിയെക്കുറിച്ചുള്ള ആശങ്കകൾ കാരണം എക്സ് 100 എക്സ് ലിബ്കോറിൽ പൊതുവായി ലഭ്യമല്ല, അതിനാൽ ഈ നടപ്പാക്കൽ ആന്തരികമായി സ്വകാര്യ ഉപയോഗത്തിന് വേണ്ടിയുള്ളതാണ്.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// ഈ മൂല്യം പോസിറ്റീവ് അനന്തമോ നെഗറ്റീവ് അനന്തമോ ആണെങ്കിൽ `true` നൽകുന്നു, അല്ലെങ്കിൽ `false`.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// ഈ നമ്പർ അനന്തമോ `NaN` അല്ലെങ്കിലോ `true` നൽകുന്നു.
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // NaN നെ പ്രത്യേകം കൈകാര്യം ചെയ്യേണ്ട ആവശ്യമില്ല: സ്വയം NaN ആണെങ്കിൽ, താരതമ്യം ശരിയല്ല, കൃത്യമായി ആഗ്രഹിക്കുന്നതുപോലെ.
        //
        self.abs_private() < Self::INFINITY
    }

    /// നമ്പർ [subnormal] ആണെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // `0` നും `min` നും ഇടയിലുള്ള മൂല്യങ്ങൾ അസാധാരണമാണ്.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// സംഖ്യ പൂജ്യമോ അനന്തമോ [subnormal] അല്ലെങ്കിൽ `NaN` അല്ലെങ്കിലോ `true` നൽകുന്നു.
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // `0` നും `min` നും ഇടയിലുള്ള മൂല്യങ്ങൾ അസാധാരണമാണ്.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// നമ്പറിന്റെ ഫ്ലോട്ടിംഗ് പോയിൻറ് വിഭാഗം നൽകുന്നു.
    /// ഒരു പ്രോപ്പർ‌ട്ടി മാത്രം പരീക്ഷിക്കാൻ‌പോകുകയാണെങ്കിൽ‌, പകരം നിർ‌ദ്ദിഷ്‌ട പ്രവചനം ഉപയോഗിക്കുന്നത് സാധാരണയായി വേഗതയേറിയതാണ്.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// X002, പോസിറ്റീവ് ചിഹ്ന ബിറ്റ്, പോസിറ്റീവ് അനന്തത എന്നിവയുള്ള `NaN`-കൾ ഉൾപ്പെടെ ഒരു പോസിറ്റീവ് ചിഹ്നം `self`-ന് ഉണ്ടെങ്കിൽ `true` നൽകുന്നു.
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// X002, നെഗറ്റീവ് ചിഹ്ന ബിറ്റ്, നെഗറ്റീവ് അനന്തത എന്നിവയുൾപ്പെടെ `NaN`-കൾ ഉൾപ്പെടെ, നെഗറ്റീവ് ചിഹ്നം `self`-ന് ഉണ്ടെങ്കിൽ `true` നൽകുന്നു.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // IEEE754 പറയുന്നു: x ന് നെഗറ്റീവ് ചിഹ്നമുണ്ടെങ്കിൽ മാത്രം isSignMinus(x) ശരിയാണ്.
        // isSignMinus പൂജ്യങ്ങൾക്കും NaN-കൾക്കും ബാധകമാണ്.
        self.to_bits() & 0x8000_0000 != 0
    }

    /// ഒരു സംഖ്യയുടെ പരസ്പര (inverse) എടുക്കുന്നു, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// റേഡിയൻസിനെ ഡിഗ്രികളിലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // മികച്ച കൃത്യതയ്ക്കായി ഒരു സ്ഥിരാങ്കം ഉപയോഗിക്കുക.
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// ഡിഗ്രികളെ റേഡിയൻസിലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// രണ്ട് അക്കങ്ങളുടെ പരമാവധി നൽകുന്നു.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// ആർ‌ഗ്യുമെൻറുകളിലൊന്ന് NaN ആണെങ്കിൽ‌, മറ്റ് ആർ‌ഗ്യുമെൻറ് മടക്കിനൽകുന്നു.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// രണ്ട് അക്കങ്ങളുടെ ഏറ്റവും കുറഞ്ഞത് നൽകുന്നു.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// ആർ‌ഗ്യുമെൻറുകളിലൊന്ന് NaN ആണെങ്കിൽ‌, മറ്റ് ആർ‌ഗ്യുമെൻറ് മടക്കിനൽകുന്നു.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// മൂല്യം പരിമിതമാണെന്നും ആ തരത്തിൽ യോജിക്കുന്നുവെന്നും കരുതി പൂജ്യത്തിലേക്ക് തിരിയുകയും ഏത് പ്രാകൃത സംഖ്യ തരത്തിലേക്ക് പരിവർത്തനം ചെയ്യുകയും ചെയ്യുന്നു.
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// മൂല്യം നിർബന്ധമായും:
    ///
    /// * `NaN` ആകരുത്
    /// * അനന്തമായിരിക്കരുത്
    /// * അതിന്റെ ഭാഗിക ഭാഗം വെട്ടിച്ചുരുക്കിയ ശേഷം റിട്ടേൺ തരം `Int`-ൽ പ്രതിനിധീകരിക്കുക
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // സുരക്ഷ: വിളിക്കുന്നയാൾ `FloatToInt::to_int_unchecked`-നായുള്ള സുരക്ഷാ കരാർ പാലിക്കണം.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// `u32`-ലേക്ക് അസംസ്കൃത പരിവർത്തനം.
    ///
    /// ഇത് നിലവിൽ എല്ലാ പ്ലാറ്റ്ഫോമുകളിലും `transmute::<f32, u32>(self)` ന് സമാനമാണ്.
    ///
    /// ഈ പ്രവർത്തനത്തിന്റെ പോർട്ടബിലിറ്റിയെക്കുറിച്ചുള്ള ചില ചർച്ചകൾക്കായി `from_bits` കാണുക (മിക്കവാറും പ്രശ്നങ്ങളൊന്നുമില്ല).
    ///
    /// ഈ ഫംഗ്ഷൻ `as` കാസ്റ്റിംഗിൽ നിന്ന് വ്യത്യസ്തമാണ്, ഇത് *സംഖ്യാ* മൂല്യം സംരക്ഷിക്കാൻ ശ്രമിക്കുന്നു, ബിറ്റ്വൈസ് മൂല്യമല്ല.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() കാസ്റ്റുചെയ്യുന്നില്ല!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // സുരക്ഷ: `u32` എന്നത് പഴയ പഴയ ഡാറ്റാ ടൈപ്പാണ്, അതിനാൽ ഞങ്ങൾക്ക് എല്ലായ്പ്പോഴും അതിലേക്ക് പരിവർത്തനം ചെയ്യാൻ കഴിയും
        unsafe { mem::transmute(self) }
    }

    /// `u32`-ൽ നിന്നുള്ള അസംസ്കൃത പരിവർത്തനം.
    ///
    /// ഇത് നിലവിൽ എല്ലാ പ്ലാറ്റ്ഫോമുകളിലും `transmute::<u32, f32>(v)` ന് സമാനമാണ്.
    /// രണ്ട് കാരണങ്ങളാൽ ഇത് അവിശ്വസനീയമാംവിധം പോർട്ടബിൾ ആണെന്ന് ഇത് മാറുന്നു:
    ///
    /// * പിന്തുണയ്‌ക്കുന്ന എല്ലാ പ്ലാറ്റ്‌ഫോമുകളിലും ഫ്ലോട്ടുകൾക്കും ഇന്റുകൾക്കും ഒരേ അന്തർലീനതയുണ്ട്.
    /// * ഐ‌ഇ‌ഇ‌ഇ-754 ഫ്ലോട്ടുകളുടെ ബിറ്റ് ലേ layout ട്ട് വളരെ കൃത്യമായി വ്യക്തമാക്കുന്നു.
    ///
    /// എന്നിരുന്നാലും ഒരു മുന്നറിയിപ്പ് ഉണ്ട്: ഐ‌ഇ‌ഇഇ-754 ന്റെ 2008 പതിപ്പിന് മുമ്പ്, NaN സിഗ്നലിംഗ് ബിറ്റ് എങ്ങനെ വ്യാഖ്യാനിക്കണം എന്ന് യഥാർത്ഥത്തിൽ വ്യക്തമാക്കിയിട്ടില്ല.
    /// മിക്ക പ്ലാറ്റ്ഫോമുകളും (പ്രത്യേകിച്ച് x86, ARM) 2008 ൽ ആത്യന്തികമായി മാനദണ്ഡമാക്കിയ വ്യാഖ്യാനം തിരഞ്ഞെടുത്തു, പക്ഷേ ചിലത് ചെയ്തില്ല (പ്രത്യേകിച്ച് MIPS).
    /// തൽഫലമായി, MIPS-ലെ എല്ലാ സിഗ്നലിംഗ് NaN-കളും x86-ൽ ശാന്തമായ NaN-കളാണ്, തിരിച്ചും.
    ///
    /// സിഗ്നലിംഗ്-നെസ് ക്രോസ്-പ്ലാറ്റ്ഫോം സംരക്ഷിക്കാൻ ശ്രമിക്കുന്നതിനുപകരം, ഈ നടപ്പാക്കൽ കൃത്യമായ ബിറ്റുകൾ സംരക്ഷിക്കുന്നതിനെ അനുകൂലിക്കുന്നു.
    /// ഇതിനർത്ഥം, ഈ രീതിയുടെ ഫലം നെറ്റ്‌വർക്കിലൂടെ ഒരു x86 മെഷീനിൽ നിന്ന് MIPS ഒന്നിലേക്ക് അയച്ചാലും NaN-കളിൽ എൻ‌കോഡുചെയ്‌തിരിക്കുന്ന ഏതെങ്കിലും പേലോഡുകൾ സംരക്ഷിക്കപ്പെടും എന്നാണ്.
    ///
    ///
    /// ഈ രീതിയുടെ ഫലങ്ങൾ‌അവ നിർമ്മിച്ച അതേ വാസ്തുവിദ്യയിലൂടെ മാത്രമേ കൈകാര്യം ചെയ്യുകയുള്ളൂവെങ്കിൽ‌, പോർ‌ട്ടബിളിറ്റി ആശങ്കകളൊന്നുമില്ല.
    ///
    /// ഇൻ‌പുട്ട് NaN അല്ലെങ്കിൽ‌, പോർ‌ട്ടബിളിറ്റി ആശങ്കകളൊന്നുമില്ല.
    ///
    /// സിഗ്നലിംഗിനെക്കുറിച്ച് നിങ്ങൾ ശ്രദ്ധിക്കുന്നില്ലെങ്കിൽ (സാധ്യത), പോർട്ടബിലിറ്റി ആശങ്കകളൊന്നുമില്ല.
    ///
    /// ഈ ഫംഗ്ഷൻ `as` കാസ്റ്റിംഗിൽ നിന്ന് വ്യത്യസ്തമാണ്, ഇത് *സംഖ്യാ* മൂല്യം സംരക്ഷിക്കാൻ ശ്രമിക്കുന്നു, ബിറ്റ്വൈസ് മൂല്യമല്ല.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // സുരക്ഷ: `u32` എന്നത് പഴയ പഴയ ഡാറ്റാ ടൈപ്പാണ്, അതിനാൽ നമുക്ക് എല്ലായ്പ്പോഴും അതിൽ നിന്ന് പരിവർത്തനം ചെയ്യാൻ കഴിയും
        // SNaN-ലെ സുരക്ഷാ പ്രശ്‌നങ്ങൾ‌അമിതവേഗത്തിലായിരുന്നുവെന്ന് ഇത് മാറുന്നു!ഹൂറേ!
        unsafe { mem::transmute(v) }
    }

    /// ഈ ഫ്ലോട്ടിംഗ് പോയിൻറ് നമ്പറിന്റെ മെമ്മറി പ്രാതിനിധ്യം ബിഗ്-എൻ‌ഡിയൻ (network) ബൈറ്റ് ക്രമത്തിൽ ഒരു ബൈറ്റ് അറേ ആയി നൽകുക.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// ഈ ഫ്ലോട്ടിംഗ് പോയിൻറ് നമ്പറിന്റെ മെമ്മറി പ്രാതിനിധ്യം ചെറിയ-എൻ‌ഡിയൻ ബൈറ്റ് ക്രമത്തിൽ ഒരു ബൈറ്റ് അറേയായി നൽകുക.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// നേറ്റീവ് ബൈറ്റ് ക്രമത്തിൽ ഒരു ബൈറ്റ് അറേ ആയി ഈ ഫ്ലോട്ടിംഗ് പോയിൻറ് നമ്പറിന്റെ മെമ്മറി പ്രാതിനിധ്യം നൽകുക.
    ///
    /// ടാർ‌ഗെറ്റ് പ്ലാറ്റ്‌ഫോമിലെ നേറ്റീവ് എൻ‌ഡിയൻ‌നെസ് ഉപയോഗിക്കുന്നതിനാൽ‌, പകരം പോർ‌ട്ടബിൾ കോഡ് [`to_be_bytes`] അല്ലെങ്കിൽ‌[`to_le_bytes`] ഉപയോഗിക്കണം.
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// നേറ്റീവ് ബൈറ്റ് ക്രമത്തിൽ ഒരു ബൈറ്റ് അറേ ആയി ഈ ഫ്ലോട്ടിംഗ് പോയിൻറ് നമ്പറിന്റെ മെമ്മറി പ്രാതിനിധ്യം നൽകുക.
    ///
    ///
    /// [`to_ne_bytes`] സാധ്യമാകുമ്പോഴെല്ലാം ഇതിനെക്കാൾ മുൻഗണന നൽകണം.
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // സുരക്ഷ: `f32` എന്നത് പഴയ പഴയ ഡാറ്റാ ടൈപ്പാണ്, അതിനാൽ ഞങ്ങൾക്ക് എല്ലായ്പ്പോഴും അതിലേക്ക് പരിവർത്തനം ചെയ്യാൻ കഴിയും
        unsafe { &*(self as *const Self as *const _) }
    }

    /// ബിഗ് എൻ‌ഡിയനിലെ ഒരു ബൈറ്റ് അറേയായി അതിന്റെ പ്രാതിനിധ്യത്തിൽ നിന്ന് ഒരു ഫ്ലോട്ടിംഗ് പോയിൻറ് മൂല്യം സൃഷ്ടിക്കുക.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// ചെറിയ എൻ‌ഡിയനിൽ‌ഒരു ബൈറ്റ് അറേയായി അതിന്റെ പ്രാതിനിധ്യത്തിൽ‌നിന്നും ഒരു ഫ്ലോട്ടിംഗ് പോയിൻറ് മൂല്യം സൃഷ്‌ടിക്കുക.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// നേറ്റീവ് എൻ‌ഡിയനിലെ ഒരു ബൈറ്റ് അറേയായി അതിന്റെ പ്രാതിനിധ്യത്തിൽ നിന്ന് ഒരു ഫ്ലോട്ടിംഗ് പോയിൻറ് മൂല്യം സൃഷ്ടിക്കുക.
    ///
    /// ടാർ‌ഗെറ്റ് പ്ലാറ്റ്‌ഫോമിലെ നേറ്റീവ് എൻ‌ഡിയൻ‌നെസ് ഉപയോഗിക്കുന്നതിനാൽ‌, പകരം പോർ‌ട്ടബിൾ കോഡ് [`from_be_bytes`] അല്ലെങ്കിൽ‌[`from_le_bytes`] ഉപയോഗിക്കാൻ‌താൽ‌പ്പര്യപ്പെടുന്നു.
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// സ്വയവും മറ്റ് മൂല്യങ്ങളും തമ്മിലുള്ള ഒരു ക്രമം നൽകുന്നു.
    /// ഫ്ലോട്ടിംഗ് പോയിൻറ് നമ്പറുകൾ തമ്മിലുള്ള സ്റ്റാൻഡേർഡ് ഭാഗിക താരതമ്യത്തിൽ നിന്ന് വ്യത്യസ്തമായി, ഈ താരതമ്യം എല്ലായ്പ്പോഴും ടോട്ടൽ ഓർഡർ പ്രവചനത്തിന് അനുസൃതമായി ഒരു ഓർഡറിംഗ് ഉൽ‌പാദിപ്പിക്കുന്നു.
    /// മൂല്യങ്ങൾ ഇനിപ്പറയുന്ന ക്രമത്തിൽ ക്രമീകരിച്ചിരിക്കുന്നു:
    /// - നെഗറ്റീവ് ശാന്തമായ NaN
    /// - നെഗറ്റീവ് സിഗ്നലിംഗ് NaN
    /// - നെഗറ്റീവ് അനന്തത
    /// - നെഗറ്റീവ് നമ്പറുകൾ
    /// - നെഗറ്റീവ് സബ്നോർമൽ നമ്പറുകൾ
    /// - നെഗറ്റീവ് പൂജ്യം
    /// - പോസിറ്റീവ് പൂജ്യം
    /// - പോസിറ്റീവ് സബ്നോർമൽ നമ്പറുകൾ
    /// - പോസിറ്റീവ് നമ്പറുകൾ
    /// - പോസിറ്റീവ് അനന്തത
    /// - പോസിറ്റീവ് സിഗ്നലിംഗ് NaN
    /// - പോസിറ്റീവ് ശാന്തമായ NaN
    ///
    /// `f32`-ന്റെ [`PartialOrd`], [`PartialEq`] നടപ്പിലാക്കലുകളുമായി ഈ ഫംഗ്ഷൻ എല്ലായ്പ്പോഴും യോജിക്കുന്നില്ലെന്നത് ശ്രദ്ധിക്കുക.പ്രത്യേകിച്ചും, അവർ നെഗറ്റീവ്, പോസിറ്റീവ് പൂജ്യം തുല്യമായി കണക്കാക്കുന്നു, അതേസമയം `total_cmp` അങ്ങനെ ചെയ്യുന്നില്ല.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // നിർദേശങ്ങളുടെ കാര്യത്തിൽ, രണ്ടിന്റെ പൂരക സംഖ്യകളായി സമാനമായ ലേ layout ട്ട് നേടുന്നതിന് ചിഹ്നം ഒഴികെയുള്ള എല്ലാ ബിറ്റുകളും ഫ്ലിപ്പുചെയ്യുക
        //
        // എന്തുകൊണ്ടാണ് ഇത് പ്രവർത്തിക്കുന്നത്?ഐ‌ഇ‌ഇഇ 754 ഫ്ലോട്ടുകൾ‌മൂന്ന്‌ഫീൽ‌ഡുകൾ‌ഉൾക്കൊള്ളുന്നു:
        // ബിറ്റ്, എക്‌സ്‌പോണന്റ്, മാന്റിസ എന്നിവ അടയാളപ്പെടുത്തുക.എക്‌സ്‌പോണന്റ്, മാന്റിസ ഫീൽഡുകൾക്ക് മൊത്തത്തിൽ അവയുടെ ബിറ്റ്വൈസ് ക്രമം മാഗ്നിറ്റ്യൂഡ് നിർവചിച്ചിരിക്കുന്ന സംഖ്യാ മാഗ്നിറ്റ്യൂഡിന് തുല്യമാണ്.
        // മാഗ്നിറ്റ്യൂഡ് സാധാരണയായി NaN മൂല്യങ്ങളിൽ നിർവചിക്കപ്പെട്ടിട്ടില്ല, എന്നാൽ ഐ‌ഇ‌ഇഇ 754 ടോട്ടൽ ഓർഡർ, ബിറ്റ്വൈസ് ക്രമം പാലിക്കുന്നതിന് NaN മൂല്യങ്ങളെയും നിർവചിക്കുന്നു.ഇത് പ്രമാണ അഭിപ്രായത്തിൽ വിശദീകരിച്ച ക്രമത്തിലേക്ക് നയിക്കുന്നു.
        // എന്നിരുന്നാലും, നെഗറ്റീവ്, പോസിറ്റീവ് സംഖ്യകൾക്ക് മാഗ്നിറ്റ്യൂഡിന്റെ പ്രാതിനിധ്യം തുല്യമാണ്-ചിഹ്ന ബിറ്റ് മാത്രം വ്യത്യസ്തമാണ്.
        // ഒപ്പിട്ട സംഖ്യകളായി ഫ്ലോട്ടുകളെ എളുപ്പത്തിൽ താരതമ്യം ചെയ്യാൻ, നെഗറ്റീവ് സംഖ്യകളുടെ കാര്യത്തിൽ ഞങ്ങൾ എക്‌സ്‌പോണന്റ്, മാന്റിസ ബിറ്റുകൾ ഫ്ലിപ്പുചെയ്യേണ്ടതുണ്ട്.
        // ഞങ്ങൾ നമ്പറുകളെ "two's complement" ഫോമിലേക്ക് ഫലപ്രദമായി പരിവർത്തനം ചെയ്യുന്നു.
        //
        // ഫ്ലിപ്പിംഗ് ചെയ്യുന്നതിന്, ഞങ്ങൾ അതിനെതിരെ ഒരു മാസ്കും XOR ഉം നിർമ്മിക്കുന്നു.
        // നെഗറ്റീവ്-ഒപ്പിട്ട മൂല്യങ്ങളിൽ നിന്ന് ഞങ്ങൾ ഒരു "all-ones except for the sign bit" മാസ്ക് ശാഖകളില്ലാതെ കണക്കാക്കുന്നു: വലത് ഷിഫ്റ്റിംഗ് പൂർണ്ണസംഖ്യയെ വിപുലീകരിക്കുന്നു, അതിനാൽ ഞങ്ങൾ ചിഹ്ന ബിറ്റുകൾ ഉപയോഗിച്ച് മാസ്ക് "fill" ചെയ്യുന്നു, തുടർന്ന് ഒപ്പിടാത്തതിലേക്ക് പരിവർത്തനം ചെയ്ത് ഒരു പൂജ്യം ബിറ്റ് കൂടി നീക്കുന്നു.
        //
        // പോസിറ്റീവ് മൂല്യങ്ങളിൽ, മാസ്ക് എല്ലാം പൂജ്യങ്ങളാണ്, അതിനാൽ ഇത് ഒരു നോ-ഒപ്പ് ആണ്.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// NaN അല്ലാത്തപക്ഷം ഒരു നിശ്ചിത ഇടവേളയിലേക്ക് ഒരു മൂല്യം നിയന്ത്രിക്കുക.
    ///
    /// `self` `max` നേക്കാൾ വലുതാണെങ്കിൽ `max`, `self` `min` നേക്കാൾ കുറവാണെങ്കിൽ `min` എന്നിവ നൽകുന്നു.
    /// അല്ലെങ്കിൽ ഇത് `self` നൽകുന്നു.
    ///
    /// പ്രാരംഭ മൂല്യം NaN ആണെങ്കിൽ ഈ ഫംഗ്ഷൻ NaN നൽകുന്നു.
    ///
    /// # Panics
    ///
    /// `min > max`, `min` NaN ആണെങ്കിൽ അല്ലെങ്കിൽ `max` NaN ആണെങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}