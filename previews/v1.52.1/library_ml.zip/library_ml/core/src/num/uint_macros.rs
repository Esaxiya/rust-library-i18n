macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// ഈ സംഖ്യ തരം പ്രതിനിധീകരിക്കാൻ കഴിയുന്ന ഏറ്റവും ചെറിയ മൂല്യം.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// ഈ സംഖ്യ തരം പ്രതിനിധീകരിക്കാൻ കഴിയുന്ന ഏറ്റവും വലിയ മൂല്യം.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// ബിറ്റുകളിൽ ഈ പൂർണ്ണസംഖ്യയുടെ വലുപ്പം.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// തന്നിരിക്കുന്ന അടിത്തറയിലെ ഒരു സ്‌ട്രിംഗ് സ്ലൈസ് ഒരു പൂർണ്ണസംഖ്യയിലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
        ///
        /// സ്ട്രിംഗ് ഒരു ഓപ്‌ഷണൽ `+` ചിഹ്നവും അക്കങ്ങൾക്ക് ശേഷം ആയിരിക്കുമെന്ന് പ്രതീക്ഷിക്കുന്നു.
        ///
        /// വൈറ്റ്‌സ്‌പെയ്‌സ് നയിക്കുന്നതും പിന്തുടരുന്നതും ഒരു പിശകിനെ പ്രതിനിധീകരിക്കുന്നു.
        /// `radix` നെ ആശ്രയിച്ച് അക്കങ്ങൾ ഈ പ്രതീകങ്ങളുടെ ഒരു ഉപസെറ്റാണ്:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// `radix` 2 മുതൽ 36 വരെയുള്ള പരിധിയിലല്ലെങ്കിൽ ഈ പ്രവർത്തനം panics.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// `self`-ന്റെ ബൈനറി പ്രാതിനിധ്യത്തിലുള്ളവയുടെ എണ്ണം നൽകുന്നു.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// `self`-ന്റെ ബൈനറി പ്രാതിനിധ്യത്തിലെ പൂജ്യങ്ങളുടെ എണ്ണം നൽകുന്നു.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// `self`-ന്റെ ബൈനറി പ്രാതിനിധ്യത്തിലെ പ്രമുഖ പൂജ്യങ്ങളുടെ എണ്ണം നൽകുന്നു.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// `self`-ന്റെ ബൈനറി പ്രാതിനിധ്യത്തിൽ പിന്തുടരുന്ന പൂജ്യങ്ങളുടെ എണ്ണം നൽകുന്നു.
        ///
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// `self`-ന്റെ ബൈനറി പ്രാതിനിധ്യത്തിലെ മുൻ‌നിരയിലുള്ളവരുടെ എണ്ണം നൽകുന്നു.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// `self`-ന്റെ ബൈനറി പ്രാതിനിധ്യത്തിൽ പിന്നിലായവരുടെ എണ്ണം നൽകുന്നു.
        ///
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// വെട്ടിച്ചുരുക്കിയ ബിറ്റുകൾ ഒരു നിശ്ചിത തുകയായ `n` ഉപയോഗിച്ച് ഇടതുവശത്തേക്ക് മാറ്റുന്നു, തത്ഫലമായുണ്ടാകുന്ന സംഖ്യയുടെ അവസാനം വരെ ചുരുക്കിയിരിക്കുന്നു.
        ///
        ///
        /// ഇത് `<<` ഷിഫ്റ്റിംഗ് ഓപ്പറേറ്ററിന്റെ അതേ പ്രവർത്തനമല്ലെന്ന് ദയവായി ശ്രദ്ധിക്കുക!
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// വെട്ടിച്ചുരുക്കിയ ബിറ്റുകൾ ഒരു നിശ്ചിത തുകയായ `n` ഉപയോഗിച്ച് വലതുവശത്തേക്ക് മാറ്റുന്നു, തത്ഫലമായുണ്ടാകുന്ന സംഖ്യയുടെ തുടക്കത്തിലേക്ക് ചുരുക്കിയ ബിറ്റുകൾ പൊതിയുന്നു.
        ///
        ///
        /// ഇത് `>>` ഷിഫ്റ്റിംഗ് ഓപ്പറേറ്ററിന്റെ അതേ പ്രവർത്തനമല്ലെന്ന് ദയവായി ശ്രദ്ധിക്കുക!
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// സംഖ്യയുടെ ബൈറ്റ് ക്രമം വിപരീതമാക്കുന്നു.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// m= n.swap_bytes() അനുവദിക്കുക;
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// പൂർണ്ണസംഖ്യയിലെ ബിറ്റുകളുടെ ക്രമം വിപരീതമാക്കുന്നു.
        /// ഏറ്റവും പ്രധാനപ്പെട്ട ബിറ്റ് ഏറ്റവും പ്രധാനപ്പെട്ട ബിറ്റായി മാറുന്നു, രണ്ടാമത്തെ ഏറ്റവും പ്രാധാന്യമുള്ള ബിറ്റ് രണ്ടാമത്തെ ഏറ്റവും പ്രധാനപ്പെട്ട ബിറ്റായി മാറുന്നു.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// m= n.reverse_bits() അനുവദിക്കുക;
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// ബിഗ് എൻ‌ഡിയനിൽ‌നിന്നും ടാർ‌ഗെറ്റിന്റെ എൻ‌ഡിയൻ‌നെസിലേക്ക് ഒരു സംഖ്യയെ പരിവർത്തനം ചെയ്യുന്നു.
        ///
        /// വലിയ എൻ‌ഡിയനിൽ‌ഇത് ഒരു നോ-ഒപ്പ് ആണ്.
        /// ചെറിയ എൻ‌ഡിയനിൽ‌ബൈറ്റുകൾ‌കൈമാറ്റം ചെയ്യപ്പെടുന്നു.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// cfg ആണെങ്കിൽ! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } else {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// ചെറിയ എൻ‌ഡിയനിൽ‌നിന്നും ടാർ‌ഗെറ്റിന്റെ എൻ‌ഡിയൻ‌നെസിലേക്ക് ഒരു സംഖ്യയെ പരിവർത്തനം ചെയ്യുന്നു.
        ///
        /// ചെറിയ എൻ‌ഡിയനിൽ‌ഇത് ഒരു നോ-ഒപ്പ് ആണ്.
        /// വലിയ എൻ‌ഡിയനിൽ‌ബൈറ്റുകൾ‌കൈമാറ്റം ചെയ്യപ്പെടുന്നു.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// cfg ആണെങ്കിൽ! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } else {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// ടാർഗറ്റിന്റെ എൻ‌ഡിയൻ‌നെസിൽ‌നിന്നും `self` വലിയ എൻ‌ഡിയനായി പരിവർത്തനം ചെയ്യുന്നു.
        ///
        /// വലിയ എൻ‌ഡിയനിൽ‌ഇത് ഒരു നോ-ഒപ്പ് ആണ്.
        /// ചെറിയ എൻ‌ഡിയനിൽ‌ബൈറ്റുകൾ‌കൈമാറ്റം ചെയ്യപ്പെടുന്നു.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// cfg ആണെങ്കിൽ! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } else { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // അല്ലെങ്കിൽ ഉണ്ടാകരുത്?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// ടാർഗറ്റിന്റെ എൻ‌ഡിയൻ‌നെസിൽ‌നിന്നും `self` നെ ചെറിയ എൻ‌ഡിയനായി പരിവർത്തനം ചെയ്യുന്നു.
        ///
        /// ചെറിയ എൻ‌ഡിയനിൽ‌ഇത് ഒരു നോ-ഒപ്പ് ആണ്.
        /// വലിയ എൻ‌ഡിയനിൽ‌ബൈറ്റുകൾ‌കൈമാറ്റം ചെയ്യപ്പെടുന്നു.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// cfg ആണെങ്കിൽ! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } else { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// പൂർണ്ണസംഖ്യ ചേർക്കുന്നത് പരിശോധിച്ചു.
        /// `self + rhs` കണക്കാക്കുന്നു, ഓവർഫ്ലോ സംഭവിച്ചാൽ `None` നൽകുന്നു.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// അൺചെക്കുചെയ്‌ത സംഖ്യ കൂട്ടിച്ചേർക്കൽ.ഓവർഫ്ലോ സംഭവിക്കില്ലെന്ന് കരുതുക, `self + rhs` കണക്കാക്കുന്നു.
        /// ഇത് എപ്പോൾ നിർവചിക്കപ്പെടാത്ത പെരുമാറ്റത്തിന് കാരണമാകുന്നു
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // സുരക്ഷ: വിളിക്കുന്നയാൾ `unchecked_add`-നായുള്ള സുരക്ഷാ കരാർ പാലിക്കണം.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// പരിശോധിച്ച സംഖ്യ കുറയ്ക്കൽ.
        /// `self - rhs` കണക്കാക്കുന്നു, ഓവർഫ്ലോ സംഭവിച്ചാൽ `None` നൽകുന്നു.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// അൺചെക്കുചെയ്ത സംഖ്യ കുറയ്ക്കൽ.ഓവർഫ്ലോ സംഭവിക്കില്ലെന്ന് കരുതുക, `self - rhs` കണക്കാക്കുന്നു.
        /// ഇത് എപ്പോൾ നിർവചിക്കപ്പെടാത്ത പെരുമാറ്റത്തിന് കാരണമാകുന്നു
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // സുരക്ഷ: വിളിക്കുന്നയാൾ `unchecked_sub`-നായുള്ള സുരക്ഷാ കരാർ പാലിക്കണം.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// പരിശോധിച്ച സംഖ്യ ഗുണനം.
        /// `self * rhs` കണക്കാക്കുന്നു, ഓവർഫ്ലോ സംഭവിച്ചാൽ `None` നൽകുന്നു.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// അൺചെക്കുചെയ്‌ത സംഖ്യ ഗുണനം.ഓവർഫ്ലോ സംഭവിക്കില്ലെന്ന് കരുതുക, `self * rhs` കണക്കാക്കുന്നു.
        /// ഇത് എപ്പോൾ നിർവചിക്കപ്പെടാത്ത പെരുമാറ്റത്തിന് കാരണമാകുന്നു
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // സുരക്ഷ: വിളിക്കുന്നയാൾ `unchecked_mul`-നായുള്ള സുരക്ഷാ കരാർ പാലിക്കണം.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// ഇൻറിജർ ഡിവിഷൻ പരിശോധിച്ചു.
        /// `self / rhs` കണക്കാക്കുന്നു, `rhs == 0` എങ്കിൽ `None` നൽകുന്നു.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // സുരക്ഷ: പൂജ്യം പ്രകാരം പൂജ്യം മുകളിൽ പരിശോധിക്കുകയും ഒപ്പിടാത്ത തരങ്ങൾക്ക് മറ്റൊന്നില്ല
                // വിഭജനത്തിനുള്ള പരാജയ മോഡുകൾ
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// യൂക്ലിഡിയൻ ഡിവിഷൻ പരിശോധിച്ചു.
        /// `self.div_euclid(rhs)` കണക്കാക്കുന്നു, `rhs == 0` എങ്കിൽ `None` നൽകുന്നു.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// പരിശോധിച്ച സംഖ്യ ബാക്കി.
        /// `self % rhs` കണക്കാക്കുന്നു, `rhs == 0` എങ്കിൽ `None` നൽകുന്നു.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // സുരക്ഷ: പൂജ്യം പ്രകാരം പൂജ്യം മുകളിൽ പരിശോധിക്കുകയും ഒപ്പിടാത്ത തരങ്ങൾക്ക് മറ്റൊന്നില്ല
                // വിഭജനത്തിനുള്ള പരാജയ മോഡുകൾ
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// യൂക്ലിഡിയൻ മൊഡ്യൂളോ പരിശോധിച്ചു.
        /// `self.rem_euclid(rhs)` കണക്കാക്കുന്നു, `rhs == 0` എങ്കിൽ `None` നൽകുന്നു.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// നിരസിച്ച പരിശോധന.`സ്വയം==അല്ലാതെ `-self` കണക്കാക്കുന്നു, `None` നൽകുന്നു
        /// 0`.
        ///
        /// ഏതെങ്കിലും പോസിറ്റീവ് സംഖ്യ നിരസിക്കുന്നത് കവിഞ്ഞൊഴുകുമെന്നത് ശ്രദ്ധിക്കുക.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// പരിശോധിച്ച ഷിഫ്റ്റ് ഇടത്.
        /// `self << rhs` കണക്കാക്കുന്നു, `rhs` `self` ലെ ബിറ്റുകളുടെ എണ്ണത്തേക്കാൾ വലുതോ തുല്യമോ ആണെങ്കിൽ `None` നൽകുന്നു.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// വലത് പരിശോധിച്ചു.
        /// `self >> rhs` കണക്കാക്കുന്നു, `rhs` `self` ലെ ബിറ്റുകളുടെ എണ്ണത്തേക്കാൾ വലുതോ തുല്യമോ ആണെങ്കിൽ `None` നൽകുന്നു.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// എക്‌സ്‌പോണൻസേഷൻ പരിശോധിച്ചു.
        /// `self.pow(exp)` കണക്കാക്കുന്നു, ഓവർഫ്ലോ സംഭവിച്ചാൽ `None` നൽകുന്നു.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // exp!=0 മുതൽ, ഒടുവിൽ exp 1 ആയിരിക്കണം.
            // എക്‌സ്‌പോണന്റിലെ അവസാന ബിറ്റുമായി പ്രത്യേകം ഇടപെടുക, കാരണം അടിസ്ഥാനത്തെ പിന്നീട് ചതുരപ്പെടുത്തുന്നത് ആവശ്യമില്ലാത്തതിനാൽ ആവശ്യമില്ലാത്ത ഓവർഫ്ലോയ്ക്ക് കാരണമായേക്കാം.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// പൂരിത സംഖ്യ സങ്കലനം.
        /// `self + rhs` കണക്കാക്കുന്നു, കവിഞ്ഞൊഴുകുന്നതിനുപകരം സംഖ്യാ പരിധികളിൽ പൂരിതമാക്കുന്നു.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// പൂരിത സംഖ്യ കുറയ്ക്കൽ.
        /// `self - rhs` കണക്കാക്കുന്നു, കവിഞ്ഞൊഴുകുന്നതിനുപകരം സംഖ്യാ പരിധികളിൽ പൂരിതമാക്കുന്നു.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// പൂരിത സംഖ്യ ഗുണനം.
        /// `self * rhs` കണക്കാക്കുന്നു, കവിഞ്ഞൊഴുകുന്നതിനുപകരം സംഖ്യാ പരിധികളിൽ പൂരിതമാക്കുന്നു.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// പൂരിത സംഖ്യ എക്‌സ്‌പോണൻസേഷൻ.
        /// `self.pow(exp)` കണക്കാക്കുന്നു, കവിഞ്ഞൊഴുകുന്നതിനുപകരം സംഖ്യാ പരിധികളിൽ പൂരിതമാക്കുന്നു.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// (modular) സങ്കലനം പൊതിയുന്നു.
        /// `self + rhs` കണക്കാക്കുന്നു, തരത്തിന്റെ അതിർത്തിയിൽ ചുറ്റുന്നു.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// (modular) കുറയ്ക്കൽ പൊതിയുന്നു.
        /// `self - rhs` കണക്കാക്കുന്നു, തരത്തിന്റെ അതിർത്തിയിൽ ചുറ്റുന്നു.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// (modular) ഗുണനം പൊതിയുന്നു.
        /// `self * rhs` കണക്കാക്കുന്നു, തരത്തിന്റെ അതിർത്തിയിൽ ചുറ്റുന്നു.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ഈ ഉദാഹരണം പൂർണ്ണസംഖ്യകൾക്കിടയിൽ പങ്കിടുന്നുവെന്നത് ശ്രദ്ധിക്കുക.
        /// എന്തുകൊണ്ടാണ് `u8` ഇവിടെ ഉപയോഗിക്കുന്നതെന്ന് ഇത് വിശദീകരിക്കുന്നു.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// (modular) ഡിവിഷൻ പൊതിയുന്നു.`self / rhs` കണക്കാക്കുന്നു.
        /// ഒപ്പിടാത്ത തരങ്ങളിൽ പൊതിഞ്ഞ വിഭജനം സാധാരണ വിഭജനം മാത്രമാണ്.
        /// പൊതിയുന്നത് ഒരിക്കലും സംഭവിക്കാൻ ഒരു വഴിയുമില്ല.
        /// ഈ പ്രവർത്തനം നിലവിലുണ്ട്, അതിനാൽ എല്ലാ പ്രവർത്തനങ്ങളും റാപ്പിംഗ് പ്രവർത്തനങ്ങളിൽ കണക്കാക്കപ്പെടുന്നു.
        ///
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// യൂക്ലിഡിയൻ ഡിവിഷൻ പൊതിയുന്നു.`self.div_euclid(rhs)` കണക്കാക്കുന്നു.
        /// ഒപ്പിടാത്ത തരങ്ങളിൽ പൊതിഞ്ഞ വിഭജനം സാധാരണ വിഭജനം മാത്രമാണ്.
        /// പൊതിയുന്നത് ഒരിക്കലും സംഭവിക്കാൻ ഒരു വഴിയുമില്ല.
        /// ഈ പ്രവർത്തനം നിലവിലുണ്ട്, അതിനാൽ എല്ലാ പ്രവർത്തനങ്ങളും റാപ്പിംഗ് പ്രവർത്തനങ്ങളിൽ കണക്കാക്കപ്പെടുന്നു.
        /// പോസിറ്റീവ് സംഖ്യകൾക്ക്, വിഭജനത്തിന്റെ പൊതുവായ എല്ലാ നിർവചനങ്ങളും തുല്യമായതിനാൽ, ഇത് `self.wrapping_div(rhs)` ന് തുല്യമാണ്.
        ///
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// (modular) ബാക്കിയുള്ളവ പൊതിയുന്നു.`self % rhs` കണക്കാക്കുന്നു.
        /// ഒപ്പിടാത്ത തരങ്ങളിൽ ബാക്കിയുള്ള കണക്കുകൂട്ടൽ സാധാരണ ബാക്കി കണക്കുകൂട്ടൽ മാത്രമാണ്.
        ///
        /// പൊതിയുന്നത് ഒരിക്കലും സംഭവിക്കാൻ ഒരു വഴിയുമില്ല.
        /// ഈ പ്രവർത്തനം നിലവിലുണ്ട്, അതിനാൽ എല്ലാ പ്രവർത്തനങ്ങളും റാപ്പിംഗ് പ്രവർത്തനങ്ങളിൽ കണക്കാക്കപ്പെടുന്നു.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// യൂക്ലിഡിയൻ മൊഡ്യൂളോ പൊതിയുന്നു.`self.rem_euclid(rhs)` കണക്കാക്കുന്നു.
        /// ഒപ്പിടാത്ത തരങ്ങളിൽ പൊതിഞ്ഞ മൊഡ്യൂളോ കണക്കുകൂട്ടൽ സാധാരണ ബാക്കി കണക്കുകൂട്ടൽ മാത്രമാണ്.
        /// പൊതിയുന്നത് ഒരിക്കലും സംഭവിക്കാൻ ഒരു വഴിയുമില്ല.
        /// ഈ പ്രവർത്തനം നിലവിലുണ്ട്, അതിനാൽ എല്ലാ പ്രവർത്തനങ്ങളും റാപ്പിംഗ് പ്രവർത്തനങ്ങളിൽ കണക്കാക്കപ്പെടുന്നു.
        /// പോസിറ്റീവ് സംഖ്യകൾക്ക്, വിഭജനത്തിന്റെ പൊതുവായ എല്ലാ നിർവചനങ്ങളും തുല്യമായതിനാൽ, ഇത് `self.wrapping_rem(rhs)` ന് തുല്യമാണ്.
        ///
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// (modular) നിരസിക്കൽ പൊതിയുന്നു.
        /// `-self` കണക്കാക്കുന്നു, തരത്തിന്റെ അതിർത്തിയിൽ ചുറ്റുന്നു.
        ///
        /// ഒപ്പിടാത്ത തരങ്ങൾക്ക് നെഗറ്റീവ് തുല്യതകളില്ലാത്തതിനാൽ, ഈ ഫംഗ്ഷന്റെ എല്ലാ ആപ്ലിക്കേഷനുകളും പൊതിയുന്നു (`-0` ഒഴികെ).
        /// ഒപ്പിട്ട തരത്തിന്റെ പരമാവധി മൂല്യത്തേക്കാൾ ചെറു മൂല്യങ്ങൾക്ക്, ഫലം ഒപ്പിട്ട മൂല്യം കാസ്റ്റുചെയ്യുന്നതിന് തുല്യമാണ്.
        ///
        /// ഏത് വലിയ മൂല്യങ്ങളും `MAX + 1 - (val - MAX - 1)` ന് തുല്യമാണ്, ഇവിടെ `MAX` എന്നത് ഒപ്പിട്ട തരത്തിന്റെ പരമാവധി ആണ്.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ഈ ഉദാഹരണം പൂർണ്ണസംഖ്യകൾക്കിടയിൽ പങ്കിടുന്നുവെന്നത് ശ്രദ്ധിക്കുക.
        /// എന്തുകൊണ്ടാണ് `i8` ഇവിടെ ഉപയോഗിക്കുന്നതെന്ന് ഇത് വിശദീകരിക്കുന്നു.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-രഹിത ബിറ്റ്വൈസ് ഷിഫ്റ്റ്-ഇടത്;
        /// `self << mask(rhs)` നൽകുന്നു, ഇവിടെ `mask`, `rhs`-ന്റെ ഏതെങ്കിലും ഉയർന്ന ഓർഡർ ബിറ്റുകൾ നീക്കംചെയ്യുന്നു, അത് ഷിഫ്റ്റ് തരത്തിന്റെ ബിറ്റ്വിഡ്ത്ത് കവിയാൻ കാരണമാകും.
        ///
        /// ഇത് ഒരു റൊട്ടേറ്റ്-ഇടത് പോലെ *അല്ല* എന്നത് ശ്രദ്ധിക്കുക;റാപ്പിംഗ് ഷിഫ്റ്റ്-ലെഫ്റ്റിന്റെ ആർ‌എച്ച്‌എസ് തരം പരിധിയിലേക്ക് പരിമിതപ്പെടുത്തിയിരിക്കുന്നു, എൽ‌എച്ച്‌എസിൽ നിന്ന് മാറ്റിയ ബിറ്റുകൾ മറ്റേ അറ്റത്തേക്ക് മടങ്ങുന്നതിന് പകരം.
        /// പ്രാകൃത സംഖ്യ തരങ്ങളെല്ലാം ഒരു [`rotate_left`](Self::rotate_left) ഫംഗ്ഷൻ നടപ്പിലാക്കുന്നു, അത് നിങ്ങൾക്ക് ആവശ്യമുള്ളതായിരിക്കാം.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // സുരക്ഷ: തരം ബിറ്റ്സൈസ് ഉപയോഗിച്ച് മറയ്ക്കുന്നത് ഞങ്ങൾ മാറുന്നില്ലെന്ന് ഉറപ്പാക്കുന്നു
            // അതിർത്തിക്കപ്പുറത്താണ്
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-രഹിത ബിറ്റ്വൈസ് ഷിഫ്റ്റ്-വലത്;
        /// `self >> mask(rhs)` നൽകുന്നു, ഇവിടെ `mask`, `rhs`-ന്റെ ഏതെങ്കിലും ഉയർന്ന ഓർഡർ ബിറ്റുകൾ നീക്കംചെയ്യുന്നു, അത് ഷിഫ്റ്റ് തരത്തിന്റെ ബിറ്റ്വിഡ്ത്ത് കവിയാൻ കാരണമാകും.
        ///
        /// ഇത് ഒരു റൊട്ടേറ്റ്-റൈറ്റ് പോലെയല്ല *;റാപ്പിംഗ് ഷിഫ്റ്റ്-റൈറ്റിന്റെ ആർ‌എച്ച്‌എസ് തരം പരിധിയിലേക്ക് പരിമിതപ്പെടുത്തിയിരിക്കുന്നു, എൽ‌എച്ച്‌എസിൽ നിന്ന് മാറ്റിയ ബിറ്റുകൾ മറ്റേ അറ്റത്തേക്ക് മടങ്ങുന്നതിന് പകരം.
        /// പ്രാകൃത സംഖ്യ തരങ്ങളെല്ലാം ഒരു [`rotate_right`](Self::rotate_right) ഫംഗ്ഷൻ നടപ്പിലാക്കുന്നു, അത് നിങ്ങൾക്ക് ആവശ്യമുള്ളതായിരിക്കാം.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // സുരക്ഷ: തരം ബിറ്റ്സൈസ് ഉപയോഗിച്ച് മറയ്ക്കുന്നത് ഞങ്ങൾ മാറുന്നില്ലെന്ന് ഉറപ്പാക്കുന്നു
            // അതിർത്തിക്കപ്പുറത്താണ്
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// (modular) എക്‌സ്‌പോണൻ‌സിയേഷൻ പൊതിയുന്നു.
        /// `self.pow(exp)` കണക്കാക്കുന്നു, തരത്തിന്റെ അതിർത്തിയിൽ ചുറ്റുന്നു.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // exp!=0 മുതൽ, ഒടുവിൽ exp 1 ആയിരിക്കണം.
            // എക്‌സ്‌പോണന്റിലെ അവസാന ബിറ്റുമായി പ്രത്യേകം ഇടപെടുക, കാരണം അടിസ്ഥാനത്തെ പിന്നീട് ചതുരപ്പെടുത്തുന്നത് ആവശ്യമില്ലാത്തതിനാൽ ആവശ്യമില്ലാത്ത ഓവർഫ്ലോയ്ക്ക് കാരണമായേക്കാം.
            //
            //
            acc.wrapping_mul(base)
        }

        /// `self` + `rhs` കണക്കാക്കുന്നു
        ///
        /// ഒരു ഗണിത ഓവർഫ്ലോ സംഭവിക്കുമോ എന്ന് സൂചിപ്പിക്കുന്ന ഒരു ബൂലിയോടൊപ്പം സങ്കലനത്തിന്റെ ഒരു ട്യൂപ്പിൾ നൽകുന്നു.
        /// ഒരു ഓവർഫ്ലോ സംഭവിച്ചിരുന്നെങ്കിൽ പൊതിഞ്ഞ മൂല്യം തിരികെ നൽകും.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self`, `rhs` കണക്കാക്കുന്നു
        ///
        /// ഒരു ഗണിത ഓവർഫ്ലോ സംഭവിക്കുമോ എന്ന് സൂചിപ്പിക്കുന്ന ഒരു ബൂളിയോടൊപ്പം കുറയ്ക്കുന്നതിന്റെ ഒരു ട്യൂപ്പിൾ നൽകുന്നു.
        /// ഒരു ഓവർഫ്ലോ സംഭവിച്ചിരുന്നെങ്കിൽ പൊതിഞ്ഞ മൂല്യം തിരികെ നൽകും.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self`, `rhs` എന്നിവയുടെ ഗുണനം കണക്കാക്കുന്നു.
        ///
        /// ഒരു ഗണിത ഓവർഫ്ലോ സംഭവിക്കുമോ എന്ന് സൂചിപ്പിക്കുന്ന ഒരു ബൂലിയനോടൊപ്പം ഗുണനത്തിന്റെ ഒരു ട്യൂപ്പിൾ നൽകുന്നു.
        /// ഒരു ഓവർഫ്ലോ സംഭവിച്ചിരുന്നെങ്കിൽ പൊതിഞ്ഞ മൂല്യം തിരികെ നൽകും.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ഈ ഉദാഹരണം പൂർണ്ണസംഖ്യകൾക്കിടയിൽ പങ്കിടുന്നുവെന്നത് ശ്രദ്ധിക്കുക.
        /// എന്തുകൊണ്ടാണ് `u32` ഇവിടെ ഉപയോഗിക്കുന്നതെന്ന് ഇത് വിശദീകരിക്കുന്നു.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// `self` നെ `rhs` കൊണ്ട് ഹരിക്കുമ്പോൾ ഡിവൈസർ കണക്കാക്കുന്നു.
        ///
        /// ഒരു ഗണിത ഓവർഫ്ലോ സംഭവിക്കുമോ എന്ന് സൂചിപ്പിക്കുന്ന ഒരു ബൂളിയനൊപ്പം ഹരണത്തിന്റെ ഒരു ട്യൂപ്പിൾ നൽകുന്നു.
        /// സൈൻ ചെയ്യാത്ത സംഖ്യകൾക്ക് ഓവർഫ്ലോ ഒരിക്കലും സംഭവിക്കില്ല, അതിനാൽ രണ്ടാമത്തെ മൂല്യം എല്ലായ്പ്പോഴും `false` ആണ്.
        ///
        /// # Panics
        ///
        /// `rhs` 0 ആണെങ്കിൽ ഈ പ്രവർത്തനം panic ആയിരിക്കും.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// യൂക്ലിഡിയൻ ഡിവിഷൻ `self.div_euclid(rhs)` ന്റെ അളവ് കണക്കാക്കുന്നു.
        ///
        /// ഒരു ഗണിത ഓവർഫ്ലോ സംഭവിക്കുമോ എന്ന് സൂചിപ്പിക്കുന്ന ഒരു ബൂളിയനൊപ്പം ഹരണത്തിന്റെ ഒരു ട്യൂപ്പിൾ നൽകുന്നു.
        /// സൈൻ ചെയ്യാത്ത സംഖ്യകൾക്ക് ഓവർഫ്ലോ ഒരിക്കലും സംഭവിക്കില്ല, അതിനാൽ രണ്ടാമത്തെ മൂല്യം എല്ലായ്പ്പോഴും `false` ആണ്.
        /// പോസിറ്റീവ് സംഖ്യകൾക്ക്, വിഭജനത്തിന്റെ പൊതുവായ എല്ലാ നിർവചനങ്ങളും തുല്യമായതിനാൽ, ഇത് `self.overflowing_div(rhs)` ന് തുല്യമാണ്.
        ///
        ///
        /// # Panics
        ///
        /// `rhs` 0 ആണെങ്കിൽ ഈ പ്രവർത്തനം panic ആയിരിക്കും.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// `self` നെ `rhs` കൊണ്ട് ഹരിക്കുമ്പോൾ ബാക്കിയുള്ളത് കണക്കാക്കുന്നു.
        ///
        /// ഒരു ഗണിത ഓവർഫ്ലോ സംഭവിക്കുമോ എന്ന് സൂചിപ്പിക്കുന്ന ഒരു ബൂളിയനൊപ്പം വിഭജിച്ച ശേഷം ബാക്കിയുള്ളതിന്റെ ഒരു ട്യൂപ്പിൾ നൽകുന്നു.
        /// സൈൻ ചെയ്യാത്ത സംഖ്യകൾക്ക് ഓവർഫ്ലോ ഒരിക്കലും സംഭവിക്കില്ല, അതിനാൽ രണ്ടാമത്തെ മൂല്യം എല്ലായ്പ്പോഴും `false` ആണ്.
        ///
        /// # Panics
        ///
        /// `rhs` 0 ആണെങ്കിൽ ഈ പ്രവർത്തനം panic ആയിരിക്കും.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// ശേഷിക്കുന്ന `self.rem_euclid(rhs)` യൂക്ലിഡിയൻ ഡിവിഷൻ പോലെ കണക്കാക്കുന്നു.
        ///
        /// ഒരു ഗണിത ഓവർഫ്ലോ സംഭവിക്കുമോ എന്ന് സൂചിപ്പിക്കുന്ന ഒരു ബൂലിയനോടൊപ്പം വിഭജിച്ചതിന് ശേഷം മൊഡ്യൂളിന്റെ ഒരു ട്യൂപ്പിൾ നൽകുന്നു.
        /// സൈൻ ചെയ്യാത്ത സംഖ്യകൾക്ക് ഓവർഫ്ലോ ഒരിക്കലും സംഭവിക്കില്ല, അതിനാൽ രണ്ടാമത്തെ മൂല്യം എല്ലായ്പ്പോഴും `false` ആണ്.
        /// പോസിറ്റീവ് സംഖ്യകൾക്ക്, വിഭജനത്തിന്റെ പൊതുവായ എല്ലാ നിർവചനങ്ങളും തുല്യമായതിനാൽ, ഈ പ്രവർത്തനം `self.overflowing_rem(rhs)` ന് തുല്യമാണ്.
        ///
        ///
        /// # Panics
        ///
        /// `rhs` 0 ആണെങ്കിൽ ഈ പ്രവർത്തനം panic ആയിരിക്കും.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// കവിഞ്ഞൊഴുകുന്ന രീതിയിൽ സ്വയം നിരസിക്കുന്നു.
        ///
        /// ഒപ്പിടാത്ത ഈ മൂല്യത്തിന്റെ നിർദേശത്തെ പ്രതിനിധീകരിക്കുന്ന മൂല്യം നൽകുന്നതിന് റാപ്പിംഗ് പ്രവർത്തനങ്ങൾ ഉപയോഗിച്ച് `!self + 1` നൽകുന്നു.
        /// ഒപ്പിടാത്ത പോസിറ്റീവ് മൂല്യങ്ങൾക്കായി ഓവർഫ്ലോ എല്ലായ്പ്പോഴും സംഭവിക്കുന്നു, പക്ഷേ 0 നിരസിക്കുന്നത് കവിഞ്ഞൊഴുകുന്നില്ല.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// `rhs` ബിറ്റുകൾ സ്വയം ഇടത്തേക്ക് മാറ്റുന്നു.
        ///
        /// ഷിഫ്റ്റ് മൂല്യം ബിറ്റുകളുടെ എണ്ണത്തേക്കാൾ വലുതാണോ തുല്യമാണോ എന്ന് സൂചിപ്പിക്കുന്ന ഒരു ബൂളിയനൊപ്പം സ്വയത്തിന്റെ ഷിഫ്റ്റ് ചെയ്ത പതിപ്പിന്റെ ഒരു ട്യൂപ്പിൾ നൽകുന്നു.
        /// ഷിഫ്റ്റ് മൂല്യം വളരെ വലുതാണെങ്കിൽ, മൂല്യം (N-1) മാസ്ക് ചെയ്യുന്നു, ഇവിടെ N എന്നത് ബിറ്റുകളുടെ എണ്ണമാണ്, കൂടാതെ ഈ മൂല്യം ഷിഫ്റ്റ് നടപ്പിലാക്കാൻ ഉപയോഗിക്കുന്നു.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// `rhs` ബിറ്റുകൾ ഉപയോഗിച്ച് സ്വയം വലത്തേക്ക് മാറ്റുന്നു.
        ///
        /// ഷിഫ്റ്റ് മൂല്യം ബിറ്റുകളുടെ എണ്ണത്തേക്കാൾ വലുതാണോ തുല്യമാണോ എന്ന് സൂചിപ്പിക്കുന്ന ഒരു ബൂളിയനൊപ്പം സ്വയത്തിന്റെ ഷിഫ്റ്റ് ചെയ്ത പതിപ്പിന്റെ ഒരു ട്യൂപ്പിൾ നൽകുന്നു.
        /// ഷിഫ്റ്റ് മൂല്യം വളരെ വലുതാണെങ്കിൽ, മൂല്യം (N-1) മാസ്ക് ചെയ്യുന്നു, ഇവിടെ N എന്നത് ബിറ്റുകളുടെ എണ്ണമാണ്, കൂടാതെ ഈ മൂല്യം ഷിഫ്റ്റ് നടപ്പിലാക്കാൻ ഉപയോഗിക്കുന്നു.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// സ്‌ക്വയറിംഗ് ഉപയോഗിച്ച് എക്‌സ്‌പോണൻസേഷൻ ഉപയോഗിച്ച് `exp`-ന്റെ ശക്തിയിലേക്ക് സ്വയം ഉയർത്തുന്നു.
        ///
        /// ഒരു ഓവർഫ്ലോ സംഭവിച്ചോ എന്ന് സൂചിപ്പിക്കുന്ന ഒരു bool-നൊപ്പം എക്‌സ്‌പോണൻസേഷന്റെ ഒരു ട്യൂപ്പിൾ നൽകുന്നു.
        ///
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, ശരി));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // കവിഞ്ഞൊഴുകുന്ന_മുളിന്റെ ഫലങ്ങൾ സംഭരിക്കുന്നതിനുള്ള സ്ഥലം സ്ക്രാച്ച് ചെയ്യുക.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // exp!=0 മുതൽ, ഒടുവിൽ exp 1 ആയിരിക്കണം.
            // എക്‌സ്‌പോണന്റിലെ അവസാന ബിറ്റുമായി പ്രത്യേകം ഇടപെടുക, കാരണം അടിസ്ഥാനത്തെ പിന്നീട് ചതുരപ്പെടുത്തുന്നത് ആവശ്യമില്ലാത്തതിനാൽ ആവശ്യമില്ലാത്ത ഓവർഫ്ലോയ്ക്ക് കാരണമായേക്കാം.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// സ്‌ക്വയറിംഗ് ഉപയോഗിച്ച് എക്‌സ്‌പോണൻസേഷൻ ഉപയോഗിച്ച് `exp`-ന്റെ ശക്തിയിലേക്ക് സ്വയം ഉയർത്തുന്നു.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // exp!=0 മുതൽ, ഒടുവിൽ exp 1 ആയിരിക്കണം.
            // എക്‌സ്‌പോണന്റിലെ അവസാന ബിറ്റുമായി പ്രത്യേകം ഇടപെടുക, കാരണം അടിസ്ഥാനത്തെ പിന്നീട് ചതുരപ്പെടുത്തുന്നത് ആവശ്യമില്ലാത്തതിനാൽ ആവശ്യമില്ലാത്ത ഓവർഫ്ലോയ്ക്ക് കാരണമായേക്കാം.
            //
            //
            acc * base
        }

        /// യൂക്ലിഡിയൻ ഡിവിഷൻ നടത്തുന്നു.
        ///
        /// പോസിറ്റീവ് സംഖ്യകൾക്ക്, വിഭജനത്തിന്റെ പൊതുവായ എല്ലാ നിർവചനങ്ങളും തുല്യമായതിനാൽ, ഇത് `self / rhs` ന് തുല്യമാണ്.
        ///
        ///
        /// # Panics
        ///
        /// `rhs` 0 ആണെങ്കിൽ ഈ പ്രവർത്തനം panic ആയിരിക്കും.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// `self (mod rhs)`-ന്റെ ഏറ്റവും ശേഷിക്കുന്ന ഭാഗം കണക്കാക്കുന്നു.
        ///
        /// പോസിറ്റീവ് സംഖ്യകൾക്ക്, വിഭജനത്തിന്റെ പൊതുവായ എല്ലാ നിർവചനങ്ങളും തുല്യമായതിനാൽ, ഇത് `self % rhs` ന് തുല്യമാണ്.
        ///
        ///
        /// # Panics
        ///
        /// `rhs` 0 ആണെങ്കിൽ ഈ പ്രവർത്തനം panic ആയിരിക്കും.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// ചില `k`-ന് `self == 2^k` ആണെങ്കിൽ മാത്രം `true` നൽകുന്നു.
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // രണ്ടിന്റെ അടുത്ത പവറിനേക്കാൾ കുറവ് നൽകുന്നു.
        // (8u8 ന് രണ്ടിന്റെ അടുത്ത ശക്തി 8u8 ഉം 6u8 ന് 8u8 ഉം ആണ്)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // ഈ രീതിക്ക് ഓവർഫ്ലോ ചെയ്യാൻ കഴിയില്ല, കാരണം `next_power_of_two` ഓവർഫ്ലോ കേസുകളിൽ ഇത് തരത്തിന്റെ പരമാവധി മൂല്യം മടക്കിനൽകുന്നു, കൂടാതെ 0 ന് 0 നൽകാം.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // സുരക്ഷ: കാരണം `p > 0`, ഇതിന് പൂർണ്ണമായും പ്രമുഖ പൂജ്യങ്ങൾ ഉൾക്കൊള്ളാൻ കഴിയില്ല.
            // അതിനർത്ഥം ഷിഫ്റ്റ് എല്ലായ്പ്പോഴും പരിധിയില്ലാത്തതാണ്, കൂടാതെ ചില പ്രോസസ്സറുകൾക്ക് (ഇന്റൽ പ്രീ-ഹാസ്വെൽ പോലുള്ളവ) വാദം പൂജ്യമല്ലാത്തപ്പോൾ കൂടുതൽ കാര്യക്ഷമമായ ctlz ആന്തരികതയുണ്ട്.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// `self`-നേക്കാൾ വലുതോ തുല്യമോ ആയ രണ്ടിന്റെ ഏറ്റവും ചെറിയ പവർ നൽകുന്നു.
        ///
        /// റിട്ടേൺ മൂല്യം ഓവർഫ്ലോ ചെയ്യുമ്പോൾ (അതായത്, ടൈപ്പ് `uN`-നുള്ള `self > (1 << (N-1))`), ഇത് ഡീബഗ് മോഡിൽ panics ഉം റിട്ടേൺ മൂല്യം റിലീസ് മോഡിൽ 0 ലേക്ക് പൊതിയുന്നു (രീതിക്ക് 0 മടങ്ങാൻ കഴിയുന്ന ഒരേയൊരു സാഹചര്യം).
        ///
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// `n`-നേക്കാൾ വലുതോ തുല്യമോ ആയ രണ്ടിന്റെ ഏറ്റവും ചെറിയ പവർ നൽകുന്നു.
        /// രണ്ടിന്റെ അടുത്ത പവർ തരത്തിന്റെ പരമാവധി മൂല്യത്തേക്കാൾ വലുതാണെങ്കിൽ, `None` മടക്കിനൽകുന്നു, അല്ലാത്തപക്ഷം രണ്ടിന്റെ ശക്തി `Some`-ൽ പൊതിഞ്ഞ് നിൽക്കുന്നു.
        ///
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// `n`-നേക്കാൾ വലുതോ തുല്യമോ ആയ രണ്ടിന്റെ ഏറ്റവും ചെറിയ പവർ നൽകുന്നു.
        /// രണ്ടിന്റെ അടുത്ത പവർ തരത്തിന്റെ പരമാവധി മൂല്യത്തേക്കാൾ വലുതാണെങ്കിൽ, റിട്ടേൺ മൂല്യം `0` ലേക്ക് പൊതിയുന്നു.
        ///
        ///
        /// # Examples
        ///
        /// അടിസ്ഥാന ഉപയോഗം:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// ബിഗ്-എൻ‌ഡിയൻ (network) ബൈറ്റ് ക്രമത്തിൽ ഒരു ബൈറ്റ് അറേയായി ഈ സംഖ്യയുടെ മെമ്മറി പ്രാതിനിധ്യം നൽകുക.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// ചെറിയ-എൻ‌ഡിയൻ‌ബൈറ്റ് ക്രമത്തിൽ‌ഒരു ബൈറ്റ് അറേയായി ഈ സംഖ്യയുടെ മെമ്മറി പ്രാതിനിധ്യം നൽകുക.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// നേറ്റീവ് ബൈറ്റ് ക്രമത്തിൽ ഒരു ബൈറ്റ് അറേയായി ഈ സംഖ്യയുടെ മെമ്മറി പ്രാതിനിധ്യം നൽകുക.
        ///
        /// ടാർ‌ഗെറ്റ് പ്ലാറ്റ്‌ഫോമിലെ നേറ്റീവ് എൻ‌ഡിയൻ‌നെസ് ഉപയോഗിക്കുന്നതിനാൽ‌, പകരം പോർ‌ട്ടബിൾ കോഡ് [`to_be_bytes`] അല്ലെങ്കിൽ‌[`to_le_bytes`] ഉപയോഗിക്കണം.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     ബൈറ്റുകൾ, cfg ആണെങ്കിൽ! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } else {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // സുരക്ഷ: സംഖ്യ ശബ്‌ദം കാരണം പൂർണ്ണസംഖ്യകൾ പഴയ പഴയ ഡാറ്റാ ടൈപ്പുകളായതിനാൽ ഞങ്ങൾക്ക് എല്ലായ്പ്പോഴും കഴിയും
        // അവയെ ബൈറ്റുകളുടെ നിരയിലേക്ക് മാറ്റുക
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // സുരക്ഷ: പൂർണ്ണസംഖ്യകൾ‌പഴയ പഴയ ഡാറ്റാ ടൈപ്പുകളായതിനാൽ‌അവ എല്ലായ്‌പ്പോഴും ഞങ്ങൾ‌ക്ക് പരിവർത്തനം ചെയ്യാൻ‌കഴിയും
            // ബൈറ്റുകളുടെ നിര
            unsafe { mem::transmute(self) }
        }

        /// നേറ്റീവ് ബൈറ്റ് ക്രമത്തിൽ ഒരു ബൈറ്റ് അറേയായി ഈ സംഖ്യയുടെ മെമ്മറി പ്രാതിനിധ്യം നൽകുക.
        ///
        ///
        /// [`to_ne_bytes`] സാധ്യമാകുമ്പോഴെല്ലാം ഇതിനെക്കാൾ മുൻഗണന നൽകണം.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// ബൈറ്റുകൾ അനുവദിക്കുക= num.as_ne_bytes();
        /// assert_eq!(
        ///     ബൈറ്റുകൾ, cfg ആണെങ്കിൽ! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } else {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // സുരക്ഷ: പൂർണ്ണസംഖ്യകൾ‌പഴയ പഴയ ഡാറ്റാ ടൈപ്പുകളായതിനാൽ‌അവ എല്ലായ്‌പ്പോഴും ഞങ്ങൾ‌ക്ക് പരിവർത്തനം ചെയ്യാൻ‌കഴിയും
            // ബൈറ്റുകളുടെ നിര
            unsafe { &*(self as *const Self as *const _) }
        }

        /// ബിഗ് എൻ‌ഡിയനിൽ‌ഒരു ബൈറ്റ് അറേയായി അതിന്റെ പ്രാതിനിധ്യത്തിൽ‌നിന്നും ഒരു നേറ്റീവ് എൻ‌ഡിയൻ‌ഇൻ‌റിജർ‌മൂല്യം സൃഷ്‌ടിക്കുക.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto ഉപയോഗിക്കുക;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ഇൻപുട്ട്=വിശ്രമം;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// ചെറിയ എൻ‌ഡിയനിൽ‌ഒരു ബൈറ്റ് അറേയായി അതിന്റെ പ്രാതിനിധ്യത്തിൽ‌നിന്നും ഒരു നേറ്റീവ് എൻ‌ഡിയൻ‌ഇൻ‌റിജർ‌മൂല്യം സൃഷ്‌ടിക്കുക.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto ഉപയോഗിക്കുക;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ഇൻപുട്ട്=വിശ്രമം;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// നേറ്റീവ് എൻ‌ഡിയൻ‌നെസിലെ ഒരു ബൈറ്റ് അറേയായി അതിന്റെ മെമ്മറി പ്രാതിനിധ്യത്തിൽ നിന്ന് ഒരു നേറ്റീവ് എൻ‌ഡിയൻ‌ഇൻ‌റിജർ‌മൂല്യം സൃഷ്‌ടിക്കുക.
        ///
        /// ടാർ‌ഗെറ്റ് പ്ലാറ്റ്‌ഫോമിലെ നേറ്റീവ് എൻ‌ഡിയൻ‌നെസ് ഉപയോഗിക്കുന്നതിനാൽ‌, പകരം പോർ‌ട്ടബിൾ കോഡ് [`from_be_bytes`] അല്ലെങ്കിൽ‌[`from_le_bytes`] ഉപയോഗിക്കാൻ‌താൽ‌പ്പര്യപ്പെടുന്നു.
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } else {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// std::convert::TryInto ഉപയോഗിക്കുക;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * ഇൻപുട്ട്=വിശ്രമം;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // സുരക്ഷ: സംഖ്യ ശബ്‌ദം കാരണം പൂർണ്ണസംഖ്യകൾ പഴയ പഴയ ഡാറ്റാ ടൈപ്പുകളായതിനാൽ ഞങ്ങൾക്ക് എല്ലായ്പ്പോഴും കഴിയും
        // അവയിലേക്ക് പരിവർത്തനം ചെയ്യുക
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // സുരക്ഷ: പൂർണ്ണസംഖ്യകൾ പഴയ പഴയ ഡാറ്റാ ടൈപ്പുകളായതിനാൽ നമുക്ക് അവയിലേക്ക് എല്ലായ്പ്പോഴും പരിവർത്തനം ചെയ്യാനാകും
            unsafe { mem::transmute(bytes) }
        }

        /// പുതിയ കോഡ് ഉപയോഗിക്കാൻ താൽപ്പര്യപ്പെടണം
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// ഈ സംഖ്യ തരം പ്രതിനിധീകരിക്കാൻ കഴിയുന്ന ഏറ്റവും ചെറിയ മൂല്യം നൽകുന്നു.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// പുതിയ കോഡ് ഉപയോഗിക്കാൻ താൽപ്പര്യപ്പെടണം
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// ഈ സംഖ്യ തരം പ്രതിനിധീകരിക്കാൻ കഴിയുന്ന ഏറ്റവും വലിയ മൂല്യം നൽകുന്നു.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}