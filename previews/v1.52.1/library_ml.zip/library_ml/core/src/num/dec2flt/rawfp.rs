//! പോസിറ്റീവ് ഐ‌ഇ‌ഇഇ 754 ഫ്ലോട്ടുകളിൽ ബിറ്റ് ഫിഡ്ലിംഗ്.നെഗറ്റീവ് നമ്പറുകൾ കൈകാര്യം ചെയ്യേണ്ടതില്ല.
//! സാധാരണ ഫ്ലോട്ടിംഗ് പോയിൻറ് നമ്പറുകൾക്ക് (frac, exp) എന്ന കാനോനിക്കൽ പ്രാതിനിധ്യം ഉണ്ട്, അതായത് മൂല്യം 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)), ഇവിടെ N എന്നത് ബിറ്റുകളുടെ എണ്ണം.
//!
//! സബ്നോർമലുകൾ അല്പം വ്യത്യസ്തവും വിചിത്രവുമാണ്, എന്നാൽ അതേ തത്ത്വം ബാധകമാണ്.
//!
//! എന്നിരുന്നാലും, ഇവിടെ ഞങ്ങൾ അവയെ f പോസിറ്റീവ് ഉള്ള (സിഗ്, കെ) ആയി പ്രതിനിധീകരിക്കുന്നു, അതായത് മൂല്യം f *
//! 2 <sup>ഇ</sup> ."hidden bit" സ്‌പഷ്‌ടമാക്കുന്നതിന് പുറമേ, ഇത് മാന്റിസ ഷിഫ്റ്റ് എന്ന് വിളിക്കപ്പെടുന്ന എക്‌സ്‌പോണന്റിനെ മാറ്റുന്നു.
//!
//! മറ്റൊരു തരത്തിൽ പറഞ്ഞാൽ, സാധാരണയായി ഫ്ലോട്ടുകളെ (1) എന്ന് എഴുതുന്നു, പക്ഷേ ഇവിടെ അവ (2) എന്ന് എഴുതുന്നു:
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! ഞങ്ങൾ (1) നെ **ഫ്രാക്ഷണൽ പ്രാതിനിധ്യം** എന്നും (2) നെ **ഇന്റഗ്രൽ പ്രാതിനിധ്യം** എന്നും വിളിക്കുന്നു.
//!
//! ഈ മൊഡ്യൂളിലെ പല ഫംഗ്ഷനുകളും സാധാരണ നമ്പറുകൾ മാത്രം കൈകാര്യം ചെയ്യുന്നു.Dec2flt ദിനചര്യകൾ വളരെ ചെറുതും വലുതുമായ സംഖ്യകൾക്കായി യാഥാസ്ഥിതികമായി സാർവത്രികമായി ശരിയായ സ്ലോ പാത്ത് (അൽഗോരിതം എം) എടുക്കുന്നു.
//! ആ അൽ‌ഗോരിതം സബ്‌നോർമലുകളും പൂജ്യങ്ങളും കൈകാര്യം ചെയ്യുന്ന next_float() മാത്രം ആവശ്യമാണ്.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// `f32`, `f64` എന്നിവയ്‌ക്കായുള്ള എല്ലാ പരിവർത്തന കോഡുകളും അടിസ്ഥാനപരമായി തനിപ്പകർപ്പാക്കുന്നത് ഒഴിവാക്കാൻ trait എന്ന സഹായി.
///
/// ഇത് എന്തുകൊണ്ട് ആവശ്യമാണെന്ന് രക്ഷാകർതൃ മൊഡ്യൂളിന്റെ പ്രമാണ അഭിപ്രായം കാണുക.
///
/// **ഒരിക്കലും** മറ്റ് തരങ്ങൾക്കായി നടപ്പിലാക്കരുത് അല്ലെങ്കിൽ dec2flt മൊഡ്യൂളിന് പുറത്ത് ഉപയോഗിക്കണം.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// `to_bits`, `from_bits` എന്നിവ ഉപയോഗിക്കുന്ന തരം.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// ഒരു പൂർണ്ണസംഖ്യയിലേക്ക് ഒരു അസംസ്കൃത പരിവർത്തനം നടത്തുന്നു.
    fn to_bits(self) -> Self::Bits;

    /// ഒരു പൂർണ്ണസംഖ്യയിൽ നിന്ന് ഒരു അസംസ്കൃത പരിവർത്തനം നടത്തുന്നു.
    fn from_bits(v: Self::Bits) -> Self;

    /// ഈ നമ്പർ ഉൾപ്പെടുന്ന വിഭാഗം നൽകുന്നു.
    fn classify(self) -> FpCategory;

    /// മാന്റിസ, എക്‌സ്‌പോണന്റ്, സൈൻ എന്നിവ പൂർണ്ണസംഖ്യകളായി നൽകുന്നു.
    fn integer_decode(self) -> (u64, i16, i8);

    /// ഫ്ലോട്ട് ഡീകോഡ് ചെയ്യുന്നു.
    fn unpack(self) -> Unpacked;

    /// കൃത്യമായി പ്രതിനിധീകരിക്കാൻ കഴിയുന്ന ഒരു ചെറിയ സംഖ്യയിൽ നിന്നുള്ള കാസ്റ്റുകൾ.
    /// Panic സംഖ്യയെ പ്രതിനിധീകരിക്കാൻ കഴിയുന്നില്ലെങ്കിൽ, ഈ മൊഡ്യൂളിലെ മറ്റ് കോഡ് ഒരിക്കലും അത് സംഭവിക്കാതിരിക്കാൻ ഉറപ്പാക്കുന്നു.
    fn from_int(x: u64) -> Self;

    /// മുൻകൂട്ടി കണക്കാക്കിയ പട്ടികയിൽ നിന്ന് 10 <sup>ഇ</sup> മൂല്യം നേടുന്നു.
    /// `e >= CEIL_LOG5_OF_MAX_SIG`-നായുള്ള Panics.
    fn short_fast_pow10(e: usize) -> Self;

    /// പേര് എന്താണ് പറയുന്നത്.
    /// ആന്തരികതയെ തമാശയാക്കുന്നതിനേക്കാളും എൽ‌എൽ‌വി‌എം സ്ഥിരമായി അത് മടക്കിക്കളയുമെന്ന് പ്രതീക്ഷിക്കുന്നതിനേക്കാളും ഹാർഡ് കോഡ് ചെയ്യുന്നത് എളുപ്പമാണ്.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // ഓവർ‌ഫ്ലോ പൂജ്യമോ ഉൽ‌പാദിപ്പിക്കാൻ‌കഴിയാത്ത ഇൻ‌പുട്ടിന്റെ ദശാംശ അക്കങ്ങളിൽ‌ഒരു യാഥാസ്ഥിതിക ബന്ധമുണ്ട്
    /// ഉപനാമങ്ങൾ.ഒരുപക്ഷേ പരമാവധി സാധാരണ മൂല്യത്തിന്റെ ദശാംശ എക്‌സ്‌പോണന്റ്, അതിനാൽ പേര്.
    const MAX_NORMAL_DIGITS: usize;

    /// ഏറ്റവും പ്രധാനപ്പെട്ട ദശാംശ അക്കത്തിന് ഇതിലും വലിയ സ്ഥലമൂല്യമുണ്ടാകുമ്പോൾ, ഈ സംഖ്യ തീർച്ചയായും അനന്തതയിലേക്ക് തിരിയുന്നു.
    ///
    const INF_CUTOFF: i64;

    /// ഏറ്റവും പ്രധാനപ്പെട്ട ഡെസിമൽ അക്കത്തിന് സ്ഥല മൂല്യത്തേക്കാൾ കുറവാണെങ്കിൽ, ഈ സംഖ്യ തീർച്ചയായും പൂജ്യമായി മാറുന്നു.
    ///
    const ZERO_CUTOFF: i64;

    /// എക്‌സ്‌പോണന്റിലെ ബിറ്റുകളുടെ എണ്ണം.
    const EXP_BITS: u8;

    /// മറഞ്ഞിരിക്കുന്ന ബിറ്റ് ഉൾപ്പെടെ * പ്രാധാന്യമുള്ള ബിറ്റുകളുടെ എണ്ണം.
    const SIG_BITS: u8;

    /// മറഞ്ഞിരിക്കുന്ന ബിറ്റിനെ ഒഴികെ * പ്രാധാന്യമുള്ള ബിറ്റുകളുടെ എണ്ണം.
    const EXPLICIT_SIG_BITS: u8;

    /// ഭിന്ന പ്രാതിനിധ്യത്തിലെ പരമാവധി നിയമപരമായ എക്‌സ്‌പോണന്റ്.
    const MAX_EXP: i16;

    /// സബ്‌നോർമലുകൾ ഒഴികെ ഫ്രാക്ഷണൽ പ്രാതിനിധ്യത്തിലെ ഏറ്റവും കുറഞ്ഞ നിയമ എക്‌സ്‌പോണന്റ്.
    const MIN_EXP: i16;

    /// `MAX_EXP` സമഗ്ര പ്രാതിനിധ്യത്തിനായി, അതായത്, ഷിഫ്റ്റ് പ്രയോഗിച്ചു.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` എൻ‌കോഡുചെയ്‌തത് (അതായത്, ഓഫ്‌സെറ്റ് ബയസ് ഉപയോഗിച്ച്)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` സമഗ്ര പ്രാതിനിധ്യത്തിനായി, അതായത്, ഷിഫ്റ്റ് പ്രയോഗിച്ചു.
    const MIN_EXP_INT: i16;

    /// ഇന്റഗ്രൽ പ്രാതിനിധ്യത്തിൽ പരമാവധി നോർമലൈസ് ചെയ്ത പ്രാധാന്യവും.
    const MAX_SIG: u64;

    /// ഇന്റഗ്രൽ പ്രാതിനിധ്യത്തിലെ ഏറ്റവും സാധാരണമായ പ്രാധാന്യം.
    const MIN_SIG: u64;
}

// കൂടുതലും #34344-നുള്ള ഒരു പരിഹാരമാർഗ്ഗം.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// മാന്റിസ, എക്‌സ്‌പോണന്റ്, സൈൻ എന്നിവ പൂർണ്ണസംഖ്യകളായി നൽകുന്നു.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // എക്‌സ്‌പോണന്റ് ബയസ് + മാന്റിസ ഷിഫ്റ്റ്
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // എല്ലാ പ്ലാറ്റ്‌ഫോമുകളിലും `as` ശരിയായി റൗണ്ട് ചെയ്യുന്നുണ്ടോ എന്ന് rkruppe ന് ഉറപ്പില്ല.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// മാന്റിസ, എക്‌സ്‌പോണന്റ്, സൈൻ എന്നിവ പൂർണ്ണസംഖ്യകളായി നൽകുന്നു.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // എക്‌സ്‌പോണന്റ് ബയസ് + മാന്റിസ ഷിഫ്റ്റ്
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // എല്ലാ പ്ലാറ്റ്‌ഫോമുകളിലും `as` ശരിയായി റൗണ്ട് ചെയ്യുന്നുണ്ടോ എന്ന് rkruppe ന് ഉറപ്പില്ല.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// ഒരു `Fp` നെ ഏറ്റവും അടുത്തുള്ള മെഷീൻ ഫ്ലോട്ട് തരത്തിലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
/// അസാധാരണമായ ഫലങ്ങൾ കൈകാര്യം ചെയ്യുന്നില്ല.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f 64 ബിറ്റ് ആണ്, അതിനാൽ xe ന് 63 ന്റെ മാന്റിസ ഷിഫ്റ്റ് ഉണ്ട്
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// 64-ബിറ്റ് പ്രാധാന്യവും എക്സ്-എക്സ് ബിറ്റുകളിലേക്ക് പകുതി മുതൽ ഇരട്ട വരെ റ ound ണ്ട് ചെയ്യുക.
/// എക്‌സ്‌പോണന്റ് ഓവർഫ്ലോ കൈകാര്യം ചെയ്യുന്നില്ല.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // മാന്റിസ ഷിഫ്റ്റ് ക്രമീകരിക്കുക
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// നോർമലൈസ്ഡ് നമ്പറുകൾക്കായി `RawFloat::unpack()` ന്റെ വിപരീതം.
/// നോർമലൈസ്ഡ് നമ്പറുകൾക്ക് പ്രാധാന്യമോ എക്‌സ്‌പോണന്റോ സാധുതയില്ലെങ്കിൽ Panics.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // മറഞ്ഞിരിക്കുന്ന ബിറ്റ് നീക്കംചെയ്യുക
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // എക്‌സ്‌പോണന്റ് ബയസ്, മാന്റിസ ഷിഫ്റ്റ് എന്നിവയ്‌ക്കായി എക്‌സ്‌പോണന്റ് ക്രമീകരിക്കുക
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // 0 ("+")-ൽ ചിഹ്ന ബിറ്റ് വിടുക, ഞങ്ങളുടെ നമ്പറുകൾ എല്ലാം പോസിറ്റീവ് ആണ്
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// ഒരു സബ്നോർമൽ നിർമ്മിക്കുക.0 ന്റെ ഒരു മാന്റിസ അനുവദിക്കുകയും പൂജ്യം നിർമ്മിക്കുകയും ചെയ്യുന്നു.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // എൻ‌കോഡുചെയ്‌ത എക്‌സ്‌പോണന്റ് 0 ആണ്, ചിഹ്നം ബിറ്റ് 0 ആണ്, അതിനാൽ ഞങ്ങൾ ബിറ്റുകൾ വീണ്ടും വ്യാഖ്യാനിക്കണം.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// ഒരു എഫ്പി ഉപയോഗിച്ച് ഒരു ബിഗ്നം ഏകദേശമാക്കുക.0.5 ULP-നുള്ള പകുതി മുതൽ ഇരട്ട വരെയുള്ള റൗണ്ടുകൾ.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // `start` സൂചികയ്‌ക്ക് മുമ്പുള്ള എല്ലാ ബിറ്റുകളും ഞങ്ങൾ മുറിച്ചുമാറ്റി, അതായത്, ഞങ്ങൾ `start` ന്റെ അളവിൽ ഫലപ്രദമായി വലത്-ഷിഫ്റ്റ് ചെയ്യുന്നു, അതിനാൽ ഇത് ഞങ്ങൾക്ക് ആവശ്യമുള്ള എക്‌സ്‌പോണന്റാണ്.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // വെട്ടിച്ചുരുക്കിയ ബിറ്റുകളെ ആശ്രയിച്ച് (half-to-even) റ ound ണ്ട്.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// ഏറ്റവും വലിയ ഫ്ലോട്ടിംഗ് പോയിൻറ് നമ്പർ ആർഗ്യുമെന്റിനേക്കാൾ ചെറുതായി കണ്ടെത്തുന്നു.
/// സബ്‌നോർമലുകൾ, പൂജ്യം അല്ലെങ്കിൽ എക്‌സ്‌പോണന്റ് അണ്ടർഫ്ലോ എന്നിവ കൈകാര്യം ചെയ്യുന്നില്ല.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// ആർഗ്യുമെന്റിനേക്കാൾ കർശനമായി വലുപ്പമുള്ള ഏറ്റവും ചെറിയ ഫ്ലോട്ടിംഗ് പോയിൻറ് നമ്പർ കണ്ടെത്തുക.
// ഈ പ്രവർത്തനം പൂരിതമാണ്, അതായത്, next_float(inf) ==inf.
// ഈ മൊഡ്യൂളിലെ മിക്ക കോഡുകളിൽ നിന്ന് വ്യത്യസ്തമായി, ഈ ഫംഗ്ഷൻ പൂജ്യം, സബ്നോർമലുകൾ, അനന്തതകൾ എന്നിവ കൈകാര്യം ചെയ്യുന്നു.
// എന്നിരുന്നാലും, ഇവിടെയുള്ള മറ്റെല്ലാ കോഡുകളേയും പോലെ, ഇത് NaN ഉം നെഗറ്റീവ് നമ്പറുകളും കൈകാര്യം ചെയ്യുന്നില്ല.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // ഇത് ശരിയാണെന്ന് തോന്നുന്നില്ല, പക്ഷേ ഇത് പ്രവർത്തിക്കുന്നു.
        // 0.0 എല്ലാ പൂജ്യ പദമായും എൻ‌കോഡുചെയ്‌തു.സബ്നോർമലുകൾ 0x000 മീ ... മീ, ഇവിടെ എം മാന്റിസയാണ്.
        // പ്രത്യേകിച്ചും, ഏറ്റവും ചെറിയ സബ്നോർമൽ 0x0 ... 01 ഉം ഏറ്റവും വലുത് 0x000F ... F ഉം ആണ്.
        // ഏറ്റവും ചെറിയ സാധാരണ നമ്പർ 0x0010 ... 0 ആണ്, അതിനാൽ ഈ കോർണർ കേസും പ്രവർത്തിക്കുന്നു.
        // ഇൻക്രിമെന്റ് മാന്റിസയെ കവിഞ്ഞൊഴുകുകയാണെങ്കിൽ, കാരി ബിറ്റ് എക്‌സ്‌പോണന്റിനെ നമുക്ക് ആവശ്യമുള്ളതുപോലെ വർദ്ധിപ്പിക്കുന്നു, ഒപ്പം മാന്റിസ ബിറ്റുകൾ പൂജ്യമാകും.
        // മറഞ്ഞിരിക്കുന്ന ബിറ്റ് കൺവെൻഷൻ കാരണം, ഇതും ഞങ്ങൾക്ക് വേണ്ടത് തന്നെയാണ്!
        // അവസാനമായി, f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}