//! ഫോമിന്റെ ദശാംശ സ്ട്രിംഗ് സാധൂകരിക്കുകയും വിഘടിപ്പിക്കുകയും ചെയ്യുന്നു:
//!
//! `(digits | digits? '.'? digits?) (('e' | 'E') ('+' | '-')? digits)?`
//!
//! മറ്റൊരു വിധത്തിൽ പറഞ്ഞാൽ, സ്റ്റാൻ‌ഡേർഡ് ഫ്ലോട്ടിംഗ്-പോയിൻറ് വാക്യഘടന, രണ്ട് ഒഴിവാക്കലുകൾ‌: ചിഹ്നമില്ല, കൂടാതെ "inf", "NaN" എന്നിവ കൈകാര്യം ചെയ്യുന്നില്ല.ഇവ കൈകാര്യം ചെയ്യുന്നത് ഡ്രൈവർ ഫംഗ്ഷൻ (super::dec2flt) ആണ്.
//!
//! സാധുവായ ഇൻപുട്ടുകൾ തിരിച്ചറിയുന്നത് താരതമ്യേന എളുപ്പമാണെങ്കിലും, ഈ മൊഡ്യൂളിന് എണ്ണമറ്റ അസാധുവായ വ്യതിയാനങ്ങൾ നിരസിക്കേണ്ടതുണ്ട്, ഒരിക്കലും panic, കൂടാതെ മറ്റ് മൊഡ്യൂളുകൾ panic (അല്ലെങ്കിൽ ഓവർഫ്ലോ) ആശ്രയിക്കാത്ത നിരവധി പരിശോധനകൾ നടത്തുകയും വേണം.
//!
//! കാര്യങ്ങൾ കൂടുതൽ വഷളാക്കാൻ, ഇൻപുട്ടിന് മുകളിലൂടെയുള്ളതെല്ലാം സംഭവിക്കുന്നു.
//! അതിനാൽ, എന്തെങ്കിലും പരിഷ്‌ക്കരിക്കുമ്പോൾ ശ്രദ്ധിക്കുക, മറ്റ് മൊഡ്യൂളുകൾ ഉപയോഗിച്ച് രണ്ടുതവണ പരിശോധിക്കുക.
//!
//!
use self::ParseResult::{Invalid, ShortcutToInf, ShortcutToZero, Valid};
use super::num;

#[derive(Debug)]
pub enum Sign {
    Positive,
    Negative,
}

#[derive(Debug, PartialEq, Eq)]
/// ഒരു ദശാംശ സ്‌ട്രിംഗിന്റെ രസകരമായ ഭാഗങ്ങൾ.
pub struct Decimal<'a> {
    pub integral: &'a [u8],
    pub fractional: &'a [u8],
    /// ഡെസിമൽ എക്‌സ്‌പോണന്റ്, 18 ഡെസിമൽ അക്കങ്ങളിൽ കുറവാണെന്ന് ഉറപ്പുനൽകുന്നു.
    pub exp: i64,
}

impl<'a> Decimal<'a> {
    pub fn new(integral: &'a [u8], fractional: &'a [u8], exp: i64) -> Decimal<'a> {
        Decimal { integral, fractional, exp }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum ParseResult<'a> {
    Valid(Decimal<'a>),
    ShortcutToInf,
    ShortcutToZero,
    Invalid,
}

/// ഇൻപുട്ട് സ്ട്രിംഗ് സാധുവായ ഫ്ലോട്ടിംഗ് പോയിന്റ് നമ്പറാണോയെന്ന് പരിശോധിക്കുന്നു, അങ്ങനെയാണെങ്കിൽ, അവിഭാജ്യ ഭാഗം, ഭിന്ന ഭാഗം, അതിലെ എക്‌സ്‌പോണന്റ് എന്നിവ കണ്ടെത്തുക.
/// അടയാളങ്ങൾ കൈകാര്യം ചെയ്യുന്നില്ല.
pub fn parse_decimal(s: &str) -> ParseResult<'_> {
    if s.is_empty() {
        return Invalid;
    }

    let s = s.as_bytes();
    let (integral, s) = eat_digits(s);

    match s.first() {
        None => Valid(Decimal::new(integral, b"", 0)),
        Some(&b'e' | &b'E') => {
            if integral.is_empty() {
                return Invalid; // 'e'-ന് മുമ്പ് അക്കങ്ങളൊന്നുമില്ല
            }

            parse_exp(integral, b"", &s[1..])
        }
        Some(&b'.') => {
            let (fractional, s) = eat_digits(&s[1..]);
            if integral.is_empty() && fractional.is_empty() {
                // പോയിന്റിന് മുമ്പോ ശേഷമോ ഞങ്ങൾക്ക് കുറഞ്ഞത് ഒരു അക്കമെങ്കിലും ആവശ്യമാണ്.
                return Invalid;
            }

            match s.first() {
                None => Valid(Decimal::new(integral, fractional, 0)),
                Some(&b'e' | &b'E') => parse_exp(integral, fractional, &s[1..]),
                _ => Invalid, // ഭിന്ന ഭാഗത്തിന് ശേഷം ജങ്ക് പിന്തുടരുന്നു
            }
        }
        _ => Invalid, // ആദ്യ അക്ക സ്‌ട്രിംഗിന് ശേഷം ജങ്ക് പിന്തുടരുന്നു
    }
}

/// ആദ്യത്തെ അക്കമല്ലാത്ത പ്രതീകം വരെ ദശാംശ അക്കങ്ങൾ കൊത്തിയെടുക്കുന്നു.
fn eat_digits(s: &[u8]) -> (&[u8], &[u8]) {
    let pos = s.iter().position(|c| !c.is_ascii_digit()).unwrap_or(s.len());
    s.split_at(pos)
}

/// എക്‌സ്‌പോണന്റ് എക്‌സ്‌ട്രാക്റ്റുചെയ്യലും പിശക് പരിശോധനയും.
fn parse_exp<'a>(integral: &'a [u8], fractional: &'a [u8], rest: &'a [u8]) -> ParseResult<'a> {
    let (sign, rest) = match rest.first() {
        Some(&b'-') => (Sign::Negative, &rest[1..]),
        Some(&b'+') => (Sign::Positive, &rest[1..]),
        _ => (Sign::Positive, rest),
    };
    let (mut number, trailing) = eat_digits(rest);
    if !trailing.is_empty() {
        return Invalid; // എക്‌സ്‌പോണന്റിന് ശേഷം ജങ്ക് പിന്തുടരുന്നു
    }
    if number.is_empty() {
        return Invalid; // ശൂന്യമായ എക്‌സ്‌പോണന്റ്
    }
    // ഈ സമയത്ത്, ഞങ്ങൾക്ക് തീർച്ചയായും സാധുവായ ഒരു അക്കമുണ്ട്.ഒരു `i64`-ൽ ഇടാൻ ഇത് വളരെ ദൈർഘ്യമേറിയതാകാം, പക്ഷേ അത് വളരെ വലുതാണെങ്കിൽ, ഇൻപുട്ട് തീർച്ചയായും പൂജ്യമോ അനന്തമോ ആണ്.
    // ദശാംശ അക്കങ്ങളിലെ ഓരോ പൂജ്യവും എക്‌സ്‌പോണന്റിനെ +/-1 കൊണ്ട് മാത്രമേ ക്രമീകരിക്കുകയുള്ളൂ എന്നതിനാൽ, exp=10 ^ 18 ന് ഇൻപുട്ട് 17 എക്‌സൈബൈറ്റ് (!) പൂജ്യങ്ങളായിരിക്കണം.
    //
    // ഇത് കൃത്യമായി ഞങ്ങൾ ഉപയോഗിക്കേണ്ട ഒരു കേസല്ല.
    //
    while number.first() == Some(&b'0') {
        number = &number[1..];
    }
    if number.len() >= 18 {
        return match sign {
            Sign::Positive => ShortcutToInf,
            Sign::Negative => ShortcutToZero,
        };
    }
    let abs_exp = num::from_str_unchecked(number);
    let e = match sign {
        Sign::Positive => abs_exp as i64,
        Sign::Negative => -(abs_exp as i64),
    };
    Valid(Decimal::new(integral, fractional, e))
}