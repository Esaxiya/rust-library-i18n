//! 64-ബിറ്റ് ഒപ്പിട്ട സംഖ്യാ തരം സ്ഥിരാങ്കങ്ങൾ.
//!
//! *[See also the `i64` primitive type][i64].*
//!
//! പുതിയ കോഡ് അനുബന്ധ സ്ഥിരതകളെ നേരിട്ട് പ്രാകൃത തരത്തിൽ ഉപയോഗിക്കണം.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i64`"
)]

int_module! { i64 }