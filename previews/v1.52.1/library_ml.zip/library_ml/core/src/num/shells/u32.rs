//! 32-ബിറ്റ് സൈൻ ചെയ്യാത്ത പൂർണ്ണസംഖ്യയുടെ സ്ഥിരത.
//!
//! *[See also the `u32` primitive type][u32].*
//!
//! പുതിയ കോഡ് അനുബന്ധ സ്ഥിരതകളെ നേരിട്ട് പ്രാകൃത തരത്തിൽ ഉപയോഗിക്കണം.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u32`"
)]

int_module! { u32 }