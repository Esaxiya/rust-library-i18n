//! പോയിന്റർ വലുപ്പത്തിലുള്ള സൈൻ ചെയ്യാത്ത സംഖ്യാ തരം സ്ഥിരാങ്കങ്ങൾ.
//!
//! *[See also the `usize` primitive type][usize].*
//!
//! പുതിയ കോഡ് അനുബന്ധ സ്ഥിരതകളെ നേരിട്ട് പ്രാകൃത തരത്തിൽ ഉപയോഗിക്കണം.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `usize`"
)]

int_module! { usize }