//! 128-ബിറ്റ് സൈൻ ചെയ്യാത്ത പൂർണ്ണസംഖ്യയുടെ സ്ഥിരത.
//!
//! *[See also the `u128` primitive type][u128].*
//!
//! പുതിയ കോഡ് അനുബന്ധ സ്ഥിരതകളെ നേരിട്ട് പ്രാകൃത തരത്തിൽ ഉപയോഗിക്കണം.

#![stable(feature = "i128", since = "1.26.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `u128`"
)]

int_module! { u128, #[stable(feature = "i128", since="1.26.0")] }