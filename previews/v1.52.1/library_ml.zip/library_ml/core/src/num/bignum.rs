//! ഇഷ്‌ടാനുസൃത അനിയന്ത്രിത-കൃത്യത നമ്പർ (bignum) നടപ്പിലാക്കൽ.
//!
//! സ്റ്റാക്ക് മെമ്മറിയുടെ ചെലവിൽ കൂമ്പാരം അനുവദിക്കുന്നത് ഒഴിവാക്കാനാണ് ഇത് രൂപകൽപ്പന ചെയ്തിരിക്കുന്നത്.
//! ഏറ്റവും കൂടുതൽ ഉപയോഗിക്കുന്ന ബിഗ്നം തരം `Big32x40` 32 × 40=1,280 ബിറ്റുകൾ കൊണ്ട് പരിമിതപ്പെടുത്തിയിരിക്കുന്നു, ഇത് പരമാവധി 160 ബൈറ്റുകൾ സ്റ്റാക്ക് മെമ്മറി എടുക്കും.
//! സാധ്യമായ എല്ലാ പരിമിത `f64` മൂല്യങ്ങളും റ round ണ്ട്-ട്രിപ്പുചെയ്യുന്നതിന് ഇത് മതിയായതിനേക്കാൾ കൂടുതലാണ്.
//!
//! തത്ത്വത്തിൽ വ്യത്യസ്ത ഇൻപുട്ടുകൾക്കായി ഒന്നിലധികം ബിഗ്നം തരങ്ങൾ സാധ്യമാണ്, പക്ഷേ കോഡ് പൊട്ടുന്നത് ഒഴിവാക്കാൻ ഞങ്ങൾ അങ്ങനെ ചെയ്യുന്നില്ല.
//!
//! ഓരോ ബിഗ്നവും യഥാർത്ഥ ഉപയോഗങ്ങൾക്കായി ഇപ്പോഴും ട്രാക്കുചെയ്യുന്നു, അതിനാൽ ഇത് സാധാരണയായി പ്രശ്നമല്ല.
//!

// ഈ മൊഡ്യൂൾ‌dec2flt, flt2dec എന്നിവയ്‌ക്ക് മാത്രമുള്ളതാണ്, മാത്രമല്ല കോർ‌ടെസ്റ്റുകൾ‌കാരണം പൊതുവായതും.
// ഇത് ഒരിക്കലും സ്ഥിരത കൈവരിക്കാൻ ഉദ്ദേശിച്ചുള്ളതല്ല.
#![doc(hidden)]
#![unstable(
    feature = "core_private_bignum",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]
#![macro_use]

use crate::intrinsics;

/// ബിഗ്നമുകൾക്ക് ആവശ്യമായ ഗണിത പ്രവർത്തനങ്ങൾ.
pub trait FullOps: Sized {
    /// `carry' * 2^W + v' = self + other + carry` പോലുള്ള `(carry', v')` നൽകുന്നു, ഇവിടെ `W` എന്നത് `Self`-ലെ ബിറ്റുകളുടെ എണ്ണമാണ്.
    ///
    fn full_add(self, other: Self, carry: bool) -> (bool /* carry */, Self);

    /// `carry'*2^W + v' = self* other + carry` പോലുള്ള `(carry', v')` നൽകുന്നു, ഇവിടെ `W` എന്നത് `Self`-ലെ ബിറ്റുകളുടെ എണ്ണമാണ്.
    ///
    fn full_mul(self, other: Self, carry: Self) -> (Self /* carry */, Self);

    /// `carry'*2^W + v' = self* other + other2 + carry` പോലുള്ള `(carry', v')` നൽകുന്നു, ഇവിടെ `W` എന്നത് `Self`-ലെ ബിറ്റുകളുടെ എണ്ണമാണ്.
    ///
    fn full_mul_add(self, other: Self, other2: Self, carry: Self) -> (Self /* carry */, Self);

    /// `borrow *2^W + self = quo* other + rem`, `0 <= rem < other` എന്നിവ പോലുള്ള `(quo, rem)` നൽകുന്നു, ഇവിടെ `W` എന്നത് `Self`-ലെ ബിറ്റുകളുടെ എണ്ണമാണ്.
    ///
    fn full_div_rem(self, other: Self, borrow: Self)
    -> (Self /* quotient */, Self /* remainder */);
}

macro_rules! impl_full_ops {
    ($($ty:ty: add($addfn:path), mul/div($bigty:ident);)*) => (
        $(
            impl FullOps for $ty {
                fn full_add(self, other: $ty, carry: bool) -> (bool, $ty) {
                    // ഇത് കവിഞ്ഞൊഴുകാൻ കഴിയില്ല;X ട്ട്‌പുട്ട് `0` നും `2 * 2^nbits - 1` നും ഇടയിലാണ്.
                    // FIXME: എൽ‌എൽ‌വി‌എം ഇത് എ‌ഡി‌സിയിലേക്ക് ഒപ്റ്റിമൈസ് ചെയ്യുമോ?
                    let (v, carry1) = intrinsics::add_with_overflow(self, other);
                    let (v, carry2) = intrinsics::add_with_overflow(v, if carry {1} else {0});
                    (carry1 || carry2, v)
                }

                fn full_mul(self, other: $ty, carry: $ty) -> ($ty, $ty) {
                    // ഇത് കവിഞ്ഞൊഴുകാൻ കഴിയില്ല;
                    // X ട്ട്‌പുട്ട് `0` നും `2^nbits * (2^nbits - 1)` നും ഇടയിലാണ്.
                    // FIXME: എൽ‌എൽ‌വി‌എം ഇത് എ‌ഡി‌സിയിലേക്ക് ഒപ്റ്റിമൈസ് ചെയ്യുമോ?
                    let v = (self as $bigty) * (other as $bigty) + (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_mul_add(self, other: $ty, other2: $ty, carry: $ty) -> ($ty, $ty) {
                    // ഇത് കവിഞ്ഞൊഴുകാൻ കഴിയില്ല;
                    // X ട്ട്‌പുട്ട് `0` നും `2^nbits * (2^nbits - 1)` നും ഇടയിലാണ്.
                    let v = (self as $bigty) * (other as $bigty) + (other2 as $bigty) +
                            (carry as $bigty);
                    ((v >> <$ty>::BITS) as $ty, v as $ty)
                }

                fn full_div_rem(self, other: $ty, borrow: $ty) -> ($ty, $ty) {
                    debug_assert!(borrow < other);
                    // ഇത് കവിഞ്ഞൊഴുകാൻ കഴിയില്ല;X ട്ട്‌പുട്ട് `0` നും `other * (2^nbits - 1)` നും ഇടയിലാണ്.
                    let lhs = ((borrow as $bigty) << <$ty>::BITS) | (self as $bigty);
                    let rhs = other as $bigty;
                    ((lhs / rhs) as $ty, (lhs % rhs) as $ty)
                }
            }
        )*
    )
}

impl_full_ops! {
    u8:  add(intrinsics::u8_add_with_overflow),  mul/div(u16);
    u16: add(intrinsics::u16_add_with_overflow), mul/div(u32);
    u32: add(intrinsics::u32_add_with_overflow), mul/div(u64);
    // ഇത് പ്രവർത്തനക്ഷമമാക്കുന്നതിന് RFC #521 കാണുക.
    // u64: add(intrinsics::u64_add_with_overflow), mul/div(u128);
}

/// അക്കങ്ങളുടെ 5 പ്രതിനിധീകരിക്കുന്ന ശക്തികളുടെ പട്ടിക.പ്രത്യേകിച്ചും, അഞ്ചിന്റെ ശക്തിയുള്ള ഏറ്റവും വലിയ {u8, u16, u32} മൂല്യം, ഒപ്പം അനുബന്ധ എക്‌സ്‌പോണന്റ്.
/// `mul_pow5`-ൽ ഉപയോഗിച്ചു.
const SMALL_POW5: [(u64, usize); 3] = [(125, 3), (15625, 6), (1_220_703_125, 13)];

macro_rules! define_bignum {
    ($name:ident: type=$ty:ty, n=$n:expr) => {
        /// സ്റ്റാക്ക്-അലോക്കേറ്റഡ് അനിയന്ത്രിത-കൃത്യത (നിശ്ചിത പരിധി വരെ) സംഖ്യ.
        ///
        /// നൽകിയിരിക്കുന്ന തരം ("digit")-ന്റെ ഒരു നിശ്ചിത വലുപ്പ അറേ ഇതിനെ പിന്തുണയ്‌ക്കുന്നു.
        /// അറേ വളരെ വലുതല്ലെങ്കിലും (സാധാരണയായി നൂറുകണക്കിന് ബൈറ്റുകൾ), അശ്രദ്ധമായി ഇത് പകർത്തുന്നത് പ്രകടനത്തിലെ ഹിറ്റിന് കാരണമാകാം.
        ///
        /// അതിനാൽ ഇത് മന ally പൂർവ്വം `Copy` അല്ല.
        ///
        /// ഓവർഫ്ലോയുടെ കാര്യത്തിൽ ബിഗ്നംസ് panic-ന് ലഭ്യമായ എല്ലാ പ്രവർത്തനങ്ങളും.
        /// ആവശ്യത്തിന് വലിയ ബിഗ്നം തരങ്ങൾ ഉപയോഗിക്കാൻ കോളറിന് ഉത്തരവാദിത്തമുണ്ട്.
        pub struct $name {
            /// ഉപയോഗത്തിലുള്ള പരമാവധി "digit" ലേക്ക് ഒരു പ്ലസ് ഓഫ്‌സെറ്റ്.
            /// ഇത് കുറയുന്നില്ല, അതിനാൽ കണക്കുകൂട്ടൽ ക്രമത്തെക്കുറിച്ച് അറിഞ്ഞിരിക്കുക.
            /// `base[size..]` പൂജ്യമായിരിക്കണം.
            size: usize,
            /// Digits.
            /// `[a, b, c, ...]` `a + b *2^W + c* 2^(2W) + ...` പ്രതിനിധീകരിക്കുന്നു, ഇവിടെ `W` എന്നത് അക്ക തരത്തിലുള്ള ബിറ്റുകളുടെ എണ്ണമാണ്.
            base: [$ty; $n],
        }

        impl $name {
            /// ഒരു അക്കത്തിൽ നിന്ന് ഒരു ബിഗ്നം ഉണ്ടാക്കുന്നു.
            pub fn from_small(v: $ty) -> $name {
                let mut base = [0; $n];
                base[0] = v;
                $name { size: 1, base: base }
            }

            /// `u64` മൂല്യത്തിൽ നിന്ന് ഒരു ബിഗ്നം ഉണ്ടാക്കുന്നു.
            pub fn from_u64(mut v: u64) -> $name {
                let mut base = [0; $n];
                let mut sz = 0;
                while v > 0 {
                    base[sz] = v as $ty;
                    v >>= <$ty>::BITS;
                    sz += 1;
                }
                $name { size: sz, base: base }
            }

            /// ആന്തരിക അക്കങ്ങൾ ഒരു സ്ലൈസ് `[a, b, c, ...]` ആയി നൽകുന്നു, അതായത് സംഖ്യാ മൂല്യം `a + b *2^W + c* 2^(2W) + ...` ആണ്, ഇവിടെ `W` എന്നത് അക്ക തരത്തിലുള്ള ബിറ്റുകളുടെ എണ്ണമാണ്.
            ///
            ///
            pub fn digits(&self) -> &[$ty] {
                &self.base[..self.size]
            }

            /// ബിറ്റ് 0 ഏറ്റവും പ്രാധാന്യമർഹിക്കുന്ന `i`-th ബിറ്റ് നൽകുന്നു.
            /// മറ്റൊരു വിധത്തിൽ പറഞ്ഞാൽ, ഭാരം `2^i` ഉള്ള ബിറ്റ്.
            pub fn get_bit(&self, i: usize) -> u8 {
                let digitbits = <$ty>::BITS as usize;
                let d = i / digitbits;
                let b = i % digitbits;
                ((self.base[d] >> b) & 1) as u8
            }

            /// ബിഗ്നം പൂജ്യമാണെങ്കിൽ `true` നൽകുന്നു.
            pub fn is_zero(&self) -> bool {
                self.digits().iter().all(|&v| v == 0)
            }

            /// ഈ മൂല്യത്തെ പ്രതിനിധീകരിക്കുന്നതിന് ആവശ്യമായ ബിറ്റുകളുടെ എണ്ണം നൽകുന്നു.
            /// പൂജ്യത്തിന് 0 ബിറ്റുകൾ ആവശ്യമാണെന്ന് ശ്രദ്ധിക്കുക.
            pub fn bit_length(&self) -> usize {
                // പൂജ്യമായ ഏറ്റവും പ്രധാനപ്പെട്ട അക്കങ്ങൾ ഒഴിവാക്കുക.
                let digits = self.digits();
                let zeros = digits.iter().rev().take_while(|&&x| x == 0).count();
                let end = digits.len() - zeros;
                let nonzero = &digits[..end];

                if nonzero.is_empty() {
                    // പൂജ്യമല്ലാത്ത അക്കങ്ങളൊന്നുമില്ല, അതായത്, സംഖ്യ പൂജ്യമാണ്.
                    return 0;
                }
                // ഇത് leading_zeros(), ബിറ്റ് ഷിഫ്റ്റുകൾ എന്നിവ ഉപയോഗിച്ച് ഒപ്റ്റിമൈസ് ചെയ്യാൻ കഴിയും, പക്ഷേ ഇത് ഒരുപക്ഷേ ബുദ്ധിമുട്ടുള്ള കാര്യമല്ല.
                //
                let digitbits = <$ty>::BITS as usize;
                let mut i = nonzero.len() * digitbits - 1;
                while self.get_bit(i) == 0 {
                    i -= 1;
                }
                i + 1
            }

            /// `other` സ്വയം ചേർത്ത് സ്വന്തം മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു.
            pub fn add<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let mut sz = cmp::max(self.size, other.size);
                let mut carry = false;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(*b, carry);
                    *a = v;
                    carry = c;
                }
                if carry {
                    self.base[sz] = 1;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            pub fn add_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let (mut carry, v) = self.base[0].full_add(other, false);
                self.base[0] = v;
                let mut i = 1;
                while carry {
                    let (c, v) = self.base[i].full_add(0, carry);
                    self.base[i] = v;
                    carry = c;
                    i += 1;
                }
                if i > self.size {
                    self.size = i;
                }
                self
            }

            /// `other` അതിൽ നിന്ന് കുറയ്ക്കുകയും അതിന്റേതായ മ്യൂട്ടബിൾ റഫറൻസ് നൽകുകയും ചെയ്യുന്നു.
            pub fn sub<'a>(&'a mut self, other: &$name) -> &'a mut $name {
                use crate::cmp;
                use crate::num::bignum::FullOps;

                let sz = cmp::max(self.size, other.size);
                let mut noborrow = true;
                for (a, b) in self.base[..sz].iter_mut().zip(&other.base[..sz]) {
                    let (c, v) = (*a).full_add(!*b, noborrow);
                    *a = v;
                    noborrow = c;
                }
                assert!(noborrow);
                self.size = sz;
                self
            }

            /// ഒരു അക്ക വലുപ്പത്തിലുള്ള `other` കൊണ്ട് സ്വയം ഗുണിച്ച് സ്വന്തം മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു.
            ///
            pub fn mul_small(&mut self, other: $ty) -> &mut $name {
                use crate::num::bignum::FullOps;

                let mut sz = self.size;
                let mut carry = 0;
                for a in &mut self.base[..sz] {
                    let (c, v) = (*a).full_mul(other, carry);
                    *a = v;
                    carry = c;
                }
                if carry > 0 {
                    self.base[sz] = carry;
                    sz += 1;
                }
                self.size = sz;
                self
            }

            /// `2^bits` കൊണ്ട് സ്വയം ഗുണിച്ച് സ്വന്തം മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു.
            pub fn mul_pow2(&mut self, bits: usize) -> &mut $name {
                let digitbits = <$ty>::BITS as usize;
                let digits = bits / digitbits;
                let bits = bits % digitbits;

                assert!(digits < $n);
                debug_assert!(self.base[$n - digits..].iter().all(|&v| v == 0));
                debug_assert!(bits == 0 || (self.base[$n - digits - 1] >> (digitbits - bits)) == 0);

                // `digits * digitbits` ബിറ്റുകൾ വഴി ഷിഫ്റ്റ് ചെയ്യുക
                for i in (0..self.size).rev() {
                    self.base[i + digits] = self.base[i];
                }
                for i in 0..digits {
                    self.base[i] = 0;
                }

                // `bits` ബിറ്റുകൾ വഴി ഷിഫ്റ്റ് ചെയ്യുക
                let mut sz = self.size + digits;
                if bits > 0 {
                    let last = sz;
                    let overflow = self.base[last - 1] >> (digitbits - bits);
                    if overflow > 0 {
                        self.base[last] = overflow;
                        sz += 1;
                    }
                    for i in (digits + 1..last).rev() {
                        self.base[i] =
                            (self.base[i] << bits) | (self.base[i - 1] >> (digitbits - bits));
                    }
                    self.base[digits] <<= bits;
                    // self.base [.. അക്കങ്ങൾ] പൂജ്യമാണ്, മാറ്റേണ്ടതില്ല
                }

                self.size = sz;
                self
            }

            /// `5^e` കൊണ്ട് സ്വയം ഗുണിച്ച് സ്വന്തം മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു.
            pub fn mul_pow5(&mut self, mut e: usize) -> &mut $name {
                use crate::mem;
                use crate::num::bignum::SMALL_POW5;

                // 2 ^ n ന് കൃത്യമായി n പുറകിലുള്ള പൂജ്യങ്ങളുണ്ട്, മാത്രമല്ല പ്രസക്തമായ അക്ക വലുപ്പങ്ങൾ രണ്ടിന്റെ തുടർച്ചയായ ശക്തികളാണ്, അതിനാൽ ഇത് പട്ടികയ്ക്ക് അനുയോജ്യമായ സൂചികയാണ്.
                //
                let table_index = mem::size_of::<$ty>().trailing_zeros() as usize;
                let (small_power, small_e) = SMALL_POW5[table_index];
                let small_power = small_power as $ty;

                // ഏറ്റവും വലിയ ഒറ്റ-അക്ക പവർ ഉപയോഗിച്ച് കഴിയുന്നിടത്തോളം ഗുണിക്കുക ...
                while e >= small_e {
                    self.mul_small(small_power);
                    e -= small_e;
                }

                // ... തുടർന്ന് ബാക്കിയുള്ളവ അവസാനിപ്പിക്കുക.
                let mut rest_power = 1;
                for _ in 0..e {
                    rest_power *= 5;
                }
                self.mul_small(rest_power);

                self
            }

            /// `other[0] + other[1]*2^W + other[2]* 2^(2W) + ...` വിവരിച്ച ഒരു സംഖ്യയാൽ തന്നെ ഗുണിക്കുന്നു (ഇവിടെ `W` എന്നത് അക്ക തരത്തിലുള്ള ബിറ്റുകളുടെ എണ്ണമാണ്) കൂടാതെ സ്വന്തം മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു.
            ///
            ///
            pub fn mul_digits<'a>(&'a mut self, other: &[$ty]) -> &'a mut $name {
                // ആന്തരിക ദിനചര്യ.aa.len() <= bb.len() ആയിരിക്കുമ്പോൾ മികച്ച രീതിയിൽ പ്രവർത്തിക്കുന്നു.
                fn mul_inner(ret: &mut [$ty; $n], aa: &[$ty], bb: &[$ty]) -> usize {
                    use crate::num::bignum::FullOps;

                    let mut retsz = 0;
                    for (i, &a) in aa.iter().enumerate() {
                        if a == 0 {
                            continue;
                        }
                        let mut sz = bb.len();
                        let mut carry = 0;
                        for (j, &b) in bb.iter().enumerate() {
                            let (c, v) = a.full_mul_add(b, ret[i + j], carry);
                            ret[i + j] = v;
                            carry = c;
                        }
                        if carry > 0 {
                            ret[i + sz] = carry;
                            sz += 1;
                        }
                        if retsz < i + sz {
                            retsz = i + sz;
                        }
                    }
                    retsz
                }

                let mut ret = [0; $n];
                let retsz = if self.size < other.len() {
                    mul_inner(&mut ret, &self.digits(), other)
                } else {
                    mul_inner(&mut ret, other, &self.digits())
                };
                self.base = ret;
                self.size = retsz;
                self
            }

            /// ഒരു അക്ക വലുപ്പത്തിലുള്ള `other` കൊണ്ട് സ്വയം വിഭജിച്ച് അതിന്റേതായ മ്യൂട്ടബിൾ റഫറൻസ് *ഉം* ബാക്കിയുള്ളവയും നൽകുന്നു.
            ///
            pub fn div_rem_small(&mut self, other: $ty) -> (&mut $name, $ty) {
                use crate::num::bignum::FullOps;

                assert!(other > 0);

                let sz = self.size;
                let mut borrow = 0;
                for a in self.base[..sz].iter_mut().rev() {
                    let (q, r) = (*a).full_div_rem(other, borrow);
                    *a = q;
                    borrow = r;
                }
                (self, borrow)
            }

            /// മറ്റൊരു ബിഗ്നം ഉപയോഗിച്ച് സ്വയം വിഭജിക്കുക, ഘടകവുമായി `q` ഉം ബാക്കിയുള്ളവ ഉപയോഗിച്ച് `r` ഉം തിരുത്തിയെഴുതുന്നു.
            ///
            pub fn div_rem(&self, d: &$name, q: &mut $name, r: &mut $name) {
                // വിഡ് up ിത്ത സ്ലോ എക്സ് 100 എക്സ് ലോംഗ് ഡിവിഷൻ
                // https://en.wikipedia.org/wiki/Division_algorithm
                // ദൈർഘ്യമേറിയ വിഭജനത്തിനായി FIXME ഒരു വലിയ ബേസ് ($ty) ഉപയോഗിക്കുന്നു.
                assert!(!d.is_zero());
                let digitbits = <$ty>::BITS as usize;
                for digit in &mut q.base[..] {
                    *digit = 0;
                }
                for digit in &mut r.base[..] {
                    *digit = 0;
                }
                r.size = d.size;
                q.size = 1;
                let mut q_is_zero = true;
                let end = self.bit_length();
                for i in (0..end).rev() {
                    r.mul_pow2(1);
                    r.base[0] |= self.get_bit(i) as $ty;
                    if &*r >= d {
                        r.sub(d);
                        // Q ന്റെ 1 ബിറ്റ് `i` സജ്ജമാക്കുക.
                        let digit_idx = i / digitbits;
                        let bit_idx = i % digitbits;
                        if q_is_zero {
                            q.size = digit_idx + 1;
                            q_is_zero = false;
                        }
                        q.base[digit_idx] |= 1 << bit_idx;
                    }
                }
                debug_assert!(q.base[q.size..].iter().all(|&d| d == 0));
                debug_assert!(r.base[r.size..].iter().all(|&d| d == 0));
            }
        }

        impl crate::cmp::PartialEq for $name {
            fn eq(&self, other: &$name) -> bool {
                self.base[..] == other.base[..]
            }
        }

        impl crate::cmp::Eq for $name {}

        impl crate::cmp::PartialOrd for $name {
            fn partial_cmp(&self, other: &$name) -> crate::option::Option<crate::cmp::Ordering> {
                crate::option::Option::Some(self.cmp(other))
            }
        }

        impl crate::cmp::Ord for $name {
            fn cmp(&self, other: &$name) -> crate::cmp::Ordering {
                use crate::cmp::max;
                let sz = max(self.size, other.size);
                let lhs = self.base[..sz].iter().cloned().rev();
                let rhs = other.base[..sz].iter().cloned().rev();
                lhs.cmp(rhs)
            }
        }

        impl crate::clone::Clone for $name {
            fn clone(&self) -> Self {
                Self { size: self.size, base: self.base }
            }
        }

        impl crate::fmt::Debug for $name {
            fn fmt(&self, f: &mut crate::fmt::Formatter<'_>) -> crate::fmt::Result {
                let sz = if self.size < 1 { 1 } else { self.size };
                let digitlen = <$ty>::BITS as usize / 4;

                write!(f, "{:#x}", self.base[sz - 1])?;
                for &v in self.base[..sz - 1].iter().rev() {
                    write!(f, "_{:01$x}", v, digitlen)?;
                }
                crate::result::Result::Ok(())
            }
        }
    };
}

/// `Big32x40`-നായുള്ള അക്ക തരം.
pub type Digit32 = u32;

define_bignum!(Big32x40: type=Digit32, n=40);

// ഇത് പരിശോധനയ്ക്ക് മാത്രം ഉപയോഗിക്കുന്നു.
#[doc(hidden)]
pub mod tests {
    define_bignum!(Big8x3: type=u8, n=3);
}