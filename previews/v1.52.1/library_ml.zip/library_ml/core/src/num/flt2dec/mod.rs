/*!

Floating-point number to decimal conversion routines.

# Problem statement

We are given the floating-point number `v = f * 2^e` with an integer `f`,
and its bounds `minus` and `plus` such that any number between `v - minus` and
`v + plus` will be rounded to `v`. For the simplicity we assume that
this range is exclusive. Then we would like to get the unique decimal
representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero.

- It's correctly rounded when parsed back: `v - minus < V < v + plus`.
  Furthermore it is shortest such one, i.e., there is no representation
  with less than `n` digits that is correctly rounded.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Note that
  there might be two representations satisfying this uniqueness requirement,
  in which case some tie-breaking mechanism is used.

We will call this mode of operation as to the *shortest* mode. This mode is used
when there is no additional constraint, and can be thought as a "natural" mode
as it matches the ordinary intuition (it at least prints `0.1f32` as "0.1").

We have two more modes of operation closely related to each other. In these modes
we are given either the number of significant digits `n` or the last-digit
limitation `limit` (which determines the actual `n`), and we would like to get
the representation `V = 0.d[0..n-1] * 10^k` such that:

- `d[0]` is non-zero, unless `n` was zero in which case only `k` is returned.

- It's closest to the original value: `abs(V - v) <= 10^(k-n) / 2`. Again,
  there might be some tie-breaking mechanism.

When `limit` is given but not `n`, we set `n` such that `k - n = limit`
so that the last digit `d[n-1]` is scaled by `10^(k-n) = 10^limit`.
If such `n` is negative, we clip it to zero so that we will only get `k`.
We are also limited by the supplied buffer. This limitation is used to print
the number up to given number of fractional digits without knowing
the correct `k` beforehand.

We will call the mode of operation requiring `n` as to the *exact* mode,
and one requiring `limit` as to the *fixed* mode. The exact mode is a subset of
the fixed mode: the sufficiently large last-digit limitation will eventually fill
the supplied buffer and let the algorithm to return.

# Implementation overview

It is easy to get the floating point printing correct but slow (Russ Cox has
[demonstrated](http://research.swtch.com/ftoa) how it's easy), or incorrect but
fast (naïve division and modulo). But it is surprisingly hard to print
floating point numbers correctly *and* efficiently.

There are two classes of algorithms widely known to be correct.

- The "Dragon" family of algorithm is first described by Guy L. Steele Jr. and
  Jon L. White. They rely on the fixed-size big integer for their correctness.
  A slight improvement was found later, which is posthumously described by
  Robert G. Burger and R. Kent Dybvig. David Gay's `dtoa.c` routine is
  a popular implementation of this strategy.

- The "Grisu" family of algorithm is first described by Florian Loitsch.
  They use very cheap integer-only procedure to determine the close-to-correct
  representation which is at least guaranteed to be shortest. The variant,
  Grisu3, actively detects if the resulting representation is incorrect.

We implement both algorithms with necessary tweaks to suit our requirements.
In particular, published literatures are short of the actual implementation
difficulties like how to avoid arithmetic overflows. Each implementation,
available in `strategy::dragon` and `strategy::grisu` respectively,
extensively describes all necessary justifications and many proofs for them.
(It is still difficult to follow though. You have been warned.)

Both implementations expose two public functions:

- `format_shortest(decoded, buf)`, which always needs at least
  `MAX_SIG_DIGITS` digits of buffer. Implements the shortest mode.

- `format_exact(decoded, buf, limit)`, which accepts as small as
  one digit of buffer. Implements exact and fixed modes.

They try to fill the `u8` buffer with digits and returns the number of digits
written and the exponent `k`. They are total for all finite `f32` and `f64`
inputs (Grisu internally falls back to Dragon if necessary).

The rendered digits are formatted into the actual string form with
four functions:

- `to_shortest_str` prints the shortest representation, which can be padded by
  zeroes to make *at least* given number of fractional digits.

- `to_shortest_exp_str` prints the shortest representation, which can be
  padded by zeroes when its exponent is in the specified ranges,
  or can be printed in the exponential form such as `1.23e45`.

- `to_exact_exp_str` prints the exact representation with given number of
  digits in the exponential form.

- `to_exact_fixed_str` prints the fixed representation with *exactly*
  given number of fractional digits.

They all return a slice of preallocated `Part` array, which corresponds to
the individual part of strings: a fixed string, a part of rendered digits,
a number of zeroes or a small (`u16`) number. The caller is expected to
provide a large enough buffer and `Part` array, and to assemble the final
string from resulting `Part`s itself.

All algorithms and formatting functions are accompanied by extensive tests
in `coretests::num::flt2dec` module. It also shows how to use individual
functions.

*/

// ഇത് വിപുലമായി രേഖപ്പെടുത്തിയിട്ടുണ്ടെങ്കിലും, ഇത് തത്വത്തിൽ സ്വകാര്യമാണ്, ഇത് പരിശോധനയ്ക്കായി മാത്രം പരസ്യമാക്കിയിരിക്കുന്നു.
// ഞങ്ങളെ തുറന്നുകാണിക്കരുത്.
#![doc(hidden)]
#![unstable(
    feature = "flt2dec",
    reason = "internal routines only exposed for testing",
    issue = "none"
)]

pub use self::decoder::{decode, DecodableFloat, Decoded, FullDecoded};

use crate::mem::MaybeUninit;

pub mod decoder;
pub mod estimator;

/// അക്ക-തലമുറ അൽ‌ഗോരിതംസ്.
pub mod strategy {
    pub mod dragon;
    pub mod grisu;
}

/// ഹ്രസ്വമായ മോഡിന് ആവശ്യമായ ബഫറിന്റെ ഏറ്റവും കുറഞ്ഞ വലുപ്പം.
///
/// ഉരുത്തിരിഞ്ഞത് അൽപ്പം നിസ്സാരമാണ്, എന്നാൽ ഇത് ഏറ്റവും കുറഞ്ഞ ഫലമുള്ള അൽ‌ഗോരിതം ഫോർ‌മാറ്റുചെയ്യുന്നതിൽ‌നിന്നും പ്രധാനപ്പെട്ട ദശാംശ അക്കങ്ങളുടെ പരമാവധി എണ്ണം കൂടിയാണ്.
///
/// കൃത്യമായ സൂത്രവാക്യം `ceil(# bits in mantissa * log_10 2 + 1)` ആണ്.
pub const MAX_SIG_DIGITS: usize = 17;

/// `d`-ൽ ദശാംശ അക്കങ്ങൾ ഉള്ളപ്പോൾ, അവസാന അക്കം വർദ്ധിപ്പിച്ച് കാരി പ്രചരിപ്പിക്കുക.
/// ദൈർഘ്യം മാറാൻ കാരണമാകുമ്പോൾ അടുത്ത അക്കം നൽകുന്നു.
#[doc(hidden)]
pub fn round_up(d: &mut [u8]) -> Option<u8> {
    match d.iter().rposition(|&c| c != b'9') {
        Some(i) => {
            // d [i + 1..n] എല്ലാം ഒമ്പത്
            d[i] += 1;
            for j in i + 1..d.len() {
                d[j] = b'0';
            }
            None
        }
        None if d.len() > 0 => {
            // 999..999 വർദ്ധിച്ച എക്‌സ്‌പോണന്റിനൊപ്പം 1000..000 വരെ റൗണ്ടുകൾ
            d[0] = b'1';
            for j in 1..d.len() {
                d[j] = b'0';
            }
            Some(b'0')
        }
        None => {
            // ഒരു ശൂന്യമായ ബഫർ റ s ണ്ട് അപ്പ് ചെയ്യുന്നു (അൽപ്പം വിചിത്രവും എന്നാൽ ന്യായയുക്തവും)
            Some(b'1')
        }
    }
}

/// ഫോർമാറ്റുചെയ്‌ത ഭാഗങ്ങൾ.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Part<'a> {
    /// പൂജ്യം അക്കങ്ങളുടെ എണ്ണം നൽകി.
    Zero(usize),
    /// 5 അക്കങ്ങൾ വരെയുള്ള അക്ഷരീയ നമ്പർ.
    Num(u16),
    /// നൽകിയ ബൈറ്റുകളുടെ പദാനുപദം.
    Copy(&'a [u8]),
}

impl<'a> Part<'a> {
    /// നൽകിയ ഭാഗത്തിന്റെ കൃത്യമായ ബൈറ്റ് ദൈർഘ്യം നൽകുന്നു.
    pub fn len(&self) -> usize {
        match *self {
            Part::Zero(nzeroes) => nzeroes,
            Part::Num(v) => {
                if v < 1_000 {
                    if v < 10 {
                        1
                    } else if v < 100 {
                        2
                    } else {
                        3
                    }
                } else {
                    if v < 10_000 { 4 } else { 5 }
                }
            }
            Part::Copy(buf) => buf.len(),
        }
    }

    /// വിതരണം ചെയ്ത ബഫറിലേക്ക് ഒരു ഭാഗം എഴുതുന്നു.
    /// എഴുതിയ ബൈറ്റുകളുടെ എണ്ണം അല്ലെങ്കിൽ ബഫർ പര്യാപ്തമല്ലെങ്കിൽ `None` നൽകുന്നു.
    /// (ഇത് ഇപ്പോഴും ഭാഗികമായി എഴുതിയ ബൈറ്റുകൾ ബഫറിൽ ഉപേക്ഷിച്ചേക്കാം; അതിനെ ആശ്രയിക്കരുത്.)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        let len = self.len();
        if out.len() >= len {
            match *self {
                Part::Zero(nzeroes) => {
                    for c in &mut out[..nzeroes] {
                        *c = b'0';
                    }
                }
                Part::Num(mut v) => {
                    for c in out[..len].iter_mut().rev() {
                        *c = b'0' + (v % 10) as u8;
                        v /= 10;
                    }
                }
                Part::Copy(buf) => {
                    out[..buf.len()].copy_from_slice(buf);
                }
            }
            Some(len)
        } else {
            None
        }
    }
}

/// ഒന്നോ അതിലധികമോ ഭാഗങ്ങൾ അടങ്ങിയ ഫോർമാറ്റുചെയ്‌ത ഫലം.
/// ഇത് ബൈറ്റ് ബഫറിലേക്ക് എഴുതാം അല്ലെങ്കിൽ അനുവദിച്ച സ്ട്രിംഗിലേക്ക് പരിവർത്തനം ചെയ്യാം.
#[allow(missing_debug_implementations)]
#[derive(Clone)]
pub struct Formatted<'a> {
    /// `""`, `"-"` അല്ലെങ്കിൽ `"+"` എന്ന ചിഹ്നത്തെ പ്രതിനിധീകരിക്കുന്ന ഒരു ബൈറ്റ് സ്ലൈസ്.
    pub sign: &'static str,
    /// ചിഹ്നത്തിനും ഓപ്‌ഷണൽ സീറോ പാഡിംഗിനും ശേഷം റെൻഡർ ചെയ്യേണ്ട ഫോർമാറ്റ് ചെയ്ത ഭാഗങ്ങൾ.
    pub parts: &'a [Part<'a>],
}

impl<'a> Formatted<'a> {
    /// സംയോജിത ഫോർമാറ്റുചെയ്‌ത ഫലത്തിന്റെ കൃത്യമായ ബൈറ്റ് ദൈർഘ്യം നൽകുന്നു.
    pub fn len(&self) -> usize {
        let mut len = self.sign.len();
        for part in self.parts {
            len += part.len();
        }
        len
    }

    /// വിതരണം ചെയ്ത ബഫറിലേക്ക് ഫോർമാറ്റ് ചെയ്ത എല്ലാ ഭാഗങ്ങളും എഴുതുന്നു.
    /// എഴുതിയ ബൈറ്റുകളുടെ എണ്ണം അല്ലെങ്കിൽ ബഫർ പര്യാപ്തമല്ലെങ്കിൽ `None` നൽകുന്നു.
    /// (ഇത് ഇപ്പോഴും ഭാഗികമായി എഴുതിയ ബൈറ്റുകൾ ബഫറിൽ ഉപേക്ഷിച്ചേക്കാം; അതിനെ ആശ്രയിക്കരുത്.)
    pub fn write(&self, out: &mut [u8]) -> Option<usize> {
        if out.len() < self.sign.len() {
            return None;
        }
        out[..self.sign.len()].copy_from_slice(self.sign.as_bytes());

        let mut written = self.sign.len();
        for part in self.parts {
            let len = part.write(&mut out[written..])?;
            written += len;
        }
        Some(written)
    }
}

/// കുറഞ്ഞത് നൽകിയിരിക്കുന്ന ഭിന്നസംഖ്യകളുള്ള ദശാംശ രൂപത്തിലേക്ക് `0.<...buf...> * 10^exp` ദശാംശ അക്കങ്ങൾ നൽകിയ ഫോർമാറ്റുകൾ.
///
/// ഫലം വിതരണം ചെയ്ത ഭാഗങ്ങളുടെ അറേയിലേക്ക് സംഭരിക്കുകയും എഴുതിയ ഭാഗങ്ങളുടെ ഒരു കഷ്ണം തിരികെ നൽകുകയും ചെയ്യുന്നു.
///
/// `frac_digits` `buf`-ലെ യഥാർത്ഥ ഭിന്നസംഖ്യകളുടെ എണ്ണത്തേക്കാൾ കുറവായിരിക്കാം;
/// ഇത് അവഗണിക്കുകയും പൂർണ്ണ അക്കങ്ങൾ അച്ചടിക്കുകയും ചെയ്യും.റെൻഡർ ചെയ്ത അക്കങ്ങൾക്ക് ശേഷം അധിക പൂജ്യങ്ങൾ അച്ചടിക്കാൻ മാത്രമേ ഇത് ഉപയോഗിക്കൂ.
/// അങ്ങനെ 0 ന്റെ `frac_digits` എന്നതിനർത്ഥം നൽകിയ അക്കങ്ങൾ മാത്രമേ അച്ചടിക്കുകയുള്ളൂ, മറ്റൊന്നുമല്ല.
///
fn digits_to_dec_str<'a>(
    buf: &'a [u8],
    exp: i16,
    frac_digits: usize,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 4);

    // അവസാന അക്ക സ്ഥാനത്ത് നിയന്ത്രണമുണ്ടെങ്കിൽ, വിർച്വൽ പൂജ്യങ്ങൾക്കൊപ്പം `buf` ഇടത് പാഡ് ആയി കണക്കാക്കപ്പെടുന്നു.
    // വിർച്വൽ സീറോകളുടെ എണ്ണം, `nzeroes`, `max(0, exp + frac_digits - buf.len())` ന് തുല്യമാണ്, അതിനാൽ അവസാന അക്കമായ `exp - buf.len() - nzeroes` ന്റെ സ്ഥാനം `-frac_digits` ൽ കൂടുതലാകരുത്:
    //
    //
    //                       |<-virtual->|
    //       | <----buf----> |പൂജ്യം |exp
    //    0. 1 2 3 4 5 6 7 8 9 _ _ _ _ _ _ x 10
    //    |                  |           |
    // 10 ^ exp 10^(exp-buf.len()) 10^(exp-buf.len()-nzeroes)
    //
    // `nzeroes` ഓവർഫ്ലോ ഒഴിവാക്കാൻ ഓരോ കേസിലും വ്യക്തിഗതമായി കണക്കാക്കുന്നു.
    //

    if exp <= 0 {
        // റെൻഡർ ചെയ്ത അക്കങ്ങൾക്ക് മുമ്പാണ് ദശാംശ ബിന്ദു: [0.][000...000][1234][____]
        let minus_exp = -(exp as i32) as usize;
        parts[0] = MaybeUninit::new(Part::Copy(b"0."));
        parts[1] = MaybeUninit::new(Part::Zero(minus_exp));
        parts[2] = MaybeUninit::new(Part::Copy(buf));
        if frac_digits > buf.len() && frac_digits - buf.len() > minus_exp {
            parts[3] = MaybeUninit::new(Part::Zero((frac_digits - buf.len()) - minus_exp));
            // സുരക്ഷ: ഞങ്ങൾ `..4` ഘടകങ്ങൾ സമാരംഭിച്ചു.
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
        } else {
            // സുരക്ഷ: ഞങ്ങൾ `..3` ഘടകങ്ങൾ സമാരംഭിച്ചു.
            unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
        }
    } else {
        let exp = exp as usize;
        if exp < buf.len() {
            // റെൻഡർ ചെയ്ത അക്കങ്ങൾക്കുള്ളിലാണ് ദശാംശ ബിന്ദു: [12][.][34][____]
            parts[0] = MaybeUninit::new(Part::Copy(&buf[..exp]));
            parts[1] = MaybeUninit::new(Part::Copy(b"."));
            parts[2] = MaybeUninit::new(Part::Copy(&buf[exp..]));
            if frac_digits > buf.len() - exp {
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits - (buf.len() - exp)));
                // സുരക്ഷ: ഞങ്ങൾ `..4` ഘടകങ്ങൾ സമാരംഭിച്ചു.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // സുരക്ഷ: ഞങ്ങൾ `..3` ഘടകങ്ങൾ സമാരംഭിച്ചു.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) }
            }
        } else {
            // റെൻഡർ ചെയ്ത അക്കങ്ങൾക്ക് ശേഷമാണ് ദശാംശ ബിന്ദു: [1234][____0000] അല്ലെങ്കിൽ [1234][__][.][__].
            parts[0] = MaybeUninit::new(Part::Copy(buf));
            parts[1] = MaybeUninit::new(Part::Zero(exp - buf.len()));
            if frac_digits > 0 {
                parts[2] = MaybeUninit::new(Part::Copy(b"."));
                parts[3] = MaybeUninit::new(Part::Zero(frac_digits));
                // സുരക്ഷ: ഞങ്ങൾ `..4` ഘടകങ്ങൾ സമാരംഭിച്ചു.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..4]) }
            } else {
                // സുരക്ഷ: ഞങ്ങൾ `..2` ഘടകങ്ങൾ സമാരംഭിച്ചു.
                unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) }
            }
        }
    }
}

/// തന്നിരിക്കുന്ന ദശാംശ അക്കങ്ങൾ `0.<...buf...> * 10^exp` എക്‌സ്‌പോണൻഷ്യൽ ഫോമിലേക്ക് ഫോർമാറ്റ് ചെയ്യുന്നു, കുറഞ്ഞത് നൽകിയിരിക്കുന്ന പ്രധാനപ്പെട്ട അക്കങ്ങളെങ്കിലും.
///
/// `upper` `true` ആകുമ്പോൾ, എക്‌സ്‌പോണന്റ് `E` പ്രിഫിക്‌സ് ചെയ്യും;അല്ലെങ്കിൽ അത് `e` ആണ്.
/// ഫലം വിതരണം ചെയ്ത ഭാഗങ്ങളുടെ അറേയിലേക്ക് സംഭരിക്കുകയും എഴുതിയ ഭാഗങ്ങളുടെ ഒരു കഷ്ണം തിരികെ നൽകുകയും ചെയ്യുന്നു.
///
/// `min_digits` `buf`-ലെ യഥാർത്ഥ പ്രധാനപ്പെട്ട അക്കങ്ങളുടെ എണ്ണത്തേക്കാൾ കുറവായിരിക്കാം;
/// ഇത് അവഗണിക്കുകയും പൂർണ്ണ അക്കങ്ങൾ അച്ചടിക്കുകയും ചെയ്യും.റെൻഡർ ചെയ്ത അക്കങ്ങൾക്ക് ശേഷം അധിക പൂജ്യങ്ങൾ അച്ചടിക്കാൻ മാത്രമേ ഇത് ഉപയോഗിക്കൂ.
/// അതിനാൽ, `min_digits == 0` അർത്ഥമാക്കുന്നത് തന്നിരിക്കുന്ന അക്കങ്ങൾ മാത്രമേ അച്ചടിക്കുകയുള്ളൂ, മറ്റൊന്നുമല്ല.
///
fn digits_to_exp_str<'a>(
    buf: &'a [u8],
    exp: i16,
    min_ndigits: usize,
    upper: bool,
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> &'a [Part<'a>] {
    assert!(!buf.is_empty());
    assert!(buf[0] > b'0');
    assert!(parts.len() >= 6);

    let mut n = 0;

    parts[n] = MaybeUninit::new(Part::Copy(&buf[..1]));
    n += 1;

    if buf.len() > 1 || min_ndigits > 1 {
        parts[n] = MaybeUninit::new(Part::Copy(b"."));
        parts[n + 1] = MaybeUninit::new(Part::Copy(&buf[1..]));
        n += 2;
        if min_ndigits > buf.len() {
            parts[n] = MaybeUninit::new(Part::Zero(min_ndigits - buf.len()));
            n += 1;
        }
    }

    // 0.1234 x 10 ^ exp= 1.234 x 10 ^ (exp-1)
    let exp = exp as i32 - 1; // എക്സ് എക്സ് എക്സ് ആയിരിക്കുമ്പോൾ അണ്ടർഫ്ലോ ഒഴിവാക്കുക
    if exp < 0 {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E-" } else { b"e-" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(-exp as u16));
    } else {
        parts[n] = MaybeUninit::new(Part::Copy(if upper { b"E" } else { b"e" }));
        parts[n + 1] = MaybeUninit::new(Part::Num(exp as u16));
    }
    // സുരക്ഷ: ഞങ്ങൾ `..n + 2` ഘടകങ്ങൾ സമാരംഭിച്ചു.
    unsafe { MaybeUninit::slice_assume_init_ref(&parts[..n + 2]) }
}

/// ഫോർമാറ്റിംഗ് ഓപ്ഷനുകൾ സൈൻ ചെയ്യുക.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Sign {
    /// നെഗറ്റീവ് പൂജ്യമല്ലാത്ത മൂല്യങ്ങൾക്കായി മാത്രം `-` പ്രിന്റുചെയ്യുന്നു.
    Minus, // -inf -1 0 0 1 inf nan
    /// ഏതെങ്കിലും നെഗറ്റീവ് മൂല്യങ്ങൾക്ക് (നെഗറ്റീവ് പൂജ്യം ഉൾപ്പെടെ) മാത്രം `-` പ്രിന്റുചെയ്യുന്നു.
    MinusRaw, // -inf -1 -0 0 1 inf nan
    /// നെഗറ്റീവ് പൂജ്യമല്ലാത്ത മൂല്യങ്ങൾക്കായി `-` അല്ലെങ്കിൽ മറ്റുവിധത്തിൽ `+` പ്രിന്റുചെയ്യുന്നു.
    MinusPlus, // -inf -1 +0 +0 +1 + inf nan
    /// ഏതെങ്കിലും നെഗറ്റീവ് മൂല്യങ്ങൾക്കായി (നെഗറ്റീവ് പൂജ്യം ഉൾപ്പെടെ) `-` അല്ലെങ്കിൽ `+` പ്രിന്റുചെയ്യുന്നു.
    MinusPlusRaw, // -inf -1 -0 +0 +1 + inf nan
}

/// ഫോർമാറ്റുചെയ്യേണ്ട ചിഹ്നത്തിന് അനുയോജ്യമായ സ്റ്റാറ്റിക് ബൈറ്റ് സ്ട്രിംഗ് നൽകുന്നു.
/// ഇത് `""`, `"+"` അല്ലെങ്കിൽ `"-"` ആകാം.
fn determine_sign(sign: Sign, decoded: &FullDecoded, negative: bool) -> &'static str {
    match (*decoded, sign) {
        (FullDecoded::Nan, _) => "",
        (FullDecoded::Zero, Sign::Minus) => "",
        (FullDecoded::Zero, Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (FullDecoded::Zero, Sign::MinusPlus) => "+",
        (FullDecoded::Zero, Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
        (_, Sign::Minus | Sign::MinusRaw) => {
            if negative {
                "-"
            } else {
                ""
            }
        }
        (_, Sign::MinusPlus | Sign::MinusPlusRaw) => {
            if negative {
                "-"
            } else {
                "+"
            }
        }
    }
}

/// തന്നിരിക്കുന്ന ഫ്ലോട്ടിംഗ് പോയിൻറ് നമ്പറിനെ ദശാംശ രൂപത്തിലേക്ക് ഫോർമാറ്റ് ചെയ്യുന്നു, കുറഞ്ഞത് നൽകിയിരിക്കുന്ന ഭിന്നസംഖ്യകളെങ്കിലും.
/// നൽകിയ ബൈറ്റ് ബഫർ ഒരു സ്ക്രാച്ചായി ഉപയോഗിക്കുമ്പോൾ ഫലം വിതരണം ചെയ്ത ഭാഗങ്ങളുടെ അറേയിലേക്ക് സൂക്ഷിക്കുന്നു.
/// `upper` നിലവിൽ ഉപയോഗിക്കാത്തവയാണ്, എന്നാൽ പരിധിയില്ലാത്ത മൂല്യങ്ങളുടെ കാര്യം മാറ്റാനുള്ള future തീരുമാനത്തിനായി അവശേഷിക്കുന്നു, അതായത്, `inf`, `nan`.
///
/// റെൻഡർ ചെയ്യേണ്ട ആദ്യ ഭാഗം എല്ലായ്പ്പോഴും ഒരു `Part::Sign` ആണ് (അടയാളങ്ങളൊന്നും റെൻഡർ ചെയ്തിട്ടില്ലെങ്കിൽ ഇത് ഒരു ശൂന്യമായ സ്ട്രിംഗ് ആകാം).
///
/// `format_shortest` അണ്ടര്ലയിങ്ങ് ഡിജിറ്റ് ജനറേഷന് ഫംഗ്ഷന് ആയിരിക്കണം.
/// ഇത് സമാരംഭിച്ച ബഫറിന്റെ ഭാഗം തിരികെ നൽകണം.
/// ഇതിനായി നിങ്ങൾക്ക് `strategy::grisu::format_shortest` ആവശ്യമായി വരും.
///
/// `frac_digits` `v`-ലെ യഥാർത്ഥ ഭിന്നസംഖ്യകളുടെ എണ്ണത്തേക്കാൾ കുറവായിരിക്കാം;
/// ഇത് അവഗണിക്കുകയും പൂർണ്ണ അക്കങ്ങൾ അച്ചടിക്കുകയും ചെയ്യും.റെൻഡർ ചെയ്ത അക്കങ്ങൾക്ക് ശേഷം അധിക പൂജ്യങ്ങൾ അച്ചടിക്കാൻ മാത്രമേ ഇത് ഉപയോഗിക്കൂ.
/// അങ്ങനെ 0 ന്റെ `frac_digits` എന്നതിനർത്ഥം നൽകിയ അക്കങ്ങൾ മാത്രമേ അച്ചടിക്കുകയുള്ളൂ, മറ്റൊന്നുമല്ല.
///
/// ബൈറ്റ് ബഫറിന് കുറഞ്ഞത് `MAX_SIG_DIGITS` ബൈറ്റുകളെങ്കിലും നീളമുണ്ടായിരിക്കണം.
/// `frac_digits = 10` ഉള്ള `[+][0.][0000][2][0000]` പോലുള്ള ഏറ്റവും മോശം അവസ്ഥ കാരണം കുറഞ്ഞത് 4 ഭാഗങ്ങളെങ്കിലും ലഭ്യമായിരിക്കണം.
///
///
///
pub fn to_shortest_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);
    assert!(buf.len() >= MAX_SIG_DIGITS);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // സുരക്ഷ: ഞങ്ങൾ `..1` ഘടകങ്ങൾ സമാരംഭിച്ചു.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // സുരക്ഷ: ഞങ്ങൾ `..1` ഘടകങ്ങൾ സമാരംഭിച്ചു.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // സുരക്ഷ: ഞങ്ങൾ `..2` ഘടകങ്ങൾ സമാരംഭിച്ചു.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // സുരക്ഷ: ഞങ്ങൾ `..1` ഘടകങ്ങൾ സമാരംഭിച്ചു.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
        }
    }
}

/// തത്ഫലമായുണ്ടാകുന്ന എക്‌സ്‌പോണന്റിനെ ആശ്രയിച്ച് തന്നിരിക്കുന്ന ഫ്ലോട്ടിംഗ് പോയിന്റ് നമ്പർ ദശാംശ രൂപത്തിലേക്കോ എക്‌സ്‌പോണൻഷ്യൽ രൂപത്തിലേക്കോ ഫോർമാറ്റുചെയ്യുന്നു.
/// നൽകിയ ബൈറ്റ് ബഫർ ഒരു സ്ക്രാച്ചായി ഉപയോഗിക്കുമ്പോൾ ഫലം വിതരണം ചെയ്ത ഭാഗങ്ങളുടെ അറേയിലേക്ക് സൂക്ഷിക്കുന്നു.
/// `upper` പരിധിയില്ലാത്ത മൂല്യങ്ങളുടെ (`inf`, `nan`) കേസ് അല്ലെങ്കിൽ എക്‌സ്‌പോണന്റ് പ്രിഫിക്സിന്റെ (`e` അല്ലെങ്കിൽ `E`) കേസ് നിർണ്ണയിക്കാൻ ഉപയോഗിക്കുന്നു.
/// റെൻഡർ ചെയ്യേണ്ട ആദ്യ ഭാഗം എല്ലായ്പ്പോഴും ഒരു `Part::Sign` ആണ് (അടയാളങ്ങളൊന്നും റെൻഡർ ചെയ്തിട്ടില്ലെങ്കിൽ ഇത് ഒരു ശൂന്യമായ സ്ട്രിംഗ് ആകാം).
///
/// `format_shortest` അണ്ടര്ലയിങ്ങ് ഡിജിറ്റ് ജനറേഷന് ഫംഗ്ഷന് ആയിരിക്കണം.
/// ഇത് സമാരംഭിച്ച ബഫറിന്റെ ഭാഗം തിരികെ നൽകണം.
/// ഇതിനായി നിങ്ങൾക്ക് `strategy::grisu::format_shortest` ആവശ്യമായി വരും.
///
/// `dec_bounds` എന്നത് ഒരു ട്യൂപ്പിൾ `(lo, hi)` ആണ്, അതായത് `10^lo <= V < 10^hi` ആയിരിക്കുമ്പോൾ മാത്രം സംഖ്യ ദശാംശമായി ഫോർമാറ്റുചെയ്യുന്നു.
/// യഥാർത്ഥ `v`-ന് പകരമായി ഇത് *പ്രത്യക്ഷമായ*`V` ആണെന്ന് ശ്രദ്ധിക്കുക!അതിനാൽ എക്‌സ്‌പോണൻഷ്യൽ രൂപത്തിൽ അച്ചടിച്ച എക്‌സ്‌പോണന്റുകളൊന്നും ഈ ശ്രേണിയിൽ ഉണ്ടാകരുത്, ഇത് ആശയക്കുഴപ്പം ഒഴിവാക്കുന്നു.
///
///
/// ബൈറ്റ് ബഫറിന് കുറഞ്ഞത് `MAX_SIG_DIGITS` ബൈറ്റുകളെങ്കിലും നീളമുണ്ടായിരിക്കണം.
/// `[+][1][.][2345][e][-][6]` പോലുള്ള ഏറ്റവും മോശം അവസ്ഥ കാരണം കുറഞ്ഞത് 6 ഭാഗങ്ങളെങ്കിലും ലഭ്യമായിരിക്കണം.
///
///
///
///
///
pub fn to_shortest_exp_str<'a, T, F>(
    mut format_shortest: F,
    v: T,
    sign: Sign,
    dec_bounds: (i16, i16),
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>]) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(dec_bounds.0 <= dec_bounds.1);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // സുരക്ഷ: ഞങ്ങൾ `..1` ഘടകങ്ങൾ സമാരംഭിച്ചു.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // സുരക്ഷ: ഞങ്ങൾ `..1` ഘടകങ്ങൾ സമാരംഭിച്ചു.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            parts[0] = if dec_bounds.0 <= 0 && 0 < dec_bounds.1 {
                MaybeUninit::new(Part::Copy(b"0"))
            } else {
                MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }))
            };
            // സുരക്ഷ: ഞങ്ങൾ `..1` ഘടകങ്ങൾ സമാരംഭിച്ചു.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Finite(ref decoded) => {
            let (buf, exp) = format_shortest(decoded, buf);
            let vis_exp = exp as i32 - 1;
            let parts = if dec_bounds.0 as i32 <= vis_exp && vis_exp < dec_bounds.1 as i32 {
                digits_to_dec_str(buf, exp, 0, parts)
            } else {
                digits_to_exp_str(buf, exp, 0, upper, parts)
            };
            Formatted { sign, parts }
        }
    }
}

/// തന്നിരിക്കുന്ന ഡീകോഡ് എക്‌സ്‌പോണന്റിൽ നിന്ന് കണക്കാക്കിയ പരമാവധി ബഫർ വലുപ്പത്തിനായി ഒരു ക്രൂഡ് ഏകദേശ (അപ്പർ ബൗണ്ട്) നൽകുന്നു.
///
/// കൃത്യമായ പരിധി ഇതാണ്:
///
/// - `exp < 0` ആയിരിക്കുമ്പോൾ, പരമാവധി നീളം `ceil(log_10 (5^-exp * (2^64 - 1)))` ആണ്.
/// - `exp >= 0` ആയിരിക്കുമ്പോൾ, പരമാവധി നീളം `ceil(log_10 (2^exp * (2^64 - 1)))` ആണ്.
///
/// `ceil(log_10 (x^exp * (2^64 - 1)))` `ceil(log_10 (2^64 - 1)) + ceil(exp *log_10 x)`-നേക്കാൾ കുറവാണ്, ഇത് `20 + (1 + exp* log_10 x)`-നേക്കാൾ കുറവാണ്.
/// ഞങ്ങളുടെ ആവശ്യങ്ങൾക്ക് പര്യാപ്തമായ `log_10 2 < 5/16`, `log_10 5 < 12/16` എന്നീ വസ്തുതകൾ ഞങ്ങൾ ഉപയോഗിക്കുന്നു.
///
/// എന്തുകൊണ്ടാണ് ഞങ്ങൾക്ക് ഇത് വേണ്ടത്?അവസാന അക്ക നിയന്ത്രണത്താൽ പരിമിതപ്പെടുത്തിയിട്ടില്ലെങ്കിൽ `format_exact` ഫംഗ്ഷനുകൾ മുഴുവൻ ബഫറിലും നിറയും, പക്ഷേ അഭ്യർത്ഥിച്ച അക്കങ്ങളുടെ എണ്ണം പരിഹാസ്യമായി വലുതായിരിക്കാം (അതായത്, 30,000 അക്കങ്ങൾ).
///
/// ബഫറിന്റെ ബഹുഭൂരിപക്ഷവും പൂജ്യങ്ങളാൽ നിറയും, അതിനാൽ എല്ലാ ബഫറുകളും മുൻ‌കൂട്ടി അനുവദിക്കാൻ ഞങ്ങൾ ആഗ്രഹിക്കുന്നില്ല.
/// തൽഫലമായി, ഏതെങ്കിലും വാദങ്ങൾക്ക്,
/// `f64`-ന് 826 ബൈറ്റുകൾ ബഫർ മതിയാകും.ഏറ്റവും മോശം അവസ്ഥയ്ക്കുള്ള യഥാർത്ഥ നമ്പറുമായി ഇത് താരതമ്യം ചെയ്യുക: 770 ബൈറ്റുകൾ (`exp = -1074` ആയിരിക്കുമ്പോൾ).
///
///
///
///
///
fn estimate_max_buf_len(exp: i16) -> usize {
    21 + ((if exp < 0 { -12 } else { 5 } * exp as i32) as usize >> 4)
}

/// എക്‌സ്‌പോണൻഷ്യൽ ഫോമിലേക്ക് ഫ്ലോട്ടിംഗ് പോയിന്റ് നമ്പർ നൽകിയ ഫോർമാറ്റുകൾ കൃത്യമായി നൽകിയ അക്കങ്ങളുടെ എണ്ണം.
/// നൽകിയ ബൈറ്റ് ബഫർ ഒരു സ്ക്രാച്ചായി ഉപയോഗിക്കുമ്പോൾ ഫലം വിതരണം ചെയ്ത ഭാഗങ്ങളുടെ അറേയിലേക്ക് സൂക്ഷിക്കുന്നു.
/// `upper` എക്‌സ്‌പോണന്റ് പ്രിഫിക്‌സിന്റെ (`e` അല്ലെങ്കിൽ `E`) കേസ് നിർണ്ണയിക്കാൻ ഉപയോഗിക്കുന്നു.
/// റെൻഡർ ചെയ്യേണ്ട ആദ്യ ഭാഗം എല്ലായ്പ്പോഴും ഒരു `Part::Sign` ആണ് (അടയാളങ്ങളൊന്നും റെൻഡർ ചെയ്തിട്ടില്ലെങ്കിൽ ഇത് ഒരു ശൂന്യമായ സ്ട്രിംഗ് ആകാം).
///
/// `format_exact` അണ്ടര്ലയിങ്ങ് ഡിജിറ്റ് ജനറേഷന് ഫംഗ്ഷന് ആയിരിക്കണം.
/// ഇത് സമാരംഭിച്ച ബഫറിന്റെ ഭാഗം തിരികെ നൽകണം.
/// ഇതിനായി നിങ്ങൾക്ക് `strategy::grisu::format_exact` ആവശ്യമായി വരും.
///
/// `ndigits` വളരെ വലുതാണെങ്കിൽ ബൈറ്റ് ബഫറിന് കുറഞ്ഞത് `ndigits` ബൈറ്റുകളെങ്കിലും ദൈർഘ്യമുണ്ടായിരിക്കണം, നിശ്ചിത എണ്ണം അക്കങ്ങൾ മാത്രമേ എഴുതുകയുള്ളൂ.
/// (`f64`-ന്റെ ടിപ്പിംഗ് പോയിന്റ് ഏകദേശം 800 ആണ്, അതിനാൽ 1000 ബൈറ്റുകൾ മതിയാകും.) `[+][1][.][2345][e][-][6]` പോലുള്ള ഏറ്റവും മോശം അവസ്ഥ കാരണം കുറഞ്ഞത് 6 ഭാഗങ്ങളെങ്കിലും ലഭ്യമായിരിക്കണം.
///
///
///
///
///
pub fn to_exact_exp_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    ndigits: usize,
    upper: bool,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 6);
    assert!(ndigits > 0);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // സുരക്ഷ: ഞങ്ങൾ `..1` ഘടകങ്ങൾ സമാരംഭിച്ചു.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // സുരക്ഷ: ഞങ്ങൾ `..1` ഘടകങ്ങൾ സമാരംഭിച്ചു.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if ndigits > 1 {
                // [0.][0000][e0]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(ndigits - 1));
                parts[2] = MaybeUninit::new(Part::Copy(if upper { b"E0" } else { b"e0" }));
                Formatted {
                    sign,
                    // സുരക്ഷ: ഞങ്ങൾ `..3` ഘടകങ്ങൾ സമാരംഭിച്ചു.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..3]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(if upper { b"0E0" } else { b"0e0" }));
                Formatted {
                    sign,
                    // സുരക്ഷ: ഞങ്ങൾ `..1` ഘടകങ്ങൾ സമാരംഭിച്ചു.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= ndigits || buf.len() >= maxlen);

            let trunc = if ndigits < maxlen { ndigits } else { maxlen };
            let (buf, exp) = format_exact(decoded, &mut buf[..trunc], i16::MIN);
            Formatted { sign, parts: digits_to_exp_str(buf, exp, ndigits, upper, parts) }
        }
    }
}

/// ഫ്ലോട്ടിംഗ് പോയിന്റ് നമ്പർ ഡെസിമൽ ഫോമിലേക്ക് നൽകിയ ഫോർമാറ്റുകൾ കൃത്യമായി നൽകിയിരിക്കുന്ന ഭിന്നസംഖ്യകളോടെ.
/// നൽകിയ ബൈറ്റ് ബഫർ ഒരു സ്ക്രാച്ചായി ഉപയോഗിക്കുമ്പോൾ ഫലം വിതരണം ചെയ്ത ഭാഗങ്ങളുടെ അറേയിലേക്ക് സൂക്ഷിക്കുന്നു.
/// `upper` നിലവിൽ ഉപയോഗിക്കാത്തവയാണ്, എന്നാൽ പരിധിയില്ലാത്ത മൂല്യങ്ങളുടെ കാര്യം മാറ്റാനുള്ള future തീരുമാനത്തിനായി അവശേഷിക്കുന്നു, അതായത്, `inf`, `nan`.
/// റെൻഡർ ചെയ്യേണ്ട ആദ്യ ഭാഗം എല്ലായ്പ്പോഴും ഒരു `Part::Sign` ആണ് (അടയാളങ്ങളൊന്നും റെൻഡർ ചെയ്തിട്ടില്ലെങ്കിൽ ഇത് ഒരു ശൂന്യമായ സ്ട്രിംഗ് ആകാം).
///
/// `format_exact` അണ്ടര്ലയിങ്ങ് ഡിജിറ്റ് ജനറേഷന് ഫംഗ്ഷന് ആയിരിക്കണം.
/// ഇത് സമാരംഭിച്ച ബഫറിന്റെ ഭാഗം തിരികെ നൽകണം.
/// ഇതിനായി നിങ്ങൾക്ക് `strategy::grisu::format_exact` ആവശ്യമായി വരും.
///
/// `frac_digits` വളരെ വലുതല്ലെങ്കിൽ output ട്ട്‌പുട്ടിനായി ബൈറ്റ് ബഫർ മതിയാകും, നിശ്ചിത എണ്ണം അക്കങ്ങൾ മാത്രമേ എഴുതുകയുള്ളൂ.
/// (`f64` നായുള്ള ടിപ്പിംഗ് പോയിൻറ് ഏകദേശം 800 ആണ്, 1000 ബൈറ്റുകൾ മതിയാകും.) `frac_digits = 10` ഉള്ള `[+][0.][0000][2][0000]` പോലുള്ള ഏറ്റവും മോശം അവസ്ഥ കാരണം കുറഞ്ഞത് 4 ഭാഗങ്ങളെങ്കിലും ലഭ്യമായിരിക്കണം.
///
///
///
///
///
pub fn to_exact_fixed_str<'a, T, F>(
    mut format_exact: F,
    v: T,
    sign: Sign,
    frac_digits: usize,
    buf: &'a mut [MaybeUninit<u8>],
    parts: &'a mut [MaybeUninit<Part<'a>>],
) -> Formatted<'a>
where
    T: DecodableFloat,
    F: FnMut(&Decoded, &'a mut [MaybeUninit<u8>], i16) -> (&'a [u8], i16),
{
    assert!(parts.len() >= 4);

    let (negative, full_decoded) = decode(v);
    let sign = determine_sign(sign, &full_decoded, negative);
    match full_decoded {
        FullDecoded::Nan => {
            parts[0] = MaybeUninit::new(Part::Copy(b"NaN"));
            // സുരക്ഷ: ഞങ്ങൾ `..1` ഘടകങ്ങൾ സമാരംഭിച്ചു.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Infinite => {
            parts[0] = MaybeUninit::new(Part::Copy(b"inf"));
            // സുരക്ഷ: ഞങ്ങൾ `..1` ഘടകങ്ങൾ സമാരംഭിച്ചു.
            Formatted { sign, parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) } }
        }
        FullDecoded::Zero => {
            if frac_digits > 0 {
                // [0.][0000]
                parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                Formatted {
                    sign,
                    // സുരക്ഷ: ഞങ്ങൾ `..2` ഘടകങ്ങൾ സമാരംഭിച്ചു.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                }
            } else {
                parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                Formatted {
                    sign,
                    // സുരക്ഷ: ഞങ്ങൾ `..1` ഘടകങ്ങൾ സമാരംഭിച്ചു.
                    parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                }
            }
        }
        FullDecoded::Finite(ref decoded) => {
            let maxlen = estimate_max_buf_len(decoded.exp);
            assert!(buf.len() >= maxlen);

            // `frac_digits` പരിഹാസ്യമായി വലുതായിരിക്കാം *.
            // `format_exact` ഈ കേസിൽ വളരെ നേരത്തെ തന്നെ റെൻഡറിംഗ് അക്കങ്ങൾ അവസാനിപ്പിക്കും, കാരണം ഞങ്ങൾ `maxlen` കർശനമായി പരിമിതപ്പെടുത്തിയിരിക്കുന്നു.
            //
            let limit = if frac_digits < 0x8000 { -(frac_digits as i16) } else { i16::MIN };
            let (buf, exp) = format_exact(decoded, &mut buf[..maxlen], limit);
            if exp <= limit {
                // നിയന്ത്രണം പാലിക്കാനായില്ല, അതിനാൽ ഇത് `exp` ആയിരുന്നാലും പൂജ്യം പോലെ റെൻഡർ ചെയ്യപ്പെടും.
                // അവസാന റൗണ്ടിംഗ് കഴിഞ്ഞതിനുശേഷം മാത്രമേ നിയന്ത്രണം പാലിച്ചിട്ടുള്ളൂ എന്ന കേസ് ഇതിൽ ഉൾപ്പെടുന്നില്ല;ഇത് `exp = limit + 1`-ന്റെ ഒരു സാധാരണ കേസാണ്.
                //
                debug_assert_eq!(buf.len(), 0);
                if frac_digits > 0 {
                    // [0.][0000]
                    parts[0] = MaybeUninit::new(Part::Copy(b"0."));
                    parts[1] = MaybeUninit::new(Part::Zero(frac_digits));
                    Formatted {
                        sign,
                        // സുരക്ഷ: ഞങ്ങൾ `..2` ഘടകങ്ങൾ സമാരംഭിച്ചു.
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..2]) },
                    }
                } else {
                    parts[0] = MaybeUninit::new(Part::Copy(b"0"));
                    Formatted {
                        sign,
                        // സുരക്ഷ: ഞങ്ങൾ `..1` ഘടകങ്ങൾ സമാരംഭിച്ചു.
                        parts: unsafe { MaybeUninit::slice_assume_init_ref(&parts[..1]) },
                    }
                }
            } else {
                Formatted { sign, parts: digits_to_dec_str(buf, exp, frac_digits, parts) }
            }
        }
    }
}