//! ഒരു ഫ്ലോട്ടിംഗ്-പോയിൻറ് മൂല്യം വ്യക്തിഗത ഭാഗങ്ങളിലേക്കും പിശക് ശ്രേണികളിലേക്കും ഡീകോഡ് ചെയ്യുന്നു.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// ഡീകോഡ് ചെയ്യാത്ത ഒപ്പില്ലാത്ത പരിമിത മൂല്യം,
///
/// - യഥാർത്ഥ മൂല്യം `mant * 2^exp`-ന് തുല്യമാണ്.
///
/// - `(mant - minus)*2^exp` മുതൽ `(mant + plus)* 2^exp` വരെയുള്ള ഏത് നമ്പറും യഥാർത്ഥ മൂല്യത്തിലേക്ക് തിരിയുന്നു.
/// `inclusive` `true` ആയിരിക്കുമ്പോൾ മാത്രമേ ശ്രേണി ഉൾക്കൊള്ളൂ.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// സ്കെയിൽ ചെയ്ത മാന്റിസ.
    pub mant: u64,
    /// കുറഞ്ഞ പിശക് ശ്രേണി.
    pub minus: u64,
    /// മുകളിലെ പിശക് ശ്രേണി.
    pub plus: u64,
    /// അടിസ്ഥാന 2 ലെ പങ്കിട്ട എക്‌സ്‌പോണന്റ്.
    pub exp: i16,
    /// പിശക് ശ്രേണി ഉൾക്കൊള്ളുമ്പോൾ ശരിയാണ്.
    ///
    /// ഐ‌ഇ‌ഇ‌ഇ 754 ൽ, യഥാർത്ഥ മാന്റിസ ഇരട്ടയായപ്പോൾ ഇത് ശരിയാണ്.
    pub inclusive: bool,
}

/// ഡീകോഡ് ചെയ്യാത്ത മൂല്യം.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// അനന്തത, പോസിറ്റീവ് അല്ലെങ്കിൽ നെഗറ്റീവ്.
    Infinite,
    /// പൂജ്യം, പോസിറ്റീവ് അല്ലെങ്കിൽ നെഗറ്റീവ്.
    Zero,
    /// കൂടുതൽ ഡീകോഡ് ചെയ്ത ഫീൽഡുകളുള്ള പരിമിത സംഖ്യകൾ.
    Finite(Decoded),
}

/// `ഡീകോഡ്` ചെയ്യാൻ കഴിയുന്ന ഒരു ഫ്ലോട്ടിംഗ് പോയിൻറ് തരം.
pub trait DecodableFloat: RawFloat + Copy {
    /// ഏറ്റവും കുറഞ്ഞ പോസിറ്റീവ് നോർമലൈസ്ഡ് മൂല്യം.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// തന്നിരിക്കുന്ന ഫ്ലോട്ടിംഗ് പോയിൻറ് നമ്പറിൽ നിന്ന് ഒരു ചിഹ്നവും (നെഗറ്റീവ് ആയിരിക്കുമ്പോൾ ശരി) `FullDecoded` മൂല്യവും നൽകുന്നു.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // അയൽക്കാർ: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode എല്ലായ്പ്പോഴും എക്‌സ്‌പോണന്റിനെ സംരക്ഷിക്കുന്നു, അതിനാൽ മാന്റിസ സബ്‌നോർമലുകൾക്കായി സ്കെയിൽ ചെയ്യുന്നു.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // അയൽക്കാർ: (പരമാവധി, കാലഹരണപ്പെടുന്നു, 1)-(മിനോർമന്റ്, എക്‌സ്‌പ്രസ്)-(മിനോർമന്റ് + 1, എക്‌സ്‌പ്രസ്)
                // ഇവിടെ maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // അയൽക്കാർ: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}