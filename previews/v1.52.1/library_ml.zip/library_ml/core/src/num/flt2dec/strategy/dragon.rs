//! "ഫ്ലോട്ടിംഗ്-പോയിൻറ് നമ്പറുകൾ‌വേഗത്തിലും കൃത്യമായും അച്ചടിക്കുന്നു" [^ 1] ന്റെ ചിത്രം 3 ന്റെ ഏതാണ്ട് നേരിട്ടുള്ള (പക്ഷേ ചെറുതായി ഒപ്റ്റിമൈസ് ചെയ്ത) Rust വിവർത്തനം.
//!
//!
//! [^1]: Burger, ആർ‌ജിയും ഡിബ്‌വിഗും, ആർ‌കെ 1996. ഫ്ലോട്ടിംഗ്-പോയിൻറ് നമ്പറുകൾ‌അച്ചടിക്കുന്നു
//!   വേഗത്തിലും കൃത്യമായും.SIGPLAN അല്ല.31, 5 (മെയ് 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// 10 for (2 ^ n) നായുള്ള `അക്ക'ത്തിന്റെ മുൻ‌കൂട്ടി കണക്കാക്കിയ അറേ
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// `x < 16 * scale` ആയിരിക്കുമ്പോൾ മാത്രം ഉപയോഗയോഗ്യമാണ്;`scaleN` `scale.mul_small(N)` ആയിരിക്കണം
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// ഡ്രാഗണിനുള്ള ഏറ്റവും ചെറിയ മോഡ് നടപ്പിലാക്കൽ.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // ഫോർമാറ്റുചെയ്യുന്നതിനുള്ള `v` നമ്പർ ഇനിപ്പറയുന്നതായി അറിയപ്പെടുന്നു:
    // - `mant * 2^exp` ന് തുല്യമാണ്;
    // - യഥാർത്ഥ തരത്തിൽ `(mant - 2 *minus)* 2^exp` ന് മുമ്പുള്ളത്;ഒപ്പം
    // - യഥാർത്ഥ തരത്തിൽ `(mant + 2 *plus)* 2^exp`-ന് ശേഷം.
    //
    // വ്യക്തമായും, `minus`, `plus` എന്നിവ പൂജ്യമാകരുത്.(അനന്തതകൾക്കായി, ഞങ്ങൾ പരിധിക്ക് പുറത്തുള്ള മൂല്യങ്ങൾ ഉപയോഗിക്കുന്നു.) കുറഞ്ഞത് ഒരു അക്കമെങ്കിലും ജനറേറ്റുചെയ്യുന്നുവെന്നും ഞങ്ങൾ അനുമാനിക്കുന്നു, അതായത്, `mant` പൂജ്യമാകരുത്.
    //
    // `low = (mant - minus)*2^exp` നും `high = (mant + plus)* 2^exp` നും ഇടയിലുള്ള ഏത് സംഖ്യയും ഈ കൃത്യമായ ഫ്ലോട്ടിംഗ് പോയിൻറ് നമ്പറിലേക്ക് മാപ്പ് ചെയ്യുമെന്നാണ് ഇതിനർത്ഥം, യഥാർത്ഥ മാന്റിസ ഇരട്ടയായിരിക്കുമ്പോൾ (അതായത്, `!mant_was_odd`) അതിരുകൾ ഉൾപ്പെടുത്തിയിട്ടുണ്ട്.
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` `if d.inclusive {a <= b} else {a < b}` ആണ്
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // `10^(k_0-1) < high <= 10^(k_0+1)` തൃപ്തിപ്പെടുത്തുന്ന യഥാർത്ഥ ഇൻപുട്ടുകളിൽ നിന്ന് `k_0` കണക്കാക്കുക.
    // ഇറുകിയ ബന്ധിത `k` തൃപ്തികരമായ `10^(k-1) < high <= 10^k` പിന്നീട് കണക്കാക്കുന്നു.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // `{mant, plus, minus} * 2^exp` നെ ഭിന്ന രൂപത്തിലേക്ക് പരിവർത്തനം ചെയ്യുന്നതിലൂടെ:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // `mant` നെ `10^k` കൊണ്ട് ഹരിക്കുക.ഇപ്പോൾ `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // `mant + plus > scale` (അല്ലെങ്കിൽ `>=`) ആയിരിക്കുമ്പോൾ പരിഹരിക്കുക.
    // ഞങ്ങൾ യഥാർത്ഥത്തിൽ `scale` പരിഷ്‌ക്കരിക്കുന്നില്ല, കാരണം പകരം പ്രാരംഭ ഗുണനം ഒഴിവാക്കാനാകും.
    // ഇപ്പോൾ `scale < mant + plus <= scale * 10`, അക്കങ്ങൾ സൃഷ്ടിക്കാൻ ഞങ്ങൾ തയ്യാറാണ്.
    //
    // `scale - plus < mant < scale` ആയിരിക്കുമ്പോൾ `d[0]` * പൂജ്യമാകുമെന്ന് ശ്രദ്ധിക്കുക.
    // ഈ സാഹചര്യത്തിൽ റൗണ്ടിംഗ്-അപ്പ് അവസ്ഥ (ചുവടെയുള്ള `up`) ഉടനടി പ്രവർത്തനക്ഷമമാകും.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // `scale` 10 കൊണ്ട് സ്കെയിലിംഗിന് തുല്യമാണ്
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // അക്ക ജനറേഷനായി എക്സ് 100 എക്സ് കാഷെ ചെയ്യുക.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // `d[0..n-1]` ഇതുവരെ സൃഷ്ടിച്ച അക്കങ്ങളായ മാറ്റങ്ങൾ‌:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (അങ്ങനെ `mant / scale < 10`) ഇവിടെ x00X എന്നത് `d [i] * 10 ^ (ji) + എന്നതിനുള്ള ഒരു ചുരുക്കെഴുത്താണ്.
        // + d [j-1] * 10 + d[j]`.

        // ഒരു അക്കമുണ്ടാക്കുക: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // പരിഷ്‌ക്കരിച്ച ഡ്രാഗൺ അൽഗോരിത്തിന്റെ ലളിതമായ വിവരണമാണിത്.
        // പല ഇന്റർമീഡിയറ്റ് ഡെറിവേറ്റേഷനുകളും പൂർണ്ണമായ ആർഗ്യുമെന്റുകളും സ for കര്യത്തിനായി ഒഴിവാക്കിയിരിക്കുന്നു.
        //
        // ഞങ്ങൾ `n` അപ്‌ഡേറ്റുചെയ്‌തതുപോലെ പരിഷ്‌ക്കരിച്ച മാറ്റങ്ങളോടെ ആരംഭിക്കുക:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // `low`, `high` എന്നിവയ്ക്കിടയിലുള്ള ഏറ്റവും ചെറിയ പ്രാതിനിധ്യമാണ് `d[0..n-1]` എന്ന് കരുതുക, അതായത്, `d[0..n-1]` ഇനിപ്പറയുന്ന രണ്ടും തൃപ്തിപ്പെടുത്തുന്നു, പക്ഷേ `d[0..n-2]` ഇത് ചെയ്യുന്നില്ല:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijectivity: `v` മുതൽ അക്കങ്ങൾ വരെ);ഒപ്പം
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (അവസാന അക്കം ശരിയാണ്).
        //
        // രണ്ടാമത്തെ അവസ്ഥ `2 * mant <= scale` ലേക്ക് ലളിതമാക്കുന്നു.
        // `mant`, `low`, `high` എന്നിവയുടെ അടിസ്ഥാനത്തിൽ മാറ്റങ്ങൾ‌പരിഹരിക്കുന്നത് ആദ്യ നിബന്ധനയുടെ ലളിതമായ പതിപ്പ് നൽകുന്നു: `-plus < mant < minus`.
        // `-plus < 0 <= mant` മുതൽ, `mant < minus`, `2 * mant <= scale` എന്നിവയുള്ളപ്പോൾ ഞങ്ങൾക്ക് ഏറ്റവും ഹ്രസ്വമായ പ്രാതിനിധ്യം ഉണ്ട്.
        // (യഥാർത്ഥ മാന്റിസ സമമാകുമ്പോൾ ആദ്യത്തേത് `mant <= minus` ആയി മാറുന്നു.)
        //
        // രണ്ടാമത്തേത് കൈവശം വയ്ക്കാത്തപ്പോൾ (`2 * മാന്ത്> സ്കെയിൽ`), അവസാന അക്കം വർദ്ധിപ്പിക്കേണ്ടതുണ്ട്.
        // ആ അവസ്ഥ പുന oring സ്ഥാപിക്കാൻ ഇത് മതിയാകും: അക്ക ജനറേഷൻ `0 <= v / 10^(k-n) - d[0..n-1] < 1` ഉറപ്പ് നൽകുന്നുവെന്ന് ഞങ്ങൾക്കറിയാം.
        // ഈ സാഹചര്യത്തിൽ, ആദ്യ വ്യവസ്ഥ `-plus < mant - scale < minus` ആയി മാറുന്നു.
        // ജനറേഷനുശേഷം `mant < scale` മുതൽ, ഞങ്ങൾക്ക് `scale < mant + plus` ഉണ്ട്.
        // (വീണ്ടും, യഥാർത്ഥ മാന്റിസ സമമാകുമ്പോൾ ഇത് `scale <= mant + plus` ആയി മാറുന്നു.)
        //
        // ചുരുക്കത്തിൽ:
        // - `mant < minus` (അല്ലെങ്കിൽ `<=`) ആയിരിക്കുമ്പോൾ `down` നിർത്തുക (അക്കങ്ങൾ അതേപടി നിലനിർത്തുക).
        // - `scale < mant + plus` (അല്ലെങ്കിൽ `<=`) ആയിരിക്കുമ്പോൾ `up` നിർത്തുക (അവസാന അക്കം വർദ്ധിപ്പിക്കുക).
        // - അല്ലാത്തപക്ഷം സൃഷ്ടിക്കുന്നത് തുടരുക.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // ഞങ്ങൾക്ക് ഏറ്റവും കുറഞ്ഞ പ്രാതിനിധ്യം ഉണ്ട്, റൗണ്ടിംഗിലേക്ക് പോകുക

        // മാറ്റങ്ങൾ‌പുന restore സ്ഥാപിക്കുക.
        // ഇത് അൽ‌ഗോരിതം എല്ലായ്‌പ്പോഴും അവസാനിപ്പിക്കും: `minus`, `plus` എന്നിവ എല്ലായ്പ്പോഴും വർദ്ധിക്കുന്നു, പക്ഷേ `mant` ക്ലിപ്പ് ചെയ്ത മൊഡ്യൂളോ `scale` ഉം `scale` ഉം ശരിയാക്കി.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // റ) ണ്ടിംഗ് സംഭവിക്കുന്നത് i) റൗണ്ടിംഗ്-അപ്പ് അവസ്ഥ മാത്രമേ പ്രവർത്തനക്ഷമമാക്കിയിട്ടുള്ളൂ, അല്ലെങ്കിൽ ii) രണ്ട് നിബന്ധനകളും പ്രവർത്തനക്ഷമമാക്കി, ടൈ ബ്രേക്കിംഗ് റൗണ്ടിംഗ് മുൻഗണന നൽകുന്നു.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // റൗണ്ടിംഗ് ദൈർഘ്യം മാറ്റുകയാണെങ്കിൽ, എക്‌സ്‌പോണന്റും മാറണം.
        // ഈ അവസ്ഥ തൃപ്തിപ്പെടുത്താൻ വളരെ ബുദ്ധിമുട്ടാണെന്ന് തോന്നുന്നു (ഒരുപക്ഷേ അസാധ്യമാണ്), പക്ഷേ ഞങ്ങൾ ഇവിടെ സുരക്ഷിതവും സ്ഥിരത പുലർത്തുന്നതുമാണ്.
        //
        // സുരക്ഷ: ഞങ്ങൾ ആ മെമ്മറി മുകളിൽ സമാരംഭിച്ചു.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // സുരക്ഷ: ഞങ്ങൾ ആ മെമ്മറി മുകളിൽ സമാരംഭിച്ചു.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// ഡ്രാഗണിനായി കൃത്യവും സ്ഥിരവുമായ മോഡ് നടപ്പിലാക്കൽ.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // `10^(k_0-1) < v <= 10^(k_0+1)` തൃപ്തിപ്പെടുത്തുന്ന യഥാർത്ഥ ഇൻപുട്ടുകളിൽ നിന്ന് `k_0` കണക്കാക്കുക.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // `mant` നെ `10^k` കൊണ്ട് ഹരിക്കുക.ഇപ്പോൾ `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // `mant + plus >= scale` ആയിരിക്കുമ്പോൾ പരിഹരിക്കുക, അവിടെ `plus / scale = 10^-buf.len() / 2`.
    // നിശ്ചിത വലുപ്പത്തിലുള്ള ബിഗ്നം നിലനിർത്തുന്നതിന്, ഞങ്ങൾ യഥാർത്ഥത്തിൽ `mant + floor(plus) >= scale` ഉപയോഗിക്കുന്നു.
    // ഞങ്ങൾ യഥാർത്ഥത്തിൽ `scale` പരിഷ്‌ക്കരിക്കുന്നില്ല, കാരണം പകരം പ്രാരംഭ ഗുണനം ഒഴിവാക്കാനാകും.
    // ഏറ്റവും ചെറിയ അൽ‌ഗോരിതം ഉപയോഗിച്ച്, `d[0]` പൂജ്യമാകുമെങ്കിലും ക്രമേണ അത് വൃത്താകൃതിയിലാകും.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // `scale` 10 കൊണ്ട് സ്കെയിലിംഗിന് തുല്യമാണ്
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // അവസാന അക്ക പരിമിതിയോടെയാണ് ഞങ്ങൾ പ്രവർത്തിക്കുന്നതെങ്കിൽ, ഇരട്ട റൗണ്ടിംഗ് ഒഴിവാക്കാൻ യഥാർത്ഥ റെൻഡറിംഗിന് മുമ്പ് ബഫർ ചെറുതാക്കേണ്ടതുണ്ട്.
    //
    // റൗണ്ടിംഗ് നടക്കുമ്പോൾ ഞങ്ങൾ വീണ്ടും ബഫർ വലുതാക്കേണ്ടതുണ്ട് എന്നത് ശ്രദ്ധിക്കുക!
    let mut len = if k < limit {
        // ക്ഷമിക്കണം, ഞങ്ങൾക്ക് *ഒരു* അക്കമുണ്ടാക്കാൻ പോലും കഴിയില്ല.
        // ഞങ്ങൾക്ക് 9.5 പോലുള്ള എന്തെങ്കിലും ലഭിക്കുകയും അത് 10 ആയി മാറുകയും ചെയ്യുമ്പോൾ ഇത് സാധ്യമാണ്.
        // `k == limit` സംഭവിക്കുമ്പോൾ സംഭവിക്കുന്ന ഒരു റ ing ണ്ട്-അപ്പ് കേസ് ഒഴികെ ഞങ്ങൾ ഒരു ശൂന്യ ബഫർ നൽകുന്നു, കൃത്യമായി ഒരു അക്കമുണ്ടാക്കണം.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // അക്ക ജനറേഷനായി എക്സ് 100 എക്സ് കാഷെ ചെയ്യുക.
        // (ഇത് ചെലവേറിയതാകാം, അതിനാൽ ബഫർ ശൂന്യമായിരിക്കുമ്പോൾ അവ കണക്കാക്കരുത്.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // ഇനിപ്പറയുന്ന അക്കങ്ങൾ എല്ലാം പൂജ്യങ്ങളാണ്, ഞങ്ങൾ ഇവിടെ നിർത്തുന്നു * റൗണ്ടിംഗ് നടത്താൻ ശ്രമിക്കരുത്!പകരം, ശേഷിക്കുന്ന അക്കങ്ങൾ പൂരിപ്പിക്കുക.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // സുരക്ഷ: ഞങ്ങൾ ആ മെമ്മറി മുകളിൽ സമാരംഭിച്ചു.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // ഇനിപ്പറയുന്ന അക്കങ്ങൾ‌കൃത്യമായി 5000 ആണെങ്കിൽ‌ഞങ്ങൾ‌അക്കങ്ങളുടെ മധ്യത്തിൽ‌നിർ‌ത്തിയാൽ‌റ ing ണ്ട് അപ്പ് ചെയ്യുന്നു ..., മുൻ‌അക്കങ്ങൾ‌പരിശോധിച്ച് ഇരട്ട സംഖ്യയിലേക്ക് ശ്രമിക്കുക (അതായത്, മുൻ‌അക്കങ്ങൾ‌തുല്യമാകുമ്പോൾ‌റ ing ണ്ട് ചെയ്യുന്നത് ഒഴിവാക്കുക).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // സുരക്ഷ: `buf[len-1]` സമാരംഭിച്ചു.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // റൗണ്ടിംഗ് ദൈർഘ്യം മാറ്റുകയാണെങ്കിൽ, എക്‌സ്‌പോണന്റും മാറണം.
        // എന്നാൽ ഞങ്ങളോട് ഒരു നിശ്ചിത എണ്ണം അക്കങ്ങൾ അഭ്യർത്ഥിച്ചിട്ടുണ്ട്, അതിനാൽ ബഫർ മാറ്റരുത് ...
        // സുരക്ഷ: ഞങ്ങൾ ആ മെമ്മറി മുകളിൽ സമാരംഭിച്ചു.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... പകരം കൃത്യമായ കൃത്യത ആവശ്യപ്പെട്ടിട്ടില്ലെങ്കിൽ.
            // യഥാർത്ഥ ബഫർ ശൂന്യമാണെങ്കിൽ, `k == limit` (edge കേസ്) ആയിരിക്കുമ്പോൾ മാത്രമേ അധിക അക്കം ചേർക്കാൻ കഴിയൂ എന്നും ഞങ്ങൾ പരിശോധിക്കേണ്ടതുണ്ട്.
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // സുരക്ഷ: ഞങ്ങൾ ആ മെമ്മറി മുകളിൽ സമാരംഭിച്ചു.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}