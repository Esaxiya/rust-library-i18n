use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // ഇത് സ്ഥിരതയുള്ള ഉപരിതല വിസ്തീർണ്ണമല്ല, എന്നാൽ എൽ‌എൽ‌വി‌എമ്മിന് എല്ലായ്പ്പോഴും എല്ലായ്പ്പോഴും ഇത് പ്രയോജനപ്പെടുത്താൻ കഴിയുന്നില്ലെങ്കിലും, അവയ്ക്കിടയിൽ `?` വിലകുറഞ്ഞതായി നിലനിർത്താൻ സഹായിക്കുന്നു.
    //
    // (ദു ly ഖകരമായ ഫലവും ഓപ്ഷനും പൊരുത്തമില്ലാത്തതിനാൽ കൺട്രോൾഫ്ലോയ്ക്ക് രണ്ടും പൊരുത്തപ്പെടാൻ കഴിയില്ല.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}