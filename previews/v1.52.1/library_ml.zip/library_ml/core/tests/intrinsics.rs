use core::any::TypeId;
use core::intrinsics::assume;

#[test]
fn test_typeid_sized_types() {
    struct X;
    struct Y(u32);

    assert_eq!(TypeId::of::<X>(), TypeId::of::<X>());
    assert_eq!(TypeId::of::<Y>(), TypeId::of::<Y>());
    assert!(TypeId::of::<X>() != TypeId::of::<Y>());
}

#[test]
fn test_typeid_unsized_types() {
    trait Z {}
    struct X(str);
    struct Y(dyn Z + 'static);

    assert_eq!(TypeId::of::<X>(), TypeId::of::<X>());
    assert_eq!(TypeId::of::<Y>(), TypeId::of::<Y>());
    assert!(TypeId::of::<X>() != TypeId::of::<Y>());
}

// `const_assume` സവിശേഷത `assume` അന്തർലീനമായ സന്ദർഭങ്ങളിൽ ഉപയോഗിക്കാൻ അനുവദിക്കുന്നുണ്ടോയെന്ന് പരിശോധിക്കുക.
//
#[test]
fn test_assume_can_be_in_const_contexts() {
    const unsafe fn foo(x: usize, y: usize) -> usize {
        // സുരക്ഷ: മുഴുവൻ പ്രവർത്തനവും സുരക്ഷിതമല്ല,
        // പക്ഷേ ഇത് മറ്റൊരിടത്തും ഉപയോഗിക്കാത്ത ഒരു ഉദാഹരണം മാത്രമാണ്.
        unsafe { assume(y != 0) };
        x / y
    }
    let rs = unsafe { foo(42, 97) };
    assert_eq!(rs, 0);
}