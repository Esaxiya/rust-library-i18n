use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // മിരി വളരെ മന്ദഗതിയിലാണ്
fn exact_sanity_test() {
    // ഈ പരീക്ഷണം അവസാനിക്കുന്നത് എക്സ് 00 എക്സ് ലൈബ്രറി ഫംഗ്ഷന്റെ ചില കോർണർ-ഇഷ് കേസാണ്, ഞങ്ങൾ ഉപയോഗിക്കുന്ന ഏത് സി റൺടൈമിലും നിർവചിക്കപ്പെടുന്നു.
    // വി‌എസ് 2013 ൽ, ലിങ്ക് ചെയ്യുമ്പോൾ ഈ പരിശോധന പരാജയപ്പെടുന്നതിനാൽ ഈ ഫംഗ്ഷന് ഒരു ബഗ് ഉണ്ടെന്ന് തോന്നുന്നു, പക്ഷേ വി‌എസ് 2015 ൽ ടെസ്റ്റ് ശരിയായി പ്രവർത്തിക്കുമ്പോൾ ബഗ് പരിഹരിച്ചതായി തോന്നുന്നു.
    //
    // `exp2(-1057)`-ന്റെ റിട്ടേൺ മൂല്യത്തിൽ ബഗ് ഒരു വ്യത്യാസമാണെന്ന് തോന്നുന്നു, അവിടെ VS 2013 ൽ ഇത് ബിറ്റ് പാറ്റേൺ 0x2 ഉപയോഗിച്ച് ഇരട്ട നൽകുന്നു, VS 2015 ൽ ഇത് 0x20000 നൽകുന്നു.
    //
    //
    // എന്തായാലും മറ്റെവിടെയെങ്കിലും പരീക്ഷിച്ചതിനാൽ ഇപ്പോൾ ഈ പരിശോധന പൂർണ്ണമായും MSVC-യിൽ അവഗണിക്കുക, മാത്രമല്ല ഓരോ പ്ലാറ്റ്ഫോമിന്റെയും exp2 നടപ്പിലാക്കൽ പരീക്ഷിക്കാൻ ഞങ്ങൾക്ക് വലിയ താൽപ്പര്യമില്ല.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}