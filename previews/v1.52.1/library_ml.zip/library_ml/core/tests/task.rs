use core::task::Poll;

#[test]
fn poll_const() {
    // `Poll`-ന്റെ രീതികൾ‌ഒരു കോൺ‌സ്റ്റക്റ്റ് സന്ദർഭത്തിൽ‌ഉപയോഗയോഗ്യമാണെന്ന് പരിശോധിക്കുക

    const POLL: Poll<usize> = Poll::Pending;

    const IS_READY: bool = POLL.is_ready();
    assert!(!IS_READY);

    const IS_PENDING: bool = POLL.is_pending();
    assert!(IS_PENDING);
}