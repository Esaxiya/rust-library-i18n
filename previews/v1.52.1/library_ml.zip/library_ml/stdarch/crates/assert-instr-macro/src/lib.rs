//! `#[assert_instr]` മാക്രോ നടപ്പിലാക്കൽ
//!
//! `stdarch` crate പരിശോധിക്കുമ്പോൾ ഈ മാക്രോ ഉപയോഗിക്കുന്നു, കൂടാതെ ഫംഗ്ഷനുകളിൽ അവ അടങ്ങിയിരിക്കുമെന്ന് ഞങ്ങൾ പ്രതീക്ഷിക്കുന്ന നിർദ്ദേശങ്ങൾ അടങ്ങിയിരിക്കുന്നുവെന്ന് ഉറപ്പാക്കാൻ ടെസ്റ്റ് കേസുകൾ സൃഷ്ടിക്കുന്നതിനും ഉപയോഗിക്കുന്നു.
//!
//! ഇവിടെയുള്ള നടപടിക്രമ മാക്രോ താരതമ്യേന ലളിതമാണ്, ഇത് യഥാർത്ഥ token സ്ട്രീമിലേക്ക് ഒരു `#[test]` ഫംഗ്ഷൻ കൂട്ടിച്ചേർക്കുന്നു, അത് ഫംഗ്ഷനിൽ തന്നെ പ്രസക്തമായ നിർദ്ദേശങ്ങൾ ഉൾക്കൊള്ളുന്നുവെന്ന് ഉറപ്പിക്കുന്നു.
//!
//!
//!
//!

extern crate proc_macro;
extern crate proc_macro2;
#[macro_use]
extern crate quote;
extern crate syn;

use proc_macro2::TokenStream;
use quote::ToTokens;

#[proc_macro_attribute]
pub fn assert_instr(
    attr: proc_macro::TokenStream,
    item: proc_macro::TokenStream,
) -> proc_macro::TokenStream {
    let invoc = match syn::parse::<Invoc>(attr) {
        Ok(s) => s,
        Err(e) => return e.to_compile_error().into(),
    };
    let item = match syn::parse::<syn::Item>(item) {
        Ok(s) => s,
        Err(e) => return e.to_compile_error().into(),
    };
    let func = match item {
        syn::Item::Fn(ref f) => f,
        _ => panic!("must be attached to a function"),
    };

    let instr = &invoc.instr;
    let name = &func.sig.ident;

    // എവിഎക്സ് പ്രാപ്തമാക്കിയ കംപൈൽ ചെയ്ത എക്സ് 100 എക്സ് ടാർഗെറ്റുകൾക്കായി assert_instr അപ്രാപ്തമാക്കുക, ഇത് ഞങ്ങൾ പരീക്ഷിക്കുന്ന വ്യത്യസ്ത ആന്തരികതകൾ സൃഷ്ടിക്കാൻ എൽഎൽവിഎമ്മിന് കാരണമാകുന്നു.
    //
    //
    let disable_assert_instr = std::env::var("STDARCH_DISABLE_ASSERT_INSTR").is_ok();

    // നിർദ്ദേശ പരിശോധനകൾ അപ്രാപ്തമാക്കിയിട്ടുണ്ടെങ്കിൽ, ഈ ഷിം പുറപ്പെടുവിക്കുന്നത് ഒഴിവാക്കുക, ഞങ്ങളുടെ ആട്രിബ്യൂട്ട് ഇല്ലാതെ യഥാർത്ഥ ഇനം തിരികെ നൽകുക.
    //
    if !cfg!(optimized) || disable_assert_instr {
        return (quote! { #item }).into();
    }

    let instr_str = instr
        .replace('.', "_")
        .replace('/', "_")
        .replace(':', "_")
        .replace(char::is_whitespace, "");
    let assert_name = syn::Ident::new(&format!("assert_{}_{}", name, instr_str), name.span());
    // ഈ പേര് പിന്നീട് ഡിസ്അസംബ്ലിംഗിൽ കണ്ടെത്തുന്നതിന് ഞങ്ങൾക്ക് അദ്വിതീയമായിരിക്കണം:
    let shim_name = syn::Ident::new(
        &format!("stdarch_test_shim_{}_{}", name, instr_str),
        name.span(),
    );
    let mut inputs = Vec::new();
    let mut input_vals = Vec::new();
    let ret = &func.sig.output;
    for arg in func.sig.inputs.iter() {
        let capture = match *arg {
            syn::FnArg::Typed(ref c) => c,
            ref v => panic!(
                "arguments must not have patterns: `{:?}`",
                v.clone().into_token_stream()
            ),
        };
        let ident = match *capture.pat {
            syn::Pat::Ident(ref i) => &i.ident,
            _ => panic!("must have bare arguments"),
        };
        if let Some(&(_, ref tokens)) = invoc.args.iter().find(|a| *ident == a.0) {
            input_vals.push(quote! { #tokens });
        } else {
            inputs.push(capture);
            input_vals.push(quote! { #ident });
        }
    }

    let attrs = func
        .attrs
        .iter()
        .filter(|attr| {
            attr.path
                .segments
                .first()
                .expect("attr.path.segments.first() failed")
                .ident
                .to_string()
                .starts_with("target")
        })
        .collect::<Vec<_>>();
    let attrs = Append(&attrs);

    // സ്ഥിരസ്ഥിതിയായി Unix-ൽ (ഞാൻ കരുതുന്നു?) സംഭവിക്കുന്നതുപോലെ, രജിസ്റ്ററുകളിൽ SIMD മൂല്യങ്ങൾ കൈമാറുന്ന Windows-ൽ ഒരു ABI ഉപയോഗിക്കുക.
    //
    let abi = if cfg!(windows) {
        syn::LitStr::new("vectorcall", proc_macro2::Span::call_site())
    } else {
        syn::LitStr::new("C", proc_macro2::Span::call_site())
    };
    let shim_name_str = format!("{}{}", shim_name, assert_name);
    let to_test = quote! {
        #attrs
        #[no_mangle]
        #[inline(never)]
        pub unsafe extern #abi fn #shim_name(#(#inputs),*) #ret {
            // ഒപ്റ്റിമൈസ് ചെയ്ത മോഡിലെ കംപൈലർ സ്ഥിരമായി എക്സ് 00 എക്സ് എന്ന പാസ് പ്രവർത്തിപ്പിക്കുന്നു, അവിടെ സമാനമായി കാണപ്പെടുന്ന ഫംഗ്ഷനുകൾ ലയിപ്പിക്കും.
            // ചില അന്തർലീനങ്ങൾ സമാന കോഡ് ഉൽ‌പാദിപ്പിക്കുകയും അവ പരസ്പരം മടക്കിക്കളയുകയും ചെയ്യുന്നു, അതായത് ഒന്ന് മറ്റൊന്നിലേക്ക് ചാടുന്നു.
            // ഇത് ഈ ഫംഗ്ഷന്റെ ഡിസ്അസംബ്ലിംഗിനെക്കുറിച്ചുള്ള ഞങ്ങളുടെ പരിശോധനയെ താറുമാറാക്കുന്നു, മാത്രമല്ല ഞങ്ങൾ അതിന്റെ വലിയ ആരാധകനല്ല.
            //
            // ഈ പാസ് തടയുന്നതിനും ഫംഗ്ഷനുകൾ ലയിപ്പിക്കുന്നതിൽ നിന്ന് തടയുന്നതിനും ഞങ്ങൾ കോഡെജന്റെ കാര്യത്തിൽ വളരെ ഇറുകിയതും എന്നാൽ കോഡ് മടക്കിക്കളയുന്നത് തടയുന്നതിൽ അദ്വിതീയവുമായ ചില കോഡ് സൃഷ്ടിക്കുന്നു.
            //
            //
            // Wasm32-ൽ ഇത് ഇപ്പോൾ ഒഴിവാക്കപ്പെടുന്നു, കാരണം ഈ ഫംഗ്ഷനുകൾ ഇൻലൈൻ ചെയ്തിട്ടില്ലാത്തതിനാൽ ഇത് ഞങ്ങളുടെ ടെസ്റ്റുകളെ തകർക്കുന്നു, കാരണം ഓരോ അന്തർലീനവും ഫംഗ്ഷനുകൾ എന്ന് വിളിക്കുന്നു.
            // ഏതുവിധേനയും wasm32 ലയിപ്പിക്കുന്നതിന് ഫംഗ്ഷനുകൾ സമാനമല്ല.
            // ഈ ബഗ് rust-lang/rust#74320 ൽ ട്രാക്കുചെയ്‌തു.
            //
            //
            //
            //
            //
            //
            //
            #[cfg(not(target_arch = "wasm32"))]
            ::stdarch_test::_DONT_DEDUP.store(
                std::mem::transmute(#shim_name_str.as_bytes().as_ptr()),
                std::sync::atomic::Ordering::Relaxed,
            );
            #name(#(#input_vals),*)
        }
    };

    let tokens: TokenStream = quote! {
        #[test]
        #[allow(non_snake_case)]
        fn #assert_name() {
            #to_test

            ::stdarch_test::assert(#shim_name as usize,
                                   stringify!(#shim_name),
                                   #instr);
        }
    };

    let tokens: TokenStream = quote! {
        #item
        #tokens
    };
    tokens.into()
}

struct Invoc {
    instr: String,
    args: Vec<(syn::Ident, syn::Expr)>,
}

impl syn::parse::Parse for Invoc {
    fn parse(input: syn::parse::ParseStream) -> syn::Result<Self> {
        use syn::{ext::IdentExt, Token};

        let mut instr = String::new();
        while !input.is_empty() {
            if input.parse::<Token![,]>().is_ok() {
                break;
            }
            if let Ok(ident) = syn::Ident::parse_any(input) {
                instr.push_str(&ident.to_string());
                continue;
            }
            if input.parse::<Token![.]>().is_ok() {
                instr.push('.');
                continue;
            }
            if let Ok(s) = input.parse::<syn::LitStr>() {
                instr.push_str(&s.value());
                continue;
            }
            println!("{:?}", input.cursor().token_stream());
            return Err(input.error("expected an instruction"));
        }
        if instr.is_empty() {
            return Err(input.error("expected an instruction before comma"));
        }
        let mut args = Vec::new();
        while !input.is_empty() {
            let name = input.parse::<syn::Ident>()?;
            input.parse::<Token![=]>()?;
            let expr = input.parse::<syn::Expr>()?;
            args.push((name, expr));

            if input.parse::<Token![,]>().is_err() {
                if !input.is_empty() {
                    return Err(input.error("extra tokens at end"));
                }
                break;
            }
        }
        Ok(Self { instr, args })
    }
}

struct Append<T>(T);

impl<T> quote::ToTokens for Append<T>
where
    T: Clone + IntoIterator,
    T::Item: quote::ToTokens,
{
    fn to_tokens(&self, tokens: &mut proc_macro2::TokenStream) {
        for item in self.0.clone() {
            item.to_tokens(tokens);
        }
    }
}