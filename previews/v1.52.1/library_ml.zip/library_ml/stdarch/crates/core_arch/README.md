`core::arch` - Rust-ന്റെ കോർ ലൈബ്രറി ആർക്കിടെക്ചർ-നിർദ്ദിഷ്ട ആന്തരികം
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

`core::arch` മൊഡ്യൂൾ വാസ്തുവിദ്യയെ ആശ്രയിച്ചുള്ള ആന്തരികത നടപ്പിലാക്കുന്നു (ഉദാ. SIMD).

# Usage 

`core::arch` `libcore` ന്റെ ഭാഗമായി ലഭ്യമാണ്, ഇത് `libstd` വീണ്ടും കയറ്റുമതി ചെയ്യുന്നു.ഈ crate വഴി ഉള്ളതിനേക്കാൾ `core::arch` അല്ലെങ്കിൽ `std::arch` വഴി ഇത് ഉപയോഗിക്കാൻ തിരഞ്ഞെടുക്കുക.
അസ്ഥിരമായ സവിശേഷതകൾ മിക്കപ്പോഴും രാത്രിയിൽ Rust-ൽ `feature(stdsimd)` വഴി ലഭ്യമാണ്.

ഈ crate വഴി `core::arch` ഉപയോഗിക്കുന്നതിന് രാത്രി Rust ആവശ്യമാണ്, മാത്രമല്ല ഇത് പലപ്പോഴും തകർക്കാൻ കഴിയും (കൂടാതെ ചെയ്യുന്നു).ഈ crate വഴി ഇത് ഉപയോഗിക്കുന്നത് നിങ്ങൾ പരിഗണിക്കേണ്ട ഒരേയൊരു കേസുകൾ:

* നിങ്ങൾക്ക് `core::arch` വീണ്ടും കംപൈൽ ചെയ്യണമെങ്കിൽ, ഉദാ. `libcore`/`libstd`-നായി പ്രവർത്തനക്ഷമമാക്കിയിട്ടില്ലാത്ത പ്രത്യേക ടാർഗെറ്റ് സവിശേഷതകൾ പ്രവർത്തനക്ഷമമാക്കി.
Note: നിലവാരമില്ലാത്ത ടാർഗെറ്റിനായി നിങ്ങൾ ഇത് വീണ്ടും കംപൈൽ ചെയ്യണമെങ്കിൽ, ഈ crate ഉപയോഗിക്കുന്നതിനുപകരം `xargo` ഉപയോഗിക്കുന്നതിനും `libcore`/`libstd` വീണ്ടും കംപൈൽ ചെയ്യുന്നതിനും തിരഞ്ഞെടുക്കുക.
  
* അസ്ഥിരമായ Rust സവിശേഷതകൾക്ക് പിന്നിലും ലഭ്യമല്ലാത്ത ചില സവിശേഷതകൾ ഉപയോഗിക്കുന്നു.ഇവ കുറഞ്ഞത് നിലനിർത്താൻ ഞങ്ങൾ ശ്രമിക്കുന്നു.
നിങ്ങൾ‌ക്ക് ഈ സവിശേഷതകളിൽ‌ചിലത് ഉപയോഗിക്കേണ്ടതുണ്ടെങ്കിൽ‌, ദയവായി ഒരു പ്രശ്‌നം തുറക്കുക, അതുവഴി രാത്രികാല Rust ൽ‌ഞങ്ങൾ‌ക്ക് അവ തുറന്നുകാട്ടാൻ‌കഴിയും, മാത്രമല്ല അവ അവിടെ നിന്ന് ഉപയോഗിക്കാനും കഴിയും.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` പ്രധാനമായും എം‌ഐ‌ടി ലൈസൻസിന്റെയും Apache ലൈസൻസിന്റെയും (പതിപ്പ് 2.0) നിബന്ധനകൾ‌ക്ക് വിധേയമായി വിതരണം ചെയ്യുന്നു, വിവിധ ബി‌എസ്‌ഡി പോലുള്ള ലൈസൻ‌സുകൾ‌ഉൾ‌ക്കൊള്ളുന്ന ഭാഗങ്ങൾ‌.

വിശദാംശങ്ങൾക്ക് LICENSE-APACHE, LICENSE-MIT എന്നിവ കാണുക.

# Contribution

നിങ്ങൾ വ്യക്തമായി പ്രസ്താവിക്കുന്നില്ലെങ്കിൽ, Apache-2.0 ലൈസൻസിൽ നിർവചിച്ചിരിക്കുന്നതുപോലെ, നിങ്ങൾ `core_arch`-ൽ ഉൾപ്പെടുത്തുന്നതിനായി മന intention പൂർവ്വം സമർപ്പിച്ച ഏതെങ്കിലും സംഭാവന, അധിക നിബന്ധനകളോ വ്യവസ്ഥകളോ ഇല്ലാതെ, മുകളിൽ പറഞ്ഞതുപോലെ ഇരട്ട ലൈസൻസുള്ളതായിരിക്കും.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












