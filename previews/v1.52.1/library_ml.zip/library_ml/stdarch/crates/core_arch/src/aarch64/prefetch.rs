#[cfg(test)]
use stdarch_test::assert_instr;

extern "C" {
    #[link_name = "llvm.prefetch"]
    fn prefetch(p: *const i8, rw: i32, loc: i32, ty: i32);
}

/// [`prefetch`](fn._prefetch.html) കാണുക.
pub const _PREFETCH_READ: i32 = 0;

/// [`prefetch`](fn._prefetch.html) കാണുക.
pub const _PREFETCH_WRITE: i32 = 1;

/// [`prefetch`](fn._prefetch.html) കാണുക.
pub const _PREFETCH_LOCALITY0: i32 = 0;

/// [`prefetch`](fn._prefetch.html) കാണുക.
pub const _PREFETCH_LOCALITY1: i32 = 1;

/// [`prefetch`](fn._prefetch.html) കാണുക.
pub const _PREFETCH_LOCALITY2: i32 = 2;

/// [`prefetch`](fn._prefetch.html) കാണുക.
pub const _PREFETCH_LOCALITY3: i32 = 3;

/// തന്നിരിക്കുന്ന `rw`, `locality` എന്നിവ ഉപയോഗിച്ച് `p` വിലാസം അടങ്ങിയിരിക്കുന്ന കാഷെ ലൈൻ നേടുക.
///
/// `rw` ഇനിപ്പറയുന്നതിൽ ഒന്നായിരിക്കണം:
///
/// * [`_PREFETCH_READ`](constant._PREFETCH_READ.html): പ്രീഫെച്ച് ഒരു വായനയ്ക്കായി തയ്യാറെടുക്കുന്നു.
///
/// * [`_PREFETCH_WRITE`](constant._PREFETCH_WRITE.html): പ്രീഫെച്ച് ഒരു റൈറ്റിനായി തയ്യാറെടുക്കുന്നു.
///
/// `locality` ഇനിപ്പറയുന്നതിൽ ഒന്നായിരിക്കണം:
///
/// * [`_PREFETCH_LOCALITY0`](constant._PREFETCH_LOCALITY0.html): ഒരുതവണ മാത്രം ഉപയോഗിക്കുന്ന ഡാറ്റയ്‌ക്കായി സ്‌ട്രീമിംഗ് അല്ലെങ്കിൽ താൽക്കാലികമല്ലാത്ത പ്രീഫെച്ച്.
///
/// * [`_PREFETCH_LOCALITY1`](constant._PREFETCH_LOCALITY1.html): ലെവൽ 3 കാഷെയിലേക്ക് നേടുക.
///
/// * [`_PREFETCH_LOCALITY2`](constant._PREFETCH_LOCALITY2.html): ലെവൽ 2 കാഷെയിലേക്ക് നേടുക.
///
/// * [`_PREFETCH_LOCALITY3`](constant._PREFETCH_LOCALITY3.html): ലെവൽ 1 കാഷെയിലേക്ക് നേടുക.
///
/// ഒരു നിർദ്ദിഷ്ട വിലാസത്തിൽ നിന്ന് മെമ്മറി ആക്സസ് ചെയ്യുന്ന മെമ്മറി സിസ്റ്റത്തിലേക്ക് പ്രീഫെച്ച് മെമ്മറി നിർദ്ദേശങ്ങൾ സിഗ്നൽ അടുത്തുള്ള future-ൽ സംഭവിക്കാൻ സാധ്യതയുണ്ട്.
/// ഒന്നോ അതിലധികമോ കാർഡുകളിലേക്ക് നിർദ്ദിഷ്ട വിലാസം പ്രീലോഡുചെയ്യുന്നത് പോലുള്ള മെമ്മറി ആക്‌സസ്സ് വേഗത്തിലാകുമെന്ന് പ്രതീക്ഷിക്കുന്ന നടപടികളിലൂടെ മെമ്മറി സിസ്റ്റത്തിന് പ്രതികരിക്കാൻ കഴിയും.
///
/// ഈ സിഗ്നലുകൾ‌സൂചനകൾ‌മാത്രമുള്ളതിനാൽ‌, ഏതെങ്കിലും അല്ലെങ്കിൽ‌എല്ലാ പ്രീഫെച്ച് നിർദ്ദേശങ്ങളും ഒരു എൻ‌ഒ‌പിയായി പരിഗണിക്കുന്നത് ഒരു പ്രത്യേക സിപിയുവിന് സാധുതയുള്ളതാണ്.
///
/// [Arm's documentation](https://developer.arm.com/documentation/den0024/a/the-a64-instruction-set/memory-access-instructions/prefetching-memory?lang=en)
///
///
///
///
///
///
#[inline(always)]
#[cfg_attr(test, assert_instr("prfm pldl1strm", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pldl3keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pldl2keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pldl1keep", rw = _PREFETCH_READ, locality = _PREFETCH_LOCALITY3))]
#[cfg_attr(test, assert_instr("prfm pstl1strm", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY0))]
#[cfg_attr(test, assert_instr("prfm pstl3keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY1))]
#[cfg_attr(test, assert_instr("prfm pstl2keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY2))]
#[cfg_attr(test, assert_instr("prfm pstl1keep", rw = _PREFETCH_WRITE, locality = _PREFETCH_LOCALITY3))]
#[rustc_args_required_const(1, 2)]
pub unsafe fn _prefetch(p: *const i8, rw: i32, locality: i32) {
    // `cache type` =1 (ഡാറ്റ കാഷെ) ഉള്ള `llvm.prefetch` ഇൻസ്ട്രിൻസിക് ഞങ്ങൾ ഉപയോഗിക്കുന്നു.
    // `rw` ഒപ്പം `strategy` ഉം ഫംഗ്ഷൻ പാരാമീറ്ററുകൾ അടിസ്ഥാനമാക്കിയുള്ളതാണ്.
    macro_rules! pref {
        ($rdwr:expr, $local:expr) => {
            match ($rdwr, $local) {
                (0, 0) => prefetch(p, 0, 0, 1),
                (0, 1) => prefetch(p, 0, 1, 1),
                (0, 2) => prefetch(p, 0, 2, 1),
                (0, 3) => prefetch(p, 0, 3, 1),
                (1, 0) => prefetch(p, 1, 0, 1),
                (1, 1) => prefetch(p, 1, 1, 1),
                (1, 2) => prefetch(p, 1, 2, 1),
                (1, 3) => prefetch(p, 1, 3, 1),
                (_, _) => panic!(
                    "Illegal (rw, locality) pair in prefetch, value ({}, {}).",
                    $rdwr, $local
                ),
            }
        };
    }
    pref!(rw, locality);
}