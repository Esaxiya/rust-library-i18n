use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // ഞങ്ങളുടെ `#[assert_instr]` വ്യാഖ്യാനങ്ങളോട് പറയാൻ ഉപയോഗിക്കുന്നു, എല്ലാ സിം‌ഡ് ആന്തരികങ്ങളും അവയുടെ കോഡ്‌ജെൻ‌പരിശോധിക്കുന്നതിന് ലഭ്യമാണ്, കാരണം ചിലത് ഇപ്പോൾ‌`#[target_feature]` ൽ‌തുല്യതയില്ലാത്ത ഒരു അധിക `-Ctarget-feature=+unimplemented-simd128` ന് പിന്നിൽ‌സ്ഥിതിചെയ്യുന്നു.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}