// rsbegin.o rsend.o എന്നിവയാണ് "compiler runtime startup objects" എന്ന് വിളിക്കപ്പെടുന്നത്.
// കംപൈലർ റൺടൈം ശരിയായി സമാരംഭിക്കുന്നതിന് ആവശ്യമായ കോഡ് അവയിൽ അടങ്ങിയിരിക്കുന്നു.
//
// ഒരു എക്സിക്യൂട്ടബിൾ അല്ലെങ്കിൽ ഡൈലിബ് ഇമേജ് ലിങ്കുചെയ്യുമ്പോൾ, എല്ലാ ഉപയോക്തൃ കോഡും ലൈബ്രറികളും ഈ രണ്ട് ഒബ്ജക്റ്റ് ഫയലുകൾക്കിടയിൽ "sandwiched" ആണ്, അതിനാൽ rsbegin.o-ൽ നിന്നുള്ള കോഡോ ഡാറ്റയോ ചിത്രത്തിന്റെ ബന്ധപ്പെട്ട വിഭാഗങ്ങളിൽ ഒന്നാമതായിത്തീരുന്നു, അതേസമയം rsend.o-ൽ നിന്നുള്ള കോഡും ഡാറ്റയും അവസാനത്തേതായി മാറുന്നു.
// ഒരു വിഭാഗത്തിന്റെ തുടക്കത്തിലോ അവസാനത്തിലോ ചിഹ്നങ്ങൾ സ്ഥാപിക്കുന്നതിനും ആവശ്യമായ തലക്കെട്ടുകൾ അല്ലെങ്കിൽ അടിക്കുറിപ്പുകൾ ഉൾപ്പെടുത്തുന്നതിനും ഈ പ്രഭാവം ഉപയോഗിക്കാം.
//
// യഥാർത്ഥ റൺടൈം സ്റ്റാർട്ടപ്പ് ഒബ്‌ജക്റ്റിലാണ് (സാധാരണയായി `crtX.o` എന്ന് വിളിക്കുന്നത്) യഥാർത്ഥ മൊഡ്യൂൾ എൻട്രി പോയിന്റ് സ്ഥിതിചെയ്യുന്നത്, തുടർന്ന് മറ്റ് റൺടൈം ഘടകങ്ങളുടെ ഓർഗനൈസേഷൻ കോൾബാക്ക് അഭ്യർത്ഥിക്കുന്നു (മറ്റൊരു പ്രത്യേക ഇമേജ് വിഭാഗം വഴി രജിസ്റ്റർ ചെയ്തു).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // സ്റ്റാക്ക് ഫ്രെയിമിന്റെ ആരംഭം അടയാളപ്പെടുത്തൽ വിവര വിഭാഗം
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // അൺ‌വൈൻഡറിന്റെ ആന്തരിക പുസ്‌തക സൂക്ഷിക്കലിനായി സ്‌ക്രാച്ച് സ്ഥലം.
    // 00 GCC/unsind-dw2-fde.h-ൽ ഇത് `struct object` ആയി നിർവചിച്ചിരിക്കുന്നു.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // വിവരം മാറ്റുക registration/deregistration ദിനചര്യകൾ.
    // Libpanic_unwind-ന്റെ പ്രമാണങ്ങൾ കാണുക.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // മൊഡ്യൂൾ സ്റ്റാർട്ടപ്പിൽ വിവരങ്ങൾ ഒഴിവാക്കുക
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // ഷട്ട്ഡ on ണിൽ രജിസ്റ്റർ ചെയ്യരുത്
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-നിർദ്ദിഷ്ട init/uninit പതിവ് രജിസ്ട്രേഷൻ
    pub mod mingw_init {
        // MinGW-ന്റെ സ്റ്റാർട്ടപ്പ് ഒബ്‌ജക്റ്റുകൾ (crt0.o/dllcrt0.o) സ്റ്റാർട്ടപ്പിലും പുറത്തുകടക്കുമ്പോഴും .ctors, .dtors വിഭാഗങ്ങളിലെ ആഗോള നിർമ്മാതാക്കളെ ക്ഷണിക്കും.
        // ഡി‌എൽ‌എല്ലുകളുടെ കാര്യത്തിൽ, ഡി‌എൽ‌എൽ ലോഡുചെയ്‌ത് അൺ‌ലോഡുചെയ്യുമ്പോഴാണ് ഇത് ചെയ്യുന്നത്.
        //
        // ലിങ്കർ വിഭാഗങ്ങളെ അടുക്കും, അത് ഞങ്ങളുടെ കോൾബാക്കുകൾ ലിസ്റ്റിന്റെ അവസാനത്തിൽ സ്ഥിതിചെയ്യുന്നുവെന്ന് ഉറപ്പാക്കുന്നു.
        // കൺ‌സ്‌ട്രക്റ്റർ‌മാർ‌വിപരീത ക്രമത്തിൽ‌പ്രവർ‌ത്തിക്കുന്നതിനാൽ‌, നടപ്പിലാക്കിയ ആദ്യത്തേതും അവസാനത്തേതും ഞങ്ങളുടെ കോൾ‌ബാക്കുകളാണെന്ന് ഇത് ഉറപ്പാക്കുന്നു.
        //
        //

        #[link_section = ".ctors.65535"] // .ക്ടറുകൾ. *: സി സമാരംഭിക്കൽ കോൾബാക്ക്
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: സി അവസാനിപ്പിക്കൽ കോൾബാക്ക്
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}