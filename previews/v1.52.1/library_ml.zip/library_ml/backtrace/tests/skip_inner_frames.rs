use backtrace::Backtrace;

// ഒരു ചിഹ്നത്തിന്റെ ആരംഭ വിലാസം റിപ്പോർട്ടുചെയ്യുന്ന ഫ്രെയിമുകൾക്കായി പ്രവർത്തിക്കുന്ന `symbol_address` ഫംഗ്ഷൻ ഉള്ള പ്ലാറ്റ്ഫോമുകളിൽ മാത്രമേ ഈ പരിശോധന പ്രവർത്തിക്കൂ.
// ഫലമായി ഇത് കുറച്ച് പ്ലാറ്റ്ഫോമുകളിൽ മാത്രമേ പ്രവർത്തനക്ഷമമാകൂ.
//
const ENABLED: bool = cfg!(all(
    // Windows ശരിക്കും പരീക്ഷിച്ചിട്ടില്ല, യഥാർത്ഥത്തിൽ ഒരു എൻ‌ക്ലോസിംഗ് ഫ്രെയിം കണ്ടെത്തുന്നതിനെ OSX പിന്തുണയ്‌ക്കുന്നില്ല, അതിനാൽ ഇത് അപ്രാപ്‌തമാക്കുക
    //
    target_os = "linux",
    // ARM ൽ എൻ‌ക്ലോസിംഗ് ഫംഗ്ഷൻ കണ്ടെത്തുന്നത് ഐപി തന്നെ നൽകുന്നു.
    not(target_arch = "arm"),
));

#[test]
fn backtrace_new_unresolved_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let mut b = Backtrace::new_unresolved();
    b.resolve();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_unresolved_should_start_with_call_site_trace as usize;
    println!("this_ip: {:?}", this_ip as *const usize);
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}

#[test]
fn backtrace_new_should_start_with_call_site_trace() {
    if !ENABLED {
        return;
    }
    let b = Backtrace::new();
    println!("{:?}", b);

    assert!(!b.frames().is_empty());

    let this_ip = backtrace_new_should_start_with_call_site_trace as usize;
    let frame_ip = b.frames().first().unwrap().symbol_address() as usize;
    assert_eq!(this_ip, frame_ip);
}