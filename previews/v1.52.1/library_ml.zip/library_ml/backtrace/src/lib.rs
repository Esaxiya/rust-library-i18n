//! റൺടൈമിൽ ഒരു ബാക്ക്‌ട്രേസ് നേടുന്നതിനുള്ള ഒരു ലൈബ്രറി
//!
//! പ്രോഗ്രമാറ്റിക്കായി റൺടൈമിൽ ഒരു ബാക്ക്‌ട്രേസ് സ്വന്തമാക്കാൻ അനുവദിച്ചുകൊണ്ട് സ്റ്റാൻഡേർഡ് ലൈബ്രറിയുടെ `RUST_BACKTRACE=1` പിന്തുണയ്‌ക്ക് അനുബന്ധമായാണ് ഈ ലൈബ്രറി ഉദ്ദേശിക്കുന്നത്.
//! ഈ ലൈബ്രറി സൃഷ്ടിച്ച ബാക്ക്‌ട്രെയ്‌സുകൾ പാഴ്‌സുചെയ്യേണ്ടതില്ല, ഉദാഹരണത്തിന്, ഒന്നിലധികം ബാക്കെൻഡ് നടപ്പാക്കലുകളുടെ പ്രവർത്തനം തുറന്നുകാട്ടുക.
//!
//! # Usage
//!
//! ആദ്യം, ഇത് നിങ്ങളുടെ Cargo.toml-ലേക്ക് ചേർക്കുക
//!
//! ```toml
//! [dependencies]
//! backtrace = "0.3"
//! ```
//!
//! Next:
//!
//! ```
//! fn main() {
//! # // ഇവിടെ സുരക്ഷിതമല്ലാത്തതിനാൽ no_std-ൽ ടെസ്റ്റ് പാസുകൾ.
//! # #[cfg(feature = "std")] {
//!     backtrace::trace(|frame| {
//!         let ip = frame.ip();
//!         let symbol_address = frame.symbol_address();
//!
//!         // ഒരു ചിഹ്ന നാമത്തിലേക്ക് ഈ നിർദ്ദേശ പോയിന്റർ പരിഹരിക്കുക
//!         backtrace::resolve_frame(frame, |symbol| {
//!             if let Some(name) = symbol.name() {
//!                 // ...
//!             }
//!             if let Some(filename) = symbol.filename() {
//!                 // ...
//!             }
//!         });
//!
//!         true // അടുത്ത ഫ്രെയിമിലേക്ക് പോകുന്നത് തുടരുക
//!     });
//! }
//! # }
//! ```
//!
//!
//!

#![doc(html_root_url = "https://docs.rs/backtrace")]
#![deny(missing_docs)]
#![no_std]
#![cfg_attr(
    all(feature = "std", target_env = "sgx", target_vendor = "fortanix"),
    feature(sgx_platform)
)]
#![warn(rust_2018_idioms)]
// ഞങ്ങൾ libstd-ന്റെ ഭാഗമായി നിർമ്മിക്കുമ്പോൾ, ഈ crate വൃക്ഷത്തിന് പുറത്ത് വികസിപ്പിച്ചതിനാൽ എല്ലാ മുന്നറിയിപ്പുകളും അപ്രസക്തമായതിനാൽ അവ നിശബ്ദമാക്കുക.
//
#![cfg_attr(backtrace_in_libstd, allow(warnings))]
#![cfg_attr(not(feature = "std"), allow(dead_code))]

#[cfg(feature = "std")]
#[macro_use]
extern crate std;

// ഇത് ഇപ്പോൾ ജിംലിക്ക് മാത്രമാണ് ഉപയോഗിക്കുന്നത്, ഇത് ചില പ്ലാറ്റ്ഫോമുകളിൽ മാത്രം ഉപയോഗിക്കുന്നു, അതിനാൽ ഇത് മറ്റ് കോൺഫിഗറേഷനുകളിൽ ഉപയോഗിക്കാത്തതിൽ വിഷമിക്കേണ്ട.
//
#[allow(unused_extern_crates)]
extern crate alloc;

pub use self::backtrace::{trace_unsynchronized, Frame};
mod backtrace;

pub use self::symbolize::resolve_frame_unsynchronized;
pub use self::symbolize::{resolve_unsynchronized, Symbol, SymbolName};
mod symbolize;

pub use self::types::BytesOrWideString;
mod types;

#[cfg(feature = "std")]
pub use self::symbolize::clear_symbol_cache;

mod print;
pub use print::{BacktraceFmt, BacktraceFrameFmt, PrintFmt};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        pub use self::backtrace::trace;
        pub use self::symbolize::{resolve, resolve_frame};
        pub use self::capture::{Backtrace, BacktraceFrame, BacktraceSymbol};
        mod capture;
    }
}

#[allow(dead_code)]
struct Bomb {
    enabled: bool,
}

#[allow(dead_code)]
impl Drop for Bomb {
    fn drop(&mut self) {
        if self.enabled {
            panic!("cannot panic during the backtrace function");
        }
    }
}

#[allow(dead_code)]
#[cfg(feature = "std")]
mod lock {
    use std::boxed::Box;
    use std::cell::Cell;
    use std::sync::{Mutex, MutexGuard, Once};

    pub struct LockGuard(Option<MutexGuard<'static, ()>>);

    static mut LOCK: *mut Mutex<()> = 0 as *mut _;
    static INIT: Once = Once::new();
    thread_local!(static LOCK_HELD: Cell<bool> = Cell::new(false));

    impl Drop for LockGuard {
        fn drop(&mut self) {
            if self.0.is_some() {
                LOCK_HELD.with(|slot| {
                    assert!(slot.get());
                    slot.set(false);
                });
            }
        }
    }

    pub fn lock() -> LockGuard {
        if LOCK_HELD.with(|l| l.get()) {
            return LockGuard(None);
        }
        LOCK_HELD.with(|s| s.set(true));
        unsafe {
            INIT.call_once(|| {
                LOCK = Box::into_raw(Box::new(Mutex::new(())));
            });
            LockGuard(Some((*LOCK).lock().unwrap()))
        }
    }
}

#[cfg(all(windows, not(target_vendor = "uwp")))]
mod dbghelp;
#[cfg(windows)]
mod windows;