//! libunwind/gcc_s/etc API-കൾ ഉപയോഗിച്ച് ബാക്ക്‌ട്രേസ് പിന്തുണ.
//!
//! ലിബൺ‌വിൻഡ്-സ്റ്റൈൽ API-കൾ ഉപയോഗിച്ച് സ്റ്റാക്ക് അൺ‌വൈൻഡ് ചെയ്യാനുള്ള കഴിവ് ഈ മൊഡ്യൂളിൽ അടങ്ങിയിരിക്കുന്നു.
//! ലിബൺ‌വിൻഡ് പോലുള്ള എ‌പി‌ഐയുടെ ഒരു കൂട്ടം നടപ്പാക്കലുകൾ‌ഉണ്ടെന്ന കാര്യം ശ്രദ്ധിക്കുക, ഇത് തിരഞ്ഞെടുക്കപ്പെടുന്നതിന് പകരം അവയെല്ലാം ഒരേസമയം പൊരുത്തപ്പെടാൻ ശ്രമിക്കുകയാണ്.
//!
//!
//! ലിബൺ‌വിൻഡ് എ‌പി‌ഐ എക്സ് 100 എക്സ് ആണ് നൽകുന്നത്, ഇത് പ്രായോഗികമായി ഒരു ബാക്ക്‌ട്രേസ് സൃഷ്ടിക്കുന്നതിൽ വളരെ വിശ്വസനീയമാണ്.
//! ഇത് എങ്ങനെ ചെയ്യുമെന്ന് പൂർണ്ണമായും വ്യക്തമല്ല (ഫ്രെയിം പോയിന്ററുകൾ? Eh_frame വിവരം? രണ്ടും?) പക്ഷേ ഇത് പ്രവർത്തിക്കുന്നതായി തോന്നുന്നു!
//!
//! ഈ മൊഡ്യൂളിന്റെ സങ്കീർണ്ണതകളിൽ ഭൂരിഭാഗവും ലിബൺ വിൻഡ് നടപ്പാക്കലുകളിലുടനീളം വിവിധ പ്ലാറ്റ്ഫോം വ്യത്യാസങ്ങൾ കൈകാര്യം ചെയ്യുന്നു.
//! അല്ലെങ്കിൽ ഇത് ലിബൺ‌വിൻഡ് എ‌പി‌ഐകളുമായി ബന്ധിപ്പിക്കുന്ന വളരെ നേരായ Rust ആണ്.
//!
//! നിലവിൽ വിൻഡോസ് ഇതര പ്ലാറ്റ്ഫോമുകൾക്കായുള്ള സ്ഥിരസ്ഥിതി അൺവൈഡിംഗ് API ഇതാണ്.
//!
//!
//!

use super::super::Bomb;
use core::ffi::c_void;

pub enum Frame {
    Raw(*mut uw::_Unwind_Context),
    Cloned {
        ip: *mut c_void,
        sp: *mut c_void,
        symbol_address: *mut c_void,
    },
}

// ഒരു അസംസ്കൃത ലിബൺ‌വിൻഡ് പോയിന്റർ ഉപയോഗിച്ച് ഇത് എപ്പോഴെങ്കിലും വായിക്കാൻ മാത്രമുള്ള ത്രെഡ്‌സെഫ് ഫാഷനിൽ മാത്രമേ ആക്‌സസ് ചെയ്യാവൂ, അതിനാൽ ഇത് `Sync` ആണ്.
// `Clone` വഴി മറ്റ് ത്രെഡുകളിലേക്ക് അയയ്ക്കുമ്പോൾ ഞങ്ങൾ എല്ലായ്പ്പോഴും ഇന്റീരിയർ പോയിന്ററുകൾ നിലനിർത്താത്ത ഒരു പതിപ്പിലേക്ക് മാറുന്നു, അതിനാൽ ഞങ്ങളും `Send` ആയിരിക്കണം.
//
//
unsafe impl Send for Frame {}
unsafe impl Sync for Frame {}

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        let ctx = match *self {
            Frame::Raw(ctx) => ctx,
            Frame::Cloned { ip, .. } => return ip,
        };
        unsafe { uw::_Unwind_GetIP(ctx) as *mut c_void }
    }

    pub fn sp(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ctx) => unsafe { uw::get_sp(ctx) as *mut c_void },
            Frame::Cloned { sp, .. } => sp,
        }
    }

    pub fn symbol_address(&self) -> *mut c_void {
        if let Frame::Cloned { symbol_address, .. } = *self {
            return symbol_address;
        }

        // OSX `_Unwind_FindEnclosingFunction`-ൽ ഒരു പോയിന്റർ നൽകുന്നുവെന്ന് തോന്നുന്നു ... അവ്യക്തമായ ഒന്ന്.
        // ഇത് എല്ലായ്പ്പോഴും ഒരു കാരണവശാലും ഉൾക്കൊള്ളുന്ന പ്രവർത്തനമല്ല.
        // ഇവിടെ എന്താണ് സംഭവിക്കുന്നതെന്ന് എനിക്ക് പൂർണ്ണമായും വ്യക്തമല്ല, അതിനാൽ ഇപ്പോൾ ഇത് അശുഭാപ്തിവൽക്കരിക്കുക, എല്ലായ്പ്പോഴും ഐപി നൽകുക.
        //
        // ഈ ഉപവാക്യം കാരണം ഒ‌എസ്‌എക്‌സിൽ എക്സ് 100 എക്സ് ടെസ്റ്റ് ഒഴിവാക്കി, ഇത് ശരിയാണെങ്കിൽ സിദ്ധാന്തത്തിലെ ടെസ്റ്റ് ഒ‌എസ്‌എക്‌സിൽ പ്രവർത്തിപ്പിക്കാൻ കഴിയും!
        //
        //
        //
        if cfg!(target_os = "macos") || cfg!(target_os = "ios") {
            self.ip()
        } else {
            unsafe { uw::_Unwind_FindEnclosingFunction(self.ip()) }
        }
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        None
    }
}

impl Clone for Frame {
    fn clone(&self) -> Frame {
        Frame::Cloned {
            ip: self.ip(),
            sp: self.sp(),
            symbol_address: self.symbol_address(),
        }
    }
}

#[inline(always)]
pub unsafe fn trace(mut cb: &mut dyn FnMut(&super::Frame) -> bool) {
    uw::_Unwind_Backtrace(trace_fn, &mut cb as *mut _ as *mut _);

    extern "C" fn trace_fn(
        ctx: *mut uw::_Unwind_Context,
        arg: *mut c_void,
    ) -> uw::_Unwind_Reason_Code {
        let cb = unsafe { &mut *(arg as *mut &mut dyn FnMut(&super::Frame) -> bool) };
        let cx = super::Frame {
            inner: Frame::Raw(ctx),
        };

        let mut bomb = Bomb { enabled: true };
        let keep_going = cb(&cx);
        bomb.enabled = false;

        if keep_going {
            uw::_URC_NO_REASON
        } else {
            uw::_URC_FAILURE
        }
    }
}

/// ബാക്ക്‌ട്രെയ്‌സുകൾക്കായി ഉപയോഗിക്കുന്ന ലൈബ്രറി ഇന്റർഫേസ് അൺവൈൻഡ് ചെയ്യുക
///
/// ഐ‌ഒ‌എസ് അവയെല്ലാം ഉപയോഗിക്കാത്തതിനാൽ ഡെഡ് കോഡ് അനുവദനീയമാണെന്നത് ശ്രദ്ധിക്കുക, പക്ഷേ കൂടുതൽ പ്ലാറ്റ്ഫോം-നിർദ്ദിഷ്ട കോൺഫിഗുകൾ ചേർക്കുന്നത് കോഡിനെ വളരെയധികം മലിനമാക്കുന്നു
///
///
#[allow(non_camel_case_types)]
#[allow(non_snake_case)]
#[allow(dead_code)]
mod uw {
    pub use self::_Unwind_Reason_Code::*;

    use core::ffi::c_void;

    #[repr(C)]
    pub enum _Unwind_Reason_Code {
        _URC_NO_REASON = 0,
        _URC_FOREIGN_EXCEPTION_CAUGHT = 1,
        _URC_FATAL_PHASE2_ERROR = 2,
        _URC_FATAL_PHASE1_ERROR = 3,
        _URC_NORMAL_STOP = 4,
        _URC_END_OF_STACK = 5,
        _URC_HANDLER_FOUND = 6,
        _URC_INSTALL_CONTEXT = 7,
        _URC_CONTINUE_UNWIND = 8,
        _URC_FAILURE = 9, // ARM EABI മാത്രം ഉപയോഗിക്കുന്നു
    }

    pub enum _Unwind_Context {}

    pub type _Unwind_Trace_Fn =
        extern "C" fn(ctx: *mut _Unwind_Context, arg: *mut c_void) -> _Unwind_Reason_Code;

    extern "C" {
        // IOS-ൽ നേറ്റീവ് _Unwind_Backtrace ഇല്ല
        #[cfg(not(all(target_os = "ios", target_arch = "arm")))]
        pub fn _Unwind_Backtrace(
            trace: _Unwind_Trace_Fn,
            trace_argument: *mut c_void,
        ) -> _Unwind_Reason_Code;

        // GCC 4.2.0 മുതൽ ലഭ്യമാണ്, ഞങ്ങളുടെ ആവശ്യത്തിനായി മികച്ചതായിരിക്കണം
        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "s390x"))
        ))]
        // ഈ ഫംഗ്ഷൻ ഒരു തെറ്റായ നാമമാണ്: ഈ ഫ്രെയിമിന്റെ കാനോനിക്കൽ ഫ്രെയിം വിലാസം (കോളർ ഫ്രെയിമിന്റെ എസ്പി) ലഭിക്കുന്നതിന് പകരം ഇത് ഈ ഫ്രെയിമിന്റെ എസ്പി നൽകുന്നു.
        //
        //
        // https://github.com/libunwind/libunwind/blob/d32956507cf29d9b1a98a8bce53c78623908f4fe/src/unwind/GetCFA.c#L28-L35
        //
        #[link_name = "_Unwind_GetCFA"]
        pub fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t;
    }

    // s390x ഒരു പക്ഷപാതപരമായ CFA മൂല്യം ഉപയോഗിക്കുന്നു, അതിനാൽ _Unwind_GetCFA-നെ ആശ്രയിക്കുന്നതിനുപകരം സ്റ്റാക്ക് പോയിന്റർ രജിസ്റ്റർ (%r15) ലഭിക്കുന്നതിന് ഞങ്ങൾ _Unwind_GetGR ഉപയോഗിക്കേണ്ടതുണ്ട്.
    //
    //
    #[cfg(all(target_os = "linux", target_arch = "s390x"))]
    pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
        extern "C" {
            pub fn _Unwind_GetGR(ctx: *mut _Unwind_Context, index: libc::c_int) -> libc::uintptr_t;
        }
        _Unwind_GetGR(ctx, 15)
    }

    // android, ഭുജം എന്നിവയിൽ, `_Unwind_GetIP` ഫംഗ്ഷനും മറ്റുള്ളവരുടെ ഒരു കൂട്ടവും മാക്രോകളാണ്, അതിനാൽ മാക്രോകളുടെ വിപുലീകരണം അടങ്ങിയ ഫംഗ്ഷനുകൾ ഞങ്ങൾ നിർവചിക്കുന്നു.
    //
    //
    // TODO: നിങ്ങൾക്ക് കണ്ടെത്താൻ കഴിയുമെങ്കിൽ ഈ മാക്രോകളെ നിർവചിക്കുന്ന തലക്കെട്ട് ഫയലിലേക്കുള്ള ലിങ്ക്.
    // (ഈ മാക്രോ വിപുലീകരണങ്ങളിൽ ചിലത് ആദ്യം കടമെടുത്ത തലക്കെട്ട് ഫയൽ എനിക്ക്, ഫിറ്റ്സ്ജെന് കണ്ടെത്താൻ കഴിയില്ല.)
    //
    //
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    pub use self::arm::*;
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    mod arm {
        pub use super::*;
        #[repr(C)]
        enum _Unwind_VRS_Result {
            _UVRSR_OK = 0,
            _UVRSR_NOT_IMPLEMENTED = 1,
            _UVRSR_FAILED = 2,
        }
        #[repr(C)]
        enum _Unwind_VRS_RegClass {
            _UVRSC_CORE = 0,
            _UVRSC_VFP = 1,
            _UVRSC_FPA = 2,
            _UVRSC_WMMXD = 3,
            _UVRSC_WMMXC = 4,
        }
        #[repr(C)]
        enum _Unwind_VRS_DataRepresentation {
            _UVRSD_UINT32 = 0,
            _UVRSD_VFPX = 1,
            _UVRSD_FPAX = 2,
            _UVRSD_UINT64 = 3,
            _UVRSD_FLOAT = 4,
            _UVRSD_DOUBLE = 5,
        }

        type _Unwind_Word = libc::c_uint;
        extern "C" {
            fn _Unwind_VRS_Get(
                ctx: *mut _Unwind_Context,
                klass: _Unwind_VRS_RegClass,
                word: _Unwind_Word,
                repr: _Unwind_VRS_DataRepresentation,
                data: *mut c_void,
            ) -> _Unwind_VRS_Result;
        }

        pub unsafe fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                15,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            (val & !1) as libc::uintptr_t
        }

        // R13 കൈയിലുള്ള സ്റ്റാക്ക് പോയിന്റർ.
        const SP: _Unwind_Word = 13;

        pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                SP,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            val as libc::uintptr_t
        }

        // ഈ ഫംഗ്ഷൻ Android അല്ലെങ്കിൽ ARM/Linux ലും നിലവിലില്ല, അതിനാൽ ഇത് ഒരു നോ-ഒപ്പ് ആക്കുക.
        //
        pub unsafe fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void {
            pc
        }
    }
}