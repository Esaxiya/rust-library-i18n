//! MSVC പ്ലാറ്റ്ഫോമുകൾക്കായുള്ള ബാക്ക്‌ട്രേസ് തന്ത്രം.
//!
//! സാധ്യമായ രണ്ട് രീതികളിൽ ഒന്ന് ഉപയോഗിച്ച് MSVC-യിൽ ഒരു ബാക്ക്‌ട്രേസ് സൃഷ്ടിക്കാനുള്ള കഴിവ് ഈ മൊഡ്യൂളിൽ അടങ്ങിയിരിക്കുന്നു.
//! സാധ്യമെങ്കിൽ `StackWalkEx` ഫംഗ്ഷൻ പ്രാഥമികമായി ഉപയോഗിക്കുന്നു, പക്ഷേ എല്ലാ സിസ്റ്റങ്ങൾക്കും അത് ഇല്ല.
//! പകരം `StackWalk64` ഫംഗ്ഷൻ ഉപയോഗിക്കുന്നതിൽ പരാജയപ്പെടുന്നു.
//! ഡീബഗ്ഗിൻ‌ഫോ ആന്തരികമായി കൈകാര്യം ചെയ്യുകയും ഇൻ‌ലൈൻ ഫ്രെയിം വിവരങ്ങൾ നൽകുകയും ചെയ്യുന്നതിനാൽ `StackWalkEx` പ്രിയങ്കരമാണെന്ന് ശ്രദ്ധിക്കുക.
//!
//!
//! എല്ലാ dbghelp പിന്തുണയും ചലനാത്മകമായി ലോഡുചെയ്തിട്ടുണ്ടെന്നത് ശ്രദ്ധിക്കുക, അതിനെക്കുറിച്ചുള്ള കൂടുതൽ വിവരങ്ങൾക്ക് `src/dbghelp.rs` കാണുക.
//!

#![allow(bad_style)]

use super::super::{dbghelp, windows::*};
use core::ffi::c_void;
use core::mem;

#[derive(Clone, Copy)]
pub enum StackFrame {
    New(STACKFRAME_EX),
    Old(STACKFRAME64),
}

#[derive(Clone, Copy)]
pub struct Frame {
    pub(crate) stack_frame: StackFrame,
    base_address: *mut c_void,
}

// ഞങ്ങൾ അസംസ്കൃത പോയിൻററുകൾ‌അയയ്‌ക്കുകയും അവ വായിക്കുകയും ചെയ്യുന്നു, അവ ഒരിക്കലും വ്യാഖ്യാനിക്കുന്നില്ല, അതിനാൽ‌ഇത് ത്രെഡുകളിലുടനീളം അയയ്‌ക്കുന്നതിനും പങ്കിടുന്നതിനും സുരക്ഷിതമായിരിക്കണം.
//
unsafe impl Send for Frame {}
unsafe impl Sync for Frame {}

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        self.addr_pc().Offset as *mut _
    }

    pub fn sp(&self) -> *mut c_void {
        self.addr_stack().Offset as *mut _
    }

    pub fn symbol_address(&self) -> *mut c_void {
        self.ip()
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        Some(self.base_address)
    }

    fn addr_pc(&self) -> &ADDRESS64 {
        match self.stack_frame {
            StackFrame::New(ref new) => &new.AddrPC,
            StackFrame::Old(ref old) => &old.AddrPC,
        }
    }

    fn addr_pc_mut(&mut self) -> &mut ADDRESS64 {
        match self.stack_frame {
            StackFrame::New(ref mut new) => &mut new.AddrPC,
            StackFrame::Old(ref mut old) => &mut old.AddrPC,
        }
    }

    fn addr_frame_mut(&mut self) -> &mut ADDRESS64 {
        match self.stack_frame {
            StackFrame::New(ref mut new) => &mut new.AddrFrame,
            StackFrame::Old(ref mut old) => &mut old.AddrFrame,
        }
    }

    fn addr_stack(&self) -> &ADDRESS64 {
        match self.stack_frame {
            StackFrame::New(ref new) => &new.AddrStack,
            StackFrame::Old(ref old) => &old.AddrStack,
        }
    }

    fn addr_stack_mut(&mut self) -> &mut ADDRESS64 {
        match self.stack_frame {
            StackFrame::New(ref mut new) => &mut new.AddrStack,
            StackFrame::Old(ref mut old) => &mut old.AddrStack,
        }
    }
}

#[repr(C, align(16))] // `CONTEXT`-ന് ആവശ്യമാണ്, ഇപ്പോൾ വിനാപിയിലെ ഒരു FIXME ആണ്
struct MyContext(CONTEXT);

#[inline(always)]
pub unsafe fn trace(cb: &mut dyn FnMut(&super::Frame) -> bool) {
    // സ്റ്റാക്ക് വാക്ക് ചെയ്യുന്നതിന് ആവശ്യമായ ഘടനകൾ അനുവദിക്കുക
    let process = GetCurrentProcess();
    let thread = GetCurrentThread();

    let mut context = mem::zeroed::<MyContext>();
    RtlCaptureContext(&mut context.0);

    // ഈ പ്രക്രിയയുടെ ചിഹ്നങ്ങൾ സമാരംഭിച്ചുവെന്ന് ഉറപ്പാക്കുക
    let dbghelp = match dbghelp::init() {
        Ok(dbghelp) => dbghelp,
        Err(()) => return, // ഓ, കൊള്ളാം...
    };

    // x86_64, ARM64 എന്നിവയിൽ ഫംഗ്ഷൻ ടേബിളും മൊഡ്യൂൾ ബേസും ലഭിക്കുന്നതിന് dbghelp-ൽ നിന്നുള്ള സ്ഥിരസ്ഥിതി `Sym*` ഫംഗ്ഷനുകൾ ഉപയോഗിക്കരുതെന്ന് ഞങ്ങൾ തിരഞ്ഞെടുക്കുന്നു.
    // പകരം ഞങ്ങൾ kernel32-ൽ `RtlLookupFunctionEntry` ഫംഗ്ഷൻ ഉപയോഗിക്കുന്നു, അത് JIT കംപൈലർ ഫ്രെയിമുകൾക്കും കാരണമാകും.
    // ഇവ തുല്യമായിരിക്കണം, പക്ഷേ `Rtl*` ഉപയോഗിക്കുന്നത് JIT ഫ്രെയിമുകളിലൂടെ ബാക്ക്ട്രേസ് ചെയ്യാൻ ഞങ്ങളെ അനുവദിക്കുന്നു.
    //
    // എക്സ്-00 എക്സ് പ്രോസസ്സ് ബാക്ക്ട്രേസുകളിൽ മാത്രമേ പ്രവർത്തിക്കൂ എന്ന കാര്യം ശ്രദ്ധിക്കുക, എന്നാൽ ഞങ്ങൾ ഏതുവിധേനയും പിന്തുണയ്ക്കുന്നു, അതിനാൽ എല്ലാം നന്നായി വരയ്ക്കുന്നു.
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(target_pointer_width = "64")] {
            use core::ptr;

            unsafe extern "system" fn function_table_access(_process: HANDLE, addr: DWORD64) -> PVOID {
                let mut base = 0;
                RtlLookupFunctionEntry(addr, &mut base, ptr::null_mut()).cast()
            }

            unsafe extern "system" fn get_module_base(_process: HANDLE, addr: DWORD64) -> DWORD64 {
                let mut base = 0;
                RtlLookupFunctionEntry(addr, &mut base, ptr::null_mut());
                base
            }
        } else {
            let function_table_access = dbghelp.SymFunctionTableAccess64();
            let get_module_base = dbghelp.SymGetModuleBase64();
        }
    }

    let process_handle = GetCurrentProcess();

    // ഞങ്ങൾക്ക് കഴിയുമെങ്കിൽ `StackWalkEx` ഉപയോഗിക്കാനുള്ള ശ്രമം, പക്ഷേ `StackWalk64` ലേക്ക് മടങ്ങുക, കാരണം ഇത് കൂടുതൽ സിസ്റ്റങ്ങളിൽ പിന്തുണയ്ക്കുന്ന സിദ്ധാന്തത്തിലാണ്.
    //
    match (*dbghelp.dbghelp()).StackWalkEx() {
        Some(StackWalkEx) => {
            let mut frame = super::Frame {
                inner: Frame {
                    stack_frame: StackFrame::New(mem::zeroed()),
                    base_address: 0 as _,
                },
            };
            let image = init_frame(&mut frame.inner, &context.0);
            let frame_ptr = match &mut frame.inner.stack_frame {
                StackFrame::New(ptr) => ptr as *mut STACKFRAME_EX,
                _ => unreachable!(),
            };

            while StackWalkEx(
                image as DWORD,
                process,
                thread,
                frame_ptr,
                &mut context.0 as *mut CONTEXT as *mut _,
                None,
                Some(function_table_access),
                Some(get_module_base),
                None,
                0,
            ) == TRUE
            {
                frame.inner.base_address = get_module_base(process_handle, frame.ip() as _) as _;

                if !cb(&frame) {
                    break;
                }
            }
        }
        None => {
            let mut frame = super::Frame {
                inner: Frame {
                    stack_frame: StackFrame::Old(mem::zeroed()),
                    base_address: 0 as _,
                },
            };
            let image = init_frame(&mut frame.inner, &context.0);
            let frame_ptr = match &mut frame.inner.stack_frame {
                StackFrame::Old(ptr) => ptr as *mut STACKFRAME64,
                _ => unreachable!(),
            };

            while dbghelp.StackWalk64()(
                image as DWORD,
                process,
                thread,
                frame_ptr,
                &mut context.0 as *mut CONTEXT as *mut _,
                None,
                Some(function_table_access),
                Some(get_module_base),
                None,
            ) == TRUE
            {
                frame.inner.base_address = get_module_base(process_handle, frame.ip() as _) as _;

                if !cb(&frame) {
                    break;
                }
            }
        }
    }
}

#[cfg(target_arch = "x86_64")]
fn init_frame(frame: &mut Frame, ctx: &CONTEXT) -> WORD {
    frame.addr_pc_mut().Offset = ctx.Rip as u64;
    frame.addr_pc_mut().Mode = AddrModeFlat;
    frame.addr_stack_mut().Offset = ctx.Rsp as u64;
    frame.addr_stack_mut().Mode = AddrModeFlat;
    frame.addr_frame_mut().Offset = ctx.Rbp as u64;
    frame.addr_frame_mut().Mode = AddrModeFlat;

    IMAGE_FILE_MACHINE_AMD64
}

#[cfg(target_arch = "x86")]
fn init_frame(frame: &mut Frame, ctx: &CONTEXT) -> WORD {
    frame.addr_pc_mut().Offset = ctx.Eip as u64;
    frame.addr_pc_mut().Mode = AddrModeFlat;
    frame.addr_stack_mut().Offset = ctx.Esp as u64;
    frame.addr_stack_mut().Mode = AddrModeFlat;
    frame.addr_frame_mut().Offset = ctx.Ebp as u64;
    frame.addr_frame_mut().Mode = AddrModeFlat;

    IMAGE_FILE_MACHINE_I386
}

#[cfg(target_arch = "aarch64")]
fn init_frame(frame: &mut Frame, ctx: &CONTEXT) -> WORD {
    frame.addr_pc_mut().Offset = ctx.Pc as u64;
    frame.addr_pc_mut().Mode = AddrModeFlat;
    frame.addr_stack_mut().Offset = ctx.Sp as u64;
    frame.addr_stack_mut().Mode = AddrModeFlat;
    unsafe {
        frame.addr_frame_mut().Offset = ctx.u.s().Fp as u64;
    }
    frame.addr_frame_mut().Mode = AddrModeFlat;
    IMAGE_FILE_MACHINE_ARM64
}

#[cfg(target_arch = "arm")]
fn init_frame(frame: &mut Frame, ctx: &CONTEXT) -> WORD {
    frame.addr_pc_mut().Offset = ctx.Pc as u64;
    frame.addr_pc_mut().Mode = AddrModeFlat;
    frame.addr_stack_mut().Offset = ctx.Sp as u64;
    frame.addr_stack_mut().Mode = AddrModeFlat;
    unsafe {
        frame.addr_frame_mut().Offset = ctx.R11 as u64;
    }
    frame.addr_frame_mut().Mode = AddrModeFlat;
    IMAGE_FILE_MACHINE_ARMNT
}