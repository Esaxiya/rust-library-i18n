use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// ഉടമസ്ഥതയിലുള്ളതും സ്വയം ഉൾക്കൊള്ളുന്നതുമായ ബാക്ക്‌ട്രെയ്‌സിന്റെ പ്രാതിനിധ്യം.
///
/// ഒരു പ്രോഗ്രാമിലെ വിവിധ പോയിന്റുകളിൽ ഒരു ബാക്ക്‌ട്രേസ് പിടിച്ചെടുക്കാനും പിന്നീട് ആ സമയത്ത് ബാക്ക്‌ട്രേസ് എന്തായിരുന്നുവെന്ന് പരിശോധിക്കാനും ഈ ഘടന ഉപയോഗിക്കാം.
///
///
/// `Backtrace` അതിന്റെ `Debug` നടപ്പാക്കലിലൂടെ ബാക്ക്‌ട്രെയ്‌സുകളുടെ പ്രെറ്റി പ്രിന്റിംഗ് പിന്തുണയ്‌ക്കുന്നു.
///
/// # ആവശ്യമായ സവിശേഷതകൾ
///
/// ഈ ഫംഗ്ഷന് `backtrace` crate ന്റെ `std` സവിശേഷത പ്രാപ്തമാക്കേണ്ടതുണ്ട്, കൂടാതെ `std` സവിശേഷത സ്ഥിരസ്ഥിതിയായി പ്രാപ്തമാക്കുന്നു.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // ഇവിടെയുള്ള ഫ്രെയിമുകൾ സ്റ്റാക്കിന്റെ മുകളിൽ നിന്ന് താഴേക്ക് പട്ടികപ്പെടുത്തിയിരിക്കുന്നു
    frames: Vec<BacktraceFrame>,
    // `Backtrace::new`, `backtrace::trace` പോലുള്ള ഫ്രെയിമുകൾ ഒഴിവാക്കിക്കൊണ്ട് ബാക്ക്‌ട്രെയ്‌സിന്റെ യഥാർത്ഥ ആരംഭമാണ് ഞങ്ങൾ വിശ്വസിക്കുന്ന സൂചിക.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// ഒരു ബാക്ക്‌ട്രെയ്‌സിൽ ഒരു ഫ്രെയിമിന്റെ ക്യാപ്‌ചർ ചെയ്‌ത പതിപ്പ്.
///
/// ഈ തരം `Backtrace::frames`-ൽ നിന്നുള്ള ഒരു ലിസ്റ്റായി മടക്കിനൽകുകയും ക്യാപ്‌ചർ ചെയ്‌ത ബാക്ക്‌ട്രെയ്‌സിലെ ഒരു സ്റ്റാക്ക് ഫ്രെയിമിനെ പ്രതിനിധീകരിക്കുകയും ചെയ്യുന്നു.
///
/// # ആവശ്യമായ സവിശേഷതകൾ
///
/// ഈ ഫംഗ്ഷന് `backtrace` crate ന്റെ `std` സവിശേഷത പ്രാപ്തമാക്കേണ്ടതുണ്ട്, കൂടാതെ `std` സവിശേഷത സ്ഥിരസ്ഥിതിയായി പ്രാപ്തമാക്കുന്നു.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// ഒരു ബാക്ക്‌ട്രെയ്‌സിൽ ഒരു ചിഹ്നത്തിന്റെ ക്യാപ്‌ചർ ചെയ്‌ത പതിപ്പ്.
///
/// ഈ തരം `BacktraceFrame::symbols`-ൽ നിന്നുള്ള ഒരു ലിസ്റ്റായി മടക്കിനൽകുകയും ബാക്ക്‌ട്രെയ്‌സിലെ ഒരു ചിഹ്നത്തിനായുള്ള മെറ്റാഡാറ്റയെ പ്രതിനിധീകരിക്കുകയും ചെയ്യുന്നു.
///
/// # ആവശ്യമായ സവിശേഷതകൾ
///
/// ഈ ഫംഗ്ഷന് `backtrace` crate ന്റെ `std` സവിശേഷത പ്രാപ്തമാക്കേണ്ടതുണ്ട്, കൂടാതെ `std` സവിശേഷത സ്ഥിരസ്ഥിതിയായി പ്രാപ്തമാക്കുന്നു.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// ഈ ഫംഗ്ഷന്റെ കോൾ‌സൈറ്റിൽ ഒരു ബാക്ക്‌ട്രേസ് ക്യാപ്‌ചർ ചെയ്യുന്നു, ഒരു ഉടമസ്ഥതയിലുള്ള പ്രാതിനിധ്യം നൽകുന്നു.
    ///
    /// Rust-ൽ ഒരു ബാക്ക്‌ട്രെയ്‌സിനെ ഒബ്‌ജക്റ്റായി പ്രതിനിധീകരിക്കുന്നതിന് ഈ പ്രവർത്തനം ഉപയോഗപ്രദമാണ്.മടക്കിയ ഈ മൂല്യം ത്രെഡുകളിലൂടെ അയച്ച് മറ്റെവിടെയെങ്കിലും അച്ചടിക്കാൻ കഴിയും, മാത്രമല്ല ഈ മൂല്യത്തിന്റെ ഉദ്ദേശ്യം പൂർണ്ണമായും സ്വയം ഉൾക്കൊള്ളുക എന്നതാണ്.
    ///
    /// ചില പ്ലാറ്റ്‌ഫോമുകളിൽ ഒരു പൂർണ്ണ ബാക്ക്‌ട്രേസ് നേടുകയും അത് പരിഹരിക്കുകയും ചെയ്യുന്നത് വളരെ ചെലവേറിയതായിരിക്കുമെന്നത് ശ്രദ്ധിക്കുക.
    /// നിങ്ങളുടെ ആപ്ലിക്കേഷന് ചെലവ് വളരെയധികം ആണെങ്കിൽ, പകരം `Backtrace::new_unresolved()` ഉപയോഗിക്കാൻ ശുപാർശചെയ്യുന്നു, ഇത് ചിഹ്ന മിഴിവ് ഘട്ടം ഒഴിവാക്കുന്നു (ഇത് സാധാരണയായി ദൈർഘ്യമേറിയതാണ്) കൂടാതെ പിന്നീടുള്ള തീയതിയിലേക്ക് മാറ്റിവയ്ക്കാൻ അനുവദിക്കുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # ആവശ്യമായ സവിശേഷതകൾ
    ///
    /// ഈ ഫംഗ്ഷന് `backtrace` crate ന്റെ `std` സവിശേഷത പ്രാപ്തമാക്കേണ്ടതുണ്ട്, കൂടാതെ `std` സവിശേഷത സ്ഥിരസ്ഥിതിയായി പ്രാപ്തമാക്കുന്നു.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // നീക്കംചെയ്യുന്നതിന് ഇവിടെ ഒരു ഫ്രെയിം ഉണ്ടെന്ന് ഉറപ്പാക്കാൻ ആഗ്രഹിക്കുന്നു
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// `new` ന് സമാനമായി ഇത് ഒരു ചിഹ്നങ്ങളും പരിഹരിക്കുന്നില്ല എന്നതൊഴിച്ചാൽ, ഇത് ബാക്ക്‌ട്രേസ് വിലാസങ്ങളുടെ പട്ടികയായി പിടിച്ചെടുക്കുന്നു.
    ///
    /// പിന്നീടുള്ള സമയത്ത്, ഈ ബാക്ക്‌ട്രെയ്‌സിന്റെ ചിഹ്നങ്ങൾ വായിക്കാവുന്ന പേരുകളായി പരിഹരിക്കുന്നതിന് `resolve` ഫംഗ്ഷനെ വിളിക്കാം.
    /// ഈ ഫംഗ്ഷൻ നിലവിലുണ്ട്, കാരണം റെസല്യൂഷൻ പ്രക്രിയയ്ക്ക് ചിലപ്പോൾ കാര്യമായ സമയമെടുക്കും, അതേസമയം ഏതെങ്കിലും ഒരു ബാക്ക്‌ട്രേസ് അപൂർവ്വമായി മാത്രമേ അച്ചടിക്കൂ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // ചിഹ്ന നാമങ്ങളൊന്നുമില്ല
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // ചിഹ്ന നാമങ്ങൾ ഇപ്പോൾ നിലവിലുണ്ട്
    /// ```
    ///
    /// # ആവശ്യമായ സവിശേഷതകൾ
    ///
    /// ഈ ഫംഗ്ഷന് `backtrace` crate ന്റെ `std` സവിശേഷത പ്രാപ്തമാക്കേണ്ടതുണ്ട്, കൂടാതെ `std` സവിശേഷത സ്ഥിരസ്ഥിതിയായി പ്രാപ്തമാക്കുന്നു.
    ///
    ///
    ///
    #[inline(never)] // നീക്കംചെയ്യുന്നതിന് ഇവിടെ ഒരു ഫ്രെയിം ഉണ്ടെന്ന് ഉറപ്പാക്കാൻ ആഗ്രഹിക്കുന്നു
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// ഈ ബാക്ക്‌ട്രേസ് ക്യാപ്‌ചർ ചെയ്‌തപ്പോൾ മുതൽ ഫ്രെയിമുകൾ നൽകുന്നു.
    ///
    /// ഈ സ്ലൈസിന്റെ ആദ്യ എൻ‌ട്രി `Backtrace::new` ഫംഗ്ഷനായിരിക്കാം, അവസാനത്തെ ഫ്രെയിം ഈ ത്രെഡ് അല്ലെങ്കിൽ പ്രധാന ഫംഗ്ഷൻ എങ്ങനെ ആരംഭിച്ചു എന്നതിനെക്കുറിച്ചുള്ളതായിരിക്കാം.
    ///
    ///
    /// # ആവശ്യമായ സവിശേഷതകൾ
    ///
    /// ഈ ഫംഗ്ഷന് `backtrace` crate ന്റെ `std` സവിശേഷത പ്രാപ്തമാക്കേണ്ടതുണ്ട്, കൂടാതെ `std` സവിശേഷത സ്ഥിരസ്ഥിതിയായി പ്രാപ്തമാക്കുന്നു.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// `new_unresolved`-ൽ നിന്നാണ് ഈ ബാക്ക്‌ട്രേസ് സൃഷ്‌ടിച്ചതെങ്കിൽ, ഈ പ്രവർത്തനം ബാക്ക്‌ട്രെയ്‌സിലെ എല്ലാ വിലാസങ്ങളും അവയുടെ പ്രതീകാത്മക നാമങ്ങളിലേക്ക് പരിഹരിക്കും.
    ///
    ///
    /// ഈ ബാക്ക്‌ട്രേസ് മുമ്പ് പരിഹരിച്ചിട്ടുണ്ടെങ്കിലോ `new` വഴി സൃഷ്ടിച്ചതാണെങ്കിലോ, ഈ പ്രവർത്തനം ഒന്നും ചെയ്യുന്നില്ല.
    ///
    /// # ആവശ്യമായ സവിശേഷതകൾ
    ///
    /// ഈ ഫംഗ്ഷന് `backtrace` crate ന്റെ `std` സവിശേഷത പ്രാപ്തമാക്കേണ്ടതുണ്ട്, കൂടാതെ `std` സവിശേഷത സ്ഥിരസ്ഥിതിയായി പ്രാപ്തമാക്കുന്നു.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// `Frame::ip` പോലെ തന്നെ
    ///
    /// # ആവശ്യമായ സവിശേഷതകൾ
    ///
    /// ഈ ഫംഗ്ഷന് `backtrace` crate ന്റെ `std` സവിശേഷത പ്രാപ്തമാക്കേണ്ടതുണ്ട്, കൂടാതെ `std` സവിശേഷത സ്ഥിരസ്ഥിതിയായി പ്രാപ്തമാക്കുന്നു.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// `Frame::symbol_address` പോലെ തന്നെ
    ///
    /// # ആവശ്യമായ സവിശേഷതകൾ
    ///
    /// ഈ ഫംഗ്ഷന് `backtrace` crate ന്റെ `std` സവിശേഷത പ്രാപ്തമാക്കേണ്ടതുണ്ട്, കൂടാതെ `std` സവിശേഷത സ്ഥിരസ്ഥിതിയായി പ്രാപ്തമാക്കുന്നു.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// `Frame::module_base_address` പോലെ തന്നെ
    ///
    /// # ആവശ്യമായ സവിശേഷതകൾ
    ///
    /// ഈ ഫംഗ്ഷന് `backtrace` crate ന്റെ `std` സവിശേഷത പ്രാപ്തമാക്കേണ്ടതുണ്ട്, കൂടാതെ `std` സവിശേഷത സ്ഥിരസ്ഥിതിയായി പ്രാപ്തമാക്കുന്നു.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// ഈ ഫ്രെയിം യോജിക്കുന്ന ചിഹ്നങ്ങളുടെ പട്ടിക നൽകുന്നു.
    ///
    /// സാധാരണയായി ഒരു ഫ്രെയിമിന് ഒരു ചിഹ്നം മാത്രമേയുള്ളൂ, എന്നാൽ ചിലപ്പോൾ നിരവധി ഫംഗ്ഷനുകൾ ഒരു ഫ്രെയിമിലേക്ക് ഇൻലൈൻ ചെയ്തിട്ടുണ്ടെങ്കിൽ ഒന്നിലധികം ചിഹ്നങ്ങൾ തിരികെ നൽകും.
    /// ലിസ്റ്റുചെയ്ത ആദ്യ ചിഹ്നം "innermost function" ആണ്, അതേസമയം അവസാന ചിഹ്നം ഏറ്റവും പുറത്തുള്ളത് (അവസാന കോളർ).
    ///
    /// ഈ ഫ്രെയിം പരിഹരിക്കപ്പെടാത്ത ബാക്ക്‌ട്രെയ്‌സിൽ നിന്നാണ് വന്നതെങ്കിൽ ഇത് ഒരു ശൂന്യമായ ലിസ്റ്റ് നൽകും.
    ///
    /// # ആവശ്യമായ സവിശേഷതകൾ
    ///
    /// ഈ ഫംഗ്ഷന് `backtrace` crate ന്റെ `std` സവിശേഷത പ്രാപ്തമാക്കേണ്ടതുണ്ട്, കൂടാതെ `std` സവിശേഷത സ്ഥിരസ്ഥിതിയായി പ്രാപ്തമാക്കുന്നു.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// `Symbol::name` പോലെ തന്നെ
    ///
    /// # ആവശ്യമായ സവിശേഷതകൾ
    ///
    /// ഈ ഫംഗ്ഷന് `backtrace` crate ന്റെ `std` സവിശേഷത പ്രാപ്തമാക്കേണ്ടതുണ്ട്, കൂടാതെ `std` സവിശേഷത സ്ഥിരസ്ഥിതിയായി പ്രാപ്തമാക്കുന്നു.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// `Symbol::addr` പോലെ തന്നെ
    ///
    /// # ആവശ്യമായ സവിശേഷതകൾ
    ///
    /// ഈ ഫംഗ്ഷന് `backtrace` crate ന്റെ `std` സവിശേഷത പ്രാപ്തമാക്കേണ്ടതുണ്ട്, കൂടാതെ `std` സവിശേഷത സ്ഥിരസ്ഥിതിയായി പ്രാപ്തമാക്കുന്നു.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// `Symbol::filename` പോലെ തന്നെ
    ///
    /// # ആവശ്യമായ സവിശേഷതകൾ
    ///
    /// ഈ ഫംഗ്ഷന് `backtrace` crate ന്റെ `std` സവിശേഷത പ്രാപ്തമാക്കേണ്ടതുണ്ട്, കൂടാതെ `std` സവിശേഷത സ്ഥിരസ്ഥിതിയായി പ്രാപ്തമാക്കുന്നു.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// `Symbol::lineno` പോലെ തന്നെ
    ///
    /// # ആവശ്യമായ സവിശേഷതകൾ
    ///
    /// ഈ ഫംഗ്ഷന് `backtrace` crate ന്റെ `std` സവിശേഷത പ്രാപ്തമാക്കേണ്ടതുണ്ട്, കൂടാതെ `std` സവിശേഷത സ്ഥിരസ്ഥിതിയായി പ്രാപ്തമാക്കുന്നു.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// `Symbol::colno` പോലെ തന്നെ
    ///
    /// # ആവശ്യമായ സവിശേഷതകൾ
    ///
    /// ഈ ഫംഗ്ഷന് `backtrace` crate ന്റെ `std` സവിശേഷത പ്രാപ്തമാക്കേണ്ടതുണ്ട്, കൂടാതെ `std` സവിശേഷത സ്ഥിരസ്ഥിതിയായി പ്രാപ്തമാക്കുന്നു.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // പാതകൾ അച്ചടിക്കുമ്പോൾ cwd നിലവിലുണ്ടെങ്കിൽ അത് നീക്കംചെയ്യാൻ ഞങ്ങൾ ശ്രമിക്കുന്നു, അല്ലാത്തപക്ഷം ഞങ്ങൾ പാത്ത് അതേപടി അച്ചടിക്കുന്നു.
        // ഹ്രസ്വ ഫോർമാറ്റിനായി മാത്രമാണ് ഞങ്ങൾ ഇത് ചെയ്യുന്നതെന്ന കാര്യം ശ്രദ്ധിക്കുക, കാരണം ഇത് നിറഞ്ഞിട്ടുണ്ടെങ്കിൽ എല്ലാം പ്രിന്റുചെയ്യാൻ ഞങ്ങൾ ആഗ്രഹിക്കുന്നു.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}