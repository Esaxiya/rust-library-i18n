use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr ഒരു കോൾബാക്ക് എടുക്കുന്നു, അത് പ്രക്രിയയിലേക്ക് ലിങ്കുചെയ്തിരിക്കുന്ന ഓരോ DSO നും ഒരു dl_phdr_info പോയിന്റർ ലഭിക്കും.
    // ആവർത്തനത്തിന്റെ ആരംഭം മുതൽ അവസാനം വരെ ഡൈനാമിക് ലിങ്കർ ലോക്ക് ചെയ്തിട്ടുണ്ടെന്ന് dl_iterate_phdr ഉറപ്പാക്കുന്നു.
    // കോൾബാക്ക് പൂജ്യമല്ലാത്ത മൂല്യം നൽകുന്നുവെങ്കിൽ ആവർത്തനം നേരത്തേ അവസാനിപ്പിക്കും.
    // 'data' ഓരോ കോളിലെയും കോൾബാക്കിലേക്കുള്ള മൂന്നാമത്തെ ആർഗ്യുമെന്റായി കൈമാറും.
    // 'size' dl_phdr_info ന്റെ വലുപ്പം നൽകുന്നു.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// ബിൽഡ് ഐഡിയും ചില അടിസ്ഥാന പ്രോഗ്രാം ഹെഡർ ഡാറ്റയും ഞങ്ങൾ പാഴ്‌സുചെയ്യേണ്ടതുണ്ട്, അതിനർത്ഥം ഞങ്ങൾക്ക് ELF സ്പെക്കിൽ നിന്ന് കുറച്ച് സ്റ്റഫ് ആവശ്യമാണ്.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// ഫ്യൂഷിയയുടെ നിലവിലെ ഡൈനാമിക് ലിങ്കർ ഉപയോഗിക്കുന്ന dl_phdr_info തരത്തിന്റെ ഘടന ഇപ്പോൾ നമ്മൾ പകർത്തണം, ബിറ്റ് ഫോർ ബിറ്റ്.
// ക്രോമിയത്തിന് ഈ എബിഐ അതിർത്തിയും ക്രാഷ്പാഡും ഉണ്ട്.
// ആത്യന്തികമായി, ഈ കേസുകൾ‌elf-തിരയൽ‌ഉപയോഗിക്കാൻ‌ഞങ്ങൾ‌താൽ‌പ്പര്യപ്പെടുന്നു, പക്ഷേ ഞങ്ങൾ‌അത് SDK ൽ‌നൽ‌കേണ്ടതുണ്ട്, അത് ഇതുവരെ നടന്നിട്ടില്ല.
//
// ഫ്യൂഷിയ ലിബ്സിയുമായി കർശനമായ കൂടിച്ചേരലിന് കാരണമാകുന്ന ഈ രീതി ഉപയോഗിക്കുന്നതിന് ഞങ്ങൾ (അവരും) കുടുങ്ങി.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // E_phoff ഉം e_phnum ഉം സാധുതയുള്ളതാണോയെന്ന് പരിശോധിക്കാൻ ഞങ്ങൾക്ക് ഒരു മാർഗവുമില്ല.
    // ലിബ്സി ഇത് ഞങ്ങൾക്ക് ഉറപ്പാക്കണം, അതിനാൽ ഇവിടെ ഒരു സ്ലൈസ് ഉണ്ടാക്കുന്നത് സുരക്ഷിതമാണ്.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// ടാർ‌ഗെറ്റ് ആർക്കിടെക്ചറിൻറെ എൻ‌ഡിയൻ‌നെസിൽ‌64-ബിറ്റ് ELF പ്രോഗ്രാം ഹെഡറിനെ Elf_Phdr പ്രതിനിധീകരിക്കുന്നു.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// പിഎച്ച്ഡിആർ സാധുവായ ഒരു ഇഎൽഎഫ് പ്രോഗ്രാം ഹെഡറിനെയും അതിന്റെ ഉള്ളടക്കങ്ങളെയും പ്രതിനിധീകരിക്കുന്നു.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // P_addr അല്ലെങ്കിൽ p_memsz സാധുതയുള്ളതാണോയെന്ന് പരിശോധിക്കാൻ ഞങ്ങൾക്ക് ഒരു മാർഗവുമില്ല.
    // ഫ്യൂഷിയയുടെ ലിബ്സി ആദ്യം കുറിപ്പുകൾ പാഴ്‌സുചെയ്യുന്നു, എന്നിരുന്നാലും ഇവിടെയുള്ളതിനാൽ ഈ തലക്കെട്ടുകൾ സാധുവായിരിക്കണം.
    //
    // നോട്ട്ഇറ്ററിന് അടിസ്ഥാന ഡാറ്റ സാധുവായിരിക്കണമെന്ന് ആവശ്യമില്ല, പക്ഷേ അതിരുകൾ സാധുവായിരിക്കേണ്ടതുണ്ട്.
    // ഇവിടെ ഞങ്ങൾക്ക് ഇത് ബാധകമാണെന്ന് ലിബ്സി ഉറപ്പുവരുത്തിയെന്ന് ഞങ്ങൾ വിശ്വസിക്കുന്നു.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// ബിൽഡ് ഐഡികൾക്കുള്ള കുറിപ്പ് തരം.
const NT_GNU_BUILD_ID: u32 = 3;

// ടാർഗറ്റിന്റെ അന്തിമതയിലുള്ള ഒരു ELF കുറിപ്പ് തലക്കെട്ടിനെ Elf_Nhdr പ്രതിനിധീകരിക്കുന്നു.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// കുറിപ്പ് ഒരു ELF കുറിപ്പിനെ പ്രതിനിധീകരിക്കുന്നു (തലക്കെട്ട് + ഉള്ളടക്കങ്ങൾ).
// എല്ലായ്പ്പോഴും അസാധുവാക്കാത്തതിനാൽ പേര് u8 സ്ലൈസായി അവശേഷിക്കുന്നു, മാത്രമല്ല ബൈറ്റുകൾ എങ്ങനെയെങ്കിലും പൊരുത്തപ്പെടുന്നുണ്ടോയെന്ന് പരിശോധിക്കാൻ rust എളുപ്പമാക്കുന്നു.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// ഒരു കുറിപ്പ് വിഭാഗത്തിൽ സുരക്ഷിതമായി ആവർത്തിക്കാൻ നോട്ട്ഇറ്റർ നിങ്ങളെ അനുവദിക്കുന്നു.
// ഒരു പിശക് സംഭവിച്ചാലുടൻ അല്ലെങ്കിൽ കൂടുതൽ കുറിപ്പുകളില്ലാത്ത ഉടൻ തന്നെ ഇത് അവസാനിക്കും.
// അസാധുവായ ഡാറ്റയിൽ നിങ്ങൾ ആവർത്തിച്ചാൽ കുറിപ്പുകളൊന്നും കണ്ടെത്തിയില്ല എന്നതുപോലെ ഇത് പ്രവർത്തിക്കും.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // നൽകിയിരിക്കുന്ന പോയിന്ററും വലുപ്പവും എല്ലാം വായിക്കാൻ കഴിയുന്ന സാധുവായ ബൈറ്റുകളുടെ ശ്രേണിയെ സൂചിപ്പിക്കുന്നു എന്നത് പ്രവർത്തനത്തിന്റെ ഒരു മാറ്റമാണ്.
    // ഈ ബൈറ്റുകളിലെ ഉള്ളടക്കങ്ങൾ‌എന്തും ആകാം, പക്ഷേ ഇത് സുരക്ഷിതമായിരിക്കുന്നതിന് ശ്രേണി സാധുവായിരിക്കണം.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to 'x' നെ 'to'-byte വിന്യാസത്തിലേക്ക് വിന്യസിക്കുന്നു 'to' 2 ന്റെ ശക്തിയാണെന്ന് കരുതുക.
// (X + to, 1)&-to ഉപയോഗിക്കുന്ന C/C ++ ELF പാഴ്‌സിംഗ് കോഡിലെ ഒരു സാധാരണ പാറ്റേൺ ഇത് പിന്തുടരുന്നു.
// Rust നിങ്ങളെ ഉപയോഗപ്പെടുത്തുന്നത് നിരസിക്കാൻ അനുവദിക്കുന്നില്ല അതിനാൽ ഞാൻ ഉപയോഗിക്കുന്നു
// അത് പുന ate സൃഷ്‌ടിക്കാനുള്ള 2 ന്റെ പൂരക പരിവർത്തനം.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 സ്ലൈസിൽ നിന്ന് നമ്പർ ബൈറ്റുകൾ ഉപയോഗിക്കുന്നു (നിലവിലുണ്ടെങ്കിൽ) കൂടാതെ അന്തിമ സ്ലൈസ് ശരിയായി വിന്യസിച്ചിട്ടുണ്ടെന്ന് ഉറപ്പാക്കുകയും ചെയ്യുന്നു.
// ഒന്നുകിൽ അഭ്യർത്ഥിച്ച ബൈറ്റുകളുടെ എണ്ണം വളരെ വലുതാണെങ്കിലോ നിലവിലുള്ള ബൈറ്റുകൾ വേണ്ടത്ര ഇല്ലാത്തതിനാൽ സ്ലൈസ് പിന്നീട് രൂപകൽപ്പന ചെയ്യാൻ കഴിയുന്നില്ലെങ്കിലോ, ഒന്നും മടക്കിനൽകുന്നില്ല, സ്ലൈസ് പരിഷ്‌ക്കരിക്കില്ല.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// പ്രകടനത്തിനായി 'bytes' വിന്യസിക്കണം എന്നതൊഴിച്ചാൽ ഈ ഫംഗ്ഷന് യഥാർത്ഥ മാറ്റങ്ങളൊന്നുമില്ല (കൂടാതെ ചില ആർക്കിടെക്ചറുകളിൽ കൃത്യത).
// Elf_Nhdr ഫീൽ‌ഡുകളിലെ മൂല്യങ്ങൾ‌അസംബന്ധമായിരിക്കാം, പക്ഷേ ഈ പ്രവർ‌ത്തനം അത്തരത്തിലുള്ള ഒന്നും ഉറപ്പാക്കുന്നില്ല.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // മതിയായ ഇടമുള്ളിടത്തോളം കാലം ഇത് സുരക്ഷിതമാണ്, മുകളിലുള്ള if സ്റ്റേറ്റ്മെന്റിൽ ഇത് സുരക്ഷിതമല്ലെന്ന് ഞങ്ങൾ സ്ഥിരീകരിച്ചു.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Sice_of: : എന്നത് ശ്രദ്ധിക്കുക<Elf_Nhdr>() എല്ലായ്പ്പോഴും 4-ബൈറ്റ് വിന്യസിച്ചിരിക്കുന്നു.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // ഞങ്ങൾ അവസാനം എത്തിയിട്ടുണ്ടോയെന്ന് പരിശോധിക്കുക.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // ഞങ്ങൾ ഒരു nhdr പരിവർത്തനം ചെയ്യുന്നു, പക്ഷേ ഫലമായുണ്ടാകുന്ന ഘടനയെ ഞങ്ങൾ ശ്രദ്ധാപൂർവ്വം പരിഗണിക്കുന്നു.
        // നെയിംസ് അല്ലെങ്കിൽ ഡെസ്ക് എന്നിവ ഞങ്ങൾ വിശ്വസിക്കുന്നില്ല, കൂടാതെ തരം അടിസ്ഥാനമാക്കി ഞങ്ങൾ സുരക്ഷിതമല്ലാത്ത തീരുമാനങ്ങളൊന്നും എടുക്കുന്നില്ല.
        //
        // അതിനാൽ സമ്പൂർണ്ണ മാലിന്യങ്ങൾ പുറത്തെടുത്താലും നാം ഇപ്പോഴും സുരക്ഷിതമായിരിക്കണം.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// ഒരു സെഗ്മെന്റ് എക്സിക്യൂട്ടബിൾ ആണെന്ന് സൂചിപ്പിക്കുന്നു.
const PERM_X: u32 = 0b00000001;
/// ഒരു സെഗ്മെന്റ് എഴുതാനാകുമെന്ന് സൂചിപ്പിക്കുന്നു.
const PERM_W: u32 = 0b00000010;
/// ഒരു സെഗ്മെന്റ് വായിക്കാൻ കഴിയുമെന്ന് സൂചിപ്പിക്കുന്നു.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// റൺടൈമിൽ ഒരു ELF സെഗ്‌മെന്റിനെ പ്രതിനിധീകരിക്കുന്നു.
struct Segment {
    /// ഈ സെഗ്‌മെന്റിന്റെ ഉള്ളടക്കങ്ങളുടെ റൺടൈം വെർച്വൽ വിലാസം നൽകുന്നു.
    addr: usize,
    /// ഈ സെഗ്‌മെന്റിന്റെ ഉള്ളടക്കങ്ങളുടെ മെമ്മറി വലുപ്പം നൽകുന്നു.
    size: usize,
    /// ഈ സെഗ്‌മെന്റിന്റെ മൊഡ്യൂൾ വെർച്വൽ വിലാസം ELF ഫയലിനൊപ്പം നൽകുന്നു.
    mod_rel_addr: usize,
    /// ELF ഫയലിൽ കാണുന്ന അനുമതികൾ നൽകുന്നു.
    /// എന്നിരുന്നാലും ഈ അനുമതികൾ റൺടൈമിൽ നിലവിലുള്ള അനുമതികളായിരിക്കണമെന്നില്ല.
    flags: Perm,
}

/// ഒരു DSO-യിൽ നിന്നുള്ള സെഗ്‌മെന്റുകളിൽ ഒരു ആവർത്തനം അനുവദിക്കുന്നു.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// ഒരു ELF DSO (ഡൈനാമിക് പങ്കിട്ട ഒബ്ജക്റ്റ്) പ്രതിനിധീകരിക്കുന്നു.
/// സ്വന്തമായി ഒരു പകർപ്പ് നിർമ്മിക്കുന്നതിനേക്കാൾ യഥാർത്ഥ DSO-യിൽ സംഭരിച്ചിരിക്കുന്ന ഡാറ്റയെ ഈ തരം പരാമർശിക്കുന്നു.
struct Dso<'a> {
    /// പേര് ശൂന്യമാണെങ്കിലും ഡൈനാമിക് ലിങ്കർ എല്ലായ്പ്പോഴും ഞങ്ങൾക്ക് ഒരു പേര് നൽകുന്നു.
    /// പ്രധാന എക്സിക്യൂട്ടബിളിന്റെ കാര്യത്തിൽ ഈ പേര് ശൂന്യമായിരിക്കും.
    /// പങ്കിട്ട ഒബ്‌ജക്റ്റിന്റെ കാര്യത്തിൽ അത് സോനെയിം ആയിരിക്കും (DT_SONAME കാണുക).
    name: &'a str,
    /// ഫ്യൂഷിയയിൽ എല്ലാ ബൈനറികളിലും ബിൽഡ് ഐഡികളുണ്ടെങ്കിലും ഇത് കർശനമായ ആവശ്യകതയല്ല.
    /// ബിൽഡ്_ഐഡി ഇല്ലെങ്കിൽ DSO വിവരങ്ങൾ ഒരു യഥാർത്ഥ ELF ഫയലുമായി പൊരുത്തപ്പെടുത്താൻ ഒരു വഴിയുമില്ല, അതിനാൽ ഓരോ DSO നും ഇവിടെ ഒന്ന് ഉണ്ടായിരിക്കണമെന്ന് ഞങ്ങൾ ആവശ്യപ്പെടുന്നു.
    ///
    /// ബിൽഡ്_ഐഡി ഇല്ലാത്ത DSO-കൾ അവഗണിക്കപ്പെടും.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// ഈ DSO-ലെ സെഗ്‌മെന്റുകളിൽ ഒരു ഇറ്ററേറ്റർ നൽകുന്നു.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// ഓരോ ഡി‌എസ്‌ഒയെയും കുറിച്ചുള്ള വിവരങ്ങൾ‌പാഴ്‌സുചെയ്യുമ്പോൾ‌ഉണ്ടാകുന്ന പ്രശ്‌നങ്ങൾ‌ഈ പിശകുകൾ‌എൻ‌കോഡുചെയ്യുന്നു.
///
enum Error {
    /// സി സ്റ്റൈൽ സ്ട്രിംഗിനെ rust സ്ട്രിംഗിലേക്ക് പരിവർത്തനം ചെയ്യുമ്പോൾ ഒരു പിശക് സംഭവിച്ചു എന്നാണ് നെയിം എറർ.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError എന്നതിനർത്ഥം ഞങ്ങൾ ഒരു ബിൽഡ് ഐഡി കണ്ടെത്തിയില്ല എന്നാണ്.
    /// ഡി‌എസ്‌ഒയ്ക്ക് ബിൽഡ് ഐഡി ഇല്ലാത്തതിനാലോ ബിൽഡ് ഐഡി അടങ്ങിയ സെഗ്‌മെന്റ് കേടായതിനാലോ ആയിരിക്കാം ഇത്.
    ///
    BuildIDError,
}

/// ഡൈനാമിക് ലിങ്കർ പ്രോസസ്സിലേക്ക് ലിങ്കുചെയ്തിരിക്കുന്ന ഓരോ DSO-യ്‌ക്കും 'dso' അല്ലെങ്കിൽ 'error' കോളുകൾ.
///
///
/// # Arguments
///
/// * `visitor` - ഫോറാച്ച് ഡി‌എസ്‌ഒ എന്ന് വിളിക്കുന്ന ഈറ്റ്സ് രീതികളിലൊന്ന് ഉൾക്കൊള്ളുന്ന ഒരു ഡിസോപ്രിന്റർ.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // info.name സാധുവായ ഒരു സ്ഥാനത്തേക്ക് പോയിന്റുചെയ്യുമെന്ന് dl_iterate_phdr ഉറപ്പാക്കുന്നു.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// ഈ പ്രവർ‌ത്തനം ഒരു ഡി‌എസ്‌ഒയിൽ‌അടങ്ങിയിരിക്കുന്ന എല്ലാ വിവരങ്ങൾ‌ക്കും ഫ്യൂഷിയ സിംബലൈസർ മാർ‌ക്കപ്പ് അച്ചടിക്കുന്നു.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}