// ഇപ്പോൾ Linux-ൽ മാത്രം ഉപയോഗിക്കുന്നു, അതിനാൽ മറ്റെവിടെയെങ്കിലും ഡെഡ് കോഡ് അനുവദിക്കുക
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// ബൈറ്റ് ബഫറുകൾ‌ക്കായി ഒരു ലളിതമായ അരീന അലോക്കേറ്റർ.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// നിർദ്ദിഷ്ട വലുപ്പത്തിന്റെ ഒരു ബഫർ അനുവദിക്കുകയും അതിലേക്ക് ഒരു മ്യൂട്ടബിൾ റഫറൻസ് നൽകുകയും ചെയ്യുന്നു.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // സുരക്ഷ: ഒരു മ്യൂട്ടബിൾ നിർമ്മിക്കുന്ന ഒരേയൊരു പ്രവർത്തനം ഇതാണ്
        // `self.buffers`-ലേക്ക് റഫറൻസ്.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // സുരക്ഷ: `self.buffers`-ൽ നിന്ന് ഞങ്ങൾ ഒരിക്കലും ഘടകങ്ങൾ നീക്കംചെയ്യില്ല, അതിനാൽ ഒരു റഫറൻസ്
        // `self` ഉള്ളിടത്തോളം കാലം ഏതെങ്കിലും ബഫറിനുള്ളിലെ ഡാറ്റയിലേക്ക് ജീവിക്കും.
        &mut buffers[i]
    }
}