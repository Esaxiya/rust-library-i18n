//! crates.io-ലെ `gimli` crate ഉപയോഗിച്ച് പ്രതീകവൽക്കരണത്തിനുള്ള പിന്തുണ
//!
//! Rust-നായുള്ള സ്ഥിരസ്ഥിതി പ്രതീകാത്മക നടപ്പാക്കലാണിത്.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // സ്വയം റഫറൻഷ്യൽ ഘടനകൾക്കുള്ള പിന്തുണയുടെ അഭാവം പരിഹരിക്കുന്നതിന് സ്റ്റാറ്റിക് ലൈഫ് ടൈം ഒരു നുണയാണ്.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // ചിഹ്നങ്ങൾ `map`, `stash` എന്നിവ മാത്രമേ കടമെടുക്കൂ എന്നതിനാൽ 'സ്റ്റാറ്റിക് ലൈഫ് ടൈമുകളിലേക്ക് പരിവർത്തനം ചെയ്യുക, ഞങ്ങൾ അവ ചുവടെ സംരക്ഷിക്കുന്നു.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Windows-ൽ നേറ്റീവ് ലൈബ്രറികൾ ലോഡുചെയ്യുന്നതിന്, ഇവിടെയുള്ള വിവിധ തന്ത്രങ്ങൾക്കായി rust-lang/rust#71060-നെക്കുറിച്ചുള്ള ചില ചർച്ച കാണുക.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // MinGW ലൈബ്രറികൾ‌നിലവിൽ‌ASLR (rust-lang/rust#16514) നെ പിന്തുണയ്‌ക്കുന്നില്ല, പക്ഷേ DLL കൾ‌ഇപ്പോഴും വിലാസ സ്ഥലത്ത് പുന oc സ്ഥാപിക്കാൻ‌കഴിയും.
            // ഡീബഗ് വിവരത്തിലെ വിലാസങ്ങളെല്ലാം ഈ ലൈബ്രറി അതിന്റെ "image base" ൽ ലോഡ് ചെയ്തതുപോലെയാണെന്ന് തോന്നുന്നു, ഇത് അതിന്റെ COFF ഫയൽ തലക്കെട്ടുകളിലെ ഒരു ഫീൽഡാണ്.
            // ഡീബഗ്ഗിൻ‌ഫോ ലിസ്റ്റുചെയ്യുന്നത് ഇതായിരിക്കുമെന്നതിനാൽ, ഞങ്ങൾ ചിഹ്ന പട്ടിക പാഴ്‌സുചെയ്യുകയും വിലാസങ്ങൾ സംഭരിക്കുകയും ചെയ്യുന്നു.
            //
            // എന്നിരുന്നാലും, "image base"-ൽ ലൈബ്രറി ലോഡുചെയ്തേക്കില്ല.
            // (മറ്റെന്തെങ്കിലും അവിടെ ലോഡുചെയ്യാം?) ഇവിടെയാണ് `bias` ഫീൽഡ് പ്രവർത്തനക്ഷമമാകുന്നത്, ഇവിടെ `bias` ന്റെ മൂല്യം ഞങ്ങൾ കണ്ടെത്തേണ്ടതുണ്ട്.നിർഭാഗ്യവശാൽ ഒരു ലോഡുചെയ്ത മൊഡ്യൂളിൽ നിന്ന് ഇത് എങ്ങനെ നേടാമെന്ന് വ്യക്തമല്ലെങ്കിലും.
            // എന്നിരുന്നാലും, ഞങ്ങളുടെ പക്കലുള്ളത് യഥാർത്ഥ ലോഡ് വിലാസം (`modBaseAddr`) ആണ്.
            //
            // ഇപ്പോൾ ഒരു കോപ്പ്-out ട്ട് എന്ന നിലയിൽ ഞങ്ങൾ ഫയൽ എംമാപ്പ് ചെയ്യുന്നു, ഫയൽ തലക്കെട്ട് വിവരങ്ങൾ വായിക്കുക, തുടർന്ന് എംമാപ്പ് ഉപേക്ഷിക്കുക.ഇത് പാഴായതിനാൽ ഞങ്ങൾ പിന്നീട് എംമാപ്പ് വീണ്ടും തുറക്കും, പക്ഷേ ഇത് ഇപ്പോൾ വേണ്ടത്ര പ്രവർത്തിക്കും.
            //
            // ഞങ്ങൾക്ക് `image_base` (ആവശ്യമുള്ള ലോഡ് സ്ഥാനം), `base_addr` (യഥാർത്ഥ ലോഡ് സ്ഥാനം) എന്നിവ ലഭിച്ചുകഴിഞ്ഞാൽ നമുക്ക് `bias` (യഥാർത്ഥവും ആവശ്യമുള്ളതും തമ്മിലുള്ള വ്യത്യാസം) പൂരിപ്പിക്കാൻ കഴിയും, തുടർന്ന് ഓരോ സെഗ്‌മെന്റിന്റെയും പ്രഖ്യാപിത വിലാസം `image_base` ആണ്, കാരണം അത് ഫയൽ പറയുന്നു.
            //
            //
            // ഇപ്പോൾ, ELF/MachO-ൽ നിന്ന് വ്യത്യസ്തമായി, ഒരു ലൈബ്രറിക്ക് ഒരു സെഗ്മെൻറ് ഉപയോഗിച്ച് ഞങ്ങൾക്ക് ചെയ്യാൻ കഴിയും, `modBaseSize` ഉപയോഗിച്ച് മുഴുവൻ വലുപ്പവും.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS അപ്ലിക്കേഷന്റെ ഭാഗമായ നേറ്റീവ് ലൈബ്രറികളുടെ ഒരു ലിസ്റ്റ് ലോഡുചെയ്യുന്നതിന് മാക്-ഒ ഫയൽ ഫോർമാറ്റ് ഉപയോഗിക്കുകയും DYLD-നിർദ്ദിഷ്ട API-കൾ ഉപയോഗിക്കുകയും ചെയ്യുന്നു.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // ഈ ലൈബ്രറിയുടെ പേര് ലഭ്യമാക്കുക, അത് എവിടെ ലോഡുചെയ്യണം എന്നതിന്റെ പാതയുമായി യോജിക്കുന്നു.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // എല്ലാ ലോഡ് കമാൻഡുകളും പാഴ്‌സുചെയ്യുന്നതിന് ഈ ലൈബ്രറിയുടെ ഇമേജ് ഹെഡർ ലോഡുചെയ്‌ത് `object`-ലേക്ക് നിയോഗിക്കുക, അതിനാൽ ഇവിടെ ഉൾപ്പെട്ടിരിക്കുന്ന എല്ലാ സെഗ്‌മെന്റുകളും ഞങ്ങൾക്ക് കണ്ടെത്താനാകും.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // സെഗ്‌മെന്റുകളെ മറികടന്ന് ഞങ്ങൾ കണ്ടെത്തിയ സെഗ്‌മെന്റുകൾക്കായി അറിയപ്പെടുന്ന പ്രദേശങ്ങൾ രജിസ്റ്റർ ചെയ്യുക.
            // പിന്നീട് പ്രോസസ്സിംഗിനായി ടെക്സ്റ്റ് സെഗ്‌മെന്റുകളുടെ വിവരങ്ങൾ റെക്കോർഡുചെയ്യുക, ചുവടെയുള്ള അഭിപ്രായങ്ങൾ കാണുക.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // മെമ്മറി ഒബ്‌ജക്റ്റുകൾ എവിടെ ലോഡുചെയ്യുന്നുവെന്ന് മനസിലാക്കാൻ ഞങ്ങൾ ഉപയോഗിക്കുന്ന പക്ഷപാതമായി അവസാനിക്കുന്ന ഈ ലൈബ്രറിയുടെ "slide" നിർണ്ണയിക്കുക.
            // ഇത് അൽപ്പം വിചിത്രമായ ഒരു കണക്കുകൂട്ടലാണ്, മാത്രമല്ല കാട്ടിൽ കുറച്ച് കാര്യങ്ങൾ പരീക്ഷിച്ച് എന്താണെന്നറിയുന്നതിന്റെ ഫലമാണിത്.
            //
            // `bias` പ്ലസ് ഒരു സെഗ്‌മെന്റിന്റെ `stated_virtual_memory_address` എന്നിവ യഥാർത്ഥ വിലാസ സ്ഥലത്ത് സെഗ്മെന്റ് താമസിക്കുന്നിടത്തായിരിക്കുമെന്നതാണ് പൊതുവായ ആശയം.
            // എന്നിരുന്നാലും ഞങ്ങൾ ആശ്രയിക്കുന്ന മറ്റൊരു കാര്യം, ചിഹ്ന പട്ടികയിലും ഡീബഗ്ഗിൻഫോയിലും കാണാനുള്ള സൂചികയാണ് എക്സ് 100 എക്സ് മൈനസ് ഒരു യഥാർത്ഥ വിലാസം.
            //
            // സിസ്റ്റം ലോഡുചെയ്ത ലൈബ്രറികൾക്ക് ഈ കണക്കുകൂട്ടലുകൾ തെറ്റാണെന്ന് ഇത് മാറുന്നു.എന്നിരുന്നാലും, നേറ്റീവ് എക്സിക്യൂട്ടബിളുകൾക്ക് ഇത് ശരിയാണെന്ന് തോന്നുന്നു.
            // എൽ‌എൽ‌ഡി‌ബിയുടെ ഉറവിടത്തിൽ‌നിന്നും ചില ലോജിക്കുകൾ‌ഉയർ‌ത്തുന്നത്, ഫയൽ‌ഓഫ്‌സെറ്റ് 0 ൽ‌നിന്നും ലോഡുചെയ്ത ആദ്യത്തെ എക്സ് 100 എക്സ് വിഭാഗത്തിന് ചില പ്രത്യേക കേസിംഗ് ഉണ്ട്.
            // ഇത് ഉള്ളപ്പോൾ ഒരു കാരണവശാലും ചിഹ്ന പട്ടിക ലൈബ്രറിയുടെ vmaddr സ്ലൈഡിന് ആപേക്ഷികമാണെന്ന് അർത്ഥമാക്കുന്നു.
            // ഇത് * നിലവിലില്ലെങ്കിൽ, ചിഹ്ന പട്ടിക vmaddr സ്ലൈഡിനും സെഗ്‌മെന്റിന്റെ പ്രഖ്യാപിത വിലാസത്തിനും ആപേക്ഷികമാണ്.
            //
            // ഫയൽ ഓഫ്‌സെറ്റ് പൂജ്യത്തിൽ ഒരു ടെക്സ്റ്റ് വിഭാഗം ഞങ്ങൾ കണ്ടെത്തിയില്ലെങ്കിൽ ഈ സാഹചര്യം കൈകാര്യം ചെയ്യുന്നതിന്, ആദ്യത്തെ ടെക്സ്റ്റ് വിഭാഗങ്ങളുടെ പ്രഖ്യാപിത വിലാസം ഉപയോഗിച്ച് ഞങ്ങൾ പക്ഷപാതം വർദ്ധിപ്പിക്കുകയും പ്രസ്താവിച്ച എല്ലാ വിലാസങ്ങളും ആ അളവിൽ കുറയ്ക്കുകയും ചെയ്യും.
            //
            // അതുവഴി ലൈബ്രറിയുടെ ബയസ് തുകയുമായി താരതമ്യപ്പെടുത്തുമ്പോൾ ചിഹ്ന പട്ടിക എല്ലായ്പ്പോഴും ദൃശ്യമാകും.
            // ചിഹ്ന പട്ടിക വഴി പ്രതീകപ്പെടുത്തുന്നതിന് ഇത് ശരിയായ ഫലങ്ങൾ ഉള്ളതായി തോന്നുന്നു.
            //
            // സത്യസന്ധമായി ഇത് ശരിയാണോ അതോ ഇത് എങ്ങനെ ചെയ്യണമെന്ന് സൂചിപ്പിക്കുന്ന മറ്റെന്തെങ്കിലും ഉണ്ടോ എന്ന് എനിക്ക് പൂർണ്ണമായും ഉറപ്പില്ല.
            // ഇപ്പോൾ ഇത് മതിയായ (?) നന്നായി പ്രവർത്തിക്കുന്നുവെന്ന് തോന്നുന്നുവെങ്കിലും ആവശ്യമെങ്കിൽ കാലക്രമേണ ഇത് മാറ്റാൻ ഞങ്ങൾക്ക് എല്ലായ്പ്പോഴും കഴിയണം.
            //
            // കൂടുതൽ വിവരങ്ങൾക്ക് #318 കാണുക
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // മറ്റ് Unix (ഉദാ
        // ലിനക്സ്) പ്ലാറ്റ്‌ഫോമുകൾ ELF ഒരു ഒബ്‌ജക്റ്റ് ഫയൽ ഫോർമാറ്റായി ഉപയോഗിക്കുന്നു, കൂടാതെ നേറ്റീവ് ലൈബ്രറികൾ ലോഡുചെയ്യുന്നതിന് `dl_iterate_phdr` എന്ന API നടപ്പിലാക്കുകയും ചെയ്യുന്നു.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` സാധുവായ പോയിന്ററുകൾ ആയിരിക്കണം.
        // `vec` ഒരു `std::Vec`-ലേക്ക് സാധുവായ പോയിന്റർ ആയിരിക്കണം.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 ഡീബഗ് വിവരത്തെ നേറ്റീവ് ആയി പിന്തുണയ്‌ക്കുന്നില്ല, പക്ഷേ ബിൽഡ് സിസ്റ്റം ഡീബഗ് വിവരങ്ങൾ `romfs:/debug_info.elf` പാതയിൽ സ്ഥാപിക്കും.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // മറ്റെല്ലാം ELF ഉപയോഗിക്കണം, പക്ഷേ നേറ്റീവ് ലൈബ്രറികൾ എങ്ങനെ ലോഡുചെയ്യണമെന്ന് അറിയില്ല.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// ലോഡുചെയ്ത അറിയപ്പെടുന്ന എല്ലാ പങ്കിട്ട ലൈബ്രറികളും.
    libraries: Vec<Library>,

    /// പാഴ്‌സുചെയ്‌ത കുള്ളൻ വിവരങ്ങൾ ഞങ്ങൾ സൂക്ഷിക്കുന്ന മാപ്പിംഗ് കാഷെ.
    ///
    /// ഈ ലിസ്റ്റിന് അതിന്റെ മുഴുവൻ ലിഫ്റ്റൈമിനും ഒരു നിശ്ചിത ശേഷി ഉണ്ട്, അത് ഒരിക്കലും വർദ്ധിക്കുന്നില്ല.
    /// ഓരോ ജോഡിയുടെയും `usize` ഘടകം `libraries`-ന് മുകളിലുള്ള ഒരു സൂചികയാണ്, അവിടെ `usize::max_value()` നിലവിലെ എക്സിക്യൂട്ടബിളിനെ പ്രതിനിധീകരിക്കുന്നു.
    ///
    /// പാഴ്‌സുചെയ്‌ത കുള്ളൻ വിവരങ്ങളുമായി ബന്ധപ്പെട്ടതാണ് `Mapping`.
    ///
    /// ഇത് അടിസ്ഥാനപരമായി ഒരു എൽ‌ആർ‌യു കാഷെ ആണെന്നും ഞങ്ങൾ വിലാസങ്ങളെ പ്രതീകപ്പെടുത്തുമ്പോൾ ഞങ്ങൾ ഇവിടെ കാര്യങ്ങൾ മാറ്റുകയാണെന്നും ശ്രദ്ധിക്കുക.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// ഈ ലൈബ്രറിയുടെ സെഗ്‌മെന്റുകൾ മെമ്മറിയിലേക്ക് ലോഡുചെയ്‌തു, അവ എവിടെയാണ് ലോഡുചെയ്യുന്നത്.
    segments: Vec<LibrarySegment>,
    /// ഈ ലൈബ്രറിയുടെ "bias", സാധാരണയായി മെമ്മറിയിലേക്ക് ലോഡുചെയ്യുന്നിടത്ത്.
    /// സെഗ്‌മെന്റിലേക്ക് ലോഡുചെയ്‌ത യഥാർത്ഥ വെർച്വൽ മെമ്മറി വിലാസം ലഭിക്കുന്നതിന് ഓരോ സെഗ്‌മെന്റിന്റെയും പ്രഖ്യാപിത വിലാസത്തിലേക്ക് ഈ മൂല്യം ചേർത്തു.
    /// കൂടാതെ, ഈ ബയസ് യഥാർത്ഥ വെർച്വൽ മെമ്മറി വിലാസങ്ങളിൽ നിന്ന് ഇൻഡെക്സിലേക്ക് ഡീബഗ്ഗിൻഫോയിലേക്കും ചിഹ്ന പട്ടികയിലേക്കും കുറയ്ക്കുന്നു.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// ഒബ്‌ജക്റ്റ് ഫയലിലെ ഈ സെഗ്‌മെന്റിന്റെ പ്രഖ്യാപിത വിലാസം.
    /// ഇത് യഥാർത്ഥത്തിൽ സെഗ്മെന്റ് ലോഡുചെയ്ത സ്ഥലമല്ല, മറിച്ച് ഈ വിലാസവും അടങ്ങിയിരിക്കുന്ന ലൈബ്രറിയുടെ `bias` ഉം എവിടെയാണ് അത് കണ്ടെത്തേണ്ടത്.
    ///
    stated_virtual_memory_address: usize,
    /// മെമ്മറിയിലെ ths സെഗ്‌മെന്റിന്റെ വലുപ്പം.
    len: usize,
}

// സുരക്ഷിതമല്ലാത്തതിനാൽ ഇത് ബാഹ്യമായി സമന്വയിപ്പിക്കേണ്ടതുണ്ട്
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // സുരക്ഷിതമല്ലാത്തതിനാൽ ഇത് ബാഹ്യമായി സമന്വയിപ്പിക്കേണ്ടതുണ്ട്
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // ഡീബഗ് വിവര മാപ്പിംഗിനായി വളരെ ചെറുതും ലളിതവുമായ എൽ‌ആർ‌യു കാഷെ.
        //
        // പങ്കിട്ട നിരവധി ലൈബ്രറികൾക്കിടയിൽ സാധാരണ സ്റ്റാക്ക് കടക്കാത്തതിനാൽ ഹിറ്റ് നിരക്ക് വളരെ ഉയർന്നതായിരിക്കണം.
        //
        // `addr2line::Context` ഘടനകൾ സൃഷ്ടിക്കാൻ വളരെ ചെലവേറിയതാണ്.
        // മികച്ച സ്പീഡ്അപ്പുകൾ ലഭിക്കുന്നതിന് `addr2line: : സന്ദർഭം` നിർമ്മിക്കുമ്പോൾ നിർമ്മിച്ച ഘടനകളെ സ്വാധീനിക്കുന്ന തുടർന്നുള്ള `locate` അന്വേഷണങ്ങൾ വഴി ഇതിന്റെ ചെലവ് പലിശ പ്രതീക്ഷിക്കുന്നു.
        //
        // ഞങ്ങൾക്ക് ഈ കാഷെ ഇല്ലായിരുന്നുവെങ്കിൽ, ആ കടം വീട്ടൽ ഒരിക്കലും സംഭവിക്കില്ല, കൂടാതെ ബാക്ക്‌ട്രേസുകളെ പ്രതീകപ്പെടുത്തുന്നത് ssssllllooooowwww ആയിരിക്കും.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // ആദ്യം, ഈ `lib` ന് `addr` (പുന oc സ്ഥാപിക്കൽ കൈകാര്യം ചെയ്യൽ) അടങ്ങിയിരിക്കുന്ന ഏതെങ്കിലും സെഗ്മെന്റ് ഉണ്ടോയെന്ന് പരിശോധിക്കുക.ഈ പരിശോധന കടന്നുപോകുകയാണെങ്കിൽ, ഞങ്ങൾക്ക് ചുവടെ തുടരാനും വിലാസം വിവർത്തനം ചെയ്യാനും കഴിയും.
                //
                // ഓവർഫ്ലോ പരിശോധനകൾ ഒഴിവാക്കാൻ ഞങ്ങൾ ഇവിടെ `wrapping_add` ഉപയോഗിക്കുന്നുവെന്നത് ശ്രദ്ധിക്കുക.എസ്‌വി‌എം‌എ + ബയസ് കണക്കുകൂട്ടൽ കവിഞ്ഞൊഴുകുന്നത് കാട്ടിൽ കാണാം.
                // ഇത് സംഭവിക്കുന്നത് അൽപ്പം വിചിത്രമായി തോന്നുന്നു, പക്ഷേ ബഹിരാകാശത്തേക്ക് പോയിന്റുചെയ്യാൻ സാധ്യതയുള്ളതിനാൽ ആ സെഗ്‌മെന്റുകളെ അവഗണിക്കുകയല്ലാതെ ഞങ്ങൾക്ക് ഇതിനെക്കുറിച്ച് വലിയൊരു തുകയുമില്ല.
                //
                // ഇത് ആദ്യം വന്നത് rust-lang/backtrace-rs#329-ലാണ്.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // `lib`-ൽ `addr` അടങ്ങിയിരിക്കുന്നുവെന്ന് ഇപ്പോൾ നമുക്കറിയാം, പ്രസ്താവിച്ച വൈറൽ മെമ്മറി വിലാസം കണ്ടെത്തുന്നതിന് പക്ഷപാതിത്വം ഉപയോഗിച്ച് നമുക്ക് ഓഫ്സെറ്റ് ചെയ്യാം.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // മാറ്റമില്ലാത്തത്: നേരത്തേ മടങ്ങിവരാതെ ഈ നിബന്ധന പൂർത്തിയാക്കിയ ശേഷം
        // ഒരു പിശകിൽ നിന്ന്, ഈ പാതയ്ക്കുള്ള കാഷെ എൻ‌ട്രി സൂചിക 0 ലാണ്.

        if let Some(idx) = idx {
            // മാപ്പിംഗ് ഇതിനകം കാഷെയിലായിരിക്കുമ്പോൾ, അത് മുന്നിലേക്ക് നീക്കുക.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // മാപ്പിംഗ് കാഷെയിലില്ലാത്തപ്പോൾ, ഒരു പുതിയ മാപ്പിംഗ് സൃഷ്ടിക്കുക, കാഷെയുടെ മുൻഭാഗത്ത് തിരുകുക, ആവശ്യമെങ്കിൽ ഏറ്റവും പഴയ കാഷെ എൻട്രി ഒഴിക്കുക.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // `'static` ആജീവനാന്തം ചോർത്തരുത്, ഇത് നമ്മുടേതാണെന്ന് സ്കോപ്പ് ചെയ്തിട്ടുണ്ടെന്ന് ഉറപ്പാക്കുക
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // നിർഭാഗ്യവശാൽ ഞങ്ങൾക്ക് ഇവിടെ ആവശ്യമുള്ളതിനാൽ `sym`-ന്റെ ആയുസ്സ് `'static` ലേക്ക് നീട്ടുക, പക്ഷേ ഇത് ഒരു റഫറൻസായി പുറത്തേക്ക് പോകുന്നു, അതിനാൽ ഇതിനെക്കുറിച്ചുള്ള ഒരു റഫറൻസും ഈ ഫ്രെയിമിനപ്പുറം നിലനിൽക്കരുത്.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // അവസാനമായി, ഒരു കാഷെ ചെയ്‌ത മാപ്പിംഗ് നേടുക അല്ലെങ്കിൽ ഈ ഫയലിനായി ഒരു പുതിയ മാപ്പിംഗ് സൃഷ്‌ടിക്കുക, കൂടാതെ ഈ വിലാസത്തിനായി file/line/name കണ്ടെത്തുന്നതിന് DWARF വിവരങ്ങൾ വിലയിരുത്തുക.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// ഈ ചിഹ്നത്തിനായുള്ള ഫ്രെയിം വിവരങ്ങൾ‌കണ്ടെത്താൻ‌ഞങ്ങൾ‌ക്ക് കഴിഞ്ഞു, കൂടാതെ `addr2line` ന്റെ ഫ്രെയിമിന് ആന്തരികമായി എല്ലാ നഗ്നമായ വിശദാംശങ്ങളും ഉണ്ട്.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// ഡീബഗ് വിവരങ്ങൾ കണ്ടെത്താനായില്ല, പക്ഷേ ഞങ്ങൾ അത് എക്സിക്യൂട്ടബിൾ ചിഹ്ന പട്ടികയിൽ കണ്ടെത്തി.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}