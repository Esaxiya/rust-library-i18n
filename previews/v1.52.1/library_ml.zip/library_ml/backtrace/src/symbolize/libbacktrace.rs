//! ലിബ്ബാക്ക്ട്രെയ്‌സിലെ DWARF-പാഴ്‌സിംഗ് കോഡ് ഉപയോഗിക്കുന്ന പ്രതീകാത്മക തന്ത്രം.
//!
//! സാധാരണയായി gcc ഉപയോഗിച്ച് വിതരണം ചെയ്യുന്ന ലിബ്ബാക്ക്ട്രേസ് സി ലൈബ്രറി ഒരു ബാക്ക്ട്രേസ് സൃഷ്ടിക്കുന്നതിനെ (ഞങ്ങൾ യഥാർത്ഥത്തിൽ ഉപയോഗിക്കാത്തവ) മാത്രമല്ല, ബാക്ക്ട്രേസ് പ്രതീകപ്പെടുത്തുന്നതിനും ഇൻലൈൻ ഫ്രെയിമുകൾ, വാട്ട്നോട്ട് എന്നിവപോലുള്ള കാര്യങ്ങളെക്കുറിച്ചുള്ള കുള്ളൻ ഡീബഗ് വിവരങ്ങൾ കൈകാര്യം ചെയ്യുന്നതിനും പിന്തുണയ്ക്കുന്നു.
//!
//!
//! ഇവിടെ നിരവധി ആശങ്കകൾ കാരണം ഇത് താരതമ്യേന സങ്കീർണ്ണമാണ്, പക്ഷേ അടിസ്ഥാന ആശയം ഇതാണ്:
//!
//! * ആദ്യം നമ്മൾ `backtrace_syminfo` എന്ന് വിളിക്കുന്നു.ഞങ്ങൾക്ക് കഴിയുമെങ്കിൽ ഇത് ഡൈനാമിക് ചിഹ്ന പട്ടികയിൽ നിന്ന് ചിഹ്ന വിവരങ്ങൾ നേടുന്നു.
//! * അടുത്തതായി ഞങ്ങൾ `backtrace_pcinfo` എന്ന് വിളിക്കുന്നു.ഡീബഗ്ഗിൻ‌ഫോ പട്ടികകൾ‌ലഭ്യമാണെങ്കിൽ‌ഇത് പാഴ്‌സുചെയ്യുകയും ഇൻ‌ലൈൻ‌ഫ്രെയിമുകൾ‌, ഫയൽ‌നാമങ്ങൾ‌, ലൈൻ‌നമ്പറുകൾ‌മുതലായവയെക്കുറിച്ചുള്ള വിവരങ്ങൾ‌വീണ്ടെടുക്കാൻ ഞങ്ങളെ അനുവദിക്കുകയും ചെയ്യും.
//!
//! കുള്ളൻ പട്ടികകളെ ലിബ്ബാക്ക്ട്രേസിലേക്ക് കൊണ്ടുവരുന്നതിനെക്കുറിച്ച് ധാരാളം തന്ത്രങ്ങളുണ്ട്, പക്ഷേ ഇത് ലോകാവസാനമല്ലെന്നും ചുവടെ വായിക്കുമ്പോൾ അത് വ്യക്തമാകുമെന്നും പ്രതീക്ഷിക്കുന്നു.
//!
//! MSVC ഇതര, OSX ഇതര പ്ലാറ്റ്ഫോമുകൾക്കായുള്ള സ്ഥിരസ്ഥിതി പ്രതീകാത്മക തന്ത്രമാണിത്.ലിബ്‌സ്റ്റഡിൽ ഇത് ഒ‌എസ്‌എക്‌സിനായുള്ള സ്ഥിരസ്ഥിതി തന്ത്രമാണ്.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // സാധ്യമെങ്കിൽ ഡീബഗ്ഗിൻ‌ഫോയിൽ‌നിന്നുമുള്ള `function` നാമം തിരഞ്ഞെടുക്കുക, ഉദാഹരണത്തിന് ഇൻ‌ലൈൻ‌ഫ്രെയിമുകൾ‌ക്ക് കൂടുതൽ‌കൃത്യതയുണ്ട്.
                // അത് നിലവിലില്ലെങ്കിൽ `symname`-ൽ വ്യക്തമാക്കിയ ചിഹ്ന പട്ടിക നാമത്തിലേക്ക് മടങ്ങുക.
                //
                // ചില സമയങ്ങളിൽ `function` ന് കുറച്ചുകൂടി കൃത്യത അനുഭവപ്പെടാമെന്നത് ശ്രദ്ധിക്കുക, ഉദാഹരണത്തിന് X002 ന്റെ `try<i32,closure>` isntead എന്ന് ലിസ്റ്റുചെയ്യുന്നു.
                //
                // എന്തുകൊണ്ടെന്ന് ശരിക്കും വ്യക്തമല്ല, പക്ഷേ മൊത്തത്തിൽ `function` പേര് കൂടുതൽ കൃത്യമാണെന്ന് തോന്നുന്നു.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // ഇപ്പോൾ ഒന്നും ചെയ്യരുത്
}

/// `data` പോയിന്ററിന്റെ തരം `syminfo_cb`-ലേക്ക് കൈമാറി
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // പരിഹരിക്കാൻ ആരംഭിക്കുമ്പോൾ `backtrace_syminfo`-ൽ നിന്ന് ഈ കോൾബാക്ക് അഭ്യർത്ഥിച്ചുകഴിഞ്ഞാൽ ഞങ്ങൾ `backtrace_pcinfo`-ലേക്ക് വിളിക്കാൻ കൂടുതൽ പോകും.
    // എക്സ് 00 എക്സ് ഫംഗ്ഷൻ ഡീബഗ് വിവരങ്ങൾ പരിശോധിക്കുകയും എക്സ് 01 എക്സ് വിവരങ്ങളും ഇൻ‌ലൈൻ ഫ്രെയിമുകളും വീണ്ടെടുക്കുക പോലുള്ള കാര്യങ്ങൾ ചെയ്യാൻ ശ്രമിക്കുകയും ചെയ്യും.
    // ഡീബഗ് വിവരങ്ങൾ ഇല്ലെങ്കിൽ `backtrace_pcinfo` പരാജയപ്പെടാം അല്ലെങ്കിൽ കൂടുതൽ ചെയ്യാൻ കഴിയില്ലെന്നത് ശ്രദ്ധിക്കുക, അതിനാൽ അങ്ങനെ സംഭവിക്കുകയാണെങ്കിൽ `syminfo_cb`-ൽ നിന്ന് കുറഞ്ഞത് ഒരു ചിഹ്നമെങ്കിലും കോൾബാക്ക് വിളിക്കുമെന്ന് ഞങ്ങൾക്ക് ഉറപ്പുണ്ട്.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// `data` പോയിന്ററിന്റെ തരം `pcinfo_cb`-ലേക്ക് കൈമാറി
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// ഒരു സംസ്ഥാനം സൃഷ്ടിക്കുന്നതിനെ ലിബ്ബാക്ക്ട്രേസ് API പിന്തുണയ്ക്കുന്നു, പക്ഷേ ഇത് ഒരു സംസ്ഥാനത്തെ നശിപ്പിക്കുന്നതിനെ പിന്തുണയ്ക്കുന്നില്ല.
// ഞാൻ വ്യക്തിപരമായി ഇത് എടുക്കുന്നത് ഒരു സംസ്ഥാനം സൃഷ്ടിക്കപ്പെടാനും പിന്നീട് എന്നേക്കും ജീവിക്കാനുമാണ്.
//
// ഈ അവസ്ഥയെ ശുദ്ധീകരിക്കുന്ന ഒരു at_exit() ഹാൻഡ്‌ലർ രജിസ്റ്റർ ചെയ്യാൻ ഞാൻ ആഗ്രഹിക്കുന്നു, പക്ഷേ ലിബ്ബാക്ക്ട്രേസ് അതിനുള്ള ഒരു മാർഗ്ഗവും നൽകുന്നില്ല.
//
// ഈ പരിമിതികൾക്കൊപ്പം, ഈ ഫംഗ്ഷന് സ്റ്റാറ്റിക്ക് കാഷെ ചെയ്ത അവസ്ഥയുണ്ട്, ഇത് ആദ്യമായി അഭ്യർത്ഥിക്കുമ്പോൾ കണക്കാക്കുന്നു.
//
// എല്ലാം ബാക്ക്‌ട്രേസിംഗ് ചെയ്യുന്നത് സീരിയലായി സംഭവിക്കുന്നു (ഒരു ആഗോള ലോക്ക്).
//
// `resolve` ബാഹ്യമായി സമന്വയിപ്പിക്കേണ്ട ആവശ്യകത മൂലമാണ് ഇവിടെ സമന്വയത്തിന്റെ അഭാവം.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // ലിബ്ബാക്ക്ട്രേസിന്റെ ത്രെഡ് സേഫ് കഴിവുകൾ ഞങ്ങൾ എല്ലായ്പ്പോഴും സമന്വയിപ്പിച്ച രീതിയിലാണ് വിളിക്കുന്നത്.
        //
        0,
        error_cb,
        ptr::null_mut(), // അധിക ഡാറ്റയൊന്നുമില്ല
    );

    return STATE;

    // ലിബ്ബാക്ക്ട്രേസ് പ്രവർത്തിക്കുന്നതിന് നിലവിലുള്ള എക്സിക്യൂട്ടബിളിനായി DWARF ഡീബഗ് വിവരങ്ങൾ കണ്ടെത്തേണ്ടതുണ്ട്.ഇനിപ്പറയുന്നവ ഉൾപ്പെടെ നിരവധി സംവിധാനങ്ങളിലൂടെ ഇത് സാധാരണ ചെയ്യുന്നു:
    //
    // * /proc/self/exe പിന്തുണയ്‌ക്കുന്ന പ്ലാറ്റ്ഫോമുകളിൽ
    // * സ്റ്റേറ്റ് സൃഷ്ടിക്കുമ്പോൾ ഫയൽ നാമം വ്യക്തമായി കടന്നുപോയി
    //
    // സി കോഡിന്റെ വലിയൊരു ഭാഗമാണ് ലിബ്ബാക്ക്ട്രേസ് ലൈബ്രറി.ഇത് സ്വാഭാവികമായും അർത്ഥമാക്കുന്നത് ഇതിന് മെമ്മറി സുരക്ഷാ കേടുപാടുകൾ ഉണ്ട്, പ്രത്യേകിച്ചും കേടായ ഡീബഗ്ഗിൻഫോ കൈകാര്യം ചെയ്യുമ്പോൾ.
    // ചരിത്രപരമായി ഇവയിൽ ധാരാളം ലിബ്സ്റ്റ് പ്രവർത്തിച്ചിട്ടുണ്ട്.
    //
    // /proc/self/exe ഉപയോഗിച്ചിട്ടുണ്ടെങ്കിൽ, ലിബ്ബാക്ക്ട്രേസ് "mostly correct" ആണെന്നും "attempted to be correct" കുള്ളൻ ഡീബഗ് വിവരങ്ങൾ ഉപയോഗിച്ച് വിചിത്രമായ കാര്യങ്ങൾ ചെയ്യുന്നില്ലെന്നും കരുതുന്നതിനാൽ നമുക്ക് ഇവ അവഗണിക്കാം.
    //
    //
    // എന്നിരുന്നാലും, ഞങ്ങൾ ഒരു ഫയൽ നാമത്തിൽ കടന്നുപോകുകയാണെങ്കിൽ, ചില പ്ലാറ്റ്ഫോമുകളിൽ (ബിഎസ്ഡി പോലുള്ളവ) ഇത് സാധ്യമാണ്, അവിടെ ഒരു ക്ഷുദ്ര നടന് ആ സ്ഥലത്ത് അനിയന്ത്രിതമായ ഫയൽ സ്ഥാപിക്കാൻ കഴിയും.
    // ഇതിനർത്ഥം, ഞങ്ങൾ ഒരു ഫയലിന്റെ പേരിനെക്കുറിച്ച് ലിബ്ബാക്ക്ട്രെയ്‌സിനോട് പറഞ്ഞാൽ അത് അനിയന്ത്രിതമായ ഫയൽ ഉപയോഗിച്ചിരിക്കാം, ഇത് സെഗ്‌ഫോൾട്ടുകൾക്ക് കാരണമാകാം.
    // ഞങ്ങൾ ലിബ്ബാക്ക്ട്രെയ്‌സിനോട് ഒന്നും പറയുന്നില്ലെങ്കിൽ, /proc/self/exe പോലുള്ള പാതകളെ പിന്തുണയ്‌ക്കാത്ത പ്ലാറ്റ്ഫോമുകളിൽ ഇത് ഒന്നും ചെയ്യില്ല!
    //
    // ഒരു ഫയൽ നാമത്തിൽ * കടന്നുപോകാതിരിക്കാൻ ഞങ്ങൾ പരമാവധി ശ്രമിക്കുന്നതെല്ലാം കണക്കിലെടുക്കുമ്പോൾ, /proc/self/exe-നെ പിന്തുണയ്‌ക്കാത്ത പ്ലാറ്റ്ഫോമുകളിൽ ഞങ്ങൾ ഉണ്ടായിരിക്കണം.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // ഞങ്ങൾ `std::env::current_exe` ഉപയോഗിക്കുമെന്നത് ശ്രദ്ധിക്കുക, പക്ഷേ ഞങ്ങൾക്ക് ഇവിടെ `std` ആവശ്യമില്ല.
            //
            // നിലവിലെ എക്സിക്യൂട്ടബിൾ പാത്ത് ഒരു സ്റ്റാറ്റിക് ഏരിയയിലേക്ക് ലോഡുചെയ്യാൻ `_NSGetExecutablePath` ഉപയോഗിക്കുക (ഇത് വളരെ ചെറുതാണെങ്കിൽ ഉപേക്ഷിക്കുക).
            //
            //
            // അഴിമതി നിറഞ്ഞ എക്സിക്യൂട്ടബിളുകളിൽ മരിക്കാതിരിക്കാൻ ഞങ്ങൾ ഇവിടെ ലിബ്ബാക്ക്ട്രെയ്‌സിനെ ഗൗരവമായി വിശ്വസിക്കുന്നുവെന്നത് ശ്രദ്ധിക്കുക, പക്ഷേ ഇത് തീർച്ചയായും ചെയ്യും ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows ഫയലുകൾ തുറക്കുന്ന ഒരു മോഡ് ഉണ്ട്, അത് തുറന്നതിനുശേഷം അത് ഇല്ലാതാക്കാൻ കഴിയില്ല.
            // പൊതുവെ ഞങ്ങൾക്ക് ഇവിടെ വേണ്ടത് കാരണം ലിബ്ബാക്ക്ട്രെയ്‌സിന് കൈമാറിയതിന് ശേഷം ഞങ്ങളുടെ എക്സിക്യൂട്ടബിൾ ഞങ്ങളുടെ കീഴിൽ നിന്ന് മാറുന്നില്ലെന്ന് ഉറപ്പാക്കാൻ ഞങ്ങൾ ആഗ്രഹിക്കുന്നു, അനിയന്ത്രിതമായ ഡാറ്റയെ ലിബ്ബാക്ക്ട്രെയ്‌സിലേക്ക് കൈമാറാനുള്ള കഴിവ് ലഘൂകരിക്കുന്നു (ഇത് തെറ്റായി കൈകാര്യം ചെയ്യപ്പെടാം).
            //
            //
            // ഞങ്ങളുടെ സ്വന്തം ഇമേജിൽ‌ഒരു തരം ലോക്ക് നേടാൻ‌ഞങ്ങൾ‌ഇവിടെ ഒരു നൃത്തം ചെയ്യുന്നു:
            //
            // * നിലവിലെ പ്രക്രിയയിലേക്ക് ഒരു ഹാൻഡിൽ നേടുക, അതിന്റെ ഫയൽ നാമം ലോഡുചെയ്യുക.
            // * വലത് ഫ്ലാഗുകൾ ഉപയോഗിച്ച് ആ ഫയൽ നാമത്തിലേക്ക് ഒരു ഫയൽ തുറക്കുക.
            // * നിലവിലെ പ്രോസസിന്റെ ഫയൽ നാമം വീണ്ടും ലോഡുചെയ്യുക, ഇത് സമാനമാണെന്ന് ഉറപ്പാക്കുക
            //
            // സിദ്ധാന്തത്തിൽ നമ്മൾ കടന്നുപോകുന്ന എല്ലാ പാസുകളും ഞങ്ങളുടെ പ്രോസസിന്റെ ഫയൽ തുറന്നിട്ടുണ്ടെങ്കിൽ അത് മാറില്ലെന്ന് ഞങ്ങൾക്ക് ഉറപ്പുണ്ട്.FWIW ഇതിന്റെ ഒരു കൂട്ടം ചരിത്രപരമായി libstd-ൽ നിന്ന് പകർത്തി, അതിനാൽ എന്താണ് സംഭവിക്കുന്നതെന്നതിനെക്കുറിച്ചുള്ള എന്റെ മികച്ച വ്യാഖ്യാനമാണിത്.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // ഇത് സ്റ്റാറ്റിക് മെമ്മറിയിൽ ജീവിക്കുന്നതിനാൽ ഞങ്ങൾക്ക് അത് തിരികെ നൽകാം ..
                static mut BUF: [i8; N] = [0; N];
                // ... ഇത് താൽക്കാലികമായതിനാൽ ഇത് സ്റ്റാക്കിൽ ജീവിക്കുന്നു
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // മന open പൂർവ്വം ഇവിടെ `handle` ചോർത്തുക, കാരണം അത് തുറന്നിരിക്കുന്നത് ഈ ഫയലിന്റെ പേരിലുള്ള ഞങ്ങളുടെ ലോക്ക് സംരക്ഷിക്കും.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // അവസാനിപ്പിച്ച ഒരു സ്ലൈസ് മടക്കിനൽകാൻ ഞങ്ങൾ ആഗ്രഹിക്കുന്നു, അതിനാൽ എല്ലാം പൂരിപ്പിച്ച് അത് മൊത്തം നീളത്തിന് തുല്യമാണെങ്കിൽ അത് പരാജയത്തിന് തുല്യമാക്കുക.
                //
                //
                // അല്ലെങ്കിൽ വിജയം തിരികെ നൽകുമ്പോൾ സ്ലൈസിൽ നൾ ബൈറ്റ് ഉൾപ്പെടുത്തിയിട്ടുണ്ടെന്ന് ഉറപ്പാക്കുക.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // ബാക്ക്‌ട്രേസ് പിശകുകൾ‌നിലവിൽ‌റഗിന്‌കീഴിലാണ്
    let state = init_state();
    if state.is_null() {
        return;
    }

    // (കോഡ് വായിക്കുന്നതിൽ നിന്ന്) `syminfo_cb` നെ കൃത്യമായി ഒരു തവണ വിളിക്കേണ്ട `backtrace_syminfo` API-ലേക്ക് വിളിക്കുക (അല്ലെങ്കിൽ ഒരു പിശകിനൊപ്പം പരാജയപ്പെടാം).
    // `syminfo_cb`-നുള്ളിൽ ഞങ്ങൾ കൂടുതൽ കൈകാര്യം ചെയ്യുന്നു.
    //
    // ബൈനറിയിൽ ഡീബഗ് വിവരങ്ങളൊന്നുമില്ലെങ്കിൽ പോലും `syminfo` ചിഹ്ന പട്ടിക പരിശോധിച്ച് ചിഹ്ന നാമങ്ങൾ കണ്ടെത്തുന്നതിനാൽ ഞങ്ങൾ ഇത് ചെയ്യുന്നു.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}