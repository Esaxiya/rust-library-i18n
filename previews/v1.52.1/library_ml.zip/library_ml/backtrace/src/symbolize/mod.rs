use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// നിർദ്ദിഷ്ട അടയ്‌ക്കലിലേക്ക് ചിഹ്നം കൈമാറിക്കൊണ്ട് ഒരു ചിഹ്നത്തിലേക്ക് ഒരു വിലാസം പരിഹരിക്കുക.
///
/// വിളവെടുക്കാനുള്ള ചിഹ്നങ്ങൾ കണ്ടെത്തുന്നതിന് പ്രാദേശിക ചിഹ്ന പട്ടിക, ഡൈനാമിക് ചിഹ്ന പട്ടിക അല്ലെങ്കിൽ DWARF ഡീബഗ് വിവരങ്ങൾ (സജീവമാക്കിയ നടപ്പാക്കലിനെ ആശ്രയിച്ച്) പോലുള്ള മേഖലകളിൽ ഈ ഫംഗ്ഷൻ നൽകിയ വിലാസം നോക്കും.
///
///
/// മിഴിവ് നടപ്പിലാക്കാൻ കഴിയുന്നില്ലെങ്കിൽ അടയ്ക്കൽ വിളിക്കപ്പെടില്ല, മാത്രമല്ല ഇൻ‌ലൈൻ ചെയ്ത ഫംഗ്ഷനുകളുടെ കാര്യത്തിലും ഇത് ഒന്നിലധികം തവണ വിളിക്കാം.
///
/// നൽകിയ ചിഹ്നങ്ങൾ നിർദ്ദിഷ്ട `addr`-ലെ എക്സിക്യൂഷനെ പ്രതിനിധീകരിക്കുന്നു, ആ വിലാസത്തിനായി file/line ജോഡികൾ നൽകുന്നു (ലഭ്യമെങ്കിൽ).
///
/// നിങ്ങൾക്ക് ഒരു `Frame` ഉണ്ടെങ്കിൽ, ഇതിന് പകരം `resolve_frame` ഫംഗ്ഷൻ ഉപയോഗിക്കാൻ ശുപാർശ ചെയ്യുന്നു.
///
/// # ആവശ്യമായ സവിശേഷതകൾ
///
/// ഈ ഫംഗ്ഷന് `backtrace` crate ന്റെ `std` സവിശേഷത പ്രാപ്തമാക്കേണ്ടതുണ്ട്, കൂടാതെ `std` സവിശേഷത സ്ഥിരസ്ഥിതിയായി പ്രാപ്തമാക്കുന്നു.
///
/// # Panics
///
/// ഈ ഫംഗ്ഷൻ ഒരിക്കലും panic ആയിരിക്കില്ല, പക്ഷേ `cb` panics നൽകിയിട്ടുണ്ടെങ്കിൽ, ചില പ്ലാറ്റ്ഫോമുകൾ ഈ പ്രക്രിയ നിർത്താൻ ഇരട്ട panic നെ നിർബന്ധിക്കും.
/// ചില പ്ലാറ്റ്‌ഫോമുകൾ ഒരു സി ലൈബ്രറി ഉപയോഗിക്കുന്നു, അത് ആന്തരികമായി കോൾബാക്കുകൾ ഉപയോഗിക്കാനാകില്ല, അതിനാൽ `cb`-ൽ നിന്ന് പരിഭ്രാന്തരാകുന്നത് ഒരു പ്രക്രിയ നിർത്തലാക്കും.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // മുകളിലെ ഫ്രെയിമിൽ മാത്രം നോക്കുക
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// മുമ്പത്തെ ക്യാപ്‌ചർ ഫ്രെയിം ഒരു ചിഹ്നത്തിലേക്ക് പരിഹരിക്കുക, ചിഹ്നം നിർദ്ദിഷ്ട ക്ലോസറിലേക്ക് കൈമാറുക.
///
/// ഒരു വിലാസത്തിനുപകരം ഒരു ആർ‌ഗ്യുമെൻറായി `Frame` എടുക്കുന്നു എന്നതൊഴിച്ചാൽ ഈ ഫങ്ക്‌റ്റിൻ `resolve`-ന്റെ അതേ പ്രവർത്തനം നിർവ്വഹിക്കുന്നു.
/// ബാക്ക്‌ട്രേസിംഗിന്റെ ചില പ്ലാറ്റ്ഫോം നടപ്പാക്കലുകൾക്ക് ഇത് കൂടുതൽ കൃത്യമായ ചിഹ്ന വിവരങ്ങളോ ഇൻലൈൻ ഫ്രെയിമുകളെക്കുറിച്ചുള്ള വിവരങ്ങളോ നൽകാൻ അനുവദിക്കുന്നു.
///
/// നിങ്ങൾക്ക് കഴിയുമെങ്കിൽ ഇത് ഉപയോഗിക്കാൻ ശുപാർശ ചെയ്യുന്നു.
///
/// # ആവശ്യമായ സവിശേഷതകൾ
///
/// ഈ ഫംഗ്ഷന് `backtrace` crate ന്റെ `std` സവിശേഷത പ്രാപ്തമാക്കേണ്ടതുണ്ട്, കൂടാതെ `std` സവിശേഷത സ്ഥിരസ്ഥിതിയായി പ്രാപ്തമാക്കുന്നു.
///
/// # Panics
///
/// ഈ ഫംഗ്ഷൻ ഒരിക്കലും panic ആയിരിക്കില്ല, പക്ഷേ `cb` panics നൽകിയിട്ടുണ്ടെങ്കിൽ, ചില പ്ലാറ്റ്ഫോമുകൾ ഈ പ്രക്രിയ നിർത്താൻ ഇരട്ട panic നെ നിർബന്ധിക്കും.
/// ചില പ്ലാറ്റ്‌ഫോമുകൾ ഒരു സി ലൈബ്രറി ഉപയോഗിക്കുന്നു, അത് ആന്തരികമായി കോൾബാക്കുകൾ ഉപയോഗിക്കാനാകില്ല, അതിനാൽ `cb`-ൽ നിന്ന് പരിഭ്രാന്തരാകുന്നത് ഒരു പ്രക്രിയ നിർത്തലാക്കും.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // മുകളിലെ ഫ്രെയിമിൽ മാത്രം നോക്കുക
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// സ്റ്റാക്ക് ഫ്രെയിമുകളിൽ നിന്നുള്ള ഐപി മൂല്യങ്ങൾ സാധാരണ സ്റ്റാക്ക് ട്രെയ്‌സ് ആയ കോളിന് ശേഷം *(always?) നിർദ്ദേശമാണ്*.
// ഇത് പ്രതീകപ്പെടുത്തുന്നത് filename/line നമ്പർ ഒന്നായി മുന്നേറുകയും ഫംഗ്ഷന്റെ അവസാനത്തോടടുക്കുകയാണെങ്കിൽ അത് അസാധുവാകുകയും ചെയ്യും.
//
// ഇത് അടിസ്ഥാനപരമായി എല്ലായ്‌പ്പോഴും എല്ലാ പ്ലാറ്റ്‌ഫോമുകളിലും ഉള്ളതായി തോന്നുന്നു, അതിനാൽ നിർദ്ദേശങ്ങൾ മടക്കിനൽകുന്നതിന് പകരം മുമ്പത്തെ കോൾ നിർദ്ദേശത്തിലേക്ക് പരിഹരിക്കുന്നതിന് ഞങ്ങൾ പരിഹരിച്ച ഐപിയിൽ നിന്ന് ഒരെണ്ണം കുറയ്ക്കുന്നു.
//
//
// ഞങ്ങൾ ഇത് ചെയ്യില്ല.
// നിലവിലുള്ളതിനേക്കാൾ *മുമ്പത്തെ* നിർദ്ദേശത്തിനായി ലൊക്കേഷൻ വിവരങ്ങൾ വേണമെന്ന് -1-ഉം അക്കൗണ്ടും സ്വമേധയാ ചെയ്യാൻ ഇവിടെ `resolve` API-കളുടെ കോളർമാർ ആവശ്യപ്പെടുന്നു.
// അടുത്ത നിർദ്ദേശത്തിന്റെ അല്ലെങ്കിൽ നിലവിലുള്ള വിലാസമാണെങ്കിൽ ഞങ്ങൾ `Frame`-ലും തുറന്നുകാട്ടും.
//
// ഇപ്പോൾ ഇത് വളരെ പ്രധാനപ്പെട്ട ഒരു കാര്യമാണെങ്കിലും ഞങ്ങൾ ആന്തരികമായി എല്ലായ്പ്പോഴും ഒന്ന് കുറയ്ക്കുന്നു.
// ഉപയോക്താക്കൾ പ്രവർത്തിക്കുകയും നല്ല ഫലങ്ങൾ നേടുകയും വേണം, അതിനാൽ ഞങ്ങൾ വേണ്ടത്ര നല്ലവരായിരിക്കണം.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// `resolve` പോലെ തന്നെ, സമന്വയിപ്പിക്കാത്തതിനാൽ സുരക്ഷിതമല്ലാത്തത് മാത്രം.
///
/// ഈ ഫംഗ്ഷന് സമന്വയ ഗ്യാരന്റികളില്ല, പക്ഷേ ഈ crate ന്റെ `std` സവിശേഷത കംപൈൽ ചെയ്യാത്തപ്പോൾ ലഭ്യമാണ്.
/// കൂടുതൽ ഡോക്യുമെന്റേഷനും ഉദാഹരണങ്ങൾക്കുമായി `resolve` ഫംഗ്ഷൻ കാണുക.
///
/// # Panics
///
/// `cb` പരിഭ്രാന്തിയിലെ മുന്നറിയിപ്പുകൾക്കായി `resolve`-നെക്കുറിച്ചുള്ള വിവരങ്ങൾ കാണുക.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// `resolve_frame` പോലെ തന്നെ, സമന്വയിപ്പിക്കാത്തതിനാൽ സുരക്ഷിതമല്ലാത്തത് മാത്രം.
///
/// ഈ ഫംഗ്ഷന് സമന്വയ ഗ്യാരന്റികളില്ല, പക്ഷേ ഈ crate ന്റെ `std` സവിശേഷത കംപൈൽ ചെയ്യാത്തപ്പോൾ ലഭ്യമാണ്.
/// കൂടുതൽ ഡോക്യുമെന്റേഷനും ഉദാഹരണങ്ങൾക്കുമായി `resolve_frame` ഫംഗ്ഷൻ കാണുക.
///
/// # Panics
///
/// `cb` പരിഭ്രാന്തിയിലെ മുന്നറിയിപ്പുകൾക്കായി `resolve_frame`-നെക്കുറിച്ചുള്ള വിവരങ്ങൾ കാണുക.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// ഒരു ഫയലിലെ ചിഹ്നത്തിന്റെ മിഴിവ് പ്രതിനിധീകരിക്കുന്ന ഒരു trait.
///
/// ഈ trait, `backtrace::resolve` ഫംഗ്ഷന് നൽകിയിട്ടുള്ള ക്ലോസറിലേക്ക് ഒരു trait ഒബ്ജക്റ്റായി നൽകുന്നു, കൂടാതെ ഏത് നടപ്പാക്കലിന് പിന്നിലാണെന്ന് അറിയാത്തതിനാൽ ഇത് ഫലത്തിൽ അയയ്ക്കുന്നു.
///
///
/// ഒരു ചിഹ്നത്തിന് ഒരു ഫംഗ്ഷനെക്കുറിച്ച് സന്ദർഭോചിതമായ വിവരങ്ങൾ നൽകാൻ കഴിയും, ഉദാഹരണത്തിന് പേര്, ഫയൽ നാമം, ലൈൻ നമ്പർ, കൃത്യമായ വിലാസം മുതലായവ.
/// എല്ലാ വിവരങ്ങളും എല്ലായ്പ്പോഴും ഒരു ചിഹ്നത്തിൽ ലഭ്യമല്ല, അതിനാൽ എല്ലാ രീതികളും ഒരു `Option` നൽകുന്നു.
///
///
pub struct Symbol {
    // TODO: ഈ ആജീവനാന്ത പരിധി `Symbol`-ലേക്ക് തുടരേണ്ടതുണ്ട്,
    // എന്നാൽ ഇത് നിലവിൽ തകർപ്പൻ മാറ്റമാണ്.
    // `Symbol` എപ്പോഴെങ്കിലും റഫറൻസ് വഴി കൈമാറുന്നതിനാൽ ക്ലോൺ ചെയ്യാൻ കഴിയാത്തതിനാൽ ഇത് സുരക്ഷിതമാണ്.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// ഈ ഫംഗ്ഷന്റെ പേര് നൽകുന്നു.
    ///
    /// ചിഹ്നത്തിന്റെ പേരിനെക്കുറിച്ചുള്ള വിവിധ സവിശേഷതകൾ അന്വേഷിക്കാൻ മടങ്ങിയ ഘടന ഉപയോഗിക്കാം:
    ///
    ///
    /// * എക്സ് 00 എക്സ് നടപ്പിലാക്കൽ ഡീമാംഗിൾ ചെയ്ത ചിഹ്നം പ്രിന്റുചെയ്യും.
    /// * ചിഹ്നത്തിന്റെ റോ `str` മൂല്യം ആക്സസ് ചെയ്യാൻ കഴിയും (ഇത് സാധുവായ utf-8 ആണെങ്കിൽ).
    /// * ചിഹ്ന നാമത്തിനായുള്ള റോ ബൈറ്റുകൾ ആക്‌സസ്സുചെയ്യാനാകും.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// ഈ ഫംഗ്ഷന്റെ ആരംഭ വിലാസം നൽകുന്നു.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// റോ ഫയൽനാമം ഒരു സ്ലൈസായി നൽകുന്നു.
    /// ഇത് പ്രധാനമായും `no_std` പരിതസ്ഥിതികൾക്ക് ഉപയോഗപ്രദമാണ്.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// ഈ ചിഹ്നം നിലവിൽ നടപ്പിലാക്കുന്ന നിരയുടെ നിര നമ്പർ നൽകുന്നു.
    ///
    /// നിലവിൽ ജിംലി മാത്രമേ ഇവിടെ ഒരു മൂല്യം നൽകുന്നുള്ളൂ, എന്നിട്ടും `filename` `Some` നൽകുന്നുവെങ്കിൽ മാത്രമേ അത് സമാന മുന്നറിയിപ്പുകൾക്ക് വിധേയമാകൂ.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// ഈ ചിഹ്നം നിലവിൽ എക്സിക്യൂട്ട് ചെയ്യുന്നിടത്ത് ലൈൻ നമ്പർ നൽകുന്നു.
    ///
    /// `filename` `Some` നൽകുന്നുവെങ്കിൽ ഈ റിട്ടേൺ മൂല്യം സാധാരണയായി `Some` ആണ്, തന്മൂലം സമാന മുന്നറിയിപ്പുകൾക്ക് വിധേയമായിരിക്കും.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// ഈ ഫംഗ്ഷൻ നിർവചിച്ച ഫയലിന്റെ പേര് നൽകുന്നു.
    ///
    /// ലിബ്ബാക്ക്ട്രേസ് അല്ലെങ്കിൽ ജിംലി ഉപയോഗിക്കുമ്പോൾ മാത്രമേ ഇത് നിലവിൽ ലഭ്യമാകൂ (ഉദാ
    /// unix പ്ലാറ്റ്ഫോമുകൾ മറ്റുള്ളവ) കൂടാതെ ഡീബഗ്ഗിൻ‌ഫോ ഉപയോഗിച്ച് ഒരു ബൈനറി കംപൈൽ ചെയ്യുമ്പോൾ.
    /// ഈ നിബന്ധനകളൊന്നും പാലിച്ചില്ലെങ്കിൽ ഇത് `None` തിരികെ നൽകും.
    ///
    /// # ആവശ്യമായ സവിശേഷതകൾ
    ///
    /// ഈ ഫംഗ്ഷന് `backtrace` crate ന്റെ `std` സവിശേഷത പ്രാപ്തമാക്കേണ്ടതുണ്ട്, കൂടാതെ `std` സവിശേഷത സ്ഥിരസ്ഥിതിയായി പ്രാപ്തമാക്കുന്നു.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Rust ആയി മാംഗിൾ ചെയ്ത ചിഹ്നം പാഴ്‌സുചെയ്യുന്നത് പരാജയപ്പെട്ടാൽ ഒരുപക്ഷേ പാഴ്‌സുചെയ്‌ത C++ ചിഹ്നം.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // ഈ പൂജ്യം വലുപ്പം നിലനിർത്തുന്നത് ഉറപ്പാക്കുക, അതുവഴി `cpp_demangle` സവിശേഷത പ്രവർത്തനരഹിതമാകുമ്പോൾ വിലയില്ല.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// ഡീമാംഗിൾ ചെയ്ത പേര്, റോ ബൈറ്റുകൾ, റോ സ്ട്രിംഗ് മുതലായവയ്‌ക്ക് എർഗണോമിക് ആക്‌സസ്സറുകൾ നൽകുന്നതിന് ഒരു ചിഹ്ന നാമത്തിന് ചുറ്റും ഒരു റാപ്പർ.
///
// `cpp_demangle` സവിശേഷത പ്രാപ്തമാക്കിയിട്ടില്ലെങ്കിൽ ഡെഡ് കോഡ് അനുവദിക്കുക.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// അസംസ്കൃത അന്തർലീന ബൈറ്റുകളിൽ നിന്ന് ഒരു പുതിയ ചിഹ്ന നാമം സൃഷ്ടിക്കുന്നു.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// ചിഹ്നം സാധുവായ utf-8 ആണെങ്കിൽ റോ (mangled) ചിഹ്ന നാമം `str` ആയി നൽകുന്നു.
    ///
    /// ഡീമാംഗിൾ ചെയ്ത പതിപ്പ് വേണമെങ്കിൽ `Display` നടപ്പിലാക്കൽ ഉപയോഗിക്കുക.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// റോ ചിഹ്ന നാമം ബൈറ്റുകളുടെ ലിസ്റ്റായി നൽകുന്നു
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // ഡീമാംഗിൾ ചെയ്ത ചിഹ്നം യഥാർത്ഥത്തിൽ സാധുതയുള്ളതല്ലെങ്കിൽ ഇത് പ്രിന്റുചെയ്യാം, അതിനാൽ പിശക് പുറത്തേക്ക് പ്രചരിപ്പിക്കാതെ ഇവിടെ മനോഹരമായി കൈകാര്യം ചെയ്യുക.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// വിലാസങ്ങളെ പ്രതീകപ്പെടുത്താൻ ഉപയോഗിച്ച കാഷെ ചെയ്ത മെമ്മറി വീണ്ടെടുക്കാനുള്ള ശ്രമം.
///
/// ഈ രീതി ആഗോളതലത്തിൽ അല്ലെങ്കിൽ കാഷെ ചെയ്തിട്ടുള്ള ഏതെങ്കിലും ആഗോള ഡാറ്റാ ഘടനകളെ റിലീസ് ചെയ്യാൻ ശ്രമിക്കും, അത് പാഴ്‌സുചെയ്‌ത DWARF വിവരങ്ങളെ അല്ലെങ്കിൽ സമാനമായവയെ പ്രതിനിധീകരിക്കുന്നു.
///
///
/// # Caveats
///
/// ഈ ഫംഗ്ഷൻ എല്ലായ്പ്പോഴും ലഭ്യമാണെങ്കിലും മിക്ക നടപ്പാക്കലുകളിലും ഇത് യഥാർത്ഥത്തിൽ ഒന്നും ചെയ്യുന്നില്ല.
/// Dbghelp അല്ലെങ്കിൽ libbacktrace പോലുള്ള ലൈബ്രറികൾ‌സംസ്ഥാനത്തെ ഡീലോക്കേറ്റ് ചെയ്യുന്നതിനും അനുവദിച്ച മെമ്മറി കൈകാര്യം ചെയ്യുന്നതിനും സ provide കര്യങ്ങൾ നൽകുന്നില്ല.
/// ഇപ്പോൾ ഈ crate ന്റെ `gimli-symbolize` സവിശേഷത മാത്രമാണ് ഈ ഫംഗ്ഷന് എന്തെങ്കിലും ഫലമുണ്ടാകുന്നത്.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}