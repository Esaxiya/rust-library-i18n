#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// ബാക്ക്‌ട്രെയ്‌സുകൾക്കായുള്ള ഒരു ഫോർമാറ്റർ.
///
/// ബാക്ക്‌ട്രേസ് എവിടെ നിന്നാണ് വരുന്നതെന്ന് പരിഗണിക്കാതെ ഒരു ബാക്ക്‌ട്രേസ് അച്ചടിക്കാൻ ഈ തരം ഉപയോഗിക്കാം.
/// നിങ്ങൾക്ക് ഒരു `Backtrace` തരം ഉണ്ടെങ്കിൽ, അതിന്റെ `Debug` നടപ്പിലാക്കൽ ഇതിനകം ഈ പ്രിന്റിംഗ് ഫോർമാറ്റ് ഉപയോഗിക്കുന്നു.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// നമുക്ക് അച്ചടിക്കാൻ കഴിയുന്ന അച്ചടി ശൈലികൾ
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// പ്രസക്തമായ വിവരങ്ങൾ‌മാത്രം അടങ്ങിയിരിക്കുന്ന ഒരു ടെർ‌സർ‌ബാക്ക്‌ട്രേസ് അച്ചടിക്കുന്നു
    Short,
    /// സാധ്യമായ എല്ലാ വിവരങ്ങളും അടങ്ങിയ ഒരു ബാക്ക്‌ട്രേസ് അച്ചടിക്കുന്നു
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// ഒരു പുതിയ `BacktraceFmt` സൃഷ്ടിക്കുക, അത് നൽകിയ `fmt`-ലേക്ക് output ട്ട്‌പുട്ട് എഴുതുന്നു.
    ///
    /// `format` ആർ‌ഗ്യുമെൻറ് ബാക്ക്‌ട്രേസ് അച്ചടിക്കുന്ന ശൈലിയെ നിയന്ത്രിക്കും, കൂടാതെ `print_path` ആർ‌ഗ്യുമെൻറ് ഫയൽ‌നാമങ്ങളുടെ `BytesOrWideString` ഉദാഹരണങ്ങൾ‌അച്ചടിക്കാൻ ഉപയോഗിക്കും.
    /// ഈ തരം തന്നെ ഫയൽനാമങ്ങളുടെ അച്ചടി ഒന്നും ചെയ്യുന്നില്ല, പക്ഷേ അങ്ങനെ ചെയ്യാൻ ഈ കോൾബാക്ക് ആവശ്യമാണ്.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// ബാക്ക്‌ട്രേസ് അച്ചടിക്കാൻ പോകുന്ന ഒരു ആമുഖം അച്ചടിക്കുന്നു.
    ///
    /// ബാക്ക്‌ട്രെയ്‌സുകൾ പിന്നീട് പൂർണ്ണമായി പ്രതീകപ്പെടുത്തുന്നതിന് ചില പ്ലാറ്റ്‌ഫോമുകളിൽ ഇത് ആവശ്യമാണ്, അല്ലാത്തപക്ഷം ഇത് ഒരു `BacktraceFmt` സൃഷ്‌ടിച്ചതിന് ശേഷം നിങ്ങൾ വിളിക്കുന്ന ആദ്യ രീതിയായിരിക്കണം.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// ബാക്ക്‌ട്രേസ് .ട്ട്‌പുട്ടിലേക്ക് ഒരു ഫ്രെയിം ചേർക്കുന്നു.
    ///
    /// ഈ പ്രതിബദ്ധത ഒരു ഫ്രെയിം അച്ചടിക്കാൻ ഉപയോഗിക്കാവുന്ന `BacktraceFrameFmt`-ന്റെ ഒരു RAII ഉദാഹരണം നൽകുന്നു, നാശത്തിൽ അത് ഫ്രെയിം ക .ണ്ടർ വർദ്ധിപ്പിക്കും.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// ബാക്ക്‌ട്രേസ് .ട്ട്‌പുട്ട് പൂർത്തിയാക്കുന്നു.
    ///
    /// ഇത് നിലവിൽ ഒരു നോ-ഒപാണ്, പക്ഷേ ബാക്ക്‌ട്രേസ് ഫോർമാറ്റുകളുമായുള്ള future അനുയോജ്യതയ്ക്കായി ഇത് ചേർത്തു.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // future കൂട്ടിച്ചേർക്കലുകൾ അനുവദിക്കുന്നതിനായി ഈ hook ഉൾപ്പെടെ നിലവിൽ ഒരു നോ-ഒപ്പ്.
        Ok(())
    }
}

/// ഒരു ബാക്ക്‌ട്രെയ്‌സിന്റെ ഒരു ഫ്രെയിമിനായുള്ള ഒരു ഫോർമാറ്റർ.
///
/// `BacktraceFmt::frame` ഫംഗ്ഷനാണ് ഈ തരം സൃഷ്ടിച്ചത്.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// ഈ ഫ്രെയിം ഫോർമാറ്റർ ഉപയോഗിച്ച് ഒരു `BacktraceFrame` പ്രിന്റുചെയ്യുന്നു.
    ///
    /// ഇത് `BacktraceFrame`-നുള്ളിലെ എല്ലാ `BacktraceSymbol` സംഭവങ്ങളും ആവർത്തിച്ച് പ്രിന്റുചെയ്യും.
    ///
    /// # ആവശ്യമായ സവിശേഷതകൾ
    ///
    /// ഈ ഫംഗ്ഷന് `backtrace` crate ന്റെ `std` സവിശേഷത പ്രാപ്തമാക്കേണ്ടതുണ്ട്, കൂടാതെ `std` സവിശേഷത സ്ഥിരസ്ഥിതിയായി പ്രാപ്തമാക്കുന്നു.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// ഒരു `BacktraceFrame`-നുള്ളിൽ ഒരു `BacktraceSymbol` പ്രിന്റുചെയ്യുന്നു.
    ///
    /// # ആവശ്യമായ സവിശേഷതകൾ
    ///
    /// ഈ ഫംഗ്ഷന് `backtrace` crate ന്റെ `std` സവിശേഷത പ്രാപ്തമാക്കേണ്ടതുണ്ട്, കൂടാതെ `std` സവിശേഷത സ്ഥിരസ്ഥിതിയായി പ്രാപ്തമാക്കുന്നു.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: ഞങ്ങൾ ഒന്നും അച്ചടിക്കുന്നത് അവസാനിപ്പിക്കാത്തതിൽ ഇത് മികച്ചതല്ല
            // utf8 അല്ലാത്ത ഫയൽനാമങ്ങൾ ഉപയോഗിച്ച്.
            // നന്ദിയോടെ മിക്കവാറും എല്ലാം utf8 ആയതിനാൽ ഇത് വളരെ മോശമാകരുത്.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// ഈ crate-ന്റെ റോ കോൾബാക്കുകൾക്കുള്ളിൽ നിന്ന് ഒരു അസംസ്കൃത ട്രെയ്‌സ്ഡ് `Frame`, `Symbol` എന്നിവ അച്ചടിക്കുന്നു.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// ബാക്ക്‌ട്രേസ് .ട്ട്‌പുട്ടിൽ ഒരു റോ ഫ്രെയിം ചേർക്കുന്നു.
    ///
    /// ഈ രീതി, മുമ്പത്തേതിൽ നിന്ന് വ്യത്യസ്തമായി, വ്യത്യസ്ത സ്ഥലങ്ങളിൽ നിന്നുള്ള ഉറവിടമാണെങ്കിൽ അസംസ്കൃത ആർഗ്യുമെന്റുകൾ എടുക്കുന്നു.
    /// ഒരു ഫ്രെയിമിനായി ഇതിനെ ഒന്നിലധികം തവണ വിളിക്കാമെന്നത് ശ്രദ്ധിക്കുക.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// നിര വിവരങ്ങൾ ഉൾപ്പെടെ ബാക്ക്‌ട്രേസ് output ട്ട്‌പുട്ടിലേക്ക് ഒരു റോ ഫ്രെയിം ചേർക്കുന്നു.
    ///
    /// മുമ്പത്തെപ്പോലെ ഈ രീതിയും വ്യത്യസ്ത സ്ഥലങ്ങളിൽ നിന്നുള്ള ഉറവിടമാണെങ്കിൽ അസംസ്കൃത ആർഗ്യുമെന്റുകൾ എടുക്കുന്നു.
    /// ഒരു ഫ്രെയിമിനായി ഇതിനെ ഒന്നിലധികം തവണ വിളിക്കാമെന്നത് ശ്രദ്ധിക്കുക.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // ഒരു പ്രക്രിയയ്ക്കുള്ളിൽ പ്രതീകപ്പെടുത്താൻ ഫ്യൂഷിയയ്‌ക്ക് കഴിയില്ല, അതിനാൽ ഇതിന് ഒരു പ്രത്യേക ഫോർമാറ്റ് ഉണ്ട്, അത് പിന്നീട് പ്രതീകപ്പെടുത്താൻ ഉപയോഗിക്കാം.
        // വിലാസങ്ങൾ അച്ചടിക്കുന്നതിനുപകരം ഞങ്ങളുടെ സ്വന്തം ഫോർമാറ്റിൽ അച്ചടിക്കുക.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // "null" ഫ്രെയിമുകൾ പ്രിന്റുചെയ്യേണ്ട ആവശ്യമില്ല, അടിസ്ഥാനപരമായി ഇത് അർത്ഥമാക്കുന്നത് സിസ്റ്റം ബാക്ക്‌ട്രേസ് സൂപ്പർ ദൂരം കണ്ടെത്താൻ അൽപ്പം ഉത്സുകനായിരുന്നു എന്നാണ്.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // എസ്‌ജി‌എക്സ് എൻ‌ക്ലേവിലെ ടി‌സി‌ബി വലുപ്പം കുറയ്ക്കുന്നതിന്, ചിഹ്ന മിഴിവ് പ്രവർത്തനം നടപ്പിലാക്കാൻ ഞങ്ങൾ ആഗ്രഹിക്കുന്നില്ല.
        // പകരം, ഞങ്ങൾക്ക് ഇവിടെ വിലാസത്തിന്റെ ഓഫ്‌സെറ്റ് അച്ചടിക്കാൻ കഴിയും, അത് പിന്നീട് ശരിയായ പ്രവർത്തനത്തിനായി മാപ്പുചെയ്യാം.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // ഫ്രെയിമിന്റെ സൂചികയും ഫ്രെയിമിന്റെ ഓപ്ഷണൽ ഇൻസ്ട്രക്ഷൻ പോയിന്ററും അച്ചടിക്കുക.
        // ഈ ഫ്രെയിമിന്റെ ആദ്യ ചിഹ്നത്തിനപ്പുറത്താണെങ്കിൽ‌ഞങ്ങൾ‌ഉചിതമായ വൈറ്റ്‌സ്‌പെയ്‌സ് അച്ചടിക്കുന്നു.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // അടുത്തതായി ചിഹ്നത്തിന്റെ പേര് എഴുതുക, ഞങ്ങൾ ഒരു പൂർണ്ണ ബാക്ക്‌ട്രേസ് ആണെങ്കിൽ കൂടുതൽ വിവരങ്ങൾക്ക് ഇതര ഫോർമാറ്റിംഗ് ഉപയോഗിച്ച്.
        // പേരില്ലാത്ത ചിഹ്നങ്ങളും ഇവിടെ ഞങ്ങൾ കൈകാര്യം ചെയ്യുന്നു,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // അവസാനമായി, filename/line നമ്പർ ലഭ്യമാണെങ്കിൽ അവ പ്രിന്റുചെയ്യുക.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line ചിഹ്ന നാമത്തിൽ വരികളിൽ അച്ചടിക്കുന്നു, അതിനാൽ സ്വയം ശരിയായി വിന്യസിക്കുന്നതിന് ഉചിതമായ ചില വൈറ്റ്സ്പേസ് അച്ചടിക്കുക.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // ഫയൽ നാമം പ്രിന്റുചെയ്യുന്നതിന് ഞങ്ങളുടെ ആന്തരിക കോൾബാക്കിലേക്ക് നിയോഗിക്കുക, തുടർന്ന് ലൈൻ നമ്പർ പ്രിന്റുചെയ്യുക.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // ലഭ്യമെങ്കിൽ നിര നമ്പർ ചേർക്കുക.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // ഒരു ഫ്രെയിമിന്റെ ആദ്യ ചിഹ്നത്തെക്കുറിച്ച് മാത്രമേ ഞങ്ങൾ ശ്രദ്ധിക്കൂ
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}