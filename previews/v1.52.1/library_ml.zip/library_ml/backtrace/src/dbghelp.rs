//! Windows-ൽ dbghelp ബൈൻഡിംഗുകൾ കൈകാര്യം ചെയ്യുന്നതിന് സഹായിക്കുന്നതിനുള്ള ഒരു മൊഡ്യൂൾ
//!
//! Windows-ലെ ബാക്ക്‌ട്രെയ്‌സുകൾ (കുറഞ്ഞത് MSVC-യ്‌ക്കെങ്കിലും) പ്രധാനമായും പ്രവർത്തിക്കുന്നത് `dbghelp.dll` വഴിയും അതിൽ അടങ്ങിയിരിക്കുന്ന വിവിധ പ്രവർത്തനങ്ങളിലൂടെയുമാണ്.
//! ഈ ഫംഗ്ഷനുകൾ നിലവിൽ `dbghelp.dll` ലേക്ക് സ്റ്റാറ്റിക്ക് ആയി ലിങ്കുചെയ്യുന്നതിനുപകരം *ചലനാത്മകമായി* ലോഡുചെയ്‌തു.
//! ഇത് നിലവിൽ സ്റ്റാൻഡേർഡ് ലൈബ്രറിയാണ് ചെയ്യുന്നത് (അത് അവിടെ സിദ്ധാന്തത്തിൽ ആവശ്യമാണ്), എന്നാൽ ബാക്ക്‌ട്രെയ്‌സുകൾ സാധാരണ ഓപ്‌ഷണലായതിനാൽ ഒരു ലൈബ്രറിയുടെ സ്റ്റാറ്റിക് ഡിഎൽ ഡിപൻഡൻസികൾ കുറയ്ക്കുന്നതിനുള്ള ഒരു ശ്രമമാണിത്.
//!
//! അങ്ങനെ പറഞ്ഞാൽ, `dbghelp.dll` എല്ലായ്പ്പോഴും Windows-ൽ വിജയകരമായി ലോഡുചെയ്യുന്നു.
//!
//! ശ്രദ്ധിക്കുക, ഞങ്ങൾ ഈ പിന്തുണയെല്ലാം ചലനാത്മകമായി ലോഡുചെയ്യുന്നതിനാൽ നമുക്ക് യഥാർത്ഥത്തിൽ `winapi`-ൽ അസംസ്കൃത നിർവചനങ്ങൾ ഉപയോഗിക്കാൻ കഴിയില്ല, മറിച്ച് ഫംഗ്ഷൻ പോയിന്റർ തരങ്ങൾ സ്വയം നിർവചിച്ച് അത് ഉപയോഗിക്കേണ്ടതുണ്ട്.
//! വിനാപിയുടെ തനിപ്പകർപ്പ് ബിസിനസ്സിൽ ഏർപ്പെടാൻ ഞങ്ങൾ ശരിക്കും ആഗ്രഹിക്കുന്നില്ല, അതിനാൽ ഞങ്ങൾക്ക് ഒരു Cargo സവിശേഷത `verify-winapi` ഉണ്ട്, ഇത് എല്ലാ ബൈൻഡിംഗുകളും വിനാപിയിലുള്ളവയുമായി പൊരുത്തപ്പെടുന്നുവെന്നും ഈ സവിശേഷത CI-ൽ പ്രാപ്തമാക്കിയിട്ടുണ്ടെന്നും ഉറപ്പിച്ചുപറയുന്നു.
//!
//! അവസാനമായി, `dbghelp.dll`-നായുള്ള dll ഒരിക്കലും അൺലോഡുചെയ്തിട്ടില്ലെന്നും അത് നിലവിൽ മന .പൂർവമാണെന്നും നിങ്ങൾ ഇവിടെ ശ്രദ്ധിക്കും.
//! ആഗോളതലത്തിൽ ഇത് കാഷെ ചെയ്യാനും API-യിലേക്കുള്ള കോളുകൾക്കിടയിൽ ഉപയോഗിക്കാനും ചെലവേറിയ loads/unloads ഒഴിവാക്കാനും കഴിയും എന്നതാണ് ചിന്ത.
//! ലീക്ക് ഡിറ്റക്ടറുകൾക്ക് ഇത് ഒരു പ്രശ്നമാണെങ്കിൽ അല്ലെങ്കിൽ അതുപോലെയുള്ള എന്തെങ്കിലും ഉണ്ടെങ്കിൽ ഞങ്ങൾ അവിടെ എത്തുമ്പോൾ പാലം കടക്കാൻ കഴിയും.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// വിനാപിയിൽ തന്നെ ഇല്ലാത്ത `SymGetOptions`, `SymSetOptions` എന്നിവയിൽ പ്രവർത്തിക്കുക.
// അല്ലെങ്കിൽ ഞങ്ങൾ വിനാപിക്കെതിരെ ഇരട്ട പരിശോധന നടത്തുമ്പോൾ മാത്രമേ ഇത് ഉപയോഗിക്കൂ.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // വിനാപിയിൽ ഇതുവരെ നിർവചിച്ചിട്ടില്ല
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // ഇത് വിനാപിയിൽ നിർവചിച്ചിരിക്കുന്നു, പക്ഷേ ഇത് തെറ്റാണ് (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // വിനാപിയിൽ ഇതുവരെ നിർവചിച്ചിട്ടില്ല
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// ഞങ്ങൾ ലോഡുചെയ്യാനിടയുള്ള എല്ലാ ഫംഗ്ഷൻ പോയിന്ററുകളും ആന്തരികമായി അടങ്ങിയിരിക്കുന്ന ഒരു `Dbghelp` ഘടന നിർവചിക്കാൻ ഈ മാക്രോ ഉപയോഗിക്കുന്നു.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// `dbghelp.dll`-നായി ലോഡുചെയ്‌ത DLL
            dll: HMODULE,

            // ഞങ്ങൾ ഉപയോഗിച്ചേക്കാവുന്ന ഓരോ ഫംഗ്ഷനുമുള്ള ഓരോ ഫംഗ്ഷൻ പോയിന്ററും
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // തുടക്കത്തിൽ ഞങ്ങൾ DLL ലോഡുചെയ്തിട്ടില്ല
            dll: 0 as *mut _,
            // തുടക്കത്തിൽ എല്ലാ പ്രവർത്തനങ്ങളും പൂജ്യമായി സജ്ജീകരിച്ചിരിക്കുന്നു, അവ ചലനാത്മകമായി ലോഡുചെയ്യേണ്ടതുണ്ടെന്ന് പറയുന്നു.
            //
            $($name: 0,)*
        };

        // ഓരോ ഫംഗ്ഷൻ തരത്തിനും സ typ കര്യപ്രദമായ ടൈപ്പ്ഡെഫ്.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// `dbghelp.dll` തുറക്കാൻ ശ്രമിക്കുന്നു.
            /// ഇത് പ്രവർത്തിക്കുകയാണെങ്കിൽ വിജയം നൽകുന്നു അല്ലെങ്കിൽ `LoadLibraryW` പരാജയപ്പെട്ടാൽ പിശക്.
            ///
            /// ലൈബ്രറി ഇതിനകം ലോഡുചെയ്തിട്ടുണ്ടെങ്കിൽ Panics.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // ഞങ്ങൾ ഉപയോഗിക്കാൻ ആഗ്രഹിക്കുന്ന ഓരോ രീതിയുടെയും പ്രവർത്തനം.
            // വിളിക്കുമ്പോൾ അത് കാഷെ ചെയ്‌ത ഫംഗ്ഷൻ പോയിന്റർ വായിക്കും അല്ലെങ്കിൽ ലോഡുചെയ്‌ത് ലോഡുചെയ്‌ത മൂല്യം നൽകും.
            // ലോഡുകൾ വിജയിക്കാൻ ഉറപ്പിച്ചുപറയുന്നു.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Dbghelp ഫംഗ്ഷനുകൾ റഫറൻസ് ചെയ്യുന്നതിന് ക്ലീനപ്പ് ലോക്കുകൾ ഉപയോഗിക്കുന്നതിനുള്ള സ pro കര്യ പ്രോക്സി.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// ഈ crate ൽ നിന്ന് `dbghelp` API ഫംഗ്ഷനുകൾ ആക്സസ് ചെയ്യുന്നതിന് ആവശ്യമായ എല്ലാ പിന്തുണയും സമാരംഭിക്കുക.
///
///
/// ഈ ഫംഗ്ഷൻ **സുരക്ഷിതമാണ്** എന്നത് ശ്രദ്ധിക്കുക, ഇതിന് ആന്തരികമായി അതിന്റേതായ സമന്വയമുണ്ട്.
/// ഈ ഫംഗ്ഷനെ ഒന്നിലധികം തവണ ആവർത്തിച്ച് വിളിക്കുന്നത് സുരക്ഷിതമാണെന്നതും ശ്രദ്ധിക്കുക.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // ഈ ഫംഗ്ഷൻ സമന്വയിപ്പിക്കുക എന്നതാണ് നമ്മൾ ആദ്യം ചെയ്യേണ്ടത്.ഇതിനെ മറ്റ് ത്രെഡുകളിൽ നിന്ന് ഒരേസമയം അല്ലെങ്കിൽ ഒരു ത്രെഡിനുള്ളിൽ ആവർത്തിച്ച് വിളിക്കാം.
        // എന്നിരുന്നാലും അതിനേക്കാൾ തന്ത്രപ്രധാനമാണെന്ന കാര്യം ശ്രദ്ധിക്കുക, കാരണം ഞങ്ങൾ ഇവിടെ ഉപയോഗിക്കുന്നത് `dbghelp`, * എന്നിവയും മറ്റ് എല്ലാ കോളർമാരുമായും ഈ പ്രക്രിയയിൽ `dbghelp` ലേക്ക് സമന്വയിപ്പിക്കേണ്ടതുണ്ട്.
        //
        // സാധാരണഗതിയിൽ ഒരേ പ്രക്രിയയ്ക്കുള്ളിൽ `dbghelp`-ലേക്ക് നിരവധി കോളുകൾ ഇല്ല, മാത്രമല്ല ഞങ്ങൾ മാത്രമാണ് ഇത് ആക്സസ് ചെയ്യുന്നതെന്ന് നമുക്ക് സുരക്ഷിതമായി അനുമാനിക്കാം.
        // എന്നിരുന്നാലും, നമ്മൾ വിഷമിക്കേണ്ട ഒരു പ്രാഥമിക മറ്റൊരു ഉപയോക്താവ് ഉണ്ട്, എന്നാൽ ഇത് വിരോധാഭാസമാണ്, പക്ഷേ സ്റ്റാൻഡേർഡ് ലൈബ്രറിയിൽ.
        // Rust സ്റ്റാൻ‌ഡേർഡ് ലൈബ്രറി ബാക്ക്‌ട്രേസ് പിന്തുണയ്‌ക്കായി ഈ crate നെ ആശ്രയിച്ചിരിക്കുന്നു, മാത്രമല്ല ഈ crate crates.io ലും നിലവിലുണ്ട്.
        // ഇതിനർത്ഥം സ്റ്റാൻഡേർഡ് ലൈബ്രറി ഒരു panic ബാക്ക്‌ട്രേസ് അച്ചടിക്കുകയാണെങ്കിൽ, ഇത് crates.io-ൽ നിന്ന് വരുന്ന ഈ crate ഉപയോഗിച്ച് ഓടിച്ചേക്കാം, ഇത് സെഗ്‌ഫോൾട്ടുകൾക്ക് കാരണമാകുന്നു.
        //
        // ഈ സമന്വയ പ്രശ്നം പരിഹരിക്കാൻ സഹായിക്കുന്നതിന് ഞങ്ങൾ ഇവിടെ ഒരു വിൻഡോസ് നിർദ്ദിഷ്ട ട്രിക്ക് ഉപയോഗിക്കുന്നു (ഇത് എല്ലാത്തിനുമുപരി, സമന്വയത്തെക്കുറിച്ചുള്ള ഒരു വിൻഡോസ് നിർദ്ദിഷ്ട നിയന്ത്രണമാണ്).
        // ഈ കോൾ പരിരക്ഷിക്കുന്നതിന് ഞങ്ങൾ മ്യൂട്ടക്സ് എന്ന പേരിൽ ഒരു *സെഷൻ-ലോക്കൽ* സൃഷ്ടിക്കുന്നു.
        // ഇവിടെ സമന്വയിപ്പിക്കുന്നതിന് സ്റ്റാൻഡേർഡ് ലൈബ്രറിയും ഈ crate-ഉം Rust-ലെവൽ API-കൾ പങ്കിടേണ്ടതില്ല, പകരം പരസ്പരം സമന്വയിപ്പിക്കുന്നുവെന്ന് ഉറപ്പാക്കുന്നതിന് പിന്നിൽ പ്രവർത്തിക്കാൻ കഴിയും എന്നതാണ് ഇവിടെ ഉദ്ദേശ്യം.
        //
        // ഈ രീതിയിൽ സ്റ്റാൻഡേർഡ് ലൈബ്രറിയിലൂടെയോ എക്സ് 100 എക്സ് വഴിയോ വിളിക്കുമ്പോൾ അതേ മ്യൂട്ടക്സ് നേടിയെടുക്കുന്നുവെന്ന് നമുക്ക് ഉറപ്പിക്കാം.
        //
        // അതിനാൽ ഇതെല്ലാം നമ്മൾ ഇവിടെ ആദ്യം ചെയ്യുന്നത് ആറ്റോമിക്കലായി ഒരു `HANDLE` സൃഷ്ടിക്കുക എന്നതാണ്, അത് Windows-ൽ പേരുള്ള മ്യൂട്ടക്സ് ആണ്.
        // ഈ ഫംഗ്ഷൻ പ്രത്യേകമായി പങ്കിടുന്ന മറ്റ് ത്രെഡുകളുമായി ഞങ്ങൾ അൽപ്പം സമന്വയിപ്പിക്കുകയും ഈ ഫംഗ്ഷന്റെ ഒരു ഉദാഹരണത്തിൽ ഒരു ഹാൻഡിൽ മാത്രമേ സൃഷ്ടിച്ചിട്ടുള്ളൂവെന്ന് ഉറപ്പാക്കുകയും ചെയ്യുന്നു.
        // ഹാൻഡിൽ ആഗോളതലത്തിൽ സംഭരിച്ചുകഴിഞ്ഞാൽ അത് ഒരിക്കലും അടയ്‌ക്കില്ല.
        //
        // ഞങ്ങൾ യഥാർത്ഥത്തിൽ ലോക്ക് പോയിക്കഴിഞ്ഞാൽ ഞങ്ങൾ അത് സ്വന്തമാക്കും, കൂടാതെ ഞങ്ങൾ കൈമാറുന്ന ഞങ്ങളുടെ `Init` ഹാൻഡിൽ ഇത് ഒടുവിൽ ഉപേക്ഷിക്കുന്നതിനുള്ള ഉത്തരവാദിത്തമായിരിക്കും.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // ശരി, ശ്ശോ!ഇപ്പോൾ നാമെല്ലാം സുരക്ഷിതമായി സമന്വയിപ്പിച്ചു, യഥാർത്ഥത്തിൽ എല്ലാം പ്രോസസ്സ് ചെയ്യാൻ ആരംഭിക്കാം.
        // ആദ്യം, ഈ പ്രക്രിയയിൽ `dbghelp.dll` യഥാർത്ഥത്തിൽ ലോഡുചെയ്തിട്ടുണ്ടെന്ന് ഉറപ്പാക്കേണ്ടതുണ്ട്.
        // ഒരു സ്റ്റാറ്റിക് ഡിപൻഡൻസി ഒഴിവാക്കാൻ ഞങ്ങൾ ഇത് ചലനാത്മകമായി ചെയ്യുന്നു.
        // ചരിത്രപരമായി വിചിത്രമായ ലിങ്കിംഗ് പ്രശ്നങ്ങളിൽ പ്രവർത്തിക്കുന്നതിനായാണ് ഇത് ചെയ്തിരിക്കുന്നത്, ഇത് ഒരു ഡീബഗ്ഗിംഗ് യൂട്ടിലിറ്റി മാത്രമായതിനാൽ ബൈനറികളെ കുറച്ചുകൂടി പോർട്ടബിൾ ആക്കാൻ ഉദ്ദേശിച്ചുള്ളതാണ്.
        //
        //
        // ഞങ്ങൾ `dbghelp.dll` തുറന്നുകഴിഞ്ഞാൽ അതിൽ ചില ഓർഗനൈസേഷൻ ഫംഗ്ഷനുകൾ വിളിക്കേണ്ടതുണ്ട്, അത് കൂടുതൽ ചുവടെ വിശദമാക്കിയിരിക്കുന്നു.
        // ഞങ്ങൾ ഇത് ഒരു തവണ മാത്രമേ ചെയ്യുന്നുള്ളൂ, അതിനാൽ ഞങ്ങൾ ഇതുവരെ പൂർത്തിയാക്കിയിട്ടുണ്ടോ ഇല്ലയോ എന്ന് സൂചിപ്പിക്കുന്ന ഒരു ആഗോള ബൂളിയൻ ലഭിച്ചു.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // `SYMOPT_DEFERRED_LOADS` ഫ്ലാഗ് സജ്ജമാക്കിയിട്ടുണ്ടെന്ന് ഉറപ്പാക്കുക, കാരണം ഇതിനെക്കുറിച്ച് MSVC യുടെ സ്വന്തം ഡോക്‍സ് അനുസരിച്ച്: "This is the fastest, most efficient way to use the symbol handler.", അതിനാൽ നമുക്ക് അത് ചെയ്യാം!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // MSVC ഉപയോഗിച്ച് യഥാർത്ഥത്തിൽ ചിഹ്നങ്ങൾ സമാരംഭിക്കുക.ഇത് പരാജയപ്പെടുമെന്നത് ശ്രദ്ധിക്കുക, പക്ഷേ ഞങ്ങൾ അത് അവഗണിക്കുന്നു.
        // ഇതിനായി ഒരു ടൺ മുൻ‌കൈയൊന്നുമില്ല, പക്ഷേ എൽ‌എൽ‌വി‌എം ആന്തരികമായി ഇവിടെയുള്ള റിട്ടേൺ മൂല്യത്തെ അവഗണിക്കുന്നതായി തോന്നുന്നു, എൽ‌എൽ‌വി‌എമ്മിലെ സാനിറ്റൈസർ ലൈബ്രറികളിലൊന്ന് ഇത് പരാജയപ്പെട്ടാലും അടിസ്ഥാനപരമായി ദീർഘകാലാടിസ്ഥാനത്തിൽ അവഗണിക്കുകയാണെങ്കിൽ ഭയപ്പെടുത്തുന്ന മുന്നറിയിപ്പ് അച്ചടിക്കുന്നു.
        //
        //
        // Rust-ന് ഇത് വളരെയധികം വരുന്ന ഒരു കേസ് സ്റ്റാൻഡേർഡ് ലൈബ്രറിയും crates.io-ലെ ഈ crate-ഉം `SymInitializeW`-നായി മത്സരിക്കാൻ ആഗ്രഹിക്കുന്നു എന്നതാണ്.
        // സ്റ്റാൻഡേർഡ് ലൈബ്രറി ചരിത്രപരമായി കൂടുതൽ സമയവും പിന്നീട് വൃത്തിയാക്കാനും ആഗ്രഹിച്ചു, എന്നാൽ ഇപ്പോൾ ഇത് ഈ crate ഉപയോഗിക്കുന്നു എന്നതിനർത്ഥം ആരെങ്കിലും ആദ്യം സമാരംഭിക്കുമെന്നും മറ്റൊരാൾ ആ സമാരംഭം എടുക്കുമെന്നും അർത്ഥമാക്കുന്നു.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}