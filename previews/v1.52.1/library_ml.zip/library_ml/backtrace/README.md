# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Rust-നായി റൺടൈമിൽ ബാക്ക്‌ട്രെയ്‌സുകൾ നേടുന്നതിനുള്ള ഒരു ലൈബ്രറി.
പ്രവർത്തിക്കാൻ ഒരു പ്രോഗ്രമാറ്റിക് ഇന്റർഫേസ് നൽകിക്കൊണ്ട് സ്റ്റാൻഡേർഡ് ലൈബ്രറിയുടെ പിന്തുണ വർദ്ധിപ്പിക്കുന്നതിനാണ് ഈ ലൈബ്രറി ലക്ഷ്യമിടുന്നത്, പക്ഷേ ലിബ്സ്റ്റഡിന്റെ panics പോലുള്ള നിലവിലെ ബാക്ക്ട്രേസ് എളുപ്പത്തിൽ അച്ചടിക്കാനും ഇത് പിന്തുണയ്ക്കുന്നു.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

ഒരു ബാക്ക്‌ട്രേസ് പിടിച്ചെടുക്കാനും പിന്നീടുള്ള സമയം വരെ ഇത് കൈകാര്യം ചെയ്യുന്നത് മാറ്റാനും, നിങ്ങൾക്ക് ഉയർന്ന ലെവൽ `Backtrace` തരം ഉപയോഗിക്കാം.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

എന്നിരുന്നാലും, യഥാർത്ഥ ട്രേസിംഗ് പ്രവർത്തനത്തിലേക്ക് കൂടുതൽ അസംസ്കൃത ആക്സസ് നിങ്ങൾ ആഗ്രഹിക്കുന്നുവെങ്കിൽ, നിങ്ങൾക്ക് നേരിട്ട് `trace`, `resolve` ഫംഗ്ഷനുകൾ ഉപയോഗിക്കാം.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // ഒരു ചിഹ്ന നാമത്തിലേക്ക് ഈ നിർദ്ദേശ പോയിന്റർ പരിഹരിക്കുക
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // അടുത്ത ഫ്രെയിമിലേക്ക് പോകുന്നത് തുടരുക
    });
}
```

# License

ഈ പ്രോജക്റ്റിന് ഇവ രണ്ടിനു കീഴിലും ലൈസൻസ് നൽകിയിട്ടുണ്ട്

 * Apache ലൈസൻസ്, പതിപ്പ് 2.0, ([LICENSE-APACHE](LICENSE-APACHE) അല്ലെങ്കിൽ http://www.apache.org/licenses/LICENSE-2.0)
 * MIT ലൈസൻസ് ([LICENSE-MIT](LICENSE-MIT) അല്ലെങ്കിൽ http://opensource.org/licenses/MIT)

നിങ്ങളുടെ ഓപ്ഷനിൽ.

### Contribution

നിങ്ങൾ വ്യക്തമായി പ്രസ്താവിക്കുന്നില്ലെങ്കിൽ, Apache-2.0 ലൈസൻസിൽ നിർവചിച്ചിരിക്കുന്നത് പോലെ നിങ്ങൾ ബാക്ക്ട്രേസ്-ആർ‌എസിൽ ഉൾപ്പെടുത്തുന്നതിന് മന intention പൂർവ്വം സമർപ്പിച്ച ഏതെങ്കിലും സംഭാവന, അധിക നിബന്ധനകളോ വ്യവസ്ഥകളോ ഇല്ലാതെ, മുകളിൽ പറഞ്ഞതുപോലെ ഇരട്ട ലൈസൻസുള്ളതായിരിക്കും.







