//! `compiler-rt` ലൈബ്രറിയുടെ പ്രൊഫൈലർ ഭാഗം കംപൈൽ ചെയ്യുന്നു.
//!
//! വിശദാംശങ്ങൾക്ക് libcompiler_builtins crate-നായി build.rs കാണുക.

use std::env;
use std::path::Path;

fn main() {
    let target = env::var("TARGET").expect("TARGET was not set");
    let cfg = &mut cc::Build::new();

    // FIXME: `rerun-if-changed` നിർദ്ദേശങ്ങൾ നിലവിൽ പുറത്തുവിടുന്നില്ല കൂടാതെ ബിൽഡ് സ്ക്രിപ്റ്റും
    // ഈ ഉറവിട ഫയലുകളിലോ അവയിൽ ഉൾപ്പെടുത്തിയിരിക്കുന്ന തലക്കെട്ടുകളിലോ വരുത്തിയ മാറ്റങ്ങൾ വീണ്ടും പ്രവർത്തിപ്പിക്കില്ല.
    let mut profile_sources = vec![
        "GCDAProfiling.c",
        "InstrProfiling.c",
        "InstrProfilingBuffer.c",
        "InstrProfilingFile.c",
        "InstrProfilingMerge.c",
        "InstrProfilingMergeFile.c",
        "InstrProfilingNameVar.c",
        "InstrProfilingPlatformDarwin.c",
        "InstrProfilingPlatformFuchsia.c",
        "InstrProfilingPlatformLinux.c",
        "InstrProfilingPlatformOther.c",
        "InstrProfilingPlatformWindows.c",
        "InstrProfilingUtil.c",
        "InstrProfilingValue.c",
        "InstrProfilingVersionVar.c",
        "InstrProfilingWriter.c",
        // ഈ ഫയലിന്റെ പേര് എൽ‌എൽ‌വി‌എം 10 ൽ പുനർ‌നാമകരണം ചെയ്തു.
        "InstrProfilingRuntime.cc",
        "InstrProfilingRuntime.cpp",
        // ഈ ഫയലുകൾ LLVM 11 ൽ ചേർത്തു.
        "InstrProfilingInternal.c",
        "InstrProfilingBiasVar.c",
    ];

    if target.contains("msvc") {
        // MSVC-യിൽ അധിക ലൈബ്രറികൾ വലിച്ചിടരുത്
        cfg.flag("/Zl");
        profile_sources.push("WindowsMMap.c");
        cfg.define("strdup", Some("_strdup"));
        cfg.define("open", Some("_open"));
        cfg.define("fdopen", Some("_fdopen"));
        cfg.define("getpid", Some("_getpid"));
        cfg.define("fileno", Some("_fileno"));
    } else {
        // gcc-ന്റെ വിവിധ സവിശേഷതകൾ ഓഫുചെയ്യുക, കംപൈലർ-ആർ‌ടിയുടെ ബിൽഡ് സിസ്റ്റം ഇതിനകം തന്നെ പകർത്തുന്നു
        //
        cfg.flag("-fno-builtin");
        cfg.flag("-fomit-frame-pointer");
        cfg.define("VISIBILITY_HIDDEN", None);
        if !target.contains("windows") {
            cfg.flag("-fvisibility=hidden");
            cfg.define("COMPILER_RT_HAS_UNAME", Some("1"));
        } else {
            profile_sources.push("WindowsMMap.c");
        }
    }

    // fnctl() ലഭ്യമാകുന്നതിനായി ഞങ്ങൾ ഇത് നിർമ്മിക്കുന്ന യുണിക്സുകൾ ഉണ്ടെന്ന് കരുതുക
    if env::var_os("CARGO_CFG_UNIX").is_some() {
        cfg.define("COMPILER_RT_HAS_FCNTL_LCK", Some("1"));
    }

    // COMPILER_RT_HAS_ATOMICS എപ്പോൾ സജ്ജമാക്കണമെന്നതിനുള്ള നല്ലൊരു ഹ്യൂറിസ്റ്റിക് ആയിരിക്കണം ഇത്
    //
    if env::var_os("CARGO_CFG_TARGET_HAS_ATOMIC")
        .map(|features| features.to_string_lossy().to_lowercase().contains("ptr"))
        .unwrap_or(false)
    {
        cfg.define("COMPILER_RT_HAS_ATOMICS", Some("1"));
    }

    // ഞങ്ങൾ പ്രവർത്തിപ്പിക്കാൻ പോകുകയാണെങ്കിൽ ഇത് നിലവിലുണ്ടെന്ന കാര്യം ശ്രദ്ധിക്കുക (അല്ലാത്തപക്ഷം ഞങ്ങൾ പ്രൊഫൈലർ ബിൽഡിനുകൾ നിർമ്മിക്കുന്നില്ല).
    //
    let root = Path::new("../../src/llvm-project/compiler-rt");

    let src_root = root.join("lib").join("profile");
    for src in profile_sources {
        let path = src_root.join(src);
        if path.exists() {
            cfg.file(path);
        }
    }

    cfg.include(root.join("include"));
    cfg.warnings(false);
    cfg.compile("profiler-rt");
}