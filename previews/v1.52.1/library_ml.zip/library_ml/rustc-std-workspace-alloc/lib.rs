#![feature(no_core)]
#![no_core]

// ഈ crate ആവശ്യമായി വരുന്നതിന് rustc-std-വർക്ക്‌സ്‌പെയ്‌സ് കോർ കാണുക.

// ലിബാലോക്കിലെ അലോക്ക് മൊഡ്യൂളുമായി പൊരുത്തപ്പെടാതിരിക്കാൻ crate എന്ന് പേരുമാറ്റുക.
extern crate alloc as foo;

pub use foo::*;