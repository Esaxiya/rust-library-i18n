//! `Cell` (scoped) അസ്തിത്വ ജീവിതകാലത്തിനായുള്ള വേരിയൻറ്.

use std::cell::Cell;
use std::mem;
use std::ops::{Deref, DerefMut};

/// ആജീവനാന്തം ഉപയോഗിച്ച് ലാംഡ അപ്ലിക്കേഷൻ ടൈപ്പുചെയ്യുക.
#[allow(unused_lifetimes)]
pub trait ApplyL<'a> {
    type Out;
}

/// ആജീവനാന്തം എടുക്കുന്ന ലാംഡ ടൈപ്പ് ചെയ്യുക, അതായത്, `Lifetime -> Type`.
pub trait LambdaL: for<'a> ApplyL<'a> {}

impl<T: for<'a> ApplyL<'a>> LambdaL for T {}

// HACK(eddyb) പ്രൊജക്ഷൻ പരിമിതികളെ അടിസ്ഥാനമാക്കി ഒരു newtype FIXME(#52812) ഉപയോഗിച്ച് `&'a mut <T as ApplyL<'b>>::Out` ഉപയോഗിച്ച് പ്രവർത്തിക്കുക
//
pub struct RefMutL<'a, 'b, T: LambdaL>(&'a mut <T as ApplyL<'b>>::Out);

impl<'a, 'b, T: LambdaL> Deref for RefMutL<'a, 'b, T> {
    type Target = <T as ApplyL<'b>>::Out;
    fn deref(&self) -> &Self::Target {
        self.0
    }
}

impl<'a, 'b, T: LambdaL> DerefMut for RefMutL<'a, 'b, T> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        self.0
    }
}

pub struct ScopedCell<T: LambdaL>(Cell<<T as ApplyL<'static>>::Out>);

impl<T: LambdaL> ScopedCell<T> {
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new(value: <T as ApplyL<'static>>::Out) -> Self {
        ScopedCell(Cell::new(value))
    }

    /// `f` പ്രവർത്തിപ്പിക്കുമ്പോൾ `self` മുതൽ `replacement` വരെ മൂല്യം സജ്ജമാക്കുന്നു, ഇത് പഴയ മൂല്യം പരസ്പരം മാറ്റുന്നു.
    /// `f` പുറത്തുകടന്നതിനുശേഷം പഴയ മൂല്യം പുന ored സ്ഥാപിക്കപ്പെടും, panic പോലും, `f` വരുത്തിയ പരിഷ്‌ക്കരണങ്ങൾ ഉൾപ്പെടെ.
    ///
    ///
    pub fn replace<'a, R>(
        &self,
        replacement: <T as ApplyL<'a>>::Out,
        f: impl for<'b, 'c> FnOnce(RefMutL<'b, 'c, T>) -> R,
    ) -> R {
        /// `f` പരിഭ്രാന്തരായിട്ടുണ്ടെങ്കിലും സെൽ എല്ലായ്പ്പോഴും നിറയുന്നുവെന്ന് ഉറപ്പാക്കുന്ന റാപ്പർ (യഥാർത്ഥ അവസ്ഥയോടൊപ്പം, `f` ഓപ്‌ഷണലായി മാറ്റിയിരിക്കുന്നു).
        ///
        ///
        struct PutBackOnDrop<'a, T: LambdaL> {
            cell: &'a ScopedCell<T>,
            value: Option<<T as ApplyL<'static>>::Out>,
        }

        impl<'a, T: LambdaL> Drop for PutBackOnDrop<'a, T> {
            fn drop(&mut self) {
                self.cell.0.set(self.value.take().unwrap());
            }
        }

        let mut put_back_on_drop = PutBackOnDrop {
            cell: self,
            value: Some(self.0.replace(unsafe {
                let erased = mem::transmute_copy(&replacement);
                mem::forget(replacement);
                erased
            })),
        };

        f(RefMutL(put_back_on_drop.value.as_mut().unwrap()))
    }

    /// `f` പ്രവർത്തിപ്പിക്കുമ്പോൾ `self` മുതൽ `value` വരെ മൂല്യം സജ്ജമാക്കുന്നു.
    pub fn set<R>(&self, value: <T as ApplyL<'_>>::Out, f: impl FnOnce() -> R) -> R {
        self.replace(value, |_| f())
    }
}