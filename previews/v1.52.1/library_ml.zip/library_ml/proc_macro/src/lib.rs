//! പുതിയ മാക്രോകൾ നിർവചിക്കുമ്പോൾ മാക്രോ രചയിതാക്കൾക്കുള്ള ഒരു പിന്തുണാ ലൈബ്രറി.
//!
//! സ്റ്റാൻഡേർഡ് ഡിസ്‌ട്രിബ്യൂഷൻ നൽകിയ ഈ ലൈബ്രറി, പ്രവർത്തനപരമായി നിർവചിക്കപ്പെട്ട മാക്രോ നിർവചനങ്ങളായ ഫംഗ്ഷൻ പോലുള്ള മാക്രോസ് `#[proc_macro]`, മാക്രോ ആട്രിബ്യൂട്ടുകൾ `#[proc_macro_attribute]`, ഇഷ്‌ടാനുസൃത ഡെറിവ് ആട്രിബ്യൂട്ടുകൾ`#[proc_macro_derive]`എന്നിവ ഉപയോഗിക്കുന്നു.
//!
//!
//! കൂടുതൽ വിവരങ്ങൾക്ക് [the book] കാണുക.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// നിലവിൽ പ്രവർത്തിക്കുന്ന പ്രോഗ്രാമിലേക്ക് proc_macro ആക്സസ് ചെയ്തിട്ടുണ്ടോ എന്ന് നിർണ്ണയിക്കുന്നു.
///
/// Proc_macro crate എന്നത് നടപടിക്രമ മാക്രോകൾ നടപ്പിലാക്കുന്നതിനുള്ള ഉപയോഗത്തിനായി മാത്രമാണ്.ഒരു ബിൽഡ് സ്ക്രിപ്റ്റ് അല്ലെങ്കിൽ യൂണിറ്റ് ടെസ്റ്റ് അല്ലെങ്കിൽ സാധാരണ Rust ബൈനറി പോലുള്ള ഒരു നടപടിക്രമ മാക്രോയ്ക്ക് പുറത്ത് നിന്ന് അഭ്യർത്ഥിച്ചാൽ ഈ crate panic ലെ എല്ലാ പ്രവർത്തനങ്ങളും.
///
/// മാക്രോ, മാക്രോ ഇതര ഉപയോഗ കേസുകളെ പിന്തുണയ്‌ക്കാൻ രൂപകൽപ്പന ചെയ്‌തിരിക്കുന്ന Rust ലൈബ്രറികൾ പരിഗണിച്ച്, proc_macro-യുടെ API ഉപയോഗിക്കുന്നതിന് ആവശ്യമായ ഇൻഫ്രാസ്ട്രക്ചർ നിലവിൽ ലഭ്യമാണോ എന്ന് കണ്ടെത്തുന്നതിന് പരിഭ്രാന്തരാകാത്ത ഒരു മാർഗം `proc_macro::is_available()` നൽകുന്നു.
/// ഒരു നടപടിക്രമ മാക്രോയുടെ ഉള്ളിൽ നിന്ന് അഭ്യർത്ഥിച്ചാൽ ശരിയാണ്, മറ്റേതെങ്കിലും ബൈനറിയിൽ നിന്ന് അഭ്യർത്ഥിച്ചാൽ തെറ്റാണ്.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// ഈ crate നൽകിയ പ്രധാന തരം, tokens ന്റെ ഒരു അമൂർത്ത സ്ട്രീമിനെ പ്രതിനിധീകരിക്കുന്നു, അല്ലെങ്കിൽ കൂടുതൽ വ്യക്തമായി പറഞ്ഞാൽ, token ട്രീകളുടെ ഒരു ശ്രേണി.
/// ആ തരം Z0 ടോക്കൺ 0 ഇസെഡ് ട്രീകളിലൂടെ ആവർത്തിക്കുന്നതിന് ഇന്റർഫേസുകൾ നൽകുന്നു, കൂടാതെ, ഒരു സ്ട്രീമിലേക്ക് നിരവധി Z0 ടോക്കൺ 0 ഇസെഡ് മരങ്ങൾ ശേഖരിക്കുന്നു.
///
///
/// ഇത് `#[proc_macro]`, `#[proc_macro_attribute]`, `#[proc_macro_derive]` നിർവചനങ്ങളുടെ ഇൻപുട്ടും output ട്ട്‌പുട്ടും ആണ്.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// `TokenStream::from_str`-ൽ നിന്ന് പിശക് മടങ്ങി.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// token ട്രീകളില്ലാത്ത ശൂന്യമായ `TokenStream` നൽകുന്നു.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// ഈ `TokenStream` ശൂന്യമാണോയെന്ന് പരിശോധിക്കുന്നു.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// സ്ട്രിംഗ് tokens ലേക്ക് തകർക്കുന്നതിനും tokens നെ token സ്ട്രീമിലേക്ക് പാഴ്‌സുചെയ്യുന്നതിനും ശ്രമിക്കുന്നു.
/// നിരവധി കാരണങ്ങളാൽ പരാജയപ്പെടാം, ഉദാഹരണത്തിന്, സ്ട്രിംഗിൽ അസന്തുലിതമായ ഡിലിമിറ്ററുകൾ അല്ലെങ്കിൽ ഭാഷയിൽ നിലവിലില്ലാത്ത പ്രതീകങ്ങൾ അടങ്ങിയിട്ടുണ്ടെങ്കിൽ.
///
/// പാഴ്‌സുചെയ്‌ത സ്‌ട്രീമിലെ എല്ലാ tokens-നും `Span::call_site()` സ്‌പാനുകൾ ലഭിക്കും.
///
/// NOTE: ചില പിശകുകൾ `LexError` മടങ്ങുന്നതിന് പകരം panics ന് കാരണമായേക്കാം.ഈ പിശകുകൾ പിന്നീട് `ലെക്സ് എററിലേക്ക് 'മാറ്റാനുള്ള അവകാശം ഞങ്ങളിൽ നിക്ഷിപ്തമാണ്.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, ബ്രിഡ്ജ് `to_string` മാത്രമേ നൽകുന്നുള്ളൂ, അതിനെ അടിസ്ഥാനമാക്കി `fmt::Display` നടപ്പിലാക്കുക (രണ്ടും തമ്മിലുള്ള സാധാരണ ബന്ധത്തിന്റെ വിപരീതം).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// `Delimiter::None` ഡിലിമിറ്ററുകളും നെഗറ്റീവ് ന്യൂമെറിക് ലിറ്ററലുകളും ഉള്ള `ടോക്കൺട്രീ: : ഗ്രൂപ്പ്` ഒഴികെ, token സ്ട്രീമിനെ അതേ token സ്ട്രീമിലേക്ക് (മൊഡ്യൂളോ സ്പാനുകൾ) പരിവർത്തനം ചെയ്യാനാകുമെന്ന് കരുതുന്ന ഒരു സ്ട്രിംഗായി പ്രിന്റ് ചെയ്യുന്നു.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// ഡീബഗ്ഗിംഗിന് സൗകര്യപ്രദമായ ഫോമിൽ token പ്രിന്റുചെയ്യുന്നു.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// ഒരൊറ്റ token ട്രീ അടങ്ങിയിരിക്കുന്ന token സ്ട്രീം സൃഷ്ടിക്കുന്നു.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// ഒരൊറ്റ സ്ട്രീമിലേക്ക് നിരവധി token മരങ്ങൾ ശേഖരിക്കുന്നു.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// token സ്ട്രീമുകളിലെ ഒരു "flattening" പ്രവർത്തനം, ഒന്നിലധികം token സ്ട്രീമുകളിൽ നിന്ന് token ട്രീകളെ ഒരൊറ്റ സ്ട്രീമിലേക്ക് ശേഖരിക്കുന്നു.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) സാധ്യമായ ഒപ്റ്റിമൈസ് ചെയ്ത നടപ്പിലാക്കൽ if/when ഉപയോഗിക്കുക.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// ഇറ്ററേറ്ററുകൾ പോലുള്ള `TokenStream` തരത്തിനായുള്ള പൊതു നടപ്പാക്കൽ വിശദാംശങ്ങൾ.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// `ടോക്കൺ‌സ്ട്രീമി'ന്റെ` ടോക്കൺ‌ട്രീ'യുടെ ഒരു ആവർത്തനം.
    /// ആവർത്തനം "shallow" ആണ്, ഉദാ. ആവർത്തനം വേർതിരിച്ച ഗ്രൂപ്പുകളിലേക്ക് തിരിയുന്നില്ല, മാത്രമല്ല മുഴുവൻ ഗ്രൂപ്പുകളെയും token ട്രീകളായി നൽകുന്നു.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` അനിയന്ത്രിതമായ tokens സ്വീകരിച്ച് ഇൻപുട്ടിനെ വിവരിക്കുന്ന `TokenStream`-ലേക്ക് വികസിക്കുന്നു.
/// ഉദാഹരണത്തിന്, `quote!(a + b)` ഒരു എക്സ്പ്രഷൻ സൃഷ്ടിക്കും, അത് വിലയിരുത്തുമ്പോൾ, `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// `$` ഉപയോഗിച്ചാണ് അൺ‌കോട്ടിംഗ് ചെയ്യുന്നത്, കൂടാതെ അടുത്ത ഐഡന്റിറ്റി അൺ‌കോട്ട് ചെയ്യാത്ത പദമായി എടുത്ത് പ്രവർത്തിക്കുന്നു.
/// `$` തന്നെ ഉദ്ധരിക്കാൻ, `$$` ഉപയോഗിക്കുക.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// മാക്രോ വിപുലീകരണ വിവരങ്ങൾക്കൊപ്പം ഉറവിട കോഡിന്റെ ഒരു പ്രദേശം.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// `self` സ്‌പാനിൽ നൽകിയിരിക്കുന്ന `message` ഉപയോഗിച്ച് ഒരു പുതിയ `Diagnostic` സൃഷ്‌ടിക്കുന്നു.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// മാക്രോ ഡെഫനിഷൻ സൈറ്റിൽ പരിഹരിക്കുന്ന ഒരു സ്‌പാൻ.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// നിലവിലെ നടപടിക്രമ മാക്രോയുടെ അഭ്യർത്ഥനയുടെ ദൈർഘ്യം.
    /// ഈ സ്‌പാൻ ഉപയോഗിച്ച് സൃഷ്‌ടിച്ച ഐഡന്റിഫയറുകൾ മാക്രോ കോൾ ലൊക്കേഷനിൽ (കോൾ-സൈറ്റ് ശുചിത്വം) നേരിട്ട് എഴുതിയതുപോലെ പരിഹരിക്കും, കൂടാതെ മാക്രോ കോൾ സൈറ്റിലെ മറ്റ് കോഡുകളും അവ റഫർ ചെയ്യാൻ കഴിയും.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// `macro_rules` ശുചിത്വത്തെ പ്രതിനിധീകരിക്കുന്ന ഒരു സ്പാൻ, ചിലപ്പോൾ മാക്രോ ഡെഫനിഷൻ സൈറ്റിലും (ലോക്കൽ വേരിയബിളുകൾ, ലേബലുകൾ, `$crate`) ചിലപ്പോൾ മാക്രോ കോൾ സൈറ്റിലും (മറ്റെല്ലാം) പരിഹരിക്കുന്നു.
    ///
    /// കോൾ സൈറ്റിൽ നിന്നാണ് സ്‌പാൻ ലൊക്കേഷൻ എടുത്തത്.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// ഈ സ്‌പാൻ ചൂണ്ടിക്കാണിക്കുന്ന യഥാർത്ഥ ഉറവിട ഫയൽ.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// മുമ്പത്തെ മാക്രോ വിപുലീകരണത്തിലെ tokens-നായുള്ള `Span`, അതിൽ നിന്ന് `self` ജനറേറ്റുചെയ്തിട്ടുണ്ടെങ്കിൽ.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// `self` ൽ നിന്ന് ജനറേറ്റുചെയ്‌ത ഉറവിട ഉറവിട കോഡിനുള്ള സ്‌പാൻ.
    /// ഈ `Span` മറ്റ് മാക്രോ എക്സ്പാൻഷനുകളിൽ നിന്ന് ജനറേറ്റുചെയ്തിട്ടില്ലെങ്കിൽ, റിട്ടേൺ മൂല്യം `*self` ന് തുല്യമാണ്.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// ഈ സ്‌പാനിനായി ഉറവിട ഫയലിൽ ആരംഭ line/column നേടുന്നു.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// ഈ സ്‌പാനിനായി ഉറവിട ഫയലിൽ അവസാനിക്കുന്ന line/column നേടുന്നു.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// `self`, `other` എന്നിവ ഉൾക്കൊള്ളുന്ന ഒരു പുതിയ സ്പാൻ സൃഷ്ടിക്കുന്നു.
    ///
    /// `self`, `other` എന്നിവ വ്യത്യസ്ത ഫയലുകളിൽ നിന്നുള്ളതാണെങ്കിൽ `None` നൽകുന്നു.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// `self`-ന് സമാനമായ line/column വിവരങ്ങളുള്ള ഒരു പുതിയ സ്‌പാൻ സൃഷ്‌ടിക്കുന്നു, പക്ഷേ അത് `other`-ൽ ഉള്ളതുപോലെ ചിഹ്നങ്ങൾ പരിഹരിക്കുന്നു.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// `self`-ന് സമാനമായ നെയിം റെസല്യൂഷൻ പ്രവർത്തനരീതിയും എന്നാൽ `other`-ന്റെ line/column വിവരവും ഉപയോഗിച്ച് ഒരു പുതിയ സ്‌പാൻ സൃഷ്‌ടിക്കുന്നു.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// അവ തുല്യമാണോയെന്ന് കാണാൻ സ്‌പാനുകളുമായി താരതമ്യപ്പെടുത്തുന്നു.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// ഒരു സ്‌പാനിന് പിന്നിലെ ഉറവിട വാചകം നൽകുന്നു.
    /// സ്‌പെയ്‌സുകളും അഭിപ്രായങ്ങളും ഉൾപ്പെടെ യഥാർത്ഥ ഉറവിട കോഡ് ഇത് സംരക്ഷിക്കുന്നു.
    /// സ്‌പാൻ യഥാർത്ഥ ഉറവിട കോഡിനോട് യോജിക്കുന്നുവെങ്കിൽ മാത്രമേ ഇത് ഒരു ഫലം നൽകൂ.
    ///
    /// Note: ഒരു മാക്രോയുടെ നിരീക്ഷിക്കാവുന്ന ഫലം tokens നെ മാത്രമേ ആശ്രയിക്കൂ, അല്ലാതെ ഈ ഉറവിട വാചകത്തെ ആശ്രയിക്കരുത്.
    ///
    /// ഈ ഫംഗ്ഷന്റെ ഫലം ഡയഗ്നോസ്റ്റിക്സിനായി മാത്രം ഉപയോഗിക്കുന്നതിനുള്ള മികച്ച ശ്രമമാണ്.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// ഡീബഗ്ഗിംഗിന് സൗകര്യപ്രദമായ രൂപത്തിൽ ഒരു സ്‌പാൻ പ്രിന്റുചെയ്യുന്നു.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// ഒരു `Span` ന്റെ ആരംഭമോ അവസാനമോ പ്രതിനിധീകരിക്കുന്ന ഒരു ലൈൻ-നിര ജോഡി.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// സ്‌പാൻ (inclusive) ആരംഭിക്കുന്ന അല്ലെങ്കിൽ അവസാനിക്കുന്ന ഉറവിട ഫയലിലെ 1-സൂചിക രേഖ.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// സ്‌പാൻ (inclusive) ആരംഭിക്കുകയോ അവസാനിക്കുകയോ ചെയ്യുന്ന ഉറവിട ഫയലിലെ 0-സൂചിക നിര (UTF-8 പ്രതീകങ്ങളിൽ).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// തന്നിരിക്കുന്ന `Span`-ന്റെ ഉറവിട ഫയൽ.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// ഈ ഉറവിട ഫയലിലേക്കുള്ള പാത്ത് നേടുന്നു.
    ///
    /// ### Note
    /// ഈ `SourceFile` മായി ബന്ധപ്പെട്ട കോഡ് സ്പാൻ ഒരു ബാഹ്യ മാക്രോ സൃഷ്ടിച്ചതാണെങ്കിൽ, ഈ മാക്രോ, ഇത് ഫയൽസിസ്റ്റത്തിലെ യഥാർത്ഥ പാതയായിരിക്കില്ല.
    /// പരിശോധിക്കാൻ [`is_real`] ഉപയോഗിക്കുക.
    ///
    /// `is_real` `true` നൽകുന്നുണ്ടെങ്കിൽപ്പോലും, കമാൻഡ് ലൈനിൽ `--remap-path-prefix` പാസായിട്ടുണ്ടെങ്കിൽ, നൽകിയിരിക്കുന്ന പാത യഥാർത്ഥത്തിൽ സാധുവായിരിക്കില്ല.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// ഈ ഉറവിട ഫയൽ ഒരു യഥാർത്ഥ ഉറവിട ഫയലാണെങ്കിൽ ഒരു ബാഹ്യ മാക്രോയുടെ വിപുലീകരണത്താൽ സൃഷ്ടിക്കപ്പെട്ടതല്ലെങ്കിൽ `true` നൽകുന്നു.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // ഇന്റർ‌ക്രേറ്റ് സ്‌പാൻ‌സ് നടപ്പിലാക്കുന്നതുവരെ ഇത് ഒരു ഹാക്കാണ്, കൂടാതെ ബാഹ്യ മാക്രോകളിൽ‌ജനറേറ്റുചെയ്‌ത സ്‌പാനുകൾ‌ക്കായി ഞങ്ങൾക്ക് യഥാർത്ഥ ഉറവിട ഫയലുകൾ‌നേടാൻ‌കഴിയും.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// ഒരൊറ്റ token അല്ലെങ്കിൽ token മരങ്ങളുടെ വേർതിരിച്ച ശ്രേണി (ഉദാ. `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// ബ്രാക്കറ്റ് ഡിലിമിറ്ററുകളാൽ ചുറ്റപ്പെട്ട ഒരു token സ്ട്രീം.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// ഒരു ഐഡന്റിഫയർ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// ഒരൊറ്റ ചിഹ്ന പ്രതീകം (`+`, `,`, `$`, മുതലായവ).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// അക്ഷരാർത്ഥത്തിൽ (`'a'`), സ്ട്രിംഗ് (`"hello"`), നമ്പർ (`2.3`) മുതലായവ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// അടങ്ങിയിരിക്കുന്ന token-ന്റെ അല്ലെങ്കിൽ വേർതിരിച്ച സ്ട്രീമിന്റെ `span` രീതിയിലേക്ക് നിയുക്തമാക്കി ഈ ട്രീയുടെ സ്‌പാൻ നൽകുന്നു.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// *ഈ token* ന് മാത്രമായി സ്‌പാൻ കോൺഫിഗർ ചെയ്യുന്നു.
    ///
    /// ഈ token ഒരു `Group` ആണെങ്കിൽ ഈ രീതി ഓരോ ആന്തരിക tokens ന്റെയും ദൈർഘ്യം ക്രമീകരിക്കില്ല, ഇത് ഓരോ വേരിയന്റിന്റെയും `set_span` രീതിയിലേക്ക് നിയുക്തമാക്കും.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// ഡീബഗ്ഗിംഗിന് സൗകര്യപ്രദമായ രൂപത്തിൽ token ട്രീ പ്രിന്റുചെയ്യുന്നു.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // ഡെറിവേഡ് ഡീബഗിലെ സ്ട്രക്റ്റ് തരത്തിൽ ഇവയിൽ ഓരോന്നിനും പേരുണ്ട്, അതിനാൽ ഇൻഡെറക്ഷന്റെ ഒരു അധിക പാളി ഉപയോഗിച്ച് വിഷമിക്കേണ്ട
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, ബ്രിഡ്ജ് `to_string` മാത്രമേ നൽകുന്നുള്ളൂ, അതിനെ അടിസ്ഥാനമാക്കി `fmt::Display` നടപ്പിലാക്കുക (രണ്ടും തമ്മിലുള്ള സാധാരണ ബന്ധത്തിന്റെ വിപരീതം).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// `Delimiter::None` ഡിലിമിറ്ററുകളും നെഗറ്റീവ് ന്യൂമെറിക് ലിറ്ററലുകളും ഉള്ള `ടോക്കൺട്രീ: : ഗ്രൂപ്പ്` ഒഴികെ, token ട്രീയെ അതേ token ട്രീയിലേക്ക് (മൊഡ്യൂളോ സ്പാനുകൾ) മാറ്റാനാകാത്ത ഒരു സ്ട്രിംഗായി പ്രിന്റ് ചെയ്യുന്നു.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// വേർതിരിച്ച token സ്ട്രീം.
///
/// ഒരു `Group` ആന്തരികമായി ഒരു `TokenStream` ഉൾക്കൊള്ളുന്നു, അത് ചുറ്റും `ഡിലിമിറ്റർ`.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// token ട്രീകളുടെ ഒരു ശ്രേണി എങ്ങനെ വേർതിരിച്ചിരിക്കുന്നു എന്ന് വിവരിക്കുന്നു.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// ഒരു വ്യക്തമായ ഡിലിമിറ്റർ, ഉദാഹരണത്തിന്, "macro variable" `$var`-ൽ നിന്ന് വരുന്ന tokens ന് ചുറ്റും ദൃശ്യമാകാം.
    /// `$var` `1 + 2` ഉള്ള `$var * 3` പോലുള്ള സന്ദർഭങ്ങളിൽ ഓപ്പറേറ്റർ മുൻ‌ഗണനകൾ സംരക്ഷിക്കേണ്ടത് പ്രധാനമാണ്.
    /// ഒരു സ്ട്രിംഗിലൂടെ ഒരു token സ്ട്രീമിന്റെ റ round ണ്ട്ട്രിപ്പിനെ വ്യക്തമായ ഡിലിമിറ്ററുകൾ അതിജീവിച്ചേക്കില്ല.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// തന്നിരിക്കുന്ന ഡിലിമിറ്ററും token സ്ട്രീമും ഉപയോഗിച്ച് ഒരു പുതിയ `Group` സൃഷ്ടിക്കുന്നു.
    ///
    /// ഈ കൺ‌സ്‌ട്രക്റ്റർ‌ഈ ഗ്രൂപ്പിനായുള്ള സ്‌പാൻ‌`Span::call_site()` ആയി സജ്ജമാക്കും.
    /// സ്‌പാൻ മാറ്റുന്നതിന് നിങ്ങൾക്ക് ചുവടെയുള്ള `set_span` രീതി ഉപയോഗിക്കാം.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// ഈ `Group`-ന്റെ ഡിലിമിറ്റർ നൽകുന്നു
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// ഈ `Group`-ൽ വേർതിരിച്ച tokens-ന്റെ `TokenStream` നൽകുന്നു.
    ///
    /// മടങ്ങിയെത്തിയ token സ്ട്രീമിൽ മുകളിൽ നൽകിയ ഡിലിമിറ്റർ ഉൾപ്പെടുന്നില്ല.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// ഈ token സ്ട്രീമിന്റെ ഡിലിമിറ്ററുകൾക്കായുള്ള സ്‌പാൻ നൽകുന്നു, ഇത് മുഴുവൻ `Group`-ലും വ്യാപിക്കുന്നു.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// ഈ ഗ്രൂപ്പിന്റെ ഓപ്പണിംഗ് ഡിലിമിറ്ററിലേക്ക് പോയിന്റുചെയ്യുന്ന സ്‌പാൻ നൽകുന്നു.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// ഈ ഗ്രൂപ്പിന്റെ ക്ലോസിംഗ് ഡിലിമിറ്ററിലേക്ക് പോയിന്റുചെയ്യുന്ന സ്‌പാൻ നൽകുന്നു.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// ഈ `ഗ്രൂപ്പിന്റെ ഡിലിമിറ്ററുകൾക്കുള്ള സ്‌പാൻ കോൺഫിഗർ ചെയ്യുന്നു, പക്ഷേ അതിന്റെ ആന്തരിക tokens അല്ല.
    ///
    /// ഈ രീതി ഈ ഗ്രൂപ്പ് സ്‌പാൻ ചെയ്‌തിരിക്കുന്ന എല്ലാ ആന്തരിക tokens-ന്റെയും സ്‌പാൻ ** സജ്ജീകരിക്കില്ല, മറിച്ച് ഇത് `Group` ലെവലിൽ tokens എന്ന ഡിലിമിറ്ററിന്റെ സ്‌പാൻ മാത്രമേ സജ്ജമാക്കൂ.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, ബ്രിഡ്ജ് `to_string` മാത്രമേ നൽകുന്നുള്ളൂ, അതിനെ അടിസ്ഥാനമാക്കി `fmt::Display` നടപ്പിലാക്കുക (രണ്ടും തമ്മിലുള്ള സാധാരണ ബന്ധത്തിന്റെ വിപരീതം).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// `Delimiter::None` ഡിലിമിറ്ററുകളുള്ള `ടോക്കൺട്രീ: : ഗ്രൂപ്പ്` ഒഴികെ, ഒരേ ഗ്രൂപ്പിലേക്ക് (മൊഡ്യൂളോ സ്പാനുകൾ) നഷ്ടപ്പെടാതെ പരിവർത്തനം ചെയ്യാവുന്ന ഒരു സ്‌ട്രിംഗായി ഗ്രൂപ്പിനെ പ്രിന്റുചെയ്യുന്നു.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `+`, `-` അല്ലെങ്കിൽ `#` പോലുള്ള ഒരൊറ്റ ചിഹ്ന പ്രതീകമാണ് `Punct`.
///
/// `+=` പോലുള്ള മൾട്ടി-ക്യാരക്ടർ ഓപ്പറേറ്റർമാരെ `Punct` ന്റെ രണ്ട് ഉദാഹരണങ്ങളായി പ്രതിനിധീകരിക്കുന്നു.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// ഒരു `Punct` മറ്റൊരു `Punct` ഉടൻ പിന്തുടരുകയാണോ അല്ലെങ്കിൽ മറ്റൊരു token അല്ലെങ്കിൽ വൈറ്റ്സ്പേസ് പിന്തുടരുകയാണോ.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// ഉദാ, `+ =`, `+ident` അല്ലെങ്കിൽ `+()`-ൽ `Alone` ആണ്.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// ഉദാ., `+` എന്നത് `+=` അല്ലെങ്കിൽ `'#`-ൽ `Joint` ആണ്.
    /// കൂടാതെ, സിംഗിൾ ഉദ്ധരണി `'`, ഐഡന്റിഫയറുകളുമായി ചേർന്ന് ജീവിതകാലം `'ident` രൂപപ്പെടുത്തുന്നു.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// തന്നിരിക്കുന്ന പ്രതീകത്തിൽ നിന്നും സ്‌പെയ്‌സിംഗിൽ നിന്നും ഒരു പുതിയ `Punct` സൃഷ്‌ടിക്കുന്നു.
    /// `ch` ആർ‌ഗ്യുമെൻറ് ഭാഷ അനുവദിക്കുന്ന ഒരു സാധുവായ ചിഹ്ന പ്രതീകമായിരിക്കണം, അല്ലാത്തപക്ഷം പ്രവർത്തനം panic ആയിരിക്കും.
    ///
    /// മടങ്ങിയ `Punct`-ന് `Span::call_site()`-ന്റെ സ്ഥിരസ്ഥിതി സ്‌പാൻ ഉണ്ടാകും, അത് ചുവടെയുള്ള `set_span` രീതി ഉപയോഗിച്ച് കൂടുതൽ ക്രമീകരിക്കാൻ കഴിയും.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// ഈ ചിഹ്നന പ്രതീകത്തിന്റെ മൂല്യം `char` ആയി നൽകുന്നു.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// ഈ ചിഹ്ന പ്രതീകത്തിന്റെ സ്‌പെയ്‌സിംഗ് നൽകുന്നു, ഇത് ഉടൻ തന്നെ token സ്ട്രീമിലെ മറ്റൊരു `Punct` പിന്തുടരുന്നുണ്ടോ എന്ന് സൂചിപ്പിക്കുന്നു, അതിനാൽ അവ ഒരു മൾട്ടി-ക്യാരക്ടർ ഓപ്പറേറ്റർ (`Joint`)-ലേക്ക് സംയോജിപ്പിക്കാൻ സാധ്യതയുണ്ട്, അല്ലെങ്കിൽ ഇതിന് ശേഷം മറ്റ് token അല്ലെങ്കിൽ വൈറ്റ്‌സ്‌പെയ്‌സ് (`Alone`) ഉണ്ട്, അതിനാൽ ഓപ്പറേറ്ററിന് തീർച്ചയായും അവസാനിച്ചു.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// ഈ വിരാമചിഹ്ന പ്രതീകത്തിനായി സ്‌പാൻ നൽകുന്നു.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// ഈ വിരാമചിഹ്ന പ്രതീകത്തിനായി സ്‌പാൻ കോൺഫിഗർ ചെയ്യുക.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, ബ്രിഡ്ജ് `to_string` മാത്രമേ നൽകുന്നുള്ളൂ, അതിനെ അടിസ്ഥാനമാക്കി `fmt::Display` നടപ്പിലാക്കുക (രണ്ടും തമ്മിലുള്ള സാധാരണ ബന്ധത്തിന്റെ വിപരീതം).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// വിരാമചിഹ്ന പ്രതീകത്തെ ഒരു സ്‌ട്രിംഗായി പ്രിന്റുചെയ്യുന്നു, അത് നഷ്ടമില്ലാതെ അതേ പ്രതീകത്തിലേക്ക് പരിവർത്തനം ചെയ്യാനാകും.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// ഒരു ഐഡന്റിഫയർ (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// തന്നിരിക്കുന്ന `string`, നിർദ്ദിഷ്ട `span` എന്നിവ ഉപയോഗിച്ച് ഒരു പുതിയ `Ident` സൃഷ്ടിക്കുന്നു.
    /// `string` ആർ‌ഗ്യുമെൻറ് ഭാഷ അനുവദിക്കുന്ന ഒരു സാധുവായ ഐഡന്റിഫയർ‌ആയിരിക്കണം (കീവേഡുകൾ‌ഉൾപ്പെടെ, ഉദാ. `self` അല്ലെങ്കിൽ‌`fn`).അല്ലെങ്കിൽ, പ്രവർത്തനം panic ആയിരിക്കും.
    ///
    /// നിലവിൽ rustc-ൽ ഉള്ള `span`, ഈ ഐഡന്റിഫയറിനായി ശുചിത്വ വിവരങ്ങൾ ക്രമീകരിക്കുന്നു.
    ///
    /// ഈ സമയം വരെ, എക്സ് 100 എക്സ് വ്യക്തമായി എക്സ് 01 എക്സ് ശുചിത്വം തിരഞ്ഞെടുക്കുന്നു, അതിനർത്ഥം ഈ സ്പാൻ ഉപയോഗിച്ച് സൃഷ്ടിച്ച ഐഡന്റിഫയറുകൾ മാക്രോ കോളിന്റെ സ്ഥാനത്ത് നേരിട്ട് എഴുതിയത് പോലെ പരിഹരിക്കപ്പെടും, കൂടാതെ മാക്രോ കോൾ സൈറ്റിലെ മറ്റ് കോഡുകൾ റഫർ ചെയ്യാൻ കഴിയും. അവയും.
    ///
    ///
    /// `Span::def_site()` പോലുള്ള പിൽക്കാല സ്‌പാനുകൾ "definition-site" ശുചിത്വം തിരഞ്ഞെടുക്കാൻ അനുവദിക്കും, അതായത് ഈ സ്‌പാൻ ഉപയോഗിച്ച് സൃഷ്‌ടിച്ച ഐഡന്റിഫയറുകൾ മാക്രോ നിർവചനത്തിന്റെ സ്ഥാനത്ത് പരിഹരിക്കപ്പെടും, മാക്രോ കോൾ സൈറ്റിലെ മറ്റ് കോഡുകൾക്ക് അവ റഫർ ചെയ്യാൻ കഴിയില്ല.
    ///
    /// ശുചിത്വത്തിന്റെ നിലവിലെ പ്രാധാന്യം കാരണം, മറ്റ് tokens ൽ നിന്ന് വ്യത്യസ്തമായി, നിർമ്മാണത്തിൽ ഒരു `Span` വ്യക്തമാക്കേണ്ടതുണ്ട്.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// `Ident::new` പോലെ തന്നെ, പക്ഷേ ഒരു റോ ഐഡന്റിഫയർ (`r#ident`) സൃഷ്ടിക്കുന്നു.
    /// `string` ആർ‌ഗ്യുമെൻറ് ഭാഷ അനുവദിച്ച സാധുവായ ഐഡന്റിഫയറാണ് (കീവേഡുകൾ‌ഉൾപ്പെടെ, ഉദാ. `fn`).
    /// പാത്ത് സെഗ്‌മെന്റുകളിൽ ഉപയോഗയോഗ്യമായ കീവേഡുകൾ (ഉദാ
    /// `self`, `സൂപ്പർ`) പിന്തുണയ്‌ക്കുന്നില്ല, മാത്രമല്ല ഇത് ഒരു panic ന് കാരണമാകും.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// [`to_string`](Self::to_string) നൽകിയ മുഴുവൻ സ്ട്രിംഗും ഉൾക്കൊള്ളുന്ന ഈ `Ident`-ന്റെ സ്‌പാൻ നൽകുന്നു.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// ഈ `Ident`-ന്റെ സ്‌പാൻ കോൺഫിഗർ ചെയ്യുന്നു, ഒരുപക്ഷേ അതിന്റെ ശുചിത്വ സന്ദർഭം മാറ്റാം.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, ബ്രിഡ്ജ് `to_string` മാത്രമേ നൽകുന്നുള്ളൂ, അതിനെ അടിസ്ഥാനമാക്കി `fmt::Display` നടപ്പിലാക്കുക (രണ്ടും തമ്മിലുള്ള സാധാരണ ബന്ധത്തിന്റെ വിപരീതം).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// ഐഡന്റിഫയറിനെ ഒരു സ്ട്രിംഗായി പ്രിന്റ് ചെയ്യുന്നു, അത് നഷ്ടമില്ലാതെ അതേ ഐഡന്റിഫയറിലേക്ക് പരിവർത്തനം ചെയ്യണം.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// അക്ഷരീയ സ്ട്രിംഗ് (`"hello"`), ബൈറ്റ് സ്ട്രിംഗ് (`b"hello"`), പ്രതീകം (`'a'`), ബൈറ്റ് പ്രതീകം (`b'a'`), ഒരു സഫിക്‌സിനൊപ്പമോ അല്ലാതെയോ ഒരു സംഖ്യ അല്ലെങ്കിൽ ഫ്ലോട്ടിംഗ് പോയിന്റ് നമ്പർ (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// `true`, `false` പോലുള്ള ബൂളിയൻ അക്ഷരങ്ങൾ ഇവിടെ ഉൾപ്പെടുന്നില്ല, അവ `ഐഡന്റിറ്റി` ആണ്.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// നിർദ്ദിഷ്ട മൂല്യത്തിനൊപ്പം ഒരു പുതിയ സഫിക്‌സ് ഇൻറിജർ ലിറ്ററൽ സൃഷ്‌ടിക്കുന്നു.
        ///
        /// ഈ ഫംഗ്ഷൻ `1u32` പോലുള്ള ഒരു സംഖ്യ സൃഷ്ടിക്കും, അവിടെ വ്യക്തമാക്കിയ സംഖ്യ മൂല്യം token ന്റെ ആദ്യ ഭാഗമാണ്, കൂടാതെ ഇന്റഗ്രലും അവസാനം സഫിക്‌സ് ചെയ്യുന്നു.
        /// നെഗറ്റീവ് നമ്പറുകളിൽ നിന്ന് സൃഷ്ടിച്ച ലിറ്ററലുകൾ `TokenStream` അല്ലെങ്കിൽ സ്ട്രിംഗുകളിലൂടെയുള്ള റ round ണ്ട്-ട്രിപ്പുകളെ അതിജീവിച്ചേക്കില്ല, അവ രണ്ട് tokens (`-`, പോസിറ്റീവ് ലിറ്ററൽ) ആയി വിഭജിക്കാം.
        ///
        ///
        /// ഈ രീതിയിലൂടെ സൃഷ്ടിച്ച ലിറ്ററലുകൾക്ക് സ്ഥിരസ്ഥിതിയായി `Span::call_site()` സ്പാൻ ഉണ്ട്, അത് ചുവടെയുള്ള `set_span` രീതി ഉപയോഗിച്ച് ക്രമീകരിക്കാൻ കഴിയും.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// നിർദ്ദിഷ്ട മൂല്യത്തിനൊപ്പം ഒരു പുതിയ അൺ‌ഫിക്സ്ഡ് ഇൻ‌റിജർ‌ലിറ്ററൽ‌സൃഷ്‌ടിക്കുന്നു.
        ///
        /// ഈ ഫംഗ്ഷൻ `1` പോലുള്ള ഒരു സംഖ്യ സൃഷ്ടിക്കും, അവിടെ വ്യക്തമാക്കിയ സംഖ്യ മൂല്യം token-ന്റെ ആദ്യ ഭാഗമാണ്.
        /// ഈ token-ൽ സഫിക്‌സ് ഒന്നും വ്യക്തമാക്കിയിട്ടില്ല, അതായത് `Literal::i8_unsuffixed(1)` പോലുള്ള ഇൻവോക്കേഷനുകൾ `Literal::u32_unsuffixed(1)`-ന് തുല്യമാണ്.
        /// നെഗറ്റീവ് നമ്പറുകളിൽ നിന്ന് സൃഷ്ടിച്ച ലിറ്ററലുകൾ `TokenStream` അല്ലെങ്കിൽ സ്ട്രിംഗുകളിലൂടെ റൗണ്ട്രിപ്പുകളെ അതിജീവിച്ചേക്കില്ല, അവ രണ്ട് tokens (`-`, പോസിറ്റീവ് ലിറ്ററൽ) ആയി വിഭജിക്കാം.
        ///
        ///
        /// ഈ രീതിയിലൂടെ സൃഷ്ടിച്ച ലിറ്ററലുകൾക്ക് സ്ഥിരസ്ഥിതിയായി `Span::call_site()` സ്പാൻ ഉണ്ട്, അത് ചുവടെയുള്ള `set_span` രീതി ഉപയോഗിച്ച് ക്രമീകരിക്കാൻ കഴിയും.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// ഒരു പുതിയ അൺ‌ഫിക്സ്ഡ് ഫ്ലോട്ടിംഗ്-പോയിൻറ് അക്ഷരാർത്ഥത്തിൽ സൃഷ്ടിക്കുന്നു.
    ///
    /// ഈ കൺ‌സ്‌ട്രക്റ്റർ‌`Literal::i8_unsuffixed` പോലുള്ളവയ്‌ക്ക് സമാനമാണ്, അവിടെ ഫ്ലോട്ടിന്റെ മൂല്യം token ലേക്ക് നേരിട്ട് പുറപ്പെടുവിക്കുന്നു, പക്ഷേ സഫിക്‌സ് ഉപയോഗിക്കുന്നില്ല, അതിനാൽ ഇത് പിന്നീട് `f64` ആയി കംപൈലറിൽ അനുമാനിക്കാം.
    ///
    /// നെഗറ്റീവ് നമ്പറുകളിൽ നിന്ന് സൃഷ്ടിച്ച ലിറ്ററലുകൾ `TokenStream` അല്ലെങ്കിൽ സ്ട്രിംഗുകളിലൂടെ റൗണ്ട്രിപ്പുകളെ അതിജീവിച്ചേക്കില്ല, അവ രണ്ട് tokens (`-`, പോസിറ്റീവ് ലിറ്ററൽ) ആയി വിഭജിക്കാം.
    ///
    /// # Panics
    ///
    /// ഈ ഫംഗ്ഷന് നിർദ്ദിഷ്ട ഫ്ലോട്ട് പരിമിതമാണെന്ന് ആവശ്യപ്പെടുന്നു, ഉദാഹരണത്തിന് ഇത് അനന്തമോ NaN ഉം ആണെങ്കിൽ ഈ ഫംഗ്ഷൻ panic ആയിരിക്കും.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// ഫ്ലോട്ടിംഗ്-പോയിന്റ് അക്ഷരാർത്ഥത്തിൽ ഒരു പുതിയ സഫിക്‌സ് സൃഷ്‌ടിക്കുന്നു.
    ///
    /// ഈ കൺ‌സ്‌ട്രക്റ്റർ‌`1.0f32` പോലുള്ള ഒരു അക്ഷരീയത സൃഷ്ടിക്കും, അവിടെ വ്യക്തമാക്കിയ മൂല്യം token ന്റെ മുൻ‌ഭാഗവും `f32` token ന്റെ സഫിക്‌സും ആണ്.
    /// ഈ token എല്ലായ്പ്പോഴും കംപൈലറിലെ ഒരു `f32` ആയി അനുമാനിക്കും.
    /// നെഗറ്റീവ് നമ്പറുകളിൽ നിന്ന് സൃഷ്ടിച്ച ലിറ്ററലുകൾ `TokenStream` അല്ലെങ്കിൽ സ്ട്രിംഗുകളിലൂടെ റൗണ്ട്രിപ്പുകളെ അതിജീവിച്ചേക്കില്ല, അവ രണ്ട് tokens (`-`, പോസിറ്റീവ് ലിറ്ററൽ) ആയി വിഭജിക്കാം.
    ///
    ///
    /// # Panics
    ///
    /// ഈ ഫംഗ്ഷന് നിർദ്ദിഷ്ട ഫ്ലോട്ട് പരിമിതമാണെന്ന് ആവശ്യപ്പെടുന്നു, ഉദാഹരണത്തിന് ഇത് അനന്തമോ NaN ഉം ആണെങ്കിൽ ഈ ഫംഗ്ഷൻ panic ആയിരിക്കും.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// ഒരു പുതിയ അൺ‌ഫിക്സ്ഡ് ഫ്ലോട്ടിംഗ്-പോയിൻറ് അക്ഷരാർത്ഥത്തിൽ സൃഷ്ടിക്കുന്നു.
    ///
    /// ഈ കൺ‌സ്‌ട്രക്റ്റർ‌`Literal::i8_unsuffixed` പോലുള്ളവയ്‌ക്ക് സമാനമാണ്, അവിടെ ഫ്ലോട്ടിന്റെ മൂല്യം token ലേക്ക് നേരിട്ട് പുറപ്പെടുവിക്കുന്നു, പക്ഷേ സഫിക്‌സ് ഉപയോഗിക്കുന്നില്ല, അതിനാൽ ഇത് പിന്നീട് `f64` ആയി കംപൈലറിൽ അനുമാനിക്കാം.
    ///
    /// നെഗറ്റീവ് നമ്പറുകളിൽ നിന്ന് സൃഷ്ടിച്ച ലിറ്ററലുകൾ `TokenStream` അല്ലെങ്കിൽ സ്ട്രിംഗുകളിലൂടെ റൗണ്ട്രിപ്പുകളെ അതിജീവിച്ചേക്കില്ല, അവ രണ്ട് tokens (`-`, പോസിറ്റീവ് ലിറ്ററൽ) ആയി വിഭജിക്കാം.
    ///
    /// # Panics
    ///
    /// ഈ ഫംഗ്ഷന് നിർദ്ദിഷ്ട ഫ്ലോട്ട് പരിമിതമാണെന്ന് ആവശ്യപ്പെടുന്നു, ഉദാഹരണത്തിന് ഇത് അനന്തമോ NaN ഉം ആണെങ്കിൽ ഈ ഫംഗ്ഷൻ panic ആയിരിക്കും.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// ഫ്ലോട്ടിംഗ്-പോയിന്റ് അക്ഷരാർത്ഥത്തിൽ ഒരു പുതിയ സഫിക്‌സ് സൃഷ്‌ടിക്കുന്നു.
    ///
    /// ഈ കൺ‌സ്‌ട്രക്റ്റർ‌`1.0f64` പോലുള്ള ഒരു അക്ഷരീയത സൃഷ്ടിക്കും, അവിടെ വ്യക്തമാക്കിയ മൂല്യം token ന്റെ മുൻ‌ഭാഗവും `f64` token ന്റെ സഫിക്‌സും ആണ്.
    /// ഈ token എല്ലായ്പ്പോഴും കംപൈലറിലെ ഒരു `f64` ആയി അനുമാനിക്കും.
    /// നെഗറ്റീവ് നമ്പറുകളിൽ നിന്ന് സൃഷ്ടിച്ച ലിറ്ററലുകൾ `TokenStream` അല്ലെങ്കിൽ സ്ട്രിംഗുകളിലൂടെ റൗണ്ട്രിപ്പുകളെ അതിജീവിച്ചേക്കില്ല, അവ രണ്ട് tokens (`-`, പോസിറ്റീവ് ലിറ്ററൽ) ആയി വിഭജിക്കാം.
    ///
    ///
    /// # Panics
    ///
    /// ഈ ഫംഗ്ഷന് നിർദ്ദിഷ്ട ഫ്ലോട്ട് പരിമിതമാണെന്ന് ആവശ്യപ്പെടുന്നു, ഉദാഹരണത്തിന് ഇത് അനന്തമോ NaN ഉം ആണെങ്കിൽ ഈ ഫംഗ്ഷൻ panic ആയിരിക്കും.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// സ്ട്രിംഗ് അക്ഷരാർത്ഥത്തിൽ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// പ്രതീകം അക്ഷരാർത്ഥത്തിൽ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// ബൈറ്റ് സ്ട്രിംഗ് അക്ഷരാർത്ഥത്തിൽ.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// ഈ അക്ഷരത്തെ ഉൾക്കൊള്ളുന്ന സ്പാൻ നൽകുന്നു.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// ഈ അക്ഷരാർത്ഥവുമായി ബന്ധപ്പെട്ട സ്‌പാൻ കോൺഫിഗർ ചെയ്യുന്നു.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// `range` ശ്രേണിയിലെ ഉറവിട ബൈറ്റുകൾ മാത്രം ഉൾക്കൊള്ളുന്ന `self.span()`-ന്റെ ഉപസെറ്റായ `Span` നൽകുന്നു.
    /// ട്രിം ചെയ്ത സ്‌പാൻ `self`-ന്റെ പരിധിക്കപ്പുറത്താണെങ്കിൽ `None` നൽകുന്നു.
    ///
    // FIXME(SergioBenitez): ഉറവിടത്തിന്റെ UTF-8 അതിർത്തിയിൽ ബൈറ്റ് ശ്രേണി ആരംഭിക്കുകയും അവസാനിക്കുകയും ചെയ്യുന്നുണ്ടോയെന്ന് പരിശോധിക്കുക.
    // അല്ലെങ്കിൽ, ഉറവിട വാചകം അച്ചടിക്കുമ്പോൾ മറ്റെവിടെയെങ്കിലും ഒരു panic സംഭവിക്കാൻ സാധ്യതയുണ്ട്.
    // FIXME(SergioBenitez): `self.span()` യഥാർത്ഥത്തിൽ എന്താണ് മാപ്പ് ചെയ്യുന്നതെന്ന് ഉപയോക്താവിന് അറിയാൻ ഒരു മാർഗവുമില്ല, അതിനാൽ ഈ രീതിയെ നിലവിൽ അന്ധമായി മാത്രമേ വിളിക്കാൻ കഴിയൂ.
    // ഉദാഹരണത്തിന്, 'c' പ്രതീകത്തിനായുള്ള `to_string()` "'\u{63}'" നൽകുന്നു;ഉറവിട വാചകം 'c' ആണോ അതോ '\u{63}' ആണോ എന്ന് ഉപയോക്താവിന് അറിയാൻ ഒരു മാർഗവുമില്ല.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) `Option::cloned`-ന് സമാനമായ ഒന്ന്, പക്ഷേ `Bound<&T>`-ന്.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, ബ്രിഡ്ജ് `to_string` മാത്രമേ നൽകുന്നുള്ളൂ, അതിനെ അടിസ്ഥാനമാക്കി `fmt::Display` നടപ്പിലാക്കുക (രണ്ടും തമ്മിലുള്ള സാധാരണ ബന്ധത്തിന്റെ വിപരീതം).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// അക്ഷരാർത്ഥത്തിൽ ഒരു സ്ട്രിംഗായി പ്രിന്റുചെയ്യുന്നു, അത് നഷ്ടമില്ലാതെ അതേ അക്ഷരത്തിലേക്ക് പരിവർത്തനം ചെയ്യണം (ഫ്ലോട്ടിംഗ് പോയിൻറ് ലിറ്ററലുകൾക്ക് സാധ്യമായ റൗണ്ടിംഗ് ഒഴികെ).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// പരിസ്ഥിതി വേരിയബിളുകളിലേക്കുള്ള ട്രാക്ക് ആക്സസ്.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// ഒരു എൻ‌വയോൺ‌മെൻറ് വേരിയബിൾ‌വീണ്ടെടുത്ത് ഡിപൻഡൻസി വിവരങ്ങൾ‌സൃഷ്‌ടിക്കുന്നതിന് ഇത് ചേർ‌ക്കുക.
    /// കംപൈലർ എക്സിക്യൂട്ട് ചെയ്യുന്ന ബിൽഡ് സിസ്റ്റം, കമ്പൈലേഷൻ സമയത്ത് വേരിയബിൾ ആക്സസ് ചെയ്തതായി അറിയും, കൂടാതെ ആ വേരിയബിളിന്റെ മൂല്യം മാറുമ്പോൾ ബിൽഡ് വീണ്ടും പ്രവർത്തിപ്പിക്കാനും കഴിയും.
    ///
    /// ഡിപൻഡൻസി ട്രാക്കിംഗ് കൂടാതെ, ഈ ഫംഗ്ഷൻ സ്റ്റാൻഡേർഡ് ലൈബ്രറിയിൽ നിന്നുള്ള `env::var` ന് തുല്യമായിരിക്കണം, അല്ലാതെ ആർഗ്യുമെന്റ് UTF-8 ആയിരിക്കണം.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}