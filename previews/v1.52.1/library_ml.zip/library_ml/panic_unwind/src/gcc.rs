//! libgcc/libunwind പിന്തുണയുള്ള panics നടപ്പിലാക്കൽ (ചില രൂപത്തിൽ).
//!
//! ഒഴിവാക്കൽ കൈകാര്യം ചെയ്യലിന്റെയും സ്റ്റാക്ക് അൺ‌വൈൻ‌ഡിംഗിന്റെയും പശ്ചാത്തലത്തിനായി ദയവായി "Exception Handling in LLVM" (llvm.org/docs/ExceptionHandling.html) ഉം അതിൽ‌നിന്നും ലിങ്കുചെയ്‌ത പ്രമാണങ്ങളും കാണുക.
//! ഇവയും നല്ല വായനയാണ്:
//!  * <https://itanium-cxx-abi.github.io/cxx-abi/abi-eh.html>
//!  * <http://monoinfinito.wordpress.com/series/exception-handling-in-c/>
//!  * <http://www.airs.com/blog/index.php?s=exception+frames>
//!
//! ## ഒരു ഹ്രസ്വ സംഗ്രഹം
//!
//! ഒഴിവാക്കൽ കൈകാര്യം ചെയ്യൽ രണ്ട് ഘട്ടങ്ങളിലായാണ് നടക്കുന്നത്: ഒരു തിരയൽ ഘട്ടം, വൃത്തിയാക്കൽ ഘട്ടം.
//!
//! രണ്ട് ഘട്ടങ്ങളിലും അൺവൈൻഡർ സ്റ്റാക്ക് ഫ്രെയിമിൽ നിന്നുള്ള വിവരങ്ങൾ ഉപയോഗിച്ച് സ്റ്റാക്ക് ഫ്രെയിമുകൾ മുകളിൽ നിന്ന് താഴേക്ക് നടക്കുന്നു നിലവിലെ പ്രോസസിന്റെ മൊഡ്യൂളുകളുടെ വിഭാഗങ്ങൾ വേർപെടുത്തുക (ഇവിടെ "module" ഒരു OS മൊഡ്യൂളിനെ സൂചിപ്പിക്കുന്നു, അതായത്, എക്സിക്യൂട്ടബിൾ അല്ലെങ്കിൽ ഡൈനാമിക് ലൈബ്രറി).
//!
//!
//! ഓരോ സ്റ്റാക്ക് ഫ്രെയിമിനും, ഇത് ബന്ധപ്പെട്ട "personality routine"-നെ അഭ്യർത്ഥിക്കുന്നു, അതിന്റെ വിലാസം അൺ‌വൈൻഡ് വിവര വിഭാഗത്തിലും സംഭരിക്കപ്പെടുന്നു.
//!
//! തിരയൽ ഘട്ടത്തിൽ, എക്സ്റ്റൻഷൻ ഒബ്ജക്റ്റ് എറിയുന്നത് പരിശോധിക്കുക, ആ സ്റ്റാക്ക് ഫ്രെയിമിൽ അത് പിടിക്കണമോ എന്ന് തീരുമാനിക്കുക എന്നതാണ് ഒരു വ്യക്തിത്വ ദിനചര്യയുടെ ജോലി.ഹാൻഡ്‌ലർ ഫ്രെയിം തിരിച്ചറിഞ്ഞുകഴിഞ്ഞാൽ, വൃത്തിയാക്കൽ ഘട്ടം ആരംഭിക്കുന്നു.
//!
//! വൃത്തിയാക്കൽ‌ഘട്ടത്തിൽ‌, അൺ‌വൈൻഡർ‌ഓരോ വ്യക്തിത്വ ദിനചര്യയും വീണ്ടും ക്ഷണിക്കുന്നു.
//! നിലവിലെ സ്റ്റാക്ക് ഫ്രെയിമിനായി ഏത് (എന്തെങ്കിലുമുണ്ടെങ്കിൽ) ക്ലീനപ്പ് കോഡ് പ്രവർത്തിപ്പിക്കേണ്ടതുണ്ടെന്ന് ഇത് തീരുമാനിക്കുന്നു.അങ്ങനെയാണെങ്കിൽ, നിയന്ത്രണം ഫംഗ്ഷൻ ബോഡിയിലെ ഒരു പ്രത്യേക branch ലേക്ക് മാറ്റുന്നു, ഇത് ഡിസ്ട്രക്റ്ററുകളെ ക്ഷണിക്കുകയും മെമ്മറി സ്വതന്ത്രമാക്കുകയും ചെയ്യുന്ന "landing pad".
//! ലാൻ‌ഡിംഗ് പാഡിന്റെ അവസാനത്തിൽ‌, നിയന്ത്രണം അൺ‌വൈൻഡർ‌, അൺ‌വൈൻ‌ഡിംഗ് റെസ്യൂമെകളിലേക്ക് തിരികെ മാറ്റുന്നു.
//!
//! ഹാൻഡ്‌ലർ ഫ്രെയിം ലെവലിലേക്ക് സ്റ്റാക്ക് മുറിവേൽപ്പിച്ചുകഴിഞ്ഞാൽ, നിർത്താതെ നിർത്തുകയും അവസാന വ്യക്തിത്വ പതിവ് നിയന്ത്രണം ക്യാച്ച് ബ്ലോക്കിലേക്ക് മാറ്റുകയും ചെയ്യുന്നു.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;

use crate::dwarf::eh::{self, EHAction, EHContext};
use libc::{c_int, uintptr_t};
use unwind as uw;

#[repr(C)]
struct Exception {
    _uwe: uw::_Unwind_Exception,
    cause: Box<dyn Any + Send>,
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let exception = Box::new(Exception {
        _uwe: uw::_Unwind_Exception {
            exception_class: rust_exception_class(),
            exception_cleanup,
            private: [0; uw::unwinder_private_data_size],
        },
        cause: data,
    });
    let exception_param = Box::into_raw(exception) as *mut uw::_Unwind_Exception;
    return uw::_Unwind_RaiseException(exception_param) as u32;

    extern "C" fn exception_cleanup(
        _unwind_code: uw::_Unwind_Reason_Code,
        exception: *mut uw::_Unwind_Exception,
    ) {
        unsafe {
            let _: Box<Exception> = Box::from_raw(exception as *mut Exception);
            super::__rust_drop_panic();
        }
    }
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    let exception = ptr as *mut uw::_Unwind_Exception;
    if (*exception).exception_class != rust_exception_class() {
        uw::_Unwind_DeleteException(exception);
        super::__rust_foreign_exception();
    } else {
        let exception = Box::from_raw(exception as *mut Exception);
        exception.cause
    }
}

// Rust-ന്റെ ഒഴിവാക്കൽ ക്ലാസ് ഐഡന്റിഫയർ.
// ഒഴിവാക്കൽ അവരുടെ സ്വന്തം റൺടൈം ഉപയോഗിച്ചാണോ എന്ന് നിർണ്ണയിക്കാൻ ഇത് വ്യക്തിഗത ദിനചര്യകൾ ഉപയോഗിക്കുന്നു.
fn rust_exception_class() -> uw::_Unwind_Exception_Class {
    // MOZ R 0 RUST-വെണ്ടർ, ഭാഷ
    0x4d4f5a_00_52555354
}

// ഓരോ ആർക്കിടെക്ചറിനുമായി എൽ‌എൽ‌വി‌എമ്മിന്റെ എക്സ് 100 എക്സ്, എക്സ് 01 എക്സ് എന്നിവയിൽ നിന്ന് രജിസ്റ്റർ ഐഡികൾ ഉയർത്തി, തുടർന്ന് രജിസ്റ്റർ ഡെഫനിഷൻ ടേബിളുകൾ വഴി ഡി‌ഡബ്ല്യുആർ‌എഫ് രജിസ്റ്റർ നമ്പറുകളിലേക്ക് മാപ്പുചെയ്തു (സാധാരണ<arch>രജിസ്റ്റർഇൻഫോ.ടിഡി, എക്സ് 02 എക്‌സിനായി തിരയുക).
//
// http://llvm.org/docs/WritingAnLLVMBackend.html#defining-a-register ഉം കാണുക.
//
//

#[cfg(target_arch = "x86")]
const UNWIND_DATA_REG: (i32, i32) = (0, 2); // EAX, EDX

#[cfg(target_arch = "x86_64")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // RAX, RDX

#[cfg(any(target_arch = "arm", target_arch = "aarch64"))]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1/X0, X1

#[cfg(any(target_arch = "mips", target_arch = "mips64"))]
const UNWIND_DATA_REG: (i32, i32) = (4, 5); // A0, A1

#[cfg(any(target_arch = "powerpc", target_arch = "powerpc64"))]
const UNWIND_DATA_REG: (i32, i32) = (3, 4); // R3, R4/X3, X4

#[cfg(target_arch = "s390x")]
const UNWIND_DATA_REG: (i32, i32) = (6, 7); // R6, R7

#[cfg(any(target_arch = "sparc", target_arch = "sparc64"))]
const UNWIND_DATA_REG: (i32, i32) = (24, 25); // I0, I1

#[cfg(target_arch = "hexagon")]
const UNWIND_DATA_REG: (i32, i32) = (0, 1); // R0, R1

#[cfg(any(target_arch = "riscv64", target_arch = "riscv32"))]
const UNWIND_DATA_REG: (i32, i32) = (10, 11); // x10, x11

// GCC ന്റെ C, C++ വ്യക്തിത്വ ദിനചര്യകളെ അടിസ്ഥാനമാക്കിയുള്ളതാണ് ഇനിപ്പറയുന്ന കോഡ്.റഫറൻസിനായി, കാണുക:
// https://github.com/gcc-mirror/gcc/blob/master/libstdc++-v3/libsupc++/eh_personality.cc
// https://github.com/gcc-mirror/gcc/blob/trunk/libgcc/unwind-c.c

cfg_if::cfg_if! {
    if #[cfg(all(target_arch = "arm", not(target_os = "ios"), not(target_os = "netbsd")))] {
        // ARM EHABI വ്യക്തിത്വ ദിനചര്യ.
        // http://infocenter.arm.com/help/topic/com.arm.doc.ihi0038b/IHI0038B_ehabi.pdf
        //
        // iOS പകരം എസ്‌ജെ‌എൽ‌ജെ അൺ‌വൈൻ‌ഡിംഗ് ഉപയോഗിക്കുന്നതിനാൽ‌സ്ഥിരസ്ഥിതി പതിവ് ഉപയോഗിക്കുന്നു.
        #[lang = "eh_personality"]
        unsafe extern "C" fn rust_eh_personality(state: uw::_Unwind_State,
                                                 exception_object: *mut uw::_Unwind_Exception,
                                                 context: *mut uw::_Unwind_Context)
                                                 -> uw::_Unwind_Reason_Code {
            let state = state as c_int;
            let action = state & uw::_US_ACTION_MASK as c_int;
            let search_phase = if action == uw::_US_VIRTUAL_UNWIND_FRAME as c_int {
                // ARM-ലെ ബാക്ക്‌ട്രെയ്‌സുകൾ വ്യക്തിത്വ ദിനചര്യയെ സ്റ്റേറ്റ്==_US_VIRTUAL_UNWIND_FRAME |_US_FORCE_UNWIND.
                // അത്തരം സാഹചര്യങ്ങളിൽ സ്റ്റാക്ക് ഒഴിവാക്കുന്നത് തുടരാൻ ഞങ്ങൾ ആഗ്രഹിക്കുന്നു, അല്ലാത്തപക്ഷം ഞങ്ങളുടെ എല്ലാ ബാക്ക്‌ട്രെയ്‌സുകളും __rust_try-ൽ അവസാനിക്കും
                //
                //
                if state & uw::_US_FORCE_UNWIND as c_int != 0 {
                    return continue_unwind(exception_object, context);
                }
                true
            } else if action == uw::_US_UNWIND_FRAME_STARTING as c_int {
                false
            } else if action == uw::_US_UNWIND_FRAME_RESUME as c_int {
                return continue_unwind(exception_object, context);
            } else {
                return uw::_URC_FAILURE;
            };

            // _Unwind_Context ഫംഗ്ഷൻ, എൽ‌എസ്‌ഡി‌എ പോയിന്ററുകൾ എന്നിവപോലുള്ളവ സൂക്ഷിക്കുന്നുവെന്ന് DWARF അൺ‌വൈൻഡർ അനുമാനിക്കുന്നു, എന്നിരുന്നാലും ARM EHABI അവയെ ഒഴിവാക്കൽ ഒബ്‌ജക്റ്റിലേക്ക് പ്രതിഷ്ഠിക്കുന്നു.
            // സന്ദർഭ പോയിന്റർ മാത്രം എടുക്കുന്ന _Unwind_GetLanguageSpecificData() പോലുള്ള ഫംഗ്ഷനുകളുടെ ഒപ്പുകൾ സംരക്ഷിക്കുന്നതിന്, ARM-ന്റെ "scratch register" (r12)-നായി കരുതിവച്ചിരിക്കുന്ന ലൊക്കേഷൻ ഉപയോഗിച്ച്, GCC വ്യക്തിഗത ദിനചര്യകൾ സന്ദർഭത്തിൽ ഒഴിവാക്കൽ_ഓബ്ജക്റ്റിലേക്ക് ഒരു പോയിന്റർ സ്ഥാപിക്കുന്നു.
            //
            //
            //
            //
            uw::_Unwind_SetGR(context,
                              uw::UNWIND_POINTER_REG,
                              exception_object as uw::_Unwind_Ptr);
            // ... കൂടുതൽ‌തത്ത്വപരമായ സമീപനം, ഞങ്ങളുടെ ലിബൺ‌വിൻഡ് ബൈൻ‌ഡിംഗുകളിൽ‌ARM ന്റെ _Unwind_Context ന്റെ പൂർണ്ണമായ നിർ‌വചനം നൽകുകയും ആവശ്യമായ ഡാറ്റ അവിടെ നിന്ന് നേരിട്ട് ലഭ്യമാക്കുകയും ചെയ്യുക, DWARF അനുയോജ്യത പ്രവർ‌ത്തനങ്ങളെ മറികടക്കുക എന്നതാണ്.
            //
            //

            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FAILURE,
            };
            if search_phase {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => return continue_unwind(exception_object, context),
                    EHAction::Catch(_) => {
                        // എക്സെപ്ഷൻ ഒബ്ജക്റ്റിന്റെ ബാരിയർ കാഷെയിൽ എസ്പി മൂല്യം അപ്ഡേറ്റ് ചെയ്യുന്നതിന് EHABI ന് വ്യക്തിഗത ദിനചര്യ ആവശ്യമാണ്.
                        //
                        (*exception_object).private[5] =
                            uw::_Unwind_GetGR(context, uw::UNWIND_SP_REG);
                        return uw::_URC_HANDLER_FOUND;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            } else {
                match eh_action {
                    EHAction::None => return continue_unwind(exception_object, context),
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                                          exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        return uw::_URC_INSTALL_CONTEXT;
                    }
                    EHAction::Terminate => return uw::_URC_FAILURE,
                }
            }

            // ARM EHABI-ൽ മടങ്ങിവരുന്നതിനുമുമ്പ് ഒരൊറ്റ സ്റ്റാക്ക് ഫ്രെയിം അൺ‌വൈൻഡ് ചെയ്യുന്നതിന് വ്യക്തിത്വ ദിനചര്യ ഉത്തരവാദിയാണ് (ARM EHABI Sec.
            // 6.1).
            unsafe fn continue_unwind(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code {
                if __gnu_unwind_frame(exception_object, context) == uw::_URC_NO_REASON {
                    uw::_URC_CONTINUE_UNWIND
                } else {
                    uw::_URC_FAILURE
                }
            }
            // libgcc-ൽ നിർവചിച്ചിരിക്കുന്നു
            extern "C" {
                fn __gnu_unwind_frame(exception_object: *mut uw::_Unwind_Exception,
                                      context: *mut uw::_Unwind_Context)
                                      -> uw::_Unwind_Reason_Code;
            }
        }
    } else {
        // സ്ഥിരസ്ഥിതി വ്യക്തിഗത ദിനചര്യ, ഇത് മിക്ക ടാർഗെറ്റുകളിലും നേരിട്ടും SEH വഴി Windows x86_64-ലും ഉപയോഗിക്കുന്നു.
        //
        unsafe extern "C" fn rust_eh_personality_impl(version: c_int,
                                                      actions: uw::_Unwind_Action,
                                                      _exception_class: uw::_Unwind_Exception_Class,
                                                      exception_object: *mut uw::_Unwind_Exception,
                                                      context: *mut uw::_Unwind_Context)
                                                      -> uw::_Unwind_Reason_Code {
            if version != 1 {
                return uw::_URC_FATAL_PHASE1_ERROR;
            }
            let eh_action = match find_eh_action(context) {
                Ok(action) => action,
                Err(_) => return uw::_URC_FATAL_PHASE1_ERROR,
            };
            if actions as i32 & uw::_UA_SEARCH_PHASE as i32 != 0 {
                match eh_action {
                    EHAction::None |
                    EHAction::Cleanup(_) => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Catch(_) => uw::_URC_HANDLER_FOUND,
                    EHAction::Terminate => uw::_URC_FATAL_PHASE1_ERROR,
                }
            } else {
                match eh_action {
                    EHAction::None => uw::_URC_CONTINUE_UNWIND,
                    EHAction::Cleanup(lpad) |
                    EHAction::Catch(lpad) => {
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.0,
                            exception_object as uintptr_t);
                        uw::_Unwind_SetGR(context, UNWIND_DATA_REG.1, 0);
                        uw::_Unwind_SetIP(context, lpad);
                        uw::_URC_INSTALL_CONTEXT
                    }
                    EHAction::Terminate => uw::_URC_FATAL_PHASE2_ERROR,
                }
            }
        }

        cfg_if::cfg_if! {
            if #[cfg(all(windows, target_arch = "x86_64", target_env = "gnu"))] {
                // x86_64 MinGW ടാർ‌ഗെറ്റുകളിൽ‌, അൺ‌വൈൻ‌ഡിംഗ് മെക്കാനിസം SEH ആണ്, എന്നിരുന്നാലും അൺ‌വൈൻഡ് ഹാൻ‌ഡ്‌ലർ ഡാറ്റ (aka LSDA) GCC-അനുയോജ്യമായ എൻ‌കോഡിംഗ് ഉപയോഗിക്കുന്നു.
                //
                #[lang = "eh_personality"]
                #[allow(nonstandard_style)]
                unsafe extern "C" fn rust_eh_personality(exceptionRecord: *mut uw::EXCEPTION_RECORD,
                        establisherFrame: uw::LPVOID,
                        contextRecord: *mut uw::CONTEXT,
                        dispatcherContext: *mut uw::DISPATCHER_CONTEXT)
                        -> uw::EXCEPTION_DISPOSITION {
                    uw::_GCC_specific_handler(exceptionRecord,
                                             establisherFrame,
                                             contextRecord,
                                             dispatcherContext,
                                             rust_eh_personality_impl)
                }
            } else {
                // ഞങ്ങളുടെ മിക്ക ടാർഗെറ്റുകളുടെയും വ്യക്തിഗത ദിനചര്യ.
                #[lang = "eh_personality"]
                unsafe extern "C" fn rust_eh_personality(version: c_int,
                        actions: uw::_Unwind_Action,
                        exception_class: uw::_Unwind_Exception_Class,
                        exception_object: *mut uw::_Unwind_Exception,
                        context: *mut uw::_Unwind_Context)
                        -> uw::_Unwind_Reason_Code {
                    rust_eh_personality_impl(version,
                                             actions,
                                             exception_class,
                                             exception_object,
                                             context)
                }
            }
        }
    }
}

unsafe fn find_eh_action(context: *mut uw::_Unwind_Context) -> Result<EHAction, ()> {
    let lsda = uw::_Unwind_GetLanguageSpecificData(context) as *const u8;
    let mut ip_before_instr: c_int = 0;
    let ip = uw::_Unwind_GetIPInfo(context, &mut ip_before_instr);
    let eh_context = EHContext {
        // എൽ‌എസ്‌ഡി‌എ ശ്രേണി പട്ടികയിലെ അടുത്ത ഐ‌പി ശ്രേണിയിൽ‌ആകാവുന്ന കോൾ‌ഇൻ‌സ്ട്രക്ഷൻ‌കഴിഞ്ഞ 1 ബൈറ്റ് മടക്ക വിലാസം.
        //
        ip: if ip_before_instr != 0 { ip } else { ip - 1 },
        func_start: uw::_Unwind_GetRegionStart(context),
        get_text_start: &|| uw::_Unwind_GetTextRelBase(context),
        get_data_start: &|| uw::_Unwind_GetDataRelBase(context),
    };
    eh::find_eh_action(lsda, &eh_context)
}

// ഫ്രെയിം അൺവൈൻഡ് വിവര രജിസ്ട്രേഷൻ
//
// ഓരോ മൊഡ്യൂളിന്റെയും ചിത്രത്തിൽ ഒരു ഫ്രെയിം അൺ‌വൈൻഡ് വിവര വിഭാഗം അടങ്ങിയിരിക്കുന്നു (സാധാരണയായി ".eh_frame").പ്രക്രിയയിലേക്ക് ഒരു മൊഡ്യൂൾ loaded/unloaded ആയിരിക്കുമ്പോൾ, മെമ്മറിയിൽ ഈ വിഭാഗത്തിന്റെ സ്ഥാനത്തെക്കുറിച്ച് അൺ‌വൈൻഡറെ അറിയിക്കണം.അത് നേടുന്നതിനുള്ള രീതികൾ പ്ലാറ്റ്ഫോം അനുസരിച്ച് വ്യത്യാസപ്പെട്ടിരിക്കുന്നു.
// ചിലതിൽ (ഉദാ., Linux), അൺ‌വൈൻഡറിന് വിവര വിഭാഗങ്ങൾ സ്വന്തമായി കണ്ടെത്താനാകും (നിലവിൽ ലോഡുചെയ്ത മൊഡ്യൂളുകൾ dl_iterate_phdr() API and finding their ".eh_frame" sections) വഴി ചലനാത്മകമായി കണക്കാക്കുന്നതിലൂടെ; Windows പോലെ മറ്റുള്ളവയ്ക്കും അൺ‌വൈൻഡർ API വഴി അവരുടെ അൺ‌വൈൻഡ് വിവര വിഭാഗങ്ങൾ സജീവമായി രജിസ്റ്റർ ചെയ്യാൻ മൊഡ്യൂളുകൾ ആവശ്യമാണ്.
//
//
// GCC റൺടൈമിൽ ഞങ്ങളുടെ വിവരങ്ങൾ രജിസ്റ്റർ ചെയ്യുന്നതിന് rsbegin.rs-ൽ നിന്ന് പരാമർശിക്കുകയും വിളിക്കുകയും ചെയ്യുന്ന രണ്ട് ചിഹ്നങ്ങളെ ഈ മൊഡ്യൂൾ നിർവചിക്കുന്നു.
// സ്റ്റാക്ക് അൺ‌വൈൻ‌ഡിംഗ് നടപ്പിലാക്കുന്നത് (ഇപ്പോൾ‌) libgcc_eh ലേക്ക് മാറ്റിയിരിക്കുന്നു, എന്നിരുന്നാലും Rust crates ഏതെങ്കിലും GCC റൺ‌ടൈമുമായുള്ള ഏറ്റുമുട്ടലുകൾ‌ഒഴിവാക്കാൻ ഈ Rust-നിർദ്ദിഷ്ട എൻ‌ട്രി പോയിൻറുകൾ‌ഉപയോഗിക്കുന്നു.
//
//
//
//
//
//
//
//
#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frame_registry {
    extern "C" {
        fn __register_frame_info(eh_frame_begin: *const u8, object: *mut u8);
        fn __deregister_frame_info(eh_frame_begin: *const u8, object: *mut u8);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __register_frame_info(eh_frame_begin, object);
    }

    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8) {
        __deregister_frame_info(eh_frame_begin, object);
    }
}