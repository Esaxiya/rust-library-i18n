//! *സന്യാസി* ടാർഗെറ്റിനായി അൺ‌വൈൻ‌ഡിംഗ്.
//!
//! ഇപ്പോൾ ഞങ്ങൾ ഇതിനെ പിന്തുണയ്ക്കുന്നില്ല, അതിനാൽ ഇത് സ്റ്റബുകൾ മാത്രമാണ്.

use alloc::boxed::Box;
use core::any::Any;

pub unsafe fn cleanup(_ptr: *mut u8) -> Box<dyn Any + Send> {
    extern "C" {
        pub fn __rust_abort() -> !;
    }
    __rust_abort();
}

pub unsafe fn panic(_data: Box<dyn Any + Send>) -> u32 {
    extern "C" {
        pub fn __rust_abort() -> !;
    }
    __rust_abort();
}