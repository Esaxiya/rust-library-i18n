//! *Emscripten* ടാർ‌ഗെറ്റിനായി അൺ‌വൈൻ‌ഡിംഗ്.
//!
//! Unix പ്ലാറ്റ്‌ഫോമുകൾക്കായി Rust-ന്റെ പതിവ് ഒഴിവാക്കൽ നടപ്പിലാക്കൽ നേരിട്ട് ലിബൺ‌വൈൻഡ് API-കളിലേക്ക് വിളിക്കുമ്പോൾ, Emscripten-ൽ ഞങ്ങൾ C++ അൺ‌വൈൻ‌ഡിംഗ് API-കളിലേക്ക് വിളിക്കുന്നു.
//! എംസ്‌ക്രിപ്റ്റന്റെ റൺടൈം എല്ലായ്‌പ്പോഴും ആ API-കൾ നടപ്പിലാക്കുകയും ലിബൺ വിൻഡ് നടപ്പാക്കാതിരിക്കുകയും ചെയ്യുന്നതിനാൽ ഇത് ഒരു പര്യവേഷണം മാത്രമാണ്.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// ഇത് C++ ലെ std::type_info ന്റെ ലേ layout ട്ടുമായി പൊരുത്തപ്പെടുന്നു
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // `_` പ്രതീകമുപയോഗിച്ച് പ്രിഫിക്സിംഗ് പോലുള്ള മറ്റേതെങ്കിലും മാംഗ്ലിംഗ് * പ്രയോഗിക്കാതിരിക്കാനുള്ള എൽ‌എൽ‌വി‌എമ്മിലേക്കുള്ള ഒരു മാന്ത്രിക സിഗ്നലാണ് ഇവിടത്തെ മുൻ‌നിര `\x01` ബൈറ്റ്.
    //
    //
    // ഈ ചിഹ്നം C++ ന്റെ `std::type_info` ഉപയോഗിക്കുന്ന vtable ആണ്.
    // ടൈപ്പ് എക്സ് 100 എക്സ്, ടൈപ്പ് ഡിസ്ക്രിപ്റ്ററുകൾ എന്നിവയുടെ ഒബ്ജക്റ്റുകൾക്ക് ഈ പട്ടികയിലേക്ക് ഒരു പോയിന്റർ ഉണ്ട്.
    // മുകളിൽ നിർവചിച്ചിരിക്കുന്ന സി ++ ഇഎച്ച് ഘടനകളാണ് ടൈപ്പ് ഡിസ്ക്രിപ്റ്ററുകളെ പരാമർശിക്കുന്നത്, ഞങ്ങൾ ചുവടെ നിർമ്മിക്കുന്നു.
    //
    // യഥാർത്ഥ വലുപ്പം 3 ഉപയോഗത്തെക്കാൾ വലുതാണെന്നത് ശ്രദ്ധിക്കുക, പക്ഷേ മൂന്നാമത്തെ ഘടകത്തിലേക്ക് പോയിന്റുചെയ്യാൻ ഞങ്ങളുടെ vtable മാത്രമേ ആവശ്യമുള്ളൂ.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info ഒരു റസ്റ്റ്_പാനിക് ക്ലാസിന്
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // സാധാരണയായി ഞങ്ങൾ .as_ptr().add(2) ഉപയോഗിക്കും, പക്ഷേ ഇത് ഒരു കോൺസ്റ്റക്റ്റ് സന്ദർഭത്തിൽ പ്രവർത്തിക്കുന്നില്ല.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // ഇത് മന intention പൂർവ്വം സാധാരണ നെയിം മാംഗ്ലിംഗ് സ്കീം ഉപയോഗിക്കുന്നില്ല, കാരണം സി ++ ന് Rust panics നിർമ്മിക്കാനോ പിടിക്കാനോ കഴിയില്ല.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // ഇത് ആവശ്യമാണ്, കാരണം C++ കോഡിന് std::exception_ptr ഉപയോഗിച്ച് ഞങ്ങളുടെ എക്സിക്യൂഷൻ ക്യാപ്‌ചർ ചെയ്യാനും ഒന്നിലധികം തവണ പുനർവിചിന്തനം ചെയ്യാനും കഴിയും, ഒരുപക്ഷേ മറ്റൊരു ത്രെഡിൽ പോലും.
    //
    //
    caught: AtomicBool,

    // ഇത് ഒരു ഓപ്ഷനായിരിക്കേണ്ടതുണ്ട്, കാരണം ഒബ്ജക്റ്റിന്റെ ആയുസ്സ് സി ++ സെമാന്റിക്‌സിനെ പിന്തുടരുന്നു: ക്യാച്ച്_അൻ‌വിൻഡ് ബോക്സിനെ ഒഴിവാക്കലിൽ നിന്ന് നീക്കുമ്പോൾ അത് ഒഴിവാക്കൽ ഒബ്‌ജക്റ്റിനെ സാധുവായ അവസ്ഥയിൽ ഉപേക്ഷിക്കണം, കാരണം അതിന്റെ ഡിസ്ട്രക്റ്റർ ഇപ്പോഴും __cxa_end_catch വിളിക്കുന്നു.
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try യഥാർത്ഥത്തിൽ ഈ ഘടനയിലേക്ക് ഞങ്ങൾക്ക് ഒരു പോയിന്റർ നൽകുന്നു.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // panic-ലേക്ക് cleanup() അനുവദനീയമല്ലാത്തതിനാൽ, പകരം ഞങ്ങൾ നിർത്തലാക്കുന്നു.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}