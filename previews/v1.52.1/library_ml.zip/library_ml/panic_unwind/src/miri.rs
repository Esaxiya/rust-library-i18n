//! മിരിയ്ക്കായി panics വിച്ഛേദിക്കുന്നു.
use alloc::boxed::Box;
use core::any::Any;

// മിറി എഞ്ചിൻ‌ഞങ്ങൾ‌ക്കായി അറിയാതെ പ്രചരിപ്പിക്കുന്ന പേലോഡിന്റെ തരം.
// പോയിന്റർ വലുപ്പമുള്ളതായിരിക്കണം.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// വേർപെടുത്താൻ ആരംഭിക്കുന്നതിന് മിറി നൽകിയ ബാഹ്യ പ്രവർത്തനം.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // `miri_start_panic`-ലേക്ക് ഞങ്ങൾ കടന്നുപോകുന്ന പേലോഡ് ചുവടെയുള്ള `cleanup`-ൽ നമുക്ക് ലഭിക്കുന്ന ആർഗ്യുമെൻറ് ആയിരിക്കും.
    // അതിനാൽ പോയിന്റർ വലുപ്പമുള്ള എന്തെങ്കിലും ലഭിക്കുന്നതിന് ഞങ്ങൾ ഇത് ഒരു തവണ ബോക്സ് അപ്പ് ചെയ്യുക.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // അന്തർലീനമായ `Box` വീണ്ടെടുക്കുക.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}