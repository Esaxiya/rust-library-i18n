//! DWARF-എൻ‌കോഡുചെയ്‌ത ഡാറ്റ സ്ട്രീമുകൾ‌പാഴ്‌സുചെയ്യുന്നതിനുള്ള യൂട്ടിലിറ്റികൾ‌.
//! <http://www.dwarfstd.org>, DWARF-4 സ്റ്റാൻഡേർഡ്, വിഭാഗം 7, "Data Representation" കാണുക
//!

// ഈ മൊഡ്യൂൾ ഇപ്പോൾ x86_64-pc-windows-gnu മാത്രമേ ഉപയോഗിക്കുന്നുള്ളൂ, പക്ഷേ റിഗ്രഷനുകൾ ഒഴിവാക്കാൻ ഞങ്ങൾ എല്ലായിടത്തും ഇത് കംപൈൽ ചെയ്യുന്നു.
//
#![allow(unused)]

#[cfg(test)]
mod tests;

pub mod eh;

use core::mem;

pub struct DwarfReader {
    pub ptr: *const u8,
}

#[repr(C, packed)]
struct Unaligned<T>(T);

impl DwarfReader {
    pub fn new(ptr: *const u8) -> DwarfReader {
        DwarfReader { ptr }
    }

    // DWARF സ്ട്രീമുകൾ നിറഞ്ഞിരിക്കുന്നു, അതിനാൽ ഉദാ. ഒരു u32 4-ബൈറ്റ് അതിർത്തിയിൽ വിന്യസിക്കേണ്ടതില്ല.
    // കർശനമായ വിന്യാസ ആവശ്യകതകളുള്ള പ്ലാറ്റ്‌ഫോമുകളിൽ ഇത് പ്രശ്‌നങ്ങൾക്ക് കാരണമായേക്കാം.
    // ഒരു "packed" സ്ട്രക്റ്റിൽ ഡാറ്റ പൊതിയുന്നതിലൂടെ, ഞങ്ങൾ "misalignment-safe" കോഡ് ജനറേറ്റ് ചെയ്യാൻ ബാക്കെൻഡിനോട് പറയുന്നു.
    //
    pub unsafe fn read<T: Copy>(&mut self) -> T {
        let Unaligned(result) = *(self.ptr as *const Unaligned<T>);
        self.ptr = self.ptr.add(mem::size_of::<T>());
        result
    }

    // ULEB128, SLEB128 എൻ‌കോഡിംഗുകൾ‌വിഭാഗം 7.6, "Variable Length Data" ൽ നിർ‌വചിച്ചിരിക്കുന്നു.
    //
    pub unsafe fn read_uleb128(&mut self) -> u64 {
        let mut shift: usize = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        result
    }

    pub unsafe fn read_sleb128(&mut self) -> i64 {
        let mut shift: u32 = 0;
        let mut result: u64 = 0;
        let mut byte: u8;
        loop {
            byte = self.read::<u8>();
            result |= ((byte & 0x7F) as u64) << shift;
            shift += 7;
            if byte & 0x80 == 0 {
                break;
            }
        }
        // sign-extend
        if shift < u64::BITS && (byte & 0x40) != 0 {
            result |= (!0 as u64) << shift;
        }
        result as i64
    }
}