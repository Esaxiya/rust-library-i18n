//! GCC-ശൈലി ഭാഷാ-നിർദ്ദിഷ്ട ഡാറ്റ ഏരിയ (LSDA) പാഴ്‌സിംഗ് വിശദാംശങ്ങൾക്ക് കാണുക:
//!  * <http://refspecs.linuxfoundation.org/LSB_3.0.0/LSB-PDA/LSB-PDA/ehframechpt.html>
//!  * <http://mentorembedded.github.io/cxx-abi/exceptions.pdf>
//!  * <http://www.airs.com/blog/archives/460>
//!  * <http://www.airs.com/blog/archives/464>
//!
//! GCC ഉറവിട ട്രീയിൽ ഒരു റഫറൻസ് നടപ്പിലാക്കൽ കണ്ടെത്തിയേക്കാം (ഈ എഴുത്തിന്റെ `<root>/libgcc/unwind-c.c`).
//!
//!

#![allow(non_upper_case_globals)]
#![allow(unused)]

use crate::dwarf::DwarfReader;
use core::mem;

pub const DW_EH_PE_omit: u8 = 0xFF;
pub const DW_EH_PE_absptr: u8 = 0x00;

pub const DW_EH_PE_uleb128: u8 = 0x01;
pub const DW_EH_PE_udata2: u8 = 0x02;
pub const DW_EH_PE_udata4: u8 = 0x03;
pub const DW_EH_PE_udata8: u8 = 0x04;
pub const DW_EH_PE_sleb128: u8 = 0x09;
pub const DW_EH_PE_sdata2: u8 = 0x0A;
pub const DW_EH_PE_sdata4: u8 = 0x0B;
pub const DW_EH_PE_sdata8: u8 = 0x0C;

pub const DW_EH_PE_pcrel: u8 = 0x10;
pub const DW_EH_PE_textrel: u8 = 0x20;
pub const DW_EH_PE_datarel: u8 = 0x30;
pub const DW_EH_PE_funcrel: u8 = 0x40;
pub const DW_EH_PE_aligned: u8 = 0x50;

pub const DW_EH_PE_indirect: u8 = 0x80;

#[derive(Copy, Clone)]
pub struct EHContext<'a> {
    pub ip: usize,                             // നിലവിലെ നിർദ്ദേശ പോയിന്റർ
    pub func_start: usize,                     // നിലവിലെ ഫംഗ്ഷന്റെ വിലാസം
    pub get_text_start: &'a dyn Fn() -> usize, // Get address of the code section
    pub get_data_start: &'a dyn Fn() -> usize, // Get address of the data section
}

pub enum EHAction {
    None,
    Cleanup(usize),
    Catch(usize),
    Terminate,
}

pub const USING_SJLJ_EXCEPTIONS: bool = cfg!(all(target_os = "ios", target_arch = "arm"));

pub unsafe fn find_eh_action(lsda: *const u8, context: &EHContext<'_>) -> Result<EHAction, ()> {
    if lsda.is_null() {
        return Ok(EHAction::None);
    }

    let func_start = context.func_start;
    let mut reader = DwarfReader::new(lsda);

    let start_encoding = reader.read::<u8>();
    // ലാൻഡിംഗ് പാഡ് ഓഫ്‌സെറ്റുകൾക്കുള്ള അടിസ്ഥാന വിലാസം
    let lpad_base = if start_encoding != DW_EH_PE_omit {
        read_encoded_pointer(&mut reader, context, start_encoding)?
    } else {
        func_start
    };

    let ttype_encoding = reader.read::<u8>();
    if ttype_encoding != DW_EH_PE_omit {
        // Rust ഒഴിവാക്കൽ തരങ്ങൾ വിശകലനം ചെയ്യുന്നില്ല, അതിനാൽ ടൈപ്പ് ടേബിളിനെക്കുറിച്ച് ഞങ്ങൾ ശ്രദ്ധിക്കുന്നില്ല
        reader.read_uleb128();
    }

    let call_site_encoding = reader.read::<u8>();
    let call_site_table_length = reader.read_uleb128();
    let action_table = reader.ptr.offset(call_site_table_length as isize);
    let ip = context.ip;

    if !USING_SJLJ_EXCEPTIONS {
        while reader.ptr < action_table {
            let cs_start = read_encoded_pointer(&mut reader, context, call_site_encoding)?;
            let cs_len = read_encoded_pointer(&mut reader, context, call_site_encoding)?;
            let cs_lpad = read_encoded_pointer(&mut reader, context, call_site_encoding)?;
            let cs_action = reader.read_uleb128();
            // കോൾ‌സൈറ്റ് പട്ടിക cs_start ഉപയോഗിച്ച് അടുക്കിയിരിക്കുന്നു, അതിനാൽ ഞങ്ങൾ ip കടന്നുപോയിട്ടുണ്ടെങ്കിൽ, ഞങ്ങൾ തിരയൽ നിർത്തിയേക്കാം.
            //
            if ip < func_start + cs_start {
                break;
            }
            if ip < func_start + cs_start + cs_len {
                if cs_lpad == 0 {
                    return Ok(EHAction::None);
                } else {
                    let lpad = lpad_base + cs_lpad;
                    return Ok(interpret_cs_action(cs_action, lpad));
                }
            }
        }
        // ഐപി പട്ടികയിൽ ഇല്ല.ഇത് സംഭവിക്കരുത് ... പക്ഷേ ഇത് സംഭവിക്കുന്നു: #35011 ഇഷ്യു ചെയ്യുക.
        // അതിനാൽ EHAction::Terminate തിരികെ നൽകുന്നതിനുപകരം ഞങ്ങൾ ഇത് ചെയ്യുന്നു.
        Ok(EHAction::None)
    } else {
        // SjLj പതിപ്പ്:
        // കോൾ-സൈറ്റ് പട്ടികയിലേക്കുള്ള ഒരു സൂചികയാണ് എക്സ് 100 എക്സ്, ഇതിൽ രണ്ട് ഒഴിവാക്കലുകൾ ഉണ്ട്:
        // -1 'no-action', 0 എന്നാൽ 'terminate' എന്നാണ് അർത്ഥമാക്കുന്നത്.
        match ip as isize {
            -1 => return Ok(EHAction::None),
            0 => return Ok(EHAction::Terminate),
            _ => (),
        }
        let mut idx = ip;
        loop {
            let cs_lpad = reader.read_uleb128();
            let cs_action = reader.read_uleb128();
            idx -= 1;
            if idx == 0 {
                // Sjlj-നായി ഒരിക്കലും ശൂന്യമായ ലാൻഡിംഗ് പാഡ് ഉണ്ടാകരുത്-അത് ഒരു -1 കോൾ സൈറ്റ് സൂചിക സൂചിപ്പിക്കുമായിരുന്നു.
                //
                let lpad = (cs_lpad + 1) as usize;
                return Ok(interpret_cs_action(cs_action, lpad));
            }
        }
    }
}

fn interpret_cs_action(cs_action: u64, lpad: usize) -> EHAction {
    if cs_action == 0 {
        // Cs_action 0 ആണെങ്കിൽ ഇത് ഒരു ക്ലീനപ്പ് (Drop::drop) ആണ്.
        // Rust panics, വിദേശ ഒഴിവാക്കലുകൾ എന്നിവയ്‌ക്കായി ഞങ്ങൾ ഇവ പ്രവർത്തിപ്പിക്കുന്നു.
        EHAction::Cleanup(lpad)
    } else {
        // ക്യാച്ച്_അൻ‌വിൻഡിൽ Rust panics ഒഴിവാക്കുന്നത് നിർത്തുക.
        EHAction::Catch(lpad)
    }
}

#[inline]
fn round_up(unrounded: usize, align: usize) -> Result<usize, ()> {
    if align.is_power_of_two() { Ok((unrounded + align - 1) & !(align - 1)) } else { Err(()) }
}

unsafe fn read_encoded_pointer(
    reader: &mut DwarfReader,
    context: &EHContext<'_>,
    encoding: u8,
) -> Result<usize, ()> {
    if encoding == DW_EH_PE_omit {
        return Err(());
    }

    // DW_EH_PE_ ക്രമീകരിച്ചത് ഇത് ഒരു കേവല പോയിന്റർ മൂല്യമാണെന്ന് സൂചിപ്പിക്കുന്നു
    if encoding == DW_EH_PE_aligned {
        reader.ptr = round_up(reader.ptr as usize, mem::size_of::<usize>())? as *const u8;
        return Ok(reader.read::<usize>());
    }

    let mut result = match encoding & 0x0F {
        DW_EH_PE_absptr => reader.read::<usize>(),
        DW_EH_PE_uleb128 => reader.read_uleb128() as usize,
        DW_EH_PE_udata2 => reader.read::<u16>() as usize,
        DW_EH_PE_udata4 => reader.read::<u32>() as usize,
        DW_EH_PE_udata8 => reader.read::<u64>() as usize,
        DW_EH_PE_sleb128 => reader.read_sleb128() as usize,
        DW_EH_PE_sdata2 => reader.read::<i16>() as usize,
        DW_EH_PE_sdata4 => reader.read::<i32>() as usize,
        DW_EH_PE_sdata8 => reader.read::<i64>() as usize,
        _ => return Err(()),
    };

    result += match encoding & 0x70 {
        DW_EH_PE_absptr => 0,
        // പേര് നൽകിയിട്ടും എൻ‌കോഡുചെയ്‌ത മൂല്യത്തിന്റെ വിലാസവുമായി ബന്ധപ്പെട്ടിരിക്കുന്നു
        DW_EH_PE_pcrel => reader.ptr as usize,
        DW_EH_PE_funcrel => {
            if context.func_start == 0 {
                return Err(());
            }
            context.func_start
        }
        DW_EH_PE_textrel => (*context.get_text_start)(),
        DW_EH_PE_datarel => (*context.get_data_start)(),
        _ => return Err(()),
    };

    if encoding & DW_EH_PE_indirect != 0 {
        result = *(result as *const usize);
    }

    Ok(result)
}