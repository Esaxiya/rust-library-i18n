//! സിംഗിൾ-ത്രെഡ് റഫറൻസ്-കൗണ്ടിംഗ് പോയിന്ററുകൾ.'Rc' എന്നാൽ 'റഫറൻസ്
//! Counted'.
//!
//! കൂമ്പാരത്തിൽ അനുവദിച്ചിരിക്കുന്ന `T` തരം മൂല്യത്തിന്റെ പങ്കിട്ട ഉടമസ്ഥാവകാശം [`Rc<T>`][`Rc`] തരം നൽകുന്നു.
//! [`Rc`]-ൽ [`clone`][clone] അഭ്യർത്ഥിക്കുന്നത് കൂമ്പാരത്തിലെ അതേ വിഹിതത്തിലേക്ക് ഒരു പുതിയ പോയിന്റർ സൃഷ്ടിക്കുന്നു.
//! തന്നിരിക്കുന്ന അലോക്കേഷന്റെ അവസാന [`Rc`] പോയിന്റർ നശിപ്പിക്കുമ്പോൾ, ആ അലോക്കേഷനിൽ സംഭരിച്ചിരിക്കുന്ന മൂല്യവും (പലപ്പോഴും "inner value" എന്ന് വിളിക്കുന്നു) ഉപേക്ഷിക്കപ്പെടും.
//!
//! Rust-ൽ പങ്കിട്ട റഫറൻസുകൾ സ്ഥിരസ്ഥിതിയായി മ്യൂട്ടേഷനെ അനുവദിക്കുന്നില്ല, കൂടാതെ [`Rc`] ഒരു അപവാദവുമല്ല: നിങ്ങൾക്ക് സാധാരണയായി ഒരു [`Rc`]-നുള്ളിലെ എന്തിനെക്കുറിച്ചും മ്യൂട്ടബിൾ റഫറൻസ് നേടാൻ കഴിയില്ല.
//! നിങ്ങൾക്ക് മ്യൂട്ടബിലിറ്റി ആവശ്യമുണ്ടെങ്കിൽ, [`Rc`]-നുള്ളിൽ ഒരു [`Cell`] അല്ലെങ്കിൽ [`RefCell`] ഇടുക;[an example of mutability inside an `Rc`][mutability] കാണുക.
//!
//! [`Rc`] നോൺ-ആറ്റോമിക് റഫറൻസ് കൗണ്ടിംഗ് ഉപയോഗിക്കുന്നു.
//! ഇതിനർത്ഥം ഓവർഹെഡ് വളരെ കുറവാണ്, പക്ഷേ ത്രെഡുകൾക്കിടയിൽ ഒരു [`Rc`] അയയ്ക്കാൻ കഴിയില്ല, തൽഫലമായി [`Rc`] [`Send`][send] നടപ്പിലാക്കില്ല.
//! തൽഫലമായി, നിങ്ങൾ ത്രെഡുകൾക്കിടയിൽ [`Rc`] അയയ്ക്കുന്നില്ലെന്ന് Rust കംപൈലർ കംപൈൽ സമയത്ത് * പരിശോധിക്കും.
//! നിങ്ങൾക്ക് മൾട്ടി-ത്രെഡ്, ആറ്റോമിക് റഫറൻസ് ക ing ണ്ടിംഗ് ആവശ്യമുണ്ടെങ്കിൽ, [`sync::Arc`][arc] ഉപയോഗിക്കുക.
//!
//! സ്വന്തമല്ലാത്ത [`Weak`] പോയിന്റർ സൃഷ്ടിക്കാൻ [`downgrade`][downgrade] രീതി ഉപയോഗിക്കാം.
//! ഒരു [`Weak`] പോയിന്റർ ഒരു [`Rc`]-ലേക്ക് [`അപ്‌ഗ്രേഡ്`][അപ്‌ഗ്രേഡ്] d ആകാം, പക്ഷേ അലോക്കേഷനിൽ സംഭരിച്ചിരിക്കുന്ന മൂല്യം ഇതിനകം തന്നെ ഉപേക്ഷിച്ചിട്ടുണ്ടെങ്കിൽ ഇത് [`None`] നൽകും.
//! മറ്റൊരു വിധത്തിൽ പറഞ്ഞാൽ, എക്സ് 00 എക്സ് പോയിന്ററുകൾ അലോക്കേഷനുള്ളിലെ മൂല്യം സജീവമായി നിലനിർത്തുന്നില്ല;എന്നിരുന്നാലും, അവർ വിഹിതം (ആന്തരിക മൂല്യത്തിനായുള്ള ബാക്കിംഗ് സ്റ്റോർ) സജീവമായി നിലനിർത്തുന്നു.
//!
//! [`Rc`] പോയിന്ററുകൾക്കിടയിലുള്ള ഒരു ചക്രം ഒരിക്കലും ഡീലോക്കേറ്റ് ചെയ്യില്ല.
//! ഇക്കാരണത്താൽ, സൈക്കിളുകൾ തകർക്കാൻ [`Weak`] ഉപയോഗിക്കുന്നു.
//! ഉദാഹരണത്തിന്, ഒരു വൃക്ഷത്തിന് രക്ഷാകർതൃ നോഡുകളിൽ നിന്ന് കുട്ടികളിലേക്ക് ശക്തമായ [`Rc`] പോയിന്ററുകളും കുട്ടികളിൽ നിന്ന് മാതാപിതാക്കളിലേക്ക് [`Weak`] പോയിന്ററുകളും ഉണ്ടാകാം.
//!
//! `Rc<T>` `T` ([`Deref`] trait വഴി) സ്വപ്രേരിതമായി ഒഴിവാക്കുന്നു, അതിനാൽ നിങ്ങൾക്ക് [`Rc<T>`][`Rc`] തരം മൂല്യത്തിൽ `ടി` രീതികളെ വിളിക്കാം.
//! `ടി'യുടെ രീതികളുമായുള്ള നാമ സംഘട്ടനങ്ങൾ ഒഴിവാക്കാൻ, [`Rc<T>`][`Rc`]-ന്റെ രീതികൾ തന്നെ ബന്ധപ്പെട്ട പ്രവർത്തനങ്ങളാണ്, അവയെ [fully qualified syntax] ഉപയോഗിച്ച് വിളിക്കുന്നു:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>`Clone` പോലുള്ള traits ന്റെ നടപ്പാക്കലുകളെ പൂർണ്ണ യോഗ്യതയുള്ള വാക്യഘടന ഉപയോഗിച്ച് വിളിക്കാം.
//! ചില ആളുകൾ‌പൂർണ്ണ യോഗ്യതയുള്ള വാക്യഘടന ഉപയോഗിക്കാൻ‌താൽ‌പ്പര്യപ്പെടുന്നു, മറ്റുള്ളവർ‌രീതി-കോൾ‌വാക്യഘടന ഉപയോഗിക്കാൻ‌താൽ‌പ്പര്യപ്പെടുന്നു.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // രീതി-കോൾ വാക്യഘടന
//! let rc2 = rc.clone();
//! // പൂർണ്ണ യോഗ്യതയുള്ള വാക്യഘടന
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] `T`-ലേക്ക് യാന്ത്രികമായി ഒഴിവാക്കില്ല, കാരണം ആന്തരിക മൂല്യം ഇതിനകം തന്നെ ഉപേക്ഷിച്ചിരിക്കാം.
//!
//! # ക്ലോണിംഗ് റഫറൻസുകൾ
//!
//! നിലവിലുള്ള റഫറൻസ് കണക്കാക്കിയ പോയിന്ററിന്റെ അതേ അലോക്കേഷനിൽ ഒരു പുതിയ റഫറൻസ് സൃഷ്‌ടിക്കുന്നത് [`Rc<T>`][`Rc`], [`Weak<T>`][`Weak`] എന്നിവയ്‌ക്കായി നടപ്പിലാക്കിയ `Clone` trait ഉപയോഗിച്ചാണ്.
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // ചുവടെയുള്ള രണ്ട് വാക്യഘടനകളും തുല്യമാണ്.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a, b എന്നിവ രണ്ടും foo എന്നതിന് സമാനമായ മെമ്മറി സ്ഥാനത്തേക്ക് വിരൽ ചൂണ്ടുന്നു.
//! ```
//!
//! `Rc::clone(&from)` വാക്യഘടന ഏറ്റവും വിവേകശൂന്യമാണ്, കാരണം ഇത് കോഡിന്റെ അർത്ഥം കൂടുതൽ വ്യക്തമായി അറിയിക്കുന്നു.
//! മുകളിലുള്ള ഉദാഹരണത്തിൽ, ഫൂവിന്റെ മുഴുവൻ ഉള്ളടക്കവും പകർത്തുന്നതിനുപകരം ഈ കോഡ് ഒരു പുതിയ റഫറൻസ് സൃഷ്ടിക്കുന്നുവെന്ന് കാണാൻ ഈ വാക്യഘടന എളുപ്പമാക്കുന്നു.
//!
//! # Examples
//!
//! തന്നിരിക്കുന്ന `Owner`-ന്റെ ഒരു കൂട്ടം `ഗാഡ്‌ജെറ്റിന്റെ 'ഉടമസ്ഥതയിലുള്ള ഒരു സാഹചര്യം പരിഗണിക്കുക.
//! ഞങ്ങളുടെ `ഗാഡ്‌ജെറ്റിന്റെ പോയിന്റ് അവരുടെ `Owner`-ലേക്ക് നേടാൻ ഞങ്ങൾ ആഗ്രഹിക്കുന്നു.അദ്വിതീയ ഉടമസ്ഥാവകാശം ഉപയോഗിച്ച് ഞങ്ങൾക്ക് ഇത് ചെയ്യാൻ കഴിയില്ല, കാരണം ഒന്നിലധികം ഗാഡ്‌ജെറ്റുകൾ ഒരേ `Owner`-ൽ ഉൾപ്പെട്ടേക്കാം.
//! [`Rc`] ഒന്നിലധികം `ഗാഡ്‌ജെറ്റുകൾക്കിടയിൽ ഒരു `Owner` പങ്കിടാൻ ഞങ്ങളെ അനുവദിക്കുന്നു, ഒപ്പം `Owner` ഏതെങ്കിലും `Gadget` പോയിന്റുകൾ ഉള്ളിടത്തോളം കാലം അനുവദിക്കുകയും ചെയ്യും.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... മറ്റ് ഫീൽഡുകൾ
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... മറ്റ് ഫീൽഡുകൾ
//! }
//!
//! fn main() {
//!     // ഒരു റഫറൻസ് കണക്കാക്കിയ `Owner` സൃഷ്ടിക്കുക.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // `gadget_owner`-ൽ നിന്നുള്ള `ഗാഡ്‌ജെറ്റ്` സൃഷ്‌ടിക്കുക.
//!     // `Rc<Owner>` ക്ലോൺ ചെയ്യുന്നത് അതേ `Owner` അലോക്കേഷന് ഒരു പുതിയ പോയിന്റർ നൽകുന്നു, ഇത് പ്രക്രിയയിൽ റഫറൻസ് എണ്ണം വർദ്ധിപ്പിക്കുന്നു.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // ഞങ്ങളുടെ ലോക്കൽ വേരിയബിൾ `gadget_owner` നീക്കംചെയ്യുക.
//!     drop(gadget_owner);
//!
//!     // `gadget_owner` ഉപേക്ഷിച്ചിട്ടും, `ഗാഡ്‌ജെറ്റിന്റെ `Owner`-ന്റെ പേര് പ്രിന്റുചെയ്യാൻ ഞങ്ങൾക്ക് ഇപ്പോഴും കഴിയും.
//!     // കാരണം, ഞങ്ങൾ ചൂണ്ടിക്കാണിക്കുന്ന `Owner` അല്ല, ഒരൊറ്റ `Rc<Owner>` മാത്രമാണ് ഞങ്ങൾ ഉപേക്ഷിച്ചത്.
//!     // ഒരേ `Owner` അലോക്കേഷനിൽ മറ്റ് `Rc<Owner>` പോയിന്റുകൾ ഉള്ളിടത്തോളം കാലം, അത് തത്സമയം തുടരും.
//!     // ഫീൽഡ് പ്രൊജക്ഷൻ `gadget1.owner.name` പ്രവർത്തിക്കുന്നു, കാരണം `Rc<Owner>` സ്വപ്രേരിതമായി `Owner` ലേക്ക് മാറുന്നു.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // ഫംഗ്ഷന്റെ അവസാനം, `gadget1`, `gadget2` എന്നിവ നശിപ്പിക്കപ്പെടുന്നു, അവയ്ക്കൊപ്പം ഞങ്ങളുടെ `Owner`-ലേക്ക് അവസാനമായി കണക്കാക്കിയ റഫറൻസുകളും.
//!     // ഗാഡ്‌ജെറ്റ് മാൻ‌ഇപ്പോൾ‌നശിപ്പിക്കപ്പെടുന്നു.
//!     //
//! }
//! ```
//!
//! ഞങ്ങളുടെ ആവശ്യകതകൾ മാറുകയും `Owner` മുതൽ `Gadget` വരെ സഞ്ചരിക്കാനും ഞങ്ങൾക്ക് കഴിയേണ്ടതുണ്ടെങ്കിൽ, ഞങ്ങൾ പ്രശ്‌നങ്ങളിൽ അകപ്പെടും.
//! `Owner` മുതൽ `Gadget` വരെയുള്ള ഒരു [`Rc`] പോയിന്റർ ഒരു സൈക്കിൾ അവതരിപ്പിക്കുന്നു.
//! ഇതിനർത്ഥം അവരുടെ റഫറൻസ് എണ്ണം ഒരിക്കലും 0 ൽ എത്താൻ കഴിയില്ല, മാത്രമല്ല വിഹിതം ഒരിക്കലും നശിപ്പിക്കപ്പെടില്ല:
//! ഒരു മെമ്മറി ലീക്ക്.ഇത് പരിഹരിക്കുന്നതിന്, ഞങ്ങൾക്ക് [`Weak`] പോയിന്ററുകൾ ഉപയോഗിക്കാം.
//!
//! Rust യഥാർത്ഥത്തിൽ ഈ ലൂപ്പ് ആദ്യം നിർമ്മിക്കുന്നത് കുറച്ച് ബുദ്ധിമുട്ടാണ്.പരസ്പരം ചൂണ്ടിക്കാണിക്കുന്ന രണ്ട് മൂല്യങ്ങളുമായി അവസാനിക്കുന്നതിന്, അവയിലൊന്ന് പരിവർത്തനം ചെയ്യേണ്ടതുണ്ട്.
//! ഇത് ബുദ്ധിമുട്ടാണ്, കാരണം എക്സ് 100 എക്സ് മെമ്മറി സുരക്ഷ നടപ്പിലാക്കുന്നത് അത് പൊതിയുന്ന മൂല്യത്തെക്കുറിച്ച് പങ്കിട്ട റഫറൻസുകൾ മാത്രം നൽകിക്കൊണ്ടാണ്, മാത്രമല്ല ഇവ നേരിട്ടുള്ള പരിവർത്തനം അനുവദിക്കുന്നില്ല.
//! [`RefCell`]-ൽ പരിവർത്തനം ചെയ്യാൻ ഞങ്ങൾ ആഗ്രഹിക്കുന്ന മൂല്യത്തിന്റെ ഒരു ഭാഗം ഞങ്ങൾ പൊതിയേണ്ടതുണ്ട്, അത് *ഇന്റീരിയർ മ്യൂട്ടബിലിറ്റി* നൽകുന്നു: പങ്കിട്ട റഫറൻസിലൂടെ മ്യൂട്ടബിളിറ്റി നേടുന്നതിനുള്ള ഒരു രീതി.
//! [`RefCell`] റൺടൈമിൽ Rust ന്റെ വായ്പയെടുക്കൽ നിയമങ്ങൾ നടപ്പിലാക്കുന്നു.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... മറ്റ് ഫീൽഡുകൾ
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... മറ്റ് ഫീൽഡുകൾ
//! }
//!
//! fn main() {
//!     // ഒരു റഫറൻസ് കണക്കാക്കിയ `Owner` സൃഷ്ടിക്കുക.
//!     // `ഗാഡ്‌ജെറ്റിന്റെ` ഉടമയുടെ vector ഒരു `RefCell`-നുള്ളിൽ ഞങ്ങൾ സ്ഥാപിച്ചിട്ടുണ്ടെന്നതിനാൽ ഒരു പങ്കിട്ട റഫറൻസിലൂടെ ഇത് പരിവർത്തനം ചെയ്യാൻ ഞങ്ങൾക്ക് കഴിയും.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // മുമ്പത്തെപ്പോലെ `gadget_owner`-ൽ നിന്നുള്ള `ഗാഡ്‌ജെറ്റ്` സൃഷ്‌ടിക്കുക.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // അവരുടെ `Owner`-ലേക്ക് `ഗാഡ്‌ജെറ്റ് 'ചേർക്കുക.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` ചലനാത്മക വായ്പ ഇവിടെ അവസാനിക്കുന്നു.
//!     }
//!
//!     // ഞങ്ങളുടെ `ഗാഡ്‌ജെറ്റുകളെക്കുറിച്ച് വിശദീകരിക്കുക, അവരുടെ വിശദാംശങ്ങൾ അച്ചടിക്കുക.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` ഒരു `Weak<Gadget>` ആണ്.
//!         // `Weak` പോയിന്ററുകൾക്ക് അലോക്കേഷൻ ഇപ്പോഴും നിലവിലുണ്ടെന്ന് ഉറപ്പുനൽകാൻ കഴിയാത്തതിനാൽ, ഞങ്ങൾ `upgrade`-നെ വിളിക്കേണ്ടതുണ്ട്, അത് ഒരു `Option<Rc<Gadget>>` നൽകുന്നു.
//!         //
//!         //
//!         // ഈ സാഹചര്യത്തിൽ അലോക്കേഷൻ ഇപ്പോഴും നിലവിലുണ്ടെന്ന് ഞങ്ങൾക്കറിയാം, അതിനാൽ ഞങ്ങൾ `unwrap` `Option` ആണ്.
//!         // കൂടുതൽ സങ്കീർണ്ണമായ ഒരു പ്രോഗ്രാമിൽ, ഒരു `None` ഫലത്തിനായി നിങ്ങൾക്ക് മനോഹരമായ പിശക് കൈകാര്യം ചെയ്യൽ ആവശ്യമായി വന്നേക്കാം.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // ഫംഗ്ഷന്റെ അവസാനം, `gadget_owner`, `gadget1`, `gadget2` എന്നിവ നശിപ്പിക്കപ്പെടുന്നു.
//!     // ഗാഡ്‌ജെറ്റുകളിലേക്ക് ഇപ്പോൾ ശക്തമായ (`Rc`) പോയിന്ററുകളൊന്നുമില്ല, അതിനാൽ അവ നശിപ്പിക്കപ്പെടുന്നു.
//!     // ഇത് ഗാഡ്‌ജെറ്റ് മാൻ‌റഫറൻ‌സ് എണ്ണം പൂജ്യമാക്കുന്നു, അതിനാൽ‌അവനും നശിപ്പിക്കപ്പെടുന്നു.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// ഫീൽഡ് പുന ord ക്രമീകരണത്തിനെതിരായ ഇത് repr(C) മുതൽ future-പ്രൂഫ് ആണ്, ഇത് കൈമാറ്റം ചെയ്യാവുന്ന ആന്തരിക തരങ്ങളുടെ സുരക്ഷിതമായ [into|from]_raw() തടസ്സപ്പെടുത്തും.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// ഒറ്റ-ത്രെഡ് റഫറൻസ്-കൗണ്ടിംഗ് പോയിന്റർ.'Rc' എന്നാൽ 'റഫറൻസ്
/// Counted'.
///
/// കൂടുതൽ വിവരങ്ങൾക്ക് [module-level documentation](./index.html) കാണുക.
///
/// `Rc`-ന്റെ അന്തർലീനമായ രീതികളെല്ലാം ബന്ധപ്പെട്ട പ്രവർത്തനങ്ങളാണ്, അതിനർത്ഥം നിങ്ങൾ അവയെ ഉദാ, `value.get_mut()`-ന് പകരം [`Rc::get_mut(&mut value)`][get_mut] എന്ന് വിളിക്കണം എന്നാണ്.
/// ഇത് ആന്തരിക തരം `T` രീതികളുമായുള്ള പൊരുത്തക്കേടുകൾ ഒഴിവാക്കുന്നു.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // ഈ സുരക്ഷിതത്വം ശരിയാണ്, കാരണം ഈ ആർ‌സി ജീവിച്ചിരിക്കുമ്പോൾ ആന്തരിക പോയിന്റർ സാധുതയുള്ളതാണെന്ന് ഞങ്ങൾക്ക് ഉറപ്പുണ്ട്.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// ഒരു പുതിയ `Rc<T>` നിർമ്മിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // എല്ലാ ശക്തമായ പോയിന്ററുകളുടെയും ഉടമസ്ഥതയിലുള്ള ഒരു വ്യക്തമായ ദുർബലമായ പോയിന്റർ ഉണ്ട്, അത് ശക്തമായ ഡിസ്ട്രക്റ്റർ പ്രവർത്തിക്കുമ്പോൾ ദുർബലമായ ഡിസ്ട്രക്റ്റർ ഒരിക്കലും വിഹിതം സ്വതന്ത്രമാക്കുന്നില്ലെന്ന് ഉറപ്പാക്കുന്നു, ദുർബലമായ പോയിന്റർ ശക്തമായ ഒന്നിനുള്ളിൽ സൂക്ഷിച്ചിട്ടുണ്ടെങ്കിലും.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// സ്വയം ഒരു ദുർബലമായ റഫറൻസ് ഉപയോഗിച്ച് ഒരു പുതിയ `Rc<T>` നിർമ്മിക്കുന്നു.
    /// ഈ ഫംഗ്ഷൻ മടങ്ങുന്നതിന് മുമ്പ് ദുർബലമായ റഫറൻസ് അപ്‌ഗ്രേഡുചെയ്യാൻ ശ്രമിക്കുന്നത് ഒരു `None` മൂല്യത്തിന് കാരണമാകും.
    ///
    /// എന്നിരുന്നാലും, ദുർബലമായ റഫറൻസ് സ ely ജന്യമായി ക്ലോൺ ചെയ്ത് പിന്നീടുള്ള സമയത്ത് ഉപയോഗത്തിനായി സൂക്ഷിക്കാം.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... കൂടുതൽ ഫീൽഡുകൾ
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // ഒരൊറ്റ ദുർബലമായ റഫറൻസ് ഉപയോഗിച്ച് "uninitialized" അവസ്ഥയിൽ ആന്തരികം നിർമ്മിക്കുക.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // ദുർബലമായ പോയിന്ററിന്റെ ഉടമസ്ഥാവകാശം ഞങ്ങൾ ഉപേക്ഷിക്കാതിരിക്കുക എന്നത് പ്രധാനമാണ്, അല്ലെങ്കിൽ `data_fn` മടങ്ങിയെത്തുമ്പോഴേക്കും മെമ്മറി സ്വതന്ത്രമാകാം.
        // ഉടമസ്ഥാവകാശം കൈമാറാൻ ഞങ്ങൾ ശരിക്കും ആഗ്രഹിക്കുന്നുവെങ്കിൽ, ഞങ്ങൾക്ക് സ്വയം ഒരു ദുർബലമായ പോയിന്റർ സൃഷ്ടിക്കാൻ കഴിയും, പക്ഷേ ഇത് ദുർബലമായ റഫറൻസ് എണ്ണത്തിലേക്ക് അധിക അപ്‌ഡേറ്റുകൾക്ക് കാരണമാകും, അല്ലാത്തപക്ഷം അത് ആവശ്യമായി വരില്ല.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // ശക്തമായ റഫറൻ‌സുകൾ‌ഒന്നിച്ച് പങ്കിട്ട ദുർബലമായ റഫറൻ‌സ് സ്വന്തമാക്കിയിരിക്കണം, അതിനാൽ‌ഞങ്ങളുടെ പഴയ ദുർബല റഫറൻസിനായി ഡിസ്ട്രക്റ്റർ‌പ്രവർത്തിപ്പിക്കരുത്.
        //
        mem::forget(weak);
        strong
    }

    /// ആരംഭിക്കാത്ത ഉള്ളടക്കങ്ങളുള്ള ഒരു പുതിയ `Rc` നിർമ്മിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // മാറ്റിവച്ച ഓർഗനൈസേഷൻ:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// മെമ്മറി `0` ബൈറ്റുകൾ കൊണ്ട് നിറച്ചുകൊണ്ട്, ആരംഭിക്കാത്ത ഉള്ളടക്കങ്ങളുള്ള ഒരു പുതിയ `Rc` നിർമ്മിക്കുന്നു.
    ///
    ///
    /// ഈ രീതിയുടെ ശരിയായതും തെറ്റായതുമായ ഉപയോഗത്തിന്റെ ഉദാഹരണങ്ങൾക്കായി [`MaybeUninit::zeroed`][zeroed] കാണുക.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// ഒരു പുതിയ `Rc<T>` നിർമ്മിക്കുന്നു, അലോക്കേഷൻ പരാജയപ്പെട്ടാൽ ഒരു പിശക് നൽകുന്നു
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // എല്ലാ ശക്തമായ പോയിന്ററുകളുടെയും ഉടമസ്ഥതയിലുള്ള ഒരു വ്യക്തമായ ദുർബലമായ പോയിന്റർ ഉണ്ട്, അത് ശക്തമായ ഡിസ്ട്രക്റ്റർ പ്രവർത്തിക്കുമ്പോൾ ദുർബലമായ ഡിസ്ട്രക്റ്റർ ഒരിക്കലും വിഹിതം സ്വതന്ത്രമാക്കുന്നില്ലെന്ന് ഉറപ്പാക്കുന്നു, ദുർബലമായ പോയിന്റർ ശക്തമായ ഒന്നിനുള്ളിൽ സൂക്ഷിച്ചിട്ടുണ്ടെങ്കിലും.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// ആരംഭിക്കാത്ത ഉള്ളടക്കങ്ങളുള്ള ഒരു പുതിയ `Rc` നിർമ്മിക്കുന്നു, അലോക്കേഷൻ പരാജയപ്പെട്ടാൽ ഒരു പിശക് നൽകുന്നു
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // മാറ്റിവച്ച ഓർഗനൈസേഷൻ:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// മെമ്മറി `0` ബൈറ്റുകൾ കൊണ്ട് നിറച്ചുകൊണ്ട്, ആരംഭിക്കാത്ത ഉള്ളടക്കങ്ങളുള്ള ഒരു പുതിയ `Rc` നിർമ്മിക്കുന്നു, അലോക്കേഷൻ പരാജയപ്പെട്ടാൽ ഒരു പിശക് നൽകുന്നു
    ///
    ///
    /// ഈ രീതിയുടെ ശരിയായതും തെറ്റായതുമായ ഉപയോഗത്തിന്റെ ഉദാഹരണങ്ങൾക്കായി [`MaybeUninit::zeroed`][zeroed] കാണുക.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// ഒരു പുതിയ `Pin<Rc<T>>` നിർമ്മിക്കുന്നു.
    /// `T` `Unpin` നടപ്പിലാക്കുന്നില്ലെങ്കിൽ, `value` മെമ്മറിയിൽ പിൻ ചെയ്യുകയും നീക്കാൻ കഴിയാതിരിക്കുകയും ചെയ്യും.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// `Rc`-ന് കൃത്യമായി ഒരു ശക്തമായ റഫറൻസ് ഉണ്ടെങ്കിൽ ആന്തരിക മൂല്യം നൽകുന്നു.
    ///
    /// അല്ലെങ്കിൽ, കടന്നുപോയ അതേ `Rc` ഉപയോഗിച്ച് ഒരു [`Err`] തിരികെ നൽകും.
    ///
    ///
    /// മികച്ച ദുർബലമായ റഫറൻസുകൾ ഉണ്ടെങ്കിലും ഇത് വിജയിക്കും.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // അടങ്ങിയിരിക്കുന്ന ഒബ്‌ജക്റ്റ് പകർത്തുക

                // ശക്തമായ എണ്ണം കുറച്ചുകൊണ്ട് അവരെ പ്രൊമോട്ട് ചെയ്യാൻ കഴിയില്ലെന്ന് ദുർബലരോട് സൂചിപ്പിക്കുക, തുടർന്ന് വ്യാജ ബലഹീനത സൃഷ്ടിച്ച് ഡ്രോപ്പ് ലോജിക് കൈകാര്യം ചെയ്യുന്നതിനിടയിൽ വ്യക്തമായ "strong weak" പോയിന്റർ നീക്കംചെയ്യുക.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// ആരംഭിക്കാത്ത ഉള്ളടക്കങ്ങൾ ഉപയോഗിച്ച് ഒരു പുതിയ റഫറൻസ് കണക്കാക്കിയ സ്ലൈസ് നിർമ്മിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // മാറ്റിവച്ച ഓർഗനൈസേഷൻ:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// മെമ്മറി `0` ബൈറ്റുകളിൽ നിറച്ചുകൊണ്ട്, ആരംഭിക്കാത്ത ഉള്ളടക്കങ്ങൾ ഉപയോഗിച്ച് ഒരു പുതിയ റഫറൻസ്-കണക്കാക്കിയ സ്ലൈസ് നിർമ്മിക്കുന്നു.
    ///
    ///
    /// ഈ രീതിയുടെ ശരിയായതും തെറ്റായതുമായ ഉപയോഗത്തിന്റെ ഉദാഹരണങ്ങൾക്കായി [`MaybeUninit::zeroed`][zeroed] കാണുക.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// `Rc<T>`-ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] പോലെ, ആന്തരിക മൂല്യം ശരിക്കും ഒരു പ്രാരംഭ അവസ്ഥയിലാണെന്ന് ഉറപ്പുനൽകേണ്ടത് കോളർ ആണ്.
    ///
    /// ഉള്ളടക്കം ഇതുവരെ പൂർണ്ണമായി ആരംഭിച്ചിട്ടില്ലാത്തപ്പോൾ ഇത് വിളിക്കുന്നത് ഉടനടി നിർവചിക്കപ്പെടാത്ത സ്വഭാവത്തിന് കാരണമാകുന്നു.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // മാറ്റിവച്ച ഓർഗനൈസേഷൻ:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// `Rc<[T]>`-ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] പോലെ, ആന്തരിക മൂല്യം ശരിക്കും ഒരു പ്രാരംഭ അവസ്ഥയിലാണെന്ന് ഉറപ്പുനൽകേണ്ടത് കോളർ ആണ്.
    ///
    /// ഉള്ളടക്കം ഇതുവരെ പൂർണ്ണമായി ആരംഭിച്ചിട്ടില്ലാത്തപ്പോൾ ഇത് വിളിക്കുന്നത് ഉടനടി നിർവചിക്കപ്പെടാത്ത സ്വഭാവത്തിന് കാരണമാകുന്നു.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // മാറ്റിവച്ച ഓർഗനൈസേഷൻ:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// പൊതിഞ്ഞ പോയിന്റർ മടക്കി `Rc` ഉപയോഗിക്കുന്നു.
    ///
    /// മെമ്മറി ലീക്ക് ഒഴിവാക്കാൻ പോയിന്റർ [`Rc::from_raw`][from_raw] ഉപയോഗിച്ച് ഒരു `Rc` ലേക്ക് തിരികെ പരിവർത്തനം ചെയ്യണം.
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// ഡാറ്റയിലേക്ക് ഒരു റോ പോയിന്റർ നൽകുന്നു.
    ///
    /// എണ്ണത്തെ ഒരു തരത്തിലും ബാധിക്കില്ല കൂടാതെ `Rc` ഉപയോഗിക്കുന്നില്ല.
    /// `Rc`-ൽ ശക്തമായ എണ്ണങ്ങൾ ഉള്ളിടത്തോളം പോയിന്റർ സാധുവാണ്.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // സുരക്ഷ: ഇതിന് Deref::deref അല്ലെങ്കിൽ Rc::inner വഴി പോകാൻ കഴിയില്ല കാരണം
        // ഉദാ. raw/mut ഉറവിടം നിലനിർത്താൻ ഇത് ആവശ്യമാണ്
        // `get_mut` `from_raw` വഴി ആർ‌സി വീണ്ടെടുത്ത ശേഷം പോയിന്ററിലൂടെ എഴുതാൻ‌കഴിയും.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// ഒരു റോ പോയിന്ററിൽ നിന്ന് ഒരു `Rc<T>` നിർമ്മിക്കുന്നു.
    ///
    /// റോ പോയിന്റർ മുമ്പ് [`Rc<U>::into_raw`][into_raw]-ലേക്ക് ഒരു കോൾ നൽകിയിരിക്കണം, അവിടെ `U`-ന് `T`-ന് സമാനമായ വലുപ്പവും വിന്യാസവും ഉണ്ടായിരിക്കണം.
    /// `U` `T` ആണെങ്കിൽ ഇത് വളരെ തുച്ഛമാണ്.
    /// `U` `T` അല്ലെങ്കിലും ഒരേ വലുപ്പവും വിന്യാസവുമുണ്ടെങ്കിൽ, ഇത് അടിസ്ഥാനപരമായി വ്യത്യസ്ത തരം റഫറൻസുകൾ കൈമാറുന്നതുപോലെയാണ്.
    /// ഈ സാഹചര്യത്തിൽ എന്ത് നിയന്ത്രണങ്ങൾ ബാധകമാണ് എന്നതിനെക്കുറിച്ചുള്ള കൂടുതൽ വിവരങ്ങൾക്ക് [`mem::transmute`][transmute] കാണുക.
    ///
    /// `from_raw` ന്റെ ഉപയോക്താവ് `T` ന്റെ ഒരു നിർദ്ദിഷ്ട മൂല്യം ഒരു തവണ മാത്രമേ ഉപേക്ഷിച്ചിട്ടുള്ളൂവെന്ന് ഉറപ്പാക്കേണ്ടതുണ്ട്.
    ///
    /// ഈ പ്രവർത്തനം സുരക്ഷിതമല്ല, കാരണം അനുചിതമായ ഉപയോഗം മെമ്മറി സുരക്ഷിതത്വത്തിലേക്ക് നയിച്ചേക്കാം, മടങ്ങിയ `Rc<T>` ഒരിക്കലും ആക്സസ് ചെയ്തിട്ടില്ലെങ്കിലും.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // ചോർച്ച തടയുന്നതിന് ഒരു `Rc`-ലേക്ക് തിരികെ പരിവർത്തനം ചെയ്യുക.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Rc::from_raw(x_ptr)`-ലേക്കുള്ള കൂടുതൽ കോളുകൾ മെമ്മറി സുരക്ഷിതമല്ല.
    /// }
    ///
    /// // `x` മുകളിലുള്ള വ്യാപ്തിയിൽ നിന്ന് പുറത്തുപോകുമ്പോൾ മെമ്മറി സ്വതന്ത്രമാക്കി, അതിനാൽ `x_ptr` ഇപ്പോൾ അപകടത്തിലാണ്!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // യഥാർത്ഥ RcBox കണ്ടെത്തുന്നതിന് ഓഫ്‌സെറ്റ് വിപരീതമാക്കുക.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// ഈ അലോക്കേഷനായി ഒരു പുതിയ [`Weak`] പോയിന്റർ സൃഷ്ടിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // ദുർബലമായ ഒരു ദുർബലത ഞങ്ങൾ സൃഷ്ടിക്കുന്നില്ലെന്ന് ഉറപ്പാക്കുക
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// ഈ അലോക്കേഷനിലേക്ക് [`Weak`] പോയിന്ററുകളുടെ എണ്ണം നേടുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// ഈ അലോക്കേഷനിൽ ശക്തമായ (`Rc`) പോയിന്ററുകളുടെ എണ്ണം നേടുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// ഈ അലോക്കേഷനിൽ മറ്റ് `Rc` അല്ലെങ്കിൽ [`Weak`] പോയിന്ററുകൾ ഇല്ലെങ്കിൽ `true` നൽകുന്നു.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// ഒരേ അലോക്കേഷനിൽ മറ്റ് `Rc` അല്ലെങ്കിൽ [`Weak`] പോയിന്ററുകൾ ഇല്ലെങ്കിൽ, നൽകിയ `Rc`-ലേക്ക് ഒരു മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു.
    ///
    ///
    /// പങ്കിട്ട മൂല്യം പരിവർത്തനം ചെയ്യുന്നത് സുരക്ഷിതമല്ലാത്തതിനാൽ [`None`] അല്ലാത്തപക്ഷം നൽകുന്നു.
    ///
    /// [`make_mut`][make_mut] ഉം കാണുക, മറ്റ് പോയിന്ററുകൾ ഉള്ളപ്പോൾ ആന്തരിക മൂല്യം [`clone`][clone] ചെയ്യും.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// ഒരു പരിശോധനയും കൂടാതെ, നൽകിയ `Rc`-ലേക്ക് ഒരു മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു.
    ///
    /// [`get_mut`] ഉം കാണുക, അത് സുരക്ഷിതവും ഉചിതമായ പരിശോധനകളും നടത്തുന്നു.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// ഒരേ അലോക്കേഷനിലേക്കുള്ള മറ്റേതെങ്കിലും `Rc` അല്ലെങ്കിൽ [`Weak`] പോയിന്ററുകൾ മടക്കിനൽകിയ വായ്പയുടെ കാലാവധിക്കായി വ്യക്തമാക്കരുത്.
    ///
    /// അത്തരം പോയിന്ററുകളൊന്നും നിലവിലില്ലെങ്കിൽ ഇത് വളരെ തുച്ഛമാണ്, ഉദാഹരണത്തിന് `Rc::new`-ന് ശേഷം.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // "count" ഫീൽഡുകൾ ഉൾക്കൊള്ളുന്ന ഒരു റഫറൻസ് * സൃഷ്ടിക്കാതിരിക്കാൻ ഞങ്ങൾ ശ്രദ്ധാലുക്കളാണ്, കാരണം ഇത് റഫറൻസ് എണ്ണങ്ങളിലേക്കുള്ള ആക്‌സസ്സുമായി പൊരുത്തപ്പെടുന്നില്ല (ഉദാ.
        // `Weak` പ്രകാരം)
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// രണ്ട് `ആർ‌സി'കളും ഒരേ അലോക്കേഷനിലേക്കാണ് വിരൽ ചൂണ്ടുന്നതെങ്കിൽ ([`ptr::eq`] ന് സമാനമായ ഒരു സിരയിൽ) `true` നൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// തന്നിരിക്കുന്ന `Rc`-ലേക്ക് മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു.
    ///
    /// സമാന അലോക്കേഷനിൽ മറ്റ് `Rc` പോയിന്ററുകൾ ഉണ്ടെങ്കിൽ, അദ്വിതീയ ഉടമസ്ഥാവകാശം ഉറപ്പാക്കുന്നതിന് `make_mut` ഒരു പുതിയ അലോക്കേഷന്റെ ആന്തരിക മൂല്യം [`clone`] ചെയ്യും.
    /// ഇതിനെ ക്ലോൺ-ഓൺ-റൈറ്റ് എന്നും വിളിക്കുന്നു.
    ///
    /// ഈ അലോക്കേഷനിൽ മറ്റ് `Rc` പോയിന്ററുകൾ ഇല്ലെങ്കിൽ, ഈ അലോക്കേഷനിലേക്കുള്ള [`Weak`] പോയിന്ററുകൾ വിച്ഛേദിക്കപ്പെടും.
    ///
    /// [`get_mut`] ഉം കാണുക, അത് ക്ലോണിംഗിനേക്കാൾ പരാജയപ്പെടും.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // ഒന്നും ക്ലോൺ ചെയ്യില്ല
    /// let mut other_data = Rc::clone(&data);    // ആന്തരിക ഡാറ്റ ക്ലോൺ ചെയ്യില്ല
    /// *Rc::make_mut(&mut data) += 1;        // ആന്തരിക ഡാറ്റ ക്ലോൺ ചെയ്യുന്നു
    /// *Rc::make_mut(&mut data) += 1;        // ഒന്നും ക്ലോൺ ചെയ്യില്ല
    /// *Rc::make_mut(&mut other_data) *= 2;  // ഒന്നും ക്ലോൺ ചെയ്യില്ല
    ///
    /// // ഇപ്പോൾ `data`, `other_data` എന്നിവ വ്യത്യസ്ത അലോക്കേഷനുകളിലേക്ക് പോയിന്റ് ചെയ്യുന്നു.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] പോയിന്ററുകൾ വേർപെടുത്തും:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // ഡാറ്റ ക്ലോൺ ചെയ്യണം, മറ്റ് ആർ‌സികളും ഉണ്ട്.
            // ക്ലോൺ ചെയ്ത മൂല്യം നേരിട്ട് എഴുതാൻ അനുവദിക്കുന്നതിന് മെമ്മറി മുൻകൂട്ടി അനുവദിക്കുക.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // ഡാറ്റ മോഷ്ടിക്കാൻ കഴിയും, അവശേഷിക്കുന്നത് ദുർബലമാണ്
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // വ്യക്തമായ ദുർബലമായ റഫർ‌നീക്കംചെയ്യുക (ഇവിടെ ഒരു വ്യാജ ബലഹീനത സൃഷ്ടിക്കേണ്ട ആവശ്യമില്ല-മറ്റ് ദുർബലർക്ക് ഞങ്ങൾക്ക് വൃത്തിയാക്കാനാകുമെന്ന് ഞങ്ങൾക്കറിയാം)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // ഈ സുരക്ഷിതത്വം കുഴപ്പമില്ല, കാരണം മടങ്ങിയെത്തിയ പോയിന്റർ ടിയിലേക്ക് മടങ്ങിയെത്തുന്ന *മാത്രം* പോയിന്റർ ആണെന്ന് ഞങ്ങൾക്ക് ഉറപ്പുണ്ട്.
        // ഈ സമയത്ത് ഞങ്ങളുടെ റഫറൻസ് എണ്ണം 1 ആയിരിക്കുമെന്ന് ഉറപ്പുനൽകുന്നു, ഞങ്ങൾക്ക് `Rc<T>` തന്നെ `mut` ആയിരിക്കേണ്ടതുണ്ട്, അതിനാൽ അലോക്കേഷന് സാധ്യമായ ഒരേയൊരു റഫറൻസ് ഞങ്ങൾ നൽകുന്നു.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Rc<dyn Any>` ഒരു കോൺക്രീറ്റ് തരത്തിലേക്ക് തരംതാഴ്ത്താനുള്ള ശ്രമം.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// മൂല്യത്തിന് ലേ layout ട്ട് നൽകിയിട്ടുള്ള, വലുപ്പം മാറ്റാത്ത ആന്തരിക മൂല്യത്തിന് മതിയായ ഇടമുള്ള ഒരു `RcBox<T>` അനുവദിക്കുന്നു.
    ///
    /// ഡാറ്റാ പോയിന്റർ ഉപയോഗിച്ച് `mem_to_rcbox` ഫംഗ്ഷൻ വിളിക്കുന്നു, കൂടാതെ `RcBox<T>`-നായി ഒരു (കൊഴുപ്പ് സാധ്യതയുള്ള)-പോയിന്റർ തിരികെ നൽകണം.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // നൽകിയ മൂല്യ ലേ .ട്ട് ഉപയോഗിച്ച് ലേ layout ട്ട് കണക്കാക്കുക.
        // മുമ്പ്, `&*(ptr as* const RcBox<T>)` എക്സ്പ്രഷനിൽ ലേ layout ട്ട് കണക്കാക്കിയിരുന്നു, പക്ഷേ ഇത് തെറ്റായി രൂപകൽപ്പന ചെയ്ത ഒരു റഫറൻസ് സൃഷ്ടിച്ചു (#54908 കാണുക).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// മൂല്യം ലേ layout ട്ട് നൽകിയിട്ടുള്ള, വലുപ്പം മാറ്റാത്ത ആന്തരിക മൂല്യത്തിന് മതിയായ ഇടമുള്ള ഒരു `RcBox<T>` അനുവദിക്കുന്നു, അലോക്കേഷൻ പരാജയപ്പെട്ടാൽ ഒരു പിശക് നൽകുന്നു.
    ///
    ///
    /// ഡാറ്റാ പോയിന്റർ ഉപയോഗിച്ച് `mem_to_rcbox` ഫംഗ്ഷൻ വിളിക്കുന്നു, കൂടാതെ `RcBox<T>`-നായി ഒരു (കൊഴുപ്പ് സാധ്യതയുള്ള)-പോയിന്റർ തിരികെ നൽകണം.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // നൽകിയ മൂല്യ ലേ .ട്ട് ഉപയോഗിച്ച് ലേ layout ട്ട് കണക്കാക്കുക.
        // മുമ്പ്, `&*(ptr as* const RcBox<T>)` എക്സ്പ്രഷനിൽ ലേ layout ട്ട് കണക്കാക്കിയിരുന്നു, പക്ഷേ ഇത് തെറ്റായി രൂപകൽപ്പന ചെയ്ത ഒരു റഫറൻസ് സൃഷ്ടിച്ചു (#54908 കാണുക).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // ലേ .ട്ടിനായി അനുവദിക്കുക.
        let ptr = allocate(layout)?;

        // RcBox സമാരംഭിക്കുക
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// വലുപ്പം മാറ്റാത്ത ആന്തരിക മൂല്യത്തിന് മതിയായ ഇടമുള്ള ഒരു `RcBox<T>` അനുവദിക്കുന്നു
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // തന്നിരിക്കുന്ന മൂല്യം ഉപയോഗിച്ച് `RcBox<T>`-നായി അനുവദിക്കുക.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // മൂല്യം ബൈറ്റുകളായി പകർത്തുക
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // അലോക്കേഷൻ അതിന്റെ ഉള്ളടക്കങ്ങൾ ഉപേക്ഷിക്കാതെ സ്വതന്ത്രമാക്കുക
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// തന്നിരിക്കുന്ന നീളമുള്ള ഒരു `RcBox<[T]>` അനുവദിക്കുന്നു.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// സ്ലൈസിൽ‌നിന്നും ഘടകങ്ങൾ‌പുതുതായി അനുവദിച്ച Rc <\[T\]> ലേക്ക് പകർ‌ത്തുക
    ///
    /// സുരക്ഷിതമല്ലാത്തതിനാൽ വിളിക്കുന്നയാൾ ഉടമസ്ഥാവകാശം ഏറ്റെടുക്കുകയോ `T: Copy` ബന്ധിപ്പിക്കുകയോ വേണം
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// ഒരു നിശ്ചിത വലുപ്പമുള്ള ഒരു ഇറ്ററേറ്ററിൽ നിന്ന് ഒരു `Rc<[T]>` നിർമ്മിക്കുന്നു.
    ///
    /// വലുപ്പം തെറ്റാണെങ്കിൽ പെരുമാറ്റം നിർവചിക്കപ്പെട്ടിട്ടില്ല.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // ടി ഘടകങ്ങൾ ക്ലോൺ ചെയ്യുമ്പോൾ Panic ഗാർഡ്.
        // ഒരു panic ഉണ്ടായാൽ, പുതിയ RcBox-ലേക്ക് എഴുതിയ ഘടകങ്ങൾ ഉപേക്ഷിക്കപ്പെടും, തുടർന്ന് മെമ്മറി സ്വതന്ത്രമാകും.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // ആദ്യ ഘടകത്തിലേക്കുള്ള പോയിന്റർ
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // എല്ലാം വ്യക്തമാണ്.ഗാർഡിനെ മറക്കുക, അതുവഴി പുതിയ RcBox സ്വതന്ത്രമാകില്ല.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// സ്പെഷ്യലൈസേഷൻ `From<&[T]>`-നായി ഉപയോഗിക്കുന്ന trait.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// `Rc` ഡ്രോപ്പ് ചെയ്യുന്നു.
    ///
    /// ഇത് ശക്തമായ റഫറൻസ് എണ്ണം കുറയ്ക്കും.
    /// ശക്തമായ റഫറൻസ് എണ്ണം പൂജ്യത്തിലെത്തിയാൽ മറ്റ് റഫറൻസുകൾ (എന്തെങ്കിലും ഉണ്ടെങ്കിൽ) [`Weak`] മാത്രമാണ്, അതിനാൽ ഞങ്ങൾ ആന്തരിക മൂല്യം `drop` ആണ്.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // ഒന്നും അച്ചടിക്കുന്നില്ല
    /// drop(foo2);   // "dropped!" പ്രിന്റുകൾ
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // അടങ്ങിയിരിക്കുന്ന ഒബ്‌ജക്റ്റ് നശിപ്പിക്കുക
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // ഞങ്ങൾ‌ഉള്ളടക്കങ്ങൾ‌നശിപ്പിച്ചതിനാൽ‌ഇപ്പോൾ‌വ്യക്തമായ "strong weak" പോയിന്റർ‌നീക്കംചെയ്യുക.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// `Rc` പോയിന്ററിന്റെ ഒരു ക്ലോൺ നിർമ്മിക്കുന്നു.
    ///
    /// ഇത് ഒരേ അലോക്കേഷനിലേക്ക് മറ്റൊരു പോയിന്റർ സൃഷ്ടിക്കുന്നു, ഇത് ശക്തമായ റഫറൻസ് എണ്ണം വർദ്ധിപ്പിക്കുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// `T`-നായി `Default` മൂല്യം ഉപയോഗിച്ച് ഒരു പുതിയ `Rc<T>` സൃഷ്ടിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// `Eq` ന് ഒരു രീതി ഉണ്ടെങ്കിലും `Eq`-ൽ സ്പെഷ്യലൈസ് ചെയ്യുന്നത് അനുവദിക്കുന്നതിനുള്ള ഹാക്ക്.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// ഞങ്ങൾ ഇവിടെ ഈ സ്പെഷ്യലൈസേഷൻ ചെയ്യുന്നു, `&T`-ലെ പൊതുവായ ഒപ്റ്റിമൈസേഷനായിട്ടല്ല, കാരണം ഇത് റഫറുകളിലെ എല്ലാ തുല്യതാ പരിശോധനകൾക്കും ചിലവ് നൽകും.
/// വലിയ മൂല്യങ്ങൾ സംഭരിക്കുന്നതിന് `Rc` കൾ ഉപയോഗിക്കുന്നുവെന്ന് ഞങ്ങൾ അനുമാനിക്കുന്നു, അവ ക്ലോൺ ചെയ്യാൻ മന്ദഗതിയിലാണ്, എന്നാൽ തുല്യത പരിശോധിക്കുന്നതിനുള്ള ഭാരവുമാണ്, ഈ ചെലവ് കൂടുതൽ എളുപ്പത്തിൽ അടയ്ക്കാൻ കാരണമാകുന്നു.
///
/// രണ്ട് `&ടി`കളേക്കാൾ ഒരേ മൂല്യത്തിലേക്ക് പോയിന്റുചെയ്യുന്ന രണ്ട് `Rc` ക്ലോണുകൾ ഉണ്ടാകാനുള്ള സാധ്യതയും കൂടുതലാണ്.
///
/// `PartialEq` ആയി `T: Eq` മന ib പൂർവ്വം പരിഹരിക്കാനാവാത്തതാണെങ്കിൽ മാത്രമേ ഞങ്ങൾക്ക് ഇത് ചെയ്യാൻ കഴിയൂ.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// രണ്ട് `Rc` കൾക്ക് തുല്യത.
    ///
    /// വ്യത്യസ്ത വിഹിതത്തിൽ സംഭരിച്ചിട്ടുണ്ടെങ്കിലും അവയുടെ ആന്തരിക മൂല്യങ്ങൾ തുല്യമാണെങ്കിൽ രണ്ട് `ആർ‌സി'കൾ തുല്യമാണ്.
    ///
    /// `T` ഉം `Eq` നടപ്പിലാക്കുകയാണെങ്കിൽ (സമത്വത്തിന്റെ റിഫ്ലെക്സിറ്റിവിറ്റി സൂചിപ്പിക്കുന്നു), ഒരേ അലോക്കേഷനിലേക്ക് വിരൽ ചൂണ്ടുന്ന രണ്ട് `Rc` കൾ എല്ലായ്പ്പോഴും തുല്യമാണ്.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// രണ്ട് `ആർ‌സി'കളുടെ അസമത്വം.
    ///
    /// ആന്തരിക മൂല്യങ്ങൾ അസമമാണെങ്കിൽ രണ്ട് `ആർ‌സി'കൾ അസമമാണ്.
    ///
    /// `T` ഉം `Eq` നടപ്പിലാക്കുകയാണെങ്കിൽ (സമത്വത്തിന്റെ റിഫ്ലെക്സിറ്റിവിറ്റി സൂചിപ്പിക്കുന്നു), ഒരേ വിഹിതത്തിലേക്ക് വിരൽ ചൂണ്ടുന്ന രണ്ട് `Rc` കൾ ഒരിക്കലും അസമമല്ല.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// രണ്ട് `Rc` കൾക്കുള്ള ഭാഗിക താരതമ്യം.
    ///
    /// ആന്തരിക മൂല്യങ്ങളിൽ `partial_cmp()` എന്ന് വിളിച്ചാണ് ഇവ രണ്ടും താരതമ്യം ചെയ്യുന്നത്.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// രണ്ട് `ആർ‌സി'കളുമായി താരതമ്യപ്പെടുത്തുന്നതിനേക്കാൾ കുറവാണ്.
    ///
    /// ആന്തരിക മൂല്യങ്ങളിൽ `<` എന്ന് വിളിച്ചാണ് ഇവ രണ്ടും താരതമ്യം ചെയ്യുന്നത്.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// രണ്ട് `ആർ‌സി'കളുമായി താരതമ്യപ്പെടുത്തുന്നതിനേക്കാൾ 'തുല്യമോ തുല്യമോ'.
    ///
    /// ആന്തരിക മൂല്യങ്ങളിൽ `<=` എന്ന് വിളിച്ചാണ് ഇവ രണ്ടും താരതമ്യം ചെയ്യുന്നത്.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// രണ്ട് `ആർ‌സി'കളുമായി താരതമ്യപ്പെടുത്തുന്നതിനേക്കാൾ വലുത്.
    ///
    /// ആന്തരിക മൂല്യങ്ങളിൽ `>` എന്ന് വിളിച്ചാണ് ഇവ രണ്ടും താരതമ്യം ചെയ്യുന്നത്.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// രണ്ട് `ആർ‌സി'കളുമായി താരതമ്യപ്പെടുത്തുന്നതിനേക്കാൾ 'വലുതോ തുല്യമോ'.
    ///
    /// ആന്തരിക മൂല്യങ്ങളിൽ `>=` എന്ന് വിളിച്ചാണ് ഇവ രണ്ടും താരതമ്യം ചെയ്യുന്നത്.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// രണ്ട് `Rc` കൾക്കുള്ള താരതമ്യം.
    ///
    /// ആന്തരിക മൂല്യങ്ങളിൽ `cmp()` എന്ന് വിളിച്ചാണ് ഇവ രണ്ടും താരതമ്യം ചെയ്യുന്നത്.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// ഒരു റഫറൻസ് കണക്കാക്കിയ സ്ലൈസ് അനുവദിച്ച് `v` ന്റെ ഇനങ്ങൾ ക്ലോൺ ചെയ്തുകൊണ്ട് പൂരിപ്പിക്കുക.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// ഒരു റഫറൻസ് കണക്കാക്കിയ സ്ട്രിംഗ് സ്ലൈസ് അനുവദിക്കുകയും അതിലേക്ക് `v` പകർത്തുകയും ചെയ്യുക.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// ഒരു റഫറൻസ് കണക്കാക്കിയ സ്ട്രിംഗ് സ്ലൈസ് അനുവദിക്കുകയും അതിലേക്ക് `v` പകർത്തുകയും ചെയ്യുക.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// ഒരു ബോക്‍സ്ഡ് ഒബ്‌ജക്റ്റ് പുതിയ, റഫറൻസ് കണക്കാക്കിയ, അലോക്കേഷനിലേക്ക് നീക്കുക.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// ഒരു റഫറൻസ് കണക്കാക്കിയ സ്ലൈസ് അനുവദിച്ച് അതിലേക്ക് `v` ന്റെ ഇനങ്ങൾ നീക്കുക.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // അതിന്റെ മെമ്മറി സ്വതന്ത്രമാക്കാൻ വെക്കിനെ അനുവദിക്കുക, പക്ഷേ അതിലെ ഉള്ളടക്കങ്ങൾ നശിപ്പിക്കരുത്
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// `Iterator`-ലെ ഓരോ ഘടകങ്ങളും എടുത്ത് ഒരു `Rc<[T]>`-ലേക്ക് ശേഖരിക്കുന്നു.
    ///
    /// # പ്രകടന സവിശേഷതകൾ
    ///
    /// ## പൊതുവായ കേസ്
    ///
    /// പൊതുവായ സാഹചര്യത്തിൽ, `Rc<[T]>`-ലേക്ക് ശേഖരിക്കുന്നത് ആദ്യം ഒരു `Vec<T>`-ലേക്ക് ശേഖരിക്കുന്നതിലൂടെയാണ്.അതായത്, ഇനിപ്പറയുന്നവ എഴുതുമ്പോൾ:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ഇത് ഞങ്ങൾ എഴുതിയതുപോലെയാണ് പ്രവർത്തിക്കുന്നത്:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // ആദ്യ സെറ്റ് അലോക്കേഷനുകൾ ഇവിടെ സംഭവിക്കുന്നു.
    ///     .into(); // `Rc<[T]>`-നുള്ള രണ്ടാമത്തെ അലോക്കേഷൻ ഇവിടെ സംഭവിക്കുന്നു.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ഇത് `Vec<T>` നിർമ്മിക്കുന്നതിന് ആവശ്യമായത്ര തവണ അനുവദിക്കും, തുടർന്ന് `Vec<T>` നെ `Rc<[T]>` ആക്കി മാറ്റുന്നതിന് ഇത് ഒരു തവണ അനുവദിക്കും.
    ///
    ///
    /// ## അറിയപ്പെടുന്ന നീളത്തിന്റെ ആവർത്തനക്കാർ
    ///
    /// നിങ്ങളുടെ `Iterator` `TrustedLen` നടപ്പിലാക്കുകയും കൃത്യമായ വലുപ്പമുള്ളപ്പോൾ, `Rc<[T]>`-നായി ഒരൊറ്റ അലോക്കേഷൻ നടത്തുകയും ചെയ്യും.ഉദാഹരണത്തിന്:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // ഒരൊറ്റ വിഹിതം ഇവിടെ സംഭവിക്കുന്നു.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// എക്സ് 00 എക്സിലേക്ക് ശേഖരിക്കുന്നതിന് സ്പെഷ്യലൈസേഷൻ trait ഉപയോഗിക്കുന്നു.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // ഒരു `TrustedLen` ആവർത്തനത്തിനായുള്ള സ്ഥിതി ഇതാണ്.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // സുരക്ഷ: ഇറ്ററേറ്ററിന് കൃത്യമായ നീളമുണ്ടെന്നും ഞങ്ങൾക്ക് ഉണ്ടെന്നും ഉറപ്പാക്കേണ്ടതുണ്ട്.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // സാധാരണ നടപ്പാക്കലിലേക്ക് മടങ്ങുക.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` നിയന്ത്രിത അലോക്കേഷന് സ്വന്തമല്ലാത്ത ഒരു റഫറൻസ് കൈവശമുള്ള [`Rc`]-ന്റെ ഒരു പതിപ്പാണ്.`Weak` പോയിന്ററിൽ [`upgrade`] എന്ന് വിളിച്ചുകൊണ്ട് അലോക്കേഷൻ ആക്‌സസ്സുചെയ്യുന്നു, അത് ഒരു [`ഓപ്ഷൻ`]`<`[`Rc`] `നൽകുന്നു<T>>`.
///
/// ഒരു `Weak` റഫറൻസ് ഉടമസ്ഥാവകാശത്തെ കണക്കാക്കാത്തതിനാൽ, അലോക്കേഷനിൽ സംഭരിച്ചിരിക്കുന്ന മൂല്യം ഉപേക്ഷിക്കുന്നത് ഇത് തടയില്ല, മാത്രമല്ല `Weak` തന്നെ ഇപ്പോഴും നിലനിൽക്കുന്ന മൂല്യത്തെക്കുറിച്ച് ഒരു ഉറപ്പുമില്ല.
/// [`അപ്‌ഗ്രേഡ്`] d ആയിരിക്കുമ്പോൾ ഇത് [`None`] നൽകാം.
/// എന്നിരുന്നാലും, ഒരു എക്സ് 00 എക്സ് റഫറൻസ് * അലോക്കേഷനെ (ബാക്കിംഗ് സ്റ്റോർ) ഡീലോക്കേറ്റ് ചെയ്യുന്നതിൽ നിന്ന് തടയുന്നു.
///
/// എക്സ് 01 എക്സ് നിയന്ത്രിക്കുന്ന അലോക്കേഷനെക്കുറിച്ച് അതിന്റെ ആന്തരിക മൂല്യം ഒഴിവാക്കുന്നത് തടയാതെ ഒരു താൽക്കാലിക റഫറൻസ് സൂക്ഷിക്കുന്നതിന് ഒരു എക്സ് 00 എക്സ് പോയിന്റർ ഉപയോഗപ്രദമാണ്.
/// [`Rc`] പോയിൻറുകൾ‌ക്കിടയിലുള്ള വൃത്താകൃതിയിലുള്ള റഫറൻ‌സുകൾ‌തടയുന്നതിനും ഇത് ഉപയോഗിക്കുന്നു, കാരണം പരസ്പര ഉടമസ്ഥതയിലുള്ള റഫറൻ‌സുകൾ‌ഒരിക്കലും [`Rc`] ഉപേക്ഷിക്കാൻ‌അനുവദിക്കില്ല.
/// ഉദാഹരണത്തിന്, ഒരു വൃക്ഷത്തിന് രക്ഷാകർതൃ നോഡുകളിൽ നിന്ന് കുട്ടികളിലേക്ക് ശക്തമായ [`Rc`] പോയിന്ററുകളും കുട്ടികളിൽ നിന്ന് മാതാപിതാക്കളിലേക്ക് `Weak` പോയിന്ററുകളും ഉണ്ടാകാം.
///
/// `Weak` പോയിന്റർ നേടുന്നതിനുള്ള സാധാരണ മാർഗം [`Rc::downgrade`] എന്ന് വിളിക്കുക എന്നതാണ്.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // ഇനാമുകളിൽ ഈ തരം വലുപ്പം ഒപ്റ്റിമൈസ് ചെയ്യാൻ അനുവദിക്കുന്നതിനുള്ള ഒരു `NonNull` ആണ് ഇത്, പക്ഷേ ഇത് സാധുവായ ഒരു പോയിന്റർ ആയിരിക്കണമെന്നില്ല.
    //
    // `Weak::new` ഇത് `usize::MAX` ആയി സജ്ജമാക്കുന്നതിനാൽ കൂമ്പാരത്തിൽ സ്ഥലം അനുവദിക്കേണ്ടതില്ല.
    // ഒരു യഥാർത്ഥ പോയിന്ററിന് ഒരിക്കലും ഉണ്ടായിരിക്കേണ്ട ഒരു മൂല്യമല്ല ഇത്, കാരണം ആർ‌സി‌ബോക്സിന് കുറഞ്ഞത് 2 എങ്കിലും വിന്യാസം ഉണ്ട്.
    // `T: Sized` ആയിരിക്കുമ്പോൾ മാത്രമേ ഇത് സാധ്യമാകൂ;വലുപ്പം മാറ്റാത്ത `T` ഒരിക്കലും തൂങ്ങിക്കിടക്കുന്നില്ല.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// മെമ്മറി അനുവദിക്കാതെ ഒരു പുതിയ `Weak<T>` നിർമ്മിക്കുന്നു.
    /// റിട്ടേൺ മൂല്യത്തിൽ [`upgrade`] എന്ന് വിളിക്കുന്നത് എല്ലായ്പ്പോഴും [`None`] നൽകുന്നു.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// ഡാറ്റാ ഫീൽഡിനെക്കുറിച്ച് ഒരു അവകാശവാദവും നടത്താതെ റഫറൻസ് എണ്ണങ്ങൾ ആക്‌സസ്സുചെയ്യാൻ അനുവദിക്കുന്നതിനുള്ള സഹായ തരം.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// ഈ `Weak<T>` ചൂണ്ടിക്കാണിച്ച `T` ഒബ്‌ജക്റ്റിലേക്ക് ഒരു റോ പോയിന്റർ നൽകുന്നു.
    ///
    /// ശക്തമായ ചില റഫറൻ‌സുകൾ‌ഉണ്ടെങ്കിൽ‌മാത്രമേ പോയിന്റർ‌സാധുതയുള്ളൂ.
    /// പോയിന്റർ തൂങ്ങിക്കിടക്കുന്നതോ ക്രമീകരിക്കാത്തതോ [`null`] അല്ലാത്തതോ ആകാം.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // രണ്ടും ഒരേ വസ്തുവിലേക്ക് വിരൽ ചൂണ്ടുന്നു
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // ഇവിടെയുള്ളവർ അതിനെ സജീവമായി നിലനിർത്തുന്നു, അതിനാൽ നമുക്ക് ഇപ്പോഴും ഒബ്‌ജക്റ്റ് ആക്‌സസ്സുചെയ്യാനാകും.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // പക്ഷേ ഇനിയില്ല.
    /// // ഞങ്ങൾക്ക് weak.as_ptr() ചെയ്യാൻ കഴിയും, പക്ഷേ പോയിന്റർ ആക്സസ് ചെയ്യുന്നത് നിർവചിക്കപ്പെടാത്ത സ്വഭാവത്തിലേക്ക് നയിക്കും.
    /// // assert_eq! ("ഹലോ", സുരക്ഷിതമല്ലാത്ത {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // പോയിന്റർ തൂങ്ങിക്കിടക്കുകയാണെങ്കിൽ, ഞങ്ങൾ സെന്റിനൽ നേരിട്ട് നൽകുന്നു.
            // പേലോഡ് RcBox (usize) പോലെ വിന്യസിച്ചിരിക്കുന്നതിനാൽ ഇത് സാധുവായ ഒരു പേലോഡ് വിലാസമായിരിക്കരുത്.
            ptr as *const T
        } else {
            // സുരക്ഷിതം: is_dangling തെറ്റാണെങ്കിൽ, പോയിന്റർ ഒഴിവാക്കാനാവില്ല.
            // ഈ സമയത്ത് പേലോഡ് ഉപേക്ഷിക്കാം, ഞങ്ങൾ തെളിവ് നിലനിർത്തേണ്ടതുണ്ട്, അതിനാൽ റോ പോയിന്റർ കൃത്രിമത്വം ഉപയോഗിക്കുക.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// `Weak<T>` ഉപയോഗിക്കുകയും അസംസ്കൃത പോയിന്ററായി മാറ്റുകയും ചെയ്യുന്നു.
    ///
    /// ഒരു ദുർബലമായ റഫറൻസിന്റെ ഉടമസ്ഥാവകാശം കാത്തുസൂക്ഷിക്കുന്നതിനിടയിൽ ഇത് ദുർബലമായ പോയിന്ററിനെ ഒരു അസംസ്കൃത പോയിന്ററായി പരിവർത്തനം ചെയ്യുന്നു (ദുർബലമായ എണ്ണം ഈ പ്രവർത്തനത്തിലൂടെ പരിഷ്‌ക്കരിക്കില്ല).
    /// ഇത് [`from_raw`] ഉപയോഗിച്ച് `Weak<T>` ലേക്ക് തിരികെ മാറ്റാൻ കഴിയും.
    ///
    /// [`as_ptr`] പോലെ പോയിന്ററിന്റെ ടാർഗെറ്റ് ആക്‌സസ് ചെയ്യുന്നതിനുള്ള അതേ നിയന്ത്രണങ്ങൾ ബാധകമാണ്.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// മുമ്പ് [`into_raw`] സൃഷ്ടിച്ച ഒരു റോ പോയിന്റർ `Weak<T>` ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// സുരക്ഷിതമായ ഒരു റഫറൻസ് നേടുന്നതിനോ (പിന്നീട് [`upgrade`] വിളിക്കുന്നതിലൂടെ) അല്ലെങ്കിൽ `Weak<T>` ഉപേക്ഷിച്ച് ദുർബലമായ എണ്ണം ഇല്ലാതാക്കുന്നതിനോ ഇത് ഉപയോഗിക്കാം.
    ///
    /// ഇത് ഒരു ദുർബലമായ റഫറൻസിന്റെ ഉടമസ്ഥാവകാശം എടുക്കുന്നു ([`new`] സൃഷ്ടിച്ച പോയിന്ററുകൾ ഒഴികെ, ഇവയൊന്നും സ്വന്തമല്ലാത്തതിനാൽ; രീതി ഇപ്പോഴും അവയിൽ പ്രവർത്തിക്കുന്നു).
    ///
    /// # Safety
    ///
    /// പോയിന്റർ [`into_raw`]-ൽ നിന്ന് ഉത്ഭവിച്ചിരിക്കണം, ഇപ്പോഴും അതിന്റെ ദുർബലമായ റഫറൻസ് സ്വന്തമാക്കിയിരിക്കണം.
    ///
    /// ഇത് വിളിക്കുമ്പോൾ ശക്തമായ എണ്ണം 0 ആയിരിക്കാൻ അനുവദിച്ചിരിക്കുന്നു.
    /// എന്നിരുന്നാലും, ഇത് നിലവിൽ ഒരു അസംസ്കൃത പോയിന്ററായി പ്രതിനിധീകരിക്കുന്ന ഒരു ദുർബലമായ റഫറൻസിന്റെ ഉടമസ്ഥാവകാശം എടുക്കുന്നു (ഈ പ്രവർത്തനം ദുർബലമായ എണ്ണം പരിഷ്‌ക്കരിച്ചിട്ടില്ല), അതിനാൽ ഇത് [`into_raw`]-ലേക്ക് മുമ്പത്തെ കോളുമായി ജോടിയാക്കണം.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // അവസാനത്തെ ദുർബലമായ എണ്ണം കുറയ്‌ക്കുക.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // ഇൻപുട്ട് പോയിന്റർ എങ്ങനെ ഉത്ഭവിച്ചു എന്നതിനെക്കുറിച്ചുള്ള സന്ദർഭത്തിനായി Weak::as_ptr കാണുക.

        let ptr = if is_dangling(ptr as *mut T) {
            // ഇത് ദുർബലമായ ദുർബലമാണ്.
            ptr as *mut RcBox<T>
        } else {
            // അല്ലാത്തപക്ഷം, പോയിന്റർ ഒരു ദുർബലമായ ദുർബലത്തിൽ നിന്നാണെന്ന് ഞങ്ങൾക്ക് ഉറപ്പുണ്ട്.
            // സുരക്ഷ: ഡാറ്റാ_ഓഫ്സെറ്റ് വിളിക്കുന്നത് സുരക്ഷിതമാണ്, കാരണം പി‌ടി‌ആർ ഒരു യഥാർത്ഥ (ഉപേക്ഷിക്കാൻ സാധ്യതയുള്ള) ടി.
            let offset = unsafe { data_offset(ptr) };
            // അങ്ങനെ, മുഴുവൻ ആർ‌സിബോക്സും ലഭിക്കുന്നതിന് ഞങ്ങൾ ഓഫ്‌സെറ്റ് തിരിച്ചിടുന്നു.
            // സുരക്ഷ: പോയിന്റർ ദുർബലമായതിൽ നിന്നാണ് ഉത്ഭവിച്ചത്, അതിനാൽ ഈ ഓഫ്‌സെറ്റ് സുരക്ഷിതമാണ്.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // സുരക്ഷ: ഞങ്ങൾ ഇപ്പോൾ യഥാർത്ഥ ദുർബല പോയിന്റർ വീണ്ടെടുത്തു, അതിനാൽ ദുർബലമായത് സൃഷ്ടിക്കാൻ കഴിയും.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// `Weak` പോയിന്റർ ഒരു [`Rc`]-ലേക്ക് അപ്‌ഗ്രേഡുചെയ്യാനുള്ള ശ്രമം, വിജയിച്ചാൽ ആന്തരിക മൂല്യം ഉപേക്ഷിക്കുന്നത് കാലതാമസം വരുത്തുന്നു.
    ///
    ///
    /// ആന്തരിക മൂല്യം ഉപേക്ഷിച്ചിട്ടുണ്ടെങ്കിൽ [`None`] നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // എല്ലാ ശക്തമായ പോയിന്ററുകളും നശിപ്പിക്കുക.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// ഈ അലോക്കേഷനിൽ പോയിന്റുചെയ്യുന്ന ശക്തമായ (`Rc`) പോയിന്ററുകളുടെ എണ്ണം നേടുന്നു.
    ///
    /// [`Weak::new`] ഉപയോഗിച്ച് `self` സൃഷ്ടിച്ചിട്ടുണ്ടെങ്കിൽ, ഇത് 0 നൽകും.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// ഈ അലോക്കേഷൻ ചൂണ്ടിക്കാണിക്കുന്ന `Weak` പോയിന്ററുകളുടെ എണ്ണം നേടുന്നു.
    ///
    /// ശക്തമായ പോയിന്ററുകളൊന്നും അവശേഷിക്കുന്നില്ലെങ്കിൽ, ഇത് പൂജ്യമാകും.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // വ്യക്തമായ ദുർബലമായ ptr കുറയ്ക്കുക
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// പോയിന്റർ തൂങ്ങിക്കിടക്കുമ്പോൾ അനുവദിച്ച `RcBox` ഇല്ലാത്തപ്പോൾ `None` നൽകുന്നു, (അതായത്, ഈ `Weak` `Weak::new` സൃഷ്ടിച്ചപ്പോൾ).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // ഫീൽഡ് ഒരേസമയം പരിവർത്തനം ചെയ്യപ്പെടുന്നതിനാൽ "data" ഫീൽഡിനെ ഉൾക്കൊള്ളുന്ന ഒരു റഫറൻസ് * സൃഷ്ടിക്കാതിരിക്കാൻ ഞങ്ങൾ ശ്രദ്ധാലുവാണ് (ഉദാഹരണത്തിന്, അവസാന `Rc` ഉപേക്ഷിക്കുകയാണെങ്കിൽ, ഡാറ്റ ഫീൽഡ് സ്ഥലത്ത് തന്നെ ഉപേക്ഷിക്കപ്പെടും).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// രണ്ട് `ദുർബല'ങ്ങളും ഒരേ അലോക്കേഷനിലേക്കാണ് ([`ptr::eq`] ന് സമാനമായത്) പോയിന്റ് ചെയ്യുന്നതെങ്കിലോ അല്ലെങ്കിൽ രണ്ടും ഏതെങ്കിലും അലോക്കേഷനിലേക്ക് വിരൽ ചൂണ്ടുന്നില്ലെങ്കിലോ `true` നൽകുന്നു (കാരണം അവ `Weak::new()`) ഉപയോഗിച്ചാണ് സൃഷ്ടിച്ചത്.
    ///
    ///
    /// # Notes
    ///
    /// ഇത് പോയിന്ററുകളെ താരതമ്യപ്പെടുത്തുന്നതിനാൽ `Weak::new()` പരസ്പരം തുല്യമാകുമെന്നാണ് ഇതിനർത്ഥം, അവ ഏതെങ്കിലും വിഹിതത്തിലേക്ക് വിരൽ ചൂണ്ടുന്നില്ലെങ്കിലും.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` താരതമ്യം ചെയ്യുന്നു.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` പോയിന്റർ ഉപേക്ഷിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // ഒന്നും അച്ചടിക്കുന്നില്ല
    /// drop(foo);        // "dropped!" പ്രിന്റുകൾ
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // ദുർബലമായ എണ്ണം 1 ൽ ആരംഭിക്കുന്നു, മാത്രമല്ല എല്ലാ ശക്തമായ പോയിന്ററുകളും അപ്രത്യക്ഷമായാൽ മാത്രമേ പൂജ്യത്തിലേക്ക് പോകൂ.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// ഒരേ അലോക്കേഷനിലേക്ക് പോയിന്റുചെയ്യുന്ന `Weak` പോയിന്ററിന്റെ ഒരു ക്ലോൺ നിർമ്മിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// ഒരു പുതിയ `Weak<T>` നിർമ്മിക്കുന്നു, `T`-ന് മെമ്മറി അനുവദിക്കാതെ തന്നെ അത് ആരംഭിക്കുന്നു.
    /// റിട്ടേൺ മൂല്യത്തിൽ [`upgrade`] എന്ന് വിളിക്കുന്നത് എല്ലായ്പ്പോഴും [`None`] നൽകുന്നു.
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: mem::forget സുരക്ഷിതമായി കൈകാര്യം ചെയ്യുന്നതിന് ഞങ്ങൾ ഇവിടെ പരിശോധിച്ചു.പ്രത്യേകിച്ച്
// നിങ്ങൾ mem::forget Rcs (അല്ലെങ്കിൽ ദുർബലമായത്) ആണെങ്കിൽ, ref-എണ്ണത്തിന് കവിഞ്ഞൊഴുകാൻ കഴിയും, തുടർന്ന് മികച്ച Rcs (അല്ലെങ്കിൽ ദുർബലമായത്) നിലനിൽക്കുമ്പോൾ നിങ്ങൾക്ക് അലോക്കേഷൻ സ്വതന്ത്രമാക്കാം.
//
// എന്താണ് സംഭവിക്കുന്നതെന്ന് ഞങ്ങൾ ശ്രദ്ധിക്കാത്ത ഒരു അധ enera പതിച്ച സാഹചര്യമായതിനാൽ ഞങ്ങൾ നിർത്തലാക്കുന്നു-ഒരു യഥാർത്ഥ പ്രോഗ്രാമും ഇത് അനുഭവിക്കരുത്.
//
// ഉടമസ്ഥാവകാശത്തിനും നീക്കൽ-സെമാന്റിക്‌സിനും നന്ദി Rust-ൽ ഇവയെല്ലാം ക്ലോൺ ചെയ്യേണ്ടതില്ല എന്നതിനാൽ ഇതിന് വളരെ ചെറിയ ഓവർഹെഡ് ഉണ്ടായിരിക്കണം.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // മൂല്യം ഉപേക്ഷിക്കുന്നതിനുപകരം ഓവർഫ്ലോയിൽ നിർത്താൻ ഞങ്ങൾ ആഗ്രഹിക്കുന്നു.
        // ഇതിനെ വിളിക്കുമ്പോൾ റഫറൻസ് എണ്ണം ഒരിക്കലും പൂജ്യമാകില്ല;
        // എന്നിരുന്നാലും, നഷ്‌ടമായ ഒപ്റ്റിമൈസേഷനിൽ എൽ‌എൽ‌വി‌എം സൂചിപ്പിക്കുന്നതിന് ഞങ്ങൾ ഇവിടെ ഒരു അലസിപ്പിക്കൽ ചേർക്കുന്നു.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // മൂല്യം ഉപേക്ഷിക്കുന്നതിനുപകരം ഓവർഫ്ലോയിൽ നിർത്താൻ ഞങ്ങൾ ആഗ്രഹിക്കുന്നു.
        // ഇതിനെ വിളിക്കുമ്പോൾ റഫറൻസ് എണ്ണം ഒരിക്കലും പൂജ്യമാകില്ല;
        // എന്നിരുന്നാലും, നഷ്‌ടമായ ഒപ്റ്റിമൈസേഷനിൽ എൽ‌എൽ‌വി‌എം സൂചിപ്പിക്കുന്നതിന് ഞങ്ങൾ ഇവിടെ ഒരു അലസിപ്പിക്കൽ ചേർക്കുന്നു.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// ഒരു പോയിന്ററിന് പിന്നിലുള്ള പേലോഡിനായി ഒരു `RcBox`-നുള്ളിൽ ഓഫ്‌സെറ്റ് നേടുക.
///
/// # Safety
///
/// പോയിന്ററിന്റെ മുമ്പത്തെ സാധുവായ ഒരു ഉദാഹരണത്തിലേക്ക് പോയിന്റർ പോയിന്റുചെയ്യണം (ഒപ്പം സാധുവായ മെറ്റാഡാറ്റയും ഉണ്ടായിരിക്കണം), പക്ഷേ ടി ഉപേക്ഷിക്കാൻ അനുവദിച്ചിരിക്കുന്നു.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // വലുപ്പം മാറ്റാത്ത മൂല്യം RcBox ന്റെ അവസാനത്തിലേക്ക് വിന്യസിക്കുക.
    // RcBox repr(C) ആയതിനാൽ, ഇത് എല്ലായ്പ്പോഴും മെമ്മറിയിലെ അവസാന ഫീൽഡായിരിക്കും.
    // സുരക്ഷ: വലുപ്പം മാറ്റാത്ത തരം സ്ലൈസുകൾ ആയതിനാൽ, trait ഒബ്ജക്റ്റുകൾ,
    // കൂടാതെ ബാഹ്യ തരങ്ങളും, align_of_val_raw ന്റെ ആവശ്യകതകൾ നിറവേറ്റുന്നതിന് നിലവിൽ ഇൻപുട്ട് സുരക്ഷാ ആവശ്യകത മതി;std ന് പുറത്ത് ആശ്രയിക്കാത്ത ഭാഷയുടെ നടപ്പാക്കൽ വിശദാംശമാണിത്.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}