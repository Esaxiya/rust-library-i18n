use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef, Root};

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// ഒരു സഹോദരനുമായി ലയിപ്പിക്കുകയോ മോഷ്ടിക്കുകയോ ചെയ്തുകൊണ്ട് ഒരുപക്ഷേ അണ്ടർഫുൾ നോഡ് സംഭരിക്കുന്നു.
    /// വിജയകരമാണെങ്കിലും രക്ഷാകർതൃ നോഡ് ചുരുക്കുന്നതിനുള്ള ചെലവിൽ, ചുരുങ്ങിയ രക്ഷാകർതൃ നോഡ് നൽകുന്നു.
    /// നോഡ് ഒരു ശൂന്യമായ റൂട്ട് ആണെങ്കിൽ ഒരു `Err` നൽകുന്നു.
    ///
    fn fix_node_through_parent(
        self,
    ) -> Result<Option<NodeRef<marker::Mut<'a>, K, V, marker::Internal>>, Self> {
        let len = self.len();
        if len >= MIN_LEN {
            Ok(None)
        } else {
            match self.choose_parent_kv() {
                Ok(Left(mut left_parent_kv)) => {
                    if left_parent_kv.can_merge() {
                        let parent = left_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        left_parent_kv.bulk_steal_left(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Ok(Right(mut right_parent_kv)) => {
                    if right_parent_kv.can_merge() {
                        let parent = right_parent_kv.merge_tracking_parent();
                        Ok(Some(parent))
                    } else {
                        right_parent_kv.bulk_steal_right(MIN_LEN - len);
                        Ok(None)
                    }
                }
                Err(root) => {
                    if len > 0 {
                        Ok(None)
                    } else {
                        Err(root)
                    }
                }
            }
        }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// ഒരുപക്ഷേ അണ്ടർഫുൾ നോഡ് സംഭരിക്കുന്നു, അത് അതിന്റെ പാരന്റ് നോഡ് ചുരുങ്ങാൻ ഇടയാക്കുന്നുവെങ്കിൽ, രക്ഷകർത്താവിനെ ആവർത്തിച്ച് സംഭരിക്കുന്നു.
    /// ട്രീ ശരിയാക്കിയാൽ `true`, റൂട്ട് നോഡ് ശൂന്യമായതിനാൽ `false` കഴിയുന്നില്ലെങ്കിൽ നൽകുന്നു.
    ///
    /// പ്രവേശനത്തിൽ‌പൂർ‌വ്വികർ‌ഇതിനകം തന്നെ പൂർ‌ണ്ണമായും panics ഉം ശൂന്യമായ ഒരു പൂർ‌വ്വികനെ കണ്ടുമുട്ടിയാൽ‌ഈ രീതി പ്രതീക്ഷിക്കുന്നില്ല.
    ///
    ///
    ///
    pub fn fix_node_and_affected_ancestors(mut self) -> bool {
        loop {
            match self.fix_node_through_parent() {
                Ok(Some(parent)) => self = parent.forget_type(),
                Ok(None) => return true,
                Err(_) => return false,
            }
        }
    }
}

impl<K, V> Root<K, V> {
    /// മുകളിലുള്ള ശൂന്യമായ ലെവലുകൾ നീക്കംചെയ്യുന്നു, പക്ഷേ മുഴുവൻ വൃക്ഷവും ശൂന്യമാണെങ്കിൽ ഒരു ശൂന്യമായ ഇല സൂക്ഷിക്കുന്നു.
    pub fn fix_top(&mut self) {
        while self.height() > 0 && self.len() == 0 {
            self.pop_internal_level();
        }
    }

    /// വൃക്ഷത്തിന്റെ വലത് അതിർത്തിയിൽ‌ഏതെങ്കിലും അണ്ടർ‌ഫുൾ‌നോഡുകൾ‌സംഭരിക്കുക അല്ലെങ്കിൽ‌ലയിപ്പിക്കുക.
    /// മറ്റ് നോഡുകളിൽ‌, റൂട്ട് അല്ലെങ്കിൽ‌വലതുവശത്തുള്ള edge അല്ലാത്തവയ്‌ക്ക് ഇതിനകം കുറഞ്ഞത് MIN_LEN ഘടകങ്ങളെങ്കിലും ഉണ്ടായിരിക്കണം.
    ///
    pub fn fix_right_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().last_kv().fix_right_border_of_right_edge();
            self.fix_top();
        }
    }

    /// `fix_right_border`-ന്റെ സമമിതി ക്ലോൺ.
    pub fn fix_left_border(&mut self) {
        self.fix_top();
        if self.len() > 0 {
            self.borrow_mut().first_kv().fix_left_border_of_left_edge();
            self.fix_top();
        }
    }

    /// വൃക്ഷത്തിന്റെ വലത് അതിർത്തിയിൽ‌ഏതെങ്കിലും അണ്ടർ‌ഫുൾ‌നോഡുകൾ‌സംഭരിക്കുക.
    /// മറ്റ് നോഡുകൾ, റൂട്ട് അല്ലാത്ത അല്ലെങ്കിൽ വലതുവശത്തുള്ള edge, MIN_LEN ഘടകങ്ങൾ വരെ മോഷ്ടിക്കാൻ തയ്യാറായിരിക്കണം.
    ///
    pub fn fix_right_border_of_plentiful(&mut self) {
        let mut cur_node = self.borrow_mut();
        while let Internal(internal) = cur_node.force() {
            // വലതുവശത്തുള്ള കുട്ടിക്ക് പൂർണ്ണമായതാണോയെന്ന് പരിശോധിക്കുക.
            let mut last_kv = internal.last_kv().consider_for_balancing();
            debug_assert!(last_kv.left_child_len() >= MIN_LEN * 2);
            let right_child_len = last_kv.right_child_len();
            if right_child_len < MIN_LEN {
                // നമ്മൾ മോഷ്ടിക്കണം.
                last_kv.bulk_steal_left(MIN_LEN - right_child_len);
            }

            // കൂടുതൽ താഴേക്ക് പോകുക.
            cur_node = last_kv.into_right_child();
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    fn fix_left_border_of_left_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_left_child().first_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }

    fn fix_right_border_of_right_edge(mut self) {
        while let Internal(internal_kv) = self.force() {
            self = internal_kv.fix_right_child().last_kv();
            debug_assert!(self.reborrow().into_node().len() > MIN_LEN);
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// ഇടത് കുട്ടിയെ സംഭരിക്കുക, ശരിയായ കുട്ടി പൂർണ്ണമല്ലെന്ന് കരുതുക, ഒപ്പം കുട്ടികളെ ലയിപ്പിക്കാൻ അനുവദിക്കാതെ ഒരു അധിക ഘടകം നൽകുകയും ചെയ്യുന്നു.
    ///
    /// ഇടത് കുട്ടിയെ നൽകുന്നു.
    ///
    fn fix_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let left_len = internal_kv.left_child_len();
        debug_assert!(internal_kv.right_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` അടുത്ത ഘട്ടത്തിൽ ലയനം നടന്നാൽ വീണ്ടും ക്രമീകരിക്കുന്നത് ഒഴിവാക്കാൻ.
            let count = (MIN_LEN + 1).saturating_sub(left_len);
            if count > 0 {
                internal_kv.bulk_steal_right(count);
            }
            internal_kv.into_left_child()
        }
    }

    /// ഇടത് കുട്ടി പൂർണ്ണമല്ലെന്ന് കരുതുക, ശരിയായ കുട്ടിയെ സംഭരിക്കുക, കൂടാതെ കുട്ടികളെ ലയിപ്പിക്കാൻ അനുവദിക്കാതെ ഒരു അധിക ഘടകം നൽകുകയും ചെയ്യുന്നു.
    ///
    /// ശരിയായ കുട്ടി അവസാനിച്ച ഇടങ്ങളിലെല്ലാം മടങ്ങുന്നു.
    ///
    fn fix_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        let mut internal_kv = self.consider_for_balancing();
        let right_len = internal_kv.right_child_len();
        debug_assert!(internal_kv.left_child_len() >= MIN_LEN);
        if internal_kv.can_merge() {
            internal_kv.merge_tracking_child()
        } else {
            // `MIN_LEN + 1` അടുത്ത ഘട്ടത്തിൽ ലയനം നടന്നാൽ വീണ്ടും ക്രമീകരിക്കുന്നത് ഒഴിവാക്കാൻ.
            let count = (MIN_LEN + 1).saturating_sub(right_len);
            if count > 0 {
                internal_kv.bulk_steal_left(count);
            }
            internal_kv.into_right_child()
        }
    }
}