use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef};

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    /// ട്രീയിൽ നിന്ന് ഒരു കീ-മൂല്യ ജോഡി നീക്കംചെയ്യുന്നു, ഒപ്പം ആ ജോഡിയും പഴയ ജോഡിക്ക് സമാനമായ edge ഇലയും നൽകുന്നു.
    /// ഇത് ആന്തരികമായ ഒരു റൂട്ട് നോഡിനെ ശൂന്യമാക്കാൻ സാധ്യതയുണ്ട്, ഇത് ട്രീ കൈവശമുള്ള മാപ്പിൽ നിന്ന് കോളർ പോപ്പ് ചെയ്യണം.
    /// കോളർ മാപ്പിന്റെ ദൈർഘ്യം കുറയ്‌ക്കുകയും വേണം.
    ///
    pub fn remove_kv_tracking<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        match self.force() {
            Leaf(node) => node.remove_leaf_kv(handle_emptied_internal_root),
            Internal(node) => node.remove_internal_kv(handle_emptied_internal_root),
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    fn remove_leaf_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let (old_kv, mut pos) = self.remove();
        let len = pos.reborrow().into_node().len();
        if len < MIN_LEN {
            let idx = pos.idx();
            // കുട്ടികളുടെ തരം ഞങ്ങൾ താൽക്കാലികമായി മറക്കണം, കാരണം ഒരു ഇലയുടെ ഉടനടി മാതാപിതാക്കൾക്ക് പ്രത്യേക നോഡ് തരം ഇല്ല.
            //
            let new_pos = match pos.into_node().forget_type().choose_parent_kv() {
                Ok(Left(left_parent_kv)) => {
                    debug_assert!(left_parent_kv.right_child_len() == MIN_LEN - 1);
                    if left_parent_kv.can_merge() {
                        left_parent_kv.merge_tracking_child_edge(Right(idx))
                    } else {
                        debug_assert!(left_parent_kv.left_child_len() > MIN_LEN);
                        left_parent_kv.steal_left(idx)
                    }
                }
                Ok(Right(right_parent_kv)) => {
                    debug_assert!(right_parent_kv.left_child_len() == MIN_LEN - 1);
                    if right_parent_kv.can_merge() {
                        right_parent_kv.merge_tracking_child_edge(Left(idx))
                    } else {
                        debug_assert!(right_parent_kv.right_child_len() > MIN_LEN);
                        right_parent_kv.steal_right(idx)
                    }
                }
                Err(pos) => unsafe { Handle::new_edge(pos, idx) },
            };
            // സുരക്ഷ: `new_pos` എന്നത് ഞങ്ങൾ ആരംഭിച്ച ഇലയോ സഹോദരനോ ആണ്.
            pos = unsafe { new_pos.cast_to_leaf_unchecked() };

            // ഞങ്ങൾ ലയിപ്പിച്ചാൽ മാത്രം, രക്ഷകർത്താവ് (എന്തെങ്കിലും ഉണ്ടെങ്കിൽ) ചുരുങ്ങി, പക്ഷേ ഇനിപ്പറയുന്ന ഘട്ടം ഒഴിവാക്കുന്നത് ബെഞ്ച്മാർക്കുകളിൽ പ്രതിഫലം നൽകില്ല.
            //
            // സുരക്ഷ: `pos` ഉള്ള ഇല ഞങ്ങൾ നശിപ്പിക്കുകയോ പുന range ക്രമീകരിക്കുകയോ ചെയ്യില്ല
            // അതിന്റെ രക്ഷകർത്താവിനെ ആവർത്തിച്ച് കൈകാര്യം ചെയ്യുന്നതിലൂടെ;ഏറ്റവും മോശമായ സമയത്ത് ഞങ്ങൾ മുത്തച്ഛനിലൂടെ മാതാപിതാക്കളെ നശിപ്പിക്കുകയോ പുന ar ക്രമീകരിക്കുകയോ ചെയ്യും, അങ്ങനെ ഇലയ്ക്കുള്ളിലെ രക്ഷകർത്താവിലേക്കുള്ള ലിങ്ക് മാറ്റും.
            //
            //
            //
            if let Ok(parent) = unsafe { pos.reborrow_mut() }.into_node().ascend() {
                if !parent.into_node().forget_type().fix_node_and_affected_ancestors() {
                    handle_emptied_internal_root();
                }
            }
        }
        (old_kv, pos)
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    fn remove_internal_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        // തൊട്ടടുത്തുള്ള കെവി അതിന്റെ ഇലയിൽ നിന്ന് നീക്കംചെയ്‌ത് നീക്കംചെയ്യാൻ ആവശ്യപ്പെട്ട മൂലകത്തിന്റെ സ്ഥാനത്ത് തിരികെ വയ്ക്കുക.
        //
        // `choose_parent_kv`-ൽ ലിസ്റ്റുചെയ്‌തിരിക്കുന്ന കാരണങ്ങളാൽ, ഇടതുവശത്തുള്ള കെ.വി.
        let left_leaf_kv = self.left_edge().descend().last_leaf_edge().left_kv();
        let left_leaf_kv = unsafe { left_leaf_kv.ok().unwrap_unchecked() };
        let (left_kv, left_hole) = left_leaf_kv.remove_leaf_kv(handle_emptied_internal_root);

        // ആന്തരിക നോഡ് മോഷ്ടിക്കുകയോ ലയിപ്പിക്കുകയോ ചെയ്‌തിരിക്കാം.
        // യഥാർത്ഥ കെവി എവിടെയാണ് അവസാനിച്ചതെന്ന് കണ്ടെത്താൻ വലത്തേക്ക് മടങ്ങുക.
        let mut internal = unsafe { left_hole.next_kv().ok().unwrap_unchecked() };
        let old_kv = internal.replace_kv(left_kv.0, left_kv.1);
        let pos = internal.next_leaf_edge();
        (old_kv, pos)
    }
}