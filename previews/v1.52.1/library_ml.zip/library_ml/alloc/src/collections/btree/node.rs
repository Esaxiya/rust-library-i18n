// ആദർശത്തെ പിന്തുടർന്ന് നടപ്പാക്കാനുള്ള ശ്രമമാണിത്
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Rust ന് യഥാർത്ഥത്തിൽ ആശ്രിത തരങ്ങളും പോളിമോർഫിക് ആവർത്തനങ്ങളും ഇല്ലാത്തതിനാൽ, ഞങ്ങൾ ധാരാളം സുരക്ഷിതത്വമില്ലാതെ പ്രവർത്തിക്കുന്നു.
//

// ഈ മൊഡ്യൂളിന്റെ ഒരു പ്രധാന ലക്ഷ്യം വൃക്ഷത്തെ ഒരു ജനറിക് (വിചിത്രമായ ആകൃതിയിലുള്ളതാണെങ്കിൽ) കണ്ടെയ്നറായി പരിഗണിച്ച് ബി-ട്രീ മാറ്റങ്ങളുമായി ഇടപഴകുന്നത് ഒഴിവാക്കുക എന്നതാണ്.
//
// അതുപോലെ, എൻ‌ട്രികൾ‌അടുക്കിയിട്ടുണ്ടോ, ഏത് നോഡുകൾ‌അണ്ടർ‌ഫുൾ‌ആകാം, അല്ലെങ്കിൽ‌അണ്ടർ‌ഫുൾ‌എന്താണ് അർ‌ത്ഥമാക്കുന്നതെന്ന് ഈ മൊഡ്യൂളിന് പരിഗണനയില്ല.എന്നിരുന്നാലും, ഞങ്ങൾ കുറച്ച് മാറ്റങ്ങളെ ആശ്രയിക്കുന്നു:
//
// - മരങ്ങൾക്ക് ആകർഷകമായ depth/height ഉണ്ടായിരിക്കണം.തന്നിരിക്കുന്ന നോഡിൽ നിന്ന് ഒരു ഇലയിലേക്കുള്ള ഓരോ പാതയ്ക്കും ഒരേ നീളമുണ്ടെന്നാണ് ഇതിനർത്ഥം.
// - `n` നീളമുള്ള ഒരു നോഡിന് `n` കീകളും `n` മൂല്യങ്ങളും `n + 1` അരികുകളും ഉണ്ട്.
//   ശൂന്യമായ ഒരു നോഡിന് പോലും കുറഞ്ഞത് ഒരു edge ഉണ്ടെന്ന് ഇത് സൂചിപ്പിക്കുന്നു.
//   ഒരു ഇല നോഡിനായി, എക്സ് 00 എക്സ് എന്നാൽ നോഡിലെ ഒരു സ്ഥാനം തിരിച്ചറിയാൻ മാത്രമേ കഴിയൂ, കാരണം ഇലയുടെ അറ്റങ്ങൾ ശൂന്യമാണ്, ഡാറ്റ പ്രാതിനിധ്യം ആവശ്യമില്ല.
// ഒരു ആന്തരിക നോഡിൽ, ഒരു edge രണ്ടും ഒരു സ്ഥാനം തിരിച്ചറിയുകയും ഒരു ചൈൽഡ് നോഡിലേക്കുള്ള പോയിന്റർ ഉൾക്കൊള്ളുകയും ചെയ്യുന്നു.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// ഇല നോഡുകളുടെ അടിസ്ഥാന പ്രാതിനിധ്യവും ആന്തരിക നോഡുകളുടെ പ്രാതിനിധ്യത്തിന്റെ ഭാഗവും.
struct LeafNode<K, V> {
    /// `K`, `V` എന്നിവയിൽ കോവിയറന്റ് ആകാൻ ഞങ്ങൾ ആഗ്രഹിക്കുന്നു.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// പാരന്റ് നോഡിന്റെ `edges` അറേയിലേക്ക് ഈ നോഡിന്റെ സൂചിക.
    /// `*node.parent.edges[node.parent_idx]` `node`-ന് തുല്യമായിരിക്കണം.
    /// `parent` ശൂന്യമല്ലാത്തപ്പോൾ മാത്രമേ ഇത് സമാരംഭിക്കുകയുള്ളൂ.
    parent_idx: MaybeUninit<u16>,

    /// ഈ നോഡ് സംഭരിക്കുന്ന കീകളുടെയും മൂല്യങ്ങളുടെയും എണ്ണം.
    len: u16,

    /// നോഡിന്റെ യഥാർത്ഥ ഡാറ്റ സംഭരിക്കുന്ന അറേകൾ.
    /// ഓരോ അറേയുടെയും ആദ്യത്തെ `len` ഘടകങ്ങൾ മാത്രമേ സമാരംഭിച്ചിട്ടുള്ളൂ.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// സ്ഥലത്ത് ഒരു പുതിയ `LeafNode` സമാരംഭിക്കുന്നു.
    unsafe fn init(this: *mut Self) {
        // ഒരു പൊതുനയം എന്ന നിലയിൽ, ഫീൽഡുകൾ സാധ്യമാകുമെങ്കിൽ അവ ആരംഭിക്കാതെ തന്നെ ഞങ്ങൾ വിടുന്നു, കാരണം ഇത് അൽപ്പം വേഗതയുള്ളതും വാൽഗ്രൈൻഡിൽ ട്രാക്കുചെയ്യാൻ എളുപ്പവുമാണ്.
        //
        unsafe {
            // പാരന്റ്_ഐഡിഎക്സ്, കീകൾ, വാളുകൾ എന്നിവയെല്ലാം ഒരുപക്ഷേ യുനിനിറ്റ് ആയിരിക്കും
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// ഒരു പുതിയ ബോക്‍സ്ഡ് `LeafNode` സൃഷ്ടിക്കുന്നു.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// ആന്തരിക നോഡുകളുടെ അടിസ്ഥാന പ്രാതിനിധ്യം.`ലീഫ്‌നോഡ് 'പോലെ, ആരംഭിക്കാത്ത കീകളും മൂല്യങ്ങളും ഉപേക്ഷിക്കുന്നത് തടയാൻ ഇവ` ബോക്‍സ്നോഡിന്' പിന്നിൽ മറയ്ക്കണം.
/// ഒരു `InternalNode`-ലേക്കുള്ള ഏത് പോയിന്ററും നോഡിന്റെ അന്തർലീനമായ `LeafNode` ഭാഗത്തേക്ക് ഒരു പോയിന്ററിലേക്ക് നേരിട്ട് കാസ്റ്റുചെയ്യാൻ കഴിയും, ഇത് ഒരു പോയിന്റർ ചൂണ്ടിക്കാണിക്കുന്ന രണ്ടിൽ ഏതാണ് എന്ന് പോലും പരിശോധിക്കാതെ തന്നെ ഇലയിലും ആന്തരിക നോഡുകളിലും കോഡ് പ്രവർത്തിക്കാൻ അനുവദിക്കുന്നു.
///
/// `repr(C)` ഉപയോഗിച്ച് ഈ പ്രോപ്പർട്ടി പ്രവർത്തനക്ഷമമാക്കി.
///
#[repr(C)]
// gdb_providers.py ആത്മപരിശോധനയ്ക്കായി ഈ തരം പേര് ഉപയോഗിക്കുന്നു.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// ഈ നോഡിന്റെ കുട്ടികളിലേക്കുള്ള പോയിന്ററുകൾ.
    /// `len + 1` ഇവയെ സമാരംഭിച്ചതും സാധുതയുള്ളതുമായി കണക്കാക്കുന്നു, അവസാനത്തോടൊഴികെ, കടം തരം `Dying` വഴി മരം പിടിച്ചിരിക്കുമ്പോൾ, ഈ പോയിൻറുകളിൽ ചിലത് തൂങ്ങിക്കിടക്കുന്നു.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// ഒരു പുതിയ ബോക്‍സ്ഡ് `InternalNode` സൃഷ്ടിക്കുന്നു.
    ///
    /// # Safety
    /// ആന്തരിക നോഡുകളുടെ ഒരു മാറ്റത്തിന് അവയ്‌ക്ക് കുറഞ്ഞത് ഒരു സമാരംഭിച്ചതും സാധുവായതുമായ edge ഉണ്ട് എന്നതാണ്.
    /// ഈ ഫംഗ്ഷൻ അത്തരമൊരു edge സജ്ജീകരിക്കുന്നില്ല.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // ഞങ്ങൾക്ക് ഡാറ്റ സമാരംഭിക്കേണ്ടതുണ്ട്;അരികുകൾ ഒരുപക്ഷേ യുനിനിറ്റ് ആണ്.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// ഒരു നോഡിലേക്കുള്ള നിയന്ത്രിത, ശൂന്യമല്ലാത്ത പോയിന്റർ.ഇത് ഒന്നുകിൽ `LeafNode<K, V>`-ന്റെ ഉടമസ്ഥതയിലുള്ള പോയിന്റർ അല്ലെങ്കിൽ `InternalNode<K, V>`-ന്റെ ഉടമസ്ഥതയിലുള്ള പോയിന്റർ ആണ്.
///
/// എന്നിരുന്നാലും, എക്സ് 100 എക്‌സിൽ ഏത് തരത്തിലുള്ള നോഡുകളാണ് യഥാർത്ഥത്തിൽ അടങ്ങിയിരിക്കുന്നതെന്ന് ഒരു വിവരവും അടങ്ങിയിട്ടില്ല, ഭാഗികമായി ഈ വിവരങ്ങളുടെ അഭാവം കാരണം ഒരു പ്രത്യേക തരം അല്ല, ഡിസ്ട്രക്റ്റർ ഇല്ല.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// ഒരു ഉടമസ്ഥതയിലുള്ള വൃക്ഷത്തിന്റെ റൂട്ട് നോഡ്.
///
/// ഇതിന് ഒരു ഡിസ്ട്രക്റ്റർ ഇല്ലെന്നത് ശ്രദ്ധിക്കുക, ഇത് സ്വമേധയാ വൃത്തിയാക്കണം.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// തുടക്കത്തിൽ ശൂന്യമായ സ്വന്തം റൂട്ട് നോഡ് ഉപയോഗിച്ച് ഒരു പുതിയ ഉടമസ്ഥതയിലുള്ള ട്രീ നൽകുന്നു.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` പൂജ്യമായിരിക്കരുത്.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// ഉടമസ്ഥതയിലുള്ള റൂട്ട് നോഡ് പരസ്പരം കടമെടുക്കുന്നു.
    /// `reborrow_mut`-ൽ നിന്ന് വ്യത്യസ്തമായി, ഇത് സുരക്ഷിതമാണ്, കാരണം റൂട്ട് നശിപ്പിക്കാൻ റിട്ടേൺ മൂല്യം ഉപയോഗിക്കാൻ കഴിയില്ല, കൂടാതെ ട്രീയെക്കുറിച്ച് മറ്റ് റഫറൻസുകൾ ഉണ്ടാകാനും കഴിയില്ല.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ഉടമസ്ഥതയിലുള്ള റൂട്ട് നോഡ് അല്പം പരിവർത്തനം ചെയ്യുന്നു.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// സഞ്ചാരത്തെ അനുവദിക്കുന്നതും വിനാശകരമായ രീതികളും മറ്റ് ചിലതും വാഗ്ദാനം ചെയ്യുന്ന ഒരു റഫറൻസിലേക്ക് മാറ്റാനാവാത്തവിധം പരിവർത്തനം ചെയ്യുന്നു.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// മുമ്പത്തെ റൂട്ട് നോഡിലേക്ക് പോയിന്റുചെയ്യുന്ന ഒരൊറ്റ edge ഉപയോഗിച്ച് ഒരു പുതിയ ആന്തരിക നോഡ് ചേർക്കുന്നു, ആ പുതിയ നോഡ് റൂട്ട് നോഡ് ആക്കി അത് തിരികെ നൽകുക.
    /// ഇത് ഉയരം 1 വർദ്ധിപ്പിക്കുകയും `pop_internal_level` ന് വിപരീതവുമാണ്.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, ഞങ്ങൾ ഇപ്പോൾ ആന്തരികമാണെന്ന് ഞങ്ങൾ മറന്നു എന്നതൊഴിച്ചാൽ:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ആന്തരിക റൂട്ട് നോഡ് നീക്കംചെയ്യുന്നു, ആദ്യത്തെ കുട്ടിയെ പുതിയ റൂട്ട് നോഡായി ഉപയോഗിക്കുന്നു.
    /// റൂട്ട് നോഡിന് ഒരു കുട്ടി മാത്രമുള്ളപ്പോൾ മാത്രമേ ഇത് വിളിക്കാൻ ഉദ്ദേശിച്ചുള്ളൂ എന്നതിനാൽ, ഏതെങ്കിലും കീകൾ, മൂല്യങ്ങൾ, മറ്റ് കുട്ടികൾ എന്നിവയിൽ വൃത്തിയാക്കൽ നടത്തുന്നില്ല.
    ///
    /// ഇത് ഉയരം 1 കുറയ്ക്കുകയും `push_internal_level` ന് വിപരീതവുമാണ്.
    ///
    /// `Root` ഒബ്‌ജക്റ്റിലേക്ക് എക്‌സ്‌ക്ലൂസീവ് ആക്‌സസ്സ് ആവശ്യമാണ്, പക്ഷേ റൂട്ട് നോഡിലേക്ക് അല്ല;
    /// ഇത് റൂട്ട് നോഡിലേക്കുള്ള മറ്റ് ഹാൻഡിലുകളോ റഫറൻസുകളോ അസാധുവാക്കില്ല.
    ///
    /// ആന്തരിക നില ഇല്ലെങ്കിൽ Panics, അതായത്, റൂട്ട് നോഡ് ഒരു ഇലയാണെങ്കിൽ.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // സുരക്ഷ: ഞങ്ങൾ ആന്തരികമാണെന്ന് ഉറപ്പിച്ചു.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // സുരക്ഷ: ഞങ്ങൾ എക്സ് 00 എക്സ് പ്രത്യേകമായി കടമെടുത്തു, അതിന്റെ വായ്പ തരം എക്സ്ക്ലൂസീവ് ആണ്.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // സുരക്ഷ: ആദ്യത്തെ edge എല്ലായ്പ്പോഴും സമാരംഭിക്കും.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `BorrowType` `Mut` ആയിരിക്കുമ്പോൾ പോലും,`NodeRef` എല്ലായ്പ്പോഴും `K`, `V` എന്നിവയിൽ കോവിയറന്റാണ്.
// ഇത് സാങ്കേതികമായി തെറ്റാണ്, പക്ഷേ `NodeRef` ന്റെ ആന്തരിക ഉപയോഗം കാരണം ഒരു സുരക്ഷിതത്വത്തിനും കാരണമാകില്ല, കാരണം ഞങ്ങൾ `K`, `V` എന്നിവയിൽ പൂർണ്ണമായും ജനറിക് ആയി തുടരുന്നു.
//
// എന്നിരുന്നാലും, ഒരു പൊതു തരം `NodeRef` പൊതിയുമ്പോഴെല്ലാം, അതിന് ശരിയായ വ്യത്യാസമുണ്ടെന്ന് ഉറപ്പാക്കുക.
//
/// ഒരു നോഡിലേക്കുള്ള റഫറൻസ്.
///
/// ഈ തരം എങ്ങനെ പ്രവർത്തിക്കുന്നുവെന്ന് നിയന്ത്രിക്കുന്ന നിരവധി പാരാമീറ്ററുകൾ ഉണ്ട്:
/// - `BorrowType`: ഒരു തരം കടം വിവരിക്കുന്നതും ജീവിതകാലം മുഴുവൻ വഹിക്കുന്നതുമായ ഒരു ഡമ്മി തരം.
///    - ഇത് `Immut<'a>` ആയിരിക്കുമ്പോൾ, `NodeRef` ഏകദേശം `&'a Node` പോലെ പ്രവർത്തിക്കുന്നു.
///    - ഇത് `ValMut<'a>` ആയിരിക്കുമ്പോൾ, കീകളെയും ട്രീ ഘടനയെയും സംബന്ധിച്ച് `NodeRef` ഏകദേശം `&'a Node` പോലെ പ്രവർത്തിക്കുന്നു, മാത്രമല്ല ട്രീയിലുടനീളമുള്ള മൂല്യങ്ങളിലേക്ക് പരസ്പരം മാറ്റാൻ കഴിയുന്ന നിരവധി റഫറൻസുകൾ ഒരുമിച്ച് നിലനിൽക്കാൻ അനുവദിക്കുന്നു.
///    - ഇത് `Mut<'a>` ആയിരിക്കുമ്പോൾ, `NodeRef` ഏകദേശം `&'a mut Node` പോലെ പ്രവർത്തിക്കുന്നു, എന്നിരുന്നാലും ഉൾപ്പെടുത്തൽ രീതികൾ ഒരു മൂല്യത്തിലേക്ക് പരിവർത്തനം ചെയ്യാവുന്ന പോയിന്ററിനെ സഹവർത്തിക്കാൻ അനുവദിക്കുന്നു.
///    - ഇത് `Owned` ആയിരിക്കുമ്പോൾ, `NodeRef` ഏകദേശം `Box<Node>` പോലെ പ്രവർത്തിക്കുന്നു, പക്ഷേ ഒരു ഡിസ്ട്രക്റ്റർ ഇല്ല, മാത്രമല്ല ഇത് സ്വമേധയാ വൃത്തിയാക്കണം.
///    - ഇത് `Dying` ആയിരിക്കുമ്പോൾ, `NodeRef` ഇപ്പോഴും ഏകദേശം `Box<Node>` പോലെ പ്രവർത്തിക്കുന്നു, പക്ഷേ വൃക്ഷത്തെ ബിറ്റ് ഉപയോഗിച്ച് നശിപ്പിക്കുന്നതിനുള്ള രീതികളുണ്ട്, കൂടാതെ സാധാരണ രീതികൾ, വിളിക്കാൻ സുരക്ഷിതമല്ലെന്ന് അടയാളപ്പെടുത്തിയിട്ടില്ലെങ്കിലും തെറ്റായി വിളിച്ചാൽ യുബിയെ അഭ്യർത്ഥിക്കാൻ കഴിയും.
///
///   ഏതെങ്കിലും `NodeRef` ട്രീയിലൂടെ നാവിഗേറ്റുചെയ്യാൻ അനുവദിക്കുന്നതിനാൽ, നോഡിന് മാത്രമല്ല, മുഴുവൻ വൃക്ഷത്തിനും `BorrowType` ഫലപ്രദമായി ബാധകമാണ്.
/// - `K` ഒപ്പം `V`: നോഡുകളിൽ സംഭരിച്ചിരിക്കുന്ന കീകളുടെയും മൂല്യങ്ങളുടെയും തരങ്ങൾ ഇവയാണ്.
/// - `Type`: ഇത് `Leaf`, `Internal` അല്ലെങ്കിൽ `LeafOrInternal` ആകാം.
/// ഇത് `Leaf` ആയിരിക്കുമ്പോൾ, `NodeRef` ഒരു ഇല നോഡിലേക്ക് പോയിന്റുചെയ്യുന്നു, ഇത് `Internal` ആയിരിക്കുമ്പോൾ `NodeRef` ഒരു ആന്തരിക നോഡിലേക്ക് പോയിന്റ് ചെയ്യുന്നു, ഇത് `LeafOrInternal` ആയിരിക്കുമ്പോൾ `NodeRef` രണ്ട് തരം നോഡുകളിലേക്കും പോയിന്റുചെയ്യാം.
///   `Type` `NodeRef` ന് പുറത്ത് ഉപയോഗിക്കുമ്പോൾ `NodeType` എന്ന് നാമകരണം ചെയ്യപ്പെടുന്നു.
///
/// സ്റ്റാറ്റിക് തരം സുരക്ഷ പ്രയോജനപ്പെടുത്തുന്നതിന് ഞങ്ങൾ നടപ്പിലാക്കുന്ന രീതികളെ `BorrowType`, `NodeType` എന്നിവ നിയന്ത്രിക്കുന്നു.അത്തരം നിയന്ത്രണങ്ങൾ‌പ്രയോഗിക്കാൻ‌ഞങ്ങൾ‌ക്ക് പരിമിതികളുണ്ട്:
/// - ഓരോ തരം പാരാമീറ്ററിനും, നമുക്ക് ഒരു രീതി സാധാരണ അല്ലെങ്കിൽ ഒരു പ്രത്യേക തരം മാത്രമേ നിർവചിക്കാൻ കഴിയൂ.
/// ഉദാഹരണത്തിന്, ഞങ്ങൾക്ക് `into_kv` പോലുള്ള ഒരു രീതി പൊതുവായി എല്ലാ `BorrowType`-നും അല്ലെങ്കിൽ ജീവിതകാലം മുഴുവൻ വഹിക്കുന്ന എല്ലാ തരത്തിനും നിർവചിക്കാൻ കഴിയില്ല, കാരണം ഇത് `&'a` റഫറൻസുകൾ നൽകണമെന്ന് ഞങ്ങൾ ആഗ്രഹിക്കുന്നു.
///   അതിനാൽ, ഏറ്റവും ശക്തിയേറിയ തരം `Immut<'a>`-ന് മാത്രമാണ് ഞങ്ങൾ ഇത് നിർവചിക്കുന്നത്.
/// - `Mut<'a>` മുതൽ `Immut<'a>` വരെ പറയാൻ‌ഞങ്ങൾ‌ക്ക് കഴിയില്ല.
///   അതിനാൽ, `into_kv` പോലുള്ള ഒരു രീതിയിലെത്താൻ കൂടുതൽ ശക്തമായ `NodeRef`-ൽ `reborrow`-നെ ഞങ്ങൾ വ്യക്തമായി വിളിക്കണം.
///
/// ഏതെങ്കിലും തരത്തിലുള്ള റഫറൻസ് നൽകുന്ന `NodeRef`-ലെ എല്ലാ രീതികളും:
/// - മൂല്യമനുസരിച്ച് `self` എടുക്കുക, ഒപ്പം `BorrowType` വഹിച്ച ആയുസ്സ് തിരികെ നൽകുക.
///   ചിലപ്പോൾ, അത്തരമൊരു രീതി അഭ്യർത്ഥിക്കാൻ, ഞങ്ങൾ `reborrow_mut`-നെ വിളിക്കേണ്ടതുണ്ട്.
/// - റഫറൻസ് പ്രകാരം `self` എടുക്കുക, X002 വഹിക്കുന്ന ആജീവനാന്തത്തിനുപകരം (implicitly) ആ റഫറൻസിന്റെ ആയുസ്സ് നൽകുന്നു.
/// ആ രീതിയിൽ, മടങ്ങിയ റഫറൻസ് ഉപയോഗിക്കുന്നിടത്തോളം കാലം `NodeRef` കടമെടുത്തതായി വായ്പ ചെക്കർ ഉറപ്പുനൽകുന്നു.
///   ഉൾപ്പെടുത്തലിനെ പിന്തുണയ്‌ക്കുന്ന രീതികൾ‌ഒരു അസംസ്കൃത പോയിന്റർ‌, അതായത്, ജീവിതകാലം മുഴുവൻ ഇല്ലാത്ത ഒരു റഫറൻസ് മടക്കിനൽകുന്നതിലൂടെ ഈ നിയമം വളച്ചൊടിക്കുന്നു.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// നോഡിന്റെ ഇലകളുടെ എണ്ണവും ഇലകളുടെ ലെവലും തമ്മിൽ വ്യത്യാസമുണ്ട്, എക്സ് 00 എക്സ് പൂർണ്ണമായും വിവരിക്കാൻ കഴിയാത്ത നോഡിന്റെ സ്ഥിരത, നോഡ് തന്നെ സംഭരിക്കുന്നില്ല.
    /// ഞങ്ങൾക്ക് റൂട്ട് നോഡിന്റെ ഉയരം മാത്രമേ സംഭരിക്കാവൂ, മാത്രമല്ല മറ്റെല്ലാ നോഡിന്റെ ഉയരവും അതിൽ നിന്ന് നേടുകയും വേണം.
    /// `Type` `Leaf` ആണെങ്കിൽ പൂജ്യവും `Type` `Internal` ആണെങ്കിൽ പൂജ്യമല്ലാത്തതുമായിരിക്കണം.
    ///
    ///
    height: usize,
    /// ഇലയിലേക്കോ ആന്തരിക നോഡിലേക്കോ പോയിന്റർ.
    /// `InternalNode`-ന്റെ നിർവചനം പോയിന്റർ ഏതെങ്കിലും വിധത്തിൽ സാധുതയുള്ളതാണെന്ന് ഉറപ്പാക്കുന്നു.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// `NodeRef::parent` ആയി പായ്ക്ക് ചെയ്ത ഒരു നോഡ് റഫറൻസ് അൺപാക്ക് ചെയ്യുക.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// ഒരു ആന്തരിക നോഡിന്റെ ഡാറ്റ വെളിപ്പെടുത്തുന്നു.
    ///
    /// ഈ നോഡിലേക്കുള്ള മറ്റ് റഫറൻസുകൾ അസാധുവാക്കുന്നത് ഒഴിവാക്കാൻ ഒരു അസംസ്കൃത ptr നൽകുന്നു.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // സുരക്ഷ: സ്റ്റാറ്റിക് നോഡ് തരം `Internal` ആണ്.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// ഒരു ആന്തരിക നോഡിന്റെ ഡാറ്റയിലേക്ക് എക്സ്ക്ലൂസീവ് ആക്സസ് കടമെടുക്കുന്നു.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// നോഡിന്റെ ദൈർഘ്യം കണ്ടെത്തുന്നു.ഇതാണ് കീകളുടെയോ മൂല്യങ്ങളുടെയോ എണ്ണം.
    /// അരികുകളുടെ എണ്ണം `len() + 1` ആണ്.
    /// ശ്രദ്ധിക്കുക, സുരക്ഷിതമാണെങ്കിലും, ഈ ഫംഗ്ഷനെ വിളിക്കുന്നത് സുരക്ഷിതമല്ലാത്ത കോഡ് സൃഷ്ടിച്ച മ്യൂട്ടബിൾ റഫറൻസുകൾ അസാധുവാക്കുന്നതിന്റെ പാർശ്വഫലമുണ്ടാക്കുമെന്നത് ശ്രദ്ധിക്കുക.
    ///
    pub fn len(&self) -> usize {
        // നിർണായകമായി, ഞങ്ങൾ ഇവിടെ `len` ഫീൽഡിൽ മാത്രമേ പ്രവേശിക്കുകയുള്ളൂ.
        // BorrowType marker::ValMut ആണെങ്കിൽ, ഞങ്ങൾ അസാധുവാക്കാൻ പാടില്ലാത്ത മൂല്യങ്ങളെക്കുറിച്ച് ശ്രദ്ധേയമായ മ്യൂട്ടബിൾ റഫറൻസുകൾ ഉണ്ടാകാം.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// നോഡും ഇലകളും വേർതിരിക്കുന്ന ലെവലുകളുടെ എണ്ണം നൽകുന്നു.
    /// പൂജ്യം ഉയരം അർത്ഥമാക്കുന്നത് നോഡ് ഒരു ഇല തന്നെ എന്നാണ്.
    /// മുകളിൽ റൂട്ട് ഉപയോഗിച്ച് നിങ്ങൾ മരങ്ങൾ ചിത്രീകരിക്കുകയാണെങ്കിൽ, ഏത് ഉയരത്തിലാണ് നോഡ് ദൃശ്യമാകുന്നതെന്ന് നമ്പർ പറയുന്നു.
    /// മുകളിൽ ഇലകളുള്ള മരങ്ങൾ നിങ്ങൾ ചിത്രീകരിക്കുകയാണെങ്കിൽ, നമ്പർ നോഡിന് മുകളിൽ മരം എത്രത്തോളം നീളുന്നുവെന്ന് നമ്പർ പറയുന്നു.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// ഒരേ നോഡിലേക്ക് മാറ്റമില്ലാത്ത മറ്റൊരു റഫറൻസ് താൽക്കാലികമായി എടുക്കുന്നു.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ഏതെങ്കിലും ഇലയുടെയോ ആന്തരിക നോഡിന്റെയോ ഇല ഭാഗം തുറന്നുകാട്ടുന്നു.
    ///
    /// ഈ നോഡിലേക്കുള്ള മറ്റ് റഫറൻസുകൾ അസാധുവാക്കുന്നത് ഒഴിവാക്കാൻ ഒരു അസംസ്കൃത ptr നൽകുന്നു.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // കുറഞ്ഞത് ലീഫ്നോഡ് ഭാഗത്തിന് നോഡ് സാധുവായിരിക്കണം.
        // ഇത് നോഡ് റീഫ് തരത്തിലുള്ള ഒരു റഫറൻസല്ല, കാരണം ഇത് അദ്വിതീയമാണോ അതോ പങ്കിട്ടതാണോ എന്ന് ഞങ്ങൾക്ക് അറിയില്ല.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// നിലവിലെ നോഡിന്റെ രക്ഷകർത്താവ് കണ്ടെത്തുന്നു.
    /// നിലവിലെ നോഡിന് യഥാർത്ഥത്തിൽ ഒരു രക്ഷകർത്താവ് ഉണ്ടെങ്കിൽ `Ok(handle)` നൽകുന്നു, ഇവിടെ `handle` നിലവിലെ നോഡിലേക്ക് പോയിന്റുചെയ്യുന്ന രക്ഷാകർതൃത്തിന്റെ edge-ലേക്ക് പോയിന്റുചെയ്യുന്നു.
    ///
    /// നിലവിലെ നോഡിന് രക്ഷകർത്താവ് ഇല്ലെങ്കിൽ `Err(self)` നൽകുന്നു, യഥാർത്ഥ `NodeRef` തിരികെ നൽകുന്നു.
    ///
    /// മുകളിൽ റൂട്ട് നോഡ് ഉപയോഗിച്ച് മരങ്ങൾ ചിത്രീകരിക്കാമെന്ന് രീതി നാമം അനുമാനിക്കുന്നു.
    ///
    /// `edge.descend().ascend().unwrap()` `node.ascend().unwrap().descend()` രണ്ടും വിജയിച്ചാൽ ഒന്നും ചെയ്യരുത്.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // ഞങ്ങൾ നോഡുകളിലേക്ക് റോ പോയിന്ററുകൾ ഉപയോഗിക്കേണ്ടതുണ്ട്, കാരണം, ബോറോടൈപ്പ് marker::ValMut ആണെങ്കിൽ, ഞങ്ങൾ അസാധുവാക്കരുതാത്ത മൂല്യങ്ങളെക്കുറിച്ച് ശ്രദ്ധേയമായ മ്യൂട്ടബിൾ റഫറൻസുകൾ ഉണ്ടാകാം.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// `self` നിസ്സഹായമായിരിക്കണം എന്നത് ശ്രദ്ധിക്കുക.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// `self` നിസ്സഹായമായിരിക്കണം എന്നത് ശ്രദ്ധിക്കുക.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// മാറ്റമില്ലാത്ത വൃക്ഷത്തിൽ ഏതെങ്കിലും ഇലയുടെയോ ആന്തരിക നോഡിന്റെയോ ഇല ഭാഗം തുറന്നുകാട്ടുന്നു.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // സുരക്ഷ: `Immut` ആയി കടമെടുത്ത ഈ ട്രീയിലേക്ക് മ്യൂട്ടബിൾ റഫറൻസുകളൊന്നുമില്ല.
        unsafe { &*ptr }
    }

    /// നോഡിൽ സംഭരിച്ചിരിക്കുന്ന കീകളിലേക്ക് ഒരു കാഴ്ച കടമെടുക്കുന്നു.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// `ascend` ന് സമാനമായി, ഒരു നോഡിന്റെ പാരന്റ് നോഡിലേക്ക് ഒരു റഫറൻസ് ലഭിക്കുന്നു, മാത്രമല്ല പ്രോസസ്സിലെ നിലവിലെ നോഡിനെ ഡീലോക്കേറ്റ് ചെയ്യുന്നു.
    /// ഇത് സുരക്ഷിതമല്ല കാരണം ഡീലോക്കേറ്റ് ചെയ്തിട്ടും നിലവിലെ നോഡ് ആക്സസ് ചെയ്യാൻ കഴിയും.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// ഈ നോഡ് ഒരു `Leaf` ആണെന്ന സ്റ്റാറ്റിക് വിവരങ്ങൾ കംപൈലറിന് സുരക്ഷിതമല്ല.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ഈ നോഡ് ഒരു `Internal` ആണെന്ന സ്റ്റാറ്റിക് വിവരങ്ങൾ കംപൈലറിന് സുരക്ഷിതമല്ല.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// ഒരേ നോഡിലേക്ക് മാറ്റാവുന്ന മറ്റൊരു റഫറൻസ് താൽക്കാലികമായി എടുക്കുന്നു.സൂക്ഷിക്കുക, ഈ രീതി വളരെ അപകടകരമാണ്, ഇരട്ടി അതിനാൽ അത് പെട്ടെന്ന് അപകടകരമാണെന്ന് തോന്നുന്നില്ല.
    ///
    /// മ്യൂട്ടബിൾ പോയിൻററുകൾ‌മരത്തിന് ചുറ്റും എവിടെയും കറങ്ങാൻ‌കഴിയുന്നതിനാൽ‌, മടങ്ങിയെത്തിയ പോയിന്റർ‌യഥാർത്ഥ പോയിന്റർ‌തൂങ്ങിക്കിടക്കുന്നതിനോ പരിധിക്ക് പുറത്തുള്ളതിനോ അല്ലെങ്കിൽ‌അടുക്കിയിരിക്കുന്ന വായ്പ നിയമങ്ങൾ‌പ്രകാരം അസാധുവാക്കുന്നതിനോ ഉപയോഗിക്കാൻ‌കഴിയും.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) പുനർനിർമ്മിച്ച പോയിന്ററുകളിൽ നാവിഗേഷൻ രീതികളുടെ ഉപയോഗം നിയന്ത്രിക്കുന്ന `NodeRef`-ലേക്ക് മറ്റൊരു തരം പാരാമീറ്റർ ചേർക്കുന്നത് പരിഗണിക്കുക, ഈ സുരക്ഷിതത്വം തടയുന്നു.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// ഏതെങ്കിലും ഇലയുടെയോ ആന്തരിക നോഡിന്റെയോ ഇല ഭാഗത്തേക്ക് എക്സ്ക്ലൂസീവ് ആക്സസ് കടമെടുക്കുന്നു.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // സുരക്ഷ: മുഴുവൻ നോഡിലേക്കും ഞങ്ങൾക്ക് എക്സ്ക്ലൂസീവ് ആക്സസ് ഉണ്ട്.
        unsafe { &mut *ptr }
    }

    /// ഏതെങ്കിലും ഇലയുടെയോ ആന്തരിക നോഡിന്റെയോ ഇല ഭാഗത്തേക്ക് എക്സ്ക്ലൂസീവ് ആക്സസ് വാഗ്ദാനം ചെയ്യുന്നു.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // സുരക്ഷ: മുഴുവൻ നോഡിലേക്കും ഞങ്ങൾക്ക് എക്സ്ക്ലൂസീവ് ആക്സസ് ഉണ്ട്.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// കീ സംഭരണ ഏരിയയിലെ ഒരു ഘടകത്തിലേക്ക് എക്‌സ്‌ക്ലൂസീവ് ആക്‌സസ്സ് കടമെടുക്കുന്നു.
    ///
    /// # Safety
    /// `index` 0. .CAPACITY എന്നതിന്റെ പരിധിയിലാണ്
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // സുരക്ഷ: വിളിക്കുന്നയാൾക്ക് സ്വയം കൂടുതൽ രീതികൾ വിളിക്കാൻ കഴിയില്ല
        // കീ സ്ലൈസ് റഫറൻസ് ഉപേക്ഷിക്കുന്നതുവരെ, വായ്പയുടെ ആജീവനാന്തത്തിൽ ഞങ്ങൾക്ക് അദ്വിതീയ ആക്‌സസ് ഉണ്ട്.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// നോഡിന്റെ മൂല്യം സംഭരണ സ്ഥലത്തിന്റെ ഒരു ഘടകത്തിലേക്കോ സ്ലൈസിലേക്കോ എക്സ്ക്ലൂസീവ് ആക്സസ് കടമെടുക്കുന്നു.
    ///
    /// # Safety
    /// `index` 0. .CAPACITY എന്നതിന്റെ പരിധിയിലാണ്
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // സുരക്ഷ: വിളിക്കുന്നയാൾക്ക് സ്വയം കൂടുതൽ രീതികൾ വിളിക്കാൻ കഴിയില്ല
        // വായ്പ സ്ലൈഫ് റഫറൻസ് ഉപേക്ഷിക്കുന്നതുവരെ, വായ്പയുടെ ആജീവനാന്തത്തിൽ ഞങ്ങൾക്ക് അദ്വിതീയ ആക്‌സസ് ഉണ്ട്.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// edge ഉള്ളടക്കങ്ങൾക്കായി നോഡിന്റെ സ്റ്റോറേജ് ഏരിയയുടെ ഒരു ഘടകത്തിലേക്കോ സ്ലൈസിലേക്കോ എക്സ്ക്ലൂസീവ് ആക്സസ് കടമെടുക്കുന്നു.
    ///
    /// # Safety
    /// `index` 0. .CAPACITY + 1 ന്റെ പരിധിയിലാണ്
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // സുരക്ഷ: വിളിക്കുന്നയാൾക്ക് സ്വയം കൂടുതൽ രീതികൾ വിളിക്കാൻ കഴിയില്ല
        // edge സ്ലൈസ് റഫറൻസ് ഉപേക്ഷിക്കുന്നതുവരെ, വായ്പയുടെ ആജീവനാന്തത്തിൽ ഞങ്ങൾക്ക് അദ്വിതീയ ആക്സസ് ഉണ്ട്.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - നോഡിന് `idx` ൽ കൂടുതൽ സമാരംഭിച്ച ഘടകങ്ങളുണ്ട്.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // മറ്റ് ഘടകങ്ങളിലേക്ക് ശ്രദ്ധേയമായ റഫറൻസുകളുമായി അപരനാമം ഒഴിവാക്കാൻ, ഞങ്ങൾക്ക് താൽപ്പര്യമുള്ള ഒരു ഘടകത്തിലേക്ക് മാത്രമാണ് ഞങ്ങൾ ഒരു റഫറൻസ് സൃഷ്ടിക്കുന്നത്, പ്രത്യേകിച്ചും, മുമ്പത്തെ ആവർത്തനങ്ങളിൽ കോളറിലേക്ക് മടങ്ങിയവ.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Rust ലക്കം #74679 കാരണം വലുപ്പം മാറ്റാത്ത അറേ പോയിന്ററുകളിലേക്ക് ഞങ്ങൾ നിർബന്ധിക്കണം.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// നോഡിന്റെ ദൈർഘ്യത്തിലേക്ക് എക്‌സ്‌ക്ലൂസീവ് ആക്‌സസ്സ് കടമെടുക്കുന്നു.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// നോഡിലേക്കുള്ള മറ്റ് റഫറൻസുകൾ അസാധുവാക്കാതെ നോഡിന്റെ ലിങ്ക് അതിന്റെ പാരന്റ് edge ലേക്ക് സജ്ജമാക്കുന്നു.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// റൂട്ടിന്റെ ലിങ്ക് അതിന്റെ പാരന്റ് edge-ലേക്ക് മായ്‌ക്കുന്നു.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// നോഡിന്റെ അവസാനത്തിൽ ഒരു കീ-മൂല്യ ജോഡി ചേർക്കുന്നു.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// `range` നൽകിയ എല്ലാ ഇനങ്ങളും നോഡിനുള്ള സാധുവായ edge സൂചികയാണ്.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// ആ ജോഡിയുടെ വലതുവശത്തേക്ക് നോഡിന്റെ അവസാനഭാഗത്തേക്ക് പോകാൻ ഒരു കീ-മൂല്യ ജോഡിയും edge ഉം ചേർക്കുന്നു.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// ഒരു നോഡ് ഒരു `Internal` നോഡാണോ അതോ എക്സ് 01 എക്സ് നോഡാണോ എന്ന് പരിശോധിക്കുന്നു.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// ഒരു നിർദ്ദിഷ്ട കീ-മൂല്യ ജോഡിയിലേക്കുള്ള റഫറൻസ് അല്ലെങ്കിൽ ഒരു നോഡിനുള്ളിലെ edge.
/// `Node` പാരാമീറ്റർ ഒരു `NodeRef` ആയിരിക്കണം, അതേസമയം `Type` ഒന്നുകിൽ `KV` (ഒരു കീ-മൂല്യ ജോഡിയിൽ ഒരു ഹാൻഡിൽ സൂചിപ്പിക്കുന്നു) അല്ലെങ്കിൽ `Edge` (edge-ൽ ഒരു ഹാൻഡിൽ സൂചിപ്പിക്കുന്നു) ആകാം.
///
/// `Leaf` നോഡുകൾക്ക് പോലും `Edge` ഹാൻഡിലുകൾ ഉണ്ടാകുമെന്നത് ശ്രദ്ധിക്കുക.
/// ഒരു ചൈൽഡ് നോഡിലേക്ക് ഒരു പോയിന്റർ പ്രതിനിധീകരിക്കുന്നതിനുപകരം, കീ-മൂല്യ ജോഡികൾക്കിടയിൽ ചൈൽഡ് പോയിന്ററുകൾ പോകുന്ന ഇടങ്ങളെ ഇവ പ്രതിനിധീകരിക്കുന്നു.
/// ഉദാഹരണത്തിന്, നീളം 2 ഉള്ള ഒരു നോഡിൽ, സാധ്യമായ 3 edge സ്ഥാനങ്ങൾ ഉണ്ടാകും, ഒന്ന് നോഡിന്റെ ഇടതുവശത്ത്, രണ്ട് ജോഡികൾക്കിടയിൽ ഒന്ന്, നോഡിന്റെ വലതുവശത്ത്.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// ഞങ്ങൾക്ക് `#[derive(Clone)]`-ന്റെ പൂർണ്ണമായ സാമാന്യത ആവശ്യമില്ല, കാരണം `Node` എന്നത് ഒരു മാറ്റമില്ലാത്ത റഫറൻസായിരിക്കുമ്പോഴും `Copy` ആകുമ്പോഴും `ക്ലോൺ` ചെയ്യാവുന്ന ഒരേയൊരു സമയമായിരിക്കും.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// ഈ ഹാൻഡിൽ ചൂണ്ടിക്കാണിക്കുന്ന edge അല്ലെങ്കിൽ കീ-മൂല്യ ജോഡി അടങ്ങിയിരിക്കുന്ന നോഡ് വീണ്ടെടുക്കുന്നു.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// നോഡിലെ ഈ ഹാൻഡിൽ സ്ഥാനം നൽകുന്നു.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// `node`-ൽ ഒരു കീ-മൂല്യ ജോഡിയിലേക്ക് ഒരു പുതിയ ഹാൻഡിൽ സൃഷ്ടിക്കുന്നു.
    /// സുരക്ഷിതമല്ലാത്തതിനാൽ കോളർ `idx < node.len()` എന്ന് ഉറപ്പാക്കണം.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// PartialEq-ന്റെ പൊതുവായ നടപ്പാക്കലാകാം, പക്ഷേ ഈ മൊഡ്യൂളിൽ മാത്രം ഉപയോഗിക്കുന്നു.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// ഒരേ സ്ഥലത്ത് മാറ്റമില്ലാത്ത മറ്റൊരു ഹാൻഡിൽ താൽക്കാലികമായി പുറത്തെടുക്കുന്നു.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // ഞങ്ങളുടെ തരം അറിയാത്തതിനാൽ ഞങ്ങൾക്ക് Handle::new_kv അല്ലെങ്കിൽ Handle::new_edge ഉപയോഗിക്കാൻ കഴിയില്ല
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// ഹാൻഡിലിന്റെ നോഡ് ഒരു `Leaf` ആണെന്ന സ്റ്റാറ്റിക് വിവരങ്ങൾ കംപൈലറിന് സുരക്ഷിതമല്ല.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// ഒരേ സ്ഥലത്ത് മാറ്റാൻ കഴിയുന്ന മറ്റൊരു ഹാൻഡിൽ താൽക്കാലികമായി എടുക്കുന്നു.
    /// സൂക്ഷിക്കുക, ഈ രീതി വളരെ അപകടകരമാണ്, ഇരട്ടി അതിനാൽ അത് പെട്ടെന്ന് അപകടകരമാണെന്ന് തോന്നുന്നില്ല.
    ///
    ///
    /// വിശദാംശങ്ങൾക്ക്, `NodeRef::reborrow_mut` കാണുക.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // ഞങ്ങളുടെ തരം അറിയാത്തതിനാൽ ഞങ്ങൾക്ക് Handle::new_kv അല്ലെങ്കിൽ Handle::new_edge ഉപയോഗിക്കാൻ കഴിയില്ല
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// `node`-ൽ ഒരു edge-ലേക്ക് ഒരു പുതിയ ഹാൻഡിൽ സൃഷ്ടിക്കുന്നു.
    /// സുരക്ഷിതമല്ലാത്തതിനാൽ കോളർ `idx <= node.len()` എന്ന് ഉറപ്പാക്കണം.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// ശേഷി നിറഞ്ഞ ഒരു നോഡിലേക്ക് ഉൾപ്പെടുത്താൻ ഞങ്ങൾ ആഗ്രഹിക്കുന്ന ഒരു edge സൂചിക നൽകിയാൽ, ഒരു സ്പ്ലിറ്റ് പോയിന്റിന്റെ വിവേകപൂർണ്ണമായ കെവി സൂചികയും എവിടെയാണ് ഉൾപ്പെടുത്തൽ കണക്കാക്കുന്നത്.
///
/// സ്പ്ലിറ്റ് പോയിന്റിന്റെ ലക്ഷ്യം അതിന്റെ കീയും മൂല്യവും ഒരു പാരന്റ് നോഡിൽ അവസാനിക്കുക എന്നതാണ്;
/// സ്പ്ലിറ്റ് പോയിന്റിന്റെ ഇടതുവശത്തുള്ള കീകളും മൂല്യങ്ങളും അരികുകളും ഇടത് കുട്ടിയായി മാറുന്നു;
/// സ്പ്ലിറ്റ് പോയിന്റിന്റെ വലതുവശത്തുള്ള കീകളും മൂല്യങ്ങളും അരികുകളും ശരിയായ കുട്ടിയാകുന്നു.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust ലക്കം #74834 ഈ സമമിതി നിയമങ്ങൾ വിശദീകരിക്കാൻ ശ്രമിക്കുന്നു.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// ഈ edge-ന്റെ വലത്തും ഇടത്തും കീ-മൂല്യ ജോഡികൾക്കിടയിൽ ഒരു പുതിയ കീ-മൂല്യ ജോഡി ചേർക്കുന്നു.
    /// പുതിയ ജോഡിക്ക് അനുയോജ്യമാകാൻ നോഡിൽ മതിയായ ഇടമുണ്ടെന്ന് ഈ രീതി അനുമാനിക്കുന്നു.
    ///
    /// നൽകിയ പോയിന്റർ ചേർത്ത മൂല്യത്തിലേക്ക് പോയിന്റുചെയ്യുന്നു.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// ഈ edge-ന്റെ വലത്തും ഇടത്തും കീ-മൂല്യ ജോഡികൾക്കിടയിൽ ഒരു പുതിയ കീ-മൂല്യ ജോഡി ചേർക്കുന്നു.
    /// മതിയായ ഇടമില്ലെങ്കിൽ ഈ രീതി നോഡിനെ വിഭജിക്കുന്നു.
    ///
    /// നൽകിയ പോയിന്റർ ചേർത്ത മൂല്യത്തിലേക്ക് പോയിന്റുചെയ്യുന്നു.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// ഈ edge ലിങ്കുചെയ്യുന്ന ചൈൽഡ് നോഡിലെ പാരന്റ് പോയിന്ററും സൂചികയും പരിഹരിക്കുന്നു.
    /// അരികുകളുടെ ക്രമം മാറ്റുമ്പോൾ ഇത് ഉപയോഗപ്രദമാകും,
    fn correct_parent_link(self) {
        // നോഡിലേക്കുള്ള മറ്റ് റഫറൻസുകൾ അസാധുവാക്കാതെ ബാക്ക്പോയിന്റർ സൃഷ്ടിക്കുക.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// ഒരു പുതിയ കീ-മൂല്യ ജോഡിയും ഒരു edge ഉം ചേർക്കുന്നു, അത് ഈ edge നും ഈ edge ന്റെ വലതുവശത്തുള്ള കീ-മൂല്യ ജോഡിക്കും ഇടയിലുള്ള പുതിയ ജോഡിയുടെ വലതുവശത്തേക്ക് പോകും.
    /// പുതിയ ജോഡിക്ക് അനുയോജ്യമാകാൻ നോഡിൽ മതിയായ ഇടമുണ്ടെന്ന് ഈ രീതി അനുമാനിക്കുന്നു.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// ഒരു പുതിയ കീ-മൂല്യ ജോഡിയും ഒരു edge ഉം ചേർക്കുന്നു, അത് ഈ edge നും ഈ edge ന്റെ വലതുവശത്തുള്ള കീ-മൂല്യ ജോഡിക്കും ഇടയിലുള്ള പുതിയ ജോഡിയുടെ വലതുവശത്തേക്ക് പോകും.
    /// മതിയായ ഇടമില്ലെങ്കിൽ ഈ രീതി നോഡിനെ വിഭജിക്കുന്നു.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// ഈ edge-ന്റെ വലത്തും ഇടത്തും കീ-മൂല്യ ജോഡികൾക്കിടയിൽ ഒരു പുതിയ കീ-മൂല്യ ജോഡി ചേർക്കുന്നു.
    /// മതിയായ ഇടമില്ലെങ്കിൽ ഈ രീതി നോഡിനെ വിഭജിക്കുന്നു, കൂടാതെ റൂട്ട് എത്തുന്നതുവരെ സ്പ്ലിറ്റ് ഓഫ് ഭാഗം പാരന്റ് നോഡിലേക്ക് ആവർത്തിച്ച് ചേർക്കാൻ ശ്രമിക്കുന്നു.
    ///
    ///
    /// നൽകിയ ഫലം ഒരു `Fit` ആണെങ്കിൽ, അതിന്റെ ഹാൻഡിൽ നോഡ് ഈ edge ന്റെ നോഡ് അല്ലെങ്കിൽ ഒരു പൂർവ്വികനാകാം.
    /// നൽകിയ ഫലം ഒരു `Split` ആണെങ്കിൽ, `left` ഫീൽഡ് റൂട്ട് നോഡ് ആയിരിക്കും.
    /// നൽകിയ പോയിന്റർ ചേർത്ത മൂല്യത്തിലേക്ക് പോയിന്റുചെയ്യുന്നു.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// ഈ edge ചൂണ്ടിക്കാണിച്ച നോഡ് കണ്ടെത്തുന്നു.
    ///
    /// മുകളിൽ റൂട്ട് നോഡ് ഉപയോഗിച്ച് മരങ്ങൾ ചിത്രീകരിക്കാമെന്ന് രീതി നാമം അനുമാനിക്കുന്നു.
    ///
    /// `edge.descend().ascend().unwrap()` `node.ascend().unwrap().descend()` രണ്ടും വിജയിച്ചാൽ ഒന്നും ചെയ്യരുത്.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // ഞങ്ങൾ നോഡുകളിലേക്ക് റോ പോയിന്ററുകൾ ഉപയോഗിക്കേണ്ടതുണ്ട്, കാരണം, ബോറോടൈപ്പ് marker::ValMut ആണെങ്കിൽ, ഞങ്ങൾ അസാധുവാക്കരുതാത്ത മൂല്യങ്ങളെക്കുറിച്ച് ശ്രദ്ധേയമായ മ്യൂട്ടബിൾ റഫറൻസുകൾ ഉണ്ടാകാം.
        // ഉയരം ഫീൽഡ് ആക്സസ് ചെയ്യുന്നതിൽ വിഷമമില്ല, കാരണം ആ മൂല്യം പകർത്തി.
        // നോഡ് പോയിന്റർ നിർ‌വ്വചിച്ചുകഴിഞ്ഞാൽ‌, ഞങ്ങൾ‌ഒരു റഫറൻ‌സ് (Rust ലക്കം #73987) ഉപയോഗിച്ച് അരികുകളുടെ അറേയിലേക്ക് പ്രവേശിക്കുകയും അറേയിലോ അകത്തോ ഉള്ള മറ്റേതെങ്കിലും റഫറൻ‌സുകൾ‌അസാധുവാക്കുകയും ചെയ്യുന്നുവെന്ന് ശ്രദ്ധിക്കുക.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // ഞങ്ങൾക്ക് പ്രത്യേക കീ, മൂല്യ രീതികൾ എന്ന് വിളിക്കാൻ കഴിയില്ല, കാരണം രണ്ടാമത്തേതിനെ വിളിക്കുന്നത് ആദ്യത്തേത് നൽകിയ റഫറൻസിനെ അസാധുവാക്കുന്നു.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// കെവി ഹാൻഡിൽ സൂചിപ്പിക്കുന്ന കീയും മൂല്യവും മാറ്റിസ്ഥാപിക്കുക.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// ഇല ഡാറ്റ പരിപാലിക്കുന്നതിലൂടെ ഒരു പ്രത്യേക `NodeType`-നായി `split` നടപ്പിലാക്കാൻ സഹായിക്കുന്നു.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// അന്തർലീനമായ നോഡിനെ മൂന്ന് ഭാഗങ്ങളായി വിഭജിക്കുന്നു:
    ///
    /// - ഈ ഹാൻഡിലിന്റെ ഇടതുവശത്തുള്ള കീ-മൂല്യ ജോഡികൾ മാത്രം ഉൾക്കൊള്ളുന്നതിനായി നോഡ് വെട്ടിച്ചുരുക്കിയിരിക്കുന്നു.
    /// - ഈ ഹാൻഡിൽ ചൂണ്ടിക്കാണിച്ച കീയും മൂല്യവും എക്‌സ്‌ട്രാക്റ്റുചെയ്യുന്നു.
    /// - ഈ ഹാൻഡിൽ വലതുവശത്തുള്ള എല്ലാ കീ-മൂല്യ ജോഡികളും പുതുതായി അനുവദിച്ച നോഡിലേക്ക് ഇടുന്നു.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// ഈ ഹാൻഡിൽ ചൂണ്ടിക്കാണിച്ച കീ-മൂല്യ ജോഡി നീക്കംചെയ്യുകയും കീ-മൂല്യ ജോഡി തകർന്ന edge-നൊപ്പം അത് തിരികെ നൽകുകയും ചെയ്യുന്നു.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// അന്തർലീനമായ നോഡിനെ മൂന്ന് ഭാഗങ്ങളായി വിഭജിക്കുന്നു:
    ///
    /// - ഈ ഹാൻഡിൽ ഇടതുവശത്തുള്ള അരികുകളും കീ-മൂല്യ ജോഡികളും മാത്രം ഉൾക്കൊള്ളുന്നതിനായി നോഡ് വെട്ടിച്ചുരുക്കിയിരിക്കുന്നു.
    /// - ഈ ഹാൻഡിൽ ചൂണ്ടിക്കാണിച്ച കീയും മൂല്യവും എക്‌സ്‌ട്രാക്റ്റുചെയ്യുന്നു.
    /// - ഈ ഹാൻഡിൽ വലതുവശത്തുള്ള എല്ലാ അരികുകളും കീ-മൂല്യ ജോഡികളും പുതുതായി അനുവദിച്ച നോഡിലേക്ക് ഇടുന്നു.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// ഒരു ആന്തരിക കീ-മൂല്യ ജോഡിക്ക് ചുറ്റും ഒരു ബാലൻസിംഗ് പ്രവർത്തനം വിലയിരുത്തുന്നതിനും നടപ്പിലാക്കുന്നതിനുമുള്ള ഒരു സെഷനെ പ്രതിനിധീകരിക്കുന്നു.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// കുട്ടിക്കാലത്ത് നോഡ് ഉൾപ്പെടുന്ന ഒരു ബാലൻസിംഗ് സന്ദർഭം തിരഞ്ഞെടുക്കുന്നു, അങ്ങനെ രക്ഷാകർതൃ നോഡിലെ കെ‌വിക്ക് ഇടത് അല്ലെങ്കിൽ വലത്തേക്ക്.
    /// രക്ഷകർത്താവ് ഇല്ലെങ്കിൽ ഒരു `Err` നൽകുന്നു.
    /// രക്ഷകർത്താവ് ശൂന്യമാണെങ്കിൽ Panics.
    ///
    /// തന്നിരിക്കുന്ന നോഡ് എങ്ങനെയെങ്കിലും അടിവരയില്ലാത്തതാണെങ്കിൽ ഒപ്റ്റിമൽ ആകാൻ ഇടത് വശത്തെ തിരഞ്ഞെടുക്കുന്നു, അതായത് ഇവിടെ ഇടത് സഹോദരനേക്കാളും വലത് സഹോദരനേക്കാളും കുറച്ച് ഘടകങ്ങൾ മാത്രമേ ഉള്ളൂ.
    /// അത്തരം സന്ദർഭങ്ങളിൽ, ഇടത് സഹോദരനുമായി ലയിപ്പിക്കുന്നത് വേഗതയേറിയതാണ്, കാരണം നമുക്ക് നോഡിന്റെ N ഘടകങ്ങൾ വലത്തേക്ക് മാറ്റുന്നതിനുപകരം മുന്നിലേക്ക് N ഘടകങ്ങളേക്കാൾ കൂടുതൽ നീക്കുന്നതിന് പകരം.
    /// ഇടത് സഹോദരനിൽ നിന്ന് മോഷ്ടിക്കുന്നതും സാധാരണ വേഗതയുള്ളതാണ്, കാരണം സഹോദരന്റെ മൂലകങ്ങളിൽ കുറഞ്ഞത് N ഇടത്തേക്ക് മാറ്റുന്നതിനുപകരം നോഡിന്റെ N ഘടകങ്ങൾ വലത്തേക്ക് മാറ്റേണ്ടതുണ്ട്.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// ലയിപ്പിക്കുന്നത് സാധ്യമാണോയെന്ന് നൽകുന്നു, അതായത്, കേന്ദ്ര കെവിയെ അടുത്തുള്ള രണ്ട് ചൈൽഡ് നോഡുകളുമായി സംയോജിപ്പിക്കാൻ ഒരു നോഡിൽ മതിയായ ഇടമുണ്ടോ എന്ന്.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// ഒരു ലയനം നടത്തുകയും എന്താണ് മടങ്ങേണ്ടതെന്ന് തീരുമാനിക്കാൻ ഒരു അടയ്ക്കൽ അനുവദിക്കുകയും ചെയ്യുന്നു.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // സുരക്ഷ: ലയിപ്പിക്കുന്ന നോഡുകളുടെ ഉയരം ഉയരത്തിന് താഴെയാണ്
                // ഈ edge ന്റെ നോഡിന്റെ, അങ്ങനെ പൂജ്യത്തിന് മുകളിലാണ്, അതിനാൽ അവ ആന്തരികമാണ്.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// രക്ഷകർത്താവിന്റെ കീ-മൂല്യ ജോഡിയും അടുത്തുള്ള ചൈൽഡ് നോഡുകളും ഇടത് ചൈൽഡ് നോഡിലേക്ക് ലയിപ്പിക്കുകയും ചുരുങ്ങിയ രക്ഷാകർതൃ നോഡ് തിരികെ നൽകുകയും ചെയ്യുന്നു.
    ///
    ///
    /// ഞങ്ങൾ `.can_merge()` ഇല്ലെങ്കിൽ Panics.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// രക്ഷകർത്താവിന്റെ കീ-മൂല്യ ജോഡിയും അടുത്തുള്ള ചൈൽഡ് നോഡുകളും ഇടത് ചൈൽഡ് നോഡിലേക്ക് ലയിപ്പിച്ച് ആ ചൈൽഡ് നോഡ് നൽകുന്നു.
    ///
    ///
    /// ഞങ്ങൾ `.can_merge()` ഇല്ലെങ്കിൽ Panics.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// രക്ഷകർത്താവിന്റെ കീ-മൂല്യ ജോഡിയും അടുത്തുള്ള രണ്ട് ചൈൽഡ് നോഡുകളും ഇടത് ചൈൽഡ് നോഡിലേക്ക് ലയിപ്പിക്കുകയും ട്രാക്കുചെയ്ത കുട്ടി edge അവസാനിച്ച ആ ചൈൽഡ് നോഡിലെ edge ഹാൻഡിൽ തിരികെ നൽകുകയും ചെയ്യുന്നു,
    ///
    ///
    /// ഞങ്ങൾ `.can_merge()` ഇല്ലെങ്കിൽ Panics.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// ഇടത് കുട്ടിയിൽ നിന്ന് ഒരു കീ-മൂല്യ ജോഡി നീക്കംചെയ്യുകയും അത് രക്ഷാകർതൃ കീ-മൂല്യ സംഭരണത്തിൽ സ്ഥാപിക്കുകയും അതേസമയം പഴയ രക്ഷാകർതൃ കീ-മൂല്യ ജോഡിയെ ശരിയായ കുട്ടിയിലേക്ക് തള്ളിവിടുകയും ചെയ്യുന്നു.
    ///
    /// `track_right_edge_idx` വ്യക്തമാക്കിയ യഥാർത്ഥ edge അവസാനിച്ച സ്ഥലത്തിന് അനുയോജ്യമായ വലത് കുട്ടിയിലെ edge ലേക്ക് ഒരു ഹാൻഡിൽ നൽകുന്നു.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// വലത് കുട്ടിയിൽ നിന്ന് ഒരു കീ-മൂല്യ ജോഡി നീക്കംചെയ്യുകയും അത് രക്ഷാകർതൃ കീ-മൂല്യ സംഭരണത്തിൽ സ്ഥാപിക്കുകയും ചെയ്യുന്നു, അതേസമയം പഴയ രക്ഷാകർതൃ കീ-മൂല്യ ജോഡി ഇടത് കുട്ടിയിലേക്ക് നീക്കുന്നു.
    ///
    /// `track_left_edge_idx` വ്യക്തമാക്കിയ ഇടത് കുട്ടിയിലെ edge ലേക്ക് ഒരു ഹാൻഡിൽ നൽകുന്നു, അത് അനങ്ങുന്നില്ല.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// ഇത് `steal_left` ന് സമാനമായ മോഷ്ടിക്കുന്നുണ്ടെങ്കിലും ഒന്നിലധികം ഘടകങ്ങൾ ഒരേസമയം മോഷ്ടിക്കുന്നു.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // ഞങ്ങൾ സുരക്ഷിതമായി മോഷ്ടിച്ചേക്കാമെന്ന് ഉറപ്പാക്കുക.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // ഇല ഡാറ്റ നീക്കുക.
            {
                // ശരിയായ കുട്ടിയിൽ മോഷ്ടിച്ച ഘടകങ്ങൾക്ക് ഇടം നൽകുക.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // ഘടകങ്ങൾ ഇടത് കുട്ടിയിൽ നിന്ന് വലത്തേക്ക് നീക്കുക.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // ഏറ്റവും മോഷ്ടിച്ച ഇടത് ജോഡി മാതാപിതാക്കളിലേക്ക് നീക്കുക.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // രക്ഷകർത്താവിന്റെ കീ-മൂല്യ ജോഡി ശരിയായ കുട്ടിയിലേക്ക് നീക്കുക.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // മോഷ്ടിച്ച അരികുകൾക്ക് ഇടം നൽകുക.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // അരികുകൾ മോഷ്ടിക്കുക.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// `bulk_steal_left`-ന്റെ സമമിതി ക്ലോൺ.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // ഞങ്ങൾ സുരക്ഷിതമായി മോഷ്ടിച്ചേക്കാമെന്ന് ഉറപ്പാക്കുക.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // ഇല ഡാറ്റ നീക്കുക.
            {
                // ഏറ്റവും മോഷ്ടിച്ച ജോഡി മാതാപിതാക്കളിലേക്ക് നീക്കുക.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // മാതാപിതാക്കളുടെ കീ-മൂല്യ ജോഡി ഇടത് കുട്ടിയിലേക്ക് നീക്കുക.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // ഘടകങ്ങൾ വലത് കുട്ടിയിൽ നിന്ന് ഇടത്തേക്ക് നീക്കുക.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // മോഷ്ടിച്ച ഘടകങ്ങൾ ഉപയോഗിച്ചിരുന്ന വിടവ് നികത്തുക.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // അരികുകൾ മോഷ്ടിക്കുക.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // മോഷ്ടിച്ച അരികുകൾ ഉപയോഗിച്ചിരുന്ന വിടവ് നികത്തുക.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// ഈ നോഡ് ഒരു `Leaf` നോഡാണെന്ന് അവകാശപ്പെടുന്ന ഏതെങ്കിലും സ്റ്റാറ്റിക് വിവരങ്ങൾ നീക്കംചെയ്യുന്നു.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// ഈ നോഡ് ഒരു `Internal` നോഡാണെന്ന് അവകാശപ്പെടുന്ന ഏതെങ്കിലും സ്റ്റാറ്റിക് വിവരങ്ങൾ നീക്കംചെയ്യുന്നു.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// അന്തർലീനമായ നോഡ് ഒരു `Internal` നോഡാണോ അതോ `Leaf` നോഡാണോ എന്ന് പരിശോധിക്കുന്നു.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// `self` ന് ശേഷം സഫിക്‌സ് ഒരു നോഡിൽ നിന്ന് മറ്റൊന്നിലേക്ക് നീക്കുക.`right` ശൂന്യമായിരിക്കണം.
    /// `right`-ന്റെ ആദ്യ edge മാറ്റമില്ലാതെ തുടരുന്നു.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// ഉൾപ്പെടുത്തലിന്റെ ഫലം, ഒരു നോഡിന് അതിന്റെ ശേഷിക്കപ്പുറം വികസിപ്പിക്കാൻ ആവശ്യമുള്ളപ്പോൾ.
pub struct SplitResult<'a, K, V, NodeType> {
    // `kv`-ന്റെ ഇടതുവശത്തുള്ള ഘടകങ്ങളും അരികുകളും ഉള്ള നിലവിലുള്ള ട്രീയിൽ മാറ്റം വരുത്തിയ നോഡ്.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // മറ്റെവിടെയെങ്കിലും ഉൾപ്പെടുത്തുന്നതിന് ചില കീയും മൂല്യവും വിഭജിച്ചിരിക്കുന്നു.
    pub kv: (K, V),
    // `kv`-ന്റെ വലതുവശത്തുള്ള ഘടകങ്ങളും അരികുകളുമുള്ള ഉടമസ്ഥതയിലുള്ള, അറ്റാച്ചുചെയ്യാത്ത, പുതിയ നോഡ്.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // ഈ കടം തരത്തിന്റെ നോഡ് റഫറൻസുകൾ ട്രീയിലെ മറ്റ് നോഡുകളിലേക്ക് പോകാൻ അനുവദിക്കുന്നുണ്ടോ.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // ട്രാവെർസൽ ആവശ്യമില്ല, ഇത് സംഭവിക്കുന്നത് `borrow_mut` ന്റെ ഫലം ഉപയോഗിച്ചാണ്.
        // ട്രാവെർസൽ അപ്രാപ്തമാക്കുന്നതിലൂടെയും വേരുകളിലേക്ക് പുതിയ റഫറൻസുകൾ സൃഷ്ടിക്കുന്നതിലൂടെയും, `Owned` തരത്തിന്റെ എല്ലാ റഫറൻസുകളും ഒരു റൂട്ട് നോഡിലാണെന്ന് ഞങ്ങൾക്കറിയാം.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// സമാരംഭിച്ച ഘടകങ്ങളുടെ ഒരു സ്ലൈസിലേക്ക് ഒരു മൂല്യം ചേർക്കുന്നു, തുടർന്ന് ആരംഭിക്കാത്ത ഒരു ഘടകം.
///
/// # Safety
/// സ്ലൈസിന് `idx`-ൽ കൂടുതൽ ഘടകങ്ങളുണ്ട്.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// സമാരംഭിച്ച എല്ലാ ഘടകങ്ങളുടെയും ഒരു സ്ലൈസിൽ നിന്ന് ഒരു മൂല്യം നീക്കംചെയ്യുകയും തിരികെ നൽകുകയും ചെയ്യുന്നു, ഇത് ആരംഭിക്കാത്ത ഒരു ഘടകത്തെ പിന്നിലാക്കുന്നു.
///
///
/// # Safety
/// സ്ലൈസിന് `idx`-ൽ കൂടുതൽ ഘടകങ്ങളുണ്ട്.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// ഒരു സ്ലൈസ് `distance` സ്ഥാനങ്ങളിലെ ഘടകങ്ങൾ ഇടത്തേക്ക് മാറ്റുന്നു.
///
/// # Safety
/// സ്ലൈസിന് കുറഞ്ഞത് `distance` ഘടകങ്ങളെങ്കിലും ഉണ്ട്.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// ഒരു സ്ലൈസ് `distance` സ്ഥാനങ്ങളിലെ ഘടകങ്ങൾ വലത്തേക്ക് മാറ്റുന്നു.
///
/// # Safety
/// സ്ലൈസിന് കുറഞ്ഞത് `distance` ഘടകങ്ങളെങ്കിലും ഉണ്ട്.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// എല്ലാ മൂല്യങ്ങളും സമാരംഭിച്ച മൂലകങ്ങളുടെ ഒരു സ്ലൈസിൽ നിന്ന് ആരംഭിക്കാത്ത ഘടകങ്ങളുടെ ഒരു സ്ലൈസിലേക്ക് നീക്കുന്നു, `src` എല്ലാം ആരംഭിക്കാത്തവയായി അവശേഷിക്കുന്നു.
///
/// `dst.copy_from_slice(src)` പോലെ പ്രവർത്തിക്കുന്നു, പക്ഷേ `T` `Copy` ആകാൻ ആവശ്യമില്ല.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;