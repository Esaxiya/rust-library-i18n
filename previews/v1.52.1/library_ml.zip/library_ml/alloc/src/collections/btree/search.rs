use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// `Bound::Included(T)` പോലെ തന്നെ തിരയാനുള്ള ഒരു പരിധി.
    Included(T),
    /// `Bound::Excluded(T)` പോലെ തന്നെ തിരയാനുള്ള എക്‌സ്‌ക്ലൂസീവ് ബൗണ്ട്.
    Excluded(T),
    /// `Bound::Unbounded` പോലെ നിരുപാധികമായ ഉൾപ്പെടുത്തൽ പരിധി.
    AllIncluded,
    /// ഉപാധികളില്ലാത്ത എക്സ്ക്ലൂസീവ് പരിധി.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// നോഡ് നയിക്കുന്ന ഒരു (ഉപ) ട്രീയിൽ നൽകിയ കീ ആവർത്തിച്ച് നോക്കുന്നു.
    /// പൊരുത്തപ്പെടുന്ന കെവിയുടെ ഹാൻഡിൽ എന്തെങ്കിലും ഉണ്ടെങ്കിൽ ഒരു `Found` നൽകുന്നു.
    /// അല്ലെങ്കിൽ, കീ ഉൾപ്പെടുന്ന edge ഇലയുടെ ഹാൻഡിൽ ഉപയോഗിച്ച് ഒരു `GoDown` നൽകുന്നു.
    ///
    /// ഒരു `BTreeMap`-ലെ ട്രീ പോലെ വൃക്ഷം കീ ഉപയോഗിച്ച് ക്രമീകരിച്ചിട്ടുണ്ടെങ്കിൽ മാത്രമേ ഫലം അർത്ഥമുള്ളൂ.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// ശ്രേണിയുടെ താഴത്തെ അതിർത്തിയുമായി പൊരുത്തപ്പെടുന്ന edge മുകളിലെ അതിർത്തിയുമായി പൊരുത്തപ്പെടുന്ന edge-ൽ നിന്ന് വ്യത്യസ്‌തമായ ഏറ്റവും അടുത്തുള്ള നോഡിലേക്ക് ഇറങ്ങുന്നു, അതായത്, ശ്രേണിയിൽ കുറഞ്ഞത് ഒരു കീയെങ്കിലും അടങ്ങിയിരിക്കുന്ന ഏറ്റവും അടുത്തുള്ള നോഡ്.
    ///
    ///
    /// കണ്ടെത്തിയാൽ, ആ നോഡിനൊപ്പം ഒരു `Ok`, ശ്രേണിയിലെ ഡിലിമിറ്റ് ചെയ്യുന്ന edge സൂചികകൾ, ചൈൽഡ് നോഡുകളിൽ തിരയൽ തുടരുന്നതിന് അനുബന്ധ ജോഡി അതിരുകൾ എന്നിവ നൽകുന്നു, നോഡ് ആന്തരികമാണെങ്കിൽ.
    ///
    /// കണ്ടെത്തിയില്ലെങ്കിൽ, edge ഇല മുഴുവൻ ശ്രേണിയുമായി പൊരുത്തപ്പെടുന്ന ഒരു `Err` നൽകുന്നു.
    ///
    /// വൃക്ഷം കീ ഉപയോഗിച്ച് ക്രമപ്പെടുത്തിയാൽ മാത്രമേ ഫലം അർത്ഥമുള്ളൂ.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // ഈ വേരിയബിളുകൾ‌ഇൻ‌ലൈൻ‌ചെയ്യുന്നത് ഒഴിവാക്കണം.
        // `range` റിപ്പോർട്ടുചെയ്ത അതിരുകൾ അതേപടി നിലനിൽക്കുമെന്ന് ഞങ്ങൾ അനുമാനിക്കുന്നു, പക്ഷേ (#81138) കോളുകൾക്കിടയിൽ ഒരു പ്രതികൂല നടപ്പാക്കൽ മാറാം.
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// ഒരു ശ്രേണിയുടെ താഴത്തെ പരിധി വേർതിരിക്കുന്ന നോഡിൽ ഒരു edge കണ്ടെത്തുന്നു.
    /// `self` ഒരു ആന്തരിക നോഡാണെങ്കിൽ, പൊരുത്തപ്പെടുന്ന ചൈൽഡ് നോഡിലെ തിരയൽ തുടരുന്നതിന് ഉപയോഗിക്കേണ്ട താഴ്ന്ന പരിധി നൽകുന്നു.
    ///
    ///
    /// വൃക്ഷം കീ ഉപയോഗിച്ച് ക്രമപ്പെടുത്തിയാൽ മാത്രമേ ഫലം അർത്ഥമുള്ളൂ.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// മുകളിലെ അതിർത്തിക്കായി `find_lower_bound_edge` ന്റെ ക്ലോൺ.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// ആവർത്തനമില്ലാതെ, നോഡിൽ നൽകിയിരിക്കുന്ന ഒരു കീ തിരയുന്നു.
    /// പൊരുത്തപ്പെടുന്ന കെവിയുടെ ഹാൻഡിൽ എന്തെങ്കിലും ഉണ്ടെങ്കിൽ ഒരു `Found` നൽകുന്നു.
    /// അല്ലെങ്കിൽ, കീ കണ്ടെത്തിയേക്കാവുന്ന (നോഡ് ആന്തരികമാണെങ്കിൽ) അല്ലെങ്കിൽ കീ ഉൾപ്പെടുത്താൻ കഴിയുന്ന edge ന്റെ ഹാൻഡിൽ ഉപയോഗിച്ച് ഒരു `GoDown` നൽകുന്നു.
    ///
    ///
    /// ഒരു `BTreeMap`-ലെ ട്രീ പോലെ വൃക്ഷം കീ ഉപയോഗിച്ച് ക്രമീകരിച്ചിട്ടുണ്ടെങ്കിൽ മാത്രമേ ഫലം അർത്ഥമുള്ളൂ.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// കീ (അല്ലെങ്കിൽ തത്തുല്യമായത്) നിലനിൽക്കുന്ന നോഡിലെ കെവി സൂചിക അല്ലെങ്കിൽ കീ ഉൾപ്പെടുന്ന edge സൂചിക നൽകുന്നു.
    ///
    ///
    /// ഒരു `BTreeMap`-ലെ ട്രീ പോലെ വൃക്ഷം കീ ഉപയോഗിച്ച് ക്രമീകരിച്ചിട്ടുണ്ടെങ്കിൽ മാത്രമേ ഫലം അർത്ഥമുള്ളൂ.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// ഒരു ശ്രേണിയുടെ താഴത്തെ പരിധി നിർണ്ണയിക്കുന്ന നോഡിൽ ഒരു edge സൂചിക കണ്ടെത്തുന്നു.
    /// `self` ഒരു ആന്തരിക നോഡാണെങ്കിൽ, പൊരുത്തപ്പെടുന്ന ചൈൽഡ് നോഡിലെ തിരയൽ തുടരുന്നതിന് ഉപയോഗിക്കേണ്ട താഴ്ന്ന പരിധി നൽകുന്നു.
    ///
    ///
    /// വൃക്ഷം കീ ഉപയോഗിച്ച് ക്രമപ്പെടുത്തിയാൽ മാത്രമേ ഫലം അർത്ഥമുള്ളൂ.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// മുകളിലെ അതിർത്തിക്കായി `find_lower_bound_index` ന്റെ ക്ലോൺ.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}