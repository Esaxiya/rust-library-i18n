// ട്രീമാപ്പിൽ നിന്ന് സമാനമായ ഒരു ഇന്റർഫേസ് ബിട്രീമാപ്പിന് ഉള്ളതിനാൽ ഇത് ട്രീസെറ്റിൽ നിന്ന് പൂർണ്ണമായും മോഷ്ടിക്കപ്പെട്ടു
//

use core::borrow::Borrow;
use core::cmp::Ordering::{Equal, Greater, Less};
use core::cmp::{max, min};
use core::fmt::{self, Debug};
use core::iter::{FromIterator, FusedIterator, Peekable};
use core::ops::{BitAnd, BitOr, BitXor, RangeBounds, Sub};

use super::map::{BTreeMap, Keys};
use super::merge_iter::MergeIterInner;
use super::Recover;

// FIXME(conventions): ബൗണ്ടഡ് ഇറ്ററേറ്ററുകൾ നടപ്പിലാക്കുക

/// ഒരു ബി-ട്രീ അടിസ്ഥാനമാക്കിയുള്ള ഒരു സെറ്റ്.
///
/// ഈ ശേഖരത്തിന്റെ പ്രകടന നേട്ടങ്ങളെയും പോരായ്മകളെയും കുറിച്ചുള്ള വിശദമായ ചർച്ചയ്ക്ക് [`BTreeMap`] ന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// [`Ord`] trait നിർ‌ണ്ണയിച്ച പ്രകാരം, മറ്റേതൊരു ഇനവുമായും താരതമ്യപ്പെടുത്തുമ്പോൾ ഇനത്തിന്റെ ക്രമം സെറ്റിലായിരിക്കുമ്പോൾ മാറുന്ന തരത്തിൽ ഒരു ഇനം പരിഷ്‌ക്കരിക്കുന്നത് ഒരു ലോജിക് പിശകാണ്.
///
/// ഇത് സാധാരണയായി [`Cell`], [`RefCell`], ഗ്ലോബൽ സ്റ്റേറ്റ്, I/O അല്ലെങ്കിൽ സുരക്ഷിതമല്ലാത്ത കോഡ് വഴി മാത്രമേ സാധ്യമാകൂ.
/// അത്തരമൊരു ലോജിക് പിശകിന്റെ ഫലമായുണ്ടായ സ്വഭാവം വ്യക്തമാക്കിയിട്ടില്ല, പക്ഷേ നിർവചിക്കപ്പെടാത്ത പെരുമാറ്റത്തിന് കാരണമാകില്ല.
/// ഇതിൽ panics, തെറ്റായ ഫലങ്ങൾ, നിർത്തലാക്കൽ, മെമ്മറി ലീക്കുകൾ, അവസാനിപ്പിക്കാത്തത് എന്നിവ ഉൾപ്പെടാം.
///
/// [`Ord`]: core::cmp::Ord
/// [`Cell`]: core::cell::Cell
/// [`RefCell`]: core::cell::RefCell
///
/// # Examples
///
/// ```
/// use std::collections::BTreeSet;
///
/// // ടൈപ്പ് ഇൻ‌ഫെൻ‌ഷൻ‌ഒരു സ്പഷ്ടമായ ടൈപ്പ് സിഗ്‌നേച്ചർ‌ഒഴിവാക്കാൻ‌ഞങ്ങളെ അനുവദിക്കുന്നു (ഇത് ഈ ഉദാഹരണത്തിൽ‌`BTreeSet<&str>` ആയിരിക്കും).
/////
/// let mut books = BTreeSet::new();
///
/// // കുറച്ച് പുസ്തകങ്ങൾ ചേർക്കുക.
/// books.insert("A Dance With Dragons");
/// books.insert("To Kill a Mockingbird");
/// books.insert("The Odyssey");
/// books.insert("The Great Gatsby");
///
/// // നിർദ്ദിഷ്ട ഒരെണ്ണം പരിശോധിക്കുക.
/// if !books.contains("The Winds of Winter") {
///     println!("We have {} books, but The Winds of Winter ain't one.",
///              books.len());
/// }
///
/// // ഒരു പുസ്തകം നീക്കംചെയ്യുക.
/// books.remove("The Odyssey");
///
/// // എല്ലാത്തിനും മീതെ സംസാരിക്കുക.
/// for book in &books {
///     println!("{}", book);
/// }
/// ```
///
///
#[derive(Hash, PartialEq, Eq, Ord, PartialOrd)]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BTreeSet")]
pub struct BTreeSet<T> {
    map: BTreeMap<T, ()>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BTreeSet<T> {
    fn clone(&self) -> Self {
        BTreeSet { map: self.map.clone() }
    }

    fn clone_from(&mut self, other: &Self) {
        self.map.clone_from(&other.map);
    }
}

/// ഒരു `BTreeSet` ന്റെ ഇനങ്ങൾ‌ക്ക് മുകളിലുള്ള ഒരു ആവർത്തനം.
///
/// [`BTreeSet`]-ലെ [`iter`] രീതി ഉപയോഗിച്ചാണ് ഈ `struct` സൃഷ്ടിച്ചിരിക്കുന്നത്.
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// [`iter`]: BTreeSet::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: Keys<'a, T, ()>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.clone()).finish()
    }
}

/// ഒരു `BTreeSet`-ന്റെ ഇനങ്ങളിൽ സ്വന്തമായി ഒരു ഇറ്ററേറ്റർ.
///
/// [`BTreeSet`]-ലെ [`into_iter`] രീതി ഉപയോഗിച്ചാണ് ഈ `struct` സൃഷ്ടിച്ചിരിക്കുന്നത് (`IntoIterator` trait നൽകിയതാണ്).
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// [`into_iter`]: BTreeSet#method.into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IntoIter<T> {
    iter: super::map::IntoIter<T, ()>,
}

/// ഒരു `BTreeSet`-ലെ ഉപ-ശ്രേണിയിലുള്ള ഇനങ്ങളുടെ ഒരു ഇറ്ററേറ്റർ.
///
/// [`BTreeSet`]-ലെ [`range`] രീതി ഉപയോഗിച്ചാണ് ഈ `struct` സൃഷ്ടിച്ചിരിക്കുന്നത്.
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// [`range`]: BTreeSet::range
#[derive(Debug)]
#[stable(feature = "btree_range", since = "1.17.0")]
pub struct Range<'a, T: 'a> {
    iter: super::map::Range<'a, T, ()>,
}

/// `BTreeSet`-ന്റെ വ്യത്യാസത്തിൽ ഘടകങ്ങൾ നിർമ്മിക്കുന്ന ഒരു അലസമായ ആവർത്തനം.
///
/// [`BTreeSet`]-ലെ [`difference`] രീതി ഉപയോഗിച്ചാണ് ഈ `struct` സൃഷ്ടിച്ചിരിക്കുന്നത്.
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// [`difference`]: BTreeSet::difference
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Difference<'a, T: 'a> {
    inner: DifferenceInner<'a, T>,
}
#[derive(Debug)]
enum DifferenceInner<'a, T: 'a> {
    Stitch {
        // എല്ലാ `self` ഉം ചില `other` ഉം ആവർത്തിക്കുക, വഴിയിൽ പൊരുത്തങ്ങൾ കണ്ടെത്തുക
        self_iter: Iter<'a, T>,
        other_iter: Peekable<Iter<'a, T>>,
    },
    Search {
        // `self` ആവർത്തിക്കുക, `other`-ൽ നോക്കുക
        self_iter: Iter<'a, T>,
        other_set: &'a BTreeSet<T>,
    },
    Iterate(Iter<'a, T>), // simply produce all values in `self`
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Difference<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Difference").field(&self.inner).finish()
    }
}

/// `BTreeSet`-ന്റെ സമമിതി വ്യത്യാസത്തിൽ ഘടകങ്ങൾ നിർമ്മിക്കുന്ന ഒരു അലസമായ ആവർത്തനം.
///
/// [`BTreeSet`]-ലെ [`symmetric_difference`] രീതി ഉപയോഗിച്ചാണ് ഈ `struct` സൃഷ്ടിച്ചിരിക്കുന്നത്.
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// [`symmetric_difference`]: BTreeSet::symmetric_difference
#[stable(feature = "rust1", since = "1.0.0")]
pub struct SymmetricDifference<'a, T: 'a>(MergeIterInner<Iter<'a, T>>);

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for SymmetricDifference<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("SymmetricDifference").field(&self.0).finish()
    }
}

/// `BTreeSet`-ന്റെ കവലയിൽ ഘടകങ്ങൾ നിർമ്മിക്കുന്ന അലസനായ ഒരു ആവർത്തനം.
///
/// [`BTreeSet`]-ലെ [`intersection`] രീതി ഉപയോഗിച്ചാണ് ഈ `struct` സൃഷ്ടിച്ചിരിക്കുന്നത്.
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// [`intersection`]: BTreeSet::intersection
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Intersection<'a, T: 'a> {
    inner: IntersectionInner<'a, T>,
}
#[derive(Debug)]
enum IntersectionInner<'a, T: 'a> {
    Stitch {
        // സമാന വലുപ്പത്തിലുള്ള സെറ്റുകൾ സംയുക്തമായി ആവർത്തിക്കുക, വഴിയിൽ പൊരുത്തങ്ങൾ കണ്ടെത്തുക
        a: Iter<'a, T>,
        b: Iter<'a, T>,
    },
    Search {
        // ഒരു ചെറിയ സെറ്റ് ആവർത്തിക്കുക, വലിയ സെറ്റിൽ നോക്കുക
        small_iter: Iter<'a, T>,
        large_set: &'a BTreeSet<T>,
    },
    Answer(Option<&'a T>), // return a specific value or emptiness
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Intersection<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Intersection").field(&self.inner).finish()
    }
}

/// `BTreeSet`-ന്റെ യൂണിയനിൽ‌ഘടകങ്ങൾ‌ഉൽ‌പാദിപ്പിക്കുന്ന ഒരു അലസമായ ആവർത്തനം.
///
/// [`BTreeSet`]-ലെ [`union`] രീതി ഉപയോഗിച്ചാണ് ഈ `struct` സൃഷ്ടിച്ചിരിക്കുന്നത്.
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// [`union`]: BTreeSet::union
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Union<'a, T: 'a>(MergeIterInner<Iter<'a, T>>);

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Union<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Union").field(&self.0).finish()
    }
}

// രണ്ട് സെറ്റുകൾ താരതമ്യം ചെയ്യുന്ന ഫംഗ്ഷനുകളാണ് ഈ സ്ഥിരാങ്കം ഉപയോഗിക്കുന്നത്.
// https://github.com/ssomers/rust_bench_btreeset_intersection-ലെ ബെഞ്ച്മാർക്കുകളെ അടിസ്ഥാനമാക്കി തിരയൽ ആവർത്തനത്തേക്കാൾ മികച്ച പ്രകടനം കാഴ്ചവയ്ക്കുന്ന ആപേക്ഷിക വലുപ്പത്തെ ഇത് കണക്കാക്കുന്നു.
//
// വലുപ്പങ്ങൾ ഗുണിക്കുന്നതിനേക്കാൾ വിഭജിക്കാനും ഓവർഫ്ലോ നിരസിക്കാനും ഇത് ഉപയോഗിക്കുന്നു, ആ വിഭജനം വിലകുറഞ്ഞതാക്കാൻ ഇത് രണ്ട് ശക്തിയാണ്.
//
//
const ITER_PERFORMANCE_TIPPING_SIZE_DIFF: usize = 16;

impl<T> BTreeSet<T> {
    /// പുതിയതും ശൂന്യവുമായ `BTreeSet` നിർമ്മിക്കുന്നു.
    ///
    /// സ്വന്തമായി ഒന്നും അനുവദിക്കുന്നില്ല.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// use std::collections::BTreeSet;
    ///
    /// let mut set: BTreeSet<i32> = BTreeSet::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_btree_new", issue = "71835")]
    pub const fn new() -> BTreeSet<T>
    where
        T: Ord,
    {
        BTreeSet { map: BTreeMap::new() }
    }

    /// സെറ്റിലെ ഘടകങ്ങളുടെ ഉപ-ശ്രേണിയിൽ ഇരട്ട-എൻഡ് ഇറ്ററേറ്റർ നിർമ്മിക്കുന്നു.
    /// `min..max` ശ്രേണി സിന്റാക്സ് ഉപയോഗിക്കുന്നതാണ് ഏറ്റവും ലളിതമായ മാർഗം, അതിനാൽ `range(min..max)` മിനിറ്റ് (inclusive) മുതൽ പരമാവധി (exclusive) വരെയുള്ള ഘടകങ്ങൾ നൽകും.
    /// ശ്രേണി `(Bound<T>, Bound<T>)` എന്നും നൽകാം, അതിനാൽ `range((Excluded(4), Included(10)))` 4 മുതൽ 10 വരെ ഇടത്-എക്സ്ക്ലൂസീവ്, വലത് ഉൾക്കൊള്ളുന്ന ശ്രേണി നൽകും.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeSet;
    /// use std::ops::Bound::Included;
    ///
    /// let mut set = BTreeSet::new();
    /// set.insert(3);
    /// set.insert(5);
    /// set.insert(8);
    /// for &elem in set.range((Included(&4), Included(&8))) {
    ///     println!("{}", elem);
    /// }
    /// assert_eq!(Some(&5), set.range(4..).next());
    /// ```
    ///
    ///
    #[stable(feature = "btree_range", since = "1.17.0")]
    pub fn range<K: ?Sized, R>(&self, range: R) -> Range<'_, T>
    where
        K: Ord,
        T: Borrow<K> + Ord,
        R: RangeBounds<K>,
    {
        Range { iter: self.map.range(range) }
    }

    /// വ്യത്യാസത്തെ പ്രതിനിധീകരിക്കുന്ന മൂല്യങ്ങൾ സന്ദർശിക്കുന്നു, അതായത്, `self`-ൽ ഉള്ളതും എന്നാൽ `other`-ൽ അല്ലാത്തതുമായ മൂല്യങ്ങൾ ആരോഹണ ക്രമത്തിൽ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeSet;
    ///
    /// let mut a = BTreeSet::new();
    /// a.insert(1);
    /// a.insert(2);
    ///
    /// let mut b = BTreeSet::new();
    /// b.insert(2);
    /// b.insert(3);
    ///
    /// let diff: Vec<_> = a.difference(&b).cloned().collect();
    /// assert_eq!(diff, [1]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn difference<'a>(&'a self, other: &'a BTreeSet<T>) -> Difference<'a, T>
    where
        T: Ord,
    {
        let (self_min, self_max) =
            if let (Some(self_min), Some(self_max)) = (self.first(), self.last()) {
                (self_min, self_max)
            } else {
                return Difference { inner: DifferenceInner::Iterate(self.iter()) };
            };
        let (other_min, other_max) =
            if let (Some(other_min), Some(other_max)) = (other.first(), other.last()) {
                (other_min, other_max)
            } else {
                return Difference { inner: DifferenceInner::Iterate(self.iter()) };
            };
        Difference {
            inner: match (self_min.cmp(other_max), self_max.cmp(other_min)) {
                (Greater, _) | (_, Less) => DifferenceInner::Iterate(self.iter()),
                (Equal, _) => {
                    let mut self_iter = self.iter();
                    self_iter.next();
                    DifferenceInner::Iterate(self_iter)
                }
                (_, Equal) => {
                    let mut self_iter = self.iter();
                    self_iter.next_back();
                    DifferenceInner::Iterate(self_iter)
                }
                _ if self.len() <= other.len() / ITER_PERFORMANCE_TIPPING_SIZE_DIFF => {
                    DifferenceInner::Search { self_iter: self.iter(), other_set: other }
                }
                _ => DifferenceInner::Stitch {
                    self_iter: self.iter(),
                    other_iter: other.iter().peekable(),
                },
            },
        }
    }

    /// സമമിതി വ്യത്യാസത്തെ പ്രതിനിധീകരിക്കുന്ന മൂല്യങ്ങൾ സന്ദർശിക്കുന്നു, അതായത്, `self` അല്ലെങ്കിൽ `other`-ൽ ഉള്ള മൂല്യങ്ങൾ, എന്നാൽ രണ്ടിലും അല്ല, ആരോഹണ ക്രമത്തിൽ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeSet;
    ///
    /// let mut a = BTreeSet::new();
    /// a.insert(1);
    /// a.insert(2);
    ///
    /// let mut b = BTreeSet::new();
    /// b.insert(2);
    /// b.insert(3);
    ///
    /// let sym_diff: Vec<_> = a.symmetric_difference(&b).cloned().collect();
    /// assert_eq!(sym_diff, [1, 3]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn symmetric_difference<'a>(&'a self, other: &'a BTreeSet<T>) -> SymmetricDifference<'a, T>
    where
        T: Ord,
    {
        SymmetricDifference(MergeIterInner::new(self.iter(), other.iter()))
    }

    /// കവലയെ പ്രതിനിധീകരിക്കുന്ന മൂല്യങ്ങൾ സന്ദർശിക്കുന്നു, അതായത്, `self`, `other` എന്നിവയിൽ ഉള്ള മൂല്യങ്ങൾ ആരോഹണ ക്രമത്തിൽ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeSet;
    ///
    /// let mut a = BTreeSet::new();
    /// a.insert(1);
    /// a.insert(2);
    ///
    /// let mut b = BTreeSet::new();
    /// b.insert(2);
    /// b.insert(3);
    ///
    /// let intersection: Vec<_> = a.intersection(&b).cloned().collect();
    /// assert_eq!(intersection, [2]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn intersection<'a>(&'a self, other: &'a BTreeSet<T>) -> Intersection<'a, T>
    where
        T: Ord,
    {
        let (self_min, self_max) =
            if let (Some(self_min), Some(self_max)) = (self.first(), self.last()) {
                (self_min, self_max)
            } else {
                return Intersection { inner: IntersectionInner::Answer(None) };
            };
        let (other_min, other_max) =
            if let (Some(other_min), Some(other_max)) = (other.first(), other.last()) {
                (other_min, other_max)
            } else {
                return Intersection { inner: IntersectionInner::Answer(None) };
            };
        Intersection {
            inner: match (self_min.cmp(other_max), self_max.cmp(other_min)) {
                (Greater, _) | (_, Less) => IntersectionInner::Answer(None),
                (Equal, _) => IntersectionInner::Answer(Some(self_min)),
                (_, Equal) => IntersectionInner::Answer(Some(self_max)),
                _ if self.len() <= other.len() / ITER_PERFORMANCE_TIPPING_SIZE_DIFF => {
                    IntersectionInner::Search { small_iter: self.iter(), large_set: other }
                }
                _ if other.len() <= self.len() / ITER_PERFORMANCE_TIPPING_SIZE_DIFF => {
                    IntersectionInner::Search { small_iter: other.iter(), large_set: self }
                }
                _ => IntersectionInner::Stitch { a: self.iter(), b: other.iter() },
            },
        }
    }

    /// യൂണിയനെ പ്രതിനിധീകരിക്കുന്ന മൂല്യങ്ങൾ സന്ദർശിക്കുന്നു, അതായത്, `self` അല്ലെങ്കിൽ `other` ലെ എല്ലാ മൂല്യങ്ങളും, തനിപ്പകർപ്പുകളില്ലാതെ, ആരോഹണ ക്രമത്തിൽ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeSet;
    ///
    /// let mut a = BTreeSet::new();
    /// a.insert(1);
    ///
    /// let mut b = BTreeSet::new();
    /// b.insert(2);
    ///
    /// let union: Vec<_> = a.union(&b).cloned().collect();
    /// assert_eq!(union, [1, 2]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn union<'a>(&'a self, other: &'a BTreeSet<T>) -> Union<'a, T>
    where
        T: Ord,
    {
        Union(MergeIterInner::new(self.iter(), other.iter()))
    }

    /// എല്ലാ മൂല്യങ്ങളും നീക്കംചെയ്ത് സെറ്റ് മായ്‌ക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeSet;
    ///
    /// let mut v = BTreeSet::new();
    /// v.insert(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.map.clear()
    }

    /// സെറ്റിൽ ഒരു മൂല്യം ഉണ്ടെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// മൂല്യം സെറ്റിന്റെ മൂല്യ തരത്തിന്റെ കടമെടുത്ത ഏതെങ്കിലും രൂപമായിരിക്കാം, പക്ഷേ കടമെടുത്ത ഫോമിലെ ഓർ‌ഡറിംഗ് * മൂല്യ തരത്തിലെ ഓർ‌ഡറിംഗുമായി പൊരുത്തപ്പെടണം.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeSet;
    ///
    /// let set: BTreeSet<_> = [1, 2, 3].iter().cloned().collect();
    /// assert_eq!(set.contains(&1), true);
    /// assert_eq!(set.contains(&4), false);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn contains<Q: ?Sized>(&self, value: &Q) -> bool
    where
        T: Borrow<Q> + Ord,
        Q: Ord,
    {
        self.map.contains_key(value)
    }

    /// തന്നിരിക്കുന്ന മൂല്യത്തിന് തുല്യമായ സെറ്റിലെ മൂല്യത്തിലേക്ക് എന്തെങ്കിലും റഫറൻസ് നൽകുന്നു.
    ///
    /// മൂല്യം സെറ്റിന്റെ മൂല്യ തരത്തിന്റെ കടമെടുത്ത ഏതെങ്കിലും രൂപമായിരിക്കാം, പക്ഷേ കടമെടുത്ത ഫോമിലെ ഓർ‌ഡറിംഗ് * മൂല്യ തരത്തിലെ ഓർ‌ഡറിംഗുമായി പൊരുത്തപ്പെടണം.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeSet;
    ///
    /// let set: BTreeSet<_> = [1, 2, 3].iter().cloned().collect();
    /// assert_eq!(set.get(&2), Some(&2));
    /// assert_eq!(set.get(&4), None);
    /// ```
    ///
    #[stable(feature = "set_recovery", since = "1.9.0")]
    pub fn get<Q: ?Sized>(&self, value: &Q) -> Option<&T>
    where
        T: Borrow<Q> + Ord,
        Q: Ord,
    {
        Recover::get(&self.map, value)
    }

    /// `self` ന് `other`-ന് സമാനമായ ഘടകങ്ങളൊന്നുമില്ലെങ്കിൽ `true` നൽകുന്നു.
    /// ഇത് ഒരു ശൂന്യമായ കവല പരിശോധിക്കുന്നതിന് തുല്യമാണ്.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeSet;
    ///
    /// let a: BTreeSet<_> = [1, 2, 3].iter().cloned().collect();
    /// let mut b = BTreeSet::new();
    ///
    /// assert_eq!(a.is_disjoint(&b), true);
    /// b.insert(4);
    /// assert_eq!(a.is_disjoint(&b), true);
    /// b.insert(1);
    /// assert_eq!(a.is_disjoint(&b), false);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_disjoint(&self, other: &BTreeSet<T>) -> bool
    where
        T: Ord,
    {
        self.intersection(other).next().is_none()
    }

    /// സെറ്റ് മറ്റൊന്നിന്റെ ഉപസെറ്റാണെങ്കിൽ `true` നൽകുന്നു, അതായത്, `other`-ൽ `self`-ലെ എല്ലാ മൂല്യങ്ങളും അടങ്ങിയിരിക്കുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeSet;
    ///
    /// let sup: BTreeSet<_> = [1, 2, 3].iter().cloned().collect();
    /// let mut set = BTreeSet::new();
    ///
    /// assert_eq!(set.is_subset(&sup), true);
    /// set.insert(2);
    /// assert_eq!(set.is_subset(&sup), true);
    /// set.insert(4);
    /// assert_eq!(set.is_subset(&sup), false);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_subset(&self, other: &BTreeSet<T>) -> bool
    where
        T: Ord,
    {
        // self.difference(other).next().is_none()-ന് സമാനമായ ഫലം, എന്നാൽ ചുവടെയുള്ള കോഡ് വേഗതയേറിയതാണ് (ചില സാഹചര്യങ്ങളിൽ വളരെ വലുതാണ്).
        //
        if self.len() > other.len() {
            return false;
        }
        let (self_min, self_max) =
            if let (Some(self_min), Some(self_max)) = (self.first(), self.last()) {
                (self_min, self_max)
            } else {
                return true; // സ്വയം ശൂന്യമാണ്
            };
        let (other_min, other_max) =
            if let (Some(other_min), Some(other_max)) = (other.first(), other.last()) {
                (other_min, other_max)
            } else {
                return false; // മറ്റൊന്ന് ശൂന്യമാണ്
            };
        let mut self_iter = self.iter();
        match self_min.cmp(other_min) {
            Less => return false,
            Equal => {
                self_iter.next();
            }
            Greater => (),
        }
        match self_max.cmp(other_max) {
            Greater => return false,
            Equal => {
                self_iter.next_back();
            }
            Less => (),
        }
        if self_iter.len() <= other.len() / ITER_PERFORMANCE_TIPPING_SIZE_DIFF {
            for next in self_iter {
                if !other.contains(next) {
                    return false;
                }
            }
        } else {
            let mut other_iter = other.iter();
            other_iter.next();
            other_iter.next_back();
            let mut self_next = self_iter.next();
            while let Some(self1) = self_next {
                match other_iter.next().map_or(Less, |other1| self1.cmp(other1)) {
                    Less => return false,
                    Equal => self_next = self_iter.next(),
                    Greater => (),
                }
            }
        }
        true
    }

    /// സെറ്റ് മറ്റൊന്നിന്റെ സൂപ്പർസെറ്റാണെങ്കിൽ `true` നൽകുന്നു, അതായത്, `self`-ൽ `other`-ലെ എല്ലാ മൂല്യങ്ങളും അടങ്ങിയിരിക്കുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeSet;
    ///
    /// let sub: BTreeSet<_> = [1, 2].iter().cloned().collect();
    /// let mut set = BTreeSet::new();
    ///
    /// assert_eq!(set.is_superset(&sub), false);
    ///
    /// set.insert(0);
    /// set.insert(1);
    /// assert_eq!(set.is_superset(&sub), false);
    ///
    /// set.insert(2);
    /// assert_eq!(set.is_superset(&sub), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_superset(&self, other: &BTreeSet<T>) -> bool
    where
        T: Ord,
    {
        other.is_subset(self)
    }

    /// സെറ്റിലെ ആദ്യ മൂല്യത്തിലേക്ക് എന്തെങ്കിലും ഉണ്ടെങ്കിൽ അവലംബം നൽകുന്നു.
    /// ഈ മൂല്യം എല്ലായ്പ്പോഴും സെറ്റിലെ എല്ലാ മൂല്യങ്ങളുടെയും ഏറ്റവും ചുരുങ്ങിയതാണ്.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeSet;
    ///
    /// let mut set = BTreeSet::new();
    /// assert_eq!(set.first(), None);
    /// set.insert(1);
    /// assert_eq!(set.first(), Some(&1));
    /// set.insert(2);
    /// assert_eq!(set.first(), Some(&1));
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn first(&self) -> Option<&T>
    where
        T: Ord,
    {
        self.map.first_key_value().map(|(k, _)| k)
    }

    /// സെറ്റിലെ അവസാന മൂല്യത്തിലേക്ക് എന്തെങ്കിലും ഉണ്ടെങ്കിൽ അവലംബം നൽകുന്നു.
    /// ഈ മൂല്യം എല്ലായ്പ്പോഴും സെറ്റിലെ എല്ലാ മൂല്യങ്ങളുടെയും പരമാവധി ആണ്.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeSet;
    ///
    /// let mut set = BTreeSet::new();
    /// assert_eq!(set.last(), None);
    /// set.insert(1);
    /// assert_eq!(set.last(), Some(&1));
    /// set.insert(2);
    /// assert_eq!(set.last(), Some(&2));
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn last(&self) -> Option<&T>
    where
        T: Ord,
    {
        self.map.last_key_value().map(|(k, _)| k)
    }

    /// സെറ്റിൽ നിന്ന് ആദ്യ മൂല്യം നീക്കംചെയ്യുകയും എന്തെങ്കിലും ഉണ്ടെങ്കിൽ അത് തിരികെ നൽകുകയും ചെയ്യുന്നു.
    /// ആദ്യ മൂല്യം എല്ലായ്പ്പോഴും സെറ്റിലെ ഏറ്റവും കുറഞ്ഞ മൂല്യമാണ്.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeSet;
    ///
    /// let mut set = BTreeSet::new();
    ///
    /// set.insert(1);
    /// while let Some(n) = set.pop_first() {
    ///     assert_eq!(n, 1);
    /// }
    /// assert!(set.is_empty());
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn pop_first(&mut self) -> Option<T>
    where
        T: Ord,
    {
        self.map.pop_first().map(|kv| kv.0)
    }

    /// സെറ്റിൽ നിന്ന് അവസാന മൂല്യം നീക്കംചെയ്യുകയും എന്തെങ്കിലും ഉണ്ടെങ്കിൽ അത് തിരികെ നൽകുകയും ചെയ്യുന്നു.
    /// അവസാന മൂല്യം എല്ലായ്പ്പോഴും സെറ്റിലെ പരമാവധി മൂല്യമാണ്.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeSet;
    ///
    /// let mut set = BTreeSet::new();
    ///
    /// set.insert(1);
    /// while let Some(n) = set.pop_last() {
    ///     assert_eq!(n, 1);
    /// }
    /// assert!(set.is_empty());
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn pop_last(&mut self) -> Option<T>
    where
        T: Ord,
    {
        self.map.pop_last().map(|kv| kv.0)
    }

    /// സെറ്റിലേക്ക് ഒരു മൂല്യം ചേർക്കുന്നു.
    ///
    /// സെറ്റിന് ഈ മൂല്യം നിലവിലില്ലെങ്കിൽ, `true` തിരികെ നൽകും.
    ///
    /// സെറ്റിന് ഈ മൂല്യം നിലവിലുണ്ടെങ്കിൽ, `false` തിരികെ നൽകും, എൻ‌ട്രി അപ്‌ഡേറ്റ് ചെയ്യുന്നില്ല.
    /// കൂടുതൽ വിവരങ്ങൾക്ക് [module-level documentation] കാണുക.
    ///
    /// [module-level documentation]: index.html#insert-and-complex-keys
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeSet;
    ///
    /// let mut set = BTreeSet::new();
    ///
    /// assert_eq!(set.insert(2), true);
    /// assert_eq!(set.insert(2), false);
    /// assert_eq!(set.len(), 1);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, value: T) -> bool
    where
        T: Ord,
    {
        self.map.insert(value, ()).is_none()
    }

    /// സെറ്റിലേക്ക് ഒരു മൂല്യം ചേർക്കുന്നു, നിലവിലുള്ള മൂല്യത്തിന് പകരം എന്തെങ്കിലും നൽകിയാൽ അത് തന്നിരിക്കുന്ന മൂല്യത്തിന് തുല്യമാണ്.
    /// മാറ്റിസ്ഥാപിച്ച മൂല്യം നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeSet;
    ///
    /// let mut set = BTreeSet::new();
    /// set.insert(Vec::<i32>::new());
    ///
    /// assert_eq!(set.get(&[][..]).unwrap().capacity(), 0);
    /// set.replace(Vec::with_capacity(10));
    /// assert_eq!(set.get(&[][..]).unwrap().capacity(), 10);
    /// ```
    #[stable(feature = "set_recovery", since = "1.9.0")]
    pub fn replace(&mut self, value: T) -> Option<T>
    where
        T: Ord,
    {
        Recover::replace(&mut self.map, value)
    }

    /// സെറ്റിൽ നിന്ന് ഒരു മൂല്യം നീക്കംചെയ്യുന്നു.സെറ്റിൽ മൂല്യം ഉണ്ടായിരുന്നോ എന്ന് നൽകുന്നു.
    ///
    /// മൂല്യം സെറ്റിന്റെ മൂല്യ തരത്തിന്റെ കടമെടുത്ത ഏതെങ്കിലും രൂപമായിരിക്കാം, പക്ഷേ കടമെടുത്ത ഫോമിലെ ഓർ‌ഡറിംഗ് * മൂല്യ തരത്തിലെ ഓർ‌ഡറിംഗുമായി പൊരുത്തപ്പെടണം.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeSet;
    ///
    /// let mut set = BTreeSet::new();
    ///
    /// set.insert(2);
    /// assert_eq!(set.remove(&2), true);
    /// assert_eq!(set.remove(&2), false);
    /// ```
    ///
    ///
    #[doc(alias = "delete")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove<Q: ?Sized>(&mut self, value: &Q) -> bool
    where
        T: Borrow<Q> + Ord,
        Q: Ord,
    {
        self.map.remove(value).is_some()
    }

    /// സെറ്റിലെ മൂല്യം നീക്കംചെയ്യുകയും തിരികെ നൽകുകയും ചെയ്യുന്നു, അത് തന്നിരിക്കുന്നതിന് തുല്യമാണ്.
    ///
    /// മൂല്യം സെറ്റിന്റെ മൂല്യ തരത്തിന്റെ കടമെടുത്ത ഏതെങ്കിലും രൂപമായിരിക്കാം, പക്ഷേ കടമെടുത്ത ഫോമിലെ ഓർ‌ഡറിംഗ് * മൂല്യ തരത്തിലെ ഓർ‌ഡറിംഗുമായി പൊരുത്തപ്പെടണം.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeSet;
    ///
    /// let mut set: BTreeSet<_> = [1, 2, 3].iter().cloned().collect();
    /// assert_eq!(set.take(&2), Some(2));
    /// assert_eq!(set.take(&2), None);
    /// ```
    ///
    #[stable(feature = "set_recovery", since = "1.9.0")]
    pub fn take<Q: ?Sized>(&mut self, value: &Q) -> Option<T>
    where
        T: Borrow<Q> + Ord,
        Q: Ord,
    {
        Recover::take(&mut self.map, value)
    }

    /// പ്രവചിക്കുക വ്യക്തമാക്കിയ ഘടകങ്ങൾ മാത്രം നിലനിർത്തുന്നു.
    ///
    /// മറ്റൊരു വിധത്തിൽ പറഞ്ഞാൽ, `e` എല്ലാ ഘടകങ്ങളും നീക്കംചെയ്യുക, അതായത് `f(&e)` `false` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(btree_retain)]
    /// use std::collections::BTreeSet;
    ///
    /// let xs = [1, 2, 3, 4, 5, 6];
    /// let mut set: BTreeSet<i32> = xs.iter().cloned().collect();
    /// // ഇരട്ട സംഖ്യകൾ മാത്രം സൂക്ഷിക്കുക.
    /// set.retain(|&k| k % 2 == 0);
    /// assert!(set.iter().eq([2, 4, 6].iter()));
    /// ```
    #[unstable(feature = "btree_retain", issue = "79025")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        T: Ord,
        F: FnMut(&T) -> bool,
    {
        self.drain_filter(|v| !f(v));
    }

    /// എല്ലാ ഘടകങ്ങളും `other`-ൽ നിന്ന് `Self`-ലേക്ക് നീക്കുന്നു, `other` ശൂന്യമാക്കും.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeSet;
    ///
    /// let mut a = BTreeSet::new();
    /// a.insert(1);
    /// a.insert(2);
    /// a.insert(3);
    ///
    /// let mut b = BTreeSet::new();
    /// b.insert(3);
    /// b.insert(4);
    /// b.insert(5);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.len(), 5);
    /// assert_eq!(b.len(), 0);
    ///
    /// assert!(a.contains(&1));
    /// assert!(a.contains(&2));
    /// assert!(a.contains(&3));
    /// assert!(a.contains(&4));
    /// assert!(a.contains(&5));
    /// ```
    #[stable(feature = "btree_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self)
    where
        T: Ord,
    {
        self.map.append(&mut other.map);
    }

    /// തന്നിരിക്കുന്ന കീയിൽ ശേഖരം രണ്ടായി വിഭജിക്കുന്നു.
    /// താക്കോൽ ഉൾപ്പെടെ നൽകിയ താക്കോലിന് ശേഷം എല്ലാം നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BTreeSet;
    ///
    /// let mut a = BTreeSet::new();
    /// a.insert(1);
    /// a.insert(2);
    /// a.insert(3);
    /// a.insert(17);
    /// a.insert(41);
    ///
    /// let b = a.split_off(&3);
    ///
    /// assert_eq!(a.len(), 2);
    /// assert_eq!(b.len(), 3);
    ///
    /// assert!(a.contains(&1));
    /// assert!(a.contains(&2));
    ///
    /// assert!(b.contains(&3));
    /// assert!(b.contains(&17));
    /// assert!(b.contains(&41));
    /// ```
    #[stable(feature = "btree_split_off", since = "1.11.0")]
    pub fn split_off<Q: ?Sized + Ord>(&mut self, key: &Q) -> Self
    where
        T: Borrow<Q> + Ord,
    {
        BTreeSet { map: self.map.split_off(key) }
    }

    /// ഒരു മൂല്യം നീക്കംചെയ്യേണ്ടതുണ്ടോ എന്ന് നിർണ്ണയിക്കാൻ ഒരു അടയ്ക്കൽ ഉപയോഗിക്കുന്ന ഒരു ഇറ്ററേറ്റർ സൃഷ്ടിക്കുന്നു.
    ///
    /// അടയ്ക്കൽ ശരിയാണെങ്കിൽ, മൂല്യം നീക്കംചെയ്യുകയും വിളവ് നൽകുകയും ചെയ്യും.
    /// അടയ്‌ക്കൽ തെറ്റാണെങ്കിൽ‌, മൂല്യം പട്ടികയിൽ‌നിലനിൽക്കും, കൂടാതെ ഇറ്ററേറ്റർ‌അത് നൽ‌കുകയുമില്ല.
    ///
    /// ഇറ്ററേറ്റർ ഭാഗികമായി മാത്രമേ ഉപയോഗിക്കുന്നുള്ളൂ അല്ലെങ്കിൽ ഉപഭോഗം ചെയ്യുന്നില്ലെങ്കിൽ, ശേഷിക്കുന്ന ഓരോ മൂല്യങ്ങളും ഇപ്പോഴും അടയ്‌ക്കുന്നതിന് വിധേയമാക്കുകയും അത് ശരിയാണെങ്കിൽ തിരിച്ചെടുക്കുകയും ഉപേക്ഷിക്കുകയും ചെയ്യും.
    ///
    /// അടയ്‌ക്കുമ്പോൾ ഒരു panic സംഭവിക്കുകയാണെങ്കിൽ, അല്ലെങ്കിൽ ഒരു മൂല്യം ഉപേക്ഷിക്കുമ്പോൾ ഒരു panic സംഭവിക്കുകയാണെങ്കിൽ, അല്ലെങ്കിൽ `DrainFilter` തന്നെ ചോർന്നാൽ എത്ര മൂല്യങ്ങൾ അടയ്‌ക്കലിന് വിധേയമാകുമെന്ന് വ്യക്തമല്ല.
    ///
    ///
    /// # Examples
    ///
    /// ഒരു സെറ്റ് ഇരട്ട സംഖ്യകളായി വിഭജിച്ച് യഥാർത്ഥ സെറ്റ് വീണ്ടും ഉപയോഗിക്കുന്നു:
    ///
    /// ```
    /// #![feature(btree_drain_filter)]
    /// use std::collections::BTreeSet;
    ///
    /// let mut set: BTreeSet<i32> = (0..8).collect();
    /// let evens: BTreeSet<_> = set.drain_filter(|v| v % 2 == 0).collect();
    /// let odds = set;
    /// assert_eq!(evens.into_iter().collect::<Vec<_>>(), vec![0, 2, 4, 6]);
    /// assert_eq!(odds.into_iter().collect::<Vec<_>>(), vec![1, 3, 5, 7]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "btree_drain_filter", issue = "70530")]
    pub fn drain_filter<'a, F>(&'a mut self, pred: F) -> DrainFilter<'a, T, F>
    where
        T: Ord,
        F: 'a + FnMut(&T) -> bool,
    {
        DrainFilter { pred, inner: self.map.drain_filter_inner() }
    }

    /// ആരോഹണ ക്രമത്തിൽ `BTreeSet`-ലെ മൂല്യങ്ങൾ സന്ദർശിക്കുന്ന ഒരു ഇറ്ററേറ്റർ ലഭിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeSet;
    ///
    /// let set: BTreeSet<usize> = [1, 2, 3].iter().cloned().collect();
    /// let mut set_iter = set.iter();
    /// assert_eq!(set_iter.next(), Some(&1));
    /// assert_eq!(set_iter.next(), Some(&2));
    /// assert_eq!(set_iter.next(), Some(&3));
    /// assert_eq!(set_iter.next(), None);
    /// ```
    ///
    /// ഇറ്ററേറ്റർ നൽകിയ മൂല്യങ്ങൾ ആരോഹണ ക്രമത്തിൽ നൽകുന്നു:
    ///
    /// ```
    /// use std::collections::BTreeSet;
    ///
    /// let set: BTreeSet<usize> = [3, 1, 2].iter().cloned().collect();
    /// let mut set_iter = set.iter();
    /// assert_eq!(set_iter.next(), Some(&1));
    /// assert_eq!(set_iter.next(), Some(&2));
    /// assert_eq!(set_iter.next(), Some(&3));
    /// assert_eq!(set_iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.map.keys() }
    }

    /// സെറ്റിലെ ഘടകങ്ങളുടെ എണ്ണം നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeSet;
    ///
    /// let mut v = BTreeSet::new();
    /// assert_eq!(v.len(), 0);
    /// v.insert(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_btree_new", issue = "71835")]
    pub const fn len(&self) -> usize {
        self.map.len()
    }

    /// സെറ്റിൽ ഘടകങ്ങളൊന്നുമില്ലെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeSet;
    ///
    /// let mut v = BTreeSet::new();
    /// assert!(v.is_empty());
    /// v.insert(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_btree_new", issue = "71835")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BTreeSet<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BTreeSet<T> {
        let mut set = BTreeSet::new();
        set.extend(iter);
        set
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BTreeSet<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// `BTreeSet` ന്റെ ഉള്ളടക്കങ്ങൾ‌നീക്കുന്നതിന് ഒരു ഇറ്ററേറ്റർ‌നേടുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeSet;
    ///
    /// let set: BTreeSet<usize> = [1, 2, 3, 4].iter().cloned().collect();
    ///
    /// let v: Vec<_> = set.into_iter().collect();
    /// assert_eq!(v, [1, 2, 3, 4]);
    /// ```
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.map.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BTreeSet<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

/// BTreeSet-ൽ `drain_filter`-ൽ വിളിച്ച് നിർമ്മിച്ച ഒരു ഇറ്ററേറ്റർ.
#[unstable(feature = "btree_drain_filter", issue = "70530")]
pub struct DrainFilter<'a, T, F>
where
    T: 'a,
    F: 'a + FnMut(&T) -> bool,
{
    pred: F,
    inner: super::map::DrainFilterInner<'a, T, ()>,
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<T, F> Drop for DrainFilter<'_, T, F>
where
    F: FnMut(&T) -> bool,
{
    fn drop(&mut self) {
        self.for_each(drop);
    }
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<T, F> fmt::Debug for DrainFilter<'_, T, F>
where
    T: fmt::Debug,
    F: FnMut(&T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DrainFilter").field(&self.inner.peek().map(|(k, _)| k)).finish()
    }
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<'a, T, F> Iterator for DrainFilter<'_, T, F>
where
    F: 'a + FnMut(&T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        let pred = &mut self.pred;
        let mut mapped_pred = |k: &T, _v: &mut ()| pred(k);
        self.inner.next(&mut mapped_pred).map(|(k, _)| k)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<T, F> FusedIterator for DrainFilter<'_, T, F> where F: FnMut(&T) -> bool {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BTreeSet<T> {
    #[inline]
    fn extend<Iter: IntoIterator<Item = T>>(&mut self, iter: Iter) {
        iter.into_iter().for_each(move |elem| {
            self.insert(elem);
        });
    }

    #[inline]
    fn extend_one(&mut self, elem: T) {
        self.insert(elem);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BTreeSet<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &'a T) {
        self.insert(elem);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BTreeSet<T> {
    /// ഒരു ശൂന്യമായ `BTreeSet` സൃഷ്ടിക്കുന്നു.
    fn default() -> BTreeSet<T> {
        BTreeSet::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord + Clone> Sub<&BTreeSet<T>> for &BTreeSet<T> {
    type Output = BTreeSet<T>;

    /// `self`, `rhs` എന്നിവയുടെ വ്യത്യാസം ഒരു പുതിയ `BTreeSet<T>` ആയി നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeSet;
    ///
    /// let a: BTreeSet<_> = vec![1, 2, 3].into_iter().collect();
    /// let b: BTreeSet<_> = vec![3, 4, 5].into_iter().collect();
    ///
    /// let result = &a - &b;
    /// let result_vec: Vec<_> = result.into_iter().collect();
    /// assert_eq!(result_vec, [1, 2]);
    /// ```
    fn sub(self, rhs: &BTreeSet<T>) -> BTreeSet<T> {
        self.difference(rhs).cloned().collect()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord + Clone> BitXor<&BTreeSet<T>> for &BTreeSet<T> {
    type Output = BTreeSet<T>;

    /// `self`, `rhs` എന്നിവയുടെ സമമിതി വ്യത്യാസം ഒരു പുതിയ `BTreeSet<T>` ആയി നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeSet;
    ///
    /// let a: BTreeSet<_> = vec![1, 2, 3].into_iter().collect();
    /// let b: BTreeSet<_> = vec![2, 3, 4].into_iter().collect();
    ///
    /// let result = &a ^ &b;
    /// let result_vec: Vec<_> = result.into_iter().collect();
    /// assert_eq!(result_vec, [1, 4]);
    /// ```
    fn bitxor(self, rhs: &BTreeSet<T>) -> BTreeSet<T> {
        self.symmetric_difference(rhs).cloned().collect()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord + Clone> BitAnd<&BTreeSet<T>> for &BTreeSet<T> {
    type Output = BTreeSet<T>;

    /// `self`, `rhs` എന്നിവയുടെ വിഭജനം ഒരു പുതിയ `BTreeSet<T>` ആയി നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeSet;
    ///
    /// let a: BTreeSet<_> = vec![1, 2, 3].into_iter().collect();
    /// let b: BTreeSet<_> = vec![2, 3, 4].into_iter().collect();
    ///
    /// let result = &a & &b;
    /// let result_vec: Vec<_> = result.into_iter().collect();
    /// assert_eq!(result_vec, [2, 3]);
    /// ```
    fn bitand(self, rhs: &BTreeSet<T>) -> BTreeSet<T> {
        self.intersection(rhs).cloned().collect()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord + Clone> BitOr<&BTreeSet<T>> for &BTreeSet<T> {
    type Output = BTreeSet<T>;

    /// `self`, `rhs` എന്നിവയുടെ യൂണിയൻ ഒരു പുതിയ `BTreeSet<T>` ആയി നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeSet;
    ///
    /// let a: BTreeSet<_> = vec![1, 2, 3].into_iter().collect();
    /// let b: BTreeSet<_> = vec![3, 4, 5].into_iter().collect();
    ///
    /// let result = &a | &b;
    /// let result_vec: Vec<_> = result.into_iter().collect();
    /// assert_eq!(result_vec, [1, 2, 3, 4, 5]);
    /// ```
    fn bitor(self, rhs: &BTreeSet<T>) -> BTreeSet<T> {
        self.union(rhs).cloned().collect()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Debug> Debug for BTreeSet<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_set().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    fn last(mut self) -> Option<&'a T> {
        self.next_back()
    }

    fn min(mut self) -> Option<&'a T> {
        self.next()
    }

    fn max(mut self) -> Option<&'a T> {
        self.next_back()
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn len(&self) -> usize {
        self.iter.len()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.iter.next().map(|(k, _)| k)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back().map(|(k, _)| k)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn len(&self) -> usize {
        self.iter.len()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<T> Clone for Range<'_, T> {
    fn clone(&self) -> Self {
        Range { iter: self.iter.clone() }
    }
}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<'a, T> Iterator for Range<'a, T> {
    type Item = &'a T;

    fn next(&mut self) -> Option<&'a T> {
        self.iter.next().map(|(k, _)| k)
    }

    fn last(mut self) -> Option<&'a T> {
        self.next_back()
    }

    fn min(mut self) -> Option<&'a T> {
        self.next()
    }

    fn max(mut self) -> Option<&'a T> {
        self.next_back()
    }
}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<'a, T> DoubleEndedIterator for Range<'a, T> {
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back().map(|(k, _)| k)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Range<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Difference<'_, T> {
    fn clone(&self) -> Self {
        Difference {
            inner: match &self.inner {
                DifferenceInner::Stitch { self_iter, other_iter } => DifferenceInner::Stitch {
                    self_iter: self_iter.clone(),
                    other_iter: other_iter.clone(),
                },
                DifferenceInner::Search { self_iter, other_set } => {
                    DifferenceInner::Search { self_iter: self_iter.clone(), other_set }
                }
                DifferenceInner::Iterate(iter) => DifferenceInner::Iterate(iter.clone()),
            },
        }
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T: Ord> Iterator for Difference<'a, T> {
    type Item = &'a T;

    fn next(&mut self) -> Option<&'a T> {
        match &mut self.inner {
            DifferenceInner::Stitch { self_iter, other_iter } => {
                let mut self_next = self_iter.next()?;
                loop {
                    match other_iter.peek().map_or(Less, |other_next| self_next.cmp(other_next)) {
                        Less => return Some(self_next),
                        Equal => {
                            self_next = self_iter.next()?;
                            other_iter.next();
                        }
                        Greater => {
                            other_iter.next();
                        }
                    }
                }
            }
            DifferenceInner::Search { self_iter, other_set } => loop {
                let self_next = self_iter.next()?;
                if !other_set.contains(&self_next) {
                    return Some(self_next);
                }
            },
            DifferenceInner::Iterate(iter) => iter.next(),
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let (self_len, other_len) = match &self.inner {
            DifferenceInner::Stitch { self_iter, other_iter } => {
                (self_iter.len(), other_iter.len())
            }
            DifferenceInner::Search { self_iter, other_set } => (self_iter.len(), other_set.len()),
            DifferenceInner::Iterate(iter) => (iter.len(), 0),
        };
        (self_len.saturating_sub(other_len), Some(self_len))
    }

    fn min(mut self) -> Option<&'a T> {
        self.next()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T: Ord> FusedIterator for Difference<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for SymmetricDifference<'_, T> {
    fn clone(&self) -> Self {
        SymmetricDifference(self.0.clone())
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T: Ord> Iterator for SymmetricDifference<'a, T> {
    type Item = &'a T;

    fn next(&mut self) -> Option<&'a T> {
        loop {
            let (a_next, b_next) = self.0.nexts(Self::Item::cmp);
            if a_next.and(b_next).is_none() {
                return a_next.or(b_next);
            }
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let (a_len, b_len) = self.0.lens();
        // ചെക്ക്_അഡ് ഇല്ല, കാരണം എ, ബി എന്നിവ ഒരേ സെറ്റിനെ സൂചിപ്പിക്കുന്നു, ടി ഒരു ശൂന്യമായ തരമാണെങ്കിലും, സെറ്റുകളുടെ സ്റ്റോറേജ് ഓവർഹെഡ് മൂലകങ്ങളുടെ എണ്ണം ഉപയോഗത്തിന്റെ പരിധിയുടെ പകുതിയിൽ താഴെയായി പരിമിതപ്പെടുത്തുന്നു.
        //
        //
        (0, Some(a_len + b_len))
    }

    fn min(mut self) -> Option<&'a T> {
        self.next()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T: Ord> FusedIterator for SymmetricDifference<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Intersection<'_, T> {
    fn clone(&self) -> Self {
        Intersection {
            inner: match &self.inner {
                IntersectionInner::Stitch { a, b } => {
                    IntersectionInner::Stitch { a: a.clone(), b: b.clone() }
                }
                IntersectionInner::Search { small_iter, large_set } => {
                    IntersectionInner::Search { small_iter: small_iter.clone(), large_set }
                }
                IntersectionInner::Answer(answer) => IntersectionInner::Answer(*answer),
            },
        }
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T: Ord> Iterator for Intersection<'a, T> {
    type Item = &'a T;

    fn next(&mut self) -> Option<&'a T> {
        match &mut self.inner {
            IntersectionInner::Stitch { a, b } => {
                let mut a_next = a.next()?;
                let mut b_next = b.next()?;
                loop {
                    match a_next.cmp(b_next) {
                        Less => a_next = a.next()?,
                        Greater => b_next = b.next()?,
                        Equal => return Some(a_next),
                    }
                }
            }
            IntersectionInner::Search { small_iter, large_set } => loop {
                let small_next = small_iter.next()?;
                if large_set.contains(&small_next) {
                    return Some(small_next);
                }
            },
            IntersectionInner::Answer(answer) => answer.take(),
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        match &self.inner {
            IntersectionInner::Stitch { a, b } => (0, Some(min(a.len(), b.len()))),
            IntersectionInner::Search { small_iter, .. } => (0, Some(small_iter.len())),
            IntersectionInner::Answer(None) => (0, Some(0)),
            IntersectionInner::Answer(Some(_)) => (1, Some(1)),
        }
    }

    fn min(mut self) -> Option<&'a T> {
        self.next()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T: Ord> FusedIterator for Intersection<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Union<'_, T> {
    fn clone(&self) -> Self {
        Union(self.0.clone())
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T: Ord> Iterator for Union<'a, T> {
    type Item = &'a T;

    fn next(&mut self) -> Option<&'a T> {
        let (a_next, b_next) = self.0.nexts(Self::Item::cmp);
        a_next.or(b_next)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let (a_len, b_len) = self.0.lens();
        // ചെക്ക്_അഡ് ഇല്ല, SymmetricDifference::size_hint കാണുക.
        (max(a_len, b_len), Some(a_len + b_len))
    }

    fn min(mut self) -> Option<&'a T> {
        self.next()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T: Ord> FusedIterator for Union<'_, T> {}

#[cfg(test)]
mod tests;