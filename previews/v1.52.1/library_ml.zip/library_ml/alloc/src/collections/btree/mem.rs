use core::intrinsics;
use core::mem;
use core::ptr;

/// പ്രസക്തമായ ഫംഗ്ഷനെ വിളിച്ചുകൊണ്ട് ഇത് `v` അദ്വിതീയ റഫറൻസിന് പിന്നിലുള്ള മൂല്യം മാറ്റിസ്ഥാപിക്കുന്നു.
///
///
/// `change` ക്ലോസറിൽ ഒരു panic സംഭവിക്കുകയാണെങ്കിൽ, മുഴുവൻ പ്രക്രിയയും നിർത്തലാക്കും.
#[allow(dead_code)] // ചിത്രീകരണമായും future ഉപയോഗത്തിനും സൂക്ഷിക്കുക
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// പ്രസക്തമായ ഫംഗ്ഷനെ വിളിച്ചുകൊണ്ട് ഇത് `v` അദ്വിതീയ റഫറൻസിന് പിന്നിലുള്ള മൂല്യം മാറ്റിസ്ഥാപിക്കുകയും വഴിയിൽ ലഭിച്ച ഒരു ഫലം നൽകുകയും ചെയ്യുന്നു.
///
///
/// `change` ക്ലോസറിൽ ഒരു panic സംഭവിക്കുകയാണെങ്കിൽ, മുഴുവൻ പ്രക്രിയയും നിർത്തലാക്കും.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}