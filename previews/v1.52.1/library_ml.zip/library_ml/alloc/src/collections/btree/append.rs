use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// രണ്ട് ആരോഹണ ഇറ്ററേറ്ററുകളുടെ യൂണിയനിൽ നിന്ന് എല്ലാ കീ-മൂല്യ ജോഡികളും കൂട്ടിച്ചേർക്കുന്നു, വഴിയിൽ ഒരു `length` വേരിയബിൾ വർദ്ധിപ്പിക്കുന്നു.ഡ്രോപ്പ് ഹാൻഡ്‌ലർ പരിഭ്രാന്തരാകുമ്പോൾ ചോർച്ച ഒഴിവാക്കുന്നത് കോളർക്ക് എളുപ്പമാക്കുന്നു.
    ///
    /// രണ്ട് ഇറ്ററേറ്ററുകളും ഒരേ കീ ഉൽ‌പാദിപ്പിക്കുകയാണെങ്കിൽ‌, ഈ രീതി ജോഡിയെ ഇടത് ഇറ്ററേറ്ററിൽ‌നിന്നും വലിച്ചിടുകയും ജോഡി വലത് ഇറ്ററേറ്ററിൽ‌നിന്നും കൂട്ടിച്ചേർക്കുകയും ചെയ്യുന്നു.
    ///
    /// ഒരു `BTreeMap` പോലെ, കർശനമായി ആരോഹണ ക്രമത്തിൽ മരം അവസാനിക്കണമെന്ന് നിങ്ങൾ ആഗ്രഹിക്കുന്നുവെങ്കിൽ, രണ്ട് ആവർത്തനങ്ങളും കർശനമായി ആരോഹണ ക്രമത്തിൽ കീകൾ നിർമ്മിക്കണം, ഓരോന്നും ട്രീയിലെ എല്ലാ കീകളേക്കാളും വലുതാണ്, പ്രവേശന സമയത്ത് മരത്തിൽ ഇതിനകം തന്നെ ഏതെങ്കിലും കീകൾ ഉൾപ്പെടെ.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // ലീനിയർ സമയത്ത് `left`, `right` എന്നിവ അടുക്കിയ ശ്രേണിയിലേക്ക് ലയിപ്പിക്കാൻ ഞങ്ങൾ തയ്യാറാകുന്നു.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // അതേസമയം, ലീനിയർ സമയത്ത് അടുക്കിയ ശ്രേണിയിൽ നിന്ന് ഞങ്ങൾ ഒരു മരം നിർമ്മിക്കുന്നു.
        self.bulk_push(iter, length)
    }

    /// എല്ലാ കീ-മൂല്യ ജോഡികളും ട്രീയുടെ അവസാനത്തിലേക്ക് തള്ളിവിടുന്നു, വഴിയിൽ ഒരു `length` വേരിയബിൾ വർദ്ധിപ്പിക്കുന്നു.
    /// ഇറ്ററേറ്റർ പരിഭ്രാന്തരാകുമ്പോൾ വിളിക്കുന്നയാൾക്ക് ചോർച്ച ഒഴിവാക്കുന്നത് രണ്ടാമത്തേത് എളുപ്പമാക്കുന്നു.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // എല്ലാ കീ-മൂല്യ ജോഡികളിലൂടെയും ആവർത്തിച്ച് ശരിയായ തലത്തിലേക്ക് നോഡുകളിലേക്ക് തള്ളുക.
        for (key, value) in iter {
            // കീ-മൂല്യ ജോഡി നിലവിലെ ലീഫ് നോഡിലേക്ക് നീക്കാൻ ശ്രമിക്കുക.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // ഇടമില്ല, മുകളിലേക്ക് പോയി അവിടേക്ക് തള്ളുക.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // ഇടം ശേഷിക്കുന്ന ഒരു നോഡ് കണ്ടെത്തി, ഇവിടെ തള്ളുക.
                                open_node = parent;
                                break;
                            } else {
                                // വീണ്ടും മുകളിലേക്ക് പോകുക.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // ഞങ്ങൾ മുകളിലാണ്, ഒരു പുതിയ റൂട്ട് നോഡ് സൃഷ്ടിച്ച് അവിടെ തള്ളുക.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // കീ-മൂല്യ ജോഡിയും പുതിയ വലത് സബ്‌ട്രീയും പുഷ് ചെയ്യുക.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // വലതുവശത്തുള്ള ഏറ്റവും ഇലയിലേക്ക് വീണ്ടും താഴേക്ക് പോകുക.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // ആവർത്തന പരിഭ്രാന്തിയിലാണെങ്കിലും മാപ്പ് അനുബന്ധ ഘടകങ്ങൾ താഴുന്നുവെന്ന് ഉറപ്പാക്കുന്നതിന് ഓരോ ആവർത്തനത്തിലും ദൈർഘ്യം വർദ്ധിപ്പിക്കുക.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// അടുക്കിയ രണ്ട് സീക്വൻസുകൾ ഒന്നിലേക്ക് ലയിപ്പിക്കുന്നതിനുള്ള ഒരു ഇറ്ററേറ്റർ
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// രണ്ട് കീകൾ തുല്യമാണെങ്കിൽ, ശരിയായ ഉറവിടത്തിൽ നിന്ന് കീ-മൂല്യ ജോഡി നൽകുന്നു.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}