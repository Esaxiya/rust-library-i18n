use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// ഒരേ ശ്രേണിക്ക് തുല്യമായ മാറ്റമില്ലാത്ത തുല്യമായ മറ്റൊന്ന് താൽക്കാലികമായി എടുക്കുന്നു.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// ഒരു വൃക്ഷത്തിൽ ഒരു നിർദ്ദിഷ്ട പരിധി നിർവചിക്കുന്ന വ്യത്യസ്ത ഇല അറ്റങ്ങൾ കണ്ടെത്തുന്നു.
    /// ഒരേ ട്രീയിലേക്ക് ഒരു ജോഡി വ്യത്യസ്ത ഹാൻഡിലുകൾ അല്ലെങ്കിൽ ഒരു ജോഡി ശൂന്യമായ ഓപ്ഷനുകൾ നൽകുന്നു.
    ///
    /// # Safety
    ///
    /// `BorrowType` `Immut` അല്ലാത്തപക്ഷം, ഒരേ കെവി രണ്ടുതവണ സന്ദർശിക്കാൻ ഡ്യൂപ്ലിക്കേറ്റ് ഹാൻഡിലുകൾ ഉപയോഗിക്കരുത്.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// `(root1.first_leaf_edge(), root2.last_leaf_edge())` ന് തുല്യമാണ്, പക്ഷേ കൂടുതൽ കാര്യക്ഷമമാണ്.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// ഒരു വൃക്ഷത്തിൽ ഒരു പ്രത്യേക ശ്രേണി വേർതിരിക്കുന്ന ഇല അരികുകളുടെ ജോഡി കണ്ടെത്തുന്നു.
    ///
    /// ഒരു `BTreeMap`-ലെ ട്രീ പോലെ വൃക്ഷം കീ ഉപയോഗിച്ച് ക്രമീകരിച്ചിട്ടുണ്ടെങ്കിൽ മാത്രമേ ഫലം അർത്ഥമുള്ളൂ.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // സുരക്ഷ: ഞങ്ങളുടെ വായ്പ തരം മാറ്റമില്ല.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// ഒരു വൃക്ഷത്തെ മുഴുവൻ വേർതിരിക്കുന്ന ജോഡി ഇല അരികുകൾ കണ്ടെത്തുന്നു.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// ഒരു നിർദ്ദിഷ്ട ശ്രേണി വേർതിരിക്കുന്ന ഒരു ജോടി ഇല അരികുകളിലേക്ക് ഒരു അദ്വിതീയ റഫറൻസ് വിഭജിക്കുന്നു.
    /// എക്സ് 00 എക്സ് മ്യൂട്ടേഷൻ അനുവദിക്കുന്ന അതുല്യമല്ലാത്ത റഫറൻസുകളാണ് ഫലം, അവ ശ്രദ്ധാപൂർവ്വം ഉപയോഗിക്കണം.
    ///
    /// ഒരു `BTreeMap`-ലെ ട്രീ പോലെ വൃക്ഷം കീ ഉപയോഗിച്ച് ക്രമീകരിച്ചിട്ടുണ്ടെങ്കിൽ മാത്രമേ ഫലം അർത്ഥമുള്ളൂ.
    ///
    ///
    /// # Safety
    /// ഒരേ കെവി രണ്ടുതവണ സന്ദർശിക്കാൻ ഡ്യൂപ്ലിക്കേറ്റ് ഹാൻഡിലുകൾ ഉപയോഗിക്കരുത്.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// വൃക്ഷത്തിന്റെ മുഴുവൻ ശ്രേണിയും വേർതിരിക്കുന്ന ഒരു ജോടി ഇല അരികുകളിലേക്ക് ഒരു അദ്വിതീയ റഫറൻസ് വിഭജിക്കുന്നു.
    /// മ്യൂട്ടേഷൻ (മൂല്യങ്ങളുടെ മാത്രം) അനുവദിക്കുന്ന അദ്വിതീയമല്ലാത്ത റഫറൻസുകളാണ് ഫലങ്ങൾ, അതിനാൽ ശ്രദ്ധയോടെ ഉപയോഗിക്കണം.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // റൂട്ട് നോഡ് റീഫ് ഞങ്ങൾ ഇവിടെ തനിപ്പകർപ്പാക്കുന്നു-ഞങ്ങൾ ഒരിക്കലും ഒരേ കെവി രണ്ടുതവണ സന്ദർശിക്കുകയില്ല, മാത്രമല്ല മൂല്യ റഫറൻസുകൾ ഓവർലാപ്പുചെയ്യുകയും ചെയ്യുന്നില്ല.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// വൃക്ഷത്തിന്റെ മുഴുവൻ ശ്രേണിയും വേർതിരിക്കുന്ന ഒരു ജോടി ഇല അരികുകളിലേക്ക് ഒരു അദ്വിതീയ റഫറൻസ് വിഭജിക്കുന്നു.
    /// വലിയ തോതിൽ വിനാശകരമായ പരിവർത്തനം അനുവദിക്കുന്ന അതുല്യമല്ലാത്ത റഫറൻസുകളാണ് ഫലങ്ങൾ, അതിനാൽ അതീവ ശ്രദ്ധയോടെ ഉപയോഗിക്കണം.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // റൂട്ട് നോഡ് റീഫ് ഞങ്ങൾ ഇവിടെ തനിപ്പകർപ്പാക്കുന്നു-റൂട്ടിൽ നിന്ന് ലഭിച്ച റഫറൻസുകളെ ഓവർലാപ്പ് ചെയ്യുന്ന രീതിയിൽ ഞങ്ങൾ ഇത് ഒരിക്കലും ആക്സസ് ചെയ്യില്ല.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// ഒരു ഇല edge ഹാൻഡിൽ നൽകി, വലതുവശത്തുള്ള അയൽവാസിയായ കെവിയിലേക്ക് ഒരു ഹാൻഡിൽ ഉപയോഗിച്ച് [`Result::Ok`] നൽകുന്നു, അത് ഒരേ ഇല നോഡിലോ അല്ലെങ്കിൽ ഒരു പൂർവ്വിക നോഡിലോ ആണ്.
    ///
    /// edge ഇല മരത്തിലെ അവസാനത്തേതാണെങ്കിൽ, റൂട്ട് നോഡിനൊപ്പം [`Result::Err`] നൽകുന്നു.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// ഒരു ഇല edge ഹാൻഡിൽ നൽകിയാൽ, ഇടത് വശത്തുള്ള അയൽവാസിയായ കെവിയിലേക്ക് ഒരു ഹാൻഡിൽ ഉപയോഗിച്ച് [`Result::Ok`] നൽകുന്നു, അത് ഒരേ ഇല നോഡിലോ അല്ലെങ്കിൽ ഒരു പൂർവ്വിക നോഡിലോ ആണ്.
    ///
    /// edge എന്ന ഇല വൃക്ഷത്തിലെ ആദ്യത്തേതാണെങ്കിൽ, റൂട്ട് നോഡിനൊപ്പം [`Result::Err`] നൽകുന്നു.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// ഒരു ആന്തരിക edge ഹാൻഡിൽ നൽകി, വലതുവശത്തുള്ള അയൽവാസിയായ കെവിയിലേക്ക് ഒരു ഹാൻഡിൽ ഉപയോഗിച്ച് [`Result::Ok`] നൽകുന്നു, അത് ഒരേ ആന്തരിക നോഡിലോ അല്ലെങ്കിൽ ഒരു പൂർവ്വിക നോഡിലോ ആണ്.
    ///
    /// ആന്തരിക edge ട്രീയിലെ അവസാനത്തേതാണെങ്കിൽ, റൂട്ട് നോഡിനൊപ്പം [`Result::Err`] നൽകുന്നു.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// ഒരു ഇല edge ഹാൻഡിൽ ഒരു മരിക്കുന്ന മരത്തിൽ നൽകി, അടുത്ത ഇല edge വലതുവശത്ത് നൽകുന്നു, അതിനിടയിലുള്ള കീ-മൂല്യ ജോഡി, ഒരേ ഇല നോഡിലോ, ഒരു പൂർവ്വിക നോഡിലോ, അല്ലെങ്കിൽ നിലവിലില്ല.
    ///
    ///
    /// ഈ രീതി അവസാനിക്കുന്ന ഏതൊരു node(s)-ലും ഡീലോക്കേറ്റ് ചെയ്യുന്നു.
    /// കൂടുതൽ കീ-മൂല്യ ജോഡി നിലവിലില്ലെങ്കിൽ, ട്രീയുടെ ബാക്കി മുഴുവൻ ഡീലോക്കേറ്റ് ചെയ്യപ്പെടുമെന്നും മടങ്ങിവരാൻ ഒന്നും ശേഷിക്കുന്നില്ലെന്നും ഇത് സൂചിപ്പിക്കുന്നു.
    ///
    /// # Safety
    /// തന്നിരിക്കുന്ന edge മുമ്പ് ക p ണ്ടർപാർട്ട് `deallocating_next_back` മടക്കി നൽകിയിരിക്കരുത്.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// ഒരു ഇല edge ഹാൻഡിൽ ഒരു മരിക്കുന്ന മരത്തിൽ നൽകി, അടുത്ത ഇല edge ഇടതുവശത്ത് നൽകുന്നു, അതിനിടയിലുള്ള കീ-മൂല്യ ജോഡി, ഒരേ ഇല നോഡിലോ, ഒരു പൂർവ്വിക നോഡിലോ, അല്ലെങ്കിൽ നിലവിലില്ല.
    ///
    ///
    /// ഈ രീതി അവസാനിക്കുന്ന ഏതൊരു node(s)-ലും ഡീലോക്കേറ്റ് ചെയ്യുന്നു.
    /// കൂടുതൽ കീ-മൂല്യ ജോഡി നിലവിലില്ലെങ്കിൽ, ട്രീയുടെ ബാക്കി മുഴുവൻ ഡീലോക്കേറ്റ് ചെയ്യപ്പെടുമെന്നും മടങ്ങിവരാൻ ഒന്നും ശേഷിക്കുന്നില്ലെന്നും ഇത് സൂചിപ്പിക്കുന്നു.
    ///
    /// # Safety
    /// തന്നിരിക്കുന്ന edge മുമ്പ് ക p ണ്ടർപാർട്ട് `deallocating_next` മടക്കി നൽകിയിരിക്കരുത്.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// ഇലയിൽ നിന്ന് റൂട്ട് വരെ നോഡുകളുടെ ഒരു കൂമ്പാരം ഡീലോക്കേറ്റ് ചെയ്യുന്നു.
    /// `deallocating_next`, `deallocating_next_back` എന്നിവ വൃക്ഷത്തിന്റെ ഇരുവശത്തും നിബ്ബ്ലിംഗ് ചെയ്യുകയും അതേ edge ൽ അടിക്കുകയും ചെയ്തതിന് ശേഷം ഒരു വൃക്ഷത്തിന്റെ ബാക്കി ഭാഗം ഡീലോക്കേറ്റ് ചെയ്യുന്നതിനുള്ള ഒരേയൊരു മാർഗ്ഗമാണിത്.
    /// എല്ലാ കീകളും മൂല്യങ്ങളും മടക്കിനൽകുമ്പോൾ മാത്രം വിളിക്കാൻ ഉദ്ദേശിച്ചുള്ളതിനാൽ, ഏതെങ്കിലും കീകളിലോ മൂല്യങ്ങളിലോ വൃത്തിയാക്കൽ നടക്കുന്നില്ല.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// ഇല edge ഹാൻഡിൽ അടുത്ത ഇല edge ലേക്ക് നീക്കുകയും അതിനിടയിലുള്ള കീയിലേക്കും മൂല്യത്തിലേക്കും റഫറൻസുകൾ നൽകുന്നു.
    ///
    ///
    /// # Safety
    /// യാത്ര ചെയ്ത ദിശയിൽ മറ്റൊരു കെവി ഉണ്ടായിരിക്കണം.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// മുമ്പത്തെ ഇല edge ലേക്ക് edge ഹാൻഡിൽ നീക്കി, അതിനിടയിലുള്ള കീയിലേക്കും മൂല്യത്തിലേക്കും റഫറൻസുകൾ നൽകുന്നു.
    ///
    ///
    /// # Safety
    /// യാത്ര ചെയ്ത ദിശയിൽ മറ്റൊരു കെവി ഉണ്ടായിരിക്കണം.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// ഇല edge ഹാൻഡിൽ അടുത്ത ഇല edge ലേക്ക് നീക്കുകയും അതിനിടയിലുള്ള കീയിലേക്കും മൂല്യത്തിലേക്കും റഫറൻസുകൾ നൽകുന്നു.
    ///
    ///
    /// # Safety
    /// യാത്ര ചെയ്ത ദിശയിൽ മറ്റൊരു കെവി ഉണ്ടായിരിക്കണം.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // ബെഞ്ച്മാർക്കുകൾ അനുസരിച്ച് ഇത് അവസാനമായി ചെയ്യുന്നത് വേഗത്തിലാണ്.
        kv.into_kv_valmut()
    }

    /// edge ഹാൻഡിൽ മുമ്പത്തെ ഇലയിലേക്ക് നീക്കി, അതിനിടയിലുള്ള കീയിലേക്കും മൂല്യത്തിലേക്കും റഫറൻസുകൾ നൽകുന്നു.
    ///
    ///
    /// # Safety
    /// യാത്ര ചെയ്ത ദിശയിൽ മറ്റൊരു കെവി ഉണ്ടായിരിക്കണം.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // ബെഞ്ച്മാർക്കുകൾ അനുസരിച്ച് ഇത് അവസാനമായി ചെയ്യുന്നത് വേഗത്തിലാണ്.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// ഇല edge ഹാൻഡിൽ അടുത്ത ഇല edge ലേക്ക് നീക്കി അതിനിടയിൽ കീയും മൂല്യവും നൽകുന്നു, ശേഷിക്കുന്ന ഏതെങ്കിലും നോഡിനെ അതിന്റെ പാരന്റ് നോഡ് ഡാംഗ്ലിംഗിൽ ഉപേക്ഷിക്കുമ്പോൾ അവശേഷിക്കുന്ന ഏതെങ്കിലും നോഡിനെ ഡീലോക്കേറ്റ് ചെയ്യുന്നു.
    ///
    /// # Safety
    /// - യാത്ര ചെയ്ത ദിശയിൽ മറ്റൊരു കെവി ഉണ്ടായിരിക്കണം.
    /// - ട്രീയിലൂടെ സഞ്ചരിക്കാൻ ഉപയോഗിക്കുന്ന ഹാൻഡിലുകളുടെ ഒരു പകർപ്പിലും കെ‌വി മുമ്പ് ക X ണ്ടർ‌പാർട്ട് എക്സ് 00 എക്സ് നൽകിയില്ല.
    ///
    /// അപ്‌ഡേറ്റുചെയ്‌ത ഹാൻഡിൽ തുടരുന്നതിനുള്ള ഏക സുരക്ഷിത മാർഗം ഇത് താരതമ്യം ചെയ്യുക, ഉപേക്ഷിക്കുക, ഈ രീതിയെ അതിന്റെ സുരക്ഷാ വ്യവസ്ഥകൾക്ക് വിധേയമായി വീണ്ടും വിളിക്കുക, അല്ലെങ്കിൽ അതിന്റെ സുരക്ഷാ വ്യവസ്ഥകൾക്ക് വിധേയമായി ക p ണ്ടർപാർട്ട് `next_back_unchecked` എന്ന് വിളിക്കുക എന്നതാണ്.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// edge ഹാൻഡിൽ മുമ്പത്തെ ഇല edge ലേക്ക് നീക്കി, അതിനിടയിൽ കീയും മൂല്യവും നൽകുന്നു, അനുബന്ധ edge അതിന്റെ പാരന്റ് നോഡിൽ തൂങ്ങിക്കിടക്കുമ്പോൾ അവശേഷിക്കുന്ന ഏതെങ്കിലും നോഡിനെ ഡീലോക്കേറ്റ് ചെയ്യുന്നു.
    ///
    /// # Safety
    /// - യാത്ര ചെയ്ത ദിശയിൽ മറ്റൊരു കെവി ഉണ്ടായിരിക്കണം.
    /// - ട്രീയിലൂടെ സഞ്ചരിക്കാൻ ഉപയോഗിക്കുന്ന ഹാൻഡിലുകളുടെ ഒരു പകർപ്പിലും edge എന്ന ഇല മുമ്പ് ക X ണ്ടർപാർട്ട് `next_unchecked` നൽകിയില്ല.
    ///
    /// അപ്‌ഡേറ്റുചെയ്‌ത ഹാൻഡിൽ തുടരുന്നതിനുള്ള ഏക സുരക്ഷിത മാർഗം ഇത് താരതമ്യം ചെയ്യുക, ഉപേക്ഷിക്കുക, ഈ രീതിയെ അതിന്റെ സുരക്ഷാ വ്യവസ്ഥകൾക്ക് വിധേയമായി വീണ്ടും വിളിക്കുക, അല്ലെങ്കിൽ അതിന്റെ സുരക്ഷാ വ്യവസ്ഥകൾക്ക് വിധേയമായി ക p ണ്ടർപാർട്ട് `next_unchecked` എന്ന് വിളിക്കുക എന്നതാണ്.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// മറ്റൊരു നോഡിൽ അല്ലെങ്കിൽ താഴെയായി ഇടതുവശത്തുള്ള ഇല edge നൽകുന്നു, മറ്റൊരു വിധത്തിൽ പറഞ്ഞാൽ, മുന്നോട്ട് നാവിഗേറ്റുചെയ്യുമ്പോൾ നിങ്ങൾക്ക് ആദ്യം ആവശ്യമുള്ള edge (അല്ലെങ്കിൽ പിന്നിലേക്ക് നാവിഗേറ്റുചെയ്യുമ്പോൾ അവസാനമായി).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// വലതുവശത്തുള്ള ഇല edge ഒരു നോഡിലോ അതിനു താഴെയോ നൽകുന്നു, മറ്റൊരു വിധത്തിൽ പറഞ്ഞാൽ, മുന്നോട്ട് നാവിഗേറ്റുചെയ്യുമ്പോൾ നിങ്ങൾക്ക് അവസാനമായി ആവശ്യമുള്ള edge (അല്ലെങ്കിൽ ആദ്യം പിന്നിലേക്ക് നാവിഗേറ്റുചെയ്യുമ്പോൾ).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// ആരോഹണ കീകളുടെ ക്രമത്തിൽ ഇല നോഡുകളും ആന്തരിക കെവികളും സന്ദർശിക്കുന്നു, കൂടാതെ ആന്തരിക നോഡുകൾ മൊത്തത്തിൽ ആഴത്തിലുള്ള ആദ്യ ക്രമത്തിൽ സന്ദർശിക്കുന്നു, അതായത് ആന്തരിക നോഡുകൾ അവരുടെ വ്യക്തിഗത കെവികൾക്കും ചൈൽഡ് നോഡുകൾക്കും മുമ്പാണ്.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// ഒരു (ഉപ) ട്രീയിലെ മൂലകങ്ങളുടെ എണ്ണം കണക്കാക്കുന്നു.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// ഫോർ‌വേർ‌ഡ് നാവിഗേഷനായി ഒരു കെ‌വിക്ക് ഏറ്റവും അടുത്തുള്ള edge ഇല നൽകുന്നു.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// ബാക്ക്‌വേർഡ് നാവിഗേഷനായി ഒരു കെ‌വിക്ക് ഏറ്റവും അടുത്തുള്ള edge ഇല നൽകുന്നു.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}