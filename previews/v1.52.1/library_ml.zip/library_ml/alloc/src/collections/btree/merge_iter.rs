use core::cmp::Ordering;
use core::fmt::{self, Debug};
use core::iter::FusedIterator;

/// കർശനമായി ആരോഹണക്രമത്തിലുള്ള രണ്ട് ഇറ്ററേറ്ററുകളുടെ output ട്ട്‌പുട്ട് ലയിപ്പിക്കുന്ന ഒരു ഇറ്ററേറ്ററിന്റെ കോർ, ഉദാഹരണത്തിന് ഒരു യൂണിയൻ അല്ലെങ്കിൽ സമമിതി വ്യത്യാസം.
///
pub struct MergeIterInner<I: Iterator> {
    a: I,
    b: I,
    peeked: Option<Peeked<I>>,
}

/// രണ്ട് ഇറ്ററേറ്ററുകളെയും പീക്ക് ചെയ്യാവുന്നതിൽ പൊതിയുന്നതിനേക്കാൾ വേഗത്തിൽ ബെഞ്ച്മാർക്കുകൾ, ഒരുപക്ഷേ ഫ്യൂസ്ഡ് ഇൻറേറ്റററിനെ ബന്ധിപ്പിക്കാൻ ഞങ്ങൾക്ക് കഴിയുമെന്നതിനാൽ.
///
#[derive(Clone, Debug)]
enum Peeked<I: Iterator> {
    A(I::Item),
    B(I::Item),
}

impl<I: Iterator> Clone for MergeIterInner<I>
where
    I: Clone,
    I::Item: Clone,
{
    fn clone(&self) -> Self {
        Self { a: self.a.clone(), b: self.b.clone(), peeked: self.peeked.clone() }
    }
}

impl<I: Iterator> Debug for MergeIterInner<I>
where
    I: Debug,
    I::Item: Debug,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("MergeIterInner").field(&self.a).field(&self.b).field(&self.peeked).finish()
    }
}

impl<I: Iterator> MergeIterInner<I> {
    /// ഒരു ജോടി ഉറവിടങ്ങൾ ലയിപ്പിക്കുന്ന ഒരു ആവർത്തനത്തിനായി ഒരു പുതിയ കോർ സൃഷ്ടിക്കുന്നു.
    pub fn new(a: I, b: I) -> Self {
        MergeIterInner { a, b, peeked: None }
    }

    /// ലയിപ്പിക്കുന്ന ഉറവിടങ്ങളിൽ നിന്ന് ഉത്ഭവിക്കുന്ന അടുത്ത ജോഡി ഇനങ്ങൾ നൽകുന്നു.
    /// മടക്കിയ രണ്ട് ഓപ്ഷനുകളിലും ഒരു മൂല്യം അടങ്ങിയിട്ടുണ്ടെങ്കിൽ, ആ മൂല്യം തുല്യമാണ്, രണ്ട് ഉറവിടങ്ങളിലും ഇത് സംഭവിക്കുന്നു.
    /// മടങ്ങിയെത്തിയ ഓപ്‌ഷനുകളിലൊന്നിൽ ഒരു മൂല്യം അടങ്ങിയിട്ടുണ്ടെങ്കിൽ, ആ മൂല്യം മറ്റ് ഉറവിടത്തിൽ സംഭവിക്കുന്നില്ല (അല്ലെങ്കിൽ ഉറവിടങ്ങൾ കർശനമായി ആരോഹണം ചെയ്യുന്നില്ല).
    ///
    /// മടങ്ങിയ ഓപ്ഷനുകളിലൊന്നും ഒരു മൂല്യം അടങ്ങിയിട്ടില്ലെങ്കിൽ, ആവർത്തനം പൂർത്തിയായി, തുടർന്നുള്ള കോളുകൾ അതേ ശൂന്യ ജോഡി നൽകും.
    ///
    ///
    pub fn nexts<Cmp: Fn(&I::Item, &I::Item) -> Ordering>(
        &mut self,
        cmp: Cmp,
    ) -> (Option<I::Item>, Option<I::Item>)
    where
        I: FusedIterator,
    {
        let mut a_next;
        let mut b_next;
        match self.peeked.take() {
            Some(Peeked::A(next)) => {
                a_next = Some(next);
                b_next = self.b.next();
            }
            Some(Peeked::B(next)) => {
                b_next = Some(next);
                a_next = self.a.next();
            }
            None => {
                a_next = self.a.next();
                b_next = self.b.next();
            }
        }
        if let (Some(ref a1), Some(ref b1)) = (&a_next, &b_next) {
            match cmp(a1, b1) {
                Ordering::Less => self.peeked = b_next.take().map(Peeked::B),
                Ordering::Greater => self.peeked = a_next.take().map(Peeked::A),
                Ordering::Equal => (),
            }
        }
        (a_next, b_next)
    }

    /// അന്തിമ ആവർത്തനത്തിന്റെ `size_hint`-നായി ഒരു ജോഡി മുകളിലെ അതിരുകൾ നൽകുന്നു.
    pub fn lens(&self) -> (usize, usize)
    where
        I: ExactSizeIterator,
    {
        match self.peeked {
            Some(Peeked::A(_)) => (1 + self.a.len(), self.b.len()),
            Some(Peeked::B(_)) => (self.a.len(), 1 + self.b.len()),
            _ => (self.a.len(), self.b.len()),
        }
    }
}