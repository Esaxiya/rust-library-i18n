use core::fmt::{self, Debug};
use core::marker::PhantomData;
use core::mem;

use super::super::borrow::DormantMutRef;
use super::super::node::{marker, Handle, InsertResult::*, NodeRef};
use super::BTreeMap;

use Entry::*;

/// ഒരു മാപ്പിലെ ഒരൊറ്റ എൻ‌ട്രിയിലേക്കുള്ള കാഴ്ച, അത് ഒഴിഞ്ഞുകിടക്കുകയോ അല്ലെങ്കിൽ‌കൈവശമാക്കുകയോ ചെയ്യാം.
///
/// [`BTreeMap`]-ലെ [`entry`] രീതിയിൽ നിന്നാണ് ഈ `enum` നിർമ്മിച്ചിരിക്കുന്നത്.
///
/// [`entry`]: BTreeMap::entry
#[stable(feature = "rust1", since = "1.0.0")]
pub enum Entry<'a, K: 'a, V: 'a> {
    /// ഒഴിഞ്ഞ പ്രവേശനം.
    #[stable(feature = "rust1", since = "1.0.0")]
    Vacant(#[stable(feature = "rust1", since = "1.0.0")] VacantEntry<'a, K, V>),

    /// ഒരു അധിനിവേശ എൻട്രി.
    #[stable(feature = "rust1", since = "1.0.0")]
    Occupied(#[stable(feature = "rust1", since = "1.0.0")] OccupiedEntry<'a, K, V>),
}

#[stable(feature = "debug_btree_map", since = "1.12.0")]
impl<K: Debug + Ord, V: Debug> Debug for Entry<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {
            Vacant(ref v) => f.debug_tuple("Entry").field(v).finish(),
            Occupied(ref o) => f.debug_tuple("Entry").field(o).finish(),
        }
    }
}

/// ഒരു `BTreeMap`-ലെ ഒഴിഞ്ഞ എൻ‌ട്രിയിലേക്കുള്ള കാഴ്ച.
/// ഇത് [`Entry`] enum ന്റെ ഭാഗമാണ്.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VacantEntry<'a, K: 'a, V: 'a> {
    pub(super) key: K,
    pub(super) handle: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>,
    pub(super) dormant_map: DormantMutRef<'a, BTreeMap<K, V>>,

    // `K`, `V` എന്നിവയിൽ മാറ്റമില്ല
    pub(super) _marker: PhantomData<&'a mut (K, V)>,
}

#[stable(feature = "debug_btree_map", since = "1.12.0")]
impl<K: Debug + Ord, V> Debug for VacantEntry<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("VacantEntry").field(self.key()).finish()
    }
}

/// ഒരു `BTreeMap`-ലെ ഒരു അധിനിവേശ എൻട്രിയുടെ കാഴ്ച.
/// ഇത് [`Entry`] enum ന്റെ ഭാഗമാണ്.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct OccupiedEntry<'a, K: 'a, V: 'a> {
    pub(super) handle: Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV>,
    pub(super) dormant_map: DormantMutRef<'a, BTreeMap<K, V>>,

    // `K`, `V` എന്നിവയിൽ മാറ്റമില്ല
    pub(super) _marker: PhantomData<&'a mut (K, V)>,
}

#[stable(feature = "debug_btree_map", since = "1.12.0")]
impl<K: Debug + Ord, V: Debug> Debug for OccupiedEntry<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("OccupiedEntry").field("key", self.key()).field("value", self.get()).finish()
    }
}

/// കീ ഇതിനകം നിലവിലുണ്ടെങ്കിൽ [`try_insert`](BTreeMap::try_insert) നൽകിയ പിശക്.
///
/// അധിനിവേശ എൻ‌ട്രിയും ഉൾപ്പെടുത്താത്ത മൂല്യവും അടങ്ങിയിരിക്കുന്നു.
#[unstable(feature = "map_try_insert", issue = "82766")]
pub struct OccupiedError<'a, K: 'a, V: 'a> {
    /// മാപ്പിലെ എൻ‌ട്രി ഇതിനകം കൈവശപ്പെടുത്തിയിരുന്നു.
    pub entry: OccupiedEntry<'a, K, V>,
    /// ഉൾപ്പെടുത്തിയിട്ടില്ലാത്ത മൂല്യം, കാരണം എൻ‌ട്രി ഇതിനകം തന്നെ കൈവശപ്പെടുത്തിയിരുന്നു.
    pub value: V,
}

#[unstable(feature = "map_try_insert", issue = "82766")]
impl<K: Debug + Ord, V: Debug> Debug for OccupiedError<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("OccupiedError")
            .field("key", self.entry.key())
            .field("old_value", self.entry.get())
            .field("new_value", &self.value)
            .finish()
    }
}

#[unstable(feature = "map_try_insert", issue = "82766")]
impl<'a, K: Debug + Ord, V: Debug> fmt::Display for OccupiedError<'a, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "failed to insert {:?}, key {:?} already exists with value {:?}",
            self.value,
            self.entry.key(),
            self.entry.get(),
        )
    }
}

impl<'a, K: Ord, V> Entry<'a, K, V> {
    /// സ്ഥിരസ്ഥിതി ശൂന്യമാണെങ്കിൽ എൻ‌ട്രിയിൽ ഒരു മൂല്യം ഉണ്ടെന്ന് ഉറപ്പാക്കുന്നു, കൂടാതെ എൻ‌ട്രിയിലെ മൂല്യത്തിലേക്ക് ഒരു മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<&str, usize> = BTreeMap::new();
    /// map.entry("poneyland").or_insert(12);
    ///
    /// assert_eq!(map["poneyland"], 12);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_insert(self, default: V) -> &'a mut V {
        match self {
            Occupied(entry) => entry.into_mut(),
            Vacant(entry) => entry.insert(default),
        }
    }

    /// സ്ഥിരസ്ഥിതി ഫംഗ്ഷന്റെ ഫലം ശൂന്യമാണെങ്കിൽ ഒരു മൂല്യം എൻ‌ട്രിയിൽ ഉണ്ടെന്ന് ഉറപ്പാക്കുന്നു, കൂടാതെ എൻ‌ട്രിയിലെ മൂല്യത്തിലേക്ക് ഒരു മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<&str, String> = BTreeMap::new();
    /// let s = "hoho".to_string();
    ///
    /// map.entry("poneyland").or_insert_with(|| s);
    ///
    /// assert_eq!(map["poneyland"], "hoho".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn or_insert_with<F: FnOnce() -> V>(self, default: F) -> &'a mut V {
        match self {
            Occupied(entry) => entry.into_mut(),
            Vacant(entry) => entry.insert(default()),
        }
    }

    /// സ്ഥിരസ്ഥിതി ഫംഗ്ഷന്റെ ഫലം ശൂന്യമാണെങ്കിൽ ഒരു മൂല്യം എൻ‌ട്രിയിൽ ഉണ്ടെന്ന് ഉറപ്പാക്കുന്നു.
    /// `.entry(key)` രീതി കോളിനിടെ നീക്കിയ കീയിലേക്ക് സ്ഥിരസ്ഥിതി ഫംഗ്ഷൻ ഒരു റഫറൻസ് നൽകിക്കൊണ്ട് ഉൾപ്പെടുത്തലിനായി കീ-ഡെറിവേഡ് മൂല്യങ്ങൾ സൃഷ്ടിക്കാൻ ഈ രീതി അനുവദിക്കുന്നു.
    ///
    ///
    /// നീക്കിയ കീയിലേക്കുള്ള റഫറൻസ് നൽകിയിട്ടുള്ളതിനാൽ `.or_insert_with(|| ... )`-ൽ നിന്ന് വ്യത്യസ്തമായി കീ ക്ലോണിംഗ് അല്ലെങ്കിൽ പകർത്തുന്നത് അനാവശ്യമാണ്.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<&str, usize> = BTreeMap::new();
    ///
    /// map.entry("poneyland").or_insert_with_key(|key| key.chars().count());
    ///
    /// assert_eq!(map["poneyland"], 9);
    /// ```
    ///
    #[inline]
    #[stable(feature = "or_insert_with_key", since = "1.50.0")]
    pub fn or_insert_with_key<F: FnOnce(&K) -> V>(self, default: F) -> &'a mut V {
        match self {
            Occupied(entry) => entry.into_mut(),
            Vacant(entry) => {
                let value = default(entry.key());
                entry.insert(value)
            }
        }
    }

    /// ഈ എൻ‌ട്രിയുടെ കീയിലേക്ക് ഒരു റഫറൻസ് നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<&str, usize> = BTreeMap::new();
    /// assert_eq!(map.entry("poneyland").key(), &"poneyland");
    /// ```
    #[stable(feature = "map_entry_keys", since = "1.10.0")]
    pub fn key(&self) -> &K {
        match *self {
            Occupied(ref entry) => entry.key(),
            Vacant(ref entry) => entry.key(),
        }
    }

    /// മാപ്പിലേക്ക് ഏതെങ്കിലും സാധ്യതയുള്ള ഉൾപ്പെടുത്തലുകൾക്ക് മുമ്പായി ഒരു അധിനിവേശ എൻ‌ട്രിയിലേക്ക് സ്ഥലത്ത് മ്യൂട്ടബിൾ ആക്‌സസ് നൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<&str, usize> = BTreeMap::new();
    ///
    /// map.entry("poneyland")
    ///    .and_modify(|e| { *e += 1 })
    ///    .or_insert(42);
    /// assert_eq!(map["poneyland"], 42);
    ///
    /// map.entry("poneyland")
    ///    .and_modify(|e| { *e += 1 })
    ///    .or_insert(42);
    /// assert_eq!(map["poneyland"], 43);
    /// ```
    #[stable(feature = "entry_and_modify", since = "1.26.0")]
    pub fn and_modify<F>(self, f: F) -> Self
    where
        F: FnOnce(&mut V),
    {
        match self {
            Occupied(mut entry) => {
                f(entry.get_mut());
                Occupied(entry)
            }
            Vacant(entry) => Vacant(entry),
        }
    }
}

impl<'a, K: Ord, V: Default> Entry<'a, K, V> {
    #[stable(feature = "entry_or_default", since = "1.28.0")]
    /// സ്ഥിരസ്ഥിതി മൂല്യം ശൂന്യമാണെങ്കിൽ എൻ‌ട്രിയിൽ ഒരു മൂല്യം ഉണ്ടെന്ന് ഉറപ്പാക്കുന്നു, കൂടാതെ എൻ‌ട്രിയിലെ മൂല്യത്തിലേക്ക് ഒരു മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<&str, Option<usize>> = BTreeMap::new();
    /// map.entry("poneyland").or_default();
    ///
    /// assert_eq!(map["poneyland"], None);
    /// ```
    pub fn or_default(self) -> &'a mut V {
        match self {
            Occupied(entry) => entry.into_mut(),
            Vacant(entry) => entry.insert(Default::default()),
        }
    }
}

impl<'a, K: Ord, V> VacantEntry<'a, K, V> {
    /// VacantEntry വഴി ഒരു മൂല്യം ചേർക്കുമ്പോൾ ഉപയോഗിക്കുന്ന കീയിലേക്ക് ഒരു റഫറൻസ് ലഭിക്കുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<&str, usize> = BTreeMap::new();
    /// assert_eq!(map.entry("poneyland").key(), &"poneyland");
    /// ```
    #[stable(feature = "map_entry_keys", since = "1.10.0")]
    pub fn key(&self) -> &K {
        &self.key
    }

    /// കീയുടെ ഉടമസ്ഥാവകാശം എടുക്കുക.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    /// use std::collections::btree_map::Entry;
    ///
    /// let mut map: BTreeMap<&str, usize> = BTreeMap::new();
    ///
    /// if let Entry::Vacant(v) = map.entry("poneyland") {
    ///     v.into_key();
    /// }
    /// ```
    #[stable(feature = "map_entry_recover_keys2", since = "1.12.0")]
    pub fn into_key(self) -> K {
        self.key
    }

    /// എൻ‌ട്രിയുടെ മൂല്യം `VacantEntry` ന്റെ കീ ഉപയോഗിച്ച് സജ്ജമാക്കി, അതിലേക്ക് ഒരു മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    /// use std::collections::btree_map::Entry;
    ///
    /// let mut map: BTreeMap<&str, u32> = BTreeMap::new();
    ///
    /// if let Entry::Vacant(o) = map.entry("poneyland") {
    ///     o.insert(37);
    /// }
    /// assert_eq!(map["poneyland"], 37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(self, value: V) -> &'a mut V {
        let out_ptr = match self.handle.insert_recursing(self.key, value) {
            (Fit(_), val_ptr) => {
                // സുരക്ഷ: ഞങ്ങൾ self.handle ഉപയോഗിച്ചു, ഹാൻഡിൽ മടങ്ങി.
                let map = unsafe { self.dormant_map.awaken() };
                map.length += 1;
                val_ptr
            }
            (Split(ins), val_ptr) => {
                drop(ins.left);
                // സുരക്ഷ: ഞങ്ങൾ self.handle ഉപയോഗിച്ചു, റഫറൻസ് മടങ്ങി.
                let map = unsafe { self.dormant_map.awaken() };
                let root = map.root.as_mut().unwrap();
                root.push_internal_level().push(ins.kv.0, ins.kv.1, ins.right);
                map.length += 1;
                val_ptr
            }
        };
        // കടമെടുത്ത റഫറൻസുകൾ ഉപയോഗിച്ച് ഞങ്ങൾ മരം വളർത്തുന്നത് ഇപ്പോൾ പൂർത്തിയാക്കി, അതിന്റെ ഒരു ഭാഗത്തേക്ക് പോയിന്റർ വ്യതിചലിപ്പിക്കുക, വഴിയിൽ ഞങ്ങൾ തിരഞ്ഞെടുത്തു.
        //
        unsafe { &mut *out_ptr }
    }
}

impl<'a, K: Ord, V> OccupiedEntry<'a, K, V> {
    /// എൻ‌ട്രിയിലെ കീയിലേക്ക് ഒരു റഫറൻസ് നേടുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<&str, usize> = BTreeMap::new();
    /// map.entry("poneyland").or_insert(12);
    /// assert_eq!(map.entry("poneyland").key(), &"poneyland");
    /// ```
    #[stable(feature = "map_entry_keys", since = "1.10.0")]
    pub fn key(&self) -> &K {
        self.handle.reborrow().into_kv().0
    }

    /// കീയുടെ ഉടമസ്ഥാവകാശവും മാപ്പിൽ നിന്ന് മൂല്യവും എടുക്കുക.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    /// use std::collections::btree_map::Entry;
    ///
    /// let mut map: BTreeMap<&str, usize> = BTreeMap::new();
    /// map.entry("poneyland").or_insert(12);
    ///
    /// if let Entry::Occupied(o) = map.entry("poneyland") {
    ///     // മാപ്പിൽ നിന്ന് ഞങ്ങൾ എൻട്രി ഇല്ലാതാക്കുന്നു.
    ///     o.remove_entry();
    /// }
    ///
    /// // ഇപ്പോൾ മൂല്യം നേടാൻ ശ്രമിക്കുകയാണെങ്കിൽ, അത് panic ചെയ്യും:
    /// // println! ("{}", മാപ്പ് ["പോണിലാന്റ്"]);
    /// ```
    #[stable(feature = "map_entry_recover_keys2", since = "1.12.0")]
    pub fn remove_entry(self) -> (K, V) {
        self.remove_kv()
    }

    /// എൻ‌ട്രിയിലെ മൂല്യത്തിലേക്ക് ഒരു റഫറൻസ് നേടുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    /// use std::collections::btree_map::Entry;
    ///
    /// let mut map: BTreeMap<&str, usize> = BTreeMap::new();
    /// map.entry("poneyland").or_insert(12);
    ///
    /// if let Entry::Occupied(o) = map.entry("poneyland") {
    ///     assert_eq!(o.get(), &12);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> &V {
        self.handle.reborrow().into_kv().1
    }

    /// എൻ‌ട്രിയിലെ മൂല്യത്തെക്കുറിച്ച് ഒരു മ്യൂട്ടബിൾ റഫറൻസ് നേടുന്നു.
    ///
    /// `Entry` മൂല്യത്തിന്റെ നാശത്തെ അതിജീവിക്കുന്ന `OccupiedEntry`-ലേക്ക് നിങ്ങൾക്ക് ഒരു റഫറൻസ് ആവശ്യമുണ്ടെങ്കിൽ, [`into_mut`] കാണുക.
    ///
    ///
    /// [`into_mut`]: OccupiedEntry::into_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    /// use std::collections::btree_map::Entry;
    ///
    /// let mut map: BTreeMap<&str, usize> = BTreeMap::new();
    /// map.entry("poneyland").or_insert(12);
    ///
    /// assert_eq!(map["poneyland"], 12);
    /// if let Entry::Occupied(mut o) = map.entry("poneyland") {
    ///     *o.get_mut() += 10;
    ///     assert_eq!(*o.get(), 22);
    ///
    ///     // ഒരേ എൻ‌ട്രി നമുക്ക് ഒന്നിലധികം തവണ ഉപയോഗിക്കാം.
    ///     *o.get_mut() += 2;
    /// }
    /// assert_eq!(map["poneyland"], 24);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self) -> &mut V {
        self.handle.kv_mut().1
    }

    /// എൻ‌ട്രിയെ അതിന്റെ മൂല്യത്തിലേക്ക് മാറ്റാവുന്ന റഫറൻസിലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// നിങ്ങൾക്ക് `OccupiedEntry`-ലേക്ക് ഒന്നിലധികം റഫറൻസുകൾ ആവശ്യമുണ്ടെങ്കിൽ, [`get_mut`] കാണുക.
    ///
    /// [`get_mut`]: OccupiedEntry::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    /// use std::collections::btree_map::Entry;
    ///
    /// let mut map: BTreeMap<&str, usize> = BTreeMap::new();
    /// map.entry("poneyland").or_insert(12);
    ///
    /// assert_eq!(map["poneyland"], 12);
    /// if let Entry::Occupied(o) = map.entry("poneyland") {
    ///     *o.into_mut() += 10;
    /// }
    /// assert_eq!(map["poneyland"], 22);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_mut(self) -> &'a mut V {
        self.handle.into_val_mut()
    }

    /// എൻ‌ട്രിയുടെ മൂല്യം `ഒക്യുപൈഡ് എൻ‌ട്രി` കീ ഉപയോഗിച്ച് സജ്ജമാക്കി എൻ‌ട്രിയുടെ പഴയ മൂല്യം നൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    /// use std::collections::btree_map::Entry;
    ///
    /// let mut map: BTreeMap<&str, usize> = BTreeMap::new();
    /// map.entry("poneyland").or_insert(12);
    ///
    /// if let Entry::Occupied(mut o) = map.entry("poneyland") {
    ///     assert_eq!(o.insert(15), 12);
    /// }
    /// assert_eq!(map["poneyland"], 15);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, value: V) -> V {
        mem::replace(self.get_mut(), value)
    }

    /// മാപ്പിലെ എൻ‌ട്രിയുടെ മൂല്യം എടുത്ത് അത് നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    /// use std::collections::btree_map::Entry;
    ///
    /// let mut map: BTreeMap<&str, usize> = BTreeMap::new();
    /// map.entry("poneyland").or_insert(12);
    ///
    /// if let Entry::Occupied(o) = map.entry("poneyland") {
    ///     assert_eq!(o.remove(), 12);
    /// }
    /// // "പോണിലാന്റ്" ന്റെ മൂല്യം നേടാൻ ഞങ്ങൾ ശ്രമിച്ചാൽ, അത് panic ആയിരിക്കും:
    /// // println! ("{}", മാപ്പ് ["പോണിലാന്റ്"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(self) -> V {
        self.remove_kv().1
    }

    // `remove_entry`-ന്റെ ബോഡി, ഒരുപക്ഷേ വേർതിരിച്ച ജോഡിയെ പേര് പ്രതിഫലിപ്പിക്കുന്നതിനാൽ വേർതിരിക്കാം.
    pub(super) fn remove_kv(self) -> (K, V) {
        let mut emptied_internal_root = false;
        let (old_kv, _) = self.handle.remove_kv_tracking(|| emptied_internal_root = true);
        // സുരക്ഷ: ഞങ്ങൾ ഇന്റർമീഡിയറ്റ് റൂട്ട് കടം കഴിച്ചു, `self.handle`.
        let map = unsafe { self.dormant_map.awaken() };
        map.length -= 1;
        if emptied_internal_root {
            let root = map.root.as_mut().unwrap();
            root.pop_internal_level();
        }
        old_kv
    }
}