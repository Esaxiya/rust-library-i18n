use core::borrow::Borrow;
use core::cmp::Ordering;
use core::fmt::{self, Debug};
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, RangeBounds};
use core::ptr;

use super::borrow::DormantMutRef;
use super::navigate::LeafRange;
use super::node::{self, marker, ForceResult::*, Handle, NodeRef, Root};
use super::search::SearchResult::*;

mod entry;
pub use entry::{Entry, OccupiedEntry, OccupiedError, VacantEntry};
use Entry::*;

/// റൂട്ട് അല്ലാത്ത നോഡുകളിലെ ഘടകങ്ങളുടെ ഏറ്റവും കുറഞ്ഞ എണ്ണം.
/// രീതികൾക്കിടയിൽ ഞങ്ങൾക്ക് താൽക്കാലികമായി കുറച്ച് ഘടകങ്ങൾ ഉണ്ടായിരിക്കാം.
pub(super) const MIN_LEN: usize = node::MIN_LEN_AFTER_SPLIT;

// `BTreeMap`-ലെ ഒരു മരം അധിക വ്യതിയാനങ്ങളുള്ള `node` മൊഡ്യൂളിലെ ഒരു വൃക്ഷമാണ്:
// - കീകൾ ആരോഹണ ക്രമത്തിൽ ദൃശ്യമാകണം (കീയുടെ തരം അനുസരിച്ച്).
// - റൂട്ട് നോഡ് ആന്തരികമാണെങ്കിൽ, അതിൽ കുറഞ്ഞത് 1 ഘടകമെങ്കിലും അടങ്ങിയിരിക്കണം.
// - എല്ലാ റൂട്ട് ഇതര നോഡിലും കുറഞ്ഞത് MIN_LEN ഘടകങ്ങൾ അടങ്ങിയിരിക്കുന്നു.
//
// ഒരു ശൂന്യമായ മാപ്പിനെ റൂട്ട് നോഡിന്റെ അഭാവം അല്ലെങ്കിൽ ഒരു ശൂന്യമായ ഇലയായ റൂട്ട് നോഡ് പ്രതിനിധീകരിക്കുന്നു.
//

/// ഒരു [B-Tree] അടിസ്ഥാനമാക്കിയുള്ള ഒരു മാപ്പ്.
///
/// കാഷെ-കാര്യക്ഷമതയും ഒരു തിരയലിൽ നടത്തുന്ന ജോലിയുടെ അളവ് കുറയ്ക്കുന്നതും തമ്മിലുള്ള അടിസ്ഥാനപരമായ ഒത്തുതീർപ്പിനെ ബി-ട്രീസ് പ്രതിനിധീകരിക്കുന്നു.തത്വത്തിൽ, ഒരു ബൈനറി സെർച്ച് ട്രീ (BST) എന്നത് ഒരു അടുക്കിയ മാപ്പിനുള്ള ഏറ്റവും അനുയോജ്യമായ തിരഞ്ഞെടുപ്പാണ്, കാരണം തികച്ചും സമതുലിതമായ ജിഎസ്ടി (log<sub>2</sub>n) എന്ന ഘടകം കണ്ടെത്തുന്നതിന് ആവശ്യമായ താരതമ്യങ്ങളുടെ സൈദ്ധാന്തിക മിനിമം അളവ് നിർവ്വഹിക്കുന്നു.
/// എന്നിരുന്നാലും, പ്രായോഗികമായി ഇത് ചെയ്യുന്ന രീതി ആധുനിക കമ്പ്യൂട്ടർ ആർക്കിടെക്ചറുകൾക്ക് *വളരെ* കാര്യക്ഷമമല്ല.
/// പ്രത്യേകിച്ചും, ഓരോ ഘടകങ്ങളും വ്യക്തിഗതമായി കൂമ്പാരം അനുവദിച്ച നോഡിൽ സൂക്ഷിക്കുന്നു.
/// ഇതിനർത്ഥം, ഓരോ ഉൾപ്പെടുത്തലും ഒരു കൂമ്പാര-അലോക്കേഷനെ പ്രേരിപ്പിക്കുന്നു, ഒപ്പം ഓരോ താരതമ്യവും ഒരു കാഷെ-മിസ് ആയിരിക്കണം.
/// ഇവ രണ്ടും പ്രായോഗികമായി ചെയ്യേണ്ട വിലയേറിയ കാര്യങ്ങളായതിനാൽ, ജിഎസ്ടി തന്ത്രം പുന ons പരിശോധിക്കാൻ ഞങ്ങൾ നിർബന്ധിതരാകുന്നു.
///
/// പകരം ഒരു ബി-ട്രീ ഓരോ നോഡിലും തുടർച്ചയായ അറേയിൽ B-1 മുതൽ 2B-1 ഘടകങ്ങൾ അടങ്ങിയിരിക്കുന്നു.ഇത് ചെയ്യുന്നതിലൂടെ, ബി യുടെ ഒരു ഘടകം ഉപയോഗിച്ച് ഞങ്ങൾ അലോക്കേഷനുകളുടെ എണ്ണം കുറയ്ക്കുകയും തിരയലുകളിൽ കാഷെ കാര്യക്ഷമത മെച്ചപ്പെടുത്തുകയും ചെയ്യുന്നു.എന്നിരുന്നാലും, തിരയലുകൾക്ക് ശരാശരി *കൂടുതൽ* താരതമ്യങ്ങൾ ചെയ്യേണ്ടിവരുമെന്നാണ് ഇതിനർത്ഥം.
/// താരതമ്യങ്ങളുടെ കൃത്യമായ എണ്ണം ഉപയോഗിച്ച നോഡ് തിരയൽ തന്ത്രത്തെ ആശ്രയിച്ചിരിക്കുന്നു.ഒപ്റ്റിമൽ കാഷെ കാര്യക്ഷമതയ്ക്കായി, ഒരാൾക്ക് നോഡുകളെ രേഖീയമായി തിരയാൻ കഴിയും.ഒപ്റ്റിമൽ താരതമ്യത്തിനായി, ബൈനറി തിരയൽ ഉപയോഗിച്ച് ഒരാൾക്ക് നോഡ് തിരയാൻ കഴിയും.ഒരു ഒത്തുതീർപ്പ് എന്ന നിലയിൽ, ഒരാൾ‌ക്ക് ഒരു ലീനിയർ‌തിരയൽ‌നടത്താനും കഴിയും, അത് തുടക്കത്തിൽ‌ഓരോ i <sup>ഘടകത്തെയും</sup> പരിശോധിക്കുന്നു.
///
/// നിലവിൽ, ഞങ്ങളുടെ നടപ്പാക്കൽ നിഷ്കളങ്കമായ ലീനിയർ തിരയൽ നടത്തുന്നു.താരതമ്യപ്പെടുത്താൻ വിലകുറഞ്ഞ ഘടകങ്ങളുടെ *ചെറിയ* നോഡുകളിൽ ഇത് മികച്ച പ്രകടനം നൽകുന്നു.എന്നിരുന്നാലും, future-ൽ, B യുടെ തിരഞ്ഞെടുപ്പിനെയും മറ്റ് ഘടകങ്ങളെയും അടിസ്ഥാനമാക്കി ഒപ്റ്റിമൽ തിരയൽ തന്ത്രം തിരഞ്ഞെടുക്കുന്നത് കൂടുതൽ പര്യവേക്ഷണം ചെയ്യാൻ ഞങ്ങൾ ആഗ്രഹിക്കുന്നു.ലീനിയർ തിരയൽ ഉപയോഗിച്ച്, ഒരു റാൻഡം ഘടകത്തിനായി തിരയുന്നത് O(B * log(n)) താരതമ്യങ്ങൾ എടുക്കുമെന്ന് പ്രതീക്ഷിക്കുന്നു, ഇത് സാധാരണയായി ഒരു ജിഎസ്ടിയേക്കാൾ മോശമാണ്.
///
/// എന്നിരുന്നാലും, പ്രായോഗികമായി, പ്രകടനം മികച്ചതാണ്.
///
/// മറ്റേതൊരു കീയുമായി താരതമ്യപ്പെടുത്തുമ്പോൾ കീയുടെ ക്രമം [`Ord`] trait നിർണ്ണയിക്കുന്നത് മാപ്പിൽ ആയിരിക്കുമ്പോൾ മാറുന്ന തരത്തിൽ ഒരു കീ പരിഷ്‌ക്കരിക്കുന്നത് ഒരു ലോജിക് പിശകാണ്.ഇത് സാധാരണയായി [`Cell`], [`RefCell`], ഗ്ലോബൽ സ്റ്റേറ്റ്, I/O അല്ലെങ്കിൽ സുരക്ഷിതമല്ലാത്ത കോഡ് വഴി മാത്രമേ സാധ്യമാകൂ.
/// അത്തരമൊരു ലോജിക് പിശകിന്റെ ഫലമായുണ്ടായ സ്വഭാവം വ്യക്തമാക്കിയിട്ടില്ല, പക്ഷേ നിർവചിക്കപ്പെടാത്ത പെരുമാറ്റത്തിന് കാരണമാകില്ല.ഇതിൽ panics, തെറ്റായ ഫലങ്ങൾ, നിർത്തലാക്കൽ, മെമ്മറി ലീക്കുകൾ, അവസാനിപ്പിക്കാത്തത് എന്നിവ ഉൾപ്പെടാം.
///
/// [B-Tree]: https://en.wikipedia.org/wiki/B-tree
/// [`Cell`]: core::cell::Cell
/// [`RefCell`]: core::cell::RefCell
///
/// # Examples
///
/// ```
/// use std::collections::BTreeMap;
///
/// // ടൈപ്പ് ഇൻ‌ഫെൻ‌ഷൻ‌ഒരു സ്പഷ്ടമായ ടൈപ്പ് സിഗ്‌നേച്ചർ‌ഒഴിവാക്കാൻ‌ഞങ്ങളെ അനുവദിക്കുന്നു (ഈ ഉദാഹരണത്തിൽ‌`BTreeMap<&str, &str>` ആയിരിക്കും).
/////
/// let mut movie_reviews = BTreeMap::new();
///
/// // ചില സിനിമകൾ അവലോകനം ചെയ്യുക.
/// movie_reviews.insert("Office Space",       "Deals with real issues in the workplace.");
/// movie_reviews.insert("Pulp Fiction",       "Masterpiece.");
/// movie_reviews.insert("The Godfather",      "Very enjoyable.");
/// movie_reviews.insert("The Blues Brothers", "Eye lyked it a lot.");
///
/// // നിർദ്ദിഷ്ട ഒരെണ്ണം പരിശോധിക്കുക.
/// if !movie_reviews.contains_key("Les Misérables") {
///     println!("We've got {} reviews, but Les Misérables ain't one.",
///              movie_reviews.len());
/// }
///
/// // ക്ഷമിക്കണം, ഈ അവലോകനത്തിൽ ധാരാളം അക്ഷരപ്പിശകുകൾ ഉണ്ട്, നമുക്ക് അത് ഇല്ലാതാക്കാം.
/// movie_reviews.remove("The Blues Brothers");
///
/// // ചില കീകളുമായി ബന്ധപ്പെട്ട മൂല്യങ്ങൾ നോക്കുക.
/// let to_find = ["Up!", "Office Space"];
/// for movie in &to_find {
///     match movie_reviews.get(movie) {
///        Some(review) => println!("{}: {}", movie, review),
///        None => println!("{} is unreviewed.", movie)
///     }
/// }
///
/// // ഒരു കീയ്‌ക്കായി മൂല്യം നോക്കുക (കീ കണ്ടെത്തിയില്ലെങ്കിൽ panic ചെയ്യും).
/// println!("Movie review: {}", movie_reviews["Office Space"]);
///
/// // എല്ലാത്തിനും മീതെ ആവർത്തിക്കുക.
/// for (movie, review) in &movie_reviews {
///     println!("{}: \"{}\"", movie, review);
/// }
/// ```
///
/// `BTreeMap` കീകളും അവയുടെ മൂല്യങ്ങളും നേടുന്നതിനും ക്രമീകരിക്കുന്നതിനും അപ്ഡേറ്റ് ചെയ്യുന്നതിനും നീക്കംചെയ്യുന്നതിനും കൂടുതൽ സങ്കീർണ്ണമായ രീതികൾ അനുവദിക്കുന്ന ഒരു [`Entry API`] ഉം നടപ്പിലാക്കുന്നു:
///
/// [`Entry API`]: BTreeMap::entry
///
/// ```
/// use std::collections::BTreeMap;
///
/// // ടൈപ്പ് ഇൻ‌ഫെൻ‌ഷൻ‌ഒരു സ്പഷ്ടമായ ടൈപ്പ് സിഗ്‌നേച്ചർ‌ഒഴിവാക്കാൻ‌ഞങ്ങളെ അനുവദിക്കുന്നു (ഈ ഉദാഹരണത്തിൽ‌ഇത് `BTreeMap<&str, u8>` ആയിരിക്കും).
/////
/// let mut player_stats = BTreeMap::new();
///
/// fn random_stat_buff() -> u8 {
///     // യഥാർത്ഥത്തിൽ ഇവിടെ ചില റാൻഡം മൂല്യം നൽകാം, ഇപ്പോൾ നമുക്ക് ചില നിശ്ചിത മൂല്യം നൽകാം
/////
///     42
/// }
///
/// // ഒരു കീ ഇതിനകം നിലവിലില്ലെങ്കിൽ മാത്രം ചേർക്കുക
/// player_stats.entry("health").or_insert(100);
///
/// // ഇതിനകം നിലവിലില്ലെങ്കിൽ മാത്രം ഒരു പുതിയ മൂല്യം നൽകുന്ന ഒരു ഫംഗ്ഷൻ ഉപയോഗിച്ച് ഒരു കീ ചേർക്കുക
/////
/// player_stats.entry("defence").or_insert_with(random_stat_buff);
///
/// // ഒരു കീ അപ്‌ഡേറ്റുചെയ്യുക, സജ്ജമാക്കിയിട്ടില്ലാത്ത കീയിൽ നിന്ന് ജാഗ്രത പാലിക്കുക
/// let stat = player_stats.entry("attack").or_insert(100);
/// *stat += random_stat_buff();
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BTreeMap")]
pub struct BTreeMap<K, V> {
    root: Option<Root<K, V>>,
    length: usize,
}

#[stable(feature = "btree_drop", since = "1.7.0")]
unsafe impl<#[may_dangle] K, #[may_dangle] V> Drop for BTreeMap<K, V> {
    fn drop(&mut self) {
        if let Some(root) = self.root.take() {
            Dropper { front: root.into_dying().first_leaf_edge(), remaining_length: self.length };
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Clone, V: Clone> Clone for BTreeMap<K, V> {
    fn clone(&self) -> BTreeMap<K, V> {
        fn clone_subtree<'a, K: Clone, V: Clone>(
            node: NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal>,
        ) -> BTreeMap<K, V>
        where
            K: 'a,
            V: 'a,
        {
            match node.force() {
                Leaf(leaf) => {
                    let mut out_tree = BTreeMap { root: Some(Root::new()), length: 0 };

                    {
                        let root = out_tree.root.as_mut().unwrap(); // ഞങ്ങൾ‌പൊതിഞ്ഞതിനാൽ‌അൺ‌റാപ്പ് വിജയിക്കുന്നു
                        let mut out_node = match root.borrow_mut().force() {
                            Leaf(leaf) => leaf,
                            Internal(_) => unreachable!(),
                        };

                        let mut in_edge = leaf.first_edge();
                        while let Ok(kv) = in_edge.right_kv() {
                            let (k, v) = kv.into_kv();
                            in_edge = kv.right_edge();

                            out_node.push(k.clone(), v.clone());
                            out_tree.length += 1;
                        }
                    }

                    out_tree
                }
                Internal(internal) => {
                    let mut out_tree = clone_subtree(internal.first_edge().descend());

                    {
                        let out_root = BTreeMap::ensure_is_owned(&mut out_tree.root);
                        let mut out_node = out_root.push_internal_level();
                        let mut in_edge = internal.first_edge();
                        while let Ok(kv) = in_edge.right_kv() {
                            let (k, v) = kv.into_kv();
                            in_edge = kv.right_edge();

                            let k = (*k).clone();
                            let v = (*v).clone();
                            let subtree = clone_subtree(in_edge.descend());

                            // BTreeMap ഡ്രോപ്പ് നടപ്പിലാക്കുന്നതിനാൽ ഞങ്ങൾക്ക് സബ്‌ട്രീ നേരിട്ട് നശിപ്പിക്കാൻ കഴിയില്ല
                            //
                            let (subroot, sublength) = unsafe {
                                let subtree = ManuallyDrop::new(subtree);
                                let root = ptr::read(&subtree.root);
                                let length = subtree.length;
                                (root, length)
                            };

                            out_node.push(k, v, subroot.unwrap_or_else(Root::new));
                            out_tree.length += 1 + sublength;
                        }
                    }

                    out_tree
                }
            }
        }

        if self.is_empty() {
            // ഞങ്ങൾ ഇവിടെ `BTreeMap::new` എന്ന് വിളിക്കും, പക്ഷേ അതിന് `K:
            // ഈ രീതിയില്ലാത്ത ഓർ‌ഡ് നിയന്ത്രണം.
            BTreeMap { root: None, length: 0 }
        } else {
            clone_subtree(self.root.as_ref().unwrap().reborrow()) // ശൂന്യമല്ലാത്തതിനാൽ അൺ‌റാപ്പ് വിജയിക്കുന്നു
        }
    }
}

impl<K, Q: ?Sized> super::Recover<Q> for BTreeMap<K, ()>
where
    K: Borrow<Q> + Ord,
    Q: Ord,
{
    type Key = K;

    fn get(&self, key: &Q) -> Option<&K> {
        let root_node = self.root.as_ref()?.reborrow();
        match root_node.search_tree(key) {
            Found(handle) => Some(handle.into_kv().0),
            GoDown(_) => None,
        }
    }

    fn take(&mut self, key: &Q) -> Option<K> {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = map.root.as_mut()?.borrow_mut();
        match root_node.search_tree(key) {
            Found(handle) => {
                Some(OccupiedEntry { handle, dormant_map, _marker: PhantomData }.remove_kv().0)
            }
            GoDown(_) => None,
        }
    }

    fn replace(&mut self, key: K) -> Option<K> {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = Self::ensure_is_owned(&mut map.root).borrow_mut();
        match root_node.search_tree::<K>(&key) {
            Found(mut kv) => Some(mem::replace(kv.key_mut(), key)),
            GoDown(handle) => {
                VacantEntry { key, handle, dormant_map, _marker: PhantomData }.insert(());
                None
            }
        }
    }
}

/// ഒരു `BTreeMap` ന്റെ എൻ‌ട്രികൾ‌ക്ക് മുകളിലുള്ള ഒരു ഇറ്ററേറ്റർ‌.
///
/// [`BTreeMap`]-ലെ [`iter`] രീതി ഉപയോഗിച്ചാണ് ഈ `struct` സൃഷ്ടിച്ചിരിക്കുന്നത്.
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// [`iter`]: BTreeMap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, K: 'a, V: 'a> {
    range: Range<'a, K, V>,
    length: usize,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V: fmt::Debug> fmt::Debug for Iter<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.clone()).finish()
    }
}

/// ഒരു `BTreeMap` ന്റെ എൻ‌ട്രികൾ‌ക്ക് മുകളിലുള്ള ഒരു മ്യൂട്ടബിൾ ഇറ്ററേറ്റർ‌.
///
/// [`BTreeMap`]-ലെ [`iter_mut`] രീതി ഉപയോഗിച്ചാണ് ഈ `struct` സൃഷ്ടിച്ചിരിക്കുന്നത്.
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// [`iter_mut`]: BTreeMap::iter_mut
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct IterMut<'a, K: 'a, V: 'a> {
    range: RangeMut<'a, K, V>,
    length: usize,
}

/// ഒരു `BTreeMap` ന്റെ എൻ‌ട്രികൾ‌ക്ക് സ്വന്തമായ ഒരു ഇറ്ററേറ്റർ‌.
///
/// [`BTreeMap`]-ലെ [`into_iter`] രീതി ഉപയോഗിച്ചാണ് ഈ `struct` സൃഷ്ടിച്ചിരിക്കുന്നത് (`IntoIterator` trait നൽകിയതാണ്).
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// [`into_iter`]: IntoIterator::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<K, V> {
    range: LeafRange<marker::Dying, K, V>,
    length: usize,
}

impl<K, V> IntoIter<K, V> {
    /// ശേഷിക്കുന്ന ഇനങ്ങളെക്കുറിച്ചുള്ള റഫറൻസുകളുടെ ഒരു ആവർത്തനം നൽകുന്നു.
    #[inline]
    pub(super) fn iter(&self) -> Iter<'_, K, V> {
        let range = Range { inner: self.range.reborrow() };
        Iter { range: range, length: self.length }
    }
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V: fmt::Debug> fmt::Debug for IntoIter<K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

/// `IntoIter`-ന്റെ ലളിതമായ പതിപ്പ് ഇരട്ട-അവസാനിക്കാത്തതും ഒരു ഉദ്ദേശ്യമേയുള്ളൂ: ഒരു `IntoIter`-ന്റെ ബാക്കി ഭാഗം ഉപേക്ഷിക്കുക.
/// അതിനാൽ ആദ്യം ഒരു `back` ഇല edge നോക്കാതെ ഒരു വൃക്ഷം മുഴുവൻ ഉപേക്ഷിക്കാനും ഇത് സഹായിക്കുന്നു.
///
struct Dropper<K, V> {
    front: Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge>,
    remaining_length: usize,
}

/// ഒരു `BTreeMap` ന്റെ കീകൾ‌ക്ക് മുകളിലുള്ള ഒരു ഇറ്ററേറ്റർ‌.
///
/// [`BTreeMap`]-ലെ [`keys`] രീതി ഉപയോഗിച്ചാണ് ഈ `struct` സൃഷ്ടിച്ചിരിക്കുന്നത്.
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// [`keys`]: BTreeMap::keys
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Keys<'a, K: 'a, V: 'a> {
    inner: Iter<'a, K, V>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V> fmt::Debug for Keys<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.clone()).finish()
    }
}

/// ഒരു `BTreeMap` ന്റെ മൂല്യങ്ങൾക്ക് മുകളിലുള്ള ഒരു ഇറ്ററേറ്റർ.
///
/// [`BTreeMap`]-ലെ [`values`] രീതി ഉപയോഗിച്ചാണ് ഈ `struct` സൃഷ്ടിച്ചിരിക്കുന്നത്.
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// [`values`]: BTreeMap::values
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Values<'a, K: 'a, V: 'a> {
    inner: Iter<'a, K, V>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K, V: fmt::Debug> fmt::Debug for Values<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.clone()).finish()
    }
}

/// ഒരു `BTreeMap` ന്റെ മൂല്യങ്ങൾക്ക് മുകളിലുള്ള ഒരു മ്യൂട്ടബിൾ ഇറ്ററേറ്റർ.
///
/// [`BTreeMap`]-ലെ [`values_mut`] രീതി ഉപയോഗിച്ചാണ് ഈ `struct` സൃഷ്ടിച്ചിരിക്കുന്നത്.
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// [`values_mut`]: BTreeMap::values_mut
#[stable(feature = "map_values_mut", since = "1.10.0")]
pub struct ValuesMut<'a, K: 'a, V: 'a> {
    inner: IterMut<'a, K, V>,
}

#[stable(feature = "map_values_mut", since = "1.10.0")]
impl<K, V: fmt::Debug> fmt::Debug for ValuesMut<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.inner.iter().map(|(_, val)| val)).finish()
    }
}

/// ഒരു `BTreeMap` ന്റെ കീകൾ‌ക്ക് മുകളിലുള്ള ഒരു ഇറ്ററേറ്റർ‌.
///
/// [`BTreeMap`]-ലെ [`into_keys`] രീതി ഉപയോഗിച്ചാണ് ഈ `struct` സൃഷ്ടിച്ചിരിക്കുന്നത്.
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// [`into_keys`]: BTreeMap::into_keys
#[unstable(feature = "map_into_keys_values", issue = "75294")]
pub struct IntoKeys<K, V> {
    inner: IntoIter<K, V>,
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K: fmt::Debug, V> fmt::Debug for IntoKeys<K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.inner.iter().map(|(key, _)| key)).finish()
    }
}

/// ഒരു `BTreeMap` ന്റെ മൂല്യങ്ങളെക്കാൾ സ്വന്തമായ ഒരു ഇറ്ററേറ്റർ.
///
/// [`BTreeMap`]-ലെ [`into_values`] രീതി ഉപയോഗിച്ചാണ് ഈ `struct` സൃഷ്ടിച്ചിരിക്കുന്നത്.
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// [`into_values`]: BTreeMap::into_values
#[unstable(feature = "map_into_keys_values", issue = "75294")]
pub struct IntoValues<K, V> {
    inner: IntoIter<K, V>,
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V: fmt::Debug> fmt::Debug for IntoValues<K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.inner.iter().map(|(_, val)| val)).finish()
    }
}

/// ഒരു `BTreeMap` ലെ എൻ‌ട്രികളുടെ ഉപ-ശ്രേണിയിലുള്ള ഒരു ഇറ്ററേറ്റർ.
///
/// [`BTreeMap`]-ലെ [`range`] രീതി ഉപയോഗിച്ചാണ് ഈ `struct` സൃഷ്ടിച്ചിരിക്കുന്നത്.
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// [`range`]: BTreeMap::range
#[stable(feature = "btree_range", since = "1.17.0")]
pub struct Range<'a, K: 'a, V: 'a> {
    inner: LeafRange<marker::Immut<'a>, K, V>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V: fmt::Debug> fmt::Debug for Range<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.clone()).finish()
    }
}

/// ഒരു `BTreeMap`-ലെ ഉപ ശ്രേണിയിലുള്ള എൻട്രികളുടെ ഒരു മ്യൂട്ടബിൾ ഇറ്ററേറ്റർ.
///
/// [`BTreeMap`]-ലെ [`range_mut`] രീതി ഉപയോഗിച്ചാണ് ഈ `struct` സൃഷ്ടിച്ചിരിക്കുന്നത്.
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// [`range_mut`]: BTreeMap::range_mut
#[stable(feature = "btree_range", since = "1.17.0")]
pub struct RangeMut<'a, K: 'a, V: 'a> {
    inner: LeafRange<marker::ValMut<'a>, K, V>,

    // `K`, `V` എന്നിവയിൽ മാറ്റമില്ല
    _marker: PhantomData<&'a mut (K, V)>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<K: fmt::Debug, V: fmt::Debug> fmt::Debug for RangeMut<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let range = Range { inner: self.inner.reborrow() };
        f.debug_list().entries(range).finish()
    }
}

impl<K, V> BTreeMap<K, V> {
    /// പുതിയതും ശൂന്യവുമായ `BTreeMap` നിർമ്മിക്കുന്നു.
    ///
    /// സ്വന്തമായി ഒന്നും അനുവദിക്കുന്നില്ല.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    ///
    /// // എൻ‌ട്രികൾ‌ഇപ്പോൾ‌ശൂന്യമായ മാപ്പിൽ‌ചേർ‌ക്കാൻ‌കഴിയും
    /// map.insert(1, "a");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_btree_new", issue = "71835")]
    pub const fn new() -> BTreeMap<K, V>
    where
        K: Ord,
    {
        BTreeMap { root: None, length: 0 }
    }

    /// എല്ലാ ഘടകങ്ങളും നീക്കംചെയ്ത് മാപ്പ് മായ്‌ക്കുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "a");
    /// a.clear();
    /// assert!(a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        *self = BTreeMap { root: None, length: 0 };
    }

    /// കീയുമായി ബന്ധപ്പെട്ട മൂല്യത്തിലേക്ക് ഒരു റഫറൻസ് നൽകുന്നു.
    ///
    /// കീ മാപ്പിന്റെ കീ തരത്തിന്റെ കടമെടുത്ത ഏതെങ്കിലും രൂപമായിരിക്കാം, പക്ഷേ കടമെടുത്ത ഫോമിലെ ഓർ‌ഡറിംഗ് * കീ തരത്തിലെ ഓർ‌ഡറിംഗുമായി പൊരുത്തപ്പെടണം.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.get(&1), Some(&"a"));
    /// assert_eq!(map.get(&2), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get<Q: ?Sized>(&self, key: &Q) -> Option<&V>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        let root_node = self.root.as_ref()?.reborrow();
        match root_node.search_tree(key) {
            Found(handle) => Some(handle.into_kv().1),
            GoDown(_) => None,
        }
    }

    /// നൽകിയ കീയുമായി ബന്ധപ്പെട്ട കീ-മൂല്യ ജോഡി നൽകുന്നു.
    ///
    /// വിതരണം ചെയ്ത കീ മാപ്പിന്റെ കീ തരത്തിന്റെ കടമെടുത്ത ഏതെങ്കിലും രൂപമായിരിക്കാം, പക്ഷേ കടമെടുത്ത ഫോമിലെ ഓർ‌ഡറിംഗ് * കീ തരത്തിലെ ഓർ‌ഡറിംഗുമായി പൊരുത്തപ്പെടണം.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.get_key_value(&1), Some((&1, &"a")));
    /// assert_eq!(map.get_key_value(&2), None);
    /// ```
    #[stable(feature = "map_get_key_value", since = "1.40.0")]
    pub fn get_key_value<Q: ?Sized>(&self, k: &Q) -> Option<(&K, &V)>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        let root_node = self.root.as_ref()?.reborrow();
        match root_node.search_tree(k) {
            Found(handle) => Some(handle.into_kv()),
            GoDown(_) => None,
        }
    }

    /// മാപ്പിലെ ആദ്യ കീ-മൂല്യ ജോഡി നൽകുന്നു.
    /// ഈ ജോഡിയിലെ കീ മാപ്പിലെ ഏറ്റവും കുറഞ്ഞ കീയാണ്.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// assert_eq!(map.first_key_value(), None);
    /// map.insert(1, "b");
    /// map.insert(2, "a");
    /// assert_eq!(map.first_key_value(), Some((&1, &"b")));
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn first_key_value(&self) -> Option<(&K, &V)>
    where
        K: Ord,
    {
        let root_node = self.root.as_ref()?.reborrow();
        root_node.first_leaf_edge().right_kv().ok().map(Handle::into_kv)
    }

    /// സ്ഥലത്തെ കൃത്രിമത്വത്തിനായി മാപ്പിലെ ആദ്യ എൻ‌ട്രി നൽകുന്നു.
    /// ഈ എൻ‌ട്രിയുടെ കീ മാപ്പിലെ ഏറ്റവും കുറഞ്ഞ കീയാണ്.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// map.insert(2, "b");
    /// if let Some(mut entry) = map.first_entry() {
    ///     if *entry.key() > 0 {
    ///         entry.insert("first");
    ///     }
    /// }
    /// assert_eq!(*map.get(&1).unwrap(), "first");
    /// assert_eq!(*map.get(&2).unwrap(), "b");
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn first_entry(&mut self) -> Option<OccupiedEntry<'_, K, V>>
    where
        K: Ord,
    {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = map.root.as_mut()?.borrow_mut();
        let kv = root_node.first_leaf_edge().right_kv().ok()?;
        Some(OccupiedEntry { handle: kv.forget_node_type(), dormant_map, _marker: PhantomData })
    }

    /// മാപ്പിലെ ആദ്യ ഘടകം നീക്കംചെയ്യുകയും തിരികെ നൽകുകയും ചെയ്യുന്നു.
    /// ഈ ഘടകത്തിന്റെ കീ മാപ്പിലെ ഏറ്റവും കുറഞ്ഞ കീയാണ്.
    ///
    /// # Examples
    ///
    /// ഓരോ ആവർത്തനത്തിലും ഉപയോഗയോഗ്യമായ മാപ്പ് സൂക്ഷിക്കുമ്പോൾ ഘടകങ്ങൾ ആരോഹണ ക്രമത്തിൽ നീക്കംചെയ്യുന്നു.
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// map.insert(2, "b");
    /// while let Some((key, _val)) = map.pop_first() {
    ///     assert!(map.iter().all(|(k, _v)| *k > key));
    /// }
    /// assert!(map.is_empty());
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn pop_first(&mut self) -> Option<(K, V)>
    where
        K: Ord,
    {
        self.first_entry().map(|entry| entry.remove_entry())
    }

    /// മാപ്പിലെ അവസാന കീ-മൂല്യ ജോഡി നൽകുന്നു.
    /// ഈ ജോഡിയിലെ കീ മാപ്പിലെ പരമാവധി കീയാണ്.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "b");
    /// map.insert(2, "a");
    /// assert_eq!(map.last_key_value(), Some((&2, &"a")));
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn last_key_value(&self) -> Option<(&K, &V)>
    where
        K: Ord,
    {
        let root_node = self.root.as_ref()?.reborrow();
        root_node.last_leaf_edge().left_kv().ok().map(Handle::into_kv)
    }

    /// സ്ഥലത്തെ കൃത്രിമത്വത്തിനായി മാപ്പിലെ അവസാന എൻ‌ട്രി നൽകുന്നു.
    /// ഈ എൻ‌ട്രിയുടെ കീ മാപ്പിലെ പരമാവധി കീയാണ്.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// map.insert(2, "b");
    /// if let Some(mut entry) = map.last_entry() {
    ///     if *entry.key() > 0 {
    ///         entry.insert("last");
    ///     }
    /// }
    /// assert_eq!(*map.get(&1).unwrap(), "a");
    /// assert_eq!(*map.get(&2).unwrap(), "last");
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn last_entry(&mut self) -> Option<OccupiedEntry<'_, K, V>>
    where
        K: Ord,
    {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = map.root.as_mut()?.borrow_mut();
        let kv = root_node.last_leaf_edge().left_kv().ok()?;
        Some(OccupiedEntry { handle: kv.forget_node_type(), dormant_map, _marker: PhantomData })
    }

    /// മാപ്പിലെ അവസാന ഘടകം നീക്കംചെയ്യുകയും തിരികെ നൽകുകയും ചെയ്യുന്നു.
    /// ഈ ഘടകത്തിന്റെ കീ മാപ്പിലുള്ള പരമാവധി കീയാണ്.
    ///
    /// # Examples
    ///
    /// ഓരോ ആവർത്തനത്തിലും ഉപയോഗയോഗ്യമായ മാപ്പ് സൂക്ഷിക്കുമ്പോൾ ഘടകങ്ങൾ അവരോഹണ ക്രമത്തിൽ നീക്കംചെയ്യുന്നു.
    ///
    /// ```
    /// #![feature(map_first_last)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// map.insert(2, "b");
    /// while let Some((key, _val)) = map.pop_last() {
    ///     assert!(map.iter().all(|(k, _v)| *k < key));
    /// }
    /// assert!(map.is_empty());
    /// ```
    #[unstable(feature = "map_first_last", issue = "62924")]
    pub fn pop_last(&mut self) -> Option<(K, V)>
    where
        K: Ord,
    {
        self.last_entry().map(|entry| entry.remove_entry())
    }

    /// നിർദ്ദിഷ്ട കീയ്‌ക്കായി മാപ്പിൽ ഒരു മൂല്യം അടങ്ങിയിട്ടുണ്ടെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// കീ മാപ്പിന്റെ കീ തരത്തിന്റെ കടമെടുത്ത ഏതെങ്കിലും രൂപമായിരിക്കാം, പക്ഷേ കടമെടുത്ത ഫോമിലെ ഓർ‌ഡറിംഗ് * കീ തരത്തിലെ ഓർ‌ഡറിംഗുമായി പൊരുത്തപ്പെടണം.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.contains_key(&1), true);
    /// assert_eq!(map.contains_key(&2), false);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn contains_key<Q: ?Sized>(&self, key: &Q) -> bool
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        self.get(key).is_some()
    }

    /// കീയുമായി ബന്ധപ്പെട്ട മൂല്യത്തിലേക്ക് ഒരു മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു.
    ///
    /// കീ മാപ്പിന്റെ കീ തരത്തിന്റെ കടമെടുത്ത ഏതെങ്കിലും രൂപമായിരിക്കാം, പക്ഷേ കടമെടുത്ത ഫോമിലെ ഓർ‌ഡറിംഗ് * കീ തരത്തിലെ ഓർ‌ഡറിംഗുമായി പൊരുത്തപ്പെടണം.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// if let Some(x) = map.get_mut(&1) {
    ///     *x = "b";
    /// }
    /// assert_eq!(map[&1], "b");
    /// ```
    // നടപ്പിലാക്കൽ കുറിപ്പുകൾക്കായി `get` കാണുക, ഇത് അടിസ്ഥാനപരമായി മ്യൂട്ട് ചേർത്ത ഒരു പകർപ്പ്-പേസ്റ്റാണ്
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut<Q: ?Sized>(&mut self, key: &Q) -> Option<&mut V>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        let root_node = self.root.as_mut()?.borrow_mut();
        match root_node.search_tree(key) {
            Found(handle) => Some(handle.into_val_mut()),
            GoDown(_) => None,
        }
    }

    /// മാപ്പിൽ ഒരു കീ-മൂല്യ ജോഡി ചേർക്കുന്നു.
    ///
    /// മാപ്പിന് ഈ കീ നിലവിലില്ലെങ്കിൽ, `None` തിരികെ നൽകും.
    ///
    /// മാപ്പിന് ഈ കീ നിലവിലുണ്ടെങ്കിൽ, മൂല്യം അപ്‌ഡേറ്റുചെയ്‌ത് പഴയ മൂല്യം മടക്കിനൽകുന്നു.
    /// കീ അപ്‌ഡേറ്റുചെയ്‌തിട്ടില്ല, എന്നിരുന്നാലും;സമാനതകളില്ലാതെ `==` ആകാവുന്ന തരങ്ങൾക്ക് ഇത് പ്രാധാന്യമുണ്ട്.
    ///
    /// കൂടുതൽ വിവരങ്ങൾക്ക് [module-level documentation] കാണുക.
    ///
    /// [module-level documentation]: index.html#insert-and-complex-keys
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// assert_eq!(map.insert(37, "a"), None);
    /// assert_eq!(map.is_empty(), false);
    ///
    /// map.insert(37, "b");
    /// assert_eq!(map.insert(37, "c"), Some("b"));
    /// assert_eq!(map[&37], "c");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, key: K, value: V) -> Option<V>
    where
        K: Ord,
    {
        match self.entry(key) {
            Occupied(mut entry) => Some(entry.insert(value)),
            Vacant(entry) => {
                entry.insert(value);
                None
            }
        }
    }

    /// മാപ്പിൽ ഒരു കീ-മൂല്യ ജോഡി ചേർക്കാൻ ശ്രമിക്കുന്നു, കൂടാതെ എൻ‌ട്രിയിലെ മൂല്യത്തിലേക്ക് ഒരു മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു.
    ///
    /// മാപ്പിന് ഇതിനകം തന്നെ ഈ കീ നിലവിലുണ്ടെങ്കിൽ, ഒന്നും അപ്‌ഡേറ്റ് ചെയ്തിട്ടില്ല, കൂടാതെ കൈവശമുള്ള എൻ‌ട്രിയും മൂല്യവും അടങ്ങിയ ഒരു പിശക് തിരികെ നൽകും.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// #![feature(map_try_insert)]
    ///
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// assert_eq!(map.try_insert(37, "a").unwrap(), &"a");
    ///
    /// let err = map.try_insert(37, "b").unwrap_err();
    /// assert_eq!(err.entry.key(), &37);
    /// assert_eq!(err.entry.get(), &"a");
    /// assert_eq!(err.value, "b");
    /// ```
    ///
    #[unstable(feature = "map_try_insert", issue = "82766")]
    pub fn try_insert(&mut self, key: K, value: V) -> Result<&mut V, OccupiedError<'_, K, V>>
    where
        K: Ord,
    {
        match self.entry(key) {
            Occupied(entry) => Err(OccupiedError { entry, value }),
            Vacant(entry) => Ok(entry.insert(value)),
        }
    }

    /// മാപ്പിൽ നിന്ന് ഒരു കീ നീക്കംചെയ്യുന്നു, കീ മുമ്പ് മാപ്പിൽ ഉണ്ടായിരുന്നെങ്കിൽ കീയിലെ മൂല്യം നൽകുന്നു.
    ///
    /// കീ മാപ്പിന്റെ കീ തരത്തിന്റെ കടമെടുത്ത ഏതെങ്കിലും രൂപമായിരിക്കാം, പക്ഷേ കടമെടുത്ത ഫോമിലെ ഓർ‌ഡറിംഗ് * കീ തരത്തിലെ ഓർ‌ഡറിംഗുമായി പൊരുത്തപ്പെടണം.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.remove(&1), Some("a"));
    /// assert_eq!(map.remove(&1), None);
    /// ```
    ///
    #[doc(alias = "delete")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove<Q: ?Sized>(&mut self, key: &Q) -> Option<V>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        self.remove_entry(key).map(|(_, v)| v)
    }

    /// മാപ്പിൽ നിന്ന് ഒരു കീ നീക്കംചെയ്യുന്നു, കീ മുമ്പ് മാപ്പിൽ ഉണ്ടായിരുന്നെങ്കിൽ സംഭരിച്ച കീയും മൂല്യവും നൽകുന്നു.
    ///
    /// കീ മാപ്പിന്റെ കീ തരത്തിന്റെ കടമെടുത്ത ഏതെങ്കിലും രൂപമായിരിക്കാം, പക്ഷേ കടമെടുത്ത ഫോമിലെ ഓർ‌ഡറിംഗ് * കീ തരത്തിലെ ഓർ‌ഡറിംഗുമായി പൊരുത്തപ്പെടണം.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(1, "a");
    /// assert_eq!(map.remove_entry(&1), Some((1, "a")));
    /// assert_eq!(map.remove_entry(&1), None);
    /// ```
    ///
    #[stable(feature = "btreemap_remove_entry", since = "1.45.0")]
    pub fn remove_entry<Q: ?Sized>(&mut self, key: &Q) -> Option<(K, V)>
    where
        K: Borrow<Q> + Ord,
        Q: Ord,
    {
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = map.root.as_mut()?.borrow_mut();
        match root_node.search_tree(key) {
            Found(handle) => {
                Some(OccupiedEntry { handle, dormant_map, _marker: PhantomData }.remove_entry())
            }
            GoDown(_) => None,
        }
    }

    /// പ്രവചിക്കുക വ്യക്തമാക്കിയ ഘടകങ്ങൾ മാത്രം നിലനിർത്തുന്നു.
    ///
    /// മറ്റൊരു വിധത്തിൽ പറഞ്ഞാൽ, `f(&k, &mut v)` എല്ലാ ജോഡികളും `(k, v)` നീക്കംചെയ്യുക, അതായത് `f(&k, &mut v)` `false` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(btree_retain)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<i32, i32> = (0..8).map(|x| (x, x*10)).collect();
    /// // ഇരട്ട അക്കങ്ങളുള്ള കീകൾ ഉള്ള ഘടകങ്ങൾ മാത്രം സൂക്ഷിക്കുക.
    /// map.retain(|&k, _| k % 2 == 0);
    /// assert!(map.into_iter().eq(vec![(0, 0), (2, 20), (4, 40), (6, 60)]));
    /// ```
    #[inline]
    #[unstable(feature = "btree_retain", issue = "79025")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        K: Ord,
        F: FnMut(&K, &mut V) -> bool,
    {
        self.drain_filter(|k, v| !f(k, v));
    }

    /// എല്ലാ ഘടകങ്ങളും `other`-ൽ നിന്ന് `Self`-ലേക്ക് നീക്കുന്നു, `other` ശൂന്യമാക്കും.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "a");
    /// a.insert(2, "b");
    /// a.insert(3, "c");
    ///
    /// let mut b = BTreeMap::new();
    /// b.insert(3, "d");
    /// b.insert(4, "e");
    /// b.insert(5, "f");
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.len(), 5);
    /// assert_eq!(b.len(), 0);
    ///
    /// assert_eq!(a[&1], "a");
    /// assert_eq!(a[&2], "b");
    /// assert_eq!(a[&3], "d");
    /// assert_eq!(a[&4], "e");
    /// assert_eq!(a[&5], "f");
    /// ```
    #[stable(feature = "btree_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self)
    where
        K: Ord,
    {
        // നമ്മൾ എന്തെങ്കിലും കൂട്ടിച്ചേർക്കേണ്ടതുണ്ടോ?
        if other.is_empty() {
            return;
        }

        // `self` ശൂന്യമാണെങ്കിൽ നമുക്ക് `self`, `other` എന്നിവ സ്വാപ്പ് ചെയ്യാം.
        if self.is_empty() {
            mem::swap(self, other);
            return;
        }

        let self_iter = mem::take(self).into_iter();
        let other_iter = mem::take(other).into_iter();
        let root = BTreeMap::ensure_is_owned(&mut self.root);
        root.append_from_sorted_iters(self_iter, other_iter, &mut self.length)
    }

    /// മാപ്പിലെ ഘടകങ്ങളുടെ ഉപ-ശ്രേണിയിൽ ഇരട്ട-എൻഡ് ഇറ്ററേറ്റർ നിർമ്മിക്കുന്നു.
    /// `min..max` ശ്രേണി സിന്റാക്സ് ഉപയോഗിക്കുന്നതാണ് ഏറ്റവും ലളിതമായ മാർഗം, അതിനാൽ `range(min..max)` മിനിറ്റ് (inclusive) മുതൽ പരമാവധി (exclusive) വരെയുള്ള ഘടകങ്ങൾ നൽകും.
    /// ശ്രേണി `(Bound<T>, Bound<T>)` എന്നും നൽകാം, അതിനാൽ `range((Excluded(4), Included(10)))` 4 മുതൽ 10 വരെ ഇടത്-എക്സ്ക്ലൂസീവ്, വലത് ഉൾക്കൊള്ളുന്ന ശ്രേണി നൽകും.
    ///
    ///
    /// # Panics
    ///
    /// ശ്രേണി `start > end` ആണെങ്കിൽ Panics.
    /// ശ്രേണി `start == end` ഉം രണ്ട് അതിരുകളും `Excluded` ആണെങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    /// use std::ops::Bound::Included;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(3, "a");
    /// map.insert(5, "b");
    /// map.insert(8, "c");
    /// for (&key, &value) in map.range((Included(&4), Included(&8))) {
    ///     println!("{}: {}", key, value);
    /// }
    /// assert_eq!(Some((&5, &"b")), map.range(4..).next());
    /// ```
    ///
    ///
    #[stable(feature = "btree_range", since = "1.17.0")]
    pub fn range<T: ?Sized, R>(&self, range: R) -> Range<'_, K, V>
    where
        T: Ord,
        K: Borrow<T> + Ord,
        R: RangeBounds<T>,
    {
        if let Some(root) = &self.root {
            Range { inner: root.reborrow().range_search(range) }
        } else {
            Range { inner: LeafRange::none() }
        }
    }

    /// മാപ്പിലെ ഘടകങ്ങളുടെ ഉപ-ശ്രേണിയിൽ മ്യൂട്ടബിൾ ഇരട്ട-അവസാന ഇറ്ററേറ്റർ നിർമ്മിക്കുന്നു.
    /// `min..max` ശ്രേണി സിന്റാക്സ് ഉപയോഗിക്കുന്നതാണ് ഏറ്റവും ലളിതമായ മാർഗം, അതിനാൽ `range(min..max)` മിനിറ്റ് (inclusive) മുതൽ പരമാവധി (exclusive) വരെയുള്ള ഘടകങ്ങൾ നൽകും.
    /// ശ്രേണി `(Bound<T>, Bound<T>)` എന്നും നൽകാം, അതിനാൽ `range((Excluded(4), Included(10)))` 4 മുതൽ 10 വരെ ഇടത്-എക്സ്ക്ലൂസീവ്, വലത് ഉൾക്കൊള്ളുന്ന ശ്രേണി നൽകും.
    ///
    ///
    /// # Panics
    ///
    /// ശ്രേണി `start > end` ആണെങ്കിൽ Panics.
    /// ശ്രേണി `start == end` ഉം രണ്ട് അതിരുകളും `Excluded` ആണെങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<&str, i32> = ["Alice", "Bob", "Carol", "Cheryl"]
    ///     .iter()
    ///     .map(|&s| (s, 0))
    ///     .collect();
    /// for (_, balance) in map.range_mut("B".."Cheryl") {
    ///     *balance += 100;
    /// }
    /// for (name, balance) in &map {
    ///     println!("{} => {}", name, balance);
    /// }
    /// ```
    ///
    ///
    #[stable(feature = "btree_range", since = "1.17.0")]
    pub fn range_mut<T: ?Sized, R>(&mut self, range: R) -> RangeMut<'_, K, V>
    where
        T: Ord,
        K: Borrow<T> + Ord,
        R: RangeBounds<T>,
    {
        if let Some(root) = &mut self.root {
            RangeMut { inner: root.borrow_valmut().range_search(range), _marker: PhantomData }
        } else {
            RangeMut { inner: LeafRange::none(), _marker: PhantomData }
        }
    }

    /// സ്ഥലത്തെ കൃത്രിമത്വത്തിനായി മാപ്പിൽ തന്നിരിക്കുന്ന കീയുടെ അനുബന്ധ എൻ‌ട്രി നേടുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut count: BTreeMap<&str, usize> = BTreeMap::new();
    ///
    /// // vec ലെ അക്ഷരങ്ങളുടെ എണ്ണം എണ്ണുക
    /// for x in vec!["a", "b", "a", "c", "a", "b"] {
    ///     *count.entry(x).or_insert(0) += 1;
    /// }
    ///
    /// assert_eq!(count["a"], 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn entry(&mut self, key: K) -> Entry<'_, K, V>
    where
        K: Ord,
    {
        // FIXME(@porglezomp) ഞങ്ങൾ ചേർക്കുന്നില്ലെങ്കിൽ അനുവദിക്കുന്നത് ഒഴിവാക്കുക
        let (map, dormant_map) = DormantMutRef::new(self);
        let root_node = Self::ensure_is_owned(&mut map.root).borrow_mut();
        match root_node.search_tree(&key) {
            Found(handle) => Occupied(OccupiedEntry { handle, dormant_map, _marker: PhantomData }),
            GoDown(handle) => {
                Vacant(VacantEntry { key, handle, dormant_map, _marker: PhantomData })
            }
        }
    }

    /// തന്നിരിക്കുന്ന കീയിൽ ശേഖരം രണ്ടായി വിഭജിക്കുന്നു.
    /// താക്കോൽ ഉൾപ്പെടെ നൽകിയ താക്കോലിന് ശേഷം എല്ലാം നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "a");
    /// a.insert(2, "b");
    /// a.insert(3, "c");
    /// a.insert(17, "d");
    /// a.insert(41, "e");
    ///
    /// let b = a.split_off(&3);
    ///
    /// assert_eq!(a.len(), 2);
    /// assert_eq!(b.len(), 3);
    ///
    /// assert_eq!(a[&1], "a");
    /// assert_eq!(a[&2], "b");
    ///
    /// assert_eq!(b[&3], "c");
    /// assert_eq!(b[&17], "d");
    /// assert_eq!(b[&41], "e");
    /// ```
    #[stable(feature = "btree_split_off", since = "1.11.0")]
    pub fn split_off<Q: ?Sized + Ord>(&mut self, key: &Q) -> Self
    where
        K: Borrow<Q> + Ord,
    {
        if self.is_empty() {
            return Self::new();
        }

        let total_num = self.len();
        let left_root = self.root.as_mut().unwrap(); // ശൂന്യമല്ലാത്തതിനാൽ അൺ‌റാപ്പ് വിജയിക്കുന്നു

        let right_root = left_root.split_off(key);

        let (new_left_len, right_len) = Root::calc_split_length(total_num, &left_root, &right_root);
        self.length = new_left_len;

        BTreeMap { root: Some(right_root), length: right_len }
    }

    /// ആരോഹണ കീ ക്രമത്തിൽ എല്ലാ ഘടകങ്ങളും (കീ-മൂല്യ ജോഡികൾ) സന്ദർശിക്കുന്ന ഒരു ഇറ്ററേറ്റർ സൃഷ്‌ടിക്കുകയും ഒരു ഘടകം നീക്കംചെയ്യേണ്ടതുണ്ടോ എന്ന് നിർണ്ണയിക്കാൻ ഒരു അടയ്ക്കൽ ഉപയോഗിക്കുകയും ചെയ്യുന്നു.
    /// അടയ്ക്കൽ `true` നൽകുന്നുവെങ്കിൽ, ഘടകം മാപ്പിൽ നിന്ന് നീക്കംചെയ്യുകയും വിളവ് നൽകുകയും ചെയ്യുന്നു.
    /// അടയ്ക്കൽ `false`, അല്ലെങ്കിൽ panics നൽകുന്നുവെങ്കിൽ, ഘടകം മാപ്പിൽ നിലനിൽക്കും, അത് ലഭിക്കില്ല.
    ///
    /// അടയ്‌ക്കലിലെ ഓരോ ഘടകത്തിന്റെയും മൂല്യം പരിവർത്തനം ചെയ്യാനോ നീക്കംചെയ്യാനോ നിങ്ങൾ തീരുമാനിച്ചാലും പരിഗണിക്കാതെ തന്നെ, ആവർത്തനം നിങ്ങളെ അനുവദിക്കുന്നു.
    ///
    /// ഇറ്ററേറ്റർ ഭാഗികമായി മാത്രമേ ഉപയോഗിക്കുന്നുള്ളൂ അല്ലെങ്കിൽ ഉപഭോഗം ചെയ്യുന്നില്ലെങ്കിൽ, ശേഷിക്കുന്ന ഓരോ ഘടകങ്ങളും ഇപ്പോഴും അടയ്‌ക്കലിന് വിധേയമാണ്, അത് അതിന്റെ മൂല്യം മാറ്റുകയും `true` മടക്കിനൽകുന്നതിലൂടെ മൂലകം നീക്കം ചെയ്യുകയും ഉപേക്ഷിക്കുകയും ചെയ്യുന്നു.
    ///
    ///
    /// അടയ്‌ക്കുമ്പോൾ ഒരു panic സംഭവിക്കുകയോ അല്ലെങ്കിൽ ഒരു ഘടകം ഉപേക്ഷിക്കുമ്പോൾ ഒരു panic സംഭവിക്കുകയോ അല്ലെങ്കിൽ `DrainFilter` മൂല്യം ചോർന്നൊഴുകുകയോ ചെയ്താൽ എത്രയെത്ര ഘടകങ്ങൾ അടയ്‌ക്കലിന് വിധേയമാകുമെന്ന് വ്യക്തമല്ല.
    ///
    /// # Examples
    ///
    /// ഒരു മാപ്പ് ഇരട്ട, വിചിത്രമായ കീകളായി വിഭജിച്ച് യഥാർത്ഥ മാപ്പ് വീണ്ടും ഉപയോഗിക്കുന്നു:
    ///
    /// ```
    /// #![feature(btree_drain_filter)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut map: BTreeMap<i32, i32> = (0..8).map(|x| (x, x)).collect();
    /// let evens: BTreeMap<_, _> = map.drain_filter(|k, _v| k % 2 == 0).collect();
    /// let odds = map;
    /// assert_eq!(evens.keys().copied().collect::<Vec<_>>(), vec![0, 2, 4, 6]);
    /// assert_eq!(odds.keys().copied().collect::<Vec<_>>(), vec![1, 3, 5, 7]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "btree_drain_filter", issue = "70530")]
    pub fn drain_filter<F>(&mut self, pred: F) -> DrainFilter<'_, K, V, F>
    where
        K: Ord,
        F: FnMut(&K, &mut V) -> bool,
    {
        DrainFilter { pred, inner: self.drain_filter_inner() }
    }

    pub(super) fn drain_filter_inner(&mut self) -> DrainFilterInner<'_, K, V>
    where
        K: Ord,
    {
        if let Some(root) = self.root.as_mut() {
            let (root, dormant_root) = DormantMutRef::new(root);
            let front = root.borrow_mut().first_leaf_edge();
            DrainFilterInner {
                length: &mut self.length,
                dormant_root: Some(dormant_root),
                cur_leaf_edge: Some(front),
            }
        } else {
            DrainFilterInner { length: &mut self.length, dormant_root: None, cur_leaf_edge: None }
        }
    }

    /// അടുക്കിയ ക്രമത്തിൽ എല്ലാ കീകളും സന്ദർശിക്കുന്ന ഒരു ഉപഭോഗ ഇറ്ററേറ്റർ സൃഷ്ടിക്കുന്നു.
    /// ഇത് വിളിച്ചതിന് ശേഷം മാപ്പ് ഉപയോഗിക്കാൻ കഴിയില്ല.
    /// ആവർത്തന ഘടക തരം `K` ആണ്.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(map_into_keys_values)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(2, "b");
    /// a.insert(1, "a");
    ///
    /// let keys: Vec<i32> = a.into_keys().collect();
    /// assert_eq!(keys, [1, 2]);
    /// ```
    #[inline]
    #[unstable(feature = "map_into_keys_values", issue = "75294")]
    pub fn into_keys(self) -> IntoKeys<K, V> {
        IntoKeys { inner: self.into_iter() }
    }

    /// കീ അനുസരിച്ച് എല്ലാ മൂല്യങ്ങളും സന്ദർശിക്കുന്ന ഒരു ഉപഭോഗ ഇറ്ററേറ്റർ സൃഷ്ടിക്കുന്നു.
    /// ഇത് വിളിച്ചതിന് ശേഷം മാപ്പ് ഉപയോഗിക്കാൻ കഴിയില്ല.
    /// ആവർത്തന ഘടക തരം `V` ആണ്.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(map_into_keys_values)]
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "hello");
    /// a.insert(2, "goodbye");
    ///
    /// let values: Vec<&str> = a.into_values().collect();
    /// assert_eq!(values, ["hello", "goodbye"]);
    /// ```
    #[inline]
    #[unstable(feature = "map_into_keys_values", issue = "75294")]
    pub fn into_values(self) -> IntoValues<K, V> {
        IntoValues { inner: self.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> IntoIterator for &'a BTreeMap<K, V> {
    type Item = (&'a K, &'a V);
    type IntoIter = Iter<'a, K, V>;

    fn into_iter(self) -> Iter<'a, K, V> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K: 'a, V: 'a> Iterator for Iter<'a, K, V> {
    type Item = (&'a K, &'a V);

    fn next(&mut self) -> Option<(&'a K, &'a V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.next_unchecked() })
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.length, Some(self.length))
    }

    fn last(mut self) -> Option<(&'a K, &'a V)> {
        self.next_back()
    }

    fn min(mut self) -> Option<(&'a K, &'a V)> {
        self.next()
    }

    fn max(mut self) -> Option<(&'a K, &'a V)> {
        self.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for Iter<'_, K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K: 'a, V: 'a> DoubleEndedIterator for Iter<'a, K, V> {
    fn next_back(&mut self) -> Option<(&'a K, &'a V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.next_back_unchecked() })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for Iter<'_, K, V> {
    fn len(&self) -> usize {
        self.length
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> Clone for Iter<'_, K, V> {
    fn clone(&self) -> Self {
        Iter { range: self.range.clone(), length: self.length }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> IntoIterator for &'a mut BTreeMap<K, V> {
    type Item = (&'a K, &'a mut V);
    type IntoIter = IterMut<'a, K, V>;

    fn into_iter(self) -> IterMut<'a, K, V> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K: 'a, V: 'a> Iterator for IterMut<'a, K, V> {
    type Item = (&'a K, &'a mut V);

    fn next(&mut self) -> Option<(&'a K, &'a mut V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.next_unchecked() })
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.length, Some(self.length))
    }

    fn last(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next_back()
    }

    fn min(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next()
    }

    fn max(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K: 'a, V: 'a> DoubleEndedIterator for IterMut<'a, K, V> {
    fn next_back(&mut self) -> Option<(&'a K, &'a mut V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.next_back_unchecked() })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for IterMut<'_, K, V> {
    fn len(&self) -> usize {
        self.length
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for IterMut<'_, K, V> {}

impl<'a, K, V> IterMut<'a, K, V> {
    /// ശേഷിക്കുന്ന ഇനങ്ങളെക്കുറിച്ചുള്ള റഫറൻസുകളുടെ ഒരു ആവർത്തനം നൽകുന്നു.
    #[inline]
    pub(super) fn iter(&self) -> Iter<'_, K, V> {
        Iter { range: self.range.iter(), length: self.length }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> IntoIterator for BTreeMap<K, V> {
    type Item = (K, V);
    type IntoIter = IntoIter<K, V>;

    fn into_iter(self) -> IntoIter<K, V> {
        let mut me = ManuallyDrop::new(self);
        if let Some(root) = me.root.take() {
            let full_range = root.into_dying().full_range();

            IntoIter { range: full_range, length: me.length }
        } else {
            IntoIter { range: LeafRange::none(), length: 0 }
        }
    }
}

impl<K, V> Drop for Dropper<K, V> {
    fn drop(&mut self) {
        // നോൺ-ഫ്യൂസിംഗ് ഇറ്ററേറ്റർ മുന്നേറുന്നതിന് സമാനമാണ്.
        fn next_or_end<K, V>(this: &mut Dropper<K, V>) -> Option<(K, V)> {
            if this.remaining_length == 0 {
                unsafe { ptr::read(&this.front).deallocating_end() }
                None
            } else {
                this.remaining_length -= 1;
                Some(unsafe { this.front.deallocating_next_unchecked() })
            }
        }

        struct DropGuard<'a, K, V>(&'a mut Dropper<K, V>);

        impl<'a, K, V> Drop for DropGuard<'a, K, V> {
            fn drop(&mut self) {
                // ഞങ്ങൾ ചുവടെ ചെയ്യുന്ന അതേ ലൂപ്പ് തുടരുക.
                // ഇത് അൺ‌വൈൻഡ് ചെയ്യുമ്പോൾ മാത്രമേ പ്രവർത്തിക്കൂ, അതിനാൽ ഇത്തവണ panics നെക്കുറിച്ച് ഞങ്ങൾ ശ്രദ്ധിക്കേണ്ടതില്ല (അവ നിർത്തലാക്കും).
                while let Some(_pair) = next_or_end(&mut self.0) {}
            }
        }

        while let Some(pair) = next_or_end(self) {
            let guard = DropGuard(self);
            drop(pair);
            mem::forget(guard);
        }
    }
}

#[stable(feature = "btree_drop", since = "1.7.0")]
impl<K, V> Drop for IntoIter<K, V> {
    fn drop(&mut self) {
        if let Some(front) = self.range.front.take() {
            Dropper { front, remaining_length: self.length };
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> Iterator for IntoIter<K, V> {
    type Item = (K, V);

    fn next(&mut self) -> Option<(K, V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.front.as_mut().unwrap().deallocating_next_unchecked() })
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.length, Some(self.length))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> DoubleEndedIterator for IntoIter<K, V> {
    fn next_back(&mut self) -> Option<(K, V)> {
        if self.length == 0 {
            None
        } else {
            self.length -= 1;
            Some(unsafe { self.range.back.as_mut().unwrap().deallocating_next_back_unchecked() })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for IntoIter<K, V> {
    fn len(&self) -> usize {
        self.length
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for IntoIter<K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> Iterator for Keys<'a, K, V> {
    type Item = &'a K;

    fn next(&mut self) -> Option<&'a K> {
        self.inner.next().map(|(k, _)| k)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<&'a K> {
        self.next_back()
    }

    fn min(mut self) -> Option<&'a K> {
        self.next()
    }

    fn max(mut self) -> Option<&'a K> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> DoubleEndedIterator for Keys<'a, K, V> {
    fn next_back(&mut self) -> Option<&'a K> {
        self.inner.next_back().map(|(k, _)| k)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for Keys<'_, K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for Keys<'_, K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> Clone for Keys<'_, K, V> {
    fn clone(&self) -> Self {
        Keys { inner: self.inner.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> Iterator for Values<'a, K, V> {
    type Item = &'a V;

    fn next(&mut self) -> Option<&'a V> {
        self.inner.next().map(|(_, v)| v)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<&'a V> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, K, V> DoubleEndedIterator for Values<'a, K, V> {
    fn next_back(&mut self) -> Option<&'a V> {
        self.inner.next_back().map(|(_, v)| v)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> ExactSizeIterator for Values<'_, K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for Values<'_, K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, V> Clone for Values<'_, K, V> {
    fn clone(&self) -> Self {
        Values { inner: self.inner.clone() }
    }
}

/// BTreeMap-ൽ `drain_filter`-ൽ വിളിച്ച് നിർമ്മിച്ച ഒരു ഇറ്ററേറ്റർ.
#[unstable(feature = "btree_drain_filter", issue = "70530")]
pub struct DrainFilter<'a, K, V, F>
where
    K: 'a,
    V: 'a,
    F: 'a + FnMut(&K, &mut V) -> bool,
{
    pred: F,
    inner: DrainFilterInner<'a, K, V>,
}
/// ഡ്രെയിൻ‌ഫിൽ‌റ്റർ‌നടപ്പിലാക്കുന്നതിൽ‌മിക്കതും പ്രവചനാതീതമായതിനേക്കാൾ‌പൊതുവായതാണ്, അതിനാൽ‌BTreeSet::DrainFilter നായി സേവനം ചെയ്യുന്നു.
///
pub(super) struct DrainFilterInner<'a, K: 'a, V: 'a> {
    /// കടമെടുത്ത മാപ്പിലെ ദൈർഘ്യ ഫീൽഡിലേക്കുള്ള റഫറൻസ്, തത്സമയം അപ്‌ഡേറ്റുചെയ്‌തു.
    length: &'a mut usize,
    /// കടമെടുത്ത മാപ്പിലെ റൂട്ട് ഫീൽഡിലേക്കുള്ള റഫറൻസ്.
    /// ഡ്രോപ്പ് ഹാൻഡ്‌ലറിനെ `take` ലേക്ക് അനുവദിക്കുന്നതിന് `Option`-ൽ പൊതിഞ്ഞു.
    dormant_root: Option<DormantMutRef<'a, Root<K, V>>>,
    /// തിരികെ നൽകേണ്ട അടുത്ത ഘടകത്തിന് മുമ്പുള്ള edge അല്ലെങ്കിൽ അവസാന ഇല edge അടങ്ങിയിരിക്കുന്നു.
    /// മാപ്പിന് റൂട്ട് ഇല്ലെങ്കിൽ, ആവർത്തനം അവസാന ഇല edge എന്നതിനപ്പുറത്തേക്ക് പോയിട്ടുണ്ടെങ്കിൽ, അല്ലെങ്കിൽ പ്രവചനത്തിൽ ഒരു panic സംഭവിച്ചിട്ടുണ്ടെങ്കിൽ ശൂന്യമാണ്.
    ///
    cur_leaf_edge: Option<Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>>,
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<K, V, F> Drop for DrainFilter<'_, K, V, F>
where
    F: FnMut(&K, &mut V) -> bool,
{
    fn drop(&mut self) {
        self.for_each(drop);
    }
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<K, V, F> fmt::Debug for DrainFilter<'_, K, V, F>
where
    K: fmt::Debug,
    V: fmt::Debug,
    F: FnMut(&K, &mut V) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DrainFilter").field(&self.inner.peek()).finish()
    }
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<K, V, F> Iterator for DrainFilter<'_, K, V, F>
where
    F: FnMut(&K, &mut V) -> bool,
{
    type Item = (K, V);

    fn next(&mut self) -> Option<(K, V)> {
        self.inner.next(&mut self.pred)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

impl<'a, K: 'a, V: 'a> DrainFilterInner<'a, K, V> {
    /// അടുത്ത ഘടകം പ്രവചിക്കാൻ ഡീബഗ് നടപ്പാക്കലുകൾ അനുവദിക്കുക.
    pub(super) fn peek(&self) -> Option<(&K, &V)> {
        let edge = self.cur_leaf_edge.as_ref()?;
        edge.reborrow().next_kv().ok().map(Handle::into_kv)
    }

    /// പ്രവചനം അനുസരിച്ച് ഒരു സാധാരണ `DrainFilter::next` രീതി നടപ്പിലാക്കൽ.
    pub(super) fn next<F>(&mut self, pred: &mut F) -> Option<(K, V)>
    where
        F: FnMut(&K, &mut V) -> bool,
    {
        while let Ok(mut kv) = self.cur_leaf_edge.take()?.next_kv() {
            let (k, v) = kv.kv_mut();
            if pred(k, v) {
                *self.length -= 1;
                let (kv, pos) = kv.remove_kv_tracking(|| {
                    // സുരക്ഷ: അല്ലാത്ത രീതിയിൽ ഞങ്ങൾ റൂട്ട് സ്പർശിക്കും
                    // നൽകിയ സ്ഥാനം അസാധുവാക്കുക.
                    let root = unsafe { self.dormant_root.take().unwrap().awaken() };
                    root.pop_internal_level();
                    self.dormant_root = Some(DormantMutRef::new(root).1);
                });
                self.cur_leaf_edge = Some(pos);
                return Some(kv);
            }
            self.cur_leaf_edge = Some(kv.next_leaf_edge());
        }
        None
    }

    /// ഒരു സാധാരണ `DrainFilter::size_hint` രീതി നടപ്പിലാക്കൽ.
    pub(super) fn size_hint(&self) -> (usize, Option<usize>) {
        // മിക്ക btree ഇറ്ററേറ്ററുകളിലും, ഇതുവരെ സന്ദർശിക്കേണ്ട ഘടകങ്ങളുടെ എണ്ണമാണ് `self.length`.
        // ഇവിടെ, സന്ദർശിച്ച ഘടകങ്ങളും drain വേണ്ടെന്ന് പ്രവചിച്ച തീരുമാനവും ഇതിൽ ഉൾപ്പെടുന്നു.
        // ഈ മുകളിലെ പരിധി കൂടുതൽ കൃത്യമാക്കുന്നതിന് ഒരു അധിക ഫീൽഡ് പരിപാലിക്കേണ്ടതുണ്ട്, അത് വിലമതിക്കുന്നില്ല.
        //
        (0, Some(*self.length))
    }
}

#[unstable(feature = "btree_drain_filter", issue = "70530")]
impl<K, V, F> FusedIterator for DrainFilter<'_, K, V, F> where F: FnMut(&K, &mut V) -> bool {}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<'a, K, V> Iterator for Range<'a, K, V> {
    type Item = (&'a K, &'a V);

    fn next(&mut self) -> Option<(&'a K, &'a V)> {
        if self.inner.is_empty() { None } else { Some(unsafe { self.next_unchecked() }) }
    }

    fn last(mut self) -> Option<(&'a K, &'a V)> {
        self.next_back()
    }

    fn min(mut self) -> Option<(&'a K, &'a V)> {
        self.next()
    }

    fn max(mut self) -> Option<(&'a K, &'a V)> {
        self.next_back()
    }
}

#[stable(feature = "map_values_mut", since = "1.10.0")]
impl<'a, K, V> Iterator for ValuesMut<'a, K, V> {
    type Item = &'a mut V;

    fn next(&mut self) -> Option<&'a mut V> {
        self.inner.next().map(|(_, v)| v)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<&'a mut V> {
        self.next_back()
    }
}

#[stable(feature = "map_values_mut", since = "1.10.0")]
impl<'a, K, V> DoubleEndedIterator for ValuesMut<'a, K, V> {
    fn next_back(&mut self) -> Option<&'a mut V> {
        self.inner.next_back().map(|(_, v)| v)
    }
}

#[stable(feature = "map_values_mut", since = "1.10.0")]
impl<K, V> ExactSizeIterator for ValuesMut<'_, K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for ValuesMut<'_, K, V> {}

impl<'a, K, V> Range<'a, K, V> {
    unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        unsafe { self.inner.front.as_mut().unwrap_unchecked().next_unchecked() }
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> Iterator for IntoKeys<K, V> {
    type Item = K;

    fn next(&mut self) -> Option<K> {
        self.inner.next().map(|(k, _)| k)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<K> {
        self.next_back()
    }

    fn min(mut self) -> Option<K> {
        self.next()
    }

    fn max(mut self) -> Option<K> {
        self.next_back()
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> DoubleEndedIterator for IntoKeys<K, V> {
    fn next_back(&mut self) -> Option<K> {
        self.inner.next_back().map(|(k, _)| k)
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> ExactSizeIterator for IntoKeys<K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> FusedIterator for IntoKeys<K, V> {}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> Iterator for IntoValues<K, V> {
    type Item = V;

    fn next(&mut self) -> Option<V> {
        self.inner.next().map(|(_, v)| v)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }

    fn last(mut self) -> Option<V> {
        self.next_back()
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> DoubleEndedIterator for IntoValues<K, V> {
    fn next_back(&mut self) -> Option<V> {
        self.inner.next_back().map(|(_, v)| v)
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> ExactSizeIterator for IntoValues<K, V> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "map_into_keys_values", issue = "75294")]
impl<K, V> FusedIterator for IntoValues<K, V> {}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<'a, K, V> DoubleEndedIterator for Range<'a, K, V> {
    fn next_back(&mut self) -> Option<(&'a K, &'a V)> {
        if self.inner.is_empty() { None } else { Some(unsafe { self.next_back_unchecked() }) }
    }
}

impl<'a, K, V> Range<'a, K, V> {
    unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        unsafe { self.inner.back.as_mut().unwrap_unchecked().next_back_unchecked() }
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for Range<'_, K, V> {}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<K, V> Clone for Range<'_, K, V> {
    fn clone(&self) -> Self {
        Range { inner: LeafRange { front: self.inner.front, back: self.inner.back } }
    }
}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<'a, K, V> Iterator for RangeMut<'a, K, V> {
    type Item = (&'a K, &'a mut V);

    fn next(&mut self) -> Option<(&'a K, &'a mut V)> {
        if self.inner.is_empty() { None } else { Some(unsafe { self.next_unchecked() }) }
    }

    fn last(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next_back()
    }

    fn min(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next()
    }

    fn max(mut self) -> Option<(&'a K, &'a mut V)> {
        self.next_back()
    }
}

impl<'a, K, V> RangeMut<'a, K, V> {
    unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        unsafe { self.inner.front.as_mut().unwrap_unchecked().next_unchecked() }
    }

    /// ശേഷിക്കുന്ന ഇനങ്ങളെക്കുറിച്ചുള്ള റഫറൻസുകളുടെ ഒരു ആവർത്തനം നൽകുന്നു.
    #[inline]
    pub(super) fn iter(&self) -> Range<'_, K, V> {
        Range { inner: self.inner.reborrow() }
    }
}

#[stable(feature = "btree_range", since = "1.17.0")]
impl<'a, K, V> DoubleEndedIterator for RangeMut<'a, K, V> {
    fn next_back(&mut self) -> Option<(&'a K, &'a mut V)> {
        if self.inner.is_empty() { None } else { Some(unsafe { self.next_back_unchecked() }) }
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<K, V> FusedIterator for RangeMut<'_, K, V> {}

impl<'a, K, V> RangeMut<'a, K, V> {
    unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        unsafe { self.inner.back.as_mut().unwrap_unchecked().next_back_unchecked() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Ord, V> FromIterator<(K, V)> for BTreeMap<K, V> {
    fn from_iter<T: IntoIterator<Item = (K, V)>>(iter: T) -> BTreeMap<K, V> {
        let mut map = BTreeMap::new();
        map.extend(iter);
        map
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Ord, V> Extend<(K, V)> for BTreeMap<K, V> {
    #[inline]
    fn extend<T: IntoIterator<Item = (K, V)>>(&mut self, iter: T) {
        iter.into_iter().for_each(move |(k, v)| {
            self.insert(k, v);
        });
    }

    #[inline]
    fn extend_one(&mut self, (k, v): (K, V)) {
        self.insert(k, v);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, K: Ord + Copy, V: Copy> Extend<(&'a K, &'a V)> for BTreeMap<K, V> {
    fn extend<I: IntoIterator<Item = (&'a K, &'a V)>>(&mut self, iter: I) {
        self.extend(iter.into_iter().map(|(&key, &value)| (key, value)));
    }

    #[inline]
    fn extend_one(&mut self, (&k, &v): (&'a K, &'a V)) {
        self.insert(k, v);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Hash, V: Hash> Hash for BTreeMap<K, V> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        for elt in self {
            elt.hash(state);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Ord, V> Default for BTreeMap<K, V> {
    /// ഒരു ശൂന്യമായ `BTreeMap` സൃഷ്ടിക്കുന്നു.
    fn default() -> BTreeMap<K, V> {
        BTreeMap::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: PartialEq, V: PartialEq> PartialEq for BTreeMap<K, V> {
    fn eq(&self, other: &BTreeMap<K, V>) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a == b)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Eq, V: Eq> Eq for BTreeMap<K, V> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: PartialOrd, V: PartialOrd> PartialOrd for BTreeMap<K, V> {
    #[inline]
    fn partial_cmp(&self, other: &BTreeMap<K, V>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Ord, V: Ord> Ord for BTreeMap<K, V> {
    #[inline]
    fn cmp(&self, other: &BTreeMap<K, V>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K: Debug, V: Debug> Debug for BTreeMap<K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_map().entries(self.iter()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<K, Q: ?Sized, V> Index<&Q> for BTreeMap<K, V>
where
    K: Borrow<Q> + Ord,
    Q: Ord,
{
    type Output = V;

    /// വിതരണം ചെയ്ത കീയുമായി ബന്ധപ്പെട്ട മൂല്യത്തിലേക്ക് ഒരു റഫറൻസ് നൽകുന്നു.
    ///
    /// # Panics
    ///
    /// `BTreeMap`-ൽ കീ ഇല്ലെങ്കിൽ Panics.
    #[inline]
    fn index(&self, key: &Q) -> &V {
        self.get(key).expect("no entry found for key")
    }
}

impl<K, V> BTreeMap<K, V> {
    /// കീ ഉപയോഗിച്ച് അടുക്കിയ മാപ്പിന്റെ എൻ‌ട്രികൾക്ക് മുകളിലൂടെ ഒരു ഇറ്ററേറ്റർ ലഭിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert(3, "c");
    /// map.insert(2, "b");
    /// map.insert(1, "a");
    ///
    /// for (key, value) in map.iter() {
    ///     println!("{}: {}", key, value);
    /// }
    ///
    /// let (first_key, first_value) = map.iter().next().unwrap();
    /// assert_eq!((*first_key, *first_value), (1, "a"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, K, V> {
        if let Some(root) = &self.root {
            let full_range = root.reborrow().full_range();

            Iter { range: Range { inner: full_range }, length: self.length }
        } else {
            Iter { range: Range { inner: LeafRange::none() }, length: 0 }
        }
    }

    /// കീ ഉപയോഗിച്ച് അടുക്കിയ മാപ്പിന്റെ എൻ‌ട്രികൾ‌ക്ക് മുകളിൽ‌ഒരു മ്യൂട്ടബിൾ‌ഇറ്ററേറ്റർ‌ലഭിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut map = BTreeMap::new();
    /// map.insert("a", 1);
    /// map.insert("b", 2);
    /// map.insert("c", 3);
    ///
    /// // കീ "a" അല്ലെങ്കിൽ മൂല്യത്തിലേക്ക് 10 ചേർക്കുക
    /// for (key, value) in map.iter_mut() {
    ///     if key != &"a" {
    ///         *value += 10;
    ///     }
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, K, V> {
        if let Some(root) = &mut self.root {
            let full_range = root.borrow_valmut().full_range();

            IterMut {
                range: RangeMut { inner: full_range, _marker: PhantomData },
                length: self.length,
            }
        } else {
            IterMut {
                range: RangeMut { inner: LeafRange::none(), _marker: PhantomData },
                length: 0,
            }
        }
    }

    /// അടുക്കിയ ക്രമത്തിൽ മാപ്പിന്റെ കീകൾക്ക് മുകളിലൂടെ ഒരു ഇറ്ററേറ്റർ ലഭിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(2, "b");
    /// a.insert(1, "a");
    ///
    /// let keys: Vec<_> = a.keys().cloned().collect();
    /// assert_eq!(keys, [1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn keys(&self) -> Keys<'_, K, V> {
        Keys { inner: self.iter() }
    }

    /// കീ അനുസരിച്ച് ക്രമത്തിൽ മാപ്പിന്റെ മൂല്യങ്ങളിൽ ഒരു ഇറ്ററേറ്റർ ലഭിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, "hello");
    /// a.insert(2, "goodbye");
    ///
    /// let values: Vec<&str> = a.values().cloned().collect();
    /// assert_eq!(values, ["hello", "goodbye"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn values(&self) -> Values<'_, K, V> {
        Values { inner: self.iter() }
    }

    /// കീ അനുസരിച്ച് ക്രമത്തിൽ മാപ്പിന്റെ മൂല്യങ്ങളിൽ ഒരു മ്യൂട്ടബിൾ ഇറ്ററേറ്റർ ലഭിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// a.insert(1, String::from("hello"));
    /// a.insert(2, String::from("goodbye"));
    ///
    /// for value in a.values_mut() {
    ///     value.push_str("!");
    /// }
    ///
    /// let values: Vec<String> = a.values().cloned().collect();
    /// assert_eq!(values, [String::from("hello!"),
    ///                     String::from("goodbye!")]);
    /// ```
    #[stable(feature = "map_values_mut", since = "1.10.0")]
    pub fn values_mut(&mut self) -> ValuesMut<'_, K, V> {
        ValuesMut { inner: self.iter_mut() }
    }

    /// മാപ്പിലെ ഘടകങ്ങളുടെ എണ്ണം നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// assert_eq!(a.len(), 0);
    /// a.insert(1, "a");
    /// assert_eq!(a.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_btree_new", issue = "71835")]
    pub const fn len(&self) -> usize {
        self.length
    }

    /// മാപ്പിൽ ഘടകങ്ങളൊന്നുമില്ലെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BTreeMap;
    ///
    /// let mut a = BTreeMap::new();
    /// assert!(a.is_empty());
    /// a.insert(1, "a");
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_btree_new", issue = "71835")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// റൂട്ട് നോഡ് ശൂന്യമായ (non-allocated) റൂട്ട് നോഡാണെങ്കിൽ, ഞങ്ങളുടെ സ്വന്തം നോഡ് അനുവദിക്കുക.
    /// മുഴുവൻ BTreeMap കടം വാങ്ങുന്നത് ഒഴിവാക്കുന്നതിനുള്ള ഒരു അനുബന്ധ പ്രവർത്തനമാണ്.
    fn ensure_is_owned(root: &mut Option<Root<K, V>>) -> &mut Root<K, V> {
        root.get_or_insert_with(Root::new)
    }
}

#[cfg(test)]
mod tests;