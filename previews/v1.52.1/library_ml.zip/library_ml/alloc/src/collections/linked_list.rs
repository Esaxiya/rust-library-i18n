//! ഉടമസ്ഥതയിലുള്ള നോഡുകളുള്ള ഇരട്ട-ലിങ്കുചെയ്‌ത ലിസ്റ്റ്.
//!
//! സ്ഥിരമായ സമയത്ത് ഇരുവശത്തും ഘടകങ്ങൾ തള്ളുന്നതിനും പോപ്പുചെയ്യുന്നതിനും `LinkedList` അനുവദിക്കുന്നു.
//!
//! NOTE: [`Vec`] അല്ലെങ്കിൽ [`VecDeque`] ഉപയോഗിക്കുന്നത് എല്ലായ്പ്പോഴും നല്ലതാണ്, കാരണം അറേ അടിസ്ഥാനമാക്കിയുള്ള കണ്ടെയ്നറുകൾ സാധാരണയായി വേഗതയുള്ളതും കൂടുതൽ മെമ്മറി കാര്യക്ഷമവുമാണ്, കൂടാതെ സിപിയു കാഷെ നന്നായി ഉപയോഗിക്കുകയും ചെയ്യുന്നു.
//!
//!
//! [`Vec`]: crate::vec::Vec
//! [`VecDeque`]: super::vec_deque::VecDeque
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::Ordering;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{FromIterator, FusedIterator};
use core::marker::PhantomData;
use core::mem;
use core::ptr::NonNull;

use super::SpecExtend;
use crate::boxed::Box;

#[cfg(test)]
mod tests;

/// ഉടമസ്ഥതയിലുള്ള നോഡുകളുള്ള ഇരട്ട-ലിങ്കുചെയ്‌ത ലിസ്റ്റ്.
///
/// സ്ഥിരമായ സമയത്ത് ഇരുവശത്തും ഘടകങ്ങൾ തള്ളുന്നതിനും പോപ്പുചെയ്യുന്നതിനും `LinkedList` അനുവദിക്കുന്നു.
///
/// NOTE: `Vec` അല്ലെങ്കിൽ `VecDeque` ഉപയോഗിക്കുന്നത് എല്ലായ്പ്പോഴും നല്ലതാണ്, കാരണം അറേ അടിസ്ഥാനമാക്കിയുള്ള കണ്ടെയ്നറുകൾ സാധാരണയായി വേഗതയുള്ളതും കൂടുതൽ മെമ്മറി കാര്യക്ഷമവുമാണ്, കൂടാതെ സിപിയു കാഷെ നന്നായി ഉപയോഗിക്കുകയും ചെയ്യുന്നു.
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "LinkedList")]
pub struct LinkedList<T> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<Box<Node<T>>>,
}

struct Node<T> {
    next: Option<NonNull<Node<T>>>,
    prev: Option<NonNull<Node<T>>>,
    element: T,
}

/// ഒരു `LinkedList` ന്റെ ഘടകങ്ങൾക്ക് മുകളിലുള്ള ഒരു ആവർത്തനം.
///
/// ഈ `struct` സൃഷ്ടിച്ചത് [`LinkedList::iter()`] ആണ്.
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
    marker: PhantomData<&'a Node<T>>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.len).finish()
    }
}

// FIXME(#26925) `#[derive(Clone)]` ന് അനുകൂലമായി നീക്കംചെയ്യുക
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { ..*self }
    }
}

/// ഒരു `LinkedList` ന്റെ ഘടകങ്ങൾക്ക് മുകളിലുള്ള ഒരു മ്യൂട്ടബിൾ ഇറ്ററേറ്റർ.
///
/// ഈ `struct` സൃഷ്ടിച്ചത് [`LinkedList::iter_mut()`] ആണ്.
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IterMut<'a, T: 'a> {
    // ഞങ്ങൾ‌ക്ക് ഇവിടെ മുഴുവൻ‌പട്ടികയും സ്വന്തമായി ഇല്ല, നോഡിന്റെ `element` നെക്കുറിച്ചുള്ള റഫറൻ‌സുകൾ‌ഇറ്ററേറ്റർ‌കൈമാറി!അതിനാൽ ഇത് ഉപയോഗിക്കുമ്പോൾ ശ്രദ്ധിക്കുക;`element`-ലേക്ക് അപരനാമം പോയിന്ററുകൾ ഉണ്ടെന്ന് വിളിക്കുന്ന രീതികൾ അറിഞ്ഞിരിക്കണം.
    //
    //
    list: &'a mut LinkedList<T>,
    head: Option<NonNull<Node<T>>>,
    tail: Option<NonNull<Node<T>>>,
    len: usize,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IterMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IterMut").field(&self.list).field(&self.len).finish()
    }
}

/// ഒരു `LinkedList` ന്റെ ഘടകങ്ങളെക്കാൾ സ്വന്തമായ ഒരു ഇറ്ററേറ്റർ.
///
/// [`LinkedList`]-ലെ [`into_iter`] രീതി ഉപയോഗിച്ചാണ് ഈ `struct` സൃഷ്ടിച്ചിരിക്കുന്നത് (`IntoIterator` trait നൽകിയതാണ്).
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// [`into_iter`]: LinkedList::into_iter
#[derive(Clone)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<T> {
    list: LinkedList<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.list).finish()
    }
}

impl<T> Node<T> {
    fn new(element: T) -> Self {
        Node { next: None, prev: None, element }
    }

    fn into_element(self: Box<Self>) -> T {
        self.element
    }
}

// സ്വകാര്യ രീതികൾ
impl<T> LinkedList<T> {
    /// തന്നിരിക്കുന്ന നോഡ് പട്ടികയുടെ മുൻവശത്ത് ചേർക്കുന്നു.
    #[inline]
    fn push_front_node(&mut self, mut node: Box<Node<T>>) {
        // മുഴുവൻ നോഡുകളിലേക്കും മ്യൂട്ടബിൾ റഫറൻസുകൾ സൃഷ്ടിക്കാതിരിക്കാനും `element`-ലേക്ക് അലിയാസിംഗ് പോയിന്ററുകളുടെ സാധുത നിലനിർത്താനും ഈ രീതി ശ്രദ്ധിക്കുന്നു.
        //
        unsafe {
            node.next = self.head;
            node.prev = None;
            let node = Some(Box::leak(node).into());

            match self.head {
                None => self.tail = node,
                // `element` ഓവർലാപ്പുചെയ്യുന്ന പുതിയ മ്യൂട്ടബിൾ (unique!) റഫറൻസുകൾ സൃഷ്‌ടിക്കുന്നില്ല.
                Some(head) => (*head.as_ptr()).prev = node,
            }

            self.head = node;
            self.len += 1;
        }
    }

    /// ലിസ്റ്റിന്റെ മുൻവശത്തുള്ള നോഡ് നീക്കംചെയ്യുകയും തിരികെ നൽകുകയും ചെയ്യുന്നു.
    #[inline]
    fn pop_front_node(&mut self) -> Option<Box<Node<T>>> {
        // മുഴുവൻ നോഡുകളിലേക്കും മ്യൂട്ടബിൾ റഫറൻസുകൾ സൃഷ്ടിക്കാതിരിക്കാനും `element`-ലേക്ക് അലിയാസിംഗ് പോയിന്ററുകളുടെ സാധുത നിലനിർത്താനും ഈ രീതി ശ്രദ്ധിക്കുന്നു.
        //
        self.head.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.head = node.next;

            match self.head {
                None => self.tail = None,
                // `element` ഓവർലാപ്പുചെയ്യുന്ന പുതിയ മ്യൂട്ടബിൾ (unique!) റഫറൻസുകൾ സൃഷ്‌ടിക്കുന്നില്ല.
                Some(head) => (*head.as_ptr()).prev = None,
            }

            self.len -= 1;
            node
        })
    }

    /// തന്നിരിക്കുന്ന നോഡ് പട്ടികയുടെ പിന്നിലേക്ക് ചേർക്കുന്നു.
    #[inline]
    fn push_back_node(&mut self, mut node: Box<Node<T>>) {
        // മുഴുവൻ നോഡുകളിലേക്കും മ്യൂട്ടബിൾ റഫറൻസുകൾ സൃഷ്ടിക്കാതിരിക്കാനും `element`-ലേക്ക് അലിയാസിംഗ് പോയിന്ററുകളുടെ സാധുത നിലനിർത്താനും ഈ രീതി ശ്രദ്ധിക്കുന്നു.
        //
        unsafe {
            node.next = None;
            node.prev = self.tail;
            let node = Some(Box::leak(node).into());

            match self.tail {
                None => self.head = node,
                // `element` ഓവർലാപ്പുചെയ്യുന്ന പുതിയ മ്യൂട്ടബിൾ (unique!) റഫറൻസുകൾ സൃഷ്‌ടിക്കുന്നില്ല.
                Some(tail) => (*tail.as_ptr()).next = node,
            }

            self.tail = node;
            self.len += 1;
        }
    }

    /// ലിസ്റ്റിന്റെ പുറകിലുള്ള നോഡ് നീക്കംചെയ്യുകയും തിരികെ നൽകുകയും ചെയ്യുന്നു.
    #[inline]
    fn pop_back_node(&mut self) -> Option<Box<Node<T>>> {
        // മുഴുവൻ നോഡുകളിലേക്കും മ്യൂട്ടബിൾ റഫറൻസുകൾ സൃഷ്ടിക്കാതിരിക്കാനും `element`-ലേക്ക് അലിയാസിംഗ് പോയിന്ററുകളുടെ സാധുത നിലനിർത്താനും ഈ രീതി ശ്രദ്ധിക്കുന്നു.
        //
        self.tail.map(|node| unsafe {
            let node = Box::from_raw(node.as_ptr());
            self.tail = node.prev;

            match self.tail {
                None => self.head = None,
                // `element` ഓവർലാപ്പുചെയ്യുന്ന പുതിയ മ്യൂട്ടബിൾ (unique!) റഫറൻസുകൾ സൃഷ്‌ടിക്കുന്നില്ല.
                Some(tail) => (*tail.as_ptr()).next = None,
            }

            self.len -= 1;
            node
        })
    }

    /// നിലവിലെ ലിസ്റ്റിൽ നിന്ന് നിർദ്ദിഷ്ട നോഡ് അൺലിങ്ക് ചെയ്യുന്നു.
    ///
    /// മുന്നറിയിപ്പ്: നൽകിയ നോഡ് നിലവിലെ പട്ടികയിലേതാണെന്ന് ഇത് പരിശോധിക്കില്ല.
    ///
    /// അപരനാമം പോയിന്ററുകളുടെ സാധുത നിലനിർത്തുന്നതിന്, `element`-ലേക്ക് മ്യൂട്ടബിൾ റഫറൻസുകൾ സൃഷ്ടിക്കാതിരിക്കാൻ ഈ രീതി ശ്രദ്ധിക്കുന്നു.
    ///
    #[inline]
    unsafe fn unlink_node(&mut self, mut node: NonNull<Node<T>>) {
        let node = unsafe { node.as_mut() }; // ഇത് ഇപ്പോൾ നമ്മുടേതാണ്, ഞങ്ങൾക്ക് ഒരു &mut സൃഷ്ടിക്കാൻ കഴിയും.

        // `element` ഓവർലാപ്പുചെയ്യുന്ന പുതിയ മ്യൂട്ടബിൾ (unique!) റഫറൻസുകൾ സൃഷ്‌ടിക്കുന്നില്ല.
        match node.prev {
            Some(prev) => unsafe { (*prev.as_ptr()).next = node.next },
            // ഈ നോഡ് ഹെഡ് നോഡാണ്
            None => self.head = node.next,
        };

        match node.next {
            Some(next) => unsafe { (*next.as_ptr()).prev = node.prev },
            // ഈ നോഡ് ടെയിൽ നോഡാണ്
            None => self.tail = node.prev,
        };

        self.len -= 1;
    }

    /// നിലവിലുള്ള രണ്ട് നോഡുകൾക്കിടയിൽ ഒരു കൂട്ടം നോഡുകൾ വിഭജിക്കുന്നു.
    ///
    /// മുന്നറിയിപ്പ്: നൽകിയിരിക്കുന്ന നോഡ് നിലവിലുള്ള രണ്ട് ലിസ്റ്റുകളുടേതാണെന്ന് ഇത് പരിശോധിക്കില്ല.
    #[inline]
    unsafe fn splice_nodes(
        &mut self,
        existing_prev: Option<NonNull<Node<T>>>,
        existing_next: Option<NonNull<Node<T>>>,
        mut splice_start: NonNull<Node<T>>,
        mut splice_end: NonNull<Node<T>>,
        splice_length: usize,
    ) {
        // ഒരേ സമയം മുഴുവൻ നോഡുകളിലേക്കും ഒന്നിലധികം മ്യൂട്ടബിൾ റഫറൻസുകൾ സൃഷ്ടിക്കാതിരിക്കാനും `element`-ലേക്ക് അപരനാമം പോയിന്ററുകളുടെ സാധുത നിലനിർത്താനും ഈ രീതി ശ്രദ്ധിക്കുന്നു.
        //
        if let Some(mut existing_prev) = existing_prev {
            unsafe {
                existing_prev.as_mut().next = Some(splice_start);
            }
        } else {
            self.head = Some(splice_start);
        }
        if let Some(mut existing_next) = existing_next {
            unsafe {
                existing_next.as_mut().prev = Some(splice_end);
            }
        } else {
            self.tail = Some(splice_end);
        }
        unsafe {
            splice_start.as_mut().prev = existing_prev;
            splice_end.as_mut().next = existing_next;
        }

        self.len += splice_length;
    }

    /// ലിങ്കുചെയ്‌ത ലിസ്റ്റിൽ നിന്ന് എല്ലാ നോഡുകളെയും ഒരു കൂട്ടം നോഡുകളായി വേർതിരിക്കുന്നു.
    #[inline]
    fn detach_all_nodes(mut self) -> Option<(NonNull<Node<T>>, NonNull<Node<T>>, usize)> {
        let head = self.head.take();
        let tail = self.tail.take();
        let len = mem::replace(&mut self.len, 0);
        if let Some(head) = head {
            let tail = tail.unwrap_or_else(|| unsafe { core::hint::unreachable_unchecked() });
            Some((head, tail, len))
        } else {
            None
        }
    }

    #[inline]
    unsafe fn split_off_before_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // സ്പ്ലിറ്റ് നോഡ് രണ്ടാം ഭാഗത്തിന്റെ പുതിയ ഹെഡ് നോഡാണ്
        if let Some(mut split_node) = split_node {
            let first_part_head;
            let first_part_tail;
            unsafe {
                first_part_tail = split_node.as_mut().prev.take();
            }
            if let Some(mut tail) = first_part_tail {
                unsafe {
                    tail.as_mut().next = None;
                }
                first_part_head = self.head;
            } else {
                first_part_head = None;
            }

            let first_part = LinkedList {
                head: first_part_head,
                tail: first_part_tail,
                len: at,
                marker: PhantomData,
            };

            // രണ്ടാം ഭാഗത്തിന്റെ ഹെഡ് പി‌ടി‌ആർ പരിഹരിക്കുക
            self.head = Some(split_node);
            self.len = self.len - at;

            first_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }

    #[inline]
    unsafe fn split_off_after_node(
        &mut self,
        split_node: Option<NonNull<Node<T>>>,
        at: usize,
    ) -> Self {
        // സ്പ്ലിറ്റ് നോഡ് ആദ്യ ഭാഗത്തിന്റെ പുതിയ ടെയിൽ നോഡാണ്, കൂടാതെ രണ്ടാം ഭാഗത്തിന്റെ തലയും സ്വന്തമാക്കി.
        //
        if let Some(mut split_node) = split_node {
            let second_part_head;
            let second_part_tail;
            unsafe {
                second_part_head = split_node.as_mut().next.take();
            }
            if let Some(mut head) = second_part_head {
                unsafe {
                    head.as_mut().prev = None;
                }
                second_part_tail = self.tail;
            } else {
                second_part_tail = None;
            }

            let second_part = LinkedList {
                head: second_part_head,
                tail: second_part_tail,
                len: self.len - at,
                marker: PhantomData,
            };

            // ആദ്യ ഭാഗത്തിന്റെ വാൽ ptr പരിഹരിക്കുക
            self.tail = Some(split_node);
            self.len = at;

            second_part
        } else {
            mem::replace(self, LinkedList::new())
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for LinkedList<T> {
    /// ഒരു ശൂന്യമായ `LinkedList<T>` സൃഷ്ടിക്കുന്നു.
    #[inline]
    fn default() -> Self {
        Self::new()
    }
}

impl<T> LinkedList<T> {
    /// ഒരു ശൂന്യമായ `LinkedList` സൃഷ്ടിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let list: LinkedList<u32> = LinkedList::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_linked_list_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        LinkedList { head: None, tail: None, len: 0, marker: PhantomData }
    }

    /// എല്ലാ ഘടകങ്ങളും `other` ൽ നിന്ന് പട്ടികയുടെ അവസാനം വരെ നീക്കുന്നു.
    ///
    /// ഇത് `other`-ൽ നിന്ന് എല്ലാ നോഡുകളും വീണ്ടും ഉപയോഗിക്കുകയും അവയെ `self`-ലേക്ക് നീക്കുകയും ചെയ്യുന്നു.
    /// ഈ പ്രവർത്തനത്തിന് ശേഷം, `other` ശൂന്യമാകും.
    ///
    /// ഈ പ്രവർത്തനം *O*(1) സമയത്തിലും *O*(1) മെമ്മറിയിലും കണക്കാക്കണം.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list1 = LinkedList::new();
    /// list1.push_back('a');
    ///
    /// let mut list2 = LinkedList::new();
    /// list2.push_back('b');
    /// list2.push_back('c');
    ///
    /// list1.append(&mut list2);
    ///
    /// let mut iter = list1.iter();
    /// assert_eq!(iter.next(), Some(&'a'));
    /// assert_eq!(iter.next(), Some(&'b'));
    /// assert_eq!(iter.next(), Some(&'c'));
    /// assert!(iter.next().is_none());
    ///
    /// assert!(list2.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn append(&mut self, other: &mut Self) {
        match self.tail {
            None => mem::swap(self, other),
            Some(mut tail) => {
                // `as_mut` രണ്ട് ലിസ്റ്റുകളിലേക്കും ഞങ്ങൾക്ക് എക്സ്ക്ലൂസീവ് ആക്സസ് ഉള്ളതിനാൽ ഇവിടെ കുഴപ്പമില്ല.
                //
                if let Some(mut other_head) = other.head.take() {
                    unsafe {
                        tail.as_mut().next = Some(other_head);
                        other_head.as_mut().prev = Some(tail);
                    }

                    self.tail = other.tail.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// എല്ലാ ഘടകങ്ങളും `other` ൽ നിന്ന് പട്ടികയുടെ ആരംഭത്തിലേക്ക് നീക്കുന്നു.
    #[unstable(feature = "linked_list_prepend", issue = "none")]
    pub fn prepend(&mut self, other: &mut Self) {
        match self.head {
            None => mem::swap(self, other),
            Some(mut head) => {
                // `as_mut` രണ്ട് ലിസ്റ്റുകളിലേക്കും ഞങ്ങൾക്ക് എക്സ്ക്ലൂസീവ് ആക്സസ് ഉള്ളതിനാൽ ഇവിടെ കുഴപ്പമില്ല.
                //
                if let Some(mut other_tail) = other.tail.take() {
                    unsafe {
                        head.as_mut().prev = Some(other_tail);
                        other_tail.as_mut().next = Some(head);
                    }

                    self.head = other.head.take();
                    self.len += mem::replace(&mut other.len, 0);
                }
            }
        }
    }

    /// ഒരു ഫോർ‌വേർ‌ഡ് ഇറ്ററേറ്റർ‌നൽ‌കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { head: self.head, tail: self.tail, len: self.len, marker: PhantomData }
    }

    /// മ്യൂട്ടബിൾ റഫറൻസുകളുള്ള ഒരു ഫോർവേഡ് ഇറ്ററേറ്റർ നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// for element in list.iter_mut() {
    ///     *element += 10;
    /// }
    ///
    /// let mut iter = list.iter();
    /// assert_eq!(iter.next(), Some(&10));
    /// assert_eq!(iter.next(), Some(&11));
    /// assert_eq!(iter.next(), Some(&12));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut { head: self.head, tail: self.tail, len: self.len, list: self }
    }

    /// മുൻവശത്തെ ഘടകത്തിൽ ഒരു കഴ്‌സർ നൽകുന്നു.
    ///
    /// പട്ടിക ശൂന്യമാണെങ്കിൽ കഴ്‌സർ "ghost" നോൺ-എലമെന്റിലേക്ക് പോയിന്റുചെയ്യുന്നു.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front(&self) -> Cursor<'_, T> {
        Cursor { index: 0, current: self.head, list: self }
    }

    /// ഫ്രണ്ട് എലമെൻറിൽ‌എഡിറ്റിംഗ് പ്രവർ‌ത്തനങ്ങളുള്ള ഒരു കഴ്‌സർ‌നൽ‌കുന്നു.
    ///
    /// പട്ടിക ശൂന്യമാണെങ്കിൽ കഴ്‌സർ "ghost" നോൺ-എലമെന്റിലേക്ക് പോയിന്റുചെയ്യുന്നു.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_front_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: 0, current: self.head, list: self }
    }

    /// പിന്നിലെ ഘടകത്തിൽ ഒരു കഴ്‌സർ നൽകുന്നു.
    ///
    /// പട്ടിക ശൂന്യമാണെങ്കിൽ കഴ്‌സർ "ghost" നോൺ-എലമെന്റിലേക്ക് പോയിന്റുചെയ്യുന്നു.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back(&self) -> Cursor<'_, T> {
        Cursor { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// പിന്നിലെ ഘടകത്തിൽ എഡിറ്റിംഗ് പ്രവർത്തനങ്ങൾ ഉള്ള ഒരു കഴ്‌സർ നൽകുന്നു.
    ///
    /// പട്ടിക ശൂന്യമാണെങ്കിൽ കഴ്‌സർ "ghost" നോൺ-എലമെന്റിലേക്ക് പോയിന്റുചെയ്യുന്നു.
    #[inline]
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn cursor_back_mut(&mut self) -> CursorMut<'_, T> {
        CursorMut { index: self.len.checked_sub(1).unwrap_or(0), current: self.tail, list: self }
    }

    /// `LinkedList` ശൂന്യമാണെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// ഈ പ്രവർത്തനം *O*(1) സമയത്തിനുള്ളിൽ കണക്കാക്കണം.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert!(dl.is_empty());
    ///
    /// dl.push_front("foo");
    /// assert!(!dl.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.head.is_none()
    }

    /// `LinkedList`-ന്റെ ദൈർഘ്യം നൽകുന്നു.
    ///
    /// ഈ പ്രവർത്തനം *O*(1) സമയത്തിനുള്ളിൽ കണക്കാക്കണം.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.len(), 1);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    ///
    /// dl.push_back(3);
    /// assert_eq!(dl.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// `LinkedList`-ൽ നിന്ന് എല്ലാ ഘടകങ്ങളും നീക്കംചെയ്യുന്നു.
    ///
    /// ഈ പ്രവർത്തനം *O*(*n*) സമയത്തിൽ കണക്കാക്കണം.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// dl.push_front(1);
    /// assert_eq!(dl.len(), 2);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// dl.clear();
    /// assert_eq!(dl.len(), 0);
    /// assert_eq!(dl.front(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        *self = Self::new();
    }

    /// തന്നിരിക്കുന്ന മൂല്യത്തിന് തുല്യമായ ഒരു ഘടകം `LinkedList`-ൽ ഉണ്ടെങ്കിൽ `true` നൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut list: LinkedList<u32> = LinkedList::new();
    ///
    /// list.push_back(0);
    /// list.push_back(1);
    /// list.push_back(2);
    ///
    /// assert_eq!(list.contains(&0), true);
    /// assert_eq!(list.contains(&10), false);
    /// ```
    #[stable(feature = "linked_list_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        self.iter().any(|e| e == x)
    }

    /// മുൻ ഘടകത്തിലേക്ക് ഒരു റഫറൻസ് നൽകുന്നു, അല്ലെങ്കിൽ പട്ടിക ശൂന്യമാണെങ്കിൽ `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        unsafe { self.head.as_ref().map(|node| &node.as_ref().element) }
    }

    /// ഫ്രണ്ട് എലമെന്റിന് ഒരു മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു, അല്ലെങ്കിൽ പട്ടിക ശൂന്യമാണെങ്കിൽ `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.front(), None);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front(), Some(&1));
    ///
    /// match dl.front_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.front(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        unsafe { self.head.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// ബാക്ക് എലമെന്റിന് ഒരു റഫറൻസ് നൽകുന്നു, അല്ലെങ്കിൽ പട്ടിക ശൂന്യമാണെങ്കിൽ `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        unsafe { self.tail.as_ref().map(|node| &node.as_ref().element) }
    }

    /// ബാക്ക് എലമെന്റിന് ഒരു മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു, അല്ലെങ്കിൽ പട്ടിക ശൂന്യമാണെങ്കിൽ `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    /// assert_eq!(dl.back(), None);
    ///
    /// dl.push_back(1);
    /// assert_eq!(dl.back(), Some(&1));
    ///
    /// match dl.back_mut() {
    ///     None => {},
    ///     Some(x) => *x = 5,
    /// }
    /// assert_eq!(dl.back(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        unsafe { self.tail.as_mut().map(|node| &mut node.as_mut().element) }
    }

    /// ലിസ്റ്റിൽ ആദ്യം ഒരു ഘടകം ചേർക്കുന്നു.
    ///
    /// ഈ പ്രവർത്തനം *O*(1) സമയത്തിനുള്ളിൽ കണക്കാക്കണം.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut dl = LinkedList::new();
    ///
    /// dl.push_front(2);
    /// assert_eq!(dl.front().unwrap(), &2);
    ///
    /// dl.push_front(1);
    /// assert_eq!(dl.front().unwrap(), &1);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, elt: T) {
        self.push_front_node(box Node::new(elt));
    }

    /// ആദ്യ ഘടകം നീക്കംചെയ്‌ത് അത് നൽകുന്നു, അല്ലെങ്കിൽ പട്ടിക ശൂന്യമാണെങ്കിൽ `None`.
    ///
    ///
    /// ഈ പ്രവർത്തനം *O*(1) സമയത്തിനുള്ളിൽ കണക്കാക്കണം.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_front(), None);
    ///
    /// d.push_front(1);
    /// d.push_front(3);
    /// assert_eq!(d.pop_front(), Some(3));
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        self.pop_front_node().map(Node::into_element)
    }

    /// ഒരു ലിസ്റ്റിന്റെ പിന്നിലേക്ക് ഒരു ഘടകം കൂട്ടിച്ചേർക്കുന്നു.
    ///
    /// ഈ പ്രവർത്തനം *O*(1) സമയത്തിനുള്ളിൽ കണക്കാക്കണം.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(3, *d.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, elt: T) {
        self.push_back_node(box Node::new(elt));
    }

    /// ഒരു ലിസ്റ്റിൽ നിന്ന് അവസാന ഘടകം നീക്കംചെയ്‌ത് അത് നൽകുന്നു, അല്ലെങ്കിൽ ശൂന്യമാണെങ്കിൽ `None`.
    ///
    ///
    /// ഈ പ്രവർത്തനം *O*(1) സമയത്തിനുള്ളിൽ കണക്കാക്കണം.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    /// assert_eq!(d.pop_back(), None);
    /// d.push_back(1);
    /// d.push_back(3);
    /// assert_eq!(d.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        self.pop_back_node().map(Node::into_element)
    }

    /// തന്നിരിക്കുന്ന സൂചികയിൽ പട്ടിക രണ്ടായി വിഭജിക്കുന്നു.
    /// സൂചിക ഉൾപ്പെടെ തന്നിരിക്കുന്ന സൂചികയ്ക്ക് ശേഷം എല്ലാം നൽകുന്നു.
    ///
    /// ഈ പ്രവർത്തനം *O*(*n*) സമയത്തിൽ കണക്കാക്കണം.
    ///
    /// # Panics
    ///
    /// `at > len` എങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// let mut split = d.split_off(2);
    ///
    /// assert_eq!(split.pop_front(), Some(1));
    /// assert_eq!(split.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn split_off(&mut self, at: usize) -> LinkedList<T> {
        let len = self.len();
        assert!(at <= len, "Cannot split off at a nonexistent index");
        if at == 0 {
            return mem::take(self);
        } else if at == len {
            return Self::new();
        }

        // ചുവടെ, ആരംഭത്തിലോ അവസാനത്തിലോ `i-1` നോഡിലേക്ക് ഞങ്ങൾ ആവർത്തിക്കുന്നു, അത് വേഗതയേറിയതാകാം.
        //
        let split_node = if at - 1 <= len - 1 - (at - 1) {
            let mut iter = self.iter_mut();
            // .skip() ഉപയോഗിച്ച് ഒഴിവാക്കുന്നതിനുപകരം (ഇത് ഒരു പുതിയ ഘടന സൃഷ്ടിക്കുന്നു), ഞങ്ങൾ സ്വമേധയാ ഒഴിവാക്കുന്നതിനാൽ സ്കിപ്പിന്റെ നടപ്പാക്കൽ വിശദാംശങ്ങളെ ആശ്രയിക്കാതെ നമുക്ക് ഹെഡ് ഫീൽഡിലേക്ക് പ്രവേശിക്കാൻ കഴിയും.
            //
            //
            for _ in 0..at - 1 {
                iter.next();
            }
            iter.head
        } else {
            // അവസാനം മുതൽ ആരംഭിക്കുന്നതാണ് നല്ലത്
            let mut iter = self.iter_mut();
            for _ in 0..len - 1 - (at - 1) {
                iter.next_back();
            }
            iter.tail
        };
        unsafe { self.split_off_after_node(split_node, at) }
    }

    /// തന്നിരിക്കുന്ന സൂചികയിലെ ഘടകം നീക്കംചെയ്യുകയും അത് തിരികെ നൽകുകയും ചെയ്യുന്നു.
    ///
    /// ഈ പ്രവർത്തനം *O*(*n*) സമയത്തിൽ കണക്കാക്കണം.
    ///
    /// # Panics
    /// > =ലെൻ ആണെങ്കിൽ Panics
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(linked_list_remove)]
    /// use std::collections::LinkedList;
    ///
    /// let mut d = LinkedList::new();
    ///
    /// d.push_front(1);
    /// d.push_front(2);
    /// d.push_front(3);
    ///
    /// assert_eq!(d.remove(1), 2);
    /// assert_eq!(d.remove(0), 3);
    /// assert_eq!(d.remove(0), 1);
    /// ```
    #[unstable(feature = "linked_list_remove", issue = "69210")]
    pub fn remove(&mut self, at: usize) -> T {
        let len = self.len();
        assert!(at < len, "Cannot remove at an index outside of the list bounds");

        // ചുവടെ, തന്നിരിക്കുന്ന സൂചികയിലെ നോഡിലേക്ക് ഞങ്ങൾ തുടക്കം മുതൽ അവസാനം വരെ ആവർത്തിക്കുന്നു, അത് വേഗതയേറിയതായിരിക്കും.
        //
        let offset_from_end = len - at - 1;
        if at <= offset_from_end {
            let mut cursor = self.cursor_front_mut();
            for _ in 0..at {
                cursor.move_next();
            }
            cursor.remove_current().unwrap()
        } else {
            let mut cursor = self.cursor_back_mut();
            for _ in 0..offset_from_end {
                cursor.move_prev();
            }
            cursor.remove_current().unwrap()
        }
    }

    /// ഒരു ഘടകം നീക്കംചെയ്യേണ്ടതുണ്ടോ എന്ന് നിർണ്ണയിക്കാൻ ഒരു അടയ്ക്കൽ ഉപയോഗിക്കുന്ന ഒരു ഇറ്ററേറ്റർ സൃഷ്ടിക്കുന്നു.
    ///
    /// അടയ്ക്കൽ ശരിയാണെങ്കിൽ, ഘടകം നീക്കംചെയ്യുകയും വിളവ് നൽകുകയും ചെയ്യുന്നു.
    /// അടയ്‌ക്കൽ തെറ്റാണെങ്കിൽ‌, ഘടകം പട്ടികയിൽ‌നിലനിൽക്കും, മാത്രമല്ല അത് ആവർത്തനത്തിന് ലഭിക്കുകയുമില്ല.
    ///
    /// ഫിൽ‌റ്റർ‌അടയ്‌ക്കുന്നതിലെ എല്ലാ ഘടകങ്ങളും പരിവർത്തനം ചെയ്യാനോ നീക്കംചെയ്യാനോ നിങ്ങൾ‌തീരുമാനിച്ചാലും അത് പരിവർത്തനം ചെയ്യാൻ `drain_filter` നിങ്ങളെ അനുവദിക്കുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ഒറിജിനൽ ലിസ്റ്റ് വീണ്ടും ഉപയോഗിച്ചുകൊണ്ട് ഒരു ലിസ്റ്റ് വൈകുന്നേരവും വിചിത്രവുമായി വിഭജിക്കുന്നു:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// use std::collections::LinkedList;
    ///
    /// let mut numbers: LinkedList<u32> = LinkedList::new();
    /// numbers.extend(&[1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15]);
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<LinkedList<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens.into_iter().collect::<Vec<_>>(), vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds.into_iter().collect::<Vec<_>>(), vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F>
    where
        F: FnMut(&mut T) -> bool,
    {
        // വായ്പ പ്രശ്‌നങ്ങൾ ഒഴിവാക്കുക.
        let it = self.head;
        let old_len = self.len;

        DrainFilter { list: self, it, pred: filter, idx: 0, old_len }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for LinkedList<T> {
    fn drop(&mut self) {
        struct DropGuard<'a, T>(&'a mut LinkedList<T>);

        impl<'a, T> Drop for DropGuard<'a, T> {
            fn drop(&mut self) {
                // ഞങ്ങൾ ചുവടെ ചെയ്യുന്ന അതേ ലൂപ്പ് തുടരുക.ഒരു ഡിസ്ട്രക്റ്റർ പരിഭ്രാന്തരാകുമ്പോൾ മാത്രമേ ഇത് പ്രവർത്തിക്കൂ.
                // മറ്റൊന്ന് panics ആണെങ്കിൽ ഇത് നിർത്തലാക്കും.
                while self.0.pop_front_node().is_some() {}
            }
        }

        while let Some(node) = self.pop_front_node() {
            let guard = DropGuard(self);
            drop(node);
            mem::forget(guard);
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // 'A ലഭിക്കാൻ പരിധിയില്ലാത്ത ആജീവനാന്തം ആവശ്യമാണ്
                let node = &*node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // 'A ലഭിക്കാൻ പരിധിയില്ലാത്ത ആജീവനാന്തം ആവശ്യമാണ്
                let node = &*node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = &'a mut T;

    #[inline]
    fn next(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.head.map(|node| unsafe {
                // 'A ലഭിക്കാൻ പരിധിയില്ലാത്ത ആജീവനാന്തം ആവശ്യമാണ്
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.head = node.next;
                &mut node.element
            })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.len, Some(self.len))
    }

    #[inline]
    fn last(mut self) -> Option<&'a mut T> {
        self.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for IterMut<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a mut T> {
        if self.len == 0 {
            None
        } else {
            self.tail.map(|node| unsafe {
                // 'A ലഭിക്കാൻ പരിധിയില്ലാത്ത ആജീവനാന്തം ആവശ്യമാണ്
                let node = &mut *node.as_ptr();
                self.len -= 1;
                self.tail = node.prev;
                &mut node.element
            })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IterMut<'_, T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IterMut<'_, T> {}

/// ഒരു `LinkedList`-ന് മുകളിലുള്ള ഒരു കഴ്‌സർ.
///
/// ഒരു `Cursor` ഒരു ഇറ്ററേറ്റർ പോലെയാണ്, അതിന് സ്വതന്ത്രമായി മുന്നോട്ടും പിന്നോട്ടും അന്വേഷിക്കാൻ കഴിയും എന്നതൊഴിച്ചാൽ.
///
/// പട്ടികയിലെ രണ്ട് ഘടകങ്ങൾക്കിടയിൽ കഴ്‌സറുകൾ എല്ലായ്പ്പോഴും വിശ്രമിക്കുന്നു, ഒപ്പം യുക്തിപരമായി വൃത്താകൃതിയിലുള്ള സൂചികയും.
/// ഇത് ഉൾക്കൊള്ളാൻ, പട്ടികയുടെ തലയ്ക്കും വാലും തമ്മിൽ `None` നൽകുന്ന ഒരു "ghost" നോൺ-എലമെന്റ് ഉണ്ട്.
///
///
/// സൃഷ്ടിക്കുമ്പോൾ, പട്ടികയുടെ മുൻഭാഗത്ത് കഴ്‌സറുകൾ ആരംഭിക്കുന്നു, അല്ലെങ്കിൽ പട്ടിക ശൂന്യമാണെങ്കിൽ "ghost" നോൺ-എലമെന്റ്.
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct Cursor<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T> Clone for Cursor<'_, T> {
    fn clone(&self) -> Self {
        let Cursor { index, current, list } = *self;
        Cursor { index, current, list }
    }
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for Cursor<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Cursor").field(&self.list).field(&self.index()).finish()
    }
}

/// എഡിറ്റിംഗ് പ്രവർത്തനങ്ങളുള്ള ഒരു `LinkedList`-ന് മുകളിലുള്ള ഒരു കഴ്‌സർ.
///
/// ഒരു എക്സ് 100 എക്സ് ഒരു ഇറ്ററേറ്റർ പോലെയാണ്, അതിന് സ്വതന്ത്രമായി മുന്നോട്ടും പിന്നോട്ടും അന്വേഷിക്കാൻ കഴിയും, കൂടാതെ ആവർത്തന സമയത്ത് സുരക്ഷിതമായി ലിസ്റ്റ് പരിവർത്തനം ചെയ്യാനും കഴിയും.
/// കാരണം, അതിന്റെ വിളവ് ലഭിച്ച റഫറൻസുകളുടെ ആജീവനാന്തം അടിസ്ഥാന ലിസ്റ്റിനു പകരം സ്വന്തം ജീവിതകാലവുമായി ബന്ധപ്പെട്ടിരിക്കുന്നു.
/// ഇതിനർത്ഥം കഴ്‌സറുകൾ‌ക്ക് ഒരേസമയം ഒന്നിലധികം ഘടകങ്ങൾ‌നൽ‌കാൻ‌കഴിയില്ല.
///
/// പട്ടികയിലെ രണ്ട് ഘടകങ്ങൾക്കിടയിൽ കഴ്‌സറുകൾ എല്ലായ്പ്പോഴും വിശ്രമിക്കുന്നു, ഒപ്പം യുക്തിപരമായി വൃത്താകൃതിയിലുള്ള സൂചികയും.
/// ഇത് ഉൾക്കൊള്ളാൻ, പട്ടികയുടെ തലയ്ക്കും വാലും തമ്മിൽ `None` നൽകുന്ന ഒരു "ghost" നോൺ-എലമെന്റ് ഉണ്ട്.
///
///
#[unstable(feature = "linked_list_cursors", issue = "58533")]
pub struct CursorMut<'a, T: 'a> {
    index: usize,
    current: Option<NonNull<Node<T>>>,
    list: &'a mut LinkedList<T>,
}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
impl<T: fmt::Debug> fmt::Debug for CursorMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("CursorMut").field(&self.list).field(&self.index()).finish()
    }
}

impl<'a, T> Cursor<'a, T> {
    /// `LinkedList`-നുള്ളിൽ കഴ്‌സർ സ്ഥാന സൂചിക നൽകുന്നു.
    ///
    /// കഴ്‌സർ നിലവിൽ "ghost" നോൺ എലമെന്റിലേക്ക് പോയിന്റുചെയ്യുന്നുവെങ്കിൽ ഇത് `None` നൽകുന്നു.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// `LinkedList`-ന്റെ അടുത്ത ഘടകത്തിലേക്ക് കഴ്‌സർ നീക്കുന്നു.
    ///
    /// കഴ്‌സർ "ghost" നോൺ-എലമെൻറിലേക്കാണ് വിരൽ ചൂണ്ടുന്നതെങ്കിൽ ഇത് ഇത് `LinkedList`-ന്റെ ആദ്യ ഘടകത്തിലേക്ക് നീക്കും.
    /// ഇത് `LinkedList`-ന്റെ അവസാന ഘടകത്തിലേക്ക് വിരൽ ചൂണ്ടുന്നുവെങ്കിൽ ഇത് ഇത് "ghost" നോൺ-എലമെന്റിലേക്ക് നീക്കും.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // ഞങ്ങൾക്ക് നിലവിലെ ഘടകങ്ങളൊന്നുമില്ല;കഴ്‌സർ ആരംഭ സ്ഥാനത്ത് ഇരിക്കുകയായിരുന്നു അടുത്ത ഘടകം പട്ടികയുടെ തലയായിരിക്കണം
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // ഞങ്ങൾക്ക് മുമ്പത്തെ ഒരു ഘടകം ഉണ്ടായിരുന്നു, അതിനാൽ നമുക്ക് അതിന്റെ അടുത്തതിലേക്ക് പോകാം
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// `LinkedList`-ന്റെ മുമ്പത്തെ ഘടകത്തിലേക്ക് കഴ്‌സർ നീക്കുന്നു.
    ///
    /// കഴ്‌സർ "ghost" നോൺ-എലമെൻറിലേക്ക് പോയിന്റുചെയ്യുന്നുവെങ്കിൽ ഇത് ഇത് `LinkedList`-ന്റെ അവസാന ഘടകത്തിലേക്ക് നീക്കും.
    /// ഇത് `LinkedList`-ന്റെ ആദ്യ ഘടകത്തിലേക്ക് വിരൽ ചൂണ്ടുന്നുവെങ്കിൽ ഇത് ഇത് "ghost" നോൺ-എലമെന്റിലേക്ക് നീക്കും.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // കറന്റ് ഇല്ല.ഞങ്ങൾ പട്ടികയുടെ തുടക്കത്തിലാണ്.ഒന്നും നൽകാതെ അവസാനത്തിലേക്ക് പോകുക.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // ഒരു മുൻ‌തൂക്കം.ഇത് നൽകി മുമ്പത്തെ ഘടകത്തിലേക്ക് പോകുക.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// കഴ്‌സർ നിലവിൽ ചൂണ്ടിക്കാണിക്കുന്ന ഘടകത്തിലേക്ക് ഒരു റഫറൻസ് നൽകുന്നു.
    ///
    /// കഴ്‌സർ നിലവിൽ "ghost" നോൺ എലമെന്റിലേക്ക് പോയിന്റുചെയ്യുന്നുവെങ്കിൽ ഇത് `None` നൽകുന്നു.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&self) -> Option<&'a T> {
        unsafe { self.current.map(|current| &(*current.as_ptr()).element) }
    }

    /// അടുത്ത ഘടകത്തിലേക്ക് ഒരു റഫറൻസ് നൽകുന്നു.
    ///
    /// കഴ്‌സർ "ghost" നോൺ-എലമെന്റിലേക്ക് പോയിന്റുചെയ്യുകയാണെങ്കിൽ, ഇത് `LinkedList`-ന്റെ ആദ്യ ഘടകം നൽകുന്നു.
    /// ഇത് `LinkedList`-ന്റെ അവസാന ഘടകത്തിലേക്ക് വിരൽ ചൂണ്ടുന്നുവെങ്കിൽ ഇത് `None` നൽകുന്നു.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&self) -> Option<&'a T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &(*next.as_ptr()).element)
        }
    }

    /// മുമ്പത്തെ ഘടകത്തിലേക്ക് ഒരു റഫറൻസ് നൽകുന്നു.
    ///
    /// കഴ്‌സർ "ghost" നോൺ-എലമെന്റിലേക്ക് പോയിന്റുചെയ്യുകയാണെങ്കിൽ, ഇത് `LinkedList`-ന്റെ അവസാന ഘടകം നൽകുന്നു.
    /// ഇത് `LinkedList`-ന്റെ ആദ്യ ഘടകത്തിലേക്ക് വിരൽ ചൂണ്ടുന്നുവെങ്കിൽ ഇത് `None` നൽകുന്നു.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&self) -> Option<&'a T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &(*prev.as_ptr()).element)
        }
    }
}

impl<'a, T> CursorMut<'a, T> {
    /// `LinkedList`-നുള്ളിൽ കഴ്‌സർ സ്ഥാന സൂചിക നൽകുന്നു.
    ///
    /// കഴ്‌സർ നിലവിൽ "ghost" നോൺ എലമെന്റിലേക്ക് പോയിന്റുചെയ്യുന്നുവെങ്കിൽ ഇത് `None` നൽകുന്നു.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn index(&self) -> Option<usize> {
        let _ = self.current?;
        Some(self.index)
    }

    /// `LinkedList`-ന്റെ അടുത്ത ഘടകത്തിലേക്ക് കഴ്‌സർ നീക്കുന്നു.
    ///
    /// കഴ്‌സർ "ghost" നോൺ-എലമെൻറിലേക്കാണ് വിരൽ ചൂണ്ടുന്നതെങ്കിൽ ഇത് ഇത് `LinkedList`-ന്റെ ആദ്യ ഘടകത്തിലേക്ക് നീക്കും.
    /// ഇത് `LinkedList`-ന്റെ അവസാന ഘടകത്തിലേക്ക് വിരൽ ചൂണ്ടുന്നുവെങ്കിൽ ഇത് ഇത് "ghost" നോൺ-എലമെന്റിലേക്ക് നീക്കും.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_next(&mut self) {
        match self.current.take() {
            // ഞങ്ങൾക്ക് നിലവിലെ ഘടകങ്ങളൊന്നുമില്ല;കഴ്‌സർ ആരംഭ സ്ഥാനത്ത് ഇരിക്കുകയായിരുന്നു അടുത്ത ഘടകം പട്ടികയുടെ തലയായിരിക്കണം
            //
            None => {
                self.current = self.list.head;
                self.index = 0;
            }
            // ഞങ്ങൾക്ക് മുമ്പത്തെ ഒരു ഘടകം ഉണ്ടായിരുന്നു, അതിനാൽ നമുക്ക് അതിന്റെ അടുത്തതിലേക്ക് പോകാം
            Some(current) => unsafe {
                self.current = current.as_ref().next;
                self.index += 1;
            },
        }
    }

    /// `LinkedList`-ന്റെ മുമ്പത്തെ ഘടകത്തിലേക്ക് കഴ്‌സർ നീക്കുന്നു.
    ///
    /// കഴ്‌സർ "ghost" നോൺ-എലമെൻറിലേക്ക് പോയിന്റുചെയ്യുന്നുവെങ്കിൽ ഇത് ഇത് `LinkedList`-ന്റെ അവസാന ഘടകത്തിലേക്ക് നീക്കും.
    /// ഇത് `LinkedList`-ന്റെ ആദ്യ ഘടകത്തിലേക്ക് വിരൽ ചൂണ്ടുന്നുവെങ്കിൽ ഇത് ഇത് "ghost" നോൺ-എലമെന്റിലേക്ക് നീക്കും.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn move_prev(&mut self) {
        match self.current.take() {
            // കറന്റ് ഇല്ല.ഞങ്ങൾ പട്ടികയുടെ തുടക്കത്തിലാണ്.ഒന്നും നൽകാതെ അവസാനത്തിലേക്ക് പോകുക.
            None => {
                self.current = self.list.tail;
                self.index = self.list.len().checked_sub(1).unwrap_or(0);
            }
            // ഒരു മുൻ‌തൂക്കം.ഇത് നൽകി മുമ്പത്തെ ഘടകത്തിലേക്ക് പോകുക.
            Some(current) => unsafe {
                self.current = current.as_ref().prev;
                self.index = self.index.checked_sub(1).unwrap_or_else(|| self.list.len());
            },
        }
    }

    /// കഴ്‌സർ നിലവിൽ ചൂണ്ടിക്കാണിക്കുന്ന ഘടകത്തിലേക്ക് ഒരു റഫറൻസ് നൽകുന്നു.
    ///
    /// കഴ്‌സർ നിലവിൽ "ghost" നോൺ എലമെന്റിലേക്ക് പോയിന്റുചെയ്യുന്നുവെങ്കിൽ ഇത് `None` നൽകുന്നു.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn current(&mut self) -> Option<&mut T> {
        unsafe { self.current.map(|current| &mut (*current.as_ptr()).element) }
    }

    /// അടുത്ത ഘടകത്തിലേക്ക് ഒരു റഫറൻസ് നൽകുന്നു.
    ///
    /// കഴ്‌സർ "ghost" നോൺ-എലമെന്റിലേക്ക് പോയിന്റുചെയ്യുകയാണെങ്കിൽ, ഇത് `LinkedList`-ന്റെ ആദ്യ ഘടകം നൽകുന്നു.
    /// ഇത് `LinkedList`-ന്റെ അവസാന ഘടകത്തിലേക്ക് വിരൽ ചൂണ്ടുന്നുവെങ്കിൽ ഇത് `None` നൽകുന്നു.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_next(&mut self) -> Option<&mut T> {
        unsafe {
            let next = match self.current {
                None => self.list.head,
                Some(current) => current.as_ref().next,
            };
            next.map(|next| &mut (*next.as_ptr()).element)
        }
    }

    /// മുമ്പത്തെ ഘടകത്തിലേക്ക് ഒരു റഫറൻസ് നൽകുന്നു.
    ///
    /// കഴ്‌സർ "ghost" നോൺ-എലമെന്റിലേക്ക് പോയിന്റുചെയ്യുകയാണെങ്കിൽ, ഇത് `LinkedList`-ന്റെ അവസാന ഘടകം നൽകുന്നു.
    /// ഇത് `LinkedList`-ന്റെ ആദ്യ ഘടകത്തിലേക്ക് വിരൽ ചൂണ്ടുന്നുവെങ്കിൽ ഇത് `None` നൽകുന്നു.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn peek_prev(&mut self) -> Option<&mut T> {
        unsafe {
            let prev = match self.current {
                None => self.list.tail,
                Some(current) => current.as_ref().prev,
            };
            prev.map(|prev| &mut (*prev.as_ptr()).element)
        }
    }

    /// നിലവിലെ ഘടകത്തിലേക്ക് പോയിന്റുചെയ്യുന്ന വായന-മാത്രം കഴ്‌സർ നൽകുന്നു.
    ///
    /// മടങ്ങിയെത്തിയ `Cursor`-ന്റെ ആയുസ്സ് `CursorMut`-മായി ബന്ധപ്പെട്ടിരിക്കുന്നു, അതിനർത്ഥം `CursorMut`-നെ അതിജീവിക്കാൻ കഴിയില്ലെന്നും `Cursor`-ന്റെ ആയുസ്സ് `CursorMut` ഫ്രീസുചെയ്‌തുവെന്നും ആണ്.
    ///
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn as_cursor(&self) -> Cursor<'_, T> {
        Cursor { list: self.list, current: self.current, index: self.index }
    }
}

// ഇപ്പോൾ ലിസ്റ്റ് എഡിറ്റിംഗ് പ്രവർത്തനങ്ങൾ

impl<'a, T> CursorMut<'a, T> {
    /// നിലവിലെ ഒന്നിനുശേഷം `LinkedList`-ലേക്ക് ഒരു പുതിയ ഘടകം ചേർക്കുന്നു.
    ///
    /// കഴ്‌സർ "ghost" നോൺ-എലമെൻറിലേക്കാണ് വിരൽ ചൂണ്ടുന്നതെങ്കിൽ, പുതിയ ഘടകം `LinkedList`-ന്റെ മുൻവശത്ത് ചേർത്തു.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_after(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, spliced_node, spliced_node, 1);
            if self.current.is_none() {
                // "ghost" നോൺ-എലമെന്റിന്റെ സൂചിക മാറി.
                self.index = self.list.len;
            }
        }
    }

    /// നിലവിലെ ഒന്നിന് മുമ്പായി `LinkedList`-ലേക്ക് ഒരു പുതിയ ഘടകം ചേർക്കുന്നു.
    ///
    /// കഴ്‌സർ "ghost" നോൺ-എലമെൻറിലേക്കാണ് വിരൽ ചൂണ്ടുന്നതെങ്കിൽ, പുതിയ ഘടകം `LinkedList`-ന്റെ അവസാനം ചേർത്തു.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn insert_before(&mut self, item: T) {
        unsafe {
            let spliced_node = Box::leak(Box::new(Node::new(item))).into();
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, spliced_node, spliced_node, 1);
            self.index += 1;
        }
    }

    /// `LinkedList`-ൽ നിന്ന് നിലവിലെ ഘടകം നീക്കംചെയ്യുന്നു.
    ///
    /// നീക്കംചെയ്ത ഘടകം മടക്കിനൽകുന്നു, കൂടാതെ `LinkedList`-ലെ അടുത്ത ഘടകത്തിലേക്ക് പോയിന്റുചെയ്യാൻ കഴ്‌സർ നീക്കുന്നു.
    ///
    ///
    /// കഴ്‌സർ നിലവിൽ "ghost" നോൺ-എലമെന്റിലേക്ക് പോയിന്റുചെയ്യുകയാണെങ്കിൽ, ഒരു ഘടകവും നീക്കംചെയ്യുകയും `None` തിരികെ നൽകുകയും ചെയ്യുന്നു.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current(&mut self) -> Option<T> {
        let unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);
            let unlinked_node = Box::from_raw(unlinked_node.as_ptr());
            Some(unlinked_node.element)
        }
    }

    /// ലിസ്റ്റ് നോഡ് ഡീലോക്കേറ്റ് ചെയ്യാതെ `LinkedList`-ൽ നിന്ന് നിലവിലെ ഘടകം നീക്കംചെയ്യുന്നു.
    ///
    /// നീക്കംചെയ്ത നോഡ് ഈ നോഡ് മാത്രം ഉൾക്കൊള്ളുന്ന ഒരു പുതിയ `LinkedList` ആയി മടക്കിനൽകുന്നു.
    /// നിലവിലെ `LinkedList`-ലെ അടുത്ത ഘടകത്തിലേക്ക് പോയിന്റുചെയ്യാൻ കഴ്‌സർ നീക്കി.
    ///
    /// കഴ്‌സർ നിലവിൽ "ghost" നോൺ-എലമെന്റിലേക്ക് പോയിന്റുചെയ്യുകയാണെങ്കിൽ, ഒരു ഘടകവും നീക്കംചെയ്യുകയും `None` തിരികെ നൽകുകയും ചെയ്യുന്നു.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn remove_current_as_list(&mut self) -> Option<LinkedList<T>> {
        let mut unlinked_node = self.current?;
        unsafe {
            self.current = unlinked_node.as_ref().next;
            self.list.unlink_node(unlinked_node);

            unlinked_node.as_mut().prev = None;
            unlinked_node.as_mut().next = None;
            Some(LinkedList {
                head: Some(unlinked_node),
                tail: Some(unlinked_node),
                len: 1,
                marker: PhantomData,
            })
        }
    }

    /// നിലവിലെ ഒന്നിനുശേഷം നൽകിയ `LinkedList`-ൽ നിന്നുള്ള ഘടകങ്ങൾ ചേർക്കുന്നു.
    ///
    /// കഴ്‌സർ "ghost" നോൺ-എലമെൻറിലേക്കാണ് വിരൽ ചൂണ്ടുന്നതെങ്കിൽ, പുതിയ ഘടകങ്ങൾ `LinkedList` ന്റെ തുടക്കത്തിൽ ചേർത്തു.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_after(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_next = match self.current {
                None => self.list.head,
                Some(node) => node.as_ref().next,
            };
            self.list.splice_nodes(self.current, node_next, splice_head, splice_tail, splice_len);
            if self.current.is_none() {
                // "ghost" നോൺ-എലമെന്റിന്റെ സൂചിക മാറി.
                self.index = self.list.len;
            }
        }
    }

    /// നിലവിലെ ഒന്നിന് മുമ്പ് നൽകിയ `LinkedList`-ൽ നിന്നുള്ള ഘടകങ്ങൾ ചേർക്കുന്നു.
    ///
    /// കഴ്‌സർ "ghost" നോൺ-എലമെൻറിലേക്കാണ് വിരൽ ചൂണ്ടുന്നതെങ്കിൽ, പുതിയ ഘടകങ്ങൾ `LinkedList`-ന്റെ അവസാനം ചേർക്കുന്നു.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn splice_before(&mut self, list: LinkedList<T>) {
        unsafe {
            let (splice_head, splice_tail, splice_len) = match list.detach_all_nodes() {
                Some(parts) => parts,
                _ => return,
            };
            let node_prev = match self.current {
                None => self.list.tail,
                Some(node) => node.as_ref().prev,
            };
            self.list.splice_nodes(node_prev, self.current, splice_head, splice_tail, splice_len);
            self.index += splice_len;
        }
    }

    /// നിലവിലെ ഘടകത്തിന് ശേഷം പട്ടിക രണ്ടായി വിഭജിക്കുന്നു.
    /// ഇത് കഴ്‌സറിന് ശേഷം എല്ലാം ഉൾക്കൊള്ളുന്ന ഒരു പുതിയ ലിസ്റ്റ് നൽകും, യഥാർത്ഥ ലിസ്റ്റ് മുമ്പുള്ളതെല്ലാം നിലനിർത്തുന്നു.
    ///
    ///
    /// കഴ്‌സർ "ghost" നോൺ-എലമെൻറിലേക്കാണ് വിരൽ ചൂണ്ടുന്നതെങ്കിൽ, `LinkedList`-ന്റെ മുഴുവൻ ഉള്ളടക്കങ്ങളും നീക്കുന്നു.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_after(&mut self) -> LinkedList<T> {
        let split_off_idx = if self.index == self.list.len { 0 } else { self.index + 1 };
        if self.index == self.list.len {
            // "ghost" നോൺ-എലമെന്റിന്റെ സൂചിക 0 ആയി മാറ്റി.
            self.index = 0;
        }
        unsafe { self.list.split_off_after_node(self.current, split_off_idx) }
    }

    /// നിലവിലെ ഘടകത്തിന് മുമ്പായി പട്ടിക രണ്ടായി വിഭജിക്കുന്നു.
    /// ഇത് കഴ്‌സറിന് മുമ്പുള്ള എല്ലാം ഉൾക്കൊള്ളുന്ന ഒരു പുതിയ ലിസ്റ്റ് നൽകും, യഥാർത്ഥ ലിസ്റ്റ് അതിനുശേഷം എല്ലാം നിലനിർത്തുന്നു.
    ///
    ///
    /// കഴ്‌സർ "ghost" നോൺ-എലമെൻറിലേക്കാണ് വിരൽ ചൂണ്ടുന്നതെങ്കിൽ, `LinkedList`-ന്റെ മുഴുവൻ ഉള്ളടക്കങ്ങളും നീക്കുന്നു.
    ///
    #[unstable(feature = "linked_list_cursors", issue = "58533")]
    pub fn split_before(&mut self) -> LinkedList<T> {
        let split_off_idx = self.index;
        self.index = 0;
        unsafe { self.list.split_off_before_node(self.current, split_off_idx) }
    }
}

/// ലിങ്ക്ഡ് ലിസ്റ്റിൽ എക്സ് 00 എക്സ് വിളിച്ച് നിർമ്മിച്ച ഒരു ഇറ്ററേറ്റർ.
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub struct DrainFilter<'a, T: 'a, F: 'a>
where
    F: FnMut(&mut T) -> bool,
{
    list: &'a mut LinkedList<T>,
    it: Option<NonNull<Node<T>>>,
    pred: F,
    idx: usize,
    old_len: usize,
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Iterator for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        while let Some(mut node) = self.it {
            unsafe {
                self.it = node.as_ref().next;
                self.idx += 1;

                if (self.pred)(&mut node.as_mut().element) {
                    // `unlink_node` `element` റഫറൻസുകൾ അപരനാമത്തിൽ കുഴപ്പമില്ല.
                    self.list.unlink_node(node);
                    return Some(Box::from_raw(node.as_ptr()).element);
                }
            }
        }

        None
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F> Drop for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T, F>(&'r mut DrainFilter<'a, T, F>)
        where
            F: FnMut(&mut T) -> bool;

        impl<'r, 'a, T, F> Drop for DropGuard<'r, 'a, T, F>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                self.0.for_each(drop);
            }
        }

        while let Some(item) = self.next() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T: fmt::Debug, F> fmt::Debug for DrainFilter<'_, T, F>
where
    F: FnMut(&mut T) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DrainFilter").field(&self.list).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.list.pop_front()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.list.len, Some(self.list.len))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.list.pop_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for LinkedList<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Self {
        let mut list = Self::new();
        list.extend(iter);
        list
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for LinkedList<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// മൂല്യം അനുസരിച്ച് ഘടകങ്ങൾ നൽകുന്ന ഒരു ആവർത്തനത്തിലേക്ക് ലിസ്റ്റ് ഉപയോഗിക്കുന്നു.
    #[inline]
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { list: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a LinkedList<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut LinkedList<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Extend<T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, elem: T) {
        self.push_back(elem);
    }
}

impl<I: IntoIterator> SpecExtend<I> for LinkedList<I::Item> {
    default fn spec_extend(&mut self, iter: I) {
        iter.into_iter().for_each(move |elt| self.push_back(elt));
    }
}

impl<T> SpecExtend<LinkedList<T>> for LinkedList<T> {
    fn spec_extend(&mut self, ref mut other: LinkedList<T>) {
        self.append(other);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for LinkedList<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &'a T) {
        self.push_back(elem);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq> PartialEq for LinkedList<T> {
    fn eq(&self, other: &Self) -> bool {
        self.len() == other.len() && self.iter().eq(other)
    }

    fn ne(&self, other: &Self) -> bool {
        self.len() != other.len() || self.iter().ne(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq> Eq for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd> PartialOrd for LinkedList<T> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.iter().partial_cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Ord for LinkedList<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.iter().cmp(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for LinkedList<T> {
    fn clone(&self) -> Self {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        let mut iter_other = other.iter();
        if self.len() > other.len() {
            self.split_off(other.len());
        }
        for (elem, elem_other) in self.iter_mut().zip(&mut iter_other) {
            elem.clone_from(elem_other);
        }
        if !iter_other.is_empty() {
            self.extend(iter_other.cloned());
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for LinkedList<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash> Hash for LinkedList<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        for elt in self {
            elt.hash(state);
        }
    }
}

// `LinkedList` ഉം അതിന്റെ റീഡ്-ഒൺലി ഇറ്ററേറ്ററുകളും അവയുടെ തരം പാരാമീറ്ററുകളിൽ കോവിയറന്റ് ആണെന്ന് ഉറപ്പാക്കുക.
#[allow(dead_code)]
fn assert_covariance() {
    fn a<'a>(x: LinkedList<&'static str>) -> LinkedList<&'a str> {
        x
    }
    fn b<'i, 'a>(x: Iter<'i, &'static str>) -> Iter<'i, &'a str> {
        x
    }
    fn c<'a>(x: IntoIter<&'static str>) -> IntoIter<&'a str> {
        x
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for LinkedList<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Send for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for Iter<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send> Send for IterMut<'_, T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync> Sync for IterMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Send for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for Cursor<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Send> Send for CursorMut<'_, T> {}

#[unstable(feature = "linked_list_cursors", issue = "58533")]
unsafe impl<T: Sync> Sync for CursorMut<'_, T> {}