use core::array;
use core::cmp::{self};
use core::mem::replace;

use super::VecDeque;

/// ജോഡി സ്ലൈസുകൾ രണ്ട് ഡെക്കുകളുടെ തുല്യ നീളമുള്ള സ്ലൈസ് ഭാഗങ്ങൾ ജോടിയാക്കുന്നു
///
/// ഉദാഹരണത്തിന്, ഇനിപ്പറയുന്ന വിഭജനത്തോടുകൂടിയ "A", "B" എന്നീ ഡെക്കുകൾ സ്ലൈസുകളായി നൽകിയിരിക്കുന്നു:
///
///
/// ഉത്തരം: [0 1 2] [3 4 5]
/// ബി: [a b] [c d e]
///
/// പൊരുത്തപ്പെടുന്ന സ്ലൈസുകളുടെ ഇനിപ്പറയുന്ന ശ്രേണി ഇത് ഉൽ‌പാദിപ്പിക്കുന്നു:
///
/// ([0 1], [a b])(\[2\],\[c\])([3 4], [d e])
///
/// എ അല്ലെങ്കിൽ ബി യുടെ അസമമായ ബാക്കി ഭാഗം ഒഴിവാക്കി.
///
pub struct PairSlices<'a, 'b, T> {
    pub(crate) a0: &'a mut [T],
    pub(crate) a1: &'a mut [T],
    pub(crate) b0: &'b [T],
    pub(crate) b1: &'b [T],
}

impl<'a, 'b, T> PairSlices<'a, 'b, T> {
    pub fn from(to: &'a mut VecDeque<T>, from: &'b VecDeque<T>) -> Self {
        let (a0, a1) = to.as_mut_slices();
        let (b0, b1) = from.as_slices();
        PairSlices { a0, a1, b0, b1 }
    }

    pub fn has_remainder(&self) -> bool {
        !self.b0.is_empty()
    }

    pub fn remainder(self) -> impl Iterator<Item = &'b [T]> {
        array::IntoIter::new([self.b0, self.b1])
    }
}

impl<'a, 'b, T> Iterator for PairSlices<'a, 'b, T> {
    type Item = (&'a mut [T], &'b [T]);
    fn next(&mut self) -> Option<Self::Item> {
        // അടുത്ത ഭാഗത്തിന്റെ ദൈർഘ്യം നേടുക
        let part = cmp::min(self.a0.len(), self.b0.len());
        if part == 0 {
            return None;
        }
        let (p0, p1) = replace(&mut self.a0, &mut []).split_at_mut(part);
        let (q0, q1) = self.b0.split_at(part);

        // a1 ശൂന്യമാണെങ്കിൽ a0-ലേക്ക് നീക്കുക (ഒപ്പം b1, b0 അതേ രീതിയിൽ).
        self.a0 = p1;
        self.b0 = q1;
        if self.a0.is_empty() {
            self.a0 = replace(&mut self.a1, &mut []);
        }
        if self.b0.is_empty() {
            self.b0 = replace(&mut self.b1, &[]);
        }
        Some((p0, q0))
    }
}