//! വളരാൻ കഴിയുന്ന റിംഗ് ബഫറിനൊപ്പം ഇരട്ട-എൻഡ് ക്യൂ നടപ്പിലാക്കി.
//!
//! ഈ ക്യൂവിൽ‌ *O*(1) പലിശയുടെ ഇൻ‌സേർ‌ട്ടുകളും കണ്ടെയ്‌നറിന്റെ രണ്ട് അറ്റങ്ങളിൽ‌നിന്നും നീക്കംചെയ്യലുകളും ഉണ്ട്.
//! ഇതിന് vector പോലെ *O*(1) സൂചികയിലുണ്ട്.
//! അടങ്ങിയിരിക്കുന്ന ഘടകങ്ങൾ‌പകർ‌ത്താനാകില്ല, മാത്രമല്ല അടങ്ങിയിരിക്കുന്ന തരം അയയ്‌ക്കാൻ‌കഴിയുമെങ്കിൽ‌ക്യൂ അയയ്‌ക്കും.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // രണ്ടിന്റെ ഏറ്റവും വലിയ പവർ

/// വളരാൻ കഴിയുന്ന റിംഗ് ബഫറിനൊപ്പം ഇരട്ട-എൻഡ് ക്യൂ നടപ്പിലാക്കി.
///
/// ക്യൂവിലേക്ക് ഈ തരത്തിലുള്ള "default" ഉപയോഗം ക്യൂവിലേക്ക് ചേർക്കാൻ [`push_back`], ക്യൂവിൽ നിന്ന് നീക്കംചെയ്യുന്നതിന് [`pop_front`] എന്നിവയാണ്.
///
/// [`extend`] ഒപ്പം [`append`] ഈ രീതിയിൽ പിന്നിലേക്ക് നീക്കുന്നു, കൂടാതെ `VecDeque`-ൽ വീണ്ടും ആവർത്തിക്കുന്നത് മുന്നിലേക്ക് പിന്നിലേക്ക് പോകുന്നു.
///
/// `VecDeque` ഒരു റിംഗ് ബഫറായതിനാൽ, അതിന്റെ ഘടകങ്ങൾ മെമ്മറിയിൽ തുടർച്ചയായിരിക്കണമെന്നില്ല.
/// കാര്യക്ഷമമായ തരംതിരിക്കൽ പോലുള്ള ഒരൊറ്റ സ്ലൈസായി ഘടകങ്ങൾ ആക്‌സസ് ചെയ്യാൻ നിങ്ങൾ ആഗ്രഹിക്കുന്നുവെങ്കിൽ, നിങ്ങൾക്ക് [`make_contiguous`] ഉപയോഗിക്കാം.
/// ഇത് `VecDeque` തിരിക്കുന്നതിലൂടെ അതിന്റെ ഘടകങ്ങൾ പൊതിയാതിരിക്കുകയും ഒരു മ്യൂട്ടബിൾ സ്ലൈസ് ഇപ്പോൾ-തുടർച്ചയായ മൂലക ശ്രേണിയിലേക്ക് തിരികെ നൽകുകയും ചെയ്യുന്നു.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // വാലും തലയും ബഫറിലേക്കുള്ള പോയിന്ററുകളാണ്.
    // ടെയിൽ എല്ലായ്പ്പോഴും വായിക്കാൻ കഴിയുന്ന ആദ്യ ഘടകത്തിലേക്ക് വിരൽ ചൂണ്ടുന്നു, ഹെഡ് എല്ലായ്പ്പോഴും ഡാറ്റ എഴുതേണ്ട സ്ഥലത്തേക്കാണ് വിരൽ ചൂണ്ടുന്നത്.
    //
    // വാൽ==തലയാണെങ്കിൽ ബഫർ ശൂന്യമാണ്.റിംഗ്ബഫറിന്റെ ദൈർഘ്യം രണ്ടും തമ്മിലുള്ള ദൂരം എന്നാണ് നിർവചിച്ചിരിക്കുന്നത്.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// സ്ലൈസ് ഉപേക്ഷിക്കുമ്പോൾ (സാധാരണയായി അല്ലെങ്കിൽ അറിയാതെ വരുമ്പോൾ) എല്ലാ ഇനങ്ങൾക്കും ഡിസ്ട്രക്റ്റർ പ്രവർത്തിപ്പിക്കുന്നു.
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // [T]-നായി ഡ്രോപ്പ് ഉപയോഗിക്കുക
            ptr::drop_in_place(front);
        }
        // റോ‌വെക് ഡീലോക്കേഷൻ കൈകാര്യം ചെയ്യുന്നു
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// ഒരു ശൂന്യമായ `VecDeque<T>` സൃഷ്ടിക്കുന്നു.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// അരികിൽ കൂടുതൽ സൗകര്യപ്രദമാണ്
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// അരികിൽ കൂടുതൽ സൗകര്യപ്രദമാണ്
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // വലുപ്പത്തിലുള്ള തരങ്ങൾക്ക്, ഞങ്ങൾ എല്ലായ്പ്പോഴും പരമാവധി ശേഷിയിലാണ്
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// Ptr ഒരു സ്ലൈസാക്കി മാറ്റുക
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// Ptr ഒരു മ്യൂട്ട് സ്ലൈസാക്കി മാറ്റുക
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// ഒരു ഘടകം ബഫറിൽ നിന്ന് നീക്കുന്നു
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// ഒരു ഘടകം ബഫറിലേക്ക് എഴുതുന്നു, അത് നീക്കുന്നു.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// ബഫർ പൂർണ്ണ ശേഷിയിലാണെങ്കിൽ `true` നൽകുന്നു.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// തന്നിരിക്കുന്ന ലോജിക്കൽ ഘടക സൂചികയ്‌ക്കായി അന്തർലീനമായ ബഫറിലെ സൂചിക നൽകുന്നു.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// തന്നിരിക്കുന്ന ലോജിക്കൽ എലമെൻറ് ഇൻഡെക്സ് + ആഡെൻഡിനായി അന്തർലീനമായ ബഫറിലെ സൂചിക നൽകുന്നു.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// തന്നിരിക്കുന്ന ലോജിക്കൽ ഘടക സൂചികയായ സബ്‌ട്രഹെൻഡിനായി അന്തർലീനമായ ബഫറിലെ സൂചിക നൽകുന്നു.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// src മുതൽ dst വരെ നീളമുള്ള മെമ്മറി ലെൻ ഒരു തുടർച്ചയായ ബ്ലോക്ക് പകർത്തുന്നു
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// src മുതൽ dst വരെ നീളമുള്ള മെമ്മറി ലെൻ ഒരു തുടർച്ചയായ ബ്ലോക്ക് പകർത്തുന്നു
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// src മുതൽ dest വരെ നീളമുള്ള മെമ്മറി ലെൻ പൊതിയാൻ സാധ്യതയുള്ള ബ്ലോക്ക് പകർത്തുന്നു.
    /// (abs(dst - src) + len) cap() നേക്കാൾ വലുതായിരിക്കരുത് (src നും dest നും ഇടയിൽ തുടർച്ചയായി ഒരു ഓവർലാപ്പിംഗ് പ്രദേശം ഉണ്ടായിരിക്കണം).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src പൊതിയുന്നില്ല, dst പൊതിയുന്നില്ല
                //
                //        എസ്...
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] ഡി.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // src ന് മുമ്പായി, src പൊതിയുന്നില്ല, dst പൊതിയുന്നു
                //
                //
                //    എസ്...
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. ഡി.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // Dst ന് മുമ്പുള്ള src, src പൊതിയുന്നില്ല, dst പൊതിയുന്നു
                //
                //
                //              എസ്...
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. ഡി.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // src, src പൊതിയുന്നതിനുമുമ്പ് dst പൊതിയുന്നില്ല
                //
                //
                //    .. എസ്.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] ഡി...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // Dst ന് മുമ്പുള്ള src, src പൊതിയുന്നു, dst പൊതിയുന്നില്ല
                //
                //
                //    .. എസ്.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] ഡി...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // src ന് മുമ്പുള്ള dst, src റാപ്പുകൾ, dst റാപ്പുകൾ
                //
                //
                //    ... എസ്.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. ഡി..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // Dst ന് മുമ്പുള്ള src, src റാപ്സ്, dst റാപ്സ്
                //
                //
                //    .. എസ്..
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G]... ഡി.
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// ഞങ്ങൾ വീണ്ടും അനുവദിച്ച വസ്തുത കൈകാര്യം ചെയ്യുന്നതിന് ചുറ്റുമുള്ള തല, വാൽ ഭാഗങ്ങൾ ഫ്രോബ് ചെയ്യുന്നു.
    /// സുരക്ഷിതമല്ലാത്തതിനാൽ ഇത് പഴയ_ ശേഷിയെ വിശ്വസിക്കുന്നു.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // റിംഗ് ബഫറിന്റെ ഏറ്റവും ചെറിയ തുടർച്ചയായ ഭാഗം നീക്കുക
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [...ooooooo......
        //          ] HT
        //   [o o o o o . o o ]
        //              HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // ഒരു നോപ്പ്
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// ഒരു ശൂന്യമായ `VecDeque` സൃഷ്ടിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// കുറഞ്ഞത് `capacity` ഘടകങ്ങൾക്കായുള്ള ഇടമുള്ള ശൂന്യമായ `VecDeque` സൃഷ്ടിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1 റിംഗ്ബഫർ എല്ലായ്പ്പോഴും ഒരു ഇടം ശൂന്യമാക്കും
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// തന്നിരിക്കുന്ന സൂചികയിലെ ഘടകത്തെക്കുറിച്ച് ഒരു റഫറൻസ് നൽകുന്നു.
    ///
    /// സൂചിക 0 ലെ ഘടകം ക്യൂവിന്റെ മുൻവശമാണ്.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// തന്നിരിക്കുന്ന സൂചികയിലെ ഘടകത്തിന് ഒരു മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു.
    ///
    /// സൂചിക 0 ലെ ഘടകം ക്യൂവിന്റെ മുൻവശമാണ്.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// `i`, `j` സൂചികകളിലെ ഘടകങ്ങൾ സ്വാപ്പ് ചെയ്യുന്നു.
    ///
    /// `i` ഒപ്പം `j` തുല്യമാകാം.
    ///
    /// സൂചിക 0 ലെ ഘടകം ക്യൂവിന്റെ മുൻവശമാണ്.
    ///
    /// # Panics
    ///
    /// ഒന്നുകിൽ സൂചിക പരിധിക്ക് പുറത്താണെങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// വീണ്ടും അനുവദിക്കാതെ തന്നെ `VecDeque`-ന് പിടിക്കാൻ കഴിയുന്ന ഘടകങ്ങളുടെ എണ്ണം നൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// തന്നിരിക്കുന്ന `VecDeque`-ൽ കൃത്യമായി `additional` കൂടുതൽ ഘടകങ്ങൾ ഉൾപ്പെടുത്താനുള്ള ഏറ്റവും കുറഞ്ഞ ശേഷി കരുതിവച്ചിരിക്കുന്നു.
    /// ശേഷി ഇതിനകം പര്യാപ്തമാണെങ്കിൽ ഒന്നും ചെയ്യുന്നില്ല.
    ///
    /// അലോക്കേറ്റർ ശേഖരണത്തിന് ആവശ്യപ്പെടുന്നതിനേക്കാൾ കൂടുതൽ ഇടം നൽകുമെന്നത് ശ്രദ്ധിക്കുക.
    /// അതിനാൽ ശേഷി കൃത്യമായി ചുരുങ്ങിയതായി ആശ്രയിക്കാനാവില്ല.
    /// future ഉൾപ്പെടുത്തലുകൾ പ്രതീക്ഷിക്കുന്നുണ്ടെങ്കിൽ [`reserve`] തിരഞ്ഞെടുക്കുക.
    ///
    /// # Panics
    ///
    /// പുതിയ ശേഷി `usize` കവിഞ്ഞൊഴുകുകയാണെങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// തന്നിരിക്കുന്ന `VecDeque`-ൽ ഉൾപ്പെടുത്തുന്നതിന് കുറഞ്ഞത് `additional` കൂടുതൽ ഘടകങ്ങൾക്കായുള്ള കരുതൽ ശേഷി.
    /// ഇടയ്ക്കിടെ വീണ്ടും അനുവദിക്കുന്നത് ഒഴിവാക്കാൻ ശേഖരം കൂടുതൽ ഇടം കരുതിവച്ചേക്കാം.
    ///
    /// # Panics
    ///
    /// പുതിയ ശേഷി `usize` കവിഞ്ഞൊഴുകുകയാണെങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// തന്നിരിക്കുന്ന `VecDeque<T>`-ൽ കൃത്യമായി `additional` കൂടുതൽ ഘടകങ്ങൾ ചേർക്കുന്നതിനുള്ള ഏറ്റവും കുറഞ്ഞ ശേഷി റിസർവ് ചെയ്യാൻ ശ്രമിക്കുന്നു.
    ///
    /// `try_reserve_exact` എന്ന് വിളിച്ചതിന് ശേഷം, ശേഷി `self.len() + additional` നേക്കാൾ വലുതോ തുല്യമോ ആയിരിക്കും.
    /// ശേഷി ഇതിനകം പര്യാപ്തമാണെങ്കിൽ ഒന്നും ചെയ്യുന്നില്ല.
    ///
    /// അലോക്കേറ്റർ ശേഖരണത്തിന് ആവശ്യപ്പെടുന്നതിനേക്കാൾ കൂടുതൽ ഇടം നൽകുമെന്നത് ശ്രദ്ധിക്കുക.
    /// അതിനാൽ, ശേഷി കൃത്യമായി ചുരുങ്ങിയതായി ആശ്രയിക്കാനാവില്ല.
    /// future ഉൾപ്പെടുത്തലുകൾ പ്രതീക്ഷിക്കുന്നുണ്ടെങ്കിൽ `reserve` തിരഞ്ഞെടുക്കുക.
    ///
    /// # Errors
    ///
    /// ശേഷി `usize` കവിഞ്ഞൊഴുകുകയോ അല്ലെങ്കിൽ അലോക്കേറ്റർ ഒരു പരാജയം റിപ്പോർട്ട് ചെയ്യുകയോ ചെയ്താൽ, ഒരു പിശക് മടക്കിനൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // മെമ്മറി മുൻകൂട്ടി റിസർവ് ചെയ്യുക, ഞങ്ങൾക്ക് കഴിയുന്നില്ലെങ്കിൽ പുറത്തുകടക്കുന്നു
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // ഞങ്ങളുടെ സങ്കീർണ്ണമായ ജോലിയുടെ മധ്യത്തിൽ ഇതിന് OOM(Out-Of-Memory) കഴിയില്ലെന്ന് ഇപ്പോൾ നമുക്കറിയാം
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // വളരെ സങ്കീർണ്ണമാണ്
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// തന്നിരിക്കുന്ന `VecDeque<T>`-ൽ ഉൾപ്പെടുത്തുന്നതിന് കുറഞ്ഞത് `additional` കൂടുതൽ ഘടകങ്ങൾക്കെങ്കിലും ശേഷി റിസർവ് ചെയ്യാൻ ശ്രമിക്കുന്നു.
    /// ഇടയ്ക്കിടെ വീണ്ടും അനുവദിക്കുന്നത് ഒഴിവാക്കാൻ ശേഖരം കൂടുതൽ ഇടം കരുതിവച്ചേക്കാം.
    /// `try_reserve` എന്ന് വിളിച്ചതിന് ശേഷം, ശേഷി `self.len() + additional` നേക്കാൾ വലുതോ തുല്യമോ ആയിരിക്കും.
    /// ശേഷി ഇതിനകം പര്യാപ്തമാണെങ്കിൽ ഒന്നും ചെയ്യുന്നില്ല.
    ///
    /// # Errors
    ///
    /// ശേഷി `usize` കവിഞ്ഞൊഴുകുകയോ അല്ലെങ്കിൽ അലോക്കേറ്റർ ഒരു പരാജയം റിപ്പോർട്ട് ചെയ്യുകയോ ചെയ്താൽ, ഒരു പിശക് മടക്കിനൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // മെമ്മറി മുൻകൂട്ടി റിസർവ് ചെയ്യുക, ഞങ്ങൾക്ക് കഴിയുന്നില്ലെങ്കിൽ പുറത്തുകടക്കുന്നു
    ///     output.try_reserve(data.len())?;
    ///
    ///     // ഞങ്ങളുടെ സങ്കീർണ്ണമായ ജോലിയുടെ മധ്യത്തിൽ ഇത് OOM ചെയ്യാൻ കഴിയില്ലെന്ന് ഇപ്പോൾ നമുക്കറിയാം
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // വളരെ സങ്കീർണ്ണമാണ്
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// `VecDeque` ന്റെ ശേഷി കഴിയുന്നിടത്തോളം ചുരുക്കുന്നു.
    ///
    /// ഇത് നീളത്തിനടുത്തായി താഴേക്ക് പതിക്കും, പക്ഷേ കുറച്ച് ഘടകങ്ങൾക്ക് കൂടുതൽ സ്ഥലമുണ്ടെന്ന് അലോക്കേറ്റർ ഇപ്പോഴും `VecDeque` നെ അറിയിച്ചേക്കാം.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// കുറഞ്ഞ പരിധിയിലുള്ള `VecDeque`-ന്റെ ശേഷി ചുരുക്കുന്നു.
    ///
    /// ശേഷി നീളവും നൽകിയ മൂല്യവും പോലെ വലുതായി തുടരും.
    ///
    ///
    /// നിലവിലെ ശേഷി താഴ്ന്ന പരിധിയേക്കാൾ കുറവാണെങ്കിൽ, ഇത് ഒരു നോ-ഒപ്പ് ആണ്.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // `self.len()` അല്ലെങ്കിൽ `self.capacity()` എന്നിവയ്‌ക്ക് ഒരിക്കലും `usize::MAX` ആകാൻ കഴിയാത്തതിനാൽ ഒരു ഓവർഫ്ലോയെക്കുറിച്ച് ഞങ്ങൾ വിഷമിക്കേണ്ടതില്ല.
        // റിംഗ്ബഫർ എല്ലായ്പ്പോഴും ഒരു ഇടം ശൂന്യമാക്കിയിരിക്കുന്നതിനാൽ +1.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // മൂന്ന് താൽപ്പര്യ കേസുകളുണ്ട്:
            //   എല്ലാ ഘടകങ്ങളും ആവശ്യമുള്ള പരിധിക്കു പുറത്താണ് ഘടകങ്ങൾ മൂലകങ്ങൾ, തല ആവശ്യമുള്ള അതിരുകൾക്ക് പുറത്താണ് ഘടകങ്ങൾ നിരന്തരമാണ്, വാൽ ആവശ്യമുള്ള അതിരുകൾക്ക് പുറത്താണ്
            //
            //
            // മറ്റെല്ലാ സമയത്തും, ഘടക സ്ഥാനങ്ങളെ ബാധിക്കില്ല.
            //
            // തലയിലെ ഘടകങ്ങൾ നീക്കണമെന്ന് സൂചിപ്പിക്കുന്നു.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // ആവശ്യമുള്ള അതിർത്തിയിൽ നിന്ന് ഘടകങ്ങൾ നീക്കുക (ടാർഗെറ്റ്_കാപ്പിന് ശേഷമുള്ള സ്ഥാനങ്ങൾ)
            if self.tail >= target_cap && head_outside {
                // ടി.എച്ച്
                //   [. . . . . . . . o o o o o o o . ]
                //    ടി.എച്ച്
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // ടി.എച്ച്
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // HT
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// `VecDeque` ചെറുതാക്കുന്നു, ആദ്യത്തെ `len` ഘടകങ്ങൾ സൂക്ഷിക്കുകയും ബാക്കിയുള്ളവ ഉപേക്ഷിക്കുകയും ചെയ്യുന്നു.
    ///
    ///
    /// `VecDeque` ന്റെ നിലവിലെ നീളത്തേക്കാൾ `len` വലുതാണെങ്കിൽ, ഇത് ഒരു ഫലവുമില്ല.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// സ്ലൈസ് ഉപേക്ഷിക്കുമ്പോൾ (സാധാരണയായി അല്ലെങ്കിൽ അറിയാതെ വരുമ്പോൾ) എല്ലാ ഇനങ്ങൾക്കും ഡിസ്ട്രക്റ്റർ പ്രവർത്തിപ്പിക്കുന്നു.
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // സുരക്ഷിതം കാരണം:
        //
        // * `drop_in_place` ലേക്ക് കൈമാറിയ ഏത് സ്ലൈസും സാധുവാണ്;രണ്ടാമത്തെ കേസിന് `len <= front.len()` ഉണ്ട്, `len > self.len()`-ലേക്ക് മടങ്ങുന്നത് ആദ്യ കേസിൽ `begin <= back.len()` ഉറപ്പാക്കുന്നു
        //
        // * `drop_in_place`-ലേക്ക് വിളിക്കുന്നതിന് മുമ്പ് VecDeque-ന്റെ തല നീക്കി, അതിനാൽ `drop_in_place` panics ആണെങ്കിൽ ഒരു മൂല്യവും രണ്ടുതവണ ഉപേക്ഷിക്കില്ല
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // ആദ്യ ZZpanics0Z-ലെ ഒരു ഡിസ്ട്രക്റ്റർ പോലും രണ്ടാം പകുതി ഉപേക്ഷിച്ചുവെന്ന് ഉറപ്പാക്കുക.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// ഒരു ഫ്രണ്ട്-ടു-ബാക്ക് ഇറ്ററേറ്റർ നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// മ്യൂട്ടബിൾ റഫറൻസുകൾ നൽകുന്ന ഒരു ഫ്രണ്ട്-ടു-ബാക്ക് ഇറ്ററേറ്റർ നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // സുരക്ഷ: ആന്തരിക `IterMut` സുരക്ഷാ മാറ്റം സ്ഥാപിച്ചു കാരണം
        // `ring` ഞങ്ങൾ‌സൃഷ്‌ടിക്കുന്നത് ആജീവനാന്തം ഒഴിവാക്കാൻ‌കഴിയുന്ന ഒരു സ്ലൈസാണ് '_.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// `VecDeque`-ന്റെ ഉള്ളടക്കങ്ങൾ ക്രമത്തിൽ അടങ്ങിയിരിക്കുന്ന ഒരു ജോടി സ്ലൈസുകൾ നൽകുന്നു.
    ///
    /// [`make_contiguous`] മുമ്പ് വിളിച്ചിരുന്നുവെങ്കിൽ, `VecDeque`-ന്റെ എല്ലാ ഘടകങ്ങളും ആദ്യ സ്ലൈസിലും രണ്ടാമത്തെ സ്ലൈസ് ശൂന്യമായും ആയിരിക്കും.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// `VecDeque`-ന്റെ ഉള്ളടക്കങ്ങൾ ക്രമത്തിൽ അടങ്ങിയിരിക്കുന്ന ഒരു ജോടി സ്ലൈസുകൾ നൽകുന്നു.
    ///
    /// [`make_contiguous`] മുമ്പ് വിളിച്ചിരുന്നുവെങ്കിൽ, `VecDeque`-ന്റെ എല്ലാ ഘടകങ്ങളും ആദ്യ സ്ലൈസിലും രണ്ടാമത്തെ സ്ലൈസ് ശൂന്യമായും ആയിരിക്കും.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// `VecDeque`-ലെ ഘടകങ്ങളുടെ എണ്ണം നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// `VecDeque` ശൂന്യമാണെങ്കിൽ `true` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// `VecDeque`-ൽ നിർദ്ദിഷ്ട ശ്രേണി ഉൾക്കൊള്ളുന്ന ഒരു ഇറ്ററേറ്റർ സൃഷ്‌ടിക്കുന്നു.
    ///
    /// # Panics
    ///
    /// ആരംഭ പോയിന്റ് അവസാന പോയിന്റിനേക്കാൾ വലുതാണെങ്കിൽ അല്ലെങ്കിൽ അവസാന പോയിന്റ് vector ന്റെ നീളത്തേക്കാൾ വലുതാണെങ്കിൽ Panics.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // ഒരു പൂർണ്ണ ശ്രേണി എല്ലാ ഉള്ളടക്കങ്ങളും ഉൾക്കൊള്ളുന്നു
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // &self-ൽ ഞങ്ങൾക്ക് പങ്കിട്ട റഫറൻസ് ഈറ്ററിന്റെ _ _ ൽ നിലനിർത്തുന്നു.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// `VecDeque`-ൽ നിർദ്ദിഷ്ട മ്യൂട്ടബിൾ ശ്രേണി ഉൾക്കൊള്ളുന്ന ഒരു ഇറ്ററേറ്റർ സൃഷ്‌ടിക്കുന്നു.
    ///
    /// # Panics
    ///
    /// ആരംഭ പോയിന്റ് അവസാന പോയിന്റിനേക്കാൾ വലുതാണെങ്കിൽ അല്ലെങ്കിൽ അവസാന പോയിന്റ് vector ന്റെ നീളത്തേക്കാൾ വലുതാണെങ്കിൽ Panics.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // ഒരു പൂർണ്ണ ശ്രേണി എല്ലാ ഉള്ളടക്കങ്ങളും ഉൾക്കൊള്ളുന്നു
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // സുരക്ഷ: ആന്തരിക `IterMut` സുരക്ഷാ മാറ്റം സ്ഥാപിച്ചു കാരണം
        // `ring` ഞങ്ങൾ‌സൃഷ്‌ടിക്കുന്നത് ആജീവനാന്തം ഒഴിവാക്കാൻ‌കഴിയുന്ന ഒരു സ്ലൈസാണ് '_.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// `VecDeque`-ലെ നിർദ്ദിഷ്ട ശ്രേണി നീക്കംചെയ്യുകയും നീക്കംചെയ്‌ത ഇനങ്ങൾ നൽകുകയും ചെയ്യുന്ന ഒരു ഡ്രെയിനിംഗ് ഇറ്ററേറ്റർ സൃഷ്‌ടിക്കുന്നു.
    ///
    /// കുറിപ്പ് 1: അവസാനം വരെ ഇറ്ററേറ്റർ ഉപയോഗിച്ചില്ലെങ്കിലും ഘടക ശ്രേണി നീക്കംചെയ്യപ്പെടും.
    ///
    /// കുറിപ്പ് 2: `Drain` മൂല്യം ഉപേക്ഷിച്ചില്ലെങ്കിൽ, ഡെക്കിൽ നിന്ന് എത്ര ഘടകങ്ങൾ നീക്കംചെയ്യുന്നുവെന്ന് വ്യക്തമല്ല, പക്ഷേ അത് കൈവശമുള്ള വായ്പ കാലഹരണപ്പെടും (ഉദാ. `mem::forget` കാരണം).
    ///
    ///
    /// # Panics
    ///
    /// ആരംഭ പോയിന്റ് അവസാന പോയിന്റിനേക്കാൾ വലുതാണെങ്കിൽ അല്ലെങ്കിൽ അവസാന പോയിന്റ് vector ന്റെ നീളത്തേക്കാൾ വലുതാണെങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // ഒരു പൂർണ്ണ ശ്രേണി എല്ലാ ഉള്ളടക്കങ്ങളും മായ്‌ക്കുന്നു
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // മെമ്മറി സുരക്ഷ
        //
        // Drain ആദ്യമായി സൃഷ്ടിക്കുമ്പോൾ, Drain ന്റെ ഡിസ്ട്രക്റ്റർ ഒരിക്കലും പ്രവർത്തിപ്പിക്കാതിരുന്നാൽ, ആരംഭിക്കാത്തതോ നീക്കിയതോ ആയ ഘടകങ്ങളൊന്നും ആക്‌സസ്സുചെയ്യാനാകില്ലെന്ന് ഉറപ്പാക്കുന്നതിന് ഉറവിട ഡെക്ക് ചുരുക്കിയിരിക്കുന്നു.
        //
        //
        // Drain നീക്കംചെയ്യാനുള്ള മൂല്യങ്ങൾ ptr::read ചെയ്യും.
        // പൂർത്തിയാകുമ്പോൾ, ദ്വാരം മറയ്ക്കുന്നതിന് ശേഷിക്കുന്ന ഡാറ്റ തിരികെ പകർത്തും, കൂടാതെ head/tail മൂല്യങ്ങൾ ശരിയായി പുന ored സ്ഥാപിക്കപ്പെടും.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // ഡെക്യൂവിന്റെ ഘടകങ്ങൾ മൂന്ന് ഭാഗങ്ങളായി വിഭജിച്ചിരിക്കുന്നു:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // ടി=എക്സ് 00 എക്സ്;H= self.head;t=drain_tail;h=drain_head
        //
        // ഞങ്ങൾ drain_tail, self.head, drain_head, self.head എന്നിവ യഥാക്രമം after0tail, after_head എന്നിവ Drain ൽ സംഭരിക്കുന്നു.
        // ഇതും ഫലപ്രദമായ അറേയെ വെട്ടിച്ചുരുക്കുന്നു, അതായത് Drain ചോർന്നാൽ, drain ആരംഭിച്ചതിനുശേഷം നീക്കാൻ സാധ്യതയുള്ള മൂല്യങ്ങളെക്കുറിച്ച് ഞങ്ങൾ മറന്നു.
        //
        //
        //        ടി th എച്ച്
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" drain ആരംഭിച്ചതിന് ശേഷം drain പൂർത്തിയായി Drain ഡിസ്ട്രക്റ്റർ പ്രവർത്തിപ്പിക്കുന്നതുവരെ മൂല്യങ്ങളെക്കുറിച്ച്.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // നിർണായകമായി, ഞങ്ങൾ ഇവിടെ `self`-ൽ നിന്ന് പങ്കിട്ട റഫറൻസുകൾ മാത്രം സൃഷ്ടിക്കുകയും അതിൽ നിന്ന് വായിക്കുകയും ചെയ്യുന്നു.
                // ഞങ്ങൾ `self`-ലേക്ക് എഴുതുകയോ മ്യൂട്ടബിൾ റഫറൻസിലേക്ക് റീബറോ ചെയ്യുകയോ ചെയ്യുന്നില്ല.
                // അതിനാൽ `deque`-നായി ഞങ്ങൾ മുകളിൽ സൃഷ്ടിച്ച റോ പോയിന്റർ സാധുവായി തുടരുന്നു.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// എല്ലാ മൂല്യങ്ങളും നീക്കംചെയ്ത് `VecDeque` മായ്‌ക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// തന്നിരിക്കുന്ന മൂല്യത്തിന് തുല്യമായ ഒരു ഘടകം `VecDeque`-ൽ ഉണ്ടെങ്കിൽ `true` നൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// മുൻ ഘടകത്തിലേക്ക് ഒരു റഫറൻസ് നൽകുന്നു, അല്ലെങ്കിൽ `VecDeque` ശൂന്യമാണെങ്കിൽ `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// ഫ്രണ്ട് എലമെന്റിന് ഒരു മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു, അല്ലെങ്കിൽ `VecDeque` ശൂന്യമാണെങ്കിൽ `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// ബാക്ക് എലമെന്റിന് ഒരു റഫറൻസ് നൽകുന്നു, അല്ലെങ്കിൽ `VecDeque` ശൂന്യമാണെങ്കിൽ `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// ബാക്ക് എലമെന്റിന് ഒരു മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു, അല്ലെങ്കിൽ `VecDeque` ശൂന്യമാണെങ്കിൽ `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// ആദ്യ ഘടകം നീക്കംചെയ്‌ത് അത് നൽകുന്നു, അല്ലെങ്കിൽ `VecDeque` ശൂന്യമാണെങ്കിൽ `None`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// `VecDeque`-ൽ നിന്ന് അവസാന ഘടകം നീക്കംചെയ്യുകയും അത് തിരികെ നൽകുകയും ചെയ്യുന്നു, അല്ലെങ്കിൽ `None` ശൂന്യമാണെങ്കിൽ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// `VecDeque`-ലേക്ക് ഒരു ഘടകം തയ്യാറാക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// `VecDeque`-ന്റെ പിന്നിലേക്ക് ഒരു ഘടകം കൂട്ടിച്ചേർക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: `head == 0` എന്നതിനർത്ഥം
        // `self` തുടർച്ചയായതാണോ?
        self.tail <= self.head
    }

    /// `VecDeque`-ൽ എവിടെ നിന്നും ഒരു ഘടകം നീക്കംചെയ്യുകയും അത് തിരികെ നൽകുകയും ചെയ്യുന്നു, അത് ആദ്യ ഘടകം ഉപയോഗിച്ച് മാറ്റിസ്ഥാപിക്കുന്നു.
    ///
    ///
    /// ഇത് ഓർ‌ഡറിംഗ് സംരക്ഷിക്കുന്നില്ല, പക്ഷേ *O*(1) ആണ്.
    ///
    /// `index` പരിധിക്ക് പുറത്താണെങ്കിൽ `None` നൽകുന്നു.
    ///
    /// സൂചിക 0 ലെ ഘടകം ക്യൂവിന്റെ മുൻവശമാണ്.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// `VecDeque`-ൽ എവിടെനിന്നും ഒരു ഘടകം നീക്കംചെയ്‌ത് അത് തിരികെ നൽകുന്നു, അവസാന ഘടകം ഉപയോഗിച്ച് അത് മാറ്റിസ്ഥാപിക്കുന്നു.
    ///
    ///
    /// ഇത് ഓർ‌ഡറിംഗ് സംരക്ഷിക്കുന്നില്ല, പക്ഷേ *O*(1) ആണ്.
    ///
    /// `index` പരിധിക്ക് പുറത്താണെങ്കിൽ `None` നൽകുന്നു.
    ///
    /// സൂചിക 0 ലെ ഘടകം ക്യൂവിന്റെ മുൻവശമാണ്.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// `VecDeque`-നുള്ളിൽ `index`-ൽ ഒരു ഘടകം ചേർക്കുന്നു, `index`-നേക്കാൾ വലുതോ തുല്യമോ ആയ സൂചികകളുള്ള എല്ലാ ഘടകങ്ങളും പിന്നിലേക്ക് മാറ്റുന്നു.
    ///
    ///
    /// സൂചിക 0 ലെ ഘടകം ക്യൂവിന്റെ മുൻവശമാണ്.
    ///
    /// # Panics
    ///
    /// `VecDeque` ന്റെ നീളത്തേക്കാൾ `index` വലുതാണെങ്കിൽ Panics
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // റിംഗ് ബഫറിലെ ഏറ്റവും കുറഞ്ഞ ഘടകങ്ങൾ‌നീക്കി തന്നിരിക്കുന്ന ഒബ്‌ജക്റ്റ് ചേർക്കുക
        //
        // പരമാവധി len/2 ൽ, 1 ഘടകങ്ങൾ നീക്കും. O(min(n, n-i))
        //
        // മൂന്ന് പ്രധാന കേസുകളുണ്ട്:
        //  ഘടകങ്ങൾ തുടർച്ചയാണ്
        //      - വാൽ 0 ആയിരിക്കുമ്പോൾ പ്രത്യേക കേസ് ഘടകങ്ങൾ നിരന്തരവും തിരുകൽ വാൽ വിഭാഗത്തിലുമാണ് ഘടകങ്ങൾ നിരന്തരവും തിരുകൽ തല വിഭാഗത്തിലും
        //
        //
        // ഓരോന്നിനും രണ്ട് കേസുകൾ കൂടി ഉണ്ട്:
        //  തിരുകുക വാലിനടുത്താണ് തിരുകുക തലയോട് അടുക്കുന്നു
        //
        // കീ: H, self.head
        //      T, self.tail o, സാധുവായ ഘടകം I, ഉൾപ്പെടുത്തൽ ഘടകം A, ഉൾപ്പെടുത്തൽ പോയിന്റ് M ന് ശേഷം ആയിരിക്കേണ്ട ഘടകം, ഘടകം നീക്കിയതായി സൂചിപ്പിക്കുന്നു
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [ഒരു oooooo.......
                //      .
                //      .]
                //
                //                       HT
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // തുടർച്ചയായ, വാലിനോട് ചേർത്ത് ചേർക്കുക:
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           ടി.എച്ച്
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // തുടർച്ചയായി, വാലിനോടും വാലിനോടും അടുത്ത് ചേർക്കുക 0:
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       HT
                    //      [o I A o o o o o . . . . . . . o]
                    //       എം.എം.

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // ഇതിനകം വാൽ നീക്കി, അതിനാൽ ഞങ്ങൾ `index - 1` ഘടകങ്ങൾ മാത്രമേ പകർത്തുകയുള്ളൂ.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // തുടർച്ചയായ, തലയോട് അടുത്ത് ചേർക്കുക:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             ടി.എച്ച്
                    //      [. . . o o o o I A o o . . . . .]
                    //                       എം.എം.എം.

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // നിരന്തരമായി, വാലിനടുത്തായി തിരുകുക, വാൽ ഭാഗം:
                    //
                    //                   എച്ച്.ടി.ഐ
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // നിരന്തരമായ, തലയോട് അടുത്ത് ചേർക്കുക, വാൽ ഭാഗം:
                    //
                    //           എച്ച്.ടി.ഐ
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             HT
                    //      [o o o . . . . . . o o o o o I A]
                    //       എം.എം.എം.എം.

                    // ഘടകങ്ങൾ പുതിയ തലയിലേക്ക് പകർത്തുക
                    self.copy(1, 0, self.head);

                    // അവസാന ഘടകം ബഫറിന്റെ ചുവടെയുള്ള ശൂന്യമായ സ്ഥലത്തേക്ക് പകർത്തുക
                    self.copy(0, self.cap() - 1, 1);

                    // ^ ഘടകം ഉൾപ്പെടുത്താതെ ഘടകങ്ങൾ ഐഡിഎക്‌സിൽ നിന്ന് അവസാനത്തിലേക്ക് നീക്കുക
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // നിരന്തരമായി, ഉൾപ്പെടുത്തൽ വാൽ, ഹെഡ് സെക്ഷന് അടുത്താണ്, മാത്രമല്ല ആന്തരിക ബഫറിലെ സൂചിക പൂജ്യത്തിലാണ്:
                    //
                    //
                    //       IHT
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [A o o o o o o o o o . . o o o I]
                    //                               എം.എം.എം.

                    // പുതിയ വാൽ വരെ ഘടകങ്ങൾ പകർത്തുക
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // അവസാന ഘടകം ബഫറിന്റെ ചുവടെയുള്ള ശൂന്യമായ സ്ഥലത്തേക്ക് പകർത്തുക
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // നിരന്തരമായ, വാലിനോട് ചേർത്ത്, തല ഭാഗം:
                    //
                    //             IHT
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o I A o o o o o o . . o o o o]
                    //       MMMMMMM

                    // പുതിയ വാൽ വരെ ഘടകങ്ങൾ പകർത്തുക
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // അവസാന ഘടകം ബഫറിന്റെ ചുവടെയുള്ള ശൂന്യമായ സ്ഥലത്തേക്ക് പകർത്തുക
                    self.copy(self.cap() - 1, 0, 1);

                    // 00 ഘടകം ഉൾപ്പെടാതെ idx-1-ൽ നിന്ന് ഘടകങ്ങൾ മുന്നോട്ട് നീക്കുക
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // നിരന്തരമായ, തലയോട് അടുത്ത് ചേർക്കുക, തല വിഭാഗം:
                    //
                    //               IHT
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     HT
                    //      [o o o o I A o o . . . . . o o o]
                    //                 എം.എം.എം.

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // വാൽ മാറ്റിയിരിക്കാം, അതിനാൽ ഞങ്ങൾ വീണ്ടും കണക്കാക്കേണ്ടതുണ്ട്
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// `VecDeque`-ൽ നിന്ന് `index`-ലെ ഘടകം നീക്കംചെയ്യുകയും തിരികെ നൽകുകയും ചെയ്യുന്നു.
    /// ഏത് അവസാനമാണ് നീക്കംചെയ്യൽ പോയിന്റിലേക്ക് അടുക്കുന്നതെങ്കിൽ അത് മുറിയിലേക്ക് മാറ്റപ്പെടും, മാത്രമല്ല ബാധിച്ച ഘടകങ്ങളെല്ലാം പുതിയ സ്ഥാനങ്ങളിലേക്ക് മാറ്റുകയും ചെയ്യും.
    ///
    /// `index` പരിധിക്ക് പുറത്താണെങ്കിൽ `None` നൽകുന്നു.
    ///
    /// സൂചിക 0 ലെ ഘടകം ക്യൂവിന്റെ മുൻവശമാണ്.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // മൂന്ന് പ്രധാന കേസുകളുണ്ട്:
        //  ഘടകങ്ങൾ‌തുടർച്ചയാണ് ഘടകങ്ങൾ‌നിരന്തരവും നീക്കംചെയ്യൽ‌വാൽ‌വിഭാഗത്തിലുമാണ് ഘടകങ്ങൾ‌നിരന്തരവും നീക്കംചെയ്യൽ‌പ്രധാന വിഭാഗത്തിലും
        //
        //      - ഘടകങ്ങൾ സാങ്കേതികമായി തുടരുമ്പോൾ പ്രത്യേക കേസ്, പക്ഷേ self.head =0
        //
        // ഓരോന്നിനും രണ്ട് കേസുകൾ കൂടി ഉണ്ട്:
        //  തിരുകുക വാലിനടുത്താണ് തിരുകുക തലയോട് അടുക്കുന്നു
        //
        // കീ: H, self.head
        //      T, self.tail o, സാധുവായ ഘടകം x, നീക്കംചെയ്യുന്നതിന് അടയാളപ്പെടുത്തിയ ഘടകം R, നീക്കംചെയ്യുന്ന ഘടകത്തെ സൂചിപ്പിക്കുന്നു M, ഘടകം നീക്കി എന്ന് സൂചിപ്പിക്കുന്നു
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // തുടർച്ചയായ, വാലിനടുത്തായി നീക്കംചെയ്യുക:
                    //
                    //             TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               ടി.എച്ച്
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // തുടർച്ചയായ, തലയോട് അടുത്ത് നീക്കംചെയ്യുക:
                    //
                    //             TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             ടി.എച്ച്
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // നിരന്തരമായി, വാലിനടുത്തായി നീക്കംചെയ്യുക, വാൽ ഭാഗം:
                    //
                    //                   HTR
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // നിരന്തരമായി, തലയോട് അടുത്ത് നീക്കംചെയ്യുക, തല വിഭാഗം:
                    //
                    //               RHT
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // നിരന്തരമായി, തലയോട് അടുത്ത് നീക്കംചെയ്യുക, വാൽ ഭാഗം:
                    //
                    //             HTR
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           HT
                    //      [o o . . . . . . . o o o o o o o]
                    //       എം.എം.എം.എം.
                    //
                    // അല്ലെങ്കിൽ അർദ്ധ-നിരന്തരമായി, തലയുടെ അടുത്തായി നീക്കംചെയ്യുക, വാൽ ഭാഗം:
                    //
                    //       HTR
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         ടി.എച്ച്
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // വാൽ വിഭാഗത്തിലെ ഘടകങ്ങൾ വരയ്ക്കുക
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // ഒഴുക്ക് തടയുന്നു.
                    if self.head != 0 {
                        // ആദ്യ ഘടകം ശൂന്യമായ സ്ഥലത്തേക്ക് പകർത്തുക
                        self.copy(self.cap() - 1, 0, 1);

                        // തല വിഭാഗത്തിലെ ഘടകങ്ങൾ പിന്നിലേക്ക് നീക്കുക
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // നിരന്തരമായി, വാലിനടുത്തായി നീക്കംചെയ്യുക, തല വിഭാഗം:
                    //
                    //           RHT
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o o o o o o o o o . . . . o o]
                    //       എം.എം.എം.എം.എം.

                    // idx വരെ ഘടകങ്ങൾ വരയ്ക്കുക
                    self.copy(1, 0, idx);

                    // അവസാന ഘടകം ശൂന്യമായ സ്ഥലത്തേക്ക് പകർത്തുക
                    self.copy(0, self.cap() - 1, 1);

                    // അവസാനത്തേത് ഒഴികെ ഘടകങ്ങൾ വാലിൽ നിന്ന് അവസാനത്തിലേക്ക് നീക്കുക
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// തന്നിരിക്കുന്ന സൂചികയിൽ `VecDeque` രണ്ടായി വിഭജിക്കുന്നു.
    ///
    /// പുതുതായി അനുവദിച്ച `VecDeque` നൽകുന്നു.
    /// `self` `[0, at)` ഘടകങ്ങൾ അടങ്ങിയിരിക്കുന്നു, മടങ്ങിയ `VecDeque`-ൽ `[at, len)` ഘടകങ്ങൾ അടങ്ങിയിരിക്കുന്നു.
    ///
    /// `self` ന്റെ ശേഷി മാറില്ലെന്നത് ശ്രദ്ധിക്കുക.
    ///
    /// സൂചിക 0 ലെ ഘടകം ക്യൂവിന്റെ മുൻവശമാണ്.
    ///
    /// # Panics
    ///
    /// `at > len` എങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` ആദ്യ പകുതിയിൽ കിടക്കുന്നു.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // രണ്ടാം പകുതി മുഴുവൻ എടുക്കുക.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` രണ്ടാം പകുതിയിൽ സ്ഥിതിചെയ്യുന്നു, ആദ്യ പകുതിയിൽ ഞങ്ങൾ ഒഴിവാക്കിയ ഘടകങ്ങളെ ഘടകമാക്കേണ്ടതുണ്ട്.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // ബഫറുകളുടെ അറ്റങ്ങൾ ഉള്ളിടത്ത് വൃത്തിയാക്കൽ
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// `other`-ന്റെ എല്ലാ ഘടകങ്ങളും `self`-ലേക്ക് നീക്കുന്നു, `other` ശൂന്യമാക്കും.
    ///
    /// # Panics
    ///
    /// സ്വയത്തിലെ പുതിയ ഘടകങ്ങളുടെ എണ്ണം ഒരു `usize` കവിഞ്ഞൊഴുകുകയാണെങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // നിഷ്കളങ്കമായ impl
        self.extend(other.drain(..));
    }

    /// പ്രവചിക്കുക വ്യക്തമാക്കിയ ഘടകങ്ങൾ മാത്രം നിലനിർത്തുന്നു.
    ///
    /// മറ്റൊരു വിധത്തിൽ പറഞ്ഞാൽ,`e` എല്ലാ ഘടകങ്ങളും നീക്കംചെയ്യുക, അതായത് `f(&e)` തെറ്റായി നൽകുന്നു.
    /// ഈ രീതി സ്ഥലത്ത് പ്രവർത്തിക്കുന്നു, ഓരോ ഘടകങ്ങളും യഥാർത്ഥ ക്രമത്തിൽ കൃത്യമായി ഒരിക്കൽ സന്ദർശിക്കുകയും നിലനിർത്തുന്ന മൂലകങ്ങളുടെ ക്രമം സംരക്ഷിക്കുകയും ചെയ്യുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// ഒരു സൂചിക പോലെ ബാഹ്യ അവസ്ഥ ട്രാക്കുചെയ്യുന്നതിന് കൃത്യമായ ക്രമം ഉപയോഗപ്രദമാകും.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // ഇത് panic അല്ലെങ്കിൽ നിർത്തലാക്കാം
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // ബഫർ വലുപ്പം ഇരട്ടിയാക്കുക.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// `VecDeque` ഇൻ-പ്ലേസ് പരിഷ്‌ക്കരിക്കുന്നു, അതിനാൽ `len()` `new_len`-ന് തുല്യമാണ്, പിന്നിൽ നിന്ന് അധിക ഘടകങ്ങൾ നീക്കംചെയ്യുന്നതിലൂടെയോ അല്ലെങ്കിൽ `generator`-നെ പിന്നിലേക്ക് വിളിച്ച് ജനറേറ്റുചെയ്‌ത ഘടകങ്ങൾ കൂട്ടിച്ചേർക്കുന്നതിലൂടെയോ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// ഈ ഡെക്കിന്റെ ആന്തരിക സംഭരണം പുന ran ക്രമീകരിക്കുന്നു, അതിനാൽ ഇത് ഒരു തുടർച്ചയായ സ്ലൈസാണ്, അത് തിരികെ നൽകും.
    ///
    /// ഈ രീതി അനുവദിക്കുന്നില്ല കൂടാതെ ചേർത്ത ഘടകങ്ങളുടെ ക്രമം മാറ്റില്ല.ഇത് ഒരു മ്യൂട്ടബിൾ സ്ലൈസ് നൽകുമ്പോൾ, ഒരു ഡെക്ക് അടുക്കാൻ ഇത് ഉപയോഗിക്കാം.
    ///
    /// ആന്തരിക സംഭരണം തുടർന്നുകഴിഞ്ഞാൽ, [`as_slices`], [`as_mut_slices`] രീതികൾ `VecDeque`-ന്റെ മുഴുവൻ ഉള്ളടക്കങ്ങളും ഒരൊറ്റ സ്ലൈസിൽ നൽകും.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// ഒരു ഡെക്യൂവിന്റെ ഉള്ളടക്കം അടുക്കുന്നു.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // ഡെക്ക് അടുക്കുന്നു
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // വിപരീത ക്രമത്തിൽ അടുക്കുന്നു
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// തുടർച്ചയായ സ്ലൈസിലേക്ക് മാറ്റമില്ലാത്ത ആക്സസ് നേടുക.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // `buf`-ലേക്ക് മാറ്റമില്ലാത്ത ആക്‌സസ് ഉള്ളപ്പോൾ തന്നെ `slice`-ൽ ഡെക്കിന്റെ എല്ലാ ഘടകങ്ങളും അടങ്ങിയിരിക്കുന്നുവെന്ന് ഞങ്ങൾക്ക് ഉറപ്പിക്കാം.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // ഒറ്റയടിക്ക് വാൽ പകർത്താൻ മതിയായ ഇടമുണ്ട്, ഇതിനർത്ഥം ഞങ്ങൾ ആദ്യം തല പിന്നിലേക്ക് മാറ്റുകയും തുടർന്ന് ശരിയായ സ്ഥാനത്തേക്ക് വാൽ പകർത്തുകയും ചെയ്യുന്നു എന്നാണ്.
            //
            //
            // അയച്ചയാൾ: DEFGH .... ABC
            // സ്വീകർത്താവ്: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: ഞങ്ങൾ നിലവിൽ പരിഗണിക്കുന്നില്ല .... ABCDEFGH
            // ഈ സാഹചര്യത്തിൽ `head` `0` ആയതിനാൽ തുടർച്ചയായിരിക്കണം.
            // ഞങ്ങൾ‌ക്ക് ഇത് മാറ്റാൻ‌താൽ‌പ്പര്യമുണ്ടെങ്കിലും ഇത് നിസ്സാരമല്ല, കാരണം `is_contiguous`, `buf[tail..head]` ഉപയോഗിച്ച് സ്ലൈസ് ചെയ്യാൻ‌കഴിയുമെന്ന് കുറച്ച് സ്ഥലങ്ങൾ‌പ്രതീക്ഷിക്കുന്നു.
            //
            //

            // ഒറ്റയടിക്ക് തല പകർത്താൻ മതിയായ ഇടമുണ്ട്, ഇതിനർത്ഥം ഞങ്ങൾ ആദ്യം വാൽ മുന്നോട്ട് നീക്കി, തുടർന്ന് തല ശരിയായ സ്ഥാനത്തേക്ക് പകർത്തുക എന്നാണ്.
            //
            //
            // അയച്ചയാൾ: FGH .... ABCDE
            // സ്വീകർത്താവ്: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // ഫ്രീ എന്നത് തലയെയും വാലിനേക്കാളും ചെറുതാണ്, ഇതിനർത്ഥം നമുക്ക് വാലും തലയും പതുക്കെ "swap" ചെയ്യണം എന്നാണ്.
            //
            //
            // പ്രേഷിതാവ്: EFGHI ... ABCD അല്ലെങ്കിൽ HIJK.ABCDEFG
            // സ്വീകർത്താവ്: ABCDEFGHI ... അല്ലെങ്കിൽ ABCDEFGHIJK.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // പൊതുവായ പ്രശ്നം ഇത് പോലെ തോന്നുന്നു
                //                  - ഒരു പുതിയ (smaller) സ്റ്റോർ ഉപയോഗിച്ച് അൽഗോരിതം പുനരാരംഭിക്കുക ചിലപ്പോൾ വലത് edge ബഫറിന്റെ അവസാനമാകുമ്പോൾ താൽക്കാലിക സ്റ്റോറിൽ എത്തിച്ചേരും, ഇതിനർത്ഥം കുറച്ച് സ്വാപ്പുകൾ ഉപയോഗിച്ച് ഞങ്ങൾ ശരിയായ ക്രമത്തിൽ എത്തിയിരിക്കുന്നു എന്നാണ്!
                //
                // E.g
                // EF..ABCD ABCDEF .., നാല് സ്വാപ്പുകൾക്ക് ശേഷം ഞങ്ങൾ പൂർത്തിയാക്കി
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// ഇരട്ട-അവസാന ക്യൂ `mid` സ്ഥലങ്ങൾ ഇടത്തേക്ക് തിരിക്കുന്നു.
    ///
    /// Equivalently,
    /// - `mid` ഇനം ആദ്യ സ്ഥാനത്തേക്ക് തിരിക്കുന്നു.
    /// - ആദ്യത്തെ `mid` ഇനങ്ങൾ പോപ്പ് ചെയ്ത് അവസാനം വരെ തള്ളുന്നു.
    /// - `len() - mid` സ്ഥലങ്ങൾ വലത്തേക്ക് തിരിക്കുന്നു.
    ///
    /// # Panics
    ///
    /// `mid` `len()` നേക്കാൾ വലുതാണെങ്കിൽ.
    /// `mid == len()` _not_ panic ചെയ്യുന്നുവെന്നും ഇത് ഒരു നോ-ഒപ്പ് റൊട്ടേഷനാണെന്നും ശ്രദ്ധിക്കുക.
    ///
    /// # Complexity
    ///
    /// `*O*(min(mid, len() - mid))` സമയമെടുക്കുന്നു, അധിക ഇടമില്ല.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// ഇരട്ട-അവസാന ക്യൂ `k` സ്ഥലങ്ങൾ വലത്തേക്ക് തിരിക്കുന്നു.
    ///
    /// Equivalently,
    /// - ആദ്യ ഇനം `k` സ്ഥാനത്തേക്ക് തിരിക്കുന്നു.
    /// - അവസാന `k` ഇനങ്ങൾ പോപ്പ് ചെയ്ത് മുന്നിലേക്ക് തള്ളുന്നു.
    /// - `len() - k` സ്ഥലങ്ങൾ ഇടത്തേക്ക് തിരിക്കുന്നു.
    ///
    /// # Panics
    ///
    /// `k` `len()` നേക്കാൾ വലുതാണെങ്കിൽ.
    /// `k == len()` _not_ panic ചെയ്യുന്നുവെന്നും ഇത് ഒരു നോ-ഒപ്പ് റൊട്ടേഷനാണെന്നും ശ്രദ്ധിക്കുക.
    ///
    /// # Complexity
    ///
    /// `*O*(min(k, len() - k))` സമയമെടുക്കുന്നു, അധിക ഇടമില്ല.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // സുരക്ഷ: ഇനിപ്പറയുന്ന രണ്ട് രീതികൾക്ക് റൊട്ടേഷൻ തുക ആവശ്യമാണ്
    // ഡെക്കിന്റെ നീളത്തിന്റെ പകുതിയിൽ താഴെയായിരിക്കുക.
    //
    // `wrap_copy` `min(x, cap() - x) + copy_len <= cap()` ആവശ്യപ്പെടുന്നു, എന്നാൽ X01 നെക്കാൾ ഒരിക്കലും ശേഷിയുടെ പകുതിയിൽ കൂടുതലല്ല, അതിനാൽ ഇവിടെ വിളിക്കുന്നത് നല്ലതാണ്, കാരണം ഞങ്ങൾ വിളിക്കുന്നത് പകുതി നീളത്തിൽ കുറവുള്ള ഒന്നാണ്, അത് ഒരിക്കലും ശേഷിയുടെ പകുതിക്ക് മുകളിലല്ല.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// തന്നിരിക്കുന്ന ഘടകത്തിനായി ബൈനറി ഈ അടുക്കിയ `VecDeque` തിരയുന്നു.
    ///
    /// മൂല്യം കണ്ടെത്തിയാൽ, പൊരുത്തപ്പെടുന്ന ഘടകത്തിന്റെ സൂചിക അടങ്ങിയ [`Result::Ok`] മടക്കിനൽകുന്നു.
    /// ഒന്നിലധികം മത്സരങ്ങളുണ്ടെങ്കിൽ, ഏതെങ്കിലും ഒരു മത്സരം മടക്കിനൽകാം.
    /// മൂല്യം കണ്ടെത്തിയില്ലെങ്കിൽ, അടുക്കിയ ക്രമം നിലനിർത്തിക്കൊണ്ട് പൊരുത്തപ്പെടുന്ന ഘടകം ഉൾപ്പെടുത്താൻ കഴിയുന്ന സൂചിക അടങ്ങിയ [`Result::Err`] മടക്കിനൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// നാല് ഘടകങ്ങളുടെ ഒരു ശ്രേണി തിരയുന്നു.
    /// ആദ്യത്തേത് അദ്വിതീയമായി നിർണ്ണയിക്കപ്പെട്ട സ്ഥാനത്തോടെ കണ്ടെത്തി;രണ്ടാമത്തെയും മൂന്നാമത്തെയും കണ്ടെത്തിയില്ല;നാലാമത്തേതിന് `[1, 4]`-ലെ ഏത് സ്ഥാനവുമായും പൊരുത്തപ്പെടാം.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// അടുക്കിയ ക്രമം നിലനിർത്തിക്കൊണ്ടുതന്നെ, അടുക്കിയ `VecDeque`-ലേക്ക് ഒരു ഇനം ചേർക്കാൻ നിങ്ങൾ ആഗ്രഹിക്കുന്നുവെങ്കിൽ:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// ഒരു താരതമ്യ ഫംഗ്ഷൻ ഉപയോഗിച്ച് ബൈനറി ഈ അടുക്കിയ `VecDeque` തിരയുന്നു.
    ///
    /// താരതമ്യ ഫംഗ്ഷൻ, അണ്ടര്ലയിംഗ് എക്സ് 00 എക്സിന്റെ സോർട്ട് ഓർഡറിന് അനുസൃതമായ ഒരു ഓർഡർ നടപ്പിലാക്കണം, ഒരു ഓർഡർ കോഡ് നൽകിക്കൊണ്ട് അതിന്റെ ആർഗ്യുമെന്റ് ആവശ്യമുള്ള ടാർഗറ്റിനേക്കാൾ എക്സ് 01, എക്സ് 02 എക്സ് അല്ലെങ്കിൽ എക്സ് 03 എക്സ് ആണോ എന്ന് സൂചിപ്പിക്കുന്നു.
    ///
    ///
    /// മൂല്യം കണ്ടെത്തിയാൽ, പൊരുത്തപ്പെടുന്ന ഘടകത്തിന്റെ സൂചിക അടങ്ങിയ [`Result::Ok`] മടക്കിനൽകുന്നു.ഒന്നിലധികം മത്സരങ്ങളുണ്ടെങ്കിൽ, ഏതെങ്കിലും ഒരു മത്സരം മടക്കിനൽകാം.
    /// മൂല്യം കണ്ടെത്തിയില്ലെങ്കിൽ, അടുക്കിയ ക്രമം നിലനിർത്തിക്കൊണ്ട് പൊരുത്തപ്പെടുന്ന ഘടകം ഉൾപ്പെടുത്താൻ കഴിയുന്ന സൂചിക അടങ്ങിയ [`Result::Err`] മടക്കിനൽകുന്നു.
    ///
    /// # Examples
    ///
    /// നാല് ഘടകങ്ങളുടെ ഒരു ശ്രേണി തിരയുന്നു.ആദ്യത്തേത് അദ്വിതീയമായി നിർണ്ണയിക്കപ്പെട്ട സ്ഥാനത്തോടെ കണ്ടെത്തി;രണ്ടാമത്തെയും മൂന്നാമത്തെയും കണ്ടെത്തിയില്ല;നാലാമത്തേതിന് `[1, 4]`-ലെ ഏത് സ്ഥാനവുമായും പൊരുത്തപ്പെടാം.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// ഒരു കീ എക്സ്ട്രാക്ഷൻ ഫംഗ്ഷൻ ഉപയോഗിച്ച് ബൈനറി ഈ അടുക്കിയ `VecDeque` തിരയുന്നു.
    ///
    /// `VecDeque` കീ ഉപയോഗിച്ച് അടുക്കിയിട്ടുണ്ടെന്ന് അനുമാനിക്കുന്നു, ഉദാഹരണത്തിന് ഒരേ കീ എക്സ്ട്രാക്ഷൻ ഫംഗ്ഷൻ ഉപയോഗിച്ച് [`make_contiguous().sort_by_key()`](#method.make_contiguous) ഉപയോഗിച്ച്.
    ///
    ///
    /// മൂല്യം കണ്ടെത്തിയാൽ, പൊരുത്തപ്പെടുന്ന ഘടകത്തിന്റെ സൂചിക അടങ്ങിയ [`Result::Ok`] മടക്കിനൽകുന്നു.
    /// ഒന്നിലധികം മത്സരങ്ങളുണ്ടെങ്കിൽ, ഏതെങ്കിലും ഒരു മത്സരം മടക്കിനൽകാം.
    /// മൂല്യം കണ്ടെത്തിയില്ലെങ്കിൽ, അടുക്കിയ ക്രമം നിലനിർത്തിക്കൊണ്ട് പൊരുത്തപ്പെടുന്ന ഘടകം ഉൾപ്പെടുത്താൻ കഴിയുന്ന സൂചിക അടങ്ങിയ [`Result::Err`] മടക്കിനൽകുന്നു.
    ///
    /// # Examples
    ///
    /// രണ്ടാമത്തെ ഘടകങ്ങളാൽ അടുക്കിയ ജോഡികളുടെ ഒരു സ്ലൈസിലെ നാല് ഘടകങ്ങളുടെ ഒരു ശ്രേണി തിരയുന്നു.
    /// ആദ്യത്തേത് അദ്വിതീയമായി നിർണ്ണയിക്കപ്പെട്ട സ്ഥാനത്തോടെ കണ്ടെത്തി;രണ്ടാമത്തെയും മൂന്നാമത്തെയും കണ്ടെത്തിയില്ല;നാലാമത്തേതിന് `[1, 4]`-ലെ ഏത് സ്ഥാനവുമായും പൊരുത്തപ്പെടാം.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// `VecDeque` ഇൻ-പ്ലേസ് പരിഷ്‌ക്കരിക്കുന്നു, അതിനാൽ `len()` പുതിയ_ലെന് തുല്യമാണ്, പിന്നിൽ നിന്ന് അധിക ഘടകങ്ങൾ നീക്കംചെയ്യുന്നതിലൂടെയോ അല്ലെങ്കിൽ `value` ന്റെ ക്ലോണുകൾ പിന്നിലേക്ക് ചേർക്കുന്നതിലൂടെയോ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// തന്നിരിക്കുന്ന ലോജിക്കൽ ഘടക സൂചികയ്‌ക്കായി അന്തർലീനമായ ബഫറിലെ സൂചിക നൽകുന്നു.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // വലുപ്പം എല്ലായ്പ്പോഴും 2 ന്റെ ശക്തിയാണ്
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// ബഫറിൽ വായിക്കാൻ ശേഷിക്കുന്ന ഘടകങ്ങളുടെ എണ്ണം കണക്കാക്കുക
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // വലുപ്പം എല്ലായ്പ്പോഴും 2 ന്റെ ശക്തിയാണ്
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // എല്ലായ്‌പ്പോഴും മൂന്ന് വിഭാഗങ്ങളായി വിഭജിക്കാം, ഉദാഹരണത്തിന്: സ്വയം: [a b c|d e f] മറ്റുള്ളവ: [0 1 2 3|4 5] ഫ്രണ്ട്=3, മിഡ്=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // As_slices രീതി വഴി മടക്കിയ സ്ലൈസുകളിൽ Hash::hash_slice ഉപയോഗിക്കാൻ കഴിയില്ല, കാരണം അവയുടെ നീളം സമാനമായ ഡെക്കുകളിൽ വ്യത്യാസപ്പെടാം.
        //
        //
        // ഹാഷർ അതിന്റെ രീതികളിലേക്കുള്ള കൃത്യമായ അതേ കോളുകൾക്ക് തുല്യത ഉറപ്പുനൽകുന്നു.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// മൂല്യം അനുസരിച്ച് ഘടകങ്ങൾ നൽകുന്ന ഒരു ഫ്രണ്ട്-ടു-ബാക്ക് ഇറ്ററേറ്ററിലേക്ക് `VecDeque` ഉപയോഗിക്കുന്നു.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // ഈ പ്രവർത്തനം ഇനിപ്പറയുന്നതിന്റെ ധാർമ്മിക തുല്യമായിരിക്കണം:
        //
        //      iter.into_iter() in ലെ ഇനത്തിനായി
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// ഒരു [`Vec<T>`] ഒരു [`VecDeque<T>`] ആക്കുക.
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// ഇത് സാധ്യമാകുന്നിടത്ത് വീണ്ടും അനുവദിക്കുന്നത് ഒഴിവാക്കുന്നു, പക്ഷേ അതിനുള്ള വ്യവസ്ഥകൾ കർശനവും മാറ്റത്തിന് വിധേയവുമാണ്, അതിനാൽ `Vec<T>` `From<VecDeque<T>>` ൽ നിന്ന് വന്ന് വീണ്ടും അനുവദിച്ചിട്ടില്ലെങ്കിൽ ഇത് ആശ്രയിക്കരുത്.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // ശേഷിയെക്കുറിച്ച് വിഷമിക്കേണ്ട ZST-കൾക്ക് യഥാർത്ഥ വിഹിതമൊന്നുമില്ല, പക്ഷേ `VecDeque`-ന് `Vec`-ന്റെ അത്രയും ദൈർഘ്യം കൈകാര്യം ചെയ്യാൻ കഴിയില്ല.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // ശേഷി രണ്ടിന്റെ ശക്തിയല്ല, വളരെ ചെറുതാണോ അല്ലെങ്കിൽ കുറഞ്ഞത് ഒരു സ്വതന്ത്ര ഇടമില്ലെങ്കിലോ ഞങ്ങൾ വലുപ്പം മാറ്റേണ്ടതുണ്ട്.
            // `Vec`-ൽ ആയിരിക്കുമ്പോൾ തന്നെ ഞങ്ങൾ ഇത് ചെയ്യുന്നു, അതിനാൽ ഇനങ്ങൾ panic-ൽ പതിക്കും.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// ഒരു [`VecDeque<T>`] ഒരു [`Vec<T>`] ആക്കുക.
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// ഇത് ഒരിക്കലും വീണ്ടും അനുവദിക്കേണ്ടതില്ല, എന്നാൽ അലോക്കേഷന്റെ തുടക്കത്തിൽ വൃത്താകൃതിയിലുള്ള ബഫർ സംഭവിച്ചില്ലെങ്കിൽ *O*(*n*) ഡാറ്റ ചലനം നടത്തേണ്ടതുണ്ട്.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // ഇത് *O*(1) ആണ്.
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // ഇതിന് ഡാറ്റ പുന ar ക്രമീകരണം ആവശ്യമാണ്.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}