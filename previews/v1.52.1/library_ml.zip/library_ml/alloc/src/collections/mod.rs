//! ശേഖരണ തരങ്ങൾ.

#![stable(feature = "rust1", since = "1.0.0")]

pub mod binary_heap;
mod btree;
pub mod linked_list;
pub mod vec_deque;

#[stable(feature = "rust1", since = "1.0.0")]
pub mod btree_map {
    //! ബി-ട്രീ അടിസ്ഥാനമാക്കിയുള്ള ഒരു മാപ്പ്.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub use super::btree::map::*;
}

#[stable(feature = "rust1", since = "1.0.0")]
pub mod btree_set {
    //! ഒരു ബി-ട്രീ അടിസ്ഥാനമാക്കിയുള്ള ഒരു സെറ്റ്.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub use super::btree::set::*;
}

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(no_inline)]
pub use binary_heap::BinaryHeap;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(no_inline)]
pub use btree_map::BTreeMap;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(no_inline)]
pub use btree_set::BTreeSet;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(no_inline)]
pub use linked_list::LinkedList;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(no_inline)]
pub use vec_deque::VecDeque;

use crate::alloc::{Layout, LayoutError};
use core::fmt::Display;

/// `try_reserve` രീതികൾക്കായുള്ള പിശക് തരം.
#[derive(Clone, PartialEq, Eq, Debug)]
#[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
pub enum TryReserveError {
    /// ശേഖരണത്തിന്റെ പരമാവധി (സാധാരണയായി `isize::MAX` ബൈറ്റുകൾ) കവിയുന്ന കമ്പ്യൂട്ട് ശേഷി കാരണം പിശക്.
    ///
    CapacityOverflow,

    /// മെമ്മറി അലോക്കേറ്റർ ഒരു പിശക് നൽകി
    AllocError {
        /// അലോക്കേഷൻ അഭ്യർത്ഥനയുടെ ലേ layout ട്ട് പരാജയപ്പെട്ടു
        layout: Layout,

        #[doc(hidden)]
        #[unstable(
            feature = "container_error_extra",
            issue = "none",
            reason = "\
            Enable exposing the allocator’s custom error value \
            if an associated type is added in the future: \
            https://github.com/rust-lang/wg-allocators/issues/23"
        )]
        non_exhaustive: (),
    },
}

#[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
impl From<LayoutError> for TryReserveError {
    #[inline]
    fn from(_: LayoutError) -> Self {
        TryReserveError::CapacityOverflow
    }
}

#[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
impl Display for TryReserveError {
    fn fmt(
        &self,
        fmt: &mut core::fmt::Formatter<'_>,
    ) -> core::result::Result<(), core::fmt::Error> {
        fmt.write_str("memory allocation failed")?;
        let reason = match &self {
            TryReserveError::CapacityOverflow => {
                " because the computed capacity exceeded the collection's maximum"
            }
            TryReserveError::AllocError { .. } => " because the memory allocator returned a error",
        };
        fmt.write_str(reason)
    }
}

/// `Extend` ന്റെ സ്പെഷ്യലൈസേഷനായി ഒരു ഇന്റർമീഡിയറ്റ് trait.
#[doc(hidden)]
trait SpecExtend<I: IntoIterator> {
    /// തന്നിരിക്കുന്ന ഇറ്ററേറ്ററിലെ ഉള്ളടക്കങ്ങൾ ഉപയോഗിച്ച് `self` വിപുലീകരിക്കുന്നു.
    fn spec_extend(&mut self, iter: I);
}