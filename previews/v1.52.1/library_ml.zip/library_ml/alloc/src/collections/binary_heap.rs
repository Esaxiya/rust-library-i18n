//! ഒരു ബൈനറി കൂമ്പാരം ഉപയോഗിച്ച് ഒരു മുൻ‌ഗണനാ ക്യൂ നടപ്പിലാക്കി.
//!
//! ഏറ്റവും വലിയ ഘടകം ഉൾപ്പെടുത്തുന്നതിനും പോപ്പുചെയ്യുന്നതിനും *O*(log(*n*)) സമയ സങ്കീർണ്ണതയുണ്ട്.
//! ഏറ്റവും വലിയ ഘടകം പരിശോധിക്കുന്നത് *O*(1) ആണ്.ഒരു vector ഒരു ബൈനറി കൂമ്പാരമായി പരിവർത്തനം ചെയ്യുന്നത് സ്ഥലത്ത് തന്നെ ചെയ്യാനാകും, കൂടാതെ *O*(*n*) സങ്കീർണ്ണതയുമുണ്ട്.
//! ഒരു ബൈനറി ഹീപ്പ് സ്ഥലത്ത് അടുക്കിയ vector ലേക്ക് പരിവർത്തനം ചെയ്യാനും ഇത് ഒരു *O*(*n*\*log(* n*)) ഇൻ-പ്ലേസ് ഹീപ്‌സോർട്ടിനായി ഉപയോഗിക്കാൻ അനുവദിക്കുന്നു.
//!
//! # Examples
//!
//! [directed graph][dir_graph]-ൽ [shortest path problem][sssp] പരിഹരിക്കുന്നതിന് [Dijkstra's algorithm][dijkstra] നടപ്പിലാക്കുന്ന ഒരു വലിയ ഉദാഹരണമാണിത്.
//!
//! ഇഷ്‌ടാനുസൃത തരങ്ങൾക്കൊപ്പം [`BinaryHeap`] എങ്ങനെ ഉപയോഗിക്കാമെന്ന് ഇത് കാണിക്കുന്നു.
//!
//! [dijkstra]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm
//! [sssp]: https://en.wikipedia.org/wiki/Shortest_path_problem
//! [dir_graph]: https://en.wikipedia.org/wiki/Directed_graph
//!
//! ```
//! use std::cmp::Ordering;
//! use std::collections::BinaryHeap;
//!
//! #[derive(Copy, Clone, Eq, PartialEq)]
//! struct State {
//!     cost: usize,
//!     position: usize,
//! }
//!
//! // മുൻ‌ഗണനാ ക്യൂ `Ord` നെ ആശ്രയിച്ചിരിക്കുന്നു.
//! // trait വ്യക്തമായി നടപ്പിലാക്കുക, അതിനാൽ ക്യൂ ഒരു മാക്സ്-ഹീപ്പിന് പകരം ഒരു മിനി-ഹീപ്പായി മാറുന്നു.
//! //
//! impl Ord for State {
//!     fn cmp(&self, other: &Self) -> Ordering {
//!         // ചെലവുകളുടെ ക്രമം ഞങ്ങൾ ഫ്ലിപ്പുചെയ്യുന്നത് ശ്രദ്ധിക്കുക.
//!         // ഒരു ടൈയുടെ കാര്യത്തിൽ ഞങ്ങൾ സ്ഥാനങ്ങൾ താരതമ്യം ചെയ്യുന്നുവെങ്കിൽ, `PartialEq`, `Ord` എന്നിവയുടെ നടപ്പാക്കൽ സ്ഥിരത കൈവരിക്കുന്നതിന് ഈ ഘട്ടം ആവശ്യമാണ്.
//!         //
//!         other.cost.cmp(&self.cost)
//!             .then_with(|| self.position.cmp(&other.position))
//!     }
//! }
//!
//! // `PartialOrd` നടപ്പാക്കേണ്ടതുണ്ട്.
//! impl PartialOrd for State {
//!     fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
//!         Some(self.cmp(other))
//!     }
//! }
//!
//! // ഹ്രസ്വമായ നടപ്പാക്കലിനായി ഓരോ നോഡിനെയും ഒരു `usize` ആയി പ്രതിനിധീകരിക്കുന്നു.
//! struct Edge {
//!     node: usize,
//!     cost: usize,
//! }
//!
//! // ഡിജക്‌സ്ട്രയുടെ ഏറ്റവും ഹ്രസ്വമായ പാത്ത് അൽഗോരിതം.
//!
//! // ഓരോ നോഡിലേക്കും നിലവിലെ ഏറ്റവും കുറഞ്ഞ ദൂരം ട്രാക്കുചെയ്യുന്നതിന് `start`-ൽ ആരംഭിച്ച് `dist` ഉപയോഗിക്കുക.ഈ നടപ്പിലാക്കൽ മെമ്മറി-കാര്യക്ഷമമല്ല, കാരണം ഇത് തനിപ്പകർപ്പ് നോഡുകൾ ക്യൂവിൽ ഇടാം.
//! //
//! // ലളിതമായ നടപ്പാക്കലിനായി ഇത് സെന്റിനൽ മൂല്യമായി `usize::MAX` ഉപയോഗിക്കുന്നു.
//! //
//! fn shortest_path(adj_list: &Vec<Vec<Edge>>, start: usize, goal: usize) -> Option<usize> {
//!     // dist [നോഡ്]= `start` മുതൽ `node` വരെയുള്ള നിലവിലെ ഏറ്റവും കുറഞ്ഞ ദൂരം
//!     let mut dist: Vec<_> = (0..adj_list.len()).map(|_| usize::MAX).collect();
//!
//!     let mut heap = BinaryHeap::new();
//!
//!     // ഞങ്ങൾ `start`-ലാണ്, പൂജ്യം ചിലവ്
//!     dist[start] = 0;
//!     heap.push(State { cost: 0, position: start });
//!
//!     // കുറഞ്ഞ വിലയുള്ള നോഡുകൾ ഉപയോഗിച്ച് ആദ്യം (min-heap) ഉപയോഗിച്ച് അതിർത്തി പരിശോധിക്കുക
//!     while let Some(State { cost, position }) = heap.pop() {
//!         // പകരമായി, ഹ്രസ്വമായ എല്ലാ പാതകളും കണ്ടെത്തുന്നത് തുടരാം
//!         if position == goal { return Some(cost); }
//!
//!         // ഞങ്ങൾ‌ഇതിനകം ഒരു മികച്ച മാർ‌ഗ്ഗം കണ്ടെത്തിയേക്കാമെന്നത് പ്രധാനമാണ്
//!         if cost > dist[position] { continue; }
//!
//!         // ഞങ്ങൾക്ക് എത്താൻ കഴിയുന്ന ഓരോ നോഡിനും, ഈ നോഡിലൂടെ കുറഞ്ഞ ചെലവിൽ ഒരു വഴി കണ്ടെത്താൻ കഴിയുമോ എന്ന് നോക്കുക
//!         //
//!         for edge in &adj_list[position] {
//!             let next = State { cost: cost + edge.cost, position: edge.node };
//!
//!             // അങ്ങനെയാണെങ്കിൽ, അത് അതിർത്തിയിലേക്ക് ചേർത്ത് തുടരുക
//!             if next.cost < dist[next.position] {
//!                 heap.push(next);
//!                 // വിശ്രമം, ഞങ്ങൾ ഇപ്പോൾ ഒരു മികച്ച മാർഗം കണ്ടെത്തി
//!                 dist[next.position] = next.cost;
//!             }
//!         }
//!     }
//!
//!     // ലക്ഷ്യം എത്തിച്ചേരാനാവില്ല
//!     None
//! }
//!
//! fn main() {
//!     // ഞങ്ങൾ ഉപയോഗിക്കാൻ പോകുന്ന സംവിധാനം ചെയ്ത ഗ്രാഫ് ഇതാണ്.
//!     // നോഡ് നമ്പറുകൾ വ്യത്യസ്ത സംസ്ഥാനങ്ങളുമായി പൊരുത്തപ്പെടുന്നു, ഒപ്പം edge തൂക്കങ്ങൾ ഒരു നോഡിൽ നിന്ന് മറ്റൊന്നിലേക്ക് നീങ്ങുന്നതിനുള്ള ചെലവിനെ പ്രതീകപ്പെടുത്തുന്നു.
//!     //
//!     // അരികുകൾ വൺവേയാണെന്ന് ശ്രദ്ധിക്കുക.
//!     //
//!     //                  7
//!     //          +-----------------+
//!     //          |                 |
//!     //          v 1 2 |2
//!     //          0-----> 1-- ---> 3-- -> 4
//!     //          |        ^        ^      ^
//!     //          |        | 1      |      |
//!     //          |        |        | 3    | 1          +------> 2 -------+      |
//!     //           10 ||
//!     //                   +---------------+
//!     //
//!     // ഒരു നോഡ് മൂല്യത്തിന് അനുസരിച്ച് ഓരോ സൂചികയ്ക്കും going ട്ട്‌ഗോയിംഗ് അരികുകളുടെ ഒരു ലിസ്റ്റ് ഉള്ള ഒരു സമീപസ്ഥല പട്ടികയായി ഗ്രാഫിനെ പ്രതിനിധീകരിക്കുന്നു.
//!     // അതിന്റെ കാര്യക്ഷമതയ്ക്കായി തിരഞ്ഞെടുത്തു.
//!     //
//!     //
//!     //
//!     let graph = vec![
//!         // നോഡ് 0
//!         vec![Edge { node: 2, cost: 10 },
//!              Edge { node: 1, cost: 1 }],
//!         // നോഡ് 1
//!         vec![Edge { node: 3, cost: 2 }],
//!         // നോഡ് 2
//!         vec![Edge { node: 1, cost: 1 },
//!              Edge { node: 3, cost: 3 },
//!              Edge { node: 4, cost: 1 }],
//!         // നോഡ് 3
//!         vec![Edge { node: 0, cost: 7 },
//!              Edge { node: 4, cost: 2 }],
//!         // നോഡ് 4
//!         vec![]];
//!
//!     assert_eq!(shortest_path(&graph, 0, 1), Some(1));
//!     assert_eq!(shortest_path(&graph, 0, 3), Some(3));
//!     assert_eq!(shortest_path(&graph, 3, 0), Some(7));
//!     assert_eq!(shortest_path(&graph, 0, 4), Some(5));
//!     assert_eq!(shortest_path(&graph, 4, 0), None);
//! }
//! ```
//!
//!

#![allow(missing_docs)]
#![stable(feature = "rust1", since = "1.0.0")]

use core::fmt;
use core::iter::{FromIterator, FusedIterator, InPlaceIterable, SourceIter, TrustedLen};
use core::mem::{self, swap, ManuallyDrop};
use core::ops::{Deref, DerefMut};
use core::ptr;

use crate::slice;
use crate::vec::{self, AsIntoIter, Vec};

use super::SpecExtend;

/// ഒരു ബൈനറി കൂമ്പാരം ഉപയോഗിച്ച് ഒരു മുൻ‌ഗണനാ ക്യൂ നടപ്പിലാക്കി.
///
/// ഇത് ഒരു പരമാവധി കൂമ്പാരമായിരിക്കും.
///
/// `Ord` trait നിർ‌ണ്ണയിച്ച പ്രകാരം, മറ്റേതൊരു ഇനവുമായും താരതമ്യപ്പെടുത്തുമ്പോൾ ഇനത്തിന്റെ ക്രമം കൂമ്പാരത്തിലായിരിക്കുമ്പോൾ മാറ്റം വരുത്തുന്ന തരത്തിൽ ഒരു ഇനം പരിഷ്‌ക്കരിക്കുന്നത് ഒരു ലോജിക് പിശകാണ്.
///
/// ഇത് സാധാരണയായി `Cell`, `RefCell`, ഗ്ലോബൽ സ്റ്റേറ്റ്, I/O അല്ലെങ്കിൽ സുരക്ഷിതമല്ലാത്ത കോഡ് വഴി മാത്രമേ സാധ്യമാകൂ.
/// അത്തരമൊരു ലോജിക് പിശകിന്റെ ഫലമായുണ്ടായ സ്വഭാവം വ്യക്തമാക്കിയിട്ടില്ല, പക്ഷേ നിർവചിക്കപ്പെടാത്ത പെരുമാറ്റത്തിന് കാരണമാകില്ല.
/// ഇതിൽ panics, തെറ്റായ ഫലങ്ങൾ, നിർത്തലാക്കൽ, മെമ്മറി ലീക്കുകൾ, അവസാനിപ്പിക്കാത്തത് എന്നിവ ഉൾപ്പെടാം.
///
/// # Examples
///
/// ```
/// use std::collections::BinaryHeap;
///
/// // ടൈപ്പ് ഇൻ‌ഫെൻ‌ഷൻ‌ഒരു സ്പഷ്ടമായ ടൈപ്പ് സിഗ്‌നേച്ചർ‌ഒഴിവാക്കാൻ‌ഞങ്ങളെ അനുവദിക്കുന്നു (ഇത് ഈ ഉദാഹരണത്തിൽ‌`BinaryHeap<i32>` ആയിരിക്കും).
/////
/// let mut heap = BinaryHeap::new();
///
/// // കൂമ്പാരത്തിലെ അടുത്ത ഇനം നോക്കാൻ നമുക്ക് പീക്ക് ഉപയോഗിക്കാം.
/// // ഈ സാഹചര്യത്തിൽ, ഇനങ്ങളൊന്നും അവിടെ ഇല്ലാത്തതിനാൽ ഞങ്ങൾക്ക് ഒന്നും ലഭിക്കുന്നില്ല.
/// assert_eq!(heap.peek(), None);
///
/// // നമുക്ക് കുറച്ച് സ്കോറുകൾ ചേർക്കാം ...
/// heap.push(1);
/// heap.push(5);
/// heap.push(2);
///
/// // ഇപ്പോൾ കൂമ്പാരത്തിലെ ഏറ്റവും പ്രധാനപ്പെട്ട ഇനം പീക്ക് കാണിക്കുന്നു.
/// assert_eq!(heap.peek(), Some(&5));
///
/// // ഒരു കൂമ്പാരത്തിന്റെ നീളം നമുക്ക് പരിശോധിക്കാം.
/// assert_eq!(heap.len(), 3);
///
/// // കൂമ്പാരത്തിലെ ഇനങ്ങൾ‌ക്രമരഹിതമായി മടക്കിനൽകുന്നുണ്ടെങ്കിലും നമുക്ക് അവ ആവർത്തിക്കാൻ‌കഴിയും.
/////
/// for x in &heap {
///     println!("{}", x);
/// }
///
/// // പകരം ഞങ്ങൾ‌ഈ സ്‌കോറുകൾ‌പോപ്പ് ചെയ്യുകയാണെങ്കിൽ‌, അവ ക്രമത്തിൽ‌മടങ്ങണം.
/// assert_eq!(heap.pop(), Some(5));
/// assert_eq!(heap.pop(), Some(2));
/// assert_eq!(heap.pop(), Some(1));
/// assert_eq!(heap.pop(), None);
///
/// // അവശേഷിക്കുന്ന ഏതെങ്കിലും ഇനങ്ങളുടെ കൂമ്പാരം നമുക്ക് മായ്‌ക്കാനാകും.
/// heap.clear();
///
/// // കൂമ്പാരം ഇപ്പോൾ ശൂന്യമായിരിക്കണം.
/// assert!(heap.is_empty())
/// ```
///
/// ## Min-heap
///
/// `BinaryHeap` ഒരു മിനി-ഹീപ്പ് ആക്കുന്നതിന് `std::cmp::Reverse` അല്ലെങ്കിൽ ഒരു ഇച്ഛാനുസൃത `Ord` നടപ്പിലാക്കൽ ഉപയോഗിക്കാം.
/// ഇത് ഏറ്റവും വലിയ മൂല്യത്തിന് പകരം ഏറ്റവും ചെറിയ മൂല്യം `heap.pop()` നൽകുന്നു.
///
/// ```
/// use std::collections::BinaryHeap;
/// use std::cmp::Reverse;
///
/// let mut heap = BinaryHeap::new();
///
/// // `Reverse`-ൽ മൂല്യങ്ങൾ പൊതിയുക
/// heap.push(Reverse(1));
/// heap.push(Reverse(5));
/// heap.push(Reverse(2));
///
/// // ഞങ്ങൾ‌ഇപ്പോൾ‌ഈ സ്കോറുകൾ‌പോപ്പ് ചെയ്യുകയാണെങ്കിൽ‌, അവ വിപരീത ക്രമത്തിൽ‌മടങ്ങണം.
/// assert_eq!(heap.pop(), Some(Reverse(1)));
/// assert_eq!(heap.pop(), Some(Reverse(2)));
/// assert_eq!(heap.pop(), Some(Reverse(5)));
/// assert_eq!(heap.pop(), None);
/// ```
///
/// # സമയ സങ്കീർണ്ണത
///
/// | [push] | [pop]     | [peek]/[peek\_mut] |
/// |--------|-----------|--------------------|
/// | O(1)~  | *O*(log(*n*)) | *O*(1)               |
///
/// `push`-നായുള്ള മൂല്യം പ്രതീക്ഷിക്കുന്ന ചിലവാണ്;രീതി ഡോക്യുമെന്റേഷൻ കൂടുതൽ വിശദമായ വിശകലനം നൽകുന്നു.
///
/// [push]: BinaryHeap::push
/// [pop]: BinaryHeap::pop
/// [peek]: BinaryHeap::peek
/// [peek\_mut]: BinaryHeap::peek_mut
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "BinaryHeap")]
pub struct BinaryHeap<T> {
    data: Vec<T>,
}

/// ഒരു `BinaryHeap`-ലെ ഏറ്റവും മികച്ച ഇനത്തിലേക്ക് മ്യൂട്ടബിൾ റഫറൻസ് പൊതിയുന്ന ഘടന.
///
///
/// [`BinaryHeap`]-ലെ [`peek_mut`] രീതി ഉപയോഗിച്ചാണ് ഈ `struct` സൃഷ്ടിച്ചിരിക്കുന്നത്.
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// [`peek_mut`]: BinaryHeap::peek_mut
#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
pub struct PeekMut<'a, T: 'a + Ord> {
    heap: &'a mut BinaryHeap<T>,
    sift: bool,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: Ord + fmt::Debug> fmt::Debug for PeekMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("PeekMut").field(&self.heap.data[0]).finish()
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Drop for PeekMut<'_, T> {
    fn drop(&mut self) {
        if self.sift {
            // സുരക്ഷ: ശൂന്യമല്ലാത്ത കൂമ്പാരങ്ങൾക്കായി മാത്രമാണ് പീക്ക്മട്ട് തൽക്ഷണം ചെയ്യുന്നത്.
            unsafe { self.heap.sift_down(0) };
        }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> Deref for PeekMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        debug_assert!(!self.heap.is_empty());
        // സുരക്ഷിതം: ശൂന്യമല്ലാത്ത കൂമ്പാരങ്ങൾക്കായി മാത്രമാണ് പീക്ക്മട്ട് തൽക്ഷണം ചെയ്യുന്നത്
        unsafe { self.heap.data.get_unchecked(0) }
    }
}

#[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
impl<T: Ord> DerefMut for PeekMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        debug_assert!(!self.heap.is_empty());
        self.sift = true;
        // സുരക്ഷിതം: ശൂന്യമല്ലാത്ത കൂമ്പാരങ്ങൾക്കായി മാത്രമാണ് പീക്ക്മട്ട് തൽക്ഷണം ചെയ്യുന്നത്
        unsafe { self.heap.data.get_unchecked_mut(0) }
    }
}

impl<'a, T: Ord> PeekMut<'a, T> {
    /// കൂമ്പാരത്തിൽ നിന്ന് പരിശോധിച്ച മൂല്യം നീക്കംചെയ്യുകയും അത് തിരികെ നൽകുകയും ചെയ്യുന്നു.
    #[stable(feature = "binary_heap_peek_mut_pop", since = "1.18.0")]
    pub fn pop(mut this: PeekMut<'a, T>) -> T {
        let value = this.heap.pop().unwrap();
        this.sift = false;
        value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for BinaryHeap<T> {
    fn clone(&self) -> Self {
        BinaryHeap { data: self.data.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.data.clone_from(&source.data);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Default for BinaryHeap<T> {
    /// ഒരു ശൂന്യമായ `BinaryHeap<T>` സൃഷ്ടിക്കുന്നു.
    #[inline]
    fn default() -> BinaryHeap<T> {
        BinaryHeap::new()
    }
}

#[stable(feature = "binaryheap_debug", since = "1.4.0")]
impl<T: fmt::Debug> fmt::Debug for BinaryHeap<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self.iter()).finish()
    }
}

impl<T: Ord> BinaryHeap<T> {
    /// ഒരു ശൂന്യമായ `BinaryHeap` ഒരു മാക്സ്-ഹീപ്പായി സൃഷ്ടിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> BinaryHeap<T> {
        BinaryHeap { data: vec![] }
    }

    /// നിർദ്ദിഷ്ട ശേഷിയുള്ള ശൂന്യമായ `BinaryHeap` സൃഷ്ടിക്കുന്നു.
    /// ഇത് `capacity` ഘടകങ്ങൾക്ക് ആവശ്യമായ മെമ്മറി മുൻകൂട്ടി നിശ്ചയിക്കുന്നു, അതിനാൽ കുറഞ്ഞത് നിരവധി മൂല്യങ്ങളെങ്കിലും അടങ്ങിയിരിക്കുന്നതുവരെ `BinaryHeap` വീണ്ടും അനുവദിക്കേണ്ടതില്ല.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(10);
    /// heap.push(4);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> BinaryHeap<T> {
        BinaryHeap { data: Vec::with_capacity(capacity) }
    }

    /// ബൈനറി ഹീപ്പിലെ ഏറ്റവും മികച്ച ഇനത്തിലേക്ക് മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു, അല്ലെങ്കിൽ അത് ശൂന്യമാണെങ്കിൽ `None`.
    ///
    /// Note: `PeekMut` മൂല്യം ചോർന്നാൽ, കൂമ്പാരം പൊരുത്തമില്ലാത്ത അവസ്ഥയിലായിരിക്കാം.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert!(heap.peek_mut().is_none());
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// {
    ///     let mut val = heap.peek_mut().unwrap();
    ///     *val = 0;
    /// }
    /// assert_eq!(heap.peek(), Some(&2));
    /// ```
    ///
    /// # സമയ സങ്കീർണ്ണത
    ///
    /// ഇനം പരിഷ്‌ക്കരിക്കുകയാണെങ്കിൽ ഏറ്റവും മോശം സമയ സങ്കീർണ്ണത *O*(log(*n*)) ആണ്, അല്ലാത്തപക്ഷം ഇത് *O*(1) ആണ്.
    ///
    ///
    ///
    #[stable(feature = "binary_heap_peek_mut", since = "1.12.0")]
    pub fn peek_mut(&mut self) -> Option<PeekMut<'_, T>> {
        if self.is_empty() { None } else { Some(PeekMut { heap: self, sift: false }) }
    }

    /// ബൈനറി കൂമ്പാരത്തിൽ നിന്ന് ഏറ്റവും മികച്ച ഇനം നീക്കംചെയ്യുകയും അത് തിരികെ നൽകുകയും ചെയ്യുന്നു, അല്ലെങ്കിൽ ശൂന്യമാണെങ്കിൽ `None`.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.pop(), Some(3));
    /// assert_eq!(heap.pop(), Some(1));
    /// assert_eq!(heap.pop(), None);
    /// ```
    ///
    /// # സമയ സങ്കീർണ്ണത
    ///
    /// *N* ഘടകങ്ങൾ അടങ്ങിയ കൂമ്പാരത്തിൽ `pop`-ന്റെ ഏറ്റവും മോശം നിരക്ക് *O*(log(*n*)) ആണ്.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        self.data.pop().map(|mut item| {
            if !self.is_empty() {
                swap(&mut item, &mut self.data[0]);
                // സുരക്ഷ: !self.is_empty() എന്നാൽ self.len()> 0 എന്നാണ്
                unsafe { self.sift_down_to_bottom(0) };
            }
            item
        })
    }

    /// ഒരു ഇനം ബൈനറി കൂമ്പാരത്തിലേക്ക് തള്ളുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert_eq!(heap.len(), 3);
    /// assert_eq!(heap.peek(), Some(&5));
    /// ```
    ///
    /// # സമയ സങ്കീർണ്ണത
    ///
    /// `push`-ന്റെ പ്രതീക്ഷിക്കുന്ന ചെലവ്, മൂലകങ്ങളുടെ എല്ലാ ഓർഡറിംഗിനേക്കാളും ശരാശരി, ആവശ്യത്തിന് വലിയ അളവിലുള്ള പുഷുകൾ *O*(1) ആണ്.
    ///
    /// ഏതെങ്കിലും തരം പാറ്റേണുകളിൽ ഇതിനകം * ഇല്ലാത്ത ഘടകങ്ങൾ തള്ളുമ്പോൾ ഇത് ഏറ്റവും അർത്ഥവത്തായ കോസ്റ്റ് മെട്രിക് ആണ്.
    ///
    /// മൂലകങ്ങൾ പ്രധാനമായും ആരോഹണ ക്രമത്തിൽ തള്ളുകയാണെങ്കിൽ സമയ സങ്കീർണ്ണത കുറയുന്നു.
    /// ഏറ്റവും മോശം അവസ്ഥയിൽ, ഘടകങ്ങൾ ആരോഹണ ക്രമത്തിൽ ക്രമീകരിക്കപ്പെടുന്നു, ഒപ്പം *n* ഘടകങ്ങൾ അടങ്ങിയ ഒരു കൂമ്പാരത്തിനെതിരെ ഓരോ പുഷിന്റെയും പലിശനിരക്ക് *O*(log(*n*)) ആണ്.
    ///
    /// `push`-ലേക്ക് *സിംഗിൾ* കോളിന്റെ ഏറ്റവും മോശം നിരക്ക് *O*(*n*) ആണ്.ശേഷി തീർന്നുപോകുമ്പോൾ ഒരു വലുപ്പം ആവശ്യമായി വരുമ്പോഴാണ് ഏറ്റവും മോശം അവസ്ഥ സംഭവിക്കുന്നത്.
    /// വലുപ്പം മാറ്റുന്നതിനുള്ള ചെലവ് മുമ്പത്തെ കണക്കുകളിൽ അംഗീകരിച്ചു.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, item: T) {
        let old_len = self.len();
        self.data.push(item);
        // സുരക്ഷ: ഞങ്ങൾ ഒരു പുതിയ ഇനം തള്ളിയതിനാൽ അതിനർത്ഥം
        //  old_len= self.len(), 1 <self.len()
        unsafe { self.sift_up(0, old_len) };
    }

    /// `BinaryHeap` ഉപയോഗിക്കുകയും അടുക്കിയ (ascending) ക്രമത്തിൽ ഒരു vector നൽകുകയും ചെയ്യുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 4, 5, 7]);
    /// heap.push(6);
    /// heap.push(3);
    ///
    /// let vec = heap.into_sorted_vec();
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6, 7]);
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_sorted_vec(mut self) -> Vec<T> {
        let mut end = self.len();
        while end > 1 {
            end -= 1;
            // സുരക്ഷ: `end` `self.len() - 1` ൽ നിന്ന് 1 ലേക്ക് പോകുന്നു (രണ്ടും ഉൾപ്പെടുത്തിയിരിക്കുന്നു),
            //  അതിനാൽ ഇത് എല്ലായ്പ്പോഴും ആക്സസ് ചെയ്യുന്നതിനുള്ള സാധുവായ സൂചികയാണ്.
            //  സൂചിക 0 (അതായത് `ptr`) ആക്സസ് ചെയ്യുന്നത് സുരക്ഷിതമാണ്, കാരണം
            //  1 <=അവസാനം <self.len(), അതായത് self.len()>=2.
            unsafe {
                let ptr = self.data.as_mut_ptr();
                ptr::swap(ptr, ptr.add(end));
            }
            // സുരക്ഷ: `end` `self.len() - 1` ൽ നിന്ന് 1 ലേക്ക് പോകുന്നു (രണ്ടും ഉൾപ്പെടുത്തിയിരിക്കുന്നു) അതിനാൽ:
            //  0 <1 <=end <= self.len(), 1 <self.len() അതായത് 0 <end and end <self.len().
            //
            unsafe { self.sift_down_range(0, end) };
        }
        self.into_vec()
    }

    // Sift_up, sift_down എന്നിവയുടെ നടപ്പാക്കലുകൾ vector-ൽ നിന്ന് ഒരു മൂലകം നീക്കുന്നതിന് (ഒരു ദ്വാരത്തിന് പുറകിൽ നിന്ന്), മറ്റുള്ളവയ്‌ക്കൊപ്പം മാറുന്നതിനും നീക്കംചെയ്‌ത മൂലകത്തെ ദ്വാരത്തിന്റെ അവസാന സ്ഥാനത്ത് vector-ലേക്ക് നീക്കുന്നതിനും സുരക്ഷിതമല്ലാത്ത ബ്ലോക്കുകൾ ഉപയോഗിക്കുന്നു.
    //
    // ഇത് പ്രതിനിധീകരിക്കുന്നതിന് `Hole` തരം ഉപയോഗിക്കുന്നു, കൂടാതെ panic-ൽ പോലും ദ്വാരം അതിന്റെ വ്യാപ്തിയുടെ അവസാനം നിറഞ്ഞിട്ടുണ്ടെന്ന് ഉറപ്പാക്കുക.
    // സ്വാപ്പുകൾ ഉപയോഗിക്കുന്നതിനെ അപേക്ഷിച്ച് ഒരു ദ്വാരം ഉപയോഗിക്കുന്നത് സ്ഥിരമായ ഘടകം കുറയ്ക്കുന്നു, അതിൽ ഇരട്ടി നീക്കങ്ങൾ ഉൾപ്പെടുന്നു.
    //
    //
    //
    //

    /// # Safety
    ///
    /// വിളിക്കുന്നയാൾ `pos < self.len()` എന്ന് ഉറപ്പ് നൽകണം.
    unsafe fn sift_up(&mut self, start: usize, pos: usize) -> usize {
        // `pos`-ൽ മൂല്യം പുറത്തെടുത്ത് ഒരു ദ്വാരം സൃഷ്ടിക്കുക.
        // സുരക്ഷ: വിളിക്കുന്നയാൾ <self.len() എന്ന് ഉറപ്പുനൽകുന്നു
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };

        while hole.pos() > start {
            let parent = (hole.pos() - 1) / 2;

            // സുരക്ഷ: hole.pos()> ആരംഭിക്കുക>=0, അതായത് hole.pos()> 0
            //  അതിനാൽ hole.pos(), 1 ന് ഒഴുകാൻ കഴിയില്ല.
            //  രക്ഷകർത്താവ് <hole.pos() ഇത് ഒരു സാധുവായ സൂചികയും!= hole.pos() ഉം ആണെന്ന് ഇത് ഉറപ്പുനൽകുന്നു.
            //
            if hole.element() <= unsafe { hole.get(parent) } {
                break;
            }

            // സുരക്ഷ: മുകളിൽ പറഞ്ഞതുപോലെ തന്നെ
            unsafe { hole.move_to(parent) };
        }

        hole.pos()
    }

    /// `pos`-ൽ ഒരു ഘടകം എടുത്ത് അതിനെ കൂമ്പാരത്തിലേക്ക് നീക്കുക, അതേസമയം അതിന്റെ കുട്ടികൾ വലുതായിരിക്കും.
    ///
    ///
    /// # Safety
    ///
    /// വിളിക്കുന്നയാൾ `pos < end <= self.len()` എന്ന് ഉറപ്പ് നൽകണം.
    unsafe fn sift_down_range(&mut self, pos: usize, end: usize) {
        // സുരക്ഷ: പോസ് <അവസാനം <= self.len() എന്ന് കോളർ ഉറപ്പുനൽകുന്നു.
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // ലൂപ്പ് മാറ്റമില്ലാത്തത്: കുട്ടി==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // സുരക്ഷിതമായ രണ്ട് കുട്ടികളുമായി താരതമ്യപ്പെടുത്തുക: കുട്ടി <അവസാനം, 1 <self.len(), കുട്ടി + 1 <അവസാനം <= self.len(), അതിനാൽ അവ സാധുവായ സൂചികകളാണ്.
            //
            //  കുട്ടി==2 *hole.pos() + 1!= hole.pos(), കുട്ടി + 1==2* hole.pos() + 2!= hole.pos().
            // FIXME: T ഒരു ZST ആണെങ്കിൽ 2 *hole.pos() + 1 അല്ലെങ്കിൽ 2* hole.pos() + 2 കവിഞ്ഞൊഴുകും
            //
            //
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // ഞങ്ങൾ ഇതിനകം ക്രമത്തിലാണെങ്കിൽ, നിർത്തുക.
            // സുരക്ഷ: കുട്ടി ഇപ്പോൾ ഒന്നുകിൽ പഴയ കുട്ടി അല്ലെങ്കിൽ പഴയ കുട്ടി + 1 ആണ്
            //  രണ്ടും <self.len() ഉം!= hole.pos() ഉം ആണെന്ന് ഞങ്ങൾ ഇതിനകം തെളിയിച്ചിട്ടുണ്ട്
            if hole.element() >= unsafe { hole.get(child) } {
                return;
            }

            // സുരക്ഷ: മുകളിൽ പറഞ്ഞതുപോലെ.
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        // സുരക്ഷ: &&ഷോർട്ട് സർക്യൂട്ട്, അതിനർത്ഥം
        //  രണ്ടാമത്തെ അവസ്ഥ കുട്ടി==അവസാനം, 1 <self.len() എന്നത് ഇതിനകം ശരിയാണ്.
        if child == end - 1 && hole.element() < unsafe { hole.get(child) } {
            // സുരക്ഷ: കുട്ടി സാധുവായ സൂചികയാണെന്ന് ഇതിനകം തെളിയിക്കപ്പെട്ടിട്ടുണ്ട്
            //  കുട്ടി==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
    }

    /// # Safety
    ///
    /// വിളിക്കുന്നയാൾ `pos < self.len()` എന്ന് ഉറപ്പ് നൽകണം.
    unsafe fn sift_down(&mut self, pos: usize) {
        let len = self.len();
        // സുരക്ഷ: പോസ് <ലെൻ വിളിക്കുന്നയാൾ ഉറപ്പുനൽകുന്നു ഒപ്പം
        //  വ്യക്തമായും len= self.len() <= self.len().
        unsafe { self.sift_down_range(pos, len) };
    }

    /// `pos`-ൽ ഒരു ഘടകം എടുത്ത് അതിനെ കൂമ്പാരത്തിലേക്ക് താഴേക്ക് നീക്കുക, തുടർന്ന് അതിനെ അതിന്റെ സ്ഥാനത്തേക്ക് ഉയർത്തുക.
    ///
    ///
    /// Note: മൂലകം വലുതാണെന്ന് അറിയുമ്പോൾ ഇത് വേഗതയേറിയതാണ്/അടിയിലേക്ക് അടുത്ത് ആയിരിക്കണം.
    ///
    /// # Safety
    ///
    /// വിളിക്കുന്നയാൾ `pos < self.len()` എന്ന് ഉറപ്പ് നൽകണം.
    ///
    unsafe fn sift_down_to_bottom(&mut self, mut pos: usize) {
        let end = self.len();
        let start = pos;

        // സുരക്ഷ: വിളിക്കുന്നയാൾ <self.len() എന്ന് ഉറപ്പുനൽകുന്നു.
        let mut hole = unsafe { Hole::new(&mut self.data, pos) };
        let mut child = 2 * hole.pos() + 1;

        // ലൂപ്പ് മാറ്റമില്ലാത്തത്: കുട്ടി==2 * hole.pos() + 1.
        while child <= end.saturating_sub(2) {
            // സുരക്ഷ: കുട്ടി <അവസാനം, 1 <self.len() കൂടാതെ
            //  കുട്ടി + 1 <അവസാനം <= self.len(), അതിനാൽ അവ സാധുവായ സൂചികകളാണ്.
            //  കുട്ടി==2 *hole.pos() + 1!= hole.pos(), കുട്ടി + 1==2* hole.pos() + 2!= hole.pos().
            //
            // FIXME: T ഒരു ZST ആണെങ്കിൽ 2 *hole.pos() + 1 അല്ലെങ്കിൽ 2* hole.pos() + 2 കവിഞ്ഞൊഴുകും
            //
            child += unsafe { hole.get(child) <= hole.get(child + 1) } as usize;

            // സുരക്ഷ: മുകളിൽ പറഞ്ഞതുപോലെ തന്നെ
            unsafe { hole.move_to(child) };
            child = 2 * hole.pos() + 1;
        }

        if child == end - 1 {
            // സുരക്ഷ: കുട്ടി==അവസാനം, 1 <self.len(), അതിനാൽ ഇത് സാധുവായ ഒരു സൂചികയാണ്
            //  കുട്ടി==2 * hole.pos() + 1!= hole.pos().
            unsafe { hole.move_to(child) };
        }
        pos = hole.pos();
        drop(hole);

        // സുരക്ഷ: പോസ് എന്നത് ദ്വാരത്തിലെ സ്ഥാനമാണ്, അത് ഇതിനകം തെളിയിക്കപ്പെട്ടിട്ടുണ്ട്
        //  സാധുവായ സൂചികയായി.
        unsafe { self.sift_up(start, pos) };
    }

    fn rebuild(&mut self) {
        let mut n = self.len() / 2;
        while n > 0 {
            n -= 1;
            // സുരക്ഷ: n self.len()/2 ൽ നിന്ന് ആരംഭിച്ച് 0 ലേക്ക് താഴുന്നു.
            //  ഇനിപ്പറയുന്ന സന്ദർഭം! (N <self.len()) എന്നത് self.len() ==0 ആണെങ്കിൽ, പക്ഷേ ഇത് ലൂപ്പ് അവസ്ഥയാൽ നിരസിക്കപ്പെടുന്നു.
            //
            unsafe { self.sift_down(n) };
        }
    }

    /// `other`-ന്റെ എല്ലാ ഘടകങ്ങളും `self`-ലേക്ക് നീക്കുന്നു, `other` ശൂന്യമാക്കും.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    ///
    /// let v = vec![-10, 1, 2, 3, 3];
    /// let mut a = BinaryHeap::from(v);
    ///
    /// let v = vec![-20, 5, 43];
    /// let mut b = BinaryHeap::from(v);
    ///
    /// a.append(&mut b);
    ///
    /// assert_eq!(a.into_sorted_vec(), [-20, -10, 1, 2, 3, 3, 5, 43]);
    /// assert!(b.is_empty());
    /// ```
    #[stable(feature = "binary_heap_append", since = "1.11.0")]
    pub fn append(&mut self, other: &mut Self) {
        if self.len() < other.len() {
            swap(self, other);
        }

        if other.is_empty() {
            return;
        }

        #[inline(always)]
        fn log2_fast(x: usize) -> usize {
            (usize::BITS - x.leading_zeros() - 1) as usize
        }

        // `rebuild` O(len1 + len2) പ്രവർത്തനങ്ങളും ഏറ്റവും മോശം അവസ്ഥയിൽ ഏകദേശം 2 *(len1 + len2) താരതമ്യങ്ങളും `extend` O(len2* log(len1)) പ്രവർത്തനങ്ങളും ഏറ്റവും മോശം അവസ്ഥയിൽ 1 *len2* log_2(len1) താരതമ്യങ്ങളും എടുക്കുന്നു, len1>= len2 എന്ന് കരുതുന്നു.
        // വലിയ കൂമ്പാരങ്ങൾക്കായി, ക്രോസ്ഓവർ പോയിന്റ് ഇനി ഈ ന്യായവാദം പിന്തുടരുന്നില്ല, അത് അനുഭാവപൂർവ്വം നിർണ്ണയിക്കപ്പെട്ടു.
        //
        //
        //
        //
        #[inline]
        fn better_to_rebuild(len1: usize, len2: usize) -> bool {
            let tot_len = len1 + len2;
            if tot_len <= 2048 {
                2 * tot_len < len2 * log2_fast(len1)
            } else {
                2 * tot_len < len2 * 11
            }
        }

        if better_to_rebuild(self.len(), other.len()) {
            self.data.append(&mut other.data);
            self.rebuild();
        } else {
            self.extend(other.drain());
        }
    }

    /// കൂമ്പാര ക്രമത്തിൽ ഘടകങ്ങൾ വീണ്ടെടുക്കുന്ന ഒരു ഇറ്ററേറ്റർ നൽകുന്നു.
    /// വീണ്ടെടുത്ത ഘടകങ്ങൾ യഥാർത്ഥ കൂമ്പാരത്തിൽ നിന്ന് നീക്കംചെയ്യുന്നു.
    /// കൂമ്പാര ക്രമത്തിൽ ഡ്രോപ്പ് ചെയ്യുമ്പോൾ ശേഷിക്കുന്ന ഘടകങ്ങൾ നീക്കംചെയ്യും.
    ///
    /// Note:
    /// * `.drain_sorted()` *O*(*n*\*log(* n*)); `.drain()` നേക്കാൾ വേഗത കുറവാണ്.
    ///   മിക്ക കേസുകളിലും നിങ്ങൾ രണ്ടാമത്തേത് ഉപയോഗിക്കണം.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// #![feature(binary_heap_drain_sorted)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    /// assert_eq!(heap.len(), 5);
    ///
    /// drop(heap.drain_sorted()); // കൂമ്പാര ക്രമത്തിൽ എല്ലാ ഘടകങ്ങളും നീക്കംചെയ്യുന്നു
    /// assert_eq!(heap.len(), 0);
    /// ```
    #[inline]
    #[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
    pub fn drain_sorted(&mut self) -> DrainSorted<'_, T> {
        DrainSorted { inner: self }
    }

    /// പ്രവചിക്കുക വ്യക്തമാക്കിയ ഘടകങ്ങൾ മാത്രം നിലനിർത്തുന്നു.
    ///
    /// മറ്റൊരു വിധത്തിൽ പറഞ്ഞാൽ, `e` എല്ലാ ഘടകങ്ങളും നീക്കംചെയ്യുക, അതായത് `f(&e)` `false` നൽകുന്നു.
    /// ഘടകങ്ങൾ ക്രമീകരിക്കാത്ത (വ്യക്തമാക്കാത്ത) ക്രമത്തിലാണ് സന്ദർശിക്കുന്നത്.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// #![feature(binary_heap_retain)]
    /// use std::collections::BinaryHeap;
    ///
    /// let mut heap = BinaryHeap::from(vec![-10, -5, 1, 2, 4, 13]);
    ///
    /// heap.retain(|x| x % 2 == 0); // ഇരട്ട സംഖ്യകൾ മാത്രം സൂക്ഷിക്കുക
    ///
    /// assert_eq!(heap.into_sorted_vec(), [-10, 2, 4])
    /// ```
    #[unstable(feature = "binary_heap_retain", issue = "71503")]
    pub fn retain<F>(&mut self, f: F)
    where
        F: FnMut(&T) -> bool,
    {
        self.data.retain(f);
        self.rebuild();
    }
}

impl<T> BinaryHeap<T> {
    /// vector-ലെ എല്ലാ മൂല്യങ്ങളും അനിയന്ത്രിതമായ ക്രമത്തിൽ സന്ദർശിക്കുന്ന ഒരു ഇറ്ററേറ്റർ നൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // 1, 2, 3, 4 ഏകപക്ഷീയമായ ക്രമത്തിൽ അച്ചടിക്കുക
    /// for x in heap.iter() {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { iter: self.data.iter() }
    }

    /// കൂമ്പാര ക്രമത്തിൽ ഘടകങ്ങൾ വീണ്ടെടുക്കുന്ന ഒരു ഇറ്ററേറ്റർ നൽകുന്നു.
    /// ഈ രീതി യഥാർത്ഥ കൂമ്പാരം ഉപയോഗിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// #![feature(binary_heap_into_iter_sorted)]
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5]);
    ///
    /// assert_eq!(heap.into_iter_sorted().take(2).collect::<Vec<_>>(), vec![5, 4]);
    /// ```
    #[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
    pub fn into_iter_sorted(self) -> IntoIterSorted<T> {
        IntoIterSorted { inner: self }
    }

    /// ബൈനറി ഹീപ്പിലെ ഏറ്റവും മികച്ച ഇനം അല്ലെങ്കിൽ ശൂന്യമാണെങ്കിൽ `None` നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// assert_eq!(heap.peek(), None);
    ///
    /// heap.push(1);
    /// heap.push(5);
    /// heap.push(2);
    /// assert_eq!(heap.peek(), Some(&5));
    ///
    /// ```
    ///
    /// # സമയ സങ്കീർണ്ണത
    ///
    /// ഏറ്റവും മോശം അവസ്ഥയിൽ *O*(1) ആണ് ചെലവ്.
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&self) -> Option<&T> {
        self.data.get(0)
    }

    /// വീണ്ടും അനുവദിക്കാതെ ബൈനറി കൂമ്പാരത്തിന് കൈവശം വയ്ക്കാവുന്ന ഘടകങ്ങളുടെ എണ്ണം നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::with_capacity(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.data.capacity()
    }

    /// തന്നിരിക്കുന്ന `BinaryHeap`-ൽ കൃത്യമായി `additional` കൂടുതൽ ഘടകങ്ങൾ ഉൾപ്പെടുത്താനുള്ള ഏറ്റവും കുറഞ്ഞ ശേഷി കരുതിവച്ചിരിക്കുന്നു.
    /// ശേഷി ഇതിനകം പര്യാപ്തമാണെങ്കിൽ ഒന്നും ചെയ്യുന്നില്ല.
    ///
    /// അലോക്കേറ്റർ ശേഖരണത്തിന് ആവശ്യപ്പെടുന്നതിനേക്കാൾ കൂടുതൽ ഇടം നൽകുമെന്നത് ശ്രദ്ധിക്കുക.
    /// അതിനാൽ ശേഷി കൃത്യമായി ചുരുങ്ങിയതായി ആശ്രയിക്കാനാവില്ല.
    /// future ഉൾപ്പെടുത്തലുകൾ പ്രതീക്ഷിക്കുന്നുണ്ടെങ്കിൽ [`reserve`] തിരഞ്ഞെടുക്കുക.
    ///
    /// # Panics
    ///
    /// പുതിയ ശേഷി `usize` കവിഞ്ഞൊഴുകുകയാണെങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve_exact(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    ///
    /// [`reserve`]: BinaryHeap::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.data.reserve_exact(additional);
    }

    /// `BinaryHeap`-ൽ ഉൾപ്പെടുത്തുന്നതിന് കുറഞ്ഞത് `additional` കൂടുതൽ ഘടകങ്ങൾക്കായുള്ള കരുതൽ ശേഷി.
    /// ഇടയ്ക്കിടെ വീണ്ടും അനുവദിക്കുന്നത് ഒഴിവാക്കാൻ ശേഖരം കൂടുതൽ ഇടം കരുതിവച്ചേക്കാം.
    ///
    /// # Panics
    ///
    /// പുതിയ ശേഷി `usize` കവിഞ്ഞൊഴുകുകയാണെങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    /// heap.reserve(100);
    /// assert!(heap.capacity() >= 100);
    /// heap.push(4);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.data.reserve(additional);
    }

    /// കഴിയുന്നത്ര അധിക ശേഷി നിരസിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to_fit();
    /// assert!(heap.capacity() == 0);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.data.shrink_to_fit();
    }

    /// കുറഞ്ഞ പരിധിയിലുള്ള ശേഷി നിരസിക്കുന്നു.
    ///
    /// ശേഷി നീളവും നൽകിയ മൂല്യവും പോലെ വലുതായി തുടരും.
    ///
    ///
    /// നിലവിലെ ശേഷി താഴ്ന്ന പരിധിയേക്കാൾ കുറവാണെങ്കിൽ, ഇത് ഒരു നോ-ഒപ്പ് ആണ്.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::BinaryHeap;
    /// let mut heap: BinaryHeap<i32> = BinaryHeap::with_capacity(100);
    ///
    /// assert!(heap.capacity() >= 100);
    /// heap.shrink_to(10);
    /// assert!(heap.capacity() >= 10);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.data.shrink_to(min_capacity)
    }

    /// `BinaryHeap` ഉപയോഗിക്കുകയും അന്തർലീനമായ vector അനിയന്ത്രിതമായ ക്രമത്തിൽ നൽകുകയും ചെയ്യുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4, 5, 6, 7]);
    /// let vec = heap.into_vec();
    ///
    /// // ചില ക്രമത്തിൽ അച്ചടിക്കും
    /// for x in vec {
    ///     println!("{}", x);
    /// }
    /// ```
    #[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
    pub fn into_vec(self) -> Vec<T> {
        self.into()
    }

    /// ബൈനറി കൂമ്പാരത്തിന്റെ നീളം നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert_eq!(heap.len(), 2);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.data.len()
    }

    /// ബൈനറി കൂമ്പാരം ശൂന്യമാണോയെന്ന് പരിശോധിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::new();
    ///
    /// assert!(heap.is_empty());
    ///
    /// heap.push(3);
    /// heap.push(5);
    /// heap.push(1);
    ///
    /// assert!(!heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// ബൈനറി ഹീപ്പ് മായ്‌ക്കുന്നു, നീക്കംചെയ്‌ത ഘടകങ്ങൾക്ക് മുകളിൽ ഒരു ഇറ്ററേറ്റർ നൽകുന്നു.
    ///
    /// ഘടകങ്ങൾ അനിയന്ത്രിതമായ ക്രമത്തിൽ നീക്കംചെയ്യുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// for x in heap.drain() {
    ///     println!("{}", x);
    /// }
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain(&mut self) -> Drain<'_, T> {
        Drain { iter: self.data.drain(..) }
    }

    /// ബൈനറി കൂമ്പാരത്തിൽ നിന്ന് എല്ലാ ഇനങ്ങളും ഉപേക്ഷിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let mut heap = BinaryHeap::from(vec![1, 3]);
    ///
    /// assert!(!heap.is_empty());
    ///
    /// heap.clear();
    ///
    /// assert!(heap.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.drain();
    }
}

/// ദ്വാരം ഒരു സ്ലൈസിലെ ദ്വാരത്തെ പ്രതിനിധീകരിക്കുന്നു, അതായത് സാധുവായ മൂല്യമില്ലാത്ത ഒരു സൂചിക (കാരണം ഇത് നീക്കുകയോ തനിപ്പകർപ്പാക്കുകയോ ചെയ്തു).
///
/// ഡ്രോപ്പിൽ, `Hole` യഥാർത്ഥത്തിൽ നീക്കംചെയ്‌ത മൂല്യത്തിൽ ദ്വാര സ്ഥാനം പൂരിപ്പിച്ച് സ്ലൈസ് പുന restore സ്ഥാപിക്കും.
///
struct Hole<'a, T: 'a> {
    data: &'a mut [T],
    elt: ManuallyDrop<T>,
    pos: usize,
}

impl<'a, T> Hole<'a, T> {
    /// സൂചിക `pos` ൽ ഒരു പുതിയ `Hole` സൃഷ്ടിക്കുക.
    ///
    /// സുരക്ഷിതമല്ലാത്തതിനാൽ പോസ് ഡാറ്റാ സ്ലൈസിനുള്ളിലായിരിക്കണം.
    #[inline]
    unsafe fn new(data: &'a mut [T], pos: usize) -> Self {
        debug_assert!(pos < data.len());
        // സുരക്ഷിതം: പോസ് സ്ലൈസിനുള്ളിലായിരിക്കണം
        let elt = unsafe { ptr::read(data.get_unchecked(pos)) };
        Hole { data, elt: ManuallyDrop::new(elt), pos }
    }

    #[inline]
    fn pos(&self) -> usize {
        self.pos
    }

    /// നീക്കംചെയ്‌ത ഘടകത്തിലേക്ക് ഒരു റഫറൻസ് നൽകുന്നു.
    #[inline]
    fn element(&self) -> &T {
        &self.elt
    }

    /// `index`-ലെ ഘടകത്തിലേക്ക് ഒരു റഫറൻസ് നൽകുന്നു.
    ///
    /// സുരക്ഷിതമല്ലാത്തതിനാൽ സൂചിക ഡാറ്റാ സ്ലൈസിനുള്ളിലായിരിക്കണം, മാത്രമല്ല പോസിന് തുല്യമാകരുത്.
    #[inline]
    unsafe fn get(&self, index: usize) -> &T {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe { self.data.get_unchecked(index) }
    }

    /// ദ്വാരം പുതിയ സ്ഥലത്തേക്ക് നീക്കുക
    ///
    /// സുരക്ഷിതമല്ലാത്തതിനാൽ സൂചിക ഡാറ്റാ സ്ലൈസിനുള്ളിലായിരിക്കണം, മാത്രമല്ല പോസിന് തുല്യമാകരുത്.
    #[inline]
    unsafe fn move_to(&mut self, index: usize) {
        debug_assert!(index != self.pos);
        debug_assert!(index < self.data.len());
        unsafe {
            let ptr = self.data.as_mut_ptr();
            let index_ptr: *const _ = ptr.add(index);
            let hole_ptr = ptr.add(self.pos);
            ptr::copy_nonoverlapping(index_ptr, hole_ptr, 1);
        }
        self.pos = index;
    }
}

impl<T> Drop for Hole<'_, T> {
    #[inline]
    fn drop(&mut self) {
        // ദ്വാരം വീണ്ടും പൂരിപ്പിക്കുക
        unsafe {
            let pos = self.pos;
            ptr::copy_nonoverlapping(&*self.elt, self.data.get_unchecked_mut(pos), 1);
        }
    }
}

/// ഒരു `BinaryHeap` ന്റെ ഘടകങ്ങൾക്ക് മുകളിലുള്ള ഒരു ആവർത്തനം.
///
/// ഈ `struct` സൃഷ്ടിച്ചത് [`BinaryHeap::iter()`] ആണ്.
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// [`iter`]: BinaryHeap::iter
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Iter<'a, T: 'a> {
    iter: slice::Iter<'a, T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for Iter<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Iter").field(&self.iter.as_slice()).finish()
    }
}

// FIXME(#26925) `#[derive(Clone)]` ന് അനുകൂലമായി നീക്കംചെയ്യുക
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Clone for Iter<'_, T> {
    fn clone(&self) -> Self {
        Iter { iter: self.iter.clone() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> Iterator for Iter<'a, T> {
    type Item = &'a T;

    #[inline]
    fn next(&mut self) -> Option<&'a T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(self) -> Option<&'a T> {
        self.iter.last()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> DoubleEndedIterator for Iter<'a, T> {
    #[inline]
    fn next_back(&mut self) -> Option<&'a T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for Iter<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Iter<'_, T> {}

/// ഒരു `BinaryHeap` ന്റെ ഘടകങ്ങളെക്കാൾ സ്വന്തമായ ഒരു ഇറ്ററേറ്റർ.
///
/// ഈ `struct` സൃഷ്ടിച്ചത് [`BinaryHeap::into_iter()`] ആണ് (`IntoIterator` trait നൽകിയതാണ്).
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// [`into_iter`]: BinaryHeap::into_iter
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Clone)]
pub struct IntoIter<T> {
    iter: vec::IntoIter<T>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl<T: fmt::Debug> fmt::Debug for IntoIter<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.iter.as_slice()).finish()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Iterator for IntoIter<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> DoubleEndedIterator for IntoIter<T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> ExactSizeIterator for IntoIter<T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for IntoIter<T> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T> SourceIter for IntoIter<T> {
    type Source = IntoIter<T>;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I> InPlaceIterable for IntoIter<I> {}

impl<I> AsIntoIter for IntoIter<I> {
    type Item = I;

    fn as_into_iter(&mut self) -> &mut vec::IntoIter<Self::Item> {
        &mut self.iter
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
#[derive(Clone, Debug)]
pub struct IntoIterSorted<T> {
    inner: BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> Iterator for IntoIterSorted<T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for IntoIterSorted<T> {}

#[unstable(feature = "binary_heap_into_iter_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for IntoIterSorted<T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for IntoIterSorted<T> {}

/// ഒരു `BinaryHeap` ന്റെ ഘടകങ്ങൾക്ക് മുകളിലൂടെ ഒഴുകുന്ന ഇറ്ററേറ്റർ.
///
/// ഈ `struct` സൃഷ്ടിച്ചത് [`BinaryHeap::drain()`] ആണ്.
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// [`drain`]: BinaryHeap::drain
#[stable(feature = "drain", since = "1.6.0")]
#[derive(Debug)]
pub struct Drain<'a, T: 'a> {
    iter: vec::Drain<'a, T>,
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> Iterator for Drain<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.iter.next()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> DoubleEndedIterator for Drain<'_, T> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        self.iter.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl<T> ExactSizeIterator for Drain<'_, T> {
    fn is_empty(&self) -> bool {
        self.iter.is_empty()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Drain<'_, T> {}

/// ഒരു `BinaryHeap` ന്റെ ഘടകങ്ങൾക്ക് മുകളിലൂടെ ഒഴുകുന്ന ഇറ്ററേറ്റർ.
///
/// ഈ `struct` സൃഷ്ടിച്ചത് [`BinaryHeap::drain_sorted()`] ആണ്.
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// [`drain_sorted`]: BinaryHeap::drain_sorted
#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
#[derive(Debug)]
pub struct DrainSorted<'a, T: Ord> {
    inner: &'a mut BinaryHeap<T>,
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<'a, T: Ord> Drop for DrainSorted<'a, T> {
    /// ഹീപ്പ് ക്രമത്തിൽ ഹീപ്പ് ഘടകങ്ങൾ നീക്കംചെയ്യുന്നു.
    fn drop(&mut self) {
        struct DropGuard<'r, 'a, T: Ord>(&'r mut DrainSorted<'a, T>);

        impl<'r, 'a, T: Ord> Drop for DropGuard<'r, 'a, T> {
            fn drop(&mut self) {
                while self.0.inner.pop().is_some() {}
            }
        }

        while let Some(item) = self.inner.pop() {
            let guard = DropGuard(self);
            drop(item);
            mem::forget(guard);
        }
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> Iterator for DrainSorted<'_, T> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        self.inner.pop()
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = self.inner.len();
        (exact, Some(exact))
    }
}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> ExactSizeIterator for DrainSorted<'_, T> {}

#[unstable(feature = "binary_heap_drain_sorted", issue = "59278")]
impl<T: Ord> FusedIterator for DrainSorted<'_, T> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T: Ord> TrustedLen for DrainSorted<'_, T> {}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T: Ord> From<Vec<T>> for BinaryHeap<T> {
    /// ഒരു `Vec<T>`-നെ `BinaryHeap<T>`-ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// ഈ പരിവർത്തനം സ്ഥലത്തുതന്നെ സംഭവിക്കുന്നു, ഒപ്പം *O*(*n*) സമയ സങ്കീർണ്ണതയുമുണ്ട്.
    fn from(vec: Vec<T>) -> BinaryHeap<T> {
        let mut heap = BinaryHeap { data: vec };
        heap.rebuild();
        heap
    }
}

#[stable(feature = "binary_heap_extras_15", since = "1.5.0")]
impl<T> From<BinaryHeap<T>> for Vec<T> {
    /// ഒരു `BinaryHeap<T>`-നെ `Vec<T>`-ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// ഈ പരിവർത്തനത്തിന് ഡാറ്റാ ചലനമോ അലോക്കേഷനോ ആവശ്യമില്ല, കൂടാതെ സ്ഥിരമായ സമയ സങ്കീർണ്ണതയുമുണ്ട്.
    ///
    fn from(heap: BinaryHeap<T>) -> Vec<T> {
        heap.data
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> FromIterator<T> for BinaryHeap<T> {
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> BinaryHeap<T> {
        BinaryHeap::from(iter.into_iter().collect::<Vec<_>>())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for BinaryHeap<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// ഒരു ഉപഭോഗ ഇറ്ററേറ്റർ സൃഷ്ടിക്കുന്നു, അതായത്, ബൈനറി കൂമ്പാരത്തിൽ നിന്ന് ഓരോ മൂല്യത്തെയും അനിയന്ത്രിതമായ ക്രമത്തിൽ നീക്കുന്ന ഒന്ന്.
    /// ഇത് വിളിച്ചതിന് ശേഷം ബൈനറി ഹീപ്പ് ഉപയോഗിക്കാൻ കഴിയില്ല.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::collections::BinaryHeap;
    /// let heap = BinaryHeap::from(vec![1, 2, 3, 4]);
    ///
    /// // 1, 2, 3, 4 ഏകപക്ഷീയമായ ക്രമത്തിൽ അച്ചടിക്കുക
    /// for x in heap.into_iter() {
    ///     // x ന് i32 തരം ഉണ്ട്, &i32 അല്ല
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { iter: self.data.into_iter() }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a BinaryHeap<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord> Extend<T> for BinaryHeap<T> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<I>>::spec_extend(self, iter);
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T: Ord, I: IntoIterator<Item = T>> SpecExtend<I> for BinaryHeap<T> {
    default fn spec_extend(&mut self, iter: I) {
        self.extend_desugared(iter.into_iter());
    }
}

impl<T: Ord> SpecExtend<BinaryHeap<T>> for BinaryHeap<T> {
    fn spec_extend(&mut self, ref mut other: BinaryHeap<T>) {
        self.append(other);
    }
}

impl<T: Ord> BinaryHeap<T> {
    fn extend_desugared<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();

        self.reserve(lower);

        iterator.for_each(move |elem| self.push(elem));
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Ord + Copy> Extend<&'a T> for BinaryHeap<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}