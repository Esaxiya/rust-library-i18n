use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // മൂന്നാം കക്ഷി അലോക്കേറ്ററുകളും എക്സ് 100 എക്സും തമ്മിലുള്ള സംയോജനത്തിന്റെ ഒരു ടെസ്റ്റ് എഴുതുന്നത് അൽപ്പം ശ്രമകരമാണ്, കാരണം എക്സ് 01 എക്സ് എപിഐ തെറ്റായ അലോക്കേഷൻ രീതികൾ വെളിപ്പെടുത്തുന്നില്ല, അതിനാൽ അലോക്കേറ്റർ തീർന്നുപോകുമ്പോൾ എന്തുസംഭവിക്കുന്നുവെന്ന് ഞങ്ങൾക്ക് പരിശോധിക്കാൻ കഴിയില്ല (ഒരു panic കണ്ടെത്തുന്നതിനപ്പുറം).
    //
    //
    // പകരം, സംഭരണം റിസർവ് ചെയ്യുമ്പോൾ `RawVec` രീതികൾ കുറഞ്ഞത് അലോക്കേറ്റർ API വഴി കടന്നുപോകുന്നുണ്ടോയെന്ന് ഇത് പരിശോധിക്കുന്നു.
    //
    //
    //
    //
    //

    // അലോക്കേഷൻ ശ്രമങ്ങൾ പരാജയപ്പെടുന്നതിന് മുമ്പ് ഒരു നിശ്ചിത അളവിൽ ഇന്ധനം ഉപയോഗിക്കുന്ന ഒരു ഭീമൻ അലോക്കേറ്റർ.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (ഒരു റീലോക്കിന് കാരണമാകുന്നു, അങ്ങനെ 50 + 150=200 യൂണിറ്റ് ഇന്ധനം ഉപയോഗിക്കുന്നു)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // ആദ്യം, X001 പോലെ `reserve` അലോക്കേറ്റ് ചെയ്യുന്നു.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 എന്നത് 7 ന്റെ ഇരട്ടിയാണ്, അതിനാൽ `reserve` `reserve_exact` പോലെ പ്രവർത്തിക്കണം.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 എന്നത് 12 ന്റെ പകുതിയിൽ താഴെയാണ്, അതിനാൽ `reserve` എക്‌സ്‌പോണൻസിയായി വളരണം.
        // എഴുതുമ്പോൾ ഈ ടെസ്റ്റ് ഗ്രോ ഫാക്ടർ 2 ആണ്, അതിനാൽ പുതിയ ശേഷി 24 ആണ്, എന്നിരുന്നാലും, എക്സ് 00 എക്സിന്റെ ഗ്രോ ഫാക്ടറും ശരിയാണ്.
        //
        // അതിനാൽ `>= 18` ഉറപ്പിച്ചുപറയുന്നു.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}