//! യൂണിക്കോഡ് സ്ട്രിംഗ് സ്ലൈസ്.
//!
//! *[See also the `str` primitive type](str).*
//!
//! `&str` തരം രണ്ട് പ്രധാന സ്ട്രിംഗ് തരങ്ങളിൽ ഒന്നാണ്, മറ്റൊന്ന് `String`.
//! `String` ക p ണ്ടർപാർട്ടിൽ നിന്ന് വ്യത്യസ്തമായി, അതിന്റെ ഉള്ളടക്കങ്ങൾ കടമെടുത്തതാണ്.
//!
//! # അടിസ്ഥാന ഉപയോഗം
//!
//! `&str` തരത്തിന്റെ അടിസ്ഥാന സ്ട്രിംഗ് പ്രഖ്യാപനം:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! ഇവിടെ ഞങ്ങൾ ഒരു സ്ട്രിംഗ് അക്ഷരാർത്ഥത്തിൽ പ്രഖ്യാപിച്ചു, ഇത് ഒരു സ്ട്രിംഗ് സ്ലൈസ് എന്നും അറിയപ്പെടുന്നു.
//! സ്ട്രിംഗ് ലിറ്ററലുകൾക്ക് ഒരു സ്റ്റാറ്റിക് ലൈഫ് ടൈം ഉണ്ട്, അതിനർത്ഥം എക്സ് 100 എക്സ് സ്ട്രിംഗ് മുഴുവൻ പ്രോഗ്രാമിന്റെ കാലാവധിക്കും സാധുതയുള്ളതാണെന്ന് ഉറപ്പുനൽകുന്നു.
//!
//! `ഹലോ_വേൾഡിന്റെ` ജീവിതകാലവും ഞങ്ങൾക്ക് വ്യക്തമായി വ്യക്തമാക്കാൻ കഴിയും:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// ഈ മൊഡ്യൂളിലെ പല ഉപയോഗങ്ങളും ടെസ്റ്റ് കോൺഫിഗറേഷനിൽ മാത്രമേ ഉപയോഗിക്കുന്നുള്ളൂ.
// അവ പരിഹരിക്കുന്നതിനേക്കാൾ ഉപയോഗിക്കാത്ത_ ഇറക്കുമതി മുന്നറിയിപ്പ് ഓഫുചെയ്യുന്നത് ശുദ്ധമാണ്.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `Concat<str>`-ലെ `str` ഇവിടെ അർത്ഥവത്തല്ല.
/// trait-ന്റെ ഈ തരം പാരാമീറ്റർ മറ്റൊരു impl പ്രവർത്തനക്ഷമമാക്കാൻ മാത്രമേ നിലനിൽക്കൂ.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // ഹാർഡ്‌കോഡ് വലുപ്പമുള്ള ലൂപ്പുകൾ വളരെ വേഗത്തിൽ പ്രവർത്തിക്കുന്നു ചെറിയ സെപ്പറേറ്റർ ദൈർഘ്യമുള്ള കേസുകൾ പ്രത്യേകമാക്കുക
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // അനിയന്ത്രിതമായ പൂജ്യമല്ലാത്ത വലുപ്പ ഫാൾബാക്ക്
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Vec-നായി പ്രവർത്തിക്കുന്ന ഒപ്റ്റിമൈസ്ഡ് ജോയിൻ നടപ്പിലാക്കൽ<T>(ടി: കോപ്പി) സ്ട്രിംഗിന്റെ ആന്തരിക വെക്ക് നിലവിൽ എക്സ് 00 എക്സ് തരം അനുമാനവും സ്പെഷ്യലൈസേഷനും ഉള്ള ഒരു ബഗ് ഉണ്ട് (ലക്കം എക്സ് 01 എക്സ് കാണുക) ഈ കാരണത്താൽ സ്ലൈസ്കോൺകാറ്റ്<T>ടി യ്ക്ക് പ്രത്യേകമല്ല: കോപ്പി, സ്ലൈസ്കോൺകാറ്റ്<str>ഈ ഫംഗ്ഷന്റെ ഏക ഉപയോക്താവ്.
// അത് ശരിയാക്കുന്ന സമയത്തേക്ക് അത് അവശേഷിക്കുന്നു.
//
// സ്ട്രിംഗ്-ജോയിനിനുള്ള അതിരുകൾ എസ്: കടം<str>ഒപ്പം Vec-join Borrow <[T]> [T], ഒപ്പം ചില ടി യ്ക്കും AsRef <[T]>
// => s.borrow().as_ref() ഞങ്ങൾക്ക് എല്ലായ്പ്പോഴും കഷ്ണങ്ങൾ ഉണ്ട്
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // ആദ്യത്തെ സ്ലൈസ് അതിന് മുമ്പുള്ള സെപ്പറേറ്റർ ഇല്ലാതെ മാത്രമേയുള്ളൂ
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // `len` കണക്കുകൂട്ടൽ കവിഞ്ഞൊഴുകുകയാണെങ്കിൽ ചേർന്ന വെക്കിന്റെ കൃത്യമായ മൊത്തം ദൈർഘ്യം കണക്കുകൂട്ടുക, ഞങ്ങൾ panic ചെയ്യും, എന്തായാലും ഞങ്ങൾക്ക് മെമ്മറി തീർന്നുപോകുമായിരുന്നു, ബാക്കി ഫംഗ്ഷന് സുരക്ഷയ്ക്കായി മുൻകൂട്ടി അനുവദിച്ച മുഴുവൻ Vec ആവശ്യമാണ്
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // ആരംഭിക്കാത്ത ബഫർ തയ്യാറാക്കുക
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // കോപ്പി സെപ്പറേറ്ററും സ്ലൈസുകളും പരിധിയില്ലാതെ ചെക്കുകൾ ചെറിയ സെപ്പറേറ്ററുകൾക്കായി ഹാർഡ്‌കോഡ് ചെയ്ത ഓഫ്‌സെറ്റുകളുള്ള ലൂപ്പുകൾ സൃഷ്ടിക്കുന്നു (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // ഒരു വിചിത്രമായ വായ്പ നടപ്പാക്കൽ ദൈർഘ്യ കണക്കുകൂട്ടലിനും യഥാർത്ഥ പകർപ്പിനും വ്യത്യസ്ത കഷ്ണങ്ങൾ നൽകിയേക്കാം.
        //
        // ഞങ്ങൾ കോളറിലേക്ക് ആരംഭിക്കാത്ത ബൈറ്റുകൾ വെളിപ്പെടുത്തുന്നില്ലെന്ന് ഉറപ്പാക്കുക.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// സ്ട്രിംഗ് സ്ലൈസുകൾക്കുള്ള രീതികൾ.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// പകർത്തുകയോ അനുവദിക്കുകയോ ചെയ്യാതെ ഒരു `Box<str>`-നെ `Box<[u8]>`-ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// ഒരു പാറ്റേണിന്റെ എല്ലാ പൊരുത്തങ്ങളും മറ്റൊരു സ്ട്രിംഗ് ഉപയോഗിച്ച് മാറ്റിസ്ഥാപിക്കുന്നു.
    ///
    /// `replace` ഒരു പുതിയ [`String`] സൃഷ്‌ടിക്കുകയും ഈ സ്‌ട്രിംഗ് സ്ലൈസിൽ നിന്നുള്ള ഡാറ്റ അതിലേക്ക് പകർത്തുകയും ചെയ്യുന്നു.
    /// അങ്ങനെ ചെയ്യുമ്പോൾ, ഒരു പാറ്റേണിന്റെ പൊരുത്തങ്ങൾ കണ്ടെത്താൻ ഇത് ശ്രമിക്കുന്നു.
    /// ഇത് എന്തെങ്കിലും കണ്ടെത്തുകയാണെങ്കിൽ, അത് അവയെ മാറ്റിസ്ഥാപിക്കുന്ന സ്ട്രിംഗ് സ്ലൈസ് ഉപയോഗിച്ച് മാറ്റിസ്ഥാപിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// പാറ്റേൺ പൊരുത്തപ്പെടാത്തപ്പോൾ:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// ഒരു പാറ്റേണിന്റെ ആദ്യ N പൊരുത്തങ്ങൾ മറ്റൊരു സ്ട്രിംഗ് ഉപയോഗിച്ച് മാറ്റിസ്ഥാപിക്കുന്നു.
    ///
    /// `replacen` ഒരു പുതിയ [`String`] സൃഷ്‌ടിക്കുകയും ഈ സ്‌ട്രിംഗ് സ്ലൈസിൽ നിന്നുള്ള ഡാറ്റ അതിലേക്ക് പകർത്തുകയും ചെയ്യുന്നു.
    /// അങ്ങനെ ചെയ്യുമ്പോൾ, ഒരു പാറ്റേണിന്റെ പൊരുത്തങ്ങൾ കണ്ടെത്താൻ ഇത് ശ്രമിക്കുന്നു.
    /// ഇത് എന്തെങ്കിലും കണ്ടെത്തുകയാണെങ്കിൽ, അത് പരമാവധി `count` സമയങ്ങളിൽ മാറ്റിസ്ഥാപിക്കുന്ന സ്ട്രിംഗ് സ്ലൈസ് ഉപയോഗിച്ച് അവയെ മാറ്റിസ്ഥാപിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// പാറ്റേൺ പൊരുത്തപ്പെടാത്തപ്പോൾ:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // വീണ്ടും അനുവദിക്കുന്ന സമയം കുറയ്ക്കുമെന്ന് പ്രതീക്ഷിക്കുന്നു
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// ഈ സ്ട്രിംഗ് സ്ലൈസിന് തുല്യമായ ചെറിയക്ഷരം ഒരു പുതിയ [`String`] ആയി നൽകുന്നു.
    ///
    /// 'Lowercase' യൂണികോഡ് ഡെറിവേഡ് കോർ പ്രോപ്പർട്ടി `Lowercase` ന്റെ നിബന്ധനകൾ അനുസരിച്ച് നിർവചിച്ചിരിക്കുന്നു.
    ///
    /// കേസ് മാറ്റുമ്പോൾ ചില പ്രതീകങ്ങൾക്ക് ഒന്നിലധികം പ്രതീകങ്ങളായി വികസിപ്പിക്കാൻ കഴിയുമെന്നതിനാൽ, സ്ഥലത്ത് പ്രവർത്തിക്കുന്ന പാരാമീറ്റർ പരിഷ്‌ക്കരിക്കുന്നതിനുപകരം ഈ പ്രവർത്തനം ഒരു [`String`] നൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// സിഗ്മയ്‌ക്കൊപ്പം ഒരു തന്ത്രപരമായ ഉദാഹരണം:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // എന്നാൽ ഒരു വാക്കിന്റെ അവസാനം, ഇത് ς അല്ല not:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// കേസില്ലാത്ത ഭാഷകൾ മാറ്റിയിട്ടില്ല:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Word എന്നതിലേക്ക് മാപ്പ് ചെയ്യുന്ന ഒരു വാക്കിന്റെ അവസാനം ഒഴികെ Σ ലേക്ക് മാപ്പ് ചെയ്യുന്നു.
                // `SpecialCasing.txt`-ലെ ഒരേയൊരു സോപാധിക (contextual) എന്നാൽ ഭാഷ-സ്വതന്ത്ര മാപ്പിംഗ് ഇതാണ്, അതിനാൽ ഒരു സാധാരണ "condition" മെക്കാനിസം ഉള്ളതിനേക്കാൾ ഹാർഡ് കോഡ് ചെയ്യുക.
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // `Final_Sigma` ന്റെ നിർവചനത്തിനായി.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// ഈ സ്ട്രിംഗ് സ്ലൈസിന് തുല്യമായ വലിയക്ഷരം ഒരു പുതിയ [`String`] ആയി നൽകുന്നു.
    ///
    /// 'Uppercase' യൂണികോഡ് ഡെറിവേഡ് കോർ പ്രോപ്പർട്ടി `Uppercase` ന്റെ നിബന്ധനകൾ അനുസരിച്ച് നിർവചിച്ചിരിക്കുന്നു.
    ///
    /// കേസ് മാറ്റുമ്പോൾ ചില പ്രതീകങ്ങൾക്ക് ഒന്നിലധികം പ്രതീകങ്ങളായി വികസിപ്പിക്കാൻ കഴിയുമെന്നതിനാൽ, സ്ഥലത്ത് പ്രവർത്തിക്കുന്ന പാരാമീറ്റർ പരിഷ്‌ക്കരിക്കുന്നതിനുപകരം ഈ പ്രവർത്തനം ഒരു [`String`] നൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// കേസില്ലാത്ത സ്ക്രിപ്റ്റുകൾ മാറ്റിയിട്ടില്ല:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// ഒരു പ്രതീകം ഒന്നിലധികം ആകാം:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// പകർത്തുകയോ അനുവദിക്കുകയോ ചെയ്യാതെ ഒരു [`Box<str>`]-നെ [`String`]-ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// `n` തവണ ഒരു സ്ട്രിംഗ് ആവർത്തിച്ചുകൊണ്ട് ഒരു പുതിയ [`String`] സൃഷ്ടിക്കുന്നു.
    ///
    /// # Panics
    ///
    /// ശേഷി കവിഞ്ഞൊഴുകുകയാണെങ്കിൽ ഈ പ്രവർത്തനം panic ആയിരിക്കും.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// ഓവർഫ്ലോയിൽ ഒരു panic:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// ഓരോ പ്രതീകവും അതിന്റെ ASCII അപ്പർ കേസ് തുല്യമായി മാപ്പുചെയ്തിരിക്കുന്ന ഈ സ്ട്രിംഗിന്റെ ഒരു പകർപ്പ് നൽകുന്നു.
    ///
    ///
    /// ASCII അക്ഷരങ്ങൾ 'a' മുതൽ 'z' വരെ 'A' മുതൽ 'Z' വരെ മാപ്പുചെയ്‌തു, പക്ഷേ ASCII ഇതര അക്ഷരങ്ങൾക്ക് മാറ്റമില്ല.
    ///
    /// സ്ഥലത്തെ മൂല്യം വലിയക്ഷരമാക്കാൻ, [`make_ascii_uppercase`] ഉപയോഗിക്കുക.
    ///
    /// ASCII ഇതര പ്രതീകങ്ങൾക്ക് പുറമേ ASCII പ്രതീകങ്ങൾ വലിയക്ഷരമാക്കാൻ, [`to_uppercase`] ഉപയോഗിക്കുക.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() UTF-8 മാറ്റത്തെ സംരക്ഷിക്കുന്നു.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// ഓരോ പ്രതീകവും അതിന്റെ ASCII ലോവർ കേസ് തുല്യമായി മാപ്പുചെയ്തിരിക്കുന്ന ഈ സ്ട്രിംഗിന്റെ ഒരു പകർപ്പ് നൽകുന്നു.
    ///
    ///
    /// ASCII അക്ഷരങ്ങൾ 'A' മുതൽ 'Z' വരെ 'a' മുതൽ 'z' വരെ മാപ്പുചെയ്‌തു, പക്ഷേ ASCII ഇതര അക്ഷരങ്ങൾക്ക് മാറ്റമില്ല.
    ///
    /// സ്ഥലത്ത് മൂല്യം കുറയ്‌ക്കാൻ, [`make_ascii_lowercase`] ഉപയോഗിക്കുക.
    ///
    /// ASCII ഇതര പ്രതീകങ്ങൾക്ക് പുറമേ ASCII പ്രതീകങ്ങൾ ചെറിയക്ഷരമാക്കാൻ, [`to_lowercase`] ഉപയോഗിക്കുക.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() UTF-8 മാറ്റത്തെ സംരക്ഷിക്കുന്നു.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// സ്‌ട്രിംഗിൽ സാധുവായ UTF-8 ഉണ്ടെന്ന് പരിശോധിക്കാതെ ബോക്‌സുചെയ്‌ത ബൈറ്റുകളുടെ സ്ലൈസ് ബോക്‌സുചെയ്‌ത സ്‌ട്രിംഗ് സ്ലൈസിലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
///
///
/// # Examples
///
/// അടിസ്ഥാന ഉപയോഗം:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}