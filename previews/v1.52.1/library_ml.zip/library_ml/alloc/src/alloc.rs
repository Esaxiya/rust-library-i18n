//! മെമ്മറി അലോക്കേഷൻ API-കൾ

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // ആഗോള അലോക്കേറ്ററെ വിളിക്കാനുള്ള മാജിക് ചിഹ്നങ്ങളാണിവ.0rustc അവരെ `__rg_alloc` മുതലായവ വിളിക്കാൻ സൃഷ്ടിക്കുന്നു.
    // ഒരു `#[global_allocator]` ആട്രിബ്യൂട്ട് ഉണ്ടെങ്കിൽ (മാക്രോ ആട്രിബ്യൂട്ട് വികസിപ്പിക്കുന്ന കോഡ് ആ ഫംഗ്ഷനുകൾ സൃഷ്ടിക്കുന്നു) അല്ലെങ്കിൽ libstd (`__rdl_alloc` മുതലായവയിലെ സ്ഥിരസ്ഥിതി നടപ്പാക്കലുകളെ വിളിക്കുക).
    //
    // `library/std/src/alloc.rs`-ൽ) അല്ലെങ്കിൽ.
    // എൽ‌എൽ‌വി‌എമ്മിന്റെ rustc fork, പ്രത്യേകമായി ഈ ഫംഗ്ഷൻ നാമങ്ങൾ യഥാക്രമം `malloc`, `realloc`, `free` എന്നിവ ഒപ്റ്റിമൈസ് ചെയ്യാൻ പ്രാപ്തമാക്കും.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// ആഗോള മെമ്മറി അലോക്കേറ്റർ.
///
/// `#[global_allocator]` ആട്രിബ്യൂട്ടിൽ രജിസ്റ്റർ ചെയ്തിട്ടുള്ള അലോക്കേറ്ററിലേക്ക് കോളുകൾ കൈമാറുന്നതിലൂടെയോ അല്ലെങ്കിൽ `std` crate ന്റെ സ്ഥിരസ്ഥിതിയായോ ഈ തരം [`Allocator`] trait നടപ്പിലാക്കുന്നു.
///
///
/// Note: ഈ തരം അസ്ഥിരമാണെങ്കിലും, ഇത് നൽകുന്ന പ്രവർത്തനം [free functions in `alloc`](self#functions) വഴി ആക്സസ് ചെയ്യാൻ കഴിയും.
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// ആഗോള അലോക്കേറ്ററുമായി മെമ്മറി അനുവദിക്കുക.
///
/// ഈ ഫംഗ്ഷൻ `#[global_allocator]` ആട്രിബ്യൂട്ടിൽ രജിസ്റ്റർ ചെയ്തിട്ടുള്ള അലോക്കേറ്ററിന്റെ [`GlobalAlloc::alloc`] രീതിയിലേക്കോ അല്ലെങ്കിൽ `std` crate ന്റെ സ്ഥിരസ്ഥിതിയിലേക്കോ വിളിക്കുന്നു.
///
///
/// ഈ ഫംഗ്ഷനും [`Allocator`] trait ഉം സ്ഥിരത കൈവരിക്കുമ്പോൾ [`Global`] തരത്തിലുള്ള `alloc` രീതിക്ക് അനുകൂലമായി ഒഴിവാക്കപ്പെടുമെന്ന് പ്രതീക്ഷിക്കുന്നു.
///
/// # Safety
///
/// [`GlobalAlloc::alloc`] കാണുക.
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// ആഗോള അലോക്കേറ്റർ ഉപയോഗിച്ച് മെമ്മറി ഡീലോക്കേറ്റ് ചെയ്യുക.
///
/// ഈ ഫംഗ്ഷൻ `#[global_allocator]` ആട്രിബ്യൂട്ടിൽ രജിസ്റ്റർ ചെയ്തിട്ടുള്ള അലോക്കേറ്ററിന്റെ [`GlobalAlloc::dealloc`] രീതിയിലേക്കോ അല്ലെങ്കിൽ `std` crate ന്റെ സ്ഥിരസ്ഥിതിയിലേക്കോ വിളിക്കുന്നു.
///
///
/// ഈ ഫംഗ്ഷനും [`Allocator`] trait ഉം സ്ഥിരത കൈവരിക്കുമ്പോൾ [`Global`] തരത്തിലുള്ള `dealloc` രീതിക്ക് അനുകൂലമായി ഒഴിവാക്കപ്പെടുമെന്ന് പ്രതീക്ഷിക്കുന്നു.
///
/// # Safety
///
/// [`GlobalAlloc::dealloc`] കാണുക.
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// ആഗോള അലോക്കേറ്റർ ഉപയോഗിച്ച് മെമ്മറി വീണ്ടും അനുവദിക്കുക.
///
/// ഈ ഫംഗ്ഷൻ `#[global_allocator]` ആട്രിബ്യൂട്ടിൽ രജിസ്റ്റർ ചെയ്തിട്ടുള്ള അലോക്കേറ്ററിന്റെ [`GlobalAlloc::realloc`] രീതിയിലേക്കോ അല്ലെങ്കിൽ `std` crate ന്റെ സ്ഥിരസ്ഥിതിയിലേക്കോ വിളിക്കുന്നു.
///
///
/// ഈ ഫംഗ്ഷനും [`Allocator`] trait ഉം സ്ഥിരത കൈവരിക്കുമ്പോൾ [`Global`] തരത്തിലുള്ള `realloc` രീതിക്ക് അനുകൂലമായി ഒഴിവാക്കപ്പെടുമെന്ന് പ്രതീക്ഷിക്കുന്നു.
///
/// # Safety
///
/// [`GlobalAlloc::realloc`] കാണുക.
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// ഗ്ലോബൽ അലോക്കേറ്റർ ഉപയോഗിച്ച് സീറോ-ഇനീഷ്യലൈസ്ഡ് മെമ്മറി അനുവദിക്കുക.
///
/// ഈ ഫംഗ്ഷൻ `#[global_allocator]` ആട്രിബ്യൂട്ടിൽ രജിസ്റ്റർ ചെയ്തിട്ടുള്ള അലോക്കേറ്ററിന്റെ [`GlobalAlloc::alloc_zeroed`] രീതിയിലേക്കോ അല്ലെങ്കിൽ `std` crate ന്റെ സ്ഥിരസ്ഥിതിയിലേക്കോ വിളിക്കുന്നു.
///
///
/// ഈ ഫംഗ്ഷനും [`Allocator`] trait ഉം സ്ഥിരത കൈവരിക്കുമ്പോൾ [`Global`] തരത്തിലുള്ള `alloc_zeroed` രീതിക്ക് അനുകൂലമായി ഒഴിവാക്കപ്പെടുമെന്ന് പ്രതീക്ഷിക്കുന്നു.
///
/// # Safety
///
/// [`GlobalAlloc::alloc_zeroed`] കാണുക.
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // സുരക്ഷ: `layout` വലുപ്പത്തിൽ പൂജ്യമല്ലാത്തതാണ്,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // സുരക്ഷ: `Allocator::grow` പോലെ തന്നെ
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // സുരക്ഷ: `old_size` പൂജ്യമല്ലാത്തതിനാൽ `old_size` `new_size` നേക്കാൾ വലുതോ തുല്യമോ ആണ്
            // സുരക്ഷാ വ്യവസ്ഥകൾ അനുസരിച്ച്.മറ്റ് നിബന്ധനകൾ വിളിക്കുന്നയാൾ ശരിവെക്കണം
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` ഒരുപക്ഷേ `new_size >= old_layout.size()` അല്ലെങ്കിൽ സമാനമായ എന്തെങ്കിലും പരിശോധിക്കുന്നു.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // സുരക്ഷ: കാരണം `new_layout.size()`, `old_size` നേക്കാൾ വലുതോ തുല്യമോ ആയിരിക്കണം,
            // പഴയതും പുതിയതുമായ മെമ്മറി അലോക്കേഷൻ `old_size` ബൈറ്റുകൾക്കായി വായിക്കുന്നതിനും എഴുതുന്നതിനും സാധുതയുള്ളതാണ്.
            // കൂടാതെ, പഴയ അലോക്കേഷൻ ഇതുവരെ ഡീലോക്കേറ്റ് ചെയ്യാത്തതിനാൽ, ഇതിന് `new_ptr` ഓവർലാപ്പ് ചെയ്യാൻ കഴിയില്ല.
            // അതിനാൽ, `copy_nonoverlapping`-ലേക്കുള്ള കോൾ സുരക്ഷിതമാണ്.
            // `dealloc`-നായുള്ള സുരക്ഷാ കരാർ കോളർ ശരിവച്ചിരിക്കണം.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // സുരക്ഷ: `layout` വലുപ്പത്തിൽ പൂജ്യമല്ലാത്തതാണ്,
            // മറ്റ് നിബന്ധനകൾ വിളിക്കുന്നയാൾ ശരിവെക്കണം
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // സുരക്ഷ: എല്ലാ നിബന്ധനകളും വിളിക്കുന്നയാൾ പാലിക്കണം
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // സുരക്ഷ: എല്ലാ നിബന്ധനകളും വിളിക്കുന്നയാൾ പാലിക്കണം
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // സുരക്ഷ: വിളിക്കുന്നയാൾ നിബന്ധനകൾ പാലിക്കണം
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // സുരക്ഷ: `new_size` പൂജ്യമല്ലാത്തതാണ്.മറ്റ് നിബന്ധനകൾ വിളിക്കുന്നയാൾ ശരിവെക്കണം
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` ഒരുപക്ഷേ `new_size <= old_layout.size()` അല്ലെങ്കിൽ സമാനമായ എന്തെങ്കിലും പരിശോധിക്കുന്നു.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // സുരക്ഷ: കാരണം `new_size` `old_layout.size()` നേക്കാൾ ചെറുതോ തുല്യമോ ആയിരിക്കണം,
            // പഴയതും പുതിയതുമായ മെമ്മറി അലോക്കേഷൻ `new_size` ബൈറ്റുകൾക്കായി വായിക്കുന്നതിനും എഴുതുന്നതിനും സാധുതയുള്ളതാണ്.
            // കൂടാതെ, പഴയ അലോക്കേഷൻ ഇതുവരെ ഡീലോക്കേറ്റ് ചെയ്യാത്തതിനാൽ, ഇതിന് `new_ptr` ഓവർലാപ്പ് ചെയ്യാൻ കഴിയില്ല.
            // അതിനാൽ, `copy_nonoverlapping`-ലേക്കുള്ള കോൾ സുരക്ഷിതമാണ്.
            // `dealloc`-നായുള്ള സുരക്ഷാ കരാർ കോളർ ശരിവച്ചിരിക്കണം.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// അദ്വിതീയ പോയിന്ററുകൾക്കുള്ള അലോക്കേറ്റർ.
// ഈ പ്രവർത്തനം പിരിയരുത്.അങ്ങനെയാണെങ്കിൽ, MIR കോഡ്‌ജെൻ പരാജയപ്പെടും.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// ഈ ഒപ്പ് `Box` ന് തുല്യമായിരിക്കണം, അല്ലാത്തപക്ഷം ഒരു ICE സംഭവിക്കും.
// `Box`-ലേക്ക് ഒരു അധിക പാരാമീറ്റർ ചേർക്കുമ്പോൾ (`A: Allocator` പോലെ), ഇത് ഇവിടെയും ചേർക്കേണ്ടതുണ്ട്.
// ഉദാഹരണത്തിന്, `Box` `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)` ലേക്ക് മാറ്റുകയാണെങ്കിൽ, ഈ ഫംഗ്ഷനും `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)` ലേക്ക് മാറ്റേണ്ടതുണ്ട്.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # അലോക്കേഷൻ പിശക് ഹാൻഡ്‌ലർ

extern "Rust" {
    // ആഗോള അലോക്കേഷൻ പിശക് ഹാൻഡ്‌ലർ എന്ന് വിളിക്കാനുള്ള മാജിക് ചിഹ്നമാണിത്.
    // ഒരു `#[alloc_error_handler]` ഉണ്ടെങ്കിൽ `__rg_oom` ലേക്ക് വിളിക്കുന്നതിനോ അല്ലെങ്കിൽ (`__rdl_oom`) ന് താഴെയുള്ള സ്ഥിരസ്ഥിതി നടപ്പാക്കലുകളെ വിളിക്കുന്നതിനോ rustc ഇത് സൃഷ്ടിക്കുന്നു.
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// മെമ്മറി അലോക്കേഷൻ പിശക് അല്ലെങ്കിൽ പരാജയം നിർത്തുക.
///
/// ഒരു അലോക്കേഷൻ പിശകിന് മറുപടിയായി കണക്കുകൂട്ടൽ നിർത്താൻ ആഗ്രഹിക്കുന്ന മെമ്മറി അലോക്കേഷൻ API-കൾ വിളിക്കുന്നവർ `panic!` അല്ലെങ്കിൽ സമാനമായവ നേരിട്ട് വിളിക്കുന്നതിനുപകരം ഈ ഫംഗ്ഷനെ വിളിക്കാൻ പ്രോത്സാഹിപ്പിക്കുന്നു.
///
///
/// സ്റ്റാൻഡേർഡ് പിശകിലേക്ക് ഒരു സന്ദേശം അച്ചടിച്ച് പ്രക്രിയ നിർത്തലാക്കുക എന്നതാണ് ഈ ഫംഗ്ഷന്റെ സ്ഥിര സ്വഭാവം.
/// ഇത് [`set_alloc_error_hook`], [`take_alloc_error_hook`] എന്നിവ ഉപയോഗിച്ച് മാറ്റിസ്ഥാപിക്കാം.
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// അലോക്കേഷൻ ടെസ്റ്റിനായി `std::alloc::handle_alloc_error` നേരിട്ട് ഉപയോഗിക്കാം.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // ജനറേറ്റുചെയ്ത `__rust_alloc_error_handler` വഴി വിളിക്കുന്നു

    // `#[alloc_error_handler]` ഇല്ലെങ്കിൽ
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // ഒരു `#[alloc_error_handler]` ഉണ്ടെങ്കിൽ
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// മുൻകൂട്ടി അനുവദിച്ച, ആരംഭിക്കാത്ത മെമ്മറിയിലേക്ക് ക്ലോണുകൾ സ്പെഷ്യലൈസ് ചെയ്യുക.
/// `Box::clone`, `Rc`/`Arc::make_mut` എന്നിവ ഉപയോഗിക്കുന്നു.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // *ആദ്യം* അനുവദിച്ചതിലൂടെ, സ്ഥലത്ത് ക്ലോൺ ചെയ്ത മൂല്യം സൃഷ്ടിക്കാൻ ഒപ്റ്റിമൈസറെ അനുവദിച്ചേക്കാം, ലോക്കൽ ഒഴിവാക്കി നീക്കുക.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // ഒരു പ്രാദേശിക മൂല്യം ഉൾപ്പെടുത്താതെ തന്നെ ഞങ്ങൾക്ക് എല്ലായ്പ്പോഴും സ്ഥലത്ത് പകർത്താനാകും.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}