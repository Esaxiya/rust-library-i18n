//! `alloc` crate-ന്റെ prelude-ന്റെ ആദ്യ പതിപ്പ്.
//!
//! കൂടുതൽ വിവരങ്ങൾക്ക് [module-level documentation](../index.html) കാണുക.

#![unstable(feature = "alloc_prelude", issue = "58935")]

#[unstable(feature = "alloc_prelude", issue = "58935")]
pub use crate::borrow::ToOwned;
#[unstable(feature = "alloc_prelude", issue = "58935")]
pub use crate::boxed::Box;
#[unstable(feature = "alloc_prelude", issue = "58935")]
pub use crate::string::{String, ToString};
#[unstable(feature = "alloc_prelude", issue = "58935")]
pub use crate::vec::Vec;