//! Prelude അനുവദിക്കുക
//!
//! മൊഡ്യൂളുകളുടെ മുകളിൽ ഒരു ഗ്ലോബ് ഇറക്കുമതി ചേർത്തുകൊണ്ട് `alloc` crate ന്റെ സാധാരണയായി ഉപയോഗിക്കുന്ന ഇനങ്ങളുടെ ഇറക്കുമതി ലഘൂകരിക്കുക എന്നതാണ് ഈ മൊഡ്യൂളിന്റെ ലക്ഷ്യം:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;