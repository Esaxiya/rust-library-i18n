use crate::alloc::{Allocator, Global};
use crate::raw_vec::RawVec;
use core::fmt;
use core::intrinsics::arith_offset;
use core::iter::{FusedIterator, InPlaceIterable, SourceIter, TrustedLen, TrustedRandomAccess};
use core::marker::PhantomData;
use core::mem::{self};
use core::ptr::{self, NonNull};
use core::slice::{self};

/// ഒരു vector-ൽ നിന്ന് പുറത്തേക്ക് നീങ്ങുന്ന ഒരു ഇറ്ററേറ്റർ.
///
/// [`Vec`](super::Vec)-ലെ `into_iter` രീതി ഉപയോഗിച്ചാണ് ഈ `struct` സൃഷ്ടിച്ചിരിക്കുന്നത് ([`IntoIterator`] trait നൽകിയതാണ്).
///
///
/// # Example
///
/// ```
/// let v = vec![0, 1, 2];
/// let iter: std::vec::IntoIter<_> = v.into_iter();
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub struct IntoIter<
    T,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> {
    pub(super) buf: NonNull<T>,
    pub(super) phantom: PhantomData<T>,
    pub(super) cap: usize,
    pub(super) alloc: A,
    pub(super) ptr: *const T,
    pub(super) end: *const T,
}

#[stable(feature = "vec_intoiter_debug", since = "1.13.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for IntoIter<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}

impl<T, A: Allocator> IntoIter<T, A> {
    /// ഈ ആവർത്തനത്തിന്റെ ശേഷിക്കുന്ന ഇനങ്ങൾ ഒരു സ്ലൈസായി നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let vec = vec!['a', 'b', 'c'];
    /// let mut into_iter = vec.into_iter();
    /// assert_eq!(into_iter.as_slice(), &['a', 'b', 'c']);
    /// let _ = into_iter.next().unwrap();
    /// assert_eq!(into_iter.as_slice(), &['b', 'c']);
    /// ```
    #[stable(feature = "vec_into_iter_as_slice", since = "1.15.0")]
    pub fn as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr, self.len()) }
    }

    /// ഈ ഇറ്ററേറ്ററിന്റെ ശേഷിക്കുന്ന ഇനങ്ങൾ മ്യൂട്ടബിൾ സ്ലൈസായി നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let vec = vec!['a', 'b', 'c'];
    /// let mut into_iter = vec.into_iter();
    /// assert_eq!(into_iter.as_slice(), &['a', 'b', 'c']);
    /// into_iter.as_mut_slice()[2] = 'z';
    /// assert_eq!(into_iter.next().unwrap(), 'a');
    /// assert_eq!(into_iter.next().unwrap(), 'b');
    /// assert_eq!(into_iter.next().unwrap(), 'z');
    /// ```
    #[stable(feature = "vec_into_iter_as_slice", since = "1.15.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        unsafe { &mut *self.as_raw_mut_slice() }
    }

    /// അന്തർലീനമായ അലോക്കേറ്ററിലേക്ക് ഒരു റഫറൻസ് നൽകുന്നു.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn as_raw_mut_slice(&mut self) -> *mut [T] {
        ptr::slice_from_raw_parts_mut(self.ptr as *mut T, self.len())
    }

    /// ശേഷിക്കുന്ന ഘടകങ്ങൾ ഉപേക്ഷിച്ച് ബാക്കിംഗ് അലോക്കേഷൻ ഉപേക്ഷിക്കുന്നു.
    ///
    /// ഇത് ഏകദേശം ഇനിപ്പറയുന്നവയ്ക്ക് തുല്യമാണ്, പക്ഷേ കൂടുതൽ കാര്യക്ഷമമാണ്
    ///
    /// ```
    /// # let mut into_iter = Vec::<u8>::with_capacity(10).into_iter();
    /// (&mut into_iter).for_each(core::mem::drop);
    /// unsafe { core::ptr::write(&mut into_iter, Vec::new().into_iter()); }
    /// ```
    pub(super) fn forget_allocation_drop_remaining(&mut self) {
        let remaining = self.as_raw_mut_slice();

        // ഒരു പുതിയ സ്ട്രക്റ്റ് സൃഷ്ടിച്ച് &mut സ്വയം തിരുത്തിയെഴുതുന്നതിനുപകരം വ്യക്തിഗത ഫീൽഡുകൾ പുനരാലേഖനം ചെയ്യുക.
        //
        // ഇത് കുറച്ച് അസംബ്ലി സൃഷ്ടിക്കുന്നു
        self.cap = 0;
        self.buf = unsafe { NonNull::new_unchecked(RawVec::NEW.ptr()) };
        self.ptr = self.buf.as_ptr();
        self.end = self.buf.as_ptr();

        unsafe {
            ptr::drop_in_place(remaining);
        }
    }
}

#[stable(feature = "vec_intoiter_as_ref", since = "1.46.0")]
impl<T, A: Allocator> AsRef<[T]> for IntoIter<T, A> {
    fn as_ref(&self) -> &[T] {
        self.as_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Send, A: Allocator + Send> Send for IntoIter<T, A> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: Sync, A: Allocator> Sync for IntoIter<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Iterator for IntoIter<T, A> {
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<T> {
        if self.ptr as *const _ == self.end {
            None
        } else if mem::size_of::<T>() == 0 {
            // ഉദ്ദേശ്യത്തോടെ 'ptr.offset' ഉപയോഗിക്കരുത്, കാരണം 0 വലുപ്പമുള്ള vectors ന് ഇത് സമാന പോയിന്റർ നൽകും.
            //
            //
            self.ptr = unsafe { arith_offset(self.ptr as *const i8, 1) as *mut T };

            // ഈ ZST-യുടെ ഒരു മൂല്യം സൃഷ്ടിക്കുക.
            Some(unsafe { mem::zeroed() })
        } else {
            let old = self.ptr;
            self.ptr = unsafe { self.ptr.offset(1) };

            Some(unsafe { ptr::read(old) })
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let exact = if mem::size_of::<T>() == 0 {
            (self.end as usize).wrapping_sub(self.ptr as usize)
        } else {
            unsafe { self.end.offset_from(self.ptr) as usize }
        };
        (exact, Some(exact))
    }

    #[inline]
    fn count(self) -> usize {
        self.len()
    }

    unsafe fn __iterator_get_unchecked(&mut self, i: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        // സുരക്ഷ: `i` അതിരുകളിലാണെന്ന് കോളർ ഉറപ്പ് നൽകണം
        // `Vec<T>`, അതിനാൽ `i` ന് ഒരു `isize` ഓവർഫ്ലോ ചെയ്യാൻ കഴിയില്ല, കൂടാതെ `self.ptr.add(i)` ന് `Vec<T>` ന്റെ ഒരു ഘടകത്തിലേക്ക് പോയിന്റർ ചെയ്യാമെന്ന് ഉറപ്പുനൽകുന്നു, അതിനാൽ ഇത് ഡീറെഫറൻസിന് സാധുതയുള്ളതാണെന്ന് ഉറപ്പുനൽകുന്നു.
        //
        //
        // `Self: TrustedRandomAccess` നടപ്പിലാക്കുന്നതിന് `T: Copy` ആവശ്യമാണെന്നതും ശ്രദ്ധിക്കുക, അതിനാൽ ബഫറിൽ നിന്നുള്ള ഘടകങ്ങൾ വായിക്കുന്നത് `Drop`-നായി അസാധുവാക്കില്ല.
        //
        //
        //
        unsafe {
            if mem::size_of::<T>() == 0 { mem::zeroed() } else { ptr::read(self.ptr.add(i)) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> DoubleEndedIterator for IntoIter<T, A> {
    #[inline]
    fn next_back(&mut self) -> Option<T> {
        if self.end == self.ptr {
            None
        } else if mem::size_of::<T>() == 0 {
            // എന്തുകൊണ്ടാണ് 'ptr.offset' ഉപയോഗിക്കാത്തതെന്ന് മുകളിൽ കാണുക
            self.end = unsafe { arith_offset(self.end as *const i8, -1) as *mut T };

            // ഈ ZST-യുടെ ഒരു മൂല്യം സൃഷ്ടിക്കുക.
            Some(unsafe { mem::zeroed() })
        } else {
            self.end = unsafe { self.end.offset(-1) };

            Some(unsafe { ptr::read(self.end) })
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ExactSizeIterator for IntoIter<T, A> {
    fn is_empty(&self) -> bool {
        self.ptr == self.end
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<T, A: Allocator> FusedIterator for IntoIter<T, A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T, A: Allocator> TrustedLen for IntoIter<T, A> {}

#[doc(hidden)]
#[unstable(issue = "none", feature = "std_internals")]
// ടി: get_unchecked self.ptr മുന്നേറാത്തതിനാൽ !Drop-ന്റെ ഏകദേശമായി പകർത്തുക
// അതിനാൽ ഞങ്ങൾക്ക് ഡ്രോപ്പ്-ഹാൻഡ്‌ലിംഗ് നടപ്പിലാക്കാൻ കഴിയില്ല
unsafe impl<T, A: Allocator> TrustedRandomAccess for IntoIter<T, A>
where
    T: Copy,
{
    const MAY_HAVE_SIDE_EFFECT: bool = false;
}

#[stable(feature = "vec_into_iter_clone", since = "1.8.0")]
impl<T: Clone, A: Allocator + Clone> Clone for IntoIter<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        self.as_slice().to_vec_in(self.alloc.clone()).into_iter()
    }
    #[cfg(test)]
    fn clone(&self) -> Self {
        crate::slice::to_vec(self.as_slice(), self.alloc.clone()).into_iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for IntoIter<T, A> {
    fn drop(&mut self) {
        struct DropGuard<'a, T, A: Allocator>(&'a mut IntoIter<T, A>);

        impl<T, A: Allocator> Drop for DropGuard<'_, T, A> {
            fn drop(&mut self) {
                unsafe {
                    // `IntoIter::alloc` ഇതിനുശേഷം ഇനി ഉപയോഗിക്കില്ല
                    let alloc = ptr::read(&self.0.alloc);
                    // റോ‌വെക് ഡീലോക്കേഷൻ കൈകാര്യം ചെയ്യുന്നു
                    let _ = RawVec::from_raw_parts_in(self.0.buf.as_ptr(), self.0.cap, alloc);
                }
            }
        }

        let guard = DropGuard(self);
        // ശേഷിക്കുന്ന ഘടകങ്ങൾ നശിപ്പിക്കുക
        unsafe {
            ptr::drop_in_place(guard.0.as_raw_mut_slice());
        }
        // ഇപ്പോൾ `guard` ഉപേക്ഷിക്കുകയും ബാക്കിയുള്ളവ ചെയ്യുകയും ചെയ്യും
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T, A: Allocator> InPlaceIterable for IntoIter<T, A> {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<T, A: Allocator> SourceIter for IntoIter<T, A> {
    type Source = Self;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut Self::Source {
        self
    }
}

// ഇൻ-പ്ലേസ് ആവർത്തന സ്പെഷ്യലൈസേഷനായി ആന്തരിക സഹായി trait.
#[rustc_specialization_trait]
pub(crate) trait AsIntoIter {
    type Item;
    fn as_into_iter(&mut self) -> &mut IntoIter<Self::Item>;
}

impl<T> AsIntoIter for IntoIter<T> {
    type Item = T;

    fn as_into_iter(&mut self) -> &mut IntoIter<Self::Item> {
        self
    }
}