use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// ഒരു ഘടകം നീക്കംചെയ്യേണ്ടതുണ്ടോ എന്ന് നിർണ്ണയിക്കാൻ ഒരു അടയ്ക്കൽ ഉപയോഗിക്കുന്ന ഒരു ഇറ്ററേറ്റർ.
///
/// ഈ ഘടന [`Vec::drain_filter`] സൃഷ്ടിച്ചതാണ്.
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// `next`-ലേക്കുള്ള അടുത്ത കോൾ വഴി പരിശോധിക്കുന്ന ഇനത്തിന്റെ സൂചിക.
    pub(super) idx: usize,
    /// ഇതുവരെ (removed) കളഞ്ഞ ഇനങ്ങളുടെ എണ്ണം.
    pub(super) del: usize,
    /// കളയുന്നതിന് മുമ്പ് `vec`-ന്റെ യഥാർത്ഥ നീളം.
    pub(super) old_len: usize,
    /// ഫിൽട്ടർ പരിശോധന പ്രവചിക്കുന്നു.
    pub(super) pred: F,
    /// ഫിൽട്ടർ ടെസ്റ്റ് പ്രവചനത്തിൽ ഒരു panic സൂചിപ്പിക്കുന്ന ഒരു ഫ്ലാഗ് സംഭവിച്ചു.
    /// `DrainFilter`-ന്റെ ബാക്കി ഉപഭോഗം തടയുന്നതിന് ഡ്രോപ്പ് നടപ്പാക്കലിന്റെ സൂചനയായി ഇത് ഉപയോഗിക്കുന്നു.
    /// പ്രോസസ്സ് ചെയ്യാത്ത ഏതെങ്കിലും ഇനങ്ങൾ `vec`-ൽ ബാക്ക് ഷിഫ്റ്റ് ചെയ്യപ്പെടും, പക്ഷേ ഫിൽട്ടർ പ്രവചിക്കുന്നതിലൂടെ ഇനങ്ങളൊന്നും ഉപേക്ഷിക്കുകയോ പരീക്ഷിക്കുകയോ ചെയ്യില്ല.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// അന്തർലീനമായ അലോക്കേറ്ററിലേക്ക് ഒരു റഫറൻസ് നൽകുന്നു.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // പ്രവചനം വിളിച്ചതിന് ശേഷം സൂചിക * അപ്‌ഡേറ്റുചെയ്യുക.
                // സൂചിക മുമ്പ് അപ്‌ഡേറ്റ് ചെയ്യുകയും panics പ്രവചിക്കുകയും ചെയ്താൽ, ഈ സൂചികയിലെ ഘടകം ചോർന്നൊലിക്കും.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // ഇത് വളരെ താറുമാറായ ഒരു അവസ്ഥയാണ്, മാത്രമല്ല ശരിക്കും ചെയ്യാൻ ശരിയായ കാര്യമില്ല.
                        // `pred` എക്സിക്യൂട്ട് ചെയ്യാൻ ശ്രമിക്കുന്നത് തുടരാൻ ഞങ്ങൾ ആഗ്രഹിക്കുന്നില്ല, അതിനാൽ ഞങ്ങൾ പ്രോസസ്സ് ചെയ്യാത്ത എല്ലാ ഘടകങ്ങളും ബാക്ക്ഷിഫ്റ്റ് ചെയ്യുകയും അവ ഇപ്പോഴും നിലവിലുണ്ടെന്ന് വെക്കിനോട് പറയുകയും ചെയ്യുന്നു.
                        //
                        // പ്രവചനത്തിലെ ഒരു panic-ന് മുമ്പ് വിജയകരമായി വറ്റിച്ച ഇനത്തിന്റെ ഇരട്ട ഡ്രോപ്പ് തടയുന്നതിന് ബാക്ക്‌ഷിഫ്റ്റ് ആവശ്യമാണ്.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // ഫിൽ‌റ്റർ‌പ്രവചനം ഇതുവരെ പരിഭ്രാന്തരായിട്ടില്ലെങ്കിൽ‌അവശേഷിക്കുന്ന ഏതെങ്കിലും ഘടകങ്ങൾ‌ഉപയോഗിക്കാനുള്ള ശ്രമം.
        // ഞങ്ങൾ ഇതിനകം പരിഭ്രാന്തരായിട്ടുണ്ടെങ്കിലും അല്ലെങ്കിൽ ഇവിടെ ഉപഭോഗം panics ആണെങ്കിൽ ശേഷിക്കുന്ന ഏതെങ്കിലും ഘടകങ്ങൾ ഞങ്ങൾ ബാക്ക്ഷിഫ്റ്റ് ചെയ്യും.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}