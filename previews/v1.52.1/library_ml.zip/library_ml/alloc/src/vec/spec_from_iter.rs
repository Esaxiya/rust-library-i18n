use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// സ്പെഷ്യലൈസേഷൻ Vec::from_iter-നായി ഉപയോഗിക്കുന്ന trait
///
/// ## ഡെലിഗേഷൻ ഗ്രാഫ്:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // ഒരു സാധാരണ കേസ് ഒരു vector ഒരു ഫംഗ്ഷനിലേക്ക് കൈമാറുന്നു, അത് ഉടനടി ഒരു vector ലേക്ക് വീണ്ടും ശേഖരിക്കുന്നു.
        // IntoIter ഒട്ടും മുന്നേറുന്നില്ലെങ്കിൽ നമുക്ക് ഇത് ഷോർട്ട് സർക്യൂട്ട് ചെയ്യാൻ കഴിയും.
        // ഇത് വികസിപ്പിച്ചുകഴിഞ്ഞാൽ നമുക്ക് മെമ്മറി വീണ്ടും ഉപയോഗിക്കാനും ഡാറ്റ മുന്നിലേക്ക് നീക്കാനും കഴിയും.
        // ഫലമായുണ്ടാകുന്ന Vec-ന് ജനറിക് ഫ്രംഇറ്ററേറ്റർ നടപ്പാക്കലിലൂടെ സൃഷ്ടിക്കുന്നതിനേക്കാൾ കൂടുതൽ ഉപയോഗിക്കാത്ത ശേഷി ഉണ്ടാകാതിരിക്കുമ്പോൾ മാത്രമാണ് ഞങ്ങൾ അങ്ങനെ ചെയ്യുന്നത്.
        //
        // വെക്കിന്റെ അലോക്കേഷൻ സ്വഭാവം മന ally പൂർവ്വം വ്യക്തമാക്കാത്തതിനാൽ ആ പരിമിതി കർശനമായി ആവശ്യമില്ല.
        // എന്നാൽ ഇത് യാഥാസ്ഥിതിക തിരഞ്ഞെടുപ്പാണ്.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // ശൂന്യമായ Vec-കൾക്കായി extend() തന്നെ spec_from-ലേക്ക് നിയുക്തമാക്കുന്നതിനാൽ spec_extend()-ലേക്ക് നിയുക്തമാക്കണം
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// അന്തിമ ശേഷി + ദൈർഘ്യത്തെക്കുറിച്ച് വിശദീകരിക്കാൻ സ്പെക്ക്_എക്സ്റ്റെൻഡ് കൂടുതൽ നടപടികൾ കൈക്കൊള്ളേണ്ടതിനാൽ ഇത് `iterator.as_slice().to_vec()` ഉപയോഗിക്കുന്നു.
// `to_vec()` നേരിട്ട് ശരിയായ തുക അനുവദിക്കുകയും കൃത്യമായി പൂരിപ്പിക്കുകയും ചെയ്യുന്നു.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): cfg(test) ഉപയോഗിച്ച് ഈ രീതി നിർവചനത്തിന് ആവശ്യമായ അന്തർലീനമായ `[T]::to_vec` രീതി ലഭ്യമല്ല.
    // പകരം cfg(test) NB-ൽ മാത്രം ലഭ്യമായ `slice::to_vec` ഫംഗ്ഷൻ ഉപയോഗിക്കുക കൂടുതൽ വിവരങ്ങൾക്ക് slice.rs-ലെ slice::hack മൊഡ്യൂൾ കാണുക
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}