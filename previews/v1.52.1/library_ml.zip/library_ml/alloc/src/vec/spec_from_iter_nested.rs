use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// ഓവർലാപ്പിംഗ് സ്പെഷ്യലൈസേഷനുകൾക്ക് സ്വമേധയാ മുൻ‌ഗണന നൽകാൻ ആവശ്യമായ Vec::from_iter-നുള്ള trait എന്ന മറ്റൊരു സ്പെഷ്യലൈസേഷൻ വിശദാംശങ്ങൾക്ക് [`SpecFromIter`](super::SpecFromIter) കാണുക.
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // ആദ്യത്തെ ആവർത്തനം അൺ‌റോൾ ചെയ്യുക, കാരണം ആവർത്തന ശൂന്യമല്ലാത്തപ്പോൾ എല്ലാ സാഹചര്യങ്ങളിലും vector വിപുലീകരിക്കാൻ പോകുന്നു, പക്ഷേ extend_desugared() ലെ ലൂപ്പ് തുടർന്നുള്ള കുറച്ച് ലൂപ്പ് ആവർത്തനങ്ങളിൽ vector നിറഞ്ഞിരിക്കുന്നത് കാണാൻ പോകുന്നില്ല.
        //
        // അതിനാൽ ഞങ്ങൾക്ക് മികച്ച branch പ്രവചനം ലഭിക്കുന്നു.
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // ശൂന്യമായ Vec-കൾക്കായി extend() തന്നെ spec_from-ലേക്ക് നിയുക്തമാക്കുന്നതിനാൽ spec_extend()-ലേക്ക് നിയുക്തമാക്കണം
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // ശൂന്യമായ Vec-കൾക്കായി extend() തന്നെ spec_from-ലേക്ക് നിയുക്തമാക്കുന്നതിനാൽ spec_extend()-ലേക്ക് നിയുക്തമാക്കണം
        //
        vector.spec_extend(iterator);
        vector
    }
}