// `SetLenOnDrop` മൂല്യം പരിധിക്ക് പുറത്താകുമ്പോൾ വെക്കിന്റെ ദൈർഘ്യം സജ്ജമാക്കുക.
//
// ആശയം ഇതാണ്: സെറ്റ്ലെൻഓൺഡ്രോപ്പിലെ ദൈർഘ്യ ഫീൽഡ് ഒരു പ്രാദേശിക വേരിയബിളാണ്, ഒപ്റ്റിമൈസർ കാണും, വെക്കിന്റെ ഡാറ്റാ പോയിന്റർ വഴി ഏതെങ്കിലും സ്റ്റോറുകളുമായി അപരനാമമില്ല.
// അപരനാമ വിശകലന ലക്കം #32155-നുള്ള പരിഹാരമാണിത്
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}