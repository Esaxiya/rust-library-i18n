use crate::boxed::Box;

#[rustc_specialization_trait]
pub(super) unsafe trait IsZero {
    /// ഈ മൂല്യം പൂജ്യമാണോ എന്ന്
    fn is_zero(&self) -> bool;
}

macro_rules! impl_is_zero {
    ($t:ty, $is_zero:expr) => {
        unsafe impl IsZero for $t {
            #[inline]
            fn is_zero(&self) -> bool {
                $is_zero(*self)
            }
        }
    };
}

impl_is_zero!(i16, |x| x == 0);
impl_is_zero!(i32, |x| x == 0);
impl_is_zero!(i64, |x| x == 0);
impl_is_zero!(i128, |x| x == 0);
impl_is_zero!(isize, |x| x == 0);

impl_is_zero!(u16, |x| x == 0);
impl_is_zero!(u32, |x| x == 0);
impl_is_zero!(u64, |x| x == 0);
impl_is_zero!(u128, |x| x == 0);
impl_is_zero!(usize, |x| x == 0);

impl_is_zero!(bool, |x| x == false);
impl_is_zero!(char, |x| x == '\0');

impl_is_zero!(f32, |x: f32| x.to_bits() == 0);
impl_is_zero!(f64, |x: f64| x.to_bits() == 0);

unsafe impl<T> IsZero for *const T {
    #[inline]
    fn is_zero(&self) -> bool {
        (*self).is_null()
    }
}

unsafe impl<T> IsZero for *mut T {
    #[inline]
    fn is_zero(&self) -> bool {
        (*self).is_null()
    }
}

// `Option<&T>` ഒപ്പം `Option<Box<T>>`, `None` ശൂന്യമാണെന്ന് പ്രതിനിധീകരിക്കുന്നു.
// കൊഴുപ്പ് പോയിന്ററുകൾക്കായി, `Some` വേരിയന്റിലെ പോയിന്റർ മെറ്റാഡാറ്റയായ ബൈറ്റുകൾ `None` വേരിയന്റിൽ പാഡിംഗ് ചെയ്യുന്നു, അതിനാൽ അവഗണിക്കുകയും പകരം പൂജ്യം സമാരംഭിക്കുകയും ചെയ്യുന്നത് ശരിയാണ്.
//
// `Option<&mut T>` ഒരിക്കലും `Clone` നടപ്പിലാക്കുന്നില്ല, അതിനാൽ `SpecFromElem` ന്റെ impl ആവശ്യമില്ല.
//
//

unsafe impl<T: ?Sized> IsZero for Option<&T> {
    #[inline]
    fn is_zero(&self) -> bool {
        self.is_none()
    }
}

unsafe impl<T: ?Sized> IsZero for Option<Box<T>> {
    #[inline]
    fn is_zero(&self) -> bool {
        self.is_none()
    }
}