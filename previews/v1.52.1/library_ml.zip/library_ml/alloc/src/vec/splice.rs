use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::{Drain, Vec};

/// `Vec`-നായി ഒരു സ്‌പ്ലിസിംഗ് ഇറ്ററേറ്റർ.
///
/// ഈ ഘടന [`Vec::splice()`] സൃഷ്ടിച്ചതാണ്.
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// # Example
///
/// ```
/// let mut v = vec![0, 1, 2];
/// let new = [7, 8];
/// let iter: std::vec::Splice<_> = v.splice(1.., new.iter().cloned());
/// ```
#[derive(Debug)]
#[stable(feature = "vec_splice", since = "1.21.0")]
pub struct Splice<
    'a,
    I: Iterator + 'a,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator + 'a = Global,
> {
    pub(super) drain: Drain<'a, I::Item, A>,
    pub(super) replace_with: I,
}

#[stable(feature = "vec_splice", since = "1.21.0")]
impl<I: Iterator, A: Allocator> Iterator for Splice<'_, I, A> {
    type Item = I::Item;

    fn next(&mut self) -> Option<Self::Item> {
        self.drain.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.drain.size_hint()
    }
}

#[stable(feature = "vec_splice", since = "1.21.0")]
impl<I: Iterator, A: Allocator> DoubleEndedIterator for Splice<'_, I, A> {
    fn next_back(&mut self) -> Option<Self::Item> {
        self.drain.next_back()
    }
}

#[stable(feature = "vec_splice", since = "1.21.0")]
impl<I: Iterator, A: Allocator> ExactSizeIterator for Splice<'_, I, A> {}

#[stable(feature = "vec_splice", since = "1.21.0")]
impl<I: Iterator, A: Allocator> Drop for Splice<'_, I, A> {
    fn drop(&mut self) {
        self.drain.by_ref().for_each(drop);

        unsafe {
            if self.drain.tail_len == 0 {
                self.drain.vec.as_mut().extend(self.replace_with.by_ref());
                return;
            }

            // ആദ്യം drain() ശേഷിക്കുന്ന ശ്രേണി പൂരിപ്പിക്കുക.
            if !self.drain.fill(&mut self.replace_with) {
                return;
            }

            // കൂടുതൽ ഘടകങ്ങൾ ഉണ്ടാകാം.എസ്റ്റിമേറ്റായി താഴത്തെ പരിധി ഉപയോഗിക്കുക.
            // FIXME: മുകളിലുള്ളത് മികച്ച ess ഹമാണോ?അതോ മറ്റെന്തെങ്കിലും?
            let (lower_bound, _upper_bound) = self.replace_with.size_hint();
            if lower_bound > 0 {
                self.drain.move_tail(lower_bound);
                if !self.drain.fill(&mut self.replace_with) {
                    return;
                }
            }

            // ശേഷിക്കുന്ന ഏതെങ്കിലും ഘടകങ്ങൾ ശേഖരിക്കുക.
            // ഇത് പൂജ്യ-ദൈർഘ്യമുള്ള vector ആണ്, ഇത് `lower_bound` കൃത്യമായിരുന്നെങ്കിൽ അനുവദിക്കില്ല.
            let mut collected = self.replace_with.by_ref().collect::<Vec<I::Item>>().into_iter();
            // ഇപ്പോൾ ഞങ്ങൾക്ക് കൃത്യമായ എണ്ണം ഉണ്ട്.
            if collected.len() > 0 {
                self.drain.move_tail(collected.len());
                let filled = self.drain.fill(&mut collected);
                debug_assert!(filled);
                debug_assert_eq!(collected.len(), 0);
            }
        }
        // ആവശ്യമെങ്കിൽ `Drain::drop` വാൽ പിന്നിലേക്ക് നീക്കി `vec.len` പുന restore സ്ഥാപിക്കുക.
    }
}

/// `Splice::drop`-നായുള്ള സ്വകാര്യ സഹായ രീതികൾ
impl<T, A: Allocator> Drain<'_, T, A> {
    /// `self.vec.len` മുതൽ `self.tail_start` വരെയുള്ള ശ്രേണിയിൽ നിന്ന് നീക്കിയ ഘടകങ്ങൾ അടങ്ങിയിരിക്കുന്നു.
    ///
    /// `replace_with` ഇറ്ററേറ്ററിൽ നിന്നുള്ള പുതിയ ഘടകങ്ങൾ ഉപയോഗിച്ച് ആ ശ്രേണി കഴിയുന്നത്ര പൂരിപ്പിക്കുക.
    /// ഞങ്ങൾ മുഴുവൻ ശ്രേണിയും പൂരിപ്പിച്ചിട്ടുണ്ടെങ്കിൽ `true` നൽകുന്നു. (`replace_with.next()` didn’t return `None`.)
    unsafe fn fill<I: Iterator<Item = T>>(&mut self, replace_with: &mut I) -> bool {
        let vec = unsafe { self.vec.as_mut() };
        let range_start = vec.len;
        let range_end = self.tail_start;
        let range_slice = unsafe {
            slice::from_raw_parts_mut(vec.as_mut_ptr().add(range_start), range_end - range_start)
        };

        for place in range_slice {
            if let Some(new_item) = replace_with.next() {
                unsafe { ptr::write(place, new_item) };
                vec.len += 1;
            } else {
                return false;
            }
        }
        true
    }

    /// വാലിനുമുമ്പ് കൂടുതൽ ഘടകങ്ങൾ ചേർക്കുന്നതിന് ഇടം നൽകുന്നു.
    unsafe fn move_tail(&mut self, additional: usize) {
        let vec = unsafe { self.vec.as_mut() };
        let len = self.tail_start + self.tail_len;
        vec.buf.reserve(len, additional);

        let new_tail_start = self.tail_start + additional;
        unsafe {
            let src = vec.as_ptr().add(self.tail_start);
            let dst = vec.as_mut_ptr().add(new_tail_start);
            ptr::copy(src, dst, self.tail_len);
        }
        self.tail_start = new_tail_start;
    }
}