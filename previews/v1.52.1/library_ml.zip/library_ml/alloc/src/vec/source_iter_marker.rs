use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// ഉറവിട വിഹിതം വീണ്ടും ഉപയോഗിക്കുമ്പോൾ ഒരു വെക്കിലേക്ക് ഒരു ഇറ്ററേറ്റർ പൈപ്പ്ലൈൻ ശേഖരിക്കുന്നതിനുള്ള സ്പെഷ്യലൈസേഷൻ മാർക്കർ, അതായത്
/// സ്ഥലത്ത് പൈപ്പ്ലൈൻ പ്രവർത്തിപ്പിക്കുന്നു.
///
/// പുനരുപയോഗം ചെയ്യേണ്ട അലോക്കേഷൻ ആക്സസ് ചെയ്യുന്നതിന് സ്പെഷ്യലൈസിംഗ് ഫംഗ്ഷന് സോഴ്സ്ഇറ്റർ പാരന്റ് trait ആവശ്യമാണ്.
/// സ്പെഷ്യലൈസേഷൻ സാധുതയുള്ളതാകാൻ ഇത് പര്യാപ്തമല്ല.
/// Impl-ൽ അധിക പരിധികൾ കാണുക.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// std-ആന്തരിക SourceIter/InPlaceIterable traits അഡാപ്റ്ററിന്റെ ശൃംഖലകളാൽ മാത്രമേ നടപ്പിലാക്കൂ <Adapter<Adapter<IntoIter>>> (എല്ലാം core/std ന്റെ ഉടമസ്ഥതയിലുള്ളത്).
// അഡാപ്റ്റർ നടപ്പിലാക്കലുകളുടെ (`impl<I: Trait> Trait for Adapter<I>` ന് അപ്പുറത്തുള്ള) അധിക പരിധികൾ ഇതിനകം സ്പെഷ്യലൈസേഷൻ traits (കോപ്പി, ട്രസ്റ്റഡ് റാൻഡം ആക്സസ്, ഫ്യൂസ്ഡ്ഇറ്ററേറ്റർ) എന്ന് ഇതിനകം അടയാളപ്പെടുത്തിയിരിക്കുന്ന മറ്റ് traits നെ മാത്രം ആശ്രയിച്ചിരിക്കുന്നു.
//
// I.e. മാർക്കർ ഉപയോക്താവ് നൽകിയ തരങ്ങളുടെ ആയുസ്സിനെ ആശ്രയിക്കുന്നില്ല.മൊഡ്യൂലോ കോപ്പി ഹോൾ, മറ്റ് നിരവധി സ്പെഷ്യലൈസേഷനുകൾ ഇതിനകം ആശ്രയിച്ചിരിക്കുന്നു.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // trait bounds വഴി പ്രകടിപ്പിക്കാൻ കഴിയാത്ത അധിക ആവശ്യകതകൾ.പകരം ഞങ്ങൾ const eval-നെ ആശ്രയിക്കുന്നു:
        // a) പുനരുപയോഗത്തിന് ഒരു വിഹിതവും ഇല്ലാത്തതിനാൽ ZST-കളില്ല, അരിത്മെറ്റിക് panic b) അലോക്ക് കരാറിന് ആവശ്യമുള്ള വലുപ്പ പൊരുത്തം c) അലോക്ക് കരാറിന് ആവശ്യമായ വിന്യാസങ്ങൾ പൊരുത്തപ്പെടുന്നു
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // കൂടുതൽ ജനറിക് നടപ്പാക്കലുകളിലേക്കുള്ള തിരിച്ചുവരവ്
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // അതിനുശേഷം ശ്രമിക്കൂ
        // - ചില ഇറ്ററേറ്റർ അഡാപ്റ്ററുകൾക്ക് ഇത് വെക്റ്ററൈസ് ചെയ്യുന്നു
        // - മിക്ക ആന്തരിക ആവർത്തന രീതികളിൽ നിന്ന് വ്യത്യസ്തമായി, ഇത് ഒരു &mut സെൽഫ് മാത്രമേ എടുക്കൂ
        // - റൈറ്റ് പോയിന്റർ അതിന്റെ ഉൾവശം വഴി ത്രെഡ് ചെയ്ത് അവസാനം തിരികെ കൊണ്ടുവരാൻ ഇത് ഞങ്ങളെ അനുവദിക്കുന്നു
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // ആവർത്തനം വിജയിച്ചു, തല വീഴരുത്
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // സോഴ്സ്ഇറ്റർ കരാർ ഒഴിവാക്കിയതാണോയെന്ന് പരിശോധിക്കുക: അവ ഇല്ലായിരുന്നുവെങ്കിൽ ഞങ്ങൾ ഇത് വരെ എത്തിക്കില്ല
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // InPlaceIterable കരാർ പരിശോധിക്കുക.ഇറ്ററേറ്റർ സോഴ്‌സ് പോയിന്റർ വികസിപ്പിച്ചാൽ മാത്രമേ ഇത് സാധ്യമാകൂ.
        // ട്രസ്റ്റഡ് റാൻഡം ആക്സസ് വഴി ഇത് അൺചെക്ക് ചെയ്ത ആക്സസ് ഉപയോഗിക്കുകയാണെങ്കിൽ, ഉറവിട പോയിന്റർ അതിന്റെ പ്രാരംഭ സ്ഥാനത്ത് തുടരും, ഞങ്ങൾക്ക് ഇത് റഫറൻസായി ഉപയോഗിക്കാൻ കഴിയില്ല
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // ഉറവിടത്തിന്റെ വാലിൽ‌അവശേഷിക്കുന്ന ഏതെങ്കിലും മൂല്യങ്ങൾ‌നൽ‌കുക, പക്ഷേ ഇൻ‌ഡോയിറ്റർ‌പരിധി വിട്ട് പോയാൽ‌panics ഡ്രോപ്പ് ചെയ്താൽ‌, അലോക്കേഷൻ‌ഡ്രോപ്പ് ചെയ്യുന്നത് തടയുക, തുടർന്ന് dst_buf ലേക്ക് ശേഖരിക്കുന്ന ഏതെങ്കിലും ഘടകങ്ങൾ‌ഞങ്ങൾ‌ചോർത്തുന്നു.
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // സോഴ്സ് പോയിന്ററിലേക്ക് try_fold ന് ഒരു പ്രത്യേക റഫറൻസ് ഉള്ളതിനാൽ InPlaceIterable കരാർ ഇവിടെ കൃത്യമായി പരിശോധിക്കാൻ കഴിയില്ല, ഞങ്ങൾക്ക് ചെയ്യാനാകുന്നത് അത് ഇപ്പോഴും പരിധിയിലാണോയെന്ന് പരിശോധിക്കുക എന്നതാണ്
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}