use core::ptr::{self};
use core::slice::{self};

// ഇൻ-പ്ലേസ് ആവർത്തനത്തിനായുള്ള ഒരു സഹായി ഘടന, അത് ആവർത്തനത്തിന്റെ ലക്ഷ്യസ്ഥാനം കുറയ്ക്കുന്നു, അതായത് തല.
// ഉറവിട സ്ലൈസ് (വാൽ) IntoIter ഉപേക്ഷിച്ചു.
pub(super) struct InPlaceDrop<T> {
    pub(super) inner: *mut T,
    pub(super) dst: *mut T,
}

impl<T> InPlaceDrop<T> {
    fn len(&self) -> usize {
        unsafe { self.dst.offset_from(self.inner) as usize }
    }
}

impl<T> Drop for InPlaceDrop<T> {
    #[inline]
    fn drop(&mut self) {
        unsafe {
            ptr::drop_in_place(slice::from_raw_parts_mut(self.inner, self.len()));
        }
    }
}