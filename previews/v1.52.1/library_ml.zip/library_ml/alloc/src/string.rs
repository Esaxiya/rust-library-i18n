//! യു‌ടി‌എഫ്-8-എൻ‌കോഡുചെയ്‌ത, വളരാൻ‌കഴിയുന്ന സ്‌ട്രിംഗ്.
//!
//! ഈ മൊഡ്യൂളിൽ [`String`] തരം, സ്ട്രിംഗുകളിലേക്ക് പരിവർത്തനം ചെയ്യുന്നതിനുള്ള [`ToString`] trait, [`സ്ട്രിംഗ്`] ഉപയോഗിച്ച് പ്രവർത്തിക്കുന്നതിന്റെ ഫലമായി ഉണ്ടാകാവുന്ന നിരവധി പിശക് തരങ്ങൾ എന്നിവ അടങ്ങിയിരിക്കുന്നു.
//!
//!
//! # Examples
//!
//! ഒരു സ്ട്രിംഗിൽ നിന്ന് ഒരു പുതിയ [`String`] സൃഷ്ടിക്കാൻ ഒന്നിലധികം വഴികളുണ്ട്:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! ഒത്തുചേർന്ന് നിലവിലുള്ളതിൽ നിന്ന് നിങ്ങൾക്ക് ഒരു പുതിയ [`String`] സൃഷ്ടിക്കാൻ കഴിയും
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! നിങ്ങൾക്ക് സാധുവായ UTF-8 ബൈറ്റുകളുടെ vector ഉണ്ടെങ്കിൽ, നിങ്ങൾക്ക് അതിൽ നിന്ന് ഒരു [`String`] നിർമ്മിക്കാൻ കഴിയും.നിങ്ങൾക്ക് റിവേഴ്സ് ചെയ്യാനും കഴിയും.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // ഈ ബൈറ്റുകൾ സാധുതയുള്ളതാണെന്ന് ഞങ്ങൾക്കറിയാം, അതിനാൽ ഞങ്ങൾ `unwrap()` ഉപയോഗിക്കും.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// യു‌ടി‌എഫ്-8-എൻ‌കോഡുചെയ്‌ത, വളരാൻ‌കഴിയുന്ന സ്‌ട്രിംഗ്.
///
/// സ്‌ട്രിംഗിലെ ഉള്ളടക്കങ്ങൾക്ക് ഉടമസ്ഥാവകാശമുള്ള ഏറ്റവും സാധാരണമായ സ്‌ട്രിംഗ് തരമാണ് `String` തരം.കടമെടുത്ത ക p ണ്ടർപാർട്ടായ പ്രൈമിറ്റീവ് എക്സ് 00 എക്സുമായി ഇതിന് അടുത്ത ബന്ധമുണ്ട്.
///
/// # Examples
///
/// [`String::from`] ഉപയോഗിച്ച് നിങ്ങൾക്ക് [a literal string][`str`]-ൽ നിന്ന് ഒരു `String` സൃഷ്ടിക്കാൻ കഴിയും:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// നിങ്ങൾക്ക് [`push`] രീതി ഉപയോഗിച്ച് `String`-ലേക്ക് ഒരു [`char`] കൂട്ടിച്ചേർക്കാനും [`push_str`] രീതി ഉപയോഗിച്ച് ഒരു [`&str`] കൂട്ടിച്ചേർക്കാനും കഴിയും:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// നിങ്ങൾക്ക് UTF-8 ബൈറ്റുകളുടെ vector ഉണ്ടെങ്കിൽ, [`from_utf8`] രീതി ഉപയോഗിച്ച് നിങ്ങൾക്ക് അതിൽ നിന്ന് ഒരു `String` സൃഷ്ടിക്കാൻ കഴിയും:
///
/// ```
/// // ഒരു vector-ൽ ചില ബൈറ്റുകൾ
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // ഈ ബൈറ്റുകൾ സാധുതയുള്ളതാണെന്ന് ഞങ്ങൾക്കറിയാം, അതിനാൽ ഞങ്ങൾ `unwrap()` ഉപയോഗിക്കും.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `സ്ട്രിംഗ്` എപ്പോഴും സാധുവായ UTF-8 ആണ്.ഇതിന് കുറച്ച് സൂചനകളുണ്ട്, അതിൽ ആദ്യത്തേത് നിങ്ങൾക്ക് യുടിഎഫ്-8 അല്ലാത്ത ഒരു സ്ട്രിംഗ് ആവശ്യമുണ്ടെങ്കിൽ, എക്സ് 02 എക്സ് പരിഗണിക്കുക.ഇത് സമാനമാണ്, പക്ഷേ UTF-8 പരിമിതിയില്ലാതെ.രണ്ടാമത്തെ സൂചന, നിങ്ങൾക്ക് ഒരു `String`-ലേക്ക് സൂചികയിലാക്കാൻ കഴിയില്ല എന്നതാണ്:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// ഇൻഡെക്സിംഗ് ഒരു സ്ഥിരമായ സമയ പ്രവർത്തനമാണ് ഉദ്ദേശിക്കുന്നത്, പക്ഷേ ഇത് ചെയ്യാൻ UTF-8 എൻകോഡിംഗ് ഞങ്ങളെ അനുവദിക്കുന്നില്ല.കൂടാതെ, സൂചിക ഏതുതരം വസ്തുവാണ് നൽകേണ്ടതെന്ന് വ്യക്തമല്ല: ഒരു ബൈറ്റ്, ഒരു കോഡ് പോയിന്റ് അല്ലെങ്കിൽ ഒരു ഗ്രാഫിം ക്ലസ്റ്റർ.
/// [`bytes`], [`chars`] രീതികൾ യഥാക്രമം ആദ്യ രണ്ടിൽ ഇറ്ററേറ്ററുകൾ നൽകുന്നു.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `സ്ട്രിംഗ്` നടപ്പിലാക്കുന്നു [`ഡെറെഫ്`] `<Target=str>`, അതിനാൽ [`str`] ന്റെ എല്ലാ രീതികളും അവകാശമാക്കുക.ഇതുകൂടാതെ, ഒരു ആമ്പർസാൻഡ് എക്സ് 00 എക്സ് ഉപയോഗിച്ച് ഒരു എക്സ് 02 എക്സ് എടുക്കുന്ന ഒരു ഫംഗ്ഷനിലേക്ക് നിങ്ങൾക്ക് ഒരു എക്സ് 01 എക്സ് പാസ് ചെയ്യാമെന്നാണ് ഇതിനർത്ഥം:
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// ഇത് `String`-ൽ നിന്ന് ഒരു [`&str`] സൃഷ്ടിക്കുകയും അതിലേക്ക് കടക്കുകയും ചെയ്യും. ഈ പരിവർത്തനം വളരെ ചെലവുകുറഞ്ഞതാണ്, അതിനാൽ സാധാരണയായി ചില പ്രത്യേക കാരണങ്ങളാൽ ഒരു `String` ആവശ്യമില്ലെങ്കിൽ ഫംഗ്ഷനുകൾ [`&str`] നെ ആർഗ്യുമെന്റുകളായി സ്വീകരിക്കും.
///
/// ചില സാഹചര്യങ്ങളിൽ, [`Deref`] ബലപ്രയോഗം എന്നറിയപ്പെടുന്ന ഈ പരിവർത്തനം നടത്താൻ ആവശ്യമായ വിവരങ്ങൾ Rust-ന് ഇല്ല.ഇനിപ്പറയുന്ന ഉദാഹരണത്തിൽ ഒരു സ്ട്രിംഗ് സ്ലൈസ് [`&'a str`][`&str`] trait `TraitExample` നടപ്പിലാക്കുന്നു, കൂടാതെ `example_func` ഫംഗ്ഷൻ trait നടപ്പിലാക്കുന്ന എന്തും എടുക്കുന്നു.
/// ഈ സാഹചര്യത്തിൽ Rust ന് രണ്ട് വ്യക്തമായ പരിവർത്തനങ്ങൾ നടത്തേണ്ടതുണ്ട്, അത് Rust ന് ചെയ്യാനുള്ള മാർഗങ്ങളില്ല.
/// ഇക്കാരണത്താൽ, ഇനിപ്പറയുന്ന ഉദാഹരണം സമാഹരിക്കില്ല.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// പകരം രണ്ട് ഓപ്ഷനുകൾ പ്രവർത്തിക്കും.ആദ്യത്തേത്, `example_func(&example_string);` എന്ന വരി `example_func(example_string.as_str());` ലേക്ക് മാറ്റുക, [`as_str()`] രീതി ഉപയോഗിച്ച് സ്ട്രിംഗ് അടങ്ങിയ സ്ട്രിംഗ് സ്ലൈസ് വ്യക്തമായി വേർതിരിച്ചെടുക്കുക.
/// രണ്ടാമത്തെ വഴി `example_func(&example_string);` നെ `example_func(&*example_string);` ലേക്ക് മാറ്റുന്നു.
/// ഈ സാഹചര്യത്തിൽ ഞങ്ങൾ ഒരു `String`-നെ [`str`][`&str`]-ലേക്ക് ഡീഫറൻസ് ചെയ്യുന്നു, തുടർന്ന് [`str`][`&str`]-നെ [`&str`]-ലേക്ക് തിരികെ പരാമർശിക്കുന്നു.
/// രണ്ടാമത്തെ മാർ‌ഗ്ഗം കൂടുതൽ‌വിഡ് otic ിത്തമാണ്, എന്നിരുന്നാലും പരോക്ഷമായ പരിവർത്തനത്തെ ആശ്രയിക്കുന്നതിനേക്കാൾ‌വ്യക്തമായി പരിവർത്തനം നടത്തുന്നതിന് രണ്ടും പ്രവർത്തിക്കുന്നു.
///
/// # Representation
///
/// ഒരു എക്സ് 100 എക്സ് മൂന്ന് ഘടകങ്ങൾ ഉൾക്കൊള്ളുന്നു: ചില ബൈറ്റുകളിലേക്കുള്ള പോയിന്റർ, നീളം, ശേഷി.പോയിന്റർ അതിന്റെ ഡാറ്റ സംഭരിക്കുന്നതിന് ഉപയോഗിക്കുന്ന ഒരു ആന്തരിക ബഫറിലേക്ക് `String` ഉപയോഗിക്കുന്നു.നിലവിൽ‌ബഫറിൽ‌സംഭരിച്ചിരിക്കുന്ന ബൈറ്റുകളുടെ എണ്ണമാണ് ദൈർ‌ഘ്യം, ശേഷി ബഫറുകളിലെ ബഫറിന്റെ വലുപ്പമാണ്.
///
/// അതുപോലെ, നീളം എല്ലായ്പ്പോഴും ശേഷിയേക്കാൾ കുറവോ തുല്യമോ ആയിരിക്കും.
///
/// ഈ ബഫർ എല്ലായ്പ്പോഴും കൂമ്പാരത്തിൽ സൂക്ഷിക്കുന്നു.
///
/// നിങ്ങൾക്ക് [`as_ptr`], [`len`], [`capacity`] രീതികൾ ഉപയോഗിച്ച് ഇവ കാണാൻ കഴിയും:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME vec_into_raw_parts സ്ഥിരത കൈവരിക്കുമ്പോൾ ഇത് അപ്‌ഡേറ്റുചെയ്യുക.
/// // സ്‌ട്രിംഗിന്റെ ഡാറ്റ യാന്ത്രികമായി ഉപേക്ഷിക്കുന്നത് തടയുക
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // സ്റ്റോറിക്ക് പത്തൊൻപത് ബൈറ്റുകളുണ്ട്
/// assert_eq!(19, len);
///
/// // Ptr, len, കപ്പാസിറ്റി എന്നിവയിൽ നിന്ന് നമുക്ക് ഒരു സ്ട്രിംഗ് പുനർനിർമ്മിക്കാൻ കഴിയും.
/// // ഇതെല്ലാം സുരക്ഷിതമല്ല കാരണം ഘടകങ്ങൾ സാധുതയുള്ളതാണെന്ന് ഉറപ്പാക്കേണ്ടത് ഞങ്ങളുടെ ഉത്തരവാദിത്തമാണ്:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// ഒരു `String`-ന് മതിയായ ശേഷിയുണ്ടെങ്കിൽ, അതിലേക്ക് ഘടകങ്ങൾ ചേർക്കുന്നത് വീണ്ടും അനുവദിക്കില്ല.ഉദാഹരണത്തിന്, ഈ പ്രോഗ്രാം പരിഗണിക്കുക:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// ഇത് ഇനിപ്പറയുന്നവ output ട്ട്‌പുട്ട് ചെയ്യും:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// ആദ്യം, ഞങ്ങൾക്ക് മെമ്മറി ഒന്നും തന്നെ അനുവദിച്ചിട്ടില്ല, പക്ഷേ ഞങ്ങൾ സ്ട്രിംഗിനൊപ്പം ചേർക്കുമ്പോൾ, അത് അതിന്റെ ശേഷി ഉചിതമായി വർദ്ധിപ്പിക്കുന്നു.തുടക്കത്തിൽ ശരിയായ ശേഷി അനുവദിക്കുന്നതിന് ഞങ്ങൾ [`with_capacity`] രീതി ഉപയോഗിക്കുകയാണെങ്കിൽ:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// ഞങ്ങൾ മറ്റൊരു output ട്ട്‌പുട്ടിൽ അവസാനിക്കുന്നു:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// ഇവിടെ, ലൂപ്പിനുള്ളിൽ കൂടുതൽ മെമ്മറി അനുവദിക്കേണ്ട ആവശ്യമില്ല.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// UTF-8 ബൈറ്റ് vector-ൽ നിന്ന് ഒരു `String` പരിവർത്തനം ചെയ്യുമ്പോൾ സാധ്യമായ പിശക് മൂല്യം.
///
/// [`String`]-ലെ [`from_utf8`] രീതിയുടെ പിശക് തരമാണ് ഈ തരം.
/// പുനർവിജ്ഞാപനങ്ങൾ ശ്രദ്ധാപൂർവ്വം ഒഴിവാക്കുന്ന രീതിയിലാണ് ഇത് രൂപകൽപ്പന ചെയ്തിരിക്കുന്നത്: പരിവർത്തന ശ്രമത്തിൽ ഉപയോഗിച്ച vector ബൈറ്റ് [`into_bytes`] രീതി തിരികെ നൽകും.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// [`std::str`] നൽകിയ [`Utf8Error`] തരം [`u8`] ന്റെ ഒരു സ്ലൈസ് [`&str`] ലേക്ക് പരിവർത്തനം ചെയ്യുമ്പോൾ ഉണ്ടാകാവുന്ന ഒരു പിശകിനെ പ്രതിനിധീകരിക്കുന്നു.
/// ഈ അർത്ഥത്തിൽ, ഇത് `FromUtf8Error`-ലേക്കുള്ള ഒരു അനലോഗ് ആണ്, കൂടാതെ നിങ്ങൾക്ക് `FromUtf8Error`-ൽ നിന്ന് [`utf8_error`] രീതിയിലൂടെ ഒന്ന് നേടാം.
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// അടിസ്ഥാന ഉപയോഗം:
///
/// ```
/// // ഒരു vector-ൽ ചില അസാധുവായ ബൈറ്റുകൾ
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// UTF-16 ബൈറ്റ് സ്ലൈസിൽ നിന്ന് ഒരു `String` പരിവർത്തനം ചെയ്യുമ്പോൾ സാധ്യമായ പിശക് മൂല്യം.
///
/// [`String`]-ലെ [`from_utf16`] രീതിയുടെ പിശക് തരമാണ് ഈ തരം.
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// അടിസ്ഥാന ഉപയോഗം:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// ഒരു പുതിയ ശൂന്യമായ `String` സൃഷ്ടിക്കുന്നു.
    ///
    /// `String` ശൂന്യമാണെന്നതിനാൽ, ഇത് പ്രാരംഭ ബഫറുകളൊന്നും അനുവദിക്കില്ല.ഈ പ്രാരംഭ പ്രവർത്തനം വളരെ വിലകുറഞ്ഞതാണെന്നാണ് ഇതിനർത്ഥം, നിങ്ങൾ ഡാറ്റ ചേർക്കുമ്പോൾ ഇത് പിന്നീട് അമിത വിഹിതത്തിന് കാരണമായേക്കാം.
    ///
    /// `String` എത്ര ഡാറ്റ കൈവശം വയ്ക്കുമെന്നതിനെക്കുറിച്ച് നിങ്ങൾക്ക് ഒരു ധാരണയുണ്ടെങ്കിൽ, അമിതമായ പുനർവിഹിതം തടയുന്നതിന് [`with_capacity`] രീതി പരിഗണിക്കുക.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// ഒരു പ്രത്യേക ശേഷിയുള്ള പുതിയ ശൂന്യമായ `String` സൃഷ്ടിക്കുന്നു.
    ///
    /// `സ്ട്രിംഗിന് 'അവരുടെ ഡാറ്റ സൂക്ഷിക്കാൻ ഒരു ആന്തരിക ബഫർ ഉണ്ട്.
    /// ശേഷി ആ ബഫറിന്റെ ദൈർഘ്യമാണ്, മാത്രമല്ല [`capacity`] രീതി ഉപയോഗിച്ച് അന്വേഷിക്കാനും കഴിയും.
    /// ഈ രീതി ശൂന്യമായ `String` സൃഷ്ടിക്കുന്നു, പക്ഷേ `capacity` ബൈറ്റുകൾ പിടിക്കാൻ കഴിയുന്ന പ്രാരംഭ ബഫറുള്ള ഒന്ന്.
    /// നിങ്ങൾ `String`-ലേക്ക് ഒരു കൂട്ടം ഡാറ്റ കൂട്ടിച്ചേർക്കുമ്പോൾ ഇത് ഉപയോഗപ്രദമാകും, ഇത് ചെയ്യേണ്ട റീലോക്കേഷനുകളുടെ എണ്ണം കുറയ്ക്കുന്നു.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// തന്നിരിക്കുന്ന ശേഷി `0` ആണെങ്കിൽ, അലോക്കേഷൻ ഒന്നും സംഭവിക്കില്ല, ഈ രീതി [`new`] രീതിക്ക് സമാനമാണ്.
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // കൂടുതൽ‌ശേഷി ഉണ്ടെങ്കിലും സ്‌ട്രിംഗിൽ‌പ്രതീകങ്ങളൊന്നുമില്ല
    /// assert_eq!(s.len(), 0);
    ///
    /// // ഇവയെല്ലാം വീണ്ടും അനുവദിക്കാതെ തന്നെ ചെയ്യുന്നു ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... എന്നാൽ ഇത് സ്ട്രിംഗ് വീണ്ടും അനുവദിക്കാൻ ഇടയാക്കും
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): cfg(test) ഉപയോഗിച്ച് ഈ രീതി നിർവചനത്തിന് ആവശ്യമായ അന്തർലീനമായ `[T]::to_vec` രീതി ലഭ്യമല്ല.
    // പരിശോധന ആവശ്യങ്ങൾ‌ക്കായി ഞങ്ങൾ‌ക്ക് ഈ രീതി ആവശ്യമില്ലാത്തതിനാൽ‌, കൂടുതൽ‌വിവരങ്ങൾ‌ക്ക് എൻ‌ബി slice.rs ലെ slice::hack മൊഡ്യൂൾ‌കാണുക
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// ഒരു vector ബൈറ്റുകളെ `String` ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// ഒരു സ്ട്രിംഗ് ([`String`]) ബൈറ്റുകൾ ([`u8`]) ഉപയോഗിച്ചാണ് നിർമ്മിച്ചിരിക്കുന്നത്, കൂടാതെ vector ബൈറ്റുകളുടെ ([`Vec<u8>`]) ബൈറ്റുകളാൽ നിർമ്മിച്ചതാണ്, അതിനാൽ ഈ പ്രവർത്തനം രണ്ടും തമ്മിൽ പരിവർത്തനം ചെയ്യുന്നു.
    /// എല്ലാ ബൈറ്റ് സ്ലൈസുകളും സാധുവായ `സ്ട്രിംഗ്`സ് അല്ല, എന്നിരുന്നാലും: `String` ന് സാധുവായ UTF-8 ആവശ്യമുണ്ട്.
    /// `from_utf8()` ബൈറ്റുകൾ സാധുവായ UTF-8 ആണെന്ന് ഉറപ്പുവരുത്തുന്നതിനായി പരിശോധിക്കുന്നു, തുടർന്ന് പരിവർത്തനം നടത്തുന്നു.
    ///
    /// ബൈറ്റ് സ്ലൈസ് സാധുവായ UTF-8 ആണെന്ന് നിങ്ങൾക്ക് ഉറപ്പുണ്ടെങ്കിൽ, സാധുതാ പരിശോധനയുടെ ഓവർഹെഡ് നേടാൻ നിങ്ങൾ ആഗ്രഹിക്കുന്നില്ലെങ്കിൽ, ഈ ഫംഗ്ഷന്റെ സുരക്ഷിതമല്ലാത്ത പതിപ്പ് ഉണ്ട്, [`from_utf8_unchecked`], സമാന സ്വഭാവമുള്ളതും എന്നാൽ പരിശോധന ഒഴിവാക്കുന്നതുമാണ്.
    ///
    ///
    /// കാര്യക്ഷമതയ്ക്കായി vector പകർത്താതിരിക്കാൻ ഈ രീതി ശ്രദ്ധിക്കും.
    ///
    /// നിങ്ങൾക്ക് `String` ന് പകരം [`&str`] വേണമെങ്കിൽ, [`str::from_utf8`] പരിഗണിക്കുക.
    ///
    /// ഈ രീതിയുടെ വിപരീതം [`into_bytes`] ആണ്.
    ///
    /// # Errors
    ///
    /// നൽകിയ ബൈറ്റുകൾ UTF-8 അല്ലാത്തത് എന്തുകൊണ്ടാണെന്ന വിവരണത്തോടെ സ്ലൈസ് UTF-8 അല്ലെങ്കിൽ [`Err`] നൽകുന്നു.നിങ്ങൾ നീക്കിയ vector ഉം ഉൾപ്പെടുത്തിയിട്ടുണ്ട്.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// // ഒരു vector-ൽ ചില ബൈറ്റുകൾ
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // ഈ ബൈറ്റുകൾ സാധുതയുള്ളതാണെന്ന് ഞങ്ങൾക്കറിയാം, അതിനാൽ ഞങ്ങൾ `unwrap()` ഉപയോഗിക്കും.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// തെറ്റായ ബൈറ്റുകൾ:
    ///
    /// ```
    /// // ഒരു vector-ൽ ചില അസാധുവായ ബൈറ്റുകൾ
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// ഈ പിശക് ഉപയോഗിച്ച് നിങ്ങൾക്ക് എന്തുചെയ്യാൻ കഴിയും എന്നതിനെക്കുറിച്ചുള്ള കൂടുതൽ വിവരങ്ങൾക്ക് [`FromUtf8Error`]-നായുള്ള ഡോക്സ് കാണുക.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// അസാധുവായ പ്രതീകങ്ങൾ ഉൾപ്പെടെ ഒരു സ്ലൈസ് ബൈറ്റുകളെ ഒരു സ്‌ട്രിംഗിലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// സ്ട്രിംഗുകൾ ([`u8`]) ബൈറ്റുകളാണ് നിർമ്മിച്ചിരിക്കുന്നത്, കൂടാതെ ([`&[u8]`][byteslice]) ബൈറ്റുകളുടെ ഒരു സ്ലൈസ് ബൈറ്റുകളാൽ നിർമ്മിച്ചതാണ്, അതിനാൽ ഈ പ്രവർത്തനം രണ്ടും തമ്മിൽ പരിവർത്തനം ചെയ്യുന്നു.എല്ലാ ബൈറ്റ് സ്ലൈസുകളും സാധുവായ സ്ട്രിംഗുകളല്ല, എന്നിരുന്നാലും: സ്ട്രിംഗുകൾ സാധുവായ UTF-8 ആയിരിക്കണം.
    /// ഈ പരിവർത്തന സമയത്ത്, `from_utf8_lossy()` ഏതെങ്കിലും അസാധുവായ UTF-8 സീക്വൻസുകളെ [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD] ഉപയോഗിച്ച് മാറ്റിസ്ഥാപിക്കും, ഇത് ഇതുപോലെ കാണപ്പെടുന്നു:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// ബൈറ്റ് സ്ലൈസ് സാധുവായ UTF-8 ആണെന്ന് നിങ്ങൾക്ക് ഉറപ്പുണ്ടെങ്കിൽ, പരിവർത്തനത്തിന്റെ ഓവർഹെഡ് ചെലവഴിക്കാൻ നിങ്ങൾ ആഗ്രഹിക്കുന്നില്ലെങ്കിൽ, ഈ ഫംഗ്ഷന്റെ സുരക്ഷിതമല്ലാത്ത പതിപ്പ് ഉണ്ട്, [`from_utf8_unchecked`], സമാന സ്വഭാവമുള്ളതും എന്നാൽ പരിശോധനകൾ ഒഴിവാക്കുന്നതുമാണ്.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// ഈ പ്രവർത്തനം ഒരു [`Cow<'a, str>`] നൽകുന്നു.ഞങ്ങളുടെ ബൈറ്റ് സ്ലൈസ് അസാധുവായ UTF-8 ആണെങ്കിൽ, ഞങ്ങൾ പകരം പ്രതീകങ്ങൾ ചേർക്കേണ്ടതുണ്ട്, അത് സ്ട്രിംഗിന്റെ വലുപ്പം മാറ്റും, അതിനാൽ ഒരു `String` ആവശ്യമാണ്.
    /// ഇത് ഇതിനകം സാധുവായ UTF-8 ആണെങ്കിൽ, ഞങ്ങൾക്ക് ഒരു പുതിയ അലോക്കേഷൻ ആവശ്യമില്ല.
    /// രണ്ട് കേസുകളും കൈകാര്യം ചെയ്യാൻ ഈ റിട്ടേൺ തരം ഞങ്ങളെ അനുവദിക്കുന്നു.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// // ഒരു vector-ൽ ചില ബൈറ്റുകൾ
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// തെറ്റായ ബൈറ്റുകൾ:
    ///
    /// ```
    /// // ചില അസാധുവായ ബൈറ്റുകൾ
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// യുടിഎഫ്-16-എൻ‌കോഡുചെയ്‌ത vector `v` ഒരു `String` ലേക്ക് ഡീകോഡ് ചെയ്യുക, `v` ൽ ഏതെങ്കിലും അസാധുവായ ഡാറ്റ ഉണ്ടെങ്കിൽ [`Err`] നൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // ശേഖരണം വഴി ഇത് ചെയ്യുന്നില്ല: : <Result<_, _>> () പ്രകടന കാരണങ്ങളാൽ.
        // FIXME: #48994 അടയ്‌ക്കുമ്പോൾ പ്രവർത്തനം വീണ്ടും ലളിതമാക്കാൻ കഴിയും.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// അസാധുവായ ഡാറ്റയെ [the replacement character (`U+FFFD`)][U+FFFD] ഉപയോഗിച്ച് മാറ്റിസ്ഥാപിച്ച് ഒരു യുടിഎഫ്-16-എൻ‌കോഡുചെയ്‌ത സ്ലൈസ് `v` ഒരു `String` ലേക്ക് ഡീകോഡ് ചെയ്യുക.
    ///
    /// [`from_utf8_lossy`] ൽ നിന്ന് വ്യത്യസ്തമായി, `from_utf16_lossy` ഒരു `String` നൽകുന്നു, കാരണം UTF-16 മുതൽ UTF-8 വരെ പരിവർത്തനത്തിന് മെമ്മറി അലോക്കേഷൻ ആവശ്യമാണ്.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// ഒരു `String` അതിന്റെ അസംസ്കൃത ഘടകങ്ങളിലേക്ക് വിഘടിപ്പിക്കുന്നു.
    ///
    /// അസംസ്കൃത പോയിന്റർ അടിസ്ഥാന ഡാറ്റയിലേക്ക് നൽകുന്നു, സ്‌ട്രിംഗിന്റെ ദൈർഘ്യം (ബൈറ്റുകളിൽ), ഡാറ്റയുടെ അനുവദിച്ച ശേഷി (ബൈറ്റുകളിൽ).
    /// [`from_raw_parts`]-ലേക്കുള്ള ആർഗ്യുമെന്റുകളുടെ അതേ ക്രമത്തിലെ അതേ ആർഗ്യുമെന്റുകളാണ് ഇവ.
    ///
    /// ഈ ഫംഗ്ഷനെ വിളിച്ചതിന് ശേഷം, മുമ്പ് `String` നിയന്ത്രിച്ച മെമ്മറിയുടെ കോളർ ഉത്തരവാദിയാണ്.
    /// അസംസ്കൃത പോയിന്റർ, നീളം, ശേഷി എന്നിവ [`from_raw_parts`] ഫംഗ്ഷനോടുകൂടിയ ഒരു `String`-ലേക്ക് പരിവർത്തനം ചെയ്യുക എന്നതാണ് ഇതിനുള്ള ഏക മാർഗം, ഇത് വൃത്തിയാക്കൽ നടത്താൻ ഡിസ്ട്രക്റ്ററെ അനുവദിക്കുന്നു.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// നീളം, ശേഷി, പോയിന്റർ എന്നിവയിൽ നിന്ന് ഒരു പുതിയ `String` സൃഷ്ടിക്കുന്നു.
    ///
    /// # Safety
    ///
    /// പരിശോധിക്കാത്ത മാറ്റങ്ങളുടെ എണ്ണം കാരണം ഇത് വളരെ സുരക്ഷിതമല്ല:
    ///
    /// * സ്റ്റാൻഡേർഡ് ലൈബ്രറി ഉപയോഗിക്കുന്ന അതേ അലോക്കേറ്റർ `buf`-ലെ മെമ്മറി മുമ്പ് അനുവദിക്കേണ്ടതുണ്ട്, കൃത്യമായി 1 വിന്യാസം ആവശ്യമാണ്.
    /// * `length` `capacity`-ൽ കുറവോ തുല്യമോ ആയിരിക്കണം.
    /// * `capacity` ശരിയായ മൂല്യം ആവശ്യമാണ്.
    /// * `buf`-ലെ ആദ്യത്തെ `length` ബൈറ്റുകൾ സാധുവായ UTF-8 ആയിരിക്കണം.
    ///
    /// ഇവ ലംഘിക്കുന്നത് അലോക്കേറ്ററിന്റെ ആന്തരിക ഡാറ്റാ ഘടനകളെ ദുഷിപ്പിക്കുന്നത് പോലുള്ള പ്രശ്നങ്ങൾക്ക് കാരണമായേക്കാം.
    ///
    /// `buf`-ന്റെ ഉടമസ്ഥാവകാശം `String`-ലേക്ക് ഫലപ്രദമായി കൈമാറ്റം ചെയ്യപ്പെടുന്നു, അത് പിന്നീട് പോയിന്റർ ചൂണ്ടിക്കാണിച്ച മെമ്മറിയിലെ ഉള്ളടക്കങ്ങൾ ഡീലോക്കേറ്റ് ചെയ്യാനോ വീണ്ടും അനുവദിക്കാനോ മാറ്റാനോ കഴിയും.
    /// ഈ ഫംഗ്ഷനെ വിളിച്ചതിന് ശേഷം മറ്റൊന്നും പോയിന്റർ ഉപയോഗിക്കുന്നില്ലെന്ന് ഉറപ്പാക്കുക.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME vec_into_raw_parts സ്ഥിരത കൈവരിക്കുമ്പോൾ ഇത് അപ്‌ഡേറ്റുചെയ്യുക.
    ///     // സ്‌ട്രിംഗിന്റെ ഡാറ്റ യാന്ത്രികമായി ഉപേക്ഷിക്കുന്നത് തടയുക
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// സ്‌ട്രിംഗിൽ സാധുവായ UTF-8 ഉണ്ടെന്ന് പരിശോധിക്കാതെ ഒരു vector ബൈറ്റുകളെ `String` ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// കൂടുതൽ വിവരങ്ങൾക്ക് [`from_utf8`] എന്ന സുരക്ഷിത പതിപ്പ് കാണുക.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// ഈ ഫംഗ്ഷൻ സുരക്ഷിതമല്ല, കാരണം അതിലേക്ക് കൈമാറിയ ബൈറ്റുകൾ സാധുവായ UTF-8 ആണെന്ന് പരിശോധിക്കുന്നില്ല.
    /// ഈ നിയന്ത്രണം ലംഘിക്കപ്പെടുകയാണെങ്കിൽ, ഇത് `String`-ന്റെ future ഉപയോക്താക്കളുമായി മെമ്മറി സുരക്ഷിതമല്ലാത്ത പ്രശ്‌നങ്ങൾക്ക് കാരണമായേക്കാം, കാരണം സ്റ്റാൻഡേർഡ് ലൈബ്രറിയുടെ ബാക്കി ഭാഗങ്ങൾ `സ്ട്രിംഗ് 'സാധുവായ UTF-8 ആണെന്ന് അനുമാനിക്കുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// // ഒരു vector-ൽ ചില ബൈറ്റുകൾ
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// ഒരു `String` ഒരു ബൈറ്റായി vector ആയി പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// ഇത് `String` ഉപയോഗിക്കുന്നു, അതിനാൽ ഞങ്ങൾ അതിന്റെ ഉള്ളടക്കങ്ങൾ പകർത്തേണ്ടതില്ല.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// മുഴുവൻ `String` അടങ്ങിയ ഒരു സ്ട്രിംഗ് സ്ലൈസ് എക്‌സ്‌ട്രാക്റ്റുചെയ്യുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// ഒരു `String` നെ മ്യൂട്ടബിൾ സ്ട്രിംഗ് സ്ലൈസായി പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// ഈ `String`-ന്റെ അവസാനത്തിൽ നൽകിയ സ്‌ട്രിംഗ് സ്ലൈസ് കൂട്ടിച്ചേർക്കുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// ഈ സ്ട്രിംഗിന്റെ ശേഷി ബൈറ്റുകളായി നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// ഈ `സ്ട്രിംഗിന്റെ 'ശേഷി അതിന്റെ നീളത്തേക്കാൾ കുറഞ്ഞത് `additional` ബൈറ്റുകളാണെന്ന് ഉറപ്പാക്കുന്നു.
    ///
    /// ഇടയ്ക്കിടെ വീണ്ടും അനുവദിക്കുന്നത് തടയുന്നതിന് ശേഷി തിരഞ്ഞെടുക്കുകയാണെങ്കിൽ `additional` ബൈറ്റുകളിൽ കൂടുതൽ വർദ്ധിപ്പിക്കാം.
    ///
    ///
    /// നിങ്ങൾക്ക് ഈ "at least" സ്വഭാവം ആവശ്യമില്ലെങ്കിൽ, [`reserve_exact`] രീതി കാണുക.
    ///
    /// # Panics
    ///
    /// പുതിയ ശേഷി [`usize`] കവിഞ്ഞൊഴുകുകയാണെങ്കിൽ Panics.
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// ഇത് യഥാർത്ഥത്തിൽ ശേഷി വർദ്ധിപ്പിച്ചേക്കില്ല:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s ന് ഇപ്പോൾ 2 നീളവും 10 ശേഷിയുമുണ്ട്
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // ഞങ്ങൾക്ക് ഇതിനകം 8 അധിക ശേഷി ഉള്ളതിനാൽ ഇതിനെ വിളിക്കുന്നു ...
    /// s.reserve(8);
    ///
    /// // ... യഥാർത്ഥത്തിൽ വർദ്ധിക്കുന്നില്ല.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// ഈ സ്ട്രിംഗിന്റെ ശേഷി `additional` ബൈറ്റുകളുടെ നീളത്തേക്കാൾ വലുതാണെന്ന് ഉറപ്പാക്കുന്നു.
    ///
    /// അലോക്കേറ്ററിനേക്കാൾ നന്നായി നിങ്ങൾക്ക് അറിയില്ലെങ്കിൽ [`reserve`] രീതി ഉപയോഗിക്കുന്നത് പരിഗണിക്കുക.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// പുതിയ ശേഷി `usize` കവിഞ്ഞൊഴുകുകയാണെങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// ഇത് യഥാർത്ഥത്തിൽ ശേഷി വർദ്ധിപ്പിച്ചേക്കില്ല:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s ന് ഇപ്പോൾ 2 നീളവും 10 ശേഷിയുമുണ്ട്
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // ഞങ്ങൾക്ക് ഇതിനകം 8 അധിക ശേഷി ഉള്ളതിനാൽ ഇതിനെ വിളിക്കുന്നു ...
    /// s.reserve_exact(8);
    ///
    /// // ... യഥാർത്ഥത്തിൽ വർദ്ധിക്കുന്നില്ല.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// തന്നിരിക്കുന്ന `String`-ൽ ഉൾപ്പെടുത്തുന്നതിന് കുറഞ്ഞത് `additional` കൂടുതൽ ഘടകങ്ങൾക്കെങ്കിലും ശേഷി റിസർവ് ചെയ്യാൻ ശ്രമിക്കുന്നു.
    /// ഇടയ്ക്കിടെ വീണ്ടും അനുവദിക്കുന്നത് ഒഴിവാക്കാൻ ശേഖരം കൂടുതൽ ഇടം കരുതിവച്ചേക്കാം.
    /// `reserve` എന്ന് വിളിച്ചതിന് ശേഷം, ശേഷി `self.len() + additional` നേക്കാൾ വലുതോ തുല്യമോ ആയിരിക്കും.
    /// ശേഷി ഇതിനകം പര്യാപ്തമാണെങ്കിൽ ഒന്നും ചെയ്യുന്നില്ല.
    ///
    /// # Errors
    ///
    /// ശേഷി കവിഞ്ഞൊഴുകുകയോ അല്ലെങ്കിൽ അലോക്കേറ്റർ ഒരു പരാജയം റിപ്പോർട്ട് ചെയ്യുകയോ ചെയ്താൽ, ഒരു പിശക് മടക്കിനൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // മെമ്മറി മുൻകൂട്ടി റിസർവ് ചെയ്യുക, ഞങ്ങൾക്ക് കഴിയുന്നില്ലെങ്കിൽ പുറത്തുകടക്കുന്നു
    ///     output.try_reserve(data.len())?;
    ///
    ///     // ഞങ്ങളുടെ സങ്കീർണ്ണമായ ജോലിയുടെ മധ്യത്തിൽ ഇത് OOM ചെയ്യാൻ കഴിയില്ലെന്ന് ഇപ്പോൾ നമുക്കറിയാം
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// തന്നിരിക്കുന്ന `String`-ൽ കൃത്യമായി `additional` കൂടുതൽ ഘടകങ്ങൾ ചേർക്കുന്നതിനുള്ള ഏറ്റവും കുറഞ്ഞ ശേഷി റിസർവ് ചെയ്യാൻ ശ്രമിക്കുന്നു.
    ///
    /// `reserve_exact` എന്ന് വിളിച്ചതിന് ശേഷം, ശേഷി `self.len() + additional` നേക്കാൾ വലുതോ തുല്യമോ ആയിരിക്കും.
    /// ശേഷി ഇതിനകം പര്യാപ്തമാണെങ്കിൽ ഒന്നും ചെയ്യുന്നില്ല.
    ///
    /// അലോക്കേറ്റർ ശേഖരണത്തിന് ആവശ്യപ്പെടുന്നതിനേക്കാൾ കൂടുതൽ ഇടം നൽകുമെന്നത് ശ്രദ്ധിക്കുക.
    /// അതിനാൽ, ശേഷി കൃത്യമായി ചുരുങ്ങിയതായി ആശ്രയിക്കാനാവില്ല.
    /// future ഉൾപ്പെടുത്തലുകൾ പ്രതീക്ഷിക്കുന്നുണ്ടെങ്കിൽ `reserve` തിരഞ്ഞെടുക്കുക.
    ///
    /// # Errors
    ///
    /// ശേഷി കവിഞ്ഞൊഴുകുകയോ അല്ലെങ്കിൽ അലോക്കേറ്റർ ഒരു പരാജയം റിപ്പോർട്ട് ചെയ്യുകയോ ചെയ്താൽ, ഒരു പിശക് മടക്കിനൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // മെമ്മറി മുൻകൂട്ടി റിസർവ് ചെയ്യുക, ഞങ്ങൾക്ക് കഴിയുന്നില്ലെങ്കിൽ പുറത്തുകടക്കുന്നു
    ///     output.try_reserve(data.len())?;
    ///
    ///     // ഞങ്ങളുടെ സങ്കീർണ്ണമായ ജോലിയുടെ മധ്യത്തിൽ ഇത് OOM ചെയ്യാൻ കഴിയില്ലെന്ന് ഇപ്പോൾ നമുക്കറിയാം
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// ഈ `String`-ന്റെ ദൈർഘ്യവുമായി പൊരുത്തപ്പെടാനുള്ള ശേഷി ചുരുക്കുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// ഈ `String` ന്റെ ശേഷി കുറഞ്ഞ പരിധിയോടെ ചുരുക്കുന്നു.
    ///
    /// ശേഷി നീളവും നൽകിയ മൂല്യവും പോലെ വലുതായി തുടരും.
    ///
    ///
    /// നിലവിലെ ശേഷി താഴ്ന്ന പരിധിയേക്കാൾ കുറവാണെങ്കിൽ, ഇത് ഒരു നോ-ഒപ്പ് ആണ്.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// തന്നിരിക്കുന്ന [`char`] ഈ `String` ന്റെ അവസാനം കൂട്ടിച്ചേർക്കുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// ഈ `സ്ട്രിംഗിന്റെ 'ഉള്ളടക്കങ്ങളുടെ ഒരു ബൈറ്റ് സ്ലൈസ് നൽകുന്നു.
    ///
    /// ഈ രീതിയുടെ വിപരീതം [`from_utf8`] ആണ്.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// നിർദ്ദിഷ്ട നീളത്തിലേക്ക് ഈ `String` ചെറുതാക്കുന്നു.
    ///
    /// സ്‌ട്രിംഗിന്റെ നിലവിലെ നീളത്തേക്കാൾ `new_len` വലുതാണെങ്കിൽ, ഇത് ഒരു ഫലവുമില്ല.
    ///
    ///
    /// ഈ രീതി സ്ട്രിംഗിന്റെ അനുവദിച്ച ശേഷിയെ ബാധിക്കില്ലെന്നത് ശ്രദ്ധിക്കുക
    ///
    /// # Panics
    ///
    /// `new_len` ഒരു [`char`] അതിർത്തിയിൽ കിടക്കുന്നില്ലെങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// സ്‌ട്രിംഗ് ബഫറിൽ നിന്ന് അവസാന പ്രതീകം നീക്കംചെയ്‌ത് അത് നൽകുന്നു.
    ///
    /// ഈ `String` ശൂന്യമാണെങ്കിൽ [`None`] നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// ഈ `String`-ൽ നിന്ന് ഒരു ബൈറ്റ് സ്ഥാനത്ത് ഒരു [`char`] നീക്കംചെയ്യുകയും അത് തിരികെ നൽകുകയും ചെയ്യുന്നു.
    ///
    /// ഇത് ഒരു *O*(*n*) പ്രവർത്തനമാണ്, കാരണം ഇതിന് ബഫറിലെ എല്ലാ ഘടകങ്ങളും പകർത്തേണ്ടതുണ്ട്.
    ///
    /// # Panics
    ///
    /// `idx` `സ്ട്രിംഗിന്റെ 'നീളത്തേക്കാൾ വലുതോ തുല്യമോ ആണെങ്കിൽ അല്ലെങ്കിൽ അത് [`char`] അതിർത്തിയിൽ കിടക്കുന്നില്ലെങ്കിൽ Panics.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// `String`-ലെ പാറ്റേൺ `pat`-ന്റെ എല്ലാ പൊരുത്തങ്ങളും നീക്കംചെയ്യുക.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// പൊരുത്തങ്ങൾ കണ്ടെത്തുകയും ആവർത്തനമായി നീക്കംചെയ്യുകയും ചെയ്യും, അതിനാൽ പാറ്റേണുകൾ ഓവർലാപ്പ് ചെയ്യുന്ന സന്ദർഭങ്ങളിൽ, ആദ്യത്തെ പാറ്റേൺ മാത്രമേ നീക്കംചെയ്യൂ:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // സുരക്ഷ: ആരംഭവും അവസാനവും ഓരോ utf8 ബൈറ്റ് അതിരുകളിലായിരിക്കും
        // തിരയൽ പ്രമാണം
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// പ്രവചിക്കുക വ്യക്തമാക്കിയ പ്രതീകങ്ങൾ മാത്രം നിലനിർത്തുന്നു.
    ///
    /// മറ്റൊരു വിധത്തിൽ പറഞ്ഞാൽ, `f(c)` എല്ലാ പ്രതീകങ്ങളും നീക്കംചെയ്യുക, അതായത് `f(c)` `false` നൽകുന്നു.
    /// ഈ രീതി സ്ഥലത്ത് പ്രവർത്തിക്കുന്നു, ഓരോ പ്രതീകവും യഥാർത്ഥ ക്രമത്തിൽ കൃത്യമായി ഒരിക്കൽ സന്ദർശിക്കുകയും നിലനിർത്തുന്ന പ്രതീകങ്ങളുടെ ക്രമം സംരക്ഷിക്കുകയും ചെയ്യുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// ഒരു സൂചിക പോലെ ബാഹ്യ അവസ്ഥ ട്രാക്കുചെയ്യുന്നതിന് കൃത്യമായ ക്രമം ഉപയോഗപ്രദമാകും.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // അടുത്ത ചാറിലേക്ക് ഐഡിഎക്സ് പോയിന്റ് ചെയ്യുക
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// ഒരു ബൈറ്റ് സ്ഥാനത്ത് ഈ `String`-ലേക്ക് ഒരു പ്രതീകം ചേർക്കുന്നു.
    ///
    /// ബഫറിലെ എല്ലാ ഘടകങ്ങളും പകർത്തേണ്ടതിനാൽ ഇത് ഒരു *O*(*n*) പ്രവർത്തനമാണ്.
    ///
    /// # Panics
    ///
    /// `idx` `സ്ട്രിംഗിന്റെ 'നീളത്തേക്കാൾ വലുതാണെങ്കിൽ അല്ലെങ്കിൽ [`char`] അതിർത്തിയിൽ കിടക്കുന്നില്ലെങ്കിൽ Panics.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// ഒരു ബൈറ്റ് സ്ഥാനത്ത് ഈ `String`-ലേക്ക് ഒരു സ്ട്രിംഗ് സ്ലൈസ് ചേർക്കുന്നു.
    ///
    /// ബഫറിലെ എല്ലാ ഘടകങ്ങളും പകർത്തേണ്ടതിനാൽ ഇത് ഒരു *O*(*n*) പ്രവർത്തനമാണ്.
    ///
    /// # Panics
    ///
    /// `idx` `സ്ട്രിംഗിന്റെ 'നീളത്തേക്കാൾ വലുതാണെങ്കിൽ അല്ലെങ്കിൽ [`char`] അതിർത്തിയിൽ കിടക്കുന്നില്ലെങ്കിൽ Panics.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// ഈ `String`-ന്റെ ഉള്ളടക്കങ്ങളിലേക്ക് ഒരു മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു.
    ///
    /// # Safety
    ///
    /// ഈ ഫംഗ്ഷൻ സുരക്ഷിതമല്ല, കാരണം അതിലേക്ക് കൈമാറിയ ബൈറ്റുകൾ സാധുവായ UTF-8 ആണെന്ന് പരിശോധിക്കുന്നില്ല.
    /// ഈ നിയന്ത്രണം ലംഘിക്കപ്പെടുകയാണെങ്കിൽ, ഇത് `String`-ന്റെ future ഉപയോക്താക്കളുമായി മെമ്മറി സുരക്ഷിതമല്ലാത്ത പ്രശ്‌നങ്ങൾക്ക് കാരണമായേക്കാം, കാരണം സ്റ്റാൻഡേർഡ് ലൈബ്രറിയുടെ ബാക്കി ഭാഗങ്ങൾ `സ്ട്രിംഗ് 'സാധുവായ UTF-8 ആണെന്ന് അനുമാനിക്കുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// ഈ `String`-ന്റെ ദൈർഘ്യം ബൈറ്റുകളായി നൽകുന്നു, [`ചാർ`] അല്ലെങ്കിൽ ഗ്രാഫിമുകളല്ല.
    /// മറ്റൊരു വിധത്തിൽ പറഞ്ഞാൽ, ഒരു മനുഷ്യൻ സ്ട്രിംഗിന്റെ നീളം പരിഗണിക്കുന്നതായിരിക്കില്ല.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// ഈ `String` ന് പൂജ്യത്തിന്റെ നീളം ഉണ്ടെങ്കിൽ `true` നൽകുന്നു, അല്ലെങ്കിൽ `false`.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// തന്നിരിക്കുന്ന ബൈറ്റ് സൂചികയിൽ സ്ട്രിംഗ് രണ്ടായി വിഭജിക്കുന്നു.
    ///
    /// പുതുതായി അനുവദിച്ച `String` നൽകുന്നു.
    /// `self` `[0, at)` ബൈറ്റുകൾ അടങ്ങിയിരിക്കുന്നു, മടങ്ങിയ `String`-ൽ `[at, len)` ബൈറ്റുകൾ അടങ്ങിയിരിക്കുന്നു.
    /// `at` ഒരു UTF-8 കോഡ് പോയിന്റിന്റെ അതിർത്തിയിലായിരിക്കണം.
    ///
    /// `self` ന്റെ ശേഷി മാറില്ലെന്നത് ശ്രദ്ധിക്കുക.
    ///
    /// # Panics
    ///
    /// `at` ഒരു `UTF-8` കോഡ് പോയിന്റ് അതിർത്തിയിലല്ലെങ്കിലോ സ്ട്രിംഗിന്റെ അവസാന കോഡ് പോയിന്റിനപ്പുറത്താണെങ്കിലോ Panics.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// എല്ലാ ഉള്ളടക്കങ്ങളും നീക്കംചെയ്ത് ഈ `String` വെട്ടിച്ചുരുക്കുന്നു.
    ///
    /// ഇതിനർത്ഥം `String` ന് പൂജ്യത്തിന്റെ നീളം ഉണ്ടായിരിക്കുമെങ്കിലും, അതിന്റെ ശേഷിയെ സ്പർശിക്കുന്നില്ല.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// `String`-ൽ നിർദ്ദിഷ്ട ശ്രേണി നീക്കംചെയ്യുകയും നീക്കംചെയ്‌ത `chars` ലഭ്യമാക്കുകയും ചെയ്യുന്ന ഒരു ഡ്രെയിനിംഗ് ഇറ്ററേറ്റർ സൃഷ്‌ടിക്കുന്നു.
    ///
    ///
    /// Note: അവസാനം വരെ ഇറ്ററേറ്റർ ഉപയോഗിക്കുന്നില്ലെങ്കിലും ഘടക ശ്രേണി നീക്കംചെയ്യപ്പെടും.
    ///
    /// # Panics
    ///
    /// ആരംഭ പോയിന്റോ അവസാന പോയിന്റോ ഒരു [`char`] അതിർത്തിയിൽ കിടക്കുന്നില്ലെങ്കിലോ അവ പരിധിക്ക് പുറത്താണെങ്കിൽ Panics.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // സ്‌ട്രിംഗിൽ നിന്ന് until വരെ ശ്രേണി നീക്കംചെയ്യുക
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // ഒരു പൂർണ്ണ ശ്രേണി സ്‌ട്രിംഗ് മായ്‌ക്കുന്നു
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // മെമ്മറി സുരക്ഷ
        //
        // Drain-ന്റെ സ്‌ട്രിംഗ് പതിപ്പിന് vector പതിപ്പിന്റെ മെമ്മറി സുരക്ഷാ പ്രശ്‌നങ്ങളില്ല.
        // ഡാറ്റ പ്ലെയിൻ ബൈറ്റുകൾ മാത്രമാണ്.
        // ഡ്രോപ്പ് പരിധി നീക്കം ചെയ്യുന്നതിനാൽ, Drain ഇറ്ററേറ്റർ ചോർന്നാൽ, നീക്കംചെയ്യൽ നടക്കില്ല.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // ഒരേസമയം രണ്ട് വായ്പകൾ എടുക്കുക.
        // ഡ്രോപ്പിൽ ആവർത്തനം അവസാനിക്കുന്നതുവരെ &mut സ്ട്രിംഗ് ആക്സസ് ചെയ്യില്ല.
        let self_ptr = self as *mut _;
        // സുരക്ഷ: `slice::range`, `is_char_boundary` എന്നിവ ഉചിതമായ അതിർത്തി പരിശോധനകൾ നടത്തുന്നു.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// സ്‌ട്രിംഗിലെ നിർദ്ദിഷ്‌ട ശ്രേണി നീക്കംചെയ്യുകയും തന്നിരിക്കുന്ന സ്‌ട്രിംഗ് ഉപയോഗിച്ച് അത് മാറ്റിസ്ഥാപിക്കുകയും ചെയ്യുന്നു.
    /// തന്നിരിക്കുന്ന സ്‌ട്രിംഗിന് ശ്രേണിയുടെ അതേ നീളം ആവശ്യമില്ല.
    ///
    /// # Panics
    ///
    /// ആരംഭ പോയിന്റോ അവസാന പോയിന്റോ ഒരു [`char`] അതിർത്തിയിൽ കിടക്കുന്നില്ലെങ്കിലോ അവ പരിധിക്ക് പുറത്താണെങ്കിൽ Panics.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // സ്‌ട്രിംഗിൽ നിന്ന് until വരെ ശ്രേണി മാറ്റിസ്ഥാപിക്കുക
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // മെമ്മറി സുരക്ഷ
        //
        // Replace_range-ന് vector സ്‌പ്ലൈസിന്റെ മെമ്മറി സുരക്ഷാ പ്രശ്‌നങ്ങളില്ല.
        // vector പതിപ്പിന്റെ.ഡാറ്റ പ്ലെയിൻ ബൈറ്റുകൾ മാത്രമാണ്.

        // മുന്നറിയിപ്പ്: ഈ വേരിയബിളിനെ ഇൻ‌ലൈൻ ചെയ്യുന്നത് സുരക്ഷിതമല്ലാത്ത (#81138) ആയിരിക്കും
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // മുന്നറിയിപ്പ്: ഈ വേരിയബിളിനെ ഇൻ‌ലൈൻ ചെയ്യുന്നത് സുരക്ഷിതമല്ലാത്ത (#81138) ആയിരിക്കും
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // `range` വീണ്ടും ഉപയോഗിക്കുന്നത് സുരക്ഷിതമല്ലാത്ത (#81138) ആയിരിക്കും `range` റിപ്പോർട്ടുചെയ്ത അതിരുകൾ അതേപടി നിലനിൽക്കുമെന്ന് ഞങ്ങൾ അനുമാനിക്കുന്നു, പക്ഷേ കോളുകൾക്കിടയിൽ ഒരു പ്രതികൂല നടപ്പാക്കൽ മാറാം
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// ഈ `String` ഒരു [`ബോക്സ്`]`<`[`സ്ട്ര`] `>` ആയി പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// ഇത് അധിക ശേഷി കുറയ്ക്കും.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// ഒരു `String` ലേക്ക് പരിവർത്തനം ചെയ്യാൻ ശ്രമിച്ച [`u8`] ബൈറ്റുകളുടെ ഒരു സ്ലൈസ് നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// // ഒരു vector-ൽ ചില അസാധുവായ ബൈറ്റുകൾ
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// ഒരു `String` ലേക്ക് പരിവർത്തനം ചെയ്യാൻ ശ്രമിച്ച ബൈറ്റുകൾ നൽകുന്നു.
    ///
    /// വിഹിതം ഒഴിവാക്കാൻ ഈ രീതി ശ്രദ്ധാപൂർവ്വം നിർമ്മിച്ചിരിക്കുന്നു.
    /// ഇത് പിശകുകൾ ഉപയോഗിക്കും, ബൈറ്റുകൾ പുറത്തേക്ക് നീക്കുന്നു, അതിനാൽ ബൈറ്റുകളുടെ ഒരു പകർപ്പ് നിർമ്മിക്കേണ്ടതില്ല.
    ///
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// // ഒരു vector-ൽ ചില അസാധുവായ ബൈറ്റുകൾ
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// പരിവർത്തന പരാജയത്തെക്കുറിച്ച് കൂടുതൽ വിശദാംശങ്ങൾക്ക് ഒരു `Utf8Error` നേടുക.
    ///
    /// [`std::str`] നൽകിയ [`Utf8Error`] തരം [`u8`] ന്റെ ഒരു സ്ലൈസ് [`&str`] ലേക്ക് പരിവർത്തനം ചെയ്യുമ്പോൾ ഉണ്ടാകാവുന്ന ഒരു പിശകിനെ പ്രതിനിധീകരിക്കുന്നു.
    /// ഈ അർത്ഥത്തിൽ, ഇത് `FromUtf8Error`-ലേക്കുള്ള ഒരു അനലോഗ് ആണ്.
    /// ഇത് ഉപയോഗിക്കുന്നതിനെക്കുറിച്ചുള്ള കൂടുതൽ വിവരങ്ങൾക്ക് അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// // ഒരു vector-ൽ ചില അസാധുവായ ബൈറ്റുകൾ
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // ആദ്യ ബൈറ്റ് ഇവിടെ അസാധുവാണ്
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // `സ്‌ട്രിംഗിനെ 'മറികടക്കുന്നതിനാൽ, ഇറ്ററേറ്ററിൽ നിന്ന് ആദ്യ സ്‌ട്രിംഗ് നേടുകയും തുടർന്നുള്ള എല്ലാ സ്‌ട്രിംഗുകളും അതിൽ ചേർക്കുകയും ചെയ്യുന്നതിലൂടെ കുറഞ്ഞത് ഒരു അലോക്കേഷനെങ്കിലും ഒഴിവാക്കാനാകും.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // ഞങ്ങൾ CoW-കളിലൂടെ ആവർത്തിക്കുന്നതിനാൽ, ആദ്യ ഇനം നേടുകയും തുടർന്നുള്ള എല്ലാ ഇനങ്ങളും കൂട്ടിച്ചേർക്കുകയും ചെയ്യുന്നതിലൂടെ നമുക്ക് (potentially) ന് കുറഞ്ഞത് ഒരു അലോക്കേഷൻ ഒഴിവാക്കാനാകും.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// `&str`-നായുള്ള impl-ലേക്ക് പ്രതിനിധീകരിക്കുന്ന ഒരു സ imp കര്യപ്രദമായ impl.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// ഒരു ശൂന്യമായ `String` സൃഷ്ടിക്കുന്നു.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// രണ്ട് സ്ട്രിംഗുകൾ സംയോജിപ്പിക്കുന്നതിനായി `+` ഓപ്പറേറ്റർ നടപ്പിലാക്കുന്നു.
///
/// ഇത് ഇടത് വശത്ത് `String` ഉപയോഗിക്കുകയും അതിന്റെ ബഫർ വീണ്ടും ഉപയോഗിക്കുകയും ചെയ്യുന്നു (ആവശ്യമെങ്കിൽ അത് വളർത്തുന്നു).
/// ഒരു പുതിയ `String` അനുവദിക്കുന്നതും എല്ലാ പ്രവർത്തനങ്ങളിലും മുഴുവൻ ഉള്ളടക്കങ്ങളും പകർത്തുന്നതും ഒഴിവാക്കുന്നതിനാണ് ഇത് ചെയ്യുന്നത്, ഇത് *O*(*n*^ 2) പ്രവർത്തിപ്പിക്കുന്ന സമയത്തിലേക്ക് നയിക്കും, ഇത് ആവർത്തിച്ച് സംയോജിപ്പിച്ച് *n*-ബൈറ്റ് സ്ട്രിംഗ് നിർമ്മിക്കുമ്പോൾ.
///
///
/// വലതുവശത്തുള്ള സ്ട്രിംഗ് കടമെടുത്തത് മാത്രമാണ്;അതിന്റെ ഉള്ളടക്കങ്ങൾ മടങ്ങിയ `String`-ലേക്ക് പകർത്തുന്നു.
///
/// # Examples
///
/// രണ്ട് `സ്ട്രിംഗുകൾ 'സംയോജിപ്പിക്കുന്നത് ആദ്യത്തേത് മൂല്യമനുസരിച്ച് എടുക്കുകയും രണ്ടാമത്തേത് കടമെടുക്കുകയും ചെയ്യുന്നു:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` നീക്കി, ഇനി ഇവിടെ ഉപയോഗിക്കാൻ കഴിയില്ല.
/// ```
///
/// നിങ്ങൾക്ക് ആദ്യത്തെ `String` ഉപയോഗിക്കുന്നത് തുടരണമെങ്കിൽ, നിങ്ങൾക്ക് അത് ക്ലോൺ ചെയ്യാനും പകരം ക്ലോണിലേക്ക് ചേർക്കാനും കഴിയും:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` ഇപ്പോഴും ഇവിടെ സാധുവാണ്.
/// ```
///
/// ആദ്യത്തേത് `String` ലേക്ക് പരിവർത്തനം ചെയ്തുകൊണ്ട് `&str` സ്ലൈസുകൾ സംയോജിപ്പിക്കാം:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// ഒരു `String`-ലേക്ക് കൂട്ടിച്ചേർക്കുന്നതിനായി `+=` ഓപ്പറേറ്റർ നടപ്പിലാക്കുന്നു.
///
/// ഇതിന് [`push_str`][String::push_str] രീതിയുടെ അതേ സ്വഭാവമുണ്ട്.
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// [`Infallible`]-നുള്ള ഒരു തരം അപരനാമം.
///
/// ഈ അപരനാമം പിന്നോക്ക അനുയോജ്യതയ്ക്കായി നിലവിലുണ്ട്, ഇത് ഒടുവിൽ ഒഴിവാക്കിയേക്കാം.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// ഒരു മൂല്യം `String` ലേക്ക് പരിവർത്തനം ചെയ്യുന്നതിനുള്ള trait.
///
/// [`Display`] trait നടപ്പിലാക്കുന്ന ഏത് തരത്തിനും ഈ trait യാന്ത്രികമായി നടപ്പിലാക്കുന്നു.
/// അതുപോലെ, `ToString` നേരിട്ട് നടപ്പിലാക്കാൻ പാടില്ല:
/// [`Display`] പകരം നടപ്പിലാക്കണം, കൂടാതെ നിങ്ങൾക്ക് `ToString` നടപ്പിലാക്കൽ സ get ജന്യമായി ലഭിക്കും.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// നൽകിയ മൂല്യം ഒരു `String` ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// ഈ നടപ്പിലാക്കലിൽ, `Display` നടപ്പിലാക്കൽ ഒരു പിശക് നൽകിയാൽ `to_string` രീതി panics.
/// `fmt::Write for String` ഒരിക്കലും ഒരു പിശക് നൽകാത്തതിനാൽ ഇത് തെറ്റായ `Display` നടപ്പിലാക്കലിനെ സൂചിപ്പിക്കുന്നു.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // ജനറിക് ഫംഗ്ഷനുകൾ ഇൻലൈൻ ചെയ്യരുത് എന്നതാണ് ഒരു പൊതു മാർഗ്ഗനിർദ്ദേശം.
    // എന്നിരുന്നാലും, ഈ രീതിയിൽ നിന്ന് `#[inline]` നീക്കംചെയ്യുന്നത് നിസ്സാരമല്ലാത്ത റിഗ്രഷനുകൾക്ക് കാരണമാകുന്നു.
    // ഇത് നീക്കംചെയ്യാനുള്ള അവസാന ശ്രമമായ <https://github.com/rust-lang/rust/pull/74852> കാണുക.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// ഒരു `&mut str`-നെ `String`-ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// ഫലം കൂമ്പാരത്തിൽ അനുവദിച്ചിരിക്കുന്നു.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: ടെസ്റ്റ് libsd-ൽ വലിക്കുന്നു, ഇത് ഇവിടെ പിശകുകൾക്ക് കാരണമാകുന്നു
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// നൽകിയിരിക്കുന്ന ബോക്‌സുചെയ്‌ത `str` സ്ലൈസ് ഒരു `String`-ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    /// `str` സ്ലൈസ് സ്വന്തമാണെന്നത് ശ്രദ്ധേയമാണ്.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// തന്നിരിക്കുന്ന `String` ഉടമസ്ഥതയിലുള്ള ഒരു ബോക്‌സുചെയ്‌ത `str` സ്ലൈസിലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// ഒരു സ്ട്രിംഗ് സ്ലൈസ് കടമെടുത്ത വേരിയന്റിലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    /// ഹീപ്പ് അലോക്കേഷനൊന്നും നടത്തുന്നില്ല, കൂടാതെ സ്ട്രിംഗ് പകർത്തിയിട്ടില്ല.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// ഒരു സ്ട്രിംഗിനെ ഒരു ഉടമസ്ഥതയിലുള്ള വേരിയന്റായി പരിവർത്തനം ചെയ്യുന്നു.
    /// ഹീപ്പ് അലോക്കേഷനൊന്നും നടത്തുന്നില്ല, കൂടാതെ സ്ട്രിംഗ് പകർത്തിയിട്ടില്ല.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// ഒരു സ്ട്രിംഗ് റഫറൻസ് കടമെടുത്ത വേരിയന്റിലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    /// ഹീപ്പ് അലോക്കേഷനൊന്നും നടത്തുന്നില്ല, കൂടാതെ സ്ട്രിംഗ് പകർത്തിയിട്ടില്ല.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// തന്നിരിക്കുന്ന `String`-നെ `u8` തരം മൂല്യങ്ങൾ ഉൾക്കൊള്ളുന്ന vector `Vec` ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// `String`-നുള്ള ഒരു ഡ്രെയിനിംഗ് ഇറ്ററേറ്റർ.
///
/// [`String`]-ലെ [`drain`] രീതി ഉപയോഗിച്ചാണ് ഈ ഘടന സൃഷ്ടിച്ചിരിക്കുന്നത്.
/// കൂടുതൽ കാര്യങ്ങൾക്കായി അതിന്റെ ഡോക്യുമെന്റേഷൻ കാണുക.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// ഡിസ്ട്രക്റ്ററിലെ ഒരു മ്യൂട്ട് സ്ട്രിംഗായി&'ഉപയോഗിക്കും
    string: *mut String,
    /// നീക്കംചെയ്യാനുള്ള ഭാഗത്തിന്റെ ആരംഭം
    start: usize,
    /// നീക്കംചെയ്യാനുള്ള ഭാഗത്തിന്റെ അവസാനം
    end: usize,
    /// നീക്കംചെയ്യാൻ നിലവിലുള്ള ശേഷിക്കുന്ന ശ്രേണി
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Vec::drain ഉപയോഗിക്കുക.
            // "Reaffirm" panic കോഡ് വീണ്ടും ചേർക്കുന്നത് ഒഴിവാക്കാൻ അതിർത്തികൾ പരിശോധിക്കുന്നു.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// ഈ ഇറ്ററേറ്ററിന്റെ ശേഷിക്കുന്ന (ഉപ) സ്ട്രിംഗ് ഒരു സ്ലൈസായി നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: സ്ഥിരത സ്ഥിരത കൈവരിക്കുമ്പോൾ AsRef ചുവടെ ഉൾക്കൊള്ളുന്നു.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// `string_drain_as_str` സ്ഥിരപ്പെടുത്തുമ്പോൾ അസ്വസ്ഥത.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>Drain <'a> {fn as_ref(&self)-> &str for എന്നതിനായി
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// Drain <'a> for fn as_ref(&self)->&[u8] for എന്നതിനായി impl <' a> AsRef <[u8]>
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}