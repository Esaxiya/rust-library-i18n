#![stable(feature = "rust1", since = "1.0.0")]

//! ത്രെഡ്-സുരക്ഷിത റഫറൻസ്-എണ്ണൽ പോയിന്ററുകൾ.
//!
//! കൂടുതൽ വിവരങ്ങൾക്ക് [`Arc<T>`][Arc] ഡോക്യുമെന്റേഷൻ കാണുക.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// ഒരു `Arc`-ലേക്ക് ചെയ്യാവുന്ന റഫറൻസുകളുടെ അളവിലുള്ള ഒരു സോഫ്റ്റ് പരിധി.
///
/// ഈ പരിധിക്ക് മുകളിലേക്ക് പോകുന്നത് നിങ്ങളുടെ പ്രോഗ്രാം _exactly_ `MAX_REFCOUNT + 1` റഫറൻസുകളിൽ നിർത്തലാക്കും (ആവശ്യമില്ലെങ്കിലും).
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ത്രെഡ് സാനിറ്റൈസർ മെമ്മറി വേലികളെ പിന്തുണയ്ക്കുന്നില്ല.
// ആർക്ക്/ദുർബലമായ നടപ്പാക്കലിലെ തെറ്റായ പോസിറ്റീവ് റിപ്പോർട്ടുകൾ ഒഴിവാക്കുന്നതിന് പകരം സമന്വയത്തിനായി ആറ്റോമിക് ലോഡുകൾ ഉപയോഗിക്കുക.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// ഒരു ത്രെഡ്-സുരക്ഷിത റഫറൻസ്-കൗണ്ടിംഗ് പോയിന്റർ.'Arc' എന്നാൽ 'ആറ്റോമിക്കലി റഫറൻസ് കണക്കാക്കപ്പെടുന്നു'.
///
/// കൂമ്പാരത്തിൽ അനുവദിച്ചിരിക്കുന്ന `T` തരം മൂല്യത്തിന്റെ പങ്കിട്ട ഉടമസ്ഥാവകാശം `Arc<T>` തരം നൽകുന്നു.`Arc`-ൽ [`clone`][clone] അഭ്യർത്ഥിക്കുന്നത് ഒരു പുതിയ `Arc` ഉദാഹരണം ഉൽ‌പാദിപ്പിക്കുന്നു, ഇത് ഒരു റഫറൻസ് എണ്ണം വർദ്ധിപ്പിക്കുമ്പോൾ `Arc` ഉറവിടമായ കൂമ്പാരത്തിന്റെ അതേ വിഹിതത്തിലേക്ക് വിരൽ ചൂണ്ടുന്നു.
/// തന്നിരിക്കുന്ന അലോക്കേഷന്റെ അവസാന `Arc` പോയിന്റർ നശിപ്പിക്കുമ്പോൾ, ആ അലോക്കേഷനിൽ സംഭരിച്ചിരിക്കുന്ന മൂല്യവും (പലപ്പോഴും "inner value" എന്ന് വിളിക്കുന്നു) ഉപേക്ഷിക്കപ്പെടും.
///
/// Rust-ൽ പങ്കിട്ട റഫറൻസുകൾ സ്ഥിരസ്ഥിതിയായി മ്യൂട്ടേഷനെ അനുവദിക്കുന്നില്ല, കൂടാതെ `Arc` ഒരു അപവാദവുമല്ല: നിങ്ങൾക്ക് സാധാരണയായി ഒരു `Arc`-നുള്ളിലെ എന്തിനെക്കുറിച്ചും മ്യൂട്ടബിൾ റഫറൻസ് നേടാൻ കഴിയില്ല.നിങ്ങൾക്ക് ഒരു `Arc` വഴി പരിവർത്തനം ചെയ്യണമെങ്കിൽ, [`Mutex`][mutex], [`RwLock`][rwlock] അല്ലെങ്കിൽ [`Atomic`][atomic] തരങ്ങളിൽ ഒന്ന് ഉപയോഗിക്കുക.
///
/// ## ത്രെഡ് സുരക്ഷ
///
/// [`Rc<T>`] ൽ നിന്ന് വ്യത്യസ്തമായി, `Arc<T>` അതിന്റെ റഫറൻസ് എണ്ണുന്നതിന് ആറ്റോമിക് പ്രവർത്തനങ്ങൾ ഉപയോഗിക്കുന്നു.ഇത് ത്രെഡ്-സുരക്ഷിതമാണെന്ന് ഇതിനർത്ഥം.സാധാരണ മെമ്മറി ആക്‌സസ്സുകളേക്കാൾ വിലയേറിയതാണ് ആറ്റോമിക് പ്രവർത്തനങ്ങൾ എന്നതാണ് പോരായ്മ.നിങ്ങൾ ത്രെഡുകൾക്കിടയിൽ റഫറൻസ് കണക്കാക്കിയ അലോക്കേഷനുകൾ പങ്കിടുന്നില്ലെങ്കിൽ, ലോവർ ഓവർഹെഡിനായി [`Rc<T>`] ഉപയോഗിക്കുന്നത് പരിഗണിക്കുക.
/// [`Rc<T>`] ഒരു സുരക്ഷിത സ്ഥിരസ്ഥിതിയാണ്, കാരണം ത്രെഡുകൾക്കിടയിൽ ഒരു [`Rc<T>`] അയയ്ക്കുന്നതിനുള്ള ഏത് ശ്രമവും കംപൈലർ പിടിക്കും.
/// എന്നിരുന്നാലും, ലൈബ്രറി ഉപയോക്താക്കൾക്ക് കൂടുതൽ വഴക്കം നൽകുന്നതിന് ഒരു ലൈബ്രറി `Arc<T>` തിരഞ്ഞെടുക്കാം.
///
/// `Arc<T>` `T` [`Send`], [`Sync`] എന്നിവ നടപ്പിലാക്കുന്നിടത്തോളം കാലം [`Send`], [`Sync`] എന്നിവ നടപ്പിലാക്കും.
/// ത്രെഡ്-സുരക്ഷിതമാക്കാൻ എന്തുകൊണ്ടാണ് നിങ്ങൾക്ക് `Arc<T>`-ൽ നോൺ-ത്രെഡ്-സുരക്ഷിത തരം `T` ഇടാൻ കഴിയാത്തത്?ഇത് ആദ്യം അൽപ്പം അവബോധജന്യമായിരിക്കാം: എല്ലാത്തിനുമുപരി, `Arc<T>` ത്രെഡ് സുരക്ഷയുടെ പോയിന്റ് അല്ലേ?പ്രധാന കാര്യം ഇതാണ്: ഒരേ ഡാറ്റയുടെ ഒന്നിലധികം ഉടമസ്ഥാവകാശം `Arc<T>` ത്രെഡ് സുരക്ഷിതമാക്കുന്നു, പക്ഷേ ഇത് അതിന്റെ ഡാറ്റയിലേക്ക് ത്രെഡ് സുരക്ഷ ചേർക്കുന്നില്ല.
///
/// `ആർക്ക് <` [`റഫർ സെൽ 'പരിഗണിക്കുക<T>`]`>`.
/// [`RefCell<T>`] [`Sync`] അല്ല, `Arc<T>` എല്ലായ്പ്പോഴും [`Send`] ആണെങ്കിൽ, `ആർക്ക് <` [`റഫർ‌സെൽ<T>`]`>`അതുപോലെ തന്നെ.
/// എന്നാൽ ഞങ്ങൾക്ക് ഒരു പ്രശ്‌നമുണ്ടാകും:
/// [`RefCell<T>`] ത്രെഡ് സുരക്ഷിതമല്ല;നോൺ-ആറ്റോമിക് പ്രവർത്തനങ്ങൾ ഉപയോഗിച്ച് വായ്പയെടുക്കുന്നതിന്റെ എണ്ണം ഇത് സൂക്ഷിക്കുന്നു.
///
/// അവസാനം, ഇതിനർത്ഥം നിങ്ങൾ `Arc<T>` യെ ഏതെങ്കിലും തരത്തിലുള്ള [`std::sync`] തരം, സാധാരണയായി [`Mutex<T>`][mutex] ജോടിയാക്കേണ്ടതുണ്ട് എന്നാണ്.
///
/// ## `Weak` ഉപയോഗിച്ച് സൈക്കിളുകൾ തകർക്കുന്നു
///
/// സ്വന്തമല്ലാത്ത [`Weak`] പോയിന്റർ സൃഷ്ടിക്കാൻ [`downgrade`][downgrade] രീതി ഉപയോഗിക്കാം.ഒരു [`Weak`] പോയിന്റർ ഒരു `Arc`-ലേക്ക് [`നവീകരിക്കുക][അപ്‌ഗ്രേഡുചെയ്യാൻ] കഴിയും, എന്നാൽ അലോക്കേഷനിൽ സംഭരിച്ചിരിക്കുന്ന മൂല്യം ഇതിനകം തന്നെ ഉപേക്ഷിച്ചിട്ടുണ്ടെങ്കിൽ ഇത് [`None`] നൽകും.
/// മറ്റൊരു വിധത്തിൽ പറഞ്ഞാൽ, എക്സ് 00 എക്സ് പോയിന്ററുകൾ അലോക്കേഷനുള്ളിലെ മൂല്യം സജീവമായി നിലനിർത്തുന്നില്ല;എന്നിരുന്നാലും, അവർ അലോക്കേഷൻ (മൂല്യത്തിനായുള്ള ബാക്കിംഗ് സ്റ്റോർ) സജീവമായി നിലനിർത്തുന്നു.
///
/// `Arc` പോയിന്ററുകൾക്കിടയിലുള്ള ഒരു ചക്രം ഒരിക്കലും ഡീലോക്കേറ്റ് ചെയ്യില്ല.
/// ഇക്കാരണത്താൽ, സൈക്കിളുകൾ തകർക്കാൻ [`Weak`] ഉപയോഗിക്കുന്നു.ഉദാഹരണത്തിന്, ഒരു വൃക്ഷത്തിന് രക്ഷാകർതൃ നോഡുകളിൽ നിന്ന് കുട്ടികളിലേക്ക് ശക്തമായ `Arc` പോയിന്ററുകളും കുട്ടികളിൽ നിന്ന് മാതാപിതാക്കളിലേക്ക് [`Weak`] പോയിന്ററുകളും ഉണ്ടാകാം.
///
/// # ക്ലോണിംഗ് റഫറൻസുകൾ
///
/// നിലവിലുള്ള റഫറൻസ്-കണക്കാക്കിയ പോയിന്ററിൽ നിന്ന് ഒരു പുതിയ റഫറൻസ് സൃഷ്‌ടിക്കുന്നത് [`Arc<T>`][Arc], [`Weak<T>`][Weak] എന്നിവയ്‌ക്കായി നടപ്പിലാക്കിയ `Clone` trait ഉപയോഗിച്ചാണ്.
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // ചുവടെയുള്ള രണ്ട് വാക്യഘടനകളും തുല്യമാണ്.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b, foo എന്നിവയെല്ലാം ഒരേ മെമ്മറി സ്ഥാനത്തേക്ക് പോയിന്റുചെയ്യുന്ന ആർക്കുകളാണ്
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` `T` ([`Deref`][deref] trait വഴി) സ്വപ്രേരിതമായി ഒഴിവാക്കുന്നു, അതിനാൽ നിങ്ങൾക്ക് `Arc<T>` തരം മൂല്യത്തിൽ `ടി` രീതികളെ വിളിക്കാം.`ടി` രീതികളുമായുള്ള നാമ സംഘട്ടനങ്ങൾ ഒഴിവാക്കാൻ, `Arc<T>`-ന്റെ രീതികൾ ബന്ധപ്പെട്ട പ്രവർത്തനങ്ങളാണ്, അവയെ [fully qualified syntax] ഉപയോഗിച്ച് വിളിക്കുന്നു:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `ആർക്ക്<T>`Clone` പോലുള്ള traits ന്റെ നടപ്പാക്കലുകളെ പൂർണ്ണ യോഗ്യതയുള്ള വാക്യഘടന ഉപയോഗിച്ച് വിളിക്കാം.
/// ചില ആളുകൾ‌പൂർണ്ണ യോഗ്യതയുള്ള വാക്യഘടന ഉപയോഗിക്കാൻ‌താൽ‌പ്പര്യപ്പെടുന്നു, മറ്റുള്ളവർ‌രീതി-കോൾ‌വാക്യഘടന ഉപയോഗിക്കാൻ‌താൽ‌പ്പര്യപ്പെടുന്നു.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // രീതി-കോൾ വാക്യഘടന
/// let arc2 = arc.clone();
/// // പൂർണ്ണ യോഗ്യതയുള്ള വാക്യഘടന
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] `T`-ലേക്ക് യാന്ത്രികമായി ഒഴിവാക്കില്ല, കാരണം ആന്തരിക മൂല്യം ഇതിനകം തന്നെ ഉപേക്ഷിച്ചിരിക്കാം.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// ത്രെഡുകൾക്കിടയിൽ മാറ്റമില്ലാത്ത ചില ഡാറ്റ പങ്കിടുന്നു:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// ഈ ടെസ്റ്റുകൾ ഞങ്ങൾ ** പ്രവർത്തിപ്പിക്കുന്നില്ലെന്നത് ശ്രദ്ധിക്കുക.
// ഒരു ത്രെഡ് പ്രധാന ത്രെഡിനെ മറികടന്ന് ഒരേ സമയം പുറത്തുകടക്കുകയാണെങ്കിൽ windows നിർമ്മാതാക്കൾക്ക് അതൃപ്തി തോന്നുന്നു (എന്തെങ്കിലും ഡെഡ്‌ലോക്കുകൾ) അതിനാൽ ഈ പരിശോധനകൾ നടത്താതെ ഞങ്ങൾ ഇത് പൂർണ്ണമായും ഒഴിവാക്കുന്നു.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// മ്യൂട്ടബിൾ [`AtomicUsize`] പങ്കിടുന്നു:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// പൊതുവായി റഫറൻസ് എണ്ണലിന്റെ കൂടുതൽ ഉദാഹരണങ്ങൾക്ക് [`rc` documentation][rc_examples] കാണുക.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` നിയന്ത്രിത അലോക്കേഷന് സ്വന്തമല്ലാത്ത ഒരു റഫറൻസ് കൈവശമുള്ള [`Arc`]-ന്റെ ഒരു പതിപ്പാണ്.
/// `Weak` പോയിന്ററിൽ [`upgrade`] എന്ന് വിളിച്ചുകൊണ്ട് അലോക്കേഷൻ ആക്‌സസ്സുചെയ്യുന്നു, അത് ഒരു [`ഓപ്ഷൻ`]`<`[`ആർക്ക്`] `നൽകുന്നു<T>>`.
///
/// ഒരു `Weak` റഫറൻസ് ഉടമസ്ഥാവകാശത്തെ കണക്കാക്കാത്തതിനാൽ, അലോക്കേഷനിൽ സംഭരിച്ചിരിക്കുന്ന മൂല്യം ഉപേക്ഷിക്കുന്നത് ഇത് തടയില്ല, മാത്രമല്ല `Weak` തന്നെ ഇപ്പോഴും നിലനിൽക്കുന്ന മൂല്യത്തെക്കുറിച്ച് ഒരു ഉറപ്പുമില്ല.
///
/// [`അപ്‌ഗ്രേഡ്`] d ആയിരിക്കുമ്പോൾ ഇത് [`None`] നൽകാം.
/// എന്നിരുന്നാലും, ഒരു എക്സ് 00 എക്സ് റഫറൻസ് * അലോക്കേഷനെ (ബാക്കിംഗ് സ്റ്റോർ) ഡീലോക്കേറ്റ് ചെയ്യുന്നതിൽ നിന്ന് തടയുന്നു.
///
/// എക്സ് 01 എക്സ് നിയന്ത്രിക്കുന്ന അലോക്കേഷനെക്കുറിച്ച് അതിന്റെ ആന്തരിക മൂല്യം ഒഴിവാക്കുന്നത് തടയാതെ ഒരു താൽക്കാലിക റഫറൻസ് സൂക്ഷിക്കുന്നതിന് ഒരു എക്സ് 00 എക്സ് പോയിന്റർ ഉപയോഗപ്രദമാണ്.
/// [`Arc`] പോയിൻറുകൾ‌ക്കിടയിലുള്ള വൃത്താകൃതിയിലുള്ള റഫറൻ‌സുകൾ‌തടയുന്നതിനും ഇത് ഉപയോഗിക്കുന്നു, കാരണം പരസ്പര ഉടമസ്ഥതയിലുള്ള റഫറൻ‌സുകൾ‌ഒരിക്കലും [`Arc`] ഉപേക്ഷിക്കാൻ‌അനുവദിക്കില്ല.
/// ഉദാഹരണത്തിന്, ഒരു വൃക്ഷത്തിന് രക്ഷാകർതൃ നോഡുകളിൽ നിന്ന് കുട്ടികളിലേക്ക് ശക്തമായ [`Arc`] പോയിന്ററുകളും കുട്ടികളിൽ നിന്ന് മാതാപിതാക്കളിലേക്ക് `Weak` പോയിന്ററുകളും ഉണ്ടാകാം.
///
/// `Weak` പോയിന്റർ നേടുന്നതിനുള്ള സാധാരണ മാർഗം [`Arc::downgrade`] എന്ന് വിളിക്കുക എന്നതാണ്.
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // ഇനാമുകളിൽ ഈ തരം വലുപ്പം ഒപ്റ്റിമൈസ് ചെയ്യാൻ അനുവദിക്കുന്നതിനുള്ള ഒരു `NonNull` ആണ് ഇത്, പക്ഷേ ഇത് സാധുവായ ഒരു പോയിന്റർ ആയിരിക്കണമെന്നില്ല.
    //
    // `Weak::new` ഇത് `usize::MAX` ആയി സജ്ജമാക്കുന്നതിനാൽ കൂമ്പാരത്തിൽ സ്ഥലം അനുവദിക്കേണ്ടതില്ല.
    // ഒരു യഥാർത്ഥ പോയിന്ററിന് ഒരിക്കലും ഉണ്ടായിരിക്കേണ്ട ഒരു മൂല്യമല്ല ഇത്, കാരണം ആർ‌സി‌ബോക്സിന് കുറഞ്ഞത് 2 എങ്കിലും വിന്യാസം ഉണ്ട്.
    // `T: Sized` ആയിരിക്കുമ്പോൾ മാത്രമേ ഇത് സാധ്യമാകൂ;വലുപ്പം മാറ്റാത്ത `T` ഒരിക്കലും തൂങ്ങിക്കിടക്കുന്നില്ല.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// ഫീൽഡ് പുന ord ക്രമീകരണത്തിനെതിരായ ഇത് repr(C) മുതൽ future-പ്രൂഫ് ആണ്, ഇത് കൈമാറ്റം ചെയ്യാവുന്ന ആന്തരിക തരങ്ങളുടെ സുരക്ഷിതമായ [into|from]_raw() തടസ്സപ്പെടുത്തും.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // usize::MAX മൂല്യം താൽ‌ക്കാലികമായി "locking" നായി ഒരു സെന്റിനലായി പ്രവർത്തിക്കുന്നു, ദുർബലമായ പോയിൻററുകൾ‌അപ്‌ഗ്രേഡുചെയ്യാനോ ശക്തമായവയെ തരംതാഴ്ത്താനോ ഉള്ള കഴിവ്;`make_mut`, `get_mut` എന്നിവയിലെ റേസുകൾ ഒഴിവാക്കാൻ ഇത് ഉപയോഗിക്കുന്നു.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// ഒരു പുതിയ `Arc<T>` നിർമ്മിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // ദുർബലമായ പോയിന്റർ എണ്ണം 1 ആയി ആരംഭിക്കുക, ഇത് എല്ലാ ശക്തമായ പോയിന്ററുകളായ (kinda) കൈവശമുള്ള ദുർബലമായ പോയിന്ററാണ്, കൂടുതൽ വിവരങ്ങൾക്ക് std/rc.rs കാണുക
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// സ്വയം ഒരു ദുർബലമായ റഫറൻസ് ഉപയോഗിച്ച് ഒരു പുതിയ `Arc<T>` നിർമ്മിക്കുന്നു.
    /// ഈ ഫംഗ്ഷൻ മടങ്ങുന്നതിന് മുമ്പ് ദുർബലമായ റഫറൻസ് അപ്‌ഗ്രേഡുചെയ്യാൻ ശ്രമിക്കുന്നത് ഒരു `None` മൂല്യത്തിന് കാരണമാകും.
    /// എന്നിരുന്നാലും, ദുർബലമായ റഫറൻസ് സ ely ജന്യമായി ക്ലോൺ ചെയ്ത് പിന്നീടുള്ള സമയത്ത് ഉപയോഗത്തിനായി സൂക്ഷിക്കാം.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // ഒരൊറ്റ ദുർബലമായ റഫറൻസ് ഉപയോഗിച്ച് "uninitialized" അവസ്ഥയിൽ ആന്തരികം നിർമ്മിക്കുക.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // ദുർബലമായ പോയിന്ററിന്റെ ഉടമസ്ഥാവകാശം ഞങ്ങൾ ഉപേക്ഷിക്കാതിരിക്കുക എന്നത് പ്രധാനമാണ്, അല്ലെങ്കിൽ `data_fn` മടങ്ങിയെത്തുമ്പോഴേക്കും മെമ്മറി സ്വതന്ത്രമാകാം.
        // ഉടമസ്ഥാവകാശം കൈമാറാൻ ഞങ്ങൾ ശരിക്കും ആഗ്രഹിക്കുന്നുവെങ്കിൽ, ഞങ്ങൾക്ക് സ്വയം ഒരു ദുർബലമായ പോയിന്റർ സൃഷ്ടിക്കാൻ കഴിയും, പക്ഷേ ഇത് ദുർബലമായ റഫറൻസ് എണ്ണത്തിലേക്ക് അധിക അപ്‌ഡേറ്റുകൾക്ക് കാരണമാകും, അല്ലാത്തപക്ഷം അത് ആവശ്യമായി വരില്ല.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // ഇപ്പോൾ നമുക്ക് ആന്തരിക മൂല്യം ശരിയായി സമാരംഭിക്കാനും ദുർബലമായ റഫറൻസിനെ ശക്തമായ റഫറൻസാക്കി മാറ്റാനും കഴിയും.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // ഡാറ്റ ഫീൽഡിലേക്കുള്ള മുകളിലുള്ള റൈറ്റ് പൂജ്യമല്ലാത്ത ശക്തമായ എണ്ണം നിരീക്ഷിക്കുന്ന ഏത് ത്രെഡുകളിലും ദൃശ്യമായിരിക്കണം.
            // അതിനാൽ `Weak::upgrade`-ലെ `compare_exchange_weak`-മായി സമന്വയിപ്പിക്കുന്നതിന് ഞങ്ങൾക്ക് കുറഞ്ഞത് "Release" ഓർഡറിംഗ് ആവശ്യമാണ്.
            //
            // "Acquire" ക്രമപ്പെടുത്തൽ ആവശ്യമില്ല.
            // `data_fn`-ന്റെ സാധ്യമായ പെരുമാറ്റരീതികൾ പരിഗണിക്കുമ്പോൾ, അപ്‌ഗ്രേഡുചെയ്യാനാകാത്ത `Weak`-നെക്കുറിച്ചുള്ള ഒരു റഫറൻസുമായി ഇതിന് എന്ത് ചെയ്യാനാകുമെന്ന് ഞങ്ങൾ നോക്കേണ്ടതുണ്ട്:
            //
            // - ഇതിന് `Weak`*ക്ലോൺ* ചെയ്യാൻ കഴിയും, ഇത് ദുർബലമായ റഫറൻസ് എണ്ണം വർദ്ധിപ്പിക്കുന്നു.
            // - ഇതിന് ആ ക്ലോണുകൾ ഉപേക്ഷിക്കാൻ കഴിയും, ദുർബലമായ റഫറൻസ് എണ്ണം കുറയുന്നു (പക്ഷേ ഒരിക്കലും പൂജ്യമാകില്ല).
            //
            // ഈ പാർശ്വഫലങ്ങൾ ഒരു തരത്തിലും ഞങ്ങളെ ബാധിക്കില്ല, മാത്രമല്ല സുരക്ഷിത കോഡ് ഉപയോഗിച്ച് മാത്രം മറ്റ് പാർശ്വഫലങ്ങൾ സാധ്യമല്ല.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // ശക്തമായ റഫറൻ‌സുകൾ‌ഒന്നിച്ച് പങ്കിട്ട ദുർബലമായ റഫറൻ‌സ് സ്വന്തമാക്കിയിരിക്കണം, അതിനാൽ‌ഞങ്ങളുടെ പഴയ ദുർബല റഫറൻസിനായി ഡിസ്ട്രക്റ്റർ‌പ്രവർത്തിപ്പിക്കരുത്.
        //
        mem::forget(weak);
        strong
    }

    /// ആരംഭിക്കാത്ത ഉള്ളടക്കങ്ങളുള്ള ഒരു പുതിയ `Arc` നിർമ്മിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // മാറ്റിവച്ച ഓർഗനൈസേഷൻ:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// മെമ്മറി `0` ബൈറ്റുകൾ കൊണ്ട് നിറച്ചുകൊണ്ട്, ആരംഭിക്കാത്ത ഉള്ളടക്കങ്ങളുള്ള ഒരു പുതിയ `Arc` നിർമ്മിക്കുന്നു.
    ///
    ///
    /// ഈ രീതിയുടെ ശരിയായതും തെറ്റായതുമായ ഉപയോഗത്തിന്റെ ഉദാഹരണങ്ങൾക്കായി [`MaybeUninit::zeroed`][zeroed] കാണുക.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// ഒരു പുതിയ `Pin<Arc<T>>` നിർമ്മിക്കുന്നു.
    /// `T` `Unpin` നടപ്പിലാക്കുന്നില്ലെങ്കിൽ, `data` മെമ്മറിയിൽ പിൻ ചെയ്യുകയും നീക്കാൻ കഴിയാതിരിക്കുകയും ചെയ്യും.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// ഒരു പുതിയ `Arc<T>` നിർമ്മിക്കുന്നു, അലോക്കേഷൻ പരാജയപ്പെട്ടാൽ ഒരു പിശക് നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // ദുർബലമായ പോയിന്റർ എണ്ണം 1 ആയി ആരംഭിക്കുക, ഇത് എല്ലാ ശക്തമായ പോയിന്ററുകളായ (kinda) കൈവശമുള്ള ദുർബലമായ പോയിന്ററാണ്, കൂടുതൽ വിവരങ്ങൾക്ക് std/rc.rs കാണുക
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// ആരംഭിക്കാത്ത ഉള്ളടക്കങ്ങളുള്ള ഒരു പുതിയ `Arc` നിർമ്മിക്കുന്നു, അലോക്കേഷൻ പരാജയപ്പെട്ടാൽ ഒരു പിശക് നൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // മാറ്റിവച്ച ഓർഗനൈസേഷൻ:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// മെമ്മറി `0` ബൈറ്റുകളാൽ നിറച്ചുകൊണ്ട്, ആരംഭിക്കാത്ത ഉള്ളടക്കങ്ങളുള്ള ഒരു പുതിയ `Arc` നിർമ്മിക്കുന്നു, അലോക്കേഷൻ പരാജയപ്പെട്ടാൽ ഒരു പിശക് നൽകുന്നു.
    ///
    ///
    /// ഈ രീതിയുടെ ശരിയായതും തെറ്റായതുമായ ഉപയോഗത്തിന്റെ ഉദാഹരണങ്ങൾക്കായി [`MaybeUninit::zeroed`][zeroed] കാണുക.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// `Arc`-ന് കൃത്യമായി ഒരു ശക്തമായ റഫറൻസ് ഉണ്ടെങ്കിൽ ആന്തരിക മൂല്യം നൽകുന്നു.
    ///
    /// അല്ലെങ്കിൽ, കടന്നുപോയ അതേ `Arc` ഉപയോഗിച്ച് ഒരു [`Err`] തിരികെ നൽകും.
    ///
    ///
    /// മികച്ച ദുർബലമായ റഫറൻസുകൾ ഉണ്ടെങ്കിലും ഇത് വിജയിക്കും.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // വ്യക്തമായ ശക്തമായ-ദുർബലമായ റഫറൻസ് വൃത്തിയാക്കാൻ ഒരു ദുർബലമായ പോയിന്റർ നിർമ്മിക്കുക
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// ആരംഭിക്കാത്ത ഉള്ളടക്കങ്ങളുള്ള ഒരു പുതിയ ആറ്റോമിക്കലി റഫറൻസ്-കണക്കാക്കിയ സ്ലൈസ് നിർമ്മിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // മാറ്റിവച്ച ഓർഗനൈസേഷൻ:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// മെമ്മറി `0` ബൈറ്റുകളാൽ നിറച്ചുകൊണ്ട്, ആരംഭിക്കാത്ത ഉള്ളടക്കങ്ങളുള്ള ഒരു പുതിയ ആറ്റോമിക്കലി റഫറൻസ്-കൗണ്ടഡ് സ്ലൈസ് നിർമ്മിക്കുന്നു.
    ///
    ///
    /// ഈ രീതിയുടെ ശരിയായതും തെറ്റായതുമായ ഉപയോഗത്തിന്റെ ഉദാഹരണങ്ങൾക്കായി [`MaybeUninit::zeroed`][zeroed] കാണുക.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// `Arc<T>`-ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] പോലെ, ആന്തരിക മൂല്യം ശരിക്കും ഒരു പ്രാരംഭ അവസ്ഥയിലാണെന്ന് ഉറപ്പുനൽകേണ്ടത് കോളർ ആണ്.
    ///
    /// ഉള്ളടക്കം ഇതുവരെ പൂർണ്ണമായി ആരംഭിച്ചിട്ടില്ലാത്തപ്പോൾ ഇത് വിളിക്കുന്നത് ഉടനടി നിർവചിക്കപ്പെടാത്ത സ്വഭാവത്തിന് കാരണമാകുന്നു.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // മാറ്റിവച്ച ഓർഗനൈസേഷൻ:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// `Arc<[T]>`-ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// # Safety
    ///
    /// [`MaybeUninit::assume_init`] പോലെ, ആന്തരിക മൂല്യം ശരിക്കും ഒരു പ്രാരംഭ അവസ്ഥയിലാണെന്ന് ഉറപ്പുനൽകേണ്ടത് കോളർ ആണ്.
    ///
    /// ഉള്ളടക്കം ഇതുവരെ പൂർണ്ണമായി ആരംഭിച്ചിട്ടില്ലാത്തപ്പോൾ ഇത് വിളിക്കുന്നത് ഉടനടി നിർവചിക്കപ്പെടാത്ത സ്വഭാവത്തിന് കാരണമാകുന്നു.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // മാറ്റിവച്ച ഓർഗനൈസേഷൻ:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// പൊതിഞ്ഞ പോയിന്റർ മടക്കി `Arc` ഉപയോഗിക്കുന്നു.
    ///
    /// മെമ്മറി ലീക്ക് ഒഴിവാക്കാൻ പോയിന്റർ [`Arc::from_raw`] ഉപയോഗിച്ച് ഒരു `Arc` ലേക്ക് തിരികെ പരിവർത്തനം ചെയ്യണം.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// ഡാറ്റയിലേക്ക് ഒരു റോ പോയിന്റർ നൽകുന്നു.
    ///
    /// എണ്ണത്തെ ഒരു തരത്തിലും ബാധിക്കില്ല കൂടാതെ `Arc` ഉപയോഗിക്കുന്നില്ല.
    /// `Arc`-ൽ ശക്തമായ എണ്ണങ്ങൾ ഉള്ളിടത്തോളം പോയിന്റർ സാധുവാണ്.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // സുരക്ഷ: ഇതിന് Deref::deref അല്ലെങ്കിൽ RcBoxPtr::inner വഴി പോകാൻ കഴിയില്ല കാരണം
        // ഉദാ. raw/mut ഉറവിടം നിലനിർത്താൻ ഇത് ആവശ്യമാണ്
        // `get_mut` `from_raw` വഴി ആർ‌സി വീണ്ടെടുത്ത ശേഷം പോയിന്ററിലൂടെ എഴുതാൻ‌കഴിയും.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// ഒരു റോ പോയിന്ററിൽ നിന്ന് ഒരു `Arc<T>` നിർമ്മിക്കുന്നു.
    ///
    /// റോ പോയിന്റർ മുമ്പ് [`Arc<U>::into_raw`][into_raw]-ലേക്ക് ഒരു കോൾ നൽകിയിരിക്കണം, അവിടെ `U`-ന് `T`-ന് സമാനമായ വലുപ്പവും വിന്യാസവും ഉണ്ടായിരിക്കണം.
    /// `U` `T` ആണെങ്കിൽ ഇത് വളരെ തുച്ഛമാണ്.
    /// `U` `T` അല്ലെങ്കിലും ഒരേ വലുപ്പവും വിന്യാസവുമുണ്ടെങ്കിൽ, ഇത് അടിസ്ഥാനപരമായി വ്യത്യസ്ത തരം റഫറൻസുകൾ കൈമാറുന്നതുപോലെയാണ്.
    /// ഈ സാഹചര്യത്തിൽ എന്ത് നിയന്ത്രണങ്ങൾ ബാധകമാണ് എന്നതിനെക്കുറിച്ചുള്ള കൂടുതൽ വിവരങ്ങൾക്ക് [`mem::transmute`][transmute] കാണുക.
    ///
    /// `from_raw` ന്റെ ഉപയോക്താവ് `T` ന്റെ ഒരു നിർദ്ദിഷ്ട മൂല്യം ഒരു തവണ മാത്രമേ ഉപേക്ഷിച്ചിട്ടുള്ളൂവെന്ന് ഉറപ്പാക്കേണ്ടതുണ്ട്.
    ///
    /// ഈ പ്രവർത്തനം സുരക്ഷിതമല്ല, കാരണം അനുചിതമായ ഉപയോഗം മെമ്മറി സുരക്ഷിതത്വത്തിലേക്ക് നയിച്ചേക്കാം, മടങ്ങിയ `Arc<T>` ഒരിക്കലും ആക്സസ് ചെയ്തിട്ടില്ലെങ്കിലും.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // ചോർച്ച തടയുന്നതിന് ഒരു `Arc`-ലേക്ക് തിരികെ പരിവർത്തനം ചെയ്യുക.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // `Arc::from_raw(x_ptr)`-ലേക്കുള്ള കൂടുതൽ കോളുകൾ മെമ്മറി സുരക്ഷിതമല്ല.
    /// }
    ///
    /// // `x` മുകളിലുള്ള വ്യാപ്തിയിൽ നിന്ന് പുറത്തുപോകുമ്പോൾ മെമ്മറി സ്വതന്ത്രമാക്കി, അതിനാൽ `x_ptr` ഇപ്പോൾ അപകടത്തിലാണ്!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // യഥാർത്ഥ ആർക്ക്ഇന്നർ കണ്ടെത്താൻ ഓഫ്‌സെറ്റ് വിപരീതമാക്കുക.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// ഈ അലോക്കേഷനായി ഒരു പുതിയ [`Weak`] പോയിന്റർ സൃഷ്ടിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // ചുവടെയുള്ള CAS ലെ മൂല്യം ഞങ്ങൾ പരിശോധിക്കുന്നതിനാൽ ഈ വിശ്രമം ശരിയാണ്.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // ദുർബലമായ ക counter ണ്ടർ നിലവിൽ "locked" ആണോയെന്ന് പരിശോധിക്കുക;അങ്ങനെയാണെങ്കിൽ, സ്പിൻ ചെയ്യുക.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: ഈ കോഡ് നിലവിൽ ഓവർഫ്ലോ സാധ്യതയെ അവഗണിക്കുന്നു
            // usize::MAX-ലേക്ക്;ഓവർഫ്ലോ കൈകാര്യം ചെയ്യുന്നതിന് പൊതുവായി ആർ‌സി, ആർക്ക് എന്നിവ ക്രമീകരിക്കേണ്ടതുണ്ട്.
            //

            // Clone()-ൽ നിന്ന് വ്യത്യസ്‌തമായി, `is_unique`-ൽ നിന്നുള്ള റൈറ്റുമായി സമന്വയിപ്പിക്കുന്നതിന് ഇത് ഒരു അക്വയർ റീഡ് ആയിരിക്കേണ്ടതുണ്ട്, അതിനാൽ ഈ റൈറ്റിന് മുമ്പുള്ള ഇവന്റുകൾ ഈ വായനയ്ക്ക് മുമ്പായി സംഭവിക്കുന്നു.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // ദുർബലമായ ഒരു ദുർബലത ഞങ്ങൾ സൃഷ്ടിക്കുന്നില്ലെന്ന് ഉറപ്പാക്കുക
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// ഈ അലോക്കേഷനിലേക്ക് [`Weak`] പോയിന്ററുകളുടെ എണ്ണം നേടുന്നു.
    ///
    /// # Safety
    ///
    /// ഈ രീതി സ്വയം സുരക്ഷിതമാണ്, പക്ഷേ ഇത് ശരിയായി ഉപയോഗിക്കുന്നതിന് അധിക പരിചരണം ആവശ്യമാണ്.
    /// മറ്റൊരു ത്രെഡിന് എപ്പോൾ വേണമെങ്കിലും ദുർബലമായ എണ്ണം മാറ്റാൻ കഴിയും, ഈ രീതി വിളിക്കുന്നതിനും ഫലത്തിൽ പ്രവർത്തിക്കുന്നതിനും ഇടയിൽ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // ഈ വാദം നിർണ്ണായകമാണ്, കാരണം ഞങ്ങൾ ത്രെഡുകൾക്കിടയിൽ `Arc` അല്ലെങ്കിൽ `Weak` പങ്കിട്ടിട്ടില്ല.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // നിലവിൽ ദുർബലമായ എണ്ണം ലോക്ക് ചെയ്തിട്ടുണ്ടെങ്കിൽ, ലോക്ക് എടുക്കുന്നതിന് തൊട്ടുമുമ്പ് എണ്ണത്തിന്റെ മൂല്യം 0 ആയിരുന്നു.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// ഈ അലോക്കേഷനിൽ ശക്തമായ (`Arc`) പോയിന്ററുകളുടെ എണ്ണം നേടുന്നു.
    ///
    /// # Safety
    ///
    /// ഈ രീതി സ്വയം സുരക്ഷിതമാണ്, പക്ഷേ ഇത് ശരിയായി ഉപയോഗിക്കുന്നതിന് അധിക പരിചരണം ആവശ്യമാണ്.
    /// മറ്റൊരു ത്രെഡിന് ഏത് സമയത്തും ശക്തമായ എണ്ണം മാറ്റാൻ കഴിയും, ഈ രീതിയെ വിളിക്കുന്നതും ഫലത്തിൽ പ്രവർത്തിക്കുന്നതും തമ്മിലുള്ള സാധ്യത ഉൾപ്പെടെ.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // ത്രെഡുകൾക്കിടയിൽ ഞങ്ങൾ `Arc` പങ്കിട്ടിട്ടില്ലാത്തതിനാൽ ഈ വാദം നിർണ്ണായകമാണ്.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// നൽകിയ പോയിന്ററുമായി ബന്ധപ്പെട്ട `Arc<T>`-ലെ ശക്തമായ റഫറൻസ് എണ്ണം ഓരോന്നായി വർദ്ധിപ്പിക്കുന്നു.
    ///
    /// # Safety
    ///
    /// പോയിന്റർ `Arc::into_raw` വഴി നേടിയിരിക്കണം, കൂടാതെ ബന്ധപ്പെട്ട `Arc` ഇൻസ്റ്റൻസ് സാധുവായിരിക്കണം (അതായത്
    /// ഈ രീതിയുടെ ദൈർഘ്യത്തിന് ശക്തമായ എണ്ണം കുറഞ്ഞത് 1) ആയിരിക്കണം.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // ത്രെഡുകൾക്കിടയിൽ ഞങ്ങൾ `Arc` പങ്കിട്ടിട്ടില്ലാത്തതിനാൽ ഈ വാദം നിർണ്ണായകമാണ്.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // ആർക്ക് നിലനിർത്തുക, പക്ഷേ മാനുവൽ ഡ്രോപ്പിൽ പൊതിഞ്ഞ് റിഫ ount ണ്ട് തൊടരുത്
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // ഇപ്പോൾ റീഫ്ക ount ണ്ട് വർദ്ധിപ്പിക്കുക, പക്ഷേ പുതിയ റീഫ്ക ount ണ്ട് ഉപേക്ഷിക്കരുത്
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// നൽകിയ പോയിന്ററുമായി ബന്ധപ്പെട്ട `Arc<T>`-ലെ ശക്തമായ റഫറൻസ് എണ്ണം ഓരോന്നായി കുറയ്‌ക്കുന്നു.
    ///
    /// # Safety
    ///
    /// പോയിന്റർ `Arc::into_raw` വഴി നേടിയിരിക്കണം, കൂടാതെ ബന്ധപ്പെട്ട `Arc` ഇൻസ്റ്റൻസ് സാധുവായിരിക്കണം (അതായത്
    /// ഈ രീതി ആവശ്യപ്പെടുമ്പോൾ ശക്തമായ എണ്ണം കുറഞ്ഞത് 1) ആയിരിക്കണം.
    /// അന്തിമ `Arc`, ബാക്കിംഗ് സ്റ്റോറേജ് എന്നിവ റിലീസ് ചെയ്യുന്നതിന് ഈ രീതി ഉപയോഗിക്കാം, പക്ഷേ അവസാന `Arc` പുറത്തിറങ്ങിയതിന് ശേഷം ** വിളിക്കരുത്.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // ത്രെഡുകൾക്കിടയിൽ ഞങ്ങൾ `Arc` പങ്കിട്ടിട്ടില്ലാത്തതിനാൽ ആ വാദങ്ങൾ നിർണ്ണായകമാണ്.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // ഈ സുരക്ഷിതത്വം ശരിയാണ്, കാരണം ഈ ആർക്ക് സജീവമായിരിക്കുമ്പോൾ ആന്തരിക പോയിന്റർ സാധുതയുള്ളതാണെന്ന് ഞങ്ങൾക്ക് ഉറപ്പുണ്ട്.
        // കൂടാതെ, `ArcInner` ഘടന തന്നെ `Sync` ആണെന്ന് ഞങ്ങൾക്കറിയാം, കാരണം ആന്തരിക ഡാറ്റയും `Sync` ആണ്, അതിനാൽ ഈ ഉള്ളടക്കങ്ങളിലേക്ക് മാറ്റമില്ലാത്ത പോയിന്റർ ഞങ്ങൾ കടമെടുക്കുന്നു.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // `drop`-ന്റെ ഇൻലൈൻ ചെയ്യാത്ത ഭാഗം.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // ബോക്സ് അലോക്കേഷൻ ഞങ്ങൾ തന്നെ സ്വതന്ത്രമാക്കിയിട്ടില്ലെങ്കിലും ഈ സമയത്ത് ഡാറ്റ നശിപ്പിക്കുക (ഇപ്പോഴും ദുർബലമായ പോയിന്ററുകൾ ചുറ്റും കിടക്കുന്നു).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // എല്ലാ ശക്തമായ റഫറൻ‌സുകളും ചേർ‌ന്നുള്ള ദുർബലമായ റഫർ‌ഉപേക്ഷിക്കുക
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// രണ്ട് `ആർക്ക്`കളും ഒരേ അലോക്കേഷനിലേക്കാണ് വിരൽ ചൂണ്ടുന്നതെങ്കിൽ ([`ptr::eq`] ന് സമാനമായ ഒരു സിരയിൽ) `true` നൽകുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// മൂല്യത്തിന് ലേ layout ട്ട് നൽകിയിട്ടുള്ള, വലുപ്പം മാറ്റാത്ത ആന്തരിക മൂല്യത്തിന് മതിയായ ഇടമുള്ള ഒരു `ArcInner<T>` അനുവദിക്കുന്നു.
    ///
    /// ഡാറ്റാ പോയിന്റർ ഉപയോഗിച്ച് `mem_to_arcinner` ഫംഗ്ഷൻ വിളിക്കുന്നു, കൂടാതെ `ArcInner<T>`-നായി ഒരു (കൊഴുപ്പ് സാധ്യതയുള്ള)-പോയിന്റർ തിരികെ നൽകണം.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // നൽകിയ മൂല്യ ലേ .ട്ട് ഉപയോഗിച്ച് ലേ layout ട്ട് കണക്കാക്കുക.
        // മുമ്പ്, `&*(ptr as* const ArcInner<T>)` എക്സ്പ്രഷനിൽ ലേ layout ട്ട് കണക്കാക്കിയിരുന്നു, പക്ഷേ ഇത് തെറ്റായി രൂപകൽപ്പന ചെയ്ത ഒരു റഫറൻസ് സൃഷ്ടിച്ചു (#54908 കാണുക).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// മൂല്യം ലേ layout ട്ട് നൽകിയിട്ടുള്ള, വലുപ്പം മാറ്റാത്ത ആന്തരിക മൂല്യത്തിന് മതിയായ ഇടമുള്ള ഒരു `ArcInner<T>` അനുവദിക്കുന്നു, അലോക്കേഷൻ പരാജയപ്പെട്ടാൽ ഒരു പിശക് നൽകുന്നു.
    ///
    ///
    /// ഡാറ്റാ പോയിന്റർ ഉപയോഗിച്ച് `mem_to_arcinner` ഫംഗ്ഷൻ വിളിക്കുന്നു, കൂടാതെ `ArcInner<T>`-നായി ഒരു (കൊഴുപ്പ് സാധ്യതയുള്ള)-പോയിന്റർ തിരികെ നൽകണം.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // നൽകിയ മൂല്യ ലേ .ട്ട് ഉപയോഗിച്ച് ലേ layout ട്ട് കണക്കാക്കുക.
        // മുമ്പ്, `&*(ptr as* const ArcInner<T>)` എക്സ്പ്രഷനിൽ ലേ layout ട്ട് കണക്കാക്കിയിരുന്നു, പക്ഷേ ഇത് തെറ്റായി രൂപകൽപ്പന ചെയ്ത ഒരു റഫറൻസ് സൃഷ്ടിച്ചു (#54908 കാണുക).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // ആർക്ക്ഇന്നർ സമാരംഭിക്കുക
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// വലുപ്പം മാറ്റാത്ത ആന്തരിക മൂല്യത്തിന് മതിയായ ഇടമുള്ള ഒരു `ArcInner<T>` അനുവദിക്കുന്നു.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // തന്നിരിക്കുന്ന മൂല്യം ഉപയോഗിച്ച് `ArcInner<T>`-നായി അനുവദിക്കുക.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // മൂല്യം ബൈറ്റുകളായി പകർത്തുക
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // അലോക്കേഷൻ അതിന്റെ ഉള്ളടക്കങ്ങൾ ഉപേക്ഷിക്കാതെ സ്വതന്ത്രമാക്കുക
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// തന്നിരിക്കുന്ന നീളമുള്ള ഒരു `ArcInner<[T]>` അനുവദിക്കുന്നു.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// സ്ലൈസിൽ നിന്ന് ഘടകങ്ങൾ പുതുതായി അനുവദിച്ച ആർക്ക് <\[T\]> ലേക്ക് പകർത്തുക
    ///
    /// സുരക്ഷിതമല്ലാത്തതിനാൽ വിളിക്കുന്നയാൾ ഉടമസ്ഥാവകാശം ഏറ്റെടുക്കുകയോ `T: Copy` ബന്ധിപ്പിക്കുകയോ വേണം.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// ഒരു നിശ്ചിത വലുപ്പമുള്ള ഒരു ഇറ്ററേറ്ററിൽ നിന്ന് ഒരു `Arc<[T]>` നിർമ്മിക്കുന്നു.
    ///
    /// വലുപ്പം തെറ്റാണെങ്കിൽ പെരുമാറ്റം നിർവചിക്കപ്പെട്ടിട്ടില്ല.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // ടി ഘടകങ്ങൾ ക്ലോൺ ചെയ്യുമ്പോൾ Panic ഗാർഡ്.
        // ഒരു panic ഉണ്ടായാൽ, പുതിയ ആർക്ക്ഇന്നറിലേക്ക് എഴുതിയ ഘടകങ്ങൾ ഉപേക്ഷിക്കപ്പെടും, തുടർന്ന് മെമ്മറി സ്വതന്ത്രമാകും.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // ആദ്യ ഘടകത്തിലേക്കുള്ള പോയിന്റർ
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // എല്ലാം വ്യക്തമാണ്.ഗാർഡിനെ മറക്കുക, അതുവഴി പുതിയ ആർക്ക്ഇന്നർ സ്വതന്ത്രമാകില്ല.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// സ്പെഷ്യലൈസേഷൻ `From<&[T]>`-നായി ഉപയോഗിക്കുന്ന trait.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// `Arc` പോയിന്ററിന്റെ ഒരു ക്ലോൺ നിർമ്മിക്കുന്നു.
    ///
    /// ഇത് ഒരേ അലോക്കേഷനിലേക്ക് മറ്റൊരു പോയിന്റർ സൃഷ്ടിക്കുന്നു, ഇത് ശക്തമായ റഫറൻസ് എണ്ണം വർദ്ധിപ്പിക്കുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // യഥാർത്ഥ റഫറൻസിനെക്കുറിച്ചുള്ള അറിവ് മറ്റ് ത്രെഡുകളെ ഒബ്‌ജക്റ്റ് തെറ്റായി ഇല്ലാതാക്കുന്നതിൽ നിന്ന് തടയുന്നതിനാൽ, ഒരു ശാന്തമായ ക്രമം ഉപയോഗിക്കുന്നത് ഇവിടെ ശരിയാണ്.
        //
        // [Boost documentation][1]-ൽ വിശദീകരിച്ചിരിക്കുന്നതുപോലെ, റഫറൻസ് ക counter ണ്ടർ വർദ്ധിപ്പിക്കുന്നത് എല്ലായ്പ്പോഴും മെമ്മറി_ഓർഡർ_റെലക്സ്ഡ് ഉപയോഗിച്ച് ചെയ്യാവുന്നതാണ്: ഒരു ഒബ്ജക്റ്റിലേക്കുള്ള പുതിയ റഫറൻസുകൾ നിലവിലുള്ള ഒരു റഫറൻസിൽ നിന്ന് മാത്രമേ രൂപീകരിക്കാൻ കഴിയൂ, കൂടാതെ നിലവിലുള്ള ഒരു റഫറൻസ് ഒരു ത്രെഡിൽ നിന്ന് മറ്റൊന്നിലേക്ക് കൈമാറുന്നത് ഇതിനകം തന്നെ ആവശ്യമായ സമന്വയം നൽകേണ്ടതുണ്ട്.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // എന്നിരുന്നാലും ആരെങ്കിലും ആർക്കുകൾ `മെം: : മറക്കുക` ആണെങ്കിൽ വമ്പിച്ച റീഫ ount ണ്ടുകളിൽ നിന്ന് നാം ജാഗ്രത പാലിക്കേണ്ടതുണ്ട്.
        // ഞങ്ങൾ ഇത് ചെയ്തില്ലെങ്കിൽ, എണ്ണം കവിഞ്ഞൊഴുകുകയും ഉപയോക്താക്കൾ സ after ജന്യമായി ഉപയോഗിക്കുകയും ചെയ്യും.
        // റഫറൻസ് എണ്ണം ഒറ്റയടിക്ക് വർദ്ധിപ്പിക്കുന്ന ~2 ബില്ല്യൺ ത്രെഡുകൾ ഇല്ലെന്ന ധാരണയിൽ ഞങ്ങൾ `isize::MAX`-ലേക്ക് വംശീയമായി പൂരിതമാകുന്നു.
        //
        // ഒരു റിയലിസ്റ്റിക് പ്രോഗ്രാമിലും ഈ branch ഒരിക്കലും എടുക്കില്ല.
        //
        // അത്തരമൊരു പ്രോഗ്രാം അവിശ്വസനീയമാംവിധം അധ enera പതിച്ചതിനാൽ ഞങ്ങൾ അത് നിർത്തുന്നു, അതിനെ പിന്തുണയ്ക്കാൻ ഞങ്ങൾ ആഗ്രഹിക്കുന്നില്ല.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// തന്നിരിക്കുന്ന `Arc`-ലേക്ക് മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു.
    ///
    /// ഒരേ അലോക്കേഷനിൽ മറ്റ് `Arc` അല്ലെങ്കിൽ [`Weak`] പോയിന്ററുകൾ ഉണ്ടെങ്കിൽ, അദ്വിതീയ ഉടമസ്ഥാവകാശം ഉറപ്പാക്കുന്നതിന് `make_mut` ഒരു പുതിയ അലോക്കേഷൻ സൃഷ്ടിക്കുകയും ആന്തരിക മൂല്യത്തിൽ [`clone`][clone] അഭ്യർത്ഥിക്കുകയും ചെയ്യും.
    /// ഇതിനെ ക്ലോൺ-ഓൺ-റൈറ്റ് എന്നും വിളിക്കുന്നു.
    ///
    /// [`Rc::make_mut`] ന്റെ സ്വഭാവത്തിൽ നിന്ന് ഇത് വ്യത്യാസപ്പെട്ടിരിക്കുന്നു, ഇത് ശേഷിക്കുന്ന `Weak` പോയിന്ററുകളെ വേർപെടുത്തും.
    ///
    /// [`get_mut`][get_mut] ഉം കാണുക, അത് ക്ലോണിംഗിനേക്കാൾ പരാജയപ്പെടും.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // ഒന്നും ക്ലോൺ ചെയ്യില്ല
    /// let mut other_data = Arc::clone(&data); // ആന്തരിക ഡാറ്റ ക്ലോൺ ചെയ്യില്ല
    /// *Arc::make_mut(&mut data) += 1;         // ആന്തരിക ഡാറ്റ ക്ലോൺ ചെയ്യുന്നു
    /// *Arc::make_mut(&mut data) += 1;         // ഒന്നും ക്ലോൺ ചെയ്യില്ല
    /// *Arc::make_mut(&mut other_data) *= 2;   // ഒന്നും ക്ലോൺ ചെയ്യില്ല
    ///
    /// // ഇപ്പോൾ `data`, `other_data` എന്നിവ വ്യത്യസ്ത അലോക്കേഷനുകളിലേക്ക് പോയിന്റ് ചെയ്യുന്നു.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // ഞങ്ങൾ ശക്തമായ റഫറൻസും ദുർബലമായ റഫറൻസും സൂക്ഷിക്കുന്നുവെന്നത് ശ്രദ്ധിക്കുക.
        // അതിനാൽ, ഞങ്ങളുടെ ശക്തമായ റഫറൻസ് മാത്രം റിലീസ് ചെയ്യുന്നത്, മെമ്മറി ഡീലോക്കേറ്റ് ചെയ്യുന്നതിന് കാരണമാകില്ല.
        //
        // X001 ലേക്ക് റിലീസ് എഴുതുന്നതിനുമുമ്പ് (അതായത്, കുറയുന്നു) സംഭവിക്കുന്ന `weak`-ലേക്ക് എന്തെങ്കിലും റൈറ്റുകൾ ഞങ്ങൾ കാണുന്നുണ്ടെന്ന് ഉറപ്പാക്കാൻ ഏറ്റെടുക്കുക ഉപയോഗിക്കുക.
        // ഞങ്ങൾ ഒരു ദുർബലമായ എണ്ണം ഉള്ളതിനാൽ, ആർക്ക്ഇന്നർ തന്നെ ഡീലോക്കേറ്റ് ചെയ്യാൻ സാധ്യതയില്ല.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // മറ്റൊരു ശക്തമായ പോയിന്റർ നിലവിലുണ്ട്, അതിനാൽ ഞങ്ങൾ ക്ലോൺ ചെയ്യണം.
            // ക്ലോൺ ചെയ്ത മൂല്യം നേരിട്ട് എഴുതാൻ അനുവദിക്കുന്നതിന് മെമ്മറി മുൻകൂട്ടി അനുവദിക്കുക.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // മുകളിൽ പറഞ്ഞവയിൽ വിശ്രമിക്കുന്നത് മതിയാകും കാരണം ഇത് അടിസ്ഥാനപരമായി ഒരു ഒപ്റ്റിമൈസേഷനാണ്: ദുർബലമായ പോയിന്ററുകൾ ഉപേക്ഷിച്ച് ഞങ്ങൾ എല്ലായ്പ്പോഴും റേസിംഗ് നടത്തുന്നു.
            // ഏറ്റവും മോശം കാര്യം, ഞങ്ങൾ ഒരു പുതിയ ആർക്ക് അനാവശ്യമായി അനുവദിച്ചു.
            //

            // അവസാന ശക്തമായ റഫർ‌ഞങ്ങൾ‌നീക്കംചെയ്‌തു, പക്ഷേ അധിക ദുർബലമായ റെഫുകൾ‌ശേഷിക്കുന്നു.
            // ഞങ്ങൾ ഉള്ളടക്കങ്ങൾ ഒരു പുതിയ ആർക്കിലേക്ക് നീക്കും, കൂടാതെ മറ്റ് ദുർബലമായ റഫറുകളും അസാധുവാക്കും.
            //

            // ദുർബലമായ എണ്ണം ശക്തമായ റഫറൻസുള്ള ഒരു ത്രെഡിന് മാത്രമേ ലോക്ക് ചെയ്യാൻ കഴിയൂ എന്നതിനാൽ, `weak` റീഡിന് usize::MAX (അതായത്, ലോക്കുചെയ്‌തത്) നൽകുന്നത് സാധ്യമല്ലെന്നത് ശ്രദ്ധിക്കുക.
            //
            //

            // ഞങ്ങളുടെ സ്വന്തം ദുർബലമായ പോയിന്റർ മെറ്റീരിയലൈസ് ചെയ്യുക, അതുവഴി ആവശ്യാനുസരണം ആർക്ക്ഇന്നർ വൃത്തിയാക്കാൻ കഴിയും.
            //
            let _weak = Weak { ptr: this.ptr };

            // ഡാറ്റ മോഷ്ടിക്കാൻ കഴിയും, അവശേഷിക്കുന്നത് ദുർബലമാണ്
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // ഞങ്ങൾ‌ഏതെങ്കിലും തരത്തിലുള്ള ഏക റഫറൻ‌സായിരുന്നു;ശക്തമായ റഫർ എണ്ണം ബാക്കപ്പ് ചെയ്യുക.
            //
            this.inner().strong.store(1, Release);
        }

        // `get_mut()` പോലെ, സുരക്ഷിതമല്ലാത്തത് ശരിയാണ്, കാരണം ഞങ്ങളുടെ റഫറൻസ് ആരംഭിക്കുന്നത് അദ്വിതീയമായിരുന്നു, അല്ലെങ്കിൽ ഉള്ളടക്കങ്ങൾ ക്ലോൺ ചെയ്യുന്ന ഒന്നായി മാറി.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// ഒരേ അലോക്കേഷനിൽ മറ്റ് `Arc` അല്ലെങ്കിൽ [`Weak`] പോയിന്ററുകൾ ഇല്ലെങ്കിൽ, നൽകിയ `Arc`-ലേക്ക് ഒരു മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു.
    ///
    ///
    /// പങ്കിട്ട മൂല്യം പരിവർത്തനം ചെയ്യുന്നത് സുരക്ഷിതമല്ലാത്തതിനാൽ [`None`] അല്ലാത്തപക്ഷം നൽകുന്നു.
    ///
    /// [`make_mut`][make_mut] ഉം കാണുക, മറ്റ് പോയിന്ററുകൾ ഉള്ളപ്പോൾ ആന്തരിക മൂല്യം [`clone`][clone] ചെയ്യും.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // ഈ സുരക്ഷിതത്വം കുഴപ്പമില്ല, കാരണം മടങ്ങിയെത്തിയ പോയിന്റർ ടിയിലേക്ക് മടങ്ങിയെത്തുന്ന *മാത്രം* പോയിന്റർ ആണെന്ന് ഞങ്ങൾക്ക് ഉറപ്പുണ്ട്.
            // ഞങ്ങളുടെ റഫറൻസ് എണ്ണം ഈ സമയത്ത് 1 ആയിരിക്കുമെന്ന് ഉറപ്പുനൽകുന്നു, കൂടാതെ ആർക്ക് തന്നെ `mut` ആയിരിക്കണമെന്ന് ഞങ്ങൾ ആവശ്യപ്പെടുന്നു, അതിനാൽ ഞങ്ങൾ ആന്തരിക ഡാറ്റയിലേക്ക് സാധ്യമായ ഒരേയൊരു റഫറൻസ് നൽകുന്നു.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// ഒരു പരിശോധനയും കൂടാതെ, നൽകിയ `Arc`-ലേക്ക് ഒരു മ്യൂട്ടബിൾ റഫറൻസ് നൽകുന്നു.
    ///
    /// [`get_mut`] ഉം കാണുക, അത് സുരക്ഷിതവും ഉചിതമായ പരിശോധനകളും നടത്തുന്നു.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// ഒരേ അലോക്കേഷനിലേക്കുള്ള മറ്റേതെങ്കിലും `Arc` അല്ലെങ്കിൽ [`Weak`] പോയിന്ററുകൾ മടക്കിനൽകിയ വായ്പയുടെ കാലാവധിക്കായി വ്യക്തമാക്കരുത്.
    ///
    /// അത്തരം പോയിന്ററുകളൊന്നും നിലവിലില്ലെങ്കിൽ ഇത് വളരെ തുച്ഛമാണ്, ഉദാഹരണത്തിന് `Arc::new`-ന് ശേഷം.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // "count" ഫീൽഡുകൾ ഉൾക്കൊള്ളുന്ന ഒരു റഫറൻസ് * സൃഷ്ടിക്കാതിരിക്കാൻ ഞങ്ങൾ ശ്രദ്ധാലുക്കളാണ്, കാരണം ഇത് റഫറൻസ് എണ്ണങ്ങളിലേക്ക് ഒരേസമയം ആക്‌സസ് ചെയ്യുന്ന അപരനാമമാണ് (ഉദാ.
        // `Weak` പ്രകാരം)
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// അടിസ്ഥാന ഡാറ്റയിലേക്കുള്ള അദ്വിതീയ റഫറൻസാണോ ഇത് (ദുർബലമായ റഫുകൾ ഉൾപ്പെടെ) നിർണ്ണയിക്കുക.
    ///
    ///
    /// ഇതിന് ദുർബലമായ റഫർ എണ്ണം ലോക്കുചെയ്യേണ്ടതുണ്ട്.
    fn is_unique(&mut self) -> bool {
        // ഞങ്ങൾ ഏക ദുർബലമായ പോയിന്റർ ഹോൾഡർ ആണെന്ന് തോന്നുകയാണെങ്കിൽ ദുർബലമായ പോയിന്റർ എണ്ണം ലോക്ക് ചെയ്യുക.
        //
        // `weak` എണ്ണം കുറയുന്നതിന് മുമ്പായി (റിലീസ് ഉപയോഗിക്കുന്ന `Weak::drop` വഴി) `strong`-ലേക്ക് (പ്രത്യേകിച്ച് `Weak::upgrade`-ൽ) ഏതെങ്കിലും റൈറ്റുകളുമായുള്ള ബന്ധം സംഭവിക്കുന്നത് ഇവിടെ ഏറ്റെടുക്കൽ ലേബൽ ഉറപ്പാക്കുന്നു.
        // അപ്‌ഗ്രേഡുചെയ്‌ത ദുർബലമായ റഫർ ഒരിക്കലും ഒഴിവാക്കിയില്ലെങ്കിൽ, ഇവിടെയുള്ള CAS പരാജയപ്പെടും അതിനാൽ സമന്വയിപ്പിക്കാൻ ഞങ്ങൾ ശ്രദ്ധിക്കുന്നില്ല.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // `drop`-ലെ `strong` ക counter ണ്ടറിന്റെ കുറവുമായി സമന്വയിപ്പിക്കുന്നതിന് ഇത് ഒരു `Acquire` ആയിരിക്കണം-അവസാന റഫറൻസ് ഒഴികെ മറ്റെന്തെങ്കിലും സംഭവിക്കുമ്പോൾ സംഭവിക്കുന്ന ഒരേയൊരു ആക്സസ്.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // ഇവിടെ റിലീസ് റൈറ്റ് `downgrade`-ലെ ഒരു വായനയുമായി സമന്വയിപ്പിക്കുന്നു, ഇത് `strong` ന്റെ മുകളിലുള്ള വായന റൈറ്റിന് ശേഷം സംഭവിക്കുന്നത് തടയുന്നു.
            //
            //
            self.inner().weak.store(1, Release); // ലോക്ക് വിടുക
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// `Arc` ഡ്രോപ്പ് ചെയ്യുന്നു.
    ///
    /// ഇത് ശക്തമായ റഫറൻസ് എണ്ണം കുറയ്ക്കും.
    /// ശക്തമായ റഫറൻസ് എണ്ണം പൂജ്യത്തിലെത്തിയാൽ മറ്റ് റഫറൻസുകൾ (എന്തെങ്കിലും ഉണ്ടെങ്കിൽ) [`Weak`] മാത്രമാണ്, അതിനാൽ ഞങ്ങൾ ആന്തരിക മൂല്യം `drop` ആണ്.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // ഒന്നും അച്ചടിക്കുന്നില്ല
    /// drop(foo2);   // "dropped!" പ്രിന്റുകൾ
    /// ```
    #[inline]
    fn drop(&mut self) {
        // `fetch_sub` ഇതിനകം ആറ്റോമിക് ആയതിനാൽ, ഒബ്ജക്റ്റ് ഇല്ലാതാക്കാൻ പോകുന്നില്ലെങ്കിൽ മറ്റ് ത്രെഡുകളുമായി സമന്വയിപ്പിക്കേണ്ട ആവശ്യമില്ല.
        // ഇതേ യുക്തി `fetch_sub`-ന് താഴെയുള്ള `fetch_sub`-നും `weak` എണ്ണത്തിനും ബാധകമാണ്.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // ഡാറ്റയുടെ പുന ord ക്രമീകരണം തടയുന്നതിനും ഡാറ്റ ഇല്ലാതാക്കുന്നതിനും ഈ വേലി ആവശ്യമാണ്.
        // ഇത് `Release` എന്ന് അടയാളപ്പെടുത്തിയിരിക്കുന്നതിനാൽ, റഫറൻസ് എണ്ണത്തിന്റെ കുറവ് ഈ `Acquire` വേലിയുമായി സമന്വയിപ്പിക്കുന്നു.
        // ഇതിനർത്ഥം ഡാറ്റയുടെ ഉപയോഗം റഫറൻസ് എണ്ണം കുറയ്ക്കുന്നതിന് മുമ്പ് സംഭവിക്കുന്നു, ഇത് ഈ വേലിക്ക് മുമ്പായി സംഭവിക്കുന്നു, ഇത് ഡാറ്റ ഇല്ലാതാക്കുന്നതിന് മുമ്പ് സംഭവിക്കുന്നു.
        //
        // [Boost documentation][1]-ൽ വിശദീകരിച്ചതുപോലെ,
        //
        // > ഒബ്‌ജക്റ്റിലേക്ക് സാധ്യമായ ഏതൊരു ആക്‌സസ്സും ഒന്നിൽ നടപ്പിലാക്കേണ്ടത് പ്രധാനമാണ്
        // > *ഇല്ലാതാക്കുന്നതിനുമുമ്പ്* സംഭവിക്കുന്നതിന് ത്രെഡ് (നിലവിലുള്ള റഫറൻസിലൂടെ)
        // > മറ്റൊരു ത്രെഡിലുള്ള ഒബ്‌ജക്റ്റ്.ഒരു "release" ആണ് ഇത് നേടുന്നത്
        // > ഒരു റഫറൻസ് ഉപേക്ഷിച്ചതിന് ശേഷമുള്ള പ്രവർത്തനം (ഒബ്‌ജക്റ്റിലേക്കുള്ള ഏതെങ്കിലും ആക്‌സസ്സ്
        // > ഈ റഫറൻസിലൂടെ വ്യക്തമായും മുമ്പ് സംഭവിച്ചിരിക്കണം), ഒരു
        // > "acquire" ഒബ്‌ജക്റ്റ് ഇല്ലാതാക്കുന്നതിനുമുമ്പ് പ്രവർത്തനം.
        //
        // പ്രത്യേകിച്ചും, ഒരു ആർക്കിലെ ഉള്ളടക്കങ്ങൾ സാധാരണയായി മാറ്റമില്ലാത്തവയാണെങ്കിലും, ഒരു മ്യൂട്ടക്സ് പോലെയുള്ളവയിലേക്ക് ഇന്റീരിയർ എഴുതാൻ സാധ്യതയുണ്ട്<T>.
        // ഒരു മ്യൂട്ടക്സ് ഇല്ലാതാക്കുമ്പോൾ അത് നേടിയെടുക്കാത്തതിനാൽ, ത്രെഡിൽ റൈറ്റുകൾ നിർമ്മിക്കുന്നതിന് അതിന്റെ സമന്വയ യുക്തിയെ ആശ്രയിക്കാൻ ഞങ്ങൾക്ക് കഴിയില്ല. ത്രെഡ് ബിയിൽ പ്രവർത്തിക്കുന്ന ഒരു ഡിസ്ട്രക്റ്ററിന് ദൃശ്യമാണ്.
        //
        //
        // ഇവിടെയുള്ള അക്വയർ വേലിക്ക് ഒരു അക്വയർ ലോഡ് ഉപയോഗിച്ച് മാറ്റിസ്ഥാപിക്കാമെന്നതും ശ്രദ്ധിക്കുക, ഇത് ഉയർന്ന മത്സര സാഹചര്യങ്ങളിൽ പ്രകടനം മെച്ചപ്പെടുത്തും.[2] കാണുക.
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// `Arc<dyn Any + Send + Sync>` ഒരു കോൺക്രീറ്റ് തരത്തിലേക്ക് തരംതാഴ്ത്താനുള്ള ശ്രമം.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// മെമ്മറി അനുവദിക്കാതെ ഒരു പുതിയ `Weak<T>` നിർമ്മിക്കുന്നു.
    /// റിട്ടേൺ മൂല്യത്തിൽ [`upgrade`] എന്ന് വിളിക്കുന്നത് എല്ലായ്പ്പോഴും [`None`] നൽകുന്നു.
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// ഡാറ്റാ ഫീൽഡിനെക്കുറിച്ച് ഒരു അവകാശവാദവും നടത്താതെ റഫറൻസ് എണ്ണങ്ങൾ ആക്‌സസ്സുചെയ്യാൻ അനുവദിക്കുന്നതിനുള്ള സഹായ തരം.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// ഈ `Weak<T>` ചൂണ്ടിക്കാണിച്ച `T` ഒബ്‌ജക്റ്റിലേക്ക് ഒരു റോ പോയിന്റർ നൽകുന്നു.
    ///
    /// ശക്തമായ ചില റഫറൻ‌സുകൾ‌ഉണ്ടെങ്കിൽ‌മാത്രമേ പോയിന്റർ‌സാധുതയുള്ളൂ.
    /// പോയിന്റർ തൂങ്ങിക്കിടക്കുന്നതോ ക്രമീകരിക്കാത്തതോ [`null`] അല്ലാത്തതോ ആകാം.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // രണ്ടും ഒരേ വസ്തുവിലേക്ക് വിരൽ ചൂണ്ടുന്നു
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // ഇവിടെയുള്ളവർ അതിനെ സജീവമായി നിലനിർത്തുന്നു, അതിനാൽ നമുക്ക് ഇപ്പോഴും ഒബ്‌ജക്റ്റ് ആക്‌സസ്സുചെയ്യാനാകും.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // പക്ഷേ ഇനിയില്ല.
    /// // ഞങ്ങൾക്ക് weak.as_ptr() ചെയ്യാൻ കഴിയും, പക്ഷേ പോയിന്റർ ആക്സസ് ചെയ്യുന്നത് നിർവചിക്കപ്പെടാത്ത സ്വഭാവത്തിലേക്ക് നയിക്കും.
    /// // assert_eq! ("ഹലോ", സുരക്ഷിതമല്ലാത്ത {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // പോയിന്റർ തൂങ്ങിക്കിടക്കുകയാണെങ്കിൽ, ഞങ്ങൾ സെന്റിനൽ നേരിട്ട് നൽകുന്നു.
            // പേലോഡ് ആർക്ക്ഇന്നർ എക്സ് 00 എക്സ് പോലെ വിന്യസിച്ചിരിക്കുന്നതിനാൽ ഇത് സാധുവായ പേലോഡ് വിലാസമായിരിക്കരുത്.
            ptr as *const T
        } else {
            // സുരക്ഷിതം: is_dangling തെറ്റാണെങ്കിൽ, പോയിന്റർ ഒഴിവാക്കാനാവില്ല.
            // ഈ സമയത്ത് പേലോഡ് ഉപേക്ഷിക്കാം, ഞങ്ങൾ തെളിവ് നിലനിർത്തേണ്ടതുണ്ട്, അതിനാൽ റോ പോയിന്റർ കൃത്രിമത്വം ഉപയോഗിക്കുക.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// `Weak<T>` ഉപയോഗിക്കുകയും അസംസ്കൃത പോയിന്ററായി മാറ്റുകയും ചെയ്യുന്നു.
    ///
    /// ഒരു ദുർബലമായ റഫറൻസിന്റെ ഉടമസ്ഥാവകാശം കാത്തുസൂക്ഷിക്കുന്നതിനിടയിൽ ഇത് ദുർബലമായ പോയിന്ററിനെ ഒരു അസംസ്കൃത പോയിന്ററായി പരിവർത്തനം ചെയ്യുന്നു (ദുർബലമായ എണ്ണം ഈ പ്രവർത്തനത്തിലൂടെ പരിഷ്‌ക്കരിക്കില്ല).
    /// ഇത് [`from_raw`] ഉപയോഗിച്ച് `Weak<T>` ലേക്ക് തിരികെ മാറ്റാൻ കഴിയും.
    ///
    /// [`as_ptr`] പോലെ പോയിന്ററിന്റെ ടാർഗെറ്റ് ആക്‌സസ് ചെയ്യുന്നതിനുള്ള അതേ നിയന്ത്രണങ്ങൾ ബാധകമാണ്.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// മുമ്പ് [`into_raw`] സൃഷ്ടിച്ച ഒരു റോ പോയിന്റർ `Weak<T>` ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// സുരക്ഷിതമായ ഒരു റഫറൻസ് നേടുന്നതിനോ (പിന്നീട് [`upgrade`] വിളിക്കുന്നതിലൂടെ) അല്ലെങ്കിൽ `Weak<T>` ഉപേക്ഷിച്ച് ദുർബലമായ എണ്ണം ഇല്ലാതാക്കുന്നതിനോ ഇത് ഉപയോഗിക്കാം.
    ///
    /// ഇത് ഒരു ദുർബലമായ റഫറൻസിന്റെ ഉടമസ്ഥാവകാശം എടുക്കുന്നു ([`new`] സൃഷ്ടിച്ച പോയിന്ററുകൾ ഒഴികെ, ഇവയൊന്നും സ്വന്തമല്ലാത്തതിനാൽ; രീതി ഇപ്പോഴും അവയിൽ പ്രവർത്തിക്കുന്നു).
    ///
    /// # Safety
    ///
    /// പോയിന്റർ [`into_raw`]-ൽ നിന്ന് ഉത്ഭവിച്ചിരിക്കണം, ഇപ്പോഴും അതിന്റെ ദുർബലമായ റഫറൻസ് സ്വന്തമാക്കിയിരിക്കണം.
    ///
    /// ഇത് വിളിക്കുമ്പോൾ ശക്തമായ എണ്ണം 0 ആയിരിക്കാൻ അനുവദിച്ചിരിക്കുന്നു.
    /// എന്നിരുന്നാലും, ഇത് നിലവിൽ ഒരു അസംസ്കൃത പോയിന്ററായി പ്രതിനിധീകരിക്കുന്ന ഒരു ദുർബലമായ റഫറൻസിന്റെ ഉടമസ്ഥാവകാശം എടുക്കുന്നു (ഈ പ്രവർത്തനം ദുർബലമായ എണ്ണം പരിഷ്‌ക്കരിച്ചിട്ടില്ല), അതിനാൽ ഇത് [`into_raw`]-ലേക്ക് മുമ്പത്തെ കോളുമായി ജോടിയാക്കണം.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // അവസാനത്തെ ദുർബലമായ എണ്ണം കുറയ്‌ക്കുക.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // ഇൻപുട്ട് പോയിന്റർ എങ്ങനെ ഉത്ഭവിച്ചു എന്നതിനെക്കുറിച്ചുള്ള സന്ദർഭത്തിനായി Weak::as_ptr കാണുക.

        let ptr = if is_dangling(ptr as *mut T) {
            // ഇത് ദുർബലമായ ദുർബലമാണ്.
            ptr as *mut ArcInner<T>
        } else {
            // അല്ലാത്തപക്ഷം, പോയിന്റർ ഒരു ദുർബലമായ ദുർബലത്തിൽ നിന്നാണെന്ന് ഞങ്ങൾക്ക് ഉറപ്പുണ്ട്.
            // സുരക്ഷ: ഡാറ്റാ_ഓഫ്സെറ്റ് വിളിക്കുന്നത് സുരക്ഷിതമാണ്, കാരണം പി‌ടി‌ആർ ഒരു യഥാർത്ഥ (ഉപേക്ഷിക്കാൻ സാധ്യതയുള്ള) ടി.
            let offset = unsafe { data_offset(ptr) };
            // അങ്ങനെ, മുഴുവൻ ആർ‌സിബോക്സും ലഭിക്കുന്നതിന് ഞങ്ങൾ ഓഫ്‌സെറ്റ് തിരിച്ചിടുന്നു.
            // സുരക്ഷ: പോയിന്റർ ദുർബലമായതിൽ നിന്നാണ് ഉത്ഭവിച്ചത്, അതിനാൽ ഈ ഓഫ്‌സെറ്റ് സുരക്ഷിതമാണ്.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // സുരക്ഷ: ഞങ്ങൾ ഇപ്പോൾ യഥാർത്ഥ ദുർബല പോയിന്റർ വീണ്ടെടുത്തു, അതിനാൽ ദുർബലമായത് സൃഷ്ടിക്കാൻ കഴിയും.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// `Weak` പോയിന്റർ ഒരു [`Arc`]-ലേക്ക് അപ്‌ഗ്രേഡുചെയ്യാനുള്ള ശ്രമം, വിജയിച്ചാൽ ആന്തരിക മൂല്യം ഉപേക്ഷിക്കുന്നത് കാലതാമസം വരുത്തുന്നു.
    ///
    ///
    /// ആന്തരിക മൂല്യം ഉപേക്ഷിച്ചിട്ടുണ്ടെങ്കിൽ [`None`] നൽകുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // എല്ലാ ശക്തമായ പോയിന്ററുകളും നശിപ്പിക്കുക.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // ഒരു ഫെച്ച്_അഡിനുപകരം ശക്തമായ എണ്ണം വർദ്ധിപ്പിക്കുന്നതിന് ഞങ്ങൾ ഒരു സി‌എ‌എസ് ലൂപ്പ് ഉപയോഗിക്കുന്നു, കാരണം ഈ ഫംഗ്ഷൻ ഒരിക്കലും റഫറൻസ് എണ്ണം പൂജ്യത്തിൽ നിന്ന് ഒന്നിലേക്ക് എടുക്കരുത്.
        //
        //
        let inner = self.inner()?;

        // വിശ്രമിക്കുന്ന ലോഡ് കാരണം നമുക്ക് നിരീക്ഷിക്കാൻ കഴിയുന്ന 0 ന്റെ ഏതെങ്കിലും എഴുത്ത് ഫീൽഡ് ശാശ്വതമായി പൂജ്യാവസ്ഥയിൽ ഉപേക്ഷിക്കുന്നു (അതിനാൽ 0 ന്റെ "stale" റീഡ് മികച്ചതാണ്), മറ്റേതെങ്കിലും മൂല്യം ചുവടെയുള്ള CAS വഴി സ്ഥിരീകരിക്കുന്നു.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // എന്തുകൊണ്ടാണ് ഞങ്ങൾ ഇത് ചെയ്യുന്നതെന്ന് `Arc::clone`-ലെ അഭിപ്രായങ്ങൾ കാണുക (`mem::forget`-ന്).
            if n > MAX_REFCOUNT {
                abort();
            }

            // പരാജയപ്പെട്ട കേസിൽ വിശ്രമിക്കുന്നത് നല്ലതാണ്, കാരണം പുതിയ സംസ്ഥാനത്തെക്കുറിച്ച് ഞങ്ങൾക്ക് പ്രതീക്ഷകളൊന്നുമില്ല.
            // `Weak` റഫറൻസുകൾ ഇതിനകം സൃഷ്ടിച്ചതിനുശേഷം ആന്തരിക മൂല്യം സമാരംഭിക്കാൻ കഴിയുമ്പോൾ, വിജയ കേസ് `Arc::new_cyclic`-മായി സമന്വയിപ്പിക്കുന്നതിന് ഏറ്റെടുക്കൽ ആവശ്യമാണ്.
            // അത്തരം സന്ദർഭങ്ങളിൽ, പൂർണ്ണമായും സമാരംഭിച്ച മൂല്യം നിരീക്ഷിക്കുമെന്ന് ഞങ്ങൾ പ്രതീക്ഷിക്കുന്നു.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // മുകളിൽ പരിശോധിച്ചത് ശൂന്യമാണ്
                Err(old) => n = old,
            }
        }
    }

    /// ഈ അലോക്കേഷനിൽ പോയിന്റുചെയ്യുന്ന ശക്തമായ (`Arc`) പോയിന്ററുകളുടെ എണ്ണം നേടുന്നു.
    ///
    /// [`Weak::new`] ഉപയോഗിച്ച് `self` സൃഷ്ടിച്ചിട്ടുണ്ടെങ്കിൽ, ഇത് 0 നൽകും.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// ഈ അലോക്കേഷനിലേക്ക് പോയിന്റുചെയ്യുന്ന `Weak` പോയിന്ററുകളുടെ എണ്ണത്തിന്റെ ഏകദേശ രൂപം നേടുന്നു.
    ///
    /// [`Weak::new`] ഉപയോഗിച്ചാണ് `self` സൃഷ്ടിച്ചതെങ്കിൽ, അല്ലെങ്കിൽ ശക്തമായ പോയിന്ററുകൾ അവശേഷിക്കുന്നില്ലെങ്കിൽ, ഇത് 0 നൽകും.
    ///
    /// # Accuracy
    ///
    /// നടപ്പിലാക്കൽ വിശദാംശങ്ങൾ കാരണം, മറ്റ് ത്രെഡുകൾ ഏതെങ്കിലും `ആർക്ക് 'അല്ലെങ്കിൽ` ദുർബല'ങ്ങൾ ഒരേ അലോക്കേഷനിൽ ചൂണ്ടിക്കാണിക്കുമ്പോൾ മറ്റ് ദിശകൾ ഒരു ദിശയിലും 1 ആയി ഓഫ് ചെയ്യാം.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // ദുർബലമായ എണ്ണം വായിച്ചതിനുശേഷം കുറഞ്ഞത് ഒരു ശക്തമായ പോയിന്ററെങ്കിലും ഉണ്ടെന്ന് ഞങ്ങൾ നിരീക്ഷിച്ചതിനാൽ, ദുർബലമായ എണ്ണം ഞങ്ങൾ നിരീക്ഷിക്കുമ്പോൾ വ്യക്തമായ ദുർബലമായ റഫറൻസ് (ഏതെങ്കിലും ശക്തമായ റഫറൻസുകൾ സജീവമാകുമ്പോഴെല്ലാം നിലവിലുണ്ട്) ഞങ്ങൾക്കറിയാം, അതിനാൽ സുരക്ഷിതമായി കുറയ്ക്കാൻ കഴിയും.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// പോയിന്റർ തൂങ്ങിക്കിടക്കുമ്പോൾ അനുവദിച്ച `ArcInner` ഇല്ലാത്തപ്പോൾ `None` നൽകുന്നു, (അതായത്, ഈ `Weak` `Weak::new` സൃഷ്ടിച്ചപ്പോൾ).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // ഫീൽഡ് ഒരേസമയം പരിവർത്തനം ചെയ്യപ്പെടുന്നതിനാൽ "data" ഫീൽഡിനെ ഉൾക്കൊള്ളുന്ന ഒരു റഫറൻസ് * സൃഷ്ടിക്കാതിരിക്കാൻ ഞങ്ങൾ ശ്രദ്ധാലുവാണ് (ഉദാഹരണത്തിന്, അവസാന `Arc` ഉപേക്ഷിക്കുകയാണെങ്കിൽ, ഡാറ്റ ഫീൽഡ് സ്ഥലത്ത് തന്നെ ഉപേക്ഷിക്കപ്പെടും).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// രണ്ട് `ദുർബല'ങ്ങളും ഒരേ അലോക്കേഷനിലേക്കാണ് ([`ptr::eq`] ന് സമാനമായത്) പോയിന്റ് ചെയ്യുന്നതെങ്കിലോ അല്ലെങ്കിൽ രണ്ടും ഏതെങ്കിലും അലോക്കേഷനിലേക്ക് വിരൽ ചൂണ്ടുന്നില്ലെങ്കിലോ `true` നൽകുന്നു (കാരണം അവ `Weak::new()`) ഉപയോഗിച്ചാണ് സൃഷ്ടിച്ചത്.
    ///
    ///
    /// # Notes
    ///
    /// ഇത് പോയിന്ററുകളെ താരതമ്യപ്പെടുത്തുന്നതിനാൽ `Weak::new()` പരസ്പരം തുല്യമാകുമെന്നാണ് ഇതിനർത്ഥം, അവ ഏതെങ്കിലും വിഹിതത്തിലേക്ക് വിരൽ ചൂണ്ടുന്നില്ലെങ്കിലും.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// `Weak::new` താരതമ്യം ചെയ്യുന്നു.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// ഒരേ അലോക്കേഷനിലേക്ക് പോയിന്റുചെയ്യുന്ന `Weak` പോയിന്ററിന്റെ ഒരു ക്ലോൺ നിർമ്മിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // എന്തുകൊണ്ടാണ് ഇത് അയവുള്ളതെന്ന് Arc::clone()-ലെ അഭിപ്രായങ്ങൾ കാണുക.
        // ഇതിന് ഒരു ഫെച്ച്_അഡ് (ലോക്ക് അവഗണിച്ച്) ഉപയോഗിക്കാം, കാരണം ദുർബലമായ എണ്ണം ലോക്ക് ചെയ്തിട്ടുള്ളിടത്ത് മാത്രമേ *മറ്റ്* ദുർബലമായ പോയിന്ററുകൾ നിലവിലില്ല.
        //
        // (അതിനാൽ ഈ സാഹചര്യത്തിൽ ഞങ്ങൾക്ക് ഈ കോഡ് പ്രവർത്തിപ്പിക്കാൻ കഴിയില്ല).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // എന്തുകൊണ്ടാണ് ഞങ്ങൾ ഇത് ചെയ്യുന്നതെന്ന് Arc::clone()-ലെ അഭിപ്രായങ്ങൾ കാണുക (mem::forget-ന്).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// മെമ്മറി അനുവദിക്കാതെ ഒരു പുതിയ `Weak<T>` നിർമ്മിക്കുന്നു.
    /// റിട്ടേൺ മൂല്യത്തിൽ [`upgrade`] എന്ന് വിളിക്കുന്നത് എല്ലായ്പ്പോഴും [`None`] നൽകുന്നു.
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// `Weak` പോയിന്റർ ഉപേക്ഷിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // ഒന്നും അച്ചടിക്കുന്നില്ല
    /// drop(foo);        // "dropped!" പ്രിന്റുകൾ
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // ഞങ്ങൾ അവസാനത്തെ ദുർബലമായ പോയിന്ററാണെന്ന് കണ്ടെത്തിയാൽ, ഡാറ്റ പൂർണ്ണമായും ഡീലോക്കേറ്റ് ചെയ്യാനുള്ള സമയമായി.മെമ്മറി ഓർഡറിംഗുകളെക്കുറിച്ച് Arc::drop()-ലെ ചർച്ച കാണുക
        //
        // ഇവിടെ ലോക്ക് ചെയ്ത അവസ്ഥ പരിശോധിക്കേണ്ട ആവശ്യമില്ല, കാരണം കൃത്യമായി ഒരു ദുർബലമായ റഫർ ഉണ്ടെങ്കിൽ മാത്രമേ ദുർബലമായ എണ്ണം ലോക്ക് ചെയ്യാൻ കഴിയൂ, അതായത് ഡ്രോപ്പ് പിന്നീട് ശേഷിക്കുന്ന ദുർബലമായ റഫിൽ മാത്രമേ പ്രവർത്തിക്കൂ, അതായത് ലോക്ക് പുറത്തിറങ്ങിയതിനുശേഷം മാത്രമേ ഇത് സംഭവിക്കൂ.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// ഞങ്ങൾ ഇവിടെ ഈ സ്പെഷ്യലൈസേഷൻ ചെയ്യുന്നു, `&T`-ലെ പൊതുവായ ഒപ്റ്റിമൈസേഷനായിട്ടല്ല, കാരണം ഇത് റഫറുകളിലെ എല്ലാ തുല്യതാ പരിശോധനകൾക്കും ചിലവ് നൽകും.
/// വലിയ മൂല്യങ്ങൾ സംഭരിക്കാൻ `ആർക്ക് 'ഉപയോഗിക്കുന്നുവെന്ന് ഞങ്ങൾ അനുമാനിക്കുന്നു, അവ ക്ലോൺ ചെയ്യാൻ മന്ദഗതിയിലാണ്, എന്നാൽ തുല്യത പരിശോധിക്കുന്നതിനുള്ള ഭാരവുമാണ്, ഈ ചെലവ് കൂടുതൽ എളുപ്പത്തിൽ അടയ്ക്കാൻ കാരണമാകുന്നു.
///
/// രണ്ട് `&ടി`കളേക്കാൾ ഒരേ മൂല്യത്തിലേക്ക് പോയിന്റുചെയ്യുന്ന രണ്ട് `Arc` ക്ലോണുകൾ ഉണ്ടാകാനുള്ള സാധ്യതയും കൂടുതലാണ്.
///
/// `PartialEq` ആയി `T: Eq` മന ib പൂർവ്വം പരിഹരിക്കാനാവാത്തതാണെങ്കിൽ മാത്രമേ ഞങ്ങൾക്ക് ഇത് ചെയ്യാൻ കഴിയൂ.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// രണ്ട് `ആർക്ക്` കൾക്ക് തുല്യത.
    ///
    /// വ്യത്യസ്ത വിഹിതത്തിൽ സംഭരിച്ചിട്ടുണ്ടെങ്കിലും അവയുടെ ആന്തരിക മൂല്യങ്ങൾ തുല്യമാണെങ്കിൽ രണ്ട് `ആർക്ക് 'തുല്യമാണ്.
    ///
    /// `T` ഉം `Eq` നടപ്പിലാക്കുകയാണെങ്കിൽ (സമത്വത്തിന്റെ റിഫ്ലെക്സിറ്റിവിറ്റി സൂചിപ്പിക്കുന്നു), ഒരേ അലോക്കേഷനിലേക്ക് വിരൽ ചൂണ്ടുന്ന രണ്ട് `ആർക്ക് 'എല്ലായ്പ്പോഴും തുല്യമാണ്.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// രണ്ട് `ആർക്ക്'കളുടെ അസമത്വം.
    ///
    /// ആന്തരിക മൂല്യങ്ങൾ അസമമാണെങ്കിൽ രണ്ട് `ആർക്ക്'കൾ സമാനമല്ല.
    ///
    /// `T` ഉം `Eq` നടപ്പിലാക്കുകയാണെങ്കിൽ (സമത്വത്തിന്റെ റിഫ്ലെക്സിറ്റിവിറ്റി സൂചിപ്പിക്കുന്നു), ഒരേ മൂല്യത്തിലേക്ക് വിരൽ ചൂണ്ടുന്ന രണ്ട് `ആർക്ക് 'ഒരിക്കലും അസമമല്ല.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// രണ്ട് `ആർക്ക്'കൾക്കുള്ള ഭാഗിക താരതമ്യം.
    ///
    /// ആന്തരിക മൂല്യങ്ങളിൽ `partial_cmp()` എന്ന് വിളിച്ചാണ് ഇവ രണ്ടും താരതമ്യം ചെയ്യുന്നത്.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// രണ്ട് `ആർക്ക്'കളുമായി താരതമ്യപ്പെടുത്തുന്നതിനേക്കാൾ കുറവാണ്.
    ///
    /// ആന്തരിക മൂല്യങ്ങളിൽ `<` എന്ന് വിളിച്ചാണ് ഇവ രണ്ടും താരതമ്യം ചെയ്യുന്നത്.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// രണ്ട് `ആർക്ക്'കളുമായി താരതമ്യപ്പെടുത്തുന്നതിനേക്കാൾ 'തുല്യമോ തുല്യമോ'.
    ///
    /// ആന്തരിക മൂല്യങ്ങളിൽ `<=` എന്ന് വിളിച്ചാണ് ഇവ രണ്ടും താരതമ്യം ചെയ്യുന്നത്.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// രണ്ട് `ആർക്ക്'കളുമായി താരതമ്യപ്പെടുത്തുന്നതിനേക്കാൾ വലുത്.
    ///
    /// ആന്തരിക മൂല്യങ്ങളിൽ `>` എന്ന് വിളിച്ചാണ് ഇവ രണ്ടും താരതമ്യം ചെയ്യുന്നത്.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// രണ്ട് `ആർക്ക്'കളുമായി താരതമ്യപ്പെടുത്തുന്നതിനേക്കാൾ 'വലുതോ തുല്യമോ'.
    ///
    /// ആന്തരിക മൂല്യങ്ങളിൽ `>=` എന്ന് വിളിച്ചാണ് ഇവ രണ്ടും താരതമ്യം ചെയ്യുന്നത്.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// രണ്ട് `ആർക്ക്` കൾക്കുള്ള താരതമ്യം.
    ///
    /// ആന്തരിക മൂല്യങ്ങളിൽ `cmp()` എന്ന് വിളിച്ചാണ് ഇവ രണ്ടും താരതമ്യം ചെയ്യുന്നത്.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// `T`-നായി `Default` മൂല്യം ഉപയോഗിച്ച് ഒരു പുതിയ `Arc<T>` സൃഷ്ടിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// ഒരു റഫറൻസ് കണക്കാക്കിയ സ്ലൈസ് അനുവദിച്ച് `v` ന്റെ ഇനങ്ങൾ ക്ലോൺ ചെയ്തുകൊണ്ട് പൂരിപ്പിക്കുക.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// ഒരു റഫറൻസ് കണക്കാക്കിയ `str` അനുവദിക്കുകയും അതിലേക്ക് `v` പകർത്തുകയും ചെയ്യുക.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// ഒരു റഫറൻസ് കണക്കാക്കിയ `str` അനുവദിക്കുകയും അതിലേക്ക് `v` പകർത്തുകയും ചെയ്യുക.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// ഒരു ബോക്‍സ്ഡ് ഒബ്‌ജക്റ്റ് പുതിയതും റഫറൻസ് കണക്കാക്കിയതുമായ അലോക്കേഷനിലേക്ക് നീക്കുക.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// ഒരു റഫറൻസ് കണക്കാക്കിയ സ്ലൈസ് അനുവദിച്ച് അതിലേക്ക് `v` ന്റെ ഇനങ്ങൾ നീക്കുക.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // അതിന്റെ മെമ്മറി സ്വതന്ത്രമാക്കാൻ വെക്കിനെ അനുവദിക്കുക, പക്ഷേ അതിലെ ഉള്ളടക്കങ്ങൾ നശിപ്പിക്കരുത്
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// `Iterator`-ലെ ഓരോ ഘടകങ്ങളും എടുത്ത് ഒരു `Arc<[T]>`-ലേക്ക് ശേഖരിക്കുന്നു.
    ///
    /// # പ്രകടന സവിശേഷതകൾ
    ///
    /// ## പൊതുവായ കേസ്
    ///
    /// പൊതുവായ സാഹചര്യത്തിൽ, `Arc<[T]>`-ലേക്ക് ശേഖരിക്കുന്നത് ആദ്യം ഒരു `Vec<T>`-ലേക്ക് ശേഖരിക്കുന്നതിലൂടെയാണ്.അതായത്, ഇനിപ്പറയുന്നവ എഴുതുമ്പോൾ:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ഇത് ഞങ്ങൾ എഴുതിയതുപോലെയാണ് പ്രവർത്തിക്കുന്നത്:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // ആദ്യ സെറ്റ് അലോക്കേഷനുകൾ ഇവിടെ സംഭവിക്കുന്നു.
    ///     .into(); // `Arc<[T]>`-നുള്ള രണ്ടാമത്തെ അലോക്കേഷൻ ഇവിടെ സംഭവിക്കുന്നു.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// ഇത് `Vec<T>` നിർമ്മിക്കുന്നതിന് ആവശ്യമായത്ര തവണ അനുവദിക്കും, തുടർന്ന് `Vec<T>` നെ `Arc<[T]>` ആക്കി മാറ്റുന്നതിന് ഇത് ഒരു തവണ അനുവദിക്കും.
    ///
    ///
    /// ## അറിയപ്പെടുന്ന നീളത്തിന്റെ ആവർത്തനക്കാർ
    ///
    /// നിങ്ങളുടെ `Iterator` `TrustedLen` നടപ്പിലാക്കുകയും കൃത്യമായ വലുപ്പമുള്ളപ്പോൾ, `Arc<[T]>`-നായി ഒരൊറ്റ അലോക്കേഷൻ നടത്തുകയും ചെയ്യും.ഉദാഹരണത്തിന്:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // ഒരൊറ്റ വിഹിതം ഇവിടെ സംഭവിക്കുന്നു.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// എക്സ് 00 എക്സിലേക്ക് ശേഖരിക്കുന്നതിന് സ്പെഷ്യലൈസേഷൻ trait ഉപയോഗിക്കുന്നു.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // ഒരു `TrustedLen` ആവർത്തനത്തിനായുള്ള സ്ഥിതി ഇതാണ്.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // സുരക്ഷ: ഇറ്ററേറ്ററിന് കൃത്യമായ നീളമുണ്ടെന്നും ഞങ്ങൾക്ക് ഉണ്ടെന്നും ഉറപ്പാക്കേണ്ടതുണ്ട്.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // സാധാരണ നടപ്പാക്കലിലേക്ക് മടങ്ങുക.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// ഒരു പോയിന്ററിന് പിന്നിലുള്ള പേലോഡിനായി ഒരു `ArcInner`-നുള്ളിൽ ഓഫ്‌സെറ്റ് നേടുക.
///
/// # Safety
///
/// പോയിന്ററിന്റെ മുമ്പത്തെ സാധുവായ ഒരു ഉദാഹരണത്തിലേക്ക് പോയിന്റർ പോയിന്റുചെയ്യണം (ഒപ്പം സാധുവായ മെറ്റാഡാറ്റയും ഉണ്ടായിരിക്കണം), പക്ഷേ ടി ഉപേക്ഷിക്കാൻ അനുവദിച്ചിരിക്കുന്നു.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // വലുപ്പം മാറ്റാത്ത മൂല്യം ആർക്ക്ഇന്നറിന്റെ അവസാനത്തിലേക്ക് വിന്യസിക്കുക.
    // RcBox repr(C) ആയതിനാൽ, ഇത് എല്ലായ്പ്പോഴും മെമ്മറിയിലെ അവസാന ഫീൽഡായിരിക്കും.
    // സുരക്ഷ: വലുപ്പം മാറ്റാത്ത തരം സ്ലൈസുകൾ ആയതിനാൽ, trait ഒബ്ജക്റ്റുകൾ,
    // കൂടാതെ ബാഹ്യ തരങ്ങളും, align_of_val_raw ന്റെ ആവശ്യകതകൾ നിറവേറ്റുന്നതിന് നിലവിൽ ഇൻപുട്ട് സുരക്ഷാ ആവശ്യകത മതി;std ന് പുറത്ത് ആശ്രയിക്കാത്ത ഭാഷയുടെ നടപ്പാക്കൽ വിശദാംശമാണിത്.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}