#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// പുതിയ മെമ്മറിയുടെ ഉള്ളടക്കങ്ങൾ‌ആരംഭിച്ചിട്ടില്ല.
    Uninitialized,
    /// പുതിയ മെമ്മറി പൂജ്യമാകുമെന്ന് ഉറപ്പുനൽകുന്നു.
    Zeroed,
}

/// ഉൾപ്പെട്ടിരിക്കുന്ന എല്ലാ കോർണർ കേസുകളെക്കുറിച്ചും വിഷമിക്കേണ്ടതില്ല, കൂടുതൽ എർണോണോമിക് അലോക്കേഷൻ, റീലോക്കേറ്റ് ചെയ്യൽ, കൂമ്പാരത്തിൽ ഒരു ബഫർ മെമ്മറി ഡീലോക്കേറ്റ് ചെയ്യുന്നതിനുള്ള ഒരു താഴ്ന്ന നിലയിലുള്ള യൂട്ടിലിറ്റി.
///
/// Vec, VecDeque പോലുള്ള നിങ്ങളുടെ സ്വന്തം ഡാറ്റാ ഘടനകൾ നിർമ്മിക്കുന്നതിന് ഈ തരം മികച്ചതാണ്.
/// പ്രത്യേകിച്ച്:
///
/// * പൂജ്യം വലുപ്പത്തിലുള്ള തരങ്ങളിൽ `Unique::dangling()` നിർമ്മിക്കുന്നു.
/// * സീറോ-ലെങ്ത് അലോക്കേഷനിൽ `Unique::dangling()` നിർമ്മിക്കുന്നു.
/// * `Unique::dangling()` സ്വതന്ത്രമാക്കുന്നത് ഒഴിവാക്കുന്നു.
/// * ശേഷി കണക്കുകൂട്ടലുകളിലെ എല്ലാ ഓവർഫ്ലോകളും പിടിക്കുന്നു (അവയെ "capacity overflow" panics ലേക്ക് പ്രമോട്ടുചെയ്യുന്നു).
/// * isize::MAX ബൈറ്റുകളിൽ കൂടുതൽ അനുവദിക്കുന്ന 32-ബിറ്റ് സിസ്റ്റങ്ങൾക്കെതിരായ കാവൽക്കാർ.
/// * നിങ്ങളുടെ ദൈർഘ്യം കവിഞ്ഞൊഴുകുന്നതിനെതിരെ കാവൽ.
/// * തെറ്റായ അലോക്കേഷനുകൾക്കായി `handle_alloc_error`-നെ വിളിക്കുന്നു.
/// * ഒരു `ptr::Unique` അടങ്ങിയിരിക്കുന്നു, അതിനാൽ ഉപയോക്താവിന് ബന്ധപ്പെട്ട എല്ലാ ആനുകൂല്യങ്ങളും നൽകുന്നു.
/// * ലഭ്യമായ ഏറ്റവും വലിയ ശേഷി ഉപയോഗിക്കുന്നതിന് അലോക്കേറ്ററിൽ നിന്ന് ലഭിച്ച അധിക തുക ഉപയോഗിക്കുന്നു.
///
/// ഈ തരം ഏതുവിധേനയും അത് കൈകാര്യം ചെയ്യുന്ന മെമ്മറി പരിശോധിക്കുന്നില്ല.അത് ഉപേക്ഷിക്കുമ്പോൾ *അതിന്റെ മെമ്മറി സ്വതന്ത്രമാക്കും, പക്ഷേ അത്* അതിന്റെ ഉള്ളടക്കങ്ങൾ ഉപേക്ഷിക്കാൻ * ശ്രമിക്കില്ല.
/// ഒരു `RawVec`-നുള്ളിൽ *സംഭരിച്ചിരിക്കുന്ന* യഥാർത്ഥ കാര്യങ്ങൾ കൈകാര്യം ചെയ്യേണ്ടത് `RawVec` ന്റെ ഉപയോക്താവാണ്.
///
/// പൂജ്യ വലുപ്പത്തിലുള്ള തരങ്ങൾ എല്ലായ്പ്പോഴും അനന്തമാണെന്നത് ശ്രദ്ധിക്കുക, അതിനാൽ `capacity()` എല്ലായ്പ്പോഴും `usize::MAX` നൽകുന്നു.
/// `capacity()` ദൈർഘ്യം നൽകാത്തതിനാൽ, `Box<[T]>` ഉപയോഗിച്ച് ഈ തരം റ round ണ്ട്-ട്രിപ്പുചെയ്യുമ്പോൾ നിങ്ങൾ ശ്രദ്ധിക്കേണ്ടതുണ്ട് എന്നാണ് ഇതിനർത്ഥം.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): ഇത് നിലവിലുണ്ട്, കാരണം `#[unstable]` `const fn`-കൾ `min_const_fn`-മായി പൊരുത്തപ്പെടേണ്ടതില്ല, അതിനാൽ അവയെ`min_const_fn`-ലും വിളിക്കാൻ കഴിയില്ല.
    ///
    /// നിങ്ങൾ `RawVec<T>::new` അല്ലെങ്കിൽ ഡിപൻഡൻസികൾ മാറ്റുകയാണെങ്കിൽ, `min_const_fn` യഥാർത്ഥത്തിൽ ലംഘിക്കുന്ന ഒന്നും അവതരിപ്പിക്കാതിരിക്കാൻ ദയവായി ശ്രദ്ധിക്കുക.
    ///
    /// NOTE: ഞങ്ങൾക്ക് ഈ ഹാക്ക് ഒഴിവാക്കാനും ചില `#[rustc_force_min_const_fn]` ആട്രിബ്യൂട്ടുകളുമായുള്ള സ്ഥിരത പരിശോധിക്കാനും കഴിയും, അത് `min_const_fn`-യുമായി സ്ഥിരത ആവശ്യപ്പെടുന്നു, പക്ഷേ `stable(...) const fn` ഉള്ളപ്പോൾ `foo` പ്രവർത്തനക്ഷമമാക്കാത്ത `stable(...) const fn`/യൂസർ കോഡിൽ വിളിക്കാൻ അനുവദിക്കുന്നില്ല.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// അനുവദിക്കാതെ തന്നെ സാധ്യമായ ഏറ്റവും വലിയ `RawVec` (സിസ്റ്റം കൂമ്പാരത്തിൽ) സൃഷ്ടിക്കുന്നു.
    /// `T` ന് പോസിറ്റീവ് വലുപ്പമുണ്ടെങ്കിൽ, ഇത് `0` ശേഷിയുള്ള `RawVec` ആക്കുന്നു.
    /// `T` പൂജ്യ വലുപ്പമാണെങ്കിൽ, അത് `usize::MAX` ശേഷിയുള്ള `RawVec` ഉണ്ടാക്കുന്നു.
    /// കാലതാമസം വരുത്തിയ വിഹിതം നടപ്പിലാക്കാൻ ഉപയോഗപ്രദമാണ്.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// ഒരു `[T; capacity]`-നുള്ള ശേഷിയും വിന്യാസ ആവശ്യകതകളും ഉപയോഗിച്ച് ഒരു `RawVec` (സിസ്റ്റം കൂമ്പാരത്തിൽ) സൃഷ്ടിക്കുന്നു.
    /// `capacity` `0` അല്ലെങ്കിൽ `T` പൂജ്യ വലുപ്പമാകുമ്പോൾ ഇത് `RawVec::new` എന്ന് വിളിക്കുന്നതിന് തുല്യമാണ്.
    /// `T` പൂജ്യ വലുപ്പമാണെങ്കിൽ ഇതിനർത്ഥം അഭ്യർത്ഥിച്ച ശേഷിയുള്ള `RawVec` നിങ്ങൾക്ക് ലഭിക്കില്ലെന്നാണ്.
    ///
    /// # Panics
    ///
    /// അഭ്യർത്ഥിച്ച ശേഷി `isize::MAX` ബൈറ്റുകൾ കവിയുന്നുവെങ്കിൽ Panics.
    ///
    /// # Aborts
    ///
    /// OOM-ൽ നിർത്തുന്നു.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// `with_capacity` പോലെ, പക്ഷേ ബഫർ പൂജ്യമാണെന്ന് ഉറപ്പുനൽകുന്നു.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// ഒരു പോയിന്ററിൽ നിന്നും ശേഷിയിൽ നിന്നും ഒരു `RawVec` പുനർനിർമ്മിക്കുന്നു.
    ///
    /// # Safety
    ///
    /// `ptr` അനുവദിക്കണം (സിസ്റ്റം കൂമ്പാരത്തിൽ), തന്നിരിക്കുന്ന `capacity` ഉപയോഗിച്ച്.
    /// വലുപ്പത്തിലുള്ള തരങ്ങൾക്ക് `capacity` ന് `isize::MAX` കവിയാൻ പാടില്ല.(32-ബിറ്റ് സിസ്റ്റങ്ങളിൽ ഒരു ആശങ്ക മാത്രം).
    /// ZST vectors ന് `usize::MAX` വരെ ശേഷി ഉണ്ടായിരിക്കാം.
    /// `ptr`, `capacity` എന്നിവ ഒരു `RawVec` ൽ നിന്നാണ് വരുന്നതെങ്കിൽ, ഇത് ഉറപ്പുനൽകുന്നു.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // ചെറിയ വെക്കുകൾ ഓർമയുണ്ട്.ഇതിലേക്ക് പോകുക:
    // - മൂലകത്തിന്റെ വലുപ്പം 1 ആണെങ്കിൽ, കാരണം ഏതെങ്കിലും കൂമ്പാരം അലോക്കേറ്റർമാർ 8 ബൈറ്റുകളിൽ നിന്ന് കുറഞ്ഞത് 8 ബൈറ്റുകളെങ്കിലും അഭ്യർത്ഥിക്കാൻ സാധ്യതയുണ്ട്.
    //
    // - 4 ഘടകങ്ങൾ മിതമായ വലുപ്പമുള്ളതാണെങ്കിൽ (<=1 KiB).
    // - 1 അല്ലാത്തപക്ഷം, വളരെ ഹ്രസ്വമായ Vec-കൾക്കായി കൂടുതൽ സ്ഥലം പാഴാക്കാതിരിക്കാൻ.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// `new` പോലെ, എന്നാൽ മടങ്ങിയ `RawVec`-നായി അലോക്കേറ്റർ തിരഞ്ഞെടുക്കുന്നതിനെ ആശ്രയിച്ച് പാരാമീറ്ററൈസ് ചെയ്തു.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` "unallocated" എന്നാണ് അർത്ഥമാക്കുന്നത്.പൂജ്യ വലുപ്പത്തിലുള്ള തരം അവഗണിച്ചു.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// `with_capacity` പോലെ, എന്നാൽ മടങ്ങിയ `RawVec`-നായി അലോക്കേറ്റർ തിരഞ്ഞെടുക്കുന്നതിനെ ആശ്രയിച്ച് പാരാമീറ്ററൈസ് ചെയ്തു.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// `with_capacity_zeroed` പോലെ, എന്നാൽ മടങ്ങിയ `RawVec`-നായി അലോക്കേറ്റർ തിരഞ്ഞെടുക്കുന്നതിനെ ആശ്രയിച്ച് പാരാമീറ്ററൈസ് ചെയ്തു.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// ഒരു `Box<[T]>`-നെ `RawVec<T>`-ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// നിർദ്ദിഷ്ട `len` ഉപയോഗിച്ച് മുഴുവൻ ബഫറിനെയും `Box<[MaybeUninit<T>]>` ലേക്ക് പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// നടപ്പിലാക്കിയേക്കാവുന്ന `cap` മാറ്റങ്ങളെ ഇത് ശരിയായി പുനർനിർമ്മിക്കുമെന്ന് ശ്രദ്ധിക്കുക.(വിശദാംശങ്ങൾക്ക് തരത്തിന്റെ വിവരണം കാണുക.)
    ///
    /// # Safety
    ///
    /// * `len` ഏറ്റവും സമീപകാലത്ത് അഭ്യർത്ഥിച്ച ശേഷിയേക്കാൾ വലുതോ തുല്യമോ ആയിരിക്കണം, കൂടാതെ
    /// * `len` `self.capacity()`-ൽ കുറവോ തുല്യമോ ആയിരിക്കണം.
    ///
    /// ശ്രദ്ധിക്കുക, അഭ്യർത്ഥിച്ച ശേഷിയും `self.capacity()`-ഉം തമ്മിൽ വ്യത്യാസമുണ്ടാകാം, കാരണം ഒരു അലോക്കേറ്ററിന് ആവശ്യപ്പെട്ടതിനേക്കാൾ വലിയ മെമ്മറി ബ്ലോക്ക് മൊത്തത്തിൽ നൽകാനും തിരികെ നൽകാനും കഴിയും.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // സുരക്ഷാ ആവശ്യകതയുടെ ഒരു പകുതി ശുചിത്വം പരിശോധിക്കുക (മറ്റേ പകുതി ഞങ്ങൾക്ക് പരിശോധിക്കാൻ കഴിയില്ല).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // ഞങ്ങൾ‌ഇവിടെ `unwrap_or_else` ഒഴിവാക്കുന്നു, കാരണം ഇത് ജനറേറ്റുചെയ്‌ത എൽ‌എൽ‌വി‌എം ഐ‌ആറിന്റെ അളവ് വർദ്ധിപ്പിക്കുന്നു.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// ഒരു പോയിന്റർ, ശേഷി, അലോക്കേറ്റർ എന്നിവയിൽ നിന്ന് ഒരു `RawVec` പുനർനിർമ്മിക്കുന്നു.
    ///
    /// # Safety
    ///
    /// `ptr` അനുവദിക്കണം (തന്നിരിക്കുന്ന അലോക്കേറ്റർ `alloc` വഴി), തന്നിരിക്കുന്ന `capacity` ഉപയോഗിച്ച്.
    /// വലുപ്പത്തിലുള്ള തരങ്ങൾക്ക് `capacity` ന് `isize::MAX` കവിയാൻ പാടില്ല.
    /// (32-ബിറ്റ് സിസ്റ്റങ്ങളിൽ ഒരു ആശങ്ക മാത്രം).
    /// ZST vectors ന് `usize::MAX` വരെ ശേഷി ഉണ്ടായിരിക്കാം.
    /// `alloc` വഴി സൃഷ്ടിച്ച `RawVec` ൽ നിന്നാണ് `ptr`, `capacity` എന്നിവ വരുന്നത് എങ്കിൽ, ഇത് ഉറപ്പുനൽകുന്നു.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// അലോക്കേഷന്റെ ആരംഭത്തിലേക്ക് ഒരു റോ പോയിന്റർ നേടുന്നു.
    /// `capacity == 0` അല്ലെങ്കിൽ `T` പൂജ്യ വലുപ്പമാണെങ്കിൽ ഇത് `Unique::dangling()` ആണെന്ന കാര്യം ശ്രദ്ധിക്കുക.
    /// മുമ്പത്തെ കേസിൽ, നിങ്ങൾ ശ്രദ്ധിക്കണം.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// അലോക്കേഷന്റെ ശേഷി നേടുന്നു.
    ///
    /// `T` പൂജ്യ വലുപ്പമാണെങ്കിൽ ഇത് എല്ലായ്പ്പോഴും `usize::MAX` ആയിരിക്കും.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// ഈ `RawVec`-നെ പിന്തുണയ്‌ക്കുന്ന അലോക്കേറ്ററിലേക്ക് ഒരു പങ്കിട്ട റഫറൻസ് നൽകുന്നു.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // ഞങ്ങൾക്ക് ഒരു നിശ്ചിത മെമ്മറി ഉണ്ട്, അതിനാൽ ഞങ്ങളുടെ നിലവിലെ ലേ .ട്ട് ലഭിക്കുന്നതിന് റൺടൈം ചെക്കുകൾ മറികടക്കാൻ കഴിയും.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// `len + additional` ഘടകങ്ങൾ കൈവശം വയ്ക്കാൻ മതിയായ ഇടമെങ്കിലും ബഫറിൽ ഉണ്ടെന്ന് ഉറപ്പാക്കുന്നു.
    /// ഇതിന് ഇതിനകം തന്നെ മതിയായ ശേഷിയില്ലെങ്കിൽ,*O*(1) പെരുമാറ്റം നേടുന്നതിന് മതിയായ സ്ഥലവും സുഖപ്രദമായ സ്ലാക്ക് സ്ഥലവും വീണ്ടും അനുവദിക്കും.
    ///
    /// panic ലേക്ക് അനാവശ്യമായി കാരണമായാൽ ഈ സ്വഭാവം പരിമിതപ്പെടുത്തും.
    ///
    /// `len` `self.capacity()` കവിയുന്നുവെങ്കിൽ, അഭ്യർത്ഥിച്ച ഇടം അനുവദിക്കുന്നതിൽ ഇത് പരാജയപ്പെട്ടേക്കാം.
    /// ഇത് ശരിക്കും സുരക്ഷിതമല്ല, പക്ഷേ ഈ ഫംഗ്ഷന്റെ സ്വഭാവത്തെ ആശ്രയിക്കുന്ന *നിങ്ങൾ* എഴുതുന്ന സുരക്ഷിതമല്ലാത്ത കോഡ് തകരാറിലായേക്കാം.
    ///
    /// `extend` പോലുള്ള ബൾക്ക്-പുഷ് പ്രവർത്തനം നടപ്പിലാക്കാൻ ഇത് അനുയോജ്യമാണ്.
    ///
    /// # Panics
    ///
    /// പുതിയ ശേഷി `isize::MAX` ബൈറ്റുകൾ കവിയുന്നുവെങ്കിൽ Panics.
    ///
    /// # Aborts
    ///
    /// OOM-ൽ നിർത്തുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // ലെൻ `isize::MAX` കവിയുന്നുവെങ്കിൽ റിസർവ് നിർത്തലാക്കുകയോ പരിഭ്രാന്തരാകുകയോ ചെയ്യുമായിരുന്നു, അതിനാൽ ഇത് ഇപ്പോൾ അൺചെക്ക് ചെയ്യുന്നത് സുരക്ഷിതമാണ്.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// `reserve`-ന് സമാനമാണ്, പക്ഷേ പരിഭ്രാന്തരാകുന്നതിനോ ഉപേക്ഷിക്കുന്നതിനോ പകരം പിശകുകൾ നൽകുന്നു.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// `len + additional` ഘടകങ്ങൾ കൈവശം വയ്ക്കാൻ മതിയായ ഇടമെങ്കിലും ബഫറിൽ ഉണ്ടെന്ന് ഉറപ്പാക്കുന്നു.
    /// ഇത് ഇതിനകം ഇല്ലെങ്കിൽ, ആവശ്യമായ മെമ്മറിയുടെ ഏറ്റവും കുറഞ്ഞ തുക വീണ്ടും അനുവദിക്കും.
    /// സാധാരണയായി ഇത് ആവശ്യമായ മെമ്മറിയുടെ അളവായിരിക്കും, പക്ഷേ തത്ത്വത്തിൽ അലോക്കേറ്റർ ഞങ്ങൾ ആവശ്യപ്പെട്ടതിലും കൂടുതൽ തിരികെ നൽകാൻ സ്വാതന്ത്ര്യമുണ്ട്.
    ///
    ///
    /// `len` `self.capacity()` കവിയുന്നുവെങ്കിൽ, അഭ്യർത്ഥിച്ച ഇടം അനുവദിക്കുന്നതിൽ ഇത് പരാജയപ്പെട്ടേക്കാം.
    /// ഇത് ശരിക്കും സുരക്ഷിതമല്ല, പക്ഷേ ഈ ഫംഗ്ഷന്റെ സ്വഭാവത്തെ ആശ്രയിക്കുന്ന *നിങ്ങൾ* എഴുതുന്ന സുരക്ഷിതമല്ലാത്ത കോഡ് തകരാറിലായേക്കാം.
    ///
    /// # Panics
    ///
    /// പുതിയ ശേഷി `isize::MAX` ബൈറ്റുകൾ കവിയുന്നുവെങ്കിൽ Panics.
    ///
    /// # Aborts
    ///
    /// OOM-ൽ നിർത്തുന്നു.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// `reserve_exact`-ന് സമാനമാണ്, പക്ഷേ പരിഭ്രാന്തരാകുന്നതിനോ ഉപേക്ഷിക്കുന്നതിനോ പകരം പിശകുകൾ നൽകുന്നു.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// അലോക്കേഷൻ നിർദ്ദിഷ്ട തുകയിലേക്ക് ചുരുക്കുന്നു.
    /// തന്നിരിക്കുന്ന തുക 0 ആണെങ്കിൽ, യഥാർത്ഥത്തിൽ പൂർണ്ണമായും ഡീലോക്കേറ്റ് ചെയ്യുന്നു.
    ///
    /// # Panics
    ///
    /// തന്നിരിക്കുന്ന തുക നിലവിലെ ശേഷിയേക്കാൾ * വലുതാണെങ്കിൽ Panics.
    ///
    /// # Aborts
    ///
    /// OOM-ൽ നിർത്തുന്നു.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// ആവശ്യമായ അധിക ശേഷി നിറവേറ്റുന്നതിന് ബഫർ വളരണമെങ്കിൽ മടങ്ങുന്നു.
    /// `grow` ഇൻ‌ലൈൻ‌ചെയ്യാതെ ഇൻ‌ലൈനിംഗ് റിസർ‌വ് കോളുകൾ‌സാധ്യമാക്കുന്നതിന് പ്രധാനമായും ഉപയോഗിക്കുന്നു.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // ഈ രീതി സാധാരണയായി പലതവണ തൽക്ഷണം ചെയ്യുന്നു.അതിനാൽ കംപൈൽ സമയം മെച്ചപ്പെടുത്തുന്നതിന് ഇത് കഴിയുന്നത്ര ചെറുതായിരിക്കണമെന്ന് ഞങ്ങൾ ആഗ്രഹിക്കുന്നു.
    // ജനറേറ്റുചെയ്ത കോഡ് വേഗത്തിൽ പ്രവർത്തിപ്പിക്കുന്നതിന്, അതിലെ ഉള്ളടക്കങ്ങൾ കഴിയുന്നത്ര സ്റ്റാറ്റിറ്റിക്കായി കണക്കുകൂട്ടാൻ ഞങ്ങൾ ആഗ്രഹിക്കുന്നു.
    // അതിനാൽ, ഈ രീതി ശ്രദ്ധാപൂർവ്വം എഴുതിയതിനാൽ `T`-നെ ആശ്രയിക്കുന്ന എല്ലാ കോഡുകളും അതിനുള്ളിലാണ്, അതേസമയം `T`-നെ ആശ്രയിക്കാത്ത കോഡിന്റെ ഭൂരിഭാഗവും `T`-നേക്കാൾ ജനറിക് അല്ലാത്ത ഫംഗ്ഷനുകളിലാണ്.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // കോളിംഗ് സന്ദർഭങ്ങളിൽ ഇത് ഉറപ്പാക്കുന്നു.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // `elem_size` ആയിരിക്കുമ്പോൾ ഞങ്ങൾ `usize::MAX` ന്റെ ശേഷി നൽകുന്നു
            // 0, ഇവിടെയെത്തുക എന്നതിനർത്ഥം `RawVec` അമിതമായിരിക്കുന്നു എന്നാണ്.
            return Err(CapacityOverflow);
        }

        // ദു check ഖകരമെന്നു പറയട്ടെ, ഈ പരിശോധനകളെക്കുറിച്ച് ഞങ്ങൾക്ക് ഒന്നും ചെയ്യാൻ കഴിയില്ല.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // ഇത് എക്‌സ്‌പോണൻഷ്യൽ വളർച്ചയ്ക്ക് ഉറപ്പ് നൽകുന്നു.
        // `cap <= isize::MAX` ഉം `cap` തരവും `usize` ആയതിനാൽ ഇരട്ടിപ്പിക്കൽ കവിഞ്ഞൊഴുകാൻ കഴിയില്ല.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` `T`-ന് മുകളിലുള്ള ജനറിക് അല്ലാത്തതാണ്.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // ഈ രീതിയിലെ പരിമിതികൾ `grow_amortized`-ൽ ഉള്ളതിന് സമാനമാണ്, എന്നാൽ ഈ രീതി സാധാരണയായി കുറച്ച് തവണ തൽക്ഷണം ചെയ്യപ്പെടുന്നതിനാൽ ഇത് വളരെ വിമർശനാത്മകമാണ്.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // തരം വലുപ്പം ആയിരിക്കുമ്പോൾ ഞങ്ങൾ `usize::MAX` ന്റെ ശേഷി നൽകുന്നു
            // 0, ഇവിടെയെത്തുക എന്നതിനർത്ഥം `RawVec` അമിതമായിരിക്കുന്നു എന്നാണ്.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` `T`-ന് മുകളിലുള്ള ജനറിക് അല്ലാത്തതാണ്.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// കംപൈൽ സമയം കുറയ്ക്കുന്നതിന് ഈ പ്രവർത്തനം `RawVec` ന് പുറത്താണ്.വിശദാംശങ്ങൾക്ക് `RawVec::grow_amortized` ന് മുകളിലുള്ള അഭിപ്രായം കാണുക.
// (`A` പാരാമീറ്റർ പ്രാധാന്യമർഹിക്കുന്നില്ല, കാരണം പ്രായോഗികമായി കാണുന്ന വ്യത്യസ്ത `A` തരങ്ങളുടെ എണ്ണം `T` തരങ്ങളുടെ എണ്ണത്തേക്കാൾ വളരെ ചെറുതാണ്.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // `RawVec::grow_*` ന്റെ വലുപ്പം കുറയ്ക്കുന്നതിന് ഇവിടെ പിശക് പരിശോധിക്കുക.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // വിന്യാസ സമത്വത്തിനായി അലോക്കേറ്റർ പരിശോധിക്കുന്നു
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// `RawVec` * ന്റെ ഉടമസ്ഥതയിലുള്ള മെമ്മറി അതിന്റെ ഉള്ളടക്കങ്ങൾ ഉപേക്ഷിക്കാൻ ശ്രമിക്കാതെ തന്നെ ശൂന്യമാക്കുന്നു.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// റിസർവ് പിശക് കൈകാര്യം ചെയ്യുന്നതിനുള്ള കേന്ദ്ര പ്രവർത്തനം.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// ഇനിപ്പറയുന്നവ ഞങ്ങൾ ഉറപ്പ് നൽകേണ്ടതുണ്ട്:
// * ഞങ്ങൾ ഒരിക്കലും `> isize::MAX` ബൈറ്റ് വലുപ്പമുള്ള ഒബ്‌ജക്റ്റുകൾ അനുവദിക്കുന്നില്ല.
// * ഞങ്ങൾ `usize::MAX` കവിഞ്ഞൊഴുകുന്നില്ല, മാത്രമല്ല വളരെ കുറച്ച് അനുവദിക്കുകയും ചെയ്യുന്നു.
//
// 64-ബിറ്റിൽ ഞങ്ങൾ ഓവർഫ്ലോ പരിശോധിക്കേണ്ടതുണ്ട്, കാരണം `> isize::MAX` ബൈറ്റുകൾ അനുവദിക്കാൻ ശ്രമിക്കുന്നത് പരാജയപ്പെടും.
// 32-ബിറ്റ്, 16-ബിറ്റ് എന്നിവയിൽ ഞങ്ങൾ ഒരു പ്ലാറ്റ്ഫോമിൽ പ്രവർത്തിക്കുന്നുണ്ടെങ്കിൽ ഒരു അധിക ഗാർഡ് ചേർക്കേണ്ടതുണ്ട്, അത് എല്ലാ 4 ജിബിയും ഉപയോക്തൃ ഇടത്തിൽ ഉപയോഗിക്കാൻ കഴിയും, ഉദാ. PAE അല്ലെങ്കിൽ x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// ശേഷി ഓവർഫ്ലോകൾ റിപ്പോർട്ടുചെയ്യുന്നതിന് ഉത്തരവാദിത്തമുള്ള ഒരു കേന്ദ്ര പ്രവർത്തനം.
// മൊഡ്യൂളിലുടനീളം ഒരു കൂട്ടത്തിനുപകരം panics എന്ന ഒരേയൊരു ലൊക്കേഷൻ ഉള്ളതിനാൽ ഈ panics-മായി ബന്ധപ്പെട്ട കോഡ് ജനറേഷൻ വളരെ കുറവാണെന്ന് ഇത് ഉറപ്പാക്കും.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}