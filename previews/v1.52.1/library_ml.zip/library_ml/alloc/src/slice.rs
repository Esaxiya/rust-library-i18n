//! തുടർച്ചയായ ശ്രേണിയിലേക്ക് ചലനാത്മക വലുപ്പത്തിലുള്ള കാഴ്ച, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! ഒരു പോയിന്ററും നീളവും പ്രതിനിധീകരിക്കുന്ന മെമ്മറി ബ്ലോക്കിലേക്കുള്ള കാഴ്ചയാണ് സ്ലൈസുകൾ.
//!
//! ```
//! // ഒരു Vec അരിഞ്ഞത്
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // ഒരു സ്ലൈസിലേക്ക് ഒരു അറേ നിർബന്ധിക്കുന്നു
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! കഷ്ണങ്ങൾ മാറ്റാവുന്നതോ പങ്കിട്ടതോ ആണ്.
//! പങ്കിട്ട സ്ലൈസ് തരം `&[T]` ആണ്, മ്യൂട്ടബിൾ സ്ലൈസ് തരം `&mut [T]` ആണ്, ഇവിടെ `T` മൂലക തരത്തെ പ്രതിനിധീകരിക്കുന്നു.
//! ഉദാഹരണത്തിന്, ഒരു മ്യൂട്ടബിൾ സ്ലൈസ് ചൂണ്ടിക്കാണിക്കുന്ന മെമ്മറി ബ്ലോക്ക് നിങ്ങൾക്ക് പരിവർത്തനം ചെയ്യാൻ കഴിയും:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! ഈ മൊഡ്യൂളിൽ അടങ്ങിയിരിക്കുന്ന ചില കാര്യങ്ങൾ ഇതാ:
//!
//! ## Structs
//!
//! സ്ലൈസുകൾക്ക് ഉപയോഗപ്രദമാകുന്ന നിരവധി സ്ട്രക്റ്റുകൾ ഉണ്ട്, എക്സ് 100 എക്സ്, ഇത് ഒരു സ്ലൈസിനു മുകളിലുള്ള ആവർത്തനത്തെ പ്രതിനിധീകരിക്കുന്നു.
//!
//! ## Trait നടപ്പിലാക്കലുകൾ
//!
//! സ്ലൈസുകൾക്കായി സാധാരണ traits-ന്റെ നിരവധി നടപ്പാക്കലുകൾ ഉണ്ട്.ചില ഉദാഹരണങ്ങളിൽ ഇവ ഉൾപ്പെടുന്നു:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], എലമെൻറ് തരം [`Eq`] അല്ലെങ്കിൽ [`Ord`] ആയ സ്ലൈസുകൾക്കായി.
//! * [`Hash`] - മൂലക തരം [`Hash`] ആയ സ്ലൈസുകൾക്കായി.
//!
//! ## Iteration
//!
//! കഷ്ണങ്ങൾ `IntoIterator` നടപ്പിലാക്കുന്നു.സ്ലൈസ് ഘടകങ്ങളിലേക്ക് റഫറൻസുകൾ ഇറ്ററേറ്റർ നൽകുന്നു.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! മ്യൂട്ടബിൾ സ്ലൈസ് ഘടകങ്ങളിലേക്ക് മ്യൂട്ടബിൾ റഫറൻസുകൾ നൽകുന്നു:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! ഈ ഇറ്ററേറ്റർ സ്ലൈസിന്റെ ഘടകങ്ങളിലേക്ക് മ്യൂട്ടബിൾ റഫറൻസുകൾ നൽകുന്നു, അതിനാൽ സ്ലൈസിന്റെ ഘടക തരം `i32` ആണെങ്കിൽ, ആവർത്തനത്തിന്റെ മൂലക തരം `&mut i32` ആണ്.
//!
//!
//! * [`.iter`] സ്ഥിരസ്ഥിതി ഇറ്ററേറ്ററുകൾ മടക്കിനൽകുന്നതിനുള്ള വ്യക്തമായ രീതികളാണ് [`.iter_mut`].
//! * [`.split`], [`.splitn`], [`.chunks`], [`.windows`] എന്നിവയും അതിലേറെയും ആണ് ഇറ്ററേറ്ററുകളെ മടക്കിനൽകുന്ന കൂടുതൽ രീതികൾ.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// ഈ മൊഡ്യൂളിലെ പല ഉപയോഗങ്ങളും ടെസ്റ്റ് കോൺഫിഗറേഷനിൽ മാത്രമേ ഉപയോഗിക്കുന്നുള്ളൂ.
// അവ പരിഹരിക്കുന്നതിനേക്കാൾ ഉപയോഗിക്കാത്ത_ ഇറക്കുമതി മുന്നറിയിപ്പ് ഓഫുചെയ്യുന്നത് ശുദ്ധമാണ്.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// അടിസ്ഥാന സ്ലൈസ് വിപുലീകരണ രീതികൾ
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) എൻ‌ബി പരിശോധിക്കുന്ന സമയത്ത് എക്സ് 00 എക്സ് മാക്രോ നടപ്പിലാക്കുന്നതിന് ആവശ്യമാണ്, കൂടുതൽ വിവരങ്ങൾക്ക് ഈ ഫയലിലെ എക്സ് 01 എക്സ് മൊഡ്യൂൾ കാണുക.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) എൻ‌ബി പരിശോധിക്കുന്ന സമയത്ത് എക്സ് 00 എക്സ് നടപ്പിലാക്കുന്നതിന് ആവശ്യമാണ്, കൂടുതൽ വിവരങ്ങൾക്ക് ഈ ഫയലിലെ എക്സ് 01 എക്സ് മൊഡ്യൂൾ കാണുക.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): cfg(test) `impl [T]` ലഭ്യമല്ലാത്തതിനാൽ, ഈ മൂന്ന് ഫംഗ്ഷനുകളും യഥാർത്ഥത്തിൽ `impl [T]`-ൽ ഉള്ള രീതികളാണ്, പക്ഷേ `core::slice::SliceExt`-ൽ അല്ല, `test_permutations` ടെസ്റ്റിനായി ഞങ്ങൾ ഈ ഫംഗ്ഷനുകൾ നൽകേണ്ടതുണ്ട്
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // `vec!` മാക്രോയിൽ ഇത് കൂടുതലും ഉപയോഗിക്കുന്നതിനാൽ ഇത് പൂർണ്ണമായ റിഗ്രഷന് കാരണമാകുന്നതിനാൽ ഞങ്ങൾ ഇതിൽ ഇൻലൈൻ ആട്രിബ്യൂട്ട് ചേർക്കരുത്.
    // ചർച്ചയ്ക്കും മികച്ച ഫലങ്ങൾക്കും #71204 കാണുക.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // ചുവടെയുള്ള ലൂപ്പിൽ ഇനങ്ങൾ‌സമാരംഭിച്ചതായി അടയാളപ്പെടുത്തി
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) ബൗണ്ട് ചെക്കുകൾ നീക്കംചെയ്യുന്നതിന് എൽ‌എൽ‌വി‌എമ്മിന് അത്യാവശ്യമാണ് കൂടാതെ സിപ്പിനേക്കാൾ മികച്ച കോഡ്‌ജെൻ ഉണ്ട്.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // vec അനുവദിക്കുകയും മുകളിൽ ഈ നീളമെങ്കിലും ആരംഭിക്കുകയും ചെയ്തു.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // `s` ന്റെ ശേഷി ഉപയോഗിച്ച് മുകളിൽ അനുവദിച്ചിരിക്കുന്നു, കൂടാതെ ptr::copy_to_non_overlapping ൽ `s.len()` ലേക്ക് സമാരംഭിക്കുക.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// സ്ലൈസ് അടുക്കുന്നു.
    ///
    /// ഈ തരം സ്ഥിരതയുള്ളതാണ് (അതായത്, തുല്യ ഘടകങ്ങൾ പുന order ക്രമീകരിക്കുന്നില്ല)*O*(*n*\*log(* n*)) ഏറ്റവും മോശം അവസ്ഥ.
    ///
    /// ബാധകമാകുമ്പോൾ, സ്ഥിരതയുള്ള സോർട്ടിംഗിനേക്കാൾ വേഗതയേറിയതും അക്സിലറി മെമ്മറി അനുവദിക്കാത്തതുമായതിനാൽ അസ്ഥിരമായ സോർട്ടിംഗിന് മുൻഗണന നൽകുന്നു.
    /// [`sort_unstable`](slice::sort_unstable) കാണുക.
    ///
    /// # നിലവിലെ നടപ്പാക്കൽ
    ///
    /// നിലവിലെ അൽ‌ഗോരിതം [timsort](https://en.wikipedia.org/wiki/Timsort)-ൽ നിന്ന് പ്രചോദനം ഉൾക്കൊണ്ട ഒരു അഡാപ്റ്റീവ്, ആവർത്തന ലയന തരം.
    /// സ്ലൈസ് ഏതാണ്ട് അടുക്കിയിരിക്കുന്ന സന്ദർഭങ്ങളിൽ ഇത് വളരെ വേഗത്തിൽ രൂപകൽപ്പന ചെയ്തിട്ടുള്ളതാണ്, അല്ലെങ്കിൽ ഒന്നോ രണ്ടോ അതിലധികമോ അടുക്കിയ രണ്ടോ അതിലധികമോ അടുക്കിയ സീക്വൻസുകൾ അടങ്ങിയിരിക്കുന്നു.
    ///
    ///
    /// കൂടാതെ, ഇത് `self`-ന്റെ പകുതി വലുപ്പമുള്ള താൽക്കാലിക സംഭരണം അനുവദിക്കുന്നു, എന്നാൽ ഹ്രസ്വ കഷ്ണങ്ങൾക്ക് പകരം അലോക്കേറ്റ് ചെയ്യാത്ത ഉൾപ്പെടുത്തൽ തരം ഉപയോഗിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// ഒരു താരതമ്യ ഫംഗ്ഷൻ ഉപയോഗിച്ച് സ്ലൈസ് അടുക്കുന്നു.
    ///
    /// ഈ തരം സ്ഥിരതയുള്ളതാണ് (അതായത്, തുല്യ ഘടകങ്ങൾ പുന order ക്രമീകരിക്കുന്നില്ല)*O*(*n*\*log(* n*)) ഏറ്റവും മോശം അവസ്ഥ.
    ///
    /// സ്ലൈസിലെ ഘടകങ്ങൾക്കായുള്ള മൊത്തം ക്രമം താരതമ്യ ഫംഗ്ഷൻ നിർവചിക്കണം.ഓർ‌ഡറിംഗ് മൊത്തത്തിൽ‌ഇല്ലെങ്കിൽ‌, ഘടകങ്ങളുടെ ക്രമം വ്യക്തമാക്കിയിട്ടില്ല.
    /// ഒരു ഓർഡർ ഉണ്ടെങ്കിൽ ആകെ ഓർഡറാണ് (എല്ലാ `a`, `b`, `c` എന്നിവയ്‌ക്കും):
    ///
    /// * മൊത്തവും ആന്റിസിമമെട്രിക്കും: കൃത്യമായി `a < b`, `a == b` അല്ലെങ്കിൽ `a > b` എന്നിവയിൽ ഒന്ന് ശരിയാണ്, കൂടാതെ
    /// * ട്രാൻസിറ്റീവ്, `a < b`, `b < c` എന്നിവ `a < c` സൂചിപ്പിക്കുന്നു.`==`, `>` എന്നിവയ്‌ക്കും ഇത് സമാനമായിരിക്കണം.
    ///
    /// ഉദാഹരണത്തിന്, `NaN != NaN` [`Ord`] നടപ്പിലാക്കാത്തതിനാൽ `NaN != NaN`, സ്ലൈസിൽ ഒരു `NaN` അടങ്ങിയിട്ടില്ലെന്ന് അറിയുമ്പോൾ നമുക്ക് `partial_cmp` ഞങ്ങളുടെ സോർട്ട് ഫംഗ്ഷനായി ഉപയോഗിക്കാം.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// ബാധകമാകുമ്പോൾ, സ്ഥിരതയുള്ള സോർട്ടിംഗിനേക്കാൾ വേഗതയേറിയതും അക്സിലറി മെമ്മറി അനുവദിക്കാത്തതുമായതിനാൽ അസ്ഥിരമായ സോർട്ടിംഗിന് മുൻഗണന നൽകുന്നു.
    /// [`sort_unstable_by`](slice::sort_unstable_by) കാണുക.
    ///
    /// # നിലവിലെ നടപ്പാക്കൽ
    ///
    /// നിലവിലെ അൽ‌ഗോരിതം [timsort](https://en.wikipedia.org/wiki/Timsort)-ൽ നിന്ന് പ്രചോദനം ഉൾക്കൊണ്ട ഒരു അഡാപ്റ്റീവ്, ആവർത്തന ലയന തരം.
    /// സ്ലൈസ് ഏതാണ്ട് അടുക്കിയിരിക്കുന്ന സന്ദർഭങ്ങളിൽ ഇത് വളരെ വേഗത്തിൽ രൂപകൽപ്പന ചെയ്തിട്ടുള്ളതാണ്, അല്ലെങ്കിൽ ഒന്നോ രണ്ടോ അതിലധികമോ അടുക്കിയ രണ്ടോ അതിലധികമോ അടുക്കിയ സീക്വൻസുകൾ അടങ്ങിയിരിക്കുന്നു.
    ///
    /// കൂടാതെ, ഇത് `self`-ന്റെ പകുതി വലുപ്പമുള്ള താൽക്കാലിക സംഭരണം അനുവദിക്കുന്നു, എന്നാൽ ഹ്രസ്വ കഷ്ണങ്ങൾക്ക് പകരം അലോക്കേറ്റ് ചെയ്യാത്ത ഉൾപ്പെടുത്തൽ തരം ഉപയോഗിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // റിവേഴ്സ് സോർട്ടിംഗ്
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// ഒരു കീ എക്സ്ട്രാക്ഷൻ ഫംഗ്ഷൻ ഉപയോഗിച്ച് സ്ലൈസ് അടുക്കുന്നു.
    ///
    /// ഈ തരം സ്ഥിരതയുള്ളതാണ് (അതായത്, തുല്യ ഘടകങ്ങൾ പുന order ക്രമീകരിക്കുന്നില്ല)*O*(*m*\* * n *\* log(*n*)) ഏറ്റവും മോശം അവസ്ഥ, ഇവിടെ പ്രധാന പ്രവർത്തനം *O*(*m*).
    ///
    /// വിലയേറിയ കീ ഫംഗ്ഷനുകൾക്കായി (ഉദാ
    /// ലളിതമായ പ്രോപ്പർട്ടി ആക്‌സസ്സുകളോ അടിസ്ഥാന പ്രവർത്തനങ്ങളോ അല്ലാത്ത പ്രവർത്തനങ്ങൾ), എലമെന്റ് കീകൾ വീണ്ടും കണക്കുകൂട്ടാത്തതിനാൽ [`sort_by_cached_key`](slice::sort_by_cached_key) വളരെ വേഗതയുള്ളതായിരിക്കും.
    ///
    ///
    /// ബാധകമാകുമ്പോൾ, സ്ഥിരതയുള്ള സോർട്ടിംഗിനേക്കാൾ വേഗതയേറിയതും അക്സിലറി മെമ്മറി അനുവദിക്കാത്തതുമായതിനാൽ അസ്ഥിരമായ സോർട്ടിംഗിന് മുൻഗണന നൽകുന്നു.
    /// [`sort_unstable_by_key`](slice::sort_unstable_by_key) കാണുക.
    ///
    /// # നിലവിലെ നടപ്പാക്കൽ
    ///
    /// നിലവിലെ അൽ‌ഗോരിതം [timsort](https://en.wikipedia.org/wiki/Timsort)-ൽ നിന്ന് പ്രചോദനം ഉൾക്കൊണ്ട ഒരു അഡാപ്റ്റീവ്, ആവർത്തന ലയന തരം.
    /// സ്ലൈസ് ഏതാണ്ട് അടുക്കിയിരിക്കുന്ന സന്ദർഭങ്ങളിൽ ഇത് വളരെ വേഗത്തിൽ രൂപകൽപ്പന ചെയ്തിട്ടുള്ളതാണ്, അല്ലെങ്കിൽ ഒന്നോ രണ്ടോ അതിലധികമോ അടുക്കിയ രണ്ടോ അതിലധികമോ അടുക്കിയ സീക്വൻസുകൾ അടങ്ങിയിരിക്കുന്നു.
    ///
    /// കൂടാതെ, ഇത് `self`-ന്റെ പകുതി വലുപ്പമുള്ള താൽക്കാലിക സംഭരണം അനുവദിക്കുന്നു, എന്നാൽ ഹ്രസ്വ കഷ്ണങ്ങൾക്ക് പകരം അലോക്കേറ്റ് ചെയ്യാത്ത ഉൾപ്പെടുത്തൽ തരം ഉപയോഗിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// ഒരു കീ എക്സ്ട്രാക്ഷൻ ഫംഗ്ഷൻ ഉപയോഗിച്ച് സ്ലൈസ് അടുക്കുന്നു.
    ///
    /// സോർട്ടിംഗ് സമയത്ത്, കീ ഫംഗ്ഷനെ ഒരു ഘടകത്തിന് ഒരു തവണ മാത്രമേ വിളിക്കൂ.
    ///
    /// ഈ തരം സ്ഥിരതയുള്ളതാണ് (അതായത്, തുല്യ ഘടകങ്ങൾ പുന order ക്രമീകരിക്കുന്നില്ല)*O*(*m*\* * n *+* n *\* log(*n*)) ഏറ്റവും മോശം അവസ്ഥ, ഇവിടെ കീ ഫംഗ്ഷൻ *O*(*m*) .
    ///
    /// ലളിതമായ കീ ഫംഗ്ഷനുകൾ‌ക്കായി (ഉദാ. പ്രോപ്പർ‌ട്ടി ആക്‌സസ് അല്ലെങ്കിൽ‌അടിസ്ഥാന പ്രവർ‌ത്തനങ്ങൾ‌), [`sort_by_key`](slice::sort_by_key) വേഗതയേറിയതായിരിക്കും.
    ///
    /// # നിലവിലെ നടപ്പാക്കൽ
    ///
    /// നിലവിലെ അൽ‌ഗോരിതം ഓഴ്‌സൺ പീറ്റേഴ്‌സിന്റെ [pattern-defeating quicksort][pdqsort] അടിസ്ഥാനമാക്കിയുള്ളതാണ്, ഇത് ക്രമരഹിതമായ ക്വിസ്‌കോർട്ടിന്റെ വേഗത്തിലുള്ള ശരാശരി കേസ് ഹീപ്‌സോർട്ടിന്റെ ഏറ്റവും മോശം കേസുമായി സംയോജിപ്പിക്കുകയും ചില പാറ്റേണുകൾ ഉപയോഗിച്ച് സ്ലൈസുകളിൽ രേഖീയ സമയം നേടുകയും ചെയ്യുന്നു.
    /// അധ enera പതിച്ച കേസുകൾ ഒഴിവാക്കാൻ ഇത് ചില റാൻഡമൈസേഷൻ ഉപയോഗിക്കുന്നു, എന്നാൽ എല്ലായ്പ്പോഴും നിർണ്ണായക സ്വഭാവം നൽകുന്നതിന് ഒരു നിശ്ചിത seed ഉപയോഗിച്ച്.
    ///
    /// ഏറ്റവും മോശം അവസ്ഥയിൽ, സ്ലൈസിന്റെ നീളം `Vec<(K, usize)>`-ൽ അൽഗോരിതം താൽക്കാലിക സംഭരണം അനുവദിക്കുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // അലോക്കേഷൻ കുറയ്ക്കുന്നതിന്, സാധ്യമായ ഏറ്റവും ചെറിയ തരം ഉപയോഗിച്ച് ഞങ്ങളുടെ vector സൂചികയിലാക്കുന്നതിനുള്ള സഹായി മാക്രോ.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // `indices`-ന്റെ ഘടകങ്ങൾ അദ്വിതീയമാണ്, കാരണം അവ സൂചികയിലാക്കിയിരിക്കും, അതിനാൽ യഥാർത്ഥ സ്ലൈസുമായി ബന്ധപ്പെട്ട് ഏത് തരത്തിലും സ്ഥിരത കൈവരിക്കും.
                // മെമ്മറി അലോക്കേഷൻ കുറവായതിനാൽ ഞങ്ങൾ ഇവിടെ `sort_unstable` ഉപയോഗിക്കുന്നു.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// `self` ഒരു പുതിയ `Vec`-ലേക്ക് പകർത്തുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // ഇവിടെ, `s`, `x` എന്നിവ സ്വതന്ത്രമായി പരിഷ്കരിക്കാനാകും.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// ഒരു അലോക്കേറ്റർ ഉപയോഗിച്ച് `self` ഒരു പുതിയ `Vec`-ലേക്ക് പകർത്തുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // ഇവിടെ, `s`, `x` എന്നിവ സ്വതന്ത്രമായി പരിഷ്കരിക്കാനാകും.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, കൂടുതൽ വിവരങ്ങൾക്ക് ഈ ഫയലിലെ `hack` മൊഡ്യൂൾ കാണുക.
        hack::to_vec(self, alloc)
    }

    /// ക്ലോണുകളോ അലോക്കേഷനോ ഇല്ലാതെ `self` ഒരു vector ആയി പരിവർത്തനം ചെയ്യുന്നു.
    ///
    /// തത്ഫലമായുണ്ടാകുന്ന vector `Vec വഴി ഒരു ബോക്സിലേക്ക് തിരികെ പരിവർത്തനം ചെയ്യാൻ കഴിയും<T>`ന്റെ `into_boxed_slice` രീതി.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` ഇത് `x` ലേക്ക് പരിവർത്തനം ചെയ്തതിനാൽ ഇനി ഉപയോഗിക്കാൻ കഴിയില്ല.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, കൂടുതൽ വിവരങ്ങൾക്ക് ഈ ഫയലിലെ `hack` മൊഡ്യൂൾ കാണുക.
        hack::into_vec(self)
    }

    /// ഒരു സ്ലൈസ് `n` തവണ ആവർത്തിച്ചുകൊണ്ട് ഒരു vector സൃഷ്ടിക്കുന്നു.
    ///
    /// # Panics
    ///
    /// ശേഷി കവിഞ്ഞൊഴുകുകയാണെങ്കിൽ ഈ പ്രവർത്തനം panic ആയിരിക്കും.
    ///
    /// # Examples
    ///
    /// അടിസ്ഥാന ഉപയോഗം:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// ഓവർഫ്ലോയിൽ ഒരു panic:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // `n` പൂജ്യത്തേക്കാൾ വലുതാണെങ്കിൽ, അതിനെ `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)` ആയി വിഭജിക്കാം.
        // `2^expn` `n`-ന്റെ ഇടതുവശത്തുള്ള '1' ബിറ്റ് പ്രതിനിധീകരിക്കുന്ന സംഖ്യയാണ്, `rem` എന്നത് `n`-ന്റെ ശേഷിക്കുന്ന ഭാഗമാണ്.
        //
        //

        // `set_len()` ആക്സസ് ചെയ്യുന്നതിന് `Vec` ഉപയോഗിക്കുന്നു.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` `buf` `expn` തവണ ഇരട്ടിയാക്കി ആവർത്തനം നടത്തുന്നു.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // `m > 0` ആണെങ്കിൽ, ഇടതുവശത്തുള്ള '1' വരെ ശേഷിക്കുന്ന ബിറ്റുകൾ ഉണ്ട്.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` `self.len() * n` ന്റെ ശേഷി ഉണ്ട്.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) `buf`-ൽ നിന്ന് തന്നെ ആദ്യത്തെ `rem` ആവർത്തനങ്ങൾ പകർത്തിയാണ് ആവർത്തനം നടത്തുന്നത്.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // `2^expn > rem` മുതൽ ഇത് ഓവർലാപ്പുചെയ്യാത്തതാണ്.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` `buf.capacity()` (`= self.len() * n`)) ന് തുല്യമാണ്.
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// `T` ന്റെ ഒരു സ്ലൈസ് ഒരൊറ്റ മൂല്യമായ `Self::Output` ലേക്ക് പരത്തുന്നു.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// `T` ന്റെ ഒരു സ്ലൈസ് ഒരൊറ്റ മൂല്യമായ `Self::Output` ലേക്ക് പരത്തുന്നു, ഓരോന്നിനും ഇടയിൽ ഒരു പ്രത്യേക സെപ്പറേറ്റർ സ്ഥാപിക്കുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// `T` ന്റെ ഒരു സ്ലൈസ് ഒരൊറ്റ മൂല്യമായ `Self::Output` ലേക്ക് പരത്തുന്നു, ഓരോന്നിനും ഇടയിൽ ഒരു പ്രത്യേക സെപ്പറേറ്റർ സ്ഥാപിക്കുന്നു.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// ഈ സ്ലൈസിന്റെ ഒരു പകർപ്പ് അടങ്ങിയ ഒരു vector നൽകുന്നു, അവിടെ ഓരോ ബൈറ്റും അതിന്റെ ASCII അപ്പർ കേസ് തുല്യമായി മാപ്പുചെയ്യുന്നു.
    ///
    ///
    /// ASCII അക്ഷരങ്ങൾ 'a' മുതൽ 'z' വരെ 'A' മുതൽ 'Z' വരെ മാപ്പുചെയ്‌തു, പക്ഷേ ASCII ഇതര അക്ഷരങ്ങൾക്ക് മാറ്റമില്ല.
    ///
    /// സ്ഥലത്തെ മൂല്യം വലിയക്ഷരമാക്കാൻ, [`make_ascii_uppercase`] ഉപയോഗിക്കുക.
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// ഈ സ്ലൈസിന്റെ ഒരു പകർപ്പ് അടങ്ങിയ ഒരു vector നൽകുന്നു, അവിടെ ഓരോ ബൈറ്റും അതിന്റെ ASCII ലോവർ കേസ് തുല്യമായി മാപ്പുചെയ്യുന്നു.
    ///
    ///
    /// ASCII അക്ഷരങ്ങൾ 'A' മുതൽ 'Z' വരെ 'a' മുതൽ 'z' വരെ മാപ്പുചെയ്‌തു, പക്ഷേ ASCII ഇതര അക്ഷരങ്ങൾക്ക് മാറ്റമില്ല.
    ///
    /// സ്ഥലത്ത് മൂല്യം കുറയ്‌ക്കാൻ, [`make_ascii_lowercase`] ഉപയോഗിക്കുക.
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// നിർദ്ദിഷ്‌ട തരത്തിലുള്ള ഡാറ്റയ്‌ക്ക് മുകളിലുള്ള സ്ലൈസുകൾക്കായുള്ള വിപുലീകരണം traits
////////////////////////////////////////////////////////////////////////////////

/// [`[T]: : concat`](സ്ലൈസ്::കോൺകാറ്റ്) എന്നതിനായുള്ള trait സഹായി.
///
/// Note: ഈ trait-ൽ `Item` തരം പാരാമീറ്റർ ഉപയോഗിക്കുന്നില്ല, പക്ഷേ ഇത് കൂടുതൽ ജനറിക് ആകാൻ അനുവദിക്കുന്നു.
/// ഇത് കൂടാതെ, ഞങ്ങൾക്ക് ഈ പിശക് ലഭിക്കുന്നു:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// ഒന്നിലധികം `Borrow<[_]>` ഇം‌പ്ളുകളുള്ള `V` തരങ്ങൾ‌നിലവിലുണ്ടാകാം എന്നതിനാലാണിത്, ഒന്നിലധികം `T` തരങ്ങൾ‌ബാധകമാകും:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// സമാഹരണത്തിനുശേഷം ഉണ്ടാകുന്ന തരം
    type Output;

    /// [`[ടി]: : കോൺകാറ്റ്`](സ്ലൈസ്::കോൺകാറ്റ്) നടപ്പിലാക്കൽ
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// [`[T]: : join`] എന്നതിനായുള്ള trait സഹായി (സ്ലൈസ്::ചേരുക)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// സമാഹരണത്തിനുശേഷം ഉണ്ടാകുന്ന തരം
    type Output;

    /// [`[T]: : join`](സ്ലൈസ്::ചേരുക) നടപ്പിലാക്കൽ
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// സ്ലൈസുകൾക്കായുള്ള സ്റ്റാൻഡേർഡ് trait നടപ്പിലാക്കലുകൾ
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // പുനരാലേഖനം ചെയ്യാത്ത എന്തും ടാർഗെറ്റിൽ ഇടുക
        target.truncate(self.len());

        // target.len മുകളിലുള്ള വെട്ടിച്ചുരുക്കിയതിനാൽ <= self.len, അതിനാൽ ഇവിടെയുള്ള കഷ്ണങ്ങൾ എല്ലായ്പ്പോഴും പരിധിയിലായിരിക്കും.
        //
        let (init, tail) = self.split_at(target.len());

        // അടങ്ങിയിരിക്കുന്ന മൂല്യങ്ങളുടെ allocations/resources വീണ്ടും ഉപയോഗിക്കുക.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// മുൻകൂട്ടി അടുക്കിയ `v[1..]` ശ്രേണിയിലേക്ക് `v[0]` ഉൾപ്പെടുത്തുന്നു, അങ്ങനെ മുഴുവൻ `v[..]` അടുക്കും.
///
/// ഉൾപ്പെടുത്തൽ തരംതിരിക്കലിന്റെ അവിഭാജ്യ സബ്റൂട്ടീൻ ഇതാണ്.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // ഉൾപ്പെടുത്തൽ നടപ്പിലാക്കാൻ ഇവിടെ മൂന്ന് വഴികളുണ്ട്:
            //
            // 1. ആദ്യത്തേത് അന്തിമ ലക്ഷ്യസ്ഥാനത്ത് എത്തുന്നതുവരെ അടുത്തുള്ള ഘടകങ്ങൾ സ്വാപ്പ് ചെയ്യുക.
            //    എന്നിരുന്നാലും, ഈ രീതിയിൽ ആവശ്യമുള്ളതിനേക്കാൾ കൂടുതൽ ഞങ്ങൾ ഡാറ്റ പകർത്തുന്നു.
            //    ഘടകങ്ങൾ വലിയ ഘടനകളാണെങ്കിൽ (പകർത്താൻ ചെലവേറിയത്), ഈ രീതി മന്ദഗതിയിലാകും.
            //
            // 2. ആദ്യ ഘടകത്തിനുള്ള ശരിയായ സ്ഥലം കണ്ടെത്തുന്നതുവരെ ആവർത്തിക്കുക.
            // അതിനുശേഷം വരുന്ന ഘടകങ്ങൾ മാറ്റി അതിനുള്ള ഇടം ഉണ്ടാക്കി അവസാനം ശേഷിക്കുന്ന ദ്വാരത്തിലേക്ക് വയ്ക്കുക.
            // ഇതൊരു നല്ല രീതിയാണ്.
            //
            // 3. ആദ്യ ഘടകം ഒരു താൽക്കാലിക വേരിയബിളിലേക്ക് പകർത്തുക.അതിനുള്ള ശരിയായ സ്ഥലം കണ്ടെത്തുന്നതുവരെ ആവർത്തിക്കുക.
            // ഞങ്ങൾ പോകുമ്പോൾ, സഞ്ചരിച്ച എല്ലാ ഘടകങ്ങളും അതിന് മുമ്പുള്ള സ്ലോട്ടിലേക്ക് പകർത്തുക.
            // അവസാനമായി, താൽക്കാലിക വേരിയബിളിൽ നിന്ന് ശേഷിക്കുന്ന ദ്വാരത്തിലേക്ക് ഡാറ്റ പകർത്തുക.
            // ഈ രീതി വളരെ നല്ലതാണ്.
            // രണ്ടാമത്തെ രീതിയെക്കാൾ മികച്ച പ്രകടനം ബെഞ്ച്മാർക്കുകൾ പ്രകടമാക്കി.
            //
            // എല്ലാ രീതികളും ബെഞ്ച്മാർക്ക് ചെയ്തു, മൂന്നാമത്തേത് മികച്ച ഫലങ്ങൾ കാണിച്ചു.അതിനാൽ ഞങ്ങൾ അത് തിരഞ്ഞെടുത്തു.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // ഉൾപ്പെടുത്തൽ പ്രക്രിയയുടെ ഇന്റർമീഡിയറ്റ് അവസ്ഥ എല്ലായ്പ്പോഴും എക്സ് 100 എക്സ് ട്രാക്കുചെയ്യുന്നു, ഇത് രണ്ട് ഉദ്ദേശ്യങ്ങൾ നിറവേറ്റുന്നു:
            // 1. `is_less`-ലെ panics-ൽ നിന്ന് `v`-ന്റെ സമഗ്രത പരിരക്ഷിക്കുന്നു.
            // 2. `v`-ൽ ശേഷിക്കുന്ന ദ്വാരം അവസാനം പൂരിപ്പിക്കുന്നു.
            //
            // Panic സുരക്ഷ:
            //
            // പ്രോസസ്സ് സമയത്ത് ഏതെങ്കിലും ഘട്ടത്തിൽ `is_less` panics ആണെങ്കിൽ, `hole` ഉപേക്ഷിച്ച് `v` ലെ ദ്വാരം `tmp` ഉപയോഗിച്ച് പൂരിപ്പിക്കും, അങ്ങനെ `v` തുടക്കത്തിൽ കൃത്യമായി കൈവശം വച്ചിരുന്ന എല്ലാ ഒബ്ജക്റ്റുകളും ഇപ്പോഴും സൂക്ഷിക്കുന്നുണ്ടെന്ന് ഉറപ്പാക്കുന്നു.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` ഉപേക്ഷിക്കുകയും അങ്ങനെ `v`-ൽ ശേഷിക്കുന്ന ദ്വാരത്തിലേക്ക് `tmp` പകർത്തുകയും ചെയ്യുന്നു.
        }
    }

    // ഉപേക്ഷിക്കുമ്പോൾ, `src`-ൽ നിന്ന് `dest`-ലേക്ക് പകർപ്പുകൾ.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// കുറയാത്ത റൺസ് `v[..mid]`, `v[mid..]` എന്നിവ `buf` ഉപയോഗിച്ച് താൽക്കാലിക സംഭരണമായി ലയിപ്പിക്കുകയും ഫലം `v[..]`-ലേക്ക് സംഭരിക്കുകയും ചെയ്യുന്നു.
///
/// # Safety
///
/// രണ്ട് സ്ലൈസുകൾ ശൂന്യമല്ലാത്തതും `mid` അതിരുകളിലായിരിക്കണം.
/// ഹ്രസ്വ സ്ലൈസിന്റെ ഒരു പകർപ്പ് കൈവശം വയ്ക്കാൻ ബഫർ `buf` ദൈർഘ്യമേറിയതായിരിക്കണം.
/// കൂടാതെ, `T` ഒരു പൂജ്യ വലുപ്പമുള്ള തരമായിരിക്കരുത്.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // ലയന പ്രക്രിയ ആദ്യം ഹ്രസ്വ ഓട്ടം `buf` ലേക്ക് പകർത്തുന്നു.
    // തുടർന്ന് ഇത് പുതുതായി പകർത്തിയ റണ്ണും ദൈർഘ്യമേറിയ ഫോർവേഡുകളും (അല്ലെങ്കിൽ പിന്നിലേക്ക്) കണ്ടെത്തുന്നു, അവയുടെ അടുത്ത അജ്ഞാത ഘടകങ്ങളെ താരതമ്യം ചെയ്യുകയും കുറഞ്ഞ (അല്ലെങ്കിൽ കൂടുതൽ) ഒരെണ്ണം `v`-ലേക്ക് പകർത്തുകയും ചെയ്യുന്നു.
    //
    // ഹ്രസ്വമായ റൺ പൂർണ്ണമായും ഉപയോഗിച്ചുകഴിഞ്ഞാൽ, പ്രക്രിയ പൂർത്തിയാകും.ദൈർഘ്യമേറിയ ഓട്ടം ആദ്യം ഉപയോഗിച്ചാൽ, ഹ്രസ്വമായ ഓട്ടത്തിന്റെ ശേഷിക്കുന്നതെന്തും `v`-ലെ ശേഷിക്കുന്ന ദ്വാരത്തിലേക്ക് ഞങ്ങൾ പകർത്തണം.
    //
    // പ്രക്രിയയുടെ ഇന്റർമീഡിയറ്റ് അവസ്ഥ എല്ലായ്പ്പോഴും എക്സ് 100 എക്സ് ട്രാക്കുചെയ്യുന്നു, ഇത് രണ്ട് ഉദ്ദേശ്യങ്ങൾ നിറവേറ്റുന്നു:
    // 1. `is_less`-ലെ panics-ൽ നിന്ന് `v`-ന്റെ സമഗ്രത പരിരക്ഷിക്കുന്നു.
    // 2. ദൈർഘ്യമേറിയ ഓട്ടം ആദ്യം ഉപയോഗിച്ചാൽ `v`-ൽ ശേഷിക്കുന്ന ദ്വാരം നിറയ്ക്കുന്നു.
    //
    // Panic സുരക്ഷ:
    //
    // പ്രോസസ്സിനിടെ ഏതെങ്കിലും ഘട്ടത്തിൽ `is_less` panics ആണെങ്കിൽ, `hole` ഉപേക്ഷിക്കുകയും `v` ലെ ദ്വാരം `buf`-ൽ കണക്കാക്കാത്ത ശ്രേണിയിൽ നിറയ്ക്കുകയും ചെയ്യും, അങ്ങനെ `v` തുടക്കത്തിൽ കൃത്യമായി കൈവശം വച്ചിരുന്ന എല്ലാ ഒബ്ജക്റ്റുകളും ഇപ്പോഴും സൂക്ഷിക്കുന്നുണ്ടെന്ന് ഉറപ്പാക്കുന്നു.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // ഇടത് റൺ ചെറുതാണ്.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // തുടക്കത്തിൽ, ഈ പോയിന്ററുകൾ അവയുടെ ശ്രേണികളുടെ തുടക്കത്തിലേക്ക് വിരൽ ചൂണ്ടുന്നു.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // കുറഞ്ഞ വശം ഉപയോഗിക്കുക.
            // തുല്യമാണെങ്കിൽ, സ്ഥിരത നിലനിർത്താൻ ഇടത് റൺ തിരഞ്ഞെടുക്കുക.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // ശരിയായ ഓട്ടം ചെറുതാണ്.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // തുടക്കത്തിൽ, ഈ പോയിന്ററുകൾ അവയുടെ അറേയുടെ അറ്റങ്ങൾ ചൂണ്ടിക്കാണിക്കുന്നു.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // വലിയ വശം ഉപയോഗിക്കുക.
            // തുല്യമാണെങ്കിൽ, സ്ഥിരത നിലനിർത്താൻ ശരിയായ റൺ തിരഞ്ഞെടുക്കുക.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // അവസാനമായി, `hole` ഉപേക്ഷിക്കുന്നു.
    // ഹ്രസ്വമായ റൺ പൂർണ്ണമായി ഉപയോഗിച്ചില്ലെങ്കിൽ, അവശേഷിക്കുന്നവയെല്ലാം ഇപ്പോൾ `v`-ലെ ദ്വാരത്തിലേക്ക് പകർത്തപ്പെടും.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // ഉപേക്ഷിക്കുമ്പോൾ, `start..end` ശ്രേണി `dest..`-ലേക്ക് പകർത്തുന്നു.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` പൂജ്യ വലുപ്പത്തിലുള്ള തരമല്ല, അതിനാൽ അതിന്റെ വലുപ്പമനുസരിച്ച് വിഭജിക്കുന്നത് ശരിയാണ്.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// ഈ ലയനം അടുക്കൽ ടിംസോർട്ടിൽ നിന്ന് ചില (എന്നാൽ എല്ലാം അല്ല) ആശയങ്ങൾ കടമെടുക്കുന്നു, ഇത് വിശദമായി [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt) ൽ വിവരിച്ചിരിക്കുന്നു.
///
///
/// അൽ‌ഗോരിതം കർശനമായി അവരോഹണവും അവരോഹണമല്ലാത്തതുമായ തുടർച്ചകളെ തിരിച്ചറിയുന്നു, അവയെ സ്വാഭാവിക റൺസ് എന്ന് വിളിക്കുന്നു.ലയിപ്പിക്കാൻ ഇനിയും ശേഷിക്കുന്ന റൺസിന്റെ ശേഖരം ഉണ്ട്.
/// പുതുതായി കണ്ടെത്തിയ ഓരോ റണ്ണും സ്റ്റാക്കിലേക്ക് തള്ളപ്പെടും, തുടർന്ന് ഈ രണ്ട് മാറ്റങ്ങളും തൃപ്തിപ്പെടുന്നതുവരെ അടുത്തുള്ള ചില ജോഡികൾ ലയിപ്പിക്കും:
///
/// 1. `1..runs.len()`-ലെ ഓരോ `i`-നും: `runs[i - 1].len > runs[i].len`
/// 2. `2..runs.len()`-ലെ ഓരോ `i`-നും: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// ആകെ പ്രവർത്തന സമയം *O*(*n*\*log(* n*)) ഏറ്റവും മോശം അവസ്ഥയാണെന്ന് മാറ്റങ്ങൾ‌ഉറപ്പാക്കുന്നു.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // ഉൾപ്പെടുത്തൽ അടുക്കൽ ഉപയോഗിച്ച് ഈ നീളം വരെയുള്ള കഷ്ണങ്ങൾ അടുക്കുന്നു.
    const MAX_INSERTION: usize = 20;
    // ഈ നിരവധി ഘടകങ്ങളെങ്കിലും വ്യാപിപ്പിക്കുന്നതിന് ഉൾപ്പെടുത്തൽ അടുക്കൽ ഉപയോഗിച്ച് വളരെ ഹ്രസ്വമായ റൺസ് വിപുലീകരിക്കുന്നു.
    const MIN_RUN: usize = 10;

    // അടുക്കുന്നതിന് പൂജ്യ വലുപ്പത്തിലുള്ള തരങ്ങളിൽ അർത്ഥവത്തായ പെരുമാറ്റമില്ല.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // അലോക്കേഷനുകൾ ഒഴിവാക്കാൻ ഹ്രസ്വ അറേകൾ ഉൾപ്പെടുത്തൽ അടുക്കൽ വഴി സ്ഥലത്ത് അടുക്കുന്നു.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // സ്ക്രാച്ച് മെമ്മറിയായി ഉപയോഗിക്കാൻ ഒരു ബഫർ അനുവദിക്കുക.`is_less` panics ആണെങ്കിൽ പകർപ്പുകളിൽ പ്രവർത്തിക്കുന്ന dtors-നെ അപകടപ്പെടുത്താതെ `v`-ന്റെ ഉള്ളടക്കങ്ങളുടെ ആഴം കുറഞ്ഞ പകർപ്പുകൾ ഞങ്ങൾ അതിൽ സൂക്ഷിക്കാം.
    //
    // അടുക്കിയ രണ്ട് റൺസ് ലയിപ്പിക്കുമ്പോൾ, ഈ ബഫർ ഹ്രസ്വമായ റണ്ണിന്റെ ഒരു പകർപ്പ് സൂക്ഷിക്കുന്നു, അത് എല്ലായ്പ്പോഴും പരമാവധി `len / 2` ദൈർഘ്യമുള്ളതായിരിക്കും.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // `v`-ൽ സ്വാഭാവിക റൺസ് തിരിച്ചറിയുന്നതിന്, ഞങ്ങൾ അത് പിന്നിലേക്ക് സഞ്ചരിക്കുന്നു.
    // അത് ഒരു വിചിത്രമായ തീരുമാനമായി തോന്നാമെങ്കിലും ലയനം പലപ്പോഴും (forwards) വിപരീത ദിശയിലേക്ക് പോകുന്നു എന്ന വസ്തുത പരിഗണിക്കുക.
    // ബെഞ്ച്മാർക്കുകൾ അനുസരിച്ച്, മുന്നോട്ട് ലയിപ്പിക്കുന്നത് പിന്നിലേക്ക് ലയിപ്പിക്കുന്നതിനേക്കാൾ അല്പം വേഗതയുള്ളതാണ്.
    // ഉപസംഹാരമായി, പിന്നിലേക്ക് സഞ്ചരിച്ച് റൺസ് തിരിച്ചറിയുന്നത് പ്രകടനം മെച്ചപ്പെടുത്തുന്നു.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // അടുത്ത സ്വാഭാവിക റൺ കണ്ടെത്തുക, അത് കർശനമായി ഇറങ്ങുകയാണെങ്കിൽ അത് വിപരീതമാക്കുക.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // ഇത് വളരെ ചെറുതാണെങ്കിൽ കുറച്ച് ഘടകങ്ങൾ കൂടി പ്രവർത്തിപ്പിക്കുക.
        // ഹ്രസ്വ സീക്വൻസുകളിൽ ലയിപ്പിക്കുന്നതിനേക്കാൾ വേഗതയേറിയതാണ് ഉൾപ്പെടുത്തൽ ക്രമീകരണം, അതിനാൽ ഇത് പ്രകടനം ഗണ്യമായി മെച്ചപ്പെടുത്തുന്നു.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // ഈ റൺ സ്റ്റാക്കിലേക്ക് നീക്കുക.
        runs.push(Run { start, len: end - start });
        end = start;

        // മാറ്റങ്ങളെ തൃപ്‌തിപ്പെടുത്തുന്നതിന് അടുത്തുള്ള ചില ജോഡികൾ ലയിപ്പിക്കുക.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // അവസാനമായി, കൃത്യമായി ഒരു റൺ സ്റ്റാക്കിൽ തുടരണം.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // റൺസിന്റെ ശേഖരം പരിശോധിക്കുകയും ലയിപ്പിക്കാനുള്ള അടുത്ത ജോഡി റൺസ് തിരിച്ചറിയുകയും ചെയ്യുന്നു.
    // കൂടുതൽ വ്യക്തമായി പറഞ്ഞാൽ, `Some(r)` മടക്കിനൽകുകയാണെങ്കിൽ, അതിനർത്ഥം `runs[r]`, `runs[r + 1]` എന്നിവ അടുത്തതായി ലയിപ്പിക്കണം.
    // പകരം അൽ‌ഗോരിതം ഒരു പുതിയ റൺ‌നിർമ്മിക്കുന്നത് തുടരുകയാണെങ്കിൽ‌, `None` തിരികെ നൽകും.
    //
    // ടിംസോർട്ട് അതിന്റെ ബഗ്ഗി നടപ്പാക്കലുകളിൽ കുപ്രസിദ്ധമാണ്, ഇവിടെ വിവരിച്ചിരിക്കുന്നത് പോലെ:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // സ്റ്റോറിയുടെ സംഗ്രഹം ഇതാണ്: സ്റ്റാക്കിലെ മികച്ച നാല് റൺസിലെ മാറ്റങ്ങളെ ഞങ്ങൾ നടപ്പിലാക്കണം.
    // ആദ്യ മൂന്ന് സ്ഥാനങ്ങളിൽ അവ നടപ്പിലാക്കുന്നത് പര്യാപ്തമല്ല, സ്റ്റാക്കിലെ *എല്ലാ* റൺസിനും അസ്ഥിരങ്ങൾ തുടരുമെന്ന് ഉറപ്പാക്കുന്നു.
    //
    // ഈ ഫംഗ്ഷൻ മികച്ച നാല് റൺസിനായുള്ള മാറ്റങ്ങളെ ശരിയായി പരിശോധിക്കുന്നു.
    // കൂടാതെ, ടോപ്പ് റൺ സൂചിക 0 ൽ ആരംഭിക്കുന്നുവെങ്കിൽ, അടുക്കൽ പൂർത്തിയാക്കുന്നതിന്, സ്റ്റാക്ക് പൂർണ്ണമായും തകരുന്നതുവരെ എല്ലായ്പ്പോഴും ലയന പ്രവർത്തനം ആവശ്യപ്പെടും.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}