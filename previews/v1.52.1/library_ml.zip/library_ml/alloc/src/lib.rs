//! # Rust കോർ അലോക്കേഷനും കളക്ഷൻ ലൈബ്രറിയും
//!
//! കൂമ്പാരം അനുവദിച്ച മൂല്യങ്ങൾ കൈകാര്യം ചെയ്യുന്നതിനുള്ള സ്മാർട്ട് പോയിന്ററുകളും ശേഖരങ്ങളും ഈ ലൈബ്രറി നൽകുന്നു.
//!
//! ഈ ലൈബ്രറി, ലിബ്കോർ പോലെ, സാധാരണയായി [`std` crate](../std/index.html)-ൽ അതിന്റെ ഉള്ളടക്കം വീണ്ടും എക്‌സ്‌പോർട്ടുചെയ്യുന്നതിനാൽ നേരിട്ട് ഉപയോഗിക്കേണ്ടതില്ല.
//! `#![no_std]` ആട്രിബ്യൂട്ട് ഉപയോഗിക്കുന്ന Crates എന്നിരുന്നാലും സാധാരണയായി `std` നെ ആശ്രയിക്കുന്നില്ല, അതിനാൽ അവർ പകരം ഈ crate ഉപയോഗിക്കും.
//!
//! ## ബോക്‌സ് ചെയ്‌ത മൂല്യങ്ങൾ
//!
//! [`Box`] തരം ഒരു സ്മാർട്ട് പോയിന്റർ തരമാണ്.ഒരു [`Box`]-ന്റെ ഒരു ഉടമ മാത്രമേ ഉണ്ടാകൂ, ഒപ്പം ഉടമസ്ഥന് ഉള്ളടക്കങ്ങൾ പരിവർത്തനം ചെയ്യാൻ തീരുമാനിക്കാം, അത് കൂമ്പാരത്തിൽ വസിക്കുന്നു.
//!
//! ഒരു `Box` മൂല്യത്തിന്റെ വലുപ്പം ഒരു പോയിന്ററിന്റേതിന് തുല്യമായതിനാൽ ഈ തരം ത്രെഡുകൾക്കിടയിൽ കാര്യക്ഷമമായി അയയ്‌ക്കാൻ കഴിയും.
//! ഓരോ നോഡിനും മിക്കപ്പോഴും ഒരു ഉടമസ്ഥൻ മാത്രമേ ഉള്ളൂ, കാരണം രക്ഷകർത്താവ് പോലുള്ള മരങ്ങൾ പോലുള്ള ഡാറ്റാ ഘടനകൾ പലപ്പോഴും ബോക്സുകൾ ഉപയോഗിച്ചാണ് നിർമ്മിച്ചിരിക്കുന്നത്.
//!
//! ## റഫറൻസ് കണക്കാക്കിയ പോയിന്ററുകൾ
//!
//! ഒരു ത്രെഡിനുള്ളിൽ മെമ്മറി പങ്കിടാൻ ഉദ്ദേശിച്ചുള്ള ത്രെഡ്‌സേഫ് അല്ലാത്ത റഫറൻസ്-കണക്കാക്കിയ പോയിന്റർ തരമാണ് [`Rc`] തരം.
//! ഒരു [`Rc`] പോയിന്റർ `T` എന്ന തരം പൊതിയുന്നു, ഒപ്പം പങ്കിട്ട റഫറൻസായ `&T`-ലേക്ക് മാത്രം പ്രവേശനം അനുവദിക്കുന്നു.
//!
//! പാരമ്പര്യമായി പരിവർത്തനം ([`Box`] ഉപയോഗിക്കുന്നത് പോലുള്ളവ) ഒരു അപ്ലിക്കേഷന് വളരെയധികം പരിമിതപ്പെടുത്തുമ്പോൾ ഈ തരം ഉപയോഗപ്രദമാണ്, മാത്രമല്ല മ്യൂട്ടേഷൻ അനുവദിക്കുന്നതിനായി പലപ്പോഴും [`Cell`] അല്ലെങ്കിൽ [`RefCell`] തരങ്ങളുമായി ജോടിയാക്കപ്പെടുന്നു.
//!
//!
//! ## ആറ്റോമിക് റഫറൻസ് എണ്ണപ്പെട്ട പോയിന്ററുകൾ
//!
//! [`Rc`] തരത്തിന് തുല്യമായ ത്രെഡ്‌സെഫ് ആണ് [`Arc`] തരം.ഇത് [`Rc`]-ന്റെ എല്ലാ സമാന പ്രവർത്തനങ്ങളും നൽകുന്നു, ഇതിൽ അടങ്ങിയിരിക്കുന്ന `T` തരം പങ്കിടാനാകുമെന്ന് ആവശ്യപ്പെടുന്നു.
//! കൂടാതെ, [`Rc<T>`][`Rc`] അല്ലാത്തപ്പോൾ [`Arc<T>`][`Arc`] തന്നെ അയയ്‌ക്കാവുന്നതാണ്.
//!
//! അടങ്ങിയിരിക്കുന്ന ഡാറ്റയിലേക്ക് പങ്കിട്ട ആക്‌സസ്സ് ഈ തരം അനുവദിക്കുന്നു, ഒപ്പം പങ്കിട്ട ഉറവിടങ്ങളുടെ പരിവർത്തനം അനുവദിക്കുന്നതിന് മ്യൂട്ടക്സുകൾ പോലുള്ള സമന്വയ പ്രൈമിറ്റീവുകളുമായി ജോടിയാക്കുന്നു.
//!
//! ## Collections
//!
//! ഏറ്റവും സാധാരണമായ പൊതു ആവശ്യത്തിനുള്ള ഡാറ്റാ ഘടനകളുടെ നടപ്പാക്കലുകൾ ഈ ലൈബ്രറിയിൽ നിർവചിച്ചിരിക്കുന്നു.[standard collections library](../std/collections/index.html) വഴി അവ വീണ്ടും കയറ്റുമതി ചെയ്യുന്നു.
//!
//! ## കൂമ്പാര ഇന്റർഫേസുകൾ
//!
//! [`alloc`](alloc/index.html) മൊഡ്യൂൾ സ്ഥിരസ്ഥിതി ആഗോള അലോക്കേറ്ററിലേക്കുള്ള ലോ-ലെവൽ ഇന്റർഫേസ് നിർവചിക്കുന്നു.ഇത് libc അലോക്കേറ്റർ API-യുമായി പൊരുത്തപ്പെടുന്നില്ല.
//!
//! [`Arc`]: sync
//! [`Box`]: boxed
//! [`Cell`]: core::cell
//! [`Rc`]: rc
//! [`RefCell`]: core::cell
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(unused_attributes)]
#![stable(feature = "alloc", since = "1.36.0")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(allow(unused_variables), deny(warnings)))
)]
#![no_std]
#![needs_allocator]
#![warn(deprecated_in_future)]
#![warn(missing_docs)]
#![warn(missing_debug_implementations)]
#![allow(explicit_outlives_requirements)]
#![deny(unsafe_op_in_unsafe_fn)]
#![feature(rustc_allow_const_fn_unstable)]
#![cfg_attr(not(test), feature(generator_trait))]
#![cfg_attr(test, feature(test))]
#![cfg_attr(test, feature(new_uninit))]
#![feature(allocator_api)]
#![feature(vec_extend_from_within)]
#![feature(array_chunks)]
#![feature(array_methods)]
#![feature(array_windows)]
#![feature(allow_internal_unstable)]
#![feature(arbitrary_self_types)]
#![feature(async_stream)]
#![feature(box_patterns)]
#![feature(box_syntax)]
#![feature(cfg_sanitize)]
#![feature(cfg_target_has_atomic)]
#![feature(coerce_unsized)]
#![feature(const_btree_new)]
#![feature(const_fn)]
#![feature(cow_is_borrowed)]
#![feature(const_cow_is_borrowed)]
#![feature(destructuring_assignment)]
#![feature(dispatch_from_dyn)]
#![feature(core_intrinsics)]
#![feature(dropck_eyepatch)]
#![feature(exact_size_is_empty)]
#![feature(exclusive_range_pattern)]
#![feature(extend_one)]
#![feature(fmt_internals)]
#![feature(fn_traits)]
#![feature(fundamental)]
#![feature(inplace_iteration)]
#![feature(int_bits_const)]
// സാങ്കേതികമായി, ഇത് റസ്റ്റ്‌ഡോക്കിലെ ഒരു ബഗ് ആണ്: `#[lang = slice_alloc]` ബ്ലോക്കുകളിലെ ഡോക്യുമെന്റേഷൻ `&[T]`-നുള്ളതാണെന്ന് റസ്റ്റ്‌ഡോക് കാണുന്നു, ഇതിന് `core`-ൽ ഈ സവിശേഷത ഉപയോഗിച്ച് ഡോക്യുമെന്റേഷനുമുണ്ട്, കൂടാതെ സവിശേഷത-ഗേറ്റ് പ്രവർത്തനക്ഷമമാക്കിയിട്ടില്ലെന്ന് ഭ്രാന്തനാകുന്നു.
// മറ്റ് crates ൽ നിന്നുള്ള ഡോക്സിനുള്ള ഫീച്ചർ ഗേറ്റിനായി ഇത് പരിശോധിക്കില്ല, പക്ഷേ ഇത് ലാംഗ് ഇനങ്ങൾക്ക് മാത്രമേ ദൃശ്യമാകൂ എന്നതിനാൽ, ഇത് പരിഹരിക്കേണ്ടതായി തോന്നുന്നില്ല.
//
//
#![feature(intra_doc_pointers)]
#![feature(lang_items)]
#![feature(layout_for_ptr)]
#![feature(maybe_uninit_ref)]
#![feature(negative_impls)]
#![feature(never_type)]
#![feature(nll)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(auto_traits)]
#![feature(option_result_unwrap_unchecked)]
#![feature(or_patterns)]
#![feature(pattern)]
#![feature(ptr_internals)]
#![feature(rustc_attrs)]
#![feature(receiver_trait)]
#![feature(min_specialization)]
#![feature(set_ptr_value)]
#![feature(slice_ptr_get)]
#![feature(slice_ptr_len)]
#![feature(slice_range)]
#![feature(staged_api)]
#![feature(str_internals)]
#![feature(trusted_len)]
#![feature(unboxed_closures)]
#![feature(unicode_internals)]
#![cfg_attr(bootstrap, feature(unsafe_block_in_unsafe_fn))]
#![feature(unsize)]
#![feature(unsized_fn_params)]
#![feature(allocator_internals)]
#![feature(slice_partition_dedup)]
#![feature(maybe_uninit_extra, maybe_uninit_slice, maybe_uninit_uninit_array)]
#![feature(alloc_layout_extra)]
#![feature(trusted_random_access)]
#![feature(try_trait)]
#![cfg_attr(bootstrap, feature(type_alias_impl_trait))]
#![cfg_attr(not(bootstrap), feature(min_type_alias_impl_trait))]
#![feature(associated_type_bounds)]
#![feature(slice_group_by)]
#![feature(decl_macro)]
// ഈ ലൈബ്രറി പരീക്ഷിക്കാൻ അനുവദിക്കുക

#[cfg(test)]
#[macro_use]
extern crate std;
#[cfg(test)]
extern crate test;

// മറ്റ് മൊഡ്യൂളുകൾ ഉപയോഗിക്കുന്ന ആന്തരിക മാക്രോകളുള്ള മൊഡ്യൂൾ (മറ്റ് മൊഡ്യൂളുകൾക്ക് മുമ്പ് ഉൾപ്പെടുത്തേണ്ടതുണ്ട്).
#[macro_use]
mod macros;

// താഴ്ന്ന നിലയിലുള്ള അലോക്കേഷൻ തന്ത്രങ്ങൾക്കായി കൂമ്പാരങ്ങൾ നൽകിയിട്ടുണ്ട്

pub mod alloc;

// മുകളിലുള്ള കൂമ്പാരങ്ങൾ ഉപയോഗിച്ച് പ്രാകൃത തരങ്ങൾ

// ടെസ്റ്റ് cfg-ൽ നിർമ്മിക്കുമ്പോൾ ലാംഗ്-ഇനങ്ങൾ തനിപ്പകർപ്പാക്കുന്നത് ഒഴിവാക്കാൻ `boxed.rs`-ൽ നിന്ന് മോഡിനെ സോപാധികമായി നിർവചിക്കേണ്ടതുണ്ട്;മാത്രമല്ല `use boxed::Box;` ഡിക്ലറേഷൻ ഉള്ള കോഡിനെ അനുവദിക്കേണ്ടതുണ്ട്.
//
//
#[cfg(not(test))]
pub mod boxed;
#[cfg(test)]
mod boxed {
    pub use std::boxed::Box;
}
pub mod borrow;
pub mod collections;
pub mod fmt;
pub mod prelude;
pub mod raw_vec;
pub mod rc;
pub mod slice;
pub mod str;
pub mod string;
#[cfg(target_has_atomic = "ptr")]
pub mod sync;
#[cfg(target_has_atomic = "ptr")]
pub mod task;
#[cfg(test)]
mod tests;
pub mod vec;

#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
pub mod __export {
    pub use core::format_args;
}