# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Knjižnica za pridobivanje povratnih sledi med izvajanjem za Rust.
Namen te knjižnice je izboljšati podporo standardne knjižnice z zagotavljanjem programskega vmesnika za delo, podpira pa tudi preprosto preprosto tiskanje trenutne povratne sledi, kot je libstd-ov panics.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Če želite preprosto zajeti povratno sled in odložiti obravnavo z njim pozneje, lahko uporabite tip `Backtrace` najvišje ravni.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Če pa želite več surovega dostopa do dejanske funkcije sledenja, lahko neposredno uporabite funkciji `trace` in `resolve`.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Ta kazalec navodil razrešite na ime simbola
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // nadaljujte na naslednji okvir
    });
}
```

# License

Ta projekt je licenciran pod katerim koli od

 * Licenca Apache, različica 2.0, ([LICENSE-APACHE](LICENSE-APACHE) ali http://www.apache.org/licenses/LICENSE-2.0)
 * Licenca MIT ([LICENSE-MIT](LICENSE-MIT) ali http://opensource.org/licenses/MIT)

po vaši izbiri.

### Contribution

Če izrecno ne navedete drugače, bo vsak prispevek, ki ste ga namerno oddali za vključitev v backtrace-rs, kot je določeno v licenci Apache-2.0, dvojno licenciran, kot je navedeno zgoraj, brez dodatnih pogojev.







