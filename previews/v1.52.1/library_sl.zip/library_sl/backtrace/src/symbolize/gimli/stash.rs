// trenutno se uporablja samo na Linux, zato mrtvo kodo dovolite drugje
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Preprost razdeljevalec aren za bajtne medpomnilnike.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Dodeljuje medpomnilnik določene velikosti in mu vrne spremenljiv sklic.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // VARNOST: to je edina funkcija, ki kdajkoli izdela spremenljivko
        // sklic na `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // VARNOST: Nikoli ne odstranimo elementov iz `self.buffers`, zato referenca
        // podatki znotraj katerega koli vmesnega pomnilnika bodo živeli tako dolgo kot `self`.
        &mut buffers[i]
    }
}