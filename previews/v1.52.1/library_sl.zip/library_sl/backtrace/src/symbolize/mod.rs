use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Razredite naslov na simbol in ga prenesite v določeno zaporo.
///
/// Ta funkcija bo iskala dani naslov na področjih, kot so tabela lokalnih simbolov, dinamična tabela simbolov ali informacije o odpravljanju napak DWARF (odvisno od aktivirane izvedbe), da bi poiskala simbole, ki jih bodo dobili.
///
///
/// Zapiranja ni mogoče poklicati, če ločljivosti ni bilo mogoče izvesti, v primeru vstavljenih funkcij pa ga je mogoče poklicati tudi večkrat.
///
/// Pridobljeni simboli predstavljajo izvajanje na določenem `addr`, ki vrne pare file/line za ta naslov (če je na voljo).
///
/// Če imate `Frame`, je priporočljivo, da namesto te uporabite funkcijo `resolve_frame`.
///
/// # Zahtevane funkcije
///
/// Ta funkcija zahteva, da je omogočena funkcija `std` `backtrace` crate, funkcija `std` pa je privzeto omogočena.
///
/// # Panics
///
/// Ta funkcija si prizadeva nikoli panic, če pa je `cb` zagotovil panics, bodo nekatere platforme prisilile dvojno panic, da prekine postopek.
/// Nekatere platforme uporabljajo knjižnico C, ki interno uporablja povratne klice, ki jih ni mogoče odviti, zato lahko panika iz `cb` sproži postopek.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // poglejte samo zgornji okvir
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Predhodni okvir za zajemanje razrešite na simbol in ga prenesite v določeno zaporo.
///
/// Ta funkcija opravlja enako funkcijo kot `resolve`, le da kot argument namesto naslova vzame `Frame`.
/// To lahko nekaterim izvedbam backtracinga omogoči natančnejše informacije o simbolih ali informacije o vstavljenih okvirih, na primer.
///
/// Priporočljivo je, da to uporabite, če lahko.
///
/// # Zahtevane funkcije
///
/// Ta funkcija zahteva, da je omogočena funkcija `std` `backtrace` crate, funkcija `std` pa je privzeto omogočena.
///
/// # Panics
///
/// Ta funkcija si prizadeva nikoli panic, če pa je `cb` zagotovil panics, bodo nekatere platforme prisilile dvojno panic, da prekine postopek.
/// Nekatere platforme uporabljajo knjižnico C, ki interno uporablja povratne klice, ki jih ni mogoče odviti, zato lahko panika iz `cb` sproži postopek.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // poglejte samo zgornji okvir
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// Vrednosti IP iz okvirov skladov so ponavadi (always?) navodila *po* klicu, ki je dejanska sled sklada.
// Če to označite, je številka filename/line ena naprej in morda v prazno, če je blizu konca funkcije.
//
// Zdi se, da to v bistvu vedno velja na vseh platformah, zato od razrešenega ip-ja vedno odštejemo enega, da ga razrešimo na prejšnje navodilo klica, namesto da bi se ukaz vrnil.
//
//
// V idealnem primeru tega ne bi storili.
// V idealnem primeru bi od klicateljev API-jev `resolve` tukaj zahtevali, da ročno opravijo -1 in upoštevajo, da želijo informacije o lokaciji za *prejšnje* navodilo, ne trenutno.
// V idealnem primeru bi tudi na `Frame` izpostavili, če smo res naslov naslednjega navodila ali trenutnega.
//
// Za zdaj je to precej nišna skrb, zato jo samo interno vedno odštejemo.
// Potrošniki bi morali še naprej delati in dosegati precej dobre rezultate, zato bi morali biti dovolj dobri.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Enako kot `resolve`, le da ni varen, ker je sinhroniziran.
///
/// Ta funkcija nima garancij za sinhronizacijo, vendar je na voljo, ko funkcija `std` tega crate ni prevedena.
/// Za več dokumentacije in primerov glejte funkcijo `resolve`.
///
/// # Panics
///
/// Glejte informacije o `resolve` za opozorila glede panike `cb`.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Enako kot `resolve_frame`, le da ni varen, ker je nesinhroniziran.
///
/// Ta funkcija nima garancij za sinhronizacijo, vendar je na voljo, ko funkcija `std` tega crate ni prevedena.
/// Za več dokumentacije in primerov glejte funkcijo `resolve_frame`.
///
/// # Panics
///
/// Glejte informacije o `resolve_frame` za opozorila glede panike `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// Portrait, ki predstavlja ločljivost simbola v datoteki.
///
/// Ta Portrait je podan kot objekt Portrait za zapiranje, dano funkciji `backtrace::resolve`, in je tako rekoč poslan, saj ni znano, katera izvedba stoji za tem.
///
///
/// Simbol lahko daje kontekstualne informacije o funkciji, na primer ime, ime datoteke, številka vrstice, natančen naslov itd.
/// Vse simboli niso vedno na voljo v simbolu, zato vse metode vrnejo `Option`.
///
///
pub struct Symbol {
    // TODO: to življenjsko dobo je treba sčasoma ohraniti do `Symbol`,
    // ampak to je trenutno prelomna sprememba.
    // Za zdaj je to varno, saj je `Symbol` vedno izročen samo po referenci in ga ni mogoče klonirati.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Vrne ime te funkcije.
    ///
    /// Vrnjeno strukturo lahko uporabimo za poizvedovanje različnih lastnosti glede imena simbola:
    ///
    ///
    /// * Izvedba `Display` bo natisnila razčlenjeni simbol.
    /// * Dostop do surove vrednosti `str` simbola (če je veljaven utf-8).
    /// * Dostop do surovih bajtov za ime simbola.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Vrne začetni naslov te funkcije.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Vrne neobdelano ime datoteke kot rezino.
    /// To je koristno predvsem za okolja `no_std`.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Vrne številko stolpca, kjer se trenutno izvaja ta simbol.
    ///
    /// Trenutno samo vrednost gimli ponuja vrednost tukaj in tudi takrat le, če `filename` vrne `Some`, zato je potem podvržen podobnim opozorilom.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Vrne številko vrstice, kjer se trenutno izvaja ta simbol.
    ///
    /// Ta vrnjena vrednost je običajno `Some`, če `filename` vrne `Some`, in je zato predmet podobnih opozoril.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Vrne ime datoteke, kjer je bila definirana ta funkcija.
    ///
    /// Trenutno je na voljo samo, kadar se uporablja libbacktrace ali gimli (npr
    /// unix druge platforme) in kadar je binarno datoteko prevedeno z debuginfo.
    /// Če noben od teh pogojev ni izpolnjen, bo to verjetno vrnilo `None`.
    ///
    /// # Zahtevane funkcije
    ///
    /// Ta funkcija zahteva, da je omogočena funkcija `std` `backtrace` crate, funkcija `std` pa je privzeto omogočena.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Mogoče razčlenjeni simbol C++ , če razčlenjevanje pretvorjenega simbola kot Rust ni uspelo.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Poskrbite, da bo ta nič velika, tako da funkcija `cpp_demangle` ne bo imela stroškov, če je onemogočena.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Ovoj okoli imena simbola, ki zagotavlja ergonomske dostopnike do razčlenjenega imena, neobdelanih bajtov, surovega niza itd.
///
// Dovoli mrtvo kodo, če funkcija `cpp_demangle` ni omogočena.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Ustvari novo ime simbola iz surovih osnovnih bajtov.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Vrne neobdelano ime simbola (mangled) kot `str`, če je simbol veljaven utf-8.
    ///
    /// Če želite razčlenjeno različico, uporabite izvedbo `Display`.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Vrne ime surovega simbola kot seznam bajtov
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // To se lahko natisne, če razstavljeni simbol dejansko ni veljaven, zato napako obravnavajte tukaj elegantno, tako da je ne razširjate navzven.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Poskus povrnitve predpomnilnika, ki se uporablja za simboliziranje naslovov.
///
/// Ta metoda bo poskušala sprostiti vse globalne podatkovne strukture, ki so bile sicer predpomnjene v globalnem ali v niti, ki običajno predstavljajo razčlenjene informacije o DWARF ali podobno.
///
///
/// # Caveats
///
/// Čeprav je ta funkcija vedno na voljo, v večini izvedb dejansko ne naredi ničesar.
/// Knjižnice, kot sta dbghelp ali libbacktrace, ne ponujajo naprav za odstranjevanje stanja in upravljanje dodeljenega pomnilnika.
/// Zaenkrat je funkcija `gimli-symbolize` tega crate edina funkcija, pri kateri ta funkcija učinkuje.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}