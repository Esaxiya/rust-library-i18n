//! Strategija simboliziranja z uporabo kode za razčlenjevanje DWARF v libbacktrace.
//!
//! Knjižnica libbacktrace C, ki se običajno distribuira z gcc, podpira ne samo ustvarjanje povratne sledi (ki je v resnici ne uporabljamo), temveč tudi simbolizacijo povratne sledi in obdelavo informacij o odpravljanju napak škratov o stvareh, kot so vstavljeni okvirji in kaj drugega.
//!
//!
//! To je razmeroma zapleteno zaradi številnih različnih pomislekov, vendar je osnovna ideja:
//!
//! * Najprej pokličemo `backtrace_syminfo`.Če lahko, ta dobi informacije o simbolih iz tabele dinamičnih simbolov.
//! * Nato pokličemo `backtrace_pcinfo`.Ta bo razčlenil tabele debuginfo, če so na voljo, in nam omogočil obnovitev informacij o vstavljenih okvirih, imenih datotek, številkah vrstic itd.
//!
//! Obstaja veliko trikov, kako spraviti škratje tabele v libbacktrace, vendar upamo, da še ni konec sveta in je dovolj jasen, ko beremo spodaj.
//!
//! To je privzeta strategija označevanja za platforme, ki niso MSVC in ne OSX.V libstd pa je to privzeta strategija za OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Če je mogoče, raje ime `function`, ki prihaja iz debuginfo in je lahko na primer bolj natančno za vstavljene okvire.
                // Če tega ni, se vrnite na ime tabele simbolov, določeno v `symname`.
                //
                // Upoštevajte, da se lahko včasih `function` počuti nekoliko manj natančno, na primer, ko je naštet kot `try<i32,closure>`, ki je del `std::panicking::try::do_call`.
                //
                // V resnici ni jasno, zakaj, vendar je na splošno ime `function` videti bolj natančno.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // za zdaj ne naredi ničesar
}

/// Tip kazalca `data`, ki je prešel v `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Ko se ta povratni klic prikliče iz `backtrace_syminfo`, ko začnemo razreševati, gremo dalje k `backtrace_pcinfo`.
    // Funkcija `backtrace_pcinfo` se bo posvetovala z informacijami o odpravljanju napak in poskusila obnoviti podatke file/line in vstavljene okvire.
    // Upoštevajte, da `backtrace_pcinfo` lahko odpove ali ne naredi veliko, če ni informacij o odpravljanju napak, tako da bomo v tem primeru zagotovo poklicali povratni klic z vsaj enim simbolom iz `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Tip kazalca `data`, ki je prešel v `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// API libbacktrace podpira ustvarjanje stanja, vendar ne podpira uničenja stanja.
// Sama to razumem tako, da pomeni državo, ki naj bi nastala in potem živela večno.
//
// Želel bi registrirati at_exit() upravljalec, ki očisti to stanje, vendar libbacktrace ne omogoča tega.
//
// S temi omejitvami ima ta funkcija statično predpomnjeno stanje, ki se izračuna prvič, ko je to zahtevano.
//
// Ne pozabite, da se sledenje vse dogaja zaporedno (ena globalna ključavnica).
//
// Upoštevajte, da je pomanjkanje sinhronizacije tukaj posledica zahteve po zunanji sinhronizaciji `resolve`.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Ne izvajajte varnih zmožnosti libbacktrace, saj ga vedno kličemo sinhronizirano.
        //
        0,
        error_cb,
        ptr::null_mut(), // brez dodatnih podatkov
    );

    return STATE;

    // Upoštevajte, da mora libbacktrace sploh delovati, mora najti informacije o odpravljanju napak DWARF za trenutno izvršljivo datoteko.Običajno to počne prek številnih mehanizmov, vključno z, vendar ne omejeno na:
    //
    // * /proc/self/exe na podprtih platformah
    // * Ime datoteke je bilo izrecno posredovano pri ustvarjanju stanja
    //
    // Knjižnica libbacktrace je velika gmota kode C.To seveda pomeni, da ima ranljivosti glede varnosti pomnilnika, zlasti pri ravnanju z nepravilno oblikovanim debuginfo.
    // Libstd je v preteklosti naletel na veliko teh.
    //
    // Če se uporablja /proc/self/exe, jih lahko običajno prezremo, saj predpostavljamo, da je libbacktrace "mostly correct" in sicer ne počne čudnih stvari z informacijami o odpravljanju napak "attempted to be correct".
    //
    //
    // Če pa vnesemo ime datoteke, potem je na nekaterih platformah (na primer BSD) mogoče, da lahko zlonamerni igralec povzroči, da se na to mesto postavi poljubna datoteka.
    // To pomeni, da če povemo libbacktrace o imenu datoteke, morda uporablja poljubno datoteko, ki lahko povzroči segfaults.
    // Če ne povemo ničesar libbacktrace, potem ne bo naredil ničesar na platformah, ki ne podpirajo poti, kot je /proc/self/exe!
    //
    // Glede na vse, kar se trudimo, da *ne* posredujemo imena datoteke, vendar moramo na platformah, ki sploh ne podpirajo /proc/self/exe.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Upoštevajte, da bi v idealnem primeru uporabili `std::env::current_exe`, vendar `std` tukaj ne moremo zahtevati.
            //
            // Uporabite `_NSGetExecutablePath`, da naložite trenutno izvršljivo pot v statično območje (če je premajhno, pa preprosto odnehajte).
            //
            //
            // Upoštevajte, da tukaj resnično zaupamo libbacktraceu, da ne bo umrl zaradi poškodovanih izvršljivih datotek, vendar zagotovo ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows ima način odpiranja datotek, kjer po odprtju ni mogoče izbrisati.
            // To je na splošno tisto, kar si tukaj želimo, ker želimo zagotoviti, da se naša izvršljiva datoteka ne bo spremenila izpod nas, potem ko jo bomo predali libbacktrace, upajmo, da bomo ublažili zmožnost prenašanja poljubnih podatkov v libbacktrace (kar je lahko napačno obdelano).
            //
            //
            // Glede na to, da tu malo plešemo, da bi poskušali doseči nekakšen zaklep na lastno podobo:
            //
            // * Pridobite ročaj za trenutni postopek, naložite njegovo ime datoteke.
            // * Odprite datoteko s tem imenom z ustreznimi zastavicami.
            // * Znova naložite ime datoteke trenutnega procesa in se prepričajte, da je enako
            //
            // Če vse to mine, smo teoretično res odprli datoteko našega procesa in smo prepričani, da se to ne bo spremenilo.FWIW kup tega je v preteklosti kopiran iz libstd, zato je to moja najboljša interpretacija dogajanja.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Ta živi v statičnem spominu, da ga lahko vrnemo ..
                static mut BUF: [i8; N] = [0; N];
                // ... in to živi na kupu, ker je začasno
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // namerno pušča `handle` sem, ker bi to odprto ohranilo našo ključavnico za to ime datoteke.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Vrniti želimo rezino, ki je ničelna, tako da če je bilo vse izpolnjeno in je enaka celotni dolžini, jo enačite z okvaro.
                //
                //
                // V nasprotnem primeru se pri vrnitvi uspeha prepričajte, da je v rezino vključen nul bajt.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // napake povratnega sledenja so trenutno pometene pod preprogo
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Pokličite API `backtrace_syminfo`, ki naj (od branja kode) natančno enkrat pokliče `syminfo_cb` (ali pa verjetno z napako).
    // Nato v `syminfo_cb` obdelamo več.
    //
    // Upoštevajte, da to počnemo, saj bo `syminfo` pregledal tabelo simbolov in poiskal imena simbolov, tudi če v binarni datoteki ni informacij o odpravljanju napak.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}