//! Modul za pomoč pri upravljanju vezi dbghelp na Windows
//!
//! Povratne sledi na Windows (vsaj za MSVC) v veliki meri poganja `dbghelp.dll` in različne funkcije, ki jih vsebuje.
//! Te funkcije so trenutno naložene *dinamično*, namesto da bi se statično povezale z `dbghelp.dll`.
//! Trenutno to počne standardna knjižnica (in teoretično tam zahteva), vendar je to prizadevanje za zmanjšanje statičnih odvisnosti DLL v knjižnici, saj so povratni sledovi običajno precej neobvezni.
//!
//! Glede na to se `dbghelp.dll` skoraj vedno uspešno naloži na Windows.
//!
//! Upoštevajte, da ker dinamično nalagamo vso to podporo, dejansko ne moremo uporabiti surovih definicij v `winapi`, temveč moramo sami določiti vrste kazalcev funkcij in to uporabiti.
//! V resnici se ne želimo ukvarjati s podvajanjem winapi, zato imamo funkcijo Cargo `verify-winapi`, ki trdi, da se vse povezave ujemajo s tistimi v winapiju in je ta funkcija omogočena na CI.
//!
//! Na koncu boste tu opazili, da dll za `dbghelp.dll` ni nikoli razložen in to je trenutno namerno.
//! Razmišljamo, da ga lahko globalno predpomnimo in uporabimo med klici API-ja, pri čemer se izognemo dragemu loads/unloads.
//! Če je to težava za detektorje puščanja ali kaj podobnega, lahko prečkamo most, ko pridemo tja.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Delo okoli `SymGetOptions` in `SymSetOptions` ni prisotno v samem winapiju.
// V nasprotnem primeru se to uporablja samo, kadar dvojno preverjamo vrste glede na winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // V winapiju še ni določeno
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // To je določeno v winapi, vendar ni pravilno (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // V winapiju še ni določeno
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Ta makro se uporablja za definiranje strukture `Dbghelp`, ki interno vsebuje vse kazalce funkcij, ki jih lahko naložimo.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// Naloženi DLL za `dbghelp.dll`
            dll: HMODULE,

            // Vsak kazalnik funkcije za vsako funkcijo, ki jo lahko uporabimo
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Sprva nismo naložili DLL-a
            dll: 0 as *mut _,
            // Vse funkcije so na začetku nastavljene na nič, kar pomeni, da jih je treba dinamično naložiti.
            //
            $($name: 0,)*
        };

        // Priročnost typedef za vsako vrsto funkcije.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Poskusi odpreti `dbghelp.dll`.
            /// Vrne uspeh, če deluje, ali napako, če `LoadLibraryW` ne uspe.
            ///
            /// Panics, če je knjižnica že naložena.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Funkcija za vsako metodo, ki jo želimo uporabiti.
            // Ko ga pokličete, bo prebral kazalec predpomnjene funkcije ali ga naložil in vrnil naloženo vrednost.
            // Obremenitve trdijo, da uspejo.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Priročen proxy za uporabo ključavnic za čiščenje za sklicevanje na funkcije dbghelp.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Inicializirajte vso podporo, potrebno za dostop do funkcij API-ja `dbghelp` s tega crate.
///
///
/// Ta funkcija je **varna**, ima interno sinhronizacijo.
/// Upoštevajte tudi, da je varno večkrat rekurzivno poklicati to funkcijo.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Najprej moramo sinhronizirati to funkcijo.To lahko pokličete sočasno iz drugih niti ali rekurzivno znotraj ene niti.
        // Upoštevajte, da je bolj zapleteno od tega, ker je tisto, kar tukaj uporabljamo, `dbghelp`,*tudi* treba v tem postopku sinhronizirati z vsemi drugimi klicatelji na `dbghelp`.
        //
        // Običajno v istem postopku ni toliko klicev na `dbghelp` in verjetno lahko varno domnevamo, da smo edini, ki dostopajo do njega.
        // Obstaja pa še en primarni uporabnik, ki ga moramo skrbeti, kar je ironično mi sami, vendar v standardni knjižnici.
        // Standardna knjižnica Rust je odvisna od tega crate za podporo pri sledenju, ta crate pa obstaja tudi na crates.io.
        // To pomeni, da lahko, če standardna knjižnica tiska povratno sled panic, lahko dirka s tem crate, ki prihaja iz crates.io, kar povzroči segfaults.
        //
        // Za reševanje te težave s sinhronizacijo tu uporabljamo trik, specifičen za Windows (navsezadnje gre za omejitev sinhronizacije, specifično za Windows).
        // Ustvarimo *lokalno sejo* z imenom mutex, da zaščitimo ta klic.
        // Namen tega je, da standardni knjižnici in tej crate ni treba deliti API-jev na ravni Rust, da se tukaj sinhronizirajo, ampak lahko namesto tega delajo v ozadju, da se prepričajo, da se sinhronizirajo med seboj.
        //
        // Na ta način, ko je ta funkcija poklicana prek standardne knjižnice ali prek crates.io, smo lahko prepričani, da je pridobljen isti mutex.
        //
        // Torej vse to pomeni, da prvo, kar tukaj naredimo, je, da atomsko ustvarimo `HANDLE`, ki je imenovani mutex na Windows.
        // Nekoliko sinhroniziramo z drugimi nitmi, ki si delijo to funkcijo posebej, in zagotovimo, da je na primerek te funkcije ustvarjen samo en ročaj.
        // Upoštevajte, da se ročaj nikoli ne zapre, ko je shranjen v globalni.
        //
        // Ko dejansko zapremo ključavnico, jo preprosto pridobimo in naš ročaj `Init`, ki ga izročimo, bo odgovoren, da ga sčasoma spustimo.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ok, fuj!Zdaj, ko smo vsi varno sinhronizirani, začnemo dejansko vse obdelati.
        // Najprej moramo zagotoviti, da je `dbghelp.dll` dejansko naložen v tem procesu.
        // To počnemo dinamično, da se izognemo statični odvisnosti.
        // V preteklosti je bilo to storjeno za odpravljanje čudnih težav s povezovanjem in naj bi binarne datoteke naredili nekoliko bolj prenosljive, saj je to v glavnem le pripomoček za odpravljanje napak.
        //
        //
        // Ko odpremo `dbghelp.dll`, moramo v njem poklicati nekaj funkcij za inicializacijo, ki so podrobneje opisane spodaj.
        // Vendar to storimo le enkrat, zato imamo globalno logično vrednost, ki označuje, ali smo še končali ali ne.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Prepričajte se, da je zastavica `SYMOPT_DEFERRED_LOADS` nastavljena, kajti v skladu z lastnimi dokumenti MSVC o tem: "This is the fastest, most efficient way to use the symbol handler.", torej naredimo to!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Pravzaprav inicializirajte simbole z MSVC.Upoštevajte, da to lahko propade, vendar ga ignoriramo.
        // Strokovnega znanja za to samo po sebi ni na tone, toda zdi se, da LLVM tu prezre vrnjeno vrednost in ena od knjižnic dezinfekcijskih sredstev v LLVM natisne strašljivo opozorilo, če to ne uspe, vendar ga v bistvu dolgoročno prezre.
        //
        //
        // Eden od primerov, ki se tega zelo odraža pri Rust, je ta, da hočeta običajna knjižnica in ta crate na crates.io tekmovati za `SymInitializeW`.
        // Standardna knjižnica je v preteklosti večino časa želela inicializirati in nato očistiti, toda zdaj, ko uporablja ta crate, pomeni, da bo nekdo najprej prišel do inicializacije, druga pa jo bo prevzela.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}