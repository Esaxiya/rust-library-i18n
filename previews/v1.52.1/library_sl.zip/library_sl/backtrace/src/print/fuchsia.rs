use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr sprejme povratni klic, ki bo prejel kazalec dl_phdr_info za vsak sistemski sistem distribucije, ki je bil povezan v postopek.
    // dl_iterate_phdr tudi zagotavlja, da je dinamični povezovalnik zaklenjen od začetka do konca ponovitve.
    // Če povratni klic vrne vrednost, ki ni nič, se ponovitev predčasno zaključi.
    // 'data' bo posredovana kot tretji argument povratnemu klicu pri vsakem klicu.
    // 'size' poda velikost dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Razčleniti moramo ID gradnje in nekatere osnovne podatke o glavi glave, kar pomeni, da potrebujemo tudi nekaj stvari iz specifikacij ELF.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Zdaj moramo bit za bit ponoviti strukturo tipa dl_phdr_info, ki ga uporablja trenutni dinamični povezovalec fuchsia.
// Chromium ima tudi to mejo ABI kot tudi padce.
// Sčasoma bi radi te primere premaknili na iskanje elf, vendar bi morali to zagotoviti v SDK, kar pa še ni bilo storjeno.
//
// Tako smo (in oni) zataknjeni, da moramo uporabiti to metodo, ki tesno poveže fuchsia libc.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Ne moremo vedeti, ali lahko preverimo, ali sta e_phoff in e_phnum veljavna.
    // libc bi nam to moral zagotoviti, zato je varno, da tukaj oblikujemo rezino.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr predstavlja 64-bitno glavo programa ELF v omejenosti ciljne arhitekture.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr predstavlja veljavno glavo programa ELF in njegovo vsebino.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Ne moremo preveriti, ali sta p_addr ali p_memsz veljavna.
    // Fuchsia-jev libc najprej razčleni opombe, vendar morajo biti zato, ker so tukaj, te glave veljavne.
    //
    // NoteIter ne zahteva, da so osnovni podatki veljavni, vendar zahteva, da so meje veljavne.
    // Verjamemo, da je libc zagotovil, da to velja za nas tukaj.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Vrsta opombe za ID-je gradnje.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr predstavlja glavo opombe ELF v endiansu cilja.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Opomba predstavlja opombo ELF (glava + vsebina).
// Ime ostane kot rezina u8, ker ni vedno ničelno zaključeno, rust pa omogoča enostavno preverjanje, ali se bajti vseeno ujemajo.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter vam omogoča varno prehod skozi segment zapiska.
// Konča se takoj, ko pride do napake ali če opomb ni več.
// Če ponovite neveljavne podatke, bo to delovalo, kot da nobene opombe ne najdete.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Invarianta funkcije je, da dani kazalec in velikost označujeta veljaven obseg bajtov, ki jih je mogoče vse prebrati.
    // Vsebina teh bajtov je lahko katera koli, vendar mora biti obseg veljaven, da je to varno.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to poravna 'x' na poravnavo bajtov, če je 'to' moč 2.
// To sledi standardnemu vzorcu v razčlenjevalni kodi C/C ++ ELF, kjer se uporabljajo (x + do, 1) in -to.
// Rust vam ne dovoli, da negirate usize, zato ga uporabljam
// Pretvorba dopolnil 2, da to ponovno ustvarite.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 porabi število bajtov iz rezine (če je prisotna) in poleg tega zagotovi, da je končna rezina pravilno poravnana.
// Če je število zahtevanih bajtov preveliko ali rezine pozneje ni mogoče znova poravnati, ker ni bilo na voljo dovolj preostalih bajtov, se vrne None in rezina ni spremenjena.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Ta funkcija nima resničnih nespremenljivk, ki jih mora klicatelj podpirati, razen morda, da je treba 'bytes' uskladiti glede na zmogljivost (in na nekaterih arhitekturah pravilnost).
// Vrednosti v poljih Elf_Nhdr so morda nesmiselne, vendar ta funkcija ne zagotavlja nobenega takega.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // To je varno, če je dovolj prostora in pravkar smo to potrdili v zgornji izjavi if, zato to ne bi smelo biti varno.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Upoštevajte, da sice_of: :<Elf_Nhdr>() je vedno poravnano s 4 bajti.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Preverite, ali smo prišli do konca.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Transmutiramo nhdr, vendar natančno preučimo nastalo strukturo.
        // Namez in descsz ne zaupamo in ne sprejemamo nobenih nevarnih odločitev glede na vrsto.
        //
        // Torej, tudi če dobimo popolne smeti, bi morali biti še vedno na varnem.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Označuje, da je segment izvedljiv.
const PERM_X: u32 = 0b00000001;
/// Označuje, da je v segment mogoče zapisati.
const PERM_W: u32 = 0b00000010;
/// Označuje, da je segment berljiv.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Predstavlja segment ELF med izvajanjem.
struct Segment {
    /// Podaja navidezni naslov med izvajanjem vsebine tega segmenta.
    addr: usize,
    /// Podaja velikost pomnilnika vsebine tega segmenta.
    size: usize,
    /// Daje navidezni naslov modula tega segmenta z datoteko ELF.
    mod_rel_addr: usize,
    /// Daje dovoljenja, najdena v datoteki ELF.
    /// Vendar ta dovoljenja niso nujno dovoljenja, ki so prisotna med izvajanjem.
    flags: Perm,
}

/// Omogoča en iteracijo po segmentih ODS.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Predstavlja ELF DSO (dinamični predmet v skupni rabi).
/// Ta vrsta se sklicuje na podatke, shranjene v dejanskem distribucijskem sistemu, namesto da bi naredila svojo kopijo.
struct Dso<'a> {
    /// Dinamični povezovalec nam vedno da ime, tudi če je ime prazno.
    /// V primeru glavne izvedljive datoteke bo to ime prazno.
    /// V primeru predmeta v skupni rabi bo to soname (glejte DT_SONAME).
    name: &'a str,
    /// Na Fuchsii imajo tako rekoč vsi binarni dokumenti gradbene ID-je, vendar to ni stroga zahteva.
    /// Če ni nobenega build_id, potem ni mogoče povezati informacij o sistemskem operaterju z resnično datoteko ELF, zato zahtevamo, da ga ima vsak sistemski operater distribucijskega sistema.
    ///
    /// Sistemski operaterji distribucijskih sistemov brez build_id so prezrti.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Vrne iterator nad segmenti v tem ODS.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Te napake kodirajo težave, ki se pojavijo med razčlenjevanjem informacij o vsakem sistemskem operaterju omrežja.
///
enum Error {
    /// NameError pomeni, da je pri pretvorbi niza sloga C v niz rust prišlo do napake.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError pomeni, da nismo našli ID-ja gradnje.
    /// To je lahko zato, ker DSO ni imel ID-ja gradnje ali ker je bil segment, ki vsebuje ID gradnje, neustrezen.
    ///
    BuildIDError,
}

/// Pokliče 'dso' ali 'error' za vsakega sistemskega operaterja distribucijskega sistema, ki je v postopek povezan z dinamičnim povezovalnikom.
///
///
/// # Arguments
///
/// * `visitor` - DsoPrinter, ki bo imel eno izmed metod, imenovano foreach DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr zagotavlja, da bo info.name kazal na veljavno lokacijo.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Ta funkcija natisne oznako Fuchsia simbolizatorja za vse informacije, ki jih vsebuje sistemski sistem distribucije.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}