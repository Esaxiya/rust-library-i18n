#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Oblikovalnik za povratne sledi.
///
/// Ta tip se lahko uporablja za tiskanje povratne sledi, ne glede na to, od kod prihaja povratna sled.
/// Če imate tip `Backtrace`, njegova izvedba `Debug` že uporablja ta format tiskanja.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Slogi tiskanja, ki jih lahko natisnemo
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Natisne terser backtrace, ki v idealnem primeru vsebuje samo ustrezne informacije
    Short,
    /// Natisne povratno sled, ki vsebuje vse možne informacije
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Ustvarite nov `BacktraceFmt`, ki bo zapisoval izhodne podatke v priloženi `fmt`.
    ///
    /// Argument `format` bo nadzoroval slog, v katerem se natisne povratna sled, argument `print_path` pa bo uporabljen za tiskanje primerkov datotek `BytesOrWideString`.
    /// Ta vrsta sama ne tiska imen datotek, vendar je za to potreben ta povratni klic.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Natisne preambulo za backtrace, ki se bo natisnil.
    ///
    /// To je na nekaterih platformah potrebno, da se pozneje v celoti simbolizirajo povratni sledovi, sicer pa bi to morala biti le prva metoda, ki jo pokličete po izdelavi `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// V izhod za povratno sledenje doda okvir.
    ///
    /// Ta odobritev vrne primerek RAII `BacktraceFrameFmt`, ki ga je mogoče uporabiti za dejansko tiskanje okvira, ob uničenju pa bo povečal števec okvirjev.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Dokonča izhod povratne sledi.
    ///
    /// To trenutno ni dovoljeno, vendar je dodano zaradi združljivosti future s formati povratnih sledi.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Trenutno ne-op-- vključno s tem hook, da se omogočijo dodatki future.
        Ok(())
    }
}

/// Oblikovalnik za samo en okvir povratne sledi.
///
/// To vrsto ustvari funkcija `BacktraceFmt::frame`.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Natisne `BacktraceFrame` s tem oblikovalnikom okvirjev.
    ///
    /// To bo rekurzivno natisnilo vse primerke `BacktraceSymbol` znotraj `BacktraceFrame`.
    ///
    /// # Zahtevane funkcije
    ///
    /// Ta funkcija zahteva, da je omogočena funkcija `std` `backtrace` crate, funkcija `std` pa je privzeto omogočena.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Natisne `BacktraceSymbol` znotraj `BacktraceFrame`.
    ///
    /// # Zahtevane funkcije
    ///
    /// Ta funkcija zahteva, da je omogočena funkcija `std` `backtrace` crate, funkcija `std` pa je privzeto omogočena.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: to ni super, da na koncu ne natisnemo ničesar
            // z imeni datotek, ki niso utf8.
            // Na srečo je skoraj vse utf8, zato to ne bi smelo biti preveč hudo.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Natisne neobdelani `Frame` in `Symbol`, običajno znotraj neobdelanih povratnih klicev tega crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Doda neobdelani okvir izhodu za povratno sledenje.
    ///
    /// Ta metoda, za razliko od prejšnje, upošteva surove argumente, če so viri z različnih lokacij.
    /// Upoštevajte, da je za en okvir to mogoče poklicati večkrat.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Izhodu povratne sledi doda neobdelani okvir, vključno s podatki o stolpcih.
    ///
    /// Ta metoda, tako kot prejšnja, zajema surove argumente, če so viri z različnih lokacij.
    /// Upoštevajte, da je za en okvir to mogoče poklicati večkrat.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuksija znotraj procesa ne more simbolizirati, zato ima posebno obliko, ki jo lahko kasneje uporabimo za simbolizacijo.
        // Natisnite to namesto tiskanja naslovov v našem formatu tukaj.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Ni vam treba tiskati okvirjev "null", kar v bistvu samo pomeni, da je bilo sistemsko sledenje nekoliko željno zelo daleč.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Da bi zmanjšali velikost TCB v enklavi Sgx, ne želimo izvajati funkcionalnosti ločevanja simbolov.
        // Namesto tega lahko tukaj natisnemo odmik naslova, ki ga lahko kasneje preslikamo, da popravi funkcijo.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Natisnite kazalo okvirja in izbirni kazalec navodil za okvir.
        // Če presegamo prvi simbol tega okvira, pa samo natisnemo ustrezen presledek.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Nato izpišite ime simbola in uporabite nadomestno oblikovanje za več informacij, če imamo popolno sled.
        // Tu obdelujemo tudi simbole, ki nimajo imena,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // In nazadnje, natisnite številko filename/line, če je na voljo.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line so natisnjene v vrsticah pod imenom simbola, zato natisnite ustrezen presledek, da se nekako poravnate po desni.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Delegirajte na naš notranji povratni klic, da natisnete ime datoteke in nato natisnete številko vrstice.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Dodajte številko stolpca, če je na voljo.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Skrbimo samo za prvi simbol okvirja
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}