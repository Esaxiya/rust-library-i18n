//! Vrste, odvisne od platforme.

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::borrow::Cow;
        use std::fmt;
        use std::path::PathBuf;
        use std::prelude::v1::*;
        use std::str;
    }
}

/// Platforma neodvisna predstavitev niza.
/// Pri delu z omogočenim `std` priporočamo priročne metode za zagotavljanje pretvorb v vrste `std`.
///
#[derive(Debug)]
pub enum BytesOrWideString<'a> {
    /// Rezina, ki je običajno na voljo na platformah Unix.
    Bytes(&'a [u8]),
    /// Široke strune, običajno od Windows.
    Wide(&'a [u16]),
}

#[cfg(feature = "std")]
impl<'a> BytesOrWideString<'a> {
    /// Lossy pretvori v `Cow<str>`, dodeli, če `Bytes` ni veljaven UTF-8 ali če je `BytesOrWideString` `Wide`.
    ///
    /// # Zahtevane funkcije
    ///
    /// Ta funkcija zahteva, da je omogočena funkcija `std` `backtrace` crate, funkcija `std` pa je privzeto omogočena.
    ///
    ///
    pub fn to_str_lossy(&self) -> Cow<'a, str> {
        use self::BytesOrWideString::*;

        match self {
            &Bytes(slice) => String::from_utf8_lossy(slice),
            &Wide(wide) => Cow::Owned(String::from_utf16_lossy(wide)),
        }
    }

    /// Ponuja `Path` predstavitev `BytesOrWideString`.
    ///
    /// # Zahtevane funkcije
    ///
    /// Ta funkcija zahteva, da je omogočena funkcija `std` `backtrace` crate, funkcija `std` pa je privzeto omogočena.
    ///
    pub fn into_path_buf(self) -> PathBuf {
        #[cfg(unix)]
        {
            use std::ffi::OsStr;
            use std::os::unix::ffi::OsStrExt;

            if let BytesOrWideString::Bytes(slice) = self {
                return PathBuf::from(OsStr::from_bytes(slice));
            }
        }

        #[cfg(windows)]
        {
            use std::ffi::OsString;
            use std::os::windows::ffi::OsStringExt;

            if let BytesOrWideString::Wide(slice) = self {
                return PathBuf::from(OsString::from_wide(slice));
            }
        }

        if let BytesOrWideString::Bytes(b) = self {
            if let Ok(s) = str::from_utf8(b) {
                return PathBuf::from(s);
            }
        }
        unreachable!()
    }
}

#[cfg(feature = "std")]
impl<'a> fmt::Display for BytesOrWideString<'a> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.to_str_lossy().fmt(f)
    }
}