use core::ffi::c_void;
use core::fmt;

/// Pregleduje trenutni niz klicev in posreduje vse aktivne okvire v zapiralo, predvideno za izračun sledi sklada.
///
/// Ta funkcija je delovni konj te knjižnice pri izračunu sledi skladov za program.V danem zaključku `cb` so predstavljeni primerki `Frame`, ki predstavljajo informacije o tem klicnem okviru na skladu.
/// Zapiranje dobi okvirji od zgoraj navzdol (nazadnje najprej imenovane funkcije).
///
/// Vrnjena vrednost zapore je pokazatelj, ali naj se sledenje nadaljuje.Vrnjena vrednost `false` bo prekinila povratno sled in se takoj vrnila.
///
/// Ko pridobite `Frame`, boste verjetno želeli poklicati `backtrace::resolve`, da `ip` (kazalec navodil) ali naslov simbola pretvorite v `Symbol`, prek katerega je mogoče izvedeti ime in/ali ime datoteke/številko vrstice.
///
///
/// Upoštevajte, da je to funkcija na razmeroma nizki ravni in če želite na primer zajeti povratno sled, ki jo je treba pregledati pozneje, je morda primernejši tip `Backtrace`.
///
/// # Zahtevane funkcije
///
/// Ta funkcija zahteva, da je omogočena funkcija `std` `backtrace` crate, funkcija `std` pa je privzeto omogočena.
///
/// # Panics
///
/// Ta funkcija si prizadeva nikoli panic, če pa je `cb` zagotovil panics, bodo nekatere platforme prisilile dvojno panic, da prekine postopek.
/// Nekatere platforme uporabljajo knjižnico C, ki interno uporablja povratne klice, ki jih ni mogoče odviti, zato lahko panika iz `cb` sproži postopek.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // nadaljujte s sledenjem
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Enako kot `trace`, le da ni varen, ker je nesinhroniziran.
///
/// Ta funkcija nima garancij za sinhronizacijo, vendar je na voljo, ko funkcija `std` tega crate ni prevedena.
/// Za več dokumentacije in primerov glejte funkcijo `trace`.
///
/// # Panics
///
/// Glejte informacije o `trace` za opozorila glede panike `cb`.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// Portrait, ki predstavlja en okvir povratne sledi, je dobil funkcijo `trace` tega crate.
///
/// Zapiranje funkcije sledenja bo dalo okvirje, okvir pa bo skoraj odposlan, saj osnovna izvedba ni vedno znana do časa izvajanja.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Vrne trenutni kazalec navodil tega okvira.
    ///
    /// To je običajno naslednje navodilo, ki ga je treba izvesti v okviru, vendar ga vse izvedbe ne navajajo s 100-odstotno natančnostjo (vendar je na splošno precej blizu).
    ///
    ///
    /// Priporočljivo je, da to vrednost prenesete na `backtrace::resolve`, da jo spremenite v ime simbola.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Vrne kazalnik trenutnega sklada tega okvira.
    ///
    /// V primeru, da zaledje ne more obnoviti kazalca sklada za ta okvir, se vrne ničelni kazalec.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Vrne naslov začetnega simbola okvira te funkcije.
    ///
    /// S tem se bo poskusil previti kazalec navodil, ki ga je vrnil `ip`, na začetek funkcije in vrnil to vrednost.
    ///
    /// V nekaterih primerih pa zaledne datoteke samo vrnejo `ip` iz te funkcije.
    ///
    /// Vrnjeno vrednost lahko včasih uporabimo, če `backtrace::resolve` ni uspel na zgoraj navedenem `ip`.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Vrne osnovni naslov modula, kateremu pripada okvir.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // To mora biti na prvem mestu, da se zagotovi, da ima Miri prednost pred gostiteljsko platformo
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // samo v dbghelp simbolizirajo
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}