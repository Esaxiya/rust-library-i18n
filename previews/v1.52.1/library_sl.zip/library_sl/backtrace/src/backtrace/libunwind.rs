//! Podpora za povratno sledenje z uporabo API-jev libunwind/gcc_s/etc.
//!
//! Ta modul vsebuje možnost odvijanja sklada z uporabo API-jev v slogu libunwind.
//! Upoštevajte, da obstaja celo vrsto izvedb libunwind podobnega API-ja, in to je le poskus združljivosti z večino vseh hkrati, namesto da bi bili izbirčni.
//!
//!
//! API libunwind poganja `_Unwind_Backtrace` in je v praksi zelo zanesljiv pri ustvarjanju povratne sledi.
//! Ni povsem jasno, kako to počne (kazalci okvirja? Eh_frame info? Oboje?), Vendar se zdi, da deluje!
//!
//! Večina zapletenosti tega modula obravnava različne razlike v platformi med izvedbami libunwind.
//! V nasprotnem primeru je to precej preprosta Rust vezava na API-je libunwind.
//!
//! To je privzeti API za odvijanje za vse platforme, ki niso Windows.
//!
//!
//!

use super::super::Bomb;
use core::ffi::c_void;

pub enum Frame {
    Raw(*mut uw::_Unwind_Context),
    Cloned {
        ip: *mut c_void,
        sp: *mut c_void,
        symbol_address: *mut c_void,
    },
}

// S surovim kazalcem libunwind bi moral biti kdaj dostopen samo na način, ki je varen samo za branje, torej `Sync`.
// Pri pošiljanju v druge niti prek `Clone` vedno preidemo na različico, ki ne ohranja notranjih kazalcev, zato bi morali biti tudi `Send`.
//
//
unsafe impl Send for Frame {}
unsafe impl Sync for Frame {}

impl Frame {
    pub fn ip(&self) -> *mut c_void {
        let ctx = match *self {
            Frame::Raw(ctx) => ctx,
            Frame::Cloned { ip, .. } => return ip,
        };
        unsafe { uw::_Unwind_GetIP(ctx) as *mut c_void }
    }

    pub fn sp(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ctx) => unsafe { uw::get_sp(ctx) as *mut c_void },
            Frame::Cloned { sp, .. } => sp,
        }
    }

    pub fn symbol_address(&self) -> *mut c_void {
        if let Frame::Cloned { symbol_address, .. } = *self {
            return symbol_address;
        }

        // Zdi se, da na OSX `_Unwind_FindEnclosingFunction` vrne kazalec na ... nekaj, kar je nejasno.
        // Vsekakor ni vedno funkcija zapiranja iz kakršnega koli razloga.
        // Ni mi povsem jasno, kaj se tukaj dogaja, zato to za zdaj pesimizirajte in vedno vrnite ip.
        //
        // Upoštevajte, da je preskus `skip_inner_frames.rs` preskočen na OSX zaradi te klavzule in če je to odpravljeno, se lahko test v teoriji izvede na OSX!
        //
        //
        //
        if cfg!(target_os = "macos") || cfg!(target_os = "ios") {
            self.ip()
        } else {
            unsafe { uw::_Unwind_FindEnclosingFunction(self.ip()) }
        }
    }

    pub fn module_base_address(&self) -> Option<*mut c_void> {
        None
    }
}

impl Clone for Frame {
    fn clone(&self) -> Frame {
        Frame::Cloned {
            ip: self.ip(),
            sp: self.sp(),
            symbol_address: self.symbol_address(),
        }
    }
}

#[inline(always)]
pub unsafe fn trace(mut cb: &mut dyn FnMut(&super::Frame) -> bool) {
    uw::_Unwind_Backtrace(trace_fn, &mut cb as *mut _ as *mut _);

    extern "C" fn trace_fn(
        ctx: *mut uw::_Unwind_Context,
        arg: *mut c_void,
    ) -> uw::_Unwind_Reason_Code {
        let cb = unsafe { &mut *(arg as *mut &mut dyn FnMut(&super::Frame) -> bool) };
        let cx = super::Frame {
            inner: Frame::Raw(ctx),
        };

        let mut bomb = Bomb { enabled: true };
        let keep_going = cb(&cx);
        bomb.enabled = false;

        if keep_going {
            uw::_URC_NO_REASON
        } else {
            uw::_URC_FAILURE
        }
    }
}

/// Odvijte vmesnik knjižnice, ki se uporablja za povratne sledi
///
/// Upoštevajte, da je mrtva koda dovoljena, saj so tukaj le vezave, iOS jih ne uporablja vseh, ampak dodajanje več konfiguracij, specifičnih za platformo, kodo preveč onesnaži
///
///
#[allow(non_camel_case_types)]
#[allow(non_snake_case)]
#[allow(dead_code)]
mod uw {
    pub use self::_Unwind_Reason_Code::*;

    use core::ffi::c_void;

    #[repr(C)]
    pub enum _Unwind_Reason_Code {
        _URC_NO_REASON = 0,
        _URC_FOREIGN_EXCEPTION_CAUGHT = 1,
        _URC_FATAL_PHASE2_ERROR = 2,
        _URC_FATAL_PHASE1_ERROR = 3,
        _URC_NORMAL_STOP = 4,
        _URC_END_OF_STACK = 5,
        _URC_HANDLER_FOUND = 6,
        _URC_INSTALL_CONTEXT = 7,
        _URC_CONTINUE_UNWIND = 8,
        _URC_FAILURE = 9, // uporablja samo ARM EABI
    }

    pub enum _Unwind_Context {}

    pub type _Unwind_Trace_Fn =
        extern "C" fn(ctx: *mut _Unwind_Context, arg: *mut c_void) -> _Unwind_Reason_Code;

    extern "C" {
        // V sistemu iOS ni izvornega_Unwind_Backtrace
        #[cfg(not(all(target_os = "ios", target_arch = "arm")))]
        pub fn _Unwind_Backtrace(
            trace: _Unwind_Trace_Fn,
            trace_argument: *mut c_void,
        ) -> _Unwind_Reason_Code;

        // na voljo od GCC 4.2.0, bi morale biti v redu za naš namen
        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm"))
        ))]
        pub fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void;

        #[cfg(all(
            not(all(target_os = "android", target_arch = "arm")),
            not(all(target_os = "freebsd", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "arm")),
            not(all(target_os = "linux", target_arch = "s390x"))
        ))]
        // Ta funkcija je napačno poimenovana: namesto da bi dobila naslov Canonical Frame Address (imenovan tudi naslov klica klica), vrne SP tega okvira.
        //
        //
        // https://github.com/libunwind/libunwind/blob/d32956507cf29d9b1a98a8bce53c78623908f4fe/src/unwind/GetCFA.c#L28-L35
        //
        #[link_name = "_Unwind_GetCFA"]
        pub fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t;
    }

    // s390x uporablja pristransko vrednost CFA, zato moramo uporabiti_Unwind_GetGR, da dobimo register kazalca sklada (%r15), namesto da se zanašamo na_Unwind_GetCFA.
    //
    //
    #[cfg(all(target_os = "linux", target_arch = "s390x"))]
    pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
        extern "C" {
            pub fn _Unwind_GetGR(ctx: *mut _Unwind_Context, index: libc::c_int) -> libc::uintptr_t;
        }
        _Unwind_GetGR(ctx, 15)
    }

    // Na android in arm sta funkcija `_Unwind_GetIP` in kup drugih makri, zato določimo funkcije, ki vsebujejo razširitev makrov.
    //
    //
    // TODO: povezava do datoteke z glavo, ki definira te makre, če jo najdete.
    // (Fitzgen ne najdem datoteke z glavo, pri kateri so bile nekatere od teh razširitev makra prvotno izposojene.)
    //
    //
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    pub use self::arm::*;
    #[cfg(any(
        all(target_os = "android", target_arch = "arm"),
        all(target_os = "freebsd", target_arch = "arm"),
        all(target_os = "linux", target_arch = "arm")
    ))]
    mod arm {
        pub use super::*;
        #[repr(C)]
        enum _Unwind_VRS_Result {
            _UVRSR_OK = 0,
            _UVRSR_NOT_IMPLEMENTED = 1,
            _UVRSR_FAILED = 2,
        }
        #[repr(C)]
        enum _Unwind_VRS_RegClass {
            _UVRSC_CORE = 0,
            _UVRSC_VFP = 1,
            _UVRSC_FPA = 2,
            _UVRSC_WMMXD = 3,
            _UVRSC_WMMXC = 4,
        }
        #[repr(C)]
        enum _Unwind_VRS_DataRepresentation {
            _UVRSD_UINT32 = 0,
            _UVRSD_VFPX = 1,
            _UVRSD_FPAX = 2,
            _UVRSD_UINT64 = 3,
            _UVRSD_FLOAT = 4,
            _UVRSD_DOUBLE = 5,
        }

        type _Unwind_Word = libc::c_uint;
        extern "C" {
            fn _Unwind_VRS_Get(
                ctx: *mut _Unwind_Context,
                klass: _Unwind_VRS_RegClass,
                word: _Unwind_Word,
                repr: _Unwind_VRS_DataRepresentation,
                data: *mut c_void,
            ) -> _Unwind_VRS_Result;
        }

        pub unsafe fn _Unwind_GetIP(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                15,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            (val & !1) as libc::uintptr_t
        }

        // R13 je kazalec sklada na roki.
        const SP: _Unwind_Word = 13;

        pub unsafe fn get_sp(ctx: *mut _Unwind_Context) -> libc::uintptr_t {
            let mut val: _Unwind_Word = 0;
            let ptr = &mut val as *mut _Unwind_Word;
            let _ = _Unwind_VRS_Get(
                ctx,
                _Unwind_VRS_RegClass::_UVRSC_CORE,
                SP,
                _Unwind_VRS_DataRepresentation::_UVRSD_UINT32,
                ptr as *mut c_void,
            );
            val as libc::uintptr_t
        }

        // Ta funkcija prav tako ne obstaja na Android ali ARM/Linux, zato je ne upoštevajte.
        //
        pub unsafe fn _Unwind_FindEnclosingFunction(pc: *mut c_void) -> *mut c_void {
            pc
        }
    }
}