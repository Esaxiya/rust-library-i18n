#![feature(no_core)]
#![no_core]

// Zakaj je ta crate potreben, glejte rustc-std-workspace-core.

// Preimenujte crate, da se izognete navzkrižju z modulom alloc v liballoc.
extern crate alloc as foo;

pub use foo::*;