use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Uporabljali so se za naše pripombe `#[assert_instr]`, da so na voljo vse simd lastnosti za preizkušanje njihovega kodegena, saj so nekateri zaprti za dodatnim `-Ctarget-feature=+unimplemented-simd128`, ki trenutno nima nobenega ekvivalenta v `#[target_feature]`.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}