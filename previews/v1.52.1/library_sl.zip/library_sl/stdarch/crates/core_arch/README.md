`core::arch` - Osnovne značilnosti arhitekture osnovne knjižnice Rust
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Modul `core::arch` izvaja lastno arhitekturo (npr. SIMD).

# Usage 

`core::arch` je na voljo kot del `libcore` in ga `libstd` ponovno izvozi.Raje ga uporabite prek `core::arch` ali `std::arch` kot prek tega crate.
Nestabilne funkcije so pogosto na voljo v nočnem Rust prek `feature(stdsimd)`.

Uporaba `core::arch` prek tega crate zahteva nočni Rust in se lahko (in tudi pogosto) zlomi.Edini primeri, v katerih bi morali razmisliti o uporabi prek tega crate, so:

* če morate sami znova sestaviti `core::arch`, npr. z omogočenimi določenimi ciljnimi funkcijami, ki za `libcore`/`libstd` niso omogočene.
Note: če ga morate ponovno sestaviti za nestandardni cilj, raje namesto tega crate uporabite `xargo` in ponovno sestavite `libcore`/`libstd`, kot je primerno.
  
* z uporabo nekaterih funkcij, ki morda niso na voljo niti za nestabilnimi funkcijami Rust.Trudimo se, da bi jih bilo čim manj.
Če morate uporabiti nekatere od teh funkcij, odprite težavo, da jih bomo lahko razkrili v nočnem Rust, vi pa jih boste lahko uporabljali od tam.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` se v glavnem distribuira pod pogoji licence MIT in licence Apache (različica 2.0), pri čemer so deli zajeti v različne licence, podobne BSD.

Za podrobnosti glejte LICENSE-APACHE in LICENSE-MIT.

# Contribution

Če izrecno ne navedete drugače, bo vsak prispevek, ki ste ga namerno oddali za vključitev v `core_arch`, kot je opredeljeno v licenci Apache-2.0, dvojno licenciran, kot je navedeno zgoraj, brez kakršnih koli dodatnih pogojev.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












