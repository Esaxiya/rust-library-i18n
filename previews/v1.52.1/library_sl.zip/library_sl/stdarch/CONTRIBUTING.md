# Prispevek k stdarchu

`stdarch` crate je več kot pripravljen sprejeti prispevke!Najprej boste verjetno želeli preveriti repozitorij in se prepričati, da so testi uspešno opravljeni za vas:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Kjer je `<your-target-arch>` ciljna trojka, kot jo uporablja `rustup`, npr. `x86_x64-unknown-linux-gnu` (brez predhodnih `nightly-` ali podobnih).
Ne pozabite tudi, da to odlagališče zahteva nočni kanal Rust!
Zgornji testi dejansko zahtevajo, da je nočni rust privzeta nastavitev vašega sistema za nastavitev, ki uporablja `rustup default nightly` (in `rustup default stable` za vrnitev v prejšnje stanje).

Če kateri od zgornjih korakov ne deluje, [please let us know][new]!

Nato lahko pomagate z [find an issue][issues], izbrali smo nekaj z oznakama [`help wanted`][help] in [`impl-period`][impl], ki bi lahko še posebej uporabili pomoč. 
Morda vas bo najbolj zanimal [#40][vendor], ki bo na x86 uvedel vse lastnosti ponudnikov.Ta številka ima nekaj dobrih napotkov o tem, kje začeti!

Če imate splošna vprašanja, vas prosimo, da [join us on gitter][gitter] povprašate!Z vprašanji lahko pišete@BurntSushi ali@alexcrichton.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Kako napisati primere za stdarch intrinsics

Obstaja nekaj funkcij, ki jih je treba omogočiti, da določena lastnost deluje pravilno, primer pa mora zagnati `cargo test --doc` le, če funkcijo podpira CPU.

Posledično privzeti `fn main`, ki ga ustvari `rustdoc`, ne bo deloval (v večini primerov).
Uporabite naslednje kot vodilo, da zagotovite, da vaš primer deluje po pričakovanjih.

```rust
/// # // Za zagotovitev primera potrebujemo cfg_target_feature
/// # // zažene `cargo test --doc`, ko CPU podpira to funkcijo
/// # #![feature(cfg_target_feature)]
/// # // Za lastno delovanje potrebujemo target_feature
/// # #![feature(target_feature)]
/// #
/// # // rustdoc privzeto uporablja `extern crate stdarch`, vendar potrebujemo
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // Prava glavna funkcija
/// # fn main() {
/// #     // To zaženite samo, če je podprt `<target feature>`
/// #     če je cfg_feature_enabled! ("<target feature>"){
/// #         // Ustvarite funkcijo `worker`, ki se bo izvajala samo, če je ciljna funkcija
/// #         // je podprta in zagotovite, da je za vašega delavca omogočen `target_feature`
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         nevarno fn worker() {
/// // Napišite svoj primer tukaj.Tukaj bodo delovale značilne značilnosti!Pojdi divji!
///
/// #         }
///
/// #         nevaren { worker(); }
/// #     }
/// # }
```

Če nekatera zgornja sintaksa ni videti znana, razdelek [Documentation as tests] v [Rust Book] precej dobro opisuje sintakso `rustdoc`.
Kot vedno vas prosimo, da se obrnete na [join us on gitter][gitter] in nas vprašate, če ste zadeli kakšen problem, in hvala, ker ste pomagali izboljšati dokumentacijo `stdarch`!

# Alternativna navodila za preskušanje

Na splošno je priporočljivo, da za izvajanje testov uporabite `ci/run.sh`.
Vendar to morda ne bo delovalo pri vas, npr. Če uporabljate Windows.

V tem primeru se lahko vrnete na zagon `cargo +nightly test` in `cargo +nightly test --release -p core_arch` za testiranje generiranja kode.
Upoštevajte, da te zahtevajo namestitev nočne verige orodij in da `rustc` ve o vaši ciljni trojki in njenem CPU.
Zlasti morate nastaviti spremenljivko okolja `TARGET`, kot bi to storili za `ci/run.sh`.
Poleg tega morate nastaviti `RUSTCFLAGS` (potrebujete `C`) za označevanje ciljnih lastnosti, npr `RUSTCFLAGS="-C -target-features=+avx2"`.
`-C -target-cpu=native` lahko nastavite tudi, če se "just" razvija glede na vaš trenutni CPU.

Upoštevajte, da pri uporabi teh nadomestnih navodil [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], npr
preizkusi generiranja navodil morda ne bodo uspeli, ker jih je razstavljalec poimenoval drugače, npr
kljub temu, da se obnašajo enako, lahko ustvari `vaesenc` namesto navodil `aesenc`.
Ta navodila izvajajo tudi manj testov, kot bi jih običajno izvajali, zato ne bodite presenečeni, da se bodo na koncu, ko povlečete zahtevo, pojavile nekatere napake pri testih, ki tukaj niso zajete.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






