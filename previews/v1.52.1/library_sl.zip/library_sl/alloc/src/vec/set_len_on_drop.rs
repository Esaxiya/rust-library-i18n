// Nastavite dolžino vec, ko vrednost `SetLenOnDrop` izstopi iz obsega.
//
// Zamisel je: Polje dolžine v SetLenOnDrop je lokalna spremenljivka, ki jo bo optimizator videl, ne vsebuje vzdevkov nobenih trgovin prek Večevega kazalca podatkov.
// To je rešitev za vprašanje vzdevka #32155
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}