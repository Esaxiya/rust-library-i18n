//! Sosednja vrsta matričnega niza z vsebino, dodeljeno kopici, napisana `Vec<T>`.
//!
//! Vectors imajo indeksiranje `O(1)`, amortizirano potiskanje `O(1)` (do konca) in `O(1)` pop (od konca).
//!
//!
//! Vectors zagotavljajo, da nikoli ne dodelijo več kot `isize::MAX` bajtov.
//!
//! # Examples
//!
//! [`Vec`] lahko izrecno ustvarite z [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... ali z uporabo makra [`vec!`]:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // deset nič
//! ```
//!
//! Vrednosti [`push`] lahko vstavite na konec vector (ki bo po potrebi rasel vector):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Popping vrednosti delujejo približno enako:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors podpira tudi indeksiranje (prek [`Index`] in [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Sosednja vrsta matričnega niza, napisana kot `Vec<T>` in izgovarjana 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// Makro [`vec!`] je na voljo za lažjo inicializacijo:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Prav tako lahko inicializira vsak element `Vec<T>` z določeno vrednostjo.
/// To je lahko bolj učinkovito kot izvajanje dodeljevanja in inicializacije v ločenih korakih, zlasti pri inicializaciji vector ničel:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Naslednje je enakovredno, vendar potencialno počasnejše:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Za več informacij glejte [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Uporabite `Vec<T>` kot učinkovit sklad:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Tiski 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Tip `Vec` omogoča dostop do vrednosti po indeksu, ker izvaja [`Index`] Portrait.Primer bo bolj jasen:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // prikazal se bo '2'
/// ```
///
/// Vendar bodite previdni: če poskušate dostopati do indeksa, ki ni v `Vec`, bo vaša programska oprema panic!Tega ne morete storiti:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Če želite preveriti, ali je indeks v `Vec`, uporabite [`get`] in [`get_mut`].
///
/// # Slicing
///
/// `Vec` je lahko spremenljiv.Po drugi strani pa so rezine predmeti samo za branje.
/// Če želite dobiti [slice][prim@slice], uporabite [`&`].Primer:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... in to je vse!
/// // lahko tudi tako:
/// let u: &[usize] = &v;
/// // ali takole:
/// let u: &[_] = &v;
/// ```
///
/// V Rust je pogosteje, da rezine posredujemo kot argumente namesto vectors, če želimo le omogočiti dostop za branje.Enako velja za [`String`] in [`&str`].
///
/// # Zmogljivost in prerazporeditev
///
/// Zmogljivost vector je količina prostora, dodeljenega katerim koli elementom future, ki bodo dodani na vector.Tega ne smemo zamenjevati z *dolžino* vector, ki določa število dejanskih elementov znotraj vector.
/// Če dolžina vector preseže njegovo zmogljivost, se njegova zmogljivost samodejno poveča, vendar je treba elemente prerazporediti.
///
/// Na primer, vector z zmogljivostjo 10 in dolžino 0 bi bil prazen vector s prostorom za še 10 elementov.Potiskanje 10 ali manj elementov na vector ne bo spremenilo njegove zmogljivosti ali povzročilo prerazporeditve.
/// Če pa se dolžina vector poveča na 11, jo bo treba prerazporediti, kar je lahko počasi.Zato je priporočljivo, da uporabite [`Vec::with_capacity`], kadar je le mogoče, da določite, kako velik naj bi bil vector.
///
/// # Guarantees
///
/// Zaradi svoje izjemno temeljne narave `Vec` daje veliko zagotovil glede svoje zasnove.To zagotavlja, da je v splošnem čim nižji režijski stroški in da z njim lahko varno upravljate na primitiven način.Upoštevajte, da se ta jamstva nanašajo na nekvalificiran `Vec<T>`.
/// Če so dodani dodatni parametri tipa (npr. Za podporo dodeljevalnikom po meri), lahko preglasitev njihovih privzetih nastavitev spremeni vedenje.
///
/// Najbolj temeljno je, da `Vec` je in bo vedno trojček (kazalec, zmogljivost, dolžina).Ne več, ne manj.Vrstni red teh polj je popolnoma nedoločen in za spreminjanje uporabite ustrezne metode.
/// Kazalec ne bo nikoli ničen, zato je ta tip optimiziran za ničelni kazalec.
///
/// Kazalec pa morda dejansko ne kaže na dodeljeni pomnilnik.
/// Če zgradite `Vec` z zmogljivostjo 0 prek [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`] ali s klicem [`shrink_to_fit`] na praznem Vecu, ne bo dodelil pomnilnika.Podobno, če v `Vec` shranite ničelne tipe, jim ne bo dodelil prostora.
/// *Upoštevajte, da v tem primeru `Vec` morda ne bo poročal o [`capacity`] z 0*.
/// `Vec` bo dodelil, če in samo, če [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// Na splošno so podrobnosti o dodelitvi "Vec" zelo prefinjene-če nameravate pomnilnik dodeliti s pomočjo `Vec` in ga uporabiti za kaj drugega (bodisi za prehod na nevarno kodo bodisi za izdelavo lastne zbirke, podprte s spominom) odstraniti pomnilnik s pomočjo `from_raw_parts` za obnovitev `Vec` in nato spustiti.
///
/// Če ima `Vec`*dodeljen* pomnilnik, je pomnilnik, na katerega kaže, na kupu (kot je določeno z razdelilnikom Rust je konfiguriran za privzeto uporabo), njegov kazalec pa kaže na inicializirane, sosednje elemente po vrstnem redu [`len`] (kaj bi želeli poglejte, ali ste ga prisilili na rezino), čemur sledijo ["zmogljivost"], "[" len "] logično neinicializirani, sosednji elementi.
///
///
/// vector, ki vsebuje elemente `'a'` in `'b'` s kapaciteto 4, si lahko ogledate, kot je prikazano spodaj.Zgornji del je struktura `Vec`, ki vsebuje kazalec na glavo dodelitve na kopici, dolžino in prostornino.
/// Spodnji del je dodelitev na kopici, sosednji pomnilniški blok.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** predstavlja pomnilnik, ki ni inicializiran, glejte [`MaybeUninit`].
/// - Note: ABI ni stabilen in `Vec` ne daje nobenih zagotovil glede postavitve pomnilnika (vključno z vrstnim redom polj).
///
/// `Vec` nikoli ne bo izvedel "small optimization", kjer so elementi dejansko shranjeni v skladu iz dveh razlogov:
///
/// * Nevarna koda bi otežila pravilno manipulacijo z `Vec`.Vsebina `Vec` ne bi imela stabilnega naslova, če bi jo le premaknili, in težje bi bilo ugotoviti, ali je `Vec` dejansko dodelil pomnilnik.
///
/// * Splošni primer bi bil kaznovan, pri vsakem dostopu pa bi se pojavil dodaten branch.
///
/// `Vec` se nikoli ne bo samodejno skrčil, tudi če je popolnoma prazen.To zagotavlja, da ne pride do nepotrebnih dodeljevanj ali sproščanja.Če izpraznite `Vec` in ga nato napolnite nazaj do istega [`len`], razdelilnik ne bi smel imeti nobenih klicev.Če želite sprostiti neuporabljeni pomnilnik, uporabite [`shrink_to_fit`] ali [`shrink_to`].
///
/// [`push`] in [`insert`] ne bo nikoli (ponovno) dodelil, če je prijavljena zmogljivost zadostna.[`push`] in [`insert`]*bosta*(pre) dodelili, če je [`len`]`==`[`zmogljivost`].To pomeni, da je prijavljena zmogljivost popolnoma natančna in se nanjo lahko zanesemo.Po želji se lahko celo ročno osvobodi pomnilnika, ki ga dodeli `Vec`.
/// Načini vstavljanja v razsutem stanju *se lahko* prerazporedijo, tudi kadar ni potrebno.
///
/// `Vec` ne zagotavlja nobene posebne strategije rasti pri prerazporeditvi, ko je polna, niti pri klicu [`reserve`].Trenutna strategija je osnovna in morda se bo izkazalo za zaželeno uporabiti nestalni faktor rasti.Kakršna koli strategija bo uporabljena, seveda zagotavlja *O*(1) amortizirano [`push`].
///
/// `vec![x; n]`, `vec![a, b, c, d]` in [`Vec::with_capacity(n)`][`Vec::with_capacity`] bosta proizvedli `Vec` s točno zahtevano zmogljivostjo.
/// Če je [`len`]`==`[` zmogljivost '](kot v primeru makra [`vec!`]), lahko `Vec<T>` pretvorite v [`Box<[T]>`][owned slice] in iz njega, ne da bi prerazporedili ali premaknili elemente.
///
/// `Vec` ne bo posebej prepisal nobenih podatkov, ki so iz njih odstranjeni, pa tudi ne bo posebej shranil.Njegov neinicializiran pomnilnik je prazen prostor, ki ga lahko uporablja, kakor koli želi.Na splošno bo naredil le tisto, kar je najučinkovitejše ali drugače enostavno izvedljivo.Ne zanašajte se, da bodo odstranjeni podatki zaradi varnosti izbrisani.
/// Tudi če spustite `Vec`, lahko drugi vmesnik `Vec` preprosto ponovno uporabi.
/// Tudi če najprej pomaknete spomin na "Vec", se to dejansko ne bo zgodilo, ker optimizator tega ne šteje za stranski učinek, ki ga je treba ohraniti.
/// Vendar obstaja en primer, ki ga ne bomo prekinili: uporaba kode `unsafe` za zapisovanje na presežno zmogljivost in nato povečanje dolžine, da se ujema, je vedno veljavno.
///
/// Trenutno `Vec` ne zagotavlja vrstnega reda spuščanja elementov.
/// Vrstni red se je v preteklosti spremenil in se lahko spremeni.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Neločljive metode
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Konstruira nov, prazen `Vec<T>`.
    ///
    /// vector se ne bo dodelil, dokler nanj ne potisnete elementov.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Konstruira nov, prazen `Vec<T>` z določeno zmogljivostjo.
    ///
    /// vector bo lahko vseboval natančno `capacity` elemente brez prerazporeditve.
    /// Če je `capacity` 0, vector ne bo dodelil.
    ///
    /// Pomembno je vedeti, da čeprav ima vrnjeni vector določeno *zmogljivost*, bo vector imel dolžino nič *.
    ///
    /// Za razlago razlike med dolžino in zmogljivostjo glejte *[Zmogljivost in prerazporeditev]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector ne vsebuje nobenih predmetov, čeprav ima zmogljivosti za več
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Vse je narejeno brez prerazporeditve ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... toda morda bo vector prerazporejen
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Ustvari `Vec<T>` neposredno iz surovih komponent drugega vector.
    ///
    /// # Safety
    ///
    /// To je zelo nevarno zaradi števila invariantov, ki niso preverjeni:
    ///
    /// * `ptr` mora biti predhodno dodeljena prek [`String`]/`Vec<T>`(vsaj zelo verjetno je napačno, če ne).
    /// * `T` mora imeti enako velikost in poravnavo, kot je bila dodeljena `ptr`.
    ///   (`T` z manj strogo poravnavo ne zadostuje, poravnava mora biti res enaka, da bo izpolnjena zahteva [`dealloc`], da je treba pomnilnik dodeliti in odstraniti z enako postavitvijo.)
    ///
    /// * `length` mora biti manjši ali enak `capacity`.
    /// * `capacity` mora biti zmogljivost, s katero je bil kazalcu dodeljen.
    ///
    /// Kršitev le-teh lahko povzroči težave, kot je poškodovanje notranjih podatkovnih struktur razdeljevalca.Na primer **ni** varno zgraditi `Vec<u8>` iz kazalca na matriko C `char` z dolžino `size_t`.
    /// Prav tako ni varno zgraditi takšnega iz `Vec<u16>` in njegove dolžine, ker je razdeljevalec pozoren na poravnavo in ti dve vrsti imata različne poravnave.
    /// Medpomnilnik je bil dodeljen s poravnavo 2 (za `u16`), po pretvorbi v `Vec<u8>` pa bo odstranjen s poravnavo 1.
    ///
    /// Lastništvo `ptr` se dejansko prenese na `Vec<T>`, ki lahko nato sprosti, prerazporedi ali spremeni vsebino pomnilnika, na katero kaže kazalnik.
    /// Prepričajte se, da nič drugega ne uporablja kazalca po klicu te funkcije.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Posodobite to, ko je vec_into_raw_parts stabiliziran.
    ///     // Preprečite zagon destruktorja `v`, da bomo imeli popoln nadzor nad dodeljevanjem.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Izvlecite različne pomembne informacije o `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Prepiši pomnilnik s 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Vse skupaj spet postavite v Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Konstruira nov, prazen `Vec<T, A>`.
    ///
    /// vector se ne bo dodelil, dokler nanj ne potisnete elementov.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// S priloženim razdelilnikom izdela nov, prazen `Vec<T, A>` z določeno zmogljivostjo.
    ///
    /// vector bo lahko vseboval natančno `capacity` elemente brez prerazporeditve.
    /// Če je `capacity` 0, vector ne bo dodelil.
    ///
    /// Pomembno je vedeti, da čeprav ima vrnjeni vector določeno *zmogljivost*, bo vector imel dolžino nič *.
    ///
    /// Za razlago razlike med dolžino in zmogljivostjo glejte *[Zmogljivost in prerazporeditev]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector ne vsebuje nobenih predmetov, čeprav ima zmogljivosti za več
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Vse je narejeno brez prerazporeditve ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... toda morda bo vector prerazporejen
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Ustvari `Vec<T, A>` neposredno iz surovih komponent drugega vector.
    ///
    /// # Safety
    ///
    /// To je zelo nevarno zaradi števila invariantov, ki niso preverjeni:
    ///
    /// * `ptr` mora biti predhodno dodeljena prek [`String`]/`Vec<T>`(vsaj zelo verjetno je napačno, če ne).
    /// * `T` mora imeti enako velikost in poravnavo, kot je bila dodeljena `ptr`.
    ///   (`T` z manj strogo poravnavo ne zadostuje, poravnava mora biti res enaka, da bo izpolnjena zahteva [`dealloc`], da je treba pomnilnik dodeliti in odstraniti z enako postavitvijo.)
    ///
    /// * `length` mora biti manjši ali enak `capacity`.
    /// * `capacity` mora biti zmogljivost, s katero je bil kazalcu dodeljen.
    ///
    /// Kršitev le-teh lahko povzroči težave, kot je poškodovanje notranjih podatkovnih struktur razdeljevalca.Na primer **ni** varno zgraditi `Vec<u8>` iz kazalca na matriko C `char` z dolžino `size_t`.
    /// Prav tako ni varno zgraditi takšnega iz `Vec<u16>` in njegove dolžine, ker je razdeljevalec pozoren na poravnavo in ti dve vrsti imata različne poravnave.
    /// Medpomnilnik je bil dodeljen s poravnavo 2 (za `u16`), po pretvorbi v `Vec<u8>` pa bo odstranjen s poravnavo 1.
    ///
    /// Lastništvo `ptr` se dejansko prenese na `Vec<T>`, ki lahko nato sprosti, prerazporedi ali spremeni vsebino pomnilnika, na katero kaže kazalnik.
    /// Prepričajte se, da nič drugega ne uporablja kazalca po klicu te funkcije.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Posodobite to, ko je vec_into_raw_parts stabiliziran.
    ///     // Preprečite zagon destruktorja `v`, da bomo imeli popoln nadzor nad dodeljevanjem.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Izvlecite različne pomembne informacije o `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Prepiši pomnilnik s 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Vse skupaj spet postavite v Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Razgradi `Vec<T>` v njegove surove komponente.
    ///
    /// Vrne neobdelani kazalnik na osnovne podatke, dolžino vector (v elementih) in dodeljeno zmogljivost podatkov (v elementih).
    /// To so enaki argumenti v enakem vrstnem redu kot argumenti za [`from_raw_parts`].
    ///
    /// Po klicu te funkcije je klicatelj odgovoren za pomnilnik, ki ga je prej upravljal `Vec`.
    /// Edini način za to je pretvorba neobdelanega kazalca, dolžine in zmogljivosti nazaj v `Vec` s funkcijo [`from_raw_parts`], kar destruktorju omogoči izvedbo čiščenja.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Zdaj lahko spremenimo komponente, na primer pretvorimo neobdelani kazalec v združljiv tip.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Razgradi `Vec<T>` v njegove surove komponente.
    ///
    /// Vrne neobdelani kazalnik na osnovne podatke, dolžino vector (v elementih), dodeljeno kapaciteto podatkov (v elementih) in razdelilnik.
    /// To so enaki argumenti v enakem vrstnem redu kot argumenti za [`from_raw_parts_in`].
    ///
    /// Po klicu te funkcije je klicatelj odgovoren za pomnilnik, ki ga je prej upravljal `Vec`.
    /// Edini način za to je pretvorba neobdelanega kazalca, dolžine in zmogljivosti nazaj v `Vec` s funkcijo [`from_raw_parts_in`], kar destruktorju omogoči izvedbo čiščenja.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Zdaj lahko spremenimo komponente, na primer pretvorimo neobdelani kazalec v združljiv tip.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Vrne število elementov, ki jih lahko vsebuje vector brez prerazporeditve.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Rezervira zmogljivost za vsaj `additional` več elementov, ki jih je treba vstaviti v dani `Vec<T>`.
    /// Zbirka lahko rezervira več prostora, da se izogne pogostim prerazporeditvam.
    /// Po klicu `reserve` bo zmogljivost večja ali enaka `self.len() + additional`.
    /// Ne stori nič, če je zmogljivost že zadostna.
    ///
    /// # Panics
    ///
    /// Panics, če nova zmogljivost presega `isize::MAX` bajtov.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Rezervira najmanjšo zmogljivost za natančno `additional` več elementov, ki jih je treba vstaviti v dani `Vec<T>`.
    ///
    /// Po klicu `reserve_exact` bo zmogljivost večja ali enaka `self.len() + additional`.
    /// Nič ne naredi, če je zmogljivost že zadostna.
    ///
    /// Upoštevajte, da lahko razdeljevalnik da zbirki več prostora, kot zahteva.
    /// Zato se ni mogoče zanašati na to, da je zmogljivost povsem minimalna.
    /// Dajte prednost `reserve`, če pričakujete vstavke future.
    ///
    /// # Panics
    ///
    /// Panics, če nova zmogljivost preseže `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Poskuša rezervirati zmogljivost za vsaj `additional` več elementov, ki jih je treba vstaviti v dani `Vec<T>`.
    /// Zbirka lahko rezervira več prostora, da se izogne pogostim prerazporeditvam.
    /// Po klicu `try_reserve` bo zmogljivost večja ali enaka `self.len() + additional`.
    /// Ne stori nič, če je zmogljivost že zadostna.
    ///
    /// # Errors
    ///
    /// Če zmogljivost preseže ali razdeljevalec poroča o napaki, se vrne napaka.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Predhodno rezervirajte pomnilnik in zapustite, če ne moremo
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Zdaj vemo, da tega sredi zapletenega dela ne moremo OOM
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // zelo zapleteno
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Poskuša rezervirati najmanjšo zmogljivost za natančno elemente `additional`, ki jih je treba vstaviti v dani `Vec<T>`.
    /// Po klicu `try_reserve_exact` bo zmogljivost večja ali enaka `self.len() + additional`, če vrne `Ok(())`.
    ///
    /// Nič ne naredi, če je zmogljivost že zadostna.
    ///
    /// Upoštevajte, da lahko razdeljevalnik da zbirki več prostora, kot zahteva.
    /// Zato se ni mogoče zanašati na to, da je zmogljivost povsem minimalna.
    /// Dajte prednost `reserve`, če pričakujete vstavke future.
    ///
    /// # Errors
    ///
    /// Če zmogljivost preseže ali razdeljevalec poroča o napaki, se vrne napaka.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Predhodno rezervirajte pomnilnik in zapustite, če ne moremo
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Zdaj vemo, da tega sredi zapletenega dela ne moremo OOM
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // zelo zapleteno
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Čim bolj skrči zmogljivost vector.
    ///
    /// Spustil se bo čim bližje dolžini, vendar lahko razdeljevalnik še vedno obvesti vector, da je prostora za še nekaj elementov.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Zmogljivost ni nikoli manjša od dolžine in ni ničesar storiti, če sta enaki, zato se lahko primeru `RawVec::shrink_to_fit` panic v `RawVec::shrink_to_fit` izognemo tako, da ga pokličemo samo z večjo zmogljivostjo.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Zmanjša zmogljivost vector z spodnjo mejo.
    ///
    /// Kapaciteta bo ostala vsaj tako velika, kot sta dolžina in dobavljena vrednost.
    ///
    ///
    /// Če je trenutna zmogljivost manjša od spodnje meje, to ne velja.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Pretvori vector v [`Box<[T]>`][owned slice].
    ///
    /// Upoštevajte, da se bo s tem zmanjšala presežna zmogljivost.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Vsa presežna zmogljivost se odstrani:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Skrajša vector, obdrži prve elemente `len`, ostale pa spusti.
    ///
    /// Če je `len` večja od trenutne dolžine vector, to ne vpliva.
    ///
    /// Metoda [`drain`] lahko posnema `truncate`, vendar povzroči, da se odvečni elementi vrnejo, namesto da bi jih spustili.
    ///
    ///
    /// Upoštevajte, da ta metoda ne vpliva na dodeljeno zmogljivost vector.
    ///
    /// # Examples
    ///
    /// Skrajšanje pet elementov vector na dva elementa:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Do okrnitve ne pride, če je `len` večja od trenutne dolžine vector:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Skrajšanje, kadar je `len == 0` enakovredno klicanju metode [`clear`].
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // To je varno, ker:
        //
        // * rezina, predana `drop_in_place`, je veljavna;primer `len > self.len` se izogne ustvarjanju neveljavne rezine in
        // * `len` vector se pred klicem `drop_in_place` skrči, tako da nobena vrednost ne bo padla dvakrat, če bi `drop_in_place` enkrat padel na panic (če je panics dvakrat, program prekine).
        //
        //
        //
        unsafe {
            // Note: Namerno je, da je to `>` in ne `>=`.
            //       Spreminjanje na `>=` ima v nekaterih primerih negativne posledice za delovanje.
            //       Za več glejte #78884.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Izvleče rezino, ki vsebuje celoten vector.
    ///
    /// Enakovredno `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Izvleče spremenljivo rezino celotnega vector.
    ///
    /// Enakovredno `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Vrne neobdelani kazalnik na medpomnilnik vector.
    ///
    /// Klicatelj mora zagotoviti, da vector preseže kazalec, ki ga ta funkcija vrne, sicer bo na koncu kazal na smeti.
    /// Sprememba vector lahko povzroči prerazporeditev njegovega vmesnega pomnilnika, zaradi česar bodo morebitni kazalci nanj neveljavni.
    ///
    /// Klicatelj mora zagotoviti tudi, da se v ta pomnilnik ali kateri koli kazalnik, ki izhaja iz njega, nikoli ne zapiše v pomnilnik, na katerega kaže kazalec (non-transitively) (razen znotraj `UnsafeCell`).
    /// Če želite mutirati vsebino rezine, uporabite [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Metodo rezine z istim imenom senčimo, da se izognemo prehodu skozi `deref`, ki ustvari vmesno referenco.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Vrne nevarno spremenljiv kazalec na medpomnilnik vector.
    ///
    /// Klicatelj mora zagotoviti, da vector preseže kazalec, ki ga ta funkcija vrne, sicer bo na koncu kazal na smeti.
    ///
    /// Sprememba vector lahko povzroči prerazporeditev njegovega vmesnega pomnilnika, zaradi česar bodo morebitni kazalci nanj neveljavni.
    ///
    /// # Examples
    ///
    /// ```
    /// // Dodelite vector dovolj velik za 4 elemente.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Elemente inicializirajte s pomočjo surovih zapisov kazalca, nato nastavite dolžino.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Metodo rezine z istim imenom senčimo, da se izognemo prehodu skozi `deref_mut`, ki ustvari vmesno referenco.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Vrne sklic na osnovni razdeljevalec.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Prisili dolžino vector do `new_len`.
    ///
    /// To je operacija na nizki ravni, ki ne ohranja nobene običajne invariante tipa.
    /// Običajno spreminjanje dolžine vector izvedemo z uporabo ene od varnih operacij, kot so [`truncate`], [`resize`], [`extend`] ali [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` mora biti manjši ali enak [`capacity()`].
    /// - Elemente v `old_len..new_len` je treba inicializirati.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Ta metoda je lahko uporabna v situacijah, v katerih vector služi kot medpomnilnik za drugo kodo, zlasti prek FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // To je le minimalno okostje za primer dokumenta;
    /// # // ne uporabljajte tega kot izhodišča za pravo knjižnico.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // V skladu z dokumenti metode FFI "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // VARNOST: Ko `deflateGetDictionary` vrne `Z_OK`, velja, da:
    ///     // 1. `dict_length` elementi so bili inicializirani.
    ///     // 2.
    ///     // `dict_length` <=zmogljivost (32_768), zaradi česar je `set_len` varno za klicanje.
    ///     unsafe {
    ///         // Opravite klic FFI ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... in posodobite dolžino na inicializirano.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Medtem ko je naslednji primer zvok, prihaja do puščanja pomnilnika, saj notranji vectors pred klicem `set_len` niso bili sproščeni:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` je prazen, zato ni treba inicializirati elementov.
    /// // 2. `0 <= capacity` vedno vsebuje vse, kar je `capacity`.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Običajno bi tukaj raje uporabili [`clear`], da bi pravilno spustili vsebino in tako ne bi puščali pomnilnika.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Odstrani element iz vector in ga vrne.
    ///
    /// Odstranjeni element se nadomesti z zadnjim elementom vector.
    ///
    /// To ne ohranja naročila, je pa O(1).
    ///
    /// # Panics
    ///
    /// Panics, če `index` ni v mejah.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Self [indeks] zamenjamo z zadnjim elementom.
            // Če zgornje preverjanje meja uspe, mora obstajati zadnji element (ki je lahko sam [indeks]).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Vstavi element na položaju `index` znotraj vector in premakne vse elemente za njim v desno.
    ///
    ///
    /// # Panics
    ///
    /// Panics, če `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // prostor za novi element
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // nezmotljiv Spot, ki postavlja novo vrednost
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Prestavite vse, da sprostite prostor.
                // (Podvajanje elementa `index` na dva zaporedna mesta.)
                ptr::copy(p, p.offset(1), len - index);
                // Zapišite ga in prepišite prvo kopijo elementa `index`.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Odstrani in vrne element na položaju `index` znotraj vector, pri čemer vse elemente za njim premakne v levo.
    ///
    ///
    /// # Panics
    ///
    /// Panics, če `index` ni v mejah.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // kraj, od koder jemljemo.
                let ptr = self.as_mut_ptr().add(index);
                // kopirajte ga, pri čemer imate nevarno kopijo vrednosti na kupu in hkrati v vector.
                //
                ret = ptr::read(ptr);

                // Premaknite vse navzdol, da zapolnite to mesto.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Obdrži samo elemente, ki jih določa predikat.
    ///
    /// Z drugimi besedami, odstranite vse elemente `e`, tako da `f(&e)` vrne `false`.
    /// Ta metoda deluje na mestu, obišče vsak element natančno enkrat v prvotnem vrstnem redu in ohrani vrstni red zadržanih elementov.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Ker so elementi obiskani natančno enkrat v prvotnem vrstnem redu, se lahko z zunanjim stanjem odločimo, katere elemente bomo obdržali.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Izogibajte se dvojnemu padcu, če zaščita pred padcem ni izvedena, saj lahko med postopkom naredimo nekaj lukenj.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-obdelana leča-> |^-poleg preverjanja
        //                  | <-črtan cnt-> |
        //      | <-original_len-> |Ohranjeno: Elementi, ki predikat vrnejo vrednost true.
        //
        // Luknja: premaknjena ali spuščena reža elementa.
        // Nepreverjeno: Nepreverjeni veljavni elementi.
        //
        // Ta zaščita pred padcem se bo sprožila, ko bo predikat ali `drop` elementa v paniki.
        // Nepreverjene elemente premakne tako, da prekrije luknje in `set_len` na pravilno dolžino.
        // V primerih, ko se predikat in `drop` ne bosta nikoli prestrašili, bo optimiziran.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // VARNOST: Sledilni nepreverjeni predmeti morajo biti veljavni, saj se jih nikoli ne dotaknemo.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // VARNOST: Po zapolnitvi lukenj so vsi predmeti v neprekinjenem pomnilniku.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // VARNOST: Neodključen element mora biti veljaven.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Vnaprej zgodaj, da se izognete dvojnemu padcu, če je `drop_in_place` paničen.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // VARNOST: Tega elementa se po padcu nikoli več ne dotaknemo.
                unsafe { ptr::drop_in_place(cur) };
                // Števec smo že napredovali.
                continue;
            }
            if g.deleted_cnt > 0 {
                // VARNOST: `deleted_cnt`> 0, zato se reža luknje ne sme prekrivati s trenutnim elementom.
                // Za premikanje uporabljamo kopijo in se tega elementa nikoli več ne dotaknemo.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Vsi elementi so obdelani.To lahko LLVM optimizira na `set_len`.
        drop(g);
    }

    /// Odstrani vse zaporedne elemente v vector, razen prvega, ki se ločijo na isti ključ.
    ///
    ///
    /// Če je vector razvrščen, to odstrani vse dvojnike.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Odstrani vse zaporedne elemente razen prvega v vector, ki izpolnjujejo dano relacijo enakosti.
    ///
    /// Funkciji `same_bucket` se posredujejo sklici na dva elementa iz vector in mora določiti, ali se elementi primerjajo enako.
    /// Elementi se posredujejo v nasprotnem vrstnem redu od njihovega vrstnega reda v rezini, tako da, če `same_bucket(a, b)` vrne `true`, se `a` odstrani.
    ///
    ///
    /// Če je vector razvrščen, to odstrani vse dvojnike.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Doda element na zadnji del zbirke.
    ///
    /// # Panics
    ///
    /// Panics, če nova zmogljivost presega `isize::MAX` bajtov.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // To bo povzročilo panic ali prekinilo, če bi dodelili> isize::MAX bajtov ali če bi prirastek dolžine pri tipih ničelne velikosti presegel.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Odstrani zadnji element iz vector in ga vrne ali [`None`], če je prazen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Premakne vse elemente `other` v `Self`, `other` pa ostane prazen.
    ///
    /// # Panics
    ///
    /// Panics, če število elementov v vector preseže `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Elemente doda `Self` iz drugega vmesnega pomnilnika.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Ustvari odtočni iterator, ki odstrani navedeni obseg v vector in ustvari odstranjene elemente.
    ///
    /// Ko iterator **pade**, se vsi elementi v obsegu odstranijo iz vector, tudi če iterator ni bil porabljen v celoti.
    /// Če iterator **ni** izpuščen (na primer pri [`mem::forget`]), ni določeno, koliko elementov je odstranjenih.
    ///
    /// # Panics
    ///
    /// Panics, če je začetna točka večja od končne točke ali če je končna točka večja od dolžine vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Celoten obseg očisti vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Varnost spomina
        //
        // Ko je Drain prvič ustvarjen, skrajša dolžino izvornega vector, da zagotovi, da sploh niso dostopni nobeni neinicializirani ali premaknjeni elementi, če destruktor Drain nikoli ne zažene.
        //
        //
        // Drain bo ptr::read izločil vrednosti, ki jih je treba odstraniti.
        // Ko končate, se preostali rep veca prekopira nazaj, da pokrije luknjo, in dolžina vector se obnovi na novo dolžino.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // nastavite dolžino self.vec na začetek, da bo varna v primeru puščanja Drain
            self.set_len(start);
            // Uporabite izposojo v IterMut, da označite vedenje izposojanja celotnega iteratorja Drain (na primer &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Počisti vector in odstrani vse vrednosti.
    ///
    /// Upoštevajte, da ta metoda ne vpliva na dodeljeno zmogljivost vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Vrne število elementov v vector, imenovanem tudi njegov 'length'.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Vrne `true`, če vector ne vsebuje elementov.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Zbirko razdeli na dva pri danem indeksu.
    ///
    /// Vrne na novo dodeljeni vector, ki vsebuje elemente v obsegu `[at, len)`.
    /// Po klicu ostane originalni vector, ki vsebuje elemente `[0, at)` s prejšnjo zmogljivostjo nespremenjeno.
    ///
    ///
    /// # Panics
    ///
    /// Panics, če `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // novi vector lahko prevzame originalni medpomnilnik in se izogne kopiji
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Nevarno `set_len` in kopirajte predmete v `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Spremeni velikost `Vec` na mestu, tako da je `len` enaka `new_len`.
    ///
    /// Če je `new_len` večji od `len`, se `Vec` podaljša za razliko, pri čemer se vsaka dodatna reža napolni z rezultatom klica zapiranja `f`.
    ///
    /// Vrnjene vrednosti iz `f` bodo končale v `Vec` v vrstnem redu, kot so bile ustvarjene.
    ///
    /// Če je `new_len` manjši od `len`, je `Vec` preprosto okrnjen.
    ///
    /// Ta metoda uporablja zapiranje za ustvarjanje novih vrednosti pri vsakem pritisku.Če želite [`Clone`] določeno vrednost, uporabite [`Vec::resize`].
    /// Če želite uporabiti [`Default`] Portrait za generiranje vrednosti, lahko [`Default::default`] posredujete kot drugi argument.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Porabi in pušča `Vec` ter vrne spremenljivo referenco na vsebino, `&'a mut [T]`.
    /// Upoštevajte, da mora tip `T` preživeti izbrano življenjsko dobo `'a`.
    /// Če ima tip samo statične sklice ali jih sploh nima, je to lahko izbrano `'static`.
    ///
    /// Ta funkcija je podobna funkciji [`leak`][Box::leak] na [`Box`], le da uhajanja pomnilnika ni mogoče obnoviti.
    ///
    ///
    /// Ta funkcija je uporabna predvsem za podatke, ki živijo do konca življenja programa.
    /// Če spustite vrnjeno referenco, bo prišlo do puščanja pomnilnika.
    ///
    /// # Examples
    ///
    /// Preprosta uporaba:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Vrne preostalo rezervno zmogljivost vector kot rezino `MaybeUninit<T>`.
    ///
    /// Vrnjeno rezino lahko uporabimo za polnjenje vector s podatki (npr
    /// z branjem iz datoteke), preden podatke označite kot inicializirane z metodo [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Dodelite vector dovolj velik za 10 elementov.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Izpolnite prve 3 elemente.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Označi prve 3 elemente vector kot inicializirane.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Ta metoda ni izvedena v smislu `split_at_spare_mut`, da se prepreči razveljavitev kazalcev na vmesnik.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Vrne vsebino vector kot rezino `T`, skupaj s preostalo prosto zmogljivostjo vector kot rezino `MaybeUninit<T>`.
    ///
    /// Vrnjeno rezino rezervne prostornine lahko uporabimo za polnjenje vector s podatki (npr. Z branjem iz datoteke), preden podatke označimo kot inicializirane z metodo [`set_len`].
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Upoštevajte, da gre za API na nizki ravni, ki ga je treba skrbno uporabljati za namene optimizacije.
    /// Če želite podatke dodati `Vec`, lahko uporabite [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] ali [`resize_with`], odvisno od vaših natančnih potreb.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Rezervirajte dodaten prostor, dovolj velik za 10 elementov.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Izpolnite naslednje 4 elemente.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Označite 4 elemente vector kot inicializirane.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len se prezre in se zato nikoli ne spremeni
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Varnost: sprememba vrnjenega .2 (&mut usize) velja za enako kot klicanje `.set_len(_)`.
    ///
    /// Ta metoda se uporablja za edinstven dostop do vseh vec delov naenkrat v `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` velja za elemente `len`
        // - `spare_ptr` usmerja en element mimo vmesnega pomnilnika, zato se ne prekriva z `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Spremeni velikost `Vec` na mestu, tako da je `len` enaka `new_len`.
    ///
    /// Če je `new_len` večji od `len`, se `Vec` podaljša za razliko, pri čemer se vsaka dodatna reža napolni z `value`.
    ///
    /// Če je `new_len` manjši od `len`, je `Vec` preprosto okrnjen.
    ///
    /// Ta metoda zahteva, da `T` implementira [`Clone`], da lahko klonira posredovano vrednost.
    /// Če potrebujete več prilagodljivosti (ali se želite zanašati na [`Default`] namesto na [`Clone`]), uporabite [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Klonira in doda vse elemente v rezini `Vec`.
    ///
    /// Iteratira čez rezino `other`, klonira vsak element in ga nato doda temu `Vec`.
    /// `other` vector se vozi po vrstnem redu.
    ///
    /// Upoštevajte, da je ta funkcija enaka kot [`extend`], le da je specializirana za delo z rezinami.
    ///
    /// Če in ko bo Rust dobil specializacijo, bo ta funkcija verjetno zastarela (vendar še vedno na voljo).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Kopira elemente od `src` do konca vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` zagotavlja, da je navedeni obseg veljaven za samoindeksiranje
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Ta koda posplošuje `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Z danim generatorjem razširite vector za vrednosti `n`.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Uporabite SetLenOnDrop, da se izognete hroščem, kjer prevajalnik morda ne bo shranil, da shramba prek `ptr` do self.set_len() ni vzdevek.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Napišite vse elemente, razen zadnjega
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // V primeru, da next() panics povečate dolžino v vsakem koraku
                local_len.increment_len(1);
            }

            if n > 0 {
                // Zadnji element lahko napišemo neposredno, brez nepotrebnega kloniranja
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // leča, nastavljena s pomočjo varovala
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Odstrani zaporedne ponavljajoče se elemente v vector v skladu z izvedbo [`PartialEq`] Portrait.
    ///
    ///
    /// Če je vector razvrščen, to odstrani vse dvojnike.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Notranje metode in funkcije
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` mora biti veljaven indeks
    /// - `self.capacity() - self.len()` mora biti `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len se poveča šele po inicializaciji elementov
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - klicatelj jamči, da je src veljaven indeks
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Element je bil pravkar inicializiran z `MaybeUninit::write`, zato je v redu, če ga želite povečati
            // - lena se poveča po vsakem elementu, da se prepreči puščanje (glej izdajo #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - klicatelj jamči, da je `src` veljaven indeks
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Oba kazalca sta ustvarjena iz edinstvenih sklicev na rezine (`&mut [_]`), zato sta veljavna in se ne prekrivata.
            //
            // - Elementi so: Kopiraj, zato je v redu, če jih kopirate, ne da bi karkoli storili s prvotnimi vrednostmi
            // - `count` je enak leni `source`, zato vir velja za branje `count`
            // - `.reserve(count)` zagotavlja, da `spare.len() >= count` tako rezerven velja za zapise `count`
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Elemente je pravkar inicializiral `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Pogoste izvedbe Portrait za Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): pri cfg(test) lastna metoda `[T]::to_vec`, ki je potrebna za to definicijo metode, ni na voljo.
    // Namesto tega uporabite funkcijo `slice::to_vec`, ki je na voljo samo z cfg(test) NB, za več informacij glejte modul slice::hack v slice.rs
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // spustite vse, kar ne bo prepisano
        self.truncate(other.len());

        // self.len <= other.len zaradi zgornjega odseka, zato so rezine tukaj vedno znotraj meja.
        //
        let (init, tail) = other.split_at(self.len());

        // ponovno uporabiti vsebovane vrednosti allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Ustvari porabni iterator, to je tisti, ki vsako vrednost premakne iz vector (od začetka do konca).
    /// Po tem klicu vector ni več mogoče uporabiti.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s ima vrsto String in ne &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // leaf metoda, ki jo različne izvedbe SpecFrom/SpecExtend pooblastijo, če nimajo dodatnih optimizacij za uporabo
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // To velja za splošni iterator.
        //
        // Ta funkcija bi morala biti moralni ekvivalent:
        //
        //      za element v iteratorju {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // Opomba se ne more preliti, ker bi morali dodeliti naslovni prostor
                self.set_len(len + 1);
            }
        }
    }

    /// Ustvari iterator spajanja, ki nadomesti navedeni obseg v vector z danim iteratorjem `replace_with` in ustvari odstranjene elemente.
    ///
    /// `replace_with` ne sme biti enake dolžine kot `range`.
    ///
    /// `range` se odstrani, tudi če iteratorja ne porabite do konca.
    ///
    /// Ni določeno, koliko elementov je odstranjenih iz vector, če je vrednost `Splice` uhajala.
    ///
    /// Vhodni iterator `replace_with` se porabi šele, ko pade vrednost `Splice`.
    ///
    /// To je optimalno, če:
    ///
    /// * Rep (elementi v vector po `range`) je prazen,
    /// * ali `replace_with` daje manj ali enakih elementov kot dolžina "obsega"
    /// * ali spodnja meja `size_hint()` je natančna.
    ///
    /// V nasprotnem primeru se dodeli začasni vector in rep se dvakrat premakne.
    ///
    /// # Panics
    ///
    /// Panics, če je začetna točka večja od končne točke ali če je končna točka večja od dolžine vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Ustvari iterator, ki s pomočjo zapore ugotovi, ali je treba element odstraniti.
    ///
    /// Če zaprtje vrne vrednost true, se element odstrani in izda.
    /// Če zaprtje vrne false, bo element ostal v vector in ga iterator ne bo dal.
    ///
    /// Uporaba te metode je enakovredna naslednji kodi:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // svojo kodo tukaj
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Toda `drain_filter` je enostavnejši za uporabo.
    /// `drain_filter` je tudi učinkovitejši, saj lahko v velikem pomiku premakne elemente polja.
    ///
    /// Upoštevajte, da vam `drain_filter` omogoča tudi mutiranje vseh elementov v zapiranju filtra, ne glede na to, ali se odločite, da ga obdržite ali odstranite.
    ///
    ///
    /// # Examples
    ///
    /// Razdelitev matrike na enake in verjetne, ponovna uporaba prvotne dodelitve:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Pazite, da ne bomo puščali (ojačanje puščanja)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Razširite izvajanje, ki kopira elemente iz referenc, preden jih potisnete na Vec.
///
/// Ta izvedba je specializirana za iteratorje rezin, kjer uporablja [`copy_from_slice`] za dodajanje celotne rezine hkrati.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Izvaja primerjavo vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Izvaja naročanje vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // uporabite padec za [T] uporabite surovo rezino, da se elementi vector sklicujejo na najšibkejši potreben tip;
            //
            // bi se lahko v nekaterih primerih izognili vprašanjem o veljavnosti
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec obravnava sprostitev
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Ustvari prazen `Vec<T>`.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: test potegne libstd, kar tukaj povzroča napake
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: test potegne libstd, kar tukaj povzroča napake
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Pridobi celotno vsebino `Vec<T>` kot matriko, če se njegova velikost natančno ujema z zahtevano matriko.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Če se dolžina ne ujema, se vhod vrne v `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Če ste v redu s samo predpono `Vec<T>`, lahko najprej pokličete [`.truncate(N)`](Vec::truncate).
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // VARNOST: `.set_len(0)` je vedno zvok.
        unsafe { vec.set_len(0) };

        // VARNOST: Kazalec `Vec` je vedno pravilno poravnan in
        // poravnava, ki jo potrebuje polje, je enaka postavkam.
        // Prej smo preverili, ali imamo dovolj predmetov.
        // Elementi se ne bodo dvakrat spustili, saj `set_len` X100Xu pove, da jih tudi ne spusti.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}