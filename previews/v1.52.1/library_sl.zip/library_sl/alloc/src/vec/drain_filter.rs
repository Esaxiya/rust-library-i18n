use crate::alloc::{Allocator, Global};
use core::ptr::{self};
use core::slice::{self};

use super::Vec;

/// Ponavljalec, ki s pomočjo zapore ugotovi, ali je treba element odstraniti.
///
/// To strukturo je ustvaril [`Vec::drain_filter`].
/// Za več si oglejte njegovo dokumentacijo.
///
/// # Example
///
/// ```
/// #![feature(drain_filter)]
///
/// let mut v = vec![0, 1, 2];
/// let iter: std::vec::DrainFilter<_, _> = v.drain_filter(|x| *x % 2 == 0);
/// ```
#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
#[derive(Debug)]
pub struct DrainFilter<
    'a,
    T,
    F,
    #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global,
> where
    F: FnMut(&mut T) -> bool,
{
    pub(super) vec: &'a mut Vec<T, A>,
    /// Indeks elementa, ki ga bo pregledal naslednji klic na `next`.
    pub(super) idx: usize,
    /// Število elementov, ki so bili do zdaj izsušeni (removed).
    pub(super) del: usize,
    /// Prvotna dolžina `vec` pred praznjenjem.
    pub(super) old_len: usize,
    /// Predikat preizkusa filtra.
    pub(super) pred: F,
    /// Oznaka, ki označuje panic, se je pojavila v predikatu preizkusa filtra.
    /// To se uporablja kot namig pri izvedbi spuščanja, da se prepreči poraba preostalega dela `DrainFilter`.
    /// Vsi neobdelani predmeti bodo v `vec` prestavljeni nazaj, vendar predikat filtra ne bo spustil ali preizkusil nadaljnjih elementov.
    ///
    ///
    pub(super) panic_flag: bool,
}

impl<T, F, A: Allocator> DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    /// Vrne sklic na osnovni razdeljevalec.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.vec.allocator()
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Iterator for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    type Item = T;

    fn next(&mut self) -> Option<T> {
        unsafe {
            while self.idx < self.old_len {
                let i = self.idx;
                let v = slice::from_raw_parts_mut(self.vec.as_mut_ptr(), self.old_len);
                self.panic_flag = true;
                let drained = (self.pred)(&mut v[i]);
                self.panic_flag = false;
                // Posodobite indeks *po*, ko se pokliče predikat.
                // Če je indeks posodobljen pred in predikat panics, bi element v tem indeksu uhajal.
                //
                self.idx += 1;
                if drained {
                    self.del += 1;
                    return Some(ptr::read(&v[i]));
                } else if self.del > 0 {
                    let del = self.del;
                    let src: *const T = &v[i];
                    let dst: *mut T = &mut v[i - del];
                    ptr::copy_nonoverlapping(src, dst, 1);
                }
            }
            None
        }
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.old_len - self.idx))
    }
}

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
impl<T, F, A: Allocator> Drop for DrainFilter<'_, T, F, A>
where
    F: FnMut(&mut T) -> bool,
{
    fn drop(&mut self) {
        struct BackshiftOnDrop<'a, 'b, T, F, A: Allocator>
        where
            F: FnMut(&mut T) -> bool,
        {
            drain: &'b mut DrainFilter<'a, T, F, A>,
        }

        impl<'a, 'b, T, F, A: Allocator> Drop for BackshiftOnDrop<'a, 'b, T, F, A>
        where
            F: FnMut(&mut T) -> bool,
        {
            fn drop(&mut self) {
                unsafe {
                    if self.drain.idx < self.drain.old_len && self.drain.del > 0 {
                        // To je precej zamočeno stanje in očitno ni prav, da bi to storili.
                        // Ne želimo si še naprej poskušati zagnati `pred`, zato preprosto prestavimo vse nepredelane elemente in vecu povemo, da še vedno obstajajo.
                        //
                        // Preklop nazaj je potreben, da se prepreči dvojni padec zadnjega uspešno izpraznjenega predmeta pred panic v predikatu.
                        //
                        //
                        let ptr = self.drain.vec.as_mut_ptr();
                        let src = ptr.add(self.drain.idx);
                        let dst = src.sub(self.drain.del);
                        let tail_len = self.drain.old_len - self.drain.idx;
                        src.copy_to(dst, tail_len);
                    }
                    self.drain.vec.set_len(self.drain.old_len - self.drain.del);
                }
            }
        }

        let backshift = BackshiftOnDrop { drain: self };

        // Poskus porabe preostalih elementov, če predikat filtra še ni prestrašil.
        // Preostale elemente bomo preusmerili nazaj, ne glede na to, ali smo že v paniki ali če je poraba tukaj panics.
        //
        if !backshift.drain.panic_flag {
            backshift.drain.for_each(drop);
        }
    }
}