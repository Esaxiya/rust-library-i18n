use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Specializacija Portrait za Vec::from_iter
///
/// ## Graf prenosa:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Pogost primer je posredovanje vector v funkcijo, ki se takoj ponovno zbere v vector.
        // To lahko povzročimo v kratkem stiku, če IntoIter sploh ni napreden.
        // Ko je napreden, lahko tudi ponovno uporabimo pomnilnik in podatke premaknemo na sprednjo stran.
        // Toda to storimo le, če dobljeni Vec ne bi imel več neizkoriščene zmogljivosti, kot bi ga ustvaril z generično izvedbo FromIterator.
        //
        // Ta omejitev ni nujno potrebna, saj Vecovo vedenje pri dodeljevanju namerno ni določeno.
        // Ampak to je konzervativna izbira.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // mora delegirati na spec_extend(), ker extend() sam delegira na spec_from za prazne Vecs
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Ta uporablja `iterator.as_slice().to_vec()`, saj mora spec_extend narediti več korakov, da razloži končno zmogljivost + dolžino in tako narediti več dela.
// `to_vec()` neposredno dodeli pravilno količino in jo natančno napolni.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): pri cfg(test) lastna metoda `[T]::to_vec`, ki je potrebna za to definicijo metode, ni na voljo.
    // Namesto tega uporabite funkcijo `slice::to_vec`, ki je na voljo samo z cfg(test) NB, za več informacij glejte modul slice::hack v slice.rs
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}