#![stable(feature = "wake_trait", since = "1.51.0")]
//! Vrste in Traits za delo z asinhronimi nalogami.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Izvajanje prebujanja naloge na izvršitelja.
///
/// Ta Portrait lahko uporabite za ustvarjanje [`Waker`].
/// Izvršitelj lahko definira izvedbo tega Portrait in jo uporabi za izdelavo Wakerja, da preide na naloge, ki se izvajajo na tem izvršitelju.
///
/// Ta Portrait je spominsko varna in ergonomska alternativa izdelavi [`RawWaker`].
/// Podpira običajno izvedbeno zasnovo, v kateri se podatki, ki se uporabljajo za prebujanje naloge, shranijo v [`Arc`].
/// Nekateri izvršitelji (zlasti tisti za vdelane sisteme) tega API-ja ne morejo uporabljati, zato [`RawWaker`] obstaja kot alternativa za te sisteme.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Osnovna funkcija `block_on`, ki sprejme future in jo dokonča na trenutni niti.
///
/// **Note:** Ta primer spreminja pravilnost zaradi enostavnosti.
/// Da bi preprečili blokade, bodo izvedbe proizvodne stopnje morale obravnavati tudi vmesne klice na `thread::unpark` in ugnezdene klice.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Waker, ki ob klicu zbudi trenutno nit.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Zaženite future do konca na trenutni niti.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // future pripnite, da bo lahko anketiran.
///     let mut fut = Box::pin(fut);
///
///     // Ustvarite nov kontekst, ki ga želite posredovati future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Zaženite future do konca.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Zbudi to nalogo.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Prebudite to nalogo, ne da bi porabili budnico.
    ///
    /// Če izvršitelj podpira cenejši način prebujanja, ne da bi požrl budnico, bi moral to metodo preglasiti.
    /// Privzeto klonira [`Arc`] in na klonu pokliče [`wake`].
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // VARNOST: To je varno, ker raw_waker varno gradi
        // RawWaker iz Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Ta zasebna funkcija za izdelavo RawWakerja se uporablja namesto
// to vključi v impl `From<Arc<W>> for RawWaker`, da se zagotovi, da varnost `From<Arc<W>> for Waker` ni odvisna od pravilne odpreme Portrait, ampak oba impulza to funkcijo pokličeta neposredno in eksplicitno.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Povečajte referenčno število loka, da ga klonirate.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Zbudite se po vrednosti in premaknite lok v funkcijo Wake::wake
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Zbudite se po referenci, zavijte waker v ManuallyDrop, da ga ne spustite
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Zmanjšajte referenčno število loka ob padcu
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}