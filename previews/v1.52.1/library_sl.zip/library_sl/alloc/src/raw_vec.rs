#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Vsebina novega pomnilnika je neinicializirana.
    Uninitialized,
    /// Zajamčeno je, da bo nov pomnilnik nič.
    Zeroed,
}

/// Pripomoček na nizki ravni za bolj ergonomsko dodeljevanje, prerazporejanje in odstranjevanje vmesnega pomnilnika na kupu, ne da bi morali skrbeti za vse zadevne vogale.
///
/// Ta vrsta je odlična za izdelavo lastnih podatkovnih struktur, kot sta Vec in VecDeque.
/// Še posebej:
///
/// * Izdeluje `Unique::dangling()` na nič velikih tipih.
/// * Proizvaja `Unique::dangling()` na dodelitvah ničelne dolžine.
/// * Izogiba se sprostitvi `Unique::dangling()`.
/// * V izračunih zmogljivosti zajame vse presežke (jih poviša v "capacity overflow" panics).
/// * Ščiti pred 32-bitnimi sistemi, ki dodeljujejo več kot isize::MAX bajtov.
/// * Ščiti pred prelivanjem vaše dolžine.
/// * Pokliče `handle_alloc_error` za napačne dodelitve.
/// * Vsebuje `ptr::Unique` in tako uporabnika obdari z vsemi povezanimi ugodnostmi.
/// * Presežek, ki ga vrne razdeljevalec, uporabi največjo razpoložljivo zmogljivost.
///
/// Ta vrsta v nobenem primeru ne pregleda pomnilnika, ki ga upravlja.Ko ga spustite *, bo* sprostil spomin, vendar *ne bo* poskušal spustiti njegove vsebine.
/// Uporabnik `RawVec` je sam, da ravna z dejanskimi stvarmi,*shranjenimi* znotraj `RawVec`.
///
/// Upoštevajte, da je presežek tipov velikosti nič vedno neskončen, zato `capacity()` vedno vrne `usize::MAX`.
/// To pomeni, da morate biti previdni pri kroženju te vrste z `Box<[T]>`, saj `capacity()` ne bo dal dolžine.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): To obstaja, ker `#[unstable]` `const fn`s ni nujno, da ustrezajo `min_const_fn`, zato jih ni mogoče poklicati niti v`min_const_fn`s.
    ///
    /// Če spremenite `RawVec<T>::new` ali odvisnosti, pazite, da ne uvedete ničesar, kar bi resnično kršilo `min_const_fn`.
    ///
    /// NOTE: Temu kramu bi se lahko izognili in preverili skladnost z nekim atributom `#[rustc_force_min_const_fn]`, ki zahteva skladnost z `min_const_fn`, ni pa nujno, da ga lahko pokličemo v `stable(...) const fn`/uporabniška koda ne omogoči `foo`, ko je prisoten `#[rustc_const_unstable(feature = "foo", issue = "01234")]`.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Ustvari največji možni `RawVec` (na sistemski kopici) brez dodelitve.
    /// Če ima `T` pozitivno velikost, potem to postane `RawVec` s kapaciteto `0`.
    /// Če je `T` ničelne velikosti, potem naredi `RawVec` s kapaciteto `usize::MAX`.
    /// Uporabno za izvajanje odložene dodelitve.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Ustvari `RawVec` (na sistemski kopici) z natančno zahtevami glede zmogljivosti in poravnave za `[T; capacity]`.
    /// To je enakovredno klicanju `RawVec::new`, kadar je `capacity` `0` ali `T` nič.
    /// Če je `T` ničelne velikosti, to pomeni, da *ne boste* dobili `RawVec` z zahtevano zmogljivostjo.
    ///
    /// # Panics
    ///
    /// Panics, če zahtevana zmogljivost presega `isize::MAX` bajtov.
    ///
    /// # Aborts
    ///
    /// Splav na OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Tako kot `with_capacity`, vendar zagotavlja, da je medpomnilnik nič.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Rekonstituira `RawVec` iz kazalca in zmogljivosti.
    ///
    /// # Safety
    ///
    /// `ptr` mora biti dodeljen (na sistemski kopici) in z danim `capacity`.
    /// `capacity` ne sme presegati `isize::MAX` za velike tipe.(skrb le za 32-bitne sisteme).
    /// ZST vectors ima lahko zmogljivost do `usize::MAX`.
    /// Če `ptr` in `capacity` prihajata iz `RawVec`, je to zagotovljeno.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Drobni Vecs so neumni.Preskoči na:
    // - 8, če je velikost elementa 1, ker bodo kateri koli razdeljevalci kopice zahtevo, manjšo od 8 bajtov, zaokrožili na vsaj 8 bajtov.
    //
    // - 4, če so elementi zmerne velikosti (<=1 KiB).
    // - 1 drugače, da ne bi izgubljali preveč prostora za zelo kratke Vecs.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Tako kot `new`, vendar parametriziran pri izbiri razdeljevalnika za vrnjeni `RawVec`.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` pomeni "unallocated".ničelni tipi so prezrti.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Tako kot `with_capacity`, vendar parametriziran pri izbiri razdeljevalnika za vrnjeni `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Tako kot `with_capacity_zeroed`, vendar parametriziran pri izbiri razdeljevalnika za vrnjeni `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Pretvori `Box<[T]>` v `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Pretvori celotni vmesni pomnilnik v `Box<[MaybeUninit<T>]>` z določenim `len`.
    ///
    /// Upoštevajte, da boste s tem pravilno rekonstruirali morebitne izvedene spremembe `cap`.(Za podrobnosti glejte opis vrste.)
    ///
    /// # Safety
    ///
    /// * `len` mora biti večja ali enaka zadnji zahtevani zmogljivosti in
    /// * `len` mora biti manjši ali enak `self.capacity()`.
    ///
    /// Upoštevajte, da se lahko zahtevana zmogljivost in `self.capacity()` razlikujeta, saj lahko razdeljevalec presežno dodeli in vrne večji pomnilniški blok od zahtevanega.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Preveriti razumnost ene polovice varnostnih zahtev (druge polovice ne moremo preveriti).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Tu se izogibamo `unwrap_or_else`, ker povečuje količino ustvarjenega IR LLVM.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Rekonstituira `RawVec` iz kazalca, zmogljivosti in razdelilnika.
    ///
    /// # Safety
    ///
    /// `ptr` mora biti dodeljen (prek danega razdelilnika `alloc`) in z danim `capacity`.
    /// `capacity` ne sme presegati `isize::MAX` za velike tipe.
    /// (skrb le za 32-bitne sisteme).
    /// ZST vectors ima lahko zmogljivost do `usize::MAX`.
    /// Če `ptr` in `capacity` prihajata iz `RawVec`, ustvarjenega prek `alloc`, je to zagotovljeno.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Pridobi neobdelan kazalec na začetek dodelitve.
    /// Upoštevajte, da je to `Unique::dangling()`, če je `capacity == 0` ali `T` ničelna.
    /// V prvem primeru morate biti previdni.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Pridobi zmogljivost dodelitve.
    ///
    /// To bo vedno `usize::MAX`, če je `T` ničelne velikosti.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Vrne skupni sklic na razdelilnik, ki podpira ta `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Dodeljen nam je del pomnilnika, zato lahko zaobidemo preverjanja med izvajanjem, da dobimo trenutno postavitev.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Zagotavlja, da vmesni pomnilnik vsebuje vsaj dovolj prostora za shranjevanje elementov `len + additional`.
    /// Če še nima dovolj zmogljivosti, bo prerazporedil dovolj prostora in udobnega ohlapnega prostora, da bo amortizirano *O*(1) vedenje.
    ///
    /// To vedenje bo omejilo, če bi se po nepotrebnem povzročil na panic.
    ///
    /// Če `len` preseže `self.capacity()`, to morda ne bo dejansko dodelilo zahtevanega prostora.
    /// To v resnici ni varno, toda nevarna koda *, ki jo napišete in ki temelji na vedenju te funkcije, se lahko pokvari.
    ///
    /// To je idealno za izvajanje operacije množičnega potiskanja, kot je `extend`.
    ///
    /// # Panics
    ///
    /// Panics, če nova zmogljivost presega `isize::MAX` bajtov.
    ///
    /// # Aborts
    ///
    /// Splav na OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // rezerva bi bila prekinjena ali panična, če bi leča presegla `isize::MAX`, zato je to zdaj varno narediti neoznačeno.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Enako kot `reserve`, vendar vrne napake, namesto da bi paničil ali prekinil.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Zagotavlja, da vmesni pomnilnik vsebuje vsaj dovolj prostora za shranjevanje elementov `len + additional`.
    /// Če še ni, bo prerazporedil najmanjšo možno količino potrebnega pomnilnika.
    /// Na splošno bo to natančno potrebna količina pomnilnika, a razdelilnik načeloma lahko vrne več, kot smo zahtevali.
    ///
    ///
    /// Če `len` preseže `self.capacity()`, to morda ne bo dejansko dodelilo zahtevanega prostora.
    /// To v resnici ni varno, toda nevarna koda *, ki jo napišete in ki temelji na vedenju te funkcije, se lahko pokvari.
    ///
    /// # Panics
    ///
    /// Panics, če nova zmogljivost presega `isize::MAX` bajtov.
    ///
    /// # Aborts
    ///
    /// Splav na OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Enako kot `reserve_exact`, vendar vrne napake, namesto da bi paničil ali prekinil.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Dodelitev zmanjša na določen znesek.
    /// Če je dani znesek 0, se dejansko popolnoma sprosti.
    ///
    /// # Panics
    ///
    /// Panics, če je dani znesek *večji* od trenutne zmogljivosti.
    ///
    /// # Aborts
    ///
    /// Splav na OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Vrne se, če mora medpomnilnik rasti, da izpolni potrebno dodatno zmogljivost.
    /// V glavnem se uporablja za vključitev rezervnih klicev brez vključitve `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Ta metoda se ponavadi izvede večkrat.Torej želimo, da je čim manjši, da se izboljša čas prevajanja.
    // Želimo pa si tudi, da bi bilo čim več njene vsebine statično izračunanih, da bi ustvarjena koda delovala hitreje.
    // Zato je ta metoda skrbno napisana, tako da je v njej vsa koda, ki je odvisna od `T`, medtem ko je čim več kode, ki ni odvisna od `T`, v funkcijah, ki niso generične kot `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // To zagotavljajo klicni konteksti.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Ker vrnemo zmogljivost `usize::MAX`, ko je `elem_size`
            // 0, če pridete sem, pomeni, da je `RawVec` pretiran.
            return Err(CapacityOverflow);
        }

        // Na žalost teh pregledov ne moremo storiti ničesar.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // To zagotavlja eksponentno rast.
        // Podvojitev se ne more preliti, ker je `cap <= isize::MAX` in tip `cap` `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` ni generičen v primerjavi z `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Omejitve pri tej metodi so skoraj enake kot pri `grow_amortized`, vendar je ta metoda ponavadi postavljena manj pogosto, zato je manj kritična.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Ker vrnemo zmogljivost `usize::MAX`, ko je velikost tipa
            // 0, če pridete sem, pomeni, da je `RawVec` pretiran.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` ni generičen v primerjavi z `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Ta funkcija je zunaj `RawVec`, da zmanjša čas prevajanja.Za podrobnosti glejte komentar zgoraj `RawVec::grow_amortized`.
// (Parameter `A` ni pomemben, ker je število različnih vrst `A`, ki jih vidimo v praksi, veliko manjše od števila tipov `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Tu poiščite napako, da zmanjšate velikost `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Dodeljevalec preveri, ali je enakovrednost poravnave
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Osvobodi pomnilnik v lasti `RawVec`*, ne da bi* poskušal spustiti njegovo vsebino.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Centralna funkcija za obdelavo rezervnih napak.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Zagotoviti moramo naslednje:
// * Nikoli ne dodelimo predmetov velikosti bajtov `> isize::MAX`.
// * `usize::MAX` ne prelivamo in ga pravzaprav dodelimo premalo.
//
// Na 64-bitni moramo samo preveriti, ali je preliv presežen, saj poskus dodelitve bajtov `> isize::MAX` zagotovo ne bo uspel.
// Pri 32-bitnih in 16-bitnih moramo za to dodati še dodatno zaščito, če uporabljamo platformo, ki lahko v uporabniškem prostoru uporablja vseh 4 GB, npr. PAE ali x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Ena osrednja funkcija, ki je odgovorna za poročanje o presežkih zmogljivosti.
// To bo zagotovilo, da je generiranje kode, povezano s temi panics, minimalno, saj obstaja samo ena lokacija, ki panics in ne kup v celotnem modulu.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}