//! Dinamično velik pogled v sosednje zaporedje, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Rezine so pogled na blok pomnilnika, predstavljen kot kazalec in dolžina.
//!
//! ```
//! // rezanje Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // prisilitev polja v rezino
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Rezine lahko spreminjate ali delite z drugimi.
//! Tip rezine v skupni rabi je `&[T]`, medtem ko je spremenljiv tip rezine `&mut [T]`, kjer `T` predstavlja vrsto elementa.
//! Na primer, lahko mutirate blok pomnilnika, na katerega kaže spremenljiva rezina:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Nekaj stvari, ki jih vsebuje ta modul:
//!
//! ## Structs
//!
//! Obstaja več struktur, ki so uporabne za rezine, na primer [`Iter`], ki predstavlja ponovitev nad rezino.
//!
//! ## Trait Izvedbe
//!
//! Obstaja več izvedb običajnih traits za rezine.Nekaj primerov vključuje:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], za rezine, katerih tip elementa je [`Eq`] ali [`Ord`].
//! * [`Hash`] - za rezine, katerih tip elementa je [`Hash`].
//!
//! ## Iteration
//!
//! Rezine izvajajo `IntoIterator`.Iterator daje sklice na elemente rezine.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Spremenljiva rezina daje spremenljive reference na elemente:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Ta iterator daje spremenljive sklice na elemente rezine, zato je vrsta elementa rezine `i32`, vrsta elementa iteratorja pa `&mut i32`.
//!
//!
//! * [`.iter`] in [`.iter_mut`] sta eksplicitni metodi za vrnitev privzetih iteratorjev.
//! * Nadaljnje metode, ki vrnejo iteratorje, so [`.split`], [`.splitn`], [`.chunks`], [`.windows`] in druge.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Veliko uporab v tem modulu se uporablja samo v testni konfiguraciji.
// Čistejše je, če samo izklopite opozorilo unused_imports, kot da jih popravite.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Osnovne metode razširitve rezine
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) potreben za izvajanje makra `vec!` med testiranjem NB, za več podrobnosti glejte modul `hack` v tej datoteki.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) potreben za izvajanje `Vec::clone` med testiranjem NB, za več podrobnosti glejte modul `hack` v tej datoteki.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Ker cfg(test) `impl [T]` ni na voljo, so te tri funkcije dejansko metode, ki so v `impl [T]`, ne pa tudi v `core::slice::SliceExt`, zato moramo te funkcije zagotoviti za test `test_permutations`
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Temu ne bi smeli dodajati vrstnega atributa, ker se ta večinoma uporablja v makro `vec!` in povzroča regresijo perf.
    // Glejte #71204 za razprave in rezultate.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // elementi so bili označeni kot inicializirani v spodnji zanki
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) je potreben, da LLVM odstrani preverjanja mej in ima boljši koden kot zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // vec je bil dodeljen in inicializiran zgoraj vsaj do te dolžine.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // dodeljena zgoraj s kapaciteto `s` in inicializirana na `s.len()` v spodnjem ptr::copy_to_non_overlapping.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Razvrsti rezino.
    ///
    /// Ta vrsta je stabilna (tj. Ne preureja enakih elementov) in *O*(*n*\*log(* n*)) v najslabšem primeru.
    ///
    /// Kadar je primerno, je prednostno nestabilno razvrščanje, ker je na splošno hitrejše od stabilnega razvrščanja in ne dodeli pomožnega pomnilnika.
    /// Glejte [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Trenutna izvedba
    ///
    /// Trenutni algoritem je prilagodljivo, iterativno združevanje, ki ga je navdihnil [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Zasnovan je tako, da je zelo hiter v primerih, ko je rezina skoraj razvrščena ali je sestavljena iz dveh ali več razvrščenih zaporedij, povezanih eno za drugo.
    ///
    ///
    /// Prav tako dodeli začasno shrambo, ki je polovica velikosti `self`, vendar se za kratke rezine namesto tega uporabi nerazporejevalna vrsta vstavljanja.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Rezino razvrsti s primerjalno funkcijo.
    ///
    /// Ta vrsta je stabilna (tj. Ne preureja enakih elementov) in *O*(*n*\*log(* n*)) v najslabšem primeru.
    ///
    /// Funkcija primerjave mora določiti skupno urejanje elementov v rezini.Če razvrščanje ni skupno, vrstni red elementov ni določen.
    /// Naročilo je skupno naročilo, če je (za vse `a`, `b` in `c`):
    ///
    /// * skupaj in antisimetrično: točno ena od `a < b`, `a == b` ali `a > b` je resnična in
    /// * prehodni, `a < b` in `b < c` pomeni `a < c`.Enako mora veljati za `==` in `>`.
    ///
    /// Na primer, medtem ko [`f64`] ne izvaja [`Ord`], ker `NaN != NaN`, lahko `partial_cmp` uporabimo kot funkcijo razvrščanja, če vemo, da rezina ne vsebuje `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Kadar je primerno, je prednostno nestabilno razvrščanje, ker je na splošno hitrejše od stabilnega razvrščanja in ne dodeli pomožnega pomnilnika.
    /// Glejte [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Trenutna izvedba
    ///
    /// Trenutni algoritem je prilagodljivo, iterativno združevanje, ki ga je navdihnil [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Zasnovan je tako, da je zelo hiter v primerih, ko je rezina skoraj razvrščena ali je sestavljena iz dveh ali več razvrščenih zaporedij, povezanih eno za drugo.
    ///
    /// Prav tako dodeli začasno shrambo, ki je polovica velikosti `self`, vendar se za kratke rezine namesto tega uporabi nerazporejevalna vrsta vstavljanja.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // obratno sortiranje
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Rezino razvrsti s funkcijo ekstrakcije ključa.
    ///
    /// Ta vrsta je stabilna (tj. Ne preureja enakih elementov) in *O*(*m*\* * n *\* log(*n*)) najslabši primer, kjer je ključna funkcija *O*(*m*).
    ///
    /// Za drage funkcije tipk (npr
    /// funkcije, ki niso preprosti dostopi do lastnosti ali osnovne operacije), bo [`sort_by_cached_key`](slice::sort_by_cached_key) verjetno bistveno hitrejši, saj ne preračuna ključev elementov.
    ///
    ///
    /// Kadar je primerno, je prednostno nestabilno razvrščanje, ker je na splošno hitrejše od stabilnega razvrščanja in ne dodeli pomožnega pomnilnika.
    /// Glejte [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Trenutna izvedba
    ///
    /// Trenutni algoritem je prilagodljivo, iterativno združevanje, ki ga je navdihnil [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Zasnovan je tako, da je zelo hiter v primerih, ko je rezina skoraj razvrščena ali je sestavljena iz dveh ali več razvrščenih zaporedij, povezanih eno za drugo.
    ///
    /// Prav tako dodeli začasno shrambo, ki je polovica velikosti `self`, vendar se za kratke rezine namesto tega uporabi nerazporejevalna vrsta vstavljanja.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Rezino razvrsti s funkcijo ekstrakcije ključa.
    ///
    /// Med razvrščanjem se funkcija ključa pokliče samo enkrat na element.
    ///
    /// Ta vrsta je stabilna (tj. Ne preureja enakih elementov) in *O*(*m*\* * n *+* n *\* log(*n*)) v najslabšem primeru, kjer je ključna funkcija *O*(*m*) .
    ///
    /// Za preproste funkcije ključev (npr. Funkcije, ki so dostopi do lastnosti ali osnovne operacije) bo [`sort_by_key`](slice::sort_by_key) verjetno hitrejši.
    ///
    /// # Trenutna izvedba
    ///
    /// Trenutni algoritem temelji na [pattern-defeating quicksort][pdqsort], ki ga je izdelal Orson Peters, ki združuje hitri povprečni primer randomiziranega hitrega sortiranja s hitro najslabšim primerom težke sorte, hkrati pa doseže linearni čas na rezinah z določenimi vzorci.
    /// Za izogibanje degeneriranim primerom uporablja nekaj naključnih naključkov, vendar s fiksnim seed vedno zagotavlja deterministično vedenje.
    ///
    /// V najslabšem primeru algoritem dodeli začasno shrambo v dolžini rezine `Vec<(K, usize)>`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Makro pomočnik za indeksiranje našega vector z najmanjšo možno vrsto, da se zmanjša dodelitev.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Elementi `indices` so edinstveni, saj so indeksirani, zato bo katera koli vrsta stabilna glede na prvotno rezino.
                // Tu uporabljamo `sort_unstable`, ker zahteva manj dodeljevanja pomnilnika.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Kopira `self` v novega `Vec`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Tu lahko `s` in `x` spremenite samostojno.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Kopira `self` v nov `Vec` z razdelilnikom.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Tu lahko `s` in `x` spremenite samostojno.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // Opomba: za več podrobnosti glejte modul `hack` v tej datoteki.
        hack::to_vec(self, alloc)
    }

    /// Pretvori `self` v vector brez klonov ali dodelitve.
    ///
    /// Nastali vector lahko pretvorite nazaj v polje prek `Vec<T>"je metoda `into_boxed_slice`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` ni več mogoče uporabiti, ker je bil pretvorjen v `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // Opomba: za več podrobnosti glejte modul `hack` v tej datoteki.
        hack::into_vec(self)
    }

    /// Ustvari vector s ponovitvijo rezine `n` krat.
    ///
    /// # Panics
    ///
    /// Ta funkcija bo panic, če bi se zmogljivost presegla.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// panic ob prelivu:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Če je `n` večji od nič, ga lahko razdelimo kot `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` je število, ki ga predstavlja skrajni levi bit '1' `n`, `rem` pa preostali del `n`.
        //
        //

        // Uporaba `Vec` za dostop do `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` ponovitev se izvede tako, da se `buf`-krat "expn" podvoji.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Če je `m > 0`, so preostali bitji do skrajno levega '1'.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` ima zmogljivost `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) ponovitev se izvede s kopiranjem prvih ponovitev `rem` iz samega `buf`.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // To se ne prekriva od `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` enako `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Rezino `T` poravna v eno vrednost `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Rezino `T` poravna v eno vrednost `Self::Output`, tako da med vsako postavi dani ločilo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Rezino `T` poravna v eno vrednost `Self::Output`, tako da med vsako postavi dani ločilo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Vrne vector, ki vsebuje kopijo te rezine, kjer je vsak bajt preslikan v svoj ekvivalent velike črke ASCII.
    ///
    ///
    /// Črke ASCII 'a' do 'z' so preslikane v 'A' do 'Z', črke, ki niso ASCII, pa nespremenjene.
    ///
    /// Če želite, da je vrednost na mestu velika, uporabite [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Vrne vector, ki vsebuje kopijo te rezine, kjer se vsak bajt preslika v svoj ekvivalent male črke ASCII.
    ///
    ///
    /// Črke ASCII 'A' do 'Z' so preslikane v 'a' do 'z', črke, ki niso ASCII, pa nespremenjene.
    ///
    /// Če želite, da je vrednost na mestu majhna, uporabite [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Razširitev traits za rezine nad določenimi vrstami podatkov
////////////////////////////////////////////////////////////////////////////////

/// Pomočnik Portrait za [`[T]: : concat`](rezina::concat).
///
/// Note: parameter tipa `Item` v tem Portrait ni uporabljen, vendar omogoča, da so implici bolj splošni.
/// Brez tega dobimo to napako:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// To pa zato, ker bi lahko obstajali tipi `V` z več impulzi `Borrow<[_]>`, tako da bi veljalo več tipov `T`:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Nastali tip po združitvi
    type Output;

    /// Izvedba [`[T]: : concat`](rezina::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Pomočnik Portrait za [`[T]: : join`](rezina::pridruži se)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Nastali tip po združitvi
    type Output;

    /// Izvedba [`[T]: : join`](rezina::pridružitev)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Standardne izvedbe Portrait za rezine
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // spustite v tarčo vse, kar ne bo prepisano
        target.truncate(self.len());

        // target.len <= self.len zaradi zgornjega odseka, zato so rezine tukaj vedno znotraj meja.
        //
        let (init, tail) = self.split_at(target.len());

        // ponovno uporabiti vsebovane vrednosti allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Vstavi `v[0]` v predhodno razvrščeno zaporedje `v[1..]`, tako da postane razvrščen celoten `v[..]`.
///
/// To je integralna podprogram vstavljanja.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Tu lahko vstavimo tri načine:
            //
            // 1. Zamenjajte sosednje elemente, dokler prvi ne pride do končnega cilja.
            //    Vendar na ta način kopiramo podatke okoli več, kot je potrebno.
            //    Če so elementi velike strukture (drage za kopiranje), bo ta metoda počasna.
            //
            // 2. Ponavljajte, dokler ne najdete pravega mesta za prvi element.
            // Nato premaknite elemente, ki mu sledijo, da mu naredite prostor in ga na koncu postavite v preostalo luknjo.
            // To je dobra metoda.
            //
            // 3. Kopirajte prvi element v začasno spremenljivko.Ponavljajte, dokler ne najdete pravega mesta za to.
            // Ko gremo naprej, kopirajte vsak prečkani element v režo pred njim.
            // Na koncu kopirajte podatke iz začasne spremenljivke v preostalo luknjo.
            // Ta metoda je zelo dobra.
            // Merila uspešnosti so pokazala nekoliko boljšo učinkovitost kot pri 2. metodi.
            //
            // Vse metode so bile primerjalne in tretja je pokazala najboljše rezultate.Tako smo izbrali tisto.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Vmesno stanje postopka vstavljanja vedno spremlja `hole`, ki ima dva namena:
            // 1. Ščiti integriteto `v` pred panics v `is_less`.
            // 2. Na koncu zapolni preostalo luknjo v `v`.
            //
            // Panic varnost:
            //
            // Če `is_less` panics na kateri koli točki med postopkom, `hole` pade in zapolni luknjo v `v` z `tmp`, s čimer se zagotovi, da `v` še vedno hrani vsak predmet, ki ga je sprva imel natanko enkrat.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` spusti in tako kopira `tmp` v preostalo luknjo v `v`.
        }
    }

    // Ko ga spustite, kopirate iz `src` v `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Združi nenapadajoči zagon `v[..mid]` in `v[mid..]` z uporabo `buf` kot začasnega pomnilnika in rezultat shrani v `v[..]`.
///
/// # Safety
///
/// Obe rezini ne smeta biti prazni, `mid` pa mora biti v mejah.
/// Vmesnik `buf` mora biti dovolj dolg, da ima kopijo krajše rezine.
/// Poleg tega `T` ne sme biti nič velikega tipa.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Postopek spajanja najprej kopira krajši zagon v `buf`.
    // Nato sledi novo kopiranemu teku in daljšemu teku naprej (ali nazaj), primerja njihove naslednje neuporabljene elemente in kopira manjšega (ali večjega) v `v`.
    //
    // Takoj ko je krajši tek v celoti porabljen, je postopek končan.Če se najprej porabi daljši tek, moramo v preostalo luknjo v `v` kopirati vse, kar je ostalo od krajšega poteka.
    //
    // Vmesno stanje procesa vedno spremlja `hole`, ki ima dva namena:
    // 1. Ščiti integriteto `v` pred panics v `is_less`.
    // 2. Zapolni preostalo luknjo v `v`, če se najprej porabi daljši tek.
    //
    // Panic varnost:
    //
    // Če se `is_less` panics kadar koli med postopkom, `hole` spusti in zapolni luknjo v `v` z nepotrošenim obsegom v `buf`, s čimer se zagotovi, da `v` še vedno hrani vsak predmet, ki ga je sprva imel natančno enkrat.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Levi tek je krajši.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Sprva ti kazalci kažejo na začetke njihovih nizov.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Porabite manjšo stran.
            // Če je enaka, raje levo, da ohranite stabilnost.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Pravi tek je krajši.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Sprva ti kazalci kažejo mimo koncev njihovih nizov.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Porabi večjo stran.
            // Če je enak, raje držite pravi tek, da ohranite stabilnost.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Končno `hole` pade.
    // Če krajši zagon ni bil porabljen v celoti, bo vse, kar ostane, zdaj kopirano v luknjo v `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Ob padcu kopira obseg `start..end` v `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` ni nič velik tip, zato je prav, da ga delite po njegovi velikosti.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Ta vrsta združevanja si sposodi nekaj (vendar ne vseh) idej TimSorta, ki je podrobno opisan v [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// Algoritem identificira strogo padajoče in ne padajoče podsekvence, ki jih imenujemo naravni teki.Obstaja kup čakajočih tekov, ki jih še ni treba združiti.
/// Vsak na novo najden potek se potisne na sklad, nato pa se nekaj parov sosednjih tekov združi, dokler se ti dve invarianti ne zadovoljita:
///
/// 1. za vsak `i` v `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. za vsak `i` v `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Invariante zagotavljajo, da je skupni čas delovanja *O*(*n*\*log(* n*)) v najslabšem primeru.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Rezine do te dolžine se razvrstijo z vstavljanjem.
    const MAX_INSERTION: usize = 20;
    // Zelo kratki teki se razširijo z razvrstitvijo vstavljanja, da zajemajo vsaj toliko elementov.
    const MIN_RUN: usize = 10;

    // Razvrščanje nima smiselnega vedenja pri tipih velikosti nič.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Kratki nizi se razvrstijo po mestu z razvrščanjem vstavljanja, da se prepreči dodelitev.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Dodelite medpomnilnik za uporabo kot prazni pomnilnik.Obdržimo dolžino 0, tako da lahko v njej shranimo plitke kopije vsebine `v`, ne da bi tvegali, da dtors tečejo na kopijah, če `is_less` panics.
    //
    // Pri združevanju dveh razvrščenih tekov ima ta vmesni pomnilnik kopijo krajšega poteka, ki bo vedno imel največ `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Da bi prepoznali naravne vožnje v `v`, ga prehodimo nazaj.
    // To se morda zdi čudna odločitev, vendar upoštevajte dejstvo, da se združevanja pogosteje odvijajo v nasprotni smeri (forwards).
    // Glede na merila uspešnosti je združevanje naprej nekoliko hitrejše kot združevanje nazaj.
    // Na koncu ugotovimo, da prepoznavanje tekov s premikanjem nazaj izboljša zmogljivost.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Poiščite naslednji naravni tek in ga obrnite, če se strogo spušča.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Če je prekratek, vstavite še nekaj elementov.
        // Razvrstitev pri vstavljanju je hitrejša od razvrščanja pri spajanju na kratkih zaporedjih, zato to bistveno izboljša zmogljivost.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Potisnite ta tek na sklad.
        runs.push(Run { start, len: end - start });
        end = start;

        // Združite nekaj parov sosednjih voženj, da zadovoljite invariante.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Na koncu mora v kupu ostati natančno en tek.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Preuči sklad tekov in prepozna naslednji par tekov, ki se združijo.
    // Natančneje, če vrnete `Some(r)`, to pomeni, da morate naslednji združiti `runs[r]` in `runs[r + 1]`.
    // Če bi algoritem namesto tega nadaljeval z izdelavo novega teka, se vrne `None`.
    //
    // TimSort je razvpit zaradi svojih izvedb hroščev, kot je opisano tukaj:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Bistvo zgodbe je: vsiliti moramo invariantke na štirih najboljših potezih sklada.
    // Izvrševanje le na prvih treh ni dovolj, da bi zagotovili, da bodo invariante še vedno držale za vse * teke v kupu.
    //
    // Ta funkcija pravilno preveri invarijante za štiri najboljše teke.
    // Poleg tega, če se zgornji zagon začne pri indeksu 0, bo vedno zahteval operacijo spajanja, dokler se sklad popolnoma ne zruši, da se dokonča razvrščanje.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}