#![stable(feature = "rust1", since = "1.0.0")]

//! Kazalci za štetje referenc, varni za nit.
//!
//! Za več podrobnosti glejte dokumentacijo [`Arc<T>`][Arc].

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Mehka omejitev števila sklicev na `Arc`.
///
/// Če presežete to omejitev, bo vaš program (čeprav ne nujno) prekinjen pri referencah _exactly_ `MAX_REFCOUNT + 1`.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer ne podpira spominskih ograj.
// Da bi se izognili lažno pozitivnim poročilom pri izvajanju Arc/Weak, za sinhronizacijo uporabite atomske obremenitve.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Kazalec za štetje referenc, ki je varen za nit.'Arc' pomeni "Atomsko referenčno štetje".
///
/// Tip `Arc<T>` zagotavlja deljeno lastništvo vrednosti tipa `T`, dodeljene v kopici.Poklic [`clone`][clone] na `Arc` ustvari nov primerek `Arc`, ki kaže na isto dodelitev na kopici kot izvor `Arc`, hkrati pa poveča število referenc.
/// Ko je zadnji kazalnik `Arc` na dano dodelitev uničen, se izbriše tudi vrednost, shranjena v tej dodelitvi (pogosto imenovana "inner value").
///
/// Sklici v skupni rabi v Rust privzeto onemogočajo mutacijo in `Arc` ni nobena izjema: na splošno ne morete dobiti spremenljivega sklica na nekaj znotraj `Arc`.Če morate mutirati prek `Arc`, uporabite [`Mutex`][mutex], [`RwLock`][rwlock] ali eno od vrst [`Atomic`][atomic].
///
/// ## Varnost niti
///
/// Za razliko od [`Rc<T>`], `Arc<T>` za štetje referenc uporablja atomske operacije.To pomeni, da je varno pred nitmi.Pomanjkljivost je, da so atomske operacije dražje od običajnih dostopov do pomnilnika.Če ne delite dodeljenih referenčnih števil med nitmi, razmislite o uporabi [`Rc<T>`] za nižje režijske stroške.
/// [`Rc<T>`] je varna privzeta nastavitev, ker bo prevajalnik ujel vsak poskus pošiljanja [`Rc<T>`] med niti.
/// Knjižnica pa lahko izbere `Arc<T>`, da bi potrošnikom knjižnice zagotovila večjo prilagodljivost.
///
/// `Arc<T>` bo implementiral [`Send`] in [`Sync`], dokler `T` izvaja [`Send`] in [`Sync`].
/// Zakaj v `Arc<T>` ne morete namestiti tipa `T`, ki ni varen za nit?To je morda sprva nekoliko protiintuitivno: navsezadnje ni bistvo varnosti niti `Arc<T>`?Ključno je to: `Arc<T>` omogoča, da je večkratno lastništvo istih podatkov večkratno varno, vendar svojim podatkom ne doda varnosti niti.
///
/// Razmislite o "Arc <" [`RefCell<T>`]`>`.
/// [`RefCell<T>`] ni [`Sync`] in če je bil `Arc<T>` vedno [`Send`], `Arc <` [`RefCell<T>`]`>`bi bilo prav tako.
/// Potem pa bi imeli težavo:
/// [`RefCell<T>`] ni varen za nit;beleži število izposojanja z neatomskimi operacijami.
///
/// Na koncu to pomeni, da boste morda morali `Arc<T>` seznaniti z nekakšno vrsto [`std::sync`], običajno [`Mutex<T>`][mutex].
///
/// ## Prekinitev ciklov z `Weak`
///
/// Metodo [`downgrade`][downgrade] lahko uporabimo za ustvarjanje lastniškega kazalca [`Weak`].Kazalec [`Weak`] lahko ["nadgradite"][nadgradite] d na `Arc`, vendar bo to vrnilo [`None`], če je vrednost, shranjena v dodelitvi, že izpuščena.
/// Z drugimi besedami, kazalci `Weak` ne ohranjajo vrednosti znotraj dodelitve žive;kljub temu pa * ohranijo dodeljevanje (hranilnik vrednosti) živo.
///
/// Cikla med kazalci `Arc` ne bo nikoli odstranjenega.
/// Iz tega razloga se [`Weak`] uporablja za prekinitev ciklov.Na primer, drevo bi lahko imelo močne kazalce `Arc` od nadrejenih vozlišč do otrok, [`Weak`] pa od otrok nazaj na njihove starše.
///
/// # Kloniranje referenc
///
/// Ustvarjanje nove reference iz obstoječega kazalca, ki šteje referenco, se izvede z uporabo `Clone` Portrait, ki je implementiran za [`Arc<T>`][Arc] in [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Spodaj navedeni skladnji sta enakovredni.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b in foo so vsi loka, ki kažejo na isto lokacijo pomnilnika
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` samodejno preusmerja na `T` (prek [`Deref`][deref] Portrait), tako da lahko pri vrednosti tipa `Arc<T>` pokličete metode T.Da bi se izognili spopadom imen z metodami T, so metode samega `Arc<T>` povezane funkcije, imenovane z uporabo [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>Izvedbe traits, kot je `Clone`, lahko pokličete tudi z uporabo popolnoma kvalificirane sintakse.
/// Nekateri raje uporabljajo popolnoma kvalificirano sintakso, drugi pa raje sintakso za klic metode.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Sintaksa klica metode
/// let arc2 = arc.clone();
/// // Popolnoma skladna skladnja
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] ne samodejno preusmeri na `T`, ker je notranja vrednost morda že padla.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Skupna raba nekaterih nespremenljivih podatkov med nitmi:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Upoštevajte, da tukaj **ne izvajamo** teh preskusov.
// Ustvarjalci windows postanejo zelo nezadovoljni, če nit preživi glavno nit in nato istočasno izstopi (nekaj je zastojev), zato se temu povsem izognemo, ker ne izvajamo teh testov.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Skupna raba spremenljivega [`AtomicUsize`]:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Za več primerov štetja referenc na splošno glejte [`rc` documentation][rc_examples].
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` je različica [`Arc`], ki vsebuje lastniški sklic na upravljano dodelitev.
/// Do dodelitve je mogoče dostopati tako, da na kazalcu `Weak` pokličete [`upgrade`], ki vrne [`Option`]`<`[`Arc`] `<T>>`.
///
/// Ker sklic `Weak` ne šteje za lastništvo, ne bo preprečil, da bi vrednost, shranjena v dodelitvi, padla, sam `Weak` pa ne jamči, da je vrednost še vedno prisotna.
///
/// Tako lahko vrne [`None`], ko [`nadgradnja`] d.
/// Upoštevajte pa, da referenca `Weak`*ne* preprečuje sprostitve same dodelitve (shrambe).
///
/// Kazalec `Weak` je uporaben za začasno sklicevanje na dodelitev, ki jo upravlja [`Arc`], ne da bi pri tem preprečil izpuščanje njegove notranje vrednosti.
/// Uporablja se tudi za preprečevanje krožnih referenc med kazalci [`Arc`], saj medsebojne reference lastništva ne bi nikoli omogočile, da bi [`Arc`] izpustil.
/// Na primer, drevo bi lahko imelo močne kazalce [`Arc`] od starševskih vozlišč do otrok in kazalce `Weak` od otrok nazaj na njihove starše.
///
/// Tipičen način za pridobitev kazalca `Weak` je klic [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // To je `NonNull`, ki omogoča optimizacijo velikosti te vrste v enumih, ni pa nujno veljaven kazalec.
    //
    // `Weak::new` nastavi na `usize::MAX`, tako da mu ni treba dodeliti prostora na kupu.
    // To ni vrednost, ki jo bo imel pravi kazalec, ker ima RcBox poravnavo vsaj 2.
    // To je mogoče le, če `T: Sized`;velikost `T` nikoli ne visi.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// To je odpornost repr(C) do future proti morebitnemu preurejanju polja, ki bi vplivalo na sicer varen [into|from]_raw() pretvorljivih notranjih tipov.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // vrednost usize::MAX deluje kot stražar za začasno "locking" sposobnost nadgradnje šibkih kazalcev ali znižanje močnih;to se uporablja za izogibanje dirkam v `make_mut` in `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Konstruira nov `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Začnite štetje šibkega kazalca kot 1, ki je šibki kazalec, ki ga imajo vsi močni kazalci (kinda), za več informacij glejte std/rc.rs
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Konstruira nov `Arc<T>` z uporabo šibkega sklicevanja na samega sebe.
    /// Poskus nadgradnje šibkega sklica, preden se ta funkcija vrne, bo imel za posledico vrednost `None`.
    /// Šibko referenco pa lahko prosto kloniramo in shranimo za poznejšo uporabo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Zgradite notranjost v stanju "uninitialized" z eno šibko referenco.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Pomembno je, da se ne odrekamo lastništvu šibkega kazalca, sicer se spomin sprosti do vrnitve `data_fn`.
        // Če bi res želeli prenesti lastništvo, bi lahko ustvarili dodaten šibki kazalec zase, vendar bi to povzročilo dodatne posodobitve števila šibkih referenc, ki sicer ne bi bile potrebne.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Zdaj lahko pravilno inicializiramo notranjo vrednost in svojo šibko referenco spremenimo v močno referenco.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Zgornji zapis v podatkovno polje mora biti viden vsem nitkam, ki opazijo močno ničelno število.
            // Zato potrebujemo vsaj "Release" naročanje, da se sinhroniziramo z `compare_exchange_weak` v `Weak::upgrade`.
            //
            // "Acquire" naročanje ni potrebno.
            // Ko razmišljamo o možnem vedenju `data_fn`, moramo samo pogledati, kaj bi lahko naredil s sklicevanjem na nenadgradljivi `Weak`:
            //
            // - Lahko *klonira*`Weak` in poveča število šibkih referenc.
            // - Te klone lahko spusti in zmanjša število šibkih referenc (vendar nikoli na nič).
            //
            // Ti neželeni učinki na nas nikakor ne vplivajo in nobeni drugi neželeni učinki niso možni samo z varno kodo.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Močne reference bi morale imeti skupno deljeno šibko referenco, zato ne zaženite destruktorja za našo staro šibko referenco.
        //
        mem::forget(weak);
        strong
    }

    /// Konstruira nov `Arc` z neinicializirano vsebino.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Odložena inicializacija:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstruira nov `Arc` z neinicializirano vsebino, pri čemer je pomnilnik napolnjen z bajti `0`.
    ///
    ///
    /// Za primere pravilne in nepravilne uporabe te metode glejte [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstruira nov `Pin<Arc<T>>`.
    /// Če `T` ne izvaja `Unpin`, bo `data` pripet v pomnilnik in ga ne bo mogoče premakniti.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Konstruira nov `Arc<T>` in vrne napako, če dodelitev ne uspe.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Začnite štetje šibkega kazalca kot 1, ki je šibki kazalec, ki ga imajo vsi močni kazalci (kinda), za več informacij glejte std/rc.rs
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Konstruira nov `Arc` z neinicializirano vsebino in vrne napako, če dodelitev ne uspe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Odložena inicializacija:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Konstruira nov `Arc` z neinicializirano vsebino, pri čemer je pomnilnik napolnjen z bajti `0` in vrne napako, če dodelitev ne uspe.
    ///
    ///
    /// Za primere pravilne in nepravilne uporabe te metode glejte [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Vrne notranjo vrednost, če ima `Arc` točno eno močno referenco.
    ///
    /// V nasprotnem primeru se vrne [`Err`] z istim `Arc`, ki je bil poslan.
    ///
    ///
    /// To bo uspelo, tudi če obstajajo izjemne šibke reference.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Naredite šibek kazalec, da počistite implicitno močno-šibko referenco
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Konstruira novo rezano atomsko šteto referenco z neinicializirano vsebino.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Odložena inicializacija:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Konstruira novo rezano atomsko šteto referenco z neinicializirano vsebino, pri čemer je pomnilnik napolnjen z bajti `0`.
    ///
    ///
    /// Za primere pravilne in nepravilne uporabe te metode glejte [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Pretvori v `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Tako kot pri [`MaybeUninit::assume_init`] mora tudi klicatelj zagotoviti, da je notranja vrednost res v inicializiranem stanju.
    ///
    /// Če pokličete to, ko vsebina še ni popolnoma inicializirana, povzroči takojšnje nedefinirano vedenje.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Odložena inicializacija:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Pretvori v `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Tako kot pri [`MaybeUninit::assume_init`] mora tudi klicatelj zagotoviti, da je notranja vrednost res v inicializiranem stanju.
    ///
    /// Če pokličete to, ko vsebina še ni popolnoma inicializirana, povzroči takojšnje nedefinirano vedenje.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Odložena inicializacija:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Porabi `Arc` in vrne oviti kazalec.
    ///
    /// Da bi se izognili puščanju pomnilnika, je treba kazalec z [`Arc::from_raw`] pretvoriti nazaj v `Arc`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Ponuja neobdelan kazalec na podatke.
    ///
    /// Na štetje to nikakor ne vpliva in `Arc` se ne porabi.
    /// Kazalec je veljaven, dokler je v `Arc` močno štetje.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // VARNOST: To ne more iti skozi Deref::deref ali RcBoxPtr::inner, ker
        // to je potrebno, da se ohrani izvor raw/mut tako, da npr
        // `get_mut` lahko piše skozi kazalec, ko je Rc obnovljen prek `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Konstruira `Arc<T>` iz surovega kazalca.
    ///
    /// Neobdelani kazalec mora biti predhodno vrnjen s klicem na [`Arc<U>::into_raw`][into_raw], kjer mora imeti `U` enako velikost in poravnavo kot `T`.
    /// To je nepomembno, če je `U` `T`.
    /// Upoštevajte, da če `U` ni `T`, vendar ima enako velikost in poravnavo, je to v bistvu podobno pretvarjanju referenc različnih vrst.
    /// Za več informacij o omejitvah, ki veljajo v tem primeru, glejte [`mem::transmute`][transmute].
    ///
    /// Uporabnik `from_raw` mora zagotoviti, da določena vrednost `T` pade le enkrat.
    ///
    /// Ta funkcija ni varna, ker lahko nepravilna uporaba vodi do nevarnosti pomnilnika, tudi če do vrnjenega `Arc<T>` nikoli ne dostopate.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Pretvorite nazaj v `Arc`, da preprečite puščanje.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Nadaljnji klici na `Arc::from_raw(x_ptr)` bi bili varni za pomnilnik.
    /// }
    ///
    /// // Spomin se je sprostil, ko je `x` izstopil zgoraj, zato `x_ptr` zdaj visi!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Če želite najti izvirni ArcInner, obrnite odmik.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Ustvari nov kazalec [`Weak`] na to dodelitev.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // To sproščeno je v redu, ker preverjamo vrednost v spodnjem CAS-ju.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // preverite, ali je šibki števec trenutno "locked";če je tako, zavrti.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: ta koda trenutno ne upošteva možnosti prelivanja
            // v usize::MAX;na splošno je treba Rc in Arc prilagoditi, da se spopademo s prelivanjem.
            //

            // Za razliko od Clone() potrebujemo to branje Acquire za sinhronizacijo s pisanjem iz `is_unique`, tako da se dogodki pred tem zapisom zgodijo pred tem branjem.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Prepričajte se, da ne ustvarjamo visečega šibkega
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Pridobi število kazalcev [`Weak`] na to dodelitev.
    ///
    /// # Safety
    ///
    /// Ta metoda je že sama po sebi varna, vendar z njeno pravilno uporabo je potrebna posebna skrb.
    /// Druga nit lahko kadar koli spremeni šibko število, tudi med klicanjem te metode in vplivanjem na rezultat.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Ta trditev je deterministična, ker `Arc` ali `Weak` nismo delili med niti.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Če je šibko število trenutno zaklenjeno, je bila vrednost štetja 0 tik pred zaklepanjem.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Pridobi število močnih kazalcev (`Arc`) na to dodelitev.
    ///
    /// # Safety
    ///
    /// Ta metoda je že sama po sebi varna, vendar z njeno pravilno uporabo je potrebna posebna skrb.
    /// Druga nit lahko kadar koli spremeni močno štetje, tudi med klicanjem te metode in vplivanjem na rezultat.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Ta trditev je deterministična, ker `Arc` nismo delili med nitmi.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Število močnih referenc poveča na `Arc<T>`, povezano s podanim kazalcem, za eno.
    ///
    /// # Safety
    ///
    /// Kazalec mora biti pridobljen s pomočjo `Arc::into_raw` in povezan primerek `Arc` mora biti veljaven (tj
    /// močno število mora biti najmanj 1) med trajanjem te metode.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Ta trditev je deterministična, ker `Arc` nismo delili med nitmi.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Zadržite Arc, vendar se ne dotikajte ponovnega štetja, tako da zavijete v ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Zdaj povečajte ponovno štetje, vendar ne spustite niti novega
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Število močnih referenc na `Arc<T>`, povezanem s podanim kazalcem, zmanjša za eno.
    ///
    /// # Safety
    ///
    /// Kazalec mora biti pridobljen s pomočjo `Arc::into_raw` in povezan primerek `Arc` mora biti veljaven (tj
    /// pri uporabi te metode mora biti močno število najmanj 1).
    /// Ta metoda se lahko uporablja za sprostitev končnega `Arc` in podpornega pomnilnika, vendar **ne sme biti** poklicana po sprostitvi končnega `Arc`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Te trditve so deterministične, ker `Arc` nismo delili med nitmi.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Ta nevarnost je v redu, ker ko je ta lok živ, smo prepričani, da je notranji kazalec veljaven.
        // Poleg tega vemo, da je sama struktura `ArcInner` `Sync`, ker so tudi notranji podatki `Sync`, zato smo v redu, če smo posodili nespremenljiv kazalec na to vsebino.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Nevstavljen del `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Trenutno uničite podatke, čeprav morda ne bomo sprostili same dodelitve škatle (morda še vedno ležijo šibki kazalci).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Odvrzite šibkega referenca, ki ga imajo vse močne reference
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Vrne `true`, če oba "Arc" kažeta na isto dodelitev (v veni, podobni [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Dodeljuje `ArcInner<T>` z dovolj prostora za morebitno velikost notranje vrednosti, če ima vrednost predvideno postavitev.
    ///
    /// Funkcija `mem_to_arcinner` se pokliče s kazalcem podatkov in mora vrniti (potencialno maščobni) kazalec za `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Postavitev izračunajte z uporabo postavitve vrednosti.
        // Prej je bila postavitev izračunana na izrazu `&*(ptr as* const ArcInner<T>)`, vendar je to ustvarilo napačno poravnano referenco (glej #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Dodeljuje `ArcInner<T>` z dovolj prostora za morebitno velikost notranje vrednosti, kjer ima vrednost predvideno postavitev, in vrne napako, če dodelitev ne uspe.
    ///
    ///
    /// Funkcija `mem_to_arcinner` se pokliče s kazalcem podatkov in mora vrniti (potencialno maščobni) kazalec za `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Postavitev izračunajte z uporabo postavitve vrednosti.
        // Prej je bila postavitev izračunana na izrazu `&*(ptr as* const ArcInner<T>)`, vendar je to ustvarilo napačno poravnano referenco (glej #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Inicializirajte ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Dodeljuje `ArcInner<T>` z dovolj prostora za velikost notranje vrednosti.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Dodelite `ArcInner<T>` z dano vrednostjo.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopiraj vrednost v bajtih
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Alokacijo osvobodite, ne da bi spustili vsebino
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Dodeljuje `ArcInner<[T]>` z dano dolžino.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Kopirajte elemente iz rezine v novo dodeljeni lok <\[T\]>
    ///
    /// Nevarno, ker mora klicatelj prevzeti lastništvo ali vezati `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Konstruira `Arc<[T]>` iz iteratorja, za katerega je znano, da je določene velikosti.
    ///
    /// Obnašanje ni določeno, če je velikost napačna.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic ščitnik med kloniranjem T elementov.
        // V primeru panic bodo elementi, ki so bili zapisani v novo ArcInner, odstranjeni, nato pa se bo sprostil pomnilnik.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Kazalec na prvi element
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Vse jasno.Pozabite na stražo, da ne bo sprostila novega ArcInnerja.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specializacija Portrait za `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Naredi klon kazalca `Arc`.
    ///
    /// To ustvari nov kazalec na isto dodelitev, kar poveča močno število referenc.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Uporaba sproščenega razvrščanja je tukaj v redu, saj poznavanje izvirne reference preprečuje, da bi druge niti zmotno izbrisale predmet.
        //
        // Kot je razloženo v [Boost documentation][1], je povečanje referenčnega števca vedno mogoče narediti z memory_order_relaxed: Nove sklice na objekt lahko oblikujemo samo iz obstoječe sklice, posredovanje obstoječe sklice iz ene niti v drugo pa mora že zagotoviti potrebno sinhronizacijo.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Vendar se moramo paziti pred množičnimi ponovnimi štetji, če nekdo spomni Arcs.
        // Če tega ne storimo, lahko število preplavi in uporabniki bodo brezplačno uporabili.
        // Hitro nasičimo do `isize::MAX` ob predpostavki, da ni niti ~2 milijard niti, ki hkrati povečajo referenčno število.
        //
        // Ta branch nikoli ne bo posnet v nobenem realnem programu.
        //
        // Prekinemo, ker je tak program neverjetno izroden in ga ne želimo podpirati.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Naredi spremenljiv sklic na dani `Arc`.
    ///
    /// Če obstajajo drugi kazalci `Arc` ali [`Weak`] na isto dodelitev, potem bo `make_mut` ustvaril novo dodelitev in na notranjo vrednost prikril [`clone`][clone], da zagotovi edinstveno lastništvo.
    /// To se imenuje tudi klon na pisanje.
    ///
    /// Upoštevajte, da se to razlikuje od vedenja [`Rc::make_mut`], ki ločuje preostale kazalce `Weak`.
    ///
    /// Glej tudi [`get_mut`][get_mut], ki ne bo uspel kot kloniral.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Ničesar ne bom kloniral
    /// let mut other_data = Arc::clone(&data); // Ne bo kloniral notranjih podatkov
    /// *Arc::make_mut(&mut data) += 1;         // Klonira notranje podatke
    /// *Arc::make_mut(&mut data) += 1;         // Ničesar ne bom kloniral
    /// *Arc::make_mut(&mut other_data) *= 2;   // Ničesar ne bom kloniral
    ///
    /// // Zdaj `data` in `other_data` kažeta na različna dodeljevanja.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Upoštevajte, da imamo tako močno kot šibko referenco.
        // Tako sprostitev samo naše močne reference sama po sebi ne bo povzročila sprostitve pomnilnika.
        //
        // Uporabite Acquire, da zagotovite, da bomo videli kakršno koli zapisovanje v `weak`, ki se zgodi pred pisanjem izdaje (tj. Zmanjšanja) v `strong`.
        // Ker imamo šibko število, ni možnosti, da bi se ArcInner sam rešil.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Obstaja še en močan kazalec, zato moramo klonirati.
            // Vnaprej dodelite pomnilnik, da omogočite neposredno pisanje klonirane vrednosti.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Zgoraj zadošča sproščeno, ker je to v bistvu optimizacija: vedno dirkamo s padci šibkih kazalcev.
            // Najslabši primer je, da smo na koncu po nepotrebnem dodelili nov Arc.
            //

            // Odstranili smo zadnji močni ref, vendar obstajajo še dodatni šibki ref.
            // Vsebino bomo premaknili v nov Arc in razveljavili druge šibke ocene.
            //

            // Upoštevajte, da branje `weak` ne more dati usize::MAX (tj. Zaklenjeno), saj lahko šibko število zaklene samo nit z močno referenco.
            //
            //

            // Materializirajte svoj implicitni šibki kazalec, da lahko po potrebi očisti ArcInner.
            //
            let _weak = Weak { ptr: this.ptr };

            // Lahko samo ukrade podatke, ostane le Weaks
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Bili smo edina referenca katere koli vrste;naglo dvignite močno število ref.
            //
            this.inner().strong.store(1, Release);
        }

        // Tako kot pri `get_mut()` je tudi tukaj nevarnost v redu, ker je bila naša referenca za začetek edinstvena ali pa je postala takšna pri kloniranju vsebine.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Vrne spremenljivo referenco v dani `Arc`, če ni drugih kazalcev `Arc` ali [`Weak`] na isto dodelitev.
    ///
    ///
    /// Vrne [`None`] v nasprotnem primeru, ker ni varno mutirati vrednosti v skupni rabi.
    ///
    /// Glejte tudi [`make_mut`][make_mut], ki bo [`clone`][clone] določil notranjo vrednost, če obstajajo drugi kazalci.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Ta nevarnost je v redu, ker imamo zagotovljeno, da je vrnjeni kazalec *edini* kazalec, ki bo kdaj vrnjen T.
            // Število referenc je v tem trenutku zajamčeno 1 in zahtevali smo, da je lok `mut`, zato vrnemo edino možno referenco na notranje podatke.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Vrne spremenljivo referenco v dani `Arc` brez preverjanja.
    ///
    /// Glejte tudi [`get_mut`], ki je varen in izvaja ustrezne preglede.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Nobenega drugega kazalca `Arc` ali [`Weak`] na isto dodelitev ne smete spreminjati med trajanjem vrnjenega posojila.
    ///
    /// To je nenavadno, če taki kazalci ne obstajajo, na primer takoj po `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Pazimo, da *ne* ustvarimo reference, ki pokriva polja "count", saj bi to pomenilo vzdevek s sočasnim dostopom do števila referenc (npr.
        // `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Ugotovite, ali je to edinstveno sklicevanje (vključno s šibkimi referencami) na osnovne podatke.
    ///
    ///
    /// Upoštevajte, da je za to treba zakleniti šibko število ref.
    fn is_unique(&mut self) -> bool {
        // zaklepanje števila šibkih kazalcev, če se zdi, da smo edini nosilec šibkega kazalca.
        //
        // Oznaka prevzema tukaj zagotavlja razmerje pred kakršnim koli zapisovanjem v `strong` (zlasti v `Weak::upgrade`) pred zmanjšanjem števila `weak` (prek `Weak::drop`, ki uporablja sprostitev).
        // Če nadgrajeni šibki ref ni bil nikoli izpuščen, CAS tukaj ne bo uspel, zato se ne želimo sinhronizirati.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // To mora biti `Acquire`, da se sinhronizira z zmanjšanjem števca `strong` v `drop`-edini dostop, ki se zgodi, ko izpustite katero koli referenco, razen zadnje.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Zapis o izdaji tukaj se sinhronizira z branjem v `downgrade`, kar učinkovito preprečuje, da bi se po pisanju zgodilo zgornje branje `strong`.
            //
            //
            self.inner().weak.store(1, Release); // spustite ključavnico
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Spusti `Arc`.
    ///
    /// To bo zmanjšalo močno število referenc.
    /// Če močno število referenc doseže nič, so edine druge reference (če obstajajo) [`Weak`], zato `drop` določimo notranjo vrednost.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Ne natisne ničesar
    /// drop(foo2);   // Natisne "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Ker je `fetch_sub` že atomska, nam ni treba sinhronizirati z drugimi nitmi, razen če bomo objekt izbrisali.
        // Ista logika velja za spodnji `fetch_sub` do števila `weak`.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Ta ograja je potrebna, da se prepreči preurejanje uporabe podatkov in brisanje podatkov.
        // Ker ima oznako `Release`, se zmanjšanje števila referenc sinhronizira s to ograjo `Acquire`.
        // To pomeni, da se uporaba podatkov zgodi pred zmanjšanjem števila referenc, kar se zgodi pred to ograjo, kar se zgodi pred brisanjem podatkov.
        //
        // Kot je pojasnjeno v [Boost documentation][1],
        //
        // > Pomembno je uveljaviti morebiten dostop do predmeta v enem
        // > nit (skozi obstoječo referenco), da se *zgodi pred* brisanjem
        // > predmet v drugi niti.To doseže "release"
        // > operacija po spuščanju reference (kakršen koli dostop do predmeta
        // > s tem sklicem se je očitno moralo zgoditi že prej) in
        // > "acquire" pred brisanjem predmeta.
        //
        // Medtem ko je vsebina loka običajno nespremenljiva, je možno, da notranjost piše v nekaj podobnega Mutexu<T>.
        // Ker Mutex ob brisanju ni pridobljen, se ne moremo zanesti na njegovo sinhronizacijsko logiko, da bo zapise v nit A videl destruktor, ki se izvaja v niti B.
        //
        //
        // Upoštevajte tudi, da bi lahko ograjo Acquire tukaj verjetno nadomestili z obremenitvijo Acquire, kar bi lahko izboljšalo zmogljivost v zelo spornih situacijah.Glejte [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Poskus `Arc<dyn Any + Send + Sync>` znižati na konkretno vrsto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Konstruira nov `Weak<T>`, ne da bi dodeljeval pomnilnik.
    /// Poklic [`upgrade`] na vrnjeno vrednost vedno da [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Vrsta pomožnika, ki omogoča dostop do števila sklicev brez navedb o podatkovnem polju.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Vrne neobdelani kazalnik na predmet `T`, na katerega kaže ta `Weak<T>`.
    ///
    /// Kazalec je veljaven le, če obstaja nekaj močnih referenc.
    /// Kazalec je lahko viseč, neuravnan ali v nasprotnem primeru celo [`null`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Oba kažeta na isti predmet
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Močni ga ohranjajo pri življenju, tako da lahko še vedno dostopamo do predmeta.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // A ne več.
    /// // Lahko naredimo weak.as_ptr(), vendar dostop do kazalca vodi do nedefiniranega vedenja.
    /// // assert_eq! ("zdravo", nevarno {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Če kazalec visi, vrnemo stražo neposredno.
            // To ne more biti veljaven naslov koristnega tovora, saj je tovor vsaj tako poravnan kot ArcInner (usize).
            ptr as *const T
        } else {
            // VARNOST: če is_dangling vrne false, potem kazalec ni mogoče referencirati.
            // Na tej točki lahko pade tovor, zato moramo ohraniti izvor, zato uporabite manipulacijo s surovim kazalcem.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Porabi `Weak<T>` in ga spremeni v neobdelan kazalec.
    ///
    /// To pretvori šibki kazalec v neobdelani kazalec, hkrati pa ohrani lastništvo ene šibke reference (šibko število s to operacijo ne spremeni).
    /// Z [`from_raw`] ga je mogoče spremeniti nazaj v `Weak<T>`.
    ///
    /// Veljajo enake omejitve dostopa do cilja kazalca kot pri [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Neobdelani kazalnik, ki ga je prej ustvaril [`into_raw`], pretvori nazaj v `Weak<T>`.
    ///
    /// To lahko uporabite za varno pridobivanje močne reference (s poznejšim klicem [`upgrade`]) ali za sprostitev šibkega števila, tako da spustite `Weak<T>`.
    ///
    /// Prevzame lastništvo ene šibke reference (z izjemo kazalcev, ki jih je ustvaril [`new`], saj ti nimajo ničesar; metoda še vedno deluje na njih).
    ///
    /// # Safety
    ///
    /// Kazalec mora izvirati iz [`into_raw`] in mora imeti še vedno potencialno šibko referenco.
    ///
    /// V času klica je dovoljeno, da je število močnih 0.
    /// Kljub temu se prevzame lastništvo ene šibke reference, ki je trenutno predstavljena kot neobdelani kazalec (šibko število s to operacijo ne spremeni), zato jo je treba seznaniti s prejšnjim klicem na [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Zmanjšaj zadnje šibko število.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Glejte Weak::as_ptr za kontekst o tem, kako je izpeljan vhodni kazalec.

        let ptr = if is_dangling(ptr as *mut T) {
            // To je viseči šibek.
            ptr as *mut ArcInner<T>
        } else {
            // V nasprotnem primeru imamo zajamčeno, da je kazalec prišel iz nezapletenega šibkega.
            // VARNOST: data_offset je varno poklicati, saj se ptr sklicuje na resnično (potencialno izpuščeno) T.
            let offset = unsafe { data_offset(ptr) };
            // Tako obrnemo odmik, da dobimo celoten RcBox.
            // VARNOST: kazalec izvira iz šibkega, zato je ta odmik varen.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // VARNOST: zdaj smo obnovili prvotni šibki kazalec, tako da lahko ustvarimo šibek.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Poskusi nadgradnje kazalca `Weak` na [`Arc`], če uspejo, odložijo spuščanje notranje vrednosti.
    ///
    ///
    /// Vrne [`None`], če je bila notranja vrednost od takrat spuščena.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Uniči vse močne kazalce.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Zanko CAS uporabljamo za povečanje močnega štetja namesto fetch_add, saj ta funkcija referenčnega števila nikoli ne bi smela sprejeti z nič na eno.
        //
        //
        let inner = self.inner()?;

        // Sproščena obremenitev, ker vsak zapis 0, ki ga lahko opazimo, pušča polje v trajno ničelnem stanju (tako da je branje "stale" 0 v redu), druge vrednosti pa potrdimo s spodnjim CAS-jem.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Oglejte si komentarje v `Arc::clone`, zakaj to počnemo (za `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Sproščeno je v primeru okvare v redu, ker glede nove države nimamo nobenih pričakovanj.
            // Pridobitev je nujna za sinhronizacijo primera uspeha z `Arc::new_cyclic`, ko je notranjo vrednost mogoče inicializirati, ko so reference `Weak` že ustvarjene.
            // V tem primeru pričakujemo, da bomo opazili popolnoma inicializirano vrednost.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // ničelno preverjeno zgoraj
                Err(old) => n = old,
            }
        }
    }

    /// Pridobi število močnih kazalcev (`Arc`), ki kažejo na to dodelitev.
    ///
    /// Če je bil `self` ustvarjen z uporabo [`Weak::new`], bo to vrnilo 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Pridobi približno število kazalcev `Weak`, ki kažejo na to dodelitev.
    ///
    /// Če je bil `self` ustvarjen z uporabo [`Weak::new`] ali če ni preostalih močnih kazalcev, bo to vrnilo 0.
    ///
    /// # Accuracy
    ///
    /// Zaradi podrobnosti izvedbe se lahko vrnjena vrednost izklopi za 1 v katero koli smer, kadar druge niti manipulirajo s katerim koli "Arc`s ali"Weak`s, ki kažejo na isto dodelitev.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Ker smo po branju šibkega števila opazili, da je obstajal vsaj en močan kazalec, vemo, da je bila implicitna šibka referenca (prisotna, kadar koli so močne reference živele) še vedno prisotna, ko smo opazovali šibko štetje, in jo zato lahko varno odštejemo.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Vrne `None`, ko kazalec visi in ni dodeljenega `ArcInner` (tj. Ko je `Weak` ustvaril `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Pazimo, da *ne* ustvarimo sklica, ki pokriva polje "data", saj lahko polje istočasno mutira (če na primer izpade zadnji `Arc`, bo podatkovno polje spuščeno na mestu).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Vrne `true`, če dva "šibka" kažeta na isto dodelitev (podobno kot [`ptr::eq`]) ali če oba ne kažeta na nobeno dodelitev (ker sta bili ustvarjeni z `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Ker to primerja kazalce, pomeni, da se bo `Weak::new()` izenačil, čeprav ne kažejo na nobeno dodelitev.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Primerjava `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Naredi klon kazalca `Weak`, ki kaže na isto dodelitev.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Glejte komentarje v Arc::clone(), zakaj je to sproščeno.
        // Pri tem lahko uporabite fetch_add (ignoriranje zaklepanja), ker je šibko število zaklenjeno samo tam, kjer *ni drugih* šibkih kazalcev.
        //
        // (Torej v tem primeru te kode ne moremo izvajati).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Oglejte si komentarje v Arc::clone(), zakaj to počnemo (za mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Konstruira nov `Weak<T>` brez dodeljevanja pomnilnika.
    /// Poklic [`upgrade`] na vrnjeno vrednost vedno da [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Spusti kazalec `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Ne natisne ničesar
    /// drop(foo);        // Natisne "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Če ugotovimo, da smo bili zadnji šibki kazalec, je čas, da v celoti odstranimo podatke.Glejte razpravo v Arc::drop() o naročilih pomnilnika
        //
        // Tu ni treba preveriti zaklenjenega stanja, ker je šibko število mogoče zakleniti le, če je bil natančno en šibek ref, kar pomeni, da se lahko padec šele nato zažene na tisti preostali šibki ref, kar se lahko zgodi šele po sprostitvi zaklepanja.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Tu se ukvarjamo s to specializacijo in ne kot splošnejša optimizacija `&T`, ker bi sicer dodala stroške vsem preverjanjem enakosti referenčnih številk.
/// Predvidevamo, da se `Arc` uporabljajo za shranjevanje velikih vrednosti, ki se počasi klonirajo, hkrati pa tudi težko preverjajo enakost, zaradi česar se ti stroški lažje izplačajo.
///
/// Prav tako je bolj verjetno, da sta dva klona `Arc`, ki kažeta na isto vrednost, kot dva "&T".
///
/// To lahko storimo le, če je `T: Eq` kot `PartialEq` morda namerno refleksiven.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Enakost za dva "loka".
    ///
    /// Dva `Arc` sta enaka, če sta njuni notranji vrednosti enaki, tudi če sta shranjena na drugačni dodelitvi.
    ///
    /// Če `T` izvaja tudi `Eq` (kar kaže na refleksivnost enakosti), sta dva "loka, ki kažeta na isto dodelitev, vedno enaka.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Neenakost za dva "Arc`s.
    ///
    /// Dva Arc sta neenaka, če sta njuni notranji vrednosti neenaki.
    ///
    /// Če `T` izvaja tudi `Eq` (kar kaže na refleksivnost enakosti), dva "loka, ki kažeta na isto vrednost, nikoli nista neenaka.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Delna primerjava za dva "Arc".
    ///
    /// Oba primerjamo s klicem `partial_cmp()` glede njihovih notranjih vrednot.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Manj kot primerjava za dva "Arc".
    ///
    /// Oba primerjamo s klicem `<` glede njihovih notranjih vrednot.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// Primerjava "Manj ali enako" za dva "Arc".
    ///
    /// Oba primerjamo s klicem `<=` glede njihovih notranjih vrednot.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Večja primerjava za dva `Arc`.
    ///
    /// Oba primerjamo s klicem `>` glede njihovih notranjih vrednot.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// Primerjava "večja ali enaka" za dva "loka".
    ///
    /// Oba primerjamo s klicem `>=` glede njihovih notranjih vrednot.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Primerjava dveh `Arc`s.
    ///
    /// Oba primerjamo s klicem `cmp()` glede njihovih notranjih vrednot.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Ustvari nov `Arc<T>` z vrednostjo `Default` za `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Dodelite referenčno šteto rezino in jo napolnite s kloniranjem elementov `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Dodelite referenčno štetje `str` in vanj kopirajte `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Dodelite referenčno štetje `str` in vanj kopirajte `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Premaknite predmet v polje v novo dodeljeno referenčno štetje.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Dodelite referenčno šteto rezino in vanjo premaknite elemente `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Pustite, da Vec sprosti svoj spomin, vendar ne uniči njegove vsebine
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Vsak element v `Iterator` vzame in zbere v `Arc<[T]>`.
    ///
    /// # Značilnosti delovanja
    ///
    /// ## Splošni primer
    ///
    /// V splošnem se zbiranje v `Arc<[T]>` opravi tako, da se najprej zbira v `Vec<T>`.Se pravi, ko pišete naslednje:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// to se obnaša, kot da bi zapisali:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Tu se zgodi prvi sklop dodelitev.
    ///     .into(); // Tu se zgodi druga dodelitev za `Arc<[T]>`.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// To bo dodelilo tolikokrat, kolikor je potrebno za izdelavo `Vec<T>`, nato pa enkrat za pretvorbo `Vec<T>` v `Arc<[T]>`.
    ///
    ///
    /// ## Iteratorji znane dolžine
    ///
    /// Ko vaš `Iterator` implementira `TrustedLen` in je natančne velikosti, bo za `Arc<[T]>` dodeljena ena dodelitev.Na primer:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Tu se zgodi samo ena dodelitev.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Specializacija Portrait za zbiranje v `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // To velja za iterator `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // VARNOST: Zagotoviti moramo, da ima iterator natančno dolžino in mi jo imamo.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Vrnite se k običajni izvedbi.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// V `ArcInner` dobite odmik koristnega tovora za kazalcem.
///
/// # Safety
///
/// Kazalec mora kazati na (in imeti veljavne metapodatke za) predhodno veljaven primerek T, vendar T lahko spustite.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Poravnajte neizmerno vrednost na konec ArcInnerja.
    // Ker je RcBox repr(C), bo to vedno zadnje polje v pomnilniku.
    // VARNOST: ker so edini možni tipi velikosti rezine, predmeti Portrait,
    // in zunanjih tipov je trenutno zahteva glede varnosti vnosa zadovoljiva zahtevam align_of_val_raw;to je izvedbena podrobnost jezika, na katero se zunaj std ni mogoče zanašati.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}