use core::marker::PhantomData;
use core::ptr::NonNull;

/// Modelira ponovitev neke edinstvene reference, ko veste, da ponovna uporaba in vsi njeni potomci (tj. Vsi kazalci in sklici, ki izhajajo iz nje) v določenem trenutku ne bodo več uporabljeni, nato pa želite znova uporabiti prvotno edinstveno referenco .
///
///
/// Preverjevalnik izposoje običajno obravnava to zlaganje posojil za vas, vendar so nekateri kontrolni tokovi, ki to zlaganje naredijo, preveč zapleteni, da bi jih prevajalnik lahko spremljal.
/// `DormantMutRef` vam omogoča, da preverite, kako si zadolžujete, hkrati pa še vedno izražate svojo zloženo naravo in enkapsulirate neobdelano kodo kazalca, ki je potrebna za to brez nedefiniranega vedenja.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Ujemite edinstveno izposojo in si jo takoj izposodite.
    /// Življenjska doba nove reference je za prevajalnik enaka življenjski dobi prvotne reference, vendar jo morate uporabiti za krajše obdobje.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // VARNOST: izposojo držimo v celotnem 'a prek `_marker` in jo izpostavimo
        // samo ta referenca, zato je edinstvena.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Vrnite se na prvotno zajeto izposojo.
    ///
    /// # Safety
    ///
    /// Vnovična uporaba se mora končati, tj. Referenca, ki jo vrne `new`, in vsi kazalci in sklici, ki izhajajo iz nje, se ne smejo več uporabljati.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // VARNOST: lastni varnostni pogoji pomenijo, da je ta referenca spet edinstvena.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;