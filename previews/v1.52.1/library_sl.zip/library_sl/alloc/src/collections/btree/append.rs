use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Priključi vse pare ključ-vrednost iz združitve dveh naraščajočih iteratorjev, pri čemer narašča spremenljivka `length`.Slednje kličočemu olajša, da se izogne puščanju, ko se vodnik spušča.
    ///
    /// Če oba iteratorja ustvarita isti ključ, ta metoda spusti par iz levega iteratorja in doda par iz desnega iteratorja.
    ///
    /// Če želite, da drevo konča v strogo naraščajočem vrstnem redu, kot pri `BTreeMap`, naj oba iteratorja izdelata ključa v strogo naraščajočem vrstnem redu, vsak večji od vseh ključev v drevesu, vključno s ključi, ki so že v drevesu ob vstopu.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Pripravimo se na združitev `left` in `right` v razvrščeno zaporedje v linearnem času.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Medtem iz razvrščenega zaporedja v linearnem času gradimo drevo.
        self.bulk_push(iter, length)
    }

    /// Potisne vse pare ključ-vrednost na konec drevesa, pri čemer narašča spremenljivka `length`.
    /// Slednje kličočemu olajša, da se izogne puščanju, ko se iterator panikira.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Prebrskajte vse pare ključ-vrednost in jih potisnite v vozlišča na pravi ravni.
        for (key, value) in iter {
            // Poskusite potisniti par ključ-vrednost v trenutno vozlišče listov.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Ni več prostora, pojdite gor in potisnite tja.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Najdeno vozlišče z levim prostorom, potisnite sem.
                                open_node = parent;
                                break;
                            } else {
                                // Pojdi spet gor.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Smo na vrhu, ustvarimo novo korensko vozlišče in potisnemo tja.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Potisnite par ključ-vrednost in novo desno poddrevo.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Ponovno se spustite do skrajno desnega lista.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Povečajte dolžino vsake ponovitve, da zagotovite, da zemljevid spusti dodane elemente, tudi če napredovanje iteratorja straši.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Ponavljalec za spajanje dveh razvrščenih zaporedij v eno
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Če sta dva ključa enaka, vrne par ključ-vrednost iz desnega vira.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}