use core::intrinsics;
use core::mem;
use core::ptr;

/// To nadomesti vrednost za edinstveno referenco `v` s klicem ustrezne funkcije.
///
///
/// Če se pri zapiranju `change` pojavi panic, bo celoten postopek prekinjen.
#[allow(dead_code)] // shranite kot ponazoritev in za uporabo future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// To nadomesti vrednost za edinstveno referenco `v` s klicanjem ustrezne funkcije in vrne rezultat, pridobljen med potjo.
///
///
/// Če se pri zapiranju `change` pojavi panic, bo celoten postopek prekinjen.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}