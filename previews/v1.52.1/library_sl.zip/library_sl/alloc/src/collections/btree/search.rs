use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// Inkluzivno, ki ga je treba iskati, tako kot `Bound::Included(T)`.
    Included(T),
    /// Ekskluziven izdelek za iskanje, tako kot `Bound::Excluded(T)`.
    Excluded(T),
    /// Brezpogojna vključujoča vezava, tako kot `Bound::Unbounded`.
    AllIncluded,
    /// Brezpogojna izključna vezava.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Poišče dani ključ v (pod) drevesu, ki ga vodi vozlišče, rekurzivno.
    /// Vrne `Found` z ročajem ustreznega KV, če obstaja.
    /// V nasprotnem primeru vrne `GoDown` z ročajem lista edge, kamor pripada ključ.
    ///
    /// Rezultat je pomemben le, če je drevo razvrščeno po ključu, kot je drevo v `BTreeMap`.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// Sestopi do najbližjega vozlišča, kjer se edge, ki ustreza spodnji meji obsega, razlikuje od edge, ki ustreza zgornji meji, tj. Najbližje vozlišče, ki ima v območju vsaj en ključ.
    ///
    ///
    /// Če je najden, vrne `Ok` s tem vozliščem, par indeksov edge v njem, ki omejuje obseg, in ustrezni par mej za nadaljevanje iskanja v podrejenih vozliščih, če je vozlišče notranje.
    ///
    /// Če ga ne najdemo, vrne `Err` z listom edge, ki ustreza celotnemu obsegu.
    ///
    /// Rezultat je pomemben le, če je drevo razvrščeno po ključu.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // Izogibati se je treba vključevanju teh spremenljivk.
        // Predvidevamo, da meje, o katerih poroča `range`, ostajajo enake, vendar se lahko kontradiktorna izvedba med klici (#81138) spremeni.
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// V vozlišču poišče edge, ki omejuje spodnjo mejo obsega.
    /// Vrne tudi spodnjo mejo, ki bo uporabljena za nadaljevanje iskanja v ujemajočem se podrejenem vozlišču, če je `self` notranje vozlišče.
    ///
    ///
    /// Rezultat je pomemben le, če je drevo razvrščeno po ključu.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// Klon `find_lower_bound_edge` za zgornjo mejo.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Poišče dani ključ v vozlišču, brez ponovitve.
    /// Vrne `Found` z ročajem ustreznega KV, če obstaja.
    /// V nasprotnem primeru vrne `GoDown` z ročajem edge, kjer je mogoče najti ključ (če je vozlišče notranje) ali kamor lahko vstavite ključ.
    ///
    ///
    /// Rezultat je pomemben le, če je drevo razvrščeno po ključu, kot je drevo v `BTreeMap`.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// Vrne bodisi indeks KV v vozlišču, na katerem obstaja ključ (ali enakovreden), bodisi indeks edge, kamor pripada ključ.
    ///
    ///
    /// Rezultat je pomemben le, če je drevo razvrščeno po ključu, kot je drevo v `BTreeMap`.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// Poišče indeks edge v vozlišču, ki omejuje spodnjo mejo obsega.
    /// Vrne tudi spodnjo mejo, ki bo uporabljena za nadaljevanje iskanja v ujemajočem se podrejenem vozlišču, če je `self` notranje vozlišče.
    ///
    ///
    /// Rezultat je pomemben le, če je drevo razvrščeno po ključu.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// Klon `find_lower_bound_index` za zgornjo mejo.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}