use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Začasno vzame drug nespremenljiv ekvivalent istega obsega.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Poišče ločene robove listov, ki omejujejo določen obseg v drevesu.
    /// Vrne bodisi par različnih ročajev v isto drevo bodisi par praznih možnosti.
    ///
    /// # Safety
    ///
    /// Če `BorrowType` ni `Immut`, ne uporabljajte podvojenih ročajev, da dvakrat obiščete isti KV.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Enakovredno `(root1.first_leaf_edge(), root2.last_leaf_edge())`, vendar bolj učinkovito.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Poišče par robov listov, ki omejujejo določen obseg v drevesu.
    ///
    /// Rezultat je pomemben le, če je drevo razvrščeno po ključu, kot je drevo v `BTreeMap`.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // VARNOST: naša vrsta izposoje je nespremenljiva.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Najde par listov, ki omejujejo celo drevo.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Enolično sklic razdeli na par robov listov, ki omejujejo določen obseg.
    /// Rezultat so neponovljive reference, ki omogočajo mutacijo (some) in jih je treba uporabljati previdno.
    ///
    /// Rezultat je pomemben le, če je drevo razvrščeno po ključu, kot je drevo v `BTreeMap`.
    ///
    ///
    /// # Safety
    /// Dvojnih ročajev ne uporabljajte za dvakratni obisk iste KV.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Razdeli edinstveno referenco na par listov, ki omejujejo celoten obseg drevesa.
    /// Rezultati so neponovljivi sklici, ki omogočajo mutacijo (samo vrednosti), zato jih je treba uporabljati previdno.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Tukaj podvojimo korenski NodeRef-nikoli ne bomo dvakrat obiskali iste KV in nikoli ne bomo imeli referenc vrednosti, ki se prekrivajo.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Razdeli edinstveno referenco na par listov, ki omejujejo celoten obseg drevesa.
    /// Rezultati so neenotne reference, ki omogočajo močno uničujoče mutacije, zato jih je treba uporabljati zelo skrbno.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Tukaj podvajamo korenski NodeRef-nikoli ne bomo dostopali do njega tako, da bo prekrival sklice, pridobljene iz korena.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Glede na ročaj lista edge vrne [`Result::Ok`] z ročajem na sosednji KV na desni strani, ki je bodisi v istem vozlišču lista bodisi v vozlišču prednika.
    ///
    /// Če je list edge zadnji v drevesu, vrne [`Result::Err`] s korenskim vozliščem.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Glede na ročaj lista edge vrne [`Result::Ok`] z ročajem v sosednji KV na levi strani, ki je v istem vozlišču lista ali vozlišču prednika.
    ///
    /// Če je list edge prvi v drevesu, vrne [`Result::Err`] s korenskim vozliščem.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Glede na notranji ročaj edge vrne [`Result::Ok`] z ročajem na sosednji KV na desni strani, ki je v istem notranjem vozlišču ali v vozlišču prednika.
    ///
    /// Če je notranji edge zadnji v drevesu, vrne [`Result::Err`] s korenskim vozliščem.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Glede na ročaj lista edge v umirajoče drevo vrne naslednji list edge na desni strani in par ključ/vrednost vmes, ki je bodisi v istem vozlišču lista, v vozlišču prednika ali pa ga sploh ni.
    ///
    ///
    /// Ta metoda razbremeni tudi vse node(s), ki jih doseže konec.
    /// To pomeni, da če ne bo več para ključ-vrednost, bo ves preostali del drevesa odstranjen in ni več ničesar za vrnitev.
    ///
    /// # Safety
    /// Danega edge ne sme predhodno vrniti nasprotni `deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Glede na ročaj lista edge v umirajoče drevo vrne naslednji list edge na levi strani in par ključ-vrednost vmes, ki je bodisi v istem vozlišču lista, v vozlišču prednika ali pa ga sploh ni.
    ///
    ///
    /// Ta metoda razbremeni tudi vse node(s), ki jih doseže konec.
    /// To pomeni, da če ne bo več para ključ-vrednost, bo ves preostali del drevesa odstranjen in ni več ničesar za vrnitev.
    ///
    /// # Safety
    /// Danega edge ne sme predhodno vrniti nasprotni `deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Razdeli kup vozlišč od lista do korena.
    /// To je edini način, da odstranimo ostanek drevesa, potem ko sta `deallocating_next` in `deallocating_next_back` grizla na obeh straneh drevesa in zadela isti edge.
    /// Ker naj bi bil poklican le, ko so vrnjeni vsi ključi in vrednosti, nobeno od tipk ali vrednosti ne opravi čiščenja.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Premakne ročaj lista edge na naslednji list edge in vrne sklice na ključ in vrednost vmes.
    ///
    ///
    /// # Safety
    /// V prevoženi smeri mora biti še en KV.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Premakne ročaj lista edge na prejšnji list edge in vrne sklice na ključ in vrednost vmes.
    ///
    ///
    /// # Safety
    /// V prevoženi smeri mora biti še en KV.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Premakne ročaj lista edge na naslednji list edge in vrne sklice na ključ in vrednost vmes.
    ///
    ///
    /// # Safety
    /// V prevoženi smeri mora biti še en KV.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Narediti to zadnje je hitreje, glede na merila uspešnosti.
        kv.into_kv_valmut()
    }

    /// Premakne ročaj lista edge na prejšnji list in vrne sklice na ključ in vrednost vmes.
    ///
    ///
    /// # Safety
    /// V prevoženi smeri mora biti še en KV.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Narediti to zadnje je hitreje, glede na merila uspešnosti.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Premakne ročaj lista edge na naslednji list edge in vmes vrne ključ in vrednost, pri čemer se izloči katero koli vozlišče, ki je ostalo, medtem ko ostane ustrezen edge v nadrejenem vozlišču.
    ///
    /// # Safety
    /// - V prevoženi smeri mora biti še en KV.
    /// - Tega KV predhodno ni vrnil nasprotnik `next_back_unchecked` na nobeni kopiji ročajev, ki se uporabljajo za prečkanje drevesa.
    ///
    /// Edini varen način, da nadaljujete s posodobljenim ročajem, je primerjava, spuščanje, ponovni klic te metode v skladu z njenimi varnostnimi pogoji ali klicanje ustreznega `next_back_unchecked` glede na njegove varnostne pogoje.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Premakne ročaj lista edge na prejšnji list edge in vrne ključ in vrednost vmes, pri čemer se izloči katero koli vozlišče, ki je ostalo, medtem ko ostane ustrezen edge v nadrejenem vozlišču.
    ///
    /// # Safety
    /// - V prevoženi smeri mora biti še en KV.
    /// - Ta list edge ni pred tem vrnil kolega `next_unchecked` na nobeni kopiji ročajev, ki se uporabljajo za prečkanje drevesa.
    ///
    /// Edini varen način, da nadaljujete s posodobljenim ročajem, je primerjava, spuščanje, ponovni klic te metode v skladu z njenimi varnostnimi pogoji ali klicanje ustreznega `next_unchecked` glede na njegove varnostne pogoje.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Vrne skrajno levi list edge v vozlišču ali pod njim, z drugimi besedami, edge, ki ga potrebujete najprej pri krmarjenju naprej (ali nazadnje pri krmarjenju nazaj).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Vrne skrajno desni list edge v vozlišču ali pod njim, z drugimi besedami, edge, ki ga potrebujete nazadnje pri krmarjenju naprej (ali najprej pri krmarjenju nazaj).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Obiskuje vozlišča listov in notranje KV po naraščajočih ključih, obišče pa tudi notranja vozlišča kot celoto po globini prvega reda, kar pomeni, da notranja vozlišča pred svojimi KV-ji in njihovimi podrejenimi vozlišči.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Izračuna število elementov v (pod) drevesu.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Vrne list edge, ki je najbližji KV za naprej.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Vrne list edge, ki je najbližji KV za navigacijo nazaj.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}