//! Kazalci za štetje referenc z enim navojem.'Rc' pomeni " Referenca`
//! Counted'.
//!
//! Tip [`Rc<T>`][`Rc`] zagotavlja deljeno lastništvo vrednosti tipa `T`, dodeljene na kopici.
//! Priklic [`clone`][clone] na [`Rc`] ustvari nov kazalec na isto dodelitev v kopici.
//! Ko je zadnji kazalnik [`Rc`] na dano dodelitev uničen, se izbriše tudi vrednost, shranjena v tej dodelitvi (pogosto imenovana "inner value").
//!
//! Sklici v skupni rabi v Rust privzeto onemogočajo mutacijo in [`Rc`] ni nobena izjema: na splošno ni mogoče dobiti spremenljivega sklica na nekaj v [`Rc`].
//! Če potrebujete spremenljivost, vstavite [`Cell`] ali [`RefCell`] znotraj [`Rc`];glej [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] uporablja neatomsko štetje referenc.
//! To pomeni, da so režijski stroški zelo majhni, vendar [`Rc`] ni mogoče poslati med nitmi, zato [`Rc`] ne izvaja [`Send`][send].
//! Kot rezultat bo prevajalnik Rust med časom prevajanja * preveril, ali med niti ne pošiljate [`Rc`].
//! Če potrebujete večnitno atomsko referenčno štetje, uporabite [`sync::Arc`][arc].
//!
//! Metodo [`downgrade`][downgrade] lahko uporabimo za ustvarjanje lastniškega kazalca [`Weak`].
//! Kazalec [`Weak`] lahko ["nadgradite"][nadgradite] d na [`Rc`], vendar bo to vrnilo [`None`], če je vrednost, shranjena v dodelitvi, že izpuščena.
//! Z drugimi besedami, kazalci `Weak` ne ohranjajo vrednosti znotraj dodelitve žive;kljub temu pa * ohranijo alokacijo (hrambo notranje vrednosti) pri življenju.
//!
//! Cikla med kazalci [`Rc`] ne bo nikoli odstranjenega.
//! Iz tega razloga se [`Weak`] uporablja za prekinitev ciklov.
//! Na primer, drevo bi lahko imelo močne kazalce [`Rc`] od starševskih vozlišč do otrok in kazalce [`Weak`] od otrok nazaj na njihove starše.
//!
//! `Rc<T>` samodejno preusmerja na `T` (prek [`Deref`] Portrait), tako da lahko za vrednost tipa [`Rc<T>`][`Rc`] pokličete metode T.
//! Da bi se izognili spopadom imen z metodami `T`, so metode samega [`Rc<T>`][`Rc`] povezane funkcije, imenovane z uporabo [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>Izvedbe traits, kot je `Clone`, lahko pokličete tudi z uporabo popolnoma kvalificirane sintakse.
//! Nekateri raje uporabljajo popolnoma kvalificirano sintakso, drugi pa raje sintakso za klic metode.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Sintaksa klica metode
//! let rc2 = rc.clone();
//! // Popolnoma skladna skladnja
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] ne samodejno preusmeri na `T`, ker je notranja vrednost morda že padla.
//!
//! # Kloniranje referenc
//!
//! Ustvarjanje novega sklica na isto dodelitev kot obstoječi kazalnik s štetjem referenc se izvede z uporabo `Clone` Portrait, implementirane za [`Rc<T>`][`Rc`] in [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Spodaj navedeni skladnji sta enakovredni.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a in b obe kažeta na isto pomnilniško mesto kot foo.
//! ```
//!
//! Sintaksa `Rc::clone(&from)` je najbolj idiomatična, ker bolj eksplicitno posreduje pomen kode.
//! V zgornjem primeru ta sintaksa lažje vidi, da ta koda ustvarja novo referenco, namesto da bi kopirala celotno vsebino foo.
//!
//! # Examples
//!
//! Razmislite o scenariju, v katerem je nabor "pripomočkov" v lasti določenega `Owner`.
//! Želimo, da naš pripomoček kaže na njihov `Owner`.Tega ne moremo storiti z edinstvenim lastništvom, ker lahko več pripomočkov pripada istemu `Owner`.
//! [`Rc`] nam omogoča, da `Owner` delimo med več "pripomočkov" in `Owner` ostane dodeljen, dokler nanj kaže katera koli `Gadget`.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... druga polja
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... druga polja
//! }
//!
//! fn main() {
//!     // Ustvarite referenčno štetje `Owner`.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Ustvari `pripomočke`, ki pripadajo `gadget_owner`.
//!     // Kloniranje `Rc<Owner>` nam da nov kazalec na isto dodelitev `Owner`, s čimer se poveča referenčno število v procesu.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Odstranite našo lokalno spremenljivko `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Kljub temu, da smo spustili `gadget_owner`, še vedno lahko natisnemo ime `Owner` v pripomočku.
//!     // To je zato, ker smo spustili samo en `Rc<Owner>`, ne pa tudi `Owner`, na katerega kaže.
//!     // Dokler obstajajo drugi `Rc<Owner>`, ki kažejo na isto dodelitev `Owner`, bo ostal v živo.
//!     // Projekcija polja `gadget1.owner.name` deluje, ker `Rc<Owner>` samodejno preusmeri na `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Na koncu funkcije se `gadget1` in `gadget2` uničijo in z njimi tudi zadnja prešteta sklicevanja na naš `Owner`.
//!     // Pripomoček Man zdaj postane tudi uničen.
//!     //
//! }
//! ```
//!
//! Če se naše zahteve spremenijo in moramo biti sposobni tudi prečkati od `Owner` do `Gadget`, bomo naleteli na težave.
//! Kazalec [`Rc`] od `Owner` do `Gadget` uvaja cikel.
//! To pomeni, da njihova referenčna števila nikoli ne morejo doseči 0 in dodelitev ne bo nikoli uničena:
//! uhajanje spomina.Da bi to rešili, lahko uporabimo kazalce [`Weak`].
//!
//! Rust dejansko nekoliko oteži izdelavo te zanke.Da bi na koncu prišli do dveh vrednot, ki kažeta drug na drugega, mora biti ena od njih spremenljiva.
//! To je težko, ker [`Rc`] uveljavlja varnost pomnilnika tako, da daje le skupne sklice na vrednost, ki jo zavije, in te ne dovoljujejo neposredne mutacije.
//! Del vrednosti, ki ga želimo mutirati, moramo zaviti v [`RefCell`], ki zagotavlja *notranjo spremenljivost*: metodo za doseganje spremenljivosti s skupno referenco.
//! [`RefCell`] uveljavlja pravila zadolževanja Rust med izvajanjem.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... druga polja
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... druga polja
//! }
//!
//! fn main() {
//!     // Ustvarite referenčno štetje `Owner`.
//!     // Upoštevajte, da smo v pripomoček `RefCell` postavili "lastnikov" vector pripomočkov, da ga lahko mutiramo prek skupne reference.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Ustvarite `pripomočke`, ki pripadajo `gadget_owner`, kot prej.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Dodajte pripomočke svojim `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` tu se konča dinamično izposojanje.
//!     }
//!
//!     // Ponavljajte se nad našimi pripomočki in natisnite njihove podrobnosti.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` je `Weak<Gadget>`.
//!         // Ker kazalci `Weak` ne morejo zagotoviti, da dodelitev še vedno obstaja, moramo poklicati `upgrade`, ki vrne `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // V tem primeru vemo, da dodelitev še vedno obstaja, zato preprosto `unwrap` `Option`.
//!         // V bolj zapletenem programu boste morda potrebovali elegantno obdelavo napak za rezultat `None`.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Na koncu funkcije se `gadget_owner`, `gadget1` in `gadget2` uničijo.
//!     // Zdaj ni močnih kazalcev (`Rc`) na pripomočke, zato so uničeni.
//!     // To pomeni nič referenčnega števila pripomočka Gadget Man, zato tudi njega uničijo.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// To je odpornost repr(C) do future proti morebitnemu preurejanju polja, ki bi vplivalo na sicer varen [into|from]_raw() pretvorljivih notranjih tipov.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Kazalec za štetje referenc z enim navojem.'Rc' pomeni " Referenca`
/// Counted'.
///
/// Za več podrobnosti glejte [module-level documentation](./index.html).
///
/// Lastne metode `Rc` so vse povezane funkcije, kar pomeni, da jih morate poklicati kot npr. [`Rc::get_mut(&mut value)`][get_mut] namesto `value.get_mut()`.
/// S tem se izognemo konfliktom z metodami notranjega tipa `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Ta nevarnost je v redu, ker je, medtem ko je ta Rc živ, zagotovljeno, da je notranji kazalec veljaven.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Konstruira nov `Rc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Obstajajo implicitni šibki kazalci, ki so v lasti vseh močnih kazalcev, kar zagotavlja, da šibki destruktor nikoli ne sprosti dodelitve, medtem ko močan destruktor deluje, tudi če je šibki kazalec shranjen znotraj močnega kazalca.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Konstruira nov `Rc<T>` z uporabo šibkega sklicevanja na samega sebe.
    /// Poskus nadgradnje šibkega sklica, preden se ta funkcija vrne, bo imel za posledico vrednost `None`.
    ///
    /// Šibko referenco pa lahko prosto kloniramo in shranimo za poznejšo uporabo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... več polj
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Zgradite notranjost v stanju "uninitialized" z eno šibko referenco.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Pomembno je, da se ne odrekamo lastništvu šibkega kazalca, sicer se spomin sprosti do vrnitve `data_fn`.
        // Če bi res želeli prenesti lastništvo, bi lahko ustvarili dodaten šibki kazalec zase, vendar bi to povzročilo dodatne posodobitve števila šibkih referenc, ki sicer ne bi bile potrebne.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Močne reference bi morale imeti skupno deljeno šibko referenco, zato ne zaženite destruktorja za našo staro šibko referenco.
        //
        mem::forget(weak);
        strong
    }

    /// Konstruira nov `Rc` z neinicializirano vsebino.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Odložena inicializacija:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstruira nov `Rc` z neinicializirano vsebino, pri čemer je pomnilnik napolnjen z bajti `0`.
    ///
    ///
    /// Za primere pravilne in nepravilne uporabe te metode glejte [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstruira nov `Rc<T>` in vrne napako, če dodelitev ne uspe
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Obstajajo implicitni šibki kazalci, ki so v lasti vseh močnih kazalcev, kar zagotavlja, da šibki destruktor nikoli ne sprosti dodelitve, medtem ko močan destruktor deluje, tudi če je šibki kazalec shranjen znotraj močnega kazalca.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Konstruira nov `Rc` z neinicializirano vsebino in vrne napako, če dodelitev ne uspe
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Odložena inicializacija:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Konstruira nov `Rc` z neinicializirano vsebino, pri čemer je pomnilnik napolnjen z bajti `0` in vrne napako, če dodelitev ne uspe
    ///
    ///
    /// Za primere pravilne in nepravilne uporabe te metode glejte [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Konstruira nov `Pin<Rc<T>>`.
    /// Če `T` ne izvaja `Unpin`, bo `value` pripet v pomnilnik in ga ne bo mogoče premakniti.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Vrne notranjo vrednost, če ima `Rc` točno eno močno referenco.
    ///
    /// V nasprotnem primeru se vrne [`Err`] z istim `Rc`, ki je bil poslan.
    ///
    ///
    /// To bo uspelo, tudi če obstajajo izjemne šibke reference.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // kopirajte vsebovani predmet

                // Weaksom označite, da jih ni mogoče napredovati, tako da zmanjšate močno število in nato odstranite implicitni kazalnik "strong weak", hkrati pa obvladate tudi logiko padca, tako da preprosto izdelate lažni šibki.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Konstruira novo rezano številko z neinicializirano vsebino.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Odložena inicializacija:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Zgradi novo rezano številko z neinicializirano vsebino, pri čemer je pomnilnik napolnjen z bajti `0`.
    ///
    ///
    /// Za primere pravilne in nepravilne uporabe te metode glejte [`MaybeUninit::zeroed`][zeroed].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Pretvori v `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Tako kot pri [`MaybeUninit::assume_init`] mora tudi klicatelj zagotoviti, da je notranja vrednost res v inicializiranem stanju.
    ///
    /// Če pokličete to, ko vsebina še ni popolnoma inicializirana, povzroči takojšnje nedefinirano vedenje.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Odložena inicializacija:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Pretvori v `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Tako kot pri [`MaybeUninit::assume_init`] mora tudi klicatelj zagotoviti, da je notranja vrednost res v inicializiranem stanju.
    ///
    /// Če pokličete to, ko vsebina še ni popolnoma inicializirana, povzroči takojšnje nedefinirano vedenje.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Odložena inicializacija:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Porabi `Rc` in vrne oviti kazalec.
    ///
    /// Da bi se izognili puščanju pomnilnika, je treba kazalec z [`Rc::from_raw`][from_raw] pretvoriti nazaj v `Rc`.
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Ponuja neobdelan kazalec na podatke.
    ///
    /// Na štetje to nikakor ne vpliva in `Rc` se ne porabi.
    /// Kazalec je veljaven, dokler v `Rc` obstaja močno štetje.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // VARNOST: To ne more iti skozi Deref::deref ali Rc::inner, ker
        // to je potrebno, da se ohrani izvor raw/mut tako, da npr
        // `get_mut` lahko piše skozi kazalec, ko je Rc obnovljen prek `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Konstruira `Rc<T>` iz surovega kazalca.
    ///
    /// Neobdelani kazalec mora biti predhodno vrnjen s klicem na [`Rc<U>::into_raw`][into_raw], kjer mora imeti `U` enako velikost in poravnavo kot `T`.
    /// To je nepomembno, če je `U` `T`.
    /// Upoštevajte, da če `U` ni `T`, vendar ima enako velikost in poravnavo, je to v bistvu podobno pretvarjanju referenc različnih vrst.
    /// Za več informacij o omejitvah, ki veljajo v tem primeru, glejte [`mem::transmute`][transmute].
    ///
    /// Uporabnik `from_raw` mora zagotoviti, da določena vrednost `T` pade le enkrat.
    ///
    /// Ta funkcija ni varna, ker lahko nepravilna uporaba vodi do nevarnosti pomnilnika, tudi če do vrnjenega `Rc<T>` nikoli ne dostopate.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Pretvorite nazaj v `Rc`, da preprečite puščanje.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Nadaljnji klici na `Rc::from_raw(x_ptr)` bi bili varni za pomnilnik.
    /// }
    ///
    /// // Spomin se je sprostil, ko je `x` izstopil zgoraj, zato `x_ptr` zdaj visi!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Če želite najti originalni RcBox, obrnite odmik.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Ustvari nov kazalec [`Weak`] na to dodelitev.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Prepričajte se, da ne ustvarjamo visečega šibkega
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Pridobi število kazalcev [`Weak`] na to dodelitev.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Pridobi število močnih kazalcev (`Rc`) na to dodelitev.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Vrne `true`, če na to dodelitev ni drugih kazalcev `Rc` ali [`Weak`].
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Vrne spremenljivo referenco v dani `Rc`, če ni drugih kazalcev `Rc` ali [`Weak`] na isto dodelitev.
    ///
    ///
    /// Vrne [`None`] v nasprotnem primeru, ker ni varno mutirati vrednosti v skupni rabi.
    ///
    /// Glejte tudi [`make_mut`][make_mut], ki bo [`clone`][clone] določil notranjo vrednost, če obstajajo drugi kazalci.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Vrne spremenljivo referenco v dani `Rc` brez preverjanja.
    ///
    /// Glejte tudi [`get_mut`], ki je varen in izvaja ustrezne preglede.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Nobenega drugega kazalca `Rc` ali [`Weak`] na isto dodelitev ne smete spreminjati med trajanjem vrnjenega posojila.
    ///
    /// To je nenavadno, če taki kazalci ne obstajajo, na primer takoj po `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Pazimo, da *ne* ustvarimo sklica, ki pokriva polja "count", saj bi to bilo v nasprotju z dostopom do števila referenc (npr.
        // `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Vrne `true`, če oba "Rc" kažeta na isto dodelitev (v veni, podobni [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Naredi spremenljiv sklic na dani `Rc`.
    ///
    /// Če obstajajo drugi kazalci `Rc` na isto dodelitev, bo `make_mut` [`clone`] notranjo vrednost nove dodelitve, da se zagotovi edinstveno lastništvo.
    /// To se imenuje tudi klon na pisanje.
    ///
    /// Če na to dodelitev ni drugih kazalcev `Rc`, bodo kazalci [`Weak`] na to dodelitev ločeni.
    ///
    /// Glej tudi [`get_mut`], ki ne bo uspel kot kloniral.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Ničesar ne bom kloniral
    /// let mut other_data = Rc::clone(&data);    // Ne bo kloniral notranjih podatkov
    /// *Rc::make_mut(&mut data) += 1;        // Klonira notranje podatke
    /// *Rc::make_mut(&mut data) += 1;        // Ničesar ne bom kloniral
    /// *Rc::make_mut(&mut other_data) *= 2;  // Ničesar ne bom kloniral
    ///
    /// // Zdaj `data` in `other_data` kažeta na različna dodeljevanja.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] kazalci bodo ločeni:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Moram klonirati podatke, obstajajo še drugi Rcs.
            // Vnaprej dodelite pomnilnik, da omogočite neposredno pisanje klonirane vrednosti.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Lahko samo ukrade podatke, ostane le Weaks
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Odstranite implicitni močan in šibek ref (tukaj ni treba izdelati lažnega šibkega-vemo, da nas lahko drugi šibki očistijo)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Ta nevarnost je v redu, ker imamo zagotovljeno, da je vrnjeni kazalec *edini* kazalec, ki bo kdaj vrnjen T.
        // Število referenc je na tej točki zajamčeno 1, zato smo zahtevali, da je `Rc<T>` `mut`, zato vrnemo edino možno referenco na dodelitev.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Poskus `Rc<dyn Any>` znižati na konkretno vrsto.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Dodeljuje `RcBox<T>` z dovolj prostora za morebitno velikost notranje vrednosti, če ima vrednost predvideno postavitev.
    ///
    /// Funkcija `mem_to_rcbox` se pokliče s kazalcem podatkov in mora vrniti (potencialno maščobni) kazalec za `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Postavitev izračunajte z uporabo postavitve vrednosti.
        // Prej je bila postavitev izračunana na izrazu `&*(ptr as* const RcBox<T>)`, vendar je to ustvarilo napačno poravnano referenco (glej #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Dodeljuje `RcBox<T>` z dovolj prostora za morebitno velikost notranje vrednosti, kjer ima vrednost predvideno postavitev, in vrne napako, če dodelitev ne uspe.
    ///
    ///
    /// Funkcija `mem_to_rcbox` se pokliče s kazalcem podatkov in mora vrniti (potencialno maščobni) kazalec za `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Postavitev izračunajte z uporabo postavitve vrednosti.
        // Prej je bila postavitev izračunana na izrazu `&*(ptr as* const RcBox<T>)`, vendar je to ustvarilo napačno poravnano referenco (glej #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Dodelite za postavitev.
        let ptr = allocate(layout)?;

        // Inicializirajte RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Dodeljuje `RcBox<T>` z dovolj prostora za velikost notranje vrednosti
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Dodelite `RcBox<T>` z dano vrednostjo.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopiraj vrednost v bajtih
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Alokacijo osvobodite, ne da bi spustili vsebino
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Dodeljuje `RcBox<[T]>` z dano dolžino.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Kopirajte elemente iz rezine v novo dodeljeno Rc <\[T\]>
    ///
    /// Nevarno, ker mora klicatelj prevzeti lastništvo ali vezati `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Konstruira `Rc<[T]>` iz iteratorja, za katerega je znano, da je določene velikosti.
    ///
    /// Obnašanje ni določeno, če je velikost napačna.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic ščitnik med kloniranjem T elementov.
        // V primeru panic bodo elementi, ki so bili zapisani v novi RcBox, odstranjeni, nato pa se bo sprostil pomnilnik.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Kazalec na prvi element
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Vse jasno.Pozabite na stražo, da ne sprosti novega RcBox-a.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specializacija Portrait za `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Spusti `Rc`.
    ///
    /// To bo zmanjšalo močno število referenc.
    /// Če močno število referenc doseže nič, so edine druge reference (če obstajajo) [`Weak`], zato `drop` določimo notranjo vrednost.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Ne natisne ničesar
    /// drop(foo2);   // Natisne "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // uničiti vsebovani predmet
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // odstranite implicitni kazalec "strong weak" zdaj, ko smo uničili vsebino.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Naredi klon kazalca `Rc`.
    ///
    /// To ustvari nov kazalec na isto dodelitev, kar poveča močno število referenc.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Ustvari nov `Rc<T>` z vrednostjo `Default` za `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Hack, da dovolite specializiranje za `Eq`, čeprav `Eq` ima metodo.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Tu se ukvarjamo s to specializacijo in ne kot splošnejša optimizacija `&T`, ker bi sicer dodala stroške vsem preverjanjem enakosti referenčnih številk.
/// Predvidevamo, da se "Rc" uporabljajo za shranjevanje velikih vrednosti, ki so počasne za kloniranje, hkrati pa tudi težke za preverjanje enakovrednosti, zaradi česar se ti stroški lažje izplačajo.
///
/// Prav tako je bolj verjetno, da sta dva klona `Rc`, ki kažeta na isto vrednost, kot dva "&T".
///
/// To lahko storimo le, če je `T: Eq` kot `PartialEq` morda namerno refleksiven.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Enakost za dva `Rc`.
    ///
    /// Dva `Rc` sta enaka, če sta njuni notranji vrednosti enaki, tudi če sta shranjena v različnih dodelitvah.
    ///
    /// Če `T` izvaja tudi `Eq` (kar kaže na refleksivnost enakosti), sta dva Rc, ki kažeta na isto dodelitev, vedno enaka.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Neenakost za dva `Rc`.
    ///
    /// Dva "Rc" sta neenaka, če so njihove notranje vrednosti neenake.
    ///
    /// Če `T` izvaja tudi `Eq` (kar kaže na refleksivnost enakosti), dva `Rc, ki kažeta na isto dodelitev, nikoli nista neenaka.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Delna primerjava za dva `Rc`.
    ///
    /// Oba primerjamo s klicem `partial_cmp()` glede njihovih notranjih vrednot.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Manj kot primerjava za dva "Rc".
    ///
    /// Oba primerjamo s klicem `<` glede njihovih notranjih vrednot.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// Primerjava "Manj ali enako" za dva "Rc".
    ///
    /// Oba primerjamo s klicem `<=` glede njihovih notranjih vrednot.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Večja primerjava za dva `Rc`.
    ///
    /// Oba primerjamo s klicem `>` glede njihovih notranjih vrednot.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// Primerjava "večja ali enaka" za dva "Rc".
    ///
    /// Oba primerjamo s klicem `>=` glede njihovih notranjih vrednot.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Primerjava za dva `Rc`.
    ///
    /// Oba primerjamo s klicem `cmp()` glede njihovih notranjih vrednot.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Dodelite referenčno šteto rezino in jo napolnite s kloniranjem elementov `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Dodelite referenčno šteto rezino niza in vanjo kopirajte `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Dodelite referenčno šteto rezino niza in vanjo kopirajte `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Premaknite predmet v polje v novo dodelitev, šteto v sklice.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Dodelite referenčno šteto rezino in vanjo premaknite elemente `v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Pustite, da Vec sprosti svoj spomin, vendar ne uniči njegove vsebine
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Vsak element v `Iterator` vzame in zbere v `Rc<[T]>`.
    ///
    /// # Značilnosti delovanja
    ///
    /// ## Splošni primer
    ///
    /// V splošnem se zbiranje v `Rc<[T]>` opravi tako, da se najprej zbira v `Vec<T>`.Se pravi, ko pišete naslednje:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// to se obnaša, kot da bi zapisali:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Tu se zgodi prvi sklop dodelitev.
    ///     .into(); // Tu se zgodi druga dodelitev za `Rc<[T]>`.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// To bo dodelilo tolikokrat, kolikor je potrebno za izdelavo `Vec<T>`, nato pa enkrat za pretvorbo `Vec<T>` v `Rc<[T]>`.
    ///
    ///
    /// ## Iteratorji znane dolžine
    ///
    /// Ko vaš `Iterator` implementira `TrustedLen` in je natančne velikosti, bo za `Rc<[T]>` dodeljena ena dodelitev.Na primer:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Tu se zgodi samo ena dodelitev.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Specializacija Portrait za zbiranje v `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // To velja za iterator `TrustedLen`.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // VARNOST: Zagotoviti moramo, da ima iterator natančno dolžino in mi jo imamo.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Vrnite se k običajni izvedbi.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` je različica [`Rc`], ki vsebuje lastniški sklic na upravljano dodelitev.Do dodelitve je mogoče dostopati s klicem [`upgrade`] na kazalcu `Weak`, ki vrne [`Možnost`]`<`[`Rc`] `<T>>`.
///
/// Ker sklic `Weak` ne šteje za lastništvo, ne bo preprečil, da bi vrednost, shranjena v dodelitvi, padla, sam `Weak` pa ne jamči, da je vrednost še vedno prisotna.
/// Tako lahko vrne [`None`], ko [`nadgradnja`] d.
/// Upoštevajte pa, da referenca `Weak`*ne* preprečuje sprostitve same dodelitve (shrambe).
///
/// Kazalec `Weak` je uporaben za začasno sklicevanje na dodelitev, ki jo upravlja [`Rc`], ne da bi pri tem preprečil izpuščanje njegove notranje vrednosti.
/// Uporablja se tudi za preprečevanje krožnih referenc med kazalci [`Rc`], saj medsebojne reference lastništva ne bi nikoli omogočile, da bi [`Rc`] izpustil.
/// Na primer, drevo bi lahko imelo močne kazalce [`Rc`] od starševskih vozlišč do otrok in kazalce `Weak` od otrok nazaj na njihove starše.
///
/// Tipičen način za pridobitev kazalca `Weak` je klic [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // To je `NonNull`, ki omogoča optimizacijo velikosti te vrste v enumih, ni pa nujno veljaven kazalec.
    //
    // `Weak::new` nastavi na `usize::MAX`, tako da mu ni treba dodeliti prostora na kupu.
    // To ni vrednost, ki jo bo imel pravi kazalec, ker ima RcBox poravnavo vsaj 2.
    // To je mogoče le, če `T: Sized`;velikost `T` nikoli ne visi.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Konstruira nov `Weak<T>`, ne da bi dodeljeval pomnilnik.
    /// Poklic [`upgrade`] na vrnjeno vrednost vedno da [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Vrsta pomožnika, ki omogoča dostop do števila sklicev brez navedb o podatkovnem polju.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Vrne neobdelani kazalnik na predmet `T`, na katerega kaže ta `Weak<T>`.
    ///
    /// Kazalec je veljaven le, če obstaja nekaj močnih referenc.
    /// Kazalec je lahko viseč, neuravnan ali v nasprotnem primeru celo [`null`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Oba kažeta na isti predmet
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Močni ga ohranjajo pri življenju, tako da lahko še vedno dostopamo do predmeta.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // A ne več.
    /// // Lahko naredimo weak.as_ptr(), vendar dostop do kazalca vodi do nedefiniranega vedenja.
    /// // assert_eq! ("zdravo", nevarno {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Če kazalec visi, vrnemo stražo neposredno.
            // To ne more biti veljaven naslov koristnega tovora, saj je tovor vsaj tako poravnan kot RcBox (usize).
            ptr as *const T
        } else {
            // VARNOST: če is_dangling vrne false, potem kazalec ni mogoče referencirati.
            // Na tej točki lahko pade tovor, zato moramo ohraniti izvor, zato uporabite manipulacijo s surovim kazalcem.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Porabi `Weak<T>` in ga spremeni v neobdelan kazalec.
    ///
    /// To pretvori šibki kazalec v neobdelani kazalec, hkrati pa ohrani lastništvo ene šibke reference (šibko število s to operacijo ne spremeni).
    /// Z [`from_raw`] ga je mogoče spremeniti nazaj v `Weak<T>`.
    ///
    /// Veljajo enake omejitve dostopa do cilja kazalca kot pri [`as_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Neobdelani kazalnik, ki ga je prej ustvaril [`into_raw`], pretvori nazaj v `Weak<T>`.
    ///
    /// To lahko uporabite za varno pridobivanje močne reference (s poznejšim klicem [`upgrade`]) ali za sprostitev šibkega števila, tako da spustite `Weak<T>`.
    ///
    /// Prevzame lastništvo ene šibke reference (z izjemo kazalcev, ki jih je ustvaril [`new`], saj ti nimajo ničesar; metoda še vedno deluje na njih).
    ///
    /// # Safety
    ///
    /// Kazalec mora izvirati iz [`into_raw`] in mora imeti še vedno potencialno šibko referenco.
    ///
    /// V času klica je dovoljeno, da je število močnih 0.
    /// Kljub temu se prevzame lastništvo ene šibke reference, ki je trenutno predstavljena kot neobdelani kazalec (šibko število s to operacijo ne spremeni), zato jo je treba seznaniti s prejšnjim klicem na [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Zmanjšaj zadnje šibko število.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Glejte Weak::as_ptr za kontekst o tem, kako je izpeljan vhodni kazalec.

        let ptr = if is_dangling(ptr as *mut T) {
            // To je viseči šibek.
            ptr as *mut RcBox<T>
        } else {
            // V nasprotnem primeru imamo zajamčeno, da je kazalec prišel iz nezapletenega šibkega.
            // VARNOST: data_offset je varno poklicati, saj se ptr sklicuje na resnično (potencialno izpuščeno) T.
            let offset = unsafe { data_offset(ptr) };
            // Tako obrnemo odmik, da dobimo celoten RcBox.
            // VARNOST: kazalec izvira iz šibkega, zato je ta odmik varen.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // VARNOST: zdaj smo obnovili prvotni šibki kazalec, tako da lahko ustvarimo šibek.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Poskusi nadgradnje kazalca `Weak` na [`Rc`], če uspe, odložijo spuščanje notranje vrednosti.
    ///
    ///
    /// Vrne [`None`], če je bila notranja vrednost od takrat spuščena.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Uniči vse močne kazalce.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Pridobi število močnih kazalcev (`Rc`), ki kažejo na to dodelitev.
    ///
    /// Če je bil `self` ustvarjen z uporabo [`Weak::new`], bo to vrnilo 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Pridobi število kazalcev `Weak`, ki kažejo na to dodelitev.
    ///
    /// Če ne ostane noben močan kazalec, bo to vrnilo nič.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // odštejemo implicitni šibki ptr
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Vrne `None`, ko kazalec visi in ni dodeljenega `RcBox` (tj. Ko je `Weak` ustvaril `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Pazimo, da *ne* ustvarimo sklica, ki pokriva polje "data", saj lahko polje istočasno mutira (če na primer izpade zadnji `Rc`, bo podatkovno polje spuščeno na mestu).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Vrne `true`, če dva "šibka" kažeta na isto dodelitev (podobno kot [`ptr::eq`]) ali če oba ne kažeta na nobeno dodelitev (ker sta bili ustvarjeni z `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Ker to primerja kazalce, pomeni, da se bo `Weak::new()` izenačil, čeprav ne kažejo na nobeno dodelitev.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Primerjava `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Spusti kazalec `Weak`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Ne natisne ničesar
    /// drop(foo);        // Natisne "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // šibko štetje se začne pri 1 in se premakne na nič, če so izginili vsi močni kazalci.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Naredi klon kazalca `Weak`, ki kaže na isto dodelitev.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Konstruira nov `Weak<T>` in dodeli pomnilnik za `T`, ne da bi ga inicializiral.
    /// Poklic [`upgrade`] na vrnjeno vrednost vedno da [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Tu smo check_add za varno obravnavo mem::forget.Še posebej
// če uporabljate mem::forget Rcs (ali Weaks), lahko štetje ponovitev preseže in nato lahko sprostite dodelitev, medtem ko obstajajo neporavnani Rcs (ali Weaks).
//
// Prekinemo, ker gre za tako izroden scenarij, da nam je vseeno, kaj se zgodi-tega ne bi smel doživeti noben pravi program.
//
// To bi moralo imeti zanemarljive dodatne stroške, saj vam zaradi lastništva in semantike premikanja v Rust pravzaprav ni treba toliko klonirati.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Namesto da spustimo vrednost, želimo prekiniti prelivanje.
        // Število sklicev nikoli ne bo nič, ko je to poklicano;
        // kljub temu tu vstavimo prekinitev, da LLVM namigne na sicer zamujeno optimizacijo.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Namesto da spustimo vrednost, želimo prekiniti prelivanje.
        // Število sklicev nikoli ne bo nič, ko je to poklicano;
        // kljub temu tu vstavimo prekinitev, da LLVM namigne na sicer zamujeno optimizacijo.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// V `RcBox` dobite odmik koristnega tovora za kazalcem.
///
/// # Safety
///
/// Kazalec mora kazati na (in imeti veljavne metapodatke za) predhodno veljaven primerek T, vendar T lahko spustite.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Velikost v velikosti poravnajte na konec RcBox-a.
    // Ker je RcBox repr(C), bo to vedno zadnje polje v pomnilniku.
    // VARNOST: ker so edini možni tipi velikosti rezine, predmeti Portrait,
    // in zunanjih tipov je trenutno zahteva glede varnosti vnosa zadovoljiva zahtevam align_of_val_raw;to je izvedbena podrobnost jezika, na katero se zunaj std ni mogoče zanašati.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}