//! Niz, ki ga kodira UTF-8.
//!
//! Ta modul vsebuje tip [`String`], [`ToString`] Portrait za pretvorbo v nize in več vrst napak, ki lahko nastanejo pri delu z [`String`] s.
//!
//!
//! # Examples
//!
//! Obstaja več načinov za ustvarjanje novega [`String`] iz nizovnega dobesednega besedila:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Iz povezave obstoječega lahko ustvarite novega [`String`]
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Če imate vector veljavnih bajtov UTF-8, lahko iz njega naredite [`String`].Lahko tudi obratno.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Vemo, da so ti bajti veljavni, zato bomo uporabili `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// Niz, ki ga kodira UTF-8.
///
/// Tip `String` je najpogostejši tip niza, ki ima lastništvo nad vsebino niza.Ima tesne odnose s svojim izposojenim kolegom, primitivnim [`str`].
///
/// # Examples
///
/// `String` lahko ustvarite iz [a literal string][`str`] z [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// [`char`] lahko dodate `String` z metodo [`push`], [`&str`] pa z metodo [`push_str`]:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Če imate vector bajtov UTF-8, lahko iz njega ustvarite `String` z metodo [`from_utf8`]:
///
/// ```
/// // nekaj bajtov, v vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Vemo, da so ti bajti veljavni, zato bomo uporabili `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `Strune so vedno veljavne UTF-8.To ima nekaj posledic, od katerih je prva ta, da če potrebujete niz, ki ni UTF-8, razmislite o [`OsString`].Podobno je, vendar brez omejitve UTF-8.Druga posledica je, da v `String` ne morete indeksirati:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Indeksiranje naj bi bilo operacija s stalnim časom, toda kodiranje UTF-8 nam tega ne omogoča.Poleg tega ni jasno, kakšno stvar naj indeks vrne: bajt, kodno točko ali gručo grafem.
/// Metodi [`bytes`] in [`chars`] vrneta iteratorje v prvih dveh.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `String`s implementirajte [`Deref`] `<Target=str>`, in tako podedujte vse metode [`str`].Poleg tega to pomeni, da lahko `String` prenesete na funkcijo, ki sprejme [`&str`], z uporabo ampersanda (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// To bo ustvarilo [`&str`] iz `String` in ga posredovalo. Ta pretvorba je zelo poceni, zato funkcije na splošno sprejmejo ["&str`] s kot argumente, razen če zaradi nekega posebnega razloga potrebujejo `String`.
///
/// V nekaterih primerih Rust nima dovolj informacij za izvedbo te pretvorbe, znane kot prisila [`Deref`].V naslednjem primeru rezina niza [`&'a str`][`&str`] implementira Portrait `TraitExample`, funkcija `example_func` pa vse, kar implementira Portrait.
/// V tem primeru bi moral Rust narediti dve implicitni pretvorbi, kar Rust nima možnosti.
/// Iz tega razloga naslednji primer ne bo preveden.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Namesto tega obstajata dve možnosti.Prva bi bila sprememba vrstice `example_func(&example_string);` v `example_func(example_string.as_str());` z uporabo metode [`as_str()`] za izrecno ekstrakcijo rezine niza, ki vsebuje niz.
/// Drugi način spremeni `example_func(&example_string);` v `example_func(&*example_string);`.
/// V tem primeru preusmerimo `String` na [`str`][`&str`], nato pa [`str`][`&str`] napotimo nazaj na [`&str`].
/// Drugi način je bolj idiomatičen, vendar oba delata pretvorbo eksplicitno, ne pa da se zanašata na implicitno pretvorbo.
///
/// # Representation
///
/// `String` je sestavljen iz treh komponent: kazalca na nekaj bajtov, dolžine in kapacitete.Kazalec kaže na notranji vmesnik, ki ga `String` uporablja za shranjevanje svojih podatkov.Dolžina je število bajtov, ki so trenutno shranjeni v vmesnem pomnilniku, zmogljivost pa je velikost vmesnega pomnilnika v bajtih.
///
/// Kot taka bo dolžina vedno manjša ali enaka nosilnosti.
///
/// Ta vmesni pomnilnik je vedno shranjen na kopici.
///
/// Te si lahko ogledate z metodami [`as_ptr`], [`len`] in [`capacity`]:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Posodobite to, ko je vec_into_raw_parts stabiliziran.
/// // Preprečite samodejno spuščanje podatkov niza
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // zgodba ima devetnajst bajtov
/// assert_eq!(19, len);
///
/// // String lahko ponovno zgradimo iz ptr, len in zmogljivosti.
/// // Vse to ni varno, ker smo odgovorni za zagotavljanje veljavnosti komponent:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Če ima `String` dovolj zmogljivosti, mu dodajanje elementov ne bo dodelilo.Na primer, upoštevajte ta program:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// To bo prikazalo naslednje:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Sprva sploh nimamo dodeljenega pomnilnika, ko pa dodamo niz, ta ustrezno poveča njegovo zmogljivost.Če namesto tega najprej uporabimo metodo [`with_capacity`] za pravilno dodelitev zmogljivosti:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Na koncu dobimo drugačen izhod:
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Tu ni treba dodeliti več pomnilnika znotraj zanke.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Možna vrednost napake pri pretvorbi `String` iz bajta UTF-8 vector.
///
/// Ta vrsta je vrsta napake za metodo [`from_utf8`] na [`String`].
/// Zasnovan je tako, da se skrbno izogne ponovnim dodelitvam: metoda [`into_bytes`] bo vrnila bajt vector, ki je bil uporabljen pri poskusu pretvorbe.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// Tip [`Utf8Error`], ki ga zagotavlja [`std::str`], predstavlja napako, ki se lahko pojavi pri pretvorbi rezine [`u8`] s v [`&str`].
/// V tem smislu je analog `FromUtf8Error` in ga lahko dobite iz `FromUtf8Error` prek metode [`utf8_error`].
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Osnovna uporaba:
///
/// ```
/// // nekaj neveljavnih bajtov v vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Možna vrednost napake pri pretvorbi `String` iz bajtne rezine UTF-16.
///
/// Ta vrsta je vrsta napake za metodo [`from_utf16`] na [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Osnovna uporaba:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Ustvari nov prazen `String`.
    ///
    /// Glede na to, da je `String` prazen, to ne bo dodelilo nobenega začetnega medpomnilnika.Čeprav to pomeni, da je ta začetna operacija zelo poceni, lahko kasneje, ko dodate podatke, povzroči prekomerno dodeljevanje.
    ///
    /// Če imate idejo, koliko podatkov bo imel `String`, razmislite o metodi [`with_capacity`], da preprečite pretirano dodeljevanje.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Ustvari nov prazen `String` z določeno zmogljivostjo.
    ///
    /// `Nizi imajo notranji vmesni pomnilnik za shranjevanje svojih podatkov.
    /// Kapaciteta je dolžina tega vmesnega pomnilnika in se lahko poizvede z metodo [`capacity`].
    /// Ta metoda ustvari prazen `String`, vendar takega z začetnim vmesnim pomnilnikom, ki lahko vsebuje bajte `capacity`.
    /// To je koristno, če morda `String` pripisujete kup podatkov in tako zmanjšate število prerazporeditev, ki jih mora opraviti.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Če je dana zmogljivost `0`, dodelitev ne bo prišlo, ta metoda pa je enaka metodi [`new`].
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // String ne vsebuje znakov, čeprav je zmožen več
    /// assert_eq!(s.len(), 0);
    ///
    /// // Vse je narejeno brez prerazporeditve ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... vendar lahko to povzroči prerazporeditev niza
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): pri cfg(test) lastna metoda `[T]::to_vec`, ki je potrebna za to definicijo metode, ni na voljo.
    // Ker te metode ne potrebujemo za namene testiranja, jo bom samo opozoril. Za več informacij glejte modul slice::hack v slice.rs
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Pretvori vector bajtov v `String`.
    ///
    /// Niz ([`String`]) je sestavljen iz bajtov ([`u8`]), vector bajtov ([`Vec<u8>`]) pa iz bajtov, zato se ta funkcija pretvori med obema.
    /// Vse rezine bajtov niso veljavne `String-ove ', vendar `String` zahteva, da je veljaven UTF-8.
    /// `from_utf8()` preveri, ali so bajti veljavni UTF-8, in nato izvede pretvorbo.
    ///
    /// Če ste prepričani, da je rezina bajtov veljavna UTF-8, in ne želite, da bi prišlo do dodatnih stroškov preverjanja veljavnosti, obstaja nevarna različica te funkcije, [`from_utf8_unchecked`], ki ima enako vedenje, vendar preskoči preskus.
    ///
    ///
    /// Ta metoda bo zaradi učinkovitosti preprečila kopiranje vector.
    ///
    /// Če namesto `String` potrebujete [`&str`], razmislite o [`str::from_utf8`].
    ///
    /// Inverzna metoda je [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Vrne [`Err`], če rezina ni UTF-8, z opisom, zakaj navedeni bajti niso UTF-8.Vključen je tudi vector, v katerega ste se preselili.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// // nekaj bajtov, v vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Vemo, da so ti bajti veljavni, zato bomo uporabili `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Napačni bajti:
    ///
    /// ```
    /// // nekaj neveljavnih bajtov v vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Za več podrobnosti o tem, kaj lahko storite s to napako, si oglejte dokumentacijo za [`FromUtf8Error`].
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Pretvori rezino bajtov v niz, vključno z neveljavnimi znaki.
    ///
    /// Strune so narejene iz bajtov ([`u8`]), rezina bajtov ([`&[u8]`][byteslice]) pa iz bajtov, zato se ta funkcija pretvori med obema.Vse rezine bajtov niso veljavni nizi, vendar morajo biti nizi veljavni UTF-8.
    /// Med to pretvorbo bo `from_utf8_lossy()` zamenjal vsa neveljavna zaporedja UTF-8 z [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], ki je videti takole:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Če ste prepričani, da je rezina bajtov veljavna UTF-8, in ne želite, da bi prišlo do dodatnih stroškov pretvorbe, obstaja nevarna različica te funkcije, [`from_utf8_unchecked`], ki ima enako vedenje, vendar preskoči preverjanja.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Ta funkcija vrne [`Cow<'a, str>`].Če je naša bajtna rezina neveljavna UTF-8, potem moramo vstaviti nadomestne znake, ki bodo spremenili velikost niza in zato zahtevajo `String`.
    /// Če pa je že veljaven UTF-8, nove dodelitve ne potrebujemo.
    /// Ta vrsta vrnitve nam omogoča, da obravnavamo oba primera.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// // nekaj bajtov, v vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Napačni bajti:
    ///
    /// ```
    /// // nekaj neveljavnih bajtov
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Dekodirajte U0F-16 kodiran vector `v` v `String` in vrnite [`Err`], če `v` vsebuje neveljavne podatke.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // To se ne naredi z zbiranjem: : <Result<_, _>> () zaradi razlogov uspešnosti.
        // FIXME: funkcijo lahko znova poenostavite, ko je #48994 zaprt.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Dešifrirajte rezin `v`, kodiran z UTF-16, v `String` in neveljavne podatke zamenjajte z [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// Za razliko od [`from_utf8_lossy`], ki vrne [`Cow<'a, str>`], `from_utf16_lossy` vrne `String`, saj pretvorba UTF-16 v UTF-8 zahteva dodelitev pomnilnika.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Razgradi `String` v njegove surove komponente.
    ///
    /// Vrne neobdelani kazalnik na osnovne podatke, dolžino niza (v bajtih) in dodeljeno kapaciteto podatkov (v bajtih).
    /// To so enaki argumenti v enakem vrstnem redu kot argumenti za [`from_raw_parts`].
    ///
    /// Po klicu te funkcije je klicatelj odgovoren za pomnilnik, ki ga je prej upravljal `String`.
    /// Edini način za to je pretvorba neobdelanega kazalca, dolžine in zmogljivosti nazaj v `String` s funkcijo [`from_raw_parts`], kar destruktorju omogoči izvedbo čiščenja.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Ustvari nov `String` iz dolžine, zmogljivosti in kazalca.
    ///
    /// # Safety
    ///
    /// To je zelo nevarno zaradi števila invariantov, ki niso preverjeni:
    ///
    /// * Spomin na `buf` mora predhodno dodeliti isti razdelilnik, ki ga uporablja standardna knjižnica, z zahtevano poravnavo natančno 1.
    /// * `length` mora biti manjši ali enak `capacity`.
    /// * `capacity` mora biti pravilna vrednost.
    /// * Prvi bajti `length` na `buf` morajo biti veljavni UTF-8.
    ///
    /// Kršitev le-teh lahko povzroči težave, kot je poškodovanje notranjih podatkovnih struktur razdeljevalca.
    ///
    /// Lastništvo `buf` se dejansko prenese na `String`, ki lahko nato sprosti, prerazporedi ali spremeni vsebino pomnilnika, na katero kaže kazalnik.
    /// Prepričajte se, da nič drugega ne uporablja kazalca po klicu te funkcije.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Posodobite to, ko je vec_into_raw_parts stabiliziran.
    ///     // Preprečite samodejno spuščanje podatkov niza
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Pretvori vector bajtov v `String`, ne da bi preveril, ali niz vsebuje veljaven UTF-8.
    ///
    /// Za več podrobnosti glejte varno različico [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Ta funkcija ni varna, ker ne preverja, ali so ji posredovani bajti veljavni UTF-8.
    /// Če se ta omejitev krši, lahko povzroči težave z varnostjo pomnilnika pri uporabnikih UTF-8 future, saj v preostali standardni knjižnici domnevamo, da so "String" veljavni UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// // nekaj bajtov, v vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Pretvori `String` v bajt vector.
    ///
    /// To porabi `String`, zato nam ni treba kopirati njegove vsebine.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Izvleče rezino niza, ki vsebuje celoten `String`.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Pretvori `String` v spremenljivo rezino niza.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Doda dodano rezino niza na konec tega `String`.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Vrne zmogljivost tega niza v bajtih.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Zagotavlja, da je zmogljivost tega niza vsaj `additional` bajtov večja od njegove dolžine.
    ///
    /// Kapaciteta se lahko poveča, če se odloči, za več kot `additional` bajtov, da se preprečijo pogoste prerazporeditve.
    ///
    ///
    /// Če tega obnašanja "at least" ne želite, glejte metodo [`reserve_exact`].
    ///
    /// # Panics
    ///
    /// Panics, če nova zmogljivost preseže [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// To dejansko ne bo povečalo zmogljivosti:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s ima dolžino 2 in zmogljivost 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Ker imamo že dodatnih 8 zmogljivosti, lahko to pokličete ...
    /// s.reserve(8);
    ///
    /// // ... se dejansko ne poveča.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Zagotavlja, da je zmogljivost tega niza `additional` bajtov večja od njegove dolžine.
    ///
    /// Razmislite o uporabi metode [`reserve`], razen če ne veste bolje od razdeljevalca.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics, če nova zmogljivost preseže `usize`.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// To dejansko ne bo povečalo zmogljivosti:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s ima dolžino 2 in zmogljivost 10
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Ker imamo že dodatnih 8 zmogljivosti, lahko to pokličete ...
    /// s.reserve_exact(8);
    ///
    /// // ... se dejansko ne poveča.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Poskuša rezervirati zmogljivost za vsaj `additional` več elementov, ki jih je treba vstaviti v dani `String`.
    /// Zbirka lahko rezervira več prostora, da se izogne pogostim prerazporeditvam.
    /// Po klicu `reserve` bo zmogljivost večja ali enaka `self.len() + additional`.
    /// Ne stori nič, če je zmogljivost že zadostna.
    ///
    /// # Errors
    ///
    /// Če zmogljivost preseže ali razdeljevalec poroča o napaki, se vrne napaka.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Predhodno rezervirajte pomnilnik in zapustite, če ne moremo
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Zdaj vemo, da tega sredi zapletenega dela ne moremo OOM
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Poskuša rezervirati minimalno zmogljivost za natančno `additional` več elementov, ki jih je treba vstaviti v dani `String`.
    ///
    /// Po klicu `reserve_exact` bo zmogljivost večja ali enaka `self.len() + additional`.
    /// Nič ne naredi, če je zmogljivost že zadostna.
    ///
    /// Upoštevajte, da lahko razdeljevalnik da zbirki več prostora, kot zahteva.
    /// Zato se ni mogoče zanašati na to, da je zmogljivost povsem minimalna.
    /// Dajte prednost `reserve`, če pričakujete vstavke future.
    ///
    /// # Errors
    ///
    /// Če zmogljivost preseže ali razdeljevalec poroča o napaki, se vrne napaka.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Predhodno rezervirajte pomnilnik in zapustite, če ne moremo
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Zdaj vemo, da tega sredi zapletenega dela ne moremo OOM
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Zmanjša zmogljivost tega `String`, da ustreza njegovi dolžini.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Zmanjša zmogljivost tega `String` z spodnjo mejo.
    ///
    /// Kapaciteta bo ostala vsaj tako velika, kot sta dolžina in dobavljena vrednost.
    ///
    ///
    /// Če je trenutna zmogljivost manjša od spodnje meje, to ne velja.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Dani [`char`] doda na konec tega `String`.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Vrne rezino bajtov vsebine tega niza.
    ///
    /// Inverzna metoda je [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Skrajša ta `String` na določeno dolžino.
    ///
    /// Če je `new_len` večja od trenutne dolžine niza, to ne vpliva.
    ///
    ///
    /// Upoštevajte, da ta metoda ne vpliva na dodeljeno kapaciteto niza
    ///
    /// # Panics
    ///
    /// Panics, če `new_len` ne leži na meji [`char`].
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Odstrani zadnji znak iz medpomnilnika niza in ga vrne.
    ///
    /// Vrne [`None`], če je ta `String` prazen.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Odstrani [`char`] iz tega `String` v bajtnem položaju in ga vrne.
    ///
    /// To je operacija *O*(*n*), saj zahteva kopiranje vseh elementov v medpomnilniku.
    ///
    /// # Panics
    ///
    /// Panics, če je `idx` večja ali enaka dolžini "niza" ali če ne leži na meji [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Odstranite vsa ujemanja vzorca `pat` v modelu `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Ujemanja bodo zaznana in odstranjena iteracijsko, zato bo v primerih, ko se vzorci prekrivajo, odstranjen samo prvi vzorec:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // VARNOST: začetek in konec bosta na mejah bajtov utf8 na
        // dokumenti iskalca
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Obdrži samo znake, ki jih določa predikat.
    ///
    /// Z drugimi besedami, odstranite vse znake `c`, tako da `f(c)` vrne `false`.
    /// Ta metoda deluje na mestu, obišče vsak znak natančno enkrat v prvotnem vrstnem redu in ohrani vrstni red zadržanih znakov.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Natančen vrstni red je lahko koristen za sledenje zunanjemu stanju, kot je indeks.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Usmerite idx na naslednji znak
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// V ta znak `String` vstavi bajt.
    ///
    /// To je operacija *O*(*n*), saj zahteva kopiranje vseh elementov v medpomnilniku.
    ///
    /// # Panics
    ///
    /// Panics, če je `idx` večja od dolžine "niza" ali če ne leži na meji [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Vstavite rezino niza v ta `String` v bajtnem položaju.
    ///
    /// To je operacija *O*(*n*), saj zahteva kopiranje vseh elementov v medpomnilniku.
    ///
    /// # Panics
    ///
    /// Panics, če je `idx` večja od dolžine "niza" ali če ne leži na meji [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Vrne spremenljiv sklic na vsebino tega `String`.
    ///
    /// # Safety
    ///
    /// Ta funkcija ni varna, ker ne preverja, ali so ji posredovani bajti veljavni UTF-8.
    /// Če se ta omejitev krši, lahko povzroči težave z varnostjo pomnilnika pri uporabnikih UTF-8 future, saj v preostali standardni knjižnici domnevamo, da so "String" veljavni UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Vrne dolžino tega `String` v bajtih, ne v [`char`] ali grafemah.
    /// Z drugimi besedami, morda človek ne šteje za dolžino vrvice.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Vrne `true`, če ima ta `String` nič, `false` pa drugače.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Niz razdeli na dva pri danem bajtnem indeksu.
    ///
    /// Vrne na novo dodeljeni `String`.
    /// `self` vsebuje bajte `[0, at)`, vrnjeni `String` pa bajte `[at, len)`.
    /// `at` mora biti na meji kodne točke UTF-8.
    ///
    /// Upoštevajte, da se zmogljivost `self` ne spreminja.
    ///
    /// # Panics
    ///
    /// Panics, če `at` ni na meji kodne točke `UTF-8` ali če presega zadnjo kodno točko niza.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Skrajša ta `String` in odstrani vso vsebino.
    ///
    /// Čeprav to pomeni, da bo `String` dolžine nič, se ne bo dotaknil njegove zmogljivosti.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Ustvari odtočni iterator, ki odstrani določen obseg v `String` in ustvari odstranjeni `chars`.
    ///
    ///
    /// Note: Obseg elementov se odstrani, tudi če iteratorja ne porabimo do konca.
    ///
    /// # Panics
    ///
    /// Panics, če začetna ali končna točka ne leži na meji [`char`] ali če je zunaj meja.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Odstranite obseg do β iz niza
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Celoten obseg počisti niz
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Varnost spomina
        //
        // Različica String Drain nima težav z varnostjo pomnilnika različice vector.
        // Podatki so samo navadni bajti.
        // Ker se odstranjevanje obsega zgodi v Drop, če iterator Drain pušča, odstranitev ne bo prišlo.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Vzemite dve hkratni posojili.
        // String &mut ne bo dostopen, dokler se ponovitev v Drop ne konča.
        let self_ptr = self as *mut _;
        // VARNOST: `slice::range` in `is_char_boundary` opravita ustrezna preverjanja meja.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Odstrani navedeni obseg v nizu in ga nadomesti z danim nizom.
    /// Dani niz ne sme biti enake dolžine kot obseg.
    ///
    /// # Panics
    ///
    /// Panics, če začetna ali končna točka ne leži na meji [`char`] ali če je zunaj meja.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Zamenjajte obseg navzgor, dokler β iz niza
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Varnost spomina
        //
        // Replace_range nima težav z varnostjo pomnilnika spojke vector.
        // različice vector.Podatki so samo navadni bajti.

        // OPOZORILO: Vključitev te spremenljivke bi bila neustrezna (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // OPOZORILO: Vključitev te spremenljivke bi bila neustrezna (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Ponovna uporaba `range` bi bila nesmiselna (#81138) Predvidevamo, da meje, o katerih poroča `range`, ostajajo enake, vendar se lahko kontradiktorna izvedba med klici spremeni
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Pretvori ta `String` v [`Box`]`<`[`str`] `>`.
    ///
    /// To bo zmanjšalo vse presežne zmogljivosti.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Vrne rezino bajtov [`u8`], ki so jih poskušali pretvoriti v `String`.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// // nekaj neveljavnih bajtov v vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Vrne bajte, ki so jih poskušali pretvoriti v `String`.
    ///
    /// Ta metoda je skrbno izdelana, da se prepreči dodelitev.
    /// Napako bo porabil in premaknil bajte, tako da kopije bajtov ni treba narediti.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// // nekaj neveljavnih bajtov v vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Pridobite `Utf8Error`, če želite več podrobnosti o neuspešni pretvorbi.
    ///
    /// Tip [`Utf8Error`], ki ga zagotavlja [`std::str`], predstavlja napako, ki se lahko pojavi pri pretvorbi rezine [`u8`] s v [`&str`].
    /// V tem smislu je analog `FromUtf8Error`.
    /// Za več podrobnosti o uporabi glejte njegovo dokumentacijo.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// // nekaj neveljavnih bajtov v vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // prvi bajt je tukaj neveljaven
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Ker se ponavljamo preko nizov, se lahko izognemo vsaj eni dodelitvi, tako da iz iteratorja pridobimo prvi niz in mu dodamo vse nadaljnje nize.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Ker ponavljamo CoW, se lahko (potentially) izognemo vsaj eni dodelitvi, tako da dobimo prvi element in mu dodamo vse naslednje elemente.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Priročen impl, ki prenese na impl za `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Ustvari prazen `String`.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Izvaja operater `+` za združevanje dveh nizov.
///
/// Ta porabi `String` na levi strani in ponovno uporabi medpomnilnik (po potrebi ga poveča).
/// To se naredi, da bi se izognili dodelitvi novega `String` in kopiranju celotne vsebine pri vsaki operaciji, kar bi pri ponavljajočem združevanju povzročilo čas delovanja *O*(*n*^ 2) pri gradnji niza z *n* bajtov.
///
///
/// Struna na desni strani je samo izposojena;njegova vsebina se kopira v vrnjeni `String`.
///
/// # Examples
///
/// Združevanje dveh nizov vzame prvega po vrednosti in izposodi drugega:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` je premaknjen in ga tukaj ni več mogoče uporabiti.
/// ```
///
/// Če želite še naprej uporabljati prvi `String`, ga lahko klonirate in namesto njega dodate:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` tukaj še vedno velja.
/// ```
///
/// Združevanje rezin `&str` lahko izvedete s pretvorbo prvega v `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Implementira operater `+=` za dodajanje `String`.
///
/// Ta ima enako vedenje kot metoda [`push_str`][String::push_str].
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Tip vzdevek za [`Infallible`].
///
/// Ta vzdevek obstaja za povratno združljivost in bo morda sčasoma zastarel.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// Portrait za pretvorbo vrednosti v `String`.
///
/// Ta Portrait se samodejno izvede za katero koli vrsto, ki izvaja [`Display`] Portrait.
/// Kot takega `ToString` ne bi smeli izvajati neposredno:
/// [`Display`] namesto tega implementirati, `ToString` pa dobite brezplačno.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Pretvori dano vrednost v `String`.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// V tej izvedbi metoda `to_string` panics, če izvedba `Display` vrne napako.
/// To pomeni nepravilno izvedbo `Display`, saj `fmt::Write for String` nikoli ne vrne napake.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Pogosto vodilo je, da ne vstavite generičnih funkcij.
    // Vendar odstranitev `#[inline]` iz te metode povzroči zanemarljive regresije.
    // Glejte <https://github.com/rust-lang/rust/pull/74852>, zadnji poskus poskusa odstranitve.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Pretvori `&mut str` v `String`.
    ///
    /// Rezultat je razdeljen na kup.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: test potegne libstd, kar tukaj povzroča napake
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Pretvori dano zarezano rezino `str` v `String`.
    /// Omeniti velja, da je rezina `str` v lasti.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Pretvori dani `String` v zapakirano rezino `str`, ki je v lasti.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Pretvori rezino niza v Izposojeno različico.
    /// Dodelitev kopice ni izvedena in niz ni kopiran.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Pretvori niz v lastniško različico.
    /// Dodelitev kopice ni izvedena in niz ni kopiran.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Pretvori sklic na niz v izposojeno različico.
    /// Dodelitev kopice ni izvedena in niz ni kopiran.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Pretvori dani `String` v vector `Vec`, ki vsebuje vrednosti tipa `u8`.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// Odtočni iterator za `String`.
///
/// Ta struktura je ustvarjena z metodo [`drain`] na [`String`].
/// Za več si oglejte njegovo dokumentacijo.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Uporablja se kot&'a mut glas v destruktorju
    string: *mut String,
    /// Začetek dela za odstranitev
    start: usize,
    /// Konec dela, ki ga želite odstraniti
    end: usize,
    /// Trenutni preostali obseg za odstranitev
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Uporabite Vec::drain.
            // "Reaffirm" meje preveri, da se prepreči ponovno vstavljanje kode panic.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Vrne preostali (pod) niz tega iteratorja kot rezino.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: razkomentirajte AsRef spodaj pri stabilizaciji.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Nekomentirajte pri stabilizaciji `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>za Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> za Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}