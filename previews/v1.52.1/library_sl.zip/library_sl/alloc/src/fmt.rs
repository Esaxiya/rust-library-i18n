//! Pripomočki za formatiranje in tiskanje `String`s.
//!
//! Ta modul vsebuje izvajalno podporo za sintaksno razširitev [`format!`].
//! Ta makro je v prevajalniku implementiran tako, da oddaja klice temu modulu, da oblikuje argumente med izvajanjem v nize.
//!
//! # Usage
//!
//! Makro [`format!`] naj bi bil poznan tistim, ki prihajajo iz funkcij C `printf`/`fprintf` ali funkcije `str.format` Python.
//!
//! Nekaj primerov razširitve [`format!`] je:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" z vodilnimi ničlami
//! ```
//!
//! Iz teh lahko vidite, da je prvi argument niz oblike.Prevajalnik zahteva, da je to niz literal;ne more biti posredovana spremenljivka (za izvajanje preverjanja veljavnosti).
//! Prevajalnik bo nato razčlenil niz oblike in ugotovil, ali je seznam podanih argumentov primeren za posredovanje v ta niz oblike.
//!
//! Če želite eno vrednost pretvoriti v niz, uporabite metodo [`to_string`].Pri tem bo uporabljeno oblikovanje [`to_string`] Portrait.
//!
//! ## Pozicijski parametri
//!
//! Vsak argument oblikovanja lahko poda, na kateri argument vrednosti se sklicuje, in če je izpuščen, se domneva, da je "the next argument".
//! Niz formatiranja `{} {} {}` bi na primer zajemal tri parametre in bili bi formatirani v enakem vrstnem redu, kot so navedeni.
//! Niz formatiranja `{2} {1} {0}` pa bi argumente formatiral v obratnem vrstnem redu.
//!
//! Stvari lahko postanejo nekoliko zapletene, ko začnete mešati dve vrsti položajnih specifikatorjev.Specifikator "next argument" si lahko predstavljamo kot iterator nad argumentom.
//! Vsakič, ko je prikazan specifikator "next argument", iterator napreduje.To vodi do takšnega vedenja:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Notranji iterator nad argumentom ni bil napreden, ko je prikazan prvi `{}`, zato natisne prvi argument.Potem, ko je dosegel drugi `{}`, je iterator napredoval naprej do drugega argumenta.
//! V bistvu parametri, ki izrecno poimenujejo svoj argument, ne vplivajo na parametre, ki ne poimenujejo argumenta v smislu položajnih specifikatorjev.
//!
//! Za uporabo vseh njegovih argumentov je potreben niz oblike, sicer gre za napako časa prevajanja.Na isti argument se lahko večkrat sklicujete v nizu oblike.
//!
//! ## Poimenovani parametri
//!
//! Rust sam po sebi nima Python podobnega imenovanih parametrov funkciji, vendar je makro [`format!`] sintaksna razširitev, ki mu omogoča, da izkoristi imenovane parametre.
//! Imenovani parametri so navedeni na koncu seznama argumentov in imajo sintakso:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Na primer, vsi naslednji izrazi [`format!`] uporabljajo imenovani argument:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Za argumente z imeni ni veljavno postavljati pozicijskih parametrov (tistih brez imen).Tako kot pri pozicijskih parametrih ni veljavno navesti imenovanih parametrov, ki jih formatni niz ne uporablja.
//!
//! # Parametri formatiranja
//!
//! Vsak argument, ki ga formatiramo, je mogoče pretvoriti s številnimi parametri formatiranja (kar ustreza `format_spec` v [the syntax](#syntax)). Ti parametri vplivajo na nizovno predstavitev tega, kar formatiramo.
//!
//! ## Width
//!
//! ```
//! // Vse to natisne "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! To je parameter za "minimum width", ki naj ga zavzame oblika.
//! Če niz vrednosti ne zapolni toliko znakov, bo zapolnitev zahtevanega prostora uporabljeno z oblazinjenjem, ki ga določi fill/alignment (glej spodaj).
//!
//! Vrednost za širino lahko na seznamu parametrov navedete tudi kot [`usize`], tako da dodate postfix `$`, kar pomeni, da je drugi argument [`usize`], ki določa širino.
//!
//! Sklicevanje na argument s sintakso dolarja ne vpliva na števec "next argument", zato je običajno dobro, da se na argumente sklicujete po položaju ali uporabite imenovane argumente.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Izbirni znak za polnjenje in poravnava sta običajno na voljo skupaj s parametrom [`width`](#width).Določiti ga je treba pred `width`, takoj za `:`.
//! To pomeni, da če bo vrednost, ki jo formatirate, manjša od `width`, bodo okoli nje natisnjeni nekateri dodatni znaki.
//! Polnjenje je na voljo v naslednjih različicah za različne poravnave:
//!
//! * `[fill]<` - argument je poravnan levo v stolpcih `width`
//! * `[fill]^` - argument je poravnan na sredino v stolpcih `width`
//! * `[fill]>` - argument je poravnan desno v stolpcih `width`
//!
//! Privzeti [fill/alignment](#fillalignment) za neštevilske vrednosti je presledek in poravnan levo.Privzeto za številske oblikovalnike je tudi presledek, vendar z desno poravnavo.
//! Če je za številke podana zastavica `0` (glej spodaj), je implicitni znak za polnjenje `0`.
//!
//! Upoštevajte, da nekatere vrste poravnave morda ne bodo izvedle.Zlasti se običajno ne uporablja za `Debug` Portrait.
//! Dober način za zagotovitev, da se uporabi oblazinjenje, je formatiranje vnosa, nato pa ta nastali niz podložite tako, da dobite izhod:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Pozdravljeni Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Vse to so zastavice, ki spreminjajo vedenje oblikovalca.
//!
//! * `+` - To je namenjeno številskim vrstam in pomeni, da je treba znak vedno natisniti.Pozitivni znaki se privzeto nikoli ne natisnejo, negativni znaki pa se privzeto natisnejo samo za `Signed` Portrait.
//! Ta zastavica pomeni, da je treba vedno natisniti pravi znak (`+` ali `-`).
//! * `-` - Trenutno se ne uporablja
//! * `#` - Ta zastavica pomeni, da je treba uporabiti obliko tiskanja "alternate".Nadomestni obrazci so:
//!     * `#?` - lepo natisnite oblikovanje [`Debug`]
//!     * `#x` - pred argumentom z `0x`
//!     * `#X` - pred argumentom z `0x`
//!     * `#b` - pred argumentom z `0b`
//!     * `#o` - pred argumentom z `0o`
//! * `0` - To se uporablja za celoštevilčne formate, da je treba oblazinjenje do `width` izvesti z znakom `0` in se zavedati znakov.
//! Oblika, kot je `{:08}`, bi za celo število `1` dala `00000001`, medtem ko bi enaka oblika dala `-0000001` za celo število `-1`.
//! Upoštevajte, da ima negativna različica eno nič manj kot pozitivna različica.
//!         Upoštevajte, da so ničelne ničle vedno postavljene za znakom (če obstaja) in pred števkami.Kadar se uporablja skupaj z zastavico `#`, velja podobno pravilo: polnilne ničle se vstavijo za predpono, vendar pred števkami.
//!         Predpona je vključena v skupno širino.
//!
//! ## Precision
//!
//! Za neštevilske tipe je to mogoče šteti za "maximum width".
//! Če je dobljeni niz daljši od te širine, se skrajša na toliko znakov in ta okrnjena vrednost se odda z ustreznimi `fill`, `alignment` in `width`, če so ti parametri nastavljeni.
//!
//! Pri integralnih vrstah se to prezre.
//!
//! Za vrste s plavajočo vejico to označuje, koliko števk za decimalno vejico je treba natisniti.
//!
//! Obstajajo trije možni načini določanja želenega `precision`:
//!
//! 1. Celo število `.N`:
//!
//!    celo število `N` je natančnost.
//!
//! 2. Celo število ali ime, ki mu sledi znak za dolar `.N$`:
//!
//!    za natančnost uporabite argument *format*`N` (ki mora biti `usize`).
//!
//! 3. Zvezdica `.*`:
//!
//!    `.*` pomeni, da je ta `{...}` povezan z dvema vhodoma formata * in ne z enim: prvi vhod vsebuje natančnost `usize`, drugi pa vrednost za tiskanje.
//!    Upoštevajte, da v tem primeru, če nekdo uporablja niz formata `{<arg>:<spec>.*}`, se del `<arg>` sklicuje na* vrednost * za tiskanje, `precision` pa mora biti v vhodu pred `<arg>`.
//!
//! Na primer, vsi naslednji klici tiskajo isto `Hello x is 0.01000`:
//!
//! ```
//! // Pozdravljeni {arg 0 ("x")} je {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Pozdravljeni {arg 1 ("x")} je {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Pozdravljeni {arg 0 ("x")} je {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Pozdravljeni {next arg ("x")} je {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Pozdravljeni {next arg ("x")} je {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Pozdravljeni {next arg ("x")} je {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Medtem ko ti:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! natisnite tri bistveno različne stvari:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! V nekaterih programskih jezikih je vedenje funkcij oblikovanja nizov odvisno od nastavitve krajevne nastavitve operacijskega sistema.
//! Funkcije oblikovanja, ki jih nudi standardna knjižnica Rust, nimajo nobenega koncepta področne nastavitve in bodo v vseh sistemih prinesle enake rezultate, ne glede na uporabniško konfiguracijo.
//!
//! Na primer, naslednja koda bo vedno natisnila `1.5`, tudi če sistemski jezik uporablja decimalno ločilo, ki ni pika.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Dobesedni znaki `{` in `}` se lahko vključijo v niz tako, da se pred njimi nahaja isti znak.Na primer, znak `{` se izogne z `{{`, znak `}` pa z `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Če povzamemo, tukaj lahko najdete celotno slovnico nizov formatov.
//! Sintaksa uporabljenega jezika za oblikovanje je črpana iz drugih jezikov, zato ne sme biti preveč tuja.Argumenti so formatirani z Python-podobno sintakso, kar pomeni, da so argumenti namesto X-X podobni X-X.
//! Dejanska slovnica za sintakso oblikovanja je:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! V zgornji slovnici `text` ne sme vsebovati nobenih znakov `'{'` ali `'}'`.
//!
//! # Oblikovanje traits
//!
//! Ko zahtevate oblikovanje argumenta z določeno vrsto, pravzaprav zahtevate, da se argument pripiše določenemu Portrait.
//! To omogoča formatiranje več dejanskih tipov prek `{:x}` (na primer [`i8`] in [`isize`]).Trenutno preslikava tipov v traits je:
//!
//! * *nič* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] z majhnimi šestnajstiškimi celoštevilskimi števili
//! * `X?` ⇒ [`Debug`] z velikimi šestnajstiškimi celimi številkami
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! To pomeni, da je mogoče katero koli vrsto argumenta, ki implementira [`fmt::Binary`][`Binary`] Portrait, formatirati z `{:b}`.Za te traits je za standardne knjižnice predvidena tudi izvedba za številne primitivne tipe.
//!
//! Če ni določena nobena oblika (kot v `{}` ali `{:6}`), potem je uporabljena oblika Portrait [`Display`] Portrait.
//!
//! Ko izvajate format Portrait za svoj tip, boste morali uporabiti metodo podpisa:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // naš tip po meri
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Vaša vrsta bo posredovana kot referenčna referenca `self`, nato pa mora funkcija oddajati izhod v tok `f.buf`.Vsaka oblika zapisa Portrait je odvisna od pravilnega upoštevanja zahtevanih parametrov formatiranja.
//! Vrednosti teh parametrov bodo navedene v poljih strukture [`Formatter`].Za pomoč pri tem nudi struktura [`Formatter`] tudi nekaj pomožnih metod.
//!
//! Poleg tega je vrnjena vrednost te funkcije [`fmt::Result`], ki je vzdevek tipa [`Rezultat`]`<(),`[`std: : fmt::Error`] `` `.
//! Izvedbe formatiranja bi morale zagotoviti, da širijo napake iz [`Formatter`] (npr. Med klicanjem [`write!`]).
//! Nikoli pa ne smejo napačno vrniti napak.
//! To pomeni, da mora izvedba oblikovanja vrniti napako in jo lahko vrne le, če posredovani [`Formatter`] vrne napako.
//! To je zato, ker je oblikovanje nizov v nasprotju s tem, kar bi lahko predlagal podpis funkcije, nezmotljiva operacija.
//! Ta funkcija vrne le rezultat, ker zapisovanje v osnovni tok morda ne bo uspelo in mora zagotoviti način za razširjanje dejstva, da je prišlo do napake nazaj v sklad.
//!
//! Primer izvedbe oblikovanja traits bi bil videti tako:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Vrednost `f` implementira `Write` Portrait, kar piše!makro pričakuje.
//!         // Upoštevajte, da to oblikovanje prezre različne zastavice, ki so na voljo za oblikovanje nizov.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Različne traits omogočajo različne oblike izpisa tipa.
//! // Pomen tega formata je natisniti velikost vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Spoštujte zastavice formatiranja z uporabo pomožne metode `pad_integral` na objektu Formatter.
//!         // Za podrobnosti glejte dokumentacijo metode, funkcijo `pad` pa lahko uporabite za vstavljanje nizov.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` v primerjavi z `fmt::Debug`
//!
//! Ti dve obliki oblikovanja traits imata različna namena:
//!
//! - [`fmt::Display`][`Display`] izvedbe trdijo, da je tip lahko ves čas zvesto predstavljen kot niz UTF-8.**Ne** se pričakuje, da vsi tipi izvajajo [`Display`] Portrait.
//! - [`fmt::Debug`][`Debug`] izvedbe je treba izvajati za **vse** javne tipe.
//!   Rezultat bo ponavadi čim bolj natančno predstavljal notranje stanje.
//!   Namen [`Debug`] Portrait je olajšati razhroščevanje kode Rust.V večini primerov je uporaba `#[derive(Debug)]` zadostna in priporočljiva.
//!
//! Nekaj primerov izhodnih podatkov iz obeh traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Sorodni makri
//!
//! V družini [`format!`] je več povezanih makrov.Trenutno se izvajajo:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Ta in [`writeln!`] sta dva makra, ki se uporabljata za oddajanje niza oblike v določen tok.To se uporablja za preprečevanje vmesnih dodelitev nizov formatov in namesto tega neposredno zapisuje izhodne podatke.
//! Pod pokrovom ta funkcija dejansko prikliče funkcijo [`write_fmt`], definirano na [`std::io::Write`] Portrait.
//! Primer uporabe je:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Ta in [`println!`] oddata svoj izhod v stdout.Podobno kot makro [`write!`] je tudi cilj teh makrov izogibanje vmesnim dodelitvam pri tiskanju.Primer uporabe je:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Makronaredbi [`eprint!`] in [`eprintln!`] sta enaki [`print!`] oziroma [`println!`], le da oddata svoj izhod v stderr.
//!
//! ### `format_args!`
//!
//! To je nenavaden makro, ki se uporablja za varno podajanje okoli neprozornega predmeta, ki opisuje niz oblikovanja.Ta objekt za izdelavo ne zahteva dodeljevanja kopice in se sklicuje samo na informacije v skladu.
//! Pod pokrovom so v zvezi s tem izvedeni vsi povezani makri.
//! Najprej je nekaj primerov uporabe:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Rezultat makra [`format_args!`] je vrednost tipa [`fmt::Arguments`].
//! Nato lahko to strukturo posredujete funkciji [`write`] in [`format`] znotraj tega modula, da obdelate niz oblikovanja.
//! Cilj tega makra je še dodatno preprečiti vmesne dodelitve pri obravnavanju nizov za oblikovanje.
//!
//! Na primer, knjižnica dnevnika bi lahko uporabila standardno sintakso formatiranja, vendar bi interno prehajala po tej strukturi, dokler ni določeno, kam naj gre izhod.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Funkcija `format` zavzame strukturo [`Arguments`] in vrne nastali formatirani niz.
///
///
/// Primerek [`Arguments`] lahko ustvarite z makrom [`format_args!`].
///
/// # Examples
///
/// Osnovna uporaba:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Upoštevajte, da je uporaba [`format!`] morda bolj zaželena.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}