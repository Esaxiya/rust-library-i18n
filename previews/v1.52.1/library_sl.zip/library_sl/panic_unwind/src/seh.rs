//! Windows SEH
//!
//! Na Windows (trenutno samo na MSVC) je privzeti mehanizem za obdelavo izjem strukturirano urejanje izjem (XML).
//! To se precej razlikuje od ravnanja z izjemami na osnovi Škratov (npr. Kaj uporabljajo druge platforme unix) v smislu notranjih komponent prevajalnika, zato mora LLVM imeti precej dodatne podpore za SEH.
//!
//! Na kratko, tukaj se zgodi:
//!
//! 1. Funkcija `panic` pokliče standardno funkcijo Windows `_CxxThrowException`, da sproži izjemo, podobno C++ , ki sproži postopek odvijanja.
//! 2.
//! Vse pristajalne ploščice, ki jih ustvari prevajalnik, uporabljajo osebnostno funkcijo `__CxxFrameHandler3`, funkcijo v CRT, in odvijalna koda v Windows bo s to funkcijo osebnosti izvedla vso čistilno kodo na kupu.
//!
//! 3. Vsi klici, ki jih ustvari prevajalnik `invoke`, imajo pristajalno ploščico nastavljeno kot navodilo `cleanuppad` LLVM, ki označuje začetek čiščenja.
//! Osebnost (v koraku 2, opredeljena v CRT) je odgovorna za izvajanje čiščenja.
//! 4. Sčasoma se izvede koda "catch" v notranji `try` (ki jo ustvari prevajalnik) in kaže, da se mora nadzor vrniti na Rust.
//! To se naredi z navodili `catchswitch` in `catchpad` z IR LLVM, končno pa vrne normalno upravljanje v program z navodilom `catchret`.
//!
//! Nekatere posebne razlike od ravnanja z izjemami na osnovi gcc so:
//!
//! * Rust nima osebne funkcije po meri, temveč je *vedno*`__CxxFrameHandler3`.Poleg tega se ne izvaja nobeno dodatno filtriranje, zato na koncu ujamemo morebitne izjeme v C++ , ki so videti kot take, ki jih vržemo.
//! Upoštevajte, da je metanje izjeme v Rust vseeno nedefinirano, zato bi moralo biti v redu.
//! * Nekaj podatkov imamo za prenos preko meje odvijanja, natančneje `Box<dyn Any + Send>`.Tako kot pri pritlikavih izjemah sta tudi ta dva kazalca shranjena kot koristni tovor v sami izjemi.
//! V MSVC pa ni potrebe po dodatnem dodeljevanju kopice, ker je sklad klicev ohranjen med izvajanjem filtrirnih funkcij.
//! To pomeni, da se kazalci posredujejo neposredno na `_CxxThrowException`, ki se nato obnovijo v funkciji filtra, da se zapišejo v okvir sklada intrinzičnega `try`.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // To mora biti možnost, ker izjemo ujamemo s sklicem, njen destruktor pa se izvede v času izvajanja C++ .
    // Ko vzamemo Box iz izjeme, moramo izjemo pustiti v veljavnem stanju, da lahko njen destruktor deluje, ne da bi dvakrat spustil Box.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Najprej cel kup definicij vrst.Tukaj je nekaj nenavadnosti, značilnih za platformo, in veliko, kar je očitno kopirano iz LLVM.Namen vsega tega je izvajanje spodnje funkcije `panic` s klicem na `_CxxThrowException`.
//
// Ta funkcija ima dva argumenta.Prvi je kazalec na podatke, ki jih posredujemo, kar je v tem primeru naš objekt Portrait.Precej enostavno najti!Naslednje pa je bolj zapleteno.
// To je kazalec na strukturo `_ThrowInfo` in je namenjen zgolj opisu vržene izjeme.
//
// Trenutno je opredelitev tega tipa [1] nekoliko poraščena in glavna nenavadnost (in razlika od spletnega članka) je, da so na 32-bitnih kazalcih kazalci, na 64-bitnih pa so kazalci izraženi kot 32-bitni odmiki od `__ImageBase` simbol.
//
// To izražata makro `ptr_t` in `ptr!` v spodnjih modulih.
//
// Tudi labirint definicij vrst natančno spremlja, kaj LLVM oddaja za tovrstno operacijo.Če na primer prevedete to kodo C++ na MSVC in oddate LLVM IR:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      praznina foo() { rust_panic a = {0, 1};
//          vrzi a;}
//
// To v bistvu poskušamo posnemati.Večina konstantnih vrednosti spodaj je bila pravkar kopirana iz LLVM,
//
// Vsekakor so vse te strukture zgrajene na podoben način in za nas je le nekoliko podrobno.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Upoštevajte, da tukaj namerno ignoriramo pravila za upravljanje imen: ne želimo, da bi C++ lahko lovil Rust panics s preprosto razglasitvijo `struct rust_panic`.
//
//
// Pri spreminjanju se prepričajte, da se niz imena imena natančno ujema z nizom, uporabljenim v `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Vodilni bajt `\x01` tukaj je pravzaprav čarobni signal LLVM, da *ne* uporabi kakršnega koli drugega ravnanja, kot je predpona z znakom `_`.
    //
    //
    // Ta simbol je vtable, ki ga uporablja C++ `std::type_info`.
    // Predmeti tipa `std::type_info`, deskriptorji tipa, imajo kazalec na to tabelo.
    // Na deskriptorje tipov se sklicujejo zgoraj definirane strukture C++ EH, ki jih sestavimo spodaj.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Ta deskriptor tipa se uporablja samo, ko vrže izjemo.
// Del ulova obravnava intrinsic try, ki ustvari svoj TypeDescriptor.
//
// To je v redu, ker izvajalno okolje MSVC uporablja primerjavo nizov v imenu tipa, da se ujema z TypeDescriptors in ne z enakostjo kazalcev.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destruktor, ki se uporablja, če se koda C++ odloči zajeti izjemo in jo spustiti brez širjenja.
// Del ulova try intrinsic bo prvo besedo predmeta izjeme postavil na 0, tako da jo destruktor preskoči.
//
// Upoštevajte, da x86 Windows uporablja klicni dogovor "thiscall" za funkcije članov C++ namesto privzetega klicnega dogovora "C".
//
// Funkcija exception_copy je tu nekoliko posebna: prikliče jo izvajalno okolje MSVC pod blokom try/catch in panic, ki ga tukaj ustvarimo, bo uporabljen kot rezultat kopije izjeme.
//
// To izvajalno okolje C++ uporablja za podporo zajemanju izjem z std::exception_ptr, ki jih ne moremo podpreti, ker Box<dyn Any>ni mogoče klonirati.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException se v celoti izvaja na tem okviru sklada, zato `data` ni treba drugače prenašati na kup.
    // Na to funkcijo preprosto prenesemo kazalec skladovnice.
    //
    // Tu je potreben ManuallyDrop, ker ne želimo, da izjema izpade med odvijanjem.
    // Namesto tega bo izpuščen z izuzetkom_cleanup, ki ga prikliče izvajalno okolje C++ .
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // To ... se morda zdi presenetljivo in upravičeno.Na 32-bitnem MSVC so kazalci med temi strukturami ravno to, kazalci.
    // Na 64-bitnem MSVC pa so kazalci med strukturami precej izraženi kot 32-bitni odmiki od `__ImageBase`.
    //
    // Posledično lahko na 32-bitnem MSVC prijavimo vse te kazalce v zgornjih `statičnih`.
    // Na 64-bitnem MSVC bi morali v statiki izraziti odštevanje kazalcev, česar Rust trenutno ne omogoča, zato tega dejansko ne moremo storiti.
    //
    // Naslednja najboljša stvar je, da te strukture izpolnite med izvajanjem (panika je že tako ali tako že "slow path").
    // Torej, tukaj vsa ta polja kazalcev znova interpretiramo kot 32-bitna cela števila in nato vanje shranimo ustrezno vrednost (atomsko, kot se lahko dogaja sočasno panics).
    //
    // Tehnično bo čas izvajanja verjetno neatomsko prebral ta polja, vendar v teoriji nikoli niso prebrali vrednosti *napačno*, zato ne bi smelo biti slabo ...
    //
    // V vsakem primeru moramo v bistvu narediti kaj takega, dokler ne bomo mogli več operacij izraziti v statiki (in morda nikoli ne bomo mogli).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // NULL tovor pomeni, da smo sem prišli iz ulova (...) __rust_try.
    // To se zgodi, ko je ujeta tuja izjema, ki ni Rust.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Prevajalnik to zahteva (npr. To je element lang), vendar ga prevajalnik nikoli ne pokliče, ker je __C_specific_handler ali_except_handler3 osebnostna funkcija, ki se vedno uporablja.
//
// Zato je to le prekinitev.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}