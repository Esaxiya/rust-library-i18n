//! Odvijanje panics za Miri.
use alloc::boxed::Box;
use core::any::Any;

// Vrsta koristnega tovora, ki ga Miri širi z odvijanjem za nas.
// Mora biti velikosti kazalca.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Zunanja funkcija, ki jo zagotavlja Miri, se začne odvijati.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Korist, ki jo posredujemo `miri_start_panic`, bo ravno argument, ki ga dobimo v spodnjem `cleanup`.
    // Torej ga samo enkrat zapakiramo, da dobimo nekaj velikosti kazalca.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Obnovite osnovni `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}