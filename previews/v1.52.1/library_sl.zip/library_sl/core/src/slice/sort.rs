//! Razvrščanje rezin
//!
//! Ta modul vsebuje algoritem za razvrščanje, ki temelji na hitrem sortiranju poraznega vzorca Orsona Petersa, objavljenem na: <https://github.com/orlp/pdqsort>
//!
//!
//! Nestabilno razvrščanje je združljivo s sistemom libcore, ker ne dodeljuje pomnilnika, za razliko od naše stabilne izvedbe razvrščanja.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Ko ga spustite, kopirate iz `src` v `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // VARNOST: To je pomožni razred.
        //          Za pravilnost glejte njegovo uporabo.
        //          Prepričati se moramo namreč, da se `src` in `dst` ne prekrivata, kot zahteva `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Premika prvi element v desno, dokler ne naleti na večji ali enak element.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // VARNOST: Spodaj navedeni varni postopki vključujejo indeksiranje brez vezanega preverjanja (`get_unchecked` in `get_unchecked_mut`)
    // in kopiranje pomnilnika (`ptr::copy_nonoverlapping`).
    //
    // a.Indeksiranje:
    //  1. Velikost matrike smo preverili na>=2.
    //  2. Vse indeksiranje, ki ga bomo izvedli, je vedno največ med {0 <= index < len}.
    //
    // b.Kopiranje pomnilnika
    //  1. Pridobivamo napotke na reference, za katere je zagotovljeno, da so veljavne.
    //  2. Ne morejo se prekrivati, ker dobimo kazalce na indekse razlik rezine.
    //     In sicer `i` in `i-1`.
    //  3. Če je rezina pravilno poravnana, so elementi pravilno poravnani.
    //     Odgovornost kličočega je zagotoviti, da je rezina pravilno poravnana.
    //
    // Za nadaljnje podrobnosti glejte komentarje spodaj.
    unsafe {
        // Če prva dva elementa nista v redu ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Preberite prvi element v spremenljivko, dodeljeno skladom.
            // Če bo naslednja primerjalna operacija panics, `hole` padla in element samodejno zapisal nazaj v rezino.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Premaknite `i`-ti element za eno mesto v levo in tako luknjo premaknite v desno.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` spusti in tako kopira `tmp` v preostalo luknjo v `v`.
        }
    }
}

/// Zadnji element premakne v levo, dokler ne naleti na manjši ali enak element.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // VARNOST: Spodaj navedeni varni postopki vključujejo indeksiranje brez vezanega preverjanja (`get_unchecked` in `get_unchecked_mut`)
    // in kopiranje pomnilnika (`ptr::copy_nonoverlapping`).
    //
    // a.Indeksiranje:
    //  1. Velikost matrike smo preverili na>=2.
    //  2. Vse indeksiranje, ki ga bomo izvedli, je vedno največ med `0 <= index < len-1`.
    //
    // b.Kopiranje pomnilnika
    //  1. Pridobivamo napotke na reference, za katere je zagotovljeno, da so veljavne.
    //  2. Ne morejo se prekrivati, ker dobimo kazalce na indekse razlik rezine.
    //     In sicer `i` in `i+1`.
    //  3. Če je rezina pravilno poravnana, so elementi pravilno poravnani.
    //     Odgovornost kličočega je zagotoviti, da je rezina pravilno poravnana.
    //
    // Za nadaljnje podrobnosti glejte komentarje spodaj.
    unsafe {
        // Če zadnja dva elementa nista v redu ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Preberite zadnji element v spremenljivko, dodeljeno skladom.
            // Če bo naslednja primerjalna operacija panics, `hole` padla in element samodejno zapisal nazaj v rezino.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Premaknite `i`-ti element za eno mesto v desno in tako luknjo premaknite v levo.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` spusti in tako kopira `tmp` v preostalo luknjo v `v`.
        }
    }
}

/// Delno razvrsti rezino s premikanjem več elementov, ki niso v redu.
///
/// Vrne `true`, če je rezina razvrščena na koncu.Ta funkcija je *O*(*n*) v najslabšem primeru.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Največje število sosednjih parov, ki niso v redu, ki se bodo premaknili.
    const MAX_STEPS: usize = 5;
    // Če je rezina krajša od te, ne premikajte nobenih elementov.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // VARNOST: Vezani pregled smo že izrecno opravili z `i < len`.
        // Vse naše nadaljnje indeksiranje je le v območju `0 <= index < len`
        unsafe {
            // Poiščite naslednji par sosednjih elementov, ki niso v redu.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Smo končali?
        if i == len {
            return true;
        }

        // Ne premikajte elementov na kratkih nizih, kar ima stroške delovanja.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Zamenjajte najdeni par elementov.To jih postavi v pravilen vrstni red.
        v.swap(i - 1, i);

        // Manjši element premaknite v levo.
        shift_tail(&mut v[..i], is_less);
        // Pomaknite večji element v desno.
        shift_head(&mut v[i..], is_less);
    }

    // Rezine ni uspel razvrstiti v omejenem številu korakov.
    false
}

/// Rezino razvrsti z uporabo razvrščanja vstavljanja, kar je *O*(*n*^ 2) najslabši primer.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Razvrsti `v` z uporabo sorte, ki zagotavlja *O*(*n*\*log(* n*)) v najslabšem primeru.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Ta binarni kup spoštuje nespremenljiv `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Otroci `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Izberite večjega otroka.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Ustavite se, če invariant drži pri `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Zamenjajte `node` z večjim otrokom, premaknite se za en korak navzdol in nadaljujte s presejanjem.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Zgradite kup v linearnem času.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Pokači največ elementov iz kupa.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Razdeli `v` na elemente, manjše od `pivot`, čemur sledijo elementi, večji ali enaki `pivot`.
///
///
/// Vrne število elementov, manjše od `pivot`.
///
/// Razdeljevanje se izvede po blokih, da se zmanjšajo stroški razvejanja.
/// Ta ideja je predstavljena v prispevku [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Število elementov v tipičnem bloku.
    const BLOCK: usize = 128;

    // Algoritem razdeljevanja do konca ponavlja naslednje korake:
    //
    // 1. Sledite bloku na levi strani, da prepoznate elemente, večje ali enake vrtišču.
    // 2. Sledite bloku z desne strani, da prepoznate elemente, ki so manjši od vrtišča.
    // 3. Identificirane elemente zamenjajte med levo in desno stranjo.
    //
    // Za blok elementov hranimo naslednje spremenljivke:
    //
    // 1. `block` - Število elementov v bloku.
    // 2. `start` - Zaženite kazalec v matriko `offsets`.
    // 3. `end` - Končni kazalec na matriko `offsets`.
    // 4. `offset, indeksi elementov v bloku, ki niso v redu.

    // Trenutni blok na levi strani (od `l` do `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Trenutni blok na desni strani (od `r.sub(block_r)` to `r`).
    // VARNOST: V dokumentaciji za .add() je posebej omenjeno, da je `vec.as_ptr().add(vec.len())` vedno varen "
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Ko dobimo VLA-je, poskusite ustvariti eno matriko dolžine `min(v.len(), 2 * BLOCK) `
    // kot dva polja s fiksno velikostjo dolžine `BLOCK`.VLA-ji so morda bolj učinkoviti v predpomnilniku.

    // Vrne število elementov med kazalcema `l` (inclusive) in `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Končamo s particioniranjem po blokih, ko se `l` in `r` zelo približamo.
        // Nato opravimo nekaj popravkov, da vmes razdelimo preostale elemente.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Število preostalih elementov (še vedno ni v primerjavi z vrtiščem).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Velikosti blokov prilagodite tako, da se levi in desni blok ne prekrivata, ampak se popolnoma poravnate, da pokrijete celotno preostalo vrzel.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Sledi elementom `block_l` z leve strani.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // VARNOST: Spodaj navedeni varnostni postopki vključujejo uporabo `offset`.
                //         V skladu s pogoji, ki jih zahteva funkcija, jih izpolnjujemo, ker:
                //         1. `offsets_l` je dodeljen skladom in se zato šteje za ločen dodeljeni objekt.
                //         2. Funkcija `is_less` vrne `bool`.
                //            Predvajanje `bool` nikoli ne bo preseglo `isize`.
                //         3. Zagotovili smo, da bo `block_l` `<= BLOCK`.
                //            Poleg tega je bil `end_l` sprva nastavljen na začetni kazalnik `offsets_`, ki je bil prijavljen na skladu.
                //            Tako vemo, da bomo tudi v najslabšem primeru (vsi klici `is_less` vrnejo false) prešli samo 1 bajt.
                //        Druga nevarna operacija tukaj je preusmeritev `elem`.
                //        Vendar je bil `elem` sprva začetni kazalec na rezino, ki je vedno veljaven.
                unsafe {
                    // Primerjava brez podružnic.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Sledi elementom `block_r` z desne strani.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // VARNOST: Spodaj navedeni varnostni postopki vključujejo uporabo `offset`.
                //         V skladu s pogoji, ki jih zahteva funkcija, jih izpolnjujemo, ker:
                //         1. `offsets_r` je dodeljen skladom in se zato šteje za ločen dodeljeni objekt.
                //         2. Funkcija `is_less` vrne `bool`.
                //            Predvajanje `bool` nikoli ne bo preseglo `isize`.
                //         3. Zagotovili smo, da bo `block_r` `<= BLOCK`.
                //            Poleg tega je bil `end_r` sprva nastavljen na začetni kazalnik `offsets_`, ki je bil prijavljen na skladu.
                //            Tako vemo, da bomo tudi v najslabšem primeru (vsi klici `is_less` vrnejo resničnost) prešli konec le največ 1 bajt.
                //        Druga nevarna operacija tukaj je preusmeritev `elem`.
                //        Vendar je bil `elem` sprva `1 *sizeof(T)` mimo konca in ga pred dostopom zmanjšamo za `1* sizeof(T)`.
                //        Poleg tega naj bi bil `block_r` manjši od `BLOCK`, zato bo `elem` kvečjemu kazal na začetek rezine.
                unsafe {
                    // Primerjava brez podružnic.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Število odpovedanih elementov za zamenjavo med levo in desno stranjo.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Namesto da bi zamenjali en par hkrati, je učinkoviteje izvesti ciklično permutacijo.
            // To ni povsem enakovredno zamenjavi, vendar daje manj podobnih rezultatov z manj operacijami pomnilnika.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Vsi napačni elementi v levem bloku so bili premaknjeni.Premakni se na naslednji blok.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Vsi napačni elementi v desnem bloku so bili premaknjeni.Premakni se na prejšnji blok.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Zdaj ostane samo en blok (bodisi levi bodisi desni) z elementi, ki niso v redu, ki jih je treba premakniti.
    // Take preostale elemente lahko preprosto premaknete do konca znotraj svojega bloka.
    //

    if start_l < end_l {
        // Levi blok ostane.
        // Preostale elemente, ki niso v redu, premaknite na skrajno desno.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Desni blok ostane.
        // Preostale elemente, ki niso v redu, premaknite skrajno levo.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Nič drugega za početi, končali smo.
        width(v.as_mut_ptr(), l)
    }
}

/// Razdeli `v` na elemente, manjše od `v[pivot]`, čemur sledijo elementi, večji ali enaki `v[pivot]`.
///
///
/// Vrne sklop:
///
/// 1. Število elementov, manjših od `v[pivot]`.
/// 2. Res je, če je bil `v` že razdeljen.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Postavite pivot na začetek rezine.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Za učinkovitost preberite vrtišče v spremenljivko, dodeljeno skladom.
        // Če se izvede naslednja primerjalna operacija panics, se vrtišče samodejno zapiše nazaj v rezino.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Poiščite prvi par elementov, ki niso v redu.
        let mut l = 0;
        let mut r = v.len();

        // VARNOST: Spodaj navedena varnost vključuje indeksiranje matrike.
        // Za prvo: Tu že preverjamo meje z `l < r`.
        // Za drugo: sprva imamo `l == 0` in `r == v.len()` in smo to preverjali pri vsaki operaciji indeksiranja.
        //                     Od tu vemo, da mora biti `r` vsaj `r == l`, kar je bilo dokazano veljavno od prvega.
        unsafe {
            // Poiščite prvi element, ki je večji ali enak vrtišču.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Poiščite zadnji element, manjši od vrtišča.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` izstopi iz področja uporabe in vrtišče (ki je spremenljivka, dodeljena skladom) zapiše nazaj v rezino, kjer je bila prvotno.
        // Ta korak je ključnega pomena pri zagotavljanju varnosti!
        //
    };

    // Postavite vrtišče med dvema particijama.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Razdeli `v` na elemente, enake `v[pivot]`, ki jim sledijo elementi, večji od `v[pivot]`.
///
/// Vrne število elementov, ki je enako vrtišču.
/// Predpostavlja se, da `v` ne vsebuje elementov, manjših od vrtišča.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Postavite pivot na začetek rezine.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Za učinkovitost preberite vrtišče v spremenljivko, dodeljeno skladom.
    // Če se izvede naslednja primerjalna operacija panics, se vrtišče samodejno zapiše nazaj v rezino.
    // VARNOST: Kazalec tukaj je veljaven, ker je pridobljen iz sklica na rezino.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Zdaj razdelite rezino.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // VARNOST: Spodaj navedena varnost vključuje indeksiranje matrike.
        // Za prvo: Tu že preverjamo meje z `l < r`.
        // Za drugo: sprva imamo `l == 0` in `r == v.len()` in smo to preverjali pri vsaki operaciji indeksiranja.
        //                     Od tu vemo, da mora biti `r` vsaj `r == l`, kar je bilo dokazano veljavno od prvega.
        unsafe {
            // Poiščite prvi element, večji od vrtišča.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Poiščite zadnji element, ki je enak vrtišču.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Smo končali?
            if l >= r {
                break;
            }

            // Zamenjajte najdeni par elementov, ki niso v redu.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Ugotovili smo, da so elementi `l` enaki vrtišču.Dodajte 1 za račun samega vrtišča.
    l + 1

    // `_pivot_guard` izstopi iz področja uporabe in vrtišče (ki je spremenljivka, dodeljena skladom) zapiše nazaj v rezino, kjer je bila prvotno.
    // Ta korak je ključnega pomena pri zagotavljanju varnosti!
}

/// Razprši nekaj elementov, da bi razbil vzorce, ki bi lahko povzročili neuravnotežene particije v hitrem sortiranju.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Generator psevdonaključnih števil iz papirja "Xorshift RNGs" Georgea Marsaglie.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Vzemite naključne številke po modulu te številke.
        // Število ustreza `usize`, ker `len` ni večji od `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Nekateri ključni kandidati bodo v bližini tega indeksa.Randomizirajmo jih.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Ustvari naključno število po modulu `len`.
            // Da bi se izognili dragim operacijam, ga najprej vzamemo za moč dva, nato pa zmanjšamo za `len`, dokler se ne prilega območju `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` zajamčeno manj kot `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Izbere vrtišče v `v` in vrne indeks in `true`, če je rezina verjetno že razvrščena.
///
/// Elementi v `v` bodo v postopku morda preurejeni.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Najmanjša dolžina za izbiro metode mediane mediane.
    // Krajše rezine uporabljajo preprosto metodo mediana-of-three.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Največje število zamenjav, ki jih je mogoče izvesti s to funkcijo.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Trije indeksi, v bližini katerih bomo izbrali pivot.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Šteje skupno število zamenjav, ki jih bomo izvedli med razvrščanjem indeksov.
    let mut swaps = 0;

    if len >= 8 {
        // Zamenja indekse tako, da `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Zamenja indekse tako, da `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Poišče srednjo vrednost `v[a - 1], v[a], v[a + 1]` in indeks shrani v `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Poiščite mediane v soseskah `a`, `b` in `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Poiščite mediano med `a`, `b` in `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Opravljeno je bilo največje število zamenjav.
        // Verjetno je rezina padajoča ali večinoma padajoča, zato bo vzvratna pomoč verjetno pomagala hitreje razvrstiti.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Razvrsti `v` rekurzivno.
///
/// Če je rezina imela predhodnika v prvotnem polju, je podana kot `pred`.
///
/// `limit` je število dovoljenih neuravnoteženih particij pred preklopom na `heapsort`.
/// Če je nič, bo ta funkcija nemudoma preklopila na sorto.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Rezine do te dolžine se razvrstijo z vstavljanjem.
    const MAX_INSERTION: usize = 20;

    // Res je, če je bila zadnja particija primerno uravnotežena.
    let mut was_balanced = true;
    // Res je, če zadnja particija ni pomešala elementov (rezina je bila že razdeljena).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Zelo kratke rezine se razvrstijo z vstavljanjem.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Če je bilo sprejetih preveč slabih pivotnih odločitev, preprosto pojdite nazaj na veliko, da zagotovite najslabši primer `O(n * log(n))`.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Če je bila zadnja particija neuravnotežena, poskusite zlomiti vzorce v rezini tako, da premešate nekatere elemente naokoli.
        // Upajmo, da bomo tokrat izbrali boljši pivot.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Izberite vrtišče in poskusite uganiti, ali je rezina že razvrščena.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Če je bila zadnja particija primerno uravnotežena in ni mešala elementov in če vrtilni izbor predvideva, da je rezina verjetno že razvrščena ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Poskusite prepoznati več elementov, ki niso v redu, in jih premaknite v pravilne položaje.
            // Če se rezina popolnoma razvrsti, smo končali.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Če je izbrani pivot enak predhodniku, je to najmanjši element v rezini.
        // Rezino razdelite na elemente, ki so enaki, in elemente, večje od vrtišča.
        // Ta primer je običajno zadet, ko rezina vsebuje veliko podvojenih elementov.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Nadaljujte z razvrščanjem elementov, večjih od vrtišča.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Razdeli rezino.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Rezino razdelite na `left`, `pivot` in `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Vrnite se na krajšo stran samo zato, da zmanjšate skupno število rekurzivnih klicev in porabite manj prostora v skladišču.
        // Nato nadaljujte z daljšo stranjo (to je podobno rekurziji repa).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Razvrsti `v` z uporabo hitrega sortiranja, ki premaga vzorce, kar je *O*(*n*\*log(* n*)) v najslabšem primeru.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Razvrščanje nima smiselnega vedenja pri tipih velikosti nič.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Omejite število neuravnoteženih particij na `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Za rezine do te dolžine jih je verjetno hitreje preprosto razvrstiti.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Izberite vrtišče
        let (pivot, _) = choose_pivot(v, is_less);

        // Če je izbrani pivot enak predhodniku, je to najmanjši element v rezini.
        // Rezino razdelite na elemente, ki so enaki, in elemente, večje od vrtišča.
        // Ta primer je običajno zadet, ko rezina vsebuje veliko podvojenih elementov.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Če smo opravili indeks, smo dobri.
                if mid > index {
                    return;
                }

                // V nasprotnem primeru nadaljujte z razvrščanjem elementov, večjih od vrtišča.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Rezino razdelite na `left`, `pivot` in `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Če je indeks mid==, smo končali, saj je partition() zagotovil, da so vsi elementi po sredini večji ali enaki midu.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Razvrščanje nima smiselnega vedenja pri tipih velikosti nič.Delati nič.
    } else if index == v.len() - 1 {
        // Poiščite element max in ga postavite na zadnji položaj polja.
        // Tu lahko brezplačno uporabljamo `unwrap()`, ker vemo, da v ne sme biti prazen.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Poiščite element min in ga postavite na prvo mesto matrike.
        // Tu lahko brezplačno uporabljamo `unwrap()`, ker vemo, da v ne sme biti prazen.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}