// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Zavrti obseg `[mid-left, mid+right)` tako, da element na `mid` postane prvi element.Enakovredno zasuka elemente obsega `left` v levo ali `right` v desno.
///
/// # Safety
///
/// Navedeni obseg mora veljati za branje in pisanje.
///
/// # Algorithm
///
/// Algoritem 1 se uporablja za majhne vrednosti `left + right` ali za velike `T`.
/// Elementi se premaknejo v končni položaj enega za drugim, začenši z `mid - left`, in napredujejo po korakih `right` po modulu `left + right`, tako da je potreben le en začasni.
/// Sčasoma prispemo nazaj v `mid - left`.
/// Če pa `gcd(left + right, right)` ni 1, so zgornji koraki preskočili elemente.
/// Na primer:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Na srečo je število preskočenih elementov med dokončanimi elementi vedno enako, tako da lahko preprosto izravnamo svoj začetni položaj in naredimo več krogov (skupno število krogov je `gcd(left + right, right)` value).
///
/// Končni rezultat je, da se vsi elementi dokončajo enkrat in samo enkrat.
///
/// Algoritem 2 se uporablja, če je `left + right` velik, vendar je `min(left, right)` dovolj majhen, da se prilega v medpomnilnik sklada.
/// Elementi `min(left, right)` se kopirajo v vmesni pomnilnik, `memmove` se uporabi za ostale, tisti v vmesnem pomnilniku pa se premaknejo nazaj v luknjo na nasprotni strani, od koder izvirajo.
///
/// Algoritmi, ki jih je mogoče vektorizirati, presegajo zgornje, ko `left + right` postane dovolj velik.
/// Algoritem 1 lahko vektoriziramo tako, da razbijemo in izvedemo več krogov hkrati, vendar je v povprečju premalo krogov, dokler `left + right` ni ogromen, in vedno je tam najslabši primer enega kroga.
/// Namesto tega algoritem 3 uporablja večkratno zamenjavo elementov `min(left, right)`, dokler ne ostane manjša težava z vrtenjem.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// ko se `left < right` zamenja, namesto tega z leve.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. spodnji algoritmi lahko propadejo, če teh primerov ne preverimo
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algoritem 1 Mikrobenčmarki kažejo, da je povprečna zmogljivost naključnih premikov boljša vse do približno `left + right == 32`, vendar je najslabši primer celo približno 16.
            // 24 je bil izbran kot vmesna točka.
            // Če je velikost `T` večja od 4 `usize`s, ta algoritem presega tudi druge algoritme.
            //
            //
            let x = unsafe { mid.sub(left) };
            // začetek prvega kroga
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` je mogoče najti pred roko z izračunom `gcd(left + right, right)`, vendar je hitreje narediti eno zanko, ki izračuna gcd kot stranski učinek, nato pa narediti preostali del
            //
            //
            let mut gcd = right;
            // merila uspešnosti razkrivajo, da je hitreje zamenjati začasne ure, namesto da bi enkrat začasno prebrali, kopirali nazaj in nato začasno zapisali na samem koncu.
            // To je verjetno posledica dejstva, da zamenjava ali zamenjava časovnikov uporablja samo en pomnilniški naslov v zanki, namesto da bi bilo treba upravljati dva.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // namesto da povečujemo `i` in nato preverjamo, ali je zunaj meja, preverimo, ali bo `i` pri naslednjem prirastku šel zunaj meja.
                // To preprečuje zavijanje kazalcev ali `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // konec prvega kroga
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // ta pogoj mora biti tukaj, če `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // zaključi kos z več krogi
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` ni nič velik tip, zato je prav, da ga delite po njegovi velikosti.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algoritem 2 Tukaj `[T; 0]` zagotavlja, da je primerno poravnan za T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algoritem 3 Obstaja nadomestni način zamenjave, ki vključuje iskanje, kje bi bila zadnja zamenjava tega algoritma, in zamenjavo s tem zadnjim delom, namesto da bi zamenjali sosednje kose, kot to počne ta algoritem, vendar je ta način še vedno hitrejši.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algoritem 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}