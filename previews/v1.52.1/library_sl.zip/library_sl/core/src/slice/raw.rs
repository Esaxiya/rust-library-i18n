//! Brezplačne funkcije za ustvarjanje `&[T]` in `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Oblikuje rezino iz kazalca in dolžine.
///
/// Argument `len` je število **elementov**, ne število bajtov.
///
/// # Safety
///
/// Vedenje ni določeno, če je kršen kateri od naslednjih pogojev:
///
/// * `data` mora biti [valid] za branje za veliko število bajtov `len * mem::size_of::<T>()` in mora biti pravilno poravnan.To zlasti pomeni:
///
///     * Celoten obseg pomnilnika te rezine mora biti v enem dodeljenem objektu!
///       Rezine nikoli ne morejo obsegati več dodeljenih predmetov.Za primer glejte [below](#incorrect-usage), ki napačno ne upošteva tega.
///     * `data` ne sme biti ničelna in poravnana tudi za rezine ničelne dolžine.
///     Eden od razlogov za to je, da se lahko optimizacije postavitve naštevanja sklicujejo na poravnave referenc (vključno z rezinami katere koli dolžine) in njihovo nično, da jih ločijo od drugih podatkov.
///     S pomočjo [`NonNull::dangling()`] lahko dobite kazalec, ki je uporaben kot `data` za rezine ničelne dolžine.
///
/// * `data` mora kazati na zaporedne pravilno inicializirane vrednosti tipa `T`.
///
/// * Pomnilnik, na katerega se sklicuje vrnjena rezina, ne sme biti mutiran v celotni življenjski dobi `'a`, razen znotraj `UnsafeCell`.
///
/// * Skupna velikost rezine `len * mem::size_of::<T>()` ne sme biti večja od `isize::MAX`.
///   Glejte varnostno dokumentacijo [`pointer::offset`].
///
/// # Caveat
///
/// Življenjska doba vrnjene rezine je odvisna od njene uporabe.
/// Da bi preprečili nenamerno zlorabo, je predlagano, da se življenjska doba veže na tisto življenjsko dobo vira, ki je varna v kontekstu, na primer z zagotavljanjem pomožne funkcije, ki vzame življenjsko dobo gostiteljske vrednosti za rezino ali z izrecnim pripisom.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // manifestira rezino za posamezen element
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Nepravilna uporaba
///
/// Naslednja funkcija `join_slices` je **nezvočna** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Zgornja trditev zagotavlja, da sta `fst` in `snd` neprekinjena, vendar ju lahko vseeno vsebuje _different allocated objects_, pri čemer je ustvarjanje te rezine nedefinirano.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` in `b` sta različna dodeljena predmeta ...
///     let a = 42;
///     let b = 27;
///     // ... ki se lahko kljub temu položijo v spomin: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Izvaja enako funkcionalnost kot [`from_raw_parts`], le da je vrnjena spremenljiva rezina.
///
/// # Safety
///
/// Vedenje ni določeno, če je kršen kateri od naslednjih pogojev:
///
/// * `data` mora biti [valid] za branje in pisanje za veliko število bajtov `len * mem::size_of::<T>()` in mora biti pravilno poravnana.To zlasti pomeni:
///
///     * Celoten obseg pomnilnika te rezine mora biti v enem dodeljenem objektu!
///       Rezine nikoli ne morejo obsegati več dodeljenih predmetov.
///     * `data` ne sme biti ničelna in poravnana tudi za rezine ničelne dolžine.
///     Eden od razlogov za to je, da se lahko optimizacije postavitve naštevanja sklicujejo na poravnave referenc (vključno z rezinami katere koli dolžine) in njihovo nično, da jih ločijo od drugih podatkov.
///
///     S pomočjo [`NonNull::dangling()`] lahko dobite kazalec, ki je uporaben kot `data` za rezine ničelne dolžine.
///
/// * `data` mora kazati na zaporedne pravilno inicializirane vrednosti tipa `T`.
///
/// * Do pomnilnika, na katerega se sklicuje vrnjena rezina, v celotni življenjski dobi `'a` ne smete dostopati prek nobenega drugega kazalca (ki ni izpeljan iz vrnjene vrednosti).
///   Dostop tako za branje kot za pisanje je prepovedan.
///
/// * Skupna velikost rezine `len * mem::size_of::<T>()` ne sme biti večja od `isize::MAX`.
///   Glejte varnostno dokumentacijo [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Pretvori sklic na T v rezino dolžine 1 (brez kopiranja).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Pretvori sklic na T v rezino dolžine 1 (brez kopiranja).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}