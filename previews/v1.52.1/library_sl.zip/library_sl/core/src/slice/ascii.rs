//! Operacije na ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Preveri, ali so vsi bajti v tej rezini znotraj območja ASCII.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Preveri, ali dve rezini ne ustrezata črkam ASCII.
    ///
    /// Enako kot `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, vendar brez dodeljevanja in kopiranja začasnih datotek.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Pretvori to rezino v njen ASCII, ki je enakovreden velikemu mestu.
    ///
    /// Črke ASCII 'a' do 'z' so preslikane v 'A' do 'Z', črke, ki niso ASCII, pa nespremenjene.
    ///
    /// Če želite vrniti novo veliko črko, ne da bi spremenili obstoječo, uporabite [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Pretvori to rezino v svoj ASCII, ki je enakovreden malim črkam.
    ///
    /// Črke ASCII 'A' do 'Z' so preslikane v 'a' do 'z', črke, ki niso ASCII, pa nespremenjene.
    ///
    /// Če želite vrniti novo majhno vrednost brez spreminjanja obstoječe, uporabite [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Vrne `true`, če je katerikoli bajt v besedi `v` nonascii (>=128).
/// Snarfed iz `../str/mod.rs`, ki naredi nekaj podobnega za validacijo utf8.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Optimiziran preizkus ASCII, ki bo uporabil operacije "uporabiti naenkrat" namesto "byte-at-time" (kadar je to mogoče).
///
/// Algoritem, ki ga tukaj uporabljamo, je precej preprost.Če je `s` prekratek, samo preverimo vsak bajt in z njim končamo.V nasprotnem primeru:
///
/// - Preberite prvo besedo z neuravnanim bremenom.
/// - Poravnajte kazalec, preberite naslednje besede do konca z poravnanimi obremenitvami.
/// - Preberite zadnji `usize` iz `s` z neuravnano obremenitvijo.
///
/// Če katera od teh obremenitev povzroči nekaj, za kar `contains_nonascii` (above) vrne resnico, potem vemo, da je odgovor napačen.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Če z besedno implementacijo ne bi ničesar pridobili, se vrnite v skalarno zanko.
    //
    // To delamo tudi za arhitekture, kjer `size_of::<usize>()` ni zadostna poravnava za `usize`, ker gre za čuden primer edge.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Vedno preberemo prvo besedo neusklajeno, kar pomeni, da `align_offset` je
    // 0, bi še enkrat prebrali isto vrednost za poravnano branje.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // VARNOST: Zgoraj preverimo `len < USIZE_SIZE`.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // To smo nekoliko implicitno preverili zgoraj.
    // Upoštevajte, da je `offset_to_aligned` `align_offset` ali `USIZE_SIZE`, oba sta izrecno potrjena zgoraj.
    //
    debug_assert!(offset_to_aligned <= len);

    // VARNOST: word_ptr je (pravilno poravnana) velikost ptr, ki jo uporabljamo za branje datoteke
    // srednji del rezine.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` je bajtni indeks `word_ptr`, ki se uporablja za preverjanje konca zanke.
    let mut byte_pos = offset_to_aligned;

    // Preverjanje paranoje glede poravnave, saj bomo naredili kup neusklajenih obremenitev.
    // V praksi pa bi to moralo biti nemogoče, če ne bi prišlo do napake v `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Preberite naslednje besede do zadnje poravnane besede, pri čemer izključite zadnjo poravnano besedo, ki jo je treba narediti pozneje pri preverjanju repa, da zagotovite, da je rep vedno največ en `usize` za dodaten branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Preverite, ali je branje v mejah
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // In da držijo naše predpostavke o `byte_pos`.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // VARNOST: Vemo, da je `word_ptr` pravilno poravnan (zaradi
        // `align_offset`) in vemo, da imamo med `word_ptr` in koncem dovolj bajtov
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // VARNOST: Vemo, da `byte_pos <= len - USIZE_SIZE`, kar pomeni
        // po tem `add` bo `word_ptr` največ enkrat na koncu.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Preveriti, ali je resnično ostal le še en `usize`.
    // To bi moralo zagotavljati naše stanje zanke.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // VARNOST: To temelji na `len >= USIZE_SIZE`, ki ga preverimo na začetku.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}