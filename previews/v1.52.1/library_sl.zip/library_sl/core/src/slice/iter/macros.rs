//! Makri, ki jih uporabljajo iteratorji rezine.

// Inlining is_empty in len naredi veliko razliko v zmogljivosti
macro_rules! is_empty {
    // Način kodiranja dolžine iteratorja ZST deluje tako za ZST kot za ne-ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Da bi se znebili nekaterih preverjanj meja (glej `position`), izračunamo dolžino na nekoliko nepričakovan način.
// (Preizkušeno z `codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // včasih smo uporabljeni v nevarnem bloku

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Ta _cannot_ uporablja `unchecked_sub`, ker smo odvisni od zavijanja, da predstavljamo dolžino dolgih iteratorjev rezin ZST.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Vemo, da je `start <= end` torej boljši od `offset_from`, ki mora biti podpisan.
            // Če tukaj nastavimo ustrezne zastavice, lahko to povemo LLVM, kar mu pomaga odstraniti preverjanja mej.
            // VARNOST: Glede na vrsto invariant, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Če tudi pove LLVM, da so kazalci ločeni z natančno večkratnikom velikosti vrste, lahko `len() == 0` optimizira do `start == end` namesto `(end - start) < size`.
            //
            // VARNOST: Glede na vrsto invariante so kazalci poravnani tako, da
            //         razdalja med njimi mora biti večkratnica velikosti koničastega krila
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Skupna definicija iteratorjev `Iter` in `IterMut`
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Vrne prvi element in premakne začetek iteratorja naprej za 1.
        // Izjemno izboljša zmogljivost v primerjavi z vgrajeno funkcijo.
        // Ponavljalec ne sme biti prazen.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Vrne zadnji element in konec iteratorja premakne za 1 nazaj.
        // Izjemno izboljša zmogljivost v primerjavi z vgrajeno funkcijo.
        // Ponavljalec ne sme biti prazen.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Skrči iterator, ko je T ZST, s premikom konca iteratorja za `n` nazaj.
        // `n` ne sme presegati `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Pomožna funkcija za ustvarjanje rezine iz iteratorja.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // VARNOST: iterator je bil ustvarjen iz rezine s kazalcem
                // `self.ptr` in dolžina `len!(self)`.
                // To zagotavlja, da so izpolnjeni vsi predpogoji za `from_raw_parts`.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Pomožna funkcija za premikanje začetka iteratorja naprej po elementih `offset` in vračanje starega zagona.
            //
            // Nevarno, ker odmik ne sme presegati `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // VARNOST: klicatelj zagotavlja, da `offset` ne preseže `self.len()`,
                    // tako da je ta novi kazalec znotraj `self` in s tem zagotovljeno, da ni nič.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Pomožna funkcija za premikanje konca iteratorja z elementi `offset` nazaj in vračanje novega konca.
            //
            // Nevarno, ker odmik ne sme presegati `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // VARNOST: klicatelj zagotavlja, da `offset` ne preseže `self.len()`,
                    // ki zagotovo ne bo preplavil `isize`.
                    // Poleg tega je dobljeni kazalec v mejah `slice`, ki izpolnjuje druge zahteve za `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // lahko izvedli z rezinami, vendar se s tem izognemo preverjanju meja

                // VARNOST: Klici `assume` so varni od začetnega kazalca rezine
                // ne sme biti nič, rezine nad ne-ZST pa morajo imeti tudi ne-null končni kazalec.
                // Klic na `next_unchecked!` je varen, saj najprej preverimo, ali je iterator prazen.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Ta iterator je zdaj prazen.
                    if mem::size_of::<T>() == 0 {
                        // To moramo storiti tako, saj `ptr` morda nikoli ne bo 0, lahko pa `end` (zaradi ovijanja).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // VARNOST: end ne more biti 0, če T ni ZST, ker ptr ni 0 in end>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // VARNOST: Smo v mejah.`post_inc_start` naredi pravilno tudi za ZST.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Preglasimo privzeto izvedbo, ki uporablja `try_fold`, ker ta preprosta izvedba ustvari manj IR LLVM in je hitrejša za prevajanje.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Preglasimo privzeto izvedbo, ki uporablja `try_fold`, ker ta preprosta izvedba ustvari manj IR LLVM in je hitrejša za prevajanje.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Preglasimo privzeto izvedbo, ki uporablja `try_fold`, ker ta preprosta izvedba ustvari manj IR LLVM in je hitrejša za prevajanje.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Preglasimo privzeto izvedbo, ki uporablja `try_fold`, ker ta preprosta izvedba ustvari manj IR LLVM in je hitrejša za prevajanje.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Preglasimo privzeto izvedbo, ki uporablja `try_fold`, ker ta preprosta izvedba ustvari manj IR LLVM in je hitrejša za prevajanje.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Preglasimo privzeto izvedbo, ki uporablja `try_fold`, ker ta preprosta izvedba ustvari manj IR LLVM in je hitrejša za prevajanje.
            // `assume` se tudi izogiba preverjanju meja.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // VARNOST: zagotovljeno je, da smo v mejah z invariantom zanke:
                        // ko `i >= n`, `self.next()` vrne `None` in zanka se prekine.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Preglasimo privzeto izvedbo, ki uporablja `try_fold`, ker ta preprosta izvedba ustvari manj IR LLVM in je hitrejša za prevajanje.
            // `assume` se tudi izogiba preverjanju meja.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // VARNOST: `i` mora biti nižji od `n`, saj se začne pri `n`
                        // in se le zmanjšuje.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // VARNOST: klicatelj mora zagotoviti, da je `i` v mejah
                // osnovno rezino, zato `i` ne more preseči `isize`, vrnjene reference pa se zagotovo nanašajo na element rezine in so tako veljavne.
                //
                // Upoštevajte tudi, da klicatelj tudi zagotavlja, da nas nikoli več ne pokličejo z istim indeksom in da se ne pokliče nobena druga metoda, ki bo dostopala do te podreze, zato velja, da je vrnjena referenca spremenljiva v primeru
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // lahko izvedli z rezinami, vendar se s tem izognemo preverjanju meja

                // VARNOST: Klici `assume` so varni, saj mora biti začetni kazalec rezine nenulen,
                // rezine nad napravami, ki niso ZST, pa morajo imeti tudi ničelni končni kazalec.
                // Klic na `next_back_unchecked!` je varen, saj najprej preverimo, ali je iterator prazen.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Ta iterator je zdaj prazen.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // VARNOST: Smo v mejah.`pre_dec_end` naredi pravilno tudi za ZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}