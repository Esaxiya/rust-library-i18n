// ignore-tidy-filelength

//! Upravljanje rezin in manipulacija.
//!
//! Za več podrobnosti glejte [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Čista izvedba rust memchr, prevzeto iz rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Ta funkcija je javna samo zato, ker ni mogoče drugače preizkusiti enote preskusov.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Vrne število elementov v rezini.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // VARNOST: const zvok, ker polje dolžine pretvorimo v velikost (kar mora biti)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // VARNOST: to je varno, ker imata `&[T]` in `FatPtr<T>` enako postavitev.
            // To garancijo lahko da samo `std`.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Zamenjajte z `crate::ptr::metadata(self)`, če je ta stabilna.
            // V času pisanja to povzroči napako "Const-stable functions can only call other const-stable functions".
            //

            // VARNOST: Dostop do vrednosti iz zveze `PtrRepr` je varen, ker * const T
            // in PtrComponents<T>imajo enake postavitve pomnilnika.
            // To garancijo lahko da samo std.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Vrne `true`, če je rezina dolga 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Vrne prvi element rezine ali `None`, če je prazen.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Vrne spremenljiv kazalec na prvi element rezine ali `None`, če je prazen.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Vrne prvi in vse preostale elemente rezine ali `None`, če je prazen.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Vrne prvi in vse preostale elemente rezine ali `None`, če je prazen.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Vrne zadnji in vse ostale elemente rezine ali `None`, če je prazen.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Vrne zadnji in vse ostale elemente rezine ali `None`, če je prazen.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Vrne zadnji element rezine ali `None`, če je prazen.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Vrne spremenljiv kazalec na zadnji element v rezini.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Vrne sklic na element ali podrezo, odvisno od vrste indeksa.
    ///
    /// - Če dobi položaj, vrne sklic na element na tem položaju ali `None`, če je zunaj meja.
    ///
    /// - Če dobi obseg, vrne podrezano vrednost, ki ustreza temu obsegu, ali `None`, če je zunaj meja.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Vrne spremenljiv sklic na element ali podrezo, odvisno od vrste indeksa (glejte [`get`]) ali `None`, če je indeks zunaj meja.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Vrne sklic na element ali podrezo brez preverjanja meja.
    ///
    /// Za varno alternativo glejte [`get`].
    ///
    /// # Safety
    ///
    /// Klicanje te metode z indeksom zunaj meje je *[nedefinirano vedenje]*, tudi če se uporabljena referenca ne uporablja.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // VARNOST: klicatelj mora spoštovati večino varnostnih zahtev za `get_unchecked`;
        // rezine ni mogoče razločiti, ker je `self` varna referenca.
        // Vrnjeni kazalec je varen, ker morajo impulzi `SliceIndex` zagotoviti, da je.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Vrne spremenljiv sklic na element ali podrezo, ne da bi preverjal meje.
    ///
    /// Za varno alternativo glejte [`get_mut`].
    ///
    /// # Safety
    ///
    /// Klicanje te metode z indeksom zunaj meje je *[nedefinirano vedenje]*, tudi če se uporabljena referenca ne uporablja.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // VARNOST: klicatelj mora upoštevati varnostne zahteve za `get_unchecked_mut`;
        // rezine ni mogoče razločiti, ker je `self` varna referenca.
        // Vrnjeni kazalec je varen, ker morajo impulzi `SliceIndex` zagotoviti, da je.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Vrne neobdelani kazalnik na medpomnilnik rezine.
    ///
    /// Klicatelj mora zagotoviti, da rezina preseže kazalec, ki ga ta funkcija vrne, sicer bo na koncu kazal na smeti.
    ///
    /// Klicatelj mora zagotoviti tudi, da se v ta pomnilnik ali kateri koli kazalnik, ki izhaja iz njega, nikoli ne zapiše v pomnilnik, na katerega kaže kazalec (non-transitively) (razen znotraj `UnsafeCell`).
    /// Če želite mutirati vsebino rezine, uporabite [`as_mut_ptr`].
    ///
    /// Spreminjanje vsebnika, na katerega se sklicuje ta rezina, lahko povzroči prerazporeditev njegovega medpomnilnika, zaradi česar bodo morebitni kazalci nanj neveljavni.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Vrne nevaren spremenljiv kazalec v medpomnilnik rezine.
    ///
    /// Klicatelj mora zagotoviti, da rezina preseže kazalec, ki ga ta funkcija vrne, sicer bo na koncu kazal na smeti.
    ///
    /// Spreminjanje vsebnika, na katerega se sklicuje ta rezina, lahko povzroči prerazporeditev njegovega medpomnilnika, zaradi česar bodo morebitni kazalci nanj neveljavni.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Vrne dva surova kazalca, ki obsegata rezino.
    ///
    /// Vrnjeni obseg je napol odprt, kar pomeni, da končni kazalec kaže *eno mimo* zadnji element rezine.
    /// Tako prazno rezino predstavljata dva enaka kazalca, razlika med kazalcema pa velikost rezine.
    ///
    /// Za opozorila o uporabi teh kazalcev glejte [`as_ptr`].Končni kazalec zahteva posebno previdnost, saj ne kaže na veljaven element v rezini.
    ///
    /// Ta funkcija je uporabna za interakcijo s tujimi vmesniki, ki uporabljajo dva kazalca za sklicevanje na vrsto elementov v pomnilniku, kot je to običajno v C++ .
    ///
    ///
    /// Koristno je tudi preveriti, ali se kazalec na element nanaša na element te rezine:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // VARNOST: `add` tukaj je varen, ker:
        //
        //   - Oba kazalca sta del istega predmeta, saj šteje tudi usmerjanje neposredno mimo predmeta.
        //
        //   - Velikost rezine ni nikoli večja od isize::MAX bajtov, kot je navedeno tukaj:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Pri tem ni zavijanja, saj se rezine ne zavijejo mimo konca naslovnega prostora.
        //
        // Glejte dokumentacijo pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Vrne dva nevarna spremenljiva kazalca, ki obsegata rezino.
    ///
    /// Vrnjeni obseg je napol odprt, kar pomeni, da končni kazalec kaže *eno mimo* zadnji element rezine.
    /// Tako prazno rezino predstavljata dva enaka kazalca, razlika med kazalcema pa velikost rezine.
    ///
    /// Glejte [`as_mut_ptr`] za opozorila o uporabi teh kazalcev.
    /// Končni kazalec zahteva posebno previdnost, saj ne kaže na veljaven element v rezini.
    ///
    /// Ta funkcija je uporabna za interakcijo s tujimi vmesniki, ki uporabljajo dva kazalca za sklicevanje na vrsto elementov v pomnilniku, kot je to običajno v C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // VARNOST: Glejte as_ptr_range() zgoraj, zakaj je `add` tukaj varen.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// V rezini zamenja dva elementa.
    ///
    /// # Arguments
    ///
    /// * a, Indeks prvega elementa
    /// * b, indeks drugega elementa
    ///
    /// # Panics
    ///
    /// Panics, če `a` ali `b` ni v mejah.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Pri enem vector ne morete prevzeti dveh spremenljivih posojil, zato raje uporabite surove kazalce.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // VARNOST: `pa` in `pb` sta ustvarjena iz varnih spremenljivih referenc in napotitev
        // elementom v rezini, zato je zagotovljeno, da bodo veljavni in poravnani.
        // Upoštevajte, da je dostop do elementov za `a` in `b` preverjen in bo panic, ko je zunaj meja.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Na svojem mestu spremeni vrstni red elementov v rezini.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // Pri zelo majhnih vrstah vsa posamezna branja na običajni poti slabo delujejo.
        // Z učinkovitim neusklajenim load/store lahko naredimo boljše, če naložimo večji del in spremenimo register.
        //

        // V idealnem primeru bi LLVM to naredil namesto nas, saj bolje kot mi ve, ali so neusklajena branja učinkovita (saj se to na primer spreminja med različicami ARM) in kakšna bi bila najboljša velikost kosov.
        // Na žalost od LLVM 4.0 (2017-05) zanko samo odvije, zato moramo to storiti sami.
        // (Hipoteza: vzvratna stran je težavna, ker se stranice lahko poravnajo drugače-bo, če bo dolžina nenavadna-zato ni mogoče oddajati pred in postludij, da bi v sredini uporabili popolnoma poravnani SIMD.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Uporabite llvm.bswap, da spremenite u8 v velikosti
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // VARNOST: Tukaj je treba preveriti več stvari:
                //
                // - Upoštevajte, da je `chunk` 4 ali 8 zaradi zgornjega preverjanja cfg.Torej je `chunk - 1` pozitiven.
                // - Indeksiranje z indeksom `i` je v redu, saj zagotavlja preverjanje zanke
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Indeksiranje z indeksom `ln - i - chunk = ln - (i + chunk)` je v redu:
                //   - `i + chunk > 0` je nepomembno resnično.
                //   - Preverjanje zanke zagotavlja:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, zato se odštevanje ne premakne.
                // - Klici `read_unaligned` in `write_unaligned` so v redu:
                //   - `pa` kaže na indeks `i`, kjer `i < ln / 2 - (chunk - 1)` (glej zgoraj) in `pb` kaže na indeks `ln - i - chunk`, tako da sta oba vsaj `chunk` veliko bajtov oddaljena od konca `self`.
                //
                //   - Vsak inicializiran pomnilnik je veljaven `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Uporabite zasuk za 16, da obrnete u16s v u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // VARNOST: Neskladen u32 je mogoče prebrati iz `i`, če je `i + 1 < ln`
                // (in očitno `i < ln`), ker je vsak element 2 bajta in beremo 4.
                //
                // `i + chunk - 1 < ln / 2` # medtem ko stanje
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Ker je manjša od dolžine, deljene z 2, mora biti v mejah.
                //
                // To tudi pomeni, da se pogoj `0 < i + chunk <= ln` vedno spoštuje, kar zagotavlja varno uporabo kazalca `pb`.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // VARNOST: `i` je slabši od polovice dolžine rezine
            // dostop do `i` in `ln - i - 1` je varen (`i` se začne ob 0 in ne presega `ln / 2 - 1`).
            // Tako dobljena kazalca `pa` in `pb` sta torej veljavna in poravnana ter ju je mogoče brati in zapisovati v.
            //
            //
            unsafe {
                // Nevarna zamenjava, da se izognete omejitvam preverjanja varne zamenjave.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Vrne iterator nad rezino.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Vrne iterator, ki omogoča spreminjanje vsake vrednosti.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Vrne iterator za vse sosednje windows dolžine `size`.
    /// windows se prekriva.
    /// Če je rezina krajša od `size`, iterator ne vrne nobene vrednosti.
    ///
    /// # Panics
    ///
    /// Panics, če je `size` 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Če je rezina krajša od `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Vrne iterator za `chunk_size` elemente rezine naenkrat, začenši na začetku rezine.
    ///
    /// Kosi so rezine in se ne prekrivajo.Če `chunk_size` ne deli dolžine rezine, potem zadnji kos ne bo imel dolžine `chunk_size`.
    ///
    /// Glejte [`chunks_exact`] za različico tega iteratorja, ki vrne koščke vedno natančno `chunk_size` elementov, in [`rchunks`] za isti iterator, vendar se začne na koncu rezine.
    ///
    ///
    /// # Panics
    ///
    /// Panics, če je `chunk_size` 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Vrne iterator za `chunk_size` elemente rezine naenkrat, začenši na začetku rezine.
    ///
    /// Kosi so spremenljive rezine in se ne prekrivajo.Če `chunk_size` ne deli dolžine rezine, potem zadnji kos ne bo imel dolžine `chunk_size`.
    ///
    /// Glejte [`chunks_exact_mut`] za različico tega iteratorja, ki vrne koščke vedno natančno `chunk_size` elementov, in [`rchunks_mut`] za isti iterator, vendar se začne na koncu rezine.
    ///
    ///
    /// # Panics
    ///
    /// Panics, če je `chunk_size` 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Vrne iterator za `chunk_size` elemente rezine naenkrat, začenši na začetku rezine.
    ///
    /// Kosi so rezine in se ne prekrivajo.
    /// Če `chunk_size` ne deli dolžine rezine, bodo izpuščeni zadnji elementi do `chunk_size-1`, ki jih je mogoče pridobiti iz funkcije `remainder` iteratorja.
    ///
    ///
    /// Zaradi vsakega dela, ki ima natančno elemente `chunk_size`, lahko prevajalnik pogosto optimizira nastalo kodo bolje kot v primeru [`chunks`].
    ///
    /// Glejte [`chunks`] za različico tega iteratorja, ki prav tako vrne preostanek kot manjši kos, in [`rchunks_exact`] za isti iterator, vendar se začne na koncu rezine.
    ///
    /// # Panics
    ///
    /// Panics, če je `chunk_size` 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Vrne iterator za `chunk_size` elemente rezine naenkrat, začenši na začetku rezine.
    ///
    /// Kosi so spremenljive rezine in se ne prekrivajo.
    /// Če `chunk_size` ne deli dolžine rezine, bodo izpuščeni zadnji elementi do `chunk_size-1`, ki jih je mogoče pridobiti iz funkcije `into_remainder` iteratorja.
    ///
    ///
    /// Zaradi vsakega dela, ki ima natančno elemente `chunk_size`, lahko prevajalnik pogosto optimizira nastalo kodo bolje kot v primeru [`chunks_mut`].
    ///
    /// Glejte [`chunks_mut`] za različico tega iteratorja, ki prav tako vrne ostanek kot manjši kos, in [`rchunks_exact_mut`] za isti iterator, vendar se začne na koncu rezine.
    ///
    /// # Panics
    ///
    /// Panics, če je `chunk_size` 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Razdeli rezino v rezino nizov elementov `N`, ob predpostavki, da ni ostanka.
    ///
    ///
    /// # Safety
    ///
    /// To lahko pokličete le, kadar
    /// - Rezina se natančno razdeli na koščke `N`-elementov (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // VARNOST: Kosi z enim elementom nikoli nimajo ostankov
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // VARNOST: dolžina rezine (6) je večkratnik 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Ti bi bili nesorazmerni:
    /// // pusti koščke: &[[_;5]]= slice.as_chunks_unchecked()//Dolžina rezine ni večkratnik 5 letnih kosov:&[[_;0]]= slice.as_chunks_unchecked()//Kosi z ničelno dolžino niso nikoli dovoljeni
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // VARNOST: Naš predpogoj je točno tisto, kar je potrebno, da to imenujemo
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // VARNOST: Vanj smo vložili rezino elementov `new_len * N`
        // rezina `new_len` veliko kosov `N` elementov.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Rezino razdeli v rezino nizov elementov N, začenši na začetku rezine, in preostalo rezino z dolžino strogo manjšo od `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, če je `N` 0. To preverjanje se bo najverjetneje spremenilo v napako časa prevajanja, preden se ta metoda stabilizira.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // VARNOST: Že zdaj smo bili v paniki za nič in zagotovljeni z gradnjo
        // da je dolžina podreza večkratnik N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Rezino razdeli na rezino nizov elementov N, začenši na koncu rezine, in preostalo rezino z dolžino, strogo manjšo od `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, če je `N` 0. To preverjanje se bo najverjetneje spremenilo v napako časa prevajanja, preden se ta metoda stabilizira.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // VARNOST: Že zdaj smo bili v paniki za nič in zagotovljeni z gradnjo
        // da je dolžina podreza večkratnik N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Vrne iterator za `N` elemente rezine naenkrat, začenši na začetku rezine.
    ///
    /// Kosi so sklici na matriko in se ne prekrivajo.
    /// Če `N` ne deli dolžine rezine, bodo izpuščeni zadnji do `N-1` elementi, ki jih je mogoče pridobiti iz funkcije `remainder` iteratorja.
    ///
    ///
    /// Ta metoda je splošni generični ekvivalent [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics, če je `N` 0. To preverjanje se bo najverjetneje spremenilo v napako časa prevajanja, preden se ta metoda stabilizira.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Razdeli rezino v rezino nizov elementov `N`, ob predpostavki, da ni ostanka.
    ///
    ///
    /// # Safety
    ///
    /// To lahko pokličete le, kadar
    /// - Rezina se natančno razdeli na koščke `N`-elementov (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // VARNOST: Kosi z enim elementom nikoli nimajo ostankov
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // VARNOST: dolžina rezine (6) je večkratnik 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Ti bi bili nesorazmerni:
    /// // pusti koščke: &[[_;5]]= slice.as_chunks_unchecked_mut()//Dolžina rezine ni večkratnik 5 letnih kosov:&[[_;0]]= slice.as_chunks_unchecked_mut()//Kosi z ničelno dolžino niso nikoli dovoljeni
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // VARNOST: Naš predpogoj je točno tisto, kar je potrebno, da to imenujemo
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // VARNOST: Vanj smo vložili rezino elementov `new_len * N`
        // rezina `new_len` veliko kosov `N` elementov.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Rezino razdeli v rezino nizov elementov N, začenši na začetku rezine, in preostalo rezino z dolžino strogo manjšo od `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, če je `N` 0. To preverjanje se bo najverjetneje spremenilo v napako časa prevajanja, preden se ta metoda stabilizira.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // VARNOST: Že zdaj smo bili v paniki za nič in zagotovljeni z gradnjo
        // da je dolžina podreza večkratnik N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Rezino razdeli na rezino nizov elementov N, začenši na koncu rezine, in preostalo rezino z dolžino, strogo manjšo od `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics, če je `N` 0. To preverjanje se bo najverjetneje spremenilo v napako časa prevajanja, preden se ta metoda stabilizira.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // VARNOST: Že zdaj smo bili v paniki za nič in zagotovljeni z gradnjo
        // da je dolžina podreza večkratnik N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Vrne iterator za `N` elemente rezine naenkrat, začenši na začetku rezine.
    ///
    /// Kosi so spremenljivi referenčni nizi in se ne prekrivajo.
    /// Če `N` ne deli dolžine rezine, bodo izpuščeni zadnji elementi do `N-1`, ki jih je mogoče pridobiti iz funkcije `into_remainder` iteratorja.
    ///
    ///
    /// Ta metoda je splošni generični ekvivalent [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics, če je `N` 0. To preverjanje se bo najverjetneje spremenilo v napako časa prevajanja, preden se ta metoda stabilizira.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Vrne iterator, ki se prekriva z elementi windows `N` rezine, začenši na začetku rezine.
    ///
    ///
    /// To je skupni generični ekvivalent [`windows`].
    ///
    /// Če je `N` večja od velikosti rezine, ne vrne windows.
    ///
    /// # Panics
    ///
    /// Panics, če je `N` 0.
    /// To preverjanje se bo najverjetneje spremenilo v napako časa prevajanja, preden se ta metoda stabilizira.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Vrne iterator za `chunk_size` elemente rezine naenkrat, začenši na koncu rezine.
    ///
    /// Kosi so rezine in se ne prekrivajo.Če `chunk_size` ne deli dolžine rezine, potem zadnji kos ne bo imel dolžine `chunk_size`.
    ///
    /// Glejte [`rchunks_exact`] za različico tega iteratorja, ki vrne koščke vedno natančno elementov `chunk_size`, in [`chunks`] za isti iterator, vendar se začne na začetku rezine.
    ///
    ///
    /// # Panics
    ///
    /// Panics, če je `chunk_size` 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Vrne iterator za `chunk_size` elemente rezine naenkrat, začenši na koncu rezine.
    ///
    /// Kosi so spremenljive rezine in se ne prekrivajo.Če `chunk_size` ne deli dolžine rezine, potem zadnji kos ne bo imel dolžine `chunk_size`.
    ///
    /// Glejte [`rchunks_exact_mut`] za različico tega iteratorja, ki vrne koščke vedno natančno elementov `chunk_size`, in [`chunks_mut`] za isti iterator, vendar se začne na začetku rezine.
    ///
    ///
    /// # Panics
    ///
    /// Panics, če je `chunk_size` 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Vrne iterator za `chunk_size` elemente rezine naenkrat, začenši na koncu rezine.
    ///
    /// Kosi so rezine in se ne prekrivajo.
    /// Če `chunk_size` ne deli dolžine rezine, bodo izpuščeni zadnji elementi do `chunk_size-1`, ki jih je mogoče pridobiti iz funkcije `remainder` iteratorja.
    ///
    /// Zaradi vsakega dela, ki ima natančno elemente `chunk_size`, lahko prevajalnik pogosto optimizira nastalo kodo bolje kot v primeru [`chunks`].
    ///
    /// Glejte [`rchunks`] za različico tega iteratorja, ki prav tako vrne preostanek kot manjši kos, in [`chunks_exact`] za isti iterator, vendar se začne na začetku rezine.
    ///
    ///
    /// # Panics
    ///
    /// Panics, če je `chunk_size` 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Vrne iterator za `chunk_size` elemente rezine naenkrat, začenši na koncu rezine.
    ///
    /// Kosi so spremenljive rezine in se ne prekrivajo.
    /// Če `chunk_size` ne deli dolžine rezine, bodo izpuščeni zadnji elementi do `chunk_size-1`, ki jih je mogoče pridobiti iz funkcije `into_remainder` iteratorja.
    ///
    /// Zaradi vsakega dela, ki ima natančno elemente `chunk_size`, lahko prevajalnik pogosto optimizira nastalo kodo bolje kot v primeru [`chunks_mut`].
    ///
    /// Glejte [`rchunks_mut`] za različico tega iteratorja, ki prav tako vrne preostanek kot manjši kos, in [`chunks_exact_mut`] za isti iterator, vendar se začne na začetku rezine.
    ///
    ///
    /// # Panics
    ///
    /// Panics, če je `chunk_size` 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Vrne iterator nad rezino, ki proizvaja neprekrivajoče se poteke elementov, ki uporabljajo predikat, da jih loči.
    ///
    /// Predikat se imenuje za dva elementa, ki si sledita, kar pomeni, da se predikat imenuje na `slice[0]` in `slice[1]`, nato na `slice[1]` in `slice[2]` itd.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// S to metodo lahko izvlečemo razvrščene podrezike:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Vrne iterator nad rezino, ki proizvaja neprekrivajoče se spremenljive teke elementov z uporabo predikata, da jih loči.
    ///
    /// Predikat se imenuje za dva elementa, ki si sledita, kar pomeni, da se predikat imenuje na `slice[0]` in `slice[1]`, nato na `slice[1]` in `slice[2]` itd.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// S to metodo lahko izvlečemo razvrščene podrezike:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Deli en rez na dva v indeksu.
    ///
    /// Prva bo vsebovala vse indekse iz `[0, mid)` (razen samega indeksa `mid`), druga pa bo vse indekse iz `[mid, len)` (brez samega indeksa `len`).
    ///
    ///
    /// # Panics
    ///
    /// Panics, če `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // VARNOST: `[ptr; mid]` in `[mid; len]` sta znotraj `self`, ki
        // izpolnjuje zahteve `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Razdeli eno spremenljivo rezino na dve pri indeksu.
    ///
    /// Prva bo vsebovala vse indekse iz `[0, mid)` (razen samega indeksa `mid`), druga pa bo vse indekse iz `[mid, len)` (brez samega indeksa `len`).
    ///
    ///
    /// # Panics
    ///
    /// Panics, če `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // VARNOST: `[ptr; mid]` in `[mid; len]` sta znotraj `self`, ki
        // izpolnjuje zahteve `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Deli en rez na dva v indeksu, ne da bi preverjal meje.
    ///
    /// Prva bo vsebovala vse indekse iz `[0, mid)` (razen samega indeksa `mid`), druga pa bo vse indekse iz `[mid, len)` (brez samega indeksa `len`).
    ///
    ///
    /// Za varno alternativo glejte [`split_at`].
    ///
    /// # Safety
    ///
    /// Klicanje te metode z indeksom zunaj meje je *[nedefinirano vedenje]*, tudi če se uporabljena referenca ne uporablja.Klicatelj mora zagotoviti, da `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // VARNOST: Klicatelj mora preveriti, ali je `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Razdeli eno spremenljivo rezino na dve v indeksu, ne da bi preverjal meje.
    ///
    /// Prva bo vsebovala vse indekse iz `[0, mid)` (razen samega indeksa `mid`), druga pa bo vse indekse iz `[mid, len)` (brez samega indeksa `len`).
    ///
    ///
    /// Za varno alternativo glejte [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// Klicanje te metode z indeksom zunaj meje je *[nedefinirano vedenje]*, tudi če se uporabljena referenca ne uporablja.Klicatelj mora zagotoviti, da `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // VARNOST: Klicatelj mora preveriti, ali je `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` in `[mid; len]` se ne prekrivata, zato je vrnitev spremenljive reference skrajna.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Vrne iterator nad podklicami, ločenimi z elementi, ki se ujemajo z `pred`.
    /// Ujemajoči se element v podrezah ni.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Če se ujema prvi element, je prazen rez prvi element, ki ga vrne iterator.
    /// Če se ujema zadnji element v rezini, bo prazen rez zadnji element, ki ga vrne iterator:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Če sta dva ujemajoča se elementa neposredno sosednja, bo med njimi prazna rezina:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Vrne iterator nad spremenljivimi podlicami, ločenimi z elementi, ki se ujemajo z `pred`.
    /// Ujemajoči se element v podrezah ni.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Vrne iterator nad podklicami, ločenimi z elementi, ki se ujemajo z `pred`.
    /// Ujemajoči se element je na koncu prejšnje podrezane kot zaključek.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Če se ujema zadnji element rezine, se ta element šteje za zaključek predhodne rezine.
    ///
    /// Ta rezina bo zadnji element, ki ga je vrnil iterator.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Vrne iterator nad spremenljivimi podlicami, ločenimi z elementi, ki se ujemajo z `pred`.
    /// Ujemajoči se element je vsebovan v prejšnji podrezi kot zaključevalnik.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Vrne iterator nad podrezikami, ločenimi z elementi, ki se ujemajo z `pred`, začenši na koncu rezine in delujoč nazaj.
    /// Ujemajoči se element v podrezah ni.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Tako kot pri `split()`, če se prvi ali zadnji element ujema, bo prazna rezina prvi (ali zadnji) element, ki ga vrne iterator.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Vrne iterator nad spremenljivimi podrezij, ločenimi z elementi, ki se ujemajo z `pred`, začenši na koncu rezine in delujoč nazaj.
    /// Ujemajoči se element v podrezah ni.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Vrne iterator nad podlicami, ločenimi z elementi, ki se ujemajo z `pred`, omejeno na vrnitev največ elementov `n`.
    /// Ujemajoči se element v podrezah ni.
    ///
    /// Zadnji vrnjeni element, če sploh, bo vseboval preostanek rezine.
    ///
    /// # Examples
    ///
    /// Natisnite rezino, razdeljeno enkrat na številke, deljive s 3 (tj. `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Vrne iterator nad podlicami, ločenimi z elementi, ki se ujemajo z `pred`, omejeno na vrnitev največ elementov `n`.
    /// Ujemajoči se element v podrezah ni.
    ///
    /// Zadnji vrnjeni element, če sploh, bo vseboval preostanek rezine.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Vrne iterator nad podlicami, ločenimi z elementi, ki se ujemajo z `pred` in so omejeni na vrnitev največ elementov `n`.
    /// To se začne na koncu rezine in deluje nazaj.
    /// Ujemajoči se element v podrezah ni.
    ///
    /// Zadnji vrnjeni element, če sploh, bo vseboval preostanek rezine.
    ///
    /// # Examples
    ///
    /// Natisnite rezino, razdeljeno enkrat, začenši od konca, s številkami, deljivimi s 3 (tj. `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Vrne iterator nad podlicami, ločenimi z elementi, ki se ujemajo z `pred` in so omejeni na vrnitev največ elementov `n`.
    /// To se začne na koncu rezine in deluje nazaj.
    /// Ujemajoči se element v podrezah ni.
    ///
    /// Zadnji vrnjeni element, če sploh, bo vseboval preostanek rezine.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Vrne `true`, če rezina vsebuje element z dano vrednostjo.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Če nimate `&T`, ampak samo `&U`, takšen, da je `T: Borrow<U>` (npr
    /// `Niz: Izposoja<str>`), lahko uporabite `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // rezina `String`
    /// assert!(v.iter().any(|e| e == "hello")); // iskanje z `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Vrne `true`, če je `needle` predpona rezine.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Vedno vrne `true`, če je `needle` prazna rezina:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Vrne `true`, če je `needle` pripona rezine.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Vedno vrne `true`, če je `needle` prazna rezina:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Vrne podrezo z odstranjeno predpono.
    ///
    /// Če se rezina začne z `prefix`, vrne podrezo za predpono, ovito v `Some`.
    /// Če je `prefix` prazen, preprosto vrne prvotno rezino.
    ///
    /// Če se rezina ne začne z `prefix`, vrne `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // To funkcijo bo treba prepisati, če in ko bo SlicePattern bolj izpopolnjen.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Vrne podrezo z odstranjeno pripono.
    ///
    /// Če se rezina konča z `suffix`, vrne podrezano pred pripono, ovito v `Some`.
    /// Če je `suffix` prazen, preprosto vrne prvotno rezino.
    ///
    /// Če se rezina ne konča z `suffix`, vrne `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // To funkcijo bo treba prepisati, če in ko bo SlicePattern bolj izpopolnjen.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Binar išče to razvrščeno rezino za dani element.
    ///
    /// Če je vrednost najdena, se vrne [`Result::Ok`], ki vsebuje indeks ujemajočega se elementa.
    /// Če je ujemanj več, lahko vrnete katero koli od ujemanj.
    /// Če vrednosti ni mogoče najti, se vrne [`Result::Err`], ki vsebuje indeks, kamor bi lahko vstavil ujemajoč se element, hkrati pa ohranil razvrščen vrstni red.
    ///
    ///
    /// Glej tudi [`binary_search_by`], [`binary_search_by_key`] in [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Poišče vrsto štirih elementov.
    /// Najdeno je prvo z edinstveno določenim položajem;drugega in tretjega ni mogoče najti;četrti se lahko ujema s katerim koli položajem v `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Če želite element vstaviti v razvrščeni vector, pri tem pa ohraniti vrstni red razvrščanja:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Binar išče to razvrščeno rezino s primerjalno funkcijo.
    ///
    /// Primerjalna funkcija mora izvajati vrstni red, ki je skladen z vrstnim redom razvrščanja osnovne rezine, in vrne kodo naročila, ki označuje, ali je njen argument `Less`, `Equal` ali `Greater` želeni cilj.
    ///
    ///
    /// Če je vrednost najdena, se vrne [`Result::Ok`], ki vsebuje indeks ujemajočega se elementa.Če je ujemanj več, lahko vrnete katero koli od ujemanj.
    /// Če vrednosti ni mogoče najti, se vrne [`Result::Err`], ki vsebuje indeks, kamor bi lahko vstavil ujemajoč se element, hkrati pa ohranil razvrščen vrstni red.
    ///
    /// Glej tudi [`binary_search`], [`binary_search_by_key`] in [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Poišče vrsto štirih elementov.Najdeno je prvo z edinstveno določenim položajem;drugega in tretjega ni mogoče najti;četrti se lahko ujema s katerim koli položajem v `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // VARNOST: klic je varen z naslednjimi invariantami:
            // - `mid >= 0`
            // - `mid < size`: `mid` je omejen z vezavo `[left; right)`.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Razlog, zakaj uporabljamo nadzorni tok if/else namesto ujemanja, je v tem, da ujemanje preureja primerjalne operacije, kar je občutljivo na perforacije.
            //
            // To je x86 asm za u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Binar išče to razvrščeno rezino s funkcijo ekstrakcije ključa.
    ///
    /// Predpostavlja, da je rezina razvrščena po ključu, na primer pri [`sort_by_key`] z uporabo iste funkcije ekstrakcije ključa.
    ///
    /// Če je vrednost najdena, se vrne [`Result::Ok`], ki vsebuje indeks ujemajočega se elementa.
    /// Če je ujemanj več, lahko vrnete katero koli od ujemanj.
    /// Če vrednosti ni mogoče najti, se vrne [`Result::Err`], ki vsebuje indeks, kamor bi lahko vstavil ujemajoč se element, hkrati pa ohranil razvrščen vrstni red.
    ///
    ///
    /// Glej tudi [`binary_search`], [`binary_search_by`] in [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Poišče vrsto štirih elementov v rezini parov, razvrščenih po njihovih drugih elementih.
    /// Najdeno je prvo z edinstveno določenim položajem;drugega in tretjega ni mogoče najti;četrti se lahko ujema s katerim koli položajem v `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links je dovoljen, saj je `slice::sort_by_key` v crate `alloc` in kot tak še ne obstaja pri gradnji `core`.
    //
    // povezave do spodnjega dela crate: #74481.Ker so primitivi dokumentirani samo v libstd (#73423), to v praksi nikoli ne vodi do prekinjenih povezav.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Razvrsti rezino, vendar morda ne bo ohranil vrstnega reda enakih elementov.
    ///
    /// Ta sorta je nestabilna (tj. Lahko preureja enake elemente), nameščena (tj. Ne dodeli) in *O*(*n*\*log(* n*)) v najslabšem primeru.
    ///
    /// # Trenutna izvedba
    ///
    /// Trenutni algoritem temelji na [pattern-defeating quicksort][pdqsort], ki ga je izdelal Orson Peters, ki združuje hitri povprečni primer randomiziranega hitrega sortiranja s hitro najslabšim primerom težke sorte, hkrati pa doseže linearni čas na rezinah z določenimi vzorci.
    /// Za izogibanje degeneriranim primerom uporablja nekaj naključnih naključkov, vendar s fiksnim seed vedno zagotavlja deterministično vedenje.
    ///
    /// Običajno je hitrejše od stabilnega razvrščanja, razen v nekaj posebnih primerih, npr. Kadar je rezina sestavljena iz več združenih razvrščenih zaporedij.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Rezino razvrsti s primerjalno funkcijo, vendar morda ne bo ohranil vrstnega reda enakih elementov.
    ///
    /// Ta sorta je nestabilna (tj. Lahko preureja enake elemente), nameščena (tj. Ne dodeli) in *O*(*n*\*log(* n*)) v najslabšem primeru.
    ///
    /// Funkcija primerjave mora določiti skupno urejanje elementov v rezini.Če razvrščanje ni skupno, vrstni red elementov ni določen.Naročilo je skupno naročilo, če je (za vse `a`, `b` in `c`):
    ///
    /// * skupaj in antisimetrično: točno ena od `a < b`, `a == b` ali `a > b` je resnična in
    /// * prehodni, `a < b` in `b < c` pomeni `a < c`.Enako mora veljati za `==` in `>`.
    ///
    /// Na primer, medtem ko [`f64`] ne izvaja [`Ord`], ker `NaN != NaN`, lahko `partial_cmp` uporabimo kot funkcijo razvrščanja, če vemo, da rezina ne vsebuje `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Trenutna izvedba
    ///
    /// Trenutni algoritem temelji na [pattern-defeating quicksort][pdqsort], ki ga je izdelal Orson Peters, ki združuje hitri povprečni primer randomiziranega hitrega sortiranja s hitro najslabšim primerom težke sorte, hkrati pa doseže linearni čas na rezinah z določenimi vzorci.
    /// Za izogibanje degeneriranim primerom uporablja nekaj naključnih naključkov, vendar s fiksnim seed vedno zagotavlja deterministično vedenje.
    ///
    /// Običajno je hitrejše od stabilnega razvrščanja, razen v nekaj posebnih primerih, npr. Kadar je rezina sestavljena iz več združenih razvrščenih zaporedij.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // obratno sortiranje
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Rezino razvrsti s funkcijo izvlečenja ključa, vendar morda ne bo ohranil vrstnega reda enakih elementov.
    ///
    /// Ta sorta je nestabilna (tj. Lahko preureja enake elemente), nameščena (tj. Ne dodeli) in *O*(m\* * n *\* log(*n*)) najslabši primer, kjer je ključna funkcija *O*(*m*).
    ///
    /// # Trenutna izvedba
    ///
    /// Trenutni algoritem temelji na [pattern-defeating quicksort][pdqsort], ki ga je izdelal Orson Peters, ki združuje hitri povprečni primer randomiziranega hitrega sortiranja s hitro najslabšim primerom težke sorte, hkrati pa doseže linearni čas na rezinah z določenimi vzorci.
    /// Za izogibanje degeneriranim primerom uporablja nekaj naključnih naključkov, vendar s fiksnim seed vedno zagotavlja deterministično vedenje.
    ///
    /// Zaradi svoje ključne klicne strategije bo [`sort_unstable_by_key`](#method.sort_unstable_by_key) verjetno počasnejši od [`sort_by_cached_key`](#method.sort_by_cached_key), kadar je ključna funkcija draga.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Razrežite rezino tako, da je element v `index` v končnem razvrščenem položaju.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Rezino razporedite s primerjalno funkcijo, tako da je element v `index` v končnem razvrščenem položaju.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Rezino razporedite s funkcijo izvlečenja ključa, tako da je element v `index` v končnem razvrščenem položaju.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Razrežite rezino tako, da je element v `index` v končnem razvrščenem položaju.
    ///
    /// To preurejanje ima dodatno lastnost, da bo katera koli vrednost na položaju `i < index` manjša ali enaka kateri koli vrednosti na položaju `j > index`.
    /// Poleg tega je to preurejanje nestabilno (tj
    /// poljubno število enakih elementov lahko konča na položaju `index`), namesto njega (tj
    /// ne dodeli) in *O*(*n*) v najslabšem primeru.
    /// Ta funkcija je v drugih knjižnicah poznana tudi kot "kth element".
    /// Vrne trojček naslednjih vrednosti: vsi elementi, manjši od tistega v danem indeksu, vrednost pri danem indeksu in vsi elementi, večji od tistega v danem indeksu.
    ///
    ///
    /// # Trenutna izvedba
    ///
    /// Trenutni algoritem temelji na delu za hitri izbor istega algoritma za hitro sortiranje, ki se uporablja za [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics, kadar je `index >= len()`, kar pomeni, da je vedno panics na praznih rezinah.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Poiščite mediano
    /// v.select_nth_unstable(2);
    ///
    /// // Zagotovljeno nam je le, da bo rezina eno od naslednjih, glede na način razvrščanja glede na navedeni indeks.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Rezino razporedite s primerjalno funkcijo, tako da je element v `index` v končnem razvrščenem položaju.
    ///
    /// To preurejanje ima dodatno lastnost, da bo katera koli vrednost na položaju `i < index` z uporabo primerjalne funkcije manjša ali enaka kateri koli vrednosti na položaju `j > index`.
    /// Poleg tega je to preurejanje nestabilno (tj. Poljubno število enakih elementov se lahko znajde na položaju `index`), na mestu (tj. Ne dodeli) in *O*(*n*) v najslabšem primeru.
    /// Ta funkcija je v drugih knjižnicah znana tudi kot "kth element".
    /// Vrne trojček naslednjih vrednosti: vsi elementi, manjši od tistega v danem indeksu, vrednost pri danem indeksu in vsi elementi, večji od tistega v danem indeksu, z uporabo podane primerjalne funkcije.
    ///
    ///
    /// # Trenutna izvedba
    ///
    /// Trenutni algoritem temelji na delu za hitri izbor istega algoritma za hitro sortiranje, ki se uporablja za [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics, kadar je `index >= len()`, kar pomeni, da je vedno panics na praznih rezinah.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Poiščite mediano, kot da bi bila rezina razvrščena po padajočem vrstnem redu.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Zagotovljeno nam je le, da bo rezina eno od naslednjih, glede na način razvrščanja glede na navedeni indeks.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Rezino razporedite s funkcijo izvlečenja ključa, tako da je element v `index` v končnem razvrščenem položaju.
    ///
    /// To preurejanje ima dodatno lastnost, da bo katera koli vrednost na položaju `i < index` manjša ali enaka kateri koli vrednosti na položaju `j > index` s pomočjo funkcije ekstrakcije ključa.
    /// Poleg tega je to preurejanje nestabilno (tj. Poljubno število enakih elementov se lahko znajde na položaju `index`), na mestu (tj. Ne dodeli) in *O*(*n*) v najslabšem primeru.
    /// Ta funkcija je v drugih knjižnicah znana tudi kot "kth element".
    /// Vrne trojček naslednjih vrednosti: vsi elementi, manjši od tistega v danem indeksu, vrednost pri danem indeksu in vsi elementi, večji od tistega v danem indeksu, z uporabo funkcije izvlečenja ključa.
    ///
    ///
    /// # Trenutna izvedba
    ///
    /// Trenutni algoritem temelji na delu za hitri izbor istega algoritma za hitro sortiranje, ki se uporablja za [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics, kadar je `index >= len()`, kar pomeni, da je vedno panics na praznih rezinah.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Vrnite mediano, kot da bi bila matrika razvrščena glede na absolutno vrednost.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Zagotovljeno nam je le, da bo rezina eno od naslednjih, glede na način razvrščanja glede na navedeni indeks.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Premakne vse zaporedne ponavljajoče se elemente na konec rezine v skladu z izvedbo [`PartialEq`] Portrait.
    ///
    ///
    /// Vrne dve rezini.Prva ne vsebuje zaporednih ponavljajočih se elementov.
    /// Drugi vsebuje vse dvojnike v nobenem določenem vrstnem redu.
    ///
    /// Če je rezina razvrščena, prva vrnjena rezina ne vsebuje dvojnikov.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Premakne vse zaporedne elemente razen prvega na konec rezine, ki izpolnjuje dano relacijo enakosti.
    ///
    /// Vrne dve rezini.Prva ne vsebuje zaporednih ponavljajočih se elementov.
    /// Drugi vsebuje vse dvojnike v nobenem določenem vrstnem redu.
    ///
    /// Funkciji `same_bucket` se posredujejo sklici na dva elementa iz rezine in mora določiti, ali se elementi primerjajo enako.
    /// Elementi se posredujejo v nasprotnem vrstnem redu od njihovega vrstnega reda v rezini, tako da, če `same_bucket(a, b)` vrne `true`, se `a` premakne na koncu rezine.
    ///
    ///
    /// Če je rezina razvrščena, prva vrnjena rezina ne vsebuje dvojnikov.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Čeprav imamo spremenljiv sklic na `self`, ne moremo narediti *poljubnih* sprememb.Klici `same_bucket` bi lahko bili panic, zato moramo zagotoviti, da je rezina ves čas v veljavnem stanju.
        //
        // To rešujemo s pomočjo zamenjav;ponavljamo se nad vsemi elementi, pri čemer zamenjamo, tako da so na koncu elementi, ki jih želimo obdržati, spredaj, tisti, ki jih želimo zavrniti, pa zadaj.
        // Nato lahko rezino razdelimo.
        // Ta operacija je še vedno `O(n)`.
        //
        // Primer: Začnemo v tem stanju, kjer `r` predstavlja "naslednji"
        // preberite "in `w` predstavlja" next_write`.
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Če primerjamo self[r] z lastnim [w-1], to ni dvojnik, zato zamenjamo self[r] in self[w] (brez učinka kot r==w) in nato povečamo r in w, pri čemer ostane:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Če primerjamo self[r] z lastnim [w-1], je ta vrednost dvojnik, zato `r` povečamo, vse ostalo pa pustimo nespremenjeno:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Če primerjate self[r] z lastnim [w-1], to ni dvojnik, zato zamenjajte self[r] in self[w] ter vnaprej r in w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Ni dvojnik, ponovite:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Dvojnik, rezina advance r. End.Razdeljen na w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // VARNOST: pogoj `while` zagotavlja `next_read` in `next_write`
        // so manjši od `len`, torej so znotraj `self`.
        // `prev_ptr_write` kaže na en element pred `ptr_write`, vendar se `next_write` začne na 1, zato `prev_ptr_write` ni nikoli manjši od 0 in je znotraj rezine.
        // To izpolnjuje zahteve za razporejanje referenc `ptr_read`, `prev_ptr_write` in `ptr_write` ter za uporabo `ptr.add(next_read)`, `ptr.add(next_write - 1)` in `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` prav tako se poveča največ enkrat na zanko, kar pomeni, da noben element ni preskočen, ko ga bo morda treba zamenjati.
        //
        // `ptr_read` in `prev_ptr_write` nikoli ne kažeta na isti element.To je potrebno, da so `&mut *ptr_read`, `&mut* prev_ptr_write` varne.
        // Razlaga je preprosto v tem, da `next_read >= next_write` vedno drži, s tem pa tudi `next_read > next_write - 1`.
        //
        //
        //
        //
        //
        unsafe {
            // Izogibajte se preverjanju meja z uporabo surovih kazalcev.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Premakne vse zaporedne elemente razen prvega na konec rezine, ki se razreši na isti ključ.
    ///
    ///
    /// Vrne dve rezini.Prva ne vsebuje zaporednih ponavljajočih se elementov.
    /// Drugi vsebuje vse dvojnike v nobenem določenem vrstnem redu.
    ///
    /// Če je rezina razvrščena, prva vrnjena rezina ne vsebuje dvojnikov.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Zareže rezino na mestu tako, da se prvi elementi `mid` rezine premaknejo na konec, zadnji elementi `self.len() - mid` pa spredaj.
    /// Po klicu `rotate_left` bo element, ki je bil prej označen z indeksom `mid`, postal prvi element v rezini.
    ///
    /// # Panics
    ///
    /// Ta funkcija bo panic, če je `mid` večja od dolžine rezine.Upoštevajte, da `mid == self.len()` uporablja _not_ panic in je rotacija brez možnosti.
    ///
    /// # Complexity
    ///
    /// Traja linearno (v času `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Vrtenje podreza:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // VARNOST: Razpon `[p.add(mid) - mid, p.add(mid) + k)` je trivialen
        // velja za branje in pisanje, kot zahteva `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Zareže rezino na mestu tako, da se prvi elementi `self.len() - k` rezine premaknejo na konec, zadnji elementi `k` pa spredaj.
    /// Po klicu `rotate_right` bo element, ki je bil prej označen z indeksom `self.len() - k`, postal prvi element v rezini.
    ///
    /// # Panics
    ///
    /// Ta funkcija bo panic, če je `k` večja od dolžine rezine.Upoštevajte, da `k == self.len()` uporablja _not_ panic in je rotacija brez možnosti.
    ///
    /// # Complexity
    ///
    /// Traja linearno (v času `self.len()`).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Zavrti podrezano:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // VARNOST: Razpon `[p.add(mid) - mid, p.add(mid) + k)` je trivialen
        // velja za branje in pisanje, kot zahteva `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Napolni `self` z elementi s kloniranjem `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Napolni `self` z elementi, ki se vrnejo z večkratnim klicem zapore.
    ///
    /// Ta metoda uporablja zapiranje za ustvarjanje novih vrednosti.Če želite [`Clone`] določeno vrednost, uporabite [`fill`].
    /// Če želite uporabiti [`Default`] Portrait za generiranje vrednosti, lahko kot argument posredujete [`Default::default`].
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Kopira elemente iz `src` v `self`.
    ///
    /// Dolžina `src` mora biti enaka kot `self`.
    ///
    /// Če `T` izvaja `Copy`, je lahko bolj učinkovita uporaba [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Ta funkcija bo panic, če imata rezini različno dolžino.
    ///
    /// # Examples
    ///
    /// Kloniranje dveh elementov iz rezine v drugega:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Ker morajo biti rezine enake dolžine, izvorno rezino razrežemo s štirih elementov na dva.
    /// // Če tega ne storimo, bo panic.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust uveljavlja, da je lahko samo ena spremenljiva referenca brez nespremenljivih referenc na določen del podatkov v določenem obsegu.
    /// Zaradi tega bo poskus uporabe `clone_from_slice` na eni rezini povzročil neuspešno prevajanje:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Da bi to rešili, lahko z [`split_at_mut`] iz rezine ustvarimo dve ločeni podrezi:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Kopira vse elemente iz `src` v `self` z uporabo memcpy.
    ///
    /// Dolžina `src` mora biti enaka kot `self`.
    ///
    /// Če `T` ne izvaja `Copy`, uporabite [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Ta funkcija bo panic, če imata rezini različno dolžino.
    ///
    /// # Examples
    ///
    /// Kopiranje dveh elementov iz rezine v drugega:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Ker morajo biti rezine enake dolžine, izvorno rezino razrežemo s štirih elementov na dva.
    /// // Če tega ne storimo, bo panic.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust uveljavlja, da je lahko samo ena spremenljiva referenca brez nespremenljivih referenc na določen del podatkov v določenem obsegu.
    /// Zaradi tega bo poskus uporabe `copy_from_slice` na eni rezini povzročil neuspešno prevajanje:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// Da bi to rešili, lahko z [`split_at_mut`] iz rezine ustvarimo dve ločeni podrezi:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // Pot kode panic je bila postavljena v hladno funkcijo, da ne napihne mesta klica.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // VARNOST: `self` velja za elemente `self.len()` po definiciji in `src` je bil
        // označeno, da ima enako dolžino.
        // Rezine se ne morejo prekrivati, ker so spremenljive reference izključne.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Kopira elemente iz enega dela rezine v drug del sebe z uporabo memvove.
    ///
    /// `src` je obseg znotraj `self`, iz katerega želite kopirati.
    /// `dest` je začetni indeks obsega znotraj `self`, v katerega želite kopirati, ki bo imel enako dolžino kot `src`.
    /// Območja se lahko prekrivata.
    /// Konca obeh območij morata biti manjša ali enaka `self.len()`.
    ///
    /// # Panics
    ///
    /// Ta funkcija bo panic, če kateri koli obseg presega konec rezine ali če je konec `src` pred začetkom.
    ///
    ///
    /// # Examples
    ///
    /// Kopiranje štirih bajtov znotraj rezine:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // VARNOST: vsi pogoji za `ptr::copy` so bili preverjeni zgoraj,
        // tako kot tiste za `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Zamenja vse elemente v `self` s tistimi v `other`.
    ///
    /// Dolžina `other` mora biti enaka kot `self`.
    ///
    /// # Panics
    ///
    /// Ta funkcija bo panic, če imata rezini različno dolžino.
    ///
    /// # Example
    ///
    /// Zamenjava dveh elementov na rezinah:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust uveljavlja, da je lahko določen del podatkov v določenem obsegu samo en spremenljiv.
    ///
    /// Zaradi tega bo poskus uporabe `swap_with_slice` na eni rezini povzročil neuspešno prevajanje:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// Da bi to rešili, lahko z [`split_at_mut`] iz rezine ustvarimo dve različni spremenljivi podrezi:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // VARNOST: `self` velja za elemente `self.len()` po definiciji in `src` je bil
        // označeno, da ima enako dolžino.
        // Rezine se ne morejo prekrivati, ker so spremenljive reference izključne.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Funkcija za izračun dolžine srednje in zadnje rezine za `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Kar bomo storili pri `rest`, je ugotoviti, katere množice U-jev lahko damo v najmanjše število T-jev.
        //
        // In koliko T potrebujemo za vsak tak "multiple".
        //
        // Upoštevajmo na primer T=u8 U=u16.Potem lahko damo 1 U v 2 Ts.Preprosto.
        // Zdaj pa razmislite na primer o primeru, ko size_of: :<T>=16, velikost_::::<U>24.</u>
        // Namesto vsakih 3 Ts v rezini `rest` lahko namestimo 2 Us.
        // Nekoliko bolj zapleteno.
        //
        // Formula za izračun tega je:
        //
        // Nas= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Razširjeno in poenostavljeno:
        //
        // Nas=velikost_: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=velikost_::::<U>gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Na srečo, ker se vse to neprestano ocenjuje ... uspešnost tukaj ni pomembna!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // iterativni Steinov algoritem Še vedno bi morali narediti ta `const fn` (in se vrniti na rekurzivni algoritem, če to storimo), ker je zanašanje na llvm za konstelacijo vsega tega ... no, neprijetno mi je.
            //
            //

            // VARNOST: `a` in `b` sta preverjeni kot različni od nič.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // odstranite vse faktorje 2 iz b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // VARNOST: `b` je preverjeno, da ni nič.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Oboroženi s tem znanjem lahko ugotovimo, koliko U-jev lahko namestimo!
        let us_len = self.len() / ts * us;
        // In koliko "T" bo v zadnji rezini!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Rezino pretvorite v rezino druge vrste in zagotovite, da se ohrani poravnava tipov.
    ///
    /// Ta metoda razdeli rezino na tri ločene rezine: predpono, pravilno poravnano srednjo rezino novega tipa in rezino končnice.
    /// Z metodo lahko srednja rezina omogoči največjo možno dolžino za dani tip in vhodno rezino, vendar mora biti od tega odvisna samo uspešnost vašega algoritma, ne pa tudi njegova pravilnost.
    ///
    /// Dovoljeno je, da se vsi vhodni podatki vrnejo kot rezina predpone ali pripone.
    ///
    /// Ta metoda nima namena, če sta vhodni element `T` ali izhodni element `U` ničelne velikosti in bo vrnila prvotno rezino, ne da bi karkoli razdelila.
    ///
    /// # Safety
    ///
    /// Ta metoda je v bistvu `transmute` glede na elemente v vrnjeni srednji rezini, zato tudi tukaj veljajo vsa običajna opozorila, ki se nanašajo na `transmute::<T, U>`.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Upoštevajte, da bo večina te funkcije stalno ocenjena,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // z ZST-ji ravnajte posebej, kar je-sploh ne ravnajte z njimi.
            return (self, &[], &[]);
        }

        // Najprej poiščite, na kateri točki razdelimo prvo in drugo rezino.
        // Enostavno z ptr.align_offset.
        let ptr = self.as_ptr();
        // VARNOST: Za podrobne varnostne pripombe glejte metodo `align_to_mut`.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // VARNOST: zdaj je `rest` zagotovo poravnan, zato je spodnji `from_raw_parts` v redu,
            // saj klicatelj zagotavlja, da lahko `T` varno pretvorimo v `U`.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Rezino pretvorite v rezino druge vrste in zagotovite, da se ohrani poravnava tipov.
    ///
    /// Ta metoda razdeli rezino na tri ločene rezine: predpono, pravilno poravnano srednjo rezino novega tipa in rezino končnice.
    /// Z metodo lahko srednja rezina omogoči največjo možno dolžino za dani tip in vhodno rezino, vendar mora biti od tega odvisna samo uspešnost vašega algoritma, ne pa tudi njegova pravilnost.
    ///
    /// Dovoljeno je, da se vsi vhodni podatki vrnejo kot rezina predpone ali pripone.
    ///
    /// Ta metoda nima namena, če sta vhodni element `T` ali izhodni element `U` ničelne velikosti in bo vrnila prvotno rezino, ne da bi karkoli razdelila.
    ///
    /// # Safety
    ///
    /// Ta metoda je v bistvu `transmute` glede na elemente v vrnjeni srednji rezini, zato tudi tukaj veljajo vsa običajna opozorila, ki se nanašajo na `transmute::<T, U>`.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Upoštevajte, da bo večina te funkcije stalno ocenjena,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // z ZST-ji ravnajte posebej, kar je-sploh ne ravnajte z njimi.
            return (self, &mut [], &mut []);
        }

        // Najprej poiščite, na kateri točki razdelimo prvo in drugo rezino.
        // Enostavno z ptr.align_offset.
        let ptr = self.as_ptr();
        // VARNOST: Tu zagotavljamo, da bomo uporabili poravnane kazalce za U za
        // preostali del metode.To se naredi tako, da na&[T] posredujete kazalnik s poravnavo, usmerjeno na U.
        // `crate::ptr::align_offset` se pokliče s pravilno poravnanim in veljavnim kazalcem `ptr` (izhaja iz sklicevanja na `self`) in z velikostjo, ki je stepen dve (ker prihaja iz odtujenosti za U), ki izpolnjuje svoje varnostne omejitve.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Po tem `rest` ne moremo več uporabiti, kar bi razveljavilo njegov vzdevek `mut_ptr`!VARNOST: glej komentarje za `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Preveri, ali so elementi te rezine razvrščeni.
    ///
    /// To pomeni, da mora za vsak element `a` in naslednji element `b` veljati `a <= b`.Če rezina daje natančno nič ali en element, se vrne `true`.
    ///
    /// Če je `Self::Item` samo `PartialOrd`, ne pa tudi `Ord`, zgornja definicija pomeni, da ta funkcija vrne `false`, če katera koli zaporedna elementa nista primerljiva.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Preveri, ali so elementi te rezine razvrščeni z dano primerjalno funkcijo.
    ///
    /// Namesto da uporablja `PartialOrd::partial_cmp`, ta funkcija uporablja dano funkcijo `compare` za določanje razvrščanja dveh elementov.
    /// Poleg tega je enakovreden [`is_sorted`];glejte njegovo dokumentacijo za več informacij.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Preveri, ali so elementi te rezine razvrščeni z dano funkcijo izvlečenja ključa.
    ///
    /// Namesto da neposredno primerja elemente rezine, ta funkcija primerja tipke elementov, kot jih določa `f`.
    /// Poleg tega je enakovreden [`is_sorted`];glejte njegovo dokumentacijo za več informacij.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Vrne indeks particijske točke glede na dani predikat (indeks prvega elementa druge particije).
    ///
    /// Predpostavka je, da je rezina razdeljena glede na dani predikat.
    /// To pomeni, da so vsi elementi, za katere predikat vrne true, na začetku rezine in vsi elementi, za katere predikat vrne false, na koncu.
    ///
    /// Na primer, [7, 15, 3, 5, 4, 12, 6] je razdeljen na predikat x% 2!=0 (vsa neparna števila so na začetku, vsa celo na koncu).
    ///
    /// Če ta rezina ni razdeljena, je vrnjeni rezultat nedoločen in nesmiseln, saj ta metoda izvaja nekakšno binarno iskanje.
    ///
    /// Glej tudi [`binary_search`], [`binary_search_by`] in [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // VARNOST: Ko `left < right`, `left <= mid < right`.
            // Zato se `left` vedno poveča in `right` vedno zmanjša in izbere se kateri koli od njih.V obeh primerih je `left <= right` zadovoljen.Če je torej `left < right` v koraku, je `left <= right` v naslednjem koraku zadovoljen.
            //
            // Torej, dokler je `left != right` zadovoljen `0 <= left < right <= len` in če je tudi `0 <= mid < len` zadovoljen.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Izrecno jih moramo razrezati na enako dolžino
        // da olajša optimizatorju izmikanje preverjanja meja.
        // Ker pa se na to ni mogoče zanesti, imamo tudi izrecno specializacijo za T: Copy.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Ustvari prazno rezino.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Ustvari spremenljivo prazno rezino.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Vzorci v rezinah, trenutno jih uporabljajo samo `strip_prefix` in `strip_suffix`.
/// Na točki future upamo, da bomo `core::str::Pattern` (ki je v času pisanja omejen na `str`) posplošili na rezine, nato pa bo ta Portrait zamenjan ali ukinjen.
///
pub trait SlicePattern {
    /// Vrsta elementa rezine, na katero se ujema.
    type Item;

    /// Trenutno potrošniki `SlicePattern` potrebujejo rezino.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}