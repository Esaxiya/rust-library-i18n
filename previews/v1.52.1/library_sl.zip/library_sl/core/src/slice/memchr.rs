// Prvotna izvedba je vzeta iz rust-memchr.
// Copyright 2015 Andrew Gallant, bluss in Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Uporabite okrnitev.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Vrne `true`, če `x` vsebuje noben bajt.
///
/// Iz *Matters Computational*, J. Arndt:
///
/// "Ideja je odšteti po enega od vsakega bajta in nato poiskati bajte, kjer se je izposoja širila vse do najpomembnejših
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Vrne prvi indeks, ki se ujema z bajtom `x` v `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Hitra pot za majhne rezine
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Poiščite enobajtno vrednost tako, da hkrati preberete dve besedi `usize`.
    //
    // Razdelite `text` na tri dele
    // - neusklajeni začetni del pred naslovom, poravnanim s prvo besedo v besedilu
    // - telo, skeniraj po dve besedi hkrati
    // - zadnji preostali del, <2 besedi

    // iskanje do poravnane meje
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // išči po besedilu
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // VARNOST: predikat while zagotavlja razdaljo najmanj 2 * usize_bytes
        // med zamikom in koncem rezine.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // break, če obstaja ustrezen bajt
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Poiščite bajt po točki, v kateri se je ustavila zanka telesa.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Vrne zadnji indeks, ki se ujema z bajtom `x` v `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Poiščite enobajtno vrednost tako, da hkrati preberete dve besedi `usize`.
    //
    // Razdelite `text` na tri dele:
    // - neskladen rep, po naslovu poravnane z zadnjo besedo v besedilu,
    // - telo, skenirano z dvema besedama hkrati,
    // - prvi preostali bajti, velikosti <2 besedi.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // To imenujemo samo zato, da dobimo dolžino predpone in končnice.
        // Na sredini vedno obdelamo dva kosa hkrati.
        // VARNOST: pretvorba `[u8]` v `[usize]` je varna, razen pri razlikah v velikosti, ki jih obravnava `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Poiščite telo besedila in se prepričajte, da ne prečkamo min_aligned_offset.
    // odmik je vedno poravnan, zato zadostuje samo testiranje `>` in se izogne morebitnemu prelivanju.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // VARNOST: odmik se začne pri len, suffix.len(), če je večji od
        // min_aligned_offset (prefix.len()) je preostala razdalja najmanj 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Prekini, če obstaja ustrezen bajt.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Poiščite bajt, preden se točka ustavi.
    text[..offset].iter().rposition(|elt| *elt == x)
}