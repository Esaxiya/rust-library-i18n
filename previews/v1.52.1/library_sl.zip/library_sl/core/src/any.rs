//! Ta modul izvaja `Any` Portrait, ki omogoča dinamično tipkanje katerega koli tipa `'static` s pomočjo odseva med izvajanjem.
//!
//! `Any` samega sebe lahko uporabimo za pridobitev `TypeId` in ima več funkcij, če se uporablja kot objekt Portrait.
//! Kot `&dyn Any` (izposojeni objekt Portrait) ima metode `is` in `downcast_ref`, da preizkusi, ali je vsebovana vrednost določenega tipa, in da sklic na notranjo vrednost kot tip.
//! Kot `&mut dyn Any` obstaja tudi metoda `downcast_mut` za pridobitev spremenljivega sklica na notranjo vrednost.
//! `Box<dyn Any>` dodaja metodo `downcast`, ki poskuša pretvoriti v `Box<T>`.
//! Za vse podrobnosti glejte dokumentacijo [`Box`].
//!
//! Upoštevajte, da je `&dyn Any` omejen na preizkušanje, ali je vrednost določene betonske vrste, in je ni mogoče uporabiti za preizkušanje, ali tip izvaja Portrait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Pametni kazalci in `dyn Any`
//!
//! Eno vedenje, ki ga je treba upoštevati pri uporabi `Any` kot predmeta Portrait, zlasti pri tipih, kot je `Box<dyn Any>` ali `Arc<dyn Any>`, je, da preprosto klicanje vrednosti `.type_id()` na vrednost ustvari `TypeId` vsebnika *, ne pa osnovnega predmeta Portrait.
//!
//! Temu se je mogoče izogniti s pretvorbo pametnega kazalca v `&dyn Any`, ki bo vrnil `TypeId` predmeta.
//! Na primer:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Verjetneje boste želeli to:
//! let actual_id = (&*boxed).type_id();
//! // ... kot to:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Razmislite o situaciji, ko želimo odjaviti vrednost, posredovano funkciji.
//! Vemo, na kakšni vrednosti delamo, izvaja Debug, vendar ne poznamo njegove konkretne vrste.Nekaterim vrstam želimo posvetiti posebno pozornost: v tem primeru natisnemo dolžino vrednosti String pred njihovo vrednostjo.
//! V času prevajanja ne poznamo konkretne vrste naše vrednosti, zato moramo namesto tega uporabiti razmislek med izvajanjem.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Logger funkcija za katero koli vrsto, ki izvaja razhroščevanje.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Poskusite pretvoriti našo vrednost v `String`.
//!     // Če je uspešen, želimo prikazati dolžino niza in njegovo vrednost.
//!     // Če ne, je drugačna vrsta: preprosto jo natisnite brez okraskov.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Ta funkcija želi odjaviti svoj parameter, preden začne delati z njim.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... opravljam kakšno drugo delo
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Vsak Portrait
///////////////////////////////////////////////////////////////////////////////

/// Portrait za posnemanje dinamičnega tipkanja.
///
/// Večina tipov uporablja `Any`.Kakršna koli vrsta, ki vsebuje nestetično referenco, pa ne.
/// Za več podrobnosti glejte [module-level documentation][mod].
///
/// [mod]: crate::any
// Ta Portrait ni varen, čeprav se zanašamo na posebnosti funkcije `type_id` edinega impl v nevarni kodi (npr. `downcast`).Običajno bi to predstavljalo težavo, ker pa je edini impulz `Any` splošna izvedba, nobena druga koda ne more implementirati `Any`.
//
// Verjetno bi lahko naredili ta Portrait nevarnim-ne bi povzročil zloma, saj nadzorujemo vse izvedbe-vendar se odločimo, da to res ni potrebno in lahko uporabnike zmede glede razlikovanja med nevarnimi traits in nevarnimi metodami (tj. `type_id` bi bilo še vedno varno poklicati, vendar bi ga verjetno želeli navesti v dokumentaciji).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Pridobi `TypeId` `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Metode razširitve za katere koli predmete Portrait.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Prepričajte se, da je mogoče rezultat npr. Združevanja niti natisniti in s tem uporabiti z `unwrap`.
// Morda sčasoma ne bo več potreben, če pošiljanje deluje s posodobitvijo.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Vrne `true`, če je vrsta v polju enaka kot `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Pridobite `TypeId` vrste, s katero je ustvarjena ta funkcija.
        let t = TypeId::of::<T>();

        // Pridobite `TypeId` tipa v objektu Portrait (`self`).
        let concrete = self.type_id();

        // Primerjajte oba `TypeId` o enakosti.
        t == concrete
    }

    /// Vrne sklic na vrednost v polju, če je tipa `T`, ali `None`, če ni.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // VARNOST: pravkar smo preverili, ali usmerjamo na pravi tip, in se lahko zanesemo
            // to preverjanje varnosti pomnilnika, ker smo uvedli Any za vse vrste;noben drug impulz ne more obstajati, saj bi bil v nasprotju z našim impl.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Vrne nekaj spremenljivega sklica na vrednost v polju, če je tipa `T`, ali `None`, če ni.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // VARNOST: pravkar smo preverili, ali usmerjamo na pravi tip, in se lahko zanesemo
            // to preverjanje varnosti pomnilnika, ker smo uvedli Any za vse vrste;noben drug impulz ne more obstajati, saj bi bil v nasprotju z našim impl.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Naprej do metode, definirane za tip `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Naprej do metode, definirane za tip `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Naprej do metode, definirane za tip `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Naprej do metode, definirane za tip `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Naprej do metode, definirane za tip `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Naprej do metode, definirane za tip `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID in njegove metode
///////////////////////////////////////////////////////////////////////////////

/// `TypeId` predstavlja globalno unikatni identifikator za tip.
///
/// Vsak `TypeId` je neprozoren objekt, ki ne omogoča pregleda, kaj je v njem, omogoča pa osnovne operacije, kot so kloniranje, primerjava, tiskanje in prikazovanje.
///
///
/// `TypeId` je trenutno na voljo samo za tipe, ki pripisujejo `'static`, vendar je to omejitev mogoče odstraniti v future.
///
/// Medtem ko `TypeId` izvaja `Hash`, `PartialOrd` in `Ord`, je treba omeniti, da se razpršitve in razvrščanje med različicami Rust razlikujejo.
/// Pazite, da se v svoji kodi ne zanašate nanje!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Vrne `TypeId` vrste, s katero je bila generirana funkcija ustvarjena.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Vrne ime tipa kot rezino niza.
///
/// # Note
///
/// Ta je namenjen diagnostični uporabi.
/// Natančna vsebina in oblika vrnjenega niza nista določena, razen če je opis vrste najboljši.
/// Na primer, med nizi, ki bi jih lahko vrnil `type_name::<Option<String>>()`, so `"Option<String>"` in `"std::option::Option<std::string::String>"`.
///
///
/// Vrnjeni niz se ne sme šteti za enolični identifikator tipa, saj se lahko več tipov preslika v isto ime tipa.
/// Podobno ni nobenega zagotovila, da se bodo vsi elementi vrste pojavili v vrnjenem nizu: na primer trenutno niso vključeni življenjski opisi.
/// Poleg tega se lahko rezultat spreminja med različicami prevajalnika.
///
/// Trenutna izvedba uporablja enako infrastrukturo kot diagnostika prevajalnika in debuginfo, vendar to ni zagotovljeno.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Vrne ime vrste vrednosti, na katero je opozorjeno, kot rezino niza.
/// To je enako kot `type_name::<T>()`, vendar se lahko uporablja, kadar vrsta spremenljivke ni lahko dostopna.
///
/// # Note
///
/// Ta je namenjen diagnostični uporabi.Natančna vsebina in oblika niza nista določena, razen če je opis vrste najboljši.
/// Na primer, `type_name_of_val::<Option<String>>(None)` lahko vrne `"Option<String>"` ali `"std::option::Option<std::string::String>"`, `"foobar"` pa ne.
///
/// Poleg tega se lahko rezultat spreminja med različicami prevajalnika.
///
/// Ta funkcija ne razrešuje objektov Portrait, kar pomeni, da lahko `type_name_of_val(&7u32 as &dyn Debug)` vrne `"dyn Debug"`, ne pa tudi `"u32"`.
///
/// Ime tipa se ne sme šteti za enolični identifikator tipa;
/// več vrst ima lahko isto ime tipa.
///
/// Trenutna izvedba uporablja enako infrastrukturo kot diagnostika prevajalnika in debuginfo, vendar to ni zagotovljeno.
///
/// # Examples
///
/// Natisne privzete vrste celih števil in float.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}