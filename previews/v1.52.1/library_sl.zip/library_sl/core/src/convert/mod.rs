//! Traits za pretvorbe med vrstami.
//!
//! traits v tem modulu omogoča pretvorbo iz ene vrste v drugo.
//! Vsak Portrait ima drugačen namen:
//!
//! - Za poceni pretvorbo referenca v referenco izvedite [`AsRef`] Portrait
//! - Uporabite [`AsMut`] Portrait za poceni pretvorljive spremenljive v spremenljive
//! - Uporabite [`From`] Portrait za porabo pretvorb vrednosti v vrednost
//! - Implementirajte [`Into`] Portrait za porabo pretvorb vrednosti v vrednost v tipe zunaj trenutnega crate
//! - [`TryFrom`] in [`TryInto`] traits se obnašata kot [`From`] in [`Into`], vendar ju je treba izvesti, kadar pretvorba ne uspe.
//!
//! traits v tem modulu se pogosto uporabljajo kot Portrait bounds za generične funkcije, tako da so podprti argumenti več vrst.Za primere glejte dokumentacijo vsakega Portrait.
//!
//! Kot avtor knjižnice bi raje kot [`Into<U>`][`Into`] ali [`TryInto<U>`][`TryInto`] namesto [`Into<U>`][`Into`] ali [`TryInto<U>`][`TryInto`] raje uvedli [`From<T>`][`From`] ali [`TryFrom<T>`][`TryFrom`], saj [`From`] in [`TryFrom`] zagotavljata večjo prilagodljivost in ponujata enakovredne izvedbe [`Into`] ali [`TryInto`], zahvaljujoč splošni izvedbi v standardni knjižnici.
//! Ko ciljate na različico pred Rust 1.41, bo morda treba neposredno pretvoriti [`Into`] ali [`TryInto`] pri pretvorbi v tip zunaj trenutnega crate.
//!
//! # Splošne izvedbe
//!
//! - [`AsRef`] in samodejno razporejanje [`AsMut`], če je notranji tip referenčni
//! - [`From`]`<U>za T` pomeni [`Into`]`</u><T><U>za U`</u>
//! - ["TryFrom`]"<U>za T"pomeni ["TryInto`] "</u><T><U>za U`</u>
//! - [`From`] in [`Into`] sta refleksna, kar pomeni, da lahko vse vrste `into` same in `from` same
//!
//! Za primere uporabe si oglejte vsak Portrait.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Funkcija identitete.
///
/// Pri tej funkciji je treba upoštevati dve stvari:
///
/// - Ni vedno enakovredno zapiranju, kot je `|x| x`, saj lahko zaprtje `x` prisili v drugo vrsto.
///
/// - Premakne vhod `x`, poslan v funkcijo.
///
/// Čeprav se zdi nenavadno, da ima funkcija, ki samo vrne vložek, obstaja nekaj zanimivih načinov uporabe.
///
///
/// # Examples
///
/// Uporaba `identity` za izvajanje ničesar v zaporedju drugih zanimivih funkcij:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Pretvarjajmo se, da je dodajanje zanimive funkcije.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Uporaba `identity` kot osnovnega primera "do nothing" v pogojnem primeru:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Naredite še zanimive stvari ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Uporaba `identity` za ohranjanje različic `Some` iteratorja `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Uporablja se za poceni pretvorbo referenca v referenco.
///
/// Ta Portrait je podoben [`AsMut`], ki se uporablja za pretvorbo med spremenljivimi referencami.
/// Če potrebujete drago pretvorbo, je bolje, da [`From`] uporabite s tipom `&T` ali napišete funkcijo po meri.
///
/// `AsRef` ima enak podpis kot [`Borrow`], vendar se [`Borrow`] v nekaj pogledih razlikuje:
///
/// - V nasprotju z `AsRef` ima [`Borrow`] splošen impl za kateri koli `T` in se lahko uporablja za sprejem referenc ali vrednosti.
/// - [`Borrow`] zahteva tudi, da so [`Hash`], [`Eq`] in [`Ord`] za izposojeno vrednost enakovredne vrednostim v lasti.
/// Iz tega razloga, če želite izposoditi samo eno polje strukture, lahko uporabite `AsRef`, ne pa tudi [`Borrow`].
///
/// **Note: Ta Portrait ne sme odpovedati **.Če pretvorba ne uspe, uporabite namensko metodo, ki vrne [`Option<T>`] ali [`Result<T, E>`].
///
/// # Splošne izvedbe
///
/// - `AsRef` samodejne preusmeritve, če je notranji tip referenca ali spremenljiv sklic (npr .: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Z uporabo Portrait bounds lahko sprejemamo argumente različnih vrst, če jih je mogoče pretvoriti v določen tip `T`.
///
/// Na primer: Z ustvarjanjem generične funkcije, ki zajema `AsRef<str>`, izrazimo, da želimo kot argument sprejeti vse reference, ki jih je mogoče pretvoriti v [`&str`].
/// Ker oba [`String`] in [`&str`] izvajata `AsRef<str>`, lahko oba sprejmemo kot vhodni argument.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Izvede pretvorbo.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Uporablja se za poceni pretvorbo spremenljivega v spremenljivo referenčno pretvorbo.
///
/// Ta Portrait je podoben [`AsRef`], vendar se uporablja za pretvorbo med spremenljivimi referencami.
/// Če potrebujete drago pretvorbo, je bolje, da [`From`] uporabite s tipom `&mut T` ali napišete funkcijo po meri.
///
/// **Note: Ta Portrait ne sme odpovedati **.Če pretvorba ne uspe, uporabite namensko metodo, ki vrne [`Option<T>`] ali [`Result<T, E>`].
///
/// # Splošne izvedbe
///
/// - `AsMut` samodejne preusmeritve, če je notranji tip spremenljiv sklic (npr .: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Z uporabo `AsMut` kot Portrait bound za generično funkcijo lahko sprejmemo vse spremenljive reference, ki jih je mogoče pretvoriti v tip `&mut T`.
/// Ker [`Box<T>`] izvaja `AsMut<T>`, lahko napišemo funkcijo `add_one`, ki sprejme vse argumente, ki jih je mogoče pretvoriti v `&mut u64`.
/// Ker [`Box<T>`] implementira `AsMut<T>`, `add_one` sprejema tudi argumente tipa `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Izvede pretvorbo.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Pretvorba vrednosti v vrednost, ki porabi vhodno vrednost.Nasprotno od [`From`].
///
/// Izogibati se je treba izvajanju [`Into`] in namesto tega izvajati [`From`].
/// Implementacija [`From`] samodejno zagotovi izvedbo [`Into`], zahvaljujoč splošni izvedbi v standardni knjižnici.
///
/// Pri podajanju Portrait bounds za generično funkcijo raje uporabite [`Into`] kot [`From`], da zagotovite, da se lahko uporabljajo tudi tipi, ki izvajajo samo [`Into`].
///
/// **Note: Ta Portrait ne sme odpovedati **.Če pretvorba ne uspe, uporabite [`TryInto`].
///
/// # Splošne izvedbe
///
/// - [`Od`]`<T>za U` pomeni `Into<U> for T`
/// - [`Into`] je refleksiven, kar pomeni, da je `Into<T> for T` implementiran
///
/// # Implementacija [`Into`] za pretvorbo v zunanje tipe v starih različicah Rust
///
/// Če pred Rust 1.41, če ciljni tip ni bil del trenutnega crate, [`From`] niste mogli neposredno implementirati.
/// Vzemimo na primer to kodo:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Tega ne bo mogoče prevesti v starejših različicah jezika, ker so bila pravila o osirotevanju Rust včasih nekoliko strožja.
/// Da bi to zaobšli, lahko [`Into`] uvedete neposredno:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Pomembno je razumeti, da [`Into`] ne zagotavlja izvedbe [`From`] (kot [`From`] z [`Into`]).
/// Zato vedno poskusite implementirati [`From`] in se nato vrnite na [`Into`], če [`From`] ni mogoče implementirati.
///
/// # Examples
///
/// [`String`] implementira [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// Da bi izrazili, da želimo, da generična funkcija sprejme vse argumente, ki jih je mogoče pretvoriti v določen tip `T`, lahko uporabimo Portrait bound od [`Into`]`<T>`.
///
/// Na primer: Funkcija `is_hello` sprejme vse argumente, ki jih je mogoče pretvoriti v [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Izvede pretvorbo.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Uporablja se za pretvorbo vrednosti v vrednost med porabo vhodne vrednosti.Je vzajemnost [`Into`].
///
/// Vedno je treba raje izvajati `From` kot [`Into`], ker implementacija `From` samodejno zagotovi izvedbo [`Into`], zahvaljujoč splošni izvedbi v standardni knjižnici.
///
///
/// Uporabite [`Into`] samo, če ciljate na različico pred Rust 1.41 in pretvarjate v tip zunaj trenutnega crate.
/// `From` zaradi starejših različic Rust teh vrst pretvorb ni mogel izvesti v prejšnjih različicah.
/// Za več podrobnosti glejte [`Into`].
///
/// Pri določanju Portrait bounds za generično funkcijo raje uporabite [`Into`] kot `From`.
/// Tako lahko kot argumente uporabimo tudi vrste, ki neposredno izvajajo [`Into`].
///
/// `From` je zelo koristen tudi pri obdelavi napak.Pri konstruiranju funkcije, ki je zmožna, bo vrsta vrnitve praviloma v obliki `Result<T, E>`.
/// `From` Portrait poenostavlja obdelavo napak, tako da funkciji omogoča vrnitev ene same vrste napak, ki vključuje več vrst napak.Za več podrobnosti glejte razdelek "Examples" in [the book][book].
///
/// **Note: Ta Portrait ne sme odpovedati **.Če pretvorba ne uspe, uporabite [`TryFrom`].
///
/// # Splošne izvedbe
///
/// - `From<T> for U` implicira [`Into`]`<U>za T`</u>
/// - `From` je refleksiven, kar pomeni, da je `From<T> for T` implementiran
///
/// # Examples
///
/// [`String`] izvaja `From<&str>`:
///
/// Izrecna pretvorba iz `&str` v niz se izvede na naslednji način:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Med izvajanjem ravnanja z napakami je pogosto koristno uporabiti `From` za svojo vrsto napake.
/// S pretvorbo osnovnih tipov napak v lastno vrsto napak po meri, ki zajema osnovno vrsto napak, lahko vrnemo eno vrsto napake, ne da bi pri tem izgubili informacije o osnovnem vzroku.
/// Operater '?' samodejno pretvori osnovno vrsto napake v naš tip napake po meri s klicem `Into<CliError>::into`, ki je samodejno na voljo pri implementaciji `From`.
/// Nato prevajalnik ugotovi, katero izvedbo `Into` je treba uporabiti.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Izvede pretvorbo.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Poskus pretvorbe, ki porabi `self`, kar je lahko drago ali ne.
///
/// Avtorji knjižnic običajno ne bi smeli neposredno izvajati tega Portrait, temveč bi raje uvedli [`TryFrom`] Portrait, ki ponuja večjo prilagodljivost in brezplačno enakovredno izvedbo `TryInto`, zahvaljujoč splošni izvedbi v standardni knjižnici.
/// Za več informacij o tem glejte dokumentacijo za [`Into`].
///
/// # Implementacija `TryInto`
///
/// To trpi zaradi enakih omejitev in razlogov kot pri uvajanju [`Into`], glejte podrobnosti.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Tip, vrnjen v primeru napake pretvorbe.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Izvede pretvorbo.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Preproste in varne pretvorbe, ki v določenih okoliščinah lahko nadzorovano ne uspejoJe vzajemnost [`TryInto`].
///
/// To je koristno, ko izvajate pretvorbo tipa, ki je lahko nepomembno uspešna, vendar bo morda potrebovala tudi posebno obdelavo.
/// Na primer ni mogoče pretvoriti [`i64`] v [`i32`] z uporabo [`From`] Portrait, ker [`i64`] lahko vsebuje vrednost, ki jo [`i32`] ne more predstavljati, zato bi pretvorba izgubila podatke.
///
/// To lahko rešite tako, da [`i64`] skrajšate na [`i32`] (v bistvu navedete vrednost [`i64`] modulo [`i32::MAX`]) ali preprosto vrnete [`i32::MAX`] ali kako drugače.
/// [`From`] Portrait je namenjen popolnim pretvorbam, zato `TryFrom` Portrait programerja obvesti, kdaj se pretvorba tipa lahko pokvari, in jim omogoči, da se sami odločijo, kako to storiti.
///
/// # Splošne izvedbe
///
/// - `TryFrom<T> for U` implicira [`TryInto`]`<U>za T`</u>
/// - [`try_from`] je refleksiven, kar pomeni, da je `TryFrom<T> for T` implementiran in ne more odpovedati-pridruženi tip `Error` za klicanje `T::try_from()` za vrednost tipa `T` je [`Infallible`].
/// Ko se tip [`!`] stabilizira, bosta [`Infallible`] in [`!`] enakovredna.
///
/// `TryFrom<T>` se lahko izvede na naslednji način:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Kot je opisano, [`i32`] izvaja `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Tiho okrni `big_number`, po odkritju zahteva zaznavanje in obdelavo okrnitve.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Vrne napako, ker je `big_number` prevelik, da bi ustrezal `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Vrne `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Tip, vrnjen v primeru napake pretvorbe.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Izvede pretvorbo.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// SPLOŠNI IMPL
////////////////////////////////////////////////////////////////////////////////

// Ko se dvigala čez&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Kot dvigala nad &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): nadomestite zgornje impulze za&/&mut z naslednjimi splošnejšimi:
// // Kot dvigala nad Derefom
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Velikost> AsRef <U>za D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut se dviga nad &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): zgornji impl za &mut zamenjajte z naslednjim splošnejšim:
// // AsMut se dvigne nad DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Velikost> AsMut <U>za D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Od implicira Into
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// From (in s tem Into) je refleksiven
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Opomba o stabilnosti:** Ta impl še ne obstaja, vendar smo "reserving space", da ga dodamo v future.
/// Za podrobnosti glejte [rust-lang/rust#64715][#64715].
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): namesto tega naredite načelno rešitev.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom pomeni TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Nepogrešljive pretvorbe so semantično enakovredne napačnim pretvorbam z nenaseljeno vrsto napake.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// BETONSKI IMPL
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// VRSTA NAPAK brez napake
////////////////////////////////////////////////////////////////////////////////

/// Vrsta napake za napake, ki se nikoli ne morejo zgoditi.
///
/// Ker ta enum nima različice, vrednost te vrste nikoli ne more dejansko obstajati.
/// To je lahko koristno za generične API-je, ki uporabljajo [`Result`] in parametrirajo vrsto napake, da označijo, da je rezultat vedno [`Ok`].
///
/// Na primer, [`TryFrom`] Portrait (pretvorba, ki vrne [`Result`]) ima popolno izvedbo za vse vrste, kjer obstaja obratna izvedba [`Into`].
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future združljivost
///
/// Ta enum ima enako vlogo kot [the `!`“never”type][never], ki je v tej različici Rust nestabilen.
/// Ko se `!` stabilizira, načrtujemo, da `Infallible` postane vzdevek tipa:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …In sčasoma opusti `Infallible`.
///
/// Vendar obstaja en primer, ko je sintakso `!` mogoče uporabiti, preden se `!` stabilizira kot polnopravni tip: v položaju vrnjenega tipa funkcije.
/// Natančneje, možne so izvedbe za dva različna tipa kazalcev funkcij:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Ker je `Infallible` enum, je ta koda veljavna.
/// Ko pa `Infallible` postane vzdevek za never type, se bosta oba impl-a začela prekrivati in bosta zaradi tega skladna z jezikovnimi pravili skladnosti Portrait prepovedala.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}