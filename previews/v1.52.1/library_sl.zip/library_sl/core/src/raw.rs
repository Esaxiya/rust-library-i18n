#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Vsebuje definicije struktur za postavitev vgrajenih vrst prevajalnika.
//!
//! Uporabljajo se lahko kot cilji transmutov v nevarni kodi za neposredno obdelavo surovih predstav.
//!
//!
//! Njihova definicija se mora vedno ujemati z ABI, opredeljenim v `rustc_middle::ty::layout`.
//!

/// Predstavitev predmeta Portrait, kot je `&dyn SomeTrait`.
///
/// Ta struktura ima enako postavitev kot tipi, kot sta `&dyn SomeTrait` in `Box<dyn AnotherTrait>`.
///
/// `TraitObject` je zagotovljeno, da se ujema z postavitvami, vendar ni vrsta predmetov Portrait (npr. polja niso neposredno dostopna na `&dyn SomeTrait`) in tudi ne nadzoruje te postavitve (sprememba definicije ne bo spremenila postavitve `&dyn SomeTrait`).
///
/// Zasnovan je samo za uporabo nevarne kode, ki mora manipulirati s podrobnostmi na nizki ravni.
///
/// Na vse predmete Portrait ni mogoče generično sklicevati, zato je edini način za ustvarjanje vrednosti te vrste funkcije, kot je [`std::mem::transmute`][transmute].
/// Podobno je edini način za ustvarjanje pravega predmeta Portrait iz vrednosti `TraitObject` z `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Sintetiziranje predmeta Portrait z neusklajenimi vrstami-takšnega, kjer vtable ne ustreza vrsti vrednosti, na katero kaže kazalnik podatkov-, bo zelo verjetno povzročilo nedefinirano vedenje.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // primer Portrait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // naj prevajalnik naredi objekt Portrait
/// let object: &dyn Foo = &value;
///
/// // poglejte surovo predstavitev
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // podatkovni kazalec je naslov `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // zgraditi nov objekt, ki kaže na drugačen `i32`, pri tem pazljivo uporabljati `i32` vtable iz `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // delovati bi moralo tako, kot da bi iz `other_value` neposredno izdelali objekt Portrait
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}