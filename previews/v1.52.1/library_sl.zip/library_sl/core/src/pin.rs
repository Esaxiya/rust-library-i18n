//! Vrste, ki podatke pripnejo na njihovo mesto v pomnilniku.
//!
//! Včasih je koristno imeti predmete, za katere je zagotovljeno, da se ne bodo premikali, v smislu, da se njihova umestitev v spomin ne bo spremenila in se nanje lahko zanesemo.
//! Vrhunski primer takšnega scenarija bi bila gradnja samoreferenčnih struktur, saj jih bo premikanje predmeta s kazalci razveljavilo, kar bi lahko povzročilo nedefinirano vedenje.
//!
//! Na visoki ravni [`Pin<P>`] zagotavlja, da ima kazalec katerega koli tipa kazalca `P` stabilno mesto v pomnilniku, kar pomeni, da ga ni mogoče premakniti drugam in pomnilnika ni mogoče odstraniti, dokler ne pade.Pravimo, da je napotnik "pinned".Stvari postanejo bolj subtilne, ko razpravljamo o vrstah, ki združujejo pripete podatke z nepripetimi podatki;[see below](#projections-and-structural-pinning) za več podrobnosti.
//!
//! Privzeto so vse vrste v Rust premične.
//! Rust omogoča posredovanje vseh vrst po vrednosti, običajni tipi pametnih kazalcev, kot sta [`Box<T>`] in `&mut T`, pa omogočajo zamenjavo in premikanje vrednosti, ki jih vsebujejo: lahko se premaknete iz [`Box<T>`] ali pa uporabite [`mem::swap`].
//! [`Pin<P>`] zavije kazalec tipa `P`, zato [`Pin`]`<`[`Box`] `<T>>`deluje podobno kot navaden
//!
//! [`Box<T>`]: when a [`Pin`]`<`[`Box`] `<T>>`pade, njegova vsebina tudi, in pomnilnik dobi
//!
//! dogovoren.Podobno je [`Pin`]`<&mut T>`zelo podoben `&mut T`.Vendar [`Pin<P>`] strankam ne dovoli, da dejansko pridobijo [`Box<T>`] ali `&mut T` za pripete podatke, kar pomeni, da ne morete uporabljati operacij, kot je [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` potrebuje `&mut T`, vendar ga ne moremo dobiti.
//!     // Zataknili smo se, vsebine teh referenc ne moremo zamenjati.
//!     // Lahko bi uporabili `Pin::get_unchecked_mut`, vendar to z razlogom ni varno:
//!     // ne smemo ga uporabljati za premikanje stvari iz `Pin`.
//! }
//! ```
//!
//! Ponovno velja poudariti, da [`Pin<P>`]*ne* spremeni dejstva, da prevajalnik Rust meni, da so vse vrste premične.[`mem::swap`] ostane vpoklican za kateri koli `T`.Namesto tega [`Pin<P>`] preprečuje premikanje določenih vrednosti * (na katere kažejo kazalci, zaviti v [`Pin<P>`]), tako da onemogoča klicanje metod, ki na njih zahtevajo `&mut T` (na primer [`mem::swap`]).
//!
//! [`Pin<P>`] se lahko uporablja za zavijanje katerega koli kazalca tipa `P` in kot tak deluje v interakciji z [`Deref`] in [`DerefMut`].[`Pin<P>`], kjer je treba `P: Deref` šteti kot "`P`-style pointer" na pripeti `P::Target`-torej, ["Pin"] "<" ["Box"] `<T>>`je lastniški kazalec na pripeti `T` in [`Pin`] `<` [`Rc`]`<T>>`je kazalnik s štetjem referenc na pripeti `T`.
//! Zaradi pravilnosti se [`Pin<P>`] zanaša na izvedbe [`Deref`] in [`DerefMut`], da se ne premaknejo iz parametra `self` in da vrnejo kazalec na pripete podatke le, ko jih pokličete na pripetem kazalcu.
//!
//! # `Unpin`
//!
//! Številne vrste so vedno prosto premične, tudi če so pripete, ker se ne zanašajo na stabilen naslov.Sem spadajo vsi osnovni tipi (na primer [`bool`], [`i32`] in reference) ter tipi, ki so sestavljeni izključno iz teh vrst.Vrste, ki jim ni mar za pripenjanje, izvajajo [`Unpin`] auto-Portrait, ki prekliče učinek [`Pin<P>`].
//! Za `T: Unpin`, [`Pin`]`<`[`Box`] `<T>>`in [`Box<T>`] delujeta enako kot [`Pin`] `<&mut T>` in `&mut T`.
//!
//! Upoštevajte, da pripenjanje in [`Unpin`] vplivata samo na usmerjeni tip `P::Target`, ne pa tudi na tip kazalca `P`, ki je bil ovit v [`Pin<P>`].Na primer, ali je [`Box<T>`] [`Unpin`] ali ne, ne vpliva na obnašanje ["Pin"] "<" ["Box"] `<T>>`(tukaj je `T` usmerjen tip).
//!
//! # Primer: samoreferenčna struktura
//!
//! Preden podrobneje razložimo garancije in izbire, povezane z `Pin<T>`, bomo obravnavali nekaj primerov, kako ga lahko uporabimo.
//! Vas prosimo, da [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // To je samoreferenčna struktura, ker polje rezine kaže na podatkovno polje.
//! // O tem prevajalnika ne moremo obvestiti z običajno referenco, saj tega vzorca ni mogoče opisati z običajnimi pravili izposojanja.
//! //
//! // Namesto tega uporabimo neobdelan kazalec, za katerega je znano, da ni nič, saj vemo, da kaže na niz.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Da bi zagotovili, da se podatki ne bodo premaknili, ko se funkcija vrne, jih postavimo na kup, kjer bodo ostali vse življenje predmeta, in edini način dostopa do njih bi bil prek kazalca nanj.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // kazalec ustvarimo šele, ko so podatki na mestu, sicer se bo že premaknil, še preden smo sploh začeli
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // vemo, da je to varno, ker spreminjanje polja ne premakne celotne strukture
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Kazalec mora kazati na pravilno lokacijo, če se struktura ne premakne.
//! //
//! // Medtem lahko prosto premikamo kazalec.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Ker naš tip ne izvaja Unpin, tega ne bo uspelo prevesti:
//! // naj mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Primer: vsiljiv dvojno povezan seznam
//!
//! Na vsiljivem dvojno povezanem seznamu zbirka dejansko ne dodeli pomnilnika za same elemente.
//! Dodelitev nadzirajo stranke, elementi pa lahko živijo na okviru sklada, ki živi krajše kot zbirka.
//!
//! Da bi to delovalo, ima vsak element kazalce na svojega predhodnika in naslednika na seznamu.Elemente je mogoče dodati samo, ko so pripeti, ker bi premikanje elementov okrnilo kazalce.Poleg tega bo izvedba povezanega elementa seznama [`Drop`] popravila kazalce predhodnika in naslednika, da se bo sam odstranil s seznama.
//!
//! Ključno je, da se moramo zanesti na klic [`drop`].Če bi element lahko sprostili ali kako drugače razveljavili, ne da bi poklicali [`drop`], bi kazalci na sosednje elemente vanj postali neveljavni, kar bi prekinilo podatkovno strukturo.
//!
//! Zato pripenjanje prihaja tudi z garancijo, povezano s "padcem".
//!
//! # `Drop` guarantee
//!
//! Namen pripenjanja je, da se lahko zanesemo na umestitev nekaterih podatkov v pomnilnik.
//! Da bi to delovalo, ni dovoljeno le premikanje podatkov;Omejeno je tudi odstranjevanje, prenastavitev ali drugačna razveljavitev pomnilnika, ki se uporablja za shranjevanje podatkov.
//! Konkretno, za pripete podatke morate ohraniti nespremenljivo, da *njegov pomnilnik ne bo razveljavljen ali preoblikovan od trenutka, ko bo pripet, do klica [`drop`]*.Šele ko se [`drop`] vrne ali panics, bo pomnilnik mogoče ponovno uporabiti.
//!
//! Pomnilnik je lahko "invalidated" s sprostitvijo, lahko pa tudi z zamenjavo [`Some(v)`] z [`None`] ali klicanjem [`Vec::set_len`] na "kill" nekaterih elementov vector.Lahko ga prenastavite z uporabo [`ptr::write`], da ga prepišete, ne da bi najprej klicali destruktor.Nič od tega ni dovoljeno za pripete podatke brez klica [`drop`].
//!
//! Prav to je zagotovilo, da mora vsiljiv povezan seznam iz prejšnjega oddelka pravilno delovati.
//!
//! Upoštevajte, da to jamstvo *ne pomeni, da spomin ne pušča!Še vedno je povsem v redu, da nikoli ne pokličete [`drop`] na pripetem elementu (npr. Še vedno lahko pokličete [`mem::forget`] na [" Pin`] " <" [" Box`] `<T>>`).V primeru dvojno povezanega seznama bi ta element le ostal na seznamu.Vendar shrambe* ne smete sprostiti ali ponovno uporabiti *, ne da bi poklicali [`drop`]*.
//!
//! # `Drop` implementation
//!
//! Če vaš tip uporablja pripenjanje (kot sta zgornja primera), morate biti previdni pri uvajanju [`Drop`].Funkcija [`drop`] zajema `&mut self`, vendar se to imenuje *, tudi če je bil vaš tip prej pripet*!Kot da bi prevajalnik samodejno poklical [`Pin::get_unchecked_mut`].
//!
//! To nikoli ne more povzročiti težav z varno kodo, ker je za izvedbo tipa, ki se opira na pripenjanje, potrebna nevarna koda, vendar se zavedajte, da se odločitev za pripenjanje v vašem tipu (na primer z izvajanjem neke operacije na [" Pripni`] >`ali [`Pin`] `<&mut Self>`) ima posledice tudi za vašo izvedbo [`Drop`]: če bi bil element vašega tipa lahko pripet, morate [`Drop`] obravnavati kot implicitno zasedbo [`Pin`]`<&mut Self>`.
//!
//!
//! Na primer, lahko `Drop` implementirate na naslednji način:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` je v redu, ker vemo, da se ta vrednost po izpustu nikoli več ne uporabi.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Dejanska spustna koda gre tukaj.
//!         }
//!     }
//! }
//! ```
//!
//! Funkcija `inner_drop` ima tip, ki bi ga moral imeti [`drop`] *, zato poskrbite, da ne boste pomotoma uporabili `self`/`this` na način, ki je v nasprotju s pripenjanjem.
//!
//! Če je vaš tip `#[repr(packed)]`, bo prevajalnik samodejno premaknil polja, da jih bo lahko spustil.To lahko stori celo za polja, ki so dovolj poravnana.Posledično ne morete uporabljati pripenjanja s tipom `#[repr(packed)]`.
//!
//! # Projekcije in strukturno pripenjanje
//!
//! Pri delu s pripetimi strukturami se zastavlja vprašanje, kako lahko dostopate do polj te strukture v metodi, ki zavzame samo [`Pin`]`<&mut Struct>`.
//! Običajni pristop je pisanje pomožnih metod (tako imenovanih *projekcij*), ki spremenijo ``Pin`] `<&mut Struct>` v sklic na polje, toda kakšen tip naj ima ta sklic?Je to [`Pin`]`<&mut Field>`ali `&mut Field`?
//! Isto vprašanje se pojavi pri poljih `enum` in tudi pri obravnavi vrst container/wrapper, kot so [`Vec<T>`], [`Box<T>`] ali [`RefCell<T>`].
//! (To vprašanje velja tako za spremenljive kot za skupne reference, za ponazoritev uporabljamo zgolj pogostejši primer spremenljivih referenc.)
//!
//! Izkazalo se je, da je dejansko na avtorju podatkovne strukture, da odloči, ali pripeta projekcija za določeno polje spremeni [`Pin`]`<&mut Struct>`v [`Pin`] `<&mut Field>` ali `&mut Field`.Obstaja nekaj omejitev, najpomembnejša omejitev pa je *doslednost*:
//! vsako polje lahko *ali* projiciramo na pripeto referenco,*ali* odstranimo pripenjanje kot del projekcije.
//! Če sta oba narejena za isto polje, bo to verjetno nesoglasno!
//!
//! Kot avtor podatkovne strukture se lahko za vsako polje odločite, ali želite "propagates" pripeti na to polje ali ne.
//! Pripenjanje, ki se širi, se imenuje tudi "structural", ker sledi strukturi tipa.
//! V naslednjih podpoglavjih opisujemo premisleke, ki jih je treba upoštevati pri izbiri.
//!
//! ## Pripenjanje *ni* strukturno za `field`
//!
//! Morda se zdi nasprotno intuitivno, da polje pripete strukture morda ni pripeto, toda to je pravzaprav najlažja izbira: če [`Pin`]`<&mut Field>`nikoli ni ustvarjen, ne more iti narobe!Torej, če se odločite, da neko polje nima strukturnega pripenjanja, morate zagotoviti, da nikoli ne ustvarite pripetega sklica na to polje.
//!
//! Polja brez strukturnega pripenjanja imajo lahko metodo projiciranja, ki pretvori [`Pin`]`<&mut Struct>`v `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // To je v redu, ker `field` nikoli ne velja za pripetega.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Lahko tudi `impl Unpin for Struct`*, tudi če* vrsta `field` ni [`Unpin`].Kaj ta vrsta misli o pripenjanju, ni pomembno, če ni nikoli ustvarjen noben [`Pin`]`<&mut Field>`.
//!
//! ## Pripenjanje *je za `field` strukturno*
//!
//! Druga možnost je, da se odločite, da je pripenjanje "structural" za `field`, kar pomeni, da če je struktura pripeta, je to tudi polje.
//!
//! To omogoča pisanje projekcije, ki ustvari [`Pin`]`<&mut Field>`, s čimer je priča, da je polje pripeto:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // To je v redu, ker je `field` pripet, ko je `self`.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Vendar ima strukturno pritrjevanje nekaj dodatnih zahtev:
//!
//! 1. Struktura mora biti [`Unpin`] le, če so vsa strukturna polja [`Unpin`].To je privzeto, toda [`Unpin`] je varen Portrait, zato je kot avtor strukture vaša odgovornost *, ne*, da dodate nekaj podobnega `impl<T> Unpin for Struct<T>`.
//! (Upoštevajte, da dodajanje projekcijske operacije zahteva nevarno kodo, zato dejstvo, da je [`Unpin`] varen Portrait, ne krši načela, da morate zaradi česar koli od tega skrbeti le, če uporabljate "nevarno".)
//! 2. Destruktor strukture ne sme premikati strukturnih polj iz argumenta.To je natančna točka, ki je bila postavljena v [previous section][drop-impl]: `drop` zavzame `&mut self`, vendar je bila struktura (in s tem tudi njena polja) morda že pripeta.
//!     Zagotoviti morate, da znotraj svoje implementacije [`Drop`] ne premaknete polja.
//!     Kot je bilo že pojasnjeno, to pomeni, da vaša struktura *ne sme biti*`#[repr(packed)]`.
//!     Glejte ta odsek, kako napisati [`drop`] tako, da vam prevajalnik pomaga, da nenamerno ne prekinete pripenjanja.
//! 3. Prepričajte se, da podpirate [`Drop` guarantee][drop-guarantee]:
//!     ko je vaša struktura pripeta, pomnilnik, ki vsebuje vsebino, ni prepisan ali odstranjen, ne da bi poklicali destruktorje vsebine.
//!     To je lahko težavno, kot priča [`VecDeque<T>`]: destruktor [`VecDeque<T>`] ne more poklicati [`drop`] za vse elemente, če je eden od destruktorjev panics.To krši garancijo [`Drop`], ker lahko povzroči odstranjevanje elementov, ne da bi bil poklican njihov destruktor.([`VecDeque<T>`] nima štrlečih štrlin, zato to ne povzroča nesmiselnosti.)
//! 4. Ne smete ponujati nobenih drugih operacij, ki bi lahko privedle do premika podatkov iz strukturnih polj, ko je vaš tip pripeti.Če na primer struktura vsebuje [`Option<T>`] in obstaja "take`" operacija s tipom `fn(Pin<&mut Struct<T>>) -> Option<T>`, lahko to operacijo uporabimo za premik `T` iz pripetega `Struct<T>`-kar pomeni, da pripenjanje ne more biti strukturno za polje, ki drži to podatkov.
//!
//!     Za bolj zapleten primer premikanja podatkov iz pripetega tipa si predstavljajte, če bi imel [`RefCell<T>`] metodo `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Potem bi lahko naredili naslednje:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     To je katastrofalno, kar pomeni, da lahko vsebino [`RefCell<T>`] najprej pripnemo (z uporabo `RefCell::get_pin_mut`), nato pa to vsebino premaknemo s spremenljivo referenco, ki smo jo dobili pozneje.
//!
//! ## Examples
//!
//! Za tip, kot je [`Vec<T>`], sta obe možnosti (strukturno pritrjevanje ali ne) smiselni.
//! [`Vec<T>`] s strukturnim pripenjanjem bi lahko imel metode `get_pin`/`get_pin_mut` za pridobivanje pripetih sklicev na elemente.Vendar pa *ne more* dovoliti klica [`pop`][Vec::pop] na pripetem [`Vec<T>`], ker bi to premaknilo (strukturno pripeto) vsebino!Prav tako ni mogel dovoliti [`push`][Vec::push], ki bi lahko prerazporedil in s tem tudi premaknil vsebino.
//!
//! [`Vec<T>`] brez strukturnega pripenjanja bi lahko `impl<T> Unpin for Vec<T>`, ker vsebina ni nikoli pripeta in je tudi [`Vec<T>`] v redu s premikanjem.
//! Takrat pripenjanje sploh nima vpliva na vector.
//!
//! V standardni knjižnici tipi kazalcev običajno nimajo strukturnega pripenjanja in zato ne ponujajo projekcij pripenjanja.Zato `Box<T>: Unpin` velja za vse `T`.
//! To je smiselno narediti za vrste kazalcev, ker premikanje `Box<T>` dejansko ne premakne `T`: [`Box<T>`] je lahko prosto premikajoč se (tudi `Unpin`), tudi če `T` ni.Pravzaprav celo [`Pin`]`<`[`Box`] `<T>>`in [`Pin`] `<&mut T>` sta vedno sama [`Unpin`], in sicer iz istega razloga: njihova vsebina (`T`) je pripeta, same kazalce pa je mogoče premikati brez premikanja pripetih podatkov.
//! Za [`Box<T>`] in [`Pin`]`<`[`Box`] `<T>>`, ali je vsebina pripeta, je popolnoma neodvisno od tega, ali je kazalec pripet, kar pomeni, da pripenjanje *ni* strukturno.
//!
//! Pri implementaciji kombinacije [`Future`] boste običajno potrebovali strukturno pripenjanje za ugnezdene futures, saj morate za klic [`poll`] dobiti pripete sklice na njih.
//! Če pa vaš kombiniralec vsebuje druge podatke, ki jih ni treba pripeti, lahko ta polja naredite nestrukturne in tako prosto dostopate do njih s spremenljivo referenco, tudi če imate samo ["Pripni"] "&&mut Self>" (na primer kot pri lastni izvedbi [`poll`]).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Pripeti kazalec.
///
/// To je ovoj okoli nekakšnega kazalca, zaradi katerega ta kazalec "pin" doseže njegovo vrednost in preprečuje premikanje vrednosti, na katero se sklicuje ta kazalnik, razen če implementira [`Unpin`].
///
///
/// *Za razlago pripenjanja glejte dokumentacijo [`pin` module].*
///
/// [`pin` module]: self
///
// Note: spodnji izpeljan `Clone` povzroča nesmiselnost, kot jo je mogoče izvesti
// `Clone` za spremenljive reference.
// Za več podrobnosti glejte <https://internals.rust-lang.org/t/unsoundness-in-pin/11311>.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Naslednje izvedbe niso izvedene, da bi se izognili težavam.
// `&self.pointer` ne bi smela biti dostopna nezaupanim izvedbam Portrait.
//
// Za več podrobnosti glejte <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73>.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Sestavite nov `Pin<P>` okoli kazalca na nekatere podatke tipa, ki implementira [`Unpin`].
    ///
    /// Za razliko od `Pin::new_unchecked` je ta metoda varna, ker se kazalec `P` preusmeri na tip [`Unpin`], kar razveljavi jamstva za pripenjanje.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // VARNOST: navedena vrednost je `Unpin` in zato nima nobenih zahtev
        // okoli pripenjanja.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Odvije ta `Pin<P>` in vrne osnovni kazalec.
    ///
    /// To zahteva, da so podatki znotraj tega `Pin` [`Unpin`], da bomo lahko pri razpakiranju prezrli invariantke pripenjanja.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Sestavite nov `Pin<P>` okoli sklica na nekatere podatke vrste, ki lahko ali pa tudi ne implementira `Unpin`.
    ///
    /// Če `pointer` preusmerja na tip `Unpin`, namesto tega uporabite `Pin::new`.
    ///
    /// # Safety
    ///
    /// Ta konstruktor ni varen, ker ne moremo zagotoviti, da so podatki, na katere opozarja `pointer`, pripeti, kar pomeni, da se podatki ne bodo premaknili ali njihovo shranjevanje postalo neveljavno, dokler ne izpadejo.
    /// Če konstruirani `Pin<P>` ne zagotavlja, da so podatki, na katere kaže `P`, pripeti, je to kršitev pogodbe API in lahko pri poznejših operacijah (safe) povzroči nedefinirano vedenje.
    ///
    /// Z uporabo te metode naredite promise o izvedbah `P::Deref` in `P::DerefMut`, če obstajajo.
    /// Najpomembneje je, da se ne smejo premakniti iz svojih argumentov `self`: `Pin::as_mut` in `Pin::as_ref` bosta na pripetem kazalcu *poklicali `DerefMut::deref_mut` in `Deref::deref`* in pričakovali, da bodo te metode ohranile pripenjalne invariante.
    /// Poleg tega s klicanjem te metode promise, iz katere referenčne reference `P` ne bodo več premaknjene;zlasti ne sme biti mogoče dobiti `&mut P::Target` in se nato premakniti iz te reference (z uporabo, na primer [`mem::swap`]).
    ///
    ///
    /// Na primer, klic `Pin::new_unchecked` na `&'a mut T` ni varen, ker čeprav ga lahko pripnete za določeno življenjsko dobo `'a`, nimate nadzora nad tem, ali bo obdržan, ko se `'a` konča:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // To bi moralo pomeniti, da se poanti `a` ne more več premikati.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Naslov `a` se je spremenil v režo skladovnice `b`, zato se je `a` premaknil, čeprav smo ga že prej pripeli!Kršili smo pogodbo o pripenjanju API-ja.
    /////
    /// }
    /// ```
    ///
    /// Ko je vrednost pripeta, mora ostati za vedno pripeta (razen če njen tip ne uporablja `Unpin`).
    ///
    /// Podobno tudi klicanje `Pin::new_unchecked` na `Rc<T>` ni varno, ker bi lahko obstajali vzdevki za iste podatke, za katere ne veljajo omejitve pripenjanja:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // To bi moralo pomeniti, da se pointi ne more nikoli več premakniti.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Če je bila `x` edina referenca, imamo spremenljivo referenco na podatke, ki smo jih pripeli zgoraj, s katerimi bi jih lahko premaknili, kot smo videli v prejšnjem primeru.
    ///     // Kršili smo pogodbo o pripenjanju API-ja.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Pridobi pripeto referenco v skupni rabi iz tega pripetega kazalca.
    ///
    /// To je splošna metoda za prehod z `&Pin<Pointer<T>>` na `Pin<&T>`.
    /// Varno je, ker se kot del pogodbe za `Pin::new_unchecked` poantee ne more premakniti po tem, ko je `Pin<Pointer<T>>` ustvarjen.
    ///
    /// "Malicious" izvedbe `Pointer::Deref` prav tako izključuje pogodba `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // VARNOST: glejte dokumentacijo o tej funkciji
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Odvije ta `Pin<P>` in vrne osnovni kazalec.
    ///
    /// # Safety
    ///
    /// Ta funkcija ni varna.Zagotoviti morate, da boste tudi po tem, ko pokličete to funkcijo, še naprej obravnavali kazalec `P` kot pripetega, da boste lahko ohranili invariante tipa `Pin`.
    /// Če koda, ki uporablja nastali `P`, še naprej ne vzdržuje invariantov pripenjanja, je to kršitev pogodbe API in lahko pri poznejših operacijah (safe) povzroči nedefinirano vedenje.
    ///
    ///
    /// Če so osnovni podatki [`Unpin`], namesto tega uporabite [`Pin::into_inner`].
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Pridobi pripeto spremenljivo referenco iz tega pripetega kazalca.
    ///
    /// To je splošna metoda za prehod z `&mut Pin<Pointer<T>>` na `Pin<&mut T>`.
    /// Varno je, ker se kot del pogodbe za `Pin::new_unchecked` poantee ne more premakniti po tem, ko je `Pin<Pointer<T>>` ustvarjen.
    ///
    /// "Malicious" izvedbe `Pointer::DerefMut` prav tako izključuje pogodba `Pin::new_unchecked`.
    ///
    /// Ta metoda je uporabna pri večkratnih klicih funkcij, ki porabijo pripeti tip.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // naredi kaj
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` porabi `self`, zato si ponovno posodite `Pin<&mut Self>` prek `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // VARNOST: glejte dokumentacijo o tej funkciji
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Pomnilniku za pripeto referenco dodeli novo vrednost.
    ///
    /// To prepiše pripete podatke, vendar je v redu: njegov destruktor se zažene, preden se prepiše, zato nobeno jamstvo za pripenjanje ni kršeno.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Konstruira nov zatič s preslikavo notranje vrednosti.
    ///
    /// Če bi na primer želeli dobiti `Pin` polja nečesa, lahko to uporabite za dostop do tega polja v eni vrstici kode.
    /// Vendar pa je pri teh "pinning projections" več težav;
    /// za nadaljne podrobnosti o tej temi glejte dokumentacijo [`pin` module].
    ///
    /// # Safety
    ///
    /// Ta funkcija ni varna.
    /// Zagotoviti morate, da se podatki, ki jih vrnete, ne bodo premikali, dokler se vrednost argumenta ne premakne (na primer, ker je eno od polj te vrednosti) in tudi, da se ne boste premaknili iz argumenta, ki ga prejmete v notranja funkcija.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // VARNOST: varnostna pogodba za `new_unchecked` mora biti
        // ki ga podpira klicatelj.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Pridobi sklic v skupni rabi iz zatiča.
    ///
    /// To je varno, ker iz skupne reference ni mogoče premakniti.
    /// Morda se zdi, da tukaj obstaja težava z notranjo spremenljivostjo: v resnici je *mogoče*`T` premakniti iz `&RefCell<T>`.
    /// Vendar to ni težava, če ne obstaja tudi `Pin<&T>`, ki kaže na iste podatke, in `RefCell<T>` ne omogoča ustvarjanja pripetega sklica na njegovo vsebino.
    ///
    /// Za nadaljnje podrobnosti glejte razpravo o ["pinning projections"].
    ///
    /// Note: `Pin` na cilj implementira tudi `Deref`, s katerim lahko dostopate do notranje vrednosti.
    /// Vendar `Deref` ponuja le referenco, ki živi toliko časa, kolikor traja izposoja `Pin`, ne pa tudi življenjska doba samega `Pin`.
    /// Ta metoda omogoča pretvorbo `Pin` v referenco z enako življenjsko dobo kot original `Pin`.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Ta `Pin<&mut T>` pretvori v `Pin<&T>` z enako življenjsko dobo.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Pridobi spremenljiv sklic na podatke znotraj tega `Pin`.
    ///
    /// To zahteva, da so podatki v tem `Pin` `Unpin`.
    ///
    /// Note: `Pin` na podatke implementira tudi `DerefMut`, ki se lahko uporablja za dostop do notranje vrednosti.
    /// Vendar `DerefMut` ponuja le referenco, ki živi toliko časa, kolikor traja izposoja `Pin`, ne pa tudi življenjska doba samega `Pin`.
    ///
    /// Ta metoda omogoča pretvorbo `Pin` v referenco z enako življenjsko dobo kot original `Pin`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Pridobi spremenljiv sklic na podatke znotraj tega `Pin`.
    ///
    /// # Safety
    ///
    /// Ta funkcija ni varna.
    /// Zagotoviti morate, da nikoli ne boste premaknili podatkov iz spremenljivega sklica, ki ga prejmete, ko pokličete to funkcijo, da boste lahko ohranili invariante tipa `Pin`.
    ///
    ///
    /// Če so osnovni podatki `Unpin`, namesto tega uporabite `Pin::get_mut`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Sestavite nov zatič tako, da preslikate notranjo vrednost.
    ///
    /// Če bi na primer želeli dobiti `Pin` polja nečesa, lahko to uporabite za dostop do tega polja v eni vrstici kode.
    /// Vendar pa je pri teh "pinning projections" več težav;
    /// za nadaljne podrobnosti o tej temi glejte dokumentacijo [`pin` module].
    ///
    /// # Safety
    ///
    /// Ta funkcija ni varna.
    /// Zagotoviti morate, da se podatki, ki jih vrnete, ne bodo premikali, dokler se vrednost argumenta ne premakne (na primer, ker je eno od polj te vrednosti) in tudi, da se ne boste premaknili iz argumenta, ki ga prejmete v notranja funkcija.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // VARNOST: klicatelj je odgovoren, da ne premakne
        // vrednost iz te reference.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // VARNOST: saj vrednost `this` zajamčeno nima
        // je bil klic `new_unchecked` varen.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Pridobite pripeto referenco iz statične reference.
    ///
    /// To je varno, ker je `T` izposojen za življenjsko dobo `'static`, ki se nikoli ne konča.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // VARNOST: 'Statično izposojanje zagotavlja, da podatkov ne bo
        // moved/invalidated dokler ne pade (kar ni nikoli).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Pridobite pripeto spremenljivo referenco iz statične spremenljive reference.
    ///
    /// To je varno, ker je `T` izposojen za življenjsko dobo `'static`, ki se nikoli ne konča.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // VARNOST: 'Statično izposojanje zagotavlja, da podatkov ne bo
        // moved/invalidated dokler ne pade (kar ni nikoli).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: to pomeni, da je vsak impl `CoerceUnsized`, ki omogoča prisilo iz
// tip, ki prikliče `Deref<Target=impl !Unpin>` na tip, ki prikliče `Deref<Target=Unpin>`, ni zvok.
// Vsak tak impl bi bil verjetno neutemeljen iz drugih razlogov, zato moramo paziti, da ne dovolimo, da takšni impulzi pristanejo v std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}