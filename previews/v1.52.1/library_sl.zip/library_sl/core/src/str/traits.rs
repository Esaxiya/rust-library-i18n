//! Trait izvedbe za `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Izvaja urejanje nizov.
///
/// Strune so [lexicographically](Ord#lexicographical-comparison) razvrščene po njihovih bajtnih vrednostih.
/// To naroči kodne točke Unicode glede na njihove položaje v kodnih kartah.
/// To ni nujno enako kot naročilo "alphabetical", ki se razlikuje glede na jezik in jezik.
/// Za razvrščanje nizov v skladu s kulturno sprejetimi standardi so potrebni lokalni podatki, ki so zunaj obsega tipa `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Izvaja primerjalne operacije nizov.
///
/// Strune primerjajo [lexicographically](Ord#lexicographical-comparison) glede na njihove bajtne vrednosti.
/// To primerja kodne točke Unicode glede na njihov položaj v kodnih kartah.
/// To ni nujno enako kot naročilo "alphabetical", ki se razlikuje glede na jezik in jezik.
/// Primerjava nizov v skladu s kulturno sprejetimi standardi zahteva podatke o jeziku, ki niso zajeti v tipu `str`.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Izvaja rezanje podnizov s sintakso `&self[..]` ali `&mut self[..]`.
///
/// Vrne rezino celotnega niza, tj. Vrne `&self` ali `&mut self`.Enakovredno `&self [0 ..
/// len] `ali`&mut self [0 ..
/// len]`.
/// V nasprotju z drugimi operacijami indeksiranja to nikoli ne more panic.
///
/// Ta postopek je *O*(1).
///
/// Pred 1.20.0 so bile te operacije indeksiranja še vedno podprte z neposrednim izvajanjem `Index` in `IndexMut`.
///
/// Enakovredno `&self[0 .. len]` ali `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Izvaja rezanje podnizov s sintakso `&self[begin .. end]` ali `&mut self[begin .. end]`.
///
/// Vrne rezino danega niza iz obsega bajtov [`start`, `end`).
///
/// Ta postopek je *O*(1).
///
/// Pred 1.20.0 so bile te operacije indeksiranja še vedno podprte z neposrednim izvajanjem `Index` in `IndexMut`.
///
/// # Panics
///
/// Panics, če `begin` ali `end` ne kaže na odmik začetnega bajta znaka (kot ga določa `is_char_boundary`), če je `begin > end` ali če je `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // ti bodo panic:
/// // bajt 2 leži znotraj `ö`:
/// // &s [2.3.];
///
/// // bajt 8 leži znotraj `老`&s [1 ..
/// // 8];
///
/// // bajt 100 je zunaj niza&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // VARNOST: pravkar preveril, ali sta `start` in `end` na meji znakov,
            // in podajamo varno referenco, zato bo enaka tudi vrnjena vrednost.
            // Preverili smo tudi meje znakov, zato je to veljaven UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // VARNOST: pravkar sem preveril, ali sta `start` in `end` na meji znakov.
            // Vemo, da je kazalec edinstven, ker smo ga dobili od `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // VARNOST: klicatelj zagotavlja, da je `self` v mejah `slice`
        // ki izpolnjuje vse pogoje za `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // VARNOST: glej komentarje za `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary preveri, ali je indeks v [0, .len()] ne more znova uporabiti `get` kot zgoraj, zaradi težav z NLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // VARNOST: pravkar preveril, ali sta `start` in `end` na meji znakov,
            // in podajamo varno referenco, zato bo enaka tudi vrnjena vrednost.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Izvaja rezanje podnizov s sintakso `&self[.. end]` ali `&mut self[.. end]`.
///
/// Vrne rezino danega niza iz obsega bajtov ["0", `end`).
/// Enakovredno `&self[0 .. end]` ali `&mut self[0 .. end]`.
///
/// Ta postopek je *O*(1).
///
/// Pred 1.20.0 so bile te operacije indeksiranja še vedno podprte z neposrednim izvajanjem `Index` in `IndexMut`.
///
/// # Panics
///
/// Panics, če `end` ne kaže na odmik začetnega bajta znaka (kot ga določa `is_char_boundary`) ali če `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // VARNOST: pravkar preveril, ali je `end` na meji znakov,
            // in podajamo varno referenco, zato bo enaka tudi vrnjena vrednost.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // VARNOST: pravkar preveril, ali je `end` na meji znakov,
            // in podajamo varno referenco, zato bo enaka tudi vrnjena vrednost.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // VARNOST: pravkar preveril, ali je `end` na meji znakov,
            // in podajamo varno referenco, zato bo enaka tudi vrnjena vrednost.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Izvaja rezanje podnizov s sintakso `&self[begin ..]` ali `&mut self[begin ..]`.
///
/// Vrne rezino danega niza iz obsega bajtov [`start`, `len`).Enakovredno `&self [začni ..
/// len] `ali`&mut self [začeti ..
/// len]`.
///
/// Ta postopek je *O*(1).
///
/// Pred 1.20.0 so bile te operacije indeksiranja še vedno podprte z neposrednim izvajanjem `Index` in `IndexMut`.
///
/// # Panics
///
/// Panics, če `begin` ne kaže na odmik začetnega bajta znaka (kot ga določa `is_char_boundary`) ali če `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // VARNOST: pravkar preveril, ali je `start` na meji znakov,
            // in podajamo varno referenco, zato bo enaka tudi vrnjena vrednost.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // VARNOST: pravkar preveril, ali je `start` na meji znakov,
            // in podajamo varno referenco, zato bo enaka tudi vrnjena vrednost.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // VARNOST: klicatelj zagotavlja, da je `self` v mejah `slice`
        // ki izpolnjuje vse pogoje za `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // VARNOST: enako kot `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // VARNOST: pravkar preveril, ali je `start` na meji znakov,
            // in podajamo varno referenco, zato bo enaka tudi vrnjena vrednost.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Izvaja rezanje podnizov s sintakso `&self[begin ..= end]` ali `&mut self[begin ..= end]`.
///
/// Vrne rezino danega niza iz obsega bajtov [`begin`, `end`].Enakovredno `&self [begin .. end + 1]` ali `&mut self[begin .. end + 1]`, razen če ima `end` največjo vrednost za `usize`.
///
/// Ta postopek je *O*(1).
///
/// # Panics
///
/// Panics, če `begin` ne kaže na odmik začetnega bajta znaka (kot ga določa `is_char_boundary`), če `end` ne kaže na odmik končnega bajta znaka (`end + 1` je bodisi odmik začetnega bajta bodisi enak `len`), če je `begin > end`, ali če `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Izvaja rezanje podnizov s sintakso `&self[..= end]` ali `&mut self[..= end]`.
///
/// Vrne rezino danega niza iz obsega bajtov [0, `end`].
/// Enakovredno `&self [0 .. end + 1]`, razen če ima `end` največjo vrednost za `usize`.
///
/// Ta postopek je *O*(1).
///
/// # Panics
///
/// Panics, če `end` ne kaže na odmik končnega bajta znaka (`end + 1` je bodisi odmik začetnega bajta, kot je opredeljen z `is_char_boundary`, bodisi enak `len`), ali če `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Razčleni vrednost iz niza
///
/// Metoda [`from_str`] "FromStr" se pogosto uporablja implicitno prek metode [`parse`] ["str`].
/// Za primere glejte dokumentacijo [`parse`].
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` nima življenjskega parametra, zato lahko razčlenite samo tipe, ki sami ne vsebujejo življenjskega parametra.
///
/// Z drugimi besedami, `i32` lahko razčlenite z `FromStr`, `&i32` pa ne.
/// Lahko razčlenite strukturo, ki vsebuje `i32`, ne pa tudi tiste, ki vsebuje `&i32`.
///
/// # Examples
///
/// Osnovna izvedba `FromStr` na primeru tipa `Point`:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Povezana napaka, ki jo je mogoče vrniti pri razčlenjevanju.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Analizira niz `s`, da vrne vrednost te vrste.
    ///
    /// Če je razčlenitev uspela, vrnite vrednost znotraj [`Ok`], sicer pa, če je niz neustrezno oblikovan, vrnite napako, značilno za notranjost [`Err`].
    /// Vrsta napake je značilna za izvedbo Portrait.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba pri [`i32`], tipu, ki implementira `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Razčlenite `bool` iz niza.
    ///
    /// Da `Result<bool, ParseBoolError>`, ker je `s` dejansko mogoče razčleniti ali pa tudi ne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Upoštevajte, da je v mnogih primerih metoda `.parse()` na `str` ustreznejša.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}