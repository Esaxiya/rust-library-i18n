//! Operacije, povezane s preverjanjem veljavnosti UTF-8.

use crate::mem;

use super::Utf8Error;

/// Vrne začetni zbiralnik kodne točke za prvi bajt.
/// Prvi bajt je poseben, želimo le 5 bitov za širino 2, 4 bite za širino 3 in 3 bite za širino 4.
///
#[inline]
fn utf8_first_byte(byte: u8, width: u32) -> u32 {
    (byte & (0x7F >> width)) as u32
}

/// Vrne vrednost `ch`, posodobljene z nadaljevalnim bajtom `byte`.
#[inline]
fn utf8_acc_cont_byte(ch: u32, byte: u8) -> u32 {
    (ch << 6) | (byte & CONT_MASK) as u32
}

/// Preveri, ali je bajt nadaljevalni bajt UTF-8 (tj. Začne se z bitoma `10`).
///
#[inline]
pub(super) fn utf8_is_cont_byte(byte: u8) -> bool {
    (byte & !CONT_MASK) == TAG_CONT_U8
}

#[inline]
fn unwrap_or_0(opt: Option<&u8>) -> u8 {
    match opt {
        Some(&byte) => byte,
        None => 0,
    }
}

/// Prebere naslednjo kodno točko iz bajtnega iteratorja (ob predpostavki kodiranja, podobnega UTF-8).
///
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn next_code_point<'a, I: Iterator<Item = &'a u8>>(bytes: &mut I) -> Option<u32> {
    // Dekodiraj UTF-8
    let x = *bytes.next()?;
    if x < 128 {
        return Some(x as u32);
    }

    // Večbajtni primer sledi Decode iz kombinacije bajtov od: [[[x y] z] w]
    //
    // NOTE: Učinkovitost je tukaj občutljiva na natančno formulacijo
    let init = utf8_first_byte(x, 2);
    let y = unwrap_or_0(bytes.next());
    let mut ch = utf8_acc_cont_byte(init, y);
    if x >= 0xE0 {
        // [[x y z] w] primer
        // 5. bit v 0xE0 .. 0xEF je vedno jasen, zato `init` še vedno velja
        let z = unwrap_or_0(bytes.next());
        let y_z = utf8_acc_cont_byte((y & CONT_MASK) as u32, z);
        ch = init << 12 | y_z;
        if x >= 0xF0 {
            // [x y z w] ohišje uporabite samo spodnje 3 bite `init`
            //
            let w = unwrap_or_0(bytes.next());
            ch = (init & 7) << 18 | utf8_acc_cont_byte(y_z, w);
        }
    }

    Some(ch)
}

/// Prebere zadnjo kodno točko iz bajtnega iteratorja (ob predpostavki kodiranja, podobnega UTF-8).
///
#[inline]
pub(super) fn next_code_point_reverse<'a, I>(bytes: &mut I) -> Option<u32>
where
    I: DoubleEndedIterator<Item = &'a u8>,
{
    // Dekodiraj UTF-8
    let w = match *bytes.next_back()? {
        next_byte if next_byte < 128 => return Some(next_byte as u32),
        back_byte => back_byte,
    };

    // Večbajtni primer sledi Decode iz kombinacije bajtov iz: [x [y [z w]]]
    //
    let mut ch;
    let z = unwrap_or_0(bytes.next_back());
    ch = utf8_first_byte(z, 2);
    if utf8_is_cont_byte(z) {
        let y = unwrap_or_0(bytes.next_back());
        ch = utf8_first_byte(y, 3);
        if utf8_is_cont_byte(y) {
            let x = unwrap_or_0(bytes.next_back());
            ch = utf8_first_byte(x, 4);
            ch = utf8_acc_cont_byte(ch, y);
        }
        ch = utf8_acc_cont_byte(ch, z);
    }
    ch = utf8_acc_cont_byte(ch, w);

    Some(ch)
}

// uporabite okrnilo, da u64 prilagodite usize
const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;

/// Vrne `true`, če je katerikoli bajt v besedi `x` nonascii (>=128).
#[inline]
fn contains_nonascii(x: usize) -> bool {
    (x & NONASCII_MASK) != 0
}

/// Sprehod skozi `v` in preverjanje, ali gre za veljavno zaporedje UTF-8, vrnitev `Ok(())` v tem primeru ali, če je neveljavna, `Err(err)`.
///
#[inline(always)]
pub(super) fn run_utf8_validation(v: &[u8]) -> Result<(), Utf8Error> {
    let mut index = 0;
    let len = v.len();

    let usize_bytes = mem::size_of::<usize>();
    let ascii_block_size = 2 * usize_bytes;
    let blocks_end = if len >= ascii_block_size { len - ascii_block_size + 1 } else { 0 };
    let align = v.as_ptr().align_offset(usize_bytes);

    while index < len {
        let old_offset = index;
        macro_rules! err {
            ($error_len: expr) => {
                return Err(Utf8Error { valid_up_to: old_offset, error_len: $error_len })
            };
        }

        macro_rules! next {
            () => {{
                index += 1;
                // potrebovali smo podatke, vendar jih ni bilo: napaka!
                if index >= len {
                    err!(None)
                }
                v[index]
            }};
        }

        let first = v[index];
        if first >= 128 {
            let w = UTF8_CHAR_WIDTH[first as usize];
            // Dvobajtno kodiranje je za kodne točke\u {0080} do\u {07ff} prvi C2 80 zadnji DF BF
            // 3-bajtno kodiranje je za kodne točke\u {0800} do\u {ffff} prve E0 A0 80 zadnje EF BF BF, razen nadomestnih kodnih točk\u {d800} do\u {dfff} ED A0 80 do ED BF BF
            // 4-bajtno kodiranje je za kodne točke\u {1000} 0 do\u {10ff} ff prvi F0 90 80 80 zadnji F4 8F BF BF
            //
            // Uporabite sintakso UTF-8 iz RFC
            //
            // https://tools.ietf.org/html/rfc3629
            // UTF8-1=% x00-7F UTF8-2=% xC2-DF UTF8-rep UTF8-3= %xE0% xA0-BF UTF8-rep/% xE1-EC 2( UTF8-tail )/%xED% x80-9F UTF8-rep/% xEE-EF 2( UTF8-tail ) UTF8-4= %xF0% x90-BF 2( UTF8-tail )/% xF1-F3 3( UTF8-tail )/%xF4% x80-8F 2( UTF8-tail )
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            match w {
                2 => {
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(1))
                    }
                }
                3 => {
                    match (first, next!()) {
                        (0xE0, 0xA0..=0xBF)
                        | (0xE1..=0xEC, 0x80..=0xBF)
                        | (0xED, 0x80..=0x9F)
                        | (0xEE..=0xEF, 0x80..=0xBF) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                }
                4 => {
                    match (first, next!()) {
                        (0xF0, 0x90..=0xBF) | (0xF1..=0xF3, 0x80..=0xBF) | (0xF4, 0x80..=0x8F) => {}
                        _ => err!(Some(1)),
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(2))
                    }
                    if next!() & !CONT_MASK != TAG_CONT_U8 {
                        err!(Some(3))
                    }
                }
                _ => err!(Some(1)),
            }
            index += 1;
        } else {
            // Primer Ascii, poskusite hitro preskočiti naprej.
            // Ko je kazalnik poravnan, preberite dve besedi podatkov na iteracijo, dokler ne najdemo besede, ki vsebuje ne-ascii bajt.
            //
            if align != usize::MAX && align.wrapping_sub(index) % usize_bytes == 0 {
                let ptr = v.as_ptr();
                while index < blocks_end {
                    // VARNOST: saj `align - index` in `ascii_block_size` sta
                    // večkratnik `usize_bytes`, `block = ptr.add(index)` je vedno poravnan z `usize`, zato je varno razporejati tako `block` kot `block.offset(1)`.
                    //
                    //
                    unsafe {
                        let block = ptr.add(index) as *const usize;
                        // prekinite, če obstaja nonascii bajt
                        let zu = contains_nonascii(*block);
                        let zv = contains_nonascii(*block.offset(1));
                        if zu | zv {
                            break;
                        }
                    }
                    index += ascii_block_size;
                }
                // stopite od točke, kjer se je besedna zanka ustavila
                while index < len && v[index] < 128 {
                    index += 1;
                }
            } else {
                index += 1;
            }
        }
    }

    Ok(())
}

// https://tools.ietf.org/html/rfc3629
static UTF8_CHAR_WIDTH: [u8; 256] = [
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x1F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x3F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x5F
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, // 0x7F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0x9F
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, // 0xBF
    0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, // 0xDF
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, // 0xEF
    4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 0xFF
];

/// Glede na prvi bajt določi, koliko bajtov je v tem znaku UTF-8.
#[unstable(feature = "str_internals", issue = "none")]
#[inline]
pub fn utf8_char_width(b: u8) -> usize {
    UTF8_CHAR_WIDTH[b as usize] as usize
}

/// Maska vrednostnih bitov nadaljevalnega bajta.
const CONT_MASK: u8 = 0b0011_1111;
/// Vrednost bitov oznake (maska oznake je !CONT_MASK) nadaljevalnega bajta.
const TAG_CONT_U8: u8 = 0b1000_0000;

// obrezati `&str` na dolžino, ki je največ enaka `max`, vrne `true`, če je bila okrnjena, in nova str.
//
pub(super) fn truncate_to_char_boundary(s: &str, mut max: usize) -> (bool, &str) {
    if max >= s.len() {
        (false, s)
    } else {
        while !s.is_char_boundary(max) {
            max -= 1;
        }
        (true, &s[..max])
    }
}