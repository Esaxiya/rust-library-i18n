//! Načini za ustvarjanje `str` iz rezine bajtov.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Pretvori rezino bajtov v rezino niza.
///
/// Rezina niza ([`&str`]) je sestavljena iz bajtov ([`u8`]), rezina bajtov ([`&[u8]`][byteslice]) pa iz bajtov, zato ta funkcija pretvarja med njima.
/// Vse rezine bajtov niso veljavne rezine nizov, vendar [`&str`] zahteva, da velja UTF-8.
/// `from_utf8()` preveri, ali so bajti veljavni UTF-8, in nato izvede pretvorbo.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Če ste prepričani, da je rezina bajtov veljavna UTF-8, in ne želite, da bi prišlo do dodatnih stroškov preverjanja veljavnosti, obstaja nevarna različica te funkcije, [`from_utf8_unchecked`], ki ima enako vedenje, vendar preskoči preskus.
///
///
/// Če namesto `&str` potrebujete `String`, razmislite o [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Ker lahko `[u8; N]` dodelite skladom in lahko vzamete [`&[u8]`][byteslice], je ta funkcija eden od načinov za niz, dodeljen skladom.Primer tega je v spodnjem oddelku s primeri.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Vrne `Err`, če rezina ni UTF-8, z opisom, zakaj podana rezina ni UTF-8.
///
/// # Examples
///
/// Osnovna uporaba:
///
/// ```
/// use std::str;
///
/// // nekaj bajtov, v vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Vemo, da so ti bajti veljavni, zato samo uporabite `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Napačni bajti:
///
/// ```
/// use std::str;
///
/// // nekaj neveljavnih bajtov v vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Za več podrobnosti o vrstah napak, ki jih je mogoče vrniti, si oglejte dokumentacijo za [`Utf8Error`].
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // nekaj bajtov v matriki, dodeljeni skladom
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Vemo, da so ti bajti veljavni, zato samo uporabite `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // VARNOST: Pravkar izvedeno preverjanje veljavnosti.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Pretvori spremenljivo rezino bajtov v spremenljivo rezino niza.
///
/// # Examples
///
/// Osnovna uporaba:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" kot spremenljiv vector
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Ker vemo, da so ti bajti veljavni, lahko uporabimo `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Napačni bajti:
///
/// ```
/// use std::str;
///
/// // Nekaj neveljavnih bajtov v spremenljivem vector
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Za več podrobnosti o vrstah napak, ki jih je mogoče vrniti, si oglejte dokumentacijo za [`Utf8Error`].
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // VARNOST: Pravkar izvedeno preverjanje veljavnosti.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Pretvori rezino bajtov v rezino niza, ne da bi preveril, ali niz vsebuje veljaven UTF-8.
///
/// Za več informacij glejte varno različico [`from_utf8`].
///
/// # Safety
///
/// Ta funkcija ni varna, ker ne preverja, ali so ji posredovani bajti veljavni UTF-8.
/// Če je ta omejitev kršena, pride do nedefiniranega vedenja, saj preostali del Rust predpostavlja, da so [`&str`] s veljavni UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Osnovna uporaba:
///
/// ```
/// use std::str;
///
/// // nekaj bajtov, v vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // VARNOST: klicatelj mora zagotoviti, da so bajti `v` veljavni UTF-8.
    // Zanaša se tudi na `&str` in `&[u8]` z enako postavitvijo.
    unsafe { mem::transmute(v) }
}

/// Pretvori rezino bajtov v rezino niza, ne da bi preveril, ali niz vsebuje veljaven UTF-8;spremenljiva različica.
///
///
/// Za več informacij glejte nespremenljivo različico [`from_utf8_unchecked()`].
///
/// # Examples
///
/// Osnovna uporaba:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // VARNOST: klicatelj mora zagotoviti, da bajti `v`
    // so veljavni UTF-8, zato je predvajanje na `*mut str` varno.
    // Preimenovanje kazalca je tudi varno, ker ta kazalec prihaja iz sklica, ki je zagotovo veljaven za zapise.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}