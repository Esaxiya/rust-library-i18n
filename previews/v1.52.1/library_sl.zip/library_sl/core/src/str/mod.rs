//! Niz manipulacije.
//!
//! Za več podrobnosti glejte modul [`std::str`].
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. izven meja
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. začetek <=konec
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. meja znakov
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // poiščite lik
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` mora biti manj kot len in meja znaka
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Vrne dolžino `self`.
    ///
    /// Ta dolžina je v bajtih, ne v znakih ali grafemah.
    /// Z drugimi besedami, morda človek ne šteje za dolžino vrvice.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // fancy f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Vrne `true`, če ima `self` dolžino nič bajtov.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Preveri, ali je indeksni bajt prvi bajt v zaporedju kodne točke UTF-8 ali konec niza.
    ///
    ///
    /// Začetek in konec niza (kadar se `index== self.len()`) štejeta za meji.
    ///
    /// Vrne `false`, če je `index` večji od `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // začetek `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // drugi bajt `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // tretji bajt `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 in len sta vedno v redu.
        // Preizkusite izrecno za 0, tako da lahko enostavno optimizira preverjanje in preskoči branje podatkov niza za ta primer.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // To je magična bit, enakovredna: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Pretvori rezino niza v bajtno rezino.
    /// Če želite bajtno rezino pretvoriti nazaj v rezino niza, uporabite funkcijo [`from_utf8`].
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // VARNOST: const zvok, ker pretvorimo dve vrsti z enako postavitvijo
        unsafe { mem::transmute(self) }
    }

    /// Pretvori spremenljivo rezino niza v spremenljivo bajtno rezino.
    ///
    /// # Safety
    ///
    /// Klicatelj mora zagotoviti, da je vsebina rezine veljavna UTF-8, preden se izposoja konča in se uporabi osnovni `str`.
    ///
    ///
    /// Uporaba `str`, katere vsebina ni veljavna UTF-8, je nedefinirano.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // VARNOST: zasedba od `&str` do `&[u8]` je varna že od `str`
        // ima enako postavitev kot `&[u8]` (to garancijo lahko zagotovi le libstd).
        // Preimenovanje kazalca je varno, saj prihaja iz spremenljive reference, ki je zagotovo veljavna za zapise.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Rezino niza pretvori v neobdelan kazalec.
    ///
    /// Ker so rezine nizov rezina bajtov, surovi kazalec kaže na [`u8`].
    /// Ta kazalec bo kazal na prvi bajt rezine niza.
    ///
    /// Klicatelj mora zagotoviti, da vrnjeni kazalnik ni nikoli zapisan.
    /// Če želite mutirati vsebino rezine niza, uporabite [`as_mut_ptr`].
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Pretvori spremenljivo rezino niza v neobdelan kazalec.
    ///
    /// Ker so rezine nizov rezina bajtov, surovi kazalec kaže na [`u8`].
    /// Ta kazalec bo kazal na prvi bajt rezine niza.
    ///
    /// Vaša odgovornost je zagotoviti, da se rezina niza spremeni samo tako, da ostane veljavna UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Vrne podrezo `str`.
    ///
    /// To je panična alternativa indeksiranju `str`.
    /// Vrne [`None`], kadar bi enakovredna operacija indeksiranja predstavljala panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // indeksi, ki niso na mejah zaporedja UTF-8
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // izven meja
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Vrne spremenljivo podreznico `str`.
    ///
    /// To je panična alternativa indeksiranju `str`.
    /// Vrne [`None`], kadar bi enakovredna operacija indeksiranja predstavljala panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // pravilna dolžina
    /// assert!(v.get_mut(0..5).is_some());
    /// // izven meja
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Vrne nepreverjeno podreznico `str`.
    ///
    /// To je nepreverjena alternativa indeksiranju `str`.
    ///
    /// # Safety
    ///
    /// Klicatelji te funkcije so odgovorni, da so izpolnjeni ti predpogoji:
    ///
    /// * Začetni indeks ne sme presegati končnega indeksa;
    /// * Kazala morajo biti v mejah prvotne rezine;
    /// * Kazala morajo ležati na mejah zaporedja UTF-8.
    ///
    /// V nasprotnem primeru se lahko vrnjena rezina niza sklicuje na neveljaven pomnilnik ali krši invariante, sporočene s tipom `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `get_unchecked`;
        // rezine ni mogoče razločiti, ker je `self` varna referenca.
        // Vrnjeni kazalec je varen, ker morajo impulzi `SliceIndex` zagotoviti, da je.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Vrne spremenljivo, nepreverjeno podreznico `str`.
    ///
    /// To je nepreverjena alternativa indeksiranju `str`.
    ///
    /// # Safety
    ///
    /// Klicatelji te funkcije so odgovorni, da so izpolnjeni ti predpogoji:
    ///
    /// * Začetni indeks ne sme presegati končnega indeksa;
    /// * Kazala morajo biti v mejah prvotne rezine;
    /// * Kazala morajo ležati na mejah zaporedja UTF-8.
    ///
    /// V nasprotnem primeru se lahko vrnjena rezina niza sklicuje na neveljaven pomnilnik ali krši invariante, sporočene s tipom `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `get_unchecked_mut`;
        // rezine ni mogoče razločiti, ker je `self` varna referenca.
        // Vrnjeni kazalec je varen, ker morajo impulzi `SliceIndex` zagotoviti, da je.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Ustvari rezino niza iz druge rezine niza, pri čemer se izognejo varnostnim preverjanjem.
    ///
    /// To na splošno ni priporočljivo, uporabljajte previdno!Za varno alternativo glejte [`str`] in [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Ta nova rezina se giblje od `begin` do `end`, vključno z `begin`, vendar brez `end`.
    ///
    /// Če želite namesto tega dobiti spremenljivo rezino niza, glejte metodo [`slice_mut_unchecked`].
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Klicatelji te funkcije so odgovorni, da so izpolnjeni trije predpogoji:
    ///
    /// * `begin` ne sme presegati `end`.
    /// * `begin` in `end` morata biti položaj bajtov znotraj rezine niza.
    /// * `begin` in `end` mora ležati na mejah zaporedja UTF-8.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `get_unchecked`;
        // rezine ni mogoče razločiti, ker je `self` varna referenca.
        // Vrnjeni kazalec je varen, ker morajo impulzi `SliceIndex` zagotoviti, da je.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Ustvari rezino niza iz druge rezine niza, pri čemer se izognejo varnostnim preverjanjem.
    /// To na splošno ni priporočljivo, uporabljajte previdno!Za varno alternativo glejte [`str`] in [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Ta nova rezina se giblje od `begin` do `end`, vključno z `begin`, vendar brez `end`.
    ///
    /// Če želite namesto tega dobiti nespremenljivo rezino nizov, glejte metodo [`slice_unchecked`].
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Klicatelji te funkcije so odgovorni, da so izpolnjeni trije predpogoji:
    ///
    /// * `begin` ne sme presegati `end`.
    /// * `begin` in `end` morata biti položaj bajtov znotraj rezine niza.
    /// * `begin` in `end` mora ležati na mejah zaporedja UTF-8.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `get_unchecked_mut`;
        // rezine ni mogoče razločiti, ker je `self` varna referenca.
        // Vrnjeni kazalec je varen, ker morajo impulzi `SliceIndex` zagotoviti, da je.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// En rezinski niz razdeli na dva po indeksu.
    ///
    /// Argument, `mid`, bi moral biti odmik bajtov od začetka niza.
    /// Prav tako mora biti na meji kodne točke UTF-8.
    ///
    /// Vrnjeni dve rezini greta od začetka rezine niza do `mid` in od `mid` do konca rezine niza.
    ///
    /// Če želite namesto tega dobiti spremenljive rezine nizov, glejte metodo [`split_at_mut`].
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics, če `mid` ni na meji kodne točke UTF-8 ali če je mimo konca zadnje kodne točke rezine niza.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary preveri, ali je indeks v [0, .len()]
        if self.is_char_boundary(mid) {
            // VARNOST: pravkar sem preveril, ali je `mid` na meji znakov.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Eno spremenljivo rezino niza razdelite na dve v indeksu.
    ///
    /// Argument, `mid`, bi moral biti odmik bajtov od začetka niza.
    /// Prav tako mora biti na meji kodne točke UTF-8.
    ///
    /// Vrnjeni dve rezini greta od začetka rezine niza do `mid` in od `mid` do konca rezine niza.
    ///
    /// Če želite namesto tega dobiti nespremenljive rezine nizov, glejte metodo [`split_at`].
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics, če `mid` ni na meji kodne točke UTF-8 ali če je mimo konca zadnje kodne točke rezine niza.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary preveri, ali je indeks v [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // VARNOST: pravkar sem preveril, ali je `mid` na meji znakov.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Vrne iterator nad [`char`] s rezine niza.
    ///
    /// Ker je rezina niza sestavljena iz veljavnega UTF-8, lahko ponovimo niz rezin do [`char`].
    /// Ta metoda vrne tak iterator.
    ///
    /// Pomembno je vedeti, da [`char`] predstavlja skalarno vrednost Unicode in se morda ne ujema z vašo predstavo o tem, kaj je 'character'.
    ///
    /// Pravzaprav si želite ponoviti grozde grafemov.
    /// Te funkcije ne zagotavlja standardna knjižnica Rust, namesto tega preverite crates.io.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Ne pozabite, da se (`char`) s morda ne ujemajo z vašo intuicijo o znakih:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // ne 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Vrne iterator nad [`char`] s rezine niza in njihove položaje.
    ///
    /// Ker je rezina niza sestavljena iz veljavnega UTF-8, lahko ponovimo niz rezin do [`char`].
    /// Ta metoda vrne iterator tako teh [`char`] kot tudi njihovih bajtnih položajev.
    ///
    /// Iterator daje torte.Položaj je prvi, [`char`] pa drugi.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Ne pozabite, da se (`char`) s morda ne ujemajo z vašo intuicijo o znakih:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // ne (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // upoštevajte tukaj 3, zadnji znak je zasedel dva bajta
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// Ponavljalec nad bajti rezine niza.
    ///
    /// Ker je rezina niza sestavljena iz zaporedja bajtov, lahko ponovimo niz rezin po bajtih.
    /// Ta metoda vrne tak iterator.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Rezino niza razdeli s presledkom.
    ///
    /// Vrnjeni iterator bo vrnil rezine nizov, ki so podrezke prvotne rezine nizov, ločene s poljubno količino presledkov.
    ///
    ///
    /// 'Whitespace' je opredeljen v skladu s pogoji Unicode izpeljane osnovne lastnosti `White_Space`.
    /// Če želite namesto tega razdeliti samo na presledke ASCII, uporabite [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Upoštevajo se vse vrste presledkov:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Delitev niza razdeli s presledkom ASCII.
    ///
    /// Vrnjeni iterator bo vrnil rezine nizov, ki so podrezke prvotne rezine nizov, ločene s poljubno količino presledkov ASCII.
    ///
    ///
    /// Če ga želite razdeliti po Unicode `Whitespace`, uporabite [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Upoštevajo se vse vrste presledkov ASCII:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// Ponavljalec nad vrsticami niza kot rezine nizov.
    ///
    /// Vrstice se končajo z novo vrstico (`\n`) ali vrnitvijo nosilca z podajanjem vrstic (`\r\n`).
    ///
    /// Končni zaključek vrstice ni obvezen.
    /// Niz, ki se konča s končno vrstico, bo vrnil iste vrstice kot sicer enak niz brez končne vrstice, ki se konča.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Končna končna vrstica ni potrebna:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// Ponavljalec nad vrsticami niza.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Vrne iterator `u16` prek niza, kodiranega kot UTF-16.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Vrne `true`, če se dani vzorec ujema s podrezilom te rezine niza.
    ///
    /// Vrne `false`, če se ne.
    ///
    /// [pattern] je lahko `&str`, [`char`], rez ["char`] s ali funkcija ali zaprtje, ki določa, ali se znak ujema.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Vrne `true`, če se dani vzorec ujema s predpono te rezine niza.
    ///
    /// Vrne `false`, če se ne.
    ///
    /// [pattern] je lahko `&str`, [`char`], rez ["char`] s ali funkcija ali zaprtje, ki določa, ali se znak ujema.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Vrne `true`, če se dani vzorec ujema s pripono te rezine niza.
    ///
    /// Vrne `false`, če se ne.
    ///
    /// [pattern] je lahko `&str`, [`char`], rez ["char`] s ali funkcija ali zaprtje, ki določa, ali se znak ujema.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Vrne indeks bajtov prvega znaka te rezine niza, ki se ujema z vzorcem.
    ///
    /// Vrne [`None`], če se vzorec ne ujema.
    ///
    /// [pattern] je lahko `&str`, [`char`], rez ["char`] s ali funkcija ali zaprtje, ki določa, ali se znak ujema.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Preprosti vzorci:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Bolj zapleteni vzorci, ki uporabljajo slog brez zapiranja in zapore:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Ne najdem vzorca:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Vrne indeks bajtov prvega znaka skrajno desnega ujemanja vzorca v tej rezini niza.
    ///
    /// Vrne [`None`], če se vzorec ne ujema.
    ///
    /// [pattern] je lahko `&str`, [`char`], rez ["char`] s ali funkcija ali zaprtje, ki določa, ali se znak ujema.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Preprosti vzorci:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Bolj zapleteni vzorci z zapirali:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Ne najdem vzorca:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// Iterator nad podnizi te rezine niza, ločen z znaki, ki se ujemajo z vzorcem.
    ///
    /// [pattern] je lahko `&str`, [`char`], rez ["char`] s ali funkcija ali zaprtje, ki določa, ali se znak ujema.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Obnašanje iteratorja
    ///
    /// Vrnjeni iterator bo [`DoubleEndedIterator`], če vzorec omogoča obratno iskanje in iskanje forward/reverse daje enake elemente.
    /// To velja na primer za [`char`], ne pa tudi za `&str`.
    ///
    /// Če vzorec omogoča obratno iskanje, vendar se njegovi rezultati morda razlikujejo od iskanja naprej, lahko uporabimo metodo [`rsplit`].
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Preprosti vzorci:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Če je vzorec rezina znakov, razdelite na vsako pojavitev katerega koli znaka:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Bolj zapleten vzorec z uporabo zapore:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Če niz vsebuje več sosednjih ločil, boste na koncu imeli prazne nize:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Neprekinjena ločila ločuje prazen niz.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Ločila na začetku ali koncu niza so sosednja s praznimi nizi.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Ko se prazen niz uporablja kot ločilo, loči vsak znak v nizu, skupaj z začetkom in koncem niza.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Neprekinjena ločila lahko pri presledku povzročijo presenetljivo vedenje.Ta koda je pravilna:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// _not_ vam omogoča:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Za to uporabite [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// Iterator nad podnizi te rezine niza, ločen z znaki, ki se ujemajo z vzorcem.
    /// Razlikuje se od iteratorja, ki ga je ustvaril `split`, v tem, da `split_inclusive` pusti ujemajoči se del kot zaključek podniza.
    ///
    ///
    /// [pattern] je lahko `&str`, [`char`], rez ["char`] s ali funkcija ali zaprtje, ki določa, ali se znak ujema.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Če se ujema zadnji element niza, se ta element šteje za zaključek prejšnjega podniza.
    /// Ta podniz bo zadnji element, ki ga je vrnil iterator.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// Iterator nad podnizi dane rezine niza, ločen z znaki, ki se ujemajo z vzorcem in dajo v obratnem vrstnem redu.
    ///
    /// [pattern] je lahko `&str`, [`char`], rez ["char`] s ali funkcija ali zaprtje, ki določa, ali se znak ujema.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Obnašanje iteratorja
    ///
    /// Vrnjeni iterator zahteva, da vzorec podpira obratno iskanje, in če bo iskanje forward/reverse dalo enake elemente, bo [`DoubleEndedIterator`].
    ///
    ///
    /// Za ponovitev od spredaj se lahko uporabi metoda [`split`].
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Preprosti vzorci:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Bolj zapleten vzorec z uporabo zapore:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// Iterator nad podnizi dane rezine niza, ločen z znaki, ki se ujemajo z vzorcem.
    ///
    /// [pattern] je lahko `&str`, [`char`], rez ["char`] s ali funkcija ali zaprtje, ki določa, ali se znak ujema.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Enakovredno [`split`], le da je končni podniz preskočen, če je prazen.
    ///
    /// [`split`]: str::split
    ///
    /// Ta metoda se lahko uporabi za nizne podatke, ki so _terminated_ in ne _separated_ po vzorcu.
    ///
    /// # Obnašanje iteratorja
    ///
    /// Vrnjeni iterator bo [`DoubleEndedIterator`], če vzorec omogoča obratno iskanje in iskanje forward/reverse daje enake elemente.
    /// To velja na primer za [`char`], ne pa tudi za `&str`.
    ///
    /// Če vzorec omogoča obratno iskanje, vendar se njegovi rezultati morda razlikujejo od iskanja naprej, lahko uporabimo metodo [`rsplit_terminator`].
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// Iterator nad podnizi `self`, ločen z znaki, ki se ujemajo z vzorcem in dobimo v obratnem vrstnem redu.
    ///
    /// [pattern] je lahko `&str`, [`char`], rez ["char`] s ali funkcija ali zaprtje, ki določa, ali se znak ujema.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Enakovredno [`split`], le da je končni podniz preskočen, če je prazen.
    ///
    /// [`split`]: str::split
    ///
    /// Ta metoda se lahko uporabi za nizne podatke, ki so _terminated_ in ne _separated_ po vzorcu.
    ///
    /// # Obnašanje iteratorja
    ///
    /// Vrnjeni iterator zahteva, da vzorec podpira obratno iskanje, in bo dvojno končan, če bo iskanje forward/reverse dalo enake elemente.
    ///
    ///
    /// Za ponovitev od spredaj se lahko uporabi metoda [`split_terminator`].
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// Ponavljalec nad podnizi dane rezine nizov, ločen z vzorcem, omejen na vrnitev večine elementov `n`.
    ///
    /// Če se vrnejo podnizi `n`, bo zadnji podniz (n-ti podniz) vseboval preostanek niza.
    ///
    /// [pattern] je lahko `&str`, [`char`], rez ["char`] s ali funkcija ali zaprtje, ki določa, ali se znak ujema.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Obnašanje iteratorja
    ///
    /// Vrnjeni iterator ne bo dvojno končan, ker ni učinkovit za podporo.
    ///
    /// Če vzorec omogoča obratno iskanje, lahko uporabimo metodo [`rsplitn`].
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Preprosti vzorci:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Bolj zapleten vzorec z uporabo zapore:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// Iterator nad podnizi te rezine niza, ločen z vzorcem, začenši s konca niza, omejen na vrnitev največ `n` elementov.
    ///
    ///
    /// Če se vrnejo podnizi `n`, bo zadnji podniz (n-ti podniz) vseboval preostanek niza.
    ///
    /// [pattern] je lahko `&str`, [`char`], rez ["char`] s ali funkcija ali zaprtje, ki določa, ali se znak ujema.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Obnašanje iteratorja
    ///
    /// Vrnjeni iterator ne bo dvojno končan, ker ni učinkovit za podporo.
    ///
    /// Za ločitev od spredaj lahko uporabimo metodo [`splitn`].
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Preprosti vzorci:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Bolj zapleten vzorec z uporabo zapore:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Razdeli niz ob prvem pojavu določenega ločila in vrne predpono pred ločevalnikom in pripono za ločevalnikom.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Razdeli niz na zadnji pojav določenega ločila in vrne predpono pred ločevalnikom in pripono za ločevalnikom.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// Iterator nad disjontnim ujemanjem vzorca znotraj dane rezine niza.
    ///
    /// [pattern] je lahko `&str`, [`char`], rez ["char`] s ali funkcija ali zaprtje, ki določa, ali se znak ujema.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Obnašanje iteratorja
    ///
    /// Vrnjeni iterator bo [`DoubleEndedIterator`], če vzorec omogoča obratno iskanje in iskanje forward/reverse daje enake elemente.
    /// To velja na primer za [`char`], ne pa tudi za `&str`.
    ///
    /// Če vzorec omogoča obratno iskanje, vendar se njegovi rezultati morda razlikujejo od iskanja naprej, lahko uporabimo metodo [`rmatches`].
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// Ponavljalec nad nerazdružljivimi ujemanji vzorca znotraj te rezine niza, ki se daje v obratnem vrstnem redu.
    ///
    /// [pattern] je lahko `&str`, [`char`], rez ["char`] s ali funkcija ali zaprtje, ki določa, ali se znak ujema.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Obnašanje iteratorja
    ///
    /// Vrnjeni iterator zahteva, da vzorec podpira obratno iskanje, in če bo iskanje forward/reverse dalo enake elemente, bo [`DoubleEndedIterator`].
    ///
    ///
    /// Za ponovitev od spredaj se lahko uporabi metoda [`matches`].
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// Iterator nad nepovezanimi ujemanji vzorca v tej rezini nizov in indeks, pri katerem se ujemanje začne.
    ///
    /// Za ujemanja `pat` znotraj `self`, ki se prekrivajo, se vrnejo samo indeksi, ki ustrezajo prvemu ujemanju.
    ///
    /// [pattern] je lahko `&str`, [`char`], rez ["char`] s ali funkcija ali zaprtje, ki določa, ali se znak ujema.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Obnašanje iteratorja
    ///
    /// Vrnjeni iterator bo [`DoubleEndedIterator`], če vzorec omogoča obratno iskanje in iskanje forward/reverse daje enake elemente.
    /// To velja na primer za [`char`], ne pa tudi za `&str`.
    ///
    /// Če vzorec omogoča obratno iskanje, vendar se njegovi rezultati morda razlikujejo od iskanja naprej, lahko uporabimo metodo [`rmatch_indices`].
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // samo prvi `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// Ponavljalec nad nepovezanimi ujemanji vzorca znotraj `self`, prikazan v obratnem vrstnem redu skupaj z indeksom ujemanja.
    ///
    /// Za ujemanja `pat` znotraj `self`, ki se prekrivajo, se vrnejo samo indeksi, ki ustrezajo zadnjemu ujemanju.
    ///
    /// [pattern] je lahko `&str`, [`char`], rez ["char`] s ali funkcija ali zaprtje, ki določa, ali se znak ujema.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Obnašanje iteratorja
    ///
    /// Vrnjeni iterator zahteva, da vzorec podpira obratno iskanje, in če bo iskanje forward/reverse dalo enake elemente, bo [`DoubleEndedIterator`].
    ///
    ///
    /// Za ponovitev od spredaj se lahko uporabi metoda [`match_indices`].
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // samo zadnji `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Vrne rezino niza z odstranjenim presledkom vodilnega in zadnjega presledka.
    ///
    /// 'Whitespace' je opredeljen v skladu s pogoji Unicode izpeljane osnovne lastnosti `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Vrne rezino niza z odstranjenim presledkom.
    ///
    /// 'Whitespace' je opredeljen v skladu s pogoji Unicode izpeljane osnovne lastnosti `White_Space`.
    ///
    /// # Usmerjenost besedila
    ///
    /// Niz je zaporedje bajtov.
    /// `start` v tem kontekstu pomeni prvi položaj tega bajtnega niza;za jezik od leve proti desni, kot sta angleščina ali ruščina, bo to leva stran, za jezike od desne proti levi, kot sta arabščina ali hebrejščina, pa desna stran.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Vrne rezino niza z odstranjenim zadnjim presledkom.
    ///
    /// 'Whitespace' je opredeljen v skladu s pogoji Unicode izpeljane osnovne lastnosti `White_Space`.
    ///
    /// # Usmerjenost besedila
    ///
    /// Niz je zaporedje bajtov.
    /// `end` v tem kontekstu pomeni zadnji položaj tega bajtnega niza;za jezik od leve proti desni, kot sta angleščina ali ruščina, bo to desna stran, za jezike od desne proti levi, kot sta arabščina ali hebrejščina, pa leva stran.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Vrne rezino niza z odstranjenim presledkom.
    ///
    /// 'Whitespace' je opredeljen v skladu s pogoji Unicode izpeljane osnovne lastnosti `White_Space`.
    ///
    /// # Usmerjenost besedila
    ///
    /// Niz je zaporedje bajtov.
    /// 'Left' v tem kontekstu pomeni prvi položaj tega bajtnega niza;za jezik, kot sta arabščina ali hebrejščina, ki sta "desno na levo" in ne "od leve proti desni", bo to stran _right_, ne leva.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Vrne rezino niza z odstranjenim zadnjim presledkom.
    ///
    /// 'Whitespace' je opredeljen v skladu s pogoji Unicode izpeljane osnovne lastnosti `White_Space`.
    ///
    /// # Usmerjenost besedila
    ///
    /// Niz je zaporedje bajtov.
    /// 'Right' v tem kontekstu pomeni zadnji položaj tega bajtnega niza;za jezik, kot sta arabščina ali hebrejščina, ki sta "od desne proti levi" in ne "od leve proti desni", bo to stran _left_, ne desna.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Vrne rezino niza z vsemi predponami in priponami, ki se ujemajo z večkrat odstranjenim vzorcem.
    ///
    /// [pattern] je lahko [`char`], rez [`char`] s ali funkcija ali zaprtje, ki določa, ali se znak ujema.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Preprosti vzorci:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Bolj zapleten vzorec z uporabo zapore:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Spomnite se najzgodnejšega znanega ujemanja, popravite ga spodaj, če
            // zadnja tekma je drugačna
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // VARNOST: Znano je, da `Searcher` vrne veljavne indekse.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Vrne rezino niza z vsemi predponami, ki se ujemajo z večkrat odstranjenim vzorcem.
    ///
    /// [pattern] je lahko `&str`, [`char`], rez ["char`] s ali funkcija ali zaprtje, ki določa, ali se znak ujema.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Usmerjenost besedila
    ///
    /// Niz je zaporedje bajtov.
    /// `start` v tem kontekstu pomeni prvi položaj tega bajtnega niza;za jezik od leve proti desni, kot sta angleščina ali ruščina, bo to leva stran, za jezike od desne proti levi, kot sta arabščina ali hebrejščina, pa desna stran.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // VARNOST: Znano je, da `Searcher` vrne veljavne indekse.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Vrne rezino niza z odstranjeno predpono.
    ///
    /// Če se niz začne z vzorcem `prefix`, vrne podniz za predpono, ovito v `Some`.
    /// Za razliko od `trim_start_matches` ta metoda predpono odstrani natančno enkrat.
    ///
    /// Če se niz ne začne z `prefix`, vrne `None`.
    ///
    /// [pattern] je lahko `&str`, [`char`], rez ["char`] s ali funkcija ali zaprtje, ki določa, ali se znak ujema.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Vrne rezino niza z odstranjeno pripono.
    ///
    /// Če se niz konča z vzorcem `suffix`, vrne podniz pred pripono, ovito v `Some`.
    /// Za razliko od `trim_end_matches` ta metoda končnico odstrani natančno enkrat.
    ///
    /// Če se niz ne konča z `suffix`, vrne `None`.
    ///
    /// [pattern] je lahko `&str`, [`char`], rez ["char`] s ali funkcija ali zaprtje, ki določa, ali se znak ujema.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Vrne rezino niza z vsemi priponami, ki se ujemajo z večkrat odstranjenim vzorcem.
    ///
    /// [pattern] je lahko `&str`, [`char`], rez ["char`] s ali funkcija ali zaprtje, ki določa, ali se znak ujema.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Usmerjenost besedila
    ///
    /// Niz je zaporedje bajtov.
    /// `end` v tem kontekstu pomeni zadnji položaj tega bajtnega niza;za jezik od leve proti desni, kot sta angleščina ali ruščina, bo to desna stran, za jezike od desne proti levi, kot sta arabščina ali hebrejščina, pa leva stran.
    ///
    ///
    /// # Examples
    ///
    /// Preprosti vzorci:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Bolj zapleten vzorec z uporabo zapore:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // VARNOST: Znano je, da `Searcher` vrne veljavne indekse.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Vrne rezino niza z vsemi predponami, ki se ujemajo z večkrat odstranjenim vzorcem.
    ///
    /// [pattern] je lahko `&str`, [`char`], rez ["char`] s ali funkcija ali zaprtje, ki določa, ali se znak ujema.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Usmerjenost besedila
    ///
    /// Niz je zaporedje bajtov.
    /// 'Left' v tem kontekstu pomeni prvi položaj tega bajtnega niza;za jezik, kot sta arabščina ali hebrejščina, ki sta "desno na levo" in ne "od leve proti desni", bo to stran _right_, ne leva.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Vrne rezino niza z vsemi priponami, ki se ujemajo z večkrat odstranjenim vzorcem.
    ///
    /// [pattern] je lahko `&str`, [`char`], rez ["char`] s ali funkcija ali zaprtje, ki določa, ali se znak ujema.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Usmerjenost besedila
    ///
    /// Niz je zaporedje bajtov.
    /// 'Right' v tem kontekstu pomeni zadnji položaj tega bajtnega niza;za jezik, kot sta arabščina ali hebrejščina, ki sta "od desne proti levi" in ne "od leve proti desni", bo to stran _left_, ne desna.
    ///
    ///
    /// # Examples
    ///
    /// Preprosti vzorci:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Bolj zapleten vzorec z uporabo zapore:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Razdeli to rezino niza na drugo vrsto.
    ///
    /// Ker je `parse` tako splošen, lahko povzroči težave s sklepanjem o tipu.
    /// Kot tak je `parse` eden redkih primerov, v katerem boste sintakso ljubkovalno imenovali 'turbofish': `::<>`.
    ///
    /// To pomaga algoritmu sklepanja natančno razumeti, v katero vrsto poskušate razčleniti.
    ///
    /// `parse` lahko razčleni na katero koli vrsto, ki implementira [`FromStr`] Portrait.
    ///

    /// # Errors
    ///
    /// Vrnil bo [`Err`], če te rezine niza ni mogoče razčleniti na želeno vrsto.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Osnovna uporaba
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Uporaba 'turbofish' namesto označevanja `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Razčlenitev ni uspela:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Preveri, ali so vsi znaki v tem nizu znotraj obsega ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Tu lahko vsak bajt obravnavamo kot znak: vsi večbajtni znaki se začnejo z bajtom, ki ni v ascii območju, zato se bomo tam že ustavili.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Preveri, ali sta dva niza ujemanja ASCII, ki ne razlikujeta med velikimi in malimi črkami.
    ///
    /// Enako kot `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, vendar brez dodeljevanja in kopiranja začasnih datotek.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Pretvori ta niz v svoj ASCII, enakovreden velikim črkam.
    ///
    /// Črke ASCII 'a' do 'z' so preslikane v 'A' do 'Z', črke, ki niso ASCII, pa nespremenjene.
    ///
    /// Če želite vrniti novo veliko črko, ne da bi spremenili obstoječo, uporabite [`to_ascii_uppercase()`].
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // VARNOST: varno, ker pretvorimo dve vrsti z enako postavitvijo.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Pretvori ta niz v svoj ASCII, ki je enakovreden malim črkam.
    ///
    /// Črke ASCII 'A' do 'Z' so preslikane v 'a' do 'z', črke, ki niso ASCII, pa nespremenjene.
    ///
    /// Če želite vrniti novo majhno vrednost brez spreminjanja obstoječe, uporabite [`to_ascii_lowercase()`].
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // VARNOST: varno, ker pretvorimo dve vrsti z enako postavitvijo.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Vrnite iterator, ki uide vsakemu znaku v `self` z [`char::escape_debug`].
    ///
    ///
    /// Note: ubežale bodo samo razširjene grafemske kodne točke, ki začnejo niz.
    ///
    /// # Examples
    ///
    /// Kot iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Neposredna uporaba `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Oba sta enakovredna:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Uporaba `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Vrnite iterator, ki uide vsakemu znaku v `self` z [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// Kot iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Neposredna uporaba `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Oba sta enakovredna:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Uporaba `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Vrnite iterator, ki uide vsakemu znaku v `self` z [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// Kot iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Neposredna uporaba `println!`:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Oba sta enakovredna:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Uporaba `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Ustvari prazen str
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Ustvari prazen spremenljiv str
    #[inline]
    fn default() -> Self {
        // VARNOST: Prazen niz je veljaven UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// Poimenovan, kloniran tip fn
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // VARNOST: ni varno
        unsafe { from_utf8_unchecked(bytes) }
    };
}