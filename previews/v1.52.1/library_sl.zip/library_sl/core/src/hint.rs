#![stable(feature = "core_hint", since = "1.27.0")]

//! Namigi prevajalniku, ki vpliva na to, kako je treba kodo oddajati ali optimizirati.
//! Namigi so lahko čas prevajanja ali čas izvajanja.

use crate::intrinsics;

/// Obvešča prevajalnik, da ta točka v kodi ni dosegljiva, kar omogoča nadaljnje optimizacije.
///
/// # Safety
///
/// Doseganje te funkcije je popolnoma *nedefinirano vedenje*(UB).Prevajalnik zlasti predpostavlja, da se vsi UB nikoli ne sme zgoditi, in bo zato odpravil vse veje, ki segajo do klica na `unreachable_unchecked()`.
///
/// Tako kot vsi primeri UB, če se izkaže, da je ta predpostavka napačna, tj. Je klic `unreachable_unchecked()` dejansko dosegljiv med vsem možnim krmilnim tokom, bo prevajalnik uporabil napačno strategijo optimizacije in lahko včasih celo pokvari na videz nepovezane kode, kar povzroči težave z odpravljanjem napak.
///
///
/// To funkcijo uporabljajte le, če lahko dokažete, da je koda ne bo nikoli poklicala.
/// V nasprotnem primeru razmislite o uporabi makra [`unreachable!`], ki ne omogoča optimizacij, vendar bo panic ob izvedbi.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` je vedno pozitiven (ne nič), zato `checked_div` ne bo nikoli vrnil `None`.
/////
///     // Zato je branch sicer nedosegljiv.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // VARNOST: varnostna pogodba za `intrinsics::unreachable` mora
    // klicatelj.
    unsafe { intrinsics::unreachable() }
}

/// Odda strojno navodilo, s katerim sporoči procesorju, da deluje v zaokroženi zanki ("spin lock").
///
/// Po prejemu signala spin-zanke lahko procesor optimizira svoje vedenje tako, da na primer prihrani energijo ali preklopi hyper-niti.
///
/// Ta funkcija se razlikuje od [`thread::yield_now`], ki se neposredno poda sistemskemu načrtovalniku, medtem ko `spin_loop` ne deluje z operacijskim sistemom.
///
/// Pogost primer uporabe `spin_loop` je izvajanje omejenega optimističnega predenja v zanki CAS v sinhronizacijskih primitivih.
/// Da bi se izognili težavam, kot je prednostna inverzija, je močno priporočljivo, da se zanka zavrti po končni količini ponovitev in se izvede ustrezen blokirajoči syscall.
///
///
/// **Opomba**: Na platformah, ki ne podpirajo prejemanja nasvetov o spin-loop, ta funkcija sploh ne naredi ničesar.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // Skupna atomska vrednost, ki jo bodo niti uporabile za koordinacijo
/// let live = Arc::new(AtomicBool::new(false));
///
/// // V niti v ozadju bomo sčasoma nastavili vrednost
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Naredite nekaj dela, nato pa vrednost poživite
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Nazaj na trenutno nit čakamo, da se nastavi vrednost
/// while !live.load(Ordering::Acquire) {
///     // Spin zanka je namig CPU-ju, da čakamo, a verjetno ne prav dolgo
/////
///     hint::spin_loop();
/// }
///
/// // Vrednost je zdaj nastavljena
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // VARNOST: atribut `cfg` zagotavlja, da to izvajamo samo na ciljih x86.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // VARNOST: atribut `cfg` zagotavlja, da to izvajamo samo na ciljih x86_64.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // VARNOST: atribut `cfg` zagotavlja, da to izvajamo samo na ciljih aarch64.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // VARNOST: `cfg` attr zagotavlja, da to izvajamo samo na ciljih roke
            // s podporo za funkcijo v6.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// Funkcija identitete, ki *__ namiguje __* prevajalniku, da je maksimalno pesimističen glede tega, kaj lahko naredi `black_box`.
///
/// Za razliko od [`std::convert::identity`] je priporočljivo, da prevajalnik Rust domneva, da lahko `black_box` uporablja `dummy` na kakršen koli veljaven način, kot je dovoljeno kodi Rust, ne da bi v klicno kodo vnesel nedefinirano vedenje.
///
/// Zaradi te lastnosti je `black_box` uporaben za pisanje kode, pri kateri nekatere optimizacije niso zaželene, na primer merila uspešnosti.
///
/// Upoštevajte pa, da je `black_box` na voljo (in lahko samo) na osnovi "best-effort".Obseg, v katerem lahko blokira optimizacije, se lahko razlikuje, odvisno od uporabljene platforme in genske kode.
/// Programi se nikakor ne morejo zanašati na `black_box` za *pravilnost*.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Argument moramo na nek način "use" argumentirati, zato ga lahko na ciljih, ki ga podpirajo, običajno uporabimo v vrstici.
    // Razlaga LLVM o vrstnem sestavljanju je, da gre za črno škatlo.
    // To ni najboljša izvedba, saj verjetno optimizira več, kot si želimo, vendar je zaenkrat dovolj dobra.
    //
    //

    #[cfg(not(miri))] // To je le namig, zato je lepo preskočiti Miri.
    // VARNOST: vstavljeni sklop ni uporabljen.
    unsafe {
        // FIXME: `asm!` ni mogoče uporabiti, ker ne podpira MIPS in drugih arhitektur.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}