//! Libcore prelude
//!
//! Ta modul je namenjen uporabnikom libcore, ki se ne povezujejo tudi z libstd.
//! Ta modul je privzeto uvožen, če je `#![no_std]` uporabljen na enak način kot standardna knjižnica prelude.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Različica jedra prelude iz leta 2015.
///
/// Za več si oglejte [module-level documentation](self).
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Različica jedra prelude iz leta 2018.
///
/// Za več si oglejte [module-level documentation](self).
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Različica jedra prelude iz leta 2021.
///
/// Za več si oglejte [module-level documentation](self).
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Dodajte več stvari.
}