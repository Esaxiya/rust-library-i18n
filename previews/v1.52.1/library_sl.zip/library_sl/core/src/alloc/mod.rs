//! API-ji za dodeljevanje pomnilnika

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Napaka `AllocError` kaže na napako pri dodeljevanju, ki je lahko posledica izčrpavanja virov ali nečesa narobe pri kombiniranju danih vhodnih argumentov s tem razdelilnikom.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (to potrebujemo za impulz napake Portrait v smeri toka)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Izvedba `Allocator` lahko dodeli, raste, skrči in izloči poljubne bloke podatkov, opisane prek [`Layout`][].
///
/// `Allocator` je zasnovan za uporabo na ZST-jih, referencah ali pametnih kazalcih, ker razdeljevalnika, kot je `MyAlloc([u8; N])`, ni mogoče premakniti, ne da bi posodobili kazalce na dodeljeni pomnilnik.
///
/// Za razliko od [`GlobalAlloc`][] so v `Allocator` dovoljene dodelitve ničelnih velikosti.
/// Če osnovni razdeljevalec tega ne podpira (na primer jemalloc) ali vrne ničelni kazalec (na primer `libc::malloc`), mora to ujeti izvedba.
///
/// ### Trenutno dodeljen pomnilnik
///
/// Nekatere metode zahtevajo, da se pomnilniški blok *trenutno dodeli* prek razdeljevalca.To pomeni da:
///
/// * začetni naslov za ta pomnilniški blok so prej vrnili [`allocate`], [`grow`] ali [`shrink`] in
///
/// * pomnilniški blok ni bil naknadno sproščen, pri čemer se bloki sprostijo neposredno s posredovanjem v [`deallocate`] ali pa so bili spremenjeni s posredovanjem v [`grow`] ali [`shrink`], ki vrne `Ok`.
///
/// Če sta `grow` ali `shrink` vrnila `Err`, posredovani kazalec ostane veljaven.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Namestitev pomnilnika
///
/// Nekatere metode zahtevajo, da postavitev *prilega* pomnilniški blok.
/// Kaj pomeni za postavitev na "fit" pomnilniški blok pomeni (ali kar ustreza pomnilniškemu bloku do "fit" postavitev) je, da morajo izpolnjevati naslednji pogoji:
///
/// * Blok mora biti dodeljen z enako poravnavo kot [`layout.align()`] in
///
/// * Navedeni [`layout.size()`] mora spadati v obseg `min ..= max`, kjer:
///   - `min` je velikost postavitve, ki je bila nazadnje uporabljena za dodelitev bloka, in
///   - `max` je zadnja dejanska velikost, vrnjena iz [`allocate`], [`grow`] ali [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Pomnilniški bloki, vrnjeni iz razdeljevalca, morajo kazati na veljaven pomnilnik in ohraniti svojo veljavnost, dokler primerek in vsi njegovi kloni ne izpadejo,
///
/// * kloniranje ali premikanje razdeljevalca ne sme razveljaviti pomnilniških blokov, vrnjenih iz tega razdeljevalnika.Klonirani razdeljevalec se mora obnašati kot isti razdeljevalec in
///
/// * Kazalec na pomnilniški blok, ki je [*currently allocated*], se lahko posreduje kateri koli drugi metodi razdeljevalca.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Poskusi dodelitve bloka pomnilnika.
    ///
    /// Po uspehu vrne [`NonNull<[u8]>`][NonNull], ki izpolnjuje garancije za velikost in poravnavo `layout`.
    ///
    /// Vrnjeni blok ima lahko večjo velikost, kot jo določa `layout.size()`, in vsebina se lahko inicializira ali pa tudi ne.
    ///
    /// # Errors
    ///
    /// Vrnitev `Err` pomeni, da je bodisi pomnilnik izčrpan ali `layout` ne izpolnjuje omejitev velikosti ali poravnave razdeljevalca.
    ///
    /// Implementacije se spodbuja, da `Err` vrnejo na izčrpavanje pomnilnika, namesto da bi ga panizirali ali splavili, vendar to ni stroga zahteva.
    /// (Natančneje: zakonsko je * to Portrait implementirati nad osnovno izvorno knjižnico dodeljevanja, ki prekine izčrpavanje spomina.)
    ///
    /// Stranke, ki želijo prekiniti izračun kot odziv na napako pri dodeljevanju, spodbujajo, da pokličejo funkcijo [`handle_alloc_error`], namesto da neposredno prikličejo `panic!` ali podobno.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Obnaša se kot `allocate`, hkrati pa zagotavlja, da je vrnjeni pomnilnik ničelno inicializiran.
    ///
    /// # Errors
    ///
    /// Vrnitev `Err` pomeni, da je bodisi pomnilnik izčrpan ali `layout` ne izpolnjuje omejitev velikosti ali poravnave razdeljevalca.
    ///
    /// Implementacije se spodbuja, da `Err` vrnejo na izčrpavanje pomnilnika, namesto da bi ga panizirali ali splavili, vendar to ni stroga zahteva.
    /// (Natančneje: zakonsko je * to Portrait implementirati nad osnovno izvorno knjižnico dodeljevanja, ki prekine izčrpavanje spomina.)
    ///
    /// Stranke, ki želijo prekiniti izračun kot odziv na napako pri dodeljevanju, spodbujajo, da pokličejo funkcijo [`handle_alloc_error`], namesto da neposredno prikličejo `panic!` ali podobno.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // VARNOST: `alloc` vrne veljaven pomnilniški blok
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Razdeli pomnilnik, na katerega se sklicuje `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` mora označevati blok pomnilnika [*currently allocated*] prek tega razdeljevalca in
    /// * `layout` mora [*fit*] ta blok pomnilnika.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Poskusi razširitve pomnilniškega bloka.
    ///
    /// Vrne nov [`NonNull<[u8]>`][NonNull], ki vsebuje kazalnik in dejansko velikost dodeljenega pomnilnika.Kazalec je primeren za shranjevanje podatkov, opisanih v `new_layout`.
    /// Da bi to dosegel, lahko razdeljevalec razširi dodelitev, na katero se sklicuje `ptr`, tako da ustreza novi postavitvi.
    ///
    /// Če ta vrne `Ok`, je bilo lastništvo nad pomnilniškim blokom, na katerega se sklicuje `ptr`, preneseno na ta razdelilnik.
    /// Spomin je bil morda sproščen ali pa tudi ne, zato bi ga bilo treba šteti za neuporabnega, razen če je bil znova vrnjen klicatelju prek vrnjene vrednosti te metode.
    ///
    /// Če ta metoda vrne `Err`, lastništvo pomnilniškega bloka ni bilo preneseno na ta razdeljevalnik in vsebina pomnilniškega bloka je nespremenjena.
    ///
    /// # Safety
    ///
    /// * `ptr` mora označevati blok pomnilnika [*currently allocated*] prek tega razdelilnika.
    /// * `old_layout` mora [*fit*] ta blok pomnilnika (Argument `new_layout` mu ne ustreza.).
    /// * `new_layout.size()` mora biti večja ali enaka `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Vrne `Err`, če nova postavitev ne ustreza omejitvam razporeditve glede velikosti in poravnave razdeljevalca ali če rast ne uspe drugače.
    ///
    /// Implementacije se spodbuja, da `Err` vrnejo na izčrpavanje pomnilnika, namesto da bi ga panizirali ali splavili, vendar to ni stroga zahteva.
    /// (Natančneje: zakonsko je * to Portrait implementirati nad osnovno izvorno knjižnico dodeljevanja, ki prekine izčrpavanje spomina.)
    ///
    /// Stranke, ki želijo prekiniti izračun kot odziv na napako pri dodeljevanju, spodbujajo, da pokličejo funkcijo [`handle_alloc_error`], namesto da neposredno prikličejo `panic!` ali podobno.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // VARNOST: ker mora biti `new_layout.size()` večja ali enaka
        // `old_layout.size()`, tako stara kot nova dodelitev pomnilnika veljata za branje in pisanje za bajte `old_layout.size()`.
        // Ker tudi stara dodelitev še ni bila izločena, se `new_ptr` ne more prekrivati.
        // Tako je klic na `copy_nonoverlapping` varen.
        // Klicatelj mora spoštovati varnostno pogodbo za `dealloc`.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Obnaša se kot `grow`, hkrati pa zagotavlja, da se nova vsebina pred vrnitvijo nastavi na nič.
    ///
    /// Po uspešnem klicu v pomnilniški blok bo navedena naslednja vsebina
    /// `grow_zeroed`:
    ///   * Bajti `0..old_layout.size()` so ohranjeni iz prvotne dodelitve.
    ///   * Bajti `old_layout.size()..old_size` bodo bodisi ohranjeni bodisi ničlirani, odvisno od izvedbe razdeljevalca.
    ///   `old_size` se nanaša na velikost pomnilniškega bloka pred klicem `grow_zeroed`, ki je lahko večja od velikosti, ki je bila prvotno zahtevana, ko je bila dodeljena.
    ///   * Bajti `old_size..new_size` so ničlirani.`new_size` se nanaša na velikost pomnilniškega bloka, ki ga vrne klic `grow_zeroed`.
    ///
    /// # Safety
    ///
    /// * `ptr` mora označevati blok pomnilnika [*currently allocated*] prek tega razdelilnika.
    /// * `old_layout` mora [*fit*] ta blok pomnilnika (Argument `new_layout` mu ne ustreza.).
    /// * `new_layout.size()` mora biti večja ali enaka `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Vrne `Err`, če nova postavitev ne ustreza omejitvam razporeditve glede velikosti in poravnave razdeljevalca ali če rast ne uspe drugače.
    ///
    /// Implementacije se spodbuja, da `Err` vrnejo na izčrpavanje pomnilnika, namesto da bi ga panizirali ali splavili, vendar to ni stroga zahteva.
    /// (Natančneje: zakonsko je * to Portrait implementirati nad osnovno izvorno knjižnico dodeljevanja, ki prekine izčrpavanje spomina.)
    ///
    /// Stranke, ki želijo prekiniti izračun kot odziv na napako pri dodeljevanju, spodbujajo, da pokličejo funkcijo [`handle_alloc_error`], namesto da neposredno prikličejo `panic!` ali podobno.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // VARNOST: ker mora biti `new_layout.size()` večja ali enaka
        // `old_layout.size()`, tako stara kot nova dodelitev pomnilnika veljata za branje in pisanje za bajte `old_layout.size()`.
        // Ker tudi stara dodelitev še ni bila izločena, se `new_ptr` ne more prekrivati.
        // Tako je klic na `copy_nonoverlapping` varen.
        // Klicatelj mora spoštovati varnostno pogodbo za `dealloc`.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Poskusi krčenja pomnilniškega bloka.
    ///
    /// Vrne nov [`NonNull<[u8]>`][NonNull], ki vsebuje kazalnik in dejansko velikost dodeljenega pomnilnika.Kazalec je primeren za shranjevanje podatkov, opisanih v `new_layout`.
    /// Da bi to dosegel, lahko razdeljevalec skrči dodelitev, na katero se sklicuje `ptr`, da se prilega novi postavitvi.
    ///
    /// Če ta vrne `Ok`, je bilo lastništvo nad pomnilniškim blokom, na katerega se sklicuje `ptr`, preneseno na ta razdelilnik.
    /// Spomin je bil morda sproščen ali pa tudi ne, zato bi ga bilo treba šteti za neuporabnega, razen če je bil znova vrnjen klicatelju prek vrnjene vrednosti te metode.
    ///
    /// Če ta metoda vrne `Err`, lastništvo pomnilniškega bloka ni bilo preneseno na ta razdeljevalnik in vsebina pomnilniškega bloka je nespremenjena.
    ///
    /// # Safety
    ///
    /// * `ptr` mora označevati blok pomnilnika [*currently allocated*] prek tega razdelilnika.
    /// * `old_layout` mora [*fit*] ta blok pomnilnika (Argument `new_layout` mu ne ustreza.).
    /// * `new_layout.size()` mora biti manjša ali enaka `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Vrne `Err`, če nova postavitev ne ustreza omejitvam razporeditve glede velikosti in poravnave razdelilnika ali če krčenje sicer ne uspe.
    ///
    /// Implementacije se spodbuja, da `Err` vrnejo na izčrpavanje pomnilnika, namesto da bi ga panizirali ali splavili, vendar to ni stroga zahteva.
    /// (Natančneje: zakonsko je * to Portrait implementirati nad osnovno izvorno knjižnico dodeljevanja, ki prekine izčrpavanje spomina.)
    ///
    /// Stranke, ki želijo prekiniti izračun kot odziv na napako pri dodeljevanju, spodbujajo, da pokličejo funkcijo [`handle_alloc_error`], namesto da neposredno prikličejo `panic!` ali podobno.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // VARNOST: ker mora biti `new_layout.size()` nižji ali enak
        // `old_layout.size()`, tako stara kot nova dodelitev pomnilnika veljata za branje in pisanje za bajte `new_layout.size()`.
        // Ker tudi stara dodelitev še ni bila izločena, se `new_ptr` ne more prekrivati.
        // Tako je klic na `copy_nonoverlapping` varen.
        // Klicatelj mora spoštovati varnostno pogodbo za `dealloc`.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Ustvari adapter "by reference" za ta primerek `Allocator`.
    ///
    /// Vrnjeni adapter tudi izvaja `Allocator` in si ga bo preprosto izposodil.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}