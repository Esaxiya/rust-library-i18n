use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Medtem ko se ta funkcija uporablja na enem mestu in bi lahko njeno izvajanje poudarili, so prejšnji poskusi rustc počasneje:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Postavitev bloka pomnilnika.
///
/// Primer `Layout` opisuje določeno postavitev pomnilnika.
/// `Layout` zgradite kot vhod za razdeljevalnik.
///
/// Vse postavitve imajo povezano velikost in poravnavo moči dveh.
///
/// (Upoštevajte, da postavitve *ne* morajo imeti velikosti, ki ni enaka nič, čeprav `GlobalAlloc` zahteva, da so vse zahteve za pomnilnik ne nič.
/// Kličoči mora bodisi zagotoviti, da so izpolnjeni takšni pogoji, uporabiti posebne razdelilnike z ohlapnejšimi zahtevami ali uporabiti milejši vmesnik `Allocator`.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // velikost zahtevanega bloka pomnilnika, merjena v bajtih.
    size_: usize,

    // poravnava zahtevanega bloka pomnilnika, merjena v bajtih.
    // zagotavljamo, da je to vedno moč dveh, saj API-ji, kot je `posix_memalign`, to zahtevajo in je smiselna omejitev, ki jo moramo naložiti konstruktorjem postavitve.
    //
    //
    // (Vendar analogno ne zahtevamo `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Konstruira `Layout` iz danih `size` in `align` ali vrne `LayoutError`, če kateri od naslednjih pogojev ni izpolnjen:
    ///
    /// * `align` ne sme biti nič,
    ///
    /// * `align` mora biti moč dveh,
    ///
    /// * `size`, ko se zaokroži na najbližji večkratnik `align`, se ne sme prelivati (tj. zaokrožena vrednost mora biti manjša ali enaka `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (power-of-two pomeni poravnaj!=0.)

        // Zaokrožena velikost je:
        //   size_rounded_up=(velikost + poravnaj, 1)&! (poravnaj, 1);
        //
        // Od zgoraj vemo, da se poravna!=0.
        // Če se dodajanje (poravnaj, 1) ne prelije, bo zaokroževanje navzgor v redu.
        //
        // Nasprotno,&-maskiranje z! (Poravnaj, 1) bo odštevalo samo bitov nizkega reda.
        // Če torej pride do prelivanja z vsoto, maska&-mask ne more odšteti toliko, da razveljavi to prelivanje.
        //
        //
        // Zgoraj pomeni, da je preverjanje prevelikega seštevanja potrebno in zadostno.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // VARNOST: pogoji za `from_size_align_unchecked` so bili
        // preverjeno zgoraj.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Ustvari postavitev, tako da zaobide vsa preverjanja.
    ///
    /// # Safety
    ///
    /// Ta funkcija ni varna, saj ne preverja predpogojev iz [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // VARNOST: klicatelj mora zagotoviti, da je `align` večja od nič.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Najmanjša velikost v bajtih za pomnilniški blok te postavitve.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Najmanjša poravnava bajtov za pomnilniški blok te postavitve.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Konstruira `Layout`, primeren za zadrževanje vrednosti tipa `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // VARNOST: poravnava je zagotovljena z Rust z močjo dveh in
        // kombinacija velikosti + poravnave bo zagotovo ustrezala našemu naslovnemu prostoru.
        // Kot rezultat uporabite tukaj nepreverjeni konstruktor, da se izognete vstavljanju kode, ki panics, če ni dovolj dobro optimizirana.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Izdeluje postavitev z opisom zapisa, ki bi ga lahko uporabili za dodelitev podporne strukture za `T` (ki je lahko Portrait ali druga vrsta, kot je rezina).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // VARNOST: glejte utemeljitev v `new`, zakaj je pri tem uporabljena nevarna različica
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Izdeluje postavitev z opisom zapisa, ki bi ga lahko uporabili za dodelitev podporne strukture za `T` (ki je lahko Portrait ali druga vrsta, kot je rezina).
    ///
    /// # Safety
    ///
    /// To funkcijo lahko varno pokličete le, če izpolnjujejo naslednje pogoje:
    ///
    /// - Če je `T` `Sized`, je to funkcijo vedno varno poklicati.
    /// - Če je nerezerviran rep `T`:
    ///     - [slice], potem mora biti dolžina repa rezine incializirano celo število, velikost *celotne vrednosti*(dinamična dolžina repa + statično velika predpona) pa mora ustrezati `isize`.
    ///     - [trait object], potem mora kazalec vtable kazati na veljaven vtable za tip `T`, pridobljen s prisilo brez spreminjanja velikosti, velikost *celotne vrednosti*(dinamična dolžina repa + statično velika predpona) pa mora ustrezati `isize`.
    ///
    ///     - (unstable) [extern type], potem je to funkcijo vedno varno poklicati, vendar lahko panic ali drugače vrne napačno vrednost, saj postavitev zunanjega tipa ni znana.
    ///     To je enako vedenje kot [`Layout::for_value`] pri sklicevanju na rep zunanjega tipa.
    ///     - v nasprotnem primeru te funkcije ni dovoljeno poklicati.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // VARNOST: predpogoje teh funkcij posredujemo kličočemu
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // VARNOST: glejte utemeljitev v `new`, zakaj je pri tem uporabljena nevarna različica
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Ustvari `NonNull`, ki je viseč, vendar dobro poravnan za to postavitev.
    ///
    /// Upoštevajte, da lahko vrednost kazalca potencialno predstavlja veljaven kazalec, kar pomeni, da se ne sme uporabljati kot kontrolna vrednost "not yet initialized".
    /// Vrste, ki jih leno dodelijo, morajo slediti inicializaciji z drugimi sredstvi.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // VARNOST: zagotovljeno je, da poravnava ni nič
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Ustvari postavitev, ki opisuje zapis, ki lahko vsebuje vrednost enake postavitve kot `self`, vendar je tudi poravnana s poravnavo `align` (merjeno v bajtih).
    ///
    ///
    /// Če `self` že ustreza predpisani poravnavi, vrne `self`.
    ///
    /// Upoštevajte, da ta metoda celotni velikosti ne doda oblazinjenja, ne glede na to, ali ima vrnjena postavitev drugačno poravnavo.
    /// Z drugimi besedami, če ima `K` velikost 16, bo `K.align_to(32)`*še vedno* imel velikost 16.
    ///
    /// Vrne napako, če kombinacija `self.size()` in danega `align` krši pogoje, navedene v [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Vrne količino oblazinjenja, ki jo moramo vstaviti za `self`, da zagotovimo, da bo naslednji naslov ustrezal `align` (merjeno v bajtih).
    ///
    /// npr. če je `self.size()` 9, potem `self.padding_needed_for(4)` vrne 3, ker je to najmanjše število bajtov oblazinjenja, potrebno za pridobitev 4-poravnanega naslova (ob predpostavki, da se ustrezni pomnilniški blok začne pri 4-poravnanem naslovu).
    ///
    ///
    /// Vrnjena vrednost te funkcije nima pomena, če `align` ni moč dveh.
    ///
    /// Upoštevajte, da uporabnost vrnjene vrednosti zahteva, da je `align` manjši ali enak poravnavi začetnega naslova za celoten dodeljeni blok pomnilnika.Eden od načinov za izpolnitev te omejitve je zagotoviti `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Zaokrožena vrednost je:
        //   len_rounded_up=(len + poravnaj, 1)&! (poravnaj, 1);
        // in nato vrnemo razliko med oblazinjenjem: `len_rounded_up - len`.
        //
        // Modularno aritmetiko uporabljamo v:
        //
        // 1. zajamčeno je, da je poravnava> 0, zato je poravnava 1 vedno veljavna.
        //
        // 2.
        // `len + align - 1` lahko preseže največ za `align - 1`, zato bo&-maska z `!(align - 1)` zagotovila, da bo v primeru prelivanja `len_rounded_up` sam 0.
        //
        //    Tako vrnjeno oblazinjenje, ko se doda `len`, da 0, kar trivialno zadosti poravnavi `align`.
        //
        // (Seveda bi poskusi dodelitve blokov pomnilnika, katerih velikost in oblazinjenje se na zgoraj navedeni način prelivata, povzročili, da bi razdeljevalec vseeno povzročil napako.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Ustvari postavitev tako, da zaokroži velikost te postavitve na večkratnik poravnave postavitve.
    ///
    ///
    /// To je enakovredno dodajanju rezultata `padding_needed_for` trenutni velikosti postavitve.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // To se ne more preliti.Citiranje invariante Layout:
        // > `size`, ko je zaokroženo na najbližji večkratnik `align`,
        // > ne sme prelivati (tj. zaokrožena vrednost mora biti manjša od
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Ustvari postavitev, ki opisuje zapis za primerke `n` `self`, s primerno količino oblazinjenja med njimi, da se zagotovi, da vsak primerek dobi zahtevano velikost in poravnavo.
    /// Ob uspehu vrne `(k, offs)`, kjer je `k` postavitev matrike, `offs` pa razdalja med začetkom vsakega elementa v matriki.
    ///
    /// Pri aritmetičnem prelivanju vrne `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // To se ne more preliti.Citiranje invariante Layout:
        // > `size`, ko je zaokroženo na najbližji večkratnik `align`,
        // > ne sme prelivati (tj. zaokrožena vrednost mora biti manjša od
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // VARNOST: Za self.align je že znano, da velja in dodelitev velikosti je že bila
        // že podložen.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Ustvari postavitev, ki opisuje zapis za `self`, ki mu sledi `next`, vključno z vsemi potrebnimi oblazinjenji, da se zagotovi pravilno poravnava `next`, vendar *brez zapolnitve*.
    ///
    /// Če želite, da se ujema s postavitvijo C predstavitve `repr(C)`, morate poklicati `pad_to_align` po razširitvi postavitve z vsemi polji.
    /// (Privzeti postavitvi predstavitve Rust `repr(Rust)`, as it is unspecified.) ni mogoče ujemati
    ///
    /// Upoštevajte, da bo poravnava nastale postavitve največja kot pri `self` in `next`, da se zagotovi poravnava obeh delov.
    ///
    /// Vrne `Ok((k, offset))`, kjer je `k` postavitev združenega zapisa, `offset` pa relativno mesto v bajtih začetka `next`, vdelanega v združeni zapis (ob predpostavki, da se zapis sam začne z zamikom 0).
    ///
    ///
    /// Pri aritmetičnem prelivanju vrne `LayoutError`.
    ///
    /// # Examples
    ///
    /// Za izračun postavitve strukture `#[repr(C)]` in odmikov polj iz postavitev polj:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Ne pozabite zaključiti z `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // preizkusite, ali deluje
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Ustvari postavitev, ki opisuje zapis za primerke `n` `self`, brez oblazinjenja med posameznimi primerki.
    ///
    /// Upoštevajte, da za razliko od `repeat` `repeat_packed` ne zagotavlja, da bodo ponovljeni primerki `self` pravilno poravnani, tudi če je določen primerek `self` pravilno poravnan.
    /// Z drugimi besedami, če se postavitev, ki jo vrne `repeat_packed`, uporablja za dodelitev matrike, ni zagotovljeno, da bodo vsi elementi v matriki pravilno poravnani.
    ///
    /// Pri aritmetičnem prelivanju vrne `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Ustvari postavitev, ki opisuje zapis za `self`, čemur sledi `next`, brez dodatnega oblazinjenja med njima.
    /// Ker ni vstavljeno nobeno oblazinjenje, poravnava `next` ni pomembna in v nastalo postavitev sploh ni vključena *.
    ///
    ///
    /// Pri aritmetičnem prelivanju vrne `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Ustvari postavitev, ki opisuje zapis za `[T; n]`.
    ///
    /// Pri aritmetičnem prelivanju vrne `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Parametri, podani `Layout::from_size_align` ali drugemu konstruktorju `Layout`, ne izpolnjujejo svojih dokumentiranih omejitev.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (to potrebujemo za impulz napake Portrait v smeri toka)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}