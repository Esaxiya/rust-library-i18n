use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Dodeljevalec pomnilnika, ki ga je mogoče prek atributa `#[global_allocator]` registrirati kot privzeto standardno knjižnico.
///
/// Nekatere metode zahtevajo, da se pomnilniški blok *trenutno dodeli* prek razdeljevalca.To pomeni da:
///
/// * začetni naslov tega pomnilniškega bloka je bil predhodno vrnjen s prejšnjim klicem metodi dodeljevanja, kot sta `alloc` in
///
/// * pomnilniški blok ni bil kasneje sproščen, pri čemer se bloki sprostijo bodisi tako, da se posredujejo metodi sprostitve, kot je `dealloc`, bodisi če se posredujejo metodi ponovne dodelitve, ki vrne ničelni kazalec.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// `GlobalAlloc` Portrait je iz več razlogov `unsafe` Portrait, izvajalci pa morajo zagotoviti, da spoštujejo te pogodbe:
///
/// * Če se globalni razdeljevalci sprostijo, je nedefinirano vedenje.Ta omejitev se lahko odstrani v future, vendar trenutno lahko panic zaradi katere koli od teh funkcij privede do nevarnosti pomnilnika.
///
/// * `Layout` poizvedbe in izračuni na splošno morajo biti pravilni.Klicatelji tega Portrait se lahko zanašajo na pogodbe, opredeljene za posamezne metode, in izvajalci morajo zagotoviti, da takšne pogodbe ostanejo resnične.
///
/// * Ne morete se zanašati na dodelitve, ki se dejansko zgodijo, tudi če so v viru eksplicitne dodelitve kopice.
/// Optimizator lahko zazna neuporabljene dodelitve, ki jih lahko v celoti odpravi ali premakne v sklad in tako nikoli ne pokliče razdeljevalca.
/// Optimizator lahko nadalje domneva, da je dodelitev nezmotljiva, zato lahko koda, ki je prej odpovedala zaradi napak razdeljevalca, zdaj nenadoma deluje, ker je optimizator obšel potrebo po dodelitvi.
/// Natančneje, naslednji primer kode je neustrezen, ne glede na to, ali vaš razdeljevalnik po meri omogoča štetje, koliko dodelitev se je zgodilo.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Upoštevajte, da zgoraj omenjene optimizacije niso edina optimizacija, ki jo je mogoče uporabiti.Običajno se ne zanašate na dodelitve kopice, ki jih je mogoče odstraniti, ne da bi spremenili vedenje programa.
///   Ali se dodelitve zgodijo ali ne, ni del vedenja programa, tudi če bi ga bilo mogoče zaznati prek razdeljevalca, ki dodelitvam sledi s tiskanjem ali ima drugače neželene učinke.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Dodelite pomnilnik, kot je opisano v danem `layout`.
    ///
    /// Vrne kazalec na novo dodeljeni pomnilnik ali nulo, ki označuje neuspešno dodelitev.
    ///
    /// # Safety
    ///
    /// Ta funkcija ni varna, ker lahko pride do nedefiniranega vedenja, če klicatelj ne zagotovi, da `layout` nima nič.
    ///
    /// (Podštevilke razširitev lahko nudijo natančnejše meje vedenja, npr. Zagotavljajo naslov stražnika ali ničelni kazalec kot odgovor na zahtevo za dodelitev ničle.)
    ///
    /// Dodeljeni blok pomnilnika se lahko inicializira ali pa tudi ne.
    ///
    /// # Errors
    ///
    /// Vrnitev ničelnega kazalca pomeni, da je bodisi pomnilnik izčrpan ali `layout` ne ustreza omejitvam velikosti ali poravnave tega razdeljevalca.
    ///
    /// Implementacije se spodbuja, da pri izčrpanosti pomnilnika vrnejo nič kot izpad, vendar to ni stroga zahteva.
    /// (Natančneje: zakonsko je * to Portrait implementirati nad osnovno izvorno knjižnico dodeljevanja, ki prekine izčrpavanje spomina.)
    ///
    /// Stranke, ki želijo prekiniti izračun kot odziv na napako pri dodeljevanju, spodbujajo, da pokličejo funkcijo [`handle_alloc_error`], namesto da neposredno prikličejo `panic!` ali podobno.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Premestite blok pomnilnika na danem kazalcu `ptr` z danim `layout`.
    ///
    /// # Safety
    ///
    /// Ta funkcija ni varna, ker lahko pride do nedefiniranega vedenja, če klicatelj ne zagotovi vsega naslednjega:
    ///
    ///
    /// * `ptr` mora označevati blok pomnilnika, ki je trenutno dodeljen prek tega razdeljevalca,
    ///
    /// * `layout` mora biti enaka postavitvi, ki je bila uporabljena za dodelitev tega bloka pomnilnika.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Obnaša se kot `alloc`, hkrati pa zagotavlja, da je vsebina pred vrnitvijo nastavljena na nič.
    ///
    /// # Safety
    ///
    /// Ta funkcija zaradi istih razlogov kot `alloc` ni varna.
    /// Dodeljeni blok pomnilnika pa je zagotovo inicializiran.
    ///
    /// # Errors
    ///
    /// Vrnitev ničelnega kazalca pomeni, da je bodisi pomnilnik izčrpan ali `layout` ne izpolnjuje omejitev velikosti ali poravnave razdeljevalca, tako kot v `alloc`.
    ///
    /// Stranke, ki želijo prekiniti izračun kot odziv na napako pri dodeljevanju, spodbujajo, da pokličejo funkcijo [`handle_alloc_error`], namesto da neposredno prikličejo `panic!` ali podobno.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `alloc`.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // VARNOST: ko je dodelitev uspela, je regija od `ptr`
            // velikosti `size` je zagotovljeno, da velja za zapise.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Skrčite ali razširite blok pomnilnika na dani `new_size`.
    /// Blok opisujejo dani kazalci `ptr` in `layout`.
    ///
    /// Če ta vrne ničelni kazalec, je bilo lastništvo nad pomnilniškim blokom, na katerega se sklicuje `ptr`, preneseno na ta razdeljevalec.
    /// Pomnilnik je bil morda odstranjen ali pa tudi ne, zato bi ga bilo treba šteti za neuporabnega (razen če ga seveda znova vrnemo kličočemu prek povratne vrednosti te metode).
    /// Novi pomnilniški blok je dodeljen z `layout`, vendar z `size`, posodobljenim na `new_size`.
    /// To novo postavitev je treba uporabiti pri sprostitvi novega pomnilniškega bloka z `dealloc`.
    /// Obseg `0..min(layout.size(), new_size) `novega pomnilniškega bloka ima enake vrednosti kot prvotni blok.
    ///
    /// Če ta metoda vrne nič, lastništvo pomnilniškega bloka ni bilo preneseno na ta razdeljevalnik in vsebina pomnilniškega bloka je nespremenjena.
    ///
    /// # Safety
    ///
    /// Ta funkcija ni varna, ker lahko pride do nedefiniranega vedenja, če klicatelj ne zagotovi vsega naslednjega:
    ///
    /// * `ptr` mora biti trenutno dodeljena prek tega razdeljevalca,
    ///
    /// * `layout` mora biti enaka postavitvi, ki je bila uporabljena za dodelitev tega bloka pomnilnika,
    ///
    /// * `new_size` mora biti večja od nič.
    ///
    /// * `new_size`, če se zaokroži na najbližji večkratnik `layout.align()`, se ne sme prelivati (tj. zaokrožena vrednost mora biti manjša od `usize::MAX`).
    ///
    /// (Podštevilke razširitev lahko nudijo natančnejše meje vedenja, npr. Zagotavljajo naslov stražnika ali ničelni kazalec kot odgovor na zahtevo za dodelitev ničle.)
    ///
    /// # Errors
    ///
    /// Vrne nič, če nova postavitev ne ustreza omejitvam velikosti in poravnave razdeljevalca ali če prerazporeditev drugače ne uspe.
    ///
    /// Implementacije se spodbuja, da pri izčrpanosti spomina vrnejo nič kot panika ali splav, vendar to ni stroga zahteva.
    /// (Natančneje: zakonsko je * to Portrait implementirati nad osnovno izvorno knjižnico dodeljevanja, ki prekine izčrpavanje spomina.)
    ///
    /// Stranke, ki želijo prekiniti izračun kot odziv na napako pri prerazporeditvi, spodbujajo, da pokličejo funkcijo [`handle_alloc_error`] in ne neposredno prikličejo `panic!` ali podobno.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // VARNOST: klicatelj mora zagotoviti, da `new_size` ne bo prelival.
        // `layout.align()` prihaja iz `Layout` in je tako zagotovljeno veljavno.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // VARNOST: klicatelj mora zagotoviti, da je `new_layout` večja od nič.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // VARNOST: predhodno dodeljeni blok ne more prekrivati novo dodeljenega bloka.
            // Klicatelj mora spoštovati varnostno pogodbo za `dealloc`.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}