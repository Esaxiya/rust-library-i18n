#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// `RawWaker` omogoča, da izvajalec izvršitelja opravila ustvari [`Waker`], ki zagotavlja prilagojeno vedenje budnosti.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Sestavljen je iz podatkovnega kazalca in [virtual function pointer table (vtable)][vtable], ki prilagodi vedenje `RawWaker`.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// Podatkovni kazalnik, ki se lahko uporablja za shranjevanje poljubnih podatkov, kot zahteva izvršitelj.
    /// To je lahko npr
    /// kazalec, izbrisan s tipom, na `Arc`, ki je povezan z nalogo.
    /// Vrednost tega polja se posreduje vsem funkcijam, ki so del vtable kot prvi parameter.
    ///
    data: *const (),
    /// Tabela kazalcev navidezne funkcije, ki prilagodi obnašanje tega budnika.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Ustvari nov `RawWaker` iz priloženega kazalca `data` in `vtable`.
    ///
    /// Kazalec `data` se lahko uporablja za shranjevanje poljubnih podatkov, kot zahteva izvršitelj.To je lahko npr
    /// kazalec, izbrisan s tipom, na `Arc`, ki je povezan z nalogo.
    /// Vrednost tega kazalca bo posredovana vsem funkcijam, ki so del `vtable` kot prvi parameter.
    ///
    /// `vtable` prilagodi vedenje `Waker`, ki je ustvarjen iz `RawWaker`.
    /// Za vsako operacijo na `Waker` bo poklicana povezana funkcija v `vtable` osnovnega `RawWaker`.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// Tabela kazalcev navidezne funkcije (vtable), ki določa obnašanje [`RawWaker`].
///
/// Kazalec, ki se prenese na vse funkcije znotraj vtable, je kazalec `data` iz priloženega predmeta [`RawWaker`].
///
/// Funkcije znotraj te strukture naj bi bile poklicane samo na kazalcu `data` pravilno zgrajenega predmeta [`RawWaker`] znotraj izvedbe [`RawWaker`].
/// Poklic ene od funkcij, ki jih vsebuje, s katerim koli drugim kazalcem `data` bo povzročil nedefinirano vedenje.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Ta funkcija bo poklicana, ko bo kloniran [`RawWaker`], npr. Ko bo kloniran [`Waker`], v katerem je shranjen [`RawWaker`].
    ///
    /// Izvedba te funkcije mora obdržati vse vire, ki so potrebni za ta dodatni primerek [`RawWaker`] in s tem povezano nalogo.
    /// Klic `wake` na nastalem [`RawWaker`] bi moral povzročiti prebujanje iste naloge, ki bi jo prebudil prvotni [`RawWaker`].
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Ta funkcija bo poklicana, ko bo na [`Waker`] poklican `wake`.
    /// Prebuditi mora nalogo, povezano s tem [`RawWaker`].
    ///
    /// Izvedba te funkcije mora zagotoviti, da sprostite vse vire, povezane s tem primerkom [`RawWaker`] in s tem povezano nalogo.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Ta funkcija bo poklicana, ko bo na [`Waker`] poklican `wake_by_ref`.
    /// Prebuditi mora nalogo, povezano s tem [`RawWaker`].
    ///
    /// Ta funkcija je podobna `wake`, vendar ne sme porabiti priloženega podatkovnega kazalca.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Ta funkcija se pokliče, ko [`RawWaker`] pade.
    ///
    /// Izvedba te funkcije mora zagotoviti, da sprostite vse vire, povezane s tem primerkom [`RawWaker`] in s tem povezano nalogo.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Ustvari nov `RawWakerVTable` iz ponujenih funkcij `clone`, `wake`, `wake_by_ref` in `drop`.
    ///
    /// # `clone`
    ///
    /// Ta funkcija bo poklicana, ko bo kloniran [`RawWaker`], npr. Ko bo kloniran [`Waker`], v katerem je shranjen [`RawWaker`].
    ///
    /// Izvedba te funkcije mora obdržati vse vire, ki so potrebni za ta dodatni primerek [`RawWaker`] in s tem povezano nalogo.
    /// Klic `wake` na nastalem [`RawWaker`] bi moral povzročiti prebujanje iste naloge, ki bi jo prebudil prvotni [`RawWaker`].
    ///
    /// # `wake`
    ///
    /// Ta funkcija bo poklicana, ko bo na [`Waker`] poklican `wake`.
    /// Prebuditi mora nalogo, povezano s tem [`RawWaker`].
    ///
    /// Izvedba te funkcije mora zagotoviti, da sprostite vse vire, povezane s tem primerkom [`RawWaker`] in s tem povezano nalogo.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Ta funkcija bo poklicana, ko bo na [`Waker`] poklican `wake_by_ref`.
    /// Prebuditi mora nalogo, povezano s tem [`RawWaker`].
    ///
    /// Ta funkcija je podobna `wake`, vendar ne sme porabiti priloženega podatkovnega kazalca.
    ///
    /// # `drop`
    ///
    /// Ta funkcija se pokliče, ko [`RawWaker`] pade.
    ///
    /// Izvedba te funkcije mora zagotoviti, da sprostite vse vire, povezane s tem primerkom [`RawWaker`] in s tem povezano nalogo.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// `Context` asinhrone naloge.
///
/// Trenutno `Context` služi le za dostop do `&Waker`, ki se lahko uporablja za prebujanje trenutne naloge.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Prepričajte se, da smo proti spremembam variance zaščiteni pred future, tako da določimo, da je življenjska doba nespremenljiva (življenjska doba argumenta in položaja je kontravarianta, življenjska doba vrnjenega položaja pa kovarijantna).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Iz `&Waker` ustvarite nov `Context`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Vrne sklic na `Waker` za trenutno nalogo.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// `Waker` je ročaj za prebujanje opravila, tako da obvesti izvršitelja, da je pripravljen za zagon.
///
/// Ta ročaj enkapsulira primerek [`RawWaker`], ki definira vedenje budilke, specifično za izvršitelja.
///
///
/// Izvaja [`Clone`], [`Send`] in [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Prebudite nalogo, povezano s tem `Waker`.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Dejanski klic prebujanja se prek klica navidezne funkcije prenese na izvedbo, ki jo določi izvajalec.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Ne kličite `drop`-waker bo porabil `wake`.
        crate::mem::forget(self);

        // VARNOST: To je varno, ker je `Waker::from_raw` edini način
        // za inicializacijo `wake` in `data`, ki od uporabnika zahteva, da potrdi, da je pogodba `RawWaker` potrjena.
        //
        unsafe { (wake)(data) };
    }

    /// Zbudite nalogo, povezano s tem `Waker`, ne da bi porabili `Waker`.
    ///
    /// To je podobno kot `wake`, vendar je lahko nekoliko manj učinkovito, če je na voljo `Waker` v lasti.
    /// Ta metoda bi morala biti prednostna klicanju `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Dejanski klic prebujanja se prek klica navidezne funkcije prenese na izvedbo, ki jo določi izvajalec.
        //

        // VARNOST: glej `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Vrne `true`, če sta ta `Waker` in druga `Waker` prebudila isto nalogo.
    ///
    /// Ta funkcija deluje po najboljših močeh in lahko vrne false, tudi če bi Wakerji prebudili isto nalogo.
    /// Če pa ta funkcija vrne `true`, je zagotovljeno, da bodo Wakerji prebudili isto nalogo.
    ///
    /// Ta funkcija se uporablja predvsem za optimizacijo.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Ustvari nov `Waker` iz [`RawWaker`].
    ///
    /// Obnašanje vrnjenega `Waker` ni opredeljeno, če pogodba, opredeljena v dokumentaciji ["RawWaker`] in ["RawWakerVTable`], ni potrjena.
    ///
    /// Zato ta metoda ni varna.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // VARNOST: To je varno, ker je `Waker::from_raw` edini način
            // za inicializacijo `clone` in `data`, ki od uporabnika zahteva, da potrdi, da je pogodba [`RawWaker`] potrjena.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // VARNOST: To je varno, ker je `Waker::from_raw` edini način
        // za inicializacijo `drop` in `data`, ki od uporabnika zahteva, da potrdi, da je pogodba `RawWaker` potrjena.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}