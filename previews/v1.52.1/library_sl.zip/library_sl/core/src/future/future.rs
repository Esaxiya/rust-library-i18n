#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// future predstavlja asinhroni izračun.
///
/// future je vrednost, ki morda še ni končala računalništva.
/// Ta vrsta "asynchronous value" omogoča, da nit še naprej opravlja koristno delo, medtem ko čaka, da vrednost postane na voljo.
///
///
/// # Metoda `poll`
///
/// Osrednja metoda future, `poll`,*poskuša* rešiti future v končno vrednost.
/// Ta metoda ne blokira, če vrednost ni pripravljena.
/// Namesto tega je predvideno, da se trenutna naloga prebudi, ko bo mogoče z nadaljnjim `anketo` nadaljevati.
/// `context`, ki se prenaša na metodo `poll`, lahko zagotovi [`Waker`], ki je ročaj za prebujanje trenutne naloge.
///
/// Ko uporabljate future, običajno ne boste poklicali `poll` neposredno, temveč `.await` vrednosti.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Vrsta vrednosti, ustvarjene ob zaključku.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Poskusite razrešiti future na končno vrednost in registrirajte trenutno nalogo za prebujanje, če vrednost še ni na voljo.
    ///
    /// # Vrnjena vrednost
    ///
    /// Ta funkcija vrne:
    ///
    /// - [`Poll::Pending`] če future še ni pripravljen
    /// - [`Poll::Ready(val)`] z rezultatom `val` tega future, če se je uspešno končal.
    ///
    /// Ko je future končan, ga stranke ne smejo več `poll`.
    ///
    /// Ko future še ni pripravljen, `poll` vrne `Poll::Pending` in shrani klon [`Waker`], kopiran iz trenutnega [`Context`].
    /// Ta [`Waker`] se nato zbudi, ko lahko future napreduje.
    /// Na primer, future, ki čaka, da vtičnica postane berljiva, pokliče `.clone()` na [`Waker`] in jo shrani.
    /// Ko drugam prispe signal, ki kaže, da je vtičnica berljiva, se pokliče [`Waker::wake`] in naloga vtičnice future se prebudi.
    /// Ko se naloga prebudi, mora znova poskusiti `poll` z0future0Z, kar lahko povzroči končno vrednost ali pa tudi ne.
    ///
    /// Upoštevajte, da bi bilo treba pri večkratnih klicih na `poll` prebuditi le [`Waker`] iz [`Context`], ki je bil poslan na zadnji klic.
    ///
    /// # Značilnosti izvajanja
    ///
    /// Samo Futures so *inertni*;za napredek jih je treba *aktivno*`anketirati ', kar pomeni, da mora vsakič, ko se trenutna naloga prebudi, aktivno ponovno` anketirati` do futures, ki jo še vedno zanima.
    ///
    /// Funkcija `poll` se ne prikliče večkrat v tesni zanki-namesto tega jo je treba poklicati šele, ko future pokaže, da je pripravljena napredovati (s klicem `wake()`).
    /// Če ste seznanjeni s sistemskimi klici `poll(2)` ali `select(2)` na Unix, je treba omeniti, da futures običajno nima * enakih težav kot "all wakeups must poll all events";so bolj podobni `epoll(4)`.
    ///
    /// Izvedba `poll` si mora prizadevati za hitro vrnitev in ne sme blokirati.Vrnitev hitro prepreči nepotrebno zamašitev niti ali zank dogodkov.
    /// Če je vnaprej znano, da lahko klic `poll` traja nekaj časa, je treba delo razporediti v področje niti (ali kaj podobnega), da se `poll` hitro vrne.
    ///
    /// # Panics
    ///
    /// Ko je future končan (vrnil `Ready` iz `poll`), lahko ponovno klicanje metode `poll` panic blokira za vedno ali povzroči druge vrste težav;`Future` Portrait ne postavlja nobenih zahtev glede učinkov takega klica.
    /// Ker pa metoda `poll` ni označena z `unsafe`, veljajo običajna pravila Rust: klici ne smejo nikoli povzročiti nedefiniranega vedenja (poškodbe pomnilnika, nepravilna uporaba funkcij `unsafe` ali podobno), ne glede na stanje future.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}