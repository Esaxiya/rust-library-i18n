//! Različni algoritmi iz prispevka.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Število pomembnih in bitov v Fp
const P: u32 = 64;

// Preprosto shranimo najboljši približek za eksponente * *, zato lahko spremenljivko "h" in s tem povezane pogoje izpustimo.
// To zamenja zmogljivost za nekaj kilobajtov prostora.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// V večini arhitektur imajo operacije s plavajočo vejico eksplicitno bitno bitno velikost, zato se natančnost izračuna izračuna na posamezno operacijo.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Na x86 se FPU x87 uporablja za plavajoče operacije, če razširitve SSE/SSE2 niso na voljo.
// x87 FPU privzeto deluje z natančnostjo 80 bitov, kar pomeni, da se operacije zaokrožijo na 80 bitov, kar povzroči dvojno zaokroževanje, ko so vrednosti na koncu predstavljene kot
//
// 32/64 bitne float vrednosti.Da bi to premagali, lahko nadzorno besedo FPU nastavimo tako, da se izračuni izvajajo v želeni natančnosti.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Struktura, ki se uporablja za ohranitev prvotne vrednosti nadzorne besede FPU, tako da jo je mogoče obnoviti, ko struktura pade.
    ///
    ///
    /// x87 FPU je 16-bitni register, katerega polja so naslednja:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Dokumentacija za vsa polja je na voljo v priročniku za razvijalce programske opreme IA-32 Architectures (zvezek 1).
    ///
    /// Edino polje, ki je pomembno za naslednjo kodo, je PC, Precision Control.
    /// To polje določa natančnost operacij, ki jih izvaja FPU.
    /// Nastavite ga lahko na:
    ///  - 0b00, enojna natančnost, tj. 32-bitni
    ///  - 0b10, dvojna natančnost, tj., 64-bitni
    ///  - 0b11, dvojno razširjena natančnost, tj. 80 bitov (privzeto stanje) Vrednost 0b01 je rezervirana in je ne bi smeli uporabljati.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // VARNOST: Navodilo `fldcw` je bilo revidirano, da lahko pravilno deluje z njim
        // kateri koli `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Za podporo LLVM 8 in LLVM 9 uporabljamo sintakso ATT.
                options(att_syntax, nostack),
            )
        }
    }

    /// Polje natančnosti FPU nastavi na `T` in vrne `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Izračunajte vrednost za polje Precision Control, ki ustreza `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 bitov
            8 => 0x0200, // 64 bitov
            _ => 0x0300, // privzeto, 80 bitov
        };

        // Pridobite prvotno vrednost kontrolne besede, da jo obnovite pozneje, ko se struktura `FPUControlWord` spusti VARNOST: navodilo `fnstcw` je bilo revidirano, da lahko pravilno deluje s katerim koli `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Za podporo LLVM 8 in LLVM 9 uporabljamo sintakso ATT.
                options(att_syntax, nostack),
            )
        }

        // Nastavite kontrolno besedo na želeno natančnost.
        // To dosežemo tako, da prikrijemo staro natančnost (bit 8 in 9, 0x300) in jo nadomestimo z zgoraj izračunano zastavico natančnosti.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Hitra pot Bellerophona z uporabo celih števil in plovcev v velikosti stroja.
///
/// Ta se izvleče v ločeno funkcijo, tako da jo je mogoče poskusiti pred izdelavo bignuma.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Na koncu natančno primerjamo vrednost MAX_SIG, to je le hitra, poceni zavrnitev (in tudi preostalo kodo osvobaja skrbi zaradi podtoka).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Hitra pot je bistveno odvisna od aritmetike, ki je zaokrožena na pravilno število bitov brez vmesnega zaokroževanja.
    // Na x86 (brez SSE ali SSE2) je treba spremeniti natančnost sklada F01 x87, tako da se neposredno zaokroži na bit 64/32.
    // Funkcija `set_precision` skrbi za nastavitev natančnosti na arhitekturah, ki jo zahtevajo, tako da spremeni globalno stanje (kot je kontrolna beseda FPU x87).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Ohišja e <0 ni mogoče zložiti v drugo branch.
    // Negativne moči imajo za posledico ponavljajoč se delni del v binarni obliki, ki je zaokrožen, kar povzroči resnične (in občasno precej pomembne!) Napake v končnem rezultatu.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algoritem Bellerophon je trivialna koda, utemeljena z netrivialno numerično analizo.
///
/// Zaokroži "f" na plovec s 64-bitnim znakom in ga pomnoži z najboljšim približkom `10^e` (v isti obliki s plavajočo vejico).To je pogosto dovolj za pravilen rezultat.
/// Ko pa je rezultat blizu polovice med dvema sosednjima plavutoma (ordinary), napaka sestavljenega zaokroževanja pri pomnožitvi dveh približkov pomeni, da je rezultat morda izklopljen za nekaj bitov.
/// Ko se to zgodi, iterativni algoritem R stvari popravi.
///
/// Ročno valovit "close to halfway" je natančen s pomočjo numerične analize v prispevku.
/// Po besedah Clingerja:
///
/// > Naklon, izražen v enotah najmanj pomembnega bita, je vključujoča meja napake
/// > akumulirane med izračunom približka f * 10 ^ e s plavajočo vejico.(Slop je
/// > ni meja resnične napake, ampak omejuje razliko med približkom z in
/// > najboljši možni približek, ki uporablja p bitov pomena in.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Primeri abs(e) <log5(2^N) so v fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Ali je nagib dovolj velik, da lahko pri zaokroževanju na n bitov pride do spremembe?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Ponavljajoči se algoritem, ki izboljša približevanje `f * 10^e` s plavajočo vejico.
///
/// Vsaka ponovitev pripelje eno enoto na zadnjem mestu, kar seveda strašno dolgo traja, da se približa, če je `z0` celo blago izklopljen.
/// Na srečo se začetni približek pri uporabi kot nadomestni Bellerophon izključi z največ enim ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Poiščite pozitivna cela števila `x`, `y`, tako da je `x / y` natančno `(f *10^e) / (m* 2^k)`.
        // S tem se ne samo izognemo obravnavanju znakov `e` in `k`, temveč tudi odpravimo moč dveh skupnih `10^e` in `2^k`, da bi številke zmanjšale.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // To je napisano nekoliko nerodno, ker naši bignumi ne podpirajo negativnih števil, zato uporabljamo podatke absolutne vrednosti + znaka.
        // Množenje z m_digits ne more preseči.
        // Če sta `x` ali `y` dovolj velika, da moramo skrbeti za prelivanje, so tudi dovolj veliki, da je `make_ratio` znižal delež za faktor 2 ^ 64 ali več.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Ne potrebujete več x, prihranite clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Še vedno potrebujete y, naredite kopijo.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Glede na `x = f` in `y = m`, kjer `f` predstavljata vhodne decimalne številke kot običajno, `m` pa je pomen in približek s plavajočo vejico, naj bo razmerje `x / y` enako `(f *10^e) / (m* 2^k)`, po možnosti zmanjšano za moč dveh skupnih.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, le da ulomek zmanjšamo za nekaj moči dveh.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m To se ne more preliti, ker zahteva pozitivne `e` in negativne `k`, kar se lahko zgodi le za vrednosti, ki so zelo blizu 1, kar pomeni, da bosta `e` in `k` razmeroma majhna.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Tudi to ne more preiti, glej zgoraj.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), spet zmanjšanje za skupno moč dveh.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Konceptualno je algoritem M najpreprostejši način pretvorbe decimalnega mesta v float.
///
/// Oblikujemo razmerje, ki je enako `f * 10^e`, nato pa vržemo v moči dva, dokler ne dobimo veljavnega float pomena in.
/// Binarni eksponent `k` je število, kako smo pomnožili števec ali imenovalec z dva, tj., Kadar je `f *10^e` enak `(u / v)* 2^k`.
/// Ko ugotovimo pomembnost, moramo zaokrožiti le tako, da pregledamo preostanek delitve, kar naredimo v pomožnih funkcijah spodaj.
///
///
/// Ta algoritem je super počasen, tudi z optimizacijo, opisano v `quick_start()`.
/// Vendar je to najpreprostejši algoritem za prilagajanje rezultatom prelivanja, podtoka in subnormalnosti.
/// Ta izvedba prevzame, ko sta Bellerophon in Algorithm R preobremenjena.
/// Zaznavanje podtoka in prelivanja je enostavno: razmerje še vedno ni pomembno v obsegu, kljub temu pa je dosežen eksponent minimum/maximum.
/// V primeru prelivanja preprosto vrnemo neskončnost.
///
/// Obravnavanje podtoka in subnormalov je bolj zapleteno.
/// Velika težava je, da je z najmanjšim eksponentom razmerje morda še vedno preveliko za pomen.
/// Za podrobnosti glejte underflow().
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME možna optimizacija: posplošite big_to_fp, da bomo tukaj lahko naredili enakovredno fp_to_float(big_to_fp(u)), le brez dvojnega zaokroževanja.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Moramo se ustaviti pri najmanjšem eksponentu, če počakamo do `k < T::MIN_EXP_INT`, bi bili dvakrat izključeni.
            // Na žalost to pomeni, da moramo uporabiti običajna števila normalnih števil z najmanjšim eksponentom.
            // FIXME najde bolj elegantno formulacijo, vendar zaženite test `tiny-pow10` in se prepričajte, da je dejansko pravi!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Preskoči večino ponovitev algoritma M s preverjanjem bitne dolžine.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Bitna dolžina je ocena osnovnega logaritma dva in log(u / v) = log(u), log(v).
    // Ocena je izključena za največ 1, vendar je vedno podcenjena, zato je napaka na log(u) in log(v) istega znaka in se izbriše (če sta obe veliki).
    // Zato je napaka tudi za log(u / v) največ ena.
    // Ciljno razmerje je tisto, pri katerem je u/v v območju dosega.Tako je naš pogojni pogoj log2(u / v), ki je pomemben in bit, plus/minus eden.
    // FIXME Če pogledamo drugi bit, bi lahko izboljšali oceno in se izognili še nekaterim delitvam.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Podvodno ali subnormalno.Prepustite glavni funkciji.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Prelivanje.Prepustite glavni funkciji.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Razmerje ni pomemben obseg in z najmanjšim eksponentom, zato moramo zaokrožiti odvečne bite in ustrezno prilagoditi eksponent.
    // Realna vrednost je zdaj videti takole:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(zastopa ga rem)
    //
    // Ko so zaokroženi bitji torej= 0.5 ULP, se zaokroževanje odločijo sami.
    // Ko so enaki in ostanek ni nič, je treba vrednost še vedno zaokrožiti navzgor.
    // Šele ko so zaokroženi bitji 1/2, preostanek pa nič, imamo situacijo na pol do enakomernosti.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Običajno okroglo do celo, zamegljeno, ker je treba zaokrožiti glede na preostanek delitve.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}