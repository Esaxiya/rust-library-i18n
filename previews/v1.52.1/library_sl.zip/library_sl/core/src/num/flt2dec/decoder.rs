//! Dekodira vrednost s plavajočo vejico v posamezne dele in obsege napak.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Dekodirana nepodpisana končna vrednost, tako da:
///
/// - Prvotna vrednost je enaka `mant * 2^exp`.
///
/// - Vsaka številka od `(mant - minus)*2^exp` do `(mant + plus)* 2^exp` se bo zaokrožila na prvotno vrednost.
/// Razpon je vključen samo, če je `inclusive` `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Prišteta mantisa.
    pub mant: u64,
    /// Spodnji obseg napak.
    pub minus: u64,
    /// Zgornje območje napak.
    pub plus: u64,
    /// Skupni eksponent v osnovi 2.
    pub exp: i16,
    /// True, če je obseg napak vključen.
    ///
    /// V IEEE 754 to drži, ko je bila prvotna mantisa sodo.
    pub inclusive: bool,
}

/// Dekodirana nepodpisana vrednost.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Neskončnosti, bodisi pozitivne bodisi negativne.
    Infinite,
    /// Nič, bodisi pozitivna bodisi negativna.
    Zero,
    /// Končna števila z nadaljnjim dekodiranim poljem.
    Finite(Decoded),
}

/// Vrsta s plavajočo vejico, ki jo je mogoče "dekodirati".
pub trait DecodableFloat: RawFloat + Copy {
    /// Najmanjša pozitivna normalizirana vrednost.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Vrne znak (true, če je negativen) in vrednost `FullDecoded` iz dane številke s plavajočo vejico.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // sosedje: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode vedno ohrani eksponent, zato je mantisa skalirana za subnormale.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // sosedje: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // kjer je maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // sosedje: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}