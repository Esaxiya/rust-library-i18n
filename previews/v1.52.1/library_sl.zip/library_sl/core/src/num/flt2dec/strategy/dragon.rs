//! Skoraj neposreden (a nekoliko optimiziran) prevod slike Rust slike 3 v "Hitro in natančno tiskanje števil s plavajočo vejico" [^ 1].
//!
//!
//! [^1]: Burger, RG in Dybvig, RK 1996. Tiskanje števil s plavajočo vejico
//!   hitro in natančno.SIGPLAN Ne.31, 5 (maj 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// vnaprej izračunana polja `Digit`ov za 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// uporaben samo, kadar je `x < 16 * scale`;`scaleN` mora biti `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Najkrajši izvedbeni način za Dragon.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // znano je, da je številka `v` za formatiranje:
    // - enako `mant * 2^exp`;
    // - pred `(mant - 2 *minus)* 2^exp` v prvotni vrsti;in
    // - čemur sledi `(mant + 2 *plus)* 2^exp` v prvotni vrsti.
    //
    // očitno `minus` in `plus` ne moreta biti nič.(za neskončnosti uporabljamo vrednosti zunaj dosega.) predpostavljamo tudi, da je ustvarjena vsaj ena številka, tj. tudi `mant` ne more biti nič.
    //
    // to tudi pomeni, da se bo katero koli število med `low = (mant - minus)*2^exp` in `high = (mant + plus)* 2^exp` preslikalo na to natančno število s plavajočo vejico, pri čemer bodo vključene meje, ko je bila prvotna mantisa sodo (tj. `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` je `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // ocenite `k_0` iz originalnih vhodov, ki ustrezajo `10^(k_0-1) < high <= 10^(k_0+1)`.
    // tesno vezani `k`, ki ustreza `10^(k-1) < high <= 10^k`, se izračuna pozneje.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // pretvorite `{mant, plus, minus} * 2^exp` v delno obliko, tako da:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // delite `mant` z `10^k`.zdaj `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // popravilo, ko `mant + plus > scale` (ali `>=`).
    // pravzaprav ne spreminjamo `scale`, saj lahko namesto tega preskočimo začetno množenje.
    // zdaj `scale < mant + plus <= scale * 10` in pripravljeni smo ustvariti števke.
    //
    // Upoštevajte, da je `d[0]`*lahko* enak nič, kadar je `scale - plus < mant < scale`.
    // v tem primeru bo stanje zaokroževanja (spodaj `up`) sproženo takoj.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // kar ustreza merilu `scale` za 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // predpomnilnik `(2, 4, 8) * scale` za generiranje številk.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // invariante, kjer so `d[0..n-1]` do zdaj ustvarjene številke:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (torej `mant / scale < 10`), kjer je `d[i..j]` okrajšava za `d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // ustvari eno števko: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // to je poenostavljen opis spremenjenega algoritma Dragon.
        // veliko vmesnih izpeljav in argumentov popolnosti je zaradi udobja izpuščenih.
        //
        // začnite s spremenjenimi invariantami, saj smo posodobili `n`:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // predpostavimo, da je `d[0..n-1]` najkrajša predstavitev med `low` in `high`, tj. `d[0..n-1]` izpolnjuje oba naslednja, vendar `d[0..n-2]` ne:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (belost: števke okrogle do `v`);in
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (zadnja številka je pravilna).
        //
        // drugi pogoj se poenostavi na `2 * mant <= scale`.
        // razreševanje invariant v smislu `mant`, `low` in `high` daje enostavnejšo različico prvega pogoja: `-plus < mant < minus`.
        // od `-plus < 0 <= mant` imamo pravilno najkrajšo predstavitev pri `mant < minus` in `2 * mant <= scale`.
        // (prvi postane `mant <= minus`, ko je prvotna mantisa sodo.)
        //
        // ko druga ne drži (`2 * mant> lestvica`), moramo povečati zadnjo številko.
        // to je dovolj za obnovo tega stanja: že vemo, da generacija številk zagotavlja `0 <= v / 10^(k-n) - d[0..n-1] < 1`.
        // v tem primeru prvi pogoj postane `-plus < mant - scale < minus`.
        // od `mant < scale` po generaciji imamo `scale < mant + plus`.
        // (spet postane `scale <= mant + plus`, ko je prvotna mantisa sodo.)
        //
        // v kratkem:
        // - ustavite in zaokrožite `down` (ohranite številke, kakršne so), ko `mant < minus` (ali `<=`).
        // - ustavite in zaokrožite `up` (povečajte zadnjo številko), ko `scale < mant + plus` (ali `<=`).
        // - še naprej ustvarjajte drugače.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // imamo najkrajšo predstavitev, nadaljujemo z zaokroževanjem

        // obnoviti nespremenljive.
        // zaradi tega se algoritem vedno zaključuje: `minus` in `plus` se vedno povečujeta, `mant` pa je odrezana modulo `scale` in `scale` je določen.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // zaokroževanje se zgodi, ko i) je bil sprožen le pogoj zaokroževanja, ali ii) sprožena oba pogoja in krajšanje tekme raje zaokroži.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // če zaokroževanje spremeni dolžino, se mora spremeniti tudi eksponent.
        // zdi se, da je ta pogoj zelo težko izpolniti (morda nemogoče), vendar smo tukaj le varni in dosledni.
        //
        // VARNOST: ta spomin smo inicializirali zgoraj.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // VARNOST: ta spomin smo inicializirali zgoraj.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Natančna in fiksna izvedba načina za Dragon.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // ocenite `k_0` iz originalnih vhodov, ki ustrezajo `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // delite `mant` z `10^k`.zdaj `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // popravek, ko `mant + plus >= scale`, kjer `plus / scale = 10^-buf.len() / 2`.
    // da bi ohranili bignum fiksne velikosti, dejansko uporabljamo `mant + floor(plus) >= scale`.
    // pravzaprav ne spreminjamo `scale`, saj lahko namesto tega preskočimo začetno množenje.
    // spet z najkrajšim algoritmom je `d[0]` lahko nič, vendar bo sčasoma zaokrožen.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // kar ustreza merilu `scale` za 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // če delamo z omejitvijo zadnje številke, moramo pred dejanskim upodabljanjem skrajšati medpomnilnik, da se izognemo dvojnemu zaokroževanju.
    //
    // upoštevajte, da moramo med zaokroževanjem medpomnilnik znova povečati!
    let mut len = if k < limit {
        // ops, ne moremo ustvariti niti *ene* številke.
        // to je mogoče, če imamo recimo nekaj takega kot 9.5 in je zaokroženo na 10.
        // vrnemo prazen vmesni pomnilnik, z izjemo kasnejšega zaokroževanja, ki se pojavi pri `k == limit` in mora navesti natanko eno števko.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // predpomnilnik `(2, 4, 8) * scale` za generiranje številk.
        // (to je lahko drago, zato jih ne izračunajte, ko je vmesnik prazen.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // naslednje številke so ničle, tukaj se ustavimo ne *ne* poskusite izvesti zaokroževanje!raje napolnite preostale številke.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // VARNOST: ta spomin smo inicializirali zgoraj.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // zaokroževanje navzgor, če se ustavimo sredi števk, če so naslednje števke natančno 5000 ..., preverite prejšnjo številko in poskusite zaokrožiti na sodo (tj. izogibajte se zaokroževanju navzgor, če je prejšnja številka soda).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // VARNOST: `buf[len-1]` je inicializiran.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // če zaokroževanje spremeni dolžino, se mora spremeniti tudi eksponent.
        // vendar smo zahtevali določeno število števk, zato ne spreminjajte medpomnilnika ...
        // VARNOST: ta spomin smo inicializirali zgoraj.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... razen če smo namesto tega zaprošeni za določeno natančnost.
            // preveriti moramo tudi, če je bil prvotni vmesni pomnilnik prazen, se lahko dodatna številka doda samo v primeru `k == limit` (primer edge).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // VARNOST: ta spomin smo inicializirali zgoraj.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}