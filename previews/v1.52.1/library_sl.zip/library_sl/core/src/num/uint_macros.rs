macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Najmanjša vrednost, ki jo lahko predstavlja ta vrsta števila.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// Največja vrednost, ki jo lahko predstavlja ta vrsta števila.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// Velikost te celoštevilčne vrste v bitih.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Pretvori rezino niza v dani osnovi v celo število.
        ///
        /// Niz naj bi bil neobvezen znak `+`, ki mu sledijo številke.
        ///
        /// Vodilni in zaostali presledki predstavljajo napako.
        /// Števke so podnabor teh znakov, odvisno od `radix`:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// Ta funkcija panics, če `radix` ni v območju od 2 do 36.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Vrne število tistih v binarni predstavitvi `self`.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// Vrne število ničel v binarni predstavitvi `self`.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Vrne število vodilnih ničel v binarni predstavitvi `self`.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// Vrne število zadnjih ničel v binarni predstavitvi `self`.
        ///
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// Vrne število vodilnih v binarni predstavitvi `self`.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// Vrne število zaostalih v binarni predstavitvi `self`.
        ///
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// Bite premakne v levo za določeno količino, `n`, in okleščene bite zavije na konec nastalega celotnega števila.
        ///
        ///
        /// Prosimo, upoštevajte, da to ni enak postopek kot menjalnik `<<`!
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// Premakne bitove v desno za določeno količino, `n`, pri čemer skrajšane bite zavije na začetek nastalega celotnega števila.
        ///
        ///
        /// Prosimo, upoštevajte, da to ni enak postopek kot menjalnik `>>`!
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// Obrne vrstni red bajtov celotnega števila.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// naj bo m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// Obrne vrstni red bitov v celotnem številu.
        /// Najmanj pomemben bit postane najpomembnejši bit, drugi najmanj pomemben bit postane drugi najpomembnejši bit itd.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// naj bo m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// Pretvori celo število iz velikega endiana v ciljno endiannost.
        ///
        /// Za big endian je to no-op.
        /// Na malem endianu se bajti zamenjajo.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// če cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } še {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Pretvori celo število iz malega endiana v endianness cilja.
        ///
        /// Na malem endianu je to no-op.
        /// Na velikem endianu se bajti zamenjajo.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// če cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } še {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Pretvori `self` v velik endian iz ciljne endianije.
        ///
        /// Za big endian je to no-op.
        /// Na malem endianu se bajti zamenjajo.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// če cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } sicer { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // ali ne biti?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Pretvori `self` v malo endian iz ciljne endianness.
        ///
        /// Na malem endianu je to no-op.
        /// Na velikem endianu se bajti zamenjajo.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// če cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } sicer { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Označeno celošteviško dodajanje.
        /// Izračuna `self + rhs` in vrne `None`, če je prišlo do prelivanja.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Nepreverjeno dodajanje celih števil.Izračuna `self + rhs`, ob predpostavki, da do prelivanja ne more priti.
        /// Posledica tega je nedefinirano vedenje, ko
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Odključeno celoštevilčno odštevanje.
        /// Izračuna `self - rhs` in vrne `None`, če je prišlo do prelivanja.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Neodključeno odštevanje celih števil.Izračuna `self - rhs`, ob predpostavki, da do prelivanja ne more priti.
        /// Posledica tega je nedefinirano vedenje, ko
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Preverjeno množenje celih števil.
        /// Izračuna `self * rhs` in vrne `None`, če je prišlo do prelivanja.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Nepreverjeno množenje celih števil.Izračuna `self * rhs`, ob predpostavki, da do prelivanja ne more priti.
        /// Posledica tega je nedefinirano vedenje, ko
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Preverjena celoštevilčna delitev.
        /// Izračuna `self / rhs`, vrne `None`, če `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // VARNOST: div z ničlo je preverjen zgoraj in nepodpisani tipi nimajo drugega
                // načini okvare za delitev
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Preverjena evklidska delitev.
        /// Izračuna `self.div_euclid(rhs)`, vrne `None`, če `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// Preverjen ostanek celotnega števila.
        /// Izračuna `self % rhs`, vrne `None`, če `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // VARNOST: div z ničlo je preverjen zgoraj in nepodpisani tipi nimajo drugega
                // načini okvare za delitev
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Preverjen evklidski modul.
        /// Izračuna `self.rem_euclid(rhs)`, vrne `None`, če `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Preverjena negacija.Izračuna `-self`, vrne `None`, razen če `self==
        /// 0`.
        ///
        /// Upoštevajte, da bo zanikanje katerega koli pozitivnega števila prelilo.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Preverjen premik levo.
        /// Izračuna `self << rhs` in vrne `None`, če je `rhs` večje ali enako številu bitov v `self`.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Preverjen premik desno.
        /// Izračuna `self >> rhs` in vrne `None`, če je `rhs` večje ali enako številu bitov v `self`.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Preverjena stopnjevanje.
        /// Izračuna `self.pow(exp)` in vrne `None`, če je prišlo do prelivanja.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // ker je exp!=0, končno mora biti exp 1.
            // Ločite se z zadnjim bitom eksponenta ločeno, saj naknadno kvadratkanje osnove ni potrebno in lahko povzroči nepotrebno prelivanje.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Nasičeno celoštevilo.
        /// Izračuna `self + rhs`, nasiči se na številskih mejah, namesto da bi se prelival.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Nasičeno celoštevilčno odštevanje.
        /// Izračuna `self - rhs`, nasiči se na številskih mejah, namesto da bi se prelival.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Nasičeno celoštevilčno množenje.
        /// Izračuna `self * rhs`, nasiči se na številskih mejah, namesto da bi se prelival.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Nasičeno celoštevilčno stopnjevanje.
        /// Izračuna `self.pow(exp)`, nasiči se na številskih mejah, namesto da bi se prelival.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Zavijanje (modular) dodatek.
        /// Izračuna `self + rhs`, ovije se na meji tipa.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Zavijanje odštevanja (modular).
        /// Izračuna `self - rhs`, ovije se na meji tipa.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Zavijanje množenja (modular).
        /// Izračuna `self * rhs`, ovije se na meji tipa.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// Upoštevajte, da si ta primer delijo celoštevilske vrste.
        /// Kar pojasnjuje, zakaj se tukaj uporablja `u8`.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Zavijanje oddelka (modular).Izračuna `self / rhs`.
        /// Zavita delitev na nepodpisanih vrstah je povsem običajna delitev.
        /// Zavijanje se nikakor ne more zgoditi.
        /// Ta funkcija obstaja, tako da so vse operacije upoštevane pri postopkih zavijanja.
        ///
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Zavijanje evklidske delitve.Izračuna `self.div_euclid(rhs)`.
        /// Zavita delitev na nepodpisanih vrstah je povsem običajna delitev.
        /// Zavijanje se nikakor ne more zgoditi.
        /// Ta funkcija obstaja, tako da so vse operacije upoštevane pri postopkih zavijanja.
        /// Ker so za pozitivna cela števila vse običajne definicije delitve enake, je to popolnoma enako `self.wrapping_div(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Zavijanje ostanka (modular).Izračuna `self % rhs`.
        /// Izračun zavitega ostanka na nepodpisanih vrstah je le običajni izračun ostanka.
        ///
        /// Zavijanje se nikakor ne more zgoditi.
        /// Ta funkcija obstaja, tako da so vse operacije upoštevane pri postopkih zavijanja.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Zavijanje evklidskega modula.Izračuna `self.rem_euclid(rhs)`.
        /// Zaviti modulski izračun za nepodpisane vrste je le običajni izračun ostanka.
        /// Zavijanje se nikakor ne more zgoditi.
        /// Ta funkcija obstaja, tako da so vse operacije upoštevane pri postopkih zavijanja.
        /// Ker so za pozitivna cela števila vse običajne definicije delitve enake, je to popolnoma enako `self.wrapping_rem(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Zavijanje negacije (modular).
        /// Izračuna `-self`, ovije se na meji tipa.
        ///
        /// Ker nepodpisani tipi nimajo negativnih ekvivalentov, se vse aplikacije te funkcije zavijejo (razen `-0`).
        /// Za vrednosti, ki so manjše od maksimuma ustreznega podpisanega tipa, je rezultat enak oddaji ustrezne podpisane vrednosti.
        ///
        /// Vse večje vrednosti so enakovredne `MAX + 1 - (val - MAX - 1)`, kjer je `MAX` največja vrednost ustreznega podpisanega tipa.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// Upoštevajte, da si ta primer delijo celoštevilske vrste.
        /// Kar pojasnjuje, zakaj se tukaj uporablja `i8`.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic brez bitnega pomika levo;
        /// daje `self << mask(rhs)`, pri čemer `mask` odstrani vse bitne razrede `rhs`, zaradi katerih bi premik presegel bitno širino tipa.
        ///
        /// Upoštevajte, da to *ni* enako kot vrtenje v levo;RHS previjanja v levo je omejen na obseg tipa, namesto da bi se bitji, premaknjeni iz LHS, vrnili na drugi konec.
        /// Vsi primitivni celoštevilski tipi izvajajo funkcijo [`rotate_left`](Self::rotate_left), ki je morda tisto, kar želite namesto tega.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // VARNOST: maskiranje s hitrostjo tipa zagotavlja, da se ne premikamo
            // izven meja
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic brez bitnega premika v desno;
        /// daje `self >> mask(rhs)`, pri čemer `mask` odstrani vse bitne razrede `rhs`, zaradi katerih bi premik presegel bitno širino tipa.
        ///
        /// Upoštevajte, da to *ni* enako kot zasukanje v desno;RHS zavijanja premika v desno je omejen na obseg tipa, namesto da bi se bitji, premaknjeni iz LHS, vrnili na drugi konec.
        /// Vsi primitivni celoštevilski tipi izvajajo funkcijo [`rotate_right`](Self::rotate_right), ki je morda tisto, kar želite namesto tega.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // VARNOST: maskiranje s hitrostjo tipa zagotavlja, da se ne premikamo
            // izven meja
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Zavijanje stopnjevanja (modular).
        /// Izračuna `self.pow(exp)`, ovije se na meji tipa.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // ker je exp!=0, končno mora biti exp 1.
            // Ločite se z zadnjim bitom eksponenta ločeno, saj naknadno kvadratkanje osnove ni potrebno in lahko povzroči nepotrebno prelivanje.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Izračuna `self` + `rhs`
        ///
        /// Vrne sklop seštevanja skupaj z logično vrednostjo, ki kaže, ali bi prišlo do aritmetičnega prelivanja.
        /// Če bi prišlo do prelivanja, se vrne ovita vrednost.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Izračuna `self`, `rhs`
        ///
        /// Vrne sklop odštevanja skupaj z logično vrednostjo, ki kaže, ali bi prišlo do aritmetičnega prelivanja.
        /// Če bi prišlo do prelivanja, se vrne ovita vrednost.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Izračuna množenje `self` in `rhs`.
        ///
        /// Vrne sklop množenja skupaj z logično vrednostjo, ki kaže, ali bi prišlo do aritmetičnega prelivanja.
        /// Če bi prišlo do prelivanja, se vrne ovita vrednost.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// Upoštevajte, da si ta primer delijo celoštevilske vrste.
        /// Kar pojasnjuje, zakaj se tukaj uporablja `u32`.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Izračuna delitelj, ko je `self` deljen s `rhs`.
        ///
        /// Vrne delitev delilnika skupaj z logično vrednostjo, ki kaže, ali bi prišlo do aritmetičnega prelivanja.
        /// Upoštevajte, da za nepodpisana cela števila nikoli ne pride do prelivanja, zato je druga vrednost vedno `false`.
        ///
        /// # Panics
        ///
        /// Ta funkcija bo panic, če je `rhs` 0.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Izračuna količnik evklidske delitve `self.div_euclid(rhs)`.
        ///
        /// Vrne delitev delilnika skupaj z logično vrednostjo, ki kaže, ali bi prišlo do aritmetičnega prelivanja.
        /// Upoštevajte, da za nepodpisana cela števila nikoli ne pride do prelivanja, zato je druga vrednost vedno `false`.
        /// Ker so za pozitivna cela števila vse običajne definicije delitve enake, je to popolnoma enako `self.overflowing_div(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Ta funkcija bo panic, če je `rhs` 0.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Izračuna ostanek, ko `self` delimo z `rhs`.
        ///
        /// Vrne sklop ostanka po delitvi skupaj z logično vrednostjo, ki kaže, ali bi prišlo do aritmetičnega prelivanja.
        /// Upoštevajte, da za nepodpisana cela števila nikoli ne pride do prelivanja, zato je druga vrednost vedno `false`.
        ///
        /// # Panics
        ///
        /// Ta funkcija bo panic, če je `rhs` 0.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Preostanek `self.rem_euclid(rhs)` izračuna kot po evklidski delitvi.
        ///
        /// Vrne sklop modula po delitvi skupaj z logično vrednostjo, ki kaže, ali bi prišlo do aritmetičnega prelivanja.
        /// Upoštevajte, da za nepodpisana cela števila nikoli ne pride do prelivanja, zato je druga vrednost vedno `false`.
        /// Ker so pri pozitivnih celih številih vse običajne definicije delitve enake, je ta operacija popolnoma enaka `self.overflowing_rem(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Ta funkcija bo panic, če je `rhs` 0.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Negatira sebe na pretiran način.
        ///
        /// Vrne `!self + 1` z uporabo postopkov zavijanja, da vrne vrednost, ki predstavlja negacijo te nepodpisane vrednosti.
        /// Upoštevajte, da pri pozitivnih nepodpisanih vrednostih vedno pride do prelivanja, zanikanje 0 pa ne preseže.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// Preklopi samo levo za bitov `rhs`.
        ///
        /// Vrne sklop premaknjene različice selfja skupaj z logično vrednostjo, ki kaže, ali je bila vrednost premika večja ali enaka številu bitov.
        /// Če je vrednost premika prevelika, je vrednost maskirana (N-1), kjer je N število bitov, in ta vrednost se nato uporabi za izvedbo premika.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Premakne se samo za 10 bitov `rhs`.
        ///
        /// Vrne sklop premaknjene različice selfja skupaj z logično vrednostjo, ki kaže, ali je bila vrednost premika večja ali enaka številu bitov.
        /// Če je vrednost premika prevelika, je vrednost maskirana (N-1), kjer je N število bitov, in ta vrednost se nato uporabi za izvedbo premika.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Z uporabo stopnjevanja s kvadratom poveča stopnjo lastnosti do moči `exp`.
        ///
        /// Vrne sklop stopnjevanja skupaj z bool, ki kaže, ali je prišlo do prelivanja.
        ///
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, resnično));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Praskajte prostor za shranjevanje rezultatov overflowing_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // ker je exp!=0, končno mora biti exp 1.
            // Ločite se z zadnjim bitom eksponenta ločeno, saj naknadno kvadratkanje osnove ni potrebno in lahko povzroči nepotrebno prelivanje.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// Z uporabo stopnjevanja s kvadratom poveča stopnjo lastnosti do moči `exp`.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // ker je exp!=0, končno mora biti exp 1.
            // Ločite se z zadnjim bitom eksponenta ločeno, saj naknadno kvadratkanje osnove ni potrebno in lahko povzroči nepotrebno prelivanje.
            //
            //
            acc * base
        }

        /// Opravlja evklidsko delitev.
        ///
        /// Ker so za pozitivna cela števila vse običajne definicije delitve enake, je to popolnoma enako `self / rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Ta funkcija bo panic, če je `rhs` 0.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// Izračuna najmanjši preostanek `self (mod rhs)`.
        ///
        /// Ker so za pozitivna cela števila vse običajne definicije delitve enake, je to popolnoma enako `self % rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Ta funkcija bo panic, če je `rhs` 0.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Vrne `true` takrat in samo, če je `self == 2^k` za nekatere `k`.
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // Vrne eno manj kot naslednja moč dveh.
        // (Pri 8u8 je naslednja moč dveh 8u8, pri 6u8 pa 8u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // Ta metoda se ne more preseči, saj v primerih prelivanja `next_power_of_two` na koncu vrne največjo vrednost vrste in lahko vrne 0 za 0.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // VARNOST: Ker `p > 0` ne more biti v celoti sestavljen iz vodilnih ničel.
            // To pomeni, da je premik vedno v mejah, nekateri procesorji (na primer Intel pre-haswell) pa imajo učinkovitejše lastnosti ctlz, kadar argument ni nič.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// Vrne najmanjšo moč dveh, večjo ali enako `self`.
        ///
        /// Ko se vrnjena vrednost preseže (tj. `self > (1 << (N-1))` za tip `uN`), je panics v načinu za odpravljanje napak in vrnjena vrednost v načinu sprostitve ovita na 0 (edina situacija, v kateri lahko metoda vrne 0).
        ///
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// Vrne najmanjšo moč dveh, večjo ali enako `n`.
        /// Če je naslednja moč dveh večja od največje vrednosti tipa, se vrne `None`, sicer je moč dveh ovita v `Some`.
        ///
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// Vrne najmanjšo moč dveh, večjo ali enako `n`.
        /// Če je naslednja moč dveh večja od največje vrednosti tipa, je vrnjena vrednost ovita v `0`.
        ///
        ///
        /// # Examples
        ///
        /// Osnovna uporaba:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// Vrnite pomnilniško predstavitev tega števila kot bajtno matriko v velikem bajtnem vrstnem redu (network).
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Vrnite pomnilniško predstavitev tega števila kot bajtno matriko v malo-endian bajtnem vrstnem redu.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Vrnite pomnilniško predstavitev tega števila kot bajtno matriko v izvornem bajtnem vrstnem redu.
        ///
        /// Ker se uporablja izvorna endianness ciljne platforme, mora prenosna koda namesto tega uporabiti [`to_be_bytes`] ali [`to_le_bytes`], kot je primerno.
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     bajtov, če cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } še {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // VARNOST: const zvok, ker so cela števila navadni stari podatkovni tipi, tako da jih lahko vedno
        // jih pretvori v nize bajtov
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // VARNOST: cela števila so navadni stari podatkovni tipi, zato jih lahko vedno pretvorimo v
            // nizi bajtov
            unsafe { mem::transmute(self) }
        }

        /// Vrnite pomnilniško predstavitev tega števila kot bajtno matriko v izvornem bajtnem vrstnem redu.
        ///
        ///
        /// [`to_ne_bytes`] če je le mogoče, je treba dati prednost temu.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// naj bodo bajti= num.as_ne_bytes();
        /// assert_eq!(
        ///     bajtov, če cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } še {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // VARNOST: cela števila so navadni stari podatkovni tipi, zato jih lahko vedno pretvorimo v
            // nizi bajtov
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Iz njegove predstavitve v obliki bajtne matrike v velikem endianu ustvarite izvorno endian celoštevilsko vrednost.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// uporabite std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * vhod=počitek;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Iz njegove predstavitve v obliki bajtne matrike v malem endianu ustvarite izvorno endian celoštevilsko vrednost.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// uporabite std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * vhod=počitek;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Iz njegove pomnilniške predstavitve ustvarite izvorno celošteviško vrednost kot bajtno matriko v izvorni endiannosti.
        ///
        /// Ker se uporablja izvorna endianness ciljne platforme, prenosna koda verjetno namesto tega želi uporabiti [`from_be_bytes`] ali [`from_le_bytes`].
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } še {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// uporabite std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * vhod=počitek;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // VARNOST: const zvok, ker so cela števila navadni stari podatkovni tipi, tako da jih lahko vedno
        // pretvori v njih
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // VARNOST: cela števila so navadni stari podatkovni tipi, zato jih lahko vedno pretvorimo
            unsafe { mem::transmute(bytes) }
        }

        /// Novo kodo raje uporabljajte
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Vrne najmanjšo vrednost, ki jo lahko predstavlja ta celoštevilski tip.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// Novo kodo raje uporabljajte
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Vrne največjo vrednost, ki jo lahko predstavlja ta vrsta števila.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}