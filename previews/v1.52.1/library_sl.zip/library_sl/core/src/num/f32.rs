//! Konstante, značilne za tip `f32` z natančnostjo s plavajočo vejico.
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! Matematično pomembne številke so na voljo v podmodulu `consts`.
//!
//! Za konstante, ki so definirane neposredno v tem modulu (za razliko od tistih, ki so definirane v podmodulu `consts`), naj nova koda namesto tega uporabi pridružene konstante, določene neposredno za tip `f32`.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// Polmer ali osnova notranje predstavitve `f32`.
/// Namesto tega uporabite [`f32::RADIX`].
///
/// # Examples
///
/// ```rust
/// // zastarel način
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // predvideni način
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// Število pomembnih števk v osnovi 2.
/// Namesto tega uporabite [`f32::MANTISSA_DIGITS`].
///
/// # Examples
///
/// ```rust
/// // zastarel način
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // predvideni način
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// Približno število pomembnih števk v osnovi 10.
/// Namesto tega uporabite [`f32::DIGITS`].
///
/// # Examples
///
/// ```rust
/// // zastarel način
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // predvideni način
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] vrednost za `f32`.
/// Namesto tega uporabite [`f32::EPSILON`].
///
/// To je razlika med `1.0` in naslednjo večjo predstavljivo številko.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // zastarel način
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // predvideni način
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// Najmanjša končna vrednost `f32`.
/// Namesto tega uporabite [`f32::MIN`].
///
/// # Examples
///
/// ```rust
/// // zastarel način
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // predvideni način
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// Najmanjša pozitivna normalna vrednost `f32`.
/// Namesto tega uporabite [`f32::MIN_POSITIVE`].
///
/// # Examples
///
/// ```rust
/// // zastarel način
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // predvideni način
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// Največja končna vrednost `f32`.
/// Namesto tega uporabite [`f32::MAX`].
///
/// # Examples
///
/// ```rust
/// // zastarel način
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // predvideni način
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// Ena večja od najmanjše možne normalne moči 2 eksponenta.
/// Namesto tega uporabite [`f32::MIN_EXP`].
///
/// # Examples
///
/// ```rust
/// // zastarel način
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // predvideni način
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// Največja možna moč 2 eksponenta.
/// Namesto tega uporabite [`f32::MAX_EXP`].
///
/// # Examples
///
/// ```rust
/// // zastarel način
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // predvideni način
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// Najmanjša možna normalna moč 10 eksponentov.
/// Namesto tega uporabite [`f32::MIN_10_EXP`].
///
/// # Examples
///
/// ```rust
/// // zastarel način
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // predvideni način
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// Največja možna moč 10 eksponentov.
/// Namesto tega uporabite [`f32::MAX_10_EXP`].
///
/// # Examples
///
/// ```rust
/// // zastarel način
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // predvideni način
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// Ni številka (NaN).
/// Namesto tega uporabite [`f32::NAN`].
///
/// # Examples
///
/// ```rust
/// // zastarel način
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // predvideni način
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// Infinity (∞).
/// Namesto tega uporabite [`f32::INFINITY`].
///
/// # Examples
///
/// ```rust
/// // zastarel način
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // predvideni način
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// Negativna neskončnost (−∞).
/// Namesto tega uporabite [`f32::NEG_INFINITY`].
///
/// # Examples
///
/// ```rust
/// // zastarel način
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // predvideni način
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// Osnovne matematične konstante.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: zamenjaj z matematičnimi konstantami iz cmath.

    /// Arhimedova konstanta (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// Konstanta celotnega kroga (τ)
    ///
    /// Enako 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// Eulerjeva številka (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// Polmer ali osnova notranje predstavitve `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Število pomembnih števk v osnovi 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// Približno število pomembnih števk v osnovi 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] vrednost za `f32`.
    ///
    /// To je razlika med `1.0` in naslednjo večjo predstavljivo številko.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// Najmanjša končna vrednost `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// Najmanjša pozitivna normalna vrednost `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// Največja končna vrednost `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// Ena večja od najmanjše možne normalne moči 2 eksponenta.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// Največja možna moč 2 eksponenta.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// Najmanjša možna normalna moč 10 eksponentov.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// Največja možna moč 10 eksponentov.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// Ni številka (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// Infinity (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// Negativna neskončnost (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// Vrne `true`, če je ta vrednost `NaN`.
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` javno ni na voljo v libcoreu zaradi pomislekov glede prenosljivosti, zato je ta izvedba namenjena interni zasebni uporabi.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// Vrne `true`, če je ta vrednost pozitivna neskončnost ali negativna neskončnost, `false` pa drugače.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Vrne `true`, če to število ni neomejeno in ne `NaN`.
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // NaN-a ni treba obravnavati ločeno: če je self NaN, primerjava ni resnična, natančno po želji.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Vrne `true`, če je številka [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // Vrednosti med `0` in `min` so podnormalne.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Vrne `true`, če število ni nič, neskončno, [subnormal] ali `NaN`.
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // Vrednosti med `0` in `min` so podnormalne.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Vrne kategorijo števila s plavajočo vejico.
    /// Če bo preizkušena samo ena lastnost, je na splošno hitreje uporabiti določen predikat.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Vrne `true`, če ima `self` pozitiven predznak, vključno z `+0.0`, `NaN-ji s pozitivnim bitom znaka in pozitivno neskončnostjo.
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// Vrne `true`, če ima `self` negativni predznak, vključno z `-0.0`, `NaN-ji z negativnim predznakom in negativno neskončnostjo.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // IEEE754 pravi: isSignMinus(x) velja, če in samo, če ima x negativni predznak.
        // isSignMinus velja tudi za ničle in NaN.
        self.to_bits() & 0x8000_0000 != 0
    }

    /// Vzame vzajemni (inverse) številke, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// Pretvori radiane v stopinje.
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // Za boljšo natančnost uporabite konstanto.
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// Pretvori stopinje v radiane.
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// Vrne največ dve številki.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Če je eden od argumentov NaN, se vrne drugi argument.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// Vrne najmanj dve številki.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Če je eden od argumentov NaN, se vrne drugi argument.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// Zaokroži proti ničli in pretvori v kateri koli primitivni celoštevilčni tip, ob predpostavki, da je vrednost končna in ustreza temu tipu.
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Vrednost mora:
    ///
    /// * Ne biti `NaN`
    /// * Ne sme biti neskončno
    /// * Po odseku njegovega delnega dela bodite predstavljivi v vrnilnem tipu `Int`
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `FloatToInt::to_int_unchecked`.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Surova pretvorba v `u32`.
    ///
    /// Ta je trenutno enak `transmute::<f32, u32>(self)` na vseh platformah.
    ///
    /// Glejte `from_bits` za nekaj razprav o prenosljivosti te operacije (skoraj ni vprašanj).
    ///
    /// Upoštevajte, da se ta funkcija razlikuje od vlivanja `as`, ki poskuša ohraniti *numerično* vrednost in ne bitno vrednost.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() ni kasting!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // VARNOST: `u32` je navaden stari podatkovni tip, zato ga lahko vedno pretvorimo
        unsafe { mem::transmute(self) }
    }

    /// Surova pretvorba iz `u32`.
    ///
    /// Ta je trenutno enak `transmute::<u32, f32>(v)` na vseh platformah.
    /// Izkazalo se je, da je to iz dveh razlogov neverjetno prenosljivo:
    ///
    /// * Floats in Ints imajo enak endian na vseh podprtih platformah.
    /// * IEEE-754 zelo natančno določa bitno postavitev plovcev.
    ///
    /// Vendar obstaja eno opozorilo: pred različico IEEE-754 iz leta 2008, kako razlagati signalni bit NaN, dejansko ni bilo določeno.
    /// Večina platform (zlasti x86 in ARM) je izbrala interpretacijo, ki je bila leta 2008 na koncu standardizirana, nekatere pa ne (zlasti MIPS).
    /// Posledično so vsi signalni NaN-ji na MIPS tihi NaN-ji na x86 in obratno.
    ///
    /// Namesto da bi poskušali ohraniti signalizacijsko navzkrižno platformo, ta izvedba daje prednost ohranjanju natančnih bitov.
    /// To pomeni, da se bodo vse obremenitve, kodirane v NaN-jih, ohranile, tudi če se rezultat te metode pošlje po omrežju s stroja x86 na MIPS.
    ///
    ///
    /// Če z rezultati te metode manipulira le ista arhitektura, ki jih je ustvarila, potem zaskrbljenost glede prenosljivosti ne obstaja.
    ///
    /// Če vhod ni NaN, potem prenosljivost ni zaskrbljujoča.
    ///
    /// Če vam ni vseeno za signalizacijo (zelo verjetno), potem skrb za prenosljivost ni zaskrbljujoča.
    ///
    /// Upoštevajte, da se ta funkcija razlikuje od vlivanja `as`, ki poskuša ohraniti *numerično* vrednost in ne bitno vrednost.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // VARNOST: `u32` je navaden stari podatkovni tip, zato ga lahko vedno pretvorimo
        // Izkazalo se je, da so bile varnostne težave sNaN prenapihnjene!Hura!
        unsafe { mem::transmute(v) }
    }

    /// Vrnite pomnilniško predstavitev te številke s plavajočo vejico kot bajtno matriko v velikem bajtnem vrstnem redu (network).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// Vrnite pomnilniško predstavitev te številke s plavajočo vejico kot bajtno matriko v malobančnem bajtnem vrstnem redu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// Vrnite pomnilniško predstavitev te številke s plavajočo vejico kot bajtno matriko v izvornem bajtnem vrstnem redu.
    ///
    /// Ker se uporablja izvorna endianness ciljne platforme, mora prenosna koda namesto tega uporabiti [`to_be_bytes`] ali [`to_le_bytes`], kot je primerno.
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// Vrnite pomnilniško predstavitev te številke s plavajočo vejico kot bajtno matriko v izvornem bajtnem vrstnem redu.
    ///
    ///
    /// [`to_ne_bytes`] če je le mogoče, je treba dati prednost temu.
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // VARNOST: `f32` je navaden stari podatkovni tip, zato ga lahko vedno pretvorimo
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Ustvari vrednost s plavajočo vejico iz njene predstavitve kot bajtno matriko v velikem endianu.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// Ustvari vrednost s plavajočo vejico iz njene predstavitve kot bajtno matriko v malem endianu.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// Ustvari vrednost s plavajočo vejico iz njene predstavitve kot bajtno matriko v izvornem endianu.
    ///
    /// Ker se uporablja izvorna endianness ciljne platforme, prenosna koda verjetno namesto tega želi uporabiti [`from_be_bytes`] ali [`from_le_bytes`].
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// Vrne vrstni red med lastnostjo in drugimi vrednotami.
    /// Za razliko od standardne delne primerjave med števili s plavajočo vejico ta primerjava vedno ustvari vrstni red v skladu s predikatom totalOrder, kot je opredeljen v standardu s plavajočo vejico IEEE 754 (revizija 2008).
    /// Vrednosti so razvrščene v naslednjem vrstnem redu:
    /// - Negativni tihi NaN
    /// - Negativno signaliziranje NaN
    /// - Negativna neskončnost
    /// - Negativne številke
    /// - Negativne podnormalne številke
    /// - Negativna nič
    /// - Pozitivna ničla
    /// - Pozitivne podnaravne številke
    /// - Pozitivne številke
    /// - Pozitivna neskončnost
    /// - Pozitivna signalizacija NaN
    /// - Pozitiven tihi NaN
    ///
    /// Upoštevajte, da se ta funkcija ne strinja vedno z izvedbama `f32` in [`PartialEq`].Zlasti negativno in pozitivno nič obravnavajo kot enaki, `total_cmp` pa ne.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // V primeru negativov obrnite vse bite, razen znaka, da dosežete podobno postavitev kot komplementarna cela števila dveh
        //
        // Zakaj to deluje?IEEE 754 plovec je sestavljen iz treh polj:
        // Znakovni bit, eksponent in mantisa.Skupina eksponentnih in mantisinih polj kot celota ima lastnost, da je njihov bitni vrstni red enak številski velikosti, kjer je določena velikost.
        // Velikost običajno ni določena za vrednosti NaN, vendar IEEE 754 totalOrder določa vrednosti NaN tudi po bitnem vrstnem redu.To vodi do vrstnega reda, pojasnjenega v komentarju dokumenta.
        // Vendar je prikaz velikosti enak za negativna in pozitivna števila-le znakovni bit je drugačen.
        // Za enostavno primerjavo floatov kot podpisanih celih števil moramo v negativnih številih obrniti eksponent in bit mantise.
        // Številke učinkovito pretvorimo v obrazec "two's complement".
        //
        // Za premikanje izdelamo masko in XOR proti njej.
        // Masko "all-ones except for the sign bit" brez vej izračunamo iz negativno podpisanih vrednosti: desno premikajoči se znak podaljša celo število, zato "fill" masko pretvorimo v znakovne bitove in nato pretvorimo v nepodpisani, da potisnemo še en nič bit.
        //
        // Pri pozitivnih vrednostih je maska enaka ničli, zato ne velja.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// Omejite vrednost na določen interval, razen če je NaN.
    ///
    /// Vrne `max`, če je `self` večji od `max`, in `min`, če je `self` manjši od `min`.
    /// V nasprotnem primeru to vrne `self`.
    ///
    /// Upoštevajte, da ta funkcija vrne NaN, če je bila tudi začetna vrednost NaN.
    ///
    /// # Panics
    ///
    /// Panics, če je `min > max`, `min` NaN ali `max` NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}