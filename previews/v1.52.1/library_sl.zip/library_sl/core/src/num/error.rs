//! Vrste napak za pretvorbo v integralne tipe.

use crate::convert::Infallible;
use crate::fmt;

/// Vrsta napake se vrne, ko preverjena pretvorba integriranega tipa ne uspe.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Namesto prisile se ujemajte, da zagotovite, da bo koda, kot je zgoraj `From<Infallible> for TryFromIntError`, še naprej delovala, ko bo `Infallible` postal vzdevek `!`.
        //
        //
        match never {}
    }
}

/// Napaka, ki jo je mogoče vrniti pri razčlenjevanju celotnega števila.
///
/// Ta napaka se uporablja kot vrsta napake za funkcije `from_str_radix()` na primitivnih vrstah celih števil, kot je [`i8::from_str_radix`].
///
/// # Potencialni vzroki
///
/// Med drugimi vzroki lahko `ParseIntError` vržemo zaradi vodilnega ali zaostalega presledka v nizu, npr. Kadar je pridobljen s standardnega vhoda.
///
/// Uporaba metode [`str::trim()`] zagotavlja, da pred razčlenitvijo ne ostane presledkov.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum za shranjevanje različnih vrst napak, ki lahko povzročijo neuspešno razčlenjevanje celotnega števila.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Razčlenjena vrednost je prazna.
    ///
    /// Med drugimi vzroki bo ta različica zgrajena pri razčlenjevanju praznega niza.
    Empty,
    /// V svojem kontekstu vsebuje neveljavno številko.
    ///
    /// Med drugimi vzroki bo ta različica izdelana pri razčlenjevanju niza, ki vsebuje znak, ki ni ASCII.
    ///
    /// Ta varianta je sestavljena tudi, če je `+` ali `-` napačno postavljen v niz bodisi sam ali sredi števila.
    ///
    ///
    InvalidDigit,
    /// Celo število je preveliko za shranjevanje v ciljno celoštevilsko vrsto.
    PosOverflow,
    /// Celo število je premajhno za shranjevanje v ciljno celoštevilsko vrsto.
    NegOverflow,
    /// Vrednost je bila nič
    ///
    /// Ta varianta se bo oddala, ko bo niz razčlenjevanja imel vrednost nič, kar bi bilo nezakonito za vrste, ki niso nič.
    ///
    Zero,
}

impl ParseIntError {
    /// Izpiše podroben vzrok razčlenjevanja celotnega števila.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}