//! `Clone` Portrait za vrste, ki jih ni mogoče "implicitno kopirati".
//!
//! V Rust so nekateri preprosti tipi "implicitly copyable" in ko jih dodelite ali posredujete kot argumente, bo sprejemnik dobil kopijo, originalna vrednost pa bo ostala na mestu.
//! Te vrste ne zahtevajo dodelitve za kopiranje in nimajo zaključevalnikov (tj. Ne vsebujejo polj v lasti ali izvajajo [`Drop`]), zato jih prevajalnik šteje za poceni in varne za kopiranje.
//!
//! Za druge vrste je treba izvode narediti izrecno po dogovoru, ki izvaja [`Clone`] Portrait in prikliče metodo [`clone`].
//!
//! [`clone`]: Clone::clone
//!
//! Primer osnovne uporabe:
//!
//! ```
//! let s = String::new(); // Tip niza izvaja Klon
//! let copy = s.clone(); // da ga lahko kloniramo
//! ```
//!
//! Za enostavno uporabo Clone Portrait lahko uporabite tudi `#[derive(Clone)]`.Primer:
//!
//! ```
//! #[derive(Clone)] // v strukturo Morpheus dodamo Klon Portrait
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // in zdaj ga lahko kloniramo!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// Pogost Portrait za možnost izrecnega podvajanja predmeta.
///
/// Razlikuje se od [`Copy`] po tem, da je [`Copy`] implicitno in izjemno poceni, medtem ko je `Clone` vedno nazoren in je lahko drag ali pa tudi ne.
/// Da bi uveljavili te značilnosti, vam Rust ne dovoljuje ponovnega izvajanja [`Copy`], lahko pa znova uporabite `Clone` in zaženete poljubno kodo.
///
/// Ker je `Clone` bolj splošen kot [`Copy`], lahko samodejno naredite vse, kar je [`Copy`], tudi `Clone`.
///
/// ## Derivable
///
/// Ta Portrait se lahko uporablja z `#[derive]`, če so vsa polja `Clone`.Izvedena izvedba [`Clone`] pokliče [`clone`] na vsakem polju.
///
/// [`clone`]: Clone::clone
///
/// Za generično strukturo `#[derive]` pogojno implementira `Clone` z dodajanjem vezanega `Clone` na generične parametre.
///
/// ```
/// // `derive` izvaja Klon za branje<T>ko je T Klon.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Kako lahko implementiram `Clone`?
///
/// Tipi, ki so [`Copy`], bi morali imeti trivialno izvedbo `Clone`.Bolj formalno:
/// če so `T: Copy`, `x: T` in `y: &T`, je `let x = y.clone();` enakovreden `let x = *y;`.
/// Ročne izvedbe morajo biti previdne, da ohranijo to nespremenljivost;vendar se nevarna koda ne sme zanašati nanjo, da bi zagotovila varnost pomnilnika.
///
/// Primer je generična struktura, ki vsebuje kazalnik funkcije.V tem primeru izvedbe `Clone` ni mogoče `izpeljati`, ampak jo je mogoče izvesti kot:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Dodatni izvedbe
///
/// Poleg [implementors listed below][impls] naslednje vrste uporabljajo tudi `Clone`:
///
/// * Tipi elementov funkcij (tj. Ločeni tipi, opredeljeni za vsako funkcijo)
/// * Vrste kazalcev funkcij (npr. `fn() -> i32`)
/// * Vrste matrike za vse velikosti, če vrsta elementa izvaja tudi `Clone` (npr. `[i32; 123456]`)
/// * Vrste sklopov, če vsaka komponenta izvaja tudi `Clone` (npr. `()`, `(i32, bool)`)
/// * Vrste zapiranja, če iz okolja ne zajamejo nobene vrednosti ali če vse take zajete vrednosti same implementirajo `Clone`.
///   Upoštevajte, da spremenljivke, zajete s skupno referenco, vedno izvajajo `Clone` (tudi če referenca ne), medtem ko spremenljivke, zajete s spremenljivo referenco, nikoli ne izvajajo `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Vrne kopijo vrednosti.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str izvaja Clone
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Opravlja dodelitev kopij iz `source`.
    ///
    /// `a.clone_from(&b)` je po funkcionalnosti enakovreden `a = b.clone()`, vendar ga je mogoče preglasiti, če želite znova uporabiti vire `a`, da se izognete nepotrebnim dodelitvam.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Izvedite makro, ki generira impl z Portrait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): te strukture uporablja izključno#[derive], da trdi, da vsaka komponenta tipa izvaja Klon ali Kopiranje.
//
//
// Te strukture naj se nikoli ne pojavijo v uporabniški kodi.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Implementacije `Clone` za primitivne tipe.
///
/// Implementacije, ki jih ni mogoče opisati v Rust, so implementirane v `traits::SelectionContext::copy_clone_conditions()` v `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Skupne reference lahko klonirate, spremenljive reference * pa ne!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Skupne reference lahko klonirate, spremenljive reference * pa ne!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}