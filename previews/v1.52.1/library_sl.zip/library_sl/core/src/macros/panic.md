Panics trenutna nit.

To omogoča, da se program takoj konča in posreduje povratne informacije klicatelju programa.
`panic!` je treba uporabiti, ko program doseže stanje, ki ga ni mogoče obnoviti.

Ta makro je odličen način za uveljavljanje pogojev v vzorčni kodi in v testih.
`panic!` je tesno povezan z metodo `unwrap` obeh naštevanj [`Option`][ounwrap] in [`Result`][runwrap].
Obe izvedbi pokličeta `panic!`, če sta nastavljeni na različici [`None`] ali [`Err`].

Ko uporabljate `panic!()`, lahko določite niz koristnega tovora, ki je zgrajen z uporabo sintakse [`format!`].
Ta koristni tovor se uporablja pri vbrizganju panic v klicno nit Rust, zaradi česar nit v celoti panic.

Vedenje privzetega `std` hook, tj
koda, ki se zažene neposredno po priklicu panic, je natisniti koristni tovor sporočila na `stderr` skupaj z informacijami file/line/column o klicu `panic!()`.

panic hook lahko preglasite s pomočjo [`std::panic::set_hook()`].
Znotraj hook lahko do panic dostopate kot `&dyn Any + Send`, ki vsebuje `&str` ali `String` za običajne klice `panic!()`.
Za panic z vrednostjo druge vrste lahko uporabimo [`panic_any`].

[`Result`] enum je pogosto boljša rešitev za obnovitev napak kot uporaba makra `panic!`.
Ta makro je treba uporabljati, da se izognete nadaljevanju z napačnimi vrednostmi, na primer iz zunanjih virov.
Podrobne informacije o ravnanju z napakami najdete v [book].

Glejte tudi makro [`compile_error!`], kjer najdete napake med prevajanjem.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Trenutna izvedba

Če je glavna nit panics, bo zaključil vse vaše niti in program končal s kodo `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





