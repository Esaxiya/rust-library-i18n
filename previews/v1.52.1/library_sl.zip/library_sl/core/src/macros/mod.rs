#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Razširi se na `$crate::panic::panic_2015` ali `$crate::panic::panic_2021`, odvisno od izdaje klicatelja.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Trdi, da sta dva izraza enaka drug drugemu (z uporabo [`PartialEq`]).
///
/// Na panic bo ta makro natisnil vrednosti izrazov z njihovimi predstavitvami za odpravljanje napak.
///
///
/// Tako kot [`assert!`] ima tudi ta makro drugo obliko, kjer je mogoče poslati sporočilo panic po meri.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Spodnje ponovitve so namenske.
                    // Brez njih se reža sklada za izposojo inicializira, še preden se vrednosti primerjajo, kar povzroči opazno upočasnitev.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Spodnje ponovitve so namenske.
                    // Brez njih se reža sklada za izposojo inicializira, še preden se vrednosti primerjajo, kar povzroči opazno upočasnitev.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Trdi, da dva izraza nista enaka (z uporabo [`PartialEq`]).
///
/// Na panic bo ta makro natisnil vrednosti izrazov z njihovimi predstavitvami za odpravljanje napak.
///
///
/// Tako kot [`assert!`] ima tudi ta makro drugo obliko, kjer je mogoče poslati sporočilo panic po meri.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Spodnje ponovitve so namenske.
                    // Brez njih se reža sklada za izposojo inicializira, še preden se vrednosti primerjajo, kar povzroči opazno upočasnitev.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Spodnje ponovitve so namenske.
                    // Brez njih se reža sklada za izposojo inicializira, še preden se vrednosti primerjajo, kar povzroči opazno upočasnitev.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Trdi, da je logični izraz `true` med izvajanjem.
///
/// To bo poklicalo makro [`panic!`], če podanega izraza ni mogoče oceniti na `true` med izvajanjem.
///
/// Tako kot [`assert!`] ima tudi ta makro drugo različico, kjer lahko dobite sporočilo panic po meri.
///
/// # Uses
///
/// V nasprotju s [`assert!`] so stavki `debug_assert!` privzeto omogočeni samo v neoptimiziranih gradnjah.
/// Optimizirana zgradba ne bo izvajala stavkov `debug_assert!`, razen če je `-C debug-assertions` posredovan prevajalniku.
/// Zaradi tega je `debug_assert!` uporaben za preglede, ki so predragi, da bi bili prisotni v različici izdaje, vendar so lahko v pomoč med razvojem.
/// Rezultat razširitve `debug_assert!` se vedno preveri.
///
/// Nepreverjena trditev omogoča, da se program v neskladnem stanju še naprej izvaja, kar ima lahko nepričakovane posledice, vendar ne predstavlja nevarnosti, če se to zgodi samo v varni kodi.
///
/// Stroški uspešnosti trditev pa na splošno niso merljivi.
/// Zamenjava [`assert!`] z `debug_assert!` se tako spodbuja le po temeljitem profiliranju in še pomembneje, samo v varni kodi!
///
/// # Examples
///
/// ```
/// // sporočilo panic za te trditve je stringificirana vrednost podanega izraza.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // zelo preprosta funkcija
/// debug_assert!(some_expensive_computation());
///
/// // uveljavite s sporočilom po meri
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Trdi, da sta dva izraza enaka drug drugemu.
///
/// Na panic bo ta makro natisnil vrednosti izrazov z njihovimi predstavitvami za odpravljanje napak.
///
/// V nasprotju s [`assert_eq!`] so stavki `debug_assert_eq!` privzeto omogočeni samo v neoptimiziranih gradnjah.
/// Optimizirana zgradba ne bo izvajala stavkov `debug_assert_eq!`, razen če je `-C debug-assertions` posredovan prevajalniku.
/// Zaradi tega je `debug_assert_eq!` uporaben za preglede, ki so predragi, da bi bili prisotni v različici izdaje, vendar so lahko v pomoč med razvojem.
///
/// Rezultat razširitve `debug_assert_eq!` se vedno preveri.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Trdi, da dva izraza nista enaka.
///
/// Na panic bo ta makro natisnil vrednosti izrazov z njihovimi predstavitvami za odpravljanje napak.
///
/// V nasprotju s [`assert_ne!`] so stavki `debug_assert_ne!` privzeto omogočeni samo v neoptimiziranih gradnjah.
/// Optimizirana zgradba ne bo izvajala stavkov `debug_assert_ne!`, razen če je `-C debug-assertions` posredovan prevajalniku.
/// Zaradi tega je `debug_assert_ne!` uporaben za preglede, ki so predragi, da bi bili prisotni v različici izdaje, vendar so lahko v pomoč med razvojem.
///
/// Rezultat razširitve `debug_assert_ne!` se vedno preveri.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Vrne, ali se podani izraz ujema s katerim od danih vzorcev.
///
/// Tako kot v izrazu `match` lahko vzorcu po želji sledi `if` in izraz varoval, ki ima dostop do imen, ki jih veže vzorec.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Odvije rezultat ali razširi njegovo napako.
///
/// Namesto `try!` je bil dodan operater `?`, ki bi ga morali namesto njega uporabiti.
/// Poleg tega je `try` rezervirana beseda v Rust 2018, zato, če jo morate uporabiti, boste morali uporabiti [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` se ujema z danim [`Result`].V primeru različice `Ok` ima izraz vrednost ovite vrednosti.
///
/// V primeru različice `Err` pridobi notranjo napako.`try!` nato izvede pretvorbo z uporabo `From`.
/// To omogoča samodejno pretvorbo med specializirane napake in bolj splošne.
/// Nato se takoj vrne nastala napaka.
///
/// Zaradi zgodnje vrnitve se `try!` lahko uporablja samo v funkcijah, ki vrnejo [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Prednostna metoda hitrega vračanja napak
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Prejšnji način hitrega vračanja napak
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // To je enakovredno:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Formatirane podatke zapiše v medpomnilnik.
///
/// Ta makro sprejema 'writer', niz oblike in seznam argumentov.
/// Argumenti bodo formatirani v skladu z določenim nizom oblike, rezultat pa bo posredovan zapisovalniku.
/// Zapisovalnik je lahko katere koli vrednosti z metodo `write_fmt`;na splošno to prihaja iz izvedbe [`fmt::Write`] ali [`io::Write`] Portrait.
/// Makro vrne vse, kar vrne metoda `write_fmt`;običajno [`fmt::Result`] ali [`io::Result`].
///
/// Glejte [`std::fmt`] za več informacij o sintaksi niza oblikovanja.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Modul lahko uvozi `std::fmt::Write` in `std::io::Write` in pokliče `write!` na objekte, ki izvajajo oba, saj objekti običajno ne izvajajo obeh.
///
/// Vendar mora modul uvoziti kvalificirane traits, da si njihova imena ne nasprotujejo:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // uporablja fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // uporablja io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Ta makro se lahko uporablja tudi v nastavitvah `no_std`.
/// Pri namestitvi `no_std` ste odgovorni za podrobnosti o izvedbi komponent.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Formatirane podatke zapišite v medpomnilnik z dodano novo vrstico.
///
/// Na vseh platformah je nova vrstica samo znak LINE FEED (`\n`/`U+000A`) (brez dodatnega CARRIAGE RETURN (`\r`/`U+000D`).
///
/// Za več informacij glejte [`write!`].Za informacije o sintaksi niza formatov glejte [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Modul lahko uvozi `std::fmt::Write` in `std::io::Write` in pokliče `write!` na objekte, ki izvajajo oba, saj objekti običajno ne izvajajo obeh.
/// Vendar mora modul uvoziti kvalificirane traits, da si njihova imena ne nasprotujejo:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // uporablja fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // uporablja io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Označuje nedosegljivo kodo.
///
/// To je koristno kadarkoli, ko prevajalnik ne more ugotoviti, da je neka koda nedosegljiva.Na primer:
///
/// * Ujemanje orožja s pogoji varovanja.
/// * Zanke, ki se dinamično zaključijo.
/// * Iteratorji, ki se dinamično zaključijo.
///
/// Če se ugotovitev, da je koda nedosegljiva, izkaže za napačno, program takoj konča z [`panic!`].
///
/// Nevarno nasprotje tega makra je funkcija [`unreachable_unchecked`], ki bo povzročila nedefinirano vedenje, če bo koda dosežena.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// To bo vedno [`panic!`].
///
/// # Examples
///
/// Tekme orožja:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // napaka pri prevajanju, če je pripomnjena
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // ena najrevnejših izvedb x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Označuje neizvedeno kodo s paniko s sporočilom "not implemented".
///
/// To omogoča, da vaša koda preveri tip, kar je koristno, če prototipirate ali izvajate Portrait, ki zahteva več metod, ki jih ne nameravate uporabiti vseh.
///
/// Razlika med `unimplemented!` in [`todo!`] je v tem, da medtem ko `todo!` sporoča namen kasnejšega izvajanja funkcionalnosti in je sporočilo "not yet implemented", `unimplemented!` tovrstnih trditev ne daje.
/// Njegovo sporočilo je "not implemented".
/// Nekateri IDE bodo označili tudi "todo!".
///
/// # Panics
///
/// To bo vedno [`panic!`], ker je `unimplemented!` le okrajšava za `panic!` s fiksnim, določenim sporočilom.
///
/// Tako kot `panic!` ima tudi ta makro drugi obrazec za prikaz vrednosti po meri.
///
/// # Examples
///
/// Recimo, da imamo Portrait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Želimo implementirati `Foo` za 'MyStruct', vendar je iz nekega razloga smiselno izvajati samo funkcijo `bar()`.
/// `baz()` in `qux()` bo še vedno treba opredeliti pri naši izvedbi `Foo`, vendar lahko v njihovih definicijah uporabimo `unimplemented!`, da omogočimo prevajanje naše kode.
///
/// Še vedno želimo, da se naš program preneha izvajati, če se dosežejo neizvedene metode.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // `baz` in `MyStruct` nima smisla, zato tu sploh nimamo logike.
/////
///         // Prikaže se "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Tu imamo nekaj logike, neizvedenemu lahko dodamo sporočilo!prikazati našo opustitev.
///         // To bo prikazalo: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Označuje nedokončano kodo.
///
/// To je lahko koristno, če se ukvarjate s prototipiranjem in želite le preveriti vrsto kode.
///
/// Razlika med [`unimplemented!`] in `todo!` je v tem, da medtem ko `todo!` sporoča namen kasnejšega izvajanja funkcionalnosti in je sporočilo "not yet implemented", `unimplemented!` tovrstnih trditev ne daje.
/// Njegovo sporočilo je "not implemented".
/// Nekateri IDE bodo označili tudi "todo!".
///
/// # Panics
///
/// To bo vedno [`panic!`].
///
/// # Examples
///
/// Tu je primer nekaj kode v teku.Imamo Portrait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Želimo implementirati `Foo` na enega od naših tipov, vendar želimo najprej delati samo na `bar()`.Da se naša koda prevede, moramo implementirati `baz()`, zato lahko uporabimo `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // izvedba gre tukaj
///     }
///
///     fn baz(&self) {
///         // ne skrbimo, da bomo za zdaj uvedli baz()
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // niti baz() ne uporabljamo, zato je to v redu.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Definicije vgrajenih makrov.
///
/// Večina lastnosti makra (stabilnost, vidnost itd.) Je vzetih iz izvorne kode tukaj, razen razširitvenih funkcij, ki makro vhode pretvorijo v izhode, te funkcije zagotavlja prevajalnik.
///
///
pub(crate) mod builtin {

    /// Pri podanem sporočilu o napaki prevajanje ne uspe.
    ///
    /// Ta makro je treba uporabiti, kadar crate uporablja pogojno strategijo prevajanja za zagotavljanje boljših sporočil o napakah pri napačnih pogojih.
    ///
    /// Je oblika [`panic!`] na ravni prevajalnika, vendar oddaja napako med *prevajanjem* in ne med *izvajanjem*.
    ///
    /// # Examples
    ///
    /// Dva takšna primera sta makra in okolji `#[cfg]`.
    ///
    /// Če makro pošlje neveljavne vrednosti, oddaja boljšo napako prevajalnika.
    /// Brez končnega branch bi prevajalnik še vedno oddajal napako, vendar sporočilo o napaki ne bi omenjalo dveh veljavnih vrednosti.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Izpusti napako prevajalnika, če ena od številnih funkcij ni na voljo.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Konstruira parametre za druge makre za oblikovanje nizov.
    ///
    /// Ta makro deluje tako, da za vsak dodatni posredovani argument sprejme literal niza za oblikovanje, ki vsebuje `{}`.
    /// `format_args!` pripravi dodatne parametre, da zagotovi, da je izhod mogoče razlagati kot niz, in argumentira kanonike v en tip.
    /// Katero koli vrednost, ki implementira [`Display`] Portrait, je mogoče posredovati `format_args!`, prav tako pa tudi katero koli izvedbo [`Debug`] `{:?}` znotraj niza za oblikovanje.
    ///
    ///
    /// Ta makro ustvari vrednost tipa [`fmt::Arguments`].To vrednost lahko posredujete makrom znotraj [`std::fmt`] za izvedbo koristne preusmeritve.
    /// Vsi drugi makri za formatiranje (["format!"], [`write!`], [`println!`] itd.) So posredovani prek tega.
    /// `format_args!`, za razliko od izpeljanih makrov se izogiba dodeljevanju kopice.
    ///
    /// Uporabite lahko vrednost [`fmt::Arguments`], ki jo `format_args!` vrne v kontekstih `Debug` in `Display`, kot je prikazano spodaj.
    /// Primer tudi kaže, da `Debug` in `Display` formatirata na isto stvar: niz interpolirane oblike v `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Za več informacij glejte dokumentacijo v [`std::fmt`].
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Enako kot `format_args`, vendar na koncu doda novo vrstico.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Pregleduje spremenljivko okolja v času prevajanja.
    ///
    /// Ta makro se bo v času prevajanja razširil na vrednost imenovane spremenljivke okolja, kar bo dalo izraz tipa `&'static str`.
    ///
    ///
    /// Če spremenljivka okolja ni definirana, bo prikazana napaka pri prevajanju.
    /// Če ne želite oddajati napake pri prevajanju, raje uporabite makro [`option_env!`].
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Sporočilo o napaki lahko prilagodite tako, da kot drugi parameter posredujete niz:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Če spremenljivka okolja `documentation` ni definirana, se prikaže naslednja napaka:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Neobvezno pregleda spremenljivko okolja v času prevajanja.
    ///
    /// Če je imenovana spremenljivka okolja prisotna v času prevajanja, se bo to razširilo v izraz tipa `Option<&'static str>`, katerega vrednost je `Some` vrednosti spremenljivke okolja.
    /// Če spremenljivka okolja ni prisotna, se bo ta razširila na `None`.
    /// Za več informacij o tej vrsti glejte [`Option<T>`][Option].
    ///
    /// Pri uporabi tega makra se nikoli ne prikaže napaka časa prevajanja, ne glede na to, ali je spremenljivka okolja prisotna ali ne.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Združi identifikatorje v en identifikator.
    ///
    /// Ta makro zavzame poljubno število z vejico ločenih identifikatorjev in jih vse združi v enega, kar da izraz, ki je nov identifikator.
    /// Upoštevajte, da higiena omogoča, da ta makro ne more zajemati lokalnih spremenljivk.
    /// Praviloma so makri dovoljeni le v položaju postavke, stavka ali izraza.
    /// To pomeni, da lahko ta makro uporabite za sklicevanje na obstoječe spremenljivke, funkcije ali module itd., Vendar z njim ne morete določiti novega.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (novo, zabavno, ime) { }//ni uporaben na ta način!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Združi literale v statično rezino niza.
    ///
    /// Ta makro zavzame poljubno število literal, ločenih z vejico, in da izraz tipa `&'static str`, ki predstavlja vse literale, povezane z leve proti desni.
    ///
    ///
    /// Celotno in plavajoče vejice se strnijo, da se združijo.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Razširi se na številko vrstice, na kateri je bil poklican.
    ///
    /// Pri [`column!`] in [`file!`] ti makri razvijalcem nudijo informacije o odpravljanju napak o lokaciji znotraj vira.
    ///
    /// Razširjeni izraz ima tip `u32` in temelji na 1, zato je prva vrstica v vsaki datoteki ocenjena na 1, druga na 2 itd.
    /// To je skladno s sporočili o napakah običajnih prevajalnikov ali priljubljenih urejevalnikov.
    /// Vrnjena vrstica *ni nujno* vrstica samega klica `line!`, temveč prvi klic makra, ki vodi do klica makra `line!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Razširi se na številko stolpca, pri kateri je bil poklican.
    ///
    /// Pri [`line!`] in [`file!`] ti makri razvijalcem nudijo informacije o odpravljanju napak o lokaciji znotraj vira.
    ///
    /// Razširjeni izraz ima tip `u32` in temelji na 1, zato je prvi stolpec v vsaki vrstici ocenjen na 1, drugi na 2 itd.
    /// To je skladno s sporočili o napakah običajnih prevajalnikov ali priljubljenih urejevalnikov.
    /// Vrnjeni stolpec *ni nujno* vrstica samega klica `column!`, temveč prvi klic makra, ki vodi do klica makra `column!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Razširi se na ime datoteke, v kateri je bila priklicana.
    ///
    /// Pri [`line!`] in [`column!`] ti makri razvijalcem nudijo informacije o odpravljanju napak o lokaciji znotraj vira.
    ///
    /// Razširjeni izraz ima tip `&'static str` in vrnjena datoteka ni klic samega makra `file!`, temveč prvi klic makra, ki vodi do klica makra `file!`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Stringificira svoje argumente.
    ///
    /// Ta makro bo dal izraz tipa `&'static str`, ki je stringifikacija vseh tokens, posredovanih makru.
    /// Sintaksa samega priklica makra ni omejena.
    ///
    /// Upoštevajte, da se lahko razširjeni rezultati vnosa tokens spremenijo v future.Bodite previdni, če se zanašate na rezultate.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Vključuje datoteko, kodirano v UTF-8, kot niz.
    ///
    /// Datoteka se nahaja glede na trenutno datoteko (podobno kot najdete module).
    /// Navedena pot se v času prevajanja interpretira na način, specifičen za platformo.
    /// Tako na primer priklic s potjo Windows, ki vsebuje poševnice `\`, na Unix ne bi bil pravilno preveden.
    ///
    ///
    /// Ta makro bo dal izraz tipa `&'static str`, ki je vsebina datoteke.
    ///
    /// # Examples
    ///
    /// Predpostavimo, da sta v istem imeniku dve datoteki z naslednjo vsebino:
    ///
    /// Datoteka 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Datoteka 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Če prevedete 'main.rs' in zaženete nastali binarni program, se natisne "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Vključuje datoteko kot sklic na bajtno matriko.
    ///
    /// Datoteka se nahaja glede na trenutno datoteko (podobno kot najdete module).
    /// Navedena pot se v času prevajanja interpretira na način, specifičen za platformo.
    /// Tako na primer priklic s potjo Windows, ki vsebuje poševnice `\`, na Unix ne bi bil pravilno preveden.
    ///
    ///
    /// Ta makro bo dal izraz tipa `&'static [u8; N]`, ki je vsebina datoteke.
    ///
    /// # Examples
    ///
    /// Predpostavimo, da sta v istem imeniku dve datoteki z naslednjo vsebino:
    ///
    /// Datoteka 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Datoteka 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Če prevedete 'main.rs' in zaženete nastali binarni program, se natisne "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Razširi se na niz, ki predstavlja trenutno pot modula.
    ///
    /// Trenutna pot modula je lahko mišljena kot hierarhija modulov, ki vodijo nazaj do crate root.
    /// Prva komponenta vrnjene poti je ime crate, ki se trenutno prevaja.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// V času prevajanja ovrednoti logične kombinacije konfiguracijskih zastavic.
    ///
    /// Poleg atributa `#[cfg]` je ta makro na voljo, da omogoča ovrednotenje logičnih izrazov konfiguracijskih zastav.
    /// To pogosto vodi do manj podvojene kode.
    ///
    /// Sintaksa tega makra je enaka sintaksi kot atribut [`cfg`].
    ///
    /// `cfg!`, za razliko od `#[cfg]` ne odstrani nobene kode in oceni le na true ali false.
    /// Na primer, vsi bloki v izrazu if/else morajo biti veljavni, kadar se za pogoj uporablja `cfg!`, ne glede na to, kaj `cfg!` ocenjuje.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Datoteko razčleni kot izraz ali element glede na kontekst.
    ///
    /// Datoteka se nahaja glede na trenutno datoteko (podobno kot najdete module).Navedena pot se v času prevajanja interpretira na način, specifičen za platformo.
    /// Tako na primer priklic s potjo Windows, ki vsebuje poševnice `\`, na Unix ne bi bil pravilno preveden.
    ///
    /// Uporaba tega makra je pogosto slaba ideja, ker če je datoteka razčlenjena kot izraz, bo nehigiensko postavljena v okoliško kodo.
    /// To lahko povzroči, da se spremenljivke ali funkcije razlikujejo od tistega, kar je datoteka pričakovala, če so v trenutni datoteki spremenljivke ali funkcije z enakim imenom.
    ///
    ///
    /// # Examples
    ///
    /// Predpostavimo, da sta v istem imeniku dve datoteki z naslednjo vsebino:
    ///
    /// Datoteka 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Datoteka 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Če prevedete 'main.rs' in zaženete nastali binarni program, se natisne "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Trdi, da je logični izraz `true` med izvajanjem.
    ///
    /// To bo poklicalo makro [`panic!`], če podanega izraza ni mogoče oceniti na `true` med izvajanjem.
    ///
    /// # Uses
    ///
    /// Trditve se vedno preverijo v gradnjah za odpravljanje napak in izdajah in jih ni mogoče onemogočiti.
    /// Glejte [`debug_assert!`] za trditve, ki privzeto niso vključene v različicah za izdajo.
    ///
    /// Nevarna koda se lahko zanaša na `assert!` za uveljavitev invariantov med izvajanjem, ki bi v primeru kršitve lahko povzročili nevarnost.
    ///
    /// Drugi primeri uporabe `assert!` vključujejo testiranje in uveljavitev invariantov časa izvajanja v varni kodi (katerih kršitev ne more povzročiti nevarnosti).
    ///
    ///
    /// # Sporočila po meri
    ///
    /// Ta makro ima drugo obliko, kjer lahko sporočilo panic po meri dobite z ali brez argumentov za oblikovanje.
    /// Za sintakso tega obrazca glejte [`std::fmt`].
    /// Izrazi, uporabljeni kot argumenti oblike, bodo ocenjeni le, če trditev ne uspe.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // sporočilo panic za te trditve je stringificirana vrednost podanega izraza.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // zelo preprosta funkcija
    ///
    /// assert!(some_computation());
    ///
    /// // uveljavite s sporočilom po meri
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Vrstna montaža.
    ///
    /// Za uporabo preberite [unstable book].
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// Vrstni sestav v obliki LLVM.
    ///
    /// Za uporabo preberite [unstable book].
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Vrstni sklop na ravni modula.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Odtisi so podali tokens v standardni izhod.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Omogoči ali onemogoči funkcijo sledenja, ki se uporablja za odpravljanje napak drugih makrov.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Makro lastnosti, ki se uporablja za uporabo izpeljanih makrov.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Makro atributov, uporabljen za funkcijo, da jo spremeni v preskus enote.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Makro atributov, uporabljen za funkcijo, da jo spremeni v primerjalni test.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// Podrobnosti izvedbe makrov `#[test]` in `#[bench]`.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Makro atributov, ki je uporabljen za statiko, da ga registrirate kot globalni razdeljevalec.
    ///
    /// Glej tudi [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Ohrani element, na katerega je bila uporabljena, če je posredovana pot dostopna, in ga sicer odstrani.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Razširi vse atribute `#[cfg]` in `#[cfg_attr]` v fragmentu kode, za katerega je uporabljen.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Nestabilne podrobnosti izvedbe prevajalnika `rustc`, ne uporabljajte.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Nestabilne podrobnosti izvedbe prevajalnika `rustc`, ne uporabljajte.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}