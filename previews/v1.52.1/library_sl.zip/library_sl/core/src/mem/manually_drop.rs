use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Ovoj, ki preprečuje, da bi prevajalnik samodejno poklical T-jev destruktor.
/// Ta ovoj ima 0 stroškov.
///
/// `ManuallyDrop<T>` je podvržen enakim optimizacijam postavitve kot `T`.
/// Posledica tega je, da *ne vpliva* na predpostavke, ki jih prevajalnik poda glede njegove vsebine.
/// Inicializacija `ManuallyDrop<&mut T>` z [`mem::zeroed`] je na primer nedefinirano vedenje.
/// Če morate ravnati z neinicializiranimi podatki, raje uporabite [`MaybeUninit<T>`].
///
/// Upoštevajte, da je dostop do vrednosti znotraj `ManuallyDrop<T>` varen.
/// To pomeni, da `ManuallyDrop<T>`, katerega vsebina je bila odstranjena, ne sme biti izpostavljen prek javno varnega API-ja.
/// Ustrezno je, da `ManuallyDrop::drop` ni varen.
///
/// # `ManuallyDrop` in spustite naročilo.
///
/// Rust ima natančno določene vrednosti [drop order].
/// Če želite zagotoviti, da bodo polja ali domači podatki spuščeni v določenem vrstnem redu, prerazporedite deklaracije tako, da bo implicitni vrstni red spuščanja pravilen.
///
/// Možno je uporabiti `ManuallyDrop` za nadzor vrstnega reda spuščanja, vendar to zahteva nevarno kodo in je težko narediti pravilno, če je odvijanje.
///
///
/// Če se želite na primer prepričati, da je določeno polje izpuščeno za ostalimi, naj bo to zadnje polje strukture:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` bo izpuščen po `children`.
///     // Rust zagotavlja, da se polja spuščajo po vrstnem redu prijave.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Zavijte vrednost, ki jo želite ročno spustiti.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Še vedno lahko varno upravljate z vrednostjo
    /// assert_eq!(*x, "Hello");
    /// // Toda `Drop` tukaj ne bo deloval
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Izvleče vrednost iz vsebnika `ManuallyDrop`.
    ///
    /// To omogoča, da se vrednost znova spusti.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // To spusti `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Vzame vrednost iz vsebnika `ManuallyDrop<T>`.
    ///
    /// Ta metoda je v prvi vrsti namenjena premikanju padajočih vrednosti.
    /// Namesto da s pomočjo [`ManuallyDrop::drop`] ročno spustite vrednost, lahko s to metodo vzamete vrednost in jo uporabite, kot želite.
    ///
    /// Kadar je le mogoče, je raje namesto tega uporabiti [`into_inner`][`ManuallyDrop::into_inner`], ki preprečuje podvajanje vsebine `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Ta funkcija semantično premakne vsebovano vrednost, ne da bi preprečila nadaljnjo uporabo, stanje tega vsebnika pa ostane nespremenjeno.
    /// Vaša odgovornost je zagotoviti, da se ta `ManuallyDrop` ne bo več uporabljal.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // VARNOST: beremo iz reference, ki je zagotovljena
        // da velja za branja.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Ročno spusti vsebovano vrednost.To je popolnoma enako klicanju [`ptr::drop_in_place`] s kazalcem na vsebovano vrednost.
    /// Kot tak, razen če je vsebovana vrednost zapakirana struktura, bo destruktor poklican na mestu, ne da bi premaknil vrednost, in ga je tako mogoče uporabiti za varno spuščanje podatkov [pinned].
    ///
    /// Če ste lastnik vrednosti, lahko namesto tega uporabite [`ManuallyDrop::into_inner`].
    ///
    /// # Safety
    ///
    /// Ta funkcija zažene destruktor vsebovane vrednosti.
    /// Razen sprememb, ki jih naredi destruktor sam, ostane pomnilnik nespremenjen in tako prevajalnik še vedno vsebuje bitni vzorec, ki velja za tip `T`.
    ///
    ///
    /// Vendar te vrednosti "zombie" ne bi smeli izpostavljati varni kodi in te funkcije ne bi smeli klicati več kot enkrat.
    /// Če uporabite vrednost po tem, ko je bila spuščena, ali pa jo večkrat spustite, lahko pride do nedefiniranega vedenja (odvisno od tega, kaj `drop` počne).
    /// Tipski sistem tega običajno preprečuje, vendar morajo uporabniki `ManuallyDrop` podpirati ta jamstva brez pomoči prevajalnika.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // VARNOST: spuščamo vrednost, na katero opozarja spremenljiva referenca
        // ki je zajamčeno veljavno za zapise.
        // Klicatelj mora poskrbeti, da `slot` ne bo spet padel.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}