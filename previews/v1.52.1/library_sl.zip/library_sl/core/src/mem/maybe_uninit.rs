use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Vrsta ovoja za izdelavo neinicializiranih primerkov `T`.
///
/// # Inicializacija invariantna
///
/// Prevajalnik na splošno predpostavlja, da je spremenljivka pravilno inicializirana v skladu z zahtevami tipa spremenljivke.Na primer, spremenljivka referenčnega tipa mora biti poravnana in ne-NULL.
/// To je nespremenljiva oblika, ki jo je treba *vedno* upoštevati, tudi v nevarni kodi.
/// Posledično ničelna inicializacija spremenljivke referenčnega tipa povzroči takojšen [undefined behavior][ub], ne glede na to, ali se ta referenca kdaj navadi za dostop do pomnilnika:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // nedefinirano vedenje!⚠️
/// // Enakovredna koda z `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // nedefinirano vedenje!⚠️
/// ```
///
/// Prevajalnik to izkorišča za različne optimizacije, na primer za odstranjevanje preverjanj med izvajanjem in optimizacijo postavitve `enum`.
///
/// Podobno ima lahko popolnoma neinicializiran pomnilnik kakršno koli vsebino, medtem ko mora biti `bool` vedno `true` ali `false`.Zato je ustvarjanje neinicializiranega `bool` nedefinirano vedenje:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // nedefinirano vedenje!⚠️
/// // Enakovredna koda z `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // nedefinirano vedenje!⚠️
/// ```
///
/// Poleg tega je neinicializiran pomnilnik poseben, ker nima fiksne vrednosti ("fixed", kar pomeni "it won't change without being written to").Večkratno branje istega neinicializiranega bajta lahko daje različne rezultate.
/// Zaradi tega je nedefinirano vedenje imeti neinicializirane podatke v spremenljivki, tudi če ima ta spremenljivka celoštevilčni tip, ki sicer lahko vsebuje kateri koli *fiksni* bitni vzorec:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // nedefinirano vedenje!⚠️
/// // Enakovredna koda z `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // nedefinirano vedenje!⚠️
/// ```
/// (Upoštevajte, da pravila o neinicializiranih celih številih še niso dokončana, vendar dokler se ne uporabijo, se jim je priporočljivo izogibati.)
///
/// Poleg tega ne pozabite, da ima večina tipov še dodatne invariante, ki se ne štejejo za inicializirane na ravni tipa.
/// Na primer, inicializiran z " 1` [`Vec<T>`] se šteje za inicializiranega (v trenutni izvedbi; to ne pomeni stabilnega jamstva), ker je edina zahteva, ki jo prevajalnik o tem ve, ta, da kazalec podatkov ne sme biti nič.
/// Ustvarjanje takega `Vec<T>` ne povzroči *takojšnjega* nedefiniranega vedenja, vendar bo povzročilo nedefinirano vedenje pri najbolj varnih operacijah (vključno s tem, da ga spustite).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` služi za omogočanje nevarni kodi za obdelavo neinicializiranih podatkov.
/// To je signal prevajalniku, ki označuje, da se podatki tukaj *ne* inicializirajo:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Ustvarite izrecno neinicializirano referenco.
/// // Prevajalnik ve, da so podatki znotraj `MaybeUninit<T>` morda neveljavni, zato to ni UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Nastavite na veljavno vrednost.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Izvlecite inicializirane podatke-to je dovoljeno *samo po* pravilno inicializaciji `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Nato prevajalnik ve, da za to kodo ne podaja napačnih predpostavk ali optimizacij.
///
/// Za `MaybeUninit<T>` si lahko mislite, da je nekoliko podoben `Option<T>`, vendar brez sledenja med izvajanjem in brez kakršnih koli varnostnih pregledov.
///
/// ## out-pointers
///
/// Za implementacijo "out-pointers" lahko uporabite `MaybeUninit<T>`: namesto da bi podatke vrnili iz funkcije, mu dodajte kazalec na nekaj pomnilnika (uninitialized), v katerega želite vnesti rezultat.
/// To je lahko koristno, kadar je za klicatelja pomembno, kako nadzira, kako se dodeli pomnilnik, v katerem je shranjen rezultat, in se želite izogniti nepotrebnim premikom.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` ne spusti stare vsebine, kar je pomembno.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Zdaj vemo, da je `v` inicializiran!To tudi zagotavlja, da se vector pravilno spusti.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Inicializacija polja po elementih
///
/// `MaybeUninit<T>` se lahko uporablja za inicializacijo velikega polja element po element:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Ustvarite neinicializirano polje `MaybeUninit`.
///     // `assume_init` je varen, ker je vrsta, za katero trdimo, da je tu inicializirana, vrsta "MaybeUninit", ki ne zahteva inicializacije.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Če spustite `MaybeUninit`, to nič ne pomeni.
///     // Tako uporaba surove dodelitve kazalca namesto `ptr::write` ne povzroči, da bi stara neinicializirana vrednost odpadla.
/////
///     // Tudi če med to zanko obstaja panic, nam pušča pomnilnik, vendar ni vprašanja o varnosti pomnilnika.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Vse je inicializirano.
///     // Pretvori matriko v inicializiran tip.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Delate lahko tudi z delno inicializiranimi nizi, ki jih lahko najdemo v nizko nivojskih podatkovnih strukturah.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Ustvarite neinicializirano polje `MaybeUninit`.
/// // `assume_init` je varen, ker je vrsta, za katero trdimo, da je tu inicializirana, vrsta "MaybeUninit", ki ne zahteva inicializacije.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Preštejte število elementov, ki smo jih dodelili.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Za vsak element v matriki spustite, če smo ga dodelili.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Inicializacija strukture po polju
///
/// Za inicializacijo struktur lahko polje po polje uporabite `MaybeUninit<T>` in makro [`std::ptr::addr_of_mut`]:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Inicializacija polja `name`
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Inicializacija polja `list` Če je tu panic, potem `String` v polju `name` pušča.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Vsa polja so inicializirana, zato pokličemo `assume_init`, da dobimo inicializiran Foo.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` ima zajamčeno enako velikost, poravnavo in ABI kot `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Vendar ne pozabite, da tip *, ki vsebuje*`MaybeUninit<T>`, ni nujno enake postavitve;Rust na splošno ne zagotavlja, da imajo polja `Foo<T>` enak vrstni red kot `Foo<U>`, tudi če imata `T` in `U` enako velikost in poravnavo.
///
/// Poleg tega, ker je katera koli bitna vrednost veljavna za `MaybeUninit<T>`, prevajalnik ne more uporabiti optimizacij non-zero/niche-filling, kar lahko povzroči večjo velikost:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Če je `T` varen za FFI, je tudi `MaybeUninit<T>`.
///
/// Medtem ko je `MaybeUninit` `#[repr(transparent)]` (kar pomeni, da zagotavlja enako velikost, poravnavo in ABI kot `T`), to *ne* spremeni nobenega od prejšnjih opozoril.
/// `Option<T>` in `Option<MaybeUninit<T>>` ima lahko še vedno različne velikosti, tipi, ki vsebujejo polje tipa `T`, pa so lahko postavljeni (in velikosti) drugače, kot če bi bilo to polje `MaybeUninit<T>`.
/// `MaybeUninit` je vrsta zveze, `#[repr(transparent)]` na zvezah pa je nestabilen (glej [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Sčasoma se lahko natančna jamstva za `#[repr(transparent)]` za sindikate razvijejo in `MaybeUninit` lahko ostane ali ne `#[repr(transparent)]`.
/// Kljub temu bo `MaybeUninit<T>`*vedno* zagotovil, da ima enako velikost, poravnavo in ABI kot `T`;samo način, kako `MaybeUninit` izvaja to garancijo, se lahko razvije.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang element, da vanj lahko zavijemo druge vrste.To je koristno za generatorje.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Če ne pokličemo `T::clone()`, ne moremo vedeti, ali smo dovolj inicializirani za to.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Ustvari nov `MaybeUninit<T>`, inicializiran z dano vrednostjo.
    /// Varno je poklicati [`assume_init`] za povratno vrednost te funkcije.
    ///
    /// Upoštevajte, da spuščanje `MaybeUninit<T>` ne bo nikoli poklicalo spustne kode T-ja.
    /// Vaša odgovornost je zagotoviti, da `T` pade, če je bil inicializiran.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Ustvari nov `MaybeUninit<T>` v neinicializiranem stanju.
    ///
    /// Upoštevajte, da spuščanje `MaybeUninit<T>` ne bo nikoli poklicalo spustne kode T-ja.
    /// Vaša odgovornost je zagotoviti, da `T` pade, če je bil inicializiran.
    ///
    /// Za nekaj primerov glejte [type-level documentation][MaybeUninit].
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Ustvarite novo polje elementov `MaybeUninit<T>` v neinicializiranem stanju.
    ///
    /// Note: v različici future Rust lahko ta metoda postane nepotrebna, če sintaksa dobesedne matrike omogoča [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// V spodnjem primeru bi nato lahko uporabili `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Vrne (morda manjšo) rezino podatkov, ki je bila dejansko prebrana
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // VARNOST: Neinicializiran `[MaybeUninit<_>; LEN]` je veljaven.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Ustvari nov `MaybeUninit<T>` v neinicializiranem stanju, pri čemer je pomnilnik napolnjen z bajti `0`.Od `T` je odvisno, ali to že omogoča pravilno inicializacijo.
    ///
    /// Na primer, `MaybeUninit<usize>::zeroed()` je inicializiran, `MaybeUninit<&'static i32>::zeroed()` pa ne, ker sklici ne smejo biti ničli.
    ///
    /// Upoštevajte, da spuščanje `MaybeUninit<T>` ne bo nikoli poklicalo spustne kode T-ja.
    /// Vaša odgovornost je zagotoviti, da `T` pade, če je bil inicializiran.
    ///
    /// # Example
    ///
    /// Pravilna uporaba te funkcije: inicializiranje strukture z ničlo, kjer lahko vsa polja strukture vsebujejo bitni vzorec 0 kot veljavno vrednost.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Nepravilna* uporaba te funkcije: klic `x.zeroed().assume_init()`, kadar `0` ni veljaven bitni vzorec za tip:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // V paru ustvarimo `NotZero`, ki nima veljavnega diskriminanta.
    /// // To je nedefinirano vedenje.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // VARNOST: `u.as_mut_ptr()` kaže na dodeljeni pomnilnik.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Nastavi vrednost `MaybeUninit<T>`.
    /// To prepiše katero koli prejšnjo vrednost, ne da bi jo spustili, zato pazite, da je ne uporabite dvakrat, razen če želite preskočiti zagon destruktorja.
    ///
    /// Za vaše udobje vrne tudi spremenljiv sklic na (zdaj varno inicializirano) vsebino `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // VARNOST: To vrednost smo pravkar inicializirali.
        unsafe { self.assume_init_mut() }
    }

    /// Pridobi kazalec na vsebovano vrednost.
    /// Branje iz tega kazalca ali spreminjanje v sklic je nedefinirano vedenje, razen če je `MaybeUninit<T>` inicializiran.
    /// Zapis v pomnilnik, na katerega kaže ta kazalec (non-transitively), je nedefinirano vedenje (razen znotraj `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Pravilna uporaba te metode:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Ustvarite referenco na `MaybeUninit<T>`.To je v redu, ker smo ga inicializirali.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Nepravilna* uporaba te metode:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Ustvarili smo sklic na neinicializiran vector!To je nedefinirano vedenje.⚠️
    /// ```
    ///
    /// (Upoštevajte, da pravila glede sklicevanja na neinicializirane podatke še niso dokončana, vendar se jih je priporočljivo izogibati, dokler niso).)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` in `ManuallyDrop` sta oba `repr(transparent)`, tako da lahko predvajamo kazalec.
        self as *const _ as *const T
    }

    /// Pridobi spremenljiv kazalec na vsebovano vrednost.
    /// Branje iz tega kazalca ali spreminjanje v sklic je nedefinirano vedenje, razen če je `MaybeUninit<T>` inicializiran.
    ///
    /// # Examples
    ///
    /// Pravilna uporaba te metode:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Ustvarite referenco na `MaybeUninit<Vec<u32>>`.
    /// // To je v redu, ker smo ga inicializirali.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Nepravilna* uporaba te metode:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Ustvarili smo sklic na neinicializiran vector!To je nedefinirano vedenje.⚠️
    /// ```
    ///
    /// (Upoštevajte, da pravila glede sklicevanja na neinicializirane podatke še niso dokončana, vendar se jih je priporočljivo izogibati, dokler niso).)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` in `ManuallyDrop` sta oba `repr(transparent)`, tako da lahko predvajamo kazalec.
        self as *mut _ as *mut T
    }

    /// Izvleče vrednost iz vsebnika `MaybeUninit<T>`.To je odličen način, da zagotovite, da bodo podatki izpadli, ker nastali `T` velja za običajno ravnanje s spuščanjem.
    ///
    /// # Safety
    ///
    /// Klicatelj mora zagotoviti, da je `MaybeUninit<T>` res v inicializiranem stanju.Če pokličete to, ko vsebina še ni popolnoma inicializirana, se povzroči nedefinirano vedenje
    /// [type-level documentation][inv] vsebuje več informacij o tej invariaciji inicializacije.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Poleg tega ne pozabite, da ima večina tipov še dodatne invariante, ki se ne štejejo za inicializirane na ravni tipa.
    /// Na primer, inicializiran z " 1` [`Vec<T>`] se šteje za inicializiranega (v trenutni izvedbi; to ne pomeni stabilnega jamstva), ker je edina zahteva, ki jo prevajalnik o tem ve, ta, da kazalec podatkov ne sme biti nič.
    ///
    /// Ustvarjanje takega `Vec<T>` ne povzroči *takojšnjega* nedefiniranega vedenja, vendar bo povzročilo nedefinirano vedenje pri najbolj varnih operacijah (vključno s tem, da ga spustite).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Pravilna uporaba te metode:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Nepravilna* uporaba te metode:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` še ni bila inicializirana, zato je ta zadnja vrstica povzročila nedefinirano vedenje.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // VARNOST: klicatelj mora zagotoviti, da je `self` inicializiran.
        // To tudi pomeni, da mora biti `self` različica `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Prebere vrednost iz vsebnika `MaybeUninit<T>`.Nastali `T` je predmet običajnega ravnanja s padci.
    ///
    /// Kadar je le mogoče, je raje namesto tega uporabiti [`assume_init`], ki preprečuje podvajanje vsebine `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Klicatelj mora zagotoviti, da je `MaybeUninit<T>` res v inicializiranem stanju.Če pokličete to, ko vsebina še ni popolnoma inicializirana, pride do nedefiniranega vedenja.
    /// [type-level documentation][inv] vsebuje več informacij o tej invariaciji inicializacije.
    ///
    /// Poleg tega ostane v `MaybeUninit<T>` kopija istih podatkov.
    /// Če uporabljate več kopij podatkov (tako, da večkrat pokličete `assume_init_read` ali najprej pokličete `assume_init_read` in nato [`assume_init`]), ste odgovorni, da zagotovite, da se ti podatki res lahko podvojijo.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Pravilna uporaba te metode:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` je `Copy`, zato lahko beremo večkrat.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Podvajanje vrednosti `None` je v redu, zato lahko beremo večkrat.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Nepravilna* uporaba te metode:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Zdaj smo ustvarili dve kopiji istega vector, kar je povzročilo dvojno brezplačno ⚠️, ko obe padeta!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // VARNOST: klicatelj mora zagotoviti, da je `self` inicializiran.
        // Branje iz `self.as_ptr()` je varno, saj je treba `self` inicializirati.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Spusti vsebovano vrednost na svoje mesto.
    ///
    /// Če ste lastnik `MaybeUninit`, lahko namesto njega uporabite [`assume_init`].
    ///
    /// # Safety
    ///
    /// Klicatelj mora zagotoviti, da je `MaybeUninit<T>` res v inicializiranem stanju.Če pokličete to, ko vsebina še ni popolnoma inicializirana, pride do nedefiniranega vedenja.
    ///
    /// Poleg tega morajo biti izpolnjeni vsi dodatni invarianti tipa `T`, saj se lahko izvedba `Drop` `T` (ali njenih članov) na to zanese.
    /// Na primer, inicializiran z " 1` [`Vec<T>`] se šteje za inicializiranega (v trenutni izvedbi; to ne pomeni stabilnega jamstva), ker je edina zahteva, ki jo prevajalnik o tem ve, ta, da kazalec podatkov ne sme biti nič.
    ///
    /// Spuščanje takega `Vec<T>` pa bo povzročilo nedefinirano vedenje.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // VARNOST: klicatelj mora zagotoviti, da je `self` inicializiran in
        // zadovoljuje vse invariante `T`.
        // Spuščanje vrednosti na mestu je varno, če je temu tako.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Pridobi sklic v skupni rabi na vsebovano vrednost.
    ///
    /// To je lahko koristno, če želimo dostopati do `MaybeUninit`, ki je bil inicializiran, vendar nima lastništva `MaybeUninit` (preprečuje uporabo `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Če pokličete to, ko vsebina še ni popolnoma inicializirana, pride do nedefiniranega vedenja: klicatelj mora zagotoviti, da je `MaybeUninit<T>` res v inicializiranem stanju.
    ///
    ///
    /// # Examples
    ///
    /// ### Pravilna uporaba te metode:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Inicializirajte `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Zdaj, ko je znano, da je naš `MaybeUninit<_>` inicializiran, je prav, da nanj ustvarimo referenco v skupni rabi:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // VARNOST: `x` je bil inicializiran.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Nepravilna* uporaba te metode:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Ustvarili smo sklic na neinicializiran vector!To je nedefinirano vedenje.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Inicializirajte `MaybeUninit` s pomočjo `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Sklic na neinicializiran `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // VARNOST: klicatelj mora zagotoviti, da je `self` inicializiran.
        // To tudi pomeni, da mora biti `self` različica `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Pridobi spremenljiv sklic (unique) na vsebovano vrednost.
    ///
    /// To je lahko koristno, če želimo dostopati do `MaybeUninit`, ki je bil inicializiran, vendar nima lastništva `MaybeUninit` (preprečuje uporabo `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Če pokličete to, ko vsebina še ni popolnoma inicializirana, pride do nedefiniranega vedenja: klicatelj mora zagotoviti, da je `MaybeUninit<T>` res v inicializiranem stanju.
    /// Na primer, `.assume_init_mut()` ni mogoče uporabiti za inicializacijo `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Pravilna uporaba te metode:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Inicializira *vse* bajte vhodnega vmesnega pomnilnika.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Inicializirajte `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Zdaj vemo, da je bil `buf` inicializiran, zato bi ga lahko `.assume_init()`.
    /// // Vendar lahko uporaba `.assume_init()` sproži `memcpy` od 2048 bajtov.
    /// // Če želimo trditi, da je bil vmesnik inicializiran, ne da bi ga kopirali, nadgradimo `&mut MaybeUninit<[u8; 2048]>` na `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // VARNOST: `buf` je bil inicializiran.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Zdaj lahko `buf` uporabljamo kot običajno rezino:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Nepravilna* uporaba te metode:
    ///
    /// Za inicializiranje vrednosti ne morete uporabiti `.assume_init_mut()`:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Ustvarili smo referenco (mutable) na neinicializiran `bool`!
    ///     // To je nedefinirano vedenje.⚠️
    /// }
    /// ```
    ///
    /// Na primer, ne morete [`Read`] v neinicializirani vmesnik:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) sklic na neinicializiran spomin!
    ///                             // To je nedefinirano vedenje.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Prav tako ne morete uporabljati neposrednega dostopa do polja za postopno inicializacijo od polja do polja:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) sklic na neinicializiran spomin!
    ///                  // To je nedefinirano vedenje.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) sklic na neinicializiran spomin!
    ///                  // To je nedefinirano vedenje.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Trenutno se zanašamo, da je zgoraj navedeno napačno, tj. Imamo sklice na neinicializirane podatke (npr. V `libcore/fmt/float.rs`).
    // Končno odločitev o pravilih bi morali sprejeti pred stabilizacijo.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // VARNOST: klicatelj mora zagotoviti, da je `self` inicializiran.
        // To tudi pomeni, da mora biti `self` različica `value`.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Izvleče vrednosti iz niza vsebnikov `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Klicatelj mora zagotoviti, da so vsi elementi polja v inicializiranem stanju.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // VARNOST: Zdaj varno, saj smo inicializirali vse elemente
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Klicatelj zagotavlja, da so vsi elementi polja inicializirani
        // * `MaybeUninit<T>` in T imata zagotovljeno enako postavitev
        // * MogočeUnint ne pade, zato ni dvojnih sprostitev in tako je pretvorba varna
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Ob predpostavki, da so vsi elementi inicializirani, jim priskrbite rezino.
    ///
    /// # Safety
    ///
    /// Klicatelj mora zagotoviti, da so elementi `MaybeUninit<T>` res v inicializiranem stanju.
    ///
    /// Če pokličete to, ko vsebina še ni popolnoma inicializirana, pride do nedefiniranega vedenja.
    ///
    /// Za več podrobnosti in primere glejte [`assume_init_ref`].
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // VARNOST: oddajanje rezine na `*const [T]` je varno, saj klicatelj to zagotavlja
        // `slice` je inicializiran in ima "MaybeUninit" enako postavitev kot `T`.
        // Pridobljeni kazalnik je veljaven, saj se nanaša na pomnilnik v lasti `slice`, ki je referenčni in je tako zagotovljeno veljaven za branje.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Ob predpostavki, da so vsi elementi inicializirani, jim zagotovite spremenljivo rezino.
    ///
    /// # Safety
    ///
    /// Klicatelj mora zagotoviti, da so elementi `MaybeUninit<T>` res v inicializiranem stanju.
    ///
    /// Če pokličete to, ko vsebina še ni popolnoma inicializirana, pride do nedefiniranega vedenja.
    ///
    /// Za več podrobnosti in primere glejte [`assume_init_mut`].
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // VARNOST: podobno kot pri varnostnih opozorilih za `slice_get_ref`, vendar imamo a
        // spremenljiva referenca, za katero je zagotovljeno, da velja tudi za zapise.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Pridobi kazalnik na prvi element polja.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Pridobi spremenljiv kazalec na prvi element polja.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Kopira elemente iz `src` v `this` in vrne spremenljiv sklic na zdaj začeto vsebino `this`.
    ///
    /// Če `T` ne izvaja `Copy`, uporabite [`write_slice_cloned`]
    ///
    /// To je podobno kot pri [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Ta funkcija bo panic, če imata rezini različno dolžino.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // VARNOST: pravkar smo kopirali vse elemente lena v prosto zmogljivost
    /// // prvi elementi src.len() vec so zdaj veljavni.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // VARNOST: &[T] in&[MaybeUninit<T>] imajo enako postavitev
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // VARNOST: Veljavni elementi so bili pravkar kopirani v `this`, zato je začet
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Klonira elemente iz `src` v `this` in vrne spremenljiv sklic na zdaj začeto vsebino `this`.
    /// Vsi že začetni elementi ne bodo izpuščeni.
    ///
    /// Če `T` implementira `Copy`, uporabite [`write_slice`]
    ///
    /// To je podobno kot pri [`slice::clone_from_slice`], vendar ne izpusti obstoječih elementov.
    ///
    /// # Panics
    ///
    /// Ta funkcija bo panic, če imata dve rezini različno dolžino ali če je izvedba `Clone` panics.
    ///
    /// Če obstaja panic, bodo že klonirani elementi odstranjeni.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // VARNOST: pravkar smo klonirali vse elemente lena v prosto zmogljivost
    /// // prvi elementi src.len() vec so zdaj veljavni.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // za razliko od copy_from_slice to na rezini ne prikliče clone_from_slice, ker `MaybeUninit<T: Clone>` ne izvaja Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // VARNOST: ta surova rezina bo vsebovala samo inicializirane predmete
                // zato ga je dovoljeno spustiti.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Izrecno jih moramo razrezati na enako dolžino
        // za preverjanje mej, ki jih je treba izbrisati, in optimizator bo ustvaril memcpy za preproste primere (na primer T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // potrebna je zaščita b/c panic se lahko zgodi med kloniranjem
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // VARNOST: Veljavni elementi so bili pravkar zapisani v `this`, zato je začet
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}