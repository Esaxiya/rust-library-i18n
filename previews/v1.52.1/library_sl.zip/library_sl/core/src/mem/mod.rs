//! Osnovne funkcije za ravnanje s spominom.
//!
//! Ta modul vsebuje funkcije za poizvedovanje po velikosti in poravnavi vrst, inicializacijo in upravljanje pomnilnika.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Prevzame lastništvo in "forgets" o vrednosti **, ne da bi zagnala njen destruktor**.
///
/// Vsi viri, ki jih upravlja vrednost, na primer pomnilnik kopice ali ročaj datoteke, bodo za vedno ostali v nedosegljivem stanju.Vendar ne zagotavlja, da bodo kazalci na ta spomin ostali veljavni.
///
/// * Če želite puščati pomnilnik, glejte [`Box::leak`].
/// * Če želite dobiti neobdelan kazalec na pomnilnik, glejte [`Box::into_raw`].
/// * Če želite vrednost pravilno odstraniti z zagonom njenega destruktorja, glejte [`mem::drop`].
///
/// # Safety
///
/// `forget` ni označen kot `unsafe`, ker varnostna jamstva Rust ne vključujejo zagotovila, da bodo destruktorji vedno delovali.
/// Na primer, program lahko ustvari referenčni cikel z uporabo [`Rc`][rc] ali pokliče [`process::exit`][exit] za izhod brez zagonu destruktorjev.
/// Dovoljenje varne kode `mem::forget` torej bistveno ne spremeni varnostnih zagotovil Rust.
///
/// Kljub temu pa uhajanje virov, kot so pomnilnik ali predmeti I/O, običajno ni zaželeno.
/// Potreba se pojavi v nekaterih posebnih primerih uporabe FFI ali nevarne kode, toda tudi takrat je običajno prednost [`ManuallyDrop`].
///
/// Ker je pozabitev vrednosti dovoljena, mora vsaka koda `unsafe`, ki jo napišete, to možnost omogočiti.Vrednosti ne morete vrniti in pričakujte, da bo klicatelj nujno zagnal destruktor vrednosti.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Kanonična varna uporaba `mem::forget` je izogibanje destruktorju vrednosti, ki ga izvaja `Drop` Portrait.Tako bo na primer puščal `File`, tj
/// povrnite prostor, ki ga zavzame spremenljivka, vendar nikoli ne zaprite osnovnega sistemskega vira:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// To je koristno, če je bilo lastništvo osnovnega vira predhodno preneseno na kodo zunaj Rust, na primer s prenosom deskriptorja surove datoteke v kodo C.
///
/// # Povezava z `ManuallyDrop`
///
/// Medtem ko je `mem::forget` mogoče uporabiti tudi za prenos lastništva *pomnilnika*, je to nagnjeno k napakam.
/// [`ManuallyDrop`] namesto tega.Upoštevajte na primer to kodo:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Zgradite `String` z uporabo vsebine `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // pušča `v`, ker njegov pomnilnik zdaj upravlja `s`
/// mem::forget(v);  // NAPAKA, v je neveljaven in se ne sme posredovati funkciji
/// assert_eq!(s, "Az");
/// // `s` je implicitno izpuščen in pomnilnik razdeljen.
/// ```
///
/// Zgornji primer ima dve težavi:
///
/// * Če bi med konstrukcijo `String` in priklicem `mem::forget()` dodali več kode, bi panic v njej povzročil dvojno brezplačno, ker z istim pomnilnikom upravljata `v` in `s`.
/// * Po klicu `v.as_mut_ptr()` in prenosu lastništva podatkov na `s` je vrednost `v` neveljavna.
/// Tudi ko je vrednost pravkar premaknjena v `mem::forget` (ki je ne bo pregledal), imajo nekatere vrste za svoje vrednosti stroge zahteve, zaradi katerih postanejo neveljavne, ko so viseče ali niso več v lasti.
/// Kakršna koli uporaba neveljavnih vrednosti, vključno s posredovanjem ali vrnitvijo iz funkcij, predstavlja nedefinirano vedenje in lahko krši predpostavke, ki jih poda prevajalnik.
///
/// S prehodom na `ManuallyDrop` se izognete obema težavama:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Preden `v` razstavimo na surove dele, se prepričajte, da ne pade!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Zdaj razstavite `v`.Te operacije ne morejo panic, zato ne more priti do puščanja.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Končno zgradite `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` je implicitno izpuščen in pomnilnik razdeljen.
/// ```
///
/// `ManuallyDrop` robustno preprečuje dvojno uporabo, ker onemogočimo destruktor `v`, preden naredimo kar koli drugega.
/// `mem::forget()` tega ne dovoli, ker porabi svoj argument in nas prisili, da ga pokličemo šele po tem, ko iz `v` izvlečemo kar koli, kar potrebujemo.
/// Tudi če bi med konstrukcijo `ManuallyDrop` in gradnjo niza uvedli panic (kar se v kodi ne more zgoditi, kot je prikazano), bi to povzročilo puščanje in ne dvojno prosti.
/// Z drugimi besedami, `ManuallyDrop` se zmoti na strani puščanja, namesto da bi se zmotil na strani (dvojnega) padca.
///
/// Poleg tega nam `ManuallyDrop` preprečuje, da bi morali imeti "touch" `v` po prenosu lastništva na `s`-zadnji korak interakcije z `v` za njegovo odstranjevanje brez zagona njegovega destruktorja se popolnoma izogne.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Tako kot [`forget`], vendar sprejema tudi velikosti.
///
/// Ta funkcija je le podloga, ki jo je treba odstraniti, ko se funkcija `unsized_locals` stabilizira.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Vrne velikost vrste v bajtih.
///
/// Natančneje, to je odmik v bajtih med zaporednimi elementi v matriki s to vrsto elementa, vključno z oblazinjenjem poravnave.
///
/// Tako ima `[T; n]` za kateri koli tip `T` in dolžino `n` velikost `n * size_of::<T>()`.
///
/// Na splošno velikost tipa ni stabilna pri kompilacijah, so pa določene vrste, na primer primitivi.
///
/// Naslednja tabela prikazuje velikost primitivov.
///
/// Vnesite |velikost: :<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 znakov |4.
///
/// Poleg tega imata `usize` in `isize` enako velikost.
///
/// Vsi tipi `*const T`, `&T`, `Box<T>`, `Option<&T>` in `Option<Box<T>>` imajo enako velikost.
/// Če je velikost `T` velikost, imajo vsi tipi enako velikost kot `usize`.
///
/// Spremenljivost kazalca ne spremeni njegove velikosti.Kot taka imata `&T` in `&mut T` enako velikost.
/// Prav tako za `*const T` in `* mut T`.
///
/// # Velikost predmetov `#[repr(C)]`
///
/// Predstavitev `C` za postavke ima določeno postavitev.
/// S to postavitvijo je tudi velikost elementov stabilna, če imajo vsa polja stabilno velikost.
///
/// ## Velikost struktur
///
/// Za `structs` je velikost določena z naslednjim algoritmom.
///
/// Za vsako polje v strukturi, razvrščeni po vrstnem redu deklaracije:
///
/// 1. Dodajte velikost polja.
/// 2. Trenutno velikost zaokroži na najbližji večkratnik naslednjega polja [alignment].
///
/// Končno zaokrožite velikost strukture na najbližji večkratnik [alignment].
/// Poravnava strukture je običajno največja poravnava vseh njegovih polj;to lahko spremenite z uporabo `repr(align(N))`.
///
/// Za razliko od `C` strukture ničelne velikosti niso zaokrožene na en bajt.
///
/// ## Velikost enumov
///
/// Enumi, ki ne vsebujejo nobenih drugih podatkov razen diskriminante, imajo enako velikost kot enumi C na platformi, za katero so prevedeni.
///
/// ## Velikost sindikatov
///
/// Velikost zveze je velikost njenega največjega polja.
///
/// Za razliko od `C` združitve ničelnih velikosti niso zaokrožene na en bajt.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Nekaj primitivcev
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Nekaj nizov
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Enakost velikosti kazalca
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Uporaba `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Velikost prvega polja je 1, zato velikosti dodajte 1.Velikost je 1.
/// // Poravnava drugega polja je 2, zato dodajte 1 velikosti za oblazinjenje.Velikost je 2.
/// // Velikost drugega polja je 2, zato velikosti dodajte 2.Velikost je 4.
/// // Poravnava tretjega polja je 1, zato dodajte 0 velikosti za oblazinjenje.Velikost je 4.
/// // Velikost tretjega polja je 1, zato velikosti dodajte 1.Velikost je 5.
/// // Na koncu je poravnava strukture 2 (ker je največja poravnava med njenimi polji 2), zato dodajte 1 velikosti za oblazinjenje.
/// // Velikost je 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Strukture tuple sledijo istim pravilom.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Upoštevajte, da lahko preurejanje polj zmanjša velikost.
/// // Oba bajta za oblazinjenje lahko odstranimo tako, da `third` postavimo pred `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Velikost Unije je velikost največjega polja.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Vrne velikost usmerjene vrednosti v bajtih.
///
/// To je običajno enako kot `size_of::<T>()`.
/// Kadar pa `T`*nima* statično znane velikosti, npr. Rezine [`[T]`][slice] ali [trait object], lahko `size_of_val` uporabimo za pridobitev dinamično znane velikosti.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // VARNOST: `val` je referenca, zato je veljaven surovi kazalec
    unsafe { intrinsics::size_of_val(val) }
}

/// Vrne velikost usmerjene vrednosti v bajtih.
///
/// To je običajno enako kot `size_of::<T>()`.Kadar pa `T`*nima* statično znane velikosti, npr. Rezine [`[T]`][slice] ali [trait object], lahko `size_of_val_raw` uporabimo za pridobitev dinamično znane velikosti.
///
/// # Safety
///
/// To funkcijo lahko varno pokličete le, če izpolnjujejo naslednje pogoje:
///
/// - Če je `T` `Sized`, je to funkcijo vedno varno poklicati.
/// - Če je nerezerviran rep `T`:
///     - [slice], potem mora biti dolžina repa rezine inicializirano celo število, velikost *celotne vrednosti*(dinamična dolžina repa + statično velika predpona) pa mora ustrezati `isize`.
///     - [trait object], mora nato kazalec vtable kazati na veljaven vtable, pridobljen s prisilo za zmanjšanje velikosti, velikost *celotne vrednosti*(dinamična dolžina repa + statično velika predpona) pa mora ustrezati `isize`.
///
///     - (unstable) [extern type], potem je to funkcijo vedno varno poklicati, vendar lahko panic ali drugače vrne napačno vrednost, saj postavitev zunanjega tipa ni znana.
///     To je enako vedenje kot [`size_of_val`] pri sklicevanju na tip z repom zunanjega tipa.
///     - v nasprotnem primeru te funkcije ni dovoljeno poklicati.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // VARNOST: klicatelj mora navesti veljaven surovi kazalec
    unsafe { intrinsics::size_of_val(val) }
}

/// Vrne minimalno poravnavo tipa, ki jo zahteva [ABI].
///
/// Vsako sklicevanje na vrednost tipa `T` mora biti večkratnik tega števila.
///
/// To je poravnava, ki se uporablja za strukturna polja.Morda je manjša od želene poravnave.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Vrne minimalno poravnavo vrste vrednosti, na katero kaže `val`, ki jo zahteva [ABI].
///
/// Vsako sklicevanje na vrednost tipa `T` mora biti večkratnik tega števila.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // VARNOST: val je referenca, zato je veljaven surovi kazalec
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Vrne minimalno poravnavo tipa, ki jo zahteva [ABI].
///
/// Vsako sklicevanje na vrednost tipa `T` mora biti večkratnik tega števila.
///
/// To je poravnava, ki se uporablja za strukturna polja.Morda je manjša od želene poravnave.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Vrne minimalno poravnavo vrste vrednosti, na katero kaže `val`, ki jo zahteva [ABI].
///
/// Vsako sklicevanje na vrednost tipa `T` mora biti večkratnik tega števila.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // VARNOST: val je referenca, zato je veljaven surovi kazalec
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Vrne minimalno poravnavo vrste vrednosti, na katero kaže `val`, ki jo zahteva [ABI].
///
/// Vsako sklicevanje na vrednost tipa `T` mora biti večkratnik tega števila.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// To funkcijo lahko varno pokličete le, če izpolnjujejo naslednje pogoje:
///
/// - Če je `T` `Sized`, je to funkcijo vedno varno poklicati.
/// - Če je nerezerviran rep `T`:
///     - [slice], potem mora biti dolžina repa rezine inicializirano celo število, velikost *celotne vrednosti*(dinamična dolžina repa + statično velika predpona) pa mora ustrezati `isize`.
///     - [trait object], mora nato kazalec vtable kazati na veljaven vtable, pridobljen s prisilo za zmanjšanje velikosti, velikost *celotne vrednosti*(dinamična dolžina repa + statično velika predpona) pa mora ustrezati `isize`.
///
///     - (unstable) [extern type], potem je to funkcijo vedno varno poklicati, vendar lahko panic ali drugače vrne napačno vrednost, saj postavitev zunanjega tipa ni znana.
///     To je enako vedenje kot [`align_of_val`] pri sklicevanju na tip z repom zunanjega tipa.
///     - v nasprotnem primeru te funkcije ni dovoljeno poklicati.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // VARNOST: klicatelj mora navesti veljaven surovi kazalec
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Vrne `true`, če so pomembne spuščene vrednosti tipa `T`.
///
/// To je zgolj namig za optimizacijo in se lahko izvaja konzervativno:
/// lahko vrne `true` za vrste, ki jih dejansko ni treba opustiti.
/// Kot tak bi bila vedno vrnitev `true` veljavna izvedba te funkcije.Če pa ta funkcija dejansko vrne `false`, ste prepričani, da spuščanje `T` nima stranskih učinkov.
///
/// Nizkorazredne izvedbe stvari, kot so zbirke, ki morajo ročno spustiti svoje podatke, bi se morale s to funkcijo izogibati nepotrebnim poskusom spuščanja vse njihove vsebine, ko so uničene.
///
/// To morda ne bo spremenilo zgradb izdaje (kjer zanko, ki nima stranskih učinkov, zlahka zaznamo in odpravimo), je pa pogosto velika zmaga pri gradnji napak.
///
/// Upoštevajte, da [`drop_in_place`] to preverjanje že izvaja, zato, če lahko vašo delovno obremenitev zmanjšate na nekaj majhnih številk klicev [`drop_in_place`], uporaba tega ni potrebna.
/// Zlasti upoštevajte, da lahko [`drop_in_place`] rezino, ki bo opravil eno samo preverjanje potrebe_kapljice za vse vrednosti.
///
/// Tipi, kot je Vec, torej samo `drop_in_place(&mut self[..])`, ne da bi izrecno uporabljali `needs_drop`.
/// Vrste, kot je [`HashMap`], pa morajo vrednosti zniževati eno za drugo in bi morali uporabljati ta API.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Tu je primer, kako lahko zbirka uporablja `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // spustite podatke
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Vrne vrednost tipa `T`, ki jo predstavlja bajt vzorec nič.
///
/// To pomeni, da na primer bajt za oblazinjenje v `(u8, u16)` ni nujno nič.
///
/// Nobenega zagotovila ni, da vzorec bajtov z ničlo predstavlja veljavno vrednost neke vrste `T`.
/// Na primer, ničelni bajtni vzorec ni veljavna vrednost za referenčne vrste (`&T`, `&mut T`) in kazalce funkcij.
/// Uporaba `zeroed` pri takih vrstah povzroči takojšen [undefined behavior][ub], ker [the Rust compiler assumes][inv], da je v spremenljivki, ki jo šteje za inicializirano, vedno veljavna vrednost.
///
///
/// To ima enak učinek kot [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Včasih je koristno za FFI, vendar se mu je na splošno treba izogibati.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Pravilna uporaba te funkcije: inicializacija celotnega števila z ničlo.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Nepravilna* uporaba te funkcije: inicializacija sklica z ničlo.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Nedefinirano vedenje!
/// let _y: fn() = unsafe { mem::zeroed() }; // In spet!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // VARNOST: klicatelj mora zagotoviti, da za `T` velja vrednost nič nič.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Obide običajne preglede za inicializacijo pomnilnika Rust tako, da se pretvarja, da proizvaja vrednost tipa `T`, pri tem pa ničesar ne naredi.
///
/// **Ta funkcija je zastarela.** Namesto tega uporabite [`MaybeUninit<T>`].
///
/// Razlog za opustitev je v tem, da funkcije v bistvu ni mogoče pravilno uporabljati: ima enak učinek kot [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Kot pojasnjuje [`assume_init` documentation][assume_init], so [the Rust compiler assumes][inv] te vrednosti pravilno inicializirane.
/// Posledično klicanje npr
/// `mem::uninitialized::<bool>()` povzroči takojšnje nedefinirano vedenje za vrnitev `bool`, ki zagotovo ni niti `true` niti `false`.
/// Še huje, resnično neinicializiran pomnilnik, kot je to, kar se vrne sem, je poseben v tem, da prevajalnik ve, da nima fiksne vrednosti.
/// Zaradi tega je nedefinirano vedenje imeti neinicializirane podatke v spremenljivki, tudi če ima ta spremenljivka celoštevilski tip.
/// (Upoštevajte, da pravila o neinicializiranih celih številih še niso dokončana, vendar dokler se ne uporabijo, se jim je priporočljivo izogibati.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // VARNOST: klicatelj mora zagotoviti, da je nepristranjena vrednost veljavna za `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Vrednosti zamenja na dveh spremenljivih lokacijah, ne da bi bilo eno od njih deinializirano.
///
/// * Če želite zamenjati s privzeto ali navidezno vrednostjo, glejte [`take`].
/// * Če želite zamenjati s posredovano vrednostjo in vrniti staro vrednost, glejte [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // VARNOST: surovi kazalci so bili ustvarjeni iz varnih spremenljivih referenc, ki ustrezajo vsem
    // omejitve za `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Zamenja `dest` s privzeto vrednostjo `T` in vrne prejšnjo vrednost `dest`.
///
/// * Če želite nadomestiti vrednosti dveh spremenljivk, glejte [`swap`].
/// * Če želite namesto privzete vrednosti nadomestiti s posredovano vrednostjo, glejte [`replace`].
///
/// # Examples
///
/// Preprost primer:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` omogoča prevzem lastništva nad strukturnim poljem tako, da ga nadomesti z vrednostjo "empty".
/// Brez `take` lahko naletite na te težave:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Upoštevajte, da `T` ni nujno implementiral [`Clone`], zato niti ne more klonirati in ponastaviti `self.buf`.
/// Toda `take` lahko uporabimo za ločitev prvotne vrednosti `self.buf` od `self`, kar omogoča vrnitev:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Premakne `src` v referenčni `dest` in vrne prejšnjo vrednost `dest`.
///
/// Niti ena vrednost ni izpuščena.
///
/// * Če želite nadomestiti vrednosti dveh spremenljivk, glejte [`swap`].
/// * Če želite zamenjati s privzeto vrednostjo, glejte [`take`].
///
/// # Examples
///
/// Preprost primer:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` omogoča porabo polja struct z nadomestitvijo z drugo vrednostjo.
/// Brez `replace` lahko naletite na te težave:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Upoštevajte, da `T` ne vključuje nujno [`Clone`], zato ne moremo niti klonirati `self.buf[i]`, da bi se izognili premiku.
/// Toda `replace` lahko uporabimo za ločitev prvotne vrednosti pri tem indeksu od `self`, kar omogoča vrnitev:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // VARNOST: Beremo iz `dest`, nato pa vanj neposredno vpišemo `src`,
    // tako, da se stara vrednost ne podvoji.
    // Nič ni spuščeno in tukaj nič ne more panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Razpolaga z vrednostjo.
///
/// To stori tako, da pokliče izvedbo argumenta [`Drop`][drop].
///
/// To dejansko ne naredi ničesar za tipe, ki uporabljajo `Copy`, npr
/// integers.
/// Takšne vrednosti se kopirajo in _then_ se premakne v funkcijo, tako da vrednost ostane po tem klicu funkcije.
///
///
/// Ta funkcija ni čarovnija;dobesedno je opredeljeno kot
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Ker je `_x` premaknjen v funkcijo, se samodejno spusti, preden se funkcija vrne.
///
/// [drop]: Drop
///
/// # Examples
///
/// Osnovna uporaba:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // izrecno spustite vector
/// ```
///
/// Ker [`RefCell`] med izvajanjem uveljavlja pravila izposoje, lahko `drop` sprosti izposojo [`RefCell`]:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // odpovejte spremenljivemu posojilu na tej reži
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Na cela števila in druge vrste, ki izvajajo [`Copy`], `drop` ne vpliva.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // kopija `x` je premaknjena in spuščena
/// drop(y); // kopija `y` je premaknjena in spuščena
///
/// println!("x: {}, y: {}", x, y.0); // še vedno na voljo
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Interpretira `src` kot tip `&U` in nato prebere `src`, ne da bi premaknil vsebovano vrednost.
///
/// Ta funkcija bo varno domnevala, da je kazalec `src` veljaven za bajte [`size_of::<U>`][size_of], tako da `&T` pretvori v `&U` in nato odčita `&U` (le da je to izvedeno na pravilen način, tudi če `&U` postavlja strožje zahteve za poravnavo kot `&T`).
/// Prav tako bo varno ustvaril kopijo vsebovane vrednosti, namesto da bi se premaknil iz `src`.
///
/// Če ima `T` in `U` različne velikosti, ne gre za napako pri prevajanju, vendar je zelo priporočljivo, da to funkcijo prikličete le tam, kjer imata `T` in `U` enako velikost.Ta funkcija sproži [undefined behavior][ub], če je `U` večji od `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Kopirajte podatke iz 'foo_array' in jih obravnavajte kot 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Spremenite kopirane podatke
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Vsebina 'foo_array' se ne bi smela spreminjati
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Če ima U zahtevo za višjo poravnavo, src morda ni primerno poravnana.
    if align_of::<U>() > align_of::<T>() {
        // VARNOST: `src` je referenca, ki je zagotovljeno veljavna za branje.
        // Klicatelj mora zagotoviti, da je dejanska transmutacija varna.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // VARNOST: `src` je referenca, ki je zagotovljeno veljavna za branje.
        // Pravkar smo preverili, ali je `src as *const U` pravilno poravnan.
        // Klicatelj mora zagotoviti, da je dejanska transmutacija varna.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Neprozorna vrsta, ki predstavlja diskriminacijo enum.
///
/// Za več informacij glejte funkcijo [`discriminant`] v tem modulu.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Teh izvedb Portrait ni mogoče izpeljati, ker ne želimo nobenih omejitev za T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Vrne vrednost, ki enolično identificira različico naštevanja v `v`.
///
/// Če `T` ni enum, klic te funkcije ne bo povzročil nedefiniranega vedenja, vendar je vrnjena vrednost nedoločena.
///
///
/// # Stability
///
/// Diskriminant različice naštevanja se lahko spremeni, če se spremeni opredelitev naštevanja.
/// Diskriminant neke variante se med kompilacijami z istim prevajalnikom ne bo spremenil.
///
/// # Examples
///
/// To lahko uporabimo za primerjavo enumov, ki prenašajo podatke, ob neupoštevanju dejanskih podatkov:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Vrne število različic v tipu enum `T`.
///
/// Če `T` ni enum, klic te funkcije ne bo povzročil nedefiniranega vedenja, vendar je vrnjena vrednost nedoločena.
/// Če je `T` enum z več različicami kot `usize::MAX`, vrnjena vrednost ni določena.
/// Upoštevane bodo nenaseljene različice.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}