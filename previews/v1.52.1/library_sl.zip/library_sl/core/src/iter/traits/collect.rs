/// Pretvorba iz [`Iterator`].
///
/// Z implementacijo `FromIterator` za tip določite, kako bo ustvarjen iz iteratorja.
/// To je običajno za tipe, ki opisujejo neko zbirko.
///
/// [`FromIterator::from_iter()`] je redko poklican eksplicitno in se namesto tega uporablja po metodi [`Iterator::collect()`].
///
/// Za več primerov glejte dokumentacijo [`Iterator::collect()`]'s.
///
/// Poglej tudi: [`IntoIterator`].
///
/// # Examples
///
/// Osnovna uporaba:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Uporaba [`Iterator::collect()`] za implicitno uporabo `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Implementacija `FromIterator` za vaš tip:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Vzorčna zbirka, to je samo ovoj čez Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Dajmo mu nekaj metod, da jih bomo lahko ustvarili in mu dodali stvari.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // in izvedli bomo FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Zdaj lahko naredimo nov iterator ...
/// let iter = (0..5).into_iter();
///
/// // ... in iz njega naredite MyCollection
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // zbirajte tudi dela!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Ustvari vrednost iz iteratorja.
    ///
    /// Za več si oglejte [module-level documentation].
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Pretvorba v [`Iterator`].
///
/// Z implementacijo `IntoIterator` za tip določite, kako bo pretvorjen v iterator.
/// To je običajno za tipe, ki opisujejo neko zbirko.
///
/// Ena od prednosti izvajanja `IntoIterator` je, da bo vaš tip [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Poglej tudi: [`FromIterator`].
///
/// # Examples
///
/// Osnovna uporaba:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Implementacija `IntoIterator` za vaš tip:
///
/// ```
/// // Vzorčna zbirka, to je samo ovoj čez Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Dajmo mu nekaj metod, da jih bomo lahko ustvarili in mu dodali stvari.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // in implementirali bomo IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Zdaj lahko naredimo novo kolekcijo ...
/// let mut c = MyCollection::new();
///
/// // ... dodajte mu nekaj stvari ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... in ga nato spremenite v Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Običajno je uporaba `IntoIterator` uporabljena kot Portrait bound.To omogoča spreminjanje vrste zbirke vnosov, če je še vedno iterator.
/// Dodatne meje lahko določite z omejitvijo na
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Vrsta elementov, ki se ponavljajo.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// V kakšen iterator to spreminjamo?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Ustvari iterator iz vrednosti.
    ///
    /// Za več si oglejte [module-level documentation].
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Razširite zbirko z vsebino iteratorja.
///
/// Iteratorji ustvarijo vrsto vrednot, zbirke pa si lahko predstavljamo tudi kot vrsto vrednot.
/// `Extend` Portrait premosti to vrzel in vam omogoča razširitev zbirke z vključitvijo vsebine tega iteratorja.
/// Pri razširitvi zbirke z že obstoječim ključem se ta vnos posodobi ali pa se vstavi, če gre za zbirke, ki dovoljujejo več vnosov z enakimi ključi.
///
///
/// # Examples
///
/// Osnovna uporaba:
///
/// ```
/// // String lahko podaljšate z nekaj znaki:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Implementacija `Extend`:
///
/// ```
/// // Vzorčna zbirka, to je samo ovoj čez Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Dajmo mu nekaj metod, da jih bomo lahko ustvarili in mu dodali stvari.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // ker ima MyCollection seznam i32, uvajamo Extend za i32
/// impl Extend<i32> for MyCollection {
///
///     // To je nekoliko bolj preprosto s konkretnim podpisom tipa: lahko pokličemo razširitev na vse, kar je mogoče spremeniti v Iterator, ki nam daje i32.
///     // Ker potrebujemo i32s, da jih vstavimo v MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Izvedba je zelo enostavna: zanko skozi iterator in add() vsak element zase.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // razširimo svojo zbirko s še tremi številkami
/// c.extend(vec![1, 2, 3]);
///
/// // te elemente smo dodali na koncu
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Razširja zbirko z vsebino iteratorja.
    ///
    /// Ker je to edina zahtevana metoda za ta Portrait, dokumenti [trait-level] vsebujejo več podrobnosti.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// // String lahko podaljšate z nekaj znaki:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Razširja zbirko z natančno enim elementom.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Rezervira kapaciteto v zbirki za določeno število dodatnih elementov.
    ///
    /// Privzeta izvedba ne naredi ničesar.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}