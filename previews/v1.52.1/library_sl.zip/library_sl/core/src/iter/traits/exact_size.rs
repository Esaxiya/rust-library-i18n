/// Ponavljalec, ki pozna njegovo natančno dolžino.
///
/// Mnogi [`Iterator`] ne vedo, kolikokrat bodo ponovili, nekateri pa.
/// Če iterator ve, kolikokrat lahko ponavlja, je dostop do teh informacij lahko koristen.
/// Če želite na primer iti nazaj, je dober začetek vedeti, kje je konec.
///
/// Ko izvajate `ExactSizeIterator`, morate implementirati tudi [`Iterator`].
/// Pri tem mora izvedba [`Iterator::size_hint`]*vrniti* natančno velikost iteratorja.
///
/// Metoda [`len`] ima privzeto izvedbo, zato je običajno ne bi smeli izvajati.
/// Vendar pa boste morda lahko zagotovili bolj učinkovito izvedbo kot privzeto, zato je v tem primeru preglasitev smiselna.
///
///
/// Upoštevajte, da je ta Portrait varen Portrait in kot tak *ne* in *ne more* zagotoviti, da je vrnjena dolžina pravilna.
/// To pomeni, da se koda `unsafe`**ne sme** zanašati na pravilnost [`Iterator::size_hint`].
/// Nestabilno in varno [`TrustedLen`](super::marker::TrustedLen) Portrait daje to dodatno garancijo.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Osnovna uporaba:
///
/// ```
/// // končni obseg natančno ve, kolikokrat se bo ponovil
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// V [module-level docs] smo uvedli [`Iterator`], `Counter`.
/// Uvedimo `ExactSizeIterator` tudi zanj:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Preostalo število ponovitev lahko enostavno izračunamo.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // In zdaj jo lahko uporabimo!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Vrne natančno dolžino iteratorja.
    ///
    /// Izvedba zagotavlja, da bo iterator pred vrnitvijo [`None`] vrnil natančno `len()` večkrat kot vrednost [`Some(T)`].
    ///
    /// Ta metoda ima privzeto izvedbo, zato je običajno ne smete izvajati neposredno.
    /// Če pa lahko zagotovite učinkovitejšo izvedbo, lahko to storite.
    /// Za primer glejte dokumentacijo [trait-level].
    ///
    /// Ta funkcija ima enaka varnostna zagotovila kot funkcija [`Iterator::size_hint`].
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// // končni obseg natančno ve, kolikokrat se bo ponovil
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Ta trditev je preveč obrambna, vendar preverja invariant
        // jamči Portrait.
        // Če bi bil ta Portrait interni rust, bi lahko uporabili debug_assert !;assert_eq!bo preveril tudi vse uporabniške izvedbe Rust.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Vrne `true`, če je iterator prazen.
    ///
    /// Ta metoda ima privzeto izvedbo z uporabo [`ExactSizeIterator::len()`], zato vam je ni treba sami izvajati.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}