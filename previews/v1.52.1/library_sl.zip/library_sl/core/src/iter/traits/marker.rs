/// Iterator, ki vedno izkoristi `None`, ko je izčrpan.
///
/// Naslednji klic na stopljenem iteratorju, ki je enkrat vrnil `None`, bo zagotovo spet vrnil [`None`].
/// Ta Portrait bi morali izvajati vsi iteratorji, ki se obnašajo tako, ker omogoča optimizacijo [`Iterator::fuse()`].
///
///
/// Note: Na splošno ne smete uporabljati `FusedIterator` v splošnih mejah, če potrebujete stopljeni iterator.
/// Namesto tega v iteratorju pokličite [`Iterator::fuse()`].
/// Če je iterator že stopljen, bo dodatni ovitek [`Fuse`] nedejaven in ne bo kaznoval zmogljivosti.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Iterator, ki poroča natančno dolžino z uporabo size_hint.
///
/// Iterator sporoči namig o velikosti, kjer je bodisi natančen (spodnja meja je enaka zgornji meji) bodisi je zgornja meja [`None`].
///
/// Zgornja meja mora biti [`None`] le, če je dejanska dolžina iteratorja večja od [`usize::MAX`].
/// V tem primeru mora biti spodnja meja [`usize::MAX`], kar ima za posledico [`Iterator::size_hint()`] `(usize::MAX, None)`.
///
/// Preden doseže konec, mora iterator izdelati natančno število elementov, ki jih je sporočil, ali pa se razhajajo.
///
/// # Safety
///
/// Ta Portrait se sme izvajati le, če je pogodba potrjena.
/// Potrošniki tega Portrait morajo pregledati zgornjo mejo [`Iterator::size_hint()`]’s.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Ponavljalec, ki je pri pridobivanju predmeta vzel vsaj en element iz osnovnega [`SourceIter`].
///
/// Klicanje katere koli metode, ki napreduje iterator, npr
/// [`next()`] ali [`try_fold()`], zagotavlja, da je bila za vsak korak vsaj ena vrednost osnovnega vira iteratorja premaknjena in da je rezultat verige iteratorjev lahko vstavljen na njegovo mesto, ob predpostavki, da strukturne omejitve vira dovoljujejo tako vstavitev.
///
/// Z drugimi besedami, ta Portrait označuje, da je mogoče iteratorski cevovod zbrati na mestu.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}