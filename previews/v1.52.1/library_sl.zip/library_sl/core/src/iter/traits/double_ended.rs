use crate::ops::{ControlFlow, Try};

/// Ponavljalec, ki lahko poda elemente z obeh koncev.
///
/// Nekaj, kar implementira `DoubleEndedIterator`, ima eno dodatno zmogljivost nad nečim, kar implementira [`Iterator`]: možnost, da posnamete tudi "predmete" od zadaj in spredaj.
///
///
/// Pomembno je omeniti, da tako naprej kot naprej delujeta na istem območju in se ne križata: iteracija je končana, ko se srečata na sredini.
///
/// Na podoben način kot protokol [`Iterator`], ko `DoubleEndedIterator` vrne [`None`] iz [`next_back()`], ga lahko znova pokliče ali pa tudi ne vrne [`Some`].
/// [`next()`] in [`next_back()`] sta v ta namen zamenljiva.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Osnovna uporaba:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Odstrani in vrne element s konca iteratorja.
    ///
    /// Vrne `None`, ko ni več elementov.
    ///
    /// Dokumenti [trait-level] vsebujejo več podrobnosti.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Elementi, dobljeni z metodami "DoubleEndedIterator", se lahko razlikujejo od elementov, dobljenih z metodami ["Iterator`]:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Elementi `n` napredujejo iterator od zadaj.
    ///
    /// `advance_back_by` je obratna različica [`advance_by`].Ta metoda nestrpno preskoči elemente `n`, začenši od zadaj, tako da pokliče [`next_back`] do `n`-krat, dokler ne naleti na [`None`].
    ///
    /// `advance_back_by(n)` bo vrnil [`Ok(())`], če iterator uspešno napreduje po elementih `n`, ali [`Err(k)`], če naletimo na [`None`], pri čemer je `k` število elementov, s katerimi je iterator napredoval, preden mu zmanjka elementov (tj.
    /// dolžina iteratorja).
    /// Upoštevajte, da je `k` vedno manjši od `n`.
    ///
    /// Klicanje `advance_back_by(0)` ne porabi nobenih elementov in vedno vrne [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // preskočen je bil le `&3`
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Vrne `n`-ti element s konca iteratorja.
    ///
    /// To je v bistvu obrnjena različica [`Iterator::nth()`].
    /// Čeprav se kot pri večini operacij indeksiranja štetje začne od nič, torej `nth_back(0)` vrne prvo vrednost od konca, `nth_back(1)` drugo itd.
    ///
    ///
    /// Upoštevajte, da bodo porabljeni vsi elementi med koncem in vrnjenim elementom, vključno z vrnjenim elementom.
    /// To tudi pomeni, da bo klic `nth_back(0)` večkrat na isti iterator vrnil različne elemente.
    ///
    /// `nth_back()` vrne [`None`], če je `n` večja ali enaka dolžini iteratorja.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Večkratno klicanje `nth_back()` ne previje iteratorja:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Vrnitev `None`, če je elementov manj kot `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// To je obratna različica [`Iterator::try_fold()`]: zajema elemente, ki se začnejo na zadnji strani iteratorja.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Ker je prišlo do kratkega stika, so preostali elementi še vedno na voljo prek iteratorja.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Metoda iteratorja, ki elemente iteratorja zmanjša na eno, končno vrednost, začenši od zadaj.
    ///
    /// To je obratna različica [`Iterator::fold()`]: zajema elemente, ki se začnejo na zadnji strani iteratorja.
    ///
    /// `rfold()` vzame dva argumenta: začetno vrednost in zaključek z dvema argumentoma: 'accumulator' in elementom.
    /// Zapiranje vrne vrednost, ki bi jo moral imeti akumulator za naslednjo ponovitev.
    ///
    /// Začetna vrednost je vrednost, ki jo bo imel akumulator ob prvem klicu.
    ///
    /// Po uporabi tega zapiranja za vsak element iteratorja `rfold()` vrne akumulator.
    ///
    /// Ta postopek se včasih imenuje 'reduce' ali 'inject'.
    ///
    /// Zlaganje je koristno, kadar imate zbirko nečesa in želite iz nje izdelati eno vrednost.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // vsota vseh elementov a
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Ta primer gradi niz, začenši z začetno vrednostjo in nadaljuje z vsakim elementom od zadaj do spredaj:
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Išče element iteratorja od zadaj, ki izpolnjuje predikat.
    ///
    /// `rfind()` zapira, ki vrne `true` ali `false`.
    /// To zapiranje uporabi za vsak element iteratorja, začenši na koncu, in če kateri od njih vrne `true`, potem `rfind()` vrne [`Some(element)`].
    /// Če vsi vrnejo `false`, vrne [`None`].
    ///
    /// `rfind()` je v kratkem stiku;z drugimi besedami, obdelava se bo ustavila takoj, ko zaprtje vrne `true`.
    ///
    /// Ker `rfind()` vzame sklic in se mnogi iteratorji prenašajo nad sklici, to vodi do morebitne zmede, ko je argument dvojna referenca.
    ///
    /// Ta učinek lahko vidite v spodnjih primerih z `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Ustavitev pri prvem `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // še vedno lahko uporabimo `iter`, saj je elementov več.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}