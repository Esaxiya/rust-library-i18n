// ignore-tidy-filelength Ta datoteka je skoraj izključno sestavljena iz definicije `Iterator`.
// Tega ne moremo razdeliti na več datotek.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Vmesnik za obravnavo iteratorjev.
///
/// To je glavni iterator Portrait.
/// Za več informacij o konceptu iteratorjev na splošno glejte [module-level documentation].
/// Zlasti boste morda želeli vedeti, kako [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Vrsta elementov, ki se ponavljajo.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Napreduje iterator in vrne naslednjo vrednost.
    ///
    /// Vrne [`None`], ko je ponovitev končana.
    /// Posamezne izvedbe iteratorjev se lahko odločijo, da bodo iteracijo nadaljevale, zato lahko klic `next()` v določenem trenutku spet začne ali morda ne bo vrnil [`Some(Item)`].
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Klic na next() vrne naslednjo vrednost ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... in potem Noben, ko je konec.
    /// assert_eq!(None, iter.next());
    ///
    /// // Več klicev lahko vrne ali ne `None`.Tukaj bodo vedno.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Vrne meje preostale dolžine iteratorja.
    ///
    /// Natančneje, `size_hint()` vrne nabor, kjer je prvi element spodnja meja, drugi element pa zgornja meja.
    ///
    /// Druga polovica vrnjene vrvice je [`Možnost`]`<`[`usize`] `>`.
    /// [`None`] tukaj pomeni, da zgornja meja ni znana ali pa je zgornja meja večja od [`usize`].
    ///
    /// # Opombe o izvajanju
    ///
    /// Ni uveljavljeno, da bi izvedba iteratorja dala prijavljeno število elementov.Popravljalnik napake lahko daje manj od spodnje meje ali več od zgornje meje elementov.
    ///
    /// `size_hint()` je v prvi vrsti namenjen za optimizacije, kot je rezerviranje prostora za elemente iteratorja, vendar se mu ne sme zaupati, da npr. izpusti preverjanja mej v nevarni kodi.
    /// Napačna izvedba `size_hint()` ne bi smela povzročiti kršitev varnosti pomnilnika.
    ///
    /// Kljub temu bi morala izvedba zagotoviti pravilno oceno, ker bi sicer kršila protokol Portrait.
    ///
    /// Privzeta izvedba vrne "(0," ["Brez"] "), kar je pravilno za kateri koli iterator.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Bolj zapleten primer:
    ///
    /// ```
    /// // Parna števila od nič do deset.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Lahko ponovimo od nič do desetkrat.
    /// // Vedeti, da je pet natančno, ne bi bilo mogoče brez izvajanja filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Z chain() dodajte še pet številk
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // zdaj se obe meji povečata za pet
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Vrnitev `None` za zgornjo mejo:
    ///
    /// ```
    /// // neskončni iterator nima zgornje in največje možne spodnje meje
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Porabi iterator, prešteje število ponovitev in ga vrne.
    ///
    /// Ta metoda bo večkrat klicala [`next`], dokler ne naleti na [`None`], in vrne število ogledov [`Some`].
    /// Upoštevajte, da je treba [`next`] poklicati vsaj enkrat, tudi če iterator nima nobenih elementov.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Vedenje prelivanja
    ///
    /// Metoda ne varuje pred prelivanjem, zato štetje elementov iteratorja z več kot [`usize::MAX`] elementi ustvari napačen rezultat ali panics.
    ///
    /// Če so trditve za odpravljanje napak omogočene, je panic zagotovljen.
    ///
    /// # Panics
    ///
    /// Ta funkcija bi lahko povzročila panic, če ima iterator več kot [`usize::MAX`] elementov.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Porabi iterator in vrne zadnji element.
    ///
    /// Ta metoda bo ocenjevala iterator, dokler ne vrne [`None`].
    /// Pri tem beleži trenutni element.
    /// Po vrnitvi [`None`] bo `last()` vrnil zadnji element, ki ga je videl.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Napreduje iterator za elemente `n`.
    ///
    /// Ta metoda bo nestrpno preskočila elemente `n` tako, da bo klicala [`next`] do `n`-krat, dokler ne naletite na [`None`].
    ///
    /// `advance_by(n)` bo vrnil [`Ok(())`][Ok], če iterator uspešno napreduje po elementih `n`, ali [`Err(k)`][Err], če naletimo na [`None`], pri čemer je `k` število elementov, s katerimi je iterator napredoval, preden mu zmanjka elementov (tj.
    /// dolžina iteratorja).
    /// Upoštevajte, da je `k` vedno manjši od `n`.
    ///
    /// Klicanje `advance_by(0)` ne porabi nobenih elementov in vedno vrne [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // preskočen je bil le `&4`
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Vrne `n`th element iteratorja.
    ///
    /// Tako kot pri večini indeksiranja se tudi štetje začne od nič, zato `nth(0)` vrne prvo vrednost, `nth(1)` drugo itd.
    ///
    /// Upoštevajte, da bodo vsi predhodni elementi, kot tudi vrnjeni element, porabljeni iz iteratorja.
    /// To pomeni, da bodo predhodni elementi zavrženi in da bo večkratno klicanje `nth(0)` na isti iterator vrnilo različne elemente.
    ///
    ///
    /// `nth()` vrne [`None`], če je `n` večja ali enaka dolžini iteratorja.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Večkratno klicanje `nth()` ne previje iteratorja:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Vrnitev `None`, če je elementov manj kot `n + 1`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Ustvari iterator, ki se začne na isti točki, vendar stopnja za dani znesek pri vsaki ponovitvi.
    ///
    /// Opomba 1: Prvi element iteratorja bo vedno vrnjen, ne glede na podani korak.
    ///
    /// Opomba 2: Čas, ko vlečejo prezrte elemente, ni določen.
    /// `StepBy` se obnaša kot zaporedje `next(), nth(step-1), nth(step-1),…`, lahko pa se tudi obnaša kot zaporedje
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Kateri način uporabe se lahko zaradi ponovitve zaradi nekaterih izvedb spremeni.
    /// Drugi način bo iterator pospešil že prej in bo morda porabil več predmetov.
    ///
    /// `advance_n_and_return_first` je enakovredno:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Metoda bo panic, če je dani korak `0`.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Zajema dva iteratorja in zaporedoma ustvari nov iterator.
    ///
    /// `chain()` bo vrnil nov iterator, ki bo najprej izvedel iteracijo nad vrednostmi iz prvega iteratorja in nato nad vrednostmi iz drugega iteratorja.
    ///
    /// Z drugimi besedami, povezuje dva iteratorja skupaj v verigo.🔗
    ///
    /// [`once`] se pogosto uporablja za prilagajanje posamezne vrednosti v verigo drugih vrst ponovitev.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ker argument `chain()` uporablja [`IntoIterator`], lahko prenesemo vse, kar je mogoče pretvoriti v [`Iterator`], ne samo [`Iterator`].
    /// Na primer, rezine (`&[T]`) izvajajo [`IntoIterator`] in jih je mogoče neposredno posredovati `chain()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Če delate z API-jem Windows, boste morda želeli pretvoriti [`OsStr`] v `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Stisne' dva iteratorja v en iterator parov.
    ///
    /// `zip()` vrne nov iterator, ki se bo ponovil nad dvema drugima iteratorjema, vrnil pač, kjer prvi element prihaja iz prvega iteratorja, drugi element pa iz drugega iteratorja.
    ///
    ///
    /// Z drugimi besedami, dva iteratorja stisne v en sam.
    ///
    /// Če kateri koli iterator vrne [`None`], bo [`next`] iz stisnjenega iteratorja vrnil [`None`].
    /// Če prvi iterator vrne [`None`], bo `zip` kratek stik in `next` ne bo poklican na drugem iteratorju.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ker argument `zip()` uporablja [`IntoIterator`], lahko prenesemo vse, kar je mogoče pretvoriti v [`Iterator`], ne samo [`Iterator`].
    /// Na primer, rezine (`&[T]`) izvajajo [`IntoIterator`] in jih je mogoče neposredno posredovati `zip()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` se pogosto uporablja za stiskanje neskončnega iteratorja na končnega.
    /// To deluje, ker bo končni iterator sčasoma vrnil [`None`] in končal zadrgo.Stiskanje z `(0..)` je lahko podobno kot [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Ustvari nov iterator, ki postavi kopijo `separator` med sosednje elemente prvotnega iteratorja.
    ///
    /// Če `separator` ne izvaja [`Clone`] ali ga je treba vsakič izračunati, uporabite [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Prvi element iz `a`.
    /// assert_eq!(a.next(), Some(&100)); // Ločilo.
    /// assert_eq!(a.next(), Some(&1));   // Naslednji element iz `a`.
    /// assert_eq!(a.next(), Some(&100)); // Ločilo.
    /// assert_eq!(a.next(), Some(&2));   // Zadnji element iz `a`.
    /// assert_eq!(a.next(), None);       // Iterator je končan.
    /// ```
    ///
    /// `intersperse` je lahko zelo koristno, če se pridružijo elementi iteratorja s skupnim elementom:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Ustvari nov iterator, ki postavi element, ki ga ustvari `separator`, med sosednje elemente prvotnega iteratorja.
    ///
    /// Zapiranje bo poklicano natanko vsakič, ko bo postavljen element med dva sosednja elementa iz osnovnega iteratorja;
    /// natančneje, zaprtje ni poklicano, če osnovni iterator daje manj kot dve postavki in po izdaji zadnjega elementa.
    ///
    ///
    /// Če element iteratorja implementira [`Clone`], bo morda lažje uporabljati [`intersperse`].
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Prvi element iz `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Ločilo.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Naslednji element iz `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Ločilo.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Zadnji element iz `v`.
    /// assert_eq!(it.next(), None);               // Iterator je končan.
    /// ```
    ///
    /// `intersperse_with` se lahko uporablja v primerih, ko je treba izračunati ločilo:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Zapiranje mu izposodi kontekst, da ustvari element.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Zapre in ustvari iterator, ki pokliče to zaporo za vsak element.
    ///
    /// `map()` pretvori en iterator v drugega s pomočjo argumenta:
    /// nekaj, kar implementira [`FnMut`].Ustvari nov iterator, ki pokliče to zaprtje za vsak element prvotnega iteratorja.
    ///
    /// Če dobro razmišljate v tipih, lahko `map()` pomislite takole:
    /// Če imate iterator, ki vam daje elemente neke vrste `A`, in želite iterator neke druge vrste `B`, lahko uporabite `map()`, mimo zapore, ki sprejme `A` in vrne `B`.
    ///
    ///
    /// `map()` je konceptualno podoben zanki [`for`].Ker pa je `map()` len, ga je najbolje uporabiti, ko že delate z drugimi iteratorji.
    /// Če za neželene učinke izvajate neke vrste zanke, je bolj idiomatično uporabljati [`for`] kot `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Če imate kakšen stranski učinek, raje [`for`] kot `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // ne delaj tega:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // niti izvršiti ne bo, saj je len.Na to vas bo opozoril Rust.
    ///
    /// // Namesto tega uporabite za:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Kliče zaprtje vsakega elementa iteratorja.
    ///
    /// To je enakovredno uporabi zanke [`for`] na iteratorju, čeprav `break` in `continue` zaradi zapore nista mogoča.
    /// Na splošno je bolj idiomatsko uporabljati zanko `for`, vendar je `for_each` morda bolj čitljiv pri obdelavi elementov na koncu daljših verig iteratorjev.
    ///
    /// V nekaterih primerih je `for_each` lahko tudi hitrejši od zanke, ker bo na vmesnikih, kot je `Chain`, uporabil interno ponovitev.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Za tako majhen primer je zanka `for` morda čistejša, vendar je morda bolj priporočljivo, da `for_each` ohrani funkcionalni slog z daljšimi iteratorji:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Ustvari iterator, ki s pomočjo zapiranja ugotovi, ali je treba dati element.
    ///
    /// Glede na element mora zapiranje vrniti `true` ali `false`.Vrnjeni iterator bo dal samo elemente, za katere zaprtje vrne true.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ker zaprtje, posredovano `filter()`, potrebuje referenco in se mnogi iteratorji prenašajo nad referencami, to vodi v morebitno zmedeno situacijo, kjer je vrsta zapore dvojna referenca:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // potrebujete dva * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Običajno namesto argumenta uporabimo destrukturiranje, da ga odstranimo:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // oboje in *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// ali oboje:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // dva &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// teh plasti.
    ///
    /// Upoštevajte, da je `iter.filter(f).next()` enakovreden `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Ustvari iterator, ki filtrira in preslika.
    ///
    /// Vrnjeni iterator poda samo vrednosti, za katere priložena zapora vrne `Some(value)`.
    ///
    /// `filter_map` je mogoče uporabiti za bolj jedrnate verige [`filter`] in [`map`].
    /// Spodnji primer prikazuje, kako lahko `map().filter().map()` skrajšate na en klic na `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Tu je isti primer, vendar z [`filter`] in [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Ustvari iterator, ki poda trenutno število ponovitev in naslednjo vrednost.
    ///
    /// Vrnjeni iterator daje pare `(i, val)`, kjer je `i` trenutni indeks ponovitve, `val` pa vrednost, ki jo vrne iterator.
    ///
    ///
    /// `enumerate()` se šteje za [`usize`].
    /// Če želite šteti z različno velikim številom, funkcija [`zip`] ponuja podobno funkcionalnost.
    ///
    /// # Vedenje prelivanja
    ///
    /// Metoda ne varuje pred prelivanjem, zato naštevanje več kot [`usize::MAX`] elementov povzroči napačen rezultat ali panics.
    /// Če so trditve za odpravljanje napak omogočene, je panic zagotovljen.
    ///
    /// # Panics
    ///
    /// Vrnjeni iterator bi lahko bil panic, če bi indeks, ki ga je treba vrniti, presegel [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Ustvari iterator, ki lahko s pomočjo [`peek`] pogleda naslednji element iteratorja, ne da bi ga porabil.
    ///
    /// V iterator doda metodo [`peek`].Za več informacij glejte njegovo dokumentacijo.
    ///
    /// Upoštevajte, da je osnovni iterator še vedno napreden, ko prvič pokličete [`peek`]: Če želite pridobiti naslednji element, se [`next`] pokliče na osnovni iterator, torej morebitni neželeni učinki (tj.
    ///
    /// zgodi se kaj drugega kot pridobivanje naslednje vrednosti) metode [`next`].
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() nam omogoča vpogled v future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // lahko peek() večkrat, iterator ne bo napredoval
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // po končanem iteratorju tudi peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Ustvari iterator, ki [`preskoči`] elemente na podlagi predikata.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` kot argument vzame zaprtje.To zapiranje bo poklical za vsak element iteratorja in prezrl elemente, dokler ne vrne `false`.
    ///
    /// Po vrnitvi `false` je opravilo `skip_while()`'s končano in preostali elementi so podani.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ker zaprtje, posredovano `skip_while()`, potrebuje referenco in se mnogi iteratorji prenašajo nad referencami, to vodi v morebitno zmedeno situacijo, kjer je vrsta argumenta zaprtja dvojna referenca:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // potrebujete dva * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ustavitev po začetnem `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // čeprav bi bilo to napačno, ker že imamo napako, skip_while() ni več v uporabi
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Ustvari iterator, ki daje elemente na podlagi predikata.
    ///
    /// `take_while()` kot argument vzame zaprtje.To zaprtje bo poklical za vsak element iteratorja in bo prinesel elemente, medtem ko vrne `true`.
    ///
    /// Po vrnitvi `false` je opravilo `take_while()`'s končano, ostali elementi pa so prezrti.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ker zaprtje, posredovano `take_while()`, potrebuje referenco in se mnogi iteratorji prenašajo nad referencami, to vodi v morebitno zmedeno situacijo, kjer je vrsta zapore dvojna referenca:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // potrebujete dva * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ustavitev po začetnem `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Imamo več elementov, ki so manjši od nič, a ker smo že dobili napačno, take_while() ni več v uporabi
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ker mora `take_while()` pogledati vrednost, da bi ugotovil, ali jo je treba vključiti ali ne, bodo porabljeni iteratorji videli, da je odstranjena:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` ni več tam, ker je bil porabljen, da bi ugotovil, ali naj se ponovitev ustavi, vendar ni bil ponovno nameščen v iterator.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Ustvari iterator, ki daje elemente na podlagi predikata in zemljevidov.
    ///
    /// `map_while()` kot argument vzame zaprtje.
    /// To zaprtje bo poklical za vsak element iteratorja in bo prinesel elemente, medtem ko vrne [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Tu je isti primer, vendar z [`take_while`] in [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Ustavitev po začetnem [`None`]:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Na voljo je več elementov, ki bi se lahko prilegali u32 (4, 5), vendar je `map_while` vrnil `None` za `-3` (kot `predicate` je vrnil `None`) in `collect` se ustavi ob prvem `None`.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Ker mora `map_while()` pogledati vrednost, da bi ugotovil, ali jo je treba vključiti ali ne, bodo porabljeni iteratorji videli, da je odstranjena:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` ni več tam, ker je bil porabljen, da bi ugotovil, ali naj se ponovitev ustavi, vendar ni bil ponovno nameščen v iterator.
    ///
    /// Upoštevajte, da za razliko od [`take_while`] ta iterator **ni** stopljen.
    /// Prav tako ni določeno, kaj ta iterator vrne po vrnitvi prvega [`None`].
    /// Če potrebujete stopljeni iterator, uporabite [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Ustvari iterator, ki preskoči prve elemente `n`.
    ///
    /// Po zaužitju se dajo ostali elementi.
    /// Namesto da bi to metodo neposredno preglasili, raje preglasite metodo `nth`.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Ustvari iterator, ki ustvari prve elemente `n`.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` se pogosto uporablja z neskončnim iteratorjem, da postane končen:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Če je na voljo manj kot `n` elementov, se `take` omeji na velikost osnovnega iteratorja:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Adapter za iterator, podoben [`fold`], ki ima notranje stanje in ustvari nov iterator.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` zavzame dva argumenta: začetno vrednost, ki zažene notranje stanje, in zapiranje z dvema argumentoma, pri čemer je prvi spremenljiv sklic na notranje stanje, drugi pa element iteratorja.
    ///
    /// Zapiranje lahko notranjemu stanju dodeli stanje med ponovitvami.
    ///
    /// Pri ponovitvi bo zapiranje uporabljeno za vsak element ponovitvenika, iterator pa bo dobil povratno vrednost iz zapore, [`Option`].
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // vsako ponovitev bomo stanje pomnožili z elementom
    ///     *state = *state * x;
    ///
    ///     // potem bomo podali negacijo države
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Ustvari iterator, ki deluje kot zemljevid, vendar poravna ugnezdeno strukturo.
    ///
    /// Vmesnik [`map`] je zelo uporaben, vendar le, če argument zapiranja ustvari vrednosti.
    /// Če namesto tega ustvari iterator, obstaja dodatna plast indirektnosti.
    /// `flat_map()` bo sam odstranil to dodatno plast.
    ///
    /// `flat_map(f)` si lahko predstavljate kot pomenski ekvivalent ['map`] ping in nato [`sploščite'] kot v `map(f).flatten()`.
    ///
    /// Drug način razmišljanja o `flat_map()`: zaprtje [`map`] vrne en element za vsak element, zapiranje `flat_map()`'s pa iterator za vsak element.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() vrne iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Ustvari iterator, ki poravna ugnezdeno strukturo.
    ///
    /// To je koristno, če imate iterator iteratorjev ali iterator stvari, ki jih je mogoče spremeniti v iteratorje in želite odstraniti eno stopnjo indirektnosti.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Kartiranje in nato ravnanje:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() vrne iterator
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// To lahko tudi prepišete v smislu [`flat_map()`], kar je v tem primeru zaželeno, saj jasneje izraža namen:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() vrne iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Izravnava odstrani le eno stopnjo gnezdenja naenkrat:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Tu vidimo, da `flatten()` ne izvaja poravnave "deep".
    /// Namesto tega se odstrani le ena raven gnezdenja.To pomeni, da če `flatten()` uporabite tridimenzionalno matriko, bo rezultat dvodimenzionalen in ne enodimenzionalen.
    /// Če želite dobiti enodimenzionalno strukturo, morate znova uporabiti `flatten()`.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Ustvari iterator, ki se konča po prvem [`None`].
    ///
    /// Ko iterator vrne [`None`], lahko klici future znova ali ne smejo dati [`Some(T)`].
    /// `fuse()` prilagodi iterator in zagotovi, da bo po podaji [`None`] vedno vrnil [`None`] za vedno.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// // iterator, ki se izmenjuje med Nekateri in Brez
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // če je celo, Some(i32), sicer Noben
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // lahko vidimo, da gre naš iterator naprej in nazaj
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // ko pa ga zlijemo ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // vedno bo prvič vrnil `None`.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Naredi nekaj z vsakim elementom iteratorja in posreduje vrednost naprej.
    ///
    /// Pri uporabi iteratorjev jih boste pogosto povezali v verigo.
    /// Med delom na takšni kodi boste morda želeli preveriti, kaj se dogaja na različnih delih cevovoda.Če želite to narediti, vstavite klic na `inspect()`.
    ///
    /// Pogosteje je, da se `inspect()` uporablja kot orodje za odpravljanje napak, kot da obstaja v končni kodi, vendar se lahko zdijo aplikacije koristne v določenih situacijah, ko je treba napake zabeležiti, preden jih zavržemo.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // to iteratorsko zaporedje je zapleteno.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // dodajte nekaj klicev inspect(), da raziščete, kaj se dogaja
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// To bo natisnilo:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Beleženje napak, preden jih zavržete:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// To bo natisnilo:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Izposodi si iterator, namesto da bi ga porabil.
    ///
    /// To je uporabno, če želite omogočiti uporabo vmesnikov iteratorjev, hkrati pa ohraniti lastništvo prvotnega iteratorja.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // če poskusimo znova uporabiti iter, ne bo delovalo.
    /// // V naslednji vrstici je "napaka: uporaba premaknjene vrednosti: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // poskusimo še enkrat
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // namesto tega dodamo .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // zdaj je to v redu:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Pretvori iterator v zbirko.
    ///
    /// `collect()` lahko vzame karkoli ponovljivega in ga spremeni v ustrezno zbirko.
    /// To je ena najmočnejših metod v standardni knjižnici, ki se uporablja v različnih kontekstih.
    ///
    /// Najosnovnejši vzorec, v katerem se uporablja `collect()`, je pretvorba ene zbirke v drugo.
    /// Vzamete zbirko, nanjo pokličete [`iter`], opravite kopico transformacij in na koncu `collect()`.
    ///
    /// `collect()` lahko tudi ustvari primerke vrst, ki niso tipične zbirke.
    /// Na primer, [`String`] je mogoče zgraditi iz [`char`] s, iterator elementov [`Result<T, E>`][`Result`] pa je mogoče zbrati v `Result<Collection<T>, E>`.
    ///
    /// Za več si oglejte spodnje primere.
    ///
    /// Ker je `collect()` tako splošen, lahko povzroči težave s sklepanjem o tipu.
    /// Kot tak je `collect()` eden redkih primerov, v katerem boste sintakso ljubkovalno imenovali 'turbofish': `::<>`.
    /// To pomaga algoritmu sklepanja natančno razumeti, v katero zbirko poskušate zbrati.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Upoštevajte, da smo potrebovali `: Vec<i32>` na levi strani.To je zato, ker bi lahko namesto tega zbrali v [`VecDeque<T>`]:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Uporaba 'turbofish' namesto označevanja `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Ker `collect()` skrbi le za tisto, v kar zbirate, lahko s turbofishom še vedno uporabite namig delnega tipa, `_`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Uporaba `collect()` za izdelavo [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Če imate seznam [`Rezultat<T, E>`][`Rezultat`] s, lahko s pomočjo `collect()` preverite, ali kateri od njih ni uspel:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // nam daje prvo napako
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // nam daje seznam odgovorov
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Porabi iterator in iz njega ustvari dve zbirki.
    ///
    /// Predikat, poslan v `partition()`, lahko vrne `true` ali `false`.
    /// `partition()` vrne par, vse elemente, za katere je vrnil `true`, in vse elemente, za katere je vrnil `false`.
    ///
    ///
    /// Glej tudi [`is_partitioned()`] in [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Preureja elemente tega iteratorja *in-place* glede na dani predikat, tako da vsi, ki vrnejo `true`, pred vsemi, ki vrnejo `false`.
    ///
    /// Vrne število najdenih elementov `true`.
    ///
    /// Relativni vrstni red razdeljenih elementov se ne ohrani.
    ///
    /// Glej tudi [`is_partitioned()`] in [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Razdelitev na mestu med enakomernimi in verjetnimi kvotami
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: bi nas moralo skrbeti, da bo število preplavljeno?Edini način, da imajo več kot
        // `usize::MAX` spremenljive reference so z ZST-ji, ki niso koristni za particioniranje ...

        // Te funkcije zapiranja "factory" obstajajo, da bi se izognili splošnosti v `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Večkrat poiščite prvi `false` in ga zamenjajte z zadnjim `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Preveri, ali so elementi tega iteratorja razdeljeni glede na dani predikat, tako da vsi, ki vrnejo `true`, pred vsemi, ki vrnejo `false`.
    ///
    ///
    /// Glej tudi [`partition()`] in [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Vsi predmeti preizkusijo `true` ali pa se prvi stavek ustavi pri `false` in preverimo, ali po tem ni več elementov `true`.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Metoda iteratorja, ki uporablja funkcijo, dokler se uspešno vrne in ustvari eno samo končno vrednost.
    ///
    /// `try_fold()` vzame dva argumenta: začetno vrednost in zaključek z dvema argumentoma: 'accumulator' in elementom.
    /// Zapora se bodisi uspešno vrne z vrednostjo, ki bi jo moral imeti akumulator za naslednjo ponovitev, bodisi vrne napako z vrednostjo napake, ki se takoj razširi nazaj na klicatelja (short-circuiting).
    ///
    ///
    /// Začetna vrednost je vrednost, ki jo bo imel akumulator ob prvem klicu.Če je uporaba zapiranja uspela za vsak element iteratorja, `try_fold()` vrne končni akumulator kot uspeh.
    ///
    /// Zlaganje je koristno, kadar imate zbirko nečesa in želite iz nje izdelati eno vrednost.
    ///
    /// # Opomba za izvajalce
    ///
    /// Nekatere druge metode (forward) imajo privzete izvedbe v smislu te, zato poskusite to izrecno izvesti, če lahko naredi kaj boljšega od privzete izvedbe zanke `for`.
    ///
    /// Zlasti poskusite imeti ta klic `try_fold()` na notranjih delih, iz katerih je sestavljen ta iterator.
    /// Če je potrebnih več klicev, je operater `?` lahko primeren za veriženje vrednosti akumulatorja, vendar pazite na vse invariante, ki jih je treba ohraniti pred zgodnjim vrnitvijo.
    /// To je metoda `&mut self`, zato je treba iteracijo nadaljevati, ko je tukaj prišlo do napake.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // preverjena vsota vseh elementov polja
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Ta vsota preseže pri dodajanju elementa 100
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Ker je prišlo do kratkega stika, so preostali elementi še vedno na voljo prek iteratorja.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Metoda iteratorja, ki uporabi zmotljivo funkcijo za vsak element v iteratorju, ustavi se ob prvi napaki in vrne to napako.
    ///
    ///
    /// Na to lahko gledamo tudi kot na napačno obliko [`for_each()`] ali kot različico [`try_fold()`] brez državljanstva.
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Prišlo je do kratkega stika, zato so preostali elementi še vedno v iteratorju:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Vsak element zloži v akumulator z uporabo operacije in vrne končni rezultat.
    ///
    /// `fold()` vzame dva argumenta: začetno vrednost in zaključek z dvema argumentoma: 'accumulator' in elementom.
    /// Zapiranje vrne vrednost, ki bi jo moral imeti akumulator za naslednjo ponovitev.
    ///
    /// Začetna vrednost je vrednost, ki jo bo imel akumulator ob prvem klicu.
    ///
    /// Po uporabi tega zapiranja za vsak element iteratorja `fold()` vrne akumulator.
    ///
    /// Ta postopek se včasih imenuje 'reduce' ali 'inject'.
    ///
    /// Zlaganje je koristno, kadar imate zbirko nečesa in želite iz nje izdelati eno vrednost.
    ///
    /// Note: `fold()` in podobne metode, ki prečkajo celoten iterator, se ne smejo končati za neskončne iteratorje, tudi na traits, za katere je rezultat mogoče določiti v končnem času.
    ///
    /// Note: [`reduce()`] lahko uporabite za uporabo prvega elementa kot začetne vrednosti, če sta vrsta akumulatorja in vrsta predmeta enaka.
    ///
    /// # Opomba za izvajalce
    ///
    /// Nekatere druge metode (forward) imajo privzete izvedbe v smislu te, zato poskusite to izrecno izvesti, če lahko naredi kaj boljšega od privzete izvedbe zanke `for`.
    ///
    ///
    /// Zlasti poskusite imeti ta klic `fold()` na notranjih delih, iz katerih je sestavljen ta iterator.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // vsota vseh elementov polja
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Pojdimo skozi vsak korak ponovitve tukaj:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// In tako, naš končni rezultat, `6`.
    ///
    /// Ljudje, ki niso pogosto uporabljali iteratorjev, običajno uporabljajo zanko `for` s seznamom stvari za ustvarjanje rezultata.Te lahko spremenite v `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // za zanko:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // enaki so
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Z večkratno uporabo operacije zmanjšanja zmanjša elemente na enega samega.
    ///
    /// Če je iterator prazen, vrne [`None`];v nasprotnem primeru vrne rezultat zmanjšanja.
    ///
    /// Za iteratorje z vsaj enim elementom je to enako kot [`fold()`] s prvim elementom iteratorja kot začetno vrednostjo, ki zloži vsak naslednji element vanj.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Poiščite največjo vrednost:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Preizkusi, ali se vsak element iteratorja ujema s predikatom.
    ///
    /// `all()` zapiranje, ki vrne `true` ali `false`.To zapiranje uporabi za vsak element iteratorja in če vsi vrnejo `true`, to stori tudi `all()`.
    /// Če kateri od njih vrne `false`, vrne `false`.
    ///
    /// `all()` je v kratkem stiku;z drugimi besedami, nehati obdelovati takoj, ko najde `false`, saj bo ne glede na to, kaj se še zgodi, rezultat tudi `false`.
    ///
    ///
    /// Prazen iterator vrne `true`.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Ustavitev pri prvem `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // še vedno lahko uporabimo `iter`, saj je elementov več.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Preizkusi, ali se kateri koli element iteratorja ujema s predikatom.
    ///
    /// `any()` zapiranje, ki vrne `true` ali `false`.To zapiranje uporabi za vsak element iteratorja in če kateri od njih vrne `true`, to stori tudi `any()`.
    /// Če vsi vrnejo `false`, vrne `false`.
    ///
    /// `any()` je v kratkem stiku;z drugimi besedami, nehati obdelovati takoj, ko najde `true`, saj bo ne glede na to, kaj se še zgodi, rezultat tudi `true`.
    ///
    ///
    /// Prazen iterator vrne `false`.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Ustavitev pri prvem `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // še vedno lahko uporabimo `iter`, saj je elementov več.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Išče element iteratorja, ki izpolnjuje predikat.
    ///
    /// `find()` zapira, ki vrne `true` ali `false`.
    /// To zapiranje uporabi za vsak element iteratorja in če kateri od njih vrne `true`, potem `find()` vrne [`Some(element)`].
    /// Če vsi vrnejo `false`, vrne [`None`].
    ///
    /// `find()` je v kratkem stiku;z drugimi besedami, obdelava se bo ustavila takoj, ko zaprtje vrne `true`.
    ///
    /// Ker `find()` vzame sklic in se mnogi iteratorji prenašajo nad sklici, to vodi do morebitne zmede, ko je argument dvojna referenca.
    ///
    /// Ta učinek lahko vidite v spodnjih primerih z `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Ustavitev pri prvem `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // še vedno lahko uporabimo `iter`, saj je elementov več.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Upoštevajte, da je `iter.find(f)` enakovreden `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Uporabi funkcijo za elemente iteratorja in vrne prvi rezultat, ki ni nič.
    ///
    ///
    /// `iter.find_map(f)` je enakovredno `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Uporabi funkcijo za elemente iteratorja in vrne prvi resnični rezultat ali prvo napako.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Išče element v iteratorju in mu vrne indeks.
    ///
    /// `position()` zapira, ki vrne `true` ali `false`.
    /// To zapiranje uporabi za vsak element iteratorja in če eden od njih vrne `true`, potem `position()` vrne [`Some(index)`].
    /// Če vsi vrnejo `false`, vrne [`None`].
    ///
    /// `position()` je v kratkem stiku;z drugimi besedami, preneha z obdelavo, takoj ko najde `true`.
    ///
    /// # Vedenje prelivanja
    ///
    /// Metoda ne varuje pred prelivanjem, zato, če je več kot [`usize::MAX`] ne ujemajočih se elementov, ali povzroči napačen rezultat ali panics.
    ///
    /// Če so trditve za odpravljanje napak omogočene, je panic zagotovljen.
    ///
    /// # Panics
    ///
    /// Ta funkcija lahko panic, če ima iterator več kot `usize::MAX` ne ujemajočih se elementov.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Ustavitev pri prvem `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // še vedno lahko uporabimo `iter`, saj je elementov več.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Vrnjeni indeks je odvisen od stanja iteratorja
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Poišče element v iteratorju z desne strani in vrne njegov indeks.
    ///
    /// `rposition()` zapira, ki vrne `true` ali `false`.
    /// To zapiranje uporabi za vsak element iteratorja, začenši od konca, in če eden od njih vrne `true`, potem `rposition()` vrne [`Some(index)`].
    ///
    /// Če vsi vrnejo `false`, vrne [`None`].
    ///
    /// `rposition()` je v kratkem stiku;z drugimi besedami, preneha z obdelavo, takoj ko najde `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Ustavitev pri prvem `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // še vedno lahko uporabimo `iter`, saj je elementov več.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Tu ni potrebe po preverjanju prelivanja, ker `ExactSizeIterator` pomeni, da število elementov ustreza `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Vrne največji element iteratorja.
    ///
    /// Če je več elementov enako največ, se vrne zadnji element.
    /// Če je iterator prazen, se vrne [`None`].
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Vrne najmanjši element iteratorja.
    ///
    /// Če je več elementov enako najmanj, se vrne prvi element.
    /// Če je iterator prazen, se vrne [`None`].
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Vrne element, ki daje največjo vrednost iz podane funkcije.
    ///
    ///
    /// Če je več elementov enako največ, se vrne zadnji element.
    /// Če je iterator prazen, se vrne [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Vrne element, ki daje največjo vrednost glede na navedeno funkcijo primerjave.
    ///
    ///
    /// Če je več elementov enako največ, se vrne zadnji element.
    /// Če je iterator prazen, se vrne [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Vrne element, ki podaja najmanjšo vrednost iz podane funkcije.
    ///
    ///
    /// Če je več elementov enako najmanj, se vrne prvi element.
    /// Če je iterator prazen, se vrne [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Vrne element, ki daje najmanjšo vrednost glede na navedeno funkcijo primerjave.
    ///
    ///
    /// Če je več elementov enako najmanj, se vrne prvi element.
    /// Če je iterator prazen, se vrne [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Obrne smer iteratorja.
    ///
    /// Ponavadi se iteratorji ponavljajo od leve proti desni.
    /// Po uporabi `rev()` se iterator namesto tega ponovi od desne proti levi.
    ///
    /// To je mogoče le, če ima iterator konec, zato `rev()` deluje samo na [`DoubleEndedIterator`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Pretvori iterator parov v par vsebnikov.
    ///
    /// `unzip()` porabi celoten iterator parov in ustvari dve zbirki: eno iz levih elementov parov in eno iz desnih elementov.
    ///
    ///
    /// Ta funkcija je v nekem smislu nasprotna [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Ustvari iterator, ki kopira vse njegove elemente.
    ///
    /// To je uporabno, če imate iterator nad `&T`, vendar potrebujete iterator nad `T`.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // kopirano je enako kot .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Ustvari iterator, ki [`clone`] vsebuje vse njegove elemente.
    ///
    /// To je uporabno, če imate iterator nad `&T`, vendar potrebujete iterator nad `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // cloned je za cela števila enak .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Ponavlja iterator neskončno.
    ///
    /// Namesto da se ustavi pri [`None`], se bo iterator namesto tega začel znova, od začetka.Po ponovni ponovitvi se bo znova začel na začetku.In spet.
    /// In spet.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Sešteva elemente iteratorja.
    ///
    /// Vsak element vzame, sešteje in vrne rezultat.
    ///
    /// Prazen iterator vrne ničelno vrednost tipa.
    ///
    /// # Panics
    ///
    /// Ko prikličete `sum()` in vrnete primitivno celoštevilsko vrsto, bo ta metoda panic, če so izračuni prekoračeni in trditve za odpravljanje napak omogočene.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Vpliva na celoten iterator in množi vse elemente
    ///
    /// Prazen iterator vrne eno vrednost tipa.
    ///
    /// # Panics
    ///
    /// Ko prikličete `product()` in vrnete primitivno celoštevilsko vrsto, bo metoda panic, če so izračuni prekoračeni in trditve za odpravljanje napak omogočene.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) primerja elemente tega [`Iterator`] z elementi drugega.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) primerja elemente tega [`Iterator`] z elementi drugega glede na določeno funkcijo primerjave.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) primerja elemente tega [`Iterator`] z elementi drugega.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) primerja elemente tega [`Iterator`] z elementi drugega glede na določeno funkcijo primerjave.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Določa, ali so elementi tega [`Iterator`] enaki elementom drugega.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Določa, ali so elementi tega [`Iterator`] enaki elementom drugega glede na določeno funkcijo enakosti.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Določa, ali so elementi tega [`Iterator`] neenaki z elementi drugega.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Določa, ali so elementi tega [`Iterator`] za [lexicographically](Ord#lexicographical-comparison) manjši od elementov drugega.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Določa, ali so elementi tega [`Iterator`] [lexicographically](Ord#lexicographical-comparison) manjši ali enaki elementom drugega.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Določa, ali so elementi tega [`Iterator`] za [lexicographically](Ord#lexicographical-comparison) večji od elementov drugega.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Določa, ali so elementi tega [`Iterator`] [lexicographically](Ord#lexicographical-comparison) večji ali enaki elementom drugega.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Preveri, ali so elementi tega iteratorja razvrščeni.
    ///
    /// To pomeni, da mora za vsak element `a` in naslednji element `b` veljati `a <= b`.Če iterator daje natančno nič ali en element, se vrne `true`.
    ///
    /// Če je `Self::Item` samo `PartialOrd`, ne pa tudi `Ord`, zgornja definicija pomeni, da ta funkcija vrne `false`, če katera koli zaporedna elementa nista primerljiva.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Preveri, ali so elementi tega iteratorja razvrščeni z dano primerjalno funkcijo.
    ///
    /// Namesto da uporablja `PartialOrd::partial_cmp`, ta funkcija uporablja dano funkcijo `compare` za določanje razvrščanja dveh elementov.
    /// Poleg tega je enakovreden [`is_sorted`];glejte njegovo dokumentacijo za več informacij.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Preveri, ali so elementi tega iteratorja razvrščeni z dano funkcijo izvlečenja ključa.
    ///
    /// Namesto da neposredno primerja elemente iteratorja, ta funkcija primerja tipke elementov, kot jih določa `f`.
    /// Poleg tega je enakovreden [`is_sorted`];glejte njegovo dokumentacijo za več informacij.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Glejte [TrustedRandomAccess]
    // Nenavadno ime je izogibanje trkom imen v ločljivosti metode, glejte #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}