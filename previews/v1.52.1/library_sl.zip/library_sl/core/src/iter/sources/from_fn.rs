use crate::fmt;

/// Ustvari nov iterator, kjer vsaka ponovitev pokliče predvideno zaporo `F: FnMut() -> Option<T>`.
///
/// To omogoča ustvarjanje prilagojenega iteratorja s kakršnim koli vedenjem, ne da bi uporabili bolj podrobno sintakso ustvarjanja namenskega tipa in zanj implementirali [`Iterator`] Portrait.
///
/// Upoštevajte, da iterator `FromFn` ne predvideva vedenja zapiranja in zato konzervativno ne izvaja [`FusedIterator`] ali preglasi [`Iterator::size_hint()`] iz privzetega `(0, None)`.
///
///
/// Zapora lahko uporablja zajemanje in njegovo okolje za sledenje stanja med ponovitvami.Glede na to, kako se uporablja iterator, bo morda treba na zapiranju navesti ključno besedo [`move`].
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Ponovno izvedimo števec iterator iz [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Povečaj naše štetje.Zato smo začeli z ničlo.
///     count += 1;
///
///     // Preverite, ali smo končali s štetjem ali ne.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Ponavljalec, pri katerem vsaka ponovitev pokliče predvideno zapiranje `F: FnMut() -> Option<T>`.
///
/// Ta `struct` je ustvarjena s funkcijo [`iter::from_fn()`].
/// Za več si oglejte njegovo dokumentacijo.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}