use crate::iter::{FusedIterator, TrustedLen};

/// Ustvari iterator, ki leno ustvari vrednost natanko enkrat s priklicem predvidene zapore.
///
/// To se običajno uporablja za prilagajanje posameznega generatorja vrednosti v [`chain()`] drugih vrst ponovitev.
/// Mogoče imate iterator, ki pokriva skoraj vse, vendar potrebujete dodaten poseben primer.
/// Mogoče imate funkcijo, ki deluje na iteratorjih, vendar morate obdelati samo eno vrednost.
///
/// Za razliko od [`once()`] bo ta funkcija na zahtevo leno generirala vrednost.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Osnovna uporaba:
///
/// ```
/// use std::iter;
///
/// // ena je najbolj osamljena številka
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // samo eno, to je vse, kar dobimo
/// assert_eq!(None, one.next());
/// ```
///
/// Povezovanje z drugim iteratorjem.
/// Recimo, da želimo itirirati po vsaki datoteki imenika `.foo`, pa tudi po konfiguracijski datoteki,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // iz iteratorja DirEntry-s moramo pretvoriti v iterator PathBufs, zato uporabljamo map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // zdaj naš iterator samo za našo konfiguracijsko datoteko
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // oba iteratorja povežite v en velik iterator
/// let files = dirs.chain(config);
///
/// // to nam bo dalo vse datoteke v .foo in .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Iterator, ki ustvari posamezen element tipa `A` z uporabo priložene zapore `F: FnOnce() -> A`.
///
///
/// Ta `struct` je ustvarjena s funkcijo [`once_with()`].
/// Za več si oglejte njegovo dokumentacijo.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}