use crate::iter::{FusedIterator, TrustedLen};

/// Ustvari iterator, ki natančno enkrat prikaže element.
///
/// To se običajno uporablja za prilagoditev posamezne vrednosti v [`chain()`] drugih vrst ponovitev.
/// Mogoče imate iterator, ki pokriva skoraj vse, vendar potrebujete dodaten poseben primer.
/// Mogoče imate funkcijo, ki deluje na iteratorjih, vendar morate obdelati samo eno vrednost.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Osnovna uporaba:
///
/// ```
/// use std::iter;
///
/// // ena je najbolj osamljena številka
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // samo eno, to je vse, kar dobimo
/// assert_eq!(None, one.next());
/// ```
///
/// Povezovanje z drugim iteratorjem.
/// Recimo, da želimo itirirati po vsaki datoteki imenika `.foo`, pa tudi po konfiguracijski datoteki,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // iz iteratorja DirEntry-s moramo pretvoriti v iterator PathBufs, zato uporabljamo map
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // zdaj naš iterator samo za našo konfiguracijsko datoteko
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // oba iteratorja povežite v en velik iterator
/// let files = dirs.chain(config);
///
/// // to nam bo dalo vse datoteke v .foo in .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Ponavljalec, ki element prikaže natanko enkrat.
///
/// Ta `struct` je ustvarjena s funkcijo [`once()`].Za več si oglejte njegovo dokumentacijo.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}