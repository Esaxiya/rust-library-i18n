use crate::iter::{FusedIterator, TrustedLen};

/// Ustvari nov iterator, ki neskončno ponavlja elemente tipa `A` z uporabo predvidene zapore, repetitorja, `F: FnMut() -> A`.
///
/// Funkcija `repeat_with()` ponavljalnik vedno znova pokliče.
///
/// Neskončni iteratorji, kot je `repeat_with()`, se pogosto uporabljajo z adapterji, kot je [`Iterator::take()`], da postanejo končni.
///
/// Če vrsta elementa iteratorja, ki ga potrebujete, implementira [`Clone`] in je v redu, če izvorni element shranite v pomnilnik, raje uporabite funkcijo [`repeat()`].
///
///
/// Ponavljalec, ki ga je ustvaril `repeat_with()`, ni [`DoubleEndedIterator`].
/// Če potrebujete `repeat_with()` za vrnitev [`DoubleEndedIterator`], odprite težavo z GitHubom, ki razloži vaš primer uporabe.
///
/// [`repeat()`]: crate::iter::repeat
/// [`DoubleEndedIterator`]: crate::iter::DoubleEndedIterator
///
/// # Examples
///
/// Osnovna uporaba:
///
/// ```
/// use std::iter;
///
/// // domnevamo, da imamo nekaj vrednosti vrste, ki ni `Clone` ali ki je še ne želimo imeti v spominu, ker je draga:
/////
/// #[derive(PartialEq, Debug)]
/// struct Expensive;
///
/// // določena vrednost za vedno:
/// let mut things = iter::repeat_with(|| Expensive);
///
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// assert_eq!(Some(Expensive), things.next());
/// ```
///
/// Uporaba mutacije in dokončno:
///
/// ```rust
/// use std::iter;
///
/// // Od ničle do tretje stopnje dva:
/// let mut curr = 1;
/// let mut pow2 = iter::repeat_with(|| { let tmp = curr; curr *= 2; tmp })
///                     .take(4);
///
/// assert_eq!(Some(1), pow2.next());
/// assert_eq!(Some(2), pow2.next());
/// assert_eq!(Some(4), pow2.next());
/// assert_eq!(Some(8), pow2.next());
///
/// // ... in zdaj smo končali
/// assert_eq!(None, pow2.next());
/// ```
///
///
///
///
#[inline]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub fn repeat_with<A, F: FnMut() -> A>(repeater: F) -> RepeatWith<F> {
    RepeatWith { repeater }
}

/// Ponavljalec, ki neskončno ponavlja elemente tipa `A` z uporabo priložene zapore `F: FnMut() -> A`.
///
///
/// Ta `struct` je ustvarjena s funkcijo [`repeat_with()`].
/// Za več si oglejte njegovo dokumentacijo.
#[derive(Copy, Clone, Debug)]
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub struct RepeatWith<F> {
    repeater: F,
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> Iterator for RepeatWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some((self.repeater)())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
impl<A, F: FnMut() -> A> FusedIterator for RepeatWith<F> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A, F: FnMut() -> A> TrustedLen for RepeatWith<F> {}