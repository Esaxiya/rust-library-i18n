use crate::iter::{FusedIterator, TrustedLen};

/// Ustvari nov iterator, ki neskončno ponavlja en sam element.
///
/// Funkcija `repeat()` znova in znova ponavlja eno samo vrednost.
///
/// Neskončni iteratorji, kot je `repeat()`, se pogosto uporabljajo z adapterji, kot je [`Iterator::take()`], da postanejo končni.
///
/// Če vrsta elementa iteratorja, ki ga potrebujete, ne izvaja `Clone` ali če ponovljenega elementa ne želite obdržati v pomnilniku, lahko namesto tega uporabite funkcijo [`repeat_with()`].
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Osnovna uporaba:
///
/// ```
/// use std::iter;
///
/// // številka štiri 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // ja, še vedno štiri
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Končno z [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // zadnji primer je bil preveč štiric.Imejmo samo štiri noge.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... in zdaj smo končali
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Ponavljalec, ki element neskončno ponavlja.
///
/// Ta `struct` je ustvarjena s funkcijo [`repeat()`].Za več si oglejte njegovo dokumentacijo.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}