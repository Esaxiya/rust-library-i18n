use crate::char;
use crate::convert::TryFrom;
use crate::mem;
use crate::ops::{self, Try};

use super::{FusedIterator, TrustedLen};

/// Predmeti, ki imajo pojem *naslednik* in *predhodnik*.
///
/// Operacija *naslednik* se premakne k vrednostim, ki so primerljive večje.
/// Operacija *predhodnik* se premakne k vrednostim, ki primerjajo manjše.
///
/// # Safety
///
/// Ta Portrait je `unsafe`, ker mora biti njegova izvedba pravilna zaradi varnosti izvedb `unsafe trait TrustedLen`, drugače pa lahko koda `unsafe` zaupa rezultatom uporabe te Portrait, da je pravilna in izpolnjuje naštete obveznosti.
///
///
///
#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
pub unsafe trait Step: Clone + PartialOrd + Sized {
    /// Vrne število korakov *naslednika*, potrebnih za prehod od `start` do `end`.
    ///
    /// Vrne `None`, če bi število korakov preseglo `usize` (ali je neskončno ali če `end` ne bi bil nikoli dosežen).
    ///
    ///
    /// # Invariants
    ///
    /// Za vse `a`, `b` in `n`:
    ///
    /// * `steps_between(&a, &b) == Some(n)` če in samo, če `Step::forward_checked(&a, n) == Some(b)`
    /// * `steps_between(&a, &b) == Some(n)` če in samo, če `Step::backward_checked(&a, n) == Some(a)`
    /// * `steps_between(&a, &b) == Some(n)` samo če `a <= b`
    ///   * Posledica: `steps_between(&a, &b) == Some(0)` takrat in samo, če je `a == b`
    ///   * Upoštevajte, da `a <= b` _not_ pomeni `steps_between(&a, &b) != None`;
    ///     v tem primeru je za doseganje `b` potrebnih več kot `usize::MAX` korakov
    /// * `steps_between(&a, &b) == None` če `a > b`
    fn steps_between(start: &Self, end: &Self) -> Option<usize>;

    /// Vrne vrednost, ki bi bila dobljena z odvzemom *naslednika*`self` `count` krat.
    ///
    /// Če bi to preseglo obseg vrednosti, ki jih podpira `Self`, vrne `None`.
    ///
    /// # Invariants
    ///
    /// Za vse `a`, `n` in `m`:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, m).and_then(|x| Step::forward_checked(x, n))`
    ///
    ///
    /// Za vse `a`, `n` in `m`, kjer se `n + m` ne preliva:
    ///
    /// * `Step::forward_checked(a, n).and_then(|x| Step::forward_checked(x, m)) == Step::forward_checked(a, n + m)`
    ///
    /// Za vse `a` in `n`:
    ///
    /// * `Step::forward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::forward_checked(&x, 1))`
    ///   * Corollary: `Step::forward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward_checked(start: Self, count: usize) -> Option<Self>;

    /// Vrne vrednost, ki bi bila dobljena z odvzemom *naslednika*`self` `count` krat.
    ///
    /// Če bi to preseglo obseg vrednosti, ki jih podpira `Self`, je ta funkcija dovoljena za panic, zavijanje ali nasičenje.
    ///
    /// Predlagano vedenje je panic, ko so omogočene trditve za odpravljanje napak, in drugače zavijanje ali nasičenje.
    ///
    /// Nevarna koda se ne sme zanašati na pravilnost vedenja po prelivanju.
    ///
    /// # Invariants
    ///
    /// Za vse `a`, `n` in `m`, kjer ne pride do prelivanja:
    ///
    /// * `Step::forward(Step::forward(a, n), m) == Step::forward(a, n + m)`
    ///
    /// Za kateri koli `a` in `n`, kjer ne pride do prelivanja:
    ///
    /// * `Step::forward_checked(a, n) == Some(Step::forward(a, n))`
    /// * `Step::forward(a, n) == (0..n).fold(a, |x, _| Step::forward(x, 1))`
    ///   * Corollary: `Step::forward(a, 0) == a`
    /// * `Step::forward(a, n) >= a`
    /// * `Step::backward(Step::forward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn forward(start: Self, count: usize) -> Self {
        Step::forward_checked(start, count).expect("overflow in `Step::forward`")
    }

    /// Vrne vrednost, ki bi bila dobljena z odvzemom *naslednika*`self` `count` krat.
    ///
    /// # Safety
    ///
    /// Za to operacijo ni določeno vedenje, da preseže obseg vrednosti, ki jih podpira `Self`.
    /// Če ne morete jamčiti, da se to ne bo prelilo, raje uporabite `forward` ali `forward_checked`.
    ///
    /// # Invariants
    ///
    /// Za kateri koli `a`:
    ///
    /// * če obstaja `b`, takšen kot `b > a`, je varno poklicati `Step::forward_unchecked(a, 1)`
    /// * če obstajajo `b`, `n`, takšni kot `steps_between(&a, &b) == Some(n)`, je varno poklicati `Step::forward_unchecked(a, m)` za kateri koli `m <= n`.
    ///
    ///
    /// Za kateri koli `a` in `n`, kjer ne pride do prelivanja:
    ///
    /// * `Step::forward_unchecked(a, n)` je enakovredno `Step::forward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn forward_unchecked(start: Self, count: usize) -> Self {
        Step::forward(start, count)
    }

    /// Vrne vrednost, ki bi bila dobljena z odvzemom *predhodnika* X-krat `count`-krat.
    ///
    /// Če bi to preseglo obseg vrednosti, ki jih podpira `Self`, vrne `None`.
    ///
    /// # Invariants
    ///
    /// Za vse `a`, `n` in `m`:
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == n.checked_add(m).and_then(|x| Step::backward_checked(a, x))`
    ///
    /// * `Step::backward_checked(a, n).and_then(|x| Step::backward_checked(x, m)) == try { Step::backward_checked(a, n.checked_add(m)?) }`
    ///
    /// Za vse `a` in `n`:
    ///
    /// * `Step::backward_checked(a, n) == (0..n).try_fold(a, |x, _| Step::backward_checked(&x, 1))`
    ///   * Corollary: `Step::backward_checked(&a, 0) == Some(a)`
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward_checked(start: Self, count: usize) -> Option<Self>;

    /// Vrne vrednost, ki bi bila dobljena z odvzemom *predhodnika* X-krat `count`-krat.
    ///
    /// Če bi to preseglo obseg vrednosti, ki jih podpira `Self`, je ta funkcija dovoljena za panic, zavijanje ali nasičenje.
    ///
    /// Predlagano vedenje je panic, ko so omogočene trditve za odpravljanje napak, in drugače zavijanje ali nasičenje.
    ///
    /// Nevarna koda se ne sme zanašati na pravilnost vedenja po prelivanju.
    ///
    /// # Invariants
    ///
    /// Za vse `a`, `n` in `m`, kjer ne pride do prelivanja:
    ///
    /// * `Step::backward(Step::backward(a, n), m) == Step::backward(a, n + m)`
    ///
    /// Za kateri koli `a` in `n`, kjer ne pride do prelivanja:
    ///
    /// * `Step::backward_checked(a, n) == Some(Step::backward(a, n))`
    /// * `Step::backward(a, n) == (0..n).fold(a, |x, _| Step::backward(x, 1))`
    ///   * Corollary: `Step::backward(a, 0) == a`
    /// * `Step::backward(a, n) <= a`
    /// * `Step::forward(Step::backward(a, n), n) == a`
    ///
    ///
    #[unstable(feature = "step_trait_ext", reason = "recently added", issue = "42168")]
    fn backward(start: Self, count: usize) -> Self {
        Step::backward_checked(start, count).expect("overflow in `Step::backward`")
    }

    /// Vrne vrednost, ki bi bila dobljena z odvzemom *predhodnika* X-krat `count`-krat.
    ///
    /// # Safety
    ///
    /// Za to operacijo ni določeno vedenje, da preseže obseg vrednosti, ki jih podpira `Self`.
    /// Če ne morete jamčiti, da se to ne bo prelilo, raje uporabite `backward` ali `backward_checked`.
    ///
    /// # Invariants
    ///
    /// Za kateri koli `a`:
    ///
    /// * če obstaja `b`, takšen kot `b < a`, je varno poklicati `Step::backward_unchecked(a, 1)`
    /// * če obstajajo `b`, `n`, takšni kot `steps_between(&b, &a) == Some(n)`, je varno poklicati `Step::backward_unchecked(a, m)` za kateri koli `m <= n`.
    ///
    ///
    /// Za kateri koli `a` in `n`, kjer ne pride do prelivanja:
    ///
    /// * `Step::backward_unchecked(a, n)` je enakovredno `Step::backward(a, n)`
    ///
    ///
    #[unstable(feature = "unchecked_math", reason = "niche optimization path", issue = "none")]
    unsafe fn backward_unchecked(start: Self, count: usize) -> Self {
        Step::backward(start, count)
    }
}

// Ti so še vedno generirani z makro, ker se celoštevilske literale razrešijo na različne tipe.
macro_rules! step_identical_methods {
    () => {
        #[inline]
        unsafe fn forward_unchecked(start: Self, n: usize) -> Self {
            // VARNOST: klicatelj mora zagotoviti, da se `start + n` ne bo prelival.
            unsafe { start.unchecked_add(n as Self) }
        }

        #[inline]
        unsafe fn backward_unchecked(start: Self, n: usize) -> Self {
            // VARNOST: klicatelj mora zagotoviti, da se `start - n` ne bo prelival.
            unsafe { start.unchecked_sub(n as Self) }
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn forward(start: Self, n: usize) -> Self {
            // V gradnjah za odpravljanje napak sprožite panic ob prelivanju.
            // To bi moralo popolnoma optimizirati gradnje različic izdaje.
            if Self::forward_checked(start, n).is_none() {
                let _ = Self::MAX + 1;
            }
            // Zavijte matematiko, da omogočite npr `Step::forward(-128i8, 255)`.
            start.wrapping_add(n as Self)
        }

        #[inline]
        #[allow(arithmetic_overflow)]
        #[rustc_inherit_overflow_checks]
        fn backward(start: Self, n: usize) -> Self {
            // V gradnjah za odpravljanje napak sprožite panic ob prelivanju.
            // To bi moralo popolnoma optimizirati gradnje različic izdaje.
            if Self::backward_checked(start, n).is_none() {
                let _ = Self::MIN - 1;
            }
            // Zavijte matematiko, da omogočite npr `Step::backward(127i8, 255)`.
            start.wrapping_sub(n as Self)
        }
    };
}

macro_rules! step_integer_impls {
    {
        narrower than or same width as usize:
            $( [ $u_narrower:ident $i_narrower:ident ] ),+;
        wider than usize:
            $( [ $u_wider:ident $i_wider:ident ] ),+;
    } => {
        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // To temelji na $u_narrower <=usize
                        Some((*end - *start) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_add(n),
                        Err(_) => None, // če je n zunaj dosega, je tudi `unsigned_start + n`
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match Self::try_from(n) {
                        Ok(n) => start.checked_sub(n),
                        Err(_) => None, // če je n zunaj dosega, je tudi `unsigned_start - n`
                    }
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_narrower {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        // Ta temelji na $i_narrower <=usize
                        //
                        // Ulivanje v velikost poveča širino, vendar ohrani znak.
                        // Uporabite wrapping_sub v prostoru velikosti isize in oddajte za uporabo, da izračunate razliko, ki morda ne ustreza znotraj obsega isize.
                        //
                        Some((*end as isize).wrapping_sub(*start as isize) as usize)
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Zavijanje obravnava ohišja, kot je `Step::forward(-120_i8, 200) == Some(80_i8)`, čeprav je 200 za i8 izven dosega.
                            //
                            //
                            let wrapped = start.wrapping_add(n as Self);
                            if wrapped >= start {
                                Some(wrapped)
                            } else {
                                None // Dodatek je bil preliven
                            }
                        }
                        // Če je n zunaj obsega npr
                        // u8, potem je večji, kot je celoten obseg i8 širok, zato `any_i8 + n` nujno preseže i8.
                        //
                        Err(_) => None,
                    }
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    match $u_narrower::try_from(n) {
                        Ok(n) => {
                            // Zavijanje obravnava ohišja, kot je `Step::forward(-120_i8, 200) == Some(80_i8)`, čeprav je 200 za i8 izven dosega.
                            //
                            //
                            let wrapped = start.wrapping_sub(n as Self);
                            if wrapped <= start {
                                Some(wrapped)
                            } else {
                                None // Odštevanje je preplavljeno
                            }
                        }
                        // Če je n zunaj obsega npr
                        // u8, potem je večji, kot je celoten obseg i8 širok, zato `any_i8 - n` nujno preseže i8.
                        //
                        Err(_) => None,
                    }
                }
            }
        )+

        $(
            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $u_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        usize::try_from(*end - *start).ok()
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }

            #[allow(unreachable_patterns)]
            #[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
            unsafe impl Step for $i_wider {
                step_identical_methods!();

                #[inline]
                fn steps_between(start: &Self, end: &Self) -> Option<usize> {
                    if *start <= *end {
                        match end.checked_sub(*start) {
                            Some(result) => usize::try_from(result).ok(),
                            // Če je razlika prevelika za npr
                            // i128, bo tudi prevelik za uporabo z manj bitov.
                            None => None,
                        }
                    } else {
                        None
                    }
                }

                #[inline]
                fn forward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_add(n as Self)
                }

                #[inline]
                fn backward_checked(start: Self, n: usize) -> Option<Self> {
                    start.checked_sub(n as Self)
                }
            }
        )+
    };
}

#[cfg(target_pointer_width = "64")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [u64 i64], [usize isize];
    wider than usize: [u128 i128];
}

#[cfg(target_pointer_width = "32")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [u32 i32], [usize isize];
    wider than usize: [u64 i64], [u128 i128];
}

#[cfg(target_pointer_width = "16")]
step_integer_impls! {
    narrower than or same width as usize: [u8 i8], [u16 i16], [usize isize];
    wider than usize: [u32 i32], [u64 i64], [u128 i128];
}

#[unstable(feature = "step_trait", reason = "recently redesigned", issue = "42168")]
unsafe impl Step for char {
    #[inline]
    fn steps_between(&start: &char, &end: &char) -> Option<usize> {
        let start = start as u32;
        let end = end as u32;
        if start <= end {
            let count = end - start;
            if start < 0xD800 && 0xE000 <= end {
                usize::try_from(count - 0x800).ok()
            } else {
                usize::try_from(count).ok()
            }
        } else {
            None
        }
    }

    #[inline]
    fn forward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::forward_checked(start, count)?;
        if start < 0xD800 && 0xD800 <= res {
            res = Step::forward_checked(res, 0x800)?;
        }
        if res <= char::MAX as u32 {
            // VARNOST: res je veljaven skalar Unicode
            // (pod 0x110000 in ne v 0xD800..0xE000)
            Some(unsafe { char::from_u32_unchecked(res) })
        } else {
            None
        }
    }

    #[inline]
    fn backward_checked(start: char, count: usize) -> Option<char> {
        let start = start as u32;
        let mut res = Step::backward_checked(start, count)?;
        if start >= 0xE000 && 0xE000 > res {
            res = Step::backward_checked(res, 0x800)?;
        }
        // VARNOST: res je veljaven skalar Unicode
        // (pod 0x110000 in ne v 0xD800..0xE000)
        Some(unsafe { char::from_u32_unchecked(res) })
    }

    #[inline]
    unsafe fn forward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // VARNOST: klicatelj mora zagotoviti, da se to ne bo prelivalo
        // obseg vrednosti za znak.
        let mut res = unsafe { Step::forward_unchecked(start, count) };
        if start < 0xD800 && 0xD800 <= res {
            // VARNOST: klicatelj mora zagotoviti, da se to ne bo prelivalo
            // obseg vrednosti za znak.
            res = unsafe { Step::forward_unchecked(res, 0x800) };
        }
        // VARNOST: zaradi prejšnje pogodbe je to zagotovljeno
        // klicatelj veljaven znak.
        unsafe { char::from_u32_unchecked(res) }
    }

    #[inline]
    unsafe fn backward_unchecked(start: char, count: usize) -> char {
        let start = start as u32;
        // VARNOST: klicatelj mora zagotoviti, da se to ne bo prelivalo
        // obseg vrednosti za znak.
        let mut res = unsafe { Step::backward_unchecked(start, count) };
        if start >= 0xE000 && 0xE000 > res {
            // VARNOST: klicatelj mora zagotoviti, da se to ne bo prelivalo
            // obseg vrednosti za znak.
            res = unsafe { Step::backward_unchecked(res, 0x800) };
        }
        // VARNOST: zaradi prejšnje pogodbe je to zagotovljeno
        // klicatelj veljaven znak.
        unsafe { char::from_u32_unchecked(res) }
    }
}

macro_rules! range_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "rust1", since = "1.0.0")]
        impl ExactSizeIterator for ops::Range<$t> { }
    )*)
}

macro_rules! range_incl_exact_iter_impl {
    ($($t:ty)*) => ($(
        #[stable(feature = "inclusive_range", since = "1.26.0")]
        impl ExactSizeIterator for ops::RangeInclusive<$t> { }
    )*)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::Range<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.start < self.end {
            // VARNOST: pravkar preverjen predpogoj
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            Some(mem::replace(&mut self.start, n))
        } else {
            None
        }
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.start < self.end {
            let hint = Step::steps_between(&self.start, &self.end);
            (hint.unwrap_or(usize::MAX), hint)
        } else {
            (0, Some(0))
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            if plus_n < self.end {
                // VARNOST: pravkar preverjen predpogoj
                self.start = unsafe { Step::forward_unchecked(plus_n.clone(), 1) };
                return Some(plus_n);
            }
        }

        self.start = self.end.clone();
        None
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

// Ti makri generirajo impulze `ExactSizeIterator` za različne vrste obsega.
//
// * `ExactSizeIterator::len` mora vedno vrniti natančen `usize`, zato noben razpon ne sme biti daljši od `usize::MAX`.
//
// * Za celoštevilčne vrste v `Range<_>` to velja za vrste, ki so ožje ali širše od `usize`.
//   Za celoštevilčne tipe v `RangeInclusive<_>` to velja za tipe *strogo ožji* od `usize`, ker npr
//   `(0..=u64::MAX).len()` bi bil `u64::MAX + 1`.
//
range_exact_iter_impl! {
    usize u8 u16
    isize i8 i16

    // Ti so v skladu z zgornjimi razlogi nedorečeni, vendar bi bila njihova odstranitev velika sprememba, saj so bili stabilizirani v Rust 1.0.0.
    // Tako npr
    // `(0..66_000_u32).len()` na primer bo sestavil brez napak ali opozoril na 16-bitnih platformah, vendar bo še naprej dajal napačen rezultat.
    //
    u32
    i32
}
range_incl_exact_iter_impl! {
    u8
    i8

    // Ti so v skladu z zgornjimi razlogi nedorečeni, vendar bi bila njihova odstranitev velika sprememba, saj so bili stabilizirani v Rust 1.26.0.
    // Tako npr
    // `(0..=u16::MAX).len()` na primer bo sestavil brez napak ali opozoril na 16-bitnih platformah, vendar bo še naprej dajal napačen rezultat.
    //
    u16
    i16
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> DoubleEndedIterator for ops::Range<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.start < self.end {
            // VARNOST: pravkar preverjen predpogoj
            self.end = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            Some(self.end.clone())
        } else {
            None
        }
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            if minus_n > self.start {
                // VARNOST: pravkar preverjen predpogoj
                self.end = unsafe { Step::backward_unchecked(minus_n, 1) };
                return Some(self.end.clone());
            }
        }

        self.end = self.start.clone();
        None
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::Range<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::Range<A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Step> Iterator for ops::RangeFrom<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let n = Step::forward(self.start.clone(), 1);
        Some(mem::replace(&mut self.start, n))
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        let plus_n = Step::forward(self.start.clone(), n);
        self.start = Step::forward(plus_n.clone(), 1);
        Some(plus_n)
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeFrom<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeFrom<A> {}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> Iterator for ops::RangeInclusive<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // VARNOST: pravkar preverjen predpogoj
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            mem::replace(&mut self.start, n)
        } else {
            self.exhausted = true;
            self.start.clone()
        })
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.is_empty() {
            return (0, Some(0));
        }

        match Step::steps_between(&self.start, &self.end) {
            Some(hint) => (hint.saturating_add(1), hint.checked_add(1)),
            None => (usize::MAX, None),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(plus_n) = Step::forward_checked(self.start.clone(), n) {
            use crate::cmp::Ordering::*;

            match plus_n.partial_cmp(&self.end) {
                Some(Less) => {
                    self.start = Step::forward(plus_n.clone(), 1);
                    return Some(plus_n);
                }
                Some(Equal) => {
                    self.start = plus_n.clone();
                    self.exhausted = true;
                    return Some(plus_n);
                }
                _ => {}
            }
        }

        self.start = self.end.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // VARNOST: pravkar preverjen predpogoj
            let n = unsafe { Step::forward_unchecked(self.start.clone(), 1) };
            let n = mem::replace(&mut self.start, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn fold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_fold(init, ok(f)).unwrap()
    }

    #[inline]
    fn last(mut self) -> Option<A> {
        self.next_back()
    }

    #[inline]
    fn min(mut self) -> Option<A> {
        self.next()
    }

    #[inline]
    fn max(mut self) -> Option<A> {
        self.next_back()
    }
}

#[stable(feature = "inclusive_range", since = "1.26.0")]
impl<A: Step> DoubleEndedIterator for ops::RangeInclusive<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        if self.is_empty() {
            return None;
        }
        let is_iterating = self.start < self.end;
        Some(if is_iterating {
            // VARNOST: pravkar preverjen predpogoj
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            mem::replace(&mut self.end, n)
        } else {
            self.exhausted = true;
            self.end.clone()
        })
    }

    #[inline]
    fn nth_back(&mut self, n: usize) -> Option<A> {
        if self.is_empty() {
            return None;
        }

        if let Some(minus_n) = Step::backward_checked(self.end.clone(), n) {
            use crate::cmp::Ordering::*;

            match minus_n.partial_cmp(&self.start) {
                Some(Greater) => {
                    self.end = Step::backward(minus_n.clone(), 1);
                    return Some(minus_n);
                }
                Some(Equal) => {
                    self.end = minus_n.clone();
                    self.exhausted = true;
                    return Some(minus_n);
                }
                _ => {}
            }
        }

        self.end = self.start.clone();
        self.exhausted = true;
        None
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        if self.is_empty() {
            return try { init };
        }

        let mut accum = init;

        while self.start < self.end {
            // VARNOST: pravkar preverjen predpogoj
            let n = unsafe { Step::backward_unchecked(self.end.clone(), 1) };
            let n = mem::replace(&mut self.end, n);
            accum = f(accum, n)?;
        }

        self.exhausted = true;

        if self.start == self.end {
            accum = f(accum, self.start.clone())?;
        }

        try { accum }
    }

    #[inline]
    fn rfold<B, F>(mut self, init: B, f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        #[inline]
        fn ok<B, T>(mut f: impl FnMut(B, T) -> B) -> impl FnMut(B, T) -> Result<B, !> {
            move |acc, x| Ok(f(acc, x))
        }

        self.try_rfold(init, ok(f)).unwrap()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Step> TrustedLen for ops::RangeInclusive<A> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Step> FusedIterator for ops::RangeInclusive<A> {}