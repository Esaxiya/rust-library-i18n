//! Sestavljiva zunanja ponovitev.
//!
//! Če ste se znašli s kakšno zbirko in potrebujete operacijo elementov omenjene zbirke, boste hitro naleteli na 'iterators'.
//! Iteratorji se pogosto uporabljajo v idiomatični kodi Rust, zato se jih je vredno seznaniti.
//!
//! Preden razložimo več, se pogovorimo o strukturi tega modula:
//!
//! # Organization
//!
//! Ta modul je večinoma organiziran po vrstah:
//!
//! * [Traits] so jedrni del: ti traits določajo, kakšni iteratorji obstajajo in kaj lahko z njimi naredite.Za metode teh traits je vredno vložiti nekaj dodatnega časa za učenje.
//! * [Functions] zagotoviti nekaj koristnih načinov za ustvarjanje nekaterih osnovnih iteratorjev.
//! * [Structs] so pogosto vrste vrnitve različnih metod na traits tega modula.Običajno boste želeli pogledati metodo, ki ustvarja `struct`, namesto samega `struct`.
//! Za več podrobnosti o tem, zakaj, glejte '[Implementing Iterator](#Implementation-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! To je to!Pojdimo v iteratorje.
//!
//! # Iterator
//!
//! Srce in duša tega modula je [`Iterator`] Portrait.Jedro [`Iterator`] je videti takole:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Iterator ima metodo [`next`], ki ob klicu vrne [`Možnost`]`<Item>`.
//! [`next`] bo vrnil [`Some(Item)`], dokler obstajajo elementi, in ko bodo vsi izčrpani, bo vrnil `None`, kar pomeni, da je ponovitev končana.
//! Posamezni iteratorji se lahko odločijo, da nadaljujejo s ponovitvijo, zato lahko klic [`next`] v določenem trenutku spet začne ali morda ne bo vrnil [`Some(Item)`] (na primer glej [`TryIter`]).
//!
//!
//! Polna definicija ["Iterator`] vključuje tudi številne druge metode, vendar so to privzete metode, zgrajene na vrhu [`next`], zato jih dobite brezplačno.
//!
//! Iteratorji so tudi sestavljivi in običajno je, da jih povežemo za bolj zapletene oblike obdelave.Za več podrobnosti glejte spodnji razdelek [Adapters](#adapters).
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Tri oblike ponovitve
//!
//! Obstajajo trije pogosti načini, ki lahko ustvarijo iteratorje iz zbirke:
//!
//! * `iter()`, ki se ponavlja pred `&T`.
//! * `iter_mut()`, ki se ponavlja pred `&mut T`.
//! * `into_iter()`, ki se ponavlja pred `T`.
//!
//! Različne stvari v standardni knjižnici lahko izvajajo enega ali več od treh, kjer je to primerno.
//!
//! # Izvajanje Iteratorja
//!
//! Ustvarjanje lastnega iteratorja vključuje dva koraka: ustvarjanje `struct`, ki zadrži stanje iteratorja, in nato izvajanje [`Iterator`] za ta `struct`.
//! Zato je v tem modulu toliko struktur: za vsakega iteratorja in adapterja iteratorja obstaja po en.
//!
//! Naredimo iterator z imenom `Counter`, ki šteje od `1` do `5`:
//!
//! ```
//! // Prvič, struktura:
//!
//! /// Ponavljalec, ki šteje od enega do pet
//! struct Counter {
//!     count: usize,
//! }
//!
//! // želimo, da se naše štetje začne ob enem, zato v pomoč dodajte metodo new().
//! // To ni nujno potrebno, je pa priročno.
//! // Upoštevajte, da `count` začnemo pri nič, bomo videli, zakaj v izvedbi `next()`'s spodaj.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Nato uvedemo `Iterator` za naš `Counter`:
//!
//! impl Iterator for Counter {
//!     // šteli bomo z usize
//!     type Item = usize;
//!
//!     // next() je edina zahtevana metoda
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Povečaj naše štetje.Zato smo začeli z ničlo.
//!         self.count += 1;
//!
//!         // Preverite, ali smo končali s štetjem ali ne.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // In zdaj jo lahko uporabimo!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Klicanje [`next`] na ta način se ponavlja.Rust ima konstrukcijo, ki lahko v vašem iteratorju pokliče [`next`], dokler ne doseže `None`.Pojdiva naprej.
//!
//! Upoštevajte tudi, da `Iterator` ponuja privzeto izvedbo metod, kot sta `nth` in `fold`, ki interno prikličejo `next`.
//! Vendar pa je mogoče napisati tudi implementacijo metod po meri, kot sta `nth` in `fold`, če jih iterator lahko izračuna učinkoviteje, ne da bi poklical `next`.
//!
//! # `for` zanke in `IntoIterator`
//!
//! Sintaksa zanke `for` Rust je pravzaprav sladkor za iteratorje.Tu je osnovni primer `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! S tem bodo natisnjene številke od ena do pet, vsaka v svoji vrstici.Toda tu boste opazili nekaj: na našem vector nismo nikoli poklicali ničesar za izdelavo iteratorja.Kaj daje?
//!
//! V standardni knjižnici je Portrait za pretvorbo nečesa v iterator: [`IntoIterator`].
//! Ta Portrait ima eno metodo, [`into_iter`], ki stvar, ki izvaja [`IntoIterator`], pretvori v iterator.
//! Ponovno si oglejmo to zanko `for` in v kaj jo pretvornik pretvori:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust to odstrani s sladkorjem v:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Najprej na vrednost pokličemo `into_iter()`.Nato se ujemamo na iteratorju, ki se vrne, in vedno znova pokličemo [`next`], dokler ne vidimo `None`.
//! Na tej točki smo `break` izstopili iz zanke in smo s ponovitvijo končali.
//!
//! Tu je še en subtilen delček: standardna knjižnica vsebuje zanimivo izvedbo [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Z drugimi besedami, vsi [`Iterator`] implementirajo [`IntoIterator`], tako da se samo vrnejo.To pomeni dve stvari:
//!
//! 1. Če pišete [`Iterator`], ga lahko uporabite z zanko `for`.
//! 2. Če ustvarjate zbirko, bo uvedba [`IntoIterator`] zanjo omogočila uporabo zbirke z zanko `for`.
//!
//! # Ponavljanje po referenci
//!
//! Ker [`into_iter()`] vzame `self` po vrednosti, uporaba zanke `for` za iteracijo po zbirki porabi to zbirko.Pogosto boste morda želeli ponoviti zbirko, ne da bi jo porabili.
//! Številne zbirke ponujajo metode, ki zagotavljajo iteratorje nad referencami, običajno imenovanimi `iter()` oziroma `iter_mut()`:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` je še vedno v lasti te funkcije.
//! ```
//!
//! Če vrsta zbirke `C` ponuja `iter()`, običajno tudi implementira `IntoIterator` za `&C`, z izvedbo, ki samo pokliče `iter()`.
//! Podobno zbirka `C`, ki zagotavlja `iter_mut()`, na splošno izvaja `IntoIterator` za `&mut C`, tako da jo prenese na `iter_mut()`.To omogoča priročno stenografijo:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // enako kot `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // enako kot `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Medtem ko številne zbirke ponujajo `iter()`, vse pa ne ponujajo `iter_mut()`.
//! Na primer, mutiranje tipk [`HashSet<T>`] ali [`HashMap<K, V>`] bi lahko zbirko postavilo v neskladno stanje, če se spremenijo zgoščeni ključi, zato te zbirke ponujajo samo `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Funkcije, ki sprejmejo [`Iterator`] in vrnejo drugo [`Iterator`], se pogosto imenujejo "iterator adapterji", saj so oblika "adapterja
//! pattern'.
//!
//! Pogosti vmesniki iteratorjev vključujejo [`map`], [`take`] in [`filter`].
//! Za več si oglejte njihovo dokumentacijo.
//!
//! Če je pretvornik iteratorja panics, bo iterator v neopredeljenem (vendar varnem pomnilniku) stanju.
//! Prav tako ni zagotovljeno, da bo to stanje ostalo nespremenjeno v različicah Rust, zato se izogibajte zanašanju na natančne vrednosti, ki jih vrne iterator, ki se je prestrašil.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iteratorji (in iterator [adapters](#adapters)) so *leni*. To pomeni, da samo ustvarjanje iteratorja ne pomeni veliko _do_. Zares se nič ne zgodi, dokler ne pokličete [`next`].
//! To včasih povzroča zmedo pri ustvarjanju iteratorja izključno zaradi njegovih stranskih učinkov.
//! Na primer metoda [`map`] pokliče zaporo vsakega elementa, ki ga ponovi:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! To ne bo natisnilo nobenih vrednosti, saj smo namesto njega uporabili samo iterator.Prevajalnik nas bo opozoril na tovrstno vedenje:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Idiomatičen način za pisanje [`map`] za neželene učinke je uporaba zanke `for` ali klic metode [`for_each`]:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Drug pogost način ocenjevanja iteratorja je uporaba metode [`collect`] za izdelavo nove zbirke.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Ni nujno, da so iteratorji končni.Kot primer je odprti obseg neskončen iterator:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Običajno je, da uporabimo adapter Xeteratorja za pretvorbo neskončnega iteratorja v končnega:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! S tem bodo natisnjene številke od `0` do `4`, vsaka v svoji vrstici.
//!
//! Upoštevajte, da se metode na neskončnih iteratorjih, tudi tistih, pri katerih je rezultat mogoče matematično določiti v končnem času, morda ne bodo končale.
//! Natančneje, metode, kot je [`min`], ki na splošno zahtevajo prehod vsakega elementa v iteratorju, se verjetno ne bodo uspešno vrnile za noben neskončen iterator.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Oh ne!Neskončna zanka!
//! // `ones.min()` povzroča neskončno zanko, zato ne bomo prišli do te točke!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;