//! Primitivne traits in tipi, ki predstavljajo osnovne lastnosti tipov.
//!
//! Vrste Rust lahko razvrstimo na različne uporabne načine glede na njihove notranje lastnosti.
//! Te klasifikacije so predstavljene kot traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Vrste, ki jih je mogoče prenesti čez meje niti.
///
/// Ta Portrait se samodejno izvede, ko prevajalnik ugotovi, da je primeren.
///
/// Primer vrste, ki ni "Pošlji", je kazalnik za štetje referenc [`rc::Rc`][`Rc`].
/// Če dve niti poskušata klonirati [`Rc`], ki kažeta na isto referenčno šteto vrednost, bosta morda poskušali hkrati posodobiti referenčno število, to je [undefined behavior][ub], ker [`Rc`] ne uporablja atomskih operacij.
///
/// Njegov bratranec [`sync::Arc`][arc] sicer uporablja atomske operacije (kar povzroči nekaj režijskih stroškov) in je tako `Send`.
///
/// Za več podrobnosti glejte [the Nomicon](../../nomicon/send-and-sync.html).
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Vrste s konstantno velikostjo, znane v času prevajanja.
///
/// Vsi parametri tipa imajo implicitno mejo `Sized`.Če to ni primerno, lahko odstranite to vez s posebno sintakso `?Sized`.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struktur FooUse(Foo<[i32]>);//napaka: Velikost za [i32] ni implementirana
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Edina izjema je implicitni tip 0X tipa `Self`.
/// Portrait nima implicitnega vezanega `Sized`, ker je to nezdružljivo z [Portrait objektom], kjer mora Portrait po definiciji sodelovati z vsemi možnimi implementatorji in je zato lahko poljubne velikosti.
///
///
/// Čeprav vam bo Rust omogočil, da `Sized` povežete z Portrait, ga pozneje ne boste mogli uporabiti za oblikovanje predmeta Portrait:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // naj y: &dyn Vrstica= &Impl;//napaka: Portrait `Bar` ni mogoče narediti v objekt
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // za privzeto, na primer, ki zahteva, da je `[T]: !Default` mogoče oceniti
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Vrste, ki so lahko "unsized" do dinamično velikega tipa.
///
/// Na primer, vrsta matrike `[i8; 2]` izvaja `Unsize<[i8]>` in `Unsize<dyn fmt::Debug>`.
///
/// Vse izvedbe `Unsize` samodejno zagotovi prevajalnik.
///
/// `Unsize` se izvaja za:
///
/// - `[T; N]` je `Unsize<[T]>`
/// - `T` je `Unsize<dyn Trait>`, ko `T: Trait`
/// - `Foo<..., T, ...>` je `Unsize<Foo<..., U, ...>>`, če:
///   - `T: Unsize<U>`
///   - Foo je struktura
///   - Samo zadnje polje `Foo` ima tip, ki vključuje `T`
///   - `T` ni del vrste nobenega drugega polja
///   - `Bar<T>: Unsize<Bar<U>>`, če ima zadnje polje `Foo` tip `Bar<T>`
///
/// `Unsize` se uporablja skupaj z [`ops::CoerceUnsized`], da vsebniki "user-defined", kot je [`Rc`], vsebujejo dinamično velike tipe.
/// Za več podrobnosti glejte [DST coercion RFC][RFC982] in [the nomicon entry on coercion][nomicon-coerce].
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Zahtevan Portrait za konstante, ki se uporabljajo v ujemanjih vzorcev.
///
/// Vsak tip, ki izpelje `PartialEq`, samodejno implementira ta Portrait, * ne glede na to, ali njegovi parametri tipa izvajajo `Eq`.
///
/// Če element `const` vsebuje neko vrsto, ki ne izvaja tega Portrait, potem ta tip bodisi (1.) ne izvaja `PartialEq` (kar pomeni, da konstanta ne bo zagotovila tiste metode primerjave, za katero domneva, da je generacija kode na voljo), ali pa (2.) implementira *svojo* različica `PartialEq` (za katero domnevamo, da ni v skladu s primerjavo strukturne enakosti).
///
///
/// V obeh zgornjih scenarijih zavrnemo uporabo takšne konstante v ujemanju vzorca.
///
/// Glej tudi [structural match RFC][RFC1445] in [issue 63438], ki sta spodbudila prehod z zasnove, ki temelji na atributih, na to Portrait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Zahtevan Portrait za konstante, ki se uporabljajo v ujemanjih vzorcev.
///
/// Vsak tip, ki izpelje `Eq`, samodejno implementira ta Portrait, * ne glede na to, ali njegovi parametri tipa izvajajo `Eq`.
///
/// To je kramp, da se izognemo omejitvam v našem tipskem sistemu.
///
/// # Background
///
/// Zahtevati želimo, da imajo vrste consts, uporabljene v ujemanjih vzorcev, atribut `#[derive(PartialEq, Eq)]`.
///
/// V bolj idealnem svetu bi lahko to zahtevo preverili tako, da samo preverimo, ali dani tip izvaja `StructuralPartialEq` Portrait *in*`Eq` Portrait.
/// Lahko pa imate ADT-je, ki *naredijo*`derive(PartialEq, Eq)`, in primer, ki ga želimo, da prevajalnik sprejme, kljub temu pa tip konstante ne uspe implementirati `Eq`.
///
/// Namreč tak primer:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Težava v zgornji kodi je, da `Wrap<fn(&())>` ne izvaja `PartialEq` niti `Eq`, ker `za <'a> fn(&'a _)` does not implement those traits.)
///
/// Zato se ne moremo zanesti na naivno preverjanje `StructuralPartialEq` in zgolj `Eq`.
///
/// Kot rešitev za to uporabimo dva ločena traits, ki jih vbrizga vsak od dveh izpeljank (`#[derive(PartialEq)]` in `#[derive(Eq)]`), in preverimo, ali sta oba prisotna kot del preverjanja strukturnih ujemanj.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Vrste, katerih vrednosti je mogoče podvojiti preprosto s kopiranjem bitov.
///
/// Priključki spremenljivk imajo privzeto "semantiko premikanja".Z drugimi besedami:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` se je preselil v `y` in ga zato ni mogoče uporabljati
///
/// // println! ("{: ?}", x);//napaka: uporaba premaknjene vrednosti
/// ```
///
/// Če pa tip implementira `Copy`, ima namesto tega 'copy semantics':
///
/// ```
/// // Izpeljemo lahko izvedbo `Copy`.
/// // `Clone` je prav tako obvezen, saj gre za supertret `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` je kopija `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Pomembno je omeniti, da je v teh dveh primerih edina razlika v tem, ali lahko po dodelitvi dostopate do `x`.
/// Pod pokrovom lahko kopiranje in premikanje povzroči kopiranje bitov v pomnilnik, čeprav je to včasih optimizirano.
///
/// ## Kako lahko implementiram `Copy`?
///
/// Obstajata dva načina za namestitev `Copy` za vaš tip.Najenostavnejša je uporaba `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// `Copy` in `Clone` lahko namestite tudi ročno:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Med obema je majhna razlika: strategija `derive` bo tudi postavila `Copy` na parametre tipa, kar ni vedno zaželeno.
///
/// ## Kakšna je razlika med `Copy` in `Clone`?
///
/// Kopije se zgodijo implicitno, na primer kot del naloge `y = x`.Obnašanja `Copy` ni mogoče prenesti;vedno je preprosta bitna kopija.
///
/// Kloniranje je eksplicitno dejanje, `x.clone()`.Izvedba [`Clone`] lahko zagotovi kakršno koli vedenje, specifično za tip, potrebno za varno podvajanje vrednosti.
/// Na primer, izvedba [`Clone`] za [`String`] mora kopirati medpomnilnik niza, ki je usmerjen v kup, na kupu.
/// Preprosta bitna kopija vrednosti [`String`] bi samo kopirala kazalec, kar bi vodilo do dvojne proste črte po črti.
/// Iz tega razloga je [`String`] [`Clone`], ne pa tudi `Copy`.
///
/// [`Clone`] je supertreit `Copy`, zato mora vse, kar je `Copy`, tudi implementirati [`Clone`].
/// Če je tip `Copy`, mora njegova izvedba [`Clone`] vrniti samo `*self` (glej zgornji primer).
///
/// ## Kdaj je moj tip lahko `Copy`?
///
/// Tip lahko izvaja `Copy`, če vse njegove komponente izvajajo `Copy`.Ta struktura je lahko na primer `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Struktura je lahko `Copy` in [`i32`] je `Copy`, zato je `Point` primerna za `Copy`.
/// Nasprotno pa razmislite
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Struktura `PointList` ne more implementirati `Copy`, ker [`Vec<T>`] ni `Copy`.Če poskusimo izpeljati izvedbo `Copy`, bomo dobili napako:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Sklice v skupni rabi (`&T`) so prav tako `Copy`, zato je tip lahko `Copy`, tudi če vsebuje skupne sklice vrst `T`, ki niso * `Copy`.
/// Upoštevajte naslednjo strukturo, ki lahko implementira `Copy`, ker vsebuje zgolj *skupno referenco* na naš ne-kopijo tipa `PointList` od zgoraj:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Kdaj * moj tip ne more biti `Copy`?
///
/// Nekaterih vrst ni mogoče varno kopirati.Kopiranje `&mut T` bi na primer ustvarilo vzvratno spremenljivo referenco.
/// Kopiranje [`String`] bi podvojilo odgovornost za upravljanje medpomnilnika [`String`], kar bi povzročilo dvojno brezplačno.
///
/// Če posplošimo slednji primer, katera koli vrsta, ki izvaja [`Drop`], ne more biti `Copy`, ker poleg svojih bajtov [`size_of::<T>`] upravlja tudi z nekaterimi viri.
///
/// Če poskušate implementirati `Copy` v strukturo ali enum, ki vsebuje podatke, ki niso `Kopija`, boste dobili napako [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Kdaj *naj bo* moj tip `Copy`?
///
/// Na splošno velja, da če vaš tip _can_ uporablja `Copy`, bi moral.
/// Upoštevajte pa, da je izvajanje `Copy` del javnega API-ja vaše vrste.
/// Če tip v future morda ne postane "Kopiraj", bi bilo pametno, da zdaj izpustimo izvedbo `Copy`, da se izognemo prelomni spremembi API-ja.
///
/// ## Dodatni izvedbe
///
/// Poleg [implementors listed below][impls] naslednje vrste uporabljajo tudi `Copy`:
///
/// * Tipi elementov funkcij (tj. Ločeni tipi, opredeljeni za vsako funkcijo)
/// * Vrste kazalcev funkcij (npr. `fn() -> i32`)
/// * Vrste matrike za vse velikosti, če vrsta elementa izvaja tudi `Copy` (npr. `[i32; 123456]`)
/// * Vrste sklopov, če vsaka komponenta izvaja tudi `Copy` (npr. `()`, `(i32, bool)`)
/// * Vrste zapiranja, če iz okolja ne zajamejo nobene vrednosti ali če vse take zajete vrednosti same implementirajo `Copy`.
///   Upoštevajte, da spremenljivke, zajete s skupno referenco, vedno izvajajo `Copy` (tudi če referenca ne), medtem ko spremenljivke, zajete s spremenljivo referenco, nikoli ne izvajajo `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) To omogoča kopiranje vrste, ki ne izvaja `Copy` zaradi nezadovoljenih življenjskih mej (kopiranje `A<'_>`, ko samo `A<'static>: Copy` in `A<'_>: Clone`).
// Ta atribut imamo za zdaj tukaj le zato, ker je na `Copy` že kar nekaj specializacij, ki že obstajajo v standardni knjižnici, in tega načina trenutno ni mogoče varno obnašati.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Izvedite makro, ki generira impl z Portrait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Vrste, za katere je varno deliti reference med nitmi.
///
/// Ta Portrait se samodejno izvede, ko prevajalnik ugotovi, da je primeren.
///
/// Natančna opredelitev je: tip `T` je [`Sync`] takrat in samo, če je `&T` [`Send`].
/// Z drugimi besedami, če pri prenosu referenc `&T` med niti ni možnosti [undefined behavior][ub] (vključno s podatkovnimi rasami).
///
/// Kot bi lahko pričakovali, so primitivni tipi, kot so [`u8`] in [`f64`], vsi [`Sync`], prav tako pa tudi preprosti agregatni tipi, ki jih vsebujejo, kot so nabori, strukture in enume.
/// Več primerov osnovnih tipov [`Sync`] vključuje vrste "immutable", kot je `&T`, in tiste s preprosto podedovano spremenljivostjo, kot so [`Box<T>`][box], [`Vec<T>`][vec] in večina drugih vrst zbirk.
///
/// (Splošni parametri morajo biti [`Sync`], da je njihov vsebnik [`Sync`].)
///
/// Nekoliko presenetljiva posledica definicije je, da je `&mut T` `Sync` (če je `T` `Sync`), čeprav se zdi, da bi to lahko povzročilo nesinhronizirano mutacijo.
/// Trik je v tem, da spremenljiva referenca za referenco v skupni rabi (to je `& &mut T`) postane samo za branje, kot da bi šlo za `& &T`.
/// Zato ni tveganja za podatkovno tekmo.
///
/// Vrste, ki niso `Sync`, so tiste, ki imajo "interior mutability" v obliki, ki ni varna za nit, na primer [`Cell`][cell] in [`RefCell`][refcell].
/// Te vrste omogočajo mutacijo njihove vsebine tudi prek nespremenljive skupne reference.
/// Na primer metoda `set` na [`Cell<T>`][cell] zavzame `&self`, zato zahteva le referenco v skupni rabi [`&Cell<T>`][cell].
/// Metoda ne izvaja sinhronizacije, zato [`Cell`][cell] ne more biti `Sync`.
///
/// Drug primer vrste, ki ni `Synnc`, je kazalec štetja referenc [`Rc`][rc].
/// Glede na kateri koli referenčni [`&Rc<T>`][rc] lahko klonirate novega [`Rc<T>`][rc] in spremenite štetje referenc na neatomski način.
///
/// V primerih, ko je potrebna notranja varnost notranje spremenljivosti, Rust ponuja [atomic data types], pa tudi izrecno zaklepanje prek [`sync::Mutex`][mutex] in [`sync::RwLock`][rwlock].
/// Ti tipi zagotavljajo, da kakršna koli mutacija ne more povzročiti podatkovnih dirk, zato so tipi `Sync`.
/// Podobno [`sync::Arc`][arc] ponuja analogni [`Rc`][rc], ki je varen za nit.
///
/// Vsi tipi z notranjo spremenljivostjo morajo uporabljati tudi ovitek [`cell::UnsafeCell`][unsafecell] okoli value(s), ki ga je mogoče mutirati prek skupne reference.
/// Če tega ne storim, je [undefined behavior][ub].
/// Na primer ['pretvori'][pretvori]-ing iz `&T` v `&mut T` ni veljaven.
///
/// Za več podrobnosti o `Sync` glejte [the Nomicon][nomicon-send-and-sync].
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): ko podpora za dodajanje opomb v `rustc_on_unimplemented` pristane v različici beta in je bila razširjena, da preveri, ali je zaprtje kje v verigi zahtev, ga razširite kot takega (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Zero velika vrsta se uporablja za označevanje stvari, ki imajo v lasti "act like" `T`.
///
/// Če svojemu tipu dodate polje `PhantomData<T>`, boste prevajalniku povedali, da deluje, kot da shranjuje vrednost tipa `T`, čeprav v resnici ne.
/// Te informacije se uporabljajo pri izračunu določenih varnostnih lastnosti.
///
/// Za podrobnejšo razlago uporabe `PhantomData<T>` glejte [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Grozljivo sporočilo 👻👻👻
///
/// Čeprav imata oba strašljiva imena, sta `PhantomData` in "fantomska tipa" sorodna, vendar ne enaka.Parameter fantomskega tipa je preprosto tipski parameter, ki se nikoli ne uporablja.
/// V Rust to pogosto povzroči, da se prevajalnik pritoži, rešitev pa je, da dodate "dummy" kot `PhantomData`.
///
/// # Examples
///
/// ## Neuporabljeni življenjski parametri
///
/// Morda je najpogostejši primer uporabe `PhantomData` struktura, ki ima neuporabljeni življenjski parameter, običajno kot del neke nevarne kode.
/// Na primer, tukaj je struktura `Slice`, ki ima dva kazalca tipa `*const T`, ki verjetno kažeta nekam v polje:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Namen je, da osnovni podatki veljajo samo za življenjsko dobo `'a`, zato `Slice` ne bi smel preživeti `'a`.
/// Vendar ta namen v kodi ni izražen, saj življenjska doba `'a` ni uporabljena in zato ni jasno, za katere podatke se nanaša.
/// To lahko popravimo tako, da prevajalniku povemo, naj deluje *, kot da* struktura `Slice` vsebuje sklic `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// To pa zahteva tudi pripis `T: 'a`, ki označuje, da so vsi sklici v `T` veljavni v celotni življenjski dobi `'a`.
///
/// Pri inicializaciji `Slice` preprosto navedete vrednost `PhantomData` za polje `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Neuporabljeni parametri tipa
///
/// Včasih se zgodi, da imate neuporabljene parametre tipa, ki kažejo, do katere vrste podatkov je struktura "tied", čeprav teh podatkov v sami strukturi dejansko ni mogoče najti.
/// Tu je primer, ko se to pojavi pri [FFI].
/// Tuji vmesnik uporablja ročaje tipa `*mut ()` za sklicevanje na vrednosti Rust različnih tipov.
/// Tipu Rust sledimo s pomočjo parametra fantomskega tipa na strukturi `ExternalResource`, ki ovije ročaj.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Lastništvo in preverjanje padca
///
/// Če dodate polje tipa `PhantomData<T>`, to pomeni, da je vaš tip lastnik podatkov tipa `T`.To pa pomeni, da lahko ob izpuščanju tipa izpusti enega ali več primerkov tipa `T`.
/// To vpliva na analizo [drop check] prevajalnika Rust.
///
/// Če vaša struktura dejansko *ni lastnik* podatkov vrste `T`, je bolje uporabiti referenčni tip, na primer `PhantomData<&'a T>` (ideally) ali `PhantomData<*const T>` (če ne velja nobena življenjska doba), da ne bi navedli lastništva.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Interni prevajalnik Portrait se uporablja za označevanje vrste diskriminatornih elementov za naštevanje.
///
/// Ta Portrait se samodejno uporabi za vse vrste in ne daje nobenih jamstev za [`mem::Discriminant`].
/// Pretvarjanje med `DiscriminantKind::Discriminant` in `mem::Discriminant` je **nedefinirano vedenje**.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Tip diskriminante, ki mora ustrezati Portrait bounds, ki ga zahteva `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Notranji prevajalnik Portrait, ki se uporablja za ugotavljanje, ali tip vsebuje kateri koli `UnsafeCell` znotraj, vendar ne z indirektno usmeritvijo.
///
/// To na primer vpliva na to, ali je `static` te vrste vstavljen v statični pomnilnik, ki je samo za branje, ali v zapisljiv statični pomnilnik.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Vrste, ki jih je mogoče varno premakniti po pripenjanju.
///
/// Rust sam nima pojma nepremičnih vrst in meni, da so premiki (npr. Z dodelitvijo ali [`mem::replace`]) vedno varni.
///
/// Namesto tega se za preprečevanje premikov skozi sistem tipa uporablja tip [`Pin`][Pin].Kazalcev `P<T>`, zavitih v ovoj [`Pin<P<T>>`][Pin], ni mogoče premakniti.
/// Za več informacij o pripenjanju glejte dokumentacijo [`pin` module].
///
/// Izvedba `Unpin` Portrait za `T` odpravlja omejitve pripenjanja tipa, ki nato omogoča premikanje `T` iz [`Pin<P<T>>`][Pin] s funkcijami, kot je [`mem::replace`].
///
///
/// `Unpin` sploh nima posledic za nepripete podatke.
/// Zlasti [`mem::replace`] z veseljem premika podatke `!Unpin` (deluje pri vseh `&mut T`, ne le pri `T: Unpin`).
/// Vendar [`mem::replace`] ne morete uporabiti za podatke, zavite v [`Pin<P<T>>`][Pin], ker ne morete dobiti `&mut T`, ki ga potrebujete za to, in *to* je tisto, zaradi česar ta sistem deluje.
///
/// Tako je na primer to mogoče storiti samo pri tipih, ki izvajajo `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Za klic `mem::replace` potrebujemo spremenljivo referenco.
/// // Takšen sklic lahko dobimo, če (implicitly) prikliče `Pin::deref_mut`, vendar je to mogoče le zato, ker `String` implementira `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Ta Portrait se samodejno izvede za skoraj vse vrste.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Tip označevalnika, ki ne izvaja `Unpin`.
///
/// Če tip vsebuje `PhantomPinned`, privzeto ne bo implementiral `Unpin`.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Implementacije `Copy` za primitivne tipe.
///
/// Implementacije, ki jih ni mogoče opisati v Rust, so implementirane v `traits::SelectionContext::copy_clone_conditions()` v `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Sklice v skupni rabi je mogoče kopirati, spremenljivih referenc * pa ne!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}