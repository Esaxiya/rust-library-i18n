//! Lastnosti prevajalca.
//!
//! Ustrezne definicije so v `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Ustrezne izvedbe const so v `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Const intrinsics
//!
//! Note: o vseh spremembah trdnosti notranjih lastnosti se je treba pogovoriti z jezikovno skupino.
//! To vključuje spremembe stabilnosti trdnosti.
//!
//! Če želite, da je intrinzično uporabno v času prevajanja, je treba kopirati implementacijo iz <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> v `compiler/rustc_mir/src/interpret/intrinsics.rs` in dodati `#[rustc_const_unstable(feature = "foo", issue = "01234")]` v notranjost.
//!
//!
//! Če naj bi se intrinsic uporabljal iz `const fn` z atributom `rustc_const_stable`, mora biti atribut intrinsic tudi `rustc_const_stable`.
//! Takšne spremembe ne bi smeli storiti brez posvetovanja z jezikom T-lang, ker v jezik vpeče funkcijo, ki je brez podpore prevajalnika ni mogoče kopirati v uporabniško kodo.
//!
//! # Volatiles
//!
//! Hlapne lastne lastnosti zagotavljajo operacije, namenjene delovanju na pomnilniku I/O, ki jih prevajalnik zagotovo ne bo prerazporedil v drugih hlapnih notranjih lastnostih.Glejte dokumentacijo LLVM za [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Atomska lastnost zagotavlja pogoste atomske operacije s strojnimi besedami z več možnimi vrstnimi razredi pomnilnika.Upoštevajo enako semantiko kot C++ 11.Glejte dokumentacijo LLVM za [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Hitro osvežitev naročila pomnilnika:
//!
//! * Pridobite, ovira za pridobitev ključavnice.Kasnejša branja in pisanja potekajo po pregradi.
//! * Sprostitev, ovira za sprostitev ključavnice.Predhodno branje in pisanje poteka pred pregrado.
//! * Zagotovljeno je, da se zaporedno skladne in zaporedno skladne operacije izvajajo v redu.To je standardni način za delo z atomskimi tipi in je enakovreden `volatile` Java.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Ta uvoz se uporablja za poenostavitev povezav znotraj dokumenta
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // VARNOST: glej `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // Opomba: ti notranji elementi zajemajo surove kazalce, ker mutirajo vzdevek pomnilnika, kar ne velja niti za `&` niti za `&mut`.
    //

    /// Shrani vrednost, če je trenutna vrednost enaka vrednosti `old`.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `compare_exchange` s posredovanjem [`Ordering::SeqCst`] kot parametra `success` in `failure`.
    ///
    /// Na primer [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Shrani vrednost, če je trenutna vrednost enaka vrednosti `old`.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `compare_exchange` s posredovanjem [`Ordering::Acquire`] kot parametra `success` in `failure`.
    ///
    /// Na primer [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Shrani vrednost, če je trenutna vrednost enaka vrednosti `old`.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `compare_exchange`, tako da [`Ordering::Release`] posreduje kot `success` in [`Ordering::Relaxed`] kot parametra `failure`.
    /// Na primer [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Shrani vrednost, če je trenutna vrednost enaka vrednosti `old`.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `compare_exchange`, tako da [`Ordering::AcqRel`] posreduje kot `success` in [`Ordering::Acquire`] kot parametra `failure`.
    /// Na primer [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Shrani vrednost, če je trenutna vrednost enaka vrednosti `old`.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `compare_exchange` s posredovanjem [`Ordering::Relaxed`] kot parametra `success` in `failure`.
    ///
    /// Na primer [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Shrani vrednost, če je trenutna vrednost enaka vrednosti `old`.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `compare_exchange`, tako da [`Ordering::SeqCst`] posreduje kot `success` in [`Ordering::Relaxed`] kot parametra `failure`.
    /// Na primer [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Shrani vrednost, če je trenutna vrednost enaka vrednosti `old`.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `compare_exchange`, tako da [`Ordering::SeqCst`] posreduje kot `success` in [`Ordering::Acquire`] kot parametra `failure`.
    /// Na primer [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Shrani vrednost, če je trenutna vrednost enaka vrednosti `old`.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `compare_exchange`, tako da [`Ordering::Acquire`] posreduje kot `success` in [`Ordering::Relaxed`] kot parametra `failure`.
    /// Na primer [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Shrani vrednost, če je trenutna vrednost enaka vrednosti `old`.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `compare_exchange`, tako da [`Ordering::AcqRel`] posreduje kot `success` in [`Ordering::Relaxed`] kot parametra `failure`.
    /// Na primer [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Shrani vrednost, če je trenutna vrednost enaka vrednosti `old`.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `compare_exchange_weak` s posredovanjem [`Ordering::SeqCst`] kot parametra `success` in `failure`.
    ///
    /// Na primer [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Shrani vrednost, če je trenutna vrednost enaka vrednosti `old`.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `compare_exchange_weak` s posredovanjem [`Ordering::Acquire`] kot parametra `success` in `failure`.
    ///
    /// Na primer [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Shrani vrednost, če je trenutna vrednost enaka vrednosti `old`.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `compare_exchange_weak`, tako da [`Ordering::Release`] posreduje kot `success` in [`Ordering::Relaxed`] kot parametra `failure`.
    /// Na primer [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Shrani vrednost, če je trenutna vrednost enaka vrednosti `old`.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `compare_exchange_weak`, tako da [`Ordering::AcqRel`] posreduje kot `success` in [`Ordering::Acquire`] kot parametra `failure`.
    /// Na primer [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Shrani vrednost, če je trenutna vrednost enaka vrednosti `old`.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `compare_exchange_weak` s posredovanjem [`Ordering::Relaxed`] kot parametra `success` in `failure`.
    ///
    /// Na primer [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Shrani vrednost, če je trenutna vrednost enaka vrednosti `old`.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `compare_exchange_weak`, tako da [`Ordering::SeqCst`] posreduje kot `success` in [`Ordering::Relaxed`] kot parametra `failure`.
    /// Na primer [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Shrani vrednost, če je trenutna vrednost enaka vrednosti `old`.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `compare_exchange_weak`, tako da [`Ordering::SeqCst`] posreduje kot `success` in [`Ordering::Acquire`] kot parametra `failure`.
    /// Na primer [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Shrani vrednost, če je trenutna vrednost enaka vrednosti `old`.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `compare_exchange_weak`, tako da [`Ordering::Acquire`] posreduje kot `success` in [`Ordering::Relaxed`] kot parametra `failure`.
    /// Na primer [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Shrani vrednost, če je trenutna vrednost enaka vrednosti `old`.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `compare_exchange_weak`, tako da [`Ordering::AcqRel`] posreduje kot `success` in [`Ordering::Relaxed`] kot parametra `failure`.
    /// Na primer [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Naloži trenutno vrednost kazalca.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `load`, tako da [`Ordering::SeqCst`] prenesete kot `order`.
    /// Na primer [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Naloži trenutno vrednost kazalca.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `load`, tako da [`Ordering::Acquire`] prenesete kot `order`.
    /// Na primer [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Naloži trenutno vrednost kazalca.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `load`, tako da [`Ordering::Relaxed`] prenesete kot `order`.
    /// Na primer [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Shrani vrednost na določenem pomnilniškem mestu.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `store`, tako da [`Ordering::SeqCst`] prenesete kot `order`.
    /// Na primer [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Shrani vrednost na določenem pomnilniškem mestu.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `store`, tako da [`Ordering::Release`] prenesete kot `order`.
    /// Na primer [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Shrani vrednost na določenem pomnilniškem mestu.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `store`, tako da [`Ordering::Relaxed`] prenesete kot `order`.
    /// Na primer [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Shrani vrednost na določeno mesto v pomnilniku in vrne staro vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `swap`, tako da [`Ordering::SeqCst`] prenesete kot `order`.
    /// Na primer [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Shrani vrednost na določeno mesto v pomnilniku in vrne staro vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `swap`, tako da [`Ordering::Acquire`] prenesete kot `order`.
    /// Na primer [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Shrani vrednost na določeno mesto v pomnilniku in vrne staro vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `swap`, tako da [`Ordering::Release`] prenesete kot `order`.
    /// Na primer [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Shrani vrednost na določeno mesto v pomnilniku in vrne staro vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `swap`, tako da [`Ordering::AcqRel`] prenesete kot `order`.
    /// Na primer [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Shrani vrednost na določeno mesto v pomnilniku in vrne staro vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo za tipe [`atomic`] prek metode `swap`, tako da [`Ordering::Relaxed`] prenesete kot `order`.
    /// Na primer [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Doda trenutni vrednosti in vrne prejšnjo vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `fetch_add`, tako da [`Ordering::SeqCst`] prenesete kot `order`.
    /// Na primer [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Doda trenutni vrednosti in vrne prejšnjo vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `fetch_add`, tako da [`Ordering::Acquire`] prenesete kot `order`.
    /// Na primer [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Doda trenutni vrednosti in vrne prejšnjo vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `fetch_add`, tako da [`Ordering::Release`] prenesete kot `order`.
    /// Na primer [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Doda trenutni vrednosti in vrne prejšnjo vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `fetch_add`, tako da [`Ordering::AcqRel`] prenesete kot `order`.
    /// Na primer [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Doda trenutni vrednosti in vrne prejšnjo vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `fetch_add`, tako da [`Ordering::Relaxed`] prenesete kot `order`.
    /// Na primer [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Odštejte od trenutne vrednosti in vrnite prejšnjo vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `fetch_sub`, tako da [`Ordering::SeqCst`] prenesete kot `order`.
    /// Na primer [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Odštejte od trenutne vrednosti in vrnite prejšnjo vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `fetch_sub`, tako da [`Ordering::Acquire`] prenesete kot `order`.
    /// Na primer [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Odštejte od trenutne vrednosti in vrnite prejšnjo vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `fetch_sub`, tako da [`Ordering::Release`] prenesete kot `order`.
    /// Na primer [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Odštejte od trenutne vrednosti in vrnite prejšnjo vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `fetch_sub`, tako da [`Ordering::AcqRel`] prenesete kot `order`.
    /// Na primer [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Odštejte od trenutne vrednosti in vrnite prejšnjo vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `fetch_sub`, tako da [`Ordering::Relaxed`] prenesete kot `order`.
    /// Na primer [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bit in s trenutno vrednostjo vrne prejšnjo vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `fetch_and`, tako da [`Ordering::SeqCst`] prenesete kot `order`.
    /// Na primer [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit in s trenutno vrednostjo vrne prejšnjo vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `fetch_and`, tako da [`Ordering::Acquire`] prenesete kot `order`.
    /// Na primer [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit in s trenutno vrednostjo vrne prejšnjo vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `fetch_and`, tako da [`Ordering::Release`] prenesete kot `order`.
    /// Na primer [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit in s trenutno vrednostjo vrne prejšnjo vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `fetch_and`, tako da [`Ordering::AcqRel`] prenesete kot `order`.
    /// Na primer [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit in s trenutno vrednostjo vrne prejšnjo vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `fetch_and`, tako da [`Ordering::Relaxed`] prenesete kot `order`.
    /// Na primer [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bit-nand s trenutno vrednostjo, ki vrne prejšnjo vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo za tip [`AtomicBool`] prek metode `fetch_nand`, tako da [`Ordering::SeqCst`] prenesete kot `order`.
    /// Na primer [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit-nand s trenutno vrednostjo, ki vrne prejšnjo vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo za tip [`AtomicBool`] prek metode `fetch_nand`, tako da [`Ordering::Acquire`] prenesete kot `order`.
    /// Na primer [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit-nand s trenutno vrednostjo, ki vrne prejšnjo vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo za tip [`AtomicBool`] prek metode `fetch_nand`, tako da [`Ordering::Release`] prenesete kot `order`.
    /// Na primer [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit-nand s trenutno vrednostjo, ki vrne prejšnjo vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo za tip [`AtomicBool`] prek metode `fetch_nand`, tako da [`Ordering::AcqRel`] prenesete kot `order`.
    /// Na primer [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bit-nand s trenutno vrednostjo, ki vrne prejšnjo vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo za tip [`AtomicBool`] prek metode `fetch_nand`, tako da [`Ordering::Relaxed`] prenesete kot `order`.
    /// Na primer [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitno ali s trenutno vrednostjo, ki vrne prejšnjo vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `fetch_or`, tako da [`Ordering::SeqCst`] prenesete kot `order`.
    /// Na primer [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitno ali s trenutno vrednostjo, ki vrne prejšnjo vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `fetch_or`, tako da [`Ordering::Acquire`] prenesete kot `order`.
    /// Na primer [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitno ali s trenutno vrednostjo, ki vrne prejšnjo vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `fetch_or`, tako da [`Ordering::Release`] prenesete kot `order`.
    /// Na primer [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitno ali s trenutno vrednostjo, ki vrne prejšnjo vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `fetch_or`, tako da [`Ordering::AcqRel`] prenesete kot `order`.
    /// Na primer [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitno ali s trenutno vrednostjo, ki vrne prejšnjo vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `fetch_or`, tako da [`Ordering::Relaxed`] prenesete kot `order`.
    /// Na primer [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitno xor s trenutno vrednostjo, ki vrne prejšnjo vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `fetch_xor`, tako da [`Ordering::SeqCst`] prenesete kot `order`.
    /// Na primer [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitno xor s trenutno vrednostjo, ki vrne prejšnjo vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `fetch_xor`, tako da [`Ordering::Acquire`] prenesete kot `order`.
    /// Na primer [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitno xor s trenutno vrednostjo, ki vrne prejšnjo vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `fetch_xor`, tako da [`Ordering::Release`] prenesete kot `order`.
    /// Na primer [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitno xor s trenutno vrednostjo, ki vrne prejšnjo vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `fetch_xor`, tako da [`Ordering::AcqRel`] prenesete kot `order`.
    /// Na primer [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitno xor s trenutno vrednostjo, ki vrne prejšnjo vrednost.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo pri tipih [`atomic`] prek metode `fetch_xor`, tako da [`Ordering::Relaxed`] prenesete kot `order`.
    /// Na primer [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Največ s trenutno vrednostjo s pomočjo podpisane primerjave.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo na celoštevilnih vrstah s podpisom [`atomic`] prek metode `fetch_max`, tako da [`Ordering::SeqCst`] prenesete kot `order`.
    /// Na primer [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Največ s trenutno vrednostjo s pomočjo podpisane primerjave.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo na celoštevilnih vrstah s podpisom [`atomic`] prek metode `fetch_max`, tako da [`Ordering::Acquire`] prenesete kot `order`.
    /// Na primer [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Največ s trenutno vrednostjo s pomočjo podpisane primerjave.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo na celoštevilnih vrstah s podpisom [`atomic`] prek metode `fetch_max`, tako da [`Ordering::Release`] prenesete kot `order`.
    /// Na primer [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Največ s trenutno vrednostjo s pomočjo podpisane primerjave.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo na celoštevilnih vrstah s podpisom [`atomic`] prek metode `fetch_max`, tako da [`Ordering::AcqRel`] prenesete kot `order`.
    /// Na primer [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Največ s trenutno vrednostjo.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo na celoštevilnih vrstah s podpisom [`atomic`] prek metode `fetch_max`, tako da [`Ordering::Relaxed`] prenesete kot `order`.
    /// Na primer [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Najmanj s trenutno vrednostjo s pomočjo podpisane primerjave.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo na celoštevilnih vrstah s podpisom [`atomic`] prek metode `fetch_min`, tako da [`Ordering::SeqCst`] prenesete kot `order`.
    /// Na primer [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Najmanj s trenutno vrednostjo s pomočjo podpisane primerjave.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo na celoštevilnih vrstah s podpisom [`atomic`] prek metode `fetch_min`, tako da [`Ordering::Acquire`] prenesete kot `order`.
    /// Na primer [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Najmanj s trenutno vrednostjo s pomočjo podpisane primerjave.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo na celoštevilnih vrstah s podpisom [`atomic`] prek metode `fetch_min`, tako da [`Ordering::Release`] prenesete kot `order`.
    /// Na primer [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Najmanj s trenutno vrednostjo s pomočjo podpisane primerjave.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo na celoštevilnih vrstah s podpisom [`atomic`] prek metode `fetch_min`, tako da [`Ordering::AcqRel`] prenesete kot `order`.
    /// Na primer [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Najmanj s trenutno vrednostjo s pomočjo podpisane primerjave.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo na celoštevilnih vrstah s podpisom [`atomic`] prek metode `fetch_min`, tako da [`Ordering::Relaxed`] prenesete kot `order`.
    /// Na primer [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Najmanj s trenutno vrednostjo z uporabo nepodpisane primerjave.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo za celoštevilčne tipe [`atomic`] po metodi `fetch_min`, tako da [`Ordering::SeqCst`] prenesete kot `order`.
    /// Na primer [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Najmanj s trenutno vrednostjo z uporabo nepodpisane primerjave.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo za celoštevilčne tipe [`atomic`] po metodi `fetch_min`, tako da [`Ordering::Acquire`] prenesete kot `order`.
    /// Na primer [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Najmanj s trenutno vrednostjo z uporabo nepodpisane primerjave.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo za celoštevilčne tipe [`atomic`] po metodi `fetch_min`, tako da [`Ordering::Release`] prenesete kot `order`.
    /// Na primer [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Najmanj s trenutno vrednostjo z uporabo nepodpisane primerjave.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo za celoštevilčne vrste [`atomic`] po metodi `fetch_min`, tako da [`Ordering::AcqRel`] prenesete kot `order`.
    /// Na primer [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Najmanj s trenutno vrednostjo z uporabo nepodpisane primerjave.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo za celoštevilčne tipe [`atomic`] po metodi `fetch_min`, tako da [`Ordering::Relaxed`] prenesete kot `order`.
    /// Na primer [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Največ s trenutno vrednostjo z uporabo nepodpisane primerjave.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo za celoštevilčne tipe [`atomic`] po metodi `fetch_max`, tako da [`Ordering::SeqCst`] prenesete kot `order`.
    /// Na primer [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Največ s trenutno vrednostjo z uporabo nepodpisane primerjave.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo za celoštevilčne tipe [`atomic`] po metodi `fetch_max`, tako da [`Ordering::Acquire`] prenesete kot `order`.
    /// Na primer [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Največ s trenutno vrednostjo z uporabo nepodpisane primerjave.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo za celoštevilčne tipe [`atomic`] po metodi `fetch_max`, tako da [`Ordering::Release`] prenesete kot `order`.
    /// Na primer [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Največ s trenutno vrednostjo z uporabo nepodpisane primerjave.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo za celoštevilčne tipe [`atomic`] po metodi `fetch_max`, tako da [`Ordering::AcqRel`] prenesete kot `order`.
    /// Na primer [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Največ s trenutno vrednostjo z uporabo nepodpisane primerjave.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo za celoštevilčne tipe [`atomic`] po metodi `fetch_max`, tako da [`Ordering::Relaxed`] prenesete kot `order`.
    /// Na primer [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Notranji `prefetch` je namig generatorju kode, da vstavi navodila za vnaprejšnjo izbiro, če je podprt;v nasprotnem primeru pa ni.
    /// Preddobivanja nimajo vpliva na obnašanje programa, lahko pa spremenijo njegove značilnosti delovanja.
    ///
    /// Argument `locality` mora biti konstantno celo število in je časovni specifikator lokacije, od (0), brez lokacije, do (3), izjemno lokalno hranjenje v predpomnilniku.
    ///
    ///
    /// Ta lastnost nima stabilnega primerka.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Notranji `prefetch` je namig generatorju kode, da vstavi navodila za vnaprejšnjo izbiro, če je podprt;v nasprotnem primeru pa ni.
    /// Preddobivanja nimajo vpliva na obnašanje programa, lahko pa spremenijo njegove značilnosti delovanja.
    ///
    /// Argument `locality` mora biti konstantno celo število in je časovni specifikator lokacije, od (0), brez lokacije, do (3), izjemno lokalno hranjenje v predpomnilniku.
    ///
    ///
    /// Ta lastnost nima stabilnega primerka.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Notranji `prefetch` je namig generatorju kode, da vstavi navodila za vnaprejšnjo izbiro, če je podprt;v nasprotnem primeru pa ni.
    /// Preddobivanja nimajo vpliva na obnašanje programa, lahko pa spremenijo njegove značilnosti delovanja.
    ///
    /// Argument `locality` mora biti konstantno celo število in je časovni specifikator lokacije, od (0), brez lokacije, do (3), izjemno lokalno hranjenje v predpomnilniku.
    ///
    ///
    /// Ta lastnost nima stabilnega primerka.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Notranji `prefetch` je namig generatorju kode, da vstavi navodila za vnaprejšnjo izbiro, če je podprt;v nasprotnem primeru pa ni.
    /// Preddobivanja nimajo vpliva na obnašanje programa, lahko pa spremenijo njegove značilnosti delovanja.
    ///
    /// Argument `locality` mora biti konstantno celo število in je časovni specifikator lokacije, od (0), brez lokacije, do (3), izjemno lokalno hranjenje v predpomnilniku.
    ///
    ///
    /// Ta lastnost nima stabilnega primerka.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Atomska ograja.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo v [`atomic::fence`], tako da [`Ordering::SeqCst`] prenesete kot `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Atomska ograja.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo v [`atomic::fence`], tako da [`Ordering::Acquire`] prenesete kot `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Atomska ograja.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo v [`atomic::fence`], tako da [`Ordering::Release`] prenesete kot `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Atomska ograja.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo v [`atomic::fence`], tako da [`Ordering::AcqRel`] prenesete kot `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Pomnilniška ovira samo za prevajalnik.
    ///
    /// Prevajalnik prepovedi dostopa do pomnilnika nikoli ne bo preuredil čez to oviro, vendar zanj ne bodo izdana navodila.
    /// To je primerno za operacije z isto nitjo, ki jih je mogoče preprečiti, na primer pri interakciji z upravljavci signalov.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo v [`atomic::compiler_fence`], tako da [`Ordering::SeqCst`] prenesete kot `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Pomnilniška ovira samo za prevajalnik.
    ///
    /// Prevajalnik prepovedi dostopa do pomnilnika nikoli ne bo preuredil čez to oviro, vendar zanj ne bodo izdana navodila.
    /// To je primerno za operacije z isto nitjo, ki jih je mogoče preprečiti, na primer pri interakciji z upravljavci signalov.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo v [`atomic::compiler_fence`], tako da [`Ordering::Acquire`] prenesete kot `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Pomnilniška ovira samo za prevajalnik.
    ///
    /// Prevajalnik prepovedi dostopa do pomnilnika nikoli ne bo preuredil čez to oviro, vendar zanj ne bodo izdana navodila.
    /// To je primerno za operacije z isto nitjo, ki jih je mogoče preprečiti, na primer pri interakciji z upravljavci signalov.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo v [`atomic::compiler_fence`], tako da [`Ordering::Release`] prenesete kot `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Pomnilniška ovira samo za prevajalnik.
    ///
    /// Prevajalnik prepovedi dostopa do pomnilnika nikoli ne bo preuredil čez to oviro, vendar zanj ne bodo izdana navodila.
    /// To je primerno za operacije z isto nitjo, ki jih je mogoče preprečiti, na primer pri interakciji z upravljavci signalov.
    ///
    /// Stabilizirana različica tega lastnega besedila je na voljo v [`atomic::compiler_fence`], tako da [`Ordering::AcqRel`] prenesete kot `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Čarobna lastnost, ki svoj pomen izvira iz atributov, pritrjenih na funkcijo.
    ///
    /// Pretok podatkov na primer to uporabi za vbrizgavanje statičnih trditev, tako da bi `rustc_peek(potentially_uninitialized)` dejansko dvakrat preveril, ali je pretok podatkov dejansko izračunal, da je na tej točki v nadzornem toku neinicializiran.
    ///
    ///
    /// Te lastne lastnosti se ne sme uporabljati zunaj prevajalnika.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Prekine izvajanje postopka.
    ///
    /// Uporabniku prijaznejša in stabilnejša različica te operacije je [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Obvešča optimizator, da ta točka v kodi ni dosegljiva, kar omogoča nadaljnje optimizacije.
    ///
    /// Opomba: to se zelo razlikuje od makra `unreachable!()`: Za razliko od makra, ki je panics, ko se izvaja, je doseganje kode, označene s to funkcijo,*nedefinirano*.
    ///
    ///
    /// Stabilizirana različica tega bistvenega je [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Obvešča optimizator, da je pogoj vedno resničen.
    /// Če je pogoj napačen, vedenje ni določeno.
    ///
    /// Za to lastno kodo ni ustvarjena nobena koda, vendar jo bo optimizator poskušal ohraniti (in njeno stanje) med prehodi, kar lahko moti optimizacijo okoliške kode in zmanjša zmogljivost.
    /// Ne sme se uporabljati, če lahko optimizator sam odkrije invariant ali če ne omogoča pomembnih optimizacij.
    ///
    /// Ta lastnost nima stabilnega primerka.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Prevajalniku namiguje, da je pogoj branch verjetno resničen.
    /// Vrne vrednost, ki ji je bila posredovana.
    ///
    /// Kakršna koli druga uporaba kot pri izjavah `if` verjetno ne bo imela učinka.
    ///
    /// Ta lastnost nima stabilnega primerka.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Prevajalniku namiguje, da je pogoj branch verjetno napačen.
    /// Vrne vrednost, ki ji je bila posredovana.
    ///
    /// Kakršna koli druga uporaba kot pri izjavah `if` verjetno ne bo imela učinka.
    ///
    /// Ta lastnost nima stabilnega primerka.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Izvede past točke zaustavitve za pregled z razhroščevalnikom.
    ///
    /// Ta lastnost nima stabilnega primerka.
    pub fn breakpoint();

    /// Velikost vrste v bajtih.
    ///
    /// Natančneje, to je zamik v bajtih med zaporednimi elementi iste vrste, vključno z oblazinjenjem poravnave.
    ///
    ///
    /// Stabilizirana različica tega bistvenega je [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Najmanjša poravnava tipa.
    ///
    /// Stabilizirana različica tega bistvenega je [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Prednostna poravnava tipa.
    ///
    /// Ta lastnost nima stabilnega primerka.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Velikost referenčne vrednosti v bajtih.
    ///
    /// Stabilizirana različica tega bistvenega je [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Zahtevana poravnava referenčne vrednosti.
    ///
    /// Stabilizirana različica tega bistvenega je [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Pridobi statično rezino niza, ki vsebuje ime tipa.
    ///
    /// Stabilizirana različica tega bistvenega je [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Pridobi identifikator, ki je globalno enoličen za določeno vrsto.
    /// Ta funkcija bo vrnila enako vrednost za tip, ne glede na to, v katerem crate je poklican.
    ///
    ///
    /// Stabilizirana različica tega bistvenega je [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Zaščita za nevarne funkcije, ki jih ni mogoče izvesti, če je `T` nenaseljen:
    /// To bo statično bodisi panic bodisi ne bo nič.
    ///
    /// Ta lastnost nima stabilnega primerka.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Zaščita pred nevarnimi funkcijami, ki je ni mogoče izvesti, če `T` ne dovoljuje ničelne inicializacije: to bo statično bodisi panic bodisi nič.
    ///
    ///
    /// Ta lastnost nima stabilnega primerka.
    pub fn assert_zero_valid<T>();

    /// Zaščita pred nevarnimi funkcijami, ki jih ni mogoče izvesti, če ima `T` neveljavne bitne vzorce: to bo statično panic ali pa ne bo nič.
    ///
    ///
    /// Ta lastnost nima stabilnega primerka.
    pub fn assert_uninit_valid<T>();

    /// Pridobi sklic na statični `Location`, ki označuje, kje je bil poklican.
    ///
    /// Namesto tega razmislite o uporabi [`core::panic::Location::caller`](crate::panic::Location::caller).
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Premakne vrednost izven obsega, ne da bi pri tem padlo lepilo.
    ///
    /// To obstaja izključno za [`mem::forget_unsized`];običajni `forget` namesto tega uporablja `ManuallyDrop`.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Ponovno interpretira bitove vrednosti ene vrste kot druge vrste.
    ///
    /// Obe vrsti morata imeti enako velikost.
    /// Niti izvirnik niti rezultat morda nista [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` je pomensko enakovreden bitnemu premiku ene vrste v drugo.Kopije bitov iz izvorne vrednosti v ciljno vrednost nato pozabi na izvirnik.
    /// Enako je C-jevemu `memcpy` pod pokrovom, tako kot `transmute_copy`.
    ///
    /// Ker je `transmute` operacija po vrednosti, poravnava *samih pretvorjenih vrednosti* ni zaskrbljujoča.
    /// Kot pri vsaki drugi funkciji tudi prevajalnik zagotavlja, da sta `T` in `U` pravilno poravnana.
    /// Vendar pa mora klicatelj pri pretvarjanju vrednosti, ki *kažejo drugam*(kot so kazalci, sklici, polja…), zagotoviti pravilno poravnavo usmerjenih vrednosti.
    ///
    /// `transmute` je **neverjetno** nevarno.Obstaja veliko načinov, kako s to funkcijo povzročiti [undefined behavior][ub].`transmute` bi moral biti zadnja možnost.
    ///
    /// [nomicon](../../nomicon/transmutes.html) ima dodatno dokumentacijo.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Obstaja nekaj stvari, za katere je `transmute` resnično koristen.
    ///
    /// Pretvorba kazalca v kazalca funkcije.To *ni* prenosljivo za stroje, kjer imajo kazalci funkcij in kazalci podatkov različne velikosti.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Podaljšanje življenjske dobe ali skrajšanje nespremenljive življenjske dobe.To je napreden, zelo varen Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Ne obupajte: veliko načinov uporabe `transmute` je mogoče doseči z drugimi sredstvi.
    /// Spodaj so običajne aplikacije `transmute`, ki jih je mogoče nadomestiti z varnejšimi konstrukcijami.
    ///
    /// Pretvorba surovega bytes(`&[u8]`) v `u32`, `f64` itd.:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // namesto tega uporabite `u32::from_ne_bytes`
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // ali uporabite `u32::from_le_bytes` ali `u32::from_be_bytes`, da določite endianness
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Pretvorba kazalca v `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Namesto tega uporabite `as` cast
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Pretvorba `*mut T` v `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Namesto tega uporabite preusmeritev
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Pretvorba `&mut T` v `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Zdaj, skupaj `as` in ponovni izposoji, upoštevajte, da veriga `as` `as` ni prehodna
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Pretvorba `&str` v `&[u8]`:
    ///
    /// ```
    /// // to ni dober način za to.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Lahko uporabite `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Ali pa samo uporabite bajtni niz, če imate nadzor nad literalom niza
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Pretvorba `Vec<&T>` v `Vec<Option<&T>>`.
    ///
    /// Če želite pretvoriti notranji tip vsebine vsebnika, se prepričajte, da ne kršite nobene invariante vsebnika.
    /// Za `Vec` to pomeni, da se morata velikost *in poravnava* notranjih tipov ujemati.
    /// Drugi zabojniki se lahko zanašajo na velikost tipa, poravnavo ali celo `TypeId`, v tem primeru pretvorba sploh ne bi bila mogoča, ne da bi kršili invariante posode.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // klonirajte vector, saj jih bomo kasneje ponovno uporabili
    /// let v_clone = v_orig.clone();
    ///
    /// // Uporaba pretvorbe: to temelji na nedoločeni postavitvi podatkov `Vec`, kar je slaba ideja in bi lahko povzročilo nedoločeno vedenje.
    /////
    /// // Vendar ni kopiranje.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // To je predlagan, varen način.
    /// // Kopira pa celoten vector v novo polje.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // To je pravi način kopiranja, ki ni varen, "transmuting" in `Vec`, ne da bi se zanašal na postavitev podatkov.
    /// // Namesto da dobesedno pokličemo `transmute`, izvedemo igranje kazalca, toda glede pretvorbe prvotnega notranjega tipa (`&i32`) v novega (`Option<&i32>`) ima to enaka opozorila.
    /////
    /// // Poleg zgoraj navedenih informacij glejte tudi dokumentacijo [`from_raw_parts`].
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Posodobite to, ko je vec_into_raw_parts stabiliziran.
    ///     // Prepričajte se, da originalni vector ni izpuščen.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Implementacija `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // To lahko storite na več načinov, pri naslednjem načinu (transmute) pa je več težav.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // prvi: transmutiranje ni varno za tip;preverja le, da sta T in
    ///         // U so enake velikosti.
    ///         // Drugič, tukaj imate dve spremenljivi referenci, ki kažeta na isti spomin.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Tako se znebite težav z varnostjo tipa;`&mut *` vam bo* dal *samo `&mut T` od `&mut T` ali `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // vendar imate še vedno dve spremenljivi sklici, ki kažeta na isti spomin.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Tako to počne standardna knjižnica.
    /// // To je najboljša metoda, če morate narediti kaj takega
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Ta ima zdaj tri spremenljive reference, ki kažejo na isti spomin.`slice`, rvalue ret.0 in rvalue ret.1.
    ///         // `slice` se nikoli ne uporablja po `let ptr = ...`, zato ga lahko obravnavamo kot "dead", zato imate samo dve pravi spremenljivi rezini.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Čeprav je zaradi tega notranja const stabilna, imamo v const fn nekaj kode po meri
    // preverjanja, ki preprečujejo njegovo uporabo znotraj `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Vrne `true`, če dejanski tip, naveden kot `T`, zahteva kapljico lepila;vrne `false`, če dejanski tip, predviden za `T`, implementira `Copy`.
    ///
    ///
    /// Če dejanski tip ne zahteva lepila in ne uporablja `Copy`, potem je vrnjena vrednost te funkcije nedoločena.
    ///
    /// Stabilizirana različica tega bistvenega je [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Izračuna odmik od kazalca.
    ///
    /// To je izvedeno kot lastno, da se prepreči pretvorba v celo število in iz njega, saj bi pretvorba zavrgla vzdevek.
    ///
    /// # Safety
    ///
    /// Kazalec začetka in rezultata mora biti v mejah ali en bajt mimo konca dodeljenega predmeta.
    /// Če je kateri koli kazalec zunaj meja ali pride do aritmetičnega prelivanja, bo vsaka nadaljnja uporaba vrnjene vrednosti povzročila nedefinirano vedenje.
    ///
    ///
    /// Stabilizirana različica tega bistvenega je [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Izračuna odmik od kazalca, ki se lahko zavije.
    ///
    /// To je izvedeno kot lastno, da se prepreči pretvorba v celo število in iz njega, saj pretvorba onemogoča nekatere optimizacije.
    ///
    /// # Safety
    ///
    /// Za razliko od intrinzičnega `offset` ta intrinzični ne omejuje nastalega kazalca, da kaže na en bajt ali mimo konca dodeljenega predmeta, in se ovije z dopolnilno aritmetiko.
    /// Nastala vrednost ni nujno veljavna za dejanski dostop do pomnilnika.
    ///
    /// Stabilizirana različica tega bistvenega je [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Enakovredno ustrezni notranji `llvm.memcpy.p0i8.0i8.*`, z velikostjo `count`*`size_of::<T>()` in poravnavo
    ///
    /// `min_align_of::<T>()`
    ///
    /// Hlapni parameter je nastavljen na `true`, zato ne bo optimiziran, razen če je velikost enaka nič.
    ///
    /// Ta lastnost nima stabilnega primerka.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Enakovredno ustrezni notranji `llvm.memmove.p0i8.0i8.*`, z velikostjo `count* size_of::<T>()` in poravnavo
    ///
    /// `min_align_of::<T>()`
    ///
    /// Hlapni parameter je nastavljen na `true`, zato ne bo optimiziran, razen če je velikost enaka nič.
    ///
    /// Ta lastnost nima stabilnega primerka.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Enakovredno ustrezni notranji `llvm.memset.p0i8.*`, z velikostjo `count* size_of::<T>()` in poravnavo `min_align_of::<T>()`.
    ///
    ///
    /// Hlapni parameter je nastavljen na `true`, zato ne bo optimiziran, razen če je velikost enaka nič.
    ///
    /// Ta lastnost nima stabilnega primerka.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Izvede hlapljivo obremenitev iz kazalca `src`.
    ///
    /// Stabilizirana različica tega bistvenega je [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Izvede hlapljivo shrambo za kazalec `dst`.
    ///
    /// Stabilizirana različica tega bistvenega je [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Izvede hlapljivo obremenitev iz kazalca `src` Kazalca ni treba poravnati.
    ///
    ///
    /// Ta lastnost nima stabilnega primerka.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Izvede hlapljivo shrambo za kazalec `dst`.
    /// Kazalca ni treba poravnati.
    ///
    /// Ta lastnost nima stabilnega primerka.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Vrne kvadratni koren `f32`
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Vrne kvadratni koren `f64`
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Dvigne `f32` na celo število.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Dvigne `f64` na celo število.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Vrne sinus `f32`.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Vrne sinus `f64`.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Vrne kosinus `f32`.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Vrne kosinus `f64`.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Dvigne `f32` do moči `f32`.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Dvigne `f64` do moči `f64`.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Vrne eksponent `f32`.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Vrne eksponent `f64`.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Vrne 2, dvignjen na moč `f32`.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Vrne 2, dvignjen na moč `f64`.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Vrne naravni logaritem `f32`.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Vrne naravni logaritem `f64`.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Vrne osnovni 10 logaritem `f32`.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Vrne osnovni 10 logaritem `f64`.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Vrne osnovni logaritem 2 `f32`.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Vrne osnovni logaritem 2 `f64`.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Vrne `a * b + c` za vrednosti `f32`.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Vrne `a * b + c` za vrednosti `f64`.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Vrne absolutno vrednost `f32`.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Vrne absolutno vrednost `f64`.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Vrne najmanj dve vrednosti `f32`.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Vrne najmanj dve vrednosti `f64`.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Vrne največ dve vrednosti `f32`.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Vrne največ dve vrednosti `f64`.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Kopira znak iz `y` v `x` za vrednosti `f32`.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Kopira znak iz `y` v `x` za vrednosti `f64`.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Vrne največje celo število, manjše ali enako `f32`.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Vrne največje celo število, manjše ali enako `f64`.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Vrne najmanjše celo število, večje ali enako `f32`.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Vrne najmanjše celo število, večje ali enako `f64`.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Vrne celoštevilski del `f32`.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Vrne celoštevilski del `f64`.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Vrne najbližje celo število `f32`.
    /// Lahko povzroči nenatančno izjemo s plavajočo vejico, če argument ni celo število.
    pub fn rintf32(x: f32) -> f32;
    /// Vrne najbližje celo število `f64`.
    /// Lahko povzroči nenatančno izjemo s plavajočo vejico, če argument ni celo število.
    pub fn rintf64(x: f64) -> f64;

    /// Vrne najbližje celo število `f32`.
    ///
    /// Ta lastnost nima stabilnega primerka.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Vrne najbližje celo število `f64`.
    ///
    /// Ta lastnost nima stabilnega primerka.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Vrne najbližje celo število `f32`.Zaokroži polovične primere stran od nič.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Vrne najbližje celo število `f64`.Zaokroži polovične primere stran od nič.
    ///
    /// Stabilizirana različica tega bistvenega je
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Dodatek float, ki omogoča optimizacije na podlagi algebrskih pravil.
    /// Lahko domnevamo, da so vnosi končni.
    ///
    /// Ta lastnost nima stabilnega primerka.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Odštevanje float-a, ki omogoča optimizacije na podlagi algebraičnih pravil.
    /// Lahko domnevamo, da so vnosi končni.
    ///
    /// Ta lastnost nima stabilnega primerka.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Množenje s plovcem, ki omogoča optimizacije na podlagi algebrskih pravil.
    /// Lahko domnevamo, da so vnosi končni.
    ///
    /// Ta lastnost nima stabilnega primerka.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Float razdelitev, ki omogoča optimizacije na podlagi algebrskih pravil.
    /// Lahko domnevamo, da so vnosi končni.
    ///
    /// Ta lastnost nima stabilnega primerka.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Float ostanek, ki omogoča optimizacije na podlagi algebrskih pravil.
    /// Lahko domnevamo, da so vnosi končni.
    ///
    /// Ta lastnost nima stabilnega primerka.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Pretvorite z LLVM-jem fptoui/fptosi, ki lahko vrne undef za vrednosti zunaj obsega
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Stabiliziran kot [`f32::to_int_unchecked`] in [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Vrne število bitov, nastavljenih v celoštevilčnem tipu `T`
    ///
    /// Stabilizirane različice tega lastnega besedila so na voljo na primitivih s celo število po metodi `count_ones`.
    /// Na primer
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Vrne število vodilnih nenastavljenih bitov (zeroes) v celoštevilčnem tipu `T`.
    ///
    /// Stabilizirane različice te intrinzične različice so na voljo na primitivih s celo število prek metode `leading_zeros`.
    /// Na primer
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `x` z vrednostjo `0` bo vrnil bitno širino `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Tako kot `ctlz`, vendar zelo nevaren, saj vrne `undef`, ko dobi `x` z vrednostjo `0`.
    ///
    ///
    /// Ta lastnost nima stabilnega primerka.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Vrne število zaključenih nenastavljenih bitov (zeroes) v celoštevilčnem tipu `T`.
    ///
    /// Stabilizirane različice te intrinzične različice so na voljo na primitivih s celo število prek metode `trailing_zeros`.
    /// Na primer
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `x` z vrednostjo `0` bo vrnil bitno širino `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Tako kot `cttz`, vendar zelo nevaren, saj vrne `undef`, ko dobi `x` z vrednostjo `0`.
    ///
    ///
    /// Ta lastnost nima stabilnega primerka.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Obrne bajte v celoštevilčnem tipu `T`.
    ///
    /// Stabilizirane različice te intrinzične različice so na voljo na primitivih s celo število prek metode `swap_bytes`.
    /// Na primer
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Obrne bitove v celoštevilčnem tipu `T`.
    ///
    /// Stabilizirane različice te intrinzične različice so na voljo na primitivih s celo število prek metode `reverse_bits`.
    /// Na primer
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Izvede preverjeno seštevanje celih števil.
    ///
    /// Stabilizirane različice te intrinzične različice so na voljo na primitivih s celo število prek metode `overflowing_add`.
    /// Na primer
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Izvede odštevano celoštevilsko število
    ///
    /// Stabilizirane različice te intrinzične različice so na voljo na primitivih s celo število prek metode `overflowing_sub`.
    /// Na primer
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Izvede preverjeno množenje celih števil
    ///
    /// Stabilizirane različice tega lastnega besedila so na voljo na primitivih s celo število po metodi `overflowing_mul`.
    /// Na primer
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Izvede natančno delitev, kar povzroči nedefinirano vedenje, kjer `x % y != 0` ali `y == 0` ali `x == T::MIN && y == -1`
    ///
    ///
    /// Ta lastnost nima stabilnega primerka.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Izvede nepreverjeno delitev, kar povzroči nedefinirano vedenje, kjer `y == 0` ali `x == T::MIN && y == -1`
    ///
    ///
    /// Varni ovitki za to lastno lastnost so na voljo na primitivih s celo število po metodi `checked_div`.
    /// Na primer
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Vrne preostanek nepreverjene delitve, kar povzroči nedefinirano vedenje, kadar `y == 0` ali `x == T::MIN && y == -1`
    ///
    ///
    /// Varni ovitki za to lastno lastnost so na voljo na primitivih s celo število po metodi `checked_rem`.
    /// Na primer
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Izvede nepreverjen premik v levo, kar povzroči nedefinirano vedenje pri `y < 0` ali `y >= N`, kjer je N širina T v bitih.
    ///
    ///
    /// Varni ovitki za to lastno lastnost so na voljo na primitivih s celo število po metodi `checked_shl`.
    /// Na primer
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Izvede nepreverjen premik v desno, kar povzroči nedefinirano vedenje pri `y < 0` ali `y >= N`, kjer je N širina T v bitih.
    ///
    ///
    /// Varni ovitki za to lastno lastnost so na voljo na primitivih s celo število po metodi `checked_shr`.
    /// Na primer
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Vrne rezultat nepreverjenega dodajanja, ki ima za posledico nedefinirano vedenje pri `x + y > T::MAX` ali `x + y < T::MIN`.
    ///
    ///
    /// Ta lastnost nima stabilnega primerka.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Vrne rezultat nepreverjenega odštevanja, kar povzroči nedefinirano vedenje pri `x - y > T::MAX` ali `x - y < T::MIN`.
    ///
    ///
    /// Ta lastnost nima stabilnega primerka.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Vrne rezultat nepreverjenega množenja, ki ima za posledico nedefinirano vedenje pri `x *y > T::MAX` ali `x* y < T::MIN`.
    ///
    ///
    /// Ta lastnost nima stabilnega primerka.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Izvaja zasuk v levo.
    ///
    /// Stabilizirane različice te intrinzične različice so na voljo na primitivih s celo število prek metode `rotate_left`.
    /// Na primer
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Izvaja zasuk v desno.
    ///
    /// Stabilizirane različice te intrinzične različice so na voljo na primitivih s celo število prek metode `rotate_right`.
    /// Na primer
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Vrne (a + b) mod 2 <sup>N</sup>, kjer je N širina T v bitih.
    ///
    /// Stabilizirane različice te intrinzične različice so na voljo na primitivih s celo število prek metode `wrapping_add`.
    /// Na primer
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Vrne (a, b) mod 2 <sup>N</sup>, kjer je N širina T v bitih.
    ///
    /// Stabilizirane različice te intrinzične različice so na voljo na primitivih s celo število prek metode `wrapping_sub`.
    /// Na primer
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Vrne (a * b) mod 2 <sup>N</sup>, kjer je N širina T v bitih.
    ///
    /// Stabilizirane različice te intrinzične različice so na voljo na primitivih s celo število prek metode `wrapping_mul`.
    /// Na primer
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Izračuna `a + b`, nasičenje na številskih mejah.
    ///
    /// Stabilizirane različice te intrinzične različice so na voljo na primitivih s celo število prek metode `saturating_add`.
    /// Na primer
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Izračuna `a - b`, nasičenje na številskih mejah.
    ///
    /// Stabilizirane različice te intrinzične različice so na voljo na primitivih s celo število prek metode `saturating_sub`.
    /// Na primer
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Vrne vrednost diskriminante za različico v 'v';
    /// če `T` nima diskriminanta, vrne `0`.
    ///
    /// Stabilizirana različica tega bistvenega je [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Vrne število različic vrste `T`, oddanih v `usize`;
    /// če `T` nima različic, vrne `0`.Upoštevane bodo nenaseljene različice.
    ///
    /// Stabilizirana različica tega bistvenega je [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Konstrukcija "try catch" Rust, ki s kazalcem podatkov `data` prikliče funkcijski kazalec `try_fn`.
    ///
    /// Tretji argument je funkcija, ki se pokliče, če se pojavi panic.
    /// Ta funkcija sprejme podatkovni kazalnik in kazalnik na ciljni izjemen objekt, ki je bil ujet.
    ///
    /// Za več informacij glejte vir prevajalnika in izvedbo ulova std.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Oddaja trgovino `!nontemporal` v skladu z LLVM (glejte njihove dokumente).
    /// Verjetno nikoli ne bo postal stabilen.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Za podrobnosti glejte dokumentacijo `<*const T>::offset_from`.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Za podrobnosti glejte dokumentacijo `<*const T>::guaranteed_eq`.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Za podrobnosti glejte dokumentacijo `<*const T>::guaranteed_ne`.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Dodelite v času prevajanja.Ne sme biti poklican med izvajanjem.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Nekatere funkcije so tukaj definirane, ker so bile v tem modulu naključno na voljo na stabilnem.
// Glejte <https://github.com/rust-lang/rust/issues/15702>.
// (Tudi `transmute` spada v to kategorijo, vendar je ni mogoče zaviti zaradi preverjanja, ali imata `T` in `U` enako velikost.)
//

/// Preveri, ali je `ptr` pravilno poravnan glede na `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Kopira bajte `count *size_of::<T>()` od `src` do `dst`.Vir in cilj se ne smeta* prekrivati.
///
/// Za območja pomnilnika, ki se lahko prekrivajo, namesto tega uporabite [`copy`].
///
/// `copy_nonoverlapping` je pomensko enakovreden C-jevemu [`memcpy`], vendar z zamenjanim vrstnim redom argumentov.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Vedenje ni določeno, če je kršen kateri od naslednjih pogojev:
///
/// * `src` mora biti [valid] za branje bajtov `count * size_of::<T>()`.
///
/// * `dst` mora biti [valid] za zapisovanje bajtov `count * size_of::<T>()`.
///
/// * Tako `src` kot `dst` morata biti pravilno poravnana.
///
/// * Območje pomnilnika, ki se začne pri `src`, z velikostjo `count *
///   velikost_: :<T>() `bajti se ne smejo * prekrivati z območjem pomnilnika, ki se začne pri `dst` z enako velikostjo.
///
/// Tako kot [`read`] tudi `copy_nonoverlapping` ustvari bitno kopijo `T`, ne glede na to, ali je `T` [`Copy`].
/// Če `T` ni [`Copy`], lahko z uporabo *obeh* vrednosti v območju, ki se začne pri `*src`, in območju, ki se začne pri `* dst`, lahko [violate memory safety][read-ownership].
///
///
/// Upoštevajte, da tudi če je dejansko kopirana velikost (`count * size_of: :<T>()`) je `0`, kazalci ne smejo biti NULL in pravilno poravnani.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Ročno izvedite [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Premakne vse elemente `src` v `dst`, `src` pa ostane prazen.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Prepričajte se, da ima `dst` dovolj zmogljivosti za shranjevanje celotnega `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Klic na odmik je vedno varen, ker `Vec` nikoli ne bo dodelil več kot `isize::MAX` bajtov.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Skrajšajte `src`, ne da bi pri tem spustili njegovo vsebino.
///         // To naredimo najprej, da se izognemo težavam v primeru, da kaj nižje od panics.
///         src.set_len(0);
///
///         // Obe regiji se ne moreta prekrivati, ker spremenljive reference nimajo vzdevkov, dve različni vectors pa ne moreta imeti istega pomnilnika.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Obvestite `dst`, da zdaj vsebuje vsebino `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Ta preverjanja izvajajte samo med izvajanjem
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Brez panike, da bi bil vpliv kodegena manjši.
        abort();
    }*/

    // VARNOST: varnostna pogodba za `copy_nonoverlapping` mora biti
    // ki ga podpira klicatelj.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Kopira bajte `count * size_of::<T>()` od `src` do `dst`.Vir in cilj se lahko prekrivata.
///
/// Če se vir in cilj *nikoli* ne prekrivata, lahko namesto tega uporabite [`copy_nonoverlapping`].
///
/// `copy` je pomensko enakovreden C-jevemu [`memmove`], vendar z zamenjanim vrstnim redom argumentov.
/// Kopiranje poteka tako, kot da bi bili bajti kopirani iz `src` v začasno polje in nato kopirani iz polja v `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Vedenje ni določeno, če je kršen kateri od naslednjih pogojev:
///
/// * `src` mora biti [valid] za branje bajtov `count * size_of::<T>()`.
///
/// * `dst` mora biti [valid] za zapisovanje bajtov `count * size_of::<T>()`.
///
/// * Tako `src` kot `dst` morata biti pravilno poravnana.
///
/// Tako kot [`read`] tudi `copy` ustvari bitno kopijo `T`, ne glede na to, ali je `T` [`Copy`].
/// Če `T` ni [`Copy`], lahko z uporabo vrednosti v območju, ki se začne pri `*src`, in območju, ki se začne pri `* dst`, lahko [violate memory safety][read-ownership].
///
///
/// Upoštevajte, da tudi če je dejansko kopirana velikost (`count * size_of: :<T>()`) je `0`, kazalci ne smejo biti NULL in pravilno poravnani.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Učinkovito ustvarite Rust vector iz nevarnega medpomnilnika:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` mora biti pravilno poravnana glede na vrsto in ne nič.
/// /// * `ptr` mora veljati za branje sosednjih elementov `elts` tipa `T`.
/// /// * Po klicu te funkcije teh elementov ne smete uporabljati, razen `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // VARNOST: Naš predpogoj zagotavlja poravnanost in veljavnost vira,
///     // in `Vec::with_capacity` zagotavlja, da imamo uporaben prostor za njihovo pisanje.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // VARNOST: S tolikšno zmogljivostjo smo ga ustvarili že prej,
///     // prejšnji `copy` pa je te elemente inicializiral.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Ta preverjanja izvajajte samo med izvajanjem
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Brez panike, da bi bil vpliv kodegena manjši.
        abort();
    }*/

    // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `copy`.
    unsafe { copy(src, dst, count) }
}

/// Nastavi `count * size_of::<T>()` bajtov pomnilnika od `dst` do `val`.
///
/// `write_bytes` je podoben C-jevemu [`memset`], vendar `count * size_of::<T>()` bajtov nastavi na `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Vedenje ni določeno, če je kršen kateri od naslednjih pogojev:
///
/// * `dst` mora biti [valid] za zapisovanje bajtov `count * size_of::<T>()`.
///
/// * `dst` mora biti pravilno poravnana.
///
/// Poleg tega mora klicatelj zagotoviti, da zapisovanje bajtov `count * size_of::<T>()` v dano območje pomnilnika povzroči veljavno vrednost `T`.
/// Uporaba območja pomnilnika, vpisanega kot `T`, ki vsebuje neveljavno vrednost `T`, je nedefinirano vedenje.
///
/// Upoštevajte, da tudi če je dejansko kopirana velikost (`count * size_of: :<T>()`) je `0`, kazalnik mora biti NULL in pravilno poravnan.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Osnovna uporaba:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Ustvarjanje neveljavne vrednosti:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Uhaja predhodno zadržana vrednost s prepisovanjem `Box<T>` z ničelnim kazalcem.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // V tem trenutku uporaba ali spuščanje `v` povzroči nedefinirano vedenje.
/// // drop(v); // ERROR
///
/// // Celo pušča `v` "uses", zato je nedefinirano vedenje.
/// // mem::forget(v); // ERROR
///
/// // Dejansko je `v` neveljaven glede na osnovne invariante postavitve tipa, zato je *vsaka* operacija *, ki se ga dotika, nedefinirano.
/////
/// // naj bo v2 =v;//NAPAKA
///
/// unsafe {
///     // Namesto tega vnesite veljavno vrednost
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Zdaj je škatla v redu
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `write_bytes`.
    unsafe { write_bytes(dst, val, count) }
}