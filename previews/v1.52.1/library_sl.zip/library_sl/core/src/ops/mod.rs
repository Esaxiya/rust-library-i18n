//! Prenosljivi operaterji.
//!
//! Izvedba teh traits vam omogoča preobremenitev nekaterih operaterjev.
//!
//! Nekatere od teh traits uvozi prelude, zato so na voljo v vseh programih Rust.Preobremenjeni so lahko samo operaterji, ki jih podpira traits.
//! Operater seštevanja (`+`) je na primer mogoče preobremeniti z [`Add`] Portrait, ker pa operater dodelitve (`=`) nima podpore Portrait, ni mogoče preobremeniti njegove semantike.
//! Poleg tega ta modul ne ponuja nobenega mehanizma za ustvarjanje novih operaterjev.
//! Če so potrebna nenehna preobremenitev ali operatorji po meri, se obrnite na makre ali vtičnike prevajalnika, da razširite sintakso Rust.
//!
//! Izvedbe operaterja traits ne bi smele presenetiti v njihovih okoliščinah, ob upoštevanju njihovih običajnih pomenov in [operator precedence].
//! Na primer, pri izvajanju [`Mul`] mora biti operacija nekoliko podobna množenju (in si deliti pričakovane lastnosti, kot je asociativnost).
//!
//! Upoštevajte, da operaterja `&&` in `||` pride do kratkega stika, tj. Ocenijo svoj drugi operand le, če prispeva k rezultatu.Ker traits tega vedenja ne more uveljaviti, `&&` in `||` niso podprti kot prenosljivi operaterji.
//!
//! Mnogi operaterji svoje operande jemljejo po vrednosti.V splošnih okoliščinah, ki vključujejo vgrajene tipe, to običajno ni problem.
//! Vendar pa uporaba teh operatorjev v generični kodi zahteva nekaj pozornosti, če je treba vrednosti ponovno uporabiti, namesto da bi jim operaterji dovolili, da jih porabijo.Ena od možnosti je občasna uporaba [`clone`].
//! Druga možnost je, da se zanesete na vključene vrste, ki zagotavljajo dodatne izvedbe operaterjev za reference.
//! Na primer, za uporabniško določen tip `T`, ki naj bi podpiral dodajanje, je verjetno dobro, da `T` in `&T` implementirata traits [`Add<T>`][`Add`] in [`Add<&T>`][`Add`], da lahko generično kodo napišemo brez nepotrebnega kloniranja.
//!
//!
//! # Examples
//!
//! Ta primer ustvari strukturo `Point`, ki implementira [`Add`] in [`Sub`], nato pa prikaže dodajanje in odštevanje dveh točk.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Za primer izvedbe glejte dokumentacijo za vsak Portrait.
//!
//! [`Fn`], [`FnMut`] in [`FnOnce`] traits se izvajajo po tipih, ki jih je mogoče priklicati kot funkcije.Upoštevajte, da [`Fn`] potrebuje `&self`, [`FnMut`] `&mut self` in [`FnOnce`] `self`.
//! Ti ustrezajo trem vrstam metod, ki jih je mogoče priklicati na primerku: klic po referenci, klic po spremenljivi referenci in klic po vrednosti.
//! Najpogostejša uporaba teh traits je, da delujejo kot meje za funkcije višje ravni, ki funkcije ali zapore jemljejo kot argumente.
//!
//! Če vzamemo [`Fn`] kot parameter:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! Če vzamemo [`FnMut`] kot parameter:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! Če vzamemo [`FnOnce`] kot parameter:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` porabi zajete spremenljivke, zato ga ni mogoče zagnati več kot enkrat
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Če poskusite znova priklicati `func()`, bo pri `func` prišlo do napake `use of moved value`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` na tej točki ni več mogoče uporabiti
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;