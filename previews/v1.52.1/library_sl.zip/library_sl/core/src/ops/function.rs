/// Različica operaterja klica, ki sprejme nespremenljivega sprejemnika.
///
/// Primerke `Fn` je mogoče večkrat poklicati brez stanja mutacije.
///
/// *Tega Portrait (`Fn`) ne smemo zamenjati z [function pointers] (`fn`).*
///
/// `Fn` se samodejno implementira z zapirali, ki sprejemajo samo nespremenljive sklice na zajete spremenljivke ali pa sploh ne zajemajo ničesar, pa tudi (safe) [function pointers] (za nekatere podrobnosti glejte njihovo dokumentacijo za več podrobnosti).
///
/// Poleg tega za katero koli vrsto `F`, ki implementira `Fn`, `&F` izvaja tudi `Fn`.
///
/// Ker sta [`FnMut`] in [`FnOnce`] nadosebki `Fn`, lahko kateri koli primerek `Fn` uporabimo kot parameter, kjer pričakujemo [`FnMut`] ali [`FnOnce`].
///
/// `Fn` uporabite kot vezavo, če želite sprejeti parameter funkcijskemu tipu in ga morate poklicati večkrat in brez mutirajočega stanja (npr. Pri sočasnem klicu).
/// Če ne potrebujete tako strogih zahtev, uporabite [`FnMut`] ali [`FnOnce`] kot omejitve.
///
/// Za več informacij o tej temi glejte [chapter on closures in *The Rust Programming Language*][book].
///
/// Opozoriti je treba tudi na posebno sintakso `Fn` traits (npr
/// `Fn(usize, bool) -> usize`).Tisti, ki jih zanimajo tehnične podrobnosti tega, se lahko sklicujejo na [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Klicanje zapore
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Uporaba parametra `Fn`
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // tako da se lahko regex zanese na ta `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Izvede operacijo klica.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Različica operaterja klica, ki ima spremenljiv sprejemnik.
///
/// Primerke `FnMut` lahko kličemo večkrat in lahko spreminja stanje.
///
/// `FnMut` se samodejno implementira z zapirali, ki imajo spremenljive sklice na zajete spremenljivke, pa tudi vse vrste, ki izvajajo [`Fn`], npr. (safe) [function pointers] (ker je `FnMut` superstrait [`Fn`]).
/// Poleg tega za katero koli vrsto `F`, ki implementira `FnMut`, `&mut F` izvaja tudi `FnMut`.
///
/// Ker je [`FnOnce`] supersrait `FnMut`, lahko kateri koli primerek `FnMut` uporabimo tam, kjer se pričakuje [`FnOnce`], in ker je [`Fn`] podrazred `FnMut`, lahko kateri koli primerek [`Fn`] uporabimo tam, kjer pričakujemo `FnMut`.
///
/// `FnMut` uporabite kot vezavo, če želite sprejeti parameter funkcijskemu tipu in ga morate večkrat poklicati, hkrati pa mu omogočiti mutacijo stanja.
/// Če ne želite, da parameter mutira stanje, uporabite [`Fn`] kot vezan;če vam ga ni treba večkrat poklicati, uporabite [`FnOnce`].
///
/// Za več informacij o tej temi glejte [chapter on closures in *The Rust Programming Language*][book].
///
/// Opozoriti je treba tudi na posebno sintakso `Fn` traits (npr
/// `Fn(usize, bool) -> usize`).Tisti, ki jih zanimajo tehnične podrobnosti tega, se lahko sklicujejo na [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Klic mutabilnega zapiranja
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Uporaba parametra `FnMut`
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // tako da se lahko regex zanese na ta `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Izvede operacijo klica.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Različica operaterja klica, ki sprejme sprejemnika vrednosti.
///
/// Lahko pokličete primerke `FnOnce`, vendar jih morda večkrat ni mogoče poklicati.Če je pri tipu edino znano, da izvaja `FnOnce`, ga je mogoče poklicati samo enkrat.
///
/// `FnOnce` se samodejno izvaja z zapirali, ki lahko porabijo zajete spremenljivke, pa tudi vse vrste, ki implementirajo [`FnMut`], npr. (safe) [function pointers] (ker je `FnOnce` supertran [`FnMut`]).
///
///
/// Ker sta [`Fn`] in [`FnMut`] podvrste `FnOnce`, lahko kateri koli primerek [`Fn`] ali [`FnMut`] uporabimo tam, kjer pričakujemo `FnOnce`.
///
/// Uporabite `FnOnce` kot vezavo, če želite sprejeti parameter funkcijskemu tipu in ga morate poklicati samo enkrat.
/// Če morate parameter večkrat poklicati, uporabite [`FnMut`] kot vezanega;če ga potrebujete tudi za mutiranje stanja, uporabite [`Fn`].
///
/// Za več informacij o tej temi glejte [chapter on closures in *The Rust Programming Language*][book].
///
/// Opozoriti je treba tudi na posebno sintakso `Fn` traits (npr
/// `Fn(usize, bool) -> usize`).Tisti, ki jih zanimajo tehnične podrobnosti tega, se lahko sklicujejo na [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Uporaba parametra `FnOnce`
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` porabi zajete spremenljivke, zato ga ni mogoče zagnati več kot enkrat.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Če poskusite znova priklicati `func()`, bo pri `func` prišlo do napake `use of moved value`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` na tej točki ni več mogoče uporabiti
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // tako da se lahko regex zanese na ta `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Vrnjena vrsta po uporabi klicnega operaterja.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Izvede operacijo klica.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}