/// Koda po meri znotraj destruktorja.
///
/// Ko vrednost ni več potrebna, bo Rust na tej vrednosti zagnal "destructor".
/// Najpogostejši način, da vrednost ni več potrebna, je, ko gre zunaj obsega.Destruktorji lahko še vedno delujejo v drugih okoliščinah, vendar se bomo osredotočili na obseg za primere tukaj.
/// Če želite izvedeti več o teh drugih primerih, glejte [the reference] razdelek o destruktorjih.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Ta destruktor je sestavljen iz dveh komponent:
/// - Klic `Drop::drop` za to vrednost, če je za vaš tip izveden ta posebni `Drop` Portrait.
/// - Samodejno generiran "drop glue", ki rekurzivno pokliče destruktorje vseh polj te vrednosti.
///
/// Ker Rust samodejno pokliče destruktorje vseh vsebovanih polj, vam v večini primerov ni treba implementirati `Drop`.
/// Vendar je v nekaterih primerih koristno, na primer za vrste, ki neposredno upravljajo vir.
/// Ta vir je lahko pomnilnik, lahko je deskriptor datoteke, lahko je omrežna vtičnica.
/// Ko se vrednost te vrste ne bo več uporabljala, naj "clean up" svoj vir sprosti tako, da sprosti pomnilnik ali zapre datoteko ali vtičnico.
/// To je naloga destruktorja in s tem naloga `Drop::drop`.
///
/// ## Examples
///
/// Če si želimo ogledati destruktorje, si oglejmo naslednji program:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust bo najprej poklical `Drop::drop` za `_x` in nato še za `_x.one` in `_x.two`, kar pomeni, da se bo tiskanje tiskalo
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Tudi če odstranimo izvedbo `Drop` za `HasTwoDrop`, se še vedno prikličejo destruktorji njegovih polj.
/// To bi povzročilo
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## `Drop::drop` ne morete poklicati sami
///
/// Ker se `Drop::drop` uporablja za čiščenje vrednosti, je po klicu metode morda nevarno uporabiti to vrednost.
/// Ker `Drop::drop` ne prevzame lastništva nad svojim vhodom, Rust preprečuje zlorabo, saj vam ne omogoča neposrednega klica `Drop::drop`.
///
/// Z drugimi besedami, če ste poskušali izrecno poklicati `Drop::drop` v zgornjem primeru, boste dobili napako prevajalnika.
///
/// Če želite izrecno poklicati destruktor vrednosti, lahko namesto njega uporabite [`mem::drop`].
///
/// [`mem::drop`]: drop
///
/// ## Odloži naročilo
///
/// Kateri od naših dveh `HasDrop` pa najprej pade?Pri konstrukcijah gre za isti vrstni red, kot so razglašeni: najprej `one`, nato `two`.
/// Če bi to želeli preizkusiti sami, lahko zgoraj spremenite `HasDrop`, da vsebuje nekaj podatkov, na primer celo število, in ga nato uporabite v `println!` znotraj `Drop`.
/// Takšno vedenje jamči jezik.
///
/// Za razliko od struktur se lokalne spremenljivke spuščajo v obratnem vrstnem redu:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// To se bo natisnilo
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Za celotna pravila glejte [the reference].
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` in `Drop` sta ekskluzivni
///
/// [`Copy`] in `Drop` ne morete implementirati na isti vrsti.Vrste, ki so `Copy`, prevajalnik implicitno podvoji, zaradi česar je zelo težko napovedati, kdaj in kako pogosto bodo izvedeni destruktorji.
///
/// Kot take te vrste ne morejo imeti destruktorjev.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Izvede destruktor za to vrsto.
    ///
    /// Ta metoda se pokliče implicitno, ko vrednost preseže obseg, in je ni mogoče izrecno poklicati (gre za napako prevajalnika [E0040]).
    /// Vendar pa lahko funkcijo [`mem::drop`] v prelude uporabimo za klic izvajanja argumenta `Drop`.
    ///
    /// Ko je bila ta metoda poklicana, `self` še ni odstranjen.
    /// To se zgodi šele po koncu metode.
    /// Če ne bi bilo tako, bi bil `self` viseča referenca.
    ///
    /// # Panics
    ///
    /// Glede na to, da bo [`panic!`] med odvijanjem poklical `drop`, bo vsak [`panic!`] v izvedbi `drop` verjetno prekinil.
    ///
    /// Upoštevajte, da tudi če je ta panics, se šteje, da je vrednost znižana;
    /// ne smete povzročiti ponovnega klica `drop`.
    /// To prevajalnik običajno samodejno obdela, vendar se pri uporabi nevarne kode včasih lahko zgodi nenamerno, zlasti pri uporabi [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}