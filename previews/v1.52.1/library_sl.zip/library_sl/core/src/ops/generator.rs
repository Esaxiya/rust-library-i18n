use crate::marker::Unpin;
use crate::pin::Pin;

/// Rezultat obnovitve generatorja.
///
/// Ta enum se vrne iz metode `Generator::resume` in označuje možne vrnjene vrednosti generatorja.
/// Trenutno to ustreza bodisi točki vzmetenja (`Yielded`) bodisi končni točki (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Generator je obešen z vrednostjo.
    ///
    /// To stanje pomeni, da je bil generator onemogočen, in običajno ustreza stavku `yield`.
    /// Vrednost, navedena v tej različici, ustreza izrazu, posredovanemu `yield`, in omogoča generatorjem, da podajo vrednost vsakič, ko dajo.
    ///
    ///
    Yielded(Y),

    /// Generator dopolnjen z vrnjeno vrednostjo.
    ///
    /// To stanje pomeni, da je generator zaključil izvajanje s predloženo vrednostjo.
    /// Ko je generator vrnil `Complete`, se šteje za napako programerja, da znova pokliče `resume`.
    ///
    Complete(R),
}

/// Portrait, ki ga uporabljajo vgrajeni tipi generatorjev
///
/// Generatorji, ki jih pogosto imenujemo tudi podprogrami, so trenutno eksperimentalna jezikovna značilnost v Rust.
/// Trenutno dodani generatorji [RFC 2033] so namenjeni predvsem zagotavljanju gradnika sintakse async/await, verjetno pa se bodo razširili tudi na zagotavljanje ergonomske definicije za iteratorje in druge primitivne elemente.
///
///
/// Sintaksa in semantika generatorjev je nestabilna in bo za stabilizacijo potrebna dodatna RFC.Trenutno pa je sintaksa podobna zapiranju:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Več dokumentacije o generatorjih najdete v nestabilni knjigi.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Vrsta vrednosti, ki jo daje ta generator.
    ///
    /// Ta pridruženi tip ustreza izrazu `yield` in vrednostim, ki jih je dovoljeno vrniti vsakič, ko da generator.
    ///
    /// Na primer, iterator-kot-generator-bi verjetno imel ta tip kot `T`, pri čemer se tip ponavlja.
    ///
    type Yield;

    /// Tip vrednosti, ki jo vrne ta generator.
    ///
    /// To ustreza vrsti, ki jo vrne generator, bodisi z izjavo `return` bodisi implicitno kot zadnji izraz literale generatorja.
    /// Na primer futures bi to uporabil kot `Result<T, E>`, saj predstavlja dokončano future.
    ///
    ///
    type Return;

    /// Nadaljuje izvajanje tega generatorja.
    ///
    /// Ta funkcija bo nadaljevala izvajanje generatorja ali začela izvajanje, če se še ni.
    /// Ta klic se bo vrnil v zadnjo točko vzmetenja generatorja in nadaljeval z izvajanjem najnovejšega `yield`.
    /// Generator bo nadaljeval z izvajanjem, dokler ne bo dobil ali se vrnil, takrat se bo ta funkcija vrnila.
    ///
    /// # Vrnjena vrednost
    ///
    /// Vrnitev `GeneratorState`, vrnjena s to funkcijo, označuje, v kakšnem stanju je generator po vrnitvi.
    /// Če se vrne različica `Yielded`, je generator dosegel točko vzmetenja in podala se je vrednost.
    /// Generatorji v tem stanju so pozneje na voljo za ponovno uporabo.
    ///
    /// Če se vrne `Complete`, je generator v celoti končal z navedeno vrednostjo.Neveljavno je, da se generator ponovno zažene.
    ///
    /// # Panics
    ///
    /// Ta funkcija lahko panic, če je poklicana po predhodno vrnjeni različici `Complete`.
    /// Medtem ko so generatorji literature v jeziku zagotovljeni panic ob nadaljevanju po `Complete`, to ni zagotovljeno za vse izvedbe `Generator` Portrait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}