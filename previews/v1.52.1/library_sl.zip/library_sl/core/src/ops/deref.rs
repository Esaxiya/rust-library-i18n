/// Uporablja se za nespremenljive operacije preusmerjanja, kot je `*v`.
///
/// Poleg tega, da ga `Deref` v številnih okoliščinah implicitno uporablja tudi za eksplicitno dereferenciranje z operaterjem (unary) `*` v nespremenljivih kontekstih.
/// Ta mehanizem se imenuje ['`Deref` coercion'][more].
/// V spremenljivih okoliščinah se uporablja [`DerefMut`].
///
/// Z uporabo `Deref` za pametne kazalce je dostop do podatkov za njimi priročen, zato uporabljajo `Deref`.
/// Po drugi strani pa so bila pravila glede `Deref` in [`DerefMut`] zasnovana posebej za namestitev pametnih kazalcev.
/// Zaradi tega se **Deref` sme izvajati samo za pametne kazalce**, da ne pride do zmede.
///
/// Iz podobnih razlogov **ta Portrait nikoli ne sme odpovedati**.Neuspeh med preusmerjanjem referenc je lahko implicitno poklican `Deref` zelo zmeden.
///
/// # Več o prisili `Deref`
///
/// Če `T` implementira `Deref<Target = U>` in je `x` vrednost tipa `T`, potem:
///
/// * V nespremenljivem kontekstu je `*x` (kjer `T` ni niti referenca niti neobdelan kazalec) enakovreden `* Deref::deref(&x)`.
/// * Vrednosti tipa `&T` so prisiljene na vrednosti tipa `&U`
/// * `T` implicitno izvaja vse metode (immutable) tipa `U`.
///
/// Za več podrobnosti obiščite [the chapter in *The Rust Programming Language*][book] in referenčne odseke o [the dereference operator][ref-deref-op], [method resolution] in [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Struktura z enim samim poljem, ki je dostopna z dereferenciranjem strukture.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Dobljeni tip po preusmeritvi.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Odšteje vrednost.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Uporablja se za spremenljive operacije preusmerjanja, kot v `*v = 1;`.
///
/// Poleg tega, da ga `DerefMut` v številnih okoliščinah implicitno uporablja tudi prevajalnik v operacijah (unary) `*` v spremenljivih kontekstih.
/// Ta mehanizem se imenuje ['`Deref` coercion'][more].
/// V nespremenljivem kontekstu se uporablja [`Deref`].
///
/// Z uvedbo `DerefMut` za pametne kazalce je mutiranje podatkov za njimi priročno, zato uporabljajo `DerefMut`.
/// Po drugi strani pa so bila pravila glede [`Deref`] in `DerefMut` zasnovana posebej za namestitev pametnih kazalcev.
/// Zaradi tega je treba **`DerefMut` izvajati samo za pametne kazalce**, da ne pride do zmede.
///
/// Iz podobnih razlogov **ta Portrait nikoli ne sme odpovedati**.Neuspeh med preusmerjanjem referenc je lahko implicitno poklican `DerefMut` zelo zmeden.
///
/// # Več o prisili `Deref`
///
/// Če `T` implementira `DerefMut<Target = U>` in je `x` vrednost tipa `T`, potem:
///
/// * V spremenljivih kontekstih je `*x` (kjer `T` ni niti referenca niti neobdelani kazalec) enakovreden `* DerefMut::deref_mut(&mut x)`.
/// * Vrednosti tipa `&mut T` so prisiljene na vrednosti tipa `&mut U`
/// * `T` implicitno izvaja vse metode (mutable) tipa `U`.
///
/// Za več podrobnosti obiščite [the chapter in *The Rust Programming Language*][book] in referenčne odseke o [the dereference operator][ref-deref-op], [method resolution] in [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// Struktura z enim samim poljem, ki jo je mogoče spremeniti z razporejanjem reference na strukturo.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Natančno preusmeri vrednost.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Označuje, da je strukturo mogoče uporabiti kot sprejemnik metode brez funkcije `arbitrary_self_types`.
///
/// To izvajajo vrste kazalcev stdlib, kot so `Box<T>`, `Rc<T>`, `&T` in `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}