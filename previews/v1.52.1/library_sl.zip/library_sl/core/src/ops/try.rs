/// Portrait za prilagajanje vedenja operaterja `?`.
///
/// Tip, ki izvaja `Try`, je tisti, ki ima kanoničen način, da ga vidi v smislu dihotomije success/failure.
/// Ta Portrait omogoča tako pridobivanje vrednosti uspeha ali neuspeha iz obstoječega primerka kot tudi ustvarjanje novega primerka iz vrednosti uspeha ali neuspeha.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Vrsta te vrednosti, če se šteje za uspešno.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Vrsta te vrednosti, če je videti kot neuspešna.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Uporabi operater "?".Vrnitev `Ok(t)` pomeni, da se mora izvajanje nadaljevati normalno, rezultat `?` pa je vrednost `t`.
    /// Vrnitev `Err(e)` pomeni, da bi se izvedba morala branch najgloblje obdajati `catch` ali vrniti iz funkcije.
    ///
    /// Če je vrnjen rezultat `Err(e)`, bo vrednost `e` "wrapped" v vrsti vrnitve obsega, ki vključuje (ki mora sam implementirati `Try`).
    ///
    /// Natančneje, vrne se vrednost `X::from_error(From::from(e))`, kjer je `X` vrsta vrnitve funkcije zapiranja.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Zavijte vrednost napake, da sestavite sestavljeni rezultat.
    /// Na primer, `Result::Err(x)` in `Result::from_error(x)` sta enakovredna.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Zavijte vrednost OK, da sestavite sestavljeni rezultat.
    /// Na primer, `Result::Ok(x)` in `Result::from_ok(x)` sta enakovredna.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}