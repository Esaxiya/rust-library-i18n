//! Sestavljiva asinhrona ponovitev.
//!
//! Če so futures asinhrone vrednosti, so tokovi asinhroni iteratorji.
//! Če ste se znašli pred nekakšno asinhrono zbirko in potrebujete operacijo nad elementi te zbirke, boste hitro naleteli na 'streams'.
//! Potoki se pogosto uporabljajo v idiomatski asinhroni kodi Rust, zato se jih je vredno seznaniti.
//!
//! Preden razložimo več, se pogovorimo o strukturi tega modula:
//!
//! # Organization
//!
//! Ta modul je večinoma organiziran po vrstah:
//!
//! * [Traits] so jedrni del: ti traits določajo, kakšni tokovi obstajajo in kaj lahko z njimi počnete.Za metode teh traits je vredno vložiti nekaj dodatnega časa za učenje.
//! * Funkcije ponujajo nekaj koristnih načinov za ustvarjanje nekaterih osnovnih tokov.
//! * Strukture so pogosto vrnitvene vrste različnih metod na traits tega modula.Običajno boste želeli pogledati metodo, ki ustvarja `struct`, namesto samega `struct`.
//! Za več podrobnosti o tem, zakaj, glejte '[Implementing Stream](#Implementation-stream)'.
//!
//! [Traits]: #traits
//!
//! To je to!Kopamo v potoke.
//!
//! # Stream
//!
//! Srce in duša tega modula je [`Stream`] Portrait.Jedro [`Stream`] je videti takole:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Za razliko od `Iterator` `Stream` razlikuje med metodo [`poll_next`], ki se uporablja pri implementaciji `Stream`, in metodo (to-be-implemented) `next`, ki se uporablja pri porabi toka.
//!
//! Potrošniki `Stream` morajo upoštevati le `next`, ki ob klicu vrne future, ki da `Option<Stream::Item>`.
//!
//! future, ki ga vrne `next`, bo dal `Some(Item)`, dokler obstajajo elementi, in ko bodo vsi izčrpani, bo `None` označeval, da je ponovitev končana.
//! Če čakamo, da se razreši nekaj asinhronega, bo future počakal, dokler tok ni pripravljen, da bo spet dobil.
//!
//! Posamezni tokovi se lahko odločijo za nadaljevanje ponovitve, zato lahko ponovno klicanje `next` v določenem trenutku spet ali ne bo dalo `Some(Item)`.
//!
//! Polna definicija ['Stream`] vključuje tudi številne druge metode, vendar so to privzete metode, zgrajene na vrhu [`poll_next`], zato jih dobite brezplačno.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Izvajanje toka
//!
//! Ustvarjanje lastnega toka vključuje dva koraka: ustvarjanje `struct`, ki zadrži stanje toka, in nato izvajanje [`Stream`] za ta `struct`.
//!
//! Naredimo tok z imenom `Counter`, ki šteje od `1` do `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Prvič, struktura:
//!
//! /// Potok, ki šteje od enega do pet
//! struct Counter {
//!     count: usize,
//! }
//!
//! // želimo, da se naše štetje začne ob enem, zato v pomoč dodajte metodo new().
//! // To ni nujno potrebno, je pa priročno.
//! // Upoštevajte, da `count` začnemo pri nič, bomo videli, zakaj v izvedbi `poll_next()`'s spodaj.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Nato uvedemo `Stream` za naš `Counter`:
//!
//! impl Stream for Counter {
//!     // šteli bomo z usize
//!     type Item = usize;
//!
//!     // poll_next() je edina zahtevana metoda
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Povečaj naše štetje.Zato smo začeli z ničlo.
//!         self.count += 1;
//!
//!         // Preverite, ali smo končali s štetjem ali ne.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Potoki so *leni*.To pomeni, da samo ustvarjanje toka ne pomeni veliko _do_.Dokler ne pokličete `next`, se v resnici nič ne zgodi.
//! To včasih povzroča zmedo pri ustvarjanju toka izključno zaradi njegovih stranskih učinkov.
//! Prevajalnik nas bo opozoril na tovrstno vedenje:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;