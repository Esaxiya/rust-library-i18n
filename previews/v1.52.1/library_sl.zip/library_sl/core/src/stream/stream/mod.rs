use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Vmesnik za obravnavo asinhronih iteratorjev.
///
/// To je glavni tok Portrait.
/// Za več informacij o konceptu tokov na splošno glejte [module-level documentation].
/// Zlasti boste morda želeli vedeti, kako [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Vrsta elementov, ki jih daje tok.
    type Item;

    /// Poskusite izvleči naslednjo vrednost tega toka, registrirajte trenutno nalogo za prebuditev, če vrednost še ni na voljo, in vrnete `None`, če je tok izčrpan.
    ///
    /// # Vrnjena vrednost
    ///
    /// Obstaja več možnih vrnjenih vrednosti, od katerih vsaka označuje ločeno stanje toka:
    ///
    /// - `Poll::Pending` pomeni, da naslednja vrednost tega toka še ni pripravljena.Izvedbe bodo zagotovile, da bo trenutna naloga obveščena, ko bo pripravljena naslednja vrednost.
    ///
    /// - `Poll::Ready(Some(val))` pomeni, da je tok uspešno ustvaril vrednost `val` in lahko pri nadaljnjih klicih `poll_next` ustvari nadaljnje vrednosti.
    ///
    /// - `Poll::Ready(None)` pomeni, da se je tok zaključil in `poll_next` ne bi smeli več priklicati.
    ///
    /// # Panics
    ///
    /// Ko se tok zaključi (vrne `Ready(None)` from `poll_next`), lahko znova pokliče svojo metodo `poll_next`, lahko panic, blokira za vedno ali povzroči druge vrste težav; `Stream` Portrait ne postavlja nobenih zahtev glede učinkov takega klica.
    ///
    /// Ker pa metoda `poll_next` ni označena z `unsafe`, veljajo običajna pravila Rust: klici ne smejo nikoli povzročiti nedefiniranega vedenja (poškodovanje pomnilnika, nepravilna uporaba funkcij `unsafe` ali podobno), ne glede na stanje toka.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Vrne meje preostale dolžine toka.
    ///
    /// Natančneje, `size_hint()` vrne nabor, kjer je prvi element spodnja meja, drugi element pa zgornja meja.
    ///
    /// Druga polovica vrnjene vrvice je [`Možnost`]`<`[`usize`] `>`.
    /// [`None`] tukaj pomeni, da zgornja meja ni znana ali pa je zgornja meja večja od [`usize`].
    ///
    /// # Opombe o izvajanju
    ///
    /// Ni uveljavljeno, da izvedba toka daje prijavljeno število elementov.Tok buggyja lahko povzroči manj kot spodnjo mejo ali več kot zgornjo mejo elementov.
    ///
    /// `size_hint()` je v prvi vrsti namenjen uporabi za optimizacije, kot je rezerviranje prostora za elemente toka, vendar se mu ne sme zaupati, da npr. izpusti preverjanja mej v nevarni kodi.
    /// Napačna izvedba `size_hint()` ne bi smela povzročiti kršitev varnosti pomnilnika.
    ///
    /// Kljub temu bi morala izvedba zagotoviti pravilno oceno, ker bi sicer kršila protokol Portrait.
    ///
    /// Privzeta izvedba vrne "(0," ["Brez"] "), kar je pravilno za kateri koli tok.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}