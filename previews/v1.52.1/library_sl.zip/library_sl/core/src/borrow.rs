//! Modul za delo z izposojenimi podatki.

#![stable(feature = "rust1", since = "1.0.0")]

/// A Portrait za izposojo podatkov.
///
/// V Rust je običajno, da za različne primere uporabe zagotovimo različne predstavitve tipa.
/// Na primer, mesto shranjevanja in upravljanje vrednosti lahko izberete kot primerno za določeno uporabo prek tipov kazalcev, kot sta [`Box<T>`] ali [`Rc<T>`].
/// Poleg teh splošnih ovojev, ki jih je mogoče uporabiti s katero koli vrsto, nekatere vrste ponujajo neobvezne fasete, ki ponujajo potencialno drago funkcijo.
/// Primer za tak tip je [`String`], ki doda možnost razširitve niza osnovnemu [`str`].
/// To zahteva, da so za preprost, nespremenljiv niz potrebni dodatni podatki.
///
/// Ti tipi omogočajo dostop do osnovnih podatkov prek sklicev na vrsto teh podatkov.Pravijo, da so te vrste "izposojene kot".
/// Na primer, [`Box<T>`] si lahko izposodite kot `T`, medtem ko si [`String`] lahko izposodite kot `str`.
///
/// Vrste izražajo, da jih je mogoče izposoditi kot neke vrste `T` z izvajanjem `Borrow<T>`, pri čemer se v metodi [`borrow`] Z0 portala Z0 PortretZ navede referenca na `T`.Tip si lahko izposodite kot več različnih vrst.
/// Če se želi mutativno sposoditi kot tip, kar omogoča spreminjanje osnovnih podatkov, lahko dodatno implementira [`BorrowMut<T>`].
///
/// Nadalje je pri zagotavljanju izvedb dodatnih traits treba razmisliti, ali bi se morali obnašati enako kot osnovni tip, ki bi bil posledica predstavitve tega osnovnega tipa.
/// Generična koda običajno uporablja `Borrow<T>`, kadar se opira na enako vedenje teh dodatnih izvedb Portrait.
/// Te traits bodo verjetno prikazane kot dodatne Portrait bounds.
///
/// Zlasti `Eq`, `Ord` in `Hash` morajo biti enakovredne za izposojene vrednosti in vrednosti v lasti: `x.borrow() == y.borrow()` mora dati enak rezultat kot `x == y`.
///
/// Če mora generična koda le delovati za vse tipe, ki se lahko sklicujejo na sorodni tip `T`, je pogosto bolje uporabiti [`AsRef<T>`], saj ga lahko več vrst varno izvaja.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Kot zbirka podatkov je [`HashMap<K, V>`] lastnik tako ključev kot vrednosti.Če so dejanski podatki ključa zaviti v neko vrsto upravljanja, pa bi vseeno moralo biti mogoče poiskati vrednost s sklicevanjem na podatke ključa.
/// Na primer, če je ključ niz, je verjetno shranjen v zemljevidu razprševanja kot [`String`], medtem ko bi moralo biti mogoče iskati s pomočjo [`&str`][`str`].
/// Tako mora `insert` delovati na `String`, medtem ko mora `get` uporabljati `&str`.
///
/// Nekoliko poenostavljeni ustrezni deli `HashMap<K, V>` izgledajo tako:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // polja izpuščena
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Celotna razpršena karta je splošna za tip ključa `K`.Ker so ti ključi shranjeni na zemljevidu razprševanja, mora biti ta tip lastnik podatkov ključa.
/// Pri vstavljanju para ključ-vrednost dobi zemljevid tak `K` in mora najti pravilno razpršilno vedro ter na podlagi tega `K` preveriti, ali je ključ že prisoten.Zato zahteva `K: Hash + Eq`.
///
/// Pri iskanju vrednosti na zemljevidu pa bi bilo treba vedno navesti sklic na `K` kot ključ za iskanje, da bi vedno ustvarili takšno vrednost v lasti.
/// Za nizne ključe bi to pomenilo, da je treba ustvariti vrednost `String` samo za iskanje primerov, ko je na voljo samo `str`.
///
/// Namesto tega je metoda `get` splošna za vrsto osnovnih podatkov ključa, ki se v zgornjem podpisu metode imenuje `Q`.Navaja, da se `K` zadolžuje kot `Q` z zahtevo, da `K: Borrow<Q>`.
/// Z dodatno zahtevo `Q: Hash + Eq` signalizira zahtevo, da imajo `K` in `Q` izvedbe `Hash` in `Eq` traits, ki dajejo enake rezultate.
///
/// Izvedba `get` se opira zlasti na enake izvedbe `Hash` tako, da določi zgoščevalni segment ključa s klicem `Hash::hash` na vrednost `Q`, čeprav je ključ vstavil na podlagi razpršene vrednosti, izračunane iz vrednosti `K`.
///
///
/// Posledično se zemljevid zgoščevanja zlomi, če `K`, ki zavije vrednost `Q`, ustvari drugačno razpršitev kot `Q`.Na primer, predstavljajte si, da imate vrsto, ki zavije niz, vendar primerja črke ASCII, pri čemer ignorira njihov primer:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Ker morata dve enaki vrednosti ustvariti isto zgoščeno vrednost, mora tudi izvedba `Hash` prezreti primer ASCII:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Ali lahko `CaseInsensitiveString` izvede `Borrow<str>`?Vsekakor lahko zagotovi sklic na rezino niza prek njenega niza v lasti.
/// Ker pa se njegova izvedba `Hash` razlikuje, se obnaša drugače kot `str` in zato v resnici ne sme izvajati `Borrow<str>`.
/// Če želi drugim omogočiti dostop do osnovnega `str`, lahko to stori prek `AsRef<str>`, ki ne zahteva dodatnih zahtev.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Neposredno izposoja od vrednosti v lasti.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// Portrait za mutabilno izposojo podatkov.
///
/// Kot spremljevalec [`Borrow<T>`] ta Portrait omogoča, da se tip sposodi kot osnovni tip z zagotavljanjem spremenljive reference.
/// Za več informacij o izposoji kot drugi vrsti glejte [`Borrow<T>`].
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Izposoja se iz lastne vrednosti.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}