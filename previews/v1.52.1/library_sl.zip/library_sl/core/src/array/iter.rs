//! Določa iterator za nize v lasti `IntoIter`.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// Vrednostni iterator [array].
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// To je matrika, po kateri se ponavljamo.
    ///
    /// Elementi z indeksom `i`, kjer `alive.start <= i < alive.end` še niso bili izdani in so veljavni vnosi v matriko.
    /// Elementi z indeksi `i < alive.start` ali `i >= alive.end` so že pridobljeni in do njih ni več dovoljen dostop!Ti mrtvi elementi so lahko celo v popolnoma neinicializiranem stanju!
    ///
    ///
    /// Invariante so torej:
    /// - `data[alive]` je živ (tj. vsebuje veljavne elemente)
    /// - `data[..alive.start]` in `data[alive.end..]` sta mrtva (tj. elementi so že prebrani in se jih ne sme več dotikati!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Elementi v `data`, ki še niso bili pridobljeni.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Ustvari nov iterator nad danim `array`.
    ///
    /// *Opomba*: ta metoda bo morda zastarela v future po [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Tip `value` je tukaj `i32`, namesto `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // VARNOST: Tukajšnja transmutacija je dejansko varna.Dokumenti `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` ima zagotovljeno enako velikost in poravnavo
        // > kot `T`.
        //
        // Dokumenti celo prikazujejo pretvorbo iz polja `MaybeUninit<T>` v polje `T`.
        //
        //
        // S tem ta inicializacija zadovoljuje invariante.

        // FIXME(LukasKalbertodt): dejansko tukaj uporabite `mem::transmute`, ko bo deloval s const generiki:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Do takrat lahko z `mem::transmute_copy` ustvarimo bitno kopijo kot drugo vrsto, nato pozabimo na `array`, da ne pade.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Vrne nespremenljivo rezino vseh elementov, ki še niso bili izdani.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // VARNOST: Vemo, da so vsi elementi znotraj `alive` pravilno inicializirani.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Vrne spremenljivo rezino vseh elementov, ki še niso bili izdani.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // VARNOST: Vemo, da so vsi elementi znotraj `alive` pravilno inicializirani.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Pridobite naslednji indeks od spredaj.
        //
        // Povečanje `alive.start` za 1 ohranja nespremenljivost glede `alive`.
        // Vendar pa zaradi te spremembe za kratek čas območje za živo ni več `data[alive]`, ampak `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Preberite element iz polja.
            // VARNOST: `idx` je indeks nekdanje regije "alive" območja
            // matriko.Branje tega elementa pomeni, da `data[idx]` zdaj velja za mrtvega (tj. Ne dotikajte se).
            // Ker je bil `idx` začetek žive cone, je zdaj zopet živa cona `data[alive]`, ki obnavlja vse invariante.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Pridobite naslednji indeks od zadaj.
        //
        // Zmanjšanje `alive.end` za 1 ohranja nespremenljivost glede `alive`.
        // Vendar pa zaradi te spremembe za kratek čas območje za živo ni več `data[alive]`, ampak `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Preberite element iz polja.
            // VARNOST: `idx` je indeks nekdanje regije "alive" območja
            // matriko.Branje tega elementa pomeni, da `data[idx]` zdaj velja za mrtvega (tj. Ne dotikajte se).
            // Ker je bil `idx` konec žive cone, je zdaj zopet živa cona `data[alive]`, ki obnavlja vse invariante.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // VARNOST: To je varno: `as_mut_slice` vrne natančno podrezko
        // elementov, ki še niso bili premaknjeni in ki jih je treba izpustiti.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Nikoli se ne bo izlival zaradi nespremenljivega `live.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Ponavljalec res sporoči pravilno dolžino.
// Število elementov "alive" (ki bodo še vedno na voljo) je dolžina obsega `alive`.
// Dolžina tega obsega se zmanjša v `next` ali `next_back`.
// Pri teh metodah se vedno zmanjša za 1, vendar le, če je vrnjen `Some(_)`.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Upoštevajte, da nam v resnici ni treba ujemati popolnoma enakega obsega živega polja, zato lahko samo kloniramo v odmik 0, ne glede na to, kje je `self`.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Klonirajte vse žive elemente.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // V novo matriko vpišite klon, nato pa posodobite njegovo živo območje.
            // Če kloniramo panics, bomo prejšnje elemente pravilno spustili.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Natisnite samo elemente, ki še niso bili izdani: do pridobljenih elementov ne moremo več dostopati.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}