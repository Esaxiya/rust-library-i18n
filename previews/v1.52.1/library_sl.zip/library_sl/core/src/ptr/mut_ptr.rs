use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// Vrne `true`, če je kazalec ničen.
    ///
    /// Upoštevajte, da imajo tipi velikosti veliko možnih ničelnih kazalcev, saj se upošteva le kazalec neobdelanih podatkov, ne pa njihova dolžina, vtable itd.
    /// Zato dva kazalca, ki sta nična, še vedno morda ne bosta primerjala enaka.
    ///
    /// ## Vedenje med oceno const
    ///
    /// Ko se ta funkcija uporablja med ocenjevanjem const, lahko vrne `false` za kazalce, ki se med izvajanjem izkažejo za nične.
    /// Natančneje, ko se kazalnik na nek pomnilnik odmika preko svojih meja na tak način, da je nastali kazalec ničen, funkcija še vedno vrne `false`.
    ///
    /// CTFE nikakor ne more poznati absolutnega položaja tega pomnilnika, zato ne moremo ugotoviti, ali je kazalec ničen ali ne.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Primerjajte z zasedbo s tankim kazalcem, zato kazalci z maščobo razmišljajo o svojem delu "data" le za ničelnost.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Predvaja kazalec druge vrste.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// Razstavite (po možnosti širok) kazalec na naslov in komponente metapodatkov.
    ///
    /// Kazalec lahko kasneje rekonstruirate z [`from_raw_parts_mut`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// Vrne `None`, če je kazalec ničen, ali pa vrne referenco v skupni rabi na vrednost, ovito v `Some`.Če je vrednost morda neinicializirana, je treba namesto nje uporabiti [`as_uninit_ref`].
    ///
    /// Za spremenljiv primer glej [`as_mut`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// Ko kličete to metodo, morate zagotoviti, da je *bodisi* kazalec NULL *bodisi* velja vse naslednje:
    ///
    /// * Kazalec mora biti pravilno poravnan.
    ///
    /// * To mora biti "dereferencable" v smislu, opredeljenem v [the module documentation].
    ///
    /// * Kazalec mora kazati na inicializiran primerek `T`.
    ///
    /// * Morate uveljaviti pravila vzdevanja Rust, saj je vrnjena življenjska doba `'a` poljubno izbrana in ne odraža nujno dejanske življenjske dobe podatkov.
    ///   Zlasti v času te življenjske dobe pomnilnik, na katerega kaže kazalec, ne sme biti mutiran (razen znotraj `UnsafeCell`).
    ///
    /// To velja tudi, če je rezultat te metode neuporabljen!
    /// (Del o inicializaciji še ni popolnoma določen, vendar dokler ni, je edini varen pristop zagotoviti, da se resnično inicializirajo.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Nič nepreverjena različica
    ///
    /// Če ste prepričani, da kazalec nikoli ne more biti nič in iščete nekakšen `as_ref_unchecked`, ki vrne `&T` namesto `Option<&T>`, vedite, da lahko kazalec usmerite neposredno.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // VARNOST: klicatelj mora zagotoviti, da `self` velja za a
        // sklic, če ni nič.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Vrne `None`, če je kazalec ničen, ali pa vrne referenco v skupni rabi na vrednost, ovito v `Some`.
    /// V nasprotju z [`as_ref`] to ne zahteva, da je treba vrednost inicializirati.
    ///
    /// Za spremenljiv primer glej [`as_uninit_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// Ko kličete to metodo, morate zagotoviti, da je *bodisi* kazalec NULL *bodisi* velja vse naslednje:
    ///
    /// * Kazalec mora biti pravilno poravnan.
    ///
    /// * To mora biti "dereferencable" v smislu, opredeljenem v [the module documentation].
    ///
    /// * Morate uveljaviti pravila vzdevanja Rust, saj je vrnjena življenjska doba `'a` poljubno izbrana in ne odraža nujno dejanske življenjske dobe podatkov.
    ///
    ///   Zlasti v času te življenjske dobe pomnilnik, na katerega kaže kazalec, ne sme biti mutiran (razen znotraj `UnsafeCell`).
    ///
    /// To velja tudi, če je rezultat te metode neuporabljen!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // VARNOST: klicatelj mora zagotoviti, da `self` izpolnjuje vse zahteve
        // zahteve za referenco.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Izračuna odmik od kazalca.
    ///
    /// `count` je v enotah T;npr. `count` od 3 predstavlja odmik kazalca bajtov `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Če je kršen kateri od naslednjih pogojev, je rezultat nedefinirano vedenje:
    ///
    /// * Kazalec začetka in rezultata mora biti v mejah ali en bajt mimo konca istega dodeljenega predmeta.
    /// Upoštevajte, da se v Rust vsaka spremenljivka (stack-allocated) šteje za ločen dodeljeni objekt.
    ///
    /// * Izračunani odmik **v bajtih** ne more preseči `isize`.
    ///
    /// * Odmik v mejah se ne more zanašati na naslovni prostor "wrapping around".To pomeni, da mora biti vsota neskončne natančnosti **v bajtih** v velikosti.
    ///
    /// Prevajalnik in standardna knjižnica na splošno skušata zagotoviti, da dodelitve nikoli ne dosežejo velikosti, kjer je odmik zaskrbljujoč.
    /// Na primer `Vec` in `Box` zagotovita, da nikoli ne dodelita več kot `isize::MAX` bajtov, zato je `vec.as_ptr().add(vec.len())` vedno varen.
    ///
    /// Večina platform v osnovi niti ne more zgraditi take dodelitve.
    /// Na primer, nobena znana 64-bitna platforma nikoli ne more vročiti zahteve za 2 <sup>63</sup> bajta zaradi omejitev tabel strani ali delitve naslovnega prostora.
    /// Nekatere 32-bitne in 16-bitne platforme pa lahko uspešno strežejo zahtevo za več kot `isize::MAX` bajtov s stvarmi, kot je razširitev fizičnega naslova.
    ///
    /// Kot tak je pomnilnik, pridobljen neposredno iz razdeljevalcev ali pomnilniško preslikanih datotek *,* lahko prevelik, da bi ga lahko uporabljali s to funkcijo.
    ///
    /// Namesto tega razmislite o uporabi [`wrapping_offset`], če je te omejitve težko izpolniti.
    /// Edina prednost te metode je, da omogoča bolj agresivne optimizacije prevajalnikov.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `offset`.
        // Pridobljeni kazalnik velja za zapise, saj mora klicatelj zagotoviti, da kaže na isti dodeljeni objekt kot `self`.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// Izračuna odmik od kazalca z uporabo aritmetike zavijanja.
    /// `count` je v enotah T;npr. `count` od 3 predstavlja odmik kazalca bajtov `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Sama ta operacija je vedno varna, vendar uporaba nastalega kazalca ni.
    ///
    /// Nastali kazalec ostane pritrjen na isti dodeljeni objekt, na katerega kaže `self`.
    /// *Ne* se lahko uporablja za dostop do drugega dodeljenega predmeta.Upoštevajte, da se v Rust vsaka spremenljivka (stack-allocated) šteje za ločen dodeljeni objekt.
    ///
    /// Z drugimi besedami, `let z = x.wrapping_offset((y as isize) - (x as isize))`*ne* pomeni, da je `z` enak `y`, tudi če domnevamo, da ima `T` velikost `1` in da ni prelivanja: `z` je še vedno pritrjen na objekt, na katerega je pritrjen `x`, in preusmeritev v referenco je nedefinirano vedenje, razen če Točka `y` v isti dodeljeni objekt.
    ///
    /// V primerjavi z [`offset`] ta metoda v bistvu zamuja z zahtevo, da ostanemo znotraj istega dodeljenega predmeta: [`offset`] je takojšnje nedoločeno vedenje pri prečkanju meja objekta;`wrapping_offset` ustvari kazalec, vendar kljub temu pripelje do nedefiniranega vedenja, če je kazalec odštet, ko je zunaj predmeta, na katerega je pritrjen.
    /// [`offset`] je mogoče bolje optimizirati in je zato zaželena v kodi, ki je občutljiva na delovanje.
    ///
    /// Zakasnjeno preverjanje upošteva samo vrednost kazalca, ki je bil dereferenciran, ne pa tudi vmesnih vrednosti, uporabljenih med izračunom končnega rezultata.
    /// Na primer, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` je vedno enak kot `x`.Z drugimi besedami, dovoljeno je zapustiti dodeljeni objekt in ga nato znova vnesti.
    ///
    /// Če morate prečkati meje predmeta, postavite kazalnik na celo število in tam opravite aritmetiko.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// // Ponavljajte z uporabo surovega kazalca v korakih po dva elementa
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // VARNOST: `arith_offset` intrinsic nima predpogojev za klic.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// Vrne `None`, če je kazalec ničen, ali pa vrne enolični sklic na vrednost, ovito v `Some`.Če je vrednost morda neinicializirana, je treba namesto nje uporabiti [`as_uninit_mut`].
    ///
    /// Za primerjavo v skupni rabi glejte [`as_ref`].
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// Ko kličete to metodo, morate zagotoviti, da je *bodisi* kazalec NULL *bodisi* velja vse naslednje:
    ///
    /// * Kazalec mora biti pravilno poravnan.
    ///
    /// * To mora biti "dereferencable" v smislu, opredeljenem v [the module documentation].
    ///
    /// * Kazalec mora kazati na inicializiran primerek `T`.
    ///
    /// * Morate uveljaviti pravila vzdevanja Rust, saj je vrnjena življenjska doba `'a` poljubno izbrana in ne odraža nujno dejanske življenjske dobe podatkov.
    ///   Zlasti v času te življenjske dobe pomnilnik, na katerega kaže kazalec, ne sme imeti dostopa (branja ali zapisa) prek katerega koli drugega kazalca.
    ///
    /// To velja tudi, če je rezultat te metode neuporabljen!
    /// (Del o inicializaciji še ni popolnoma določen, vendar dokler ni, je edini varen pristop zagotoviti, da se resnično inicializirajo.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Natisnilo se bo: "[4, 2, 3]".
    /// ```
    ///
    /// # Nič nepreverjena različica
    ///
    /// Če ste prepričani, da kazalec nikoli ne more biti nič in iščete nekakšen `as_mut_unchecked`, ki vrne `&mut T` namesto `Option<&mut T>`, vedite, da lahko kazalec usmerite neposredno.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Natisnilo se bo: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // VARNOST: klicatelj mora zagotoviti, da `self` velja
        // spremenljiv sklic, če ni nič.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// Vrne `None`, če je kazalec ničen, ali pa vrne enolični sklic na vrednost, ovito v `Some`.
    /// V nasprotju z [`as_mut`] to ne zahteva, da je treba vrednost inicializirati.
    ///
    /// Za primerjavo v skupni rabi glejte [`as_uninit_ref`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// Ko kličete to metodo, morate zagotoviti, da je *bodisi* kazalec NULL *bodisi* velja vse naslednje:
    ///
    /// * Kazalec mora biti pravilno poravnan.
    ///
    /// * To mora biti "dereferencable" v smislu, opredeljenem v [the module documentation].
    ///
    /// * Morate uveljaviti pravila vzdevanja Rust, saj je vrnjena življenjska doba `'a` poljubno izbrana in ne odraža nujno dejanske življenjske dobe podatkov.
    ///
    ///   Zlasti v času te življenjske dobe pomnilnik, na katerega kaže kazalec, ne sme imeti dostopa (branja ali zapisa) prek katerega koli drugega kazalca.
    ///
    /// To velja tudi, če je rezultat te metode neuporabljen!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // VARNOST: klicatelj mora zagotoviti, da `self` izpolnjuje vse zahteve
        // zahteve za referenco.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// Vrne, ali sta dva kazalca zajamčena enaka.
    ///
    /// Med izvajanjem se ta funkcija obnaša kot `self == other`.
    /// Vendar v nekaterih kontekstih (npr. Vrednotenje časa prevajanja) ni vedno mogoče določiti enakosti dveh kazalcev, zato lahko ta funkcija lažno vrne `false` za kazalce, ki se kasneje dejansko izkažejo za enake.
    ///
    /// Ko pa vrne `true`, bodo kazalci zagotovo enaki.
    ///
    /// Ta funkcija je zrcalo [`guaranteed_ne`], ne pa tudi obratno.Obstajajo primerjave kazalcev, pri katerih obe funkciji vrneta `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Vrnjena vrednost se lahko spremeni glede na različico prevajalnika in nevarna koda se morda ne zanaša na rezultat te funkcije glede trdnosti.
    /// Priporočljivo je, da to funkcijo uporabljate le za optimizacijo zmogljivosti, kadar napačne vrnjene vrednosti `false` s to funkcijo ne vplivajo na rezultat, ampak samo na zmogljivost.
    /// Posledice uporabe te metode za drugačno obnašanje izvajalne kode in kode prevajanja niso bile raziskane.
    /// Te metode ne bi smeli uporabljati za uvajanje takšnih razlik in je tudi ne bi smeli stabilizirati, preden bomo bolje razumeli to težavo.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// Vrne, ali sta dva kazalca zagotovo neenaka.
    ///
    /// Med izvajanjem se ta funkcija obnaša kot `self != other`.
    /// Vendar v nekaterih kontekstih (npr. Ocena časa prevajanja) ni vedno mogoče ugotoviti neenakosti dveh kazalcev, zato lahko ta funkcija lažno vrne `false` za kazalce, ki se kasneje dejansko izkažejo za neenake.
    ///
    /// Ko pa vrne `true`, bodo kazalci zagotovo neenaki.
    ///
    /// Ta funkcija je zrcalo [`guaranteed_eq`], ne pa tudi obratno.Obstajajo primerjave kazalcev, pri katerih obe funkciji vrneta `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Vrnjena vrednost se lahko spremeni glede na različico prevajalnika in nevarna koda se morda ne zanaša na rezultat te funkcije glede trdnosti.
    /// Priporočljivo je, da to funkcijo uporabljate le za optimizacijo zmogljivosti, kadar napačne vrnjene vrednosti `false` s to funkcijo ne vplivajo na rezultat, ampak samo na zmogljivost.
    /// Posledice uporabe te metode za drugačno obnašanje izvajalne kode in kode prevajanja niso bile raziskane.
    /// Te metode ne bi smeli uporabljati za uvajanje takšnih razlik in je tudi ne bi smeli stabilizirati, preden bomo bolje razumeli to težavo.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// Izračuna razdaljo med kazalcema.Vrnjena vrednost je v enotah T: razdalja v bajtih je deljena z `mem::size_of::<T>()`.
    ///
    /// Ta funkcija je inverzna vrednost [`offset`].
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// Če je kršen kateri od naslednjih pogojev, je rezultat nedefinirano vedenje:
    ///
    /// * Tako začetni kot drugi kazalnik morata biti v mejah ali en bajt mimo konca istega dodeljenega predmeta.
    /// Upoštevajte, da se v Rust vsaka spremenljivka (stack-allocated) šteje za ločen dodeljeni objekt.
    ///
    /// * Oba kazalca morata biti *izpeljana iz* kazalca na isti predmet.
    ///   (Primer glejte spodaj.)
    ///
    /// * Razdalja med kazalci v bajtih mora biti natančno večkratnik velikosti `T`.
    ///
    /// * Razdalja med kazalci,**v bajtih**, ne more preseči `isize`.
    ///
    /// * Razdalja v mejah se ne more zanesti na naslovni prostor "wrapping around".
    ///
    /// Vrste Rust niso nikoli večje od `isize::MAX`, dodelitve Rust pa se nikoli ne zavijejo okoli naslovnega prostora, zato dva kazalca znotraj neke vrednosti katerega koli tipa Rust tipa `T` vedno izpolnjujeta zadnja dva pogoja.
    ///
    /// Standardna knjižnica tudi na splošno zagotavlja, da dodelitve nikoli ne dosežejo velikosti, pri kateri je odmik zaskrbljujoč.
    /// Na primer `Vec` in `Box` zagotovita, da nikoli ne dodelita več kot `isize::MAX` bajtov, zato `ptr_into_vec.offset_from(vec.as_ptr())` vedno izpolnjuje zadnja dva pogoja.
    ///
    /// Večina platform v osnovi niti ne more zgraditi tako velike dodelitve.
    /// Na primer, nobena znana 64-bitna platforma nikoli ne more vročiti zahteve za 2 <sup>63</sup> bajta zaradi omejitev tabel strani ali delitve naslovnega prostora.
    /// Nekatere 32-bitne in 16-bitne platforme pa lahko uspešno strežejo zahtevo za več kot `isize::MAX` bajtov s stvarmi, kot je razširitev fizičnega naslova.
    /// Kot tak je pomnilnik, pridobljen neposredno iz razdeljevalcev ali pomnilniško preslikanih datotek *,* lahko prevelik, da bi ga lahko uporabljali s to funkcijo.
    /// (Upoštevajte, da imata [`offset`] in [`add`] tudi podobno omejitev, zato ju ni mogoče uporabiti tudi pri tako velikih dodelitvah.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Ta funkcija panics, če je `T` ničelnega tipa ("ZST").
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Nepravilna* uporaba:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Naj ptr2_other postane "alias" od ptr2, vendar izpeljan iz ptr1.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Ker ptr2_other in ptr2 izhajata iz kazalcev na različne predmete, je računanje njihovega odmika nedefinirano, čeprav kažeta na isti naslov!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Nedoločeno vedenje
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `offset_from`.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Izračuna odmik od kazalca (priročnost za `.offset(count as isize)`).
    ///
    /// `count` je v enotah T;npr. `count` od 3 predstavlja odmik kazalca bajtov `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Če je kršen kateri od naslednjih pogojev, je rezultat nedefinirano vedenje:
    ///
    /// * Kazalec začetka in rezultata mora biti v mejah ali en bajt mimo konca istega dodeljenega predmeta.
    /// Upoštevajte, da se v Rust vsaka spremenljivka (stack-allocated) šteje za ločen dodeljeni objekt.
    ///
    /// * Izračunani odmik **v bajtih** ne more preseči `isize`.
    ///
    /// * Odmik v mejah se ne more zanašati na naslovni prostor "wrapping around".To pomeni, da mora biti vsota neskončne natančnosti vgrajena v `usize`.
    ///
    /// Prevajalnik in standardna knjižnica na splošno skušata zagotoviti, da dodelitve nikoli ne dosežejo velikosti, kjer je odmik zaskrbljujoč.
    /// Na primer `Vec` in `Box` zagotovita, da nikoli ne dodelita več kot `isize::MAX` bajtov, zato je `vec.as_ptr().add(vec.len())` vedno varen.
    ///
    /// Večina platform v osnovi niti ne more zgraditi take dodelitve.
    /// Na primer, nobena znana 64-bitna platforma nikoli ne more vročiti zahteve za 2 <sup>63</sup> bajta zaradi omejitev tabel strani ali delitve naslovnega prostora.
    /// Nekatere 32-bitne in 16-bitne platforme pa lahko uspešno strežejo zahtevo za več kot `isize::MAX` bajtov s stvarmi, kot je razširitev fizičnega naslova.
    ///
    /// Kot tak je pomnilnik, pridobljen neposredno iz razdeljevalcev ali pomnilniško preslikanih datotek *,* lahko prevelik, da bi ga lahko uporabljali s to funkcijo.
    ///
    /// Namesto tega razmislite o uporabi [`wrapping_add`], če je te omejitve težko izpolniti.
    /// Edina prednost te metode je, da omogoča bolj agresivne optimizacije prevajalnikov.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Izračuna odmik iz kazalca (priročnost za `.offset ((šteje kot isize).wrapping_neg())`).
    ///
    /// `count` je v enotah T;npr. `count` od 3 predstavlja odmik kazalca bajtov `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Če je kršen kateri od naslednjih pogojev, je rezultat nedefinirano vedenje:
    ///
    /// * Kazalec začetka in rezultata mora biti v mejah ali en bajt mimo konca istega dodeljenega predmeta.
    /// Upoštevajte, da se v Rust vsaka spremenljivka (stack-allocated) šteje za ločen dodeljeni objekt.
    ///
    /// * Izračunani odmik ne sme presegati `isize::MAX`**bajtov**.
    ///
    /// * Odmik v mejah se ne more zanašati na naslovni prostor "wrapping around".To pomeni, da mora biti vsota neskončne natančnosti v velikosti.
    ///
    /// Prevajalnik in standardna knjižnica na splošno skušata zagotoviti, da dodelitve nikoli ne dosežejo velikosti, kjer je odmik zaskrbljujoč.
    /// Na primer `Vec` in `Box` zagotovita, da nikoli ne dodelita več kot `isize::MAX` bajtov, zato je `vec.as_ptr().add(vec.len()).sub(vec.len())` vedno varen.
    ///
    /// Večina platform v osnovi niti ne more zgraditi take dodelitve.
    /// Na primer, nobena znana 64-bitna platforma nikoli ne more vročiti zahteve za 2 <sup>63</sup> bajta zaradi omejitev tabel strani ali delitve naslovnega prostora.
    /// Nekatere 32-bitne in 16-bitne platforme pa lahko uspešno strežejo zahtevo za več kot `isize::MAX` bajtov s stvarmi, kot je razširitev fizičnega naslova.
    ///
    /// Kot tak je pomnilnik, pridobljen neposredno iz razdeljevalcev ali pomnilniško preslikanih datotek *,* lahko prevelik, da bi ga lahko uporabljali s to funkcijo.
    ///
    /// Namesto tega razmislite o uporabi [`wrapping_sub`], če je te omejitve težko izpolniti.
    /// Edina prednost te metode je, da omogoča bolj agresivne optimizacije prevajalnikov.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Izračuna odmik od kazalca z uporabo aritmetike zavijanja.
    /// (priročnost za `.wrapping_offset(count as isize)`)
    ///
    /// `count` je v enotah T;npr. `count` od 3 predstavlja odmik kazalca bajtov `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Sama ta operacija je vedno varna, vendar uporaba nastalega kazalca ni.
    ///
    /// Nastali kazalec ostane pritrjen na isti dodeljeni objekt, na katerega kaže `self`.
    /// *Ne* se lahko uporablja za dostop do drugega dodeljenega predmeta.Upoštevajte, da se v Rust vsaka spremenljivka (stack-allocated) šteje za ločen dodeljeni objekt.
    ///
    /// Z drugimi besedami, `let z = x.wrapping_add((y as usize) - (x as usize))`*ne* pomeni, da je `z` enak `y`, tudi če domnevamo, da ima `T` velikost `1` in da ni prelivanja: `z` je še vedno pritrjen na objekt, na katerega je pritrjen `x`, in preusmeritev v to je nedefinirano vedenje, razen če `x` in Točka `y` v isti dodeljeni objekt.
    ///
    /// V primerjavi z [`add`] ta metoda v bistvu zamuja z zahtevo, da ostanemo znotraj istega dodeljenega predmeta: [`add`] je takojšnje nedoločeno vedenje pri prečkanju meja objekta;`wrapping_add` ustvari kazalec, vendar kljub temu pripelje do nedefiniranega vedenja, če je kazalec odštet, ko je zunaj predmeta, na katerega je pritrjen.
    /// [`add`] je mogoče bolje optimizirati in je zato zaželena v kodi, ki je občutljiva na delovanje.
    ///
    /// Zakasnjeno preverjanje upošteva samo vrednost kazalca, ki je bil dereferenciran, ne pa tudi vmesnih vrednosti, uporabljenih med izračunom končnega rezultata.
    /// Na primer, `x.wrapping_add(o).wrapping_sub(o)` je vedno enak kot `x`.Z drugimi besedami, dovoljeno je zapustiti dodeljeni objekt in ga nato znova vnesti.
    ///
    /// Če morate prečkati meje predmeta, postavite kazalnik na celo število in tam opravite aritmetiko.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// // Ponavljajte z uporabo surovega kazalca v korakih po dva elementa
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Ta zanka natisne "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Izračuna odmik od kazalca z uporabo aritmetike zavijanja.
    /// (priročnost za `.wrapping_offset ((šteje kot isize).wrapping_neg())`)
    ///
    /// `count` je v enotah T;npr. `count` od 3 predstavlja odmik kazalca bajtov `3 * size_of::<T>()`.
    ///
    /// # Safety
    ///
    /// Sama ta operacija je vedno varna, vendar uporaba nastalega kazalca ni.
    ///
    /// Nastali kazalec ostane pritrjen na isti dodeljeni objekt, na katerega kaže `self`.
    /// *Ne* se lahko uporablja za dostop do drugega dodeljenega predmeta.Upoštevajte, da se v Rust vsaka spremenljivka (stack-allocated) šteje za ločen dodeljeni objekt.
    ///
    /// Z drugimi besedami, `let z = x.wrapping_sub((x as usize) - (y as usize))`*ne* pomeni, da je `z` enak `y`, tudi če domnevamo, da ima `T` velikost `1` in da ni prelivanja: `z` je še vedno pritrjen na objekt, na katerega je pritrjen `x`, in preusmeritev v to je nedefinirano vedenje, razen če `x` in Točka `y` v isti dodeljeni objekt.
    ///
    /// V primerjavi z [`sub`] ta metoda v bistvu zamuja z zahtevo, da ostanemo znotraj istega dodeljenega predmeta: [`sub`] je takojšnje nedoločeno vedenje pri prečkanju meja objekta;`wrapping_sub` ustvari kazalec, vendar kljub temu pripelje do nedefiniranega vedenja, če je kazalec odštet, ko je zunaj predmeta, na katerega je pritrjen.
    /// [`sub`] je mogoče bolje optimizirati in je zato zaželena v kodi, ki je občutljiva na delovanje.
    ///
    /// Zakasnjeno preverjanje upošteva samo vrednost kazalca, ki je bil dereferenciran, ne pa tudi vmesnih vrednosti, uporabljenih med izračunom končnega rezultata.
    /// Na primer, `x.wrapping_add(o).wrapping_sub(o)` je vedno enak kot `x`.Z drugimi besedami, dovoljeno je zapustiti dodeljeni objekt in ga nato znova vnesti.
    ///
    /// Če morate prečkati meje predmeta, postavite kazalnik na celo število in tam opravite aritmetiko.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// // Ponavljajte z uporabo surovega kazalca v korakih po dva elementa (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Ta zanka natisne "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Nastavi vrednost kazalca na `ptr`.
    ///
    /// Če je `self` kazalec (fat) na nevelik tip, bo ta operacija vplivala samo na kazalec, medtem ko ima kazalci (thin) na velike tipe enak učinek kot preprosta dodelitev.
    ///
    /// Nastali kazalec bo imel izvor `val`, tj. Za kazalec maščobe je ta operacija pomensko enaka ustvarjanju novega kazalca maščobe z vrednostjo podatkovnega kazalca `val`, vendar z metapodatki `self`.
    ///
    ///
    /// # Examples
    ///
    /// Ta funkcija je uporabna predvsem za omogočanje bajtne aritmetike kazalca na potencialno kazalcih maščob:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // bo natisnil "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // VARNOST: V primeru tankega kazalca je ta postopek enak
        // na preprosto nalogo.
        // V primeru kazalca maščobe je pri trenutni izvedbi postavitve kazalca maščobe prvo polje takega kazalca vedno podatkovni kazalec, ki je prav tako dodeljen.
        //
        unsafe { *thin = val };
        self
    }

    /// Prebere vrednost iz `self`, ne da bi jo premaknil.
    /// Tako ostane pomnilnik v `self` nespremenjen.
    ///
    /// Za varnostna vprašanja in primere glejte [`ptr::read`].
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo za ``.
        unsafe { read(self) }
    }

    /// Izvede nihajno branje vrednosti iz `self`, ne da bi ga premaknil.Tako ostane pomnilnik v `self` nespremenjen.
    ///
    /// Hlapne operacije naj bi delovale na pomnilniku I/O in jih prevajalnik zagotovo ne bo izbrisal ali prerazporedil pri drugih hlapljivih operacijah.
    ///
    ///
    /// Za varnostna vprašanja in primere glejte [`ptr::read_volatile`].
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Prebere vrednost iz `self`, ne da bi jo premaknil.
    /// Tako ostane pomnilnik v `self` nespremenjen.
    ///
    /// Za razliko od `read` kazalec morda ni poravnan.
    ///
    /// Za varnostna vprašanja in primere glejte [`ptr::read_unaligned`].
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Kopira bajte `count * size_of<T>` od `self` do `dest`.
    /// Vir in cilj se lahko prekrivata.
    ///
    /// NOTE: ta ima *enak* vrstni red argumentov kot [`ptr::copy`].
    ///
    /// Za varnostna vprašanja in primere glejte [`ptr::copy`].
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Kopira bajte `count * size_of<T>` od `self` do `dest`.
    /// Vir in cilj se lahko *ne* prekrivata.
    ///
    /// NOTE: ta ima *enak* vrstni red argumentov kot [`ptr::copy_nonoverlapping`].
    ///
    /// Za varnostna vprašanja in primere glejte [`ptr::copy_nonoverlapping`].
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Kopira bajte `count * size_of<T>` od `src` do `self`.
    /// Vir in cilj se lahko prekrivata.
    ///
    /// NOTE: ta ima *nasprotni* vrstni red argumentov [`ptr::copy`].
    ///
    /// Za varnostna vprašanja in primere glejte [`ptr::copy`].
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `copy`.
        unsafe { copy(src, self, count) }
    }

    /// Kopira bajte `count * size_of<T>` od `src` do `self`.
    /// Vir in cilj se lahko *ne* prekrivata.
    ///
    /// NOTE: ta ima *nasprotni* vrstni red argumentov [`ptr::copy_nonoverlapping`].
    ///
    /// Za varnostna vprašanja in primere glejte [`ptr::copy_nonoverlapping`].
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// Izvede destruktor (če obstaja) usmerjene vrednosti.
    ///
    /// Za varnostna vprašanja in primere glejte [`ptr::drop_in_place`].
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `drop_in_place`.
        unsafe { drop_in_place(self) }
    }

    /// Prepiše pomnilniško mesto z dano vrednostjo, ne da bi prebral ali spustil staro vrednost.
    ///
    ///
    /// Za varnostna vprašanja in primere glejte [`ptr::write`].
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `write`.
        unsafe { write(self, val) }
    }

    /// Prikliče memset na določeni kazalec, nastavi `count * size_of::<T>()` bajtov pomnilnika, ki se začnejo od `self` do `val`.
    ///
    ///
    /// Za varnostna vprašanja in primere glejte [`ptr::write_bytes`].
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `write_bytes`.
        unsafe { write_bytes(self, val, count) }
    }

    /// Izvede hlapljivo zapisovanje lokacije pomnilnika z dano vrednostjo, ne da bi prebralo ali spustilo staro vrednost.
    ///
    /// Hlapne operacije naj bi delovale na pomnilniku I/O in jih prevajalnik zagotovo ne bo izbrisal ali prerazporedil pri drugih hlapljivih operacijah.
    ///
    ///
    /// Za varnostna vprašanja in primere glejte [`ptr::write_volatile`].
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `write_volatile`.
        unsafe { write_volatile(self, val) }
    }

    /// Prepiše pomnilniško mesto z dano vrednostjo, ne da bi prebral ali spustil staro vrednost.
    ///
    ///
    /// Za razliko od `write` kazalec morda ni poravnan.
    ///
    /// Za varnostna vprašanja in primere glejte [`ptr::write_unaligned`].
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `write_unaligned`.
        unsafe { write_unaligned(self, val) }
    }

    /// Vrednost v `self` nadomesti z `src`, pri čemer vrne staro vrednost, ne da bi pri tem spustil.
    ///
    ///
    /// Za varnostna vprašanja in primere glejte [`ptr::replace`].
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `replace`.
        unsafe { replace(self, src) }
    }

    /// Vrednosti zamenja na dveh spremenljivih mestih istega tipa, ne da bi jih bilo treba tudi deinializirati.
    /// Za razliko od `mem::swap`, ki je sicer enakovreden, se lahko prekrivajo.
    ///
    /// Za varnostna vprašanja in primere glejte [`ptr::swap`].
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `swap`.
        unsafe { swap(self, with) }
    }

    /// Izračuna odmik, ki ga je treba uporabiti za kazalec, da se poravna na `align`.
    ///
    /// Če kazalca ni mogoče poravnati, izvedba vrne `usize::MAX`.
    /// Dovoljeno je, da izvedba *vedno* vrne `usize::MAX`.
    /// Samo uspešnost vašega algoritma je lahko odvisna od tega, kako dobite uporaben odmik, ne pa tudi od njegove pravilnosti.
    ///
    /// Odmik je izražen v številu elementov `T` in ne v bajtih.Vrnjena vrednost se lahko uporabi z metodo `wrapping_add`.
    ///
    /// Nobenega zagotovila ni, da se odmik kazalca ne bo prelival ali presegel dodelitve, na katero kaže kazalec.
    ///
    /// Klicatelj mora zagotoviti, da je vrnjeni odmik pravilen v vseh pogojih, razen v poravnavi.
    ///
    /// # Panics
    ///
    /// Funkcija panics, če `align` ni moč dveh.
    ///
    /// # Examples
    ///
    /// Dostop do sosednjega `u8` kot `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // medtem ko je kazalec mogoče poravnati prek `offset`, bi kazal zunaj dodelitve
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // VARNOST: Zgoraj je bilo preverjeno, da ima `align` moč 2
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// Vrne dolžino surove rezine.
    ///
    /// Vrnjena vrednost je število **elementov**, ne število bajtov.
    ///
    /// Ta funkcija je varna, tudi če surove rezine ni mogoče oddati na sklic na rezino, ker je kazalec ničen ali neuravnan.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // VARNOST: to je varno, ker imata `*const [T]` in `FatPtr<T>` enako postavitev.
            // To garancijo lahko da samo `std`.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Vrne neobdelani kazalnik na medpomnilnik rezine.
    ///
    /// To je enakovredno oddajanju `self` do `*mut T`, vendar bolj varno za tip.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// Vrne neobdelani kazalnik na element ali podrezo, ne da bi preverjal meje.
    ///
    /// Klicanje te metode z indeksom zunaj meja ali kadar `self` ni mogoče preusmeriti, je *[nedefinirano vedenje]*, tudi če uporabljeni kazalnik ni uporabljen.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // VARNOST: klicatelj zagotavlja, da `self` ni mogoče referencirati in da je `index` znotraj.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// Vrne `None`, če je kazalec ničen, ali pa vrne deljeno rezino na vrednost, ovito v `Some`.
    /// V nasprotju z [`as_ref`] to ne zahteva, da je treba vrednost inicializirati.
    ///
    /// Za spremenljiv primer glej [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Ko kličete to metodo, morate zagotoviti, da je *bodisi* kazalec NULL *bodisi* velja vse naslednje:
    ///
    /// * Kazalec mora biti [valid] za branje za veliko število bajtov `ptr.len() * mem::size_of::<T>()` in mora biti pravilno poravnan.To zlasti pomeni:
    ///
    ///     * Celoten obseg pomnilnika te rezine mora biti v enem dodeljenem objektu!
    ///       Rezine nikoli ne morejo obsegati več dodeljenih predmetov.
    ///
    ///     * Kazalec mora biti poravnan tudi za rezine ničelne dolžine.
    ///     Eden od razlogov za to je, da se lahko optimizacije postavitve naštevanja sklicujejo na poravnave referenc (vključno z rezinami katere koli dolžine) in njihovo nično, da jih ločijo od drugih podatkov.
    ///
    ///     S pomočjo [`NonNull::dangling()`] lahko dobite kazalec, ki je uporaben kot `data` za rezine ničelne dolžine.
    ///
    /// * Skupna velikost rezine `ptr.len() * mem::size_of::<T>()` ne sme biti večja od `isize::MAX`.
    ///   Glejte varnostno dokumentacijo [`pointer::offset`].
    ///
    /// * Morate uveljaviti pravila vzdevanja Rust, saj je vrnjena življenjska doba `'a` poljubno izbrana in ne odraža nujno dejanske življenjske dobe podatkov.
    ///   Zlasti v času te življenjske dobe pomnilnik, na katerega kaže kazalec, ne sme biti mutiran (razen znotraj `UnsafeCell`).
    ///
    /// To velja tudi, če je rezultat te metode neuporabljen!
    ///
    /// Glej tudi [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// Vrne `None`, če je kazalec ničen, ali pa vrne unikatno rezino na vrednost, ovito v `Some`.
    /// V nasprotju z [`as_mut`] to ne zahteva, da je treba vrednost inicializirati.
    ///
    /// Za primerjavo v skupni rabi glejte [`as_uninit_slice`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// Ko kličete to metodo, morate zagotoviti, da je *bodisi* kazalec NULL *bodisi* velja vse naslednje:
    ///
    /// * Kazalec mora biti [valid] za branje in zapisovanje za veliko bajtov `ptr.len() * mem::size_of::<T>()` in mora biti pravilno poravnan.To zlasti pomeni:
    ///
    ///     * Celoten obseg pomnilnika te rezine mora biti v enem dodeljenem objektu!
    ///       Rezine nikoli ne morejo obsegati več dodeljenih predmetov.
    ///
    ///     * Kazalec mora biti poravnan tudi za rezine ničelne dolžine.
    ///     Eden od razlogov za to je, da se lahko optimizacije postavitve naštevanja sklicujejo na poravnave referenc (vključno z rezinami katere koli dolžine) in njihovo nično, da jih ločijo od drugih podatkov.
    ///
    ///     S pomočjo [`NonNull::dangling()`] lahko dobite kazalec, ki je uporaben kot `data` za rezine ničelne dolžine.
    ///
    /// * Skupna velikost rezine `ptr.len() * mem::size_of::<T>()` ne sme biti večja od `isize::MAX`.
    ///   Glejte varnostno dokumentacijo [`pointer::offset`].
    ///
    /// * Morate uveljaviti pravila vzdevanja Rust, saj je vrnjena življenjska doba `'a` poljubno izbrana in ne odraža nujno dejanske življenjske dobe podatkov.
    ///   Zlasti v času te življenjske dobe pomnilnik, na katerega kaže kazalec, ne sme imeti dostopa (branja ali zapisa) prek katerega koli drugega kazalca.
    ///
    /// To velja tudi, če je rezultat te metode neuporabljen!
    ///
    /// Glej tudi [`slice::from_raw_parts_mut`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `as_uninit_slice_mut`.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Enakost za kazalce
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}