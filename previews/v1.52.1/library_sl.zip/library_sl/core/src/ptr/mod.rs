//! Ročno upravljajte s pomnilnikom prek surovih kazalcev.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Številne funkcije v tem modulu jemljejo surove kazalce kot argumente in jih berejo ali pišejo nanje.Da bo to varno, morajo biti ti kazalci *veljavni*.
//! Ali je kazalec veljaven, je odvisno od operacije, za katero se uporablja (branje ali pisanje), in obsega dostopa do pomnilnika (tj. Koliko bajtov je read/written).
//! Večina funkcij uporablja `*mut T` in `* const T` za dostop samo do ene vrednosti, v tem primeru dokumentacija izpusti velikost in implicitno predpostavlja, da gre za bajte `size_of::<T>()`.
//!
//! Natančna pravila za veljavnost še niso določena.Jamstva, ki so na tej točki zagotovljena, so zelo minimalna:
//!
//! * Kazalec [null] ni *nikoli* veljaven, niti za dostope do [size zero][zst].
//! * Da je kazalec veljaven, je potrebno, vendar ne vedno dovolj, da je kazalec lahko *neoporečen*: obseg pomnilnika dane velikosti, ki se začne pri kazalcu, mora biti v mejah enega dodeljenega predmeta.
//!
//! Upoštevajte, da se v Rust vsaka spremenljivka (stack-allocated) šteje za ločen dodeljeni objekt.
//! * Tudi pri operacijah [size zero][zst] kazalec ne sme kazati na razveljavljeni pomnilnik, tj. Razveljavitev povzroči, da kazalci postanejo neveljavni tudi za operacije brez velikosti.
//! Vendar pa oddajanje poljubnega celoštevilčnega *literala* v kazalec velja za dostope ničelne velikosti, tudi če na tem naslovu obstaja nekaj pomnilnika in se sprosti.
//! To ustreza pisanju lastnega razdeljevalca: dodeljevanje nič velikih predmetov ni zelo težko.
//! Kanonični način za pridobitev kazalca, ki velja za dostope ničelne velikosti, je [`NonNull::dangling`].
//! * Vsi dostopi, ki jih izvajajo funkcije v tem modulu, so *neatomski* v smislu [atomic operations], ki se uporabljajo za sinhronizacijo med nitmi.
//! To pomeni, da je nedoločeno vedenje izvajati dva sočasna dostopa do iste lokacije iz različnih niti, razen če oba dostopa bereta samo iz pomnilnika.
//! Upoštevajte, da to izrecno vključuje [`read_volatile`] in [`write_volatile`]: Hlapnih dostopov ni mogoče uporabiti za sinhronizacijo med nitmi.
//! * Rezultat oddajanja sklica na kazalec je veljaven, dokler je osnovni objekt v živo in se za dostop do istega pomnilnika ne uporablja noben sklic (samo surovi kazalci).
//!
//! Ti aksiomi, skupaj s skrbno uporabo [`offset`] za aritmetiko kazalcev, zadoščajo za pravilno izvedbo številnih uporabnih stvari v nevarni kodi.
//! Sčasoma bodo zagotovljena močnejša jamstva, saj se določajo pravila [aliasing].
//! Za več informacij glejte [book] in razdelek v referenci, posvečeni [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Veljavni surovi kazalci, kot so definirani zgoraj, niso nujno pravilno poravnani (pri čemer je poravnava "proper" določena s tipom kazalca, tj. `*const T` mora biti poravnana z `mem::align_of::<T>()`).
//! Vendar večina funkcij zahteva, da so njihovi argumenti pravilno poravnani in bodo to zahtevo izrecno navedli v svoji dokumentaciji.
//! Izjemne izjeme so [`read_unaligned`] in [`write_unaligned`].
//!
//! Kadar funkcija zahteva pravilno poravnavo, to stori tudi, če ima dostop velikost 0, tj. Tudi če se pomnilnik dejansko ne dotakne.V takih primerih razmislite o uporabi [`NonNull::dangling`].
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Izvede destruktor (če obstaja) usmerjene vrednosti.
///
/// To je semantično enakovredno klicanju [`ptr::read`] in zavrženju rezultata, vendar ima naslednje prednosti:
///
/// * * Za uporabo `drop_in_place` je potrebno, da spustite nevelike vrste, kot so predmeti Portrait, ker jih ni mogoče prebrati na sklad in jih normalno spustiti.
///
/// * Optimizatorju je prijazneje, če to stori prek [`ptr::read`], ko spušča ročno dodeljeni pomnilnik (npr. Pri izvedbah `Box`/`Rc`/`Vec`), saj prevajalniku ni treba dokazati, da kopija izbriše.
///
///
/// * Z njim lahko spustite podatke [pinned], kadar `T` ni `repr(packed)` (pripetih podatkov ne smete premakniti, preden jih spustite).
///
/// Neskladnih vrednosti ni mogoče spustiti na svoje mesto, najprej jih je treba kopirati na poravnano mesto s pomočjo [`ptr::read_unaligned`].Za zapakirane strukture ta prehod samodejno izvede prevajalnik.
/// To pomeni, da polja zapakiranih struktur ne padejo na svoje mesto.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Vedenje ni določeno, če je kršen kateri od naslednjih pogojev:
///
/// * `to_drop` mora biti [valid] za branje in pisanje.
///
/// * `to_drop` mora biti pravilno poravnana.
///
/// * Vrednost, na katero kaže `to_drop`, mora biti veljavna za spuščanje, kar lahko pomeni, da mora ohraniti dodatne invariante, kar je odvisno od tipa.
///
/// Če `T` ni [`Copy`], lahko uporaba usmerjene vrednosti po klicu `drop_in_place` povzroči nedefinirano vedenje.Upoštevajte, da `*to_drop = foo` šteje kot uporaba, ker bo povzročila, da bo vrednost spet padla.
/// [`write()`] se lahko uporablja za prepisovanje podatkov, ne da bi jih povzročili.
///
/// Tudi če ima `T` velikost `0`, mora kazalec biti NULL in pravilno poravnan.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Ročno odstranite zadnji element iz vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Pridobite neobdelan kazalec na zadnji element v `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Skrajšajte `v`, da preprečite spuščanje zadnjega predmeta.
///     // To naredimo najprej, da preprečimo težave, če je `drop_in_place` pod panics.
///     v.set_len(1);
///     // Brez klica `drop_in_place` zadnjega elementa nikoli ne bi spustili in pomnilnik, ki ga upravlja, bi uhajal.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Prepričajte se, da je bil zadnji element odstranjen.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Upoštevajte, da prevajalnik samodejno izvede to kopijo, ko spusti zapakirane strukture, tj. Običajno vam ni treba skrbeti za takšne težave, razen če `drop_in_place` pokličete ročno.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Koda tukaj ni pomembna, to prevajalnik nadomesti s pravim kapljičnim lepilom.
    //

    // VARNOST: glej komentar zgoraj
    unsafe { drop_in_place(to_drop) }
}

/// Ustvari ničelni surovi kazalec.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Ustvari ničelno spremenljiv surov kazalec.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Potreben je ročni impl, da se izognete vezavi na `T: Clone`.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Potreben je ročni impl, da se izognete vezavi na `T: Copy`.
impl<T> Copy for FatPtr<T> {}

/// Oblikuje surovo rezino iz kazalca in dolžine.
///
/// Argument `len` je število **elementov**, ne število bajtov.
///
/// Ta funkcija je varna, vendar uporaba povratne vrednosti ni varna.
/// Za varnostne zahteve glede rezin glejte dokumentacijo [`slice::from_raw_parts`].
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // ustvari kazalec rezine, ko začneš s kazalcem na prvi element
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // VARNOST: Dostop do vrednosti iz zveze `Repr` je varen, saj * const [T]
        //
        // in FatPtr imata enake postavitve pomnilnika.To garancijo lahko da samo std.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Izvaja enako funkcionalnost kot [`slice_from_raw_parts`], le da se vrne neobdelana spremenljiva rezina, v nasprotju s surovo nespremenljivo rezino.
///
///
/// Za več podrobnosti glejte dokumentacijo [`slice_from_raw_parts`].
///
/// Ta funkcija je varna, vendar uporaba povratne vrednosti ni varna.
/// Za varnostne zahteve glede rezin glejte dokumentacijo [`slice::from_raw_parts_mut`].
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // dodeli vrednost indeksu v rezini
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // VARNOST: Dostop do vrednosti iz zveze `Repr` je varen, saj * mut [T]
        // in FatPtr imata enake postavitve pomnilnika
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Vrednosti zamenja na dveh spremenljivih mestih istega tipa, ne da bi jih bilo treba tudi deinializirati.
///
/// Toda za naslednji dve izjemi je ta funkcija pomensko enakovredna [`mem::swap`]:
///
///
/// * Namesto referenc deluje na surove kazalce.
/// Ko so na voljo reference, je treba dati prednost [`mem::swap`].
///
/// * Obe usmerjeni vrednosti se lahko prekrivata.
/// Če se vrednosti prekrivajo, bo uporabljeno prekrivajoče se območje pomnilnika iz `x`.
/// To je prikazano v drugem primeru spodaj.
///
/// # Safety
///
/// Vedenje ni določeno, če je kršen kateri od naslednjih pogojev:
///
/// * Tako `x` kot `y` morata biti [valid] za branje in pisanje.
///
/// * Tako `x` kot `y` morata biti pravilno poravnana.
///
/// Upoštevajte, da tudi če ima `T` velikost `0`, kazalci ne smejo biti NULL in pravilno poravnani.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Zamenjava dveh neprekrivajočih se regij:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // to je `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // to je `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Zamenjava dveh prekrivajočih se regij:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // to je `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // to je `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Indeksi `1..3` rezine se prekrivajo med `x` in `y`.
///     // Primerni rezultati bi bili zanje `[2, 3]`, tako da so indeksi `0..3` `[1, 2, 3]` (ujemajo se z `y` pred `swap`);ali naj bodo `[0, 1]`, tako da so indeksi `1..4` `[0, 1, 2]` (ujemajo se z `x` pred `swap`).
/////
///     // Ta izvedba je opredeljena tako, da se odloči za slednjo.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Dajte si nekaj prostora za praske.
    // Ni nam treba skrbeti za padce: `MaybeUninit` ob padcu nič ne naredi.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Izvedite zamenjavo VARNOST: klicatelj mora zagotoviti, da sta `x` in `y` veljavni za pisanje in pravilno poravnani.
    // `tmp` ne moreta prekrivati niti `x` niti `y`, ker je bil `tmp` pravkar dodeljen v sklad kot ločen dodeljeni objekt.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` in `y` se lahko prekrivata
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Menjava bajtov `count * size_of::<T>()` med obema regijama pomnilnika, ki se začneta pri `x` in `y`.
/// Obe regiji se ne smeta * prekrivati.
///
/// # Safety
///
/// Vedenje ni določeno, če je kršen kateri od naslednjih pogojev:
///
/// * Tako `x` kot `y` morata biti [valid] za branje in zapisovanje štetja `count *
///   velikost_: :<T>() `bajtov.
///
/// * Tako `x` kot `y` morata biti pravilno poravnana.
///
/// * Območje pomnilnika, ki se začne pri `x`, z velikostjo `count *
///   velikost_: :<T>() `bajti se ne smejo * prekrivati z območjem pomnilnika, ki se začne pri `y` z enako velikostjo.
///
/// Upoštevajte, da tudi če je dejansko kopirana velikost (`count * size_of: :<T>()`) je `0`, kazalci ne smejo biti NULL in pravilno poravnani.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Osnovna uporaba:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // VARNOST: klicatelj mora zagotoviti, da sta `x` in `y`
    // velja za zapise in pravilno poravnana.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Za tipe, manjše od spodnje optimizacije blokov, preprosto zamenjajte, da se izognete pesimizu kodegena.
    //
    if mem::size_of::<T>() < 32 {
        // VARNOST: klicatelj mora zagotoviti, da sta `x` in `y` veljavni
        // za zapise, pravilno poravnane in neprekrivajoče se.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Pristop je ta, da uporabimo simd za učinkovito zamenjavo x&y.
    // Testiranje razkriva, da je zamenjava 32 ali 64 bajtov hkrati najučinkovitejša za procesorje Intel Haswell E.
    // LLVM je bolj sposoben optimizirati, če damo strukturi #[repr(simd)], tudi če te strukture dejansko ne uporabljamo neposredno.
    //
    //
    // FIXME repr(simd) pokvarjen na emscripten in redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Prelistajte x&y, kopirajte jih `Block` naenkrat. Optimizator bi moral zanko v celoti razviti za večino vrst NB.
    // Zanke for ne moremo uporabiti, ker `range` impl rekurzivno pokliče `mem::swap`
    //
    let mut i = 0;
    while i + block_size <= len {
        // Ustvarite nekaj neinicializiranega pomnilnika, saj je prostor za praske z izjavo `t` izognjen poravnavi sklada, kadar ta zanka ni uporabljena.
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // VARNOST: Kot `i < len` in kot klicatelj mora zagotoviti, da sta `x` in `y` veljavni
        // za bajte `len` morajo biti `x + i` in `y + i` veljavni naslovi, kar izpolnjuje varnostno pogodbo za `add`.
        //
        // Prav tako mora klicatelj zagotoviti, da `x` in `y` veljata za zapise, pravilno poravnavo in neprekrivanje, kar izpolnjuje varnostno pogodbo za `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Zamenjajte blok bajtov x&y, pri čemer uporabite t kot začasni medpomnilnik. To je treba optimizirati v učinkovite operacije SIMD, kjer je na voljo
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Zamenjajte preostale bajte
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // VARNOST: glej prejšnji komentar o varnosti.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Premakne `src` v koničast `dst` in vrne prejšnjo vrednost `dst`.
///
/// Niti ena vrednost ni izpuščena.
///
/// Ta funkcija je pomensko enakovredna [`mem::replace`], le da deluje na surove kazalce namesto na reference.
/// Ko so reference na voljo, je treba dati prednost [`mem::replace`].
///
/// # Safety
///
/// Vedenje ni določeno, če je kršen kateri od naslednjih pogojev:
///
/// * `dst` mora biti [valid] za branje in pisanje.
///
/// * `dst` mora biti pravilno poravnana.
///
/// * `dst` mora kazati na pravilno inicializirano vrednost tipa `T`.
///
/// Tudi če ima `T` velikost `0`, mora kazalec biti NULL in pravilno poravnan.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` bi imel enak učinek, ne da bi bil potreben nevarni blok.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // VARNOST: klicatelj mora zagotoviti, da je `dst` veljaven
    // predan na spremenljiv sklic (velja za zapise, poravnano, inicializirano) in se ne more prekrivati z `src`, saj mora `dst` kazati na ločen dodeljeni objekt.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // ne more prekrivati
    }
    src
}

/// Prebere vrednost iz `src`, ne da bi jo premaknil.Tako ostane pomnilnik v `src` nespremenjen.
///
/// # Safety
///
/// Vedenje ni določeno, če je kršen kateri od naslednjih pogojev:
///
/// * `src` mora biti [valid] za branje.
///
/// * `src` mora biti pravilno poravnana.V nasprotnem primeru uporabite [`read_unaligned`].
///
/// * `src` mora kazati na pravilno inicializirano vrednost tipa `T`.
///
/// Tudi če ima `T` velikost `0`, mora kazalec biti NULL in pravilno poravnan.
///
/// # Examples
///
/// Osnovna uporaba:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Ročno izvedite [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Ustvarite bitno kopijo vrednosti pri `a` v `tmp`.
///         let tmp = ptr::read(a);
///
///         // Izhod na tej točki (bodisi z izrecnim vrnitvijo bodisi s klicem funkcije, ki panics) povzroči, da se vrednost v `tmp` spusti, medtem ko `a` še vedno sklicuje na isto vrednost.
///         // To lahko sproži nedefinirano vedenje, če `T` ni `Copy`.
/////
/////
///
///         // Ustvari bitno kopijo vrednosti pri `b` v `a`.
///         // To je varno, ker spremenljive reference ne morejo imeti vzdevkov.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Kot zgoraj, bi lahko izhod tukaj sprožil nedefinirano vedenje, ker se na isto vrednost sklicujeta `a` in `b`.
/////
///
///         // Premaknite `tmp` v `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` je bil premaknjen (`write` prevzame lastništvo nad svojim drugim argumentom), tako da tukaj nič ni implicitno spuščeno.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Lastništvo vrnjene vrednosti
///
/// `read` ustvari bitno kopijo `T`, ne glede na to, ali je `T` [`Copy`].
/// Če `T` ni [`Copy`], lahko uporaba vrnjene vrednosti in vrednosti na `*src` krši varnost pomnilnika.
/// Upoštevajte, da dodelitev `*src` šteje kot uporaba, ker bo poskušala spustiti vrednost pri `* src`.
///
/// [`write()`] se lahko uporablja za prepisovanje podatkov, ne da bi jih povzročili.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` zdaj kaže na isti osnovni pomnilnik kot `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Če dodelite `s2`, bo izpuščena njegova prvotna vrednost.
///     // Po tej točki se `s` ne sme več uporabljati, ker je bil sproščen osnovni pomnilnik.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Če dodelite `s`, bi stara vrednost ponovno padla, kar bi povzročilo nedefinirano vedenje.
/////
///     // s= String::from("bar");//NAPAKA
///
///     // `ptr::write` lahko uporabite za prepisovanje vrednosti, ne da bi jo spustili.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // VARNOST: klicatelj mora zagotoviti, da `src` velja za branje.
    // `src` ne more prekrivati `tmp`, ker je bil `tmp` pravkar dodeljen v sklad kot ločen dodeljeni objekt.
    //
    //
    // Ker smo v `tmp` pravkar zapisali veljavno vrednost, je zagotovljeno, da bo pravilno inicializirana.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Prebere vrednost iz `src`, ne da bi jo premaknil.Tako ostane pomnilnik v `src` nespremenjen.
///
/// Za razliko od [`read`], `read_unaligned` deluje z neusmerjenimi kazalci.
///
/// # Safety
///
/// Vedenje ni določeno, če je kršen kateri od naslednjih pogojev:
///
/// * `src` mora biti [valid] za branje.
///
/// * `src` mora kazati na pravilno inicializirano vrednost tipa `T`.
///
/// Tako kot [`read`] tudi `read_unaligned` ustvari bitno kopijo `T`, ne glede na to, ali je `T` [`Copy`].
/// Če `T` ni [`Copy`], lahko z uporabo vrnjene vrednosti in vrednosti na `*src` [violate memory safety][read-ownership].
///
/// Tudi če ima `T` velikost `0`, mora kazalec imeti NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Na konstrukcijah `packed`
///
/// Trenutno ni mogoče ustvariti surovih kazalcev na neuravnana polja zapakirane strukture.
///
/// Poskus ustvarjanja neobdelanega kazalca na strukturno polje `unaligned` z izrazom, kot je `&packed.unaligned as *const FieldType`, ustvari vmesni neusklajeni sklic, preden ga pretvorite v neobdelani kazalec.
///
/// Da je ta referenca začasna in takoj oddana, ni pomembno, saj prevajalnik vedno pričakuje, da bodo reference pravilno poravnane.
/// Posledično uporaba `&packed.unaligned as *const FieldType` povzroči takojšnje* nedefinirano vedenje * v vašem programu.
///
/// Primer tega, česar ne smemo početi in kako je to povezano z `read_unaligned`, je:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Tu poskušamo vzeti naslov 32-bitnega celega števila, ki ni poravnano.
///     let unaligned =
///         // Tu se ustvari začasna neusklajena referenca, ki povzroči nedefinirano vedenje, ne glede na to, ali se referenca uporablja ali ne.
/////
///         &packed.unaligned
///         // Predvajanje v surovi kazalec ne pomaga;napaka se je že zgodila.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Dostop do neusklajenih polj, npr. Z `packed.unaligned`, je varen.
///
///
///
///
///
///
// FIXME: Posodobite dokumente glede na izid RFC #2582 in prijateljev.
/// # Examples
///
/// Preberite vrednost velikosti iz bajtnega medpomnilnika:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // VARNOST: klicatelj mora zagotoviti, da `src` velja za branje.
    // `src` ne more prekrivati `tmp`, ker je bil `tmp` pravkar dodeljen v sklad kot ločen dodeljeni objekt.
    //
    //
    // Ker smo v `tmp` pravkar zapisali veljavno vrednost, je zagotovljeno, da bo pravilno inicializirana.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Prepiše pomnilniško mesto z dano vrednostjo, ne da bi prebral ali spustil staro vrednost.
///
/// `write` ne spusti vsebine `dst`.
/// To je varno, vendar lahko pušča dodelitve ali vire, zato je treba paziti, da ne prepišete predmeta, ki bi ga morali spustiti.
///
///
/// Poleg tega ne pade `src`.Semantično se `src` premakne na mesto, na katerega kaže `dst`.
///
/// To je primerno za inicializacijo neinicializiranega pomnilnika ali prepisovanje pomnilnika, ki je bil prej iz [`read`].
///
/// # Safety
///
/// Vedenje ni določeno, če je kršen kateri od naslednjih pogojev:
///
/// * `dst` za zapisovanje mora biti [valid].
///
/// * `dst` mora biti pravilno poravnana.V nasprotnem primeru uporabite [`write_unaligned`].
///
/// Tudi če ima `T` velikost `0`, mora kazalec biti NULL in pravilno poravnan.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Osnovna uporaba:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Ročno izvedite [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Ustvarite bitno kopijo vrednosti pri `a` v `tmp`.
///         let tmp = ptr::read(a);
///
///         // Izhod na tej točki (bodisi z izrecnim vrnitvijo bodisi s klicem funkcije, ki panics) povzroči, da se vrednost v `tmp` spusti, medtem ko `a` še vedno sklicuje na isto vrednost.
///         // To lahko sproži nedefinirano vedenje, če `T` ni `Copy`.
/////
/////
///
///         // Ustvari bitno kopijo vrednosti pri `b` v `a`.
///         // To je varno, ker spremenljive reference ne morejo imeti vzdevkov.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Kot zgoraj, bi lahko izhod tukaj sprožil nedefinirano vedenje, ker se na isto vrednost sklicujeta `a` in `b`.
/////
///
///         // Premaknite `tmp` v `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` je bil premaknjen (`write` prevzame lastništvo nad svojim drugim argumentom), tako da tukaj nič ni implicitno spuščeno.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Notranji kličemo neposredno, da se izognemo klicem funkcij v ustvarjeni kodi, saj je `intrinsics::copy_nonoverlapping` funkcija zavijanja.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // VARNOST: klicatelj mora zagotoviti, da `dst` velja za pisanje.
    // `dst` ne more prekrivati `src`, ker ima klicatelj spremenljiv dostop do `dst`, medtem ko je `src` v lasti te funkcije.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Prepiše pomnilniško mesto z dano vrednostjo, ne da bi prebral ali spustil staro vrednost.
///
/// Za razliko od [`write()`] kazalec morda ni poravnan.
///
/// `write_unaligned` ne spusti vsebine `dst`.To je varno, vendar lahko pušča dodelitve ali vire, zato je treba paziti, da ne prepišete predmeta, ki bi ga morali spustiti.
///
/// Poleg tega ne pade `src`.Semantično se `src` premakne na mesto, na katerega kaže `dst`.
///
/// To je primerno za inicializacijo neinicializiranega pomnilnika ali prepisovanje pomnilnika, ki je bil že prebran z [`read_unaligned`].
///
/// # Safety
///
/// Vedenje ni določeno, če je kršen kateri od naslednjih pogojev:
///
/// * `dst` za zapisovanje mora biti [valid].
///
/// Tudi če ima `T` velikost `0`, mora kazalec imeti NULL.
///
/// [valid]: self#safety
///
/// ## Na konstrukcijah `packed`
///
/// Trenutno ni mogoče ustvariti surovih kazalcev na neuravnana polja zapakirane strukture.
///
/// Poskus ustvarjanja neobdelanega kazalca na strukturno polje `unaligned` z izrazom, kot je `&packed.unaligned as *const FieldType`, ustvari vmesni neusklajeni sklic, preden ga pretvorite v neobdelani kazalec.
///
/// Da je ta referenca začasna in takoj oddana, ni pomembno, saj prevajalnik vedno pričakuje, da bodo reference pravilno poravnane.
/// Posledično uporaba `&packed.unaligned as *const FieldType` povzroči takojšnje* nedefinirano vedenje * v vašem programu.
///
/// Primer tega, česar ne smemo početi in kako je to povezano z `write_unaligned`, je:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Tu poskušamo vzeti naslov 32-bitnega celega števila, ki ni poravnano.
///     let unaligned =
///         // Tu se ustvari začasna neusklajena referenca, ki povzroči nedefinirano vedenje, ne glede na to, ali se referenca uporablja ali ne.
/////
///         &mut packed.unaligned
///         // Predvajanje v surovi kazalec ne pomaga;napaka se je že zgodila.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Dostop do neusklajenih polj, npr. Z `packed.unaligned`, je varen.
///
///
///
///
///
///
///
///
///
// FIXME: Posodobite dokumente glede na izid RFC #2582 in prijateljev.
/// # Examples
///
/// V bajtni vmesnik zapišite vrednost usize:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // VARNOST: klicatelj mora zagotoviti, da `dst` velja za pisanje.
    // `dst` ne more prekrivati `src`, ker ima klicatelj spremenljiv dostop do `dst`, medtem ko je `src` v lasti te funkcije.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Notranjo kličemo neposredno, da se izognemo funkcijskim klicem v ustvarjeni kodi.
        intrinsics::forget(src);
    }
}

/// Izvede nihajno branje vrednosti iz `src`, ne da bi ga premaknil.Tako ostane pomnilnik v `src` nespremenjen.
///
/// Hlapne operacije naj bi delovale na pomnilniku I/O in jih prevajalnik zagotovo ne bo izbrisal ali prerazporedil pri drugih hlapljivih operacijah.
///
/// # Notes
///
/// Rust trenutno nima strogo in formalno opredeljenega pomnilniškega modela, zato se natančna semantika tega, kar tukaj pomeni "volatile", lahko sčasoma spremeni.
/// Semantika bo skoraj vedno podobna [C11's definition of volatile][c11].
///
/// Prevajalnik ne sme spreminjati relativnega vrstnega reda ali števila nestanovitnih pomnilniških operacij.
/// Vendar so nestanovitne operacije pomnilnika na tipih velikosti nič (npr. Če se tip velikosti nič posreduje `read_volatile`) noops in jih lahko prezrete.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Vedenje ni določeno, če je kršen kateri od naslednjih pogojev:
///
/// * `src` mora biti [valid] za branje.
///
/// * `src` mora biti pravilno poravnana.
///
/// * `src` mora kazati na pravilno inicializirano vrednost tipa `T`.
///
/// Tako kot [`read`] tudi `read_volatile` ustvari bitno kopijo `T`, ne glede na to, ali je `T` [`Copy`].
/// Če `T` ni [`Copy`], lahko z uporabo vrnjene vrednosti in vrednosti na `*src` [violate memory safety][read-ownership].
/// Vendar je shranjevanje vrst, ki niso ["Copy"], v nestanoviten pomnilnik skoraj zagotovo napačno.
///
/// Tudi če ima `T` velikost `0`, mora kazalec biti NULL in pravilno poravnan.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Tako kot v C tudi vprašanje, ali je operacija volatilna, nima nobenega vpliva na vprašanja, ki vključujejo hkratni dostop iz več niti.Hlapljivi dostopi se v tem pogledu obnašajo popolnoma enako kot neatomski dostopi.
///
/// Zlasti dirka med `read_volatile` in katero koli operacijo pisanja na isto lokacijo je nedefinirano vedenje.
///
/// # Examples
///
/// Osnovna uporaba:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Brez panike, da bi bil vpliv kodegena manjši.
        abort();
    }
    // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Izvede hlapljivo zapisovanje lokacije pomnilnika z dano vrednostjo, ne da bi prebralo ali spustilo staro vrednost.
///
/// Hlapne operacije naj bi delovale na pomnilniku I/O in jih prevajalnik zagotovo ne bo izbrisal ali prerazporedil pri drugih hlapljivih operacijah.
///
/// `write_volatile` ne spusti vsebine `dst`.To je varno, vendar lahko pušča dodelitve ali vire, zato je treba paziti, da ne prepišete predmeta, ki bi ga morali spustiti.
///
/// Poleg tega ne pade `src`.Semantično se `src` premakne na mesto, na katerega kaže `dst`.
///
/// # Notes
///
/// Rust trenutno nima strogo in formalno opredeljenega pomnilniškega modela, zato se natančna semantika tega, kar tukaj pomeni "volatile", lahko sčasoma spremeni.
/// Semantika bo skoraj vedno podobna [C11's definition of volatile][c11].
///
/// Prevajalnik ne sme spreminjati relativnega vrstnega reda ali števila nestanovitnih pomnilniških operacij.
/// Vendar so nestanovitne operacije pomnilnika na tipih velikosti nič (npr. Če se tip velikosti nič posreduje `write_volatile`) noops in jih lahko prezrete.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Vedenje ni določeno, če je kršen kateri od naslednjih pogojev:
///
/// * `dst` za zapisovanje mora biti [valid].
///
/// * `dst` mora biti pravilno poravnana.
///
/// Tudi če ima `T` velikost `0`, mora kazalec biti NULL in pravilno poravnan.
///
/// [valid]: self#safety
///
/// Tako kot v C tudi vprašanje, ali je operacija volatilna, nima nobenega vpliva na vprašanja, ki vključujejo hkratni dostop iz več niti.Hlapljivi dostopi se v tem pogledu obnašajo popolnoma enako kot neatomski dostopi.
///
/// Zlasti dirka med `write_volatile` in katero koli drugo operacijo (branje ali pisanje) na isti lokaciji je nedefinirano vedenje.
///
/// # Examples
///
/// Osnovna uporaba:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Brez panike, da bi bil vpliv kodegena manjši.
        abort();
    }
    // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Poravnajte kazalec `p`.
///
/// Izračunajte odmik (glede na elemente koraka `stride`), ki ga je treba uporabiti za kazalec `p`, tako da se kazalnik `p` poravna s `a`.
///
/// Note: Ta izvedba je bila skrbno prilagojena ne panic.Za to je UB do panic.
/// Edina resnična sprememba, ki jo lahko tukaj naredimo, je sprememba `INV_TABLE_MOD_16` in s tem povezanih konstant.
///
/// Če se bomo kdaj odločili, da bomo s `a` lahko poklicali bistvo, ki ni moč dveh, bo verjetno bolj smotrno, če se le odločimo za naivno izvedbo, namesto da bi to poskušali prilagoditi tej spremembi.
///
///
/// Vsa vprašanja pojdite na@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Neposredna uporaba teh lastnosti bistveno izboljša kodegen na opt-level <=
    // 1, kjer različice metod teh operacij niso zapisane.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Izračunajte multiplikativno modularno inverzno vrednost `x` po modulu `m`.
    ///
    /// Ta izvedba je prilagojena `align_offset` in ima naslednje pogoje:
    ///
    /// * `m` je moč dveh;
    /// * `x < m`; (če je `x ≥ m`, namesto tega podajte `x % m`)
    ///
    /// Izvajanje te funkcije ne sme biti panic.Kdaj.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Multiplikativna modularna inverzna tabela modul 2⁴=16.
        ///
        /// Upoštevajte, da ta tabela ne vsebuje vrednosti, kjer inverzna ne obstaja (tj. Za `0⁻¹ mod 16`, `2⁻¹ mod 16` itd.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modul, kateremu je `INV_TABLE_MOD_16` namenjen.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // VARNOST: `m` mora biti moč dveh, torej ne nič.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Ponovimo "up" po naslednji formuli:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // do 2²ⁿ ≥ m.Nato se lahko z rezultatom `mod m` zmanjšamo na želeni `m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Upoštevajte, da tu namenoma uporabljamo postopke zavijanja-prvotna formula uporablja npr. Odštevanje `mod n`.
                // Popolnoma je v redu, če jim namesto tega naredimo `mod usize::MAX`, saj rezultat `mod n` vseeno vzamemo na koncu.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // VARNOST: `a` je moč dveh, zato ni nič.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` Primer je mogoče preprosteje izračunati prek `-p (mod a)`, vendar to onemogoča LLVM, da izbere navodila, kot je `lea`.Namesto tega izračunamo
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // ki razporeja operacije okoli nosilnosti, a `and` pesimira dovolj, da lahko LLVM izkoristi različne optimizacije, za katere ve.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Že poravnano.Juhu!
        return 0;
    } else if stride == 0 {
        // Če kazalec ni poravnan in je element ničelne velikosti, kazalnik ne bo nikoli poravnal nobene količine elementov.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // VARNOST: a je moč dveh, torej ni nič.stride==0 je obravnavan zgoraj.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // VARNOST: gcdpow ima zgornjo mejo, ki je največ število bitov v velikosti.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // VARNOST: gcd je vedno večji ali enak 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Ta branch rešuje naslednjo enačbo linearne skladnosti:
        //
        // ` p + so = 0 mod a `
        //
        // `p` tukaj je vrednost kazalca, `s`, korak `T`, odmik `o` v `T` in `a`, zahtevana poravnava.
        //
        // Z `g = gcd(a, s)` in zgornjim pogojem, ki trdi, da je `p` tudi deljiv s `g`, lahko označimo `a' = a/g`, `s' = s/g`, `p' = p/g`, potem postane to enakovredno:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Prvi izraz je "the relative alignment of `p` to `a`" (deljen z `g`), drugi izraz je "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (spet deljen z `g`).
        //
        // Delitev z `g` je potrebna, da je inverza dobro oblikovana, če `a` in `s` nista soprosti.
        //
        // Poleg tega rezultat, ki ga daje ta rešitev, ni "minimal", zato je treba vzeti rezultat `o mod lcm(s, a)`.`lcm(s, a)` lahko nadomestimo s samo `a'`.
        //
        //
        //
        //
        //

        // VARNOST: `gcdpow` ima zgornjo mejo, ki ni večja od števila končnih 0-bitov v `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // VARNOST: `a2` ni nič.Premik `a` za `gcdpow` ne more premakniti nobenega od nastavljenih bitov
        // v `a` (od katerih jih ima točno enega).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // VARNOST: `gcdpow` ima zgornjo mejo, ki ni večja od števila končnih 0-bitov v `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // VARNOST: `gcdpow` ima zgornjo mejo, ki ni večja od števila zadnjih bitov 0
        // `a`.
        // Poleg tega odštevanje ne more preseči, ker bo `a2 = a >> gcdpow` vedno strogo večji od `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // VARNOST: `a2` je moč dveh, kot je dokazano zgoraj.`s2` je strogo manjši od `a2`
        // ker je `(s % a) >> gcdpow` strogo manjši od `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Sploh ni mogoče poravnati.
    usize::MAX
}

/// Primerja surove kazalce za enakost.
///
/// To je enako kot pri uporabi operaterja `==`, vendar manj splošnega:
/// argumenti morajo biti `*const T` surovi kazalci, ne pa nič, kar implementira `PartialEq`.
///
/// To lahko uporabimo za primerjavo referenc `&T` (ki implicitno prisilijo `*const T`) po njihovem naslovu, namesto da primerjamo vrednosti, na katere kažejo (kar naredi izvedba `PartialEq for &T`).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Rezine primerjamo tudi po dolžini (kazalci maščob):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits primerjamo tudi po njihovi izvedbi:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Kazalci imajo enake naslove.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Predmeti imajo enake naslove, vendar ima `Trait` različne izvedbe.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Pretvorba sklica v `*const u8` se primerja po naslovu.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Razpršite surovi kazalec.
///
/// S tem se lahko razprši referenca `&T` (ki implicitno prisili na `*const T`) po naslovu in ne po vrednosti, na katero kaže (kar naredi izvedba `Hash for &T`).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Predstavlja za kazalce funkcij
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Za AVR je potreben vmesni oddaj kot usize
                // tako da se v končnem kazalcu funkcije ohrani naslovni prostor kazalca izvorne funkcije.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Za AVR je potreben vmesni oddaj kot usize
                // tako da se v končnem kazalcu funkcije ohrani naslovni prostor kazalca izvorne funkcije.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Ni variadnih funkcij z 0 parametri
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Ustvarite surov kazalec `const` na mesto, ne da bi ustvarili vmesno referenco.
///
/// Ustvarjanje sklica z `&`/`&mut` je dovoljeno le, če je kazalec pravilno poravnan in kaže na inicializirane podatke.
/// V primerih, ko te zahteve ne veljajo, je treba namesto njih uporabiti surove kazalce.
/// Vendar `&expr as *const _` ustvari sklic, preden ga odda v neobdelani kazalnik, za ta sklic pa veljajo ista pravila kot za vse druge sklice.
///
/// Ta makro lahko ustvari neobdelani kazalec *, ne da bi* najprej ustvaril referenco.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` bi ustvaril neskladen sklic in s tem nedefinirano vedenje!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Ustvarite surov kazalec `mut` na mesto, ne da bi ustvarili vmesno referenco.
///
/// Ustvarjanje sklica z `&`/`&mut` je dovoljeno le, če je kazalec pravilno poravnan in kaže na inicializirane podatke.
/// V primerih, ko te zahteve ne veljajo, je treba namesto njih uporabiti surove kazalce.
/// Vendar `&mut expr as *mut _` ustvari sklic, preden ga odda v neobdelani kazalnik, za ta sklic pa veljajo ista pravila kot za vse druge sklice.
///
/// Ta makro lahko ustvari neobdelani kazalec *, ne da bi* najprej ustvaril referenco.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` bi ustvaril neskladen sklic in s tem nedefinirano vedenje!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` prisili kopiranje polja, namesto da bi ustvaril sklic.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}