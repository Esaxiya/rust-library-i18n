use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Ovoj okoli surovega ne-null `*mut T`, ki kaže, da je lastnik tega ovoja lastnik referenta.
/// Uporabno za gradnjo abstrakcij, kot so `Box<T>`, `Vec<T>`, `String` in `HashMap<K, V>`.
///
/// Za razliko od `*mut T` se `Unique<T>` obnaša kot "as if", da je bil primerek `T`.
/// Izvaja `Send`/`Sync`, če je `T` `Send`/`Sync`.
/// To pomeni tudi vrsto močnih vzdevkov, ki jih lahko pričakuje primerek `T`:
/// referenca kazalca se ne sme spreminjati brez edinstvene poti do lastnega Unique.
///
/// Če niste prepričani, ali je pravilno uporabiti `Unique` za svoje namene, razmislite o uporabi `NonNull`, ki ima šibkejšo semantiko.
///
///
/// Za razliko od `*mut T` mora kazalec vedno biti ne-null, tudi če kazalca nikoli ne odštejemo.
/// To pomeni, da lahko enumi uporabljajo to prepovedano vrednost kot diskriminator-`Option<Unique<T>>` ima enako velikost kot `Unique<T>`.
/// Kazalec pa lahko še vedno visi, če ni imenovan.
///
/// Za razliko od `*mut T` je `Unique<T>` kovarianten nad `T`.
/// To mora biti vedno pravilno za vse vrste, ki izpolnjujejo Unique-ove vzdevek.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: ta označevalec nima posledic za odstopanje, vendar je nujen
    // da dropck razume, da smo logično lastnik `T`.
    //
    // Za podrobnosti glejte:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` kazalci so `Send`, če je `T` `Send`, ker so podatki, na katere se sklicujejo, nedoseženi.
/// Upoštevajte, da ta vzporedni invariant ni uveljavljen s sistemom tipov;abstrakcija z uporabo `Unique` mora to uveljaviti.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` kazalci so `Sync`, če je `T` `Sync`, ker so podatki, na katere se sklicujejo, nedoseženi.
/// Upoštevajte, da ta vzporedni invariant ni uveljavljen s sistemom tipov;abstrakcija z uporabo `Unique` mora to uveljaviti.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Ustvari nov `Unique`, ki je viseč, vendar dobro usklajen.
    ///
    /// To je koristno za inicializacijo vrst, ki jih lenobno dodelijo, kot to počne `Vec::new`.
    ///
    /// Upoštevajte, da lahko vrednost kazalca potencialno predstavlja veljaven kazalec na `T`, kar pomeni, da se ne sme uporabljati kot kontrolna vrednost "not yet initialized".
    /// Vrste, ki jih leno dodelijo, morajo slediti inicializaciji z drugimi sredstvi.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // VARNOST: mem::align_of() vrne veljaven, ne-null kazalec.The
        // tako so izpolnjeni pogoji za klic new_unchecked().
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Ustvari nov `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` ne sme biti nič.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // VARNOST: klicatelj mora zagotoviti, da `ptr` ni ničelna.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Ustvari nov `Unique`, če `ptr` ni nič.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // VARNOST: Kazalec je že preverjen in ni nič.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Pridobi osnovni kazalnik `*mut`.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Odstranitev vsebine.
    ///
    /// Nastala življenjska doba je vezana na samega sebe, zato se to obnaša "as if", v resnici gre za primerek T, ki se izposoja.
    /// Če je potrebna daljša življenjska doba (unbound), uporabite `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // VARNOST: klicatelj mora zagotoviti, da `self` izpolnjuje vse zahteve
        // zahteve za referenco.
        unsafe { &*self.as_ptr() }
    }

    /// Izmenjava vsebine preusmerja.
    ///
    /// Nastala življenjska doba je vezana na samega sebe, zato se to obnaša "as if", v resnici gre za primerek T, ki se izposoja.
    /// Če je potrebna daljša življenjska doba (unbound), uporabite `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // VARNOST: klicatelj mora zagotoviti, da `self` izpolnjuje vse zahteve
        // zahteve za spremenljivo referenco.
        unsafe { &mut *self.as_ptr() }
    }

    /// Predvaja kazalec druge vrste.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // VARNOST: Unique::new_unchecked() ustvarja novo edinstvenost in potrebe
        // da dani kazalec ne bo nič.
        // Ker predajamo sebe kot kazalec, ne more biti nič.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // VARNOST: Spremenljivi sklic ne sme biti ničen
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}