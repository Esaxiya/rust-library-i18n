use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` vendar ničen in kovarianten.
///
/// To je pogosto pravilno uporabljati pri gradnji podatkovnih struktur z uporabo surovih kazalcev, vendar je na koncu zaradi svojih dodatnih lastnosti bolj nevarno.Če niste prepričani, ali bi morali uporabiti `NonNull<T>`, samo uporabite `*mut T`!
///
/// Za razliko od `*mut T` mora kazalec vedno imeti neveljavno vrednost, tudi če kazalca nikoli ne odštejemo.To je zato, da lahko enumi uporabljajo to prepovedano vrednost kot diskriminator-`Option<NonNull<T>>` ima enako velikost kot `* mut T`.
/// Kazalec pa lahko še vedno visi, če ni imenovan.
///
/// Za razliko od `*mut T` je bil `NonNull<T>` izbran za kovarianto nad `T`.To omogoča uporabo `NonNull<T>` pri gradnji kovariantnih tipov, vendar predstavlja tveganje za neskladnost, če se uporablja v tipu, ki dejansko ne bi smel biti kovarianten.
/// (Nasprotno se je odločila za `*mut T`, čeprav je tehnično neustreznost lahko povzročila le klicanje nevarnih funkcij.)
///
/// Kovarianca je pravilna za večino varnih abstrakcij, kot so `Box`, `Rc`, `Arc`, `Vec` in `LinkedList`.To velja, ker zagotavljajo javni API, ki sledi običajnim skupnim pravilom, ki jih je mogoče spremeniti XOR, Rust.
///
/// Če vaš tip ne more biti varno kovarianten, morate zagotoviti, da vsebuje nekaj dodatnih polj, ki zagotavljajo nespremenljivost.Pogosto je to polje tipa [`PhantomData`], kot je `PhantomData<Cell<T>>` ali `PhantomData<&'a mut T>`.
///
/// Upoštevajte, da ima `NonNull<T>` primerek `From` za `&T`.Vendar to ne spremeni dejstva, da je mutiranje skozi (kazalnik, izpeljan iz a) skupne reference nedefinirano vedenje, razen če se mutacija zgodi znotraj [`UnsafeCell<T>`].Enako velja za ustvarjanje spremenljive reference iz skupne reference.
///
/// Ko uporabljate ta primerek `From` brez `UnsafeCell<T>`, ste odgovorni, da `as_mut` nikoli ne pokličete in `as_ptr` nikoli ne uporabite za mutacijo.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` kazalci niso `Send`, ker so lahko podatki, na katere se sklicujejo, vzdevek.
// Opomba: ta impl ni potreben, vendar bi moral zagotavljati boljša sporočila o napakah.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` kazalci niso `Sync`, ker so lahko podatki, na katere se sklicujejo, vzdevek.
// Opomba: ta impl ni potreben, vendar bi moral zagotavljati boljša sporočila o napakah.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Ustvari nov `NonNull`, ki je viseč, vendar dobro usklajen.
    ///
    /// To je koristno za inicializacijo vrst, ki jih lenobno dodelijo, kot to počne `Vec::new`.
    ///
    /// Upoštevajte, da lahko vrednost kazalca potencialno predstavlja veljaven kazalec na `T`, kar pomeni, da se ne sme uporabljati kot kontrolna vrednost "not yet initialized".
    /// Vrste, ki jih leno dodelijo, morajo slediti inicializaciji z drugimi sredstvi.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // VARNOST: mem::align_of() vrne velikost, ki ni enaka nič, ki se nato odda
        // do * mut T.
        // Zato `ptr` ni nič in so pogoji za klic new_unchecked() spoštovani.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Vrne skupne sklice na vrednost.V nasprotju z [`as_ref`] to ne zahteva, da je treba vrednost inicializirati.
    ///
    /// Za spremenljiv primer glej [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Ko kličete to metodo, morate zagotoviti, da velja vse naslednje:
    ///
    /// * Kazalec mora biti pravilno poravnan.
    ///
    /// * To mora biti "dereferencable" v smislu, opredeljenem v [the module documentation].
    ///
    /// * Morate uveljaviti pravila vzdevanja Rust, saj je vrnjena življenjska doba `'a` poljubno izbrana in ne odraža nujno dejanske življenjske dobe podatkov.
    ///
    ///   Zlasti v času te življenjske dobe pomnilnik, na katerega kaže kazalec, ne sme biti mutiran (razen znotraj `UnsafeCell`).
    ///
    /// To velja tudi, če je rezultat te metode neuporabljen!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // VARNOST: klicatelj mora zagotoviti, da `self` izpolnjuje vse zahteve
        // zahteve za referenco.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Vrne enolične sklice na vrednost.V nasprotju z [`as_mut`] to ne zahteva, da je treba vrednost inicializirati.
    ///
    /// Za primerjavo v skupni rabi glejte [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Ko kličete to metodo, morate zagotoviti, da velja vse naslednje:
    ///
    /// * Kazalec mora biti pravilno poravnan.
    ///
    /// * To mora biti "dereferencable" v smislu, opredeljenem v [the module documentation].
    ///
    /// * Morate uveljaviti pravila vzdevanja Rust, saj je vrnjena življenjska doba `'a` poljubno izbrana in ne odraža nujno dejanske življenjske dobe podatkov.
    ///
    ///   Zlasti v času te življenjske dobe pomnilnik, na katerega kaže kazalec, ne sme imeti dostopa (branja ali zapisa) prek katerega koli drugega kazalca.
    ///
    /// To velja tudi, če je rezultat te metode neuporabljen!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // VARNOST: klicatelj mora zagotoviti, da `self` izpolnjuje vse zahteve
        // zahteve za referenco.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Ustvari nov `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` ne sme biti nič.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // VARNOST: klicatelj mora zagotoviti, da `ptr` ni ničelna.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Ustvari nov `NonNull`, če `ptr` ni nič.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // VARNOST: Kazalec je že preverjen in ni nič
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Izvaja enako funkcionalnost kot [`std::ptr::from_raw_parts`], le da se vrne kazalec `NonNull`, v nasprotju s surovim kazalcem `*const`.
    ///
    ///
    /// Za več podrobnosti glejte dokumentacijo [`std::ptr::from_raw_parts`].
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // VARNOST: Rezultat `ptr::from::raw_parts_mut` ni nič, ker `data_address` je.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Razstavite (po možnosti širok) kazalec na naslov in komponente metapodatkov.
    ///
    /// Kazalec lahko kasneje rekonstruirate z [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Pridobi osnovni kazalnik `*mut`.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Vrne skupni sklic na vrednost.Če je vrednost morda neinicializirana, je treba namesto nje uporabiti [`as_uninit_ref`].
    ///
    /// Za spremenljiv primer glej [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Ko kličete to metodo, morate zagotoviti, da velja vse naslednje:
    ///
    /// * Kazalec mora biti pravilno poravnan.
    ///
    /// * To mora biti "dereferencable" v smislu, opredeljenem v [the module documentation].
    ///
    /// * Kazalec mora kazati na inicializiran primerek `T`.
    ///
    /// * Morate uveljaviti pravila vzdevanja Rust, saj je vrnjena življenjska doba `'a` poljubno izbrana in ne odraža nujno dejanske življenjske dobe podatkov.
    ///
    ///   Zlasti v času te življenjske dobe pomnilnik, na katerega kaže kazalec, ne sme biti mutiran (razen znotraj `UnsafeCell`).
    ///
    /// To velja tudi, če je rezultat te metode neuporabljen!
    /// (Del o inicializaciji še ni popolnoma določen, vendar dokler ni, je edini varen pristop zagotoviti, da se resnično inicializirajo.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // VARNOST: klicatelj mora zagotoviti, da `self` izpolnjuje vse zahteve
        // zahteve za referenco.
        unsafe { &*self.as_ptr() }
    }

    /// Vrne enolično sklic na vrednost.Če je vrednost morda neinicializirana, je treba namesto nje uporabiti [`as_uninit_mut`].
    ///
    /// Za primerjavo v skupni rabi glejte [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Ko kličete to metodo, morate zagotoviti, da velja vse naslednje:
    ///
    /// * Kazalec mora biti pravilno poravnan.
    ///
    /// * To mora biti "dereferencable" v smislu, opredeljenem v [the module documentation].
    ///
    /// * Kazalec mora kazati na inicializiran primerek `T`.
    ///
    /// * Morate uveljaviti pravila vzdevanja Rust, saj je vrnjena življenjska doba `'a` poljubno izbrana in ne odraža nujno dejanske življenjske dobe podatkov.
    ///
    ///   Zlasti v času te življenjske dobe pomnilnik, na katerega kaže kazalec, ne sme imeti dostopa (branja ali zapisa) prek katerega koli drugega kazalca.
    ///
    /// To velja tudi, če je rezultat te metode neuporabljen!
    /// (Del o inicializaciji še ni popolnoma določen, vendar dokler ni, je edini varen pristop zagotoviti, da se resnično inicializirajo.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // VARNOST: klicatelj mora zagotoviti, da `self` izpolnjuje vse zahteve
        // zahteve za spremenljivo referenco.
        unsafe { &mut *self.as_ptr() }
    }

    /// Predvaja kazalec druge vrste.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // VARNOST: `self` je kazalec `NonNull`, ki nujno ni nič
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Ustvari ne-null surovo rezino iz tankega kazalca in dolžine.
    ///
    /// Argument `len` je število **elementov**, ne število bajtov.
    ///
    /// Ta funkcija je varna, vendar preusmerjanje referenčne vrednosti ni varno.
    /// Za varnostne zahteve glede rezin glejte dokumentacijo [`slice::from_raw_parts`].
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // ustvari kazalec rezine, ko začneš s kazalcem na prvi element
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Upoštevajte, da ta primer umetno prikazuje uporabo te metode, vendar `let slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // VARNOST: `data` je kazalec `NonNull`, ki nujno ni nič
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Vrne dolžino ne-null surove rezine.
    ///
    /// Vrnjena vrednost je število **elementov**, ne število bajtov.
    ///
    /// Ta funkcija je varna, tudi če ničelne surove rezine ni mogoče preusmeriti na rezino, ker kazalec nima veljavnega naslova.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Vrne ničelni kazalec na medpomnilnik rezine.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // VARNOST: Vemo, da `self` ni nič.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Vrne neobdelani kazalnik na medpomnilnik rezine.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Vrne sklic v skupni rabi na rezino morebiti neinicializiranih vrednosti.V nasprotju z [`as_ref`] to ne zahteva, da je treba vrednost inicializirati.
    ///
    /// Za spremenljiv primer glej [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Ko kličete to metodo, morate zagotoviti, da velja vse naslednje:
    ///
    /// * Kazalec mora biti [valid] za branje za veliko število bajtov `ptr.len() * mem::size_of::<T>()` in mora biti pravilno poravnan.To zlasti pomeni:
    ///
    ///     * Celoten obseg pomnilnika te rezine mora biti v enem dodeljenem objektu!
    ///       Rezine nikoli ne morejo obsegati več dodeljenih predmetov.
    ///
    ///     * Kazalec mora biti poravnan tudi za rezine ničelne dolžine.
    ///     Eden od razlogov za to je, da se lahko optimizacije postavitve naštevanja sklicujejo na poravnave referenc (vključno z rezinami katere koli dolžine) in njihovo nično, da jih ločijo od drugih podatkov.
    ///
    ///     S pomočjo [`NonNull::dangling()`] lahko dobite kazalec, ki je uporaben kot `data` za rezine ničelne dolžine.
    ///
    /// * Skupna velikost rezine `ptr.len() * mem::size_of::<T>()` ne sme biti večja od `isize::MAX`.
    ///   Glejte varnostno dokumentacijo [`pointer::offset`].
    ///
    /// * Morate uveljaviti pravila vzdevanja Rust, saj je vrnjena življenjska doba `'a` poljubno izbrana in ne odraža nujno dejanske življenjske dobe podatkov.
    ///   Zlasti v času te življenjske dobe pomnilnik, na katerega kaže kazalec, ne sme biti mutiran (razen znotraj `UnsafeCell`).
    ///
    /// To velja tudi, če je rezultat te metode neuporabljen!
    ///
    /// Glej tudi [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Vrne enolično sklic na rezino morebiti neinicializiranih vrednosti.V nasprotju z [`as_mut`] to ne zahteva, da je treba vrednost inicializirati.
    ///
    /// Za primerjavo v skupni rabi glejte [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Ko kličete to metodo, morate zagotoviti, da velja vse naslednje:
    ///
    /// * Kazalec mora biti [valid] za branje in zapisovanje za veliko bajtov `ptr.len() * mem::size_of::<T>()` in mora biti pravilno poravnan.To zlasti pomeni:
    ///
    ///     * Celoten obseg pomnilnika te rezine mora biti v enem dodeljenem objektu!
    ///       Rezine nikoli ne morejo obsegati več dodeljenih predmetov.
    ///
    ///     * Kazalec mora biti poravnan tudi za rezine ničelne dolžine.
    ///     Eden od razlogov za to je, da se lahko optimizacije postavitve naštevanja sklicujejo na poravnave referenc (vključno z rezinami katere koli dolžine) in njihovo nično, da jih ločijo od drugih podatkov.
    ///
    ///     S pomočjo [`NonNull::dangling()`] lahko dobite kazalec, ki je uporaben kot `data` za rezine ničelne dolžine.
    ///
    /// * Skupna velikost rezine `ptr.len() * mem::size_of::<T>()` ne sme biti večja od `isize::MAX`.
    ///   Glejte varnostno dokumentacijo [`pointer::offset`].
    ///
    /// * Morate uveljaviti pravila vzdevanja Rust, saj je vrnjena življenjska doba `'a` poljubno izbrana in ne odraža nujno dejanske življenjske dobe podatkov.
    ///   Zlasti v času te življenjske dobe pomnilnik, na katerega kaže kazalec, ne sme imeti dostopa (branja ali zapisa) prek katerega koli drugega kazalca.
    ///
    /// To velja tudi, če je rezultat te metode neuporabljen!
    ///
    /// Glej tudi [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // To je varno, saj `memory` velja za branje in zapisovanje za veliko bajtov `memory.len()`.
    /// // Upoštevajte, da klic `memory.as_mut()` tukaj ni dovoljen, ker je vsebina morda neinicializirana.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo za `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Vrne neobdelani kazalnik na element ali podrezo, ne da bi preverjal meje.
    ///
    /// Klicanje te metode z indeksom zunaj meja ali kadar `self` ni mogoče preusmeriti, je *[nedefinirano vedenje]*, tudi če uporabljeni kazalnik ni uporabljen.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // VARNOST: klicatelj zagotavlja, da `self` ni mogoče referencirati in da je `index` znotraj.
        // Posledica tega je, da dobljeni kazalec ne more biti NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // VARNOST: Edinstveni kazalec ne more biti ničen, zato so pogoji za
        // new_unchecked() spoštujejo.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // VARNOST: Spremenljivi sklic ne sme biti ničen.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // VARNOST: sklic ne sme biti ničen, zato so pogoji za
        // new_unchecked() spoštujejo.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}