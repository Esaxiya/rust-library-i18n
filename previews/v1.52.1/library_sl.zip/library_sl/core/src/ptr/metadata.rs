#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Ponuja vrsto metapodatkov kazalca katerega koli usmerjenega tipa.
///
/// # Metapodatki kazalca
///
/// Neobdelane vrste kazalcev in referenčne vrste v Rust lahko predstavljamo kot sestavljene iz dveh delov:
/// podatkovni kazalnik, ki vsebuje pomnilniški naslov vrednosti in nekatere metapodatke.
///
/// Za tipe s statično velikostjo (ki izvajajo `Sized` traits) in za tipe `extern` naj bi bili kazalci "tanki": metapodatki so nič veliki, njihov tip pa `()`.
///
///
/// Kazalci na [dynamically-sized types][dst] naj bi bili "široki" ali "debeli", imajo metapodatke, ki niso nič enaki:
///
/// * Za strukture, katerih zadnje polje je DST, so metapodatki metapodatki za zadnje polje
/// * Za tip `str` so metapodatki dolžina v bajtih kot `usize`
/// * Za vrste rezin, kot je `[T]`, so metapodatki dolžina elementov kot `usize`
/// * Za predmete Portrait, kot je `dyn SomeTrait`, so metapodatki [`DynMetadata<Self>`][DynMetadata] (npr. `DynMetadata<dyn SomeTrait>`)
///
/// V jeziku future lahko jezik Rust pridobi nove vrste tipov z različnimi metapodatki kazalca.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` Portrait
///
/// Bistvo tega Portrait je njegov tip, povezan z `Metadata`, ki je `()` ali `usize` ali `DynMetadata<_>`, kot je opisano zgoraj.
/// Samodejno se izvaja za vsako vrsto.
/// Lahko se domneva, da se izvaja v splošnem kontekstu, tudi brez ustrezne meje.
///
/// # Usage
///
/// Surove kazalce je mogoče razstaviti na podatkovni naslov in komponente metapodatkov s svojo metodo [`to_raw_parts`].
///
/// S funkcijo [`metadata`] lahko izvlečete samo metapodatke.
/// Sklic se lahko posreduje na [`metadata`] in ga implicitno prisili.
///
/// Kazalec (possibly-wide) lahko sestavite iz naslova in metapodatkov z [`from_raw_parts`] ali [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Vrsta metapodatkov v kazalcih in sklici na `Self`.
    #[lang = "metadata_type"]
    // NOTE: Naj bo Portrait bounds v `static_assert_expected_bounds_for_metadata`
    //
    // v `library/core/src/ptr/metadata.rs` sinhronizirano s tistimi tukaj:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Kazalci na tipe, ki izvajajo ta vzdevek Portrait, so "tanki".
///
/// Sem spadajo tipi "velikosti" in tipi `extern`.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: ne stabilizirajte tega, preden so vzdevki Portrait stabilni v jeziku?
pub trait Thin = Pointee<Metadata = ()>;

/// Izvlecite komponento metapodatkov kazalca.
///
/// Vrednosti tipa `*mut T`, `&T` ali `&mut T` se lahko posredujejo neposredno tej funkciji, saj implicitno prisilijo v `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // VARNOST: Dostop do vrednosti iz zveze `PtrRepr` je varen, ker * const T
    // in PtrComponents<T>imajo enake postavitve pomnilnika.
    // To garancijo lahko da samo std.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Oblikuje neobdelani kazalec (possibly-wide) iz podatkovnega naslova in metapodatkov.
///
/// Ta funkcija je varna, vendar vrnjeni kazalec ni nujno varen za dereference.
/// Za rezine glejte dokumentacijo [`slice::from_raw_parts`] glede varnostnih zahtev.
/// Za predmete Portrait morajo metapodatki prihajati iz kazalca na isti osnovni izbrisani tip.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // VARNOST: Dostop do vrednosti iz zveze `PtrRepr` je varen, ker * const T
    // in PtrComponents<T>imajo enake postavitve pomnilnika.
    // To garancijo lahko da samo std.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Izvaja enako funkcionalnost kot [`from_raw_parts`], le da se vrne neobdelani kazalnik `*mut`, v nasprotju s surovim kazalcem `* const`.
///
///
/// Za več podrobnosti glejte dokumentacijo [`from_raw_parts`].
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // VARNOST: Dostop do vrednosti iz zveze `PtrRepr` je varen, ker * const T
    // in PtrComponents<T>imajo enake postavitve pomnilnika.
    // To garancijo lahko da samo std.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Potreben je ročni impl, da se izognete vezavi na `T: Copy`.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Potreben je ročni impl, da se izognete vezavi na `T: Clone`.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Metapodatki za vrsto predmeta `Dyn = dyn SomeTrait` Portrait.
///
/// Je kazalec na vtable (navidezna klicna tabela), ki predstavlja vse potrebne informacije za manipulacijo s konkretnim tipom, shranjenim znotraj predmeta Portrait.
/// Vtable predvsem vsebuje:
///
/// * velikost tipa
/// * poravnava tipa
/// * kazalec na impl tipa `drop_in_place` tipa (za navadne-stare podatke morda ni dovoljeno)
/// * kaže na vse metode za izvedbo tipa Portrait
///
/// Upoštevajte, da so prvi trije posebni, ker so nujni za dodeljevanje, spuščanje in odstranjevanje katerega koli predmeta Portrait.
///
/// To strukturo je mogoče poimenovati s parametrom tipa, ki ni objekt `dyn` Portrait (na primer `DynMetadata<u64>`), ne pa tudi pridobiti smiselne vrednosti te strukture.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Skupna predpona vseh vtabel.Sledijo kazalci funkcij za metode Portrait.
///
/// Podrobnosti o zasebni izvedbi `DynMetadata::size_of` itd.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Vrne velikost vrste, povezane s tem vtableom.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Vrne poravnavo tipa, povezanega s tem vtableom.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Vrne velikost in poravnavo skupaj kot `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // VARNOST: prevajalnik je ta vtable oddajal za konkreten tip Rust, ki
        // je znano, da ima veljavno postavitev.Utemeljitev kot pri `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Ročni impulzi, potrebni za izogibanje omejitvam `Dyn: $Trait`.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}