//! Panic podpora za libcore
//!
//! Osnovna knjižnica ne more definirati panike, vendar *deklarira* paniko.
//! To pomeni, da so funkcije znotraj libcoreja dovoljene panic, toda za uporabnost mora zgornji crate določiti paniko, ki jo lahko uporabi libcore.
//! Trenutni vmesnik za paniko je:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Ta definicija omogoča paniko s katerim koli splošnim sporočilom, ne omogoča pa okvare z vrednostjo `Box<Any>`.
//! (`PanicInfo` vsebuje samo `&(dyn Any + Send)`, za katerega v "PanicInfo: : internal_constructor" vnesemo navidezno vrednost.) Razlog za to je, da libcore ne sme dodeliti.
//!
//!
//! Ta modul vsebuje nekaj drugih funkcij panike, vendar so to le nujni elementi lang za prevajalnik.Vsi panics so usmerjeni skozi to eno funkcijo.
//! Dejanski simbol se navede prek atributa `#[panic_handler]`.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Osnovna izvedba makra `panic!` libcoreja, kadar se ne uporablja oblikovanje.
#[cold]
// nikoli v vrstici, razen panic_immediate_abort, da se čim bolj izognete napihnjenosti kode na klicnih mestih
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // ki ga potrebuje codegen za panic na prelivu in druge zaključke MIR `Assert`
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Uporabite Arguments::new_v1 namesto format_args! ("{}", Expr), da potencialno zmanjšate režijske stroške.
    // Formati_args!makro uporablja str-ov Display Portrait za pisanje izraza, ki pokliče Formatter::pad, ki mora vključevati skrajšanje nizov in oblazinjenje (čeprav tukaj ni uporabljen noben).
    //
    // Uporaba Arguments::new_v1 lahko prevajalniku omogoči, da Formatter::pad izpusti iz izhodne binarne datoteke in prihrani do nekaj kilobajtov.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // potrebno za const-ovrednoteno panics
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // ki ga potrebuje codegen za panic pri dostopu do OOB array/slice
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Osnovna izvedba makra `panic!` mapa libcore pri uporabi formatiranja.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // OPOMBA Ta funkcija nikoli ne prestopi meje FFI;gre za klic Rust-to-Rust, ki se razreši na funkcijo `#[panic_handler]`.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // VARNOST: `panic_impl` je definiran v varni kodi Rust in je tako varen za klic.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Notranja funkcija za makre `assert_eq!` in `assert_ne!`
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}