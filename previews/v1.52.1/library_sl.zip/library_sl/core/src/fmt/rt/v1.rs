//! To je interni modul, ki ga uporablja ifmt!čas izvajanja.Te strukture se predčasno oddajo v statična polja v predkompilirane nize formatov.
//!
//! Te definicije so podobne njihovim ekvivalentom `ct`, vendar se razlikujejo po tem, da jih je mogoče statično dodeliti in so nekoliko optimizirane za čas izvajanja
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Možne poravnave, ki jih je mogoče zahtevati kot del direktive o oblikovanju.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Oznaka, da mora biti vsebina poravnana levo.
    Left,
    /// Oznaka, da mora biti vsebina poravnana desno.
    Right,
    /// Oznaka, da mora biti vsebina poravnana po sredini.
    Center,
    /// Poravnava ni bila zahtevana.
    Unknown,
}

/// Uporabljajo ga specifikatorji [width](https://doc.rust-lang.org/std/fmt/#width) in [precision](https://doc.rust-lang.org/std/fmt/#precision).
#[derive(Copy, Clone)]
pub enum Count {
    /// Navedeno z dobesedno številko, shrani vrednost
    Is(usize),
    /// Navedeno s sintaksama `$` in `*`, indeks shrani v `args`
    Param(usize),
    /// Ni določeno
    Implied,
}