//! Pretvorbe znakov.

use crate::convert::TryFrom;
use crate::fmt;
use crate::mem::transmute;
use crate::str::FromStr;

use super::MAX;

/// Pretvori `u32` v `char`.
///
/// Upoštevajte, da so vsi [`char`] s veljavni [`u32`] s in jih lahko predvajate z enim s
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Vendar obratno ni res: niso vsi veljavni [`u32`] s veljavni [`char`] s.
/// `from_u32()` vrne `None`, če vnos ni veljavna vrednost za [`char`].
///
/// Za nevarno različico te funkcije, ki prezre ta preverjanja, glejte [`from_u32_unchecked`].
///
///
/// # Examples
///
/// Osnovna uporaba:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x2764);
///
/// assert_eq!(Some('❤'), c);
/// ```
///
/// Vrnitev `None`, če vnos ni veljaven [`char`]:
///
/// ```
/// use std::char;
///
/// let c = char::from_u32(0x110000);
///
/// assert_eq!(None, c);
/// ```
///
#[doc(alias = "chr")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_u32(i: u32) -> Option<char> {
    char::try_from(i).ok()
}

/// Pretvori `u32` v `char`, pri čemer ne upošteva veljavnosti.
///
/// Upoštevajte, da so vsi [`char`] s veljavni [`u32`] s in jih lahko predvajate z enim s
/// `as`:
///
/// ```
/// let c = '💯';
/// let i = c as u32;
///
/// assert_eq!(128175, i);
/// ```
///
/// Vendar obratno ni res: niso vsi veljavni [`u32`] s veljavni [`char`] s.
/// `from_u32_unchecked()` bo to prezrl in slepo predvajal na [`char`], kar bo morda ustvarilo neveljavnega.
///
///
/// # Safety
///
/// Ta funkcija ni varna, saj lahko ustvari neveljavne vrednosti `char`.
///
/// Za varno različico te funkcije glejte funkcijo [`from_u32`].
///
/// # Examples
///
/// Osnovna uporaba:
///
/// ```
/// use std::char;
///
/// let c = unsafe { char::from_u32_unchecked(0x2764) };
///
/// assert_eq!('❤', c);
/// ```
#[inline]
#[stable(feature = "char_from_unchecked", since = "1.5.0")]
pub unsafe fn from_u32_unchecked(i: u32) -> char {
    // VARNOST: klicatelj mora zagotoviti, da je `i` veljavna vrednost znaka.
    if cfg!(debug_assertions) { char::from_u32(i).unwrap() } else { unsafe { transmute(i) } }
}

#[stable(feature = "char_convert", since = "1.13.0")]
impl From<char> for u32 {
    /// Pretvori [`char`] v [`u32`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = 'c';
    /// let u = u32::from(c);
    /// assert!(4 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        c as u32
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u64 {
    /// Pretvori [`char`] v [`u64`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '👤';
    /// let u = u64::from(c);
    /// assert!(8 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Znak se ulije na vrednost kodne točke, nato pa se nič podaljša na 64 bitov.
        // Glejte [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u64
    }
}

#[stable(feature = "more_char_conversions", since = "1.51.0")]
impl From<char> for u128 {
    /// Pretvori [`char`] v [`u128`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let c = '⚙';
    /// let u = u128::from(c);
    /// assert!(16 == mem::size_of_val(&u))
    /// ```
    #[inline]
    fn from(c: char) -> Self {
        // Znak se ulije na vrednost kodne točke, nato pa se nič podaljša na 128 bitov.
        // Glejte [https://doc.rust-lang.org/reference/expressions/operator-expr.html#semantics]
        c as u128
    }
}

/// Preslikava bajt v 0x00 ..=0xFF v `char`, katerega kodna točka ima enako vrednost, v U + 0000 ..=U + 00FF.
///
/// Unicode je zasnovan tako, da ta učinkovito dekodira bajte s kodiranjem znakov, ki ga IANA pokliče ISO-8859-1.
/// To kodiranje je združljivo z ASCII.
///
/// Upoštevajte, da se to razlikuje od ISO/IEC 8859-1 aka
/// ISO 8859-1 (z enim vezajem manj), ki pušča nekaj "blanks", bajtnih vrednosti, ki niso dodeljene nobenemu znaku.
/// ISO-8859-1 (IANA) jih dodeli nadzornim kodam C0 in C1.
///
/// Upoštevajte, da se to *tudi* razlikuje od Windows-1252 aka
/// kodna stran 1252, ki je nadnabor ISO/IEC 8859-1, ki ločilom in različnim latiničnim znakom dodeli nekaj (ne vseh!) praznih mest.
///
/// Da bi stvari še bolj zmedli, so [on the Web](https://encoding.spec.whatwg.org/) `ascii`, `iso-8859-1` in `windows-1252` vzdevki za nadnabor sistema Windows-1252, ki preostala prazna mesta zapolni z ustreznimi nadzornimi kodami C0 in C1.
///
///
///
///
///
#[stable(feature = "char_convert", since = "1.13.0")]
impl From<u8> for char {
    /// Pretvori [`u8`] v [`char`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::mem;
    ///
    /// let u = 32 as u8;
    /// let c = char::from(u);
    /// assert!(4 == mem::size_of_val(&c))
    /// ```
    #[inline]
    fn from(i: u8) -> Self {
        i as char
    }
}

/// Napaka, ki jo je mogoče vrniti pri razčlenjevanju znaka.
#[stable(feature = "char_from_str", since = "1.20.0")]
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ParseCharError {
    kind: CharErrorKind,
}

impl ParseCharError {
    #[unstable(
        feature = "char_error_internals",
        reason = "this method should not be available publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            CharErrorKind::EmptyString => "cannot parse char from empty string",
            CharErrorKind::TooManyChars => "too many characters in string",
        }
    }
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum CharErrorKind {
    EmptyString,
    TooManyChars,
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl fmt::Display for ParseCharError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}

#[stable(feature = "char_from_str", since = "1.20.0")]
impl FromStr for char {
    type Err = ParseCharError;

    #[inline]
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let mut chars = s.chars();
        match (chars.next(), chars.next()) {
            (None, _) => Err(ParseCharError { kind: CharErrorKind::EmptyString }),
            (Some(c), None) => Ok(c),
            _ => Err(ParseCharError { kind: CharErrorKind::TooManyChars }),
        }
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl TryFrom<u32> for char {
    type Error = CharTryFromError;

    #[inline]
    fn try_from(i: u32) -> Result<Self, Self::Error> {
        if (i > MAX as u32) || (i >= 0xD800 && i <= 0xDFFF) {
            Err(CharTryFromError(()))
        } else {
            // VARNOST: preverjeno, ali gre za zakonsko vrednost Unicode
            Ok(unsafe { transmute(i) })
        }
    }
}

/// Tip napake se vrne, ko pretvorba iz u32 v char ne uspe.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct CharTryFromError(());

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for CharTryFromError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "converted integer out of range for `char`".fmt(f)
    }
}

/// Pretvori številko v danem radiksu v `char`.
///
/// 'radix' tukaj včasih imenujemo tudi 'base'.
/// Polmer dva označuje binarno število, pol deset, decimalno in pol šestnajstnajstnajstiško, da dobimo nekaj skupnih vrednosti.
///
/// Podprti so samovoljni radiksi.
///
/// `from_digit()` vrne `None`, če vnos ni številka v danem radiksu.
///
/// # Panics
///
/// Panics, če je polmer večji od 36.
///
/// # Examples
///
/// Osnovna uporaba:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(4, 10);
///
/// assert_eq!(Some('4'), c);
///
/// // Decimalno 11 je enomestno v bazi 16
/// let c = char::from_digit(11, 16);
///
/// assert_eq!(Some('b'), c);
/// ```
///
/// Vrnitev `None`, če vnos ni številka:
///
/// ```
/// use std::char;
///
/// let c = char::from_digit(20, 10);
///
/// assert_eq!(None, c);
/// ```
///
/// Mimo velikega radiksa povzroči panic:
///
/// ```should_panic
/// use std::char;
///
/// // this panics
/// let c = char::from_digit(1, 37);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_digit(num: u32, radix: u32) -> Option<char> {
    if radix > 36 {
        panic!("from_digit: radix is too high (maximum 36)");
    }
    if num < radix {
        let num = num as u8;
        if num < 10 { Some((b'0' + num) as char) } else { Some((b'a' + num - 10) as char) }
    } else {
        None
    }
}