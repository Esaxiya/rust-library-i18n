//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Najvišja veljavna kodna točka, ki jo ima `char`.
    ///
    /// `char` je [Unicode Scalar Value], kar pomeni, da gre za [Code Point], vendar le tiste v določenem obsegu.
    /// `MAX` je najvišja veljavna kodna točka, ki je veljaven [Unicode Scalar Value].
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () se v Unicode uporablja kot napaka pri dekodiranju.
    ///
    /// Pojavi se lahko na primer pri podajanju neoblikovanih bajtov UTF-8 [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Različica [Unicode](http://www.unicode.org/), na kateri temeljijo Unicode deli metod `char` in `str`.
    ///
    /// Nove različice Unicode se redno izdajajo in nato se posodobijo vse metode v standardni knjižnici, odvisno od Unicode.
    /// Zato se vedenje nekaterih metod `char` in `str` in vrednost te konstante s časom spreminjata.
    /// To se *ne* šteje za prelomno spremembo.
    ///
    /// Shema oštevilčenja različic je razložena v [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Ustvari iterator nad kodnimi točkami, kodiranimi z UTF-16, v `iter` in vrne neparne nadomestke kot `Err`s.
    ///
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// Dekoder z izgubo lahko dobite z zamenjavo rezultatov `Err` z nadomestnim znakom:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Pretvori `u32` v `char`.
    ///
    /// Upoštevajte, da so vsi znaki veljavni [`u32`] s in jih lahko predvajate z enim
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Vendar obratno ne drži: niso vsi veljavni [`u32`] s veljavni`char`s.
    /// `from_u32()` vrne `None`, če vnos ni veljavna vrednost za `char`.
    ///
    /// Za nevarno različico te funkcije, ki prezre ta preverjanja, glejte [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Vrnitev `None`, če vnos ni veljaven `char`:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Pretvori `u32` v `char`, pri čemer ne upošteva veljavnosti.
    ///
    /// Upoštevajte, da so vsi znaki veljavni [`u32`] s in jih lahko predvajate z enim
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Vendar obratno ne drži: niso vsi veljavni [`u32`] s veljavni`char`s.
    /// `from_u32_unchecked()` bo to prezrl in slepo predvajal na `char`, kar bo morda ustvarilo neveljavnega.
    ///
    ///
    /// # Safety
    ///
    /// Ta funkcija ni varna, saj lahko ustvari neveljavne vrednosti `char`.
    ///
    /// Za varno različico te funkcije glejte funkcijo [`from_u32`].
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // VARNOST: klicatelj mora spoštovati varnostno pogodbo.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Pretvori številko v danem radiksu v `char`.
    ///
    /// 'radix' tukaj včasih imenujemo tudi 'base'.
    /// Polmer dva označuje binarno število, pol deset, decimalno in pol šestnajstnajstnajstiško, da dobimo nekaj skupnih vrednosti.
    ///
    /// Podprti so samovoljni radiksi.
    ///
    /// `from_digit()` vrne `None`, če vnos ni številka v danem radiksu.
    ///
    /// # Panics
    ///
    /// Panics, če je polmer večji od 36.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Decimalno 11 je enomestno v bazi 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Vrnitev `None`, če vnos ni številka:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// Mimo velikega radiksa povzroči panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Preveri, ali je `char` številka v danem radiksu.
    ///
    /// 'radix' tukaj včasih imenujemo tudi 'base'.
    /// Polmer dva označuje binarno število, pol deset, decimalno in pol šestnajstnajstnajstiško, da dobimo nekaj skupnih vrednosti.
    ///
    /// Podprti so samovoljni radiksi.
    ///
    /// V primerjavi z [`is_numeric()`] ta funkcija prepozna samo znake `0-9`, `a-z` in `A-Z`.
    ///
    /// 'Digit' je opredeljen kot samo naslednji znaki:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// Za celovitejše razumevanje 'digit' glejte [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics, če je polmer večji od 36.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// Mimo velikega radiksa povzroči panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Pretvori `char` v številko v danem radiksu.
    ///
    /// 'radix' tukaj včasih imenujemo tudi 'base'.
    /// Polmer dva označuje binarno število, pol deset, decimalno in pol šestnajstnajstnajstiško, da dobimo nekaj skupnih vrednosti.
    ///
    /// Podprti so samovoljni radiksi.
    ///
    /// 'Digit' je opredeljen kot samo naslednji znaki:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Vrne `None`, če se `char` ne nanaša na številko v danem radiksu.
    ///
    /// # Panics
    ///
    /// Panics, če je polmer večji od 36.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// Prenos nedifrenega števila povzroči neuspeh:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// Mimo velikega radiksa povzroči panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // koda je tukaj razdeljena, da se izboljša hitrost izvajanja v primerih, ko je `radix` konstanten in 10 ali manj
        //
        let val = if likely(radix <= 10) {
            // Če ne števka, bo ustvarjena številka, večja od radix.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Vrne iterator, ki daje heksadecimalni pobeg Unicode znaka kot "char".
    ///
    /// To bo ušlo znakom s sintakso Rust oblike `\u{NNNNNN}`, kjer je `NNNNNN` šestnajstiška predstavitev.
    ///
    ///
    /// # Examples
    ///
    /// Kot iterator:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Neposredna uporaba `println!`:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Oba sta enakovredna:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Uporaba `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // or-ing 1 zagotavlja, da za c==0 koda izračuna, da je treba natisniti eno številko in (kar je enako) prepreči (31, 32) podtoka
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // indeks najpomembnejše šestnajstiške številke
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// Razširjena različica `escape_debug`, ki po izbiri dovoljuje uhajanje kodnih točk razširjenega grafema.
    /// To nam omogoča boljše oblikovanje znakov, kot so nerazmične oznake, ko so na začetku niza.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Vrne iterator, ki daje dobesedno ubežno kodo znaka kot `char`s.
    ///
    /// To bo ušlo znakom, podobnim izvedbam `Debug` `str` ali `char`.
    ///
    ///
    /// # Examples
    ///
    /// Kot iterator:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Neposredna uporaba `println!`:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Oba sta enakovredna:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Uporaba `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Vrne iterator, ki daje dobesedno ubežno kodo znaka kot `char`s.
    ///
    /// Privzeto je izbrano s pristranskostjo glede izdelave dobesednih besedil, ki so zakonite v različnih jezikih, vključno z C++ 11 in podobnimi jeziki družine C.
    /// Natančna pravila so:
    ///
    /// * Tab je ubežljiv kot `\t`.
    /// * Vrnitev kočije se uide kot `\r`.
    /// * Dovod v vrstici se umakne kot `\n`.
    /// * Enojna ponudba je zaprta kot `\'`.
    /// * Dvojni narekovaj je ubežljiv kot `\"`.
    /// * Povratna poševnica je ubežala kot `\\`.
    /// * Noben znak v obsegu "natisljiv ASCII" `0x20` .. vključno z `0x7e` ni izognjen.
    /// * Vsi drugi znaki dobijo šestnajstiški pobeg Unicode;glej [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Kot iterator:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Neposredna uporaba `println!`:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Oba sta enakovredna:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Uporaba `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Vrne število bajtov, ki bi ga potreboval `char`, če je kodiran v UTF-8.
    ///
    /// To število bajtov je vedno med 1 in vključno 4.
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// Tip `&str` zagotavlja, da je njegova vsebina UTF-8, zato lahko primerjamo dolžino, ki bi jo potrebovali, če bi bila vsaka kodna točka predstavljena kot `char` v primerjavi s samim `&str`:
    ///
    ///
    /// ```
    /// // kot znaki
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // oba sta lahko predstavljena v obliki treh bajtov
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // kot &str sta ta dva kodirana v UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // vidimo, da skupaj zavzamejo šest bajtov ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... tako kot &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Vrne število 16-bitnih kodnih enot, ki bi jih potreboval `char`, če je kodiran v UTF-16.
    ///
    ///
    /// Za več razlag tega koncepta glejte dokumentacijo za [`len_utf8()`].
    /// Ta funkcija je ogledalo, vendar za UTF-16 namesto za UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Ta znak kodira kot UTF-8 v podani bajtni medpomnilnik in nato vrne podrezo medpomnilnika, ki vsebuje kodiran znak.
    ///
    ///
    /// # Panics
    ///
    /// Panics, če vmesni pomnilnik ni dovolj velik.
    /// Medpomnilnik dolžine štiri je dovolj velik, da kodira kateri koli `char`.
    ///
    /// # Examples
    ///
    /// V obeh primerih 'ß' za kodiranje potrebuje dva bajta.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Premajhen medpomnilnik:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // VARNOST: `char` ni nadomestek, zato je to veljaven UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Ta znak kodira kot UTF-16 v priloženi vmesni pomnilnik `u16` in nato vrne podrezo medpomnilnika, ki vsebuje kodiran znak.
    ///
    ///
    /// # Panics
    ///
    /// Panics, če vmesni pomnilnik ni dovolj velik.
    /// Medpomnilnik dolžine 2 je dovolj velik, da kodira kateri koli `char`.
    ///
    /// # Examples
    ///
    /// V obeh primerih '𝕊' za kodiranje potrebuje dva `u16`.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// Premajhen medpomnilnik:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Vrne `true`, če ima ta `char` lastnost `Alphabetic`.
    ///
    /// `Alphabetic` je opisan v poglavju 4 (Lastnosti znakov) [Unicode Standard] in določen v [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // ljubezen je veliko stvari, vendar ni abecedna
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Vrne `true`, če ima ta `char` lastnost `Lowercase`.
    ///
    /// `Lowercase` je opisan v poglavju 4 (Lastnosti znakov) [Unicode Standard] in določen v [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // Različne kitajske pisave in ločila nimajo velikih in malih črk, zato:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Vrne `true`, če ima ta `char` lastnost `Uppercase`.
    ///
    /// `Uppercase` je opisan v poglavju 4 (Lastnosti znakov) [Unicode Standard] in določen v [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // Različne kitajske pisave in ločila nimajo velikih in malih črk, zato:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Vrne `true`, če ima ta `char` lastnost `White_Space`.
    ///
    /// `White_Space` je določeno v [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // neprekinjen prostor
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Vrne `true`, če ta `char` izpolnjuje [`is_alphabetic()`] ali [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Vrne `true`, če ima ta `char` splošno kategorijo za nadzorne kode.
    ///
    /// Nadzorne kode (kodne točke s splošno kategorijo `Cc`) so opisane v poglavju 4 (Lastnosti znakov) [Unicode Standard] in določene v [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// // U + 009C, STRING TERMINATOR
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Vrne `true`, če ima ta `char` lastnost `Grapheme_Extend`.
    ///
    /// `Grapheme_Extend` je opisan v [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] in določen v [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Vrne `true`, če ima ta `char` eno od splošnih kategorij številk.
    ///
    /// Splošne kategorije za številke (`Nd` za decimalne števke, `Nl` za črkovne številske znake in `No` za druge številske znake) so določene v [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Osnovna uporaba:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Vrne iterator, ki daje preslikavo malih črk tega `char` kot enega ali več
    /// `char`s.
    ///
    /// Če ta `char` nima preslikave z malimi črkami, iterator da isti `char`.
    ///
    /// Če ima ta `char` preslikavo z malimi črkami ena na ena, ki jo poda [Unicode Character Database][ucd] [`UnicodeData.txt`], iterator da ta `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Če ta `char` zahteva posebne premisleke (npr. Več "char"), iterator poda "char" (-e), ki jih poda [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Ta operacija izvede brezpogojno preslikavo brez prilagajanja.To pomeni, da je pretvorba neodvisna od konteksta in jezika.
    ///
    /// V [Unicode Standard] je v poglavju 4 (Lastnosti znakov) razpravljeno o preslikavi primerov na splošno, v poglavju 3 (Conformance) pa o privzetem algoritmu za pretvorbo primerov.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Kot iterator:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Neposredna uporaba `println!`:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Oba sta enakovredna:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Uporaba `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Včasih je rezultat več znakov:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Znaki, ki nimajo velikih in malih črk, se pretvorijo vase.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Vrne iterator, ki daje preslikavo velikih črk tega `char` kot enega ali več
    /// `char`s.
    ///
    /// Če ta `char` nima preslikave velikih črk, iterator da isti `char`.
    ///
    /// Če ima ta `char` preslikavo z velikimi črkami ena na ena, ki jo poda [Unicode Character Database][ucd] [`UnicodeData.txt`], iterator da ta `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Če ta `char` zahteva posebne premisleke (npr. Več "char"), iterator poda "char" (-e), ki jih poda [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Ta operacija izvede brezpogojno preslikavo brez prilagajanja.To pomeni, da je pretvorba neodvisna od konteksta in jezika.
    ///
    /// V [Unicode Standard] je v poglavju 4 (Lastnosti znakov) razpravljeno o preslikavi primerov na splošno, v poglavju 3 (Conformance) pa o privzetem algoritmu za pretvorbo primerov.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Kot iterator:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Neposredna uporaba `println!`:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Oba sta enakovredna:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Uporaba `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Včasih je rezultat več znakov:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Znaki, ki nimajo velikih in malih črk, se pretvorijo vase.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Opomba o jeziku
    ///
    /// V turščini ima ekvivalent 'i' v latinici pet oblik namesto dveh:
    ///
    /// * 'Dotless': I/ı, včasih napisano ï
    /// * 'Dotted': İ/i
    ///
    /// Upoštevajte, da je mala črka 'i' enaka latinici.Zato:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Vrednost `upper_i` se tukaj opira na jezik besedila: če smo v `en-US`, bi moral biti `"I"`, če pa smo v `tr_TR`, bi moral biti `"İ"`.
    /// `to_uppercase()` tega ne upošteva in tako:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// drži v različnih jezikih.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Preveri, ali je vrednost v območju ASCII.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Naredi kopijo vrednosti v ekvivalentu velike črke ASCII.
    ///
    /// Črke ASCII 'a' do 'z' so preslikane v 'A' do 'Z', črke, ki niso ASCII, pa nespremenjene.
    ///
    /// Če želite, da je vrednost na mestu velika, uporabite [`make_ascii_uppercase()`].
    ///
    /// Za velike črke ASCII poleg znakov, ki niso ASCII, uporabite [`to_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Naredi kopijo vrednosti v ekvivalentu male črke ASCII.
    ///
    /// Črke ASCII 'A' do 'Z' so preslikane v 'a' do 'z', črke, ki niso ASCII, pa nespremenjene.
    ///
    /// Če želite, da je vrednost na mestu majhna, uporabite [`make_ascii_lowercase()`].
    ///
    /// Če želite poleg znakov, ki niso ASCII, tudi male znake ASCII, uporabite [`to_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Preveri, ali se dve vrednosti ujemata z velikimi in malimi črkami ASCII.
    ///
    /// Enakovredno `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Pretvori to vrsto v svoj ASCII z velikimi črkami, enakovrednim mestu.
    ///
    /// Črke ASCII 'a' do 'z' so preslikane v 'A' do 'Z', črke, ki niso ASCII, pa nespremenjene.
    ///
    /// Če želite vrniti novo veliko črko, ne da bi spremenili obstoječo, uporabite [`to_ascii_uppercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Pretvori to vrsto v svoj ASCII, ki je enakovreden malim črkam.
    ///
    /// Črke ASCII 'A' do 'Z' so preslikane v 'a' do 'z', črke, ki niso ASCII, pa nespremenjene.
    ///
    /// Če želite vrniti novo majhno vrednost brez spreminjanja obstoječe, uporabite [`to_ascii_lowercase()`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Preveri, ali je vrednost abecedni znak ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', oz
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Preveri, ali je vrednost velika črka ASCII:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Preveri, ali je vrednost mala črka ASCII:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Preveri, ali je vrednost alfanumerični znak ASCII:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z', oz
    /// - U + 0061 'a' ..=U + 007A 'z', oz
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Preveri, ali je vrednost decimalna številka ASCII:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Preveri, ali je vrednost šestnajstiška številka ASCII:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', oz
    /// - U + 0041 'A' ..=U + 0046 'F', oz
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Preveri, ali je vrednost ločilni znak ASCII:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, oz
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, oz
    /// - U + 005B ..=U + 0060 "[\] ^ _` `` ali
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Preveri, ali je vrednost grafični znak ASCII:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Preveri, ali je vrednost presledka ASCII:
    /// U + 0020 PROSTOR, U + 0009 HORIZONTALNA MIZKA, U + 000A LINE FEED, U + 000C OBLIKA FEED ali U + 000D VRAČANJE NOSILCA.
    ///
    /// Rust uporablja WhatWG Infra Standard [definition of ASCII whitespace][infra-aw].Obstaja več drugih opredelitev v široki uporabi.
    /// Na primer, [the POSIX locale][pct] vključuje U + 000B VERTICAL TAB, kot tudi vse zgornje znake, vendar-iz iste specifikacije-[privzeto pravilo za "field splitting" v Bourne shell][bfs] upošteva *samo* SPACE, HORIZONTALNA TABLA in LINE FEED kot presledek.
    ///
    ///
    /// Če pišete program, ki bo obdelal obstoječo obliko datoteke, pred uporabo te funkcije preverite, kakšna je definicija presledka v tej obliki.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Preveri, ali je vrednost kontrolni znak ASCII:
    /// U + 0000 NUL ..=U + 001F SEPARATOR ENOT, ali U + 007F IZBRIŠI.
    /// Upoštevajte, da je večina presledkov ASCII nadzornih znakov, SPACE pa ne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Kodira neobdelano vrednost u32 kot UTF-8 v podani bajtni medpomnilnik in nato vrne podrezo medpomnilnika, ki vsebuje kodiran znak.
///
///
/// Za razliko od `char::encode_utf8` ta metoda obdeluje tudi kodne točke v nadomestnem območju.
/// (Ustvarjanje `char` v nadomestnem območju je UB.) Rezultat je veljaven [generalized UTF-8], vendar ni veljaven UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics, če vmesni pomnilnik ni dovolj velik.
/// Medpomnilnik dolžine štiri je dovolj velik, da kodira kateri koli `char`.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Kodira neobdelano vrednost u32 kot UTF-16 v priloženi vmesni pomnilnik `u16` in nato vrne podrezo medpomnilnika, ki vsebuje kodiran znak.
///
///
/// Za razliko od `char::encode_utf16` ta metoda obdeluje tudi kodne točke v nadomestnem območju.
/// (Ustvarjanje `char` v nadomestnem območju je UB.)
///
/// # Panics
///
/// Panics, če vmesni pomnilnik ni dovolj velik.
/// Medpomnilnik dolžine 2 je dovolj velik, da kodira kateri koli `char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // VARNOST: vsaka roka preveri, ali je dovolj zapisov
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP pade skozi
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Dopolnilna letala se zlomijo v nadomestke.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}