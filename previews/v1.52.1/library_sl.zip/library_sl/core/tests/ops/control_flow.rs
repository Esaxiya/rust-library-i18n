use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // To ni stabilna površina, pomaga pa ohranjati poceni `?` med njimi, tudi če ga LLVM zdaj ne more vedno izkoristiti.
    //
    // (Žal sta rezultat in možnost neskladna, zato se ControlFlow ne more ujemati z obema.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}