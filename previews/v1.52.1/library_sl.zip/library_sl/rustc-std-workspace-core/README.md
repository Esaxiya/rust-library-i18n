# `rustc-std-workspace-core` crate

Ta crate je prazen in prazen crate, ki je preprosto odvisen od `libcore` in ponovno izvozi vso njegovo vsebino.
crate je bistvo opolnomočenja standardne knjižnice, da je odvisna od crates iz crates.io

Crates na crates.io, od katere je odvisna standardna knjižnica, mora biti odvisen od `rustc-std-workspace-core` crate iz crates.io, ki je prazen.

Uporabljamo `[patch]`, da ga v tem odlagališču preglasimo na ta crate.
Kot rezultat bo crates na crates.io narisal odvisnost edge do `libcore`, različico, določeno v tem skladišču.
To bi moralo narisati vse robove odvisnosti, da bi zagotovili, da Cargo uspešno gradi crates!

Upoštevajte, da mora biti crates na crates.io odvisen od tega crate z imenom `core`, da bo vse delovalo pravilno.Za to lahko uporabljajo:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Z uporabo tipke `package` se crate preimenuje v `core`, kar pomeni, da bo videti tako

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

ko Cargo prikliče prevajalnik, ki izpolnjuje implicitno direktivo `extern crate core`, ki jo vbrizga prevajalnik.




