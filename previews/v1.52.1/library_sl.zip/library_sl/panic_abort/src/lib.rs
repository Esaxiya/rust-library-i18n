//! Izvajanje Rust panics s postopkom prekinjeno
//!
//! V primerjavi z izvajanjem z odvijanjem je ta crate *veliko* preprostejši!Kot rečeno, ni tako vsestranski, toda gre!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" koristnega tovora in podložke do ustreznega prekinitve na zadevni platformi.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // pokličite std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // Na Windows uporabite za procesor specifičen mehanizem __fastfail.V različici Windows 8 in novejših bo postopek takoj končal, ne da bi se med izvajanjem izvajali kakršni koli obdelavi izjem.
            // V starejših različicah Windows bo to zaporedje navodil obravnavano kot kršitev dostopa, postopek bo končan, ne da bi nujno zaobšli vse upravljavce izjem.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: to je enaka izvedba kot pri libstdovem `abort_internal`
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// To ... je malo čudno.Tl; dr;je, da je to potrebno za pravilno povezavo, daljša razlaga je spodaj.
//
// Trenutno so vsi binarni elementi libcore/libstd, ki jih dobavljamo, sestavljeni z `-C panic=unwind`.To se naredi, da se zagotovi, da so binarni programi maksimalno združljivi s čim več situacijami.
// Prevajalnik pa zahteva "personality function" za vse funkcije, prevedene z `-C panic=unwind`.Ta osebnostna funkcija je trdo kodirana s simbolom `rust_eh_personality` in je definirana s postavko lang `eh_personality`.
//
// So...
// zakaj ne bi preprosto definirali tega elementa lang tukaj?Dobro vprašanje!Način, na katerega so povezane izvedbe panic, je pravzaprav nekoliko prefinjen, saj so v prevajalnikovi trgovini crate "sort of", vendar dejansko povezani le, če drug ni dejansko povezan.
//
// To pomeni, da se lahko ta crate in panic_unwind crate pojavita v zbirki crate prevajalnika, in če oba določita element jezika `eh_personality`, bo prišlo do napake.
//
// Za obdelavo tega prevajalnik zahteva, da je `eh_personality` definiran samo, če je izvajalno okolje panic, v katerega je povezan, izvajalno okolje odvijanja, sicer pa ga ni treba definirati (upravičeno).
// V tem primeru pa ta knjižnica samo definira ta simbol, tako da je nekje vsaj nekaj osebnosti.
//
// Ta simbol je v bistvu definiran tako, da poveže do binarnih datotek libcore/libstd, vendar ga nikoli ne bi smeli klicati, saj sploh ne povezujemo v odvijalnem času izvajanja.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // Na x86_64-pc-windows-gnu uporabljamo lastno osebnostno funkcijo, ki mora vrniti `ExceptionContinueSearch`, ko prenašamo vse svoje okvire.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Podobno kot zgoraj, to ustreza postavki jezika `eh_catch_typeinfo`, ki se trenutno uporablja samo na Emscripten.
    //
    // Ker panics ne ustvarja izjem, tuje izjeme so trenutno UB z -C panic=abort (čeprav se to lahko spremeni), vsi klici catch_unwind ne bodo nikoli uporabili te informacije.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Ta dva pokličejo naši zagonski predmeti na i686-pc-windows-gnu, vendar jim ni treba storiti ničesar, zato so telesa nops.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}