//! Knjižnica podpore za avtorje makrov pri definiranju novih makrov.
//!
//! Ta knjižnica, ki jo zagotavlja standardna distribucija, zagotavlja tipe, porabljene v vmesnikih postopkovno opredeljenih definicij makrov, kot so funkcijski makri `#[proc_macro]`, atributi makra `#[proc_macro_attribute]` in atributi izpeljave po meri "#[proc_macro_derive]".
//!
//!
//! Za več glejte [the book].
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Določa, ali je bil program proc_macro dostopen trenutno izvajanemu programu.
///
/// Proc_macro crate je namenjen samo uporabi znotraj izvajanja proceduralnih makrov.Vse funkcije v tem crate panic, če jih prikličete zunaj proceduralnega makra, na primer iz skripta gradnje ali preskusa enote ali navadnega binarnega Rust.
///
/// Glede na knjižnice Rust, ki so zasnovane tako, da podpirajo primere uporabe makrov in ne makro, `proc_macro::is_available()` ponuja nepaničen način zaznavanja, ali je infrastruktura, potrebna za uporabo API-ja proc_macro, trenutno na voljo.
/// Vrne true, če je poklican iz notranjosti proceduralnega makra, false, če je poklican iz katerega koli drugega binarnega elementa.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Glavni tip, ki ga zagotavlja ta crate, ki predstavlja abstraktni tok tokens ali natančneje zaporedje dreves token.
/// Tip nudi vmesnike za iteracijo teh dreves token in, nasprotno, zbiranje številnih dreves token v en tok.
///
///
/// To je vhod in izhod definicij `#[proc_macro]`, `#[proc_macro_attribute]` in `#[proc_macro_derive]`.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Napaka vrnjena iz `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Vrne prazen `TokenStream`, ki ne vsebuje dreves token.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Preveri, ali je `TokenStream` prazen.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Poskusi ločiti niz v tokens in razčleniti te tokens v tok token.
/// Morda ne bo uspelo iz več razlogov, na primer, če niz vsebuje neuravnotežene ločila ali znake, ki v jeziku ne obstajajo.
///
/// Vsi tokens v razčlenjenem toku dobijo razpone `Span::call_site()`.
///
/// NOTE: nekatere napake lahko povzročijo panics namesto vrnitve `LexError`.Pridržujemo si pravico, da te napake pozneje spremenimo v "LexError".
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// Opomba: most zagotavlja samo `to_string`, na njem pa implementirajte `fmt::Display` (obratno od običajnega razmerja med njima).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Natisne tok token kot niz, ki naj bi ga bilo mogoče brez konverzij pretvoriti nazaj v isti tok token (modulo razteza), razen morebitnih `TokenTree: : Group`s z ločili `Delimiter::None` in negativnimi številskimi črkami.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Natisne token v obliki, primerni za odpravljanje napak.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Ustvari tok token, ki vsebuje eno drevo token.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Zbere več dreves token v en tok.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// Operacija "flattening" na tokovih token zbira drevesa token iz več tokov token v en tok.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Uporabite optimizirano izvedbo if/when.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Podrobnosti o javni izvedbi za tip `TokenStream`, kot so iteratorji.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Iterator nad `TokenTree`s`TokenStream`.
    /// Ponovitev je "shallow", npr. Iterator se ne ponovi v razmejene skupine in vrne cele skupine kot drevesa token.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` sprejme poljuben tokens in se razširi v `TokenStream`, ki opisuje vhod.
/// Na primer, `quote!(a + b)` ustvari izraz, ki po oceni sestavi `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Ločenje je narejeno z `$` in deluje tako, da se kot naslednji izraz uvrsti ena naslednja ident.
/// Če želite citirati sam `$`, uporabite `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Območje izvorne kode, skupaj z informacijami o razširitvi makra.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Ustvari nov `Diagnostic` z danim `message` v razponu `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Razpon, ki se razreši na mestu z definicijo makra.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Obseg priklica trenutnega postopkovnega makra.
    /// Identifikatorji, ustvarjeni s tem razponom, bodo razrešeni, kot da bi bili napisani neposredno na lokaciji klica makra (higiena mesta klica), druga koda na mestu klica makra pa se bo lahko sklicevala tudi nanje.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Razpon, ki predstavlja higieno `macro_rules` in se včasih razreši na mestu definicije makra (lokalne spremenljivke, nalepke, `$crate`) in včasih na mestu klica makra (vse ostalo).
    ///
    /// Lokacija razpona je vzeta s klicnega mesta.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Izvirna izvorna datoteka, v katero kaže ta razpon.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `Span` za tokens v prejšnji razširitvi makra, iz katere je bil generiran `self`, če sploh.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Obseg izvorne izvorne kode, iz katere je bil ustvarjen `self`.
    /// Če ta `Span` ni bil ustvarjen iz drugih razširitev makra, je vrnjena vrednost enaka `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Pridobi začetni line/column v izvorni datoteki za ta razpon.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Pridobi končni line/column v izvorni datoteki za ta razpon.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Ustvari nov razpon, ki zajema `self` in `other`.
    ///
    /// Vrne `None`, če sta `self` in `other` iz različnih datotek.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Ustvari nov razpon z enakimi informacijami line/column kot `self`, vendar razreši simbole, kot da bi bil v `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Ustvari nov razpon z enakim vedenjem ločljivosti imena kot `self`, vendar z informacijami line/column `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Primerja se z razponi, da se ugotovi, ali so enaki.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Vrne izvorno besedilo za razponom.
    /// To ohrani izvirno izvorno kodo, vključno s presledki in komentarji.
    /// Rezultat vrne le, če razpon ustreza resnični izvorni kodi.
    ///
    /// Note: Opazni rezultat makra se mora zanašati samo na tokens in ne na to izvorno besedilo.
    ///
    /// Rezultat te funkcije je najboljši napor, ki se uporablja samo za diagnostiko.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Natisne razpon v obliki, primerni za odpravljanje napak.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Par črt-stolpec, ki predstavlja začetek ali konec `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Vrstica z indeksom 1 v izvorni datoteki, na kateri se razpon začne ali konča (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Stolpec z indeksom 0 (v znakih UTF-8) v izvorni datoteki, v kateri se razpon začne ali konča (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Izvorna datoteka danega `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Pridobi pot do te izvorne datoteke.
    ///
    /// ### Note
    /// Če je razpon kode, povezan s tem `SourceFile`, ustvaril zunanji makro, ta makro morda ne bo dejanska pot v datotečnem sistemu.
    /// Za preverjanje uporabite [`is_real`].
    ///
    /// Upoštevajte tudi, da tudi če `is_real` vrne `true`, če je bila `--remap-path-prefix` posredovana v ukazni vrstici, podana pot morda dejansko ni veljavna.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Vrne `true`, če je ta izvorna datoteka resnična izvorna datoteka in ni ustvarjena z razširitvijo zunanjega makra.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // To je kramp, dokler se ne izvajajo intercrate spansi in imamo lahko resnične izvorne datoteke za razpone, ustvarjene v zunanjih makroh.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// Posamezen token ali razmejeno zaporedje dreves token (npr. `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Tok token, obdan z ločili oklepajev.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Identifikator.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// En ločilni znak (`+`, `,`, `$` itd.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Dobesedni znak (`'a'`), niz (`"hello"`), številka (`2.3`) itd.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Vrne razpon tega drevesa in prenese na metodo `span` vsebovanega token ali ločenega toka.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Konfigurira razpon za *samo ta token*.
    ///
    /// Če je ta token `Group`, potem ta metoda ne bo konfigurirala razpona vsakega od notranjih tokens, temveč bo preprosto prenesla na metodo `set_span` vsake različice.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Natisne drevo token v obliki, primerni za odpravljanje napak.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Vsak od njih ima ime v vrsti struct v izpeljani odpravljalni napaki, zato se ne obremenjujte z dodatno plastjo indirektnosti
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// Opomba: most zagotavlja samo `to_string`, na njem pa implementirajte `fmt::Display` (obratno od običajnega razmerja med njima).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Natisne drevo token kot niz, ki naj bi ga bilo mogoče brez pretvorb vrniti v isto drevo token (modulo razteza), razen morebitnih `TokenTree: : Group`s z ločili `Delimiter::None` in negativnimi številskimi črkami.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Ločen tok token.
///
/// `Group` notranje vsebuje `TokenStream`, ki je obkrožen z `delilniki`.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Opisuje, kako je razmejeno zaporedje dreves token.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Impliciten ločilo, ki se lahko na primer pojavi okoli tokens, ki prihaja iz "macro variable" `$var`.
    /// Pomembno je ohraniti prednostne naloge operaterjev v primerih, kot je `$var * 3`, kjer je `$var` `1 + 2`.
    /// Implicitna ločila morda ne bodo preživela krožnega potovanja toka token skozi niz.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Ustvari nov `Group` z danim ločevalnikom in tokom token.
    ///
    /// Ta konstruktor bo določil razpon za to skupino na `Span::call_site()`.
    /// Za spremembo razpona lahko uporabite spodnjo metodo `set_span`.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Vrne ločilo tega `Group`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Vrne `TokenStream` tokens, ki so razmejeni v tem `Group`.
    ///
    /// Upoštevajte, da vrnjeni tok token ne vključuje zgornjega vrnilnega ločila.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Vrne razpon ločil tega toka token, ki zajema celoten `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Vrne razpon, ki kaže na začetno ločilo te skupine.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Vrne razpon, ki kaže na zaključno ločilo te skupine.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Konfigurira razpon za ločila te `Skupine`, ne pa tudi za njene notranje tokens.
    ///
    /// Ta metoda **ne** nastavi razpona vseh notranjih tokens, ki jih obsega ta skupina, temveč bo le določila razpon ločila tokens na ravni `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// Opomba: most zagotavlja samo `to_string`, na njem pa implementirajte `fmt::Display` (obratno od običajnega razmerja med njima).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Natisne skupino kot niz, ki bi ga bilo mogoče brez pretvorb vrniti v isto skupino (modulo razteza), razen morebitnih `TokenTree: : Group`s z ločili `Delimiter::None`.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` je en ločilni znak, kot so `+`, `-` ali `#`.
///
/// Večznakovni operaterji, kot je `+=`, so predstavljeni kot dva primerka `Punct` z različnimi oblikami vrnjenih `Spacing`.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Ali `Punct` takoj sledi drug `Punct` ali pa drugi token ali presledki.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// npr. `+` je `Alone` v `+ =`, `+ident` ali `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// npr. `+` je `Joint` v `+=` ali `'#`.
    /// Poleg tega se lahko enojni narekovaj `'` združi z identifikatorji in tvori življenjske dobe `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Ustvari nov `Punct` iz danega znaka in razmika.
    /// Argument `ch` mora biti veljaven ločilni znak, ki ga jezik dovoljuje, sicer bo funkcija panic.
    ///
    /// Vrnjeni `Punct` bo imel privzeti razpon `Span::call_site()`, ki ga je mogoče nadalje konfigurirati s spodnjo metodo `set_span`.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Vrne vrednost tega ločila kot `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Vrne razmik med temi ločili, ki označuje, ali mu takoj sledi drug `Punct` v toku token, tako da jih je mogoče združiti v večznakovni operater (`Joint`), ali mu sledi kak drug token ali presledek (`Alone`), tako da ima operater zagotovo končala.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Vrne razpon za ta ločila.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfigurirajte razpon za ta ločila.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// Opomba: most zagotavlja samo `to_string`, na njem pa implementirajte `fmt::Display` (obratno od običajnega razmerja med njima).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Ločila natisne kot niz, ki bi ga bilo mogoče brez pretvorb izgubiti nazaj v isti znak.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Identifikator (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Ustvari nov `Ident` z danim `string` in navedenim `span`.
    /// Argument `string` mora biti veljaven identifikator, ki ga jezik dovoljuje (vključno s ključnimi besedami, npr. `self` ali `fn`).V nasprotnem primeru bo funkcija panic.
    ///
    /// Upoštevajte, da `span`, ki je trenutno v rustc, konfigurira higienske informacije za ta identifikator.
    ///
    /// Od takrat se `Span::call_site()` izrecno prijavi za higieno "call-site", kar pomeni, da bodo identifikatorji, ustvarjeni s tem razponom, razrešeni, kot da bi bili napisani neposredno na mestu klica makra, druga koda na mestu klica makra pa se bo lahko sklicevala na tudi njih.
    ///
    ///
    /// Kasnejši razponi, kot je `Span::def_site()`, bodo omogočili prijavo v higieno "definition-site", kar pomeni, da bodo identifikatorji, ustvarjeni s tem razponom, razrešeni na mestu definicije makra, druga koda na mestu klica makra pa se nanje ne bo mogla sklicevati.
    ///
    /// Zaradi trenutne pomembnosti higiene ta konstruktor v nasprotju z drugimi tokens zahteva, da se pri gradnji navede `Span`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Enako kot `Ident::new`, vendar ustvari neobdelani identifikator (`r#ident`).
    /// Argument `string` je veljaven identifikator, ki ga jezik dovoljuje (vključno s ključnimi besedami, npr. `fn`).
    /// Ključne besede, ki so uporabne v odsekih poti (npr
    /// `self`, "super") niso podprti in povzročajo panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Vrne razpon tega `Ident`, ki zajema celoten niz, ki ga vrne [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfigurira obseg tega `Ident` in morda spremeni njegov higienski kontekst.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// Opomba: most zagotavlja samo `to_string`, na njem pa implementirajte `fmt::Display` (obratno od običajnega razmerja med njima).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Natisne identifikator kot niz, ki bi ga bilo mogoče brez pretvorb vrniti v isti identifikator.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Dobesedni niz (`"hello"`), bajtni niz (`b"hello"`), znak (`'a'`), bajtni znak (`b'a'`), celo število ali številka s plavajočo vejico s pripono ali brez (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// Logična literala, kot sta `true` in `false`, ne spadata sem, gre za "identitete".
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Ustvari nov priponski celoštevilčni literal z navedeno vrednostjo.
        ///
        /// Ta funkcija bo ustvarila celo število, kot je `1u32`, kjer je navedena celoštevilska vrednost prvi del token in je na koncu tudi pripona integrala.
        /// Dobesedni izrazi, ustvarjeni iz negativnih števil, morda ne bodo preživeli povratnih potovanj skozi `TokenStream` ali nize in jih bodo lahko razdelili na dva tokens (`-` in pozitivno dobesedno).
        ///
        ///
        /// Literali, ustvarjeni s to metodo, imajo privzeto razpon `Span::call_site()`, ki ga je mogoče konfigurirati s spodnjo metodo `set_span`.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Ustvari nov nesifiksni celoštevilčni literal s podano vrednostjo.
        ///
        /// Ta funkcija bo ustvarila celo število, kot je `1`, kjer je navedena celoštevilska vrednost prvi del token.
        /// Na tem token ni podana nobena pripona, kar pomeni, da so klici, kot je `Literal::i8_unsuffixed(1)`, enakovredni `Literal::u32_unsuffixed(1)`.
        /// Dobesedni izrazi, ustvarjeni iz negativnih števil, morda ne bodo preživeli krožnih poti skozi `TokenStream` ali nize in se lahko razdelijo na dva tokens (`-` in pozitivno dobesedno).
        ///
        ///
        /// Literali, ustvarjeni s to metodo, imajo privzeto razpon `Span::call_site()`, ki ga je mogoče konfigurirati s spodnjo metodo `set_span`.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Ustvari novo nesifiksirano dobesedno s plavajočo vejico.
    ///
    /// Ta konstruktor je podoben tistim, kot je `Literal::i8_unsuffixed`, kjer se vrednost float-a odda neposredno v token, vendar ni uporabljena nobena pripona, zato lahko kasneje v prevajalniku sklepamo, da je `f64`.
    ///
    /// Dobesedni izrazi, ustvarjeni iz negativnih števil, morda ne bodo preživeli krožnih poti skozi `TokenStream` ali nize in se lahko razdelijo na dva tokens (`-` in pozitivno dobesedno).
    ///
    /// # Panics
    ///
    /// Ta funkcija zahteva, da je navedeni float končen, na primer, če je neskončnost ali NaN, bo ta funkcija panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Ustvari novo pripono s pripono s plavajočo vejico.
    ///
    /// Ta konstruktor bo ustvaril dobesedno besedilo, kot je `1.0f32`, kjer je navedena vrednost predhodni del token, `f32` pa je pripona token.
    /// Za ta token bo vedno razvidno, da je `f32` v prevajalniku.
    /// Dobesedni izrazi, ustvarjeni iz negativnih števil, morda ne bodo preživeli krožnih poti skozi `TokenStream` ali nize in se lahko razdelijo na dva tokens (`-` in pozitivno dobesedno).
    ///
    ///
    /// # Panics
    ///
    /// Ta funkcija zahteva, da je navedeni float končen, na primer, če je neskončnost ali NaN, bo ta funkcija panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Ustvari novo nesifiksirano dobesedno s plavajočo vejico.
    ///
    /// Ta konstruktor je podoben tistim, kot je `Literal::i8_unsuffixed`, kjer se vrednost float-a odda neposredno v token, vendar ni uporabljena nobena pripona, zato lahko kasneje v prevajalniku sklepamo, da je `f64`.
    ///
    /// Dobesedni izrazi, ustvarjeni iz negativnih števil, morda ne bodo preživeli krožnih poti skozi `TokenStream` ali nize in se lahko razdelijo na dva tokens (`-` in pozitivno dobesedno).
    ///
    /// # Panics
    ///
    /// Ta funkcija zahteva, da je navedeni float končen, na primer, če je neskončnost ali NaN, bo ta funkcija panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Ustvari novo pripono s pripono s plavajočo vejico.
    ///
    /// Ta konstruktor bo ustvaril dobesedno besedilo, kot je `1.0f64`, kjer je navedena vrednost predhodni del token, `f64` pa je pripona token.
    /// Za ta token bo vedno razvidno, da je `f64` v prevajalniku.
    /// Dobesedni izrazi, ustvarjeni iz negativnih števil, morda ne bodo preživeli krožnih poti skozi `TokenStream` ali nize in se lahko razdelijo na dva tokens (`-` in pozitivno dobesedno).
    ///
    ///
    /// # Panics
    ///
    /// Ta funkcija zahteva, da je navedeni float končen, na primer, če je neskončnost ali NaN, bo ta funkcija panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// String dobesedno.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Znak dobeseden.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Dobesedni niz bajtov.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Vrne razpon, ki zajema to dobesedno.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfigurira razpon, povezan s tem dobesednim znakom.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Vrne `Span`, ki je podskupina `self.span()`, ki vsebuje samo izvorne bajte v obsegu `range`.
    /// Vrne `None`, če je potencialno obrezan razpon zunaj meja `self`.
    ///
    // FIXME(SergioBenitez): preverite, ali se obseg bajtov začne in konča na UTF-8 meji vira.
    // v nasprotnem primeru je verjetno, da se bo panic pojavil drugje, ko bo natisnjeno izvorno besedilo.
    // FIXME(SergioBenitez): uporabnik nikakor ne more vedeti, na kaj `self.span()` dejansko preslika, zato je to metodo trenutno mogoče poklicati le slepo.
    // Na primer, `to_string()` za znak 'c' vrne "'\u{63}'";uporabnik nikakor ne more vedeti, ali je bilo izvorno besedilo 'c' ali '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) nekaj podobnega `Option::cloned`, ampak za `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// Opomba: most zagotavlja samo `to_string`, na njem pa implementirajte `fmt::Display` (obratno od običajnega razmerja med njima).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Natisne dobesedno besedilo kot niz, ki bi ga bilo treba brez pretvorb izgubiti nazaj v isto dobesedno (razen možnega zaokroževanja za slovnice s plavajočo vejico).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Dostop do spremenljivk okolja.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Pridobite spremenljivko okolja in jo dodajte, če želite zgraditi informacije o odvisnosti.
    /// Sistem zgradbe, ki izvaja prevajalnik, bo vedel, da je bila spremenljivka dostopna med prevajanjem, in bo lahko znova zgradil, ko se bo vrednost spremenljivke spremenila.
    ///
    /// Poleg sledenja odvisnosti mora biti ta funkcija enakovredna `env::var` iz standardne knjižnice, le da mora biti argument UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}