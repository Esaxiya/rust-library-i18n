// rsbegin.o in rsend.o sta tako imenovani "compiler runtime startup objects".
// Vsebujejo kodo, potrebno za pravilno inicializacijo časa izvajanja prevajalnika.
//
// Ko je povezana izvršljiva slika ali slika dylib, sta med tema dvema objektnima datotekama vsa uporabniška koda in knjižnice "sandwiched", zato koda ali podatki iz rsbegin.o postanejo prvi v ustreznih odsekih slike, medtem ko koda in podatki iz rsend.o postanejo zadnji.
// Ta učinek lahko uporabimo za postavitev simbolov na začetek ali konec odseka, pa tudi za vstavitev zahtevanih glav ali nog.
//
// Upoštevajte, da se dejanska vstopna točka modula nahaja v zagonskem objektu izvajalnega okolja C (običajno imenovanem `crtX.o`), ki nato prikliče povratne klice inicializacije drugih izvajalnih komponent (registriranih prek še enega posebnega odseka slike).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Označuje začetek okvira za odvijanje informacij
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Praskajte prostor za notranje knjigovodstvo odvijalca.
    // To je opredeljeno kot `struct object` v $ GCC/unsind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Odvijte info registration/deregistration rutine.
    // Oglejte si dokumente libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // registrirajte informacije o sprostitvi ob zagonu modula
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // odjavi registracijo ob izklopu
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // Minutna registracija init/uninit za MinGW
    pub mod mingw_init {
        // MinGW-ovi zagonski predmeti (crt0.o/dllcrt0.o) bodo ob zagonu in izhodu poklicali globalne konstruktorje v odsekih .ctors in .dtors.
        // Pri DLL-jih se to naredi, ko se DLL naloži in razloži.
        //
        // Povezovalnik bo razvrstil razdelke, kar zagotavlja, da so naši povratni klici na koncu seznama.
        // Ker se konstruktorji izvajajo v obratnem vrstnem redu, to zagotavlja, da so naši povratni klici prvi in zadnji izvedeni.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: povratni klici inicializacije C
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: povratni klici za zaključek C
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}