// rsbegin.o og rsend.o er den såkaldte "compiler runtime startup objects".
// De indeholder kode, der er nødvendig for korrekt initialisering af kompilatorens kørselstid.
//
// Når et eksekverbart eller dylib-billede er linket, er alle brugerkoder og biblioteker "sandwiched" mellem disse to objektfiler, så kode eller data fra rsbegin.o bliver først i de respektive sektioner af billedet, mens kode og data fra rsend.o bliver de sidste.
// Denne effekt kan bruges til at placere symboler i begyndelsen eller slutningen af en sektion samt til at indsætte de nødvendige sidehoveder eller sidefødder.
//
// Bemærk, at det faktiske modulindgangssted er placeret i C-runtime-startobjektet (normalt kaldet `crtX.o`), som derefter påberåber initialisering af tilbagekald af andre runtime-komponenter (registreret via endnu et specielt billedsektion).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Markerer begyndelsen på stakrammen til at slappe af info
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Skrab plads til afviklerens interne bogføring.
    // Dette er defineret som `struct object` i $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Slap af info registration/deregistration-rutiner.
    // Se dokumenterne fra libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // registrer info om afvikling af modul ved opstart
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // afregistrere ved lukning
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-specifik init/uninit rutinemæssig registrering
    pub mod mingw_init {
        // MinGWs startobjekter (crt0.o/dllcrt0.o) påberåber globale konstruktører i .ctors-og .dtors-sektionerne ved opstart og afslutning.
        // I tilfælde af DLL'er gøres dette, når DLL indlæses og aflæsses.
        //
        // Linkeren vil sortere sektionerne, hvilket sikrer, at vores tilbagekald findes i slutningen af listen.
        // Da konstruktører køres i omvendt rækkefølge, sikrer dette, at vores tilbagekald er de første og sidste, der udføres.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: C initialisering tilbagekald
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: C-tilbagekald ved opsigelse
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}