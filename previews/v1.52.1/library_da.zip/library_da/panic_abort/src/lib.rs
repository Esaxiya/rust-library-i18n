//! Implementering af Rust panics via procesafbrydelser
//!
//! Sammenlignet med implementeringen via afvikling er denne crate *meget* enklere!Når det er sagt, er det ikke helt så alsidigt, men her går!
//!

#![no_std]
#![unstable(feature = "panic_abort", issue = "32837")]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/"
)]
#![panic_runtime]
#![allow(unused_features)]
#![feature(core_intrinsics)]
#![feature(nll)]
#![feature(panic_runtime)]
#![feature(std_internals)]
#![feature(staged_api)]
#![feature(rustc_attrs)]
#![feature(asm)]

use core::any::Any;
use core::panic::BoxMeUp;

#[rustc_std_internal_symbol]
#[allow(improper_ctypes_definitions)]
pub unsafe extern "C" fn __rust_panic_cleanup(_: *mut u8) -> *mut (dyn Any + Send + 'static) {
    unreachable!()
}

// "Leak" nyttelast og shim til den relevante afbrydelse på den pågældende platform.
#[rustc_std_internal_symbol]
pub unsafe extern "C" fn __rust_start_panic(_payload: *mut &mut dyn BoxMeUp) -> u32 {
    abort();

    cfg_if::cfg_if! {
        if #[cfg(unix)] {
            unsafe fn abort() -> ! {
                libc::abort();
            }
        } else if #[cfg(any(target_os = "hermit",
                            all(target_vendor = "fortanix", target_env = "sgx")
        ))] {
            unsafe fn abort() -> ! {
                // ring til std::sys::abort_internal
                extern "C" {
                    pub fn __rust_abort() -> !;
                }
                __rust_abort();
            }
        } else if #[cfg(all(windows, not(miri)))] {
            // På Windows skal du bruge den processorspecifikke __fastfail-mekanisme.I Windows 8 og senere afsluttes processen med det samme uden at køre nogen undtagelsesbehandlere i processen.
            // I tidligere versioner af Windows vil denne sekvens af instruktioner blive behandlet som en adgangsovertrædelse, der afslutter processen, men uden nødvendigvis at omgå alle undtagelsesbehandlere.
            //
            //
            // https://docs.microsoft.com/en-us/cpp/intrinsics/fastfail
            //
            // Note: dette er den samme implementering som i libstds `abort_internal`
            //
            //
            //
            unsafe fn abort() -> ! {
                const FAST_FAIL_FATAL_APP_EXIT: usize = 7;
                cfg_if::cfg_if! {
                    if #[cfg(any(target_arch = "x86", target_arch = "x86_64"))] {
                        asm!("int $$0x29", in("ecx") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(all(target_arch = "arm", target_feature = "thumb-mode"))] {
                        asm!(".inst 0xDEFB", in("r0") FAST_FAIL_FATAL_APP_EXIT);
                    } else if #[cfg(target_arch = "aarch64")] {
                        asm!("brk 0xF003", in("x0") FAST_FAIL_FATAL_APP_EXIT);
                    } else {
                        core::intrinsics::abort();
                    }
                }
                core::intrinsics::unreachable();
            }
        } else {
            unsafe fn abort() -> ! {
                core::intrinsics::abort();
            }
        }
    }
}

// Dette ... er lidt underligt.Tl; dr;er, at dette er nødvendigt for at linke korrekt, den længere forklaring er nedenfor.
//
// Lige nu er binærfiler fra libcore/libstd, som vi sender, alle udarbejdet med `-C panic=unwind`.Dette gøres for at sikre, at binærfiler er maksimalt kompatible med så mange situationer som muligt.
// Compileren kræver dog en "personality function" til alle funktioner, der er kompileret med `-C panic=unwind`.Denne personlighedsfunktion er hårdkodet til symbolet `rust_eh_personality` og defineres af `eh_personality` lang-elementet.
//
// So...
// hvorfor ikke bare definere det lang element her?Godt spørgsmål!Den måde, hvorpå panic-driftstider er forbundet, er faktisk en smule subtil, da de er "sort of" i kompilatorens crate-butik, men kun faktisk linket, hvis en anden ikke faktisk er linket.
//
// Dette ender med at betyde, at både denne crate og panic_unwind crate kan vises i compilerens crate-butik, og hvis begge definerer `eh_personality` lang-elementet, rammer der en fejl.
//
// For at håndtere dette kræver kompilatoren kun, at `eh_personality` er defineret, hvis panic-runtime, der linkes til, er den afviklende runtime, og ellers er det ikke nødvendigt at definere det (med rette).
// I dette tilfælde definerer dette bibliotek imidlertid bare dette symbol, så der er i det mindste en eller anden personlighed.
//
// I det væsentlige er dette symbol netop defineret for at blive kablet op til libcore/libstd-binære filer, men det skal aldrig kaldes, da vi slet ikke forbinder i en afviklende runtime.
//
//
//
//
//
//
//
//
//
//
//
//
pub mod personalities {
    #[rustc_std_internal_symbol]
    #[cfg(not(any(
        all(target_arch = "wasm32", not(target_os = "emscripten"),),
        all(target_os = "windows", target_env = "gnu", target_arch = "x86_64",),
    )))]
    pub extern "C" fn rust_eh_personality() {}

    // På x86_64-pc-windows-gnu bruger vi vores egen personlighedsfunktion, der skal returnere `ExceptionContinueSearch`, når vi videregiver alle vores rammer.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86_64"))]
    pub extern "C" fn rust_eh_personality(
        _record: usize,
        _frame: usize,
        _context: usize,
        _dispatcher: usize,
    ) -> u32 {
        1 // `ExceptionContinueSearch`
    }

    // Svarende til ovenstående svarer det til `eh_catch_typeinfo` lang-emnet, der kun bruges på Emscripten i øjeblikket.
    //
    // Da panics ikke genererer undtagelser, og udenlandske undtagelser i øjeblikket er UB med -C panic=afbrudt (selvom dette kan ændres), vil alle catch_unwind-opkald aldrig bruge denne typeinfo.
    //
    //
    //
    #[rustc_std_internal_symbol]
    #[allow(non_upper_case_globals)]
    #[cfg(target_os = "emscripten")]
    static rust_eh_catch_typeinfo: [usize; 2] = [0; 2];

    // Disse to kaldes af vores startobjekter på i686-pc-windows-gnu, men de behøver ikke gøre noget, så ligene er nops.
    //
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_register_frames() {}
    #[rustc_std_internal_symbol]
    #[cfg(all(target_os = "windows", target_env = "gnu", target_arch = "x86"))]
    pub extern "C" fn rust_eh_unregister_frames() {}
}