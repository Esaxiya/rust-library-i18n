`core::arch` - Rust's kernebiblioteksarkitektur-specifikke iboende egenskaber
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

`core::arch`-modulet implementerer arkitekturafhængig iboende egenskaber (f.eks. SIMD).

# Usage 

`core::arch` er tilgængelig som en del af `libcore`, og den eksporteres igen af `libstd`.Foretrækker at bruge det via `core::arch` eller `std::arch` end via denne crate.
Ustabile funktioner er ofte tilgængelige i Rust om natten via `feature(stdsimd)`.

Brug af `core::arch` via denne crate kræver Rust om natten, og det kan (og gør) ofte bryde.De eneste tilfælde, hvor du bør overveje at bruge det via denne crate, er:

* hvis du har brug for at kompilere `core::arch` selv, f.eks. med bestemte målfunktioner aktiveret, der ikke er aktiveret til `libcore`/`libstd`.
Note: Hvis du har brug for at kompilere det igen til et ikke-standardmål, bedes du bruge `xargo` og re-kompilere `libcore`/`libstd` efter behov i stedet for at bruge denne crate.
  
* ved hjælp af nogle funktioner, der muligvis ikke er tilgængelige selv bag ustabile Rust-funktioner.Vi prøver at holde disse på et minimum.
Hvis du har brug for nogle af disse funktioner, skal du åbne et problem, så vi kan udsætte dem i Rust om natten, og du kan bruge dem derfra.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` distribueres primært under vilkårene for både MIT-licensen og Apache-licensen (version 2.0) med dele dækket af forskellige BSD-lignende licenser.

Se LICENSE-APACHE og LICENSE-MIT for detaljer.

# Contribution

Medmindre du udtrykkeligt angiver andet, skal ethvert bidrag med vilje indsendt til optagelse i `core_arch` af dig, som defineret i Apache-2.0-licensen, være dobbelt licenseret som ovenfor uden yderligere vilkår eller betingelser.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












