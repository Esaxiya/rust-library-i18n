use std::env;

fn main() {
    println!("cargo:rustc-cfg=core_arch_docs");

    // Bruges til at fortælle vores `#[assert_instr]`-kommentarer, at alle simd-iboende egenskaber er tilgængelige for at teste deres kodegen, da nogle er lukket bag en ekstra `-Ctarget-feature=+unimplemented-simd128`, der ikke har noget tilsvarende i `#[target_feature]` lige nu.
    //
    //
    //
    println!("cargo:rerun-if-env-changed=RUSTFLAGS");
    if env::var("RUSTFLAGS")
        .unwrap_or_default()
        .contains("unimplemented-simd128")
    {
        println!("cargo:rustc-cfg=all_simd");
    }
}