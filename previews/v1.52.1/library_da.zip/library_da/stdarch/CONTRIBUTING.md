# Bidrager til stdarch

`stdarch` crate er mere end villig til at acceptere bidrag!Først vil du sandsynligvis tjekke lageret og sørge for, at testene passerer dig:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Hvor `<your-target-arch>` er målet tredobbelt som brugt af `rustup`, f.eks. `x86_x64-unknown-linux-gnu` (uden nogen foregående `nightly-` eller lignende).
Husk også, at dette arkiv kræver Rust's natlige kanal!
Ovenstående tests kræver faktisk, at rust om natten er standard på dit system, for at indstille den brug `rustup default nightly` (og `rustup default stable` til at vende tilbage).

Hvis et af ovenstående trin ikke virker, [please let us know][new]!

Derefter kan du [find an issue][issues] for at hjælpe med, vi har valgt et par med [`help wanted`][help]-og [`impl-period`][impl]-tags, som især kunne bruge lidt hjælp. 
Du er muligvis mest interesseret i [#40][vendor] og implementerer al leverandørens egenart på x86.Det emne har nogle gode råd om, hvor man kan komme i gang!

Hvis du har generelle spørgsmål, er du velkommen til [join us on gitter][gitter] og spørg rundt!Du er velkommen til at pinge enten@BurntSushi eller@alexcrichton med spørgsmål.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Sådan skriver du eksempler på stdarch-iboende egenskaber

Der er et par funktioner, der skal være aktiveret for at den givne indre funktion kan fungere korrekt, og eksemplet skal kun køres af `cargo test --doc`, når funktionen understøttes af CPU'en.

Som et resultat fungerer standard `fn main`, der genereres af `rustdoc`, ikke (i de fleste tilfælde).
Overvej at bruge følgende som en guide for at sikre, at dit eksempel fungerer som forventet.

```rust
/// # // Vi har brug for cfg_target_feature for at sikre, at eksemplet kun er
/// # // køres af `cargo test --doc`, når CPU'en understøtter funktionen
/// # #![feature(cfg_target_feature)]
/// # // Vi har brug for target_feature for at det indre kan arbejde
/// # #![feature(target_feature)]
/// #
/// # // rustdoc bruger som standard `extern crate stdarch`, men vi har brug for
/// # // `#[macro_use]`
/// # # [makrobrug] ekstern crate stdarch;
/// #
/// # // Den virkelige hovedfunktion
/// # fn main() {
/// #     // Kør kun dette, hvis `<target feature>` understøttes
/// #     hvis cfg_feature_enabled! ("<target feature>"){
/// #         // Opret en `worker`-funktion, der kun køres, hvis målfunktionen
/// #         // understøttes og sørg for, at `target_feature` er aktiveret for din medarbejder
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         usikre fn worker() {
/// // Skriv dit eksempel her.Funktionsspecifikke iboende egenskaber fungerer her!Gå vild!
///
/// #         }
///
/// #         usikre { worker(); }
/// #     }
/// # }
```

Hvis nogle af ovenstående syntaks ikke ser velkendte ud, beskriver [Documentation as tests]-sektionen i [Rust Book] `rustdoc`-syntaksen ganske godt.
Som altid, er du velkommen til [join us on gitter][gitter] og spørg os, hvis du rammer noget, og tak fordi du hjælper med at forbedre dokumentationen til `stdarch`!

# Alternative testinstruktioner

Det anbefales generelt, at du bruger `ci/run.sh` til at køre testene.
Dette fungerer muligvis ikke for dig, f.eks. Hvis du er på Windows.

I så fald kan du falde tilbage til at køre `cargo +nightly test` og `cargo +nightly test --release -p core_arch` til test af kodegenerering.
Bemærk, at disse kræver, at værktøjskæden om natten installeres, og at `rustc` skal vide om din mål-triple og dens CPU.
Især skal du indstille miljøvariablen `TARGET`, som du ville gøre for `ci/run.sh`.
Derudover skal du indstille `RUSTCFLAGS` (har brug for `C`) for at angive målfunktioner, f.eks `RUSTCFLAGS="-C -target-features=+avx2"`.
Du kan også indstille `-C -target-cpu=native`, hvis du udvikler "just" mod din nuværende CPU.

Vær advaret om, at når du bruger disse alternative instruktioner, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], f.eks
instruktionsgenereringstest kan mislykkes, fordi disassembleren navngav dem anderledes, f.eks
det kan generere `vaesenc` i stedet for `aesenc` instruktioner, selvom de opfører sig det samme.
Disse instruktioner udfører også færre tests, end normalt ville være gjort, så vær ikke overrasket over, at når du til sidst trækker anmodning, kan der opstå nogle fejl til tests, der ikke er dækket her.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






