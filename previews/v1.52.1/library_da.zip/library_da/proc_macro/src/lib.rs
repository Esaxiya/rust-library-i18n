//! Et supportbibliotek til makroforfattere, når nye makroer defineres.
//!
//! Dette bibliotek, leveret af standardfordelingen, giver de typer, der forbruges i grænsefladerne for proceduremæssigt definerede makrodefinitioner såsom funktionslignende makroer `#[proc_macro]`, makroattributter `#[proc_macro_attribute]` og brugerdefinerede afledningsattributter '#[proc_macro_derive] `.
//!
//!
//! Se [the book] for mere.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Bestemmer, om proc_macro er gjort tilgængeligt for det aktuelt kørende program.
///
/// Proc_macro crate er kun beregnet til brug inden for implementeringen af proceduremakroer.Alle funktionerne i denne crate panic, hvis de påberåbes uden for en proceduremakro, f.eks. Fra et build-script eller en enhedstest eller almindelig Rust-binær.
///
/// Under hensyntagen til Rust-biblioteker, der er designet til at understøtte både makro-og ikke-makro-anvendelsessager, giver `proc_macro::is_available()` en ikke-panik-måde at opdage, om den nødvendige infrastruktur til at bruge API'en til proc_macro i øjeblikket er tilgængelig.
/// Returnerer sandt, hvis det påberåbes inde fra en proceduremakro, falsk, hvis det påberåbes fra en anden binær.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Hovedtypen leveret af denne crate, der repræsenterer en abstrakt strøm af tokens, eller mere specifikt en sekvens af token træer.
/// Typen giver grænseflader til iterering over disse token træer og omvendt, indsamling af et antal token træer i en strøm.
///
///
/// Dette er både input og output af `#[proc_macro]`, `#[proc_macro_attribute]` og `#[proc_macro_derive]` definitioner.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Fejl returneret fra `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Returnerer en tom `TokenStream`, der ikke indeholder token træer.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Kontrollerer, om denne `TokenStream` er tom.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Forsøg på at bryde strengen i tokens og analysere disse tokens i en token stream.
/// Kan mislykkes af en række årsager, for eksempel hvis strengen indeholder ubalancerede afgrænsere eller tegn, der ikke findes på sproget.
///
/// Alle tokens i den analyserede strøm får `Span::call_site()`-spændinger.
///
/// NOTE: nogle fejl kan forårsage panics i stedet for at returnere `LexError`.Vi forbeholder os ret til at ændre disse fejl til `LexError`s senere.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, broen leverer kun `to_string`, implementer `fmt::Display` baseret på den (det modsatte af det sædvanlige forhold mellem de to).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Udskriver token-strømmen som en streng, der formodes at være tabsfrit konverterbar tilbage til den samme token-stream (modulo spænder), bortset fra muligvis 'TokenTree: : Group`s med `Delimiter::None`-afgrænsere og negative numeriske bogstaver.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Udskriver token i en form, der er praktisk til debugging.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Opretter en token-stream, der indeholder et enkelt token-træ.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Samler et antal token træer i en enkelt strøm.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// En "flattening"-operation på token-streams samler token-træer fra flere token-streams til en enkelt stream.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Brug en optimeret implementering if/when mulig.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Offentlige implementeringsoplysninger for `TokenStream`-typen, såsom iteratorer.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// En iterator over `TokenStream`s`TokenTree`s.
    /// Iterationen er "shallow", f.eks. Gentages iteratoren ikke i afgrænsede grupper og returnerer hele grupper som token træer.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` accepterer vilkårlig tokens og udvides til en `TokenStream`, der beskriver input.
/// For eksempel vil `quote!(a + b)` producere et udtryk, der, når det evalueres, konstruerer `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Unquoting udføres med `$` og fungerer ved at tage den næste næste ident som den ikke-citerede betegnelse.
/// For at citere `$` i sig selv skal du bruge `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// En region med kildekode sammen med makroudvidelsesoplysninger.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Opretter en ny `Diagnostic` med den givne `message` i intervallet `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Et spændvidde, der løses på makrodefinitionsstedet.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Omfanget af påkaldelsen af den nuværende proceduremakro.
    /// Identifikatorer oprettet med dette interval løses, som om de blev skrevet direkte på makroopkaldsstedet (opkaldsstedshygiejne), og anden kode på makroopkaldsstedet vil også kunne henvise til dem.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Et span, der repræsenterer `macro_rules` hygiejne, og sommetider løses på makrodefinitionsstedet (lokale variabler, etiketter, `$crate`) og undertiden på makroopkaldsstedet (alt andet).
    ///
    /// Spændplaceringen er taget fra opkaldsstedet.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Den oprindelige kildefil, som dette span peger i.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// `Span` til tokens i den tidligere makroudvidelse, hvorfra `self` blev genereret fra, hvis nogen.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Spændvidden for den oprindelige kildekode, som `self` blev genereret fra.
    /// Hvis denne `Span` ikke blev genereret fra andre makroudvidelser, er returværdien den samme som `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Får start-line/column i kildefilen til dette span.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Henter slutningen af line/column i kildefilen til dette span.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Opretter et nyt span, der omfatter `self` og `other`.
    ///
    /// Returnerer `None`, hvis `self` og `other` er fra forskellige filer.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Opretter et nyt interval med de samme line/column-oplysninger som `self`, men det løser symboler, som om de var ved `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Opretter et nyt span med samme opløsningsadfærd som `self`, men med line/column-oplysningerne fra `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Sammenligner med spænd for at se, om de er lige.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Returnerer kildeteksten bag et interval.
    /// Dette bevarer den oprindelige kildekode, inklusive mellemrum og kommentarer.
    /// Det returnerer kun et resultat, hvis spændvidden svarer til den reelle kildekode.
    ///
    /// Note: Det observerbare resultat af en makro skal kun stole på tokens og ikke på denne kildetekst.
    ///
    /// Resultatet af denne funktion er den bedste indsats, der kun skal bruges til diagnostik.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Udskriver et span i en form, der er praktisk til debugging.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Et linjesøjlepar, der repræsenterer starten eller slutningen af en `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Den 1-indekserede linje i kildefilen, hvor spændvidden starter eller slutter (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Den 0-indekserede kolonne (i UTF-8 tegn) i kildefilen, hvor spændvidden starter eller slutter (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Kildefilen til en given `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Henter stien til denne kildefil.
    ///
    /// ### Note
    /// Hvis kodespændet, der er knyttet til denne `SourceFile`, blev genereret af en ekstern makro, er denne makro muligvis ikke en egentlig sti på filsystemet.
    /// Brug [`is_real`] til at kontrollere.
    ///
    /// Bemærk også, at selvom `is_real` returnerer `true`, hvis `--remap-path-prefix` blev sendt på kommandolinjen, er stien som angivet muligvis ikke gyldig.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Returnerer `true`, hvis denne kildefil er en rigtig kildefil og ikke genereres af en ekstern makros udvidelse.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Dette er et hack, indtil intervaller mellem intervaller er implementeret, og vi kan have ægte kildefiler til spænd, der genereres i eksterne makroer.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// En enkelt token eller en afgrænset sekvens af token træer (f.eks. `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// En token-stream omgivet af parentesafgrænsere.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// En identifikator.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Et enkelt tegnsætningstegn (`+`, `,`, `$` osv.).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// En bogstavelig karakter (`'a'`), streng (`"hello"`), nummer (`2.3`) osv.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Returnerer rækkevidden for dette træ, delegeret til `span`-metoden for den indeholdte token eller en afgrænset stream.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Konfigurerer spændingen for *kun denne token*.
    ///
    /// Bemærk, at hvis denne token er en `Group`, konfigurerer denne metode ikke spændvidden for hver af de interne tokens, dette delegeres simpelthen til `set_span`-metoden for hver variant.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Udskriver token-træ i en form, der er praktisk til fejlfinding.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Hver af disse har navnet i strukturtypen i den afledte fejlretning, så gider ikke et ekstra lag af retning
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, broen leverer kun `to_string`, implementer `fmt::Display` baseret på den (det modsatte af det sædvanlige forhold mellem de to).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Udskriver token-træet som en streng, der formodes at være tabsfrit konvertibelt tilbage til det samme token-træ (modulo spænder), bortset fra muligvis `TokenTree: : Group`s med `Delimiter::None` afgrænsere og negative numeriske bogstaver.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// En afgrænset token-stream.
///
/// En `Group` indeholder internt en `TokenStream`, der er omgivet af 'Afgrænser`s.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Beskriver, hvordan en sekvens af token træer afgrænses.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// En implicit afgrænsning, der f.eks. Kan vises omkring tokens, der kommer fra en "macro variable" `$var`.
    /// Det er vigtigt at bevare operatørprioriteter i tilfælde som `$var * 3`, hvor `$var` er `1 + 2`.
    /// Implicitte afgrænsere overlever muligvis ikke returflyvning af en token-stream gennem en streng.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Opretter en ny `Group` med den givne afgrænser og token stream.
    ///
    /// Denne konstruktør indstiller spændvidden for denne gruppe til `Span::call_site()`.
    /// For at ændre spændet kan du bruge `set_span`-metoden nedenfor.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Returnerer afgrænsningen af denne `Group`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Returnerer `TokenStream` af tokens, der er afgrænset i denne `Group`.
    ///
    /// Bemærk, at den returnerede token-strøm ikke inkluderer skillelinjen, der er returneret ovenfor.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Returnerer intervallet for afgrænsningerne for denne token-strøm, der spænder over hele `Group`.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Returnerer spændvidde, der peger på åbningsafgrænseren for denne gruppe.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Returnerer spændvidden, der peger på den afsluttende afgrænser for denne gruppe.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Konfigurerer spændvidden for denne `gruppe`s afgrænsning, men ikke dens interne tokens.
    ///
    /// Denne metode **indstiller ikke** spændvidden for alle de interne tokens, der er spændt af denne gruppe, men snarere indstiller den kun spændingen for afgrænser tokens på niveauet for `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, broen leverer kun `to_string`, implementer `fmt::Display` baseret på den (det modsatte af det sædvanlige forhold mellem de to).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Udskriver gruppen som en streng, der tabsfrit kan konverteres tilbage til den samme gruppe (modulo-spænd), bortset fra muligvis 'TokenTree: : Group`s med `Delimiter::None`-afgrænsere.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// En `Punct` er et enkelt tegnsætningstegn som `+`, `-` eller `#`.
///
/// Multi-karakter operatører som `+=` er repræsenteret som to forekomster af `Punct` med forskellige former for `Spacing` returneret.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Uanset om en `Punct` følges straks af en anden `Punct` eller efterfølges af en anden token eller et hvidt mellemrum.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// f.eks. er `+` `Alone` i `+ =`, `+ident` eller `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// f.eks. er `+` `Joint` i `+=` eller `'#`.
    /// Derudover kan enkelt citat `'` slutte sig til identifikatorer for at danne livstid `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Opretter en ny `Punct` fra det givne tegn og afstand.
    /// `ch`-argumentet skal være et gyldigt tegnsætningstegn, der er tilladt af sproget, ellers vil funktionen panic.
    ///
    /// Den returnerede `Punct` har standardområdet `Span::call_site()`, som kan konfigureres yderligere med `set_span`-metoden nedenfor.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Returnerer værdien af dette tegnsætningstegn som `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Returnerer afstanden for dette tegnsætningstegn, hvilket indikerer, om det straks efterfølges af en anden `Punct` i token-strømmen, så de potentielt kan kombineres til en multi-karakter-operator (`Joint`), eller efterfulgt af et andet token eller hvidt mellemrum (`Alone`), så operatøren helt sikkert sluttede.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Returnerer spændvidden for dette tegnsætningstegn.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfigurer spændvidden for dette tegnsætningstegn.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, broen leverer kun `to_string`, implementer `fmt::Display` baseret på den (det modsatte af det sædvanlige forhold mellem de to).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Udskriver tegnsætningstegn som en streng, der tabsfrit kan konverteres tilbage til det samme tegn.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// En identifikator (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Opretter en ny `Ident` med den givne `string` samt den specificerede `span`.
    /// `string`-argumentet skal være en gyldig identifikator, der er tilladt af sproget (inklusive nøgleord, f.eks. `self` eller `fn`).Ellers vil funktionen panic.
    ///
    /// Bemærk, at `span`, der i øjeblikket er i rustc, konfigurerer hygiejneoplysningerne til denne identifikator.
    ///
    /// På dette tidspunkt vælger `Span::call_site()` eksplicit til "call-site" hygiejne, hvilket betyder, at identifikatorer oprettet med dette span løses som om de blev skrevet direkte på stedet for makroopkaldet, og anden kode på makroopkaldsstedet vil være i stand til at henvise til dem også.
    ///
    ///
    /// Senere spændinger som `Span::def_site()` giver mulighed for at tilmelde sig "definition-site" hygiejne, hvilket betyder, at identifikatorer oprettet med dette span løses ved placeringen af makrodefinitionen, og anden kode på webstedet for makroopkald vil ikke være i stand til at henvise til dem.
    ///
    /// På grund af hygiejnes nuværende betydning kræver denne konstruktør, i modsætning til andre tokens, at en `Span` skal specificeres ved konstruktion.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Samme som `Ident::new`, men opretter en rå identifikator (`r#ident`).
    /// `string`-argumentet er en gyldig identifikator, der er tilladt af sproget (inklusive nøgleord, f.eks. `fn`).
    /// Nøgleord, der kan bruges i stisegmenter (f.eks
    /// `self`, `super`) understøttes ikke og vil forårsage en panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Returnerer spændvidden for denne `Ident`, der omfatter hele strengen, der returneres af [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfigurerer rækkevidden af denne `Ident` og muligvis ændrer dens hygiejnekontekst.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, broen leverer kun `to_string`, implementer `fmt::Display` baseret på den (det modsatte af det sædvanlige forhold mellem de to).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Udskriver identifikatoren som en streng, der tabsfrit kan konverteres tilbage til den samme identifikator.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// En bogstavstreng (`"hello"`), byte-streng (`b"hello"`), karakter (`'a'`), byte-karakter (`b'a'`), et heltal eller flydende nummer med eller uden et suffiks (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// Boolske bogstaver som `true` og `false` hører ikke hjemme her, de er `Ident`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Opretter et nyt efterfulgt heltal bogstaveligt med den angivne værdi.
        ///
        /// Denne funktion opretter et heltal som `1u32`, hvor det angivne heltalsværdi er den første del af token, og integralet også er suffikset i slutningen.
        /// Litteratur oprettet ud fra negative tal overlever muligvis ikke returrejser gennem `TokenStream` eller strenge og kan opdeles i to tokens (`-` og positive bogstaver).
        ///
        ///
        /// Litteratur oprettet ved hjælp af denne metode har `Span::call_site()`-spændet som standard, som kan konfigureres med `set_span`-metoden nedenfor.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Opretter et nyt ikke-tilføjet heltal bogstaveligt med den angivne værdi.
        ///
        /// Denne funktion opretter et heltal som `1`, hvor det angivne heltalsværdi er den første del af token.
        /// Intet suffiks er specificeret på denne token, hvilket betyder at påkald som `Literal::i8_unsuffixed(1)` svarer til `Literal::u32_unsuffixed(1)`.
        /// Litteratur oprettet ud fra negative tal overlever muligvis ikke rountrips gennem `TokenStream` eller strenge og kan opdeles i to tokens (`-` og positive bogstavelige).
        ///
        ///
        /// Litteratur oprettet ved hjælp af denne metode har `Span::call_site()`-spændet som standard, som kan konfigureres med `set_span`-metoden nedenfor.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Opretter et nyt ikke-fastgjort flydende punkt bogstaveligt.
    ///
    /// Denne konstruktor ligner dem som `Literal::i8_unsuffixed`, hvor floatens værdi udsendes direkte i token, men der ikke bruges noget suffiks, så det kan udledes at være en `f64` senere i compileren.
    ///
    /// Litteratur oprettet ud fra negative tal overlever muligvis ikke rountrips gennem `TokenStream` eller strenge og kan opdeles i to tokens (`-` og positive bogstavelige).
    ///
    /// # Panics
    ///
    /// Denne funktion kræver, at den angivne float er endelig, for eksempel hvis den er uendelig eller NaN, vil denne funktion panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Opretter et nyt suffiks bogstaveligt flydende punkt.
    ///
    /// Denne konstruktør opretter en bogstavelig som `1.0f32`, hvor den angivne værdi er den foregående del af token, og `f32` er suffikset for token.
    /// Denne token vil altid blive udledt til at være en `f32` i compileren.
    /// Litteratur oprettet ud fra negative tal overlever muligvis ikke rountrips gennem `TokenStream` eller strenge og kan opdeles i to tokens (`-` og positive bogstavelige).
    ///
    ///
    /// # Panics
    ///
    /// Denne funktion kræver, at den angivne float er endelig, for eksempel hvis den er uendelig eller NaN, vil denne funktion panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Opretter et nyt ikke-fastgjort flydende punkt bogstaveligt.
    ///
    /// Denne konstruktor ligner dem som `Literal::i8_unsuffixed`, hvor floatens værdi udsendes direkte i token, men der ikke bruges noget suffiks, så det kan udledes at være en `f64` senere i compileren.
    ///
    /// Litteratur oprettet ud fra negative tal overlever muligvis ikke rountrips gennem `TokenStream` eller strenge og kan opdeles i to tokens (`-` og positive bogstavelige).
    ///
    /// # Panics
    ///
    /// Denne funktion kræver, at den angivne float er endelig, for eksempel hvis den er uendelig eller NaN, vil denne funktion panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Opretter et nyt suffiks bogstaveligt flydende punkt.
    ///
    /// Denne konstruktør opretter en bogstavelig som `1.0f64`, hvor den angivne værdi er den foregående del af token, og `f64` er suffikset for token.
    /// Denne token vil altid blive udledt til at være en `f64` i compileren.
    /// Litteratur oprettet ud fra negative tal overlever muligvis ikke rountrips gennem `TokenStream` eller strenge og kan opdeles i to tokens (`-` og positive bogstavelige).
    ///
    ///
    /// # Panics
    ///
    /// Denne funktion kræver, at den angivne float er endelig, for eksempel hvis den er uendelig eller NaN, vil denne funktion panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// String bogstavelig.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Karakter bogstavelig.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Byte streng bogstavelig.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Returnerer spændvidden, der omfatter denne bogstavelige.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Konfigurerer det tilknyttede interval for denne bogstavelige.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Returnerer en `Span`, der er en delmængde af `self.span()`, der kun indeholder kildebyte i området `range`.
    /// Returnerer `None`, hvis det trimmede span er uden for `self` s grænser.
    ///
    // FIXME(SergioBenitez): Kontroller, at byteområdet starter og slutter ved en UTF-8-grænse for kilden.
    // ellers er det sandsynligt, at en panic vil forekomme andre steder, når kildeteksten udskrives.
    // FIXME(SergioBenitez): der er ingen måde for brugeren at vide, hvad `self.span()` faktisk kortlægger, så denne metode kan i øjeblikket kun kaldes blindt.
    // For eksempel returnerer `to_string()` for tegnet 'c' "'\u{63}'";der er ingen måde for brugeren at vide, om kildeteksten var 'c', eller om det var '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) noget der ligner `Option::cloned`, men for `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, broen leverer kun `to_string`, implementer `fmt::Display` baseret på den (det modsatte af det sædvanlige forhold mellem de to).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Udskriver bogstavet som en streng, der tabsfrit kan konverteres tilbage til den samme bogstavelige (undtagen mulig afrunding for flydende bogstavsbogstaver).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Sporet adgang til miljøvariabler.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Hent en miljøvariabel, og tilføj den for at opbygge afhængighedsinformation.
    /// Build-system, der udfører compileren, ved, at variablen blev åbnet under kompilering, og vil være i stand til at køre build'en igen, når værdien af den variabel ændres.
    ///
    /// Udover afhængighedssporing skal denne funktion svare til `env::var` fra standardbiblioteket, bortset fra at argumentet skal være UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}