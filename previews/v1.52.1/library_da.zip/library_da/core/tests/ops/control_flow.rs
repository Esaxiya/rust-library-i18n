use core::intrinsics::discriminant_value;
use core::ops::ControlFlow;

#[test]
fn control_flow_discriminants_match_result() {
    // Dette er ikke stabilt overfladeareal, men hjælper med at holde `?` billigt mellem dem, selvom LLVM ikke altid kan udnytte det lige nu.
    //
    // (Desværre er resultat og mulighed inkonsekvente, så ControlFlow kan ikke matche begge dele.)

    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Break(3)),
        discriminant_value(&Result::<i32, i32>::Err(3)),
    );
    assert_eq!(
        discriminant_value(&ControlFlow::<i32, i32>::Continue(3)),
        discriminant_value(&Result::<i32, i32>::Ok(3)),
    );
}