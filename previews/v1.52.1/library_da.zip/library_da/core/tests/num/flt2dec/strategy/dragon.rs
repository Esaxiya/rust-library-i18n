use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri er for langsom
fn exact_sanity_test() {
    // Denne test ender med at køre, hvad jeg kun kan antage, er et hjørneeksempel på `exp2`-biblioteksfunktionen, defineret i den C-kørselstid, vi bruger.
    // I VS 2013 havde denne funktion tilsyneladende en fejl, da denne test mislykkedes, når den blev linket, men med VS 2015 ser fejlen ud til at være løst, da testen kører fint.
    //
    // Fejlen ser ud til at være en forskel i returværdien på `exp2(-1057)`, hvor den i VS 2013 returnerer en dobbelt med bitmønsteret 0x2 og i VS 2015 returnerer den 0x20000.
    //
    //
    // For nu er det bare at ignorere denne test helt på MSVC, da den alligevel er testet andetsteds, og vi er ikke superinteresserede i at teste hver platforms exp2-implementering.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}