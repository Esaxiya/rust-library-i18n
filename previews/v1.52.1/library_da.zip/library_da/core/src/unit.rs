use crate::iter::FromIterator;

/// Skjuler alle enhedsgenstande fra en iterator til en.
///
/// Dette er mere nyttigt, når det kombineres med abstraktioner på højere niveau, som at samle til en `Result<(), E>`, hvor du kun er interesseret i fejl:
///
///
/// ```
/// use std::io::*;
/// let data = vec![1, 2, 3, 4, 5];
/// let res: Result<()> = data.iter()
///     .map(|x| writeln!(stdout(), "{}", x))
///     .collect();
/// assert!(res.is_ok());
/// ```
#[stable(feature = "unit_from_iter", since = "1.23.0")]
impl FromIterator<()> for () {
    fn from_iter<I: IntoIterator<Item = ()>>(iter: I) -> Self {
        iter.into_iter().for_each(|()| {})
    }
}