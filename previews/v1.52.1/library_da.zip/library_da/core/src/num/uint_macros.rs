macro_rules! uint_impl {
    ($SelfT:ty, $ActualT:ty, $BITS:expr, $MaxV:expr,
        $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
        $reversed:expr, $le_bytes:expr, $be_bytes:expr,
        $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Den mindste værdi, der kan repræsenteres af denne heltalstype.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, 0);")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = 0;

        /// Den største værdi, der kan repræsenteres af denne heltalstype.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($MaxV), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !0;

        /// Størrelsen på denne heltalstype i bits.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Konverterer en strengskive i en given base til et heltal.
        ///
        /// Strengen forventes at være et valgfrit `+`-tegn efterfulgt af cifre.
        ///
        /// Ledende og efterfølgende mellemrum repræsenterer en fejl.
        /// Cifre er en delmængde af disse tegn afhængigt af `radix`:
        ///
        /// * `0-9`
        /// * `a-z`
        /// * `A-Z`
        ///
        /// # Panics
        ///
        /// Denne funktion panics, hvis `radix` ikke er i området fra 2 til 36.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Returnerer antallet af dem i den binære repræsentation af `self`.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("let n = 0b01001100", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 {
            intrinsics::ctpop(self as $ActualT) as u32
        }

        /// Returnerer antallet af nuller i den binære repræsentation af `self`.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Returnerer antallet af førende nuller i den binære repræsentation af `self`.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("let n = ", stringify!($SelfT), "::MAX >> 2;")]
        /// assert_eq!(n.leading_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            intrinsics::ctlz(self as $ActualT) as u32
        }

        /// Returnerer antallet af efterfølgende nuller i den binære repræsentation af `self`.
        ///
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("let n = 0b0101000", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 3);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            intrinsics::cttz(self) as u32
        }

        /// Returnerer antallet af førende i den binære repræsentation af `self`.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("let n = !(", stringify!($SelfT), "::MAX >> 2);")]
        /// assert_eq!(n.leading_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (!self).leading_zeros()
        }

        /// Returnerer antallet af bageste i den binære repræsentation af `self`.
        ///
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("let n = 0b1010111", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 3);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (!self).trailing_zeros()
        }

        /// Flytter bitene til venstre med et specificeret beløb, `n`, der indpakker de afkortede bits til slutningen af det resulterende heltal.
        ///
        ///
        /// Bemærk, at dette ikke er den samme handling som `<<`-skiftoperatøren!
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            intrinsics::rotate_left(self, n as $SelfT)
        }

        /// Skifter bitene til højre med et bestemt beløb, `n`, der indpakker de afkortede bits til begyndelsen af det resulterende heltal.
        ///
        ///
        /// Bemærk, at dette ikke er den samme handling som `>>`-skiftoperatøren!
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            intrinsics::rotate_right(self, n as $SelfT)
        }

        /// Vender heltalets byte rækkefølge.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// lad m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            intrinsics::bswap(self as $ActualT) as Self
        }

        /// Vender rækkefølgen af bits i heltal.
        /// Den mindst signifikante bit bliver den mest betydningsfulde bit, den anden mindst signifikante bit bliver næstmest signifikante bit osv
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// lad m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            intrinsics::bitreverse(self as $ActualT) as Self
        }

        /// Konverterer et helt tal fra stor endian til målets endianness.
        ///
        /// På store endian er dette et no-op.
        /// På lille endian byttes byte.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// hvis cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } andet {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Konverterer et helt tal fra lille endian til målets endianness.
        ///
        /// På lille endian er dette et no-op.
        /// På store endian byttes byte.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// hvis cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } andet {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Konverterer `self` til stor endian fra målets endianness.
        ///
        /// På store endian er dette et no-op.
        /// På lille endian byttes byte.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// hvis cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } ellers { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // eller ikke være?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Konverterer `self` til lille endian fra målets endianness.
        ///
        /// På lille endian er dette et no-op.
        /// På store endian byttes byte.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// hvis cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } ellers { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_math", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Kontrolleret tilføjelse af heltal.
        /// Beregner `self + rhs`, returnerer `None`, hvis der opstod overløb.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!(
            "assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), ",
            "Some(", stringify!($SelfT), "::MAX - 1));"
        )]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Ikke-markeret heltalstilsætning.Beregner `self + rhs`, forudsat at overløb ikke kan forekomme.
        /// Dette resulterer i udefineret adfærd, når
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Kontrolleret heltalstraktion.
        /// Beregner `self - rhs`, returnerer `None`, hvis der opstod overløb.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_sub(1), Some(0));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_sub(1), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Umarkeret heltalstraktion.Beregner `self - rhs`, forudsat at overløb ikke kan forekomme.
        /// Dette resulterer i udefineret adfærd, når
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Kontrolleret multiplikation af heltal.
        /// Beregner `self * rhs`, returnerer `None`, hvis der opstod overløb.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_mul(1), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Ikke-markeret heltalsmultiplikation.Beregner `self * rhs`, forudsat at overløb ikke kan forekomme.
        /// Dette resulterer i udefineret adfærd, når
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Kontrolleret heltal division.
        /// Beregner `self / rhs`, returnerer `None` hvis `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SIKKERHED: div ved nul er markeret ovenfor, og usignerede typer har ingen andre
                // fejltilstande til deling
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Kontrolleret euklidisk division.
        /// Beregner `self.div_euclid(rhs)`, returnerer `None` hvis `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".checked_div_euclid(2), Some(64));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }


        /// Kontrolleret heltal rest.
        /// Beregner `self % rhs`, returnerer `None` hvis `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                // SIKKERHED: div ved nul er markeret ovenfor, og usignerede typer har ingen andre
                // fejltilstande til deling
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Kontrolleret euklidisk modulo.
        /// Beregner `self.rem_euclid(rhs)`, returnerer `None` hvis `rhs == 0`.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Kontrolleret negation.Beregner `-self`, returnerer `None`, medmindre `self==
        /// 0`.
        ///
        /// Bemærk, at negering af et positivt heltal overløber.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".checked_neg(), Some(0));")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Kontrolleret skift til venstre.
        /// Beregner `self << rhs`, returnerer `None`, hvis `rhs` er større end eller lig med antallet af bit i `self`.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Kontrolleret skift til højre.
        /// Beregner `self >> rhs`, returnerer `None`, hvis `rhs` er større end eller lig med antallet af bit i `self`.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Kontrolleret eksponentiering.
        /// Beregner `self.pow(exp)`, returnerer `None`, hvis der opstod overløb.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_pow(5), Some(32));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }

            // da exp!=0, skal exp endelig være 1.
            // Håndter den sidste bit af eksponenten separat, da kvadrering af basen bagefter ikke er nødvendig og kan forårsage et unødvendigt overløb.
            //
            //

            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Mættende heltalstilsætning.
        /// Beregner `self + rhs`, mætter ved de numeriske grænser i stedet for at løbe over.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(127), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Mættende heltalstraktion.
        /// Beregner `self - rhs`, mætter ved de numeriske grænser i stedet for at løbe over.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(27), 73);")]
        #[doc = concat!("assert_eq!(13", stringify!($SelfT), ".saturating_sub(127), 0);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Mættende heltalsmultiplikation.
        /// Beregner `self * rhs`, mætter ved de numeriske grænser i stedet for at løbe over.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".saturating_mul(10), 20);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX).saturating_mul(10), ", stringify!($SelfT),"::MAX);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Mættende heltal eksponentiering.
        /// Beregner `self.pow(exp)`, mætter ved de numeriske grænser i stedet for at løbe over.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(4", stringify!($SelfT), ".saturating_pow(3), 64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None => Self::MAX,
            }
        }

        /// Indpakning af (modular)-tilføjelse.
        /// Beregner `self + rhs`, der vikles rundt ved grænsen for typen.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(55), 255);")]
        #[doc = concat!("assert_eq!(200", stringify!($SelfT), ".wrapping_add(", stringify!($SelfT), "::MAX), 199);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Indpakning af (modular)-subtraktion.
        /// Beregner `self - rhs`, der vikles rundt ved grænsen for typen.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(100), 0);")]
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_sub(", stringify!($SelfT), "::MAX), 101);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Indpakning af (modular)-multiplikation.
        /// Beregner `self * rhs`, der vikles rundt ved grænsen for typen.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// Bemærk, at dette eksempel deles mellem heltalstyper.
        /// Hvilket forklarer, hvorfor `u8` bruges her.
        ///
        /// ```
        /// assert_eq!(10u8.wrapping_mul(12), 120);
        /// assert_eq!(25u8.wrapping_mul(12), 44);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Indpakning af (modular)-division.Beregner `self / rhs`.
        /// Indpakket opdeling på usignerede typer er bare normal opdeling.
        /// Der er ingen måde, indpakning nogensinde kan ske.
        /// Denne funktion findes, så alle operationer tages med i indpakningen.
        ///
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Indpakning af den euklidiske division.Beregner `self.div_euclid(rhs)`.
        /// Indpakket opdeling på usignerede typer er bare normal opdeling.
        /// Der er ingen måde, indpakning nogensinde kan ske.
        /// Denne funktion findes, så alle operationer tages med i indpakningen.
        /// Da de almindelige definitioner af division for de positive heltal er ens, er dette nøjagtigt lig med `self.wrapping_div(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }

        /// Indpakning af (modular) resten.Beregner `self % rhs`.
        /// Indpakket restberegning på usignerede typer er bare den almindelige restberegning.
        ///
        /// Der er ingen måde, indpakning nogensinde kan ske.
        /// Denne funktion findes, så alle operationer tages med i indpakningen.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Indpakning af euklidisk modulo.Beregner `self.rem_euclid(rhs)`.
        /// Indpakket modulo-beregning på usignerede typer er bare den almindelige restberegning.
        /// Der er ingen måde, indpakning nogensinde kan ske.
        /// Denne funktion findes, så alle operationer tages med i indpakningen.
        /// Da de almindelige definitioner af division for de positive heltal er ens, er dette nøjagtigt lig med `self.wrapping_rem(rhs)`.
        ///
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Indpakning af (modular)-negation.
        /// Beregner `-self`, der vikles rundt ved grænsen for typen.
        ///
        /// Da usignerede typer ikke har negative ækvivalenter, vil alle applikationer af denne funktion blive pakket (undtagen `-0`).
        /// For værdier, der er mindre end den tilsvarende underskrevne type, er resultatet det samme som at caste den tilsvarende signerede værdi.
        ///
        /// Eventuelle større værdier svarer til `MAX + 1 - (val - MAX - 1)`, hvor `MAX` er den maksimale signerede type.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// Bemærk, at dette eksempel deles mellem heltalstyper.
        /// Hvilket forklarer, hvorfor `i8` bruges her.
        ///
        /// ```
        /// assert_eq!(100i8.wrapping_neg(), -100);
        /// assert_eq!((-128i8).wrapping_neg(), -128);
        /// ```
        ///
        ///
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-fri bitvis skift-venstre;
        /// giver `self << mask(rhs)`, hvor `mask` fjerner alle bit af `rhs` af høj ordre, der ville få skiftet til at overstige typebitbredden.
        ///
        /// Bemærk, at dette er *ikke* det samme som en roter-venstre;RHS for et indpakningsskift-venstre er begrænset til rækkevidden af typen snarere end bitene, der er flyttet ud af LHS, returneres til den anden ende.
        /// De primitive heltalstyper implementerer alle en [`rotate_left`](Self::rotate_left)-funktion, hvilket måske er det, du vil have i stedet.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(7), 128);")]
        #[doc = concat!("assert_eq!(1", stringify!($SelfT), ".wrapping_shl(128), 1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // SIKKERHED: maskeringen efter bitstørrelsen af typen sikrer, at vi ikke skifter
            // Over grænsen
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-fri bitvis skift til højre;
        /// giver `self >> mask(rhs)`, hvor `mask` fjerner alle bit af `rhs` af høj ordre, der ville få skiftet til at overstige typebitbredden.
        ///
        /// Bemærk, at dette er *ikke* det samme som en roter-højre;RHS for et indpakningsskift-højre er begrænset til rækkevidden af typen snarere end bitene, der er flyttet ud af LHS, returneres til den anden ende.
        /// De primitive heltalstyper implementerer alle en [`rotate_right`](Self::rotate_right)-funktion, hvilket måske er det, du vil have i stedet.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        ///
        ///
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(7), 1);")]
        #[doc = concat!("assert_eq!(128", stringify!($SelfT), ".wrapping_shr(128), 128);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // SIKKERHED: maskeringen efter bitstørrelsen af typen sikrer, at vi ikke skifter
            // Over grænsen
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Indpakning af (modular)-eksponentiering.
        /// Beregner `self.pow(exp)`, der vikles rundt ved grænsen for typen.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(5), 243);")]
        /// assert_eq!(3u8.wrapping_pow(6), 217);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // da exp!=0, skal exp endelig være 1.
            // Håndter den sidste bit af eksponenten separat, da kvadrering af basen bagefter ikke er nødvendig og kan forårsage et unødvendigt overløb.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Beregner `self` + `rhs`
        ///
        /// Returnerer en tupel af tilføjelsen sammen med en boolsk, der angiver, om der ville forekomme et aritmetisk overløb.
        /// Hvis et overløb ville have fundet sted, returneres den indpakkede værdi.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (0, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Beregner `self`, `rhs`
        ///
        /// Returnerer en tuple af subtraktionen sammen med en boolsk, der indikerer, om der vil forekomme et aritmetisk overløb.
        /// Hvis et overløb ville have fundet sted, returneres den indpakkede værdi.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Beregner multiplikationen af `self` og `rhs`.
        ///
        /// Returnerer en tuple af multiplikationen sammen med en boolsk, der indikerer, om der vil forekomme et aritmetisk overløb.
        /// Hvis et overløb ville have fundet sted, returneres den indpakkede værdi.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// Bemærk, at dette eksempel deles mellem heltalstyper.
        /// Hvilket forklarer, hvorfor `u32` bruges her.
        ///
        /// ```
        /// assert_eq!(5u32.overflowing_mul(2), (10, false));
        /// assert_eq!(1_000_000_000u32.overflowing_mul(10), (1410065408, true));
        /// ```
        ///
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Beregner divisoren, når `self` divideres med `rhs`.
        ///
        /// Returnerer en tuple af skillevæggen sammen med en boolsk, der angiver, om der ville opstå et aritmetisk overløb.
        /// Bemærk, at der for usignerede heltal aldrig forekommer overløb, så den anden værdi er altid `false`.
        ///
        /// # Panics
        ///
        /// Denne funktion vil panic, hvis `rhs` er 0.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Beregner kvotienten for den euklidiske division `self.div_euclid(rhs)`.
        ///
        /// Returnerer en tuple af skillevæggen sammen med en boolsk, der angiver, om der ville opstå et aritmetisk overløb.
        /// Bemærk, at der for usignerede heltal aldrig forekommer overløb, så den anden værdi er altid `false`.
        /// Da de almindelige definitioner af division for de positive heltal er ens, er dette nøjagtigt lig med `self.overflowing_div(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Denne funktion vil panic, hvis `rhs` er 0.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            (self / rhs, false)
        }

        /// Beregner resten, når `self` divideres med `rhs`.
        ///
        /// Returnerer en tuple af resten efter opdeling sammen med en boolsk, der angiver, om et aritmetisk overløb ville forekomme.
        /// Bemærk, at der for usignerede heltal aldrig forekommer overløb, så den anden værdi er altid `false`.
        ///
        /// # Panics
        ///
        /// Denne funktion vil panic, hvis `rhs` er 0.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Beregner den resterende `self.rem_euclid(rhs)` som ved euklidisk division.
        ///
        /// Returnerer en tuple af modulo efter opdeling sammen med en boolsk, der angiver, om et aritmetisk overløb ville forekomme.
        /// Bemærk, at der for usignerede heltal aldrig forekommer overløb, så den anden værdi er altid `false`.
        /// Da alle almindelige definitioner af division for de positive heltal er ens, er denne operation nøjagtig lig med `self.overflowing_rem(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Denne funktion vil panic, hvis `rhs` er 0.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            (self % rhs, false)
        }

        /// Negerer selv på en overfyldt måde.
        ///
        /// Returnerer `!self + 1` ved hjælp af indpakningsoperationer for at returnere den værdi, der repræsenterer negationen af denne usignerede værdi.
        /// Bemærk, at der ved positive usignerede værdier altid forekommer overløb, men at negere 0 ikke overløber.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".overflowing_neg(), (0, false));")]
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2i32 as ", stringify!($SelfT), ", true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            ((!self).wrapping_add(1), self != 0)
        }

        /// Skifter selv efterladt af `rhs` bits.
        ///
        /// Returnerer en tuple af den skiftede version af selv sammen med en boolsk, der angiver, om forskydningsværdien var større end eller lig med antallet af bits.
        /// Hvis forskydningsværdien er for stor, maskeres værdien (N-1), hvor N er antallet af bits, og denne værdi bruges derefter til at udføre skiftet.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(4), (0x10, false));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".overflowing_shl(132), (0x10, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Skifter selvret med `rhs` bits.
        ///
        /// Returnerer en tuple af den skiftede version af selv sammen med en boolsk, der angiver, om forskydningsværdien var større end eller lig med antallet af bits.
        /// Hvis forskydningsværdien er for stor, maskeres værdien (N-1), hvor N er antallet af bits, og denne værdi bruges derefter til at udføre skiftet.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug
        ///
        /// ```
        ///
        ///
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(132), (0x1, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_wrapping_math", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Løfter sig selv til kraften i `exp` ved hjælp af eksponentiering ved at kvadre.
        ///
        /// Returnerer en tuple af eksponentieringen sammen med en bool, der angiver, om der opstod et overløb.
        ///
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(5), (243, false));")]
        /// assert_eq!(3u8.overflowing_pow(6), (217, sandt));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0{
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Ridseplads til lagring af resultater af overflowing_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // da exp!=0, skal exp endelig være 1.
            // Håndter den sidste bit af eksponenten separat, da kvadrering af basen bagefter ikke er nødvendig og kan forårsage et unødvendigt overløb.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;

            r
        }

        /// Løfter sig selv til kraften i `exp` ved hjælp af eksponentiering ved at kvadre.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".pow(5), 32);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                          without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // da exp!=0, skal exp endelig være 1.
            // Håndter den sidste bit af eksponenten separat, da kvadrering af basen bagefter ikke er nødvendig og kan forårsage et unødvendigt overløb.
            //
            //
            acc * base
        }

        /// Udfører euklidisk division.
        ///
        /// Da de almindelige definitioner af division for de positive heltal er ens, er dette nøjagtigt lig med `self / rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Denne funktion vil panic, hvis `rhs` er 0.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".div_euclid(4), 1); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            self / rhs
        }


        /// Beregner den mindste rest af `self (mod rhs)`.
        ///
        /// Da de almindelige definitioner af division for de positive heltal er ens, er dette nøjagtigt lig med `self % rhs`.
        ///
        ///
        /// # Panics
        ///
        /// Denne funktion vil panic, hvis `rhs` er 0.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(7", stringify!($SelfT), ".rem_euclid(4), 3); // or any other integer type")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            self % rhs
        }

        /// Returnerer `true` hvis og kun hvis `self == 2^k` for nogle `k`.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert!(16", stringify!($SelfT), ".is_power_of_two());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_power_of_two());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_is_power_of_two", since = "1.32.0")]
        #[inline]
        pub const fn is_power_of_two(self) -> bool {
            self.count_ones() == 1
        }

        // Returnerer en mindre end næste effekt på to.
        // (For 8u8 er næste effekt på to 8u8 og for 6u8 er det 8u8)
        //
        // 8u8.one_less_than_next_power_of_two() ==7
        // 6u8.one_less_than_next_power_of_two() ==7
        //
        // Denne metode kan ikke overløbe, da den i `next_power_of_two`-overløbssager i stedet ender med at returnere den maksimale værdi af typen og kan returnere 0 til 0.
        //
        //
        #[inline]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        const fn one_less_than_next_power_of_two(self) -> Self {
            if self <= 1 { return 0; }

            let p = self - 1;
            // SIKKERHED: Fordi `p > 0`, kan den ikke bestå helt af ledende nuller.
            // Det betyder, at skiftet altid er inden for grænserne, og nogle processorer (såsom intel pre-haswell) har mere effektiv ctlz-iboende egenskaber, når argumentet er ikke-nul.
            //
            //
            let z = unsafe { intrinsics::ctlz_nonzero(p) };
            <$SelfT>::MAX >> z
        }

        /// Returnerer den mindste effekt på to større end eller lig med `self`.
        ///
        /// Når returværdien overløber (dvs. `self > (1 << (N-1))` for type `uN`), panics i fejlretningstilstand, og returværdien indpakkes til 0 i frigivelsestilstand (den eneste situation, hvor metoden kan returnere 0).
        ///
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".next_power_of_two(), 4);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two() + 1
        }

        /// Returnerer den mindste effekt på to større end eller lig med `n`.
        /// Hvis den næste effekt på to er større end typens maksimale værdi, returneres `None`, ellers er effekten på to pakket ind i `Some`.
        ///
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".checked_next_power_of_two(), Some(2));")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".checked_next_power_of_two(), Some(4));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_next_power_of_two(), None);")]
        /// ```
        #[inline]
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn checked_next_power_of_two(self) -> Option<Self> {
            self.one_less_than_next_power_of_two().checked_add(1)
        }

        /// Returnerer den mindste effekt på to større end eller lig med `n`.
        /// Hvis den næste effekt på to er større end typens maksimale værdi, pakkes returværdien til `0`.
        ///
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        /// #![feature(wrapping_next_power_of_two)]
        ///
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".wrapping_next_power_of_two(), 2);")]
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_next_power_of_two(), 4);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_next_power_of_two(), 0);")]
        /// ```
        #[unstable(feature = "wrapping_next_power_of_two", issue = "32463",
                   reason = "needs decision on wrapping behaviour")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        pub const fn wrapping_next_power_of_two(self) -> Self {
            self.one_less_than_next_power_of_two().wrapping_add(1)
        }

        /// Returner hukommelsesrepræsentationen for dette heltal som et byte-array i stor-endian (network) byte-rækkefølge.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Returner hukommelsesrepræsentationen for dette heltal som et byte-array i lille endian-byte-rækkefølge.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Returner hukommelsesrepræsentationen for dette heltal som et byte-array i native byte-rækkefølge.
        ///
        /// Da målplatformens native endianness anvendes, skal bærbar kode i stedet bruge [`to_be_bytes`] eller [`to_le_bytes`].
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     bytes, hvis cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } andet {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SIKKERHED: const-lyd, fordi heltal er almindelige gamle datatyper, så vi altid kan
        // transmitter dem til arrays af bytes
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // SIKKERHED: heltal er almindelige gamle datatyper, så vi altid kan transmittere dem til
            // arrays af bytes
            unsafe { mem::transmute(self) }
        }

        /// Returner hukommelsesrepræsentationen for dette heltal som et byte-array i native byte-rækkefølge.
        ///
        ///
        /// [`to_ne_bytes`] bør foretrækkes frem for dette, når det er muligt.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// lad bytes= num.as_ne_bytes();
        /// assert_eq!(
        ///     bytes, hvis cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } andet {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // SIKKERHED: heltal er almindelige gamle datatyper, så vi altid kan transmittere dem til
            // arrays af bytes
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Opret en native endian-heltalværdi ud fra dens repræsentation som et byte-array i big endian.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// brug std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input=hvile;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Opret en native endian-heltalværdi ud fra dens repræsentation som et byte-array i lille endian.
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// brug std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input=hvile;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Opret en native endian-heltalsværdi ud fra dens hukommelsesrepræsentation som et byte-array i native endianness.
        ///
        /// Da målplatformens native endianness anvendes, vil bærbar kode sandsynligvis i stedet bruge [`from_be_bytes`] eller [`from_le_bytes`].
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $from_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes, "")]
        /// } andet {
        #[doc = concat!("    ", $le_bytes, "")]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// brug std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input=hvile;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SIKKERHED: const-lyd, fordi heltal er almindelige gamle datatyper, så vi altid kan
        // transmutere til dem
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // SIKKERHED: heltal er almindelige gamle datatyper, så vi altid kan transmittere til dem
            unsafe { mem::transmute(bytes) }
        }

        /// Ny kode foretrækker at bruge
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Returnerer den mindste værdi, der kan repræsenteres af denne heltalstype.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self { Self::MIN }

        /// Ny kode foretrækker at bruge
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Returnerer den største værdi, der kan repræsenteres af denne heltalstype.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_promotable]
        #[inline(always)]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self { Self::MAX }
    }
}