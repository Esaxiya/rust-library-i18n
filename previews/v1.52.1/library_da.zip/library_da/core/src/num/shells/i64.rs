//! Konstanter til 64-bit signeret heltalstype.
//!
//! *[See also the `i64` primitive type][i64].*
//!
//! Ny kode skal bruge de tilknyttede konstanter direkte på den primitive type.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i64`"
)]

int_module! { i64 }