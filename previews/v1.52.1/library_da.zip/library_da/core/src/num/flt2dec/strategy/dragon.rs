//! Næsten direkte (men let optimeret) Rust-oversættelse af figur 3 i "Udskrivning af flydepunktsnumre hurtigt og præcist" [^ 1].
//!
//!
//! [^1]: Burger, RG og Dybvig, RK 1996. Udskrivning af flydende numre
//!   hurtigt og præcist.SIGPLAN Ikke.31, 5 (maj 1996), 108-116.

use crate::cmp::Ordering;
use crate::mem::MaybeUninit;

use crate::num::bignum::Big32x40 as Big;
use crate::num::bignum::Digit32 as Digit;
use crate::num::flt2dec::estimator::estimate_scaling_factor;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

static POW10: [Digit; 10] =
    [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000];
static TWOPOW10: [Digit; 10] =
    [2, 20, 200, 2000, 20000, 200000, 2000000, 20000000, 200000000, 2000000000];

// forudberegnede arrays af `Digit`s for 10 ^ (2 ^ n)
static POW10TO16: [Digit; 2] = [0x6fc10000, 0x2386f2];
static POW10TO32: [Digit; 4] = [0, 0x85acef81, 0x2d6d415b, 0x4ee];
static POW10TO64: [Digit; 7] = [0, 0, 0xbf6a1f01, 0x6e38ed64, 0xdaa797ed, 0xe93ff9f4, 0x184f03];
static POW10TO128: [Digit; 14] = [
    0, 0, 0, 0, 0x2e953e01, 0x3df9909, 0xf1538fd, 0x2374e42f, 0xd3cff5ec, 0xc404dc08, 0xbccdb0da,
    0xa6337f19, 0xe91f2603, 0x24e,
];
static POW10TO256: [Digit; 27] = [
    0, 0, 0, 0, 0, 0, 0, 0, 0x982e7c01, 0xbed3875b, 0xd8d99f72, 0x12152f87, 0x6bde50c6, 0xcf4a6e70,
    0xd595d80f, 0x26b2716e, 0xadc666b0, 0x1d153624, 0x3c42d35a, 0x63ff540e, 0xcc5573c0, 0x65f9ef17,
    0x55bc28f2, 0x80dcc7f7, 0xf46eeddc, 0x5fdcefce, 0x553f7,
];

#[doc(hidden)]
pub fn mul_pow10(x: &mut Big, n: usize) -> &mut Big {
    debug_assert!(n < 512);
    if n & 7 != 0 {
        x.mul_small(POW10[n & 7]);
    }
    if n & 8 != 0 {
        x.mul_small(POW10[8]);
    }
    if n & 16 != 0 {
        x.mul_digits(&POW10TO16);
    }
    if n & 32 != 0 {
        x.mul_digits(&POW10TO32);
    }
    if n & 64 != 0 {
        x.mul_digits(&POW10TO64);
    }
    if n & 128 != 0 {
        x.mul_digits(&POW10TO128);
    }
    if n & 256 != 0 {
        x.mul_digits(&POW10TO256);
    }
    x
}

fn div_2pow10(x: &mut Big, mut n: usize) -> &mut Big {
    let largest = POW10.len() - 1;
    while n > largest {
        x.div_rem_small(POW10[largest]);
        n -= largest;
    }
    x.div_rem_small(TWOPOW10[n]);
    x
}

// kun anvendelig, når `x < 16 * scale`;`scaleN` skal være `scale.mul_small(N)`
fn div_rem_upto_16<'a>(
    x: &'a mut Big,
    scale: &Big,
    scale2: &Big,
    scale4: &Big,
    scale8: &Big,
) -> (u8, &'a mut Big) {
    let mut d = 0;
    if *x >= *scale8 {
        x.sub(scale8);
        d += 8;
    }
    if *x >= *scale4 {
        x.sub(scale4);
        d += 4;
    }
    if *x >= *scale2 {
        x.sub(scale2);
        d += 2;
    }
    if *x >= *scale {
        x.sub(scale);
        d += 1;
    }
    debug_assert!(*x < *scale);
    (d, x)
}

/// Den korteste tilstandsimplementering til Dragon.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    // nummeret `v` til format er kendt for at være:
    // - lig med `mant * 2^exp`;
    // - forud for `(mant - 2 *minus)* 2^exp` i den originale type;og
    // - efterfulgt af `(mant + 2 *plus)* 2^exp` i den originale type.
    //
    // `minus` og `plus` kan naturligvis ikke være nul.(for uendelighed bruger vi værdier uden for området.) Vi antager også, at mindst et ciffer genereres, dvs. at `mant` heller ikke kan være nul.
    //
    // Dette betyder også, at ethvert tal mellem `low = (mant - minus)*2^exp` og `high = (mant + plus)* 2^exp` vil kortlægges til dette nøjagtige flydende nummer, med grænser inkluderet, når den originale mantissa var jævn (dvs. `!mant_was_odd`).
    //
    //
    //

    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);

    // `a.cmp(&b) < rounding` er `if d.inclusive {a <= b} else {a < b}`
    let rounding = if d.inclusive { Ordering::Greater } else { Ordering::Equal };

    // estimer `k_0` fra originale input, der tilfredsstiller `10^(k_0-1) < high <= 10^(k_0+1)`.
    // den stramme `k`, der tilfredsstiller `10^(k-1) < high <= 10^k`, beregnes senere.
    let mut k = estimate_scaling_factor(d.mant + d.plus, d.exp);

    // konvertere `{mant, plus, minus} * 2^exp` til brøkform, så:
    // - `v = mant / scale`
    // - `low = (mant - minus) / scale`
    // - `high = (mant + plus) / scale`
    let mut mant = Big::from_u64(d.mant);
    let mut minus = Big::from_u64(d.minus);
    let mut plus = Big::from_u64(d.plus);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
        minus.mul_pow2(d.exp as usize);
        plus.mul_pow2(d.exp as usize);
    }

    // del `mant` med `10^k`.nu `scale / 10 < mant + plus <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
        mul_pow10(&mut minus, -k as usize);
        mul_pow10(&mut plus, -k as usize);
    }

    // fixup når `mant + plus > scale` (eller `>=`).
    // vi ændrer faktisk ikke `scale`, da vi i stedet kan springe den indledende multiplikation over.
    // nu `scale < mant + plus <= scale * 10`, og vi er klar til at generere cifre.
    //
    // bemærk, at `d[0]`*kan* være nul, når `scale - plus < mant < scale`.
    // i dette tilfælde udløses afrundingstilstand (`up` nedenfor) med det samme.
    if scale.cmp(mant.clone().add(&plus)) < rounding {
        // svarende til skalering af `scale` med 10
        k += 1;
    } else {
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // cache `(2, 4, 8) * scale` til generering af cifre.
    let mut scale2 = scale.clone();
    scale2.mul_pow2(1);
    let mut scale4 = scale.clone();
    scale4.mul_pow2(2);
    let mut scale8 = scale.clone();
    scale8.mul_pow2(3);

    let mut down;
    let mut up;
    let mut i = 0;
    loop {
        // invarianter, hvor `d[0..n-1]` er cifre genereret indtil videre:
        // - `v = mant / scale * 10^(k-n-1) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n-1)`
        // - `high - v = plus / scale * 10^(k-n-1)`
        // - `(mant + plus) / scale <= 10` (altså `mant / scale < 10`) hvor `d[i..j]` er en stenografi for `d [i] * 10 ^ (ji) + ...
        // + d [j-1] * 10 + d[j]`.

        // generere et ciffer: `d[n] = floor(mant / scale) < 10`.
        let (d, _) = div_rem_upto_16(&mut mant, &scale, &scale2, &scale4, &scale8);
        debug_assert!(d < 10);
        buf[i] = MaybeUninit::new(b'0' + d);
        i += 1;

        // dette er en forenklet beskrivelse af den modificerede Dragon-algoritme.
        // mange mellemliggende afledninger og fuldstændighedsargumenter udelades for nemheds skyld.
        //
        // start med modificerede invarianter, da vi har opdateret `n`:
        // - `v = mant / scale * 10^(k-n) + d[0..n-1] * 10^(k-n)`
        // - `v - low = minus / scale * 10^(k-n)`
        // - `high - v = plus / scale * 10^(k-n)`
        //
        // antag at `d[0..n-1]` er den korteste repræsentation mellem `low` og `high`, dvs. at `d[0..n-1]` opfylder begge følgende, men `d[0..n-2]` ikke:
        //
        // - `low < d[0..n-1] * 10^(k-n) < high` (bijektivitet: cifre rundt til `v`);og
        // - `abs(v / 10^(k-n) - d[0..n-1]) <= 1/2` (det sidste ciffer er korrekt).
        //
        // den anden betingelse forenkles til `2 * mant <= scale`.
        // løsning af invarianter i form af `mant`, `low` og `high` giver en enklere version af den første betingelse: `-plus < mant < minus`.
        // siden `-plus < 0 <= mant` har vi den korrekte korteste repræsentation, når `mant < minus` og `2 * mant <= scale`.
        // (den førstnævnte bliver `mant <= minus`, når den originale mantissa er jævn.)
        //
        // når det andet ikke holder (`2 * mant> skala`), skal vi øge det sidste ciffer.
        // dette er nok til at gendanne denne tilstand: vi ved allerede, at ciffergenerering garanterer `0 <= v / 10^(k-n) - d[0..n-1] < 1`.
        // i dette tilfælde bliver den første betingelse `-plus < mant - scale < minus`.
        // siden `mant < scale` efter generationen har vi `scale < mant + plus`.
        // (igen, dette bliver `scale <= mant + plus`, når den originale mantissa er jævn.)
        //
        // kort sagt:
        // - stop og runde `down` (hold cifre, som de er), når `mant < minus` (eller `<=`).
        // - stop og rund `up` (øg det sidste ciffer) når `scale < mant + plus` (eller `<=`).
        // - Fortsæt med at generere ellers.
        //
        //
        //
        down = mant.cmp(&minus) < rounding;
        up = scale.cmp(mant.clone().add(&plus)) < rounding;
        if down || up {
            break;
        } // vi har den korteste repræsentation, fortsæt til afrundingen

        // gendanne invarianterne.
        // dette gør, at algoritmen altid afsluttes: `minus` og `plus` øges altid, men `mant` klippes modulo `scale` og `scale` er fast.
        //
        mant.mul_small(10);
        minus.mul_small(10);
        plus.mul_small(10);
    }

    // afrunding sker, når i) kun afrundingsbetingelsen blev udløst, eller ii) begge betingelser blev udløst, og slipsafbrydelse foretrækker afrunding op.
    //
    //
    if up && (!down || *mant.mul_pow2(1) >= scale) {
        // hvis afrunding ændrer længden, bør eksponenten også ændre sig.
        // det ser ud til, at denne betingelse er meget vanskelig at opfylde (muligvis umulig), men vi er bare sikre og konsistente her.
        //
        // SIKKERHED: Vi initialiserede den hukommelse ovenfor.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) }) {
            buf[i] = MaybeUninit::new(c);
            i += 1;
            k += 1;
        }
    }

    // SIKKERHED: Vi initialiserede den hukommelse ovenfor.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..i]) }, k)
}

/// Den nøjagtige og faste tilstandsimplementering for Dragon.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());

    // estimer `k_0` fra originale input, der tilfredsstiller `10^(k_0-1) < v <= 10^(k_0+1)`.
    let mut k = estimate_scaling_factor(d.mant, d.exp);

    // `v = mant / scale`.
    let mut mant = Big::from_u64(d.mant);
    let mut scale = Big::from_small(1);
    if d.exp < 0 {
        scale.mul_pow2(-d.exp as usize);
    } else {
        mant.mul_pow2(d.exp as usize);
    }

    // del `mant` med `10^k`.nu `scale / 10 < mant <= scale * 10`.
    if k >= 0 {
        mul_pow10(&mut scale, k as usize);
    } else {
        mul_pow10(&mut mant, -k as usize);
    }

    // fixup når `mant + plus >= scale`, hvor `plus / scale = 10^-buf.len() / 2`.
    // For at holde bignum i fast størrelse bruger vi faktisk `mant + floor(plus) >= scale`.
    // vi ændrer faktisk ikke `scale`, da vi i stedet kan springe den indledende multiplikation over.
    // igen med den korteste algoritme kan `d[0]` være nul, men vil til sidst blive afrundet op.
    if *div_2pow10(&mut scale.clone(), buf.len()).add(&mant) >= scale {
        // svarende til skalering af `scale` med 10
        k += 1;
    } else {
        mant.mul_small(10);
    }

    // hvis vi arbejder med den sidste cifrede begrænsning, er vi nødt til at forkorte bufferen før den faktiske gengivelse for at undgå dobbelt afrunding.
    //
    // bemærk, at vi er nødt til at forstørre bufferen igen, når afrunding sker!
    let mut len = if k < limit {
        // Ups, vi kan ikke engang producere *et* ciffer.
        // dette er muligt, når vi f.eks. har noget som 9.5, og det afrundes til 10.
        // vi returnerer en tom buffer med undtagelse af den senere afrundingssag, der opstår, når `k == limit` og skal producere nøjagtigt et ciffer.
        //
        0
    } else if ((k as i32 - limit as i32) as usize) < buf.len() {
        (k - limit) as usize
    } else {
        buf.len()
    };

    if len > 0 {
        // cache `(2, 4, 8) * scale` til generering af cifre.
        // (dette kan være dyrt, så beregn dem ikke, når bufferen er tom.)
        let mut scale2 = scale.clone();
        scale2.mul_pow2(1);
        let mut scale4 = scale.clone();
        scale4.mul_pow2(2);
        let mut scale8 = scale.clone();
        scale8.mul_pow2(3);

        for i in 0..len {
            if mant.is_zero() {
                // følgende cifre er alle nuller, vi stopper her, prøv ikke *ikke* at udføre afrunding!snarere udfyld de resterende cifre.
                //
                for c in &mut buf[i..len] {
                    *c = MaybeUninit::new(b'0');
                }
                // SIKKERHED: Vi initialiserede den hukommelse ovenfor.
                return (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k);
            }

            let mut d = 0;
            if mant >= scale8 {
                mant.sub(&scale8);
                d += 8;
            }
            if mant >= scale4 {
                mant.sub(&scale4);
                d += 4;
            }
            if mant >= scale2 {
                mant.sub(&scale2);
                d += 2;
            }
            if mant >= scale {
                mant.sub(&scale);
                d += 1;
            }
            debug_assert!(mant < scale);
            debug_assert!(d < 10);
            buf[i] = MaybeUninit::new(b'0' + d);
            mant.mul_small(10);
        }
    }

    // afrunding, hvis vi stopper midt i cifrene, hvis de følgende cifre er nøjagtigt 5000 ..., tjek det forrige ciffer og prøv at afrunde til lige (dvs. undgå at afrunde, når det forrige ciffer er jævn).
    //
    //
    let order = mant.cmp(scale.mul_small(5));
    if order == Ordering::Greater
        || (order == Ordering::Equal
            // SIKKERHED: `buf[len-1]` initialiseres.
            && (len == 0 || unsafe { buf[len - 1].assume_init() } & 1 == 1))
    {
        // hvis afrunding ændrer længden, bør eksponenten også ændre sig.
        // men vi er blevet anmodet om et fast antal cifre, så ændr ikke bufferen ...
        // SIKKERHED: Vi initialiserede den hukommelse ovenfor.
        if let Some(c) = round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) }) {
            // ... medmindre vi er blevet anmodet om den faste præcision i stedet.
            // Vi skal også kontrollere, at hvis den originale buffer var tom, kan det ekstra ciffer kun tilføjes, når `k == limit` (edge-sag).
            //
            k += 1;
            if k > limit && len < buf.len() {
                buf[len] = MaybeUninit::new(c);
                len += 1;
            }
        }
    }

    // SIKKERHED: Vi initialiserede den hukommelse ovenfor.
    (unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, k)
}