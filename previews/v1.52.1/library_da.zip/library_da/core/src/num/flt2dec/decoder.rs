//! Dekoder en flydende punktværdi i individuelle dele og fejlområder.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Dekodet usigneret endelig værdi, således at:
///
/// - Den oprindelige værdi er lig med `mant * 2^exp`.
///
/// - Ethvert tal fra `(mant - minus)*2^exp` til `(mant + plus)* 2^exp` afrundes til den oprindelige værdi.
/// Området inkluderer kun, når `inclusive` er `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Den skalerede mantissa.
    pub mant: u64,
    /// Det lavere fejlinterval.
    pub minus: u64,
    /// Det øverste fejlinterval.
    pub plus: u64,
    /// Den delte eksponent i base 2.
    pub exp: i16,
    /// Sandt når fejlområdet er inklusive.
    ///
    /// I IEEE 754 er dette sandt, når den oprindelige mantissa var jævn.
    pub inclusive: bool,
}

/// Dekodet usigneret værdi.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Uendelighed, enten positiv eller negativ.
    Infinite,
    /// Nul, enten positiv eller negativ.
    Zero,
    /// Endelige tal med yderligere afkodede felter.
    Finite(Decoded),
}

/// En flydende punkt-type, der kan `dekodes`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Den minimale positive normaliserede værdi.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Returnerer et tegn (sand når negativ) og `FullDecoded`-værdi fra det givne flydende nummer.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // naboer: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode bevarer altid eksponenten, så mantissen skaleres til undernormale.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // naboer: (maxmant, exp, 1)-(minnormmant, exp)-(minnormmant + 1, exp)
                // hvor maxmant=minnormmant * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // naboer: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}