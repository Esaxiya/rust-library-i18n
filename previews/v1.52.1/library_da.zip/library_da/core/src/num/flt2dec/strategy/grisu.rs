//! Rust-tilpasning af Grisu3-algoritmen beskrevet i "Udskrivning af flydepunktsnumre hurtigt og præcist med heltal" [^ 1].
//! Det bruger cirka 1 KB forudberegnet tabel, og det er igen meget hurtigt for de fleste input.
//!
//! [^1]: Florian Loitsch.2010. Udskrivning af flydende numre hurtigt og
//!   nøjagtigt med heltal.SIGPLAN Ikke.45, 6 (juni 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// se kommentarerne i `format_shortest_opt` for begrundelsen.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* i, 80
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Givet `x > 0`, returnerer `(k, 10^k)` sådan, at `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Den korteste tilstandsimplementering til Grisu.
///
/// Det returnerer `None`, når det ellers ville returnere en unøjagtig repræsentation.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // vi har brug for mindst tre bits ekstra præcision

    // start med de normaliserede værdier med den delte eksponent
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // finde en hvilken som helst `cached = 10^minusk` sådan, at `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // da `plus` er normaliseret, betyder det `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // givet vores valg af `ALPHA` og `GAMMA`, sætter dette `plus * cached` i `[4, 2^32)`.
    //
    // det er naturligvis ønskeligt at maksimere `GAMMA - ALPHA`, så vi ikke har brug for mange cachede kræfter på 10, men der er nogle overvejelser:
    //
    //
    // 1. Vi ønsker at holde `floor(plus * cached)` inden for `u32`, da det har brug for en dyr opdeling.
    //    (dette kan ikke undgås, resten kræves for nøjagtighedsestimering.)
    // 2.
    // resten af `floor(plus * cached)` ganges gentagne gange med 10, og den skal ikke løbe over.
    //
    // den første giver `64 + GAMMA <= 32`, mens den anden giver `10 * 2^-ALPHA <= 2^64`;
    // -60 og -32 er det maksimale interval med denne begrænsning, og V8 bruger dem også.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // skala fps.dette giver den maksimale fejl på 1 ulp (bevist fra sætning 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-faktisk interval på minus
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // over `minus` er `v` og `plus`*kvantiserede* tilnærmelser (fejl <1 ulp).
    // da vi ikke ved fejlen er positiv eller negativ, bruger vi to tilnærmelser fordelt ens og har den maksimale fejl på 2 ulps.
    //
    // "unsafe region" er et liberalt interval, som vi oprindeligt genererer.
    // "safe region" er et konservativt interval, som vi kun accepterer.
    // Vi starter med den korrekte repr inden for den usikre region og prøver at finde den nærmeste repr til `v`, som også er inden for den sikre region.
    // hvis vi ikke kan, giver vi op.
    //
    let plus1 = plus.f + 1;
    // lad plus0 = plus.f, 1;//kun til forklaring lad minus0 = minus.f + 1;//kun til forklaring
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // delt eksponent

    // Opdel `plus1` i integrerede og brøkdele.
    // integrerede dele passer garanteret til u32, da cachelagret effekt garanterer `plus < 2^32` og normaliseret `plus.f` altid er mindre end `2^64 - 2^4` på grund af præcisionskravet.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // beregne den største `10^max_kappa` ikke mere end `plus1` (altså `plus1 < 10^(max_kappa+1)`).
    // dette er en øvre grænse for `kappa` nedenfor.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Sætning 6.2: hvis `k` er det største heltal st
    // `0 <= y mod 10^k <= y - x`,              så er `V = floor(y / 10^k) * 10^k` i `[x, y]` og en af de korteste repræsentationer (med det minimale antal signifikante cifre) i dette interval.
    //
    //
    // find cifferlængden `kappa` mellem `(minus1, plus1)` ifølge sætning 6.2.
    // Sætning 6.2 kan vedtages for at ekskludere `x` ved at kræve `y mod 10^k < y - x` i stedet.
    // (f.eks. `x` =32000, `y` =32777; `kappa` =2 siden `y mod 10 ^ 3=777 <y, x=777`.) algoritmen er afhængig af den senere verifikationsfase for at udelukke `y`.
    //
    let delta1 = plus1 - minus1;
    // lad delta1int=(delta1>> e) som størrelse;//kun til forklaring
    let delta1frac = delta1 & ((1 << e) - 1);

    // gengive integrerede dele, mens du kontrollerer for nøjagtigheden ved hvert trin.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // cifre, der endnu ikke skal gengives
    loop {
        // vi har altid mindst et ciffer at gengive som `plus1 >= 10^kappa`-invarianter:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (det følger, at `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // del `remainder` med `10^kappa`.begge skaleres med `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; vi har fundet den rigtige `kappa`.
            let ten_kappa = (ten_kappa as u64) << e; // skalere 10 ^ kappa tilbage til den delte eksponent
            return round_and_weed(
                // SIKKERHED: Vi initialiserede den hukommelse ovenfor.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // bryde løkken, når vi har gengivet alle integrerede cifre.
        // det nøjagtige antal cifre er `max_kappa + 1` som `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // gendanne invarianter
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // gengive brøkdele, mens du kontrollerer for nøjagtigheden ved hvert trin.
    // denne gang stoler vi på gentagne multiplikationer, da division mister præcisionen.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // det næste ciffer skal være markant, da vi har testet det, inden vi bryder ud invarianter, hvor `m = max_kappa + 1` (antal cifre i den integrerede del):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // vil ikke løbe over, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // del `remainder` med `10^kappa`.
        // begge skaleres af `2^e / 10^kappa`, så sidstnævnte er implicit her.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // implicit divisor
            return round_and_weed(
                // SIKKERHED: Vi initialiserede den hukommelse ovenfor.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // gendanne invarianter
        kappa -= 1;
        remainder = r;
    }

    // Vi har genereret alle vigtige cifre i `plus1`, men er ikke sikre på, om det er det optimale.
    // for eksempel, hvis `minus1` er 3.14153 ... og `plus1` er 3.14158 ..., er der 5 forskellige korteste repræsentationer fra 3.14154 til 3.14158, men vi har kun den største.
    // Vi skal successivt reducere det sidste ciffer og kontrollere, om dette er den optimale repr.
    // der er højst 9 kandidater (..1 til ..9), så dette er ret hurtigt.("rounding"-fase)
    //
    // funktionen kontrollerer, om denne "optimal" repr faktisk er inden for ulp-intervallerne, og det er også muligt, at "second-to-optimal" repr faktisk kan være optimal på grund af afrundingsfejlen.
    // i begge tilfælde returnerer dette `None`.
    // ("weeding"-fase)
    //
    // alle argumenter her skaleres af den fælles (men implicitte) værdi `k`, så:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (og også `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (og også `threshold > plus1v` fra tidligere invariantere)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // producere to tilnærmelser til `v` (faktisk `plus1 - v`) inden for 1.5 ulps.
        // den resulterende repræsentation skal være den nærmeste repræsentation for begge.
        //
        // her bruges `plus1 - v`, da beregninger udføres med hensyn til `plus1` for at undgå overflow/underflow (deraf de tilsyneladende byttede navne).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // formindsk det sidste ciffer og stop ved den nærmeste repræsentation til `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // vi arbejder med de omtrentlige cifre `w(n)`, som oprindeligt er lig med `plus1 - plus1 % 10^kappa`.efter at have kørt sløjfekroppen `n` gange, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // vi indstiller `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (altså `resten= plus1w(0)`) for at forenkle kontroller.
            // bemærk, at `plus1w(n)` altid stiger.
            //
            // vi har tre betingelser at afslutte.nogen af dem vil gøre sløjfen ikke i stand til at fortsætte, men vi har alligevel mindst en gyldig repræsentation, der vides at være tættest på `v + 1 ulp`.
            // vi vil betegne dem som TC1 til TC3 for kortfattethed.
            //
            // TC1: `w(n) <= v + 1 ulp`, dvs. dette er den sidste repr, der kan være den nærmeste.
            // dette svarer til `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // kombineret med TC2 (som kontrollerer om `w(n+1)` is valid) forhindrer det mulige overløb ved beregningen af `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, dvs. næste repr afrunder bestemt ikke til `v`.
            // dette svarer til `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // venstre side kan løbe over, men vi kender `threshold > plus1v`, så hvis TC1 er falsk, kan `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` og vi sikkert teste, om `threshold - plus1w(n) < 10^kappa` i stedet.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, dvs. den næste repr er
            // ikke tættere på `v + 1 ulp` end den aktuelle repr.
            // givet `z(n) = plus1v_up - plus1w(n)`, bliver dette `abs(z(n)) <= abs(z(n+1))`.igen forudsat at TC1 er falsk, har vi `z(n) > 0`.vi har to sager at overveje:
            //
            // - når `z(n+1) >= 0`: TC3 bliver `z(n) <= z(n+1)`.
            // da `plus1w(n)` stiger, bør `z(n)` være faldende, og dette er helt klart falsk.
            // - når `z(n+1) < 0`:
            //   - TC3a: forudsætningen er `plus1v_up < plus1w(n) + 10^kappa`.forudsat at TC2 er falsk, `threshold >= plus1w(n) + 10^kappa`, så det ikke kan løbe over.
            //   - TC3b: TC3 bliver `z(n) <= -z(n+1)`, dvs. `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   den negerede TC1 giver `plus1v_up > plus1w(n)`, så den ikke kan løbe over eller underløbe, når den kombineres med TC3a.
            //
            // derfor skal vi stoppe, når `TC1 || TC2 || (TC3a && TC3b)`.det følgende er lig med dets inverse, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // den korteste repr kan ikke ende med `0`
                plus1w += ten_kappa;
            }
        }

        // Kontroller, om denne repræsentation også er den nærmeste repræsentation til `v - 1 ulp`.
        //
        // dette er simpelthen det samme som de afsluttende betingelser for `v + 1 ulp`, idet alle `plus1v_up` erstattes af `plus1v_down` i stedet.
        // analyse af overløb holder lige meget.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // nu har vi den nærmeste repræsentation til `v` mellem `plus1` og `minus1`.
        // dette er dog for liberalt, så vi afviser enhver `w(n)` ikke mellem `plus0` og `minus0`, dvs. `plus1 - plus1w(n) <= minus0` eller `plus1 - plus1w(n) >= plus0`.
        // vi bruger de fakta, som `threshold = plus1 - minus1` og `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Den korteste tilstandsimplementering til Grisu med Dragon fallback.
///
/// Dette skal bruges i de fleste tilfælde.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // SIKKERHED: Lånekontrollen er ikke smart nok til at lade os bruge `buf`
    // i den anden branch, så vi vasker livet her.
    // Men vi genbruger kun `buf`, hvis `format_shortest_opt` returnerede `None`, så det er okay.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Den nøjagtige og faste tilstandsimplementering for Grisu.
///
/// Det returnerer `None`, når det ellers ville returnere en unøjagtig repræsentation.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // vi har brug for mindst tre bits ekstra præcision
    assert!(!buf.is_empty());

    // normalisere og skalere `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // Opdel `v` i integrerede og brøkdele.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // både gamle `v` og nye `v` (skaleret af `10^-k`) har en fejl på <1 ulp (sætning 5.1).
    // da vi ikke ved fejlen er positiv eller negativ, bruger vi to tilnærmelser fordelt ens og har den maksimale fejl på 2 ulps (det samme som det korteste tilfælde).
    //
    //
    // Målet er at finde den nøjagtigt afrundede række cifre, der er fælles for både `v - 1 ulp` og `v + 1 ulp`, så vi er maksimalt sikre.
    // hvis dette ikke er muligt, ved vi ikke, hvilken der er den rigtige output til `v`, så vi giver op og falder tilbage.
    //
    // `err` er defineret som `1 ulp * 2^e` her (det samme som ulp i `vfrac`), og vi skalerer det, når `v` bliver skaleret.
    //
    //
    //
    let mut err = 1;

    // beregne den største `10^max_kappa` ikke mere end `v` (altså `v < 10^(max_kappa+1)`).
    // dette er en øvre grænse for `kappa` nedenfor.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // hvis vi arbejder med den sidste cifrede begrænsning, er vi nødt til at forkorte bufferen før den faktiske gengivelse for at undgå dobbelt afrunding.
    //
    // bemærk, at vi er nødt til at forstørre bufferen igen, når afrunding sker!
    let len = if exp <= limit {
        // Ups, vi kan ikke engang producere *et* ciffer.
        // dette er muligt, når vi f.eks. har noget som 9.5, og det afrundes til 10.
        //
        // i princippet kan vi straks ringe til `possibly_round` med en tom buffer, men skalering af `max_ten_kappa << e` med 10 kan resultere i overløb.
        //
        // derfor er vi sjusket her og udvider fejlområdet med en faktor 10.
        // dette vil øge den falske negative sats, men kun meget,*meget* let;
        // det kan kun have betydning mærkbart, når mantissen er større end 60 bits.
        //
        // SIKKERHED: `len=0`, så forpligtelsen til at have initialiseret denne hukommelse er triviel.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // gengive integrerede dele.
    // fejlen er helt brøk, så vi behøver ikke kontrollere den i denne del.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // cifre, der endnu ikke skal gengives
    loop {
        // vi har altid mindst et ciffer til at gengive invarianter:
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (det følger, at `remainder = vint % 10^(kappa+1)`)
        //
        //

        // del `remainder` med `10^kappa`.begge skaleres med `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // er bufferen fuld?kør afrundingskortet med resten.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // SIKKERHED: vi har initialiseret `len` mange byte.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // bryde løkken, når vi har gengivet alle integrerede cifre.
        // det nøjagtige antal cifre er `max_kappa + 1` som `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // gendanne invarianter
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // gengive brøkdele.
    //
    // i princippet kan vi fortsætte til det sidste tilgængelige ciffer og kontrollere nøjagtigheden.
    // desværre arbejder vi med de endelige heltal, så vi har brug for et kriterium for at detektere overløbet.
    // V8 bruger `remainder > err`, som bliver falsk, når de første `i` signifikante cifre i `v - 1 ulp` og `v` adskiller sig.
    // dette afviser dog for mange ellers gyldige input.
    //
    // Da den senere fase har en korrekt overløbsdetektion, bruger vi i stedet strammere kriterium:
    // vi fortsætter til `err` overstiger `10^kappa / 2`, så området mellem `v - 1 ulp` og `v + 1 ulp` helt sikkert indeholder to eller flere afrundede repræsentationer.
    //
    // dette er det samme som de to første sammenligninger fra `possibly_round` til reference.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // invarianter, hvor `m = max_kappa + 1` (antal cifre i den integrerede del):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // vil ikke løbe over, `2^e * 10 < 2^64`
        err *= 10; // vil ikke løbe over, `err * 10 < 2^e * 5 < 2^64`

        // del `remainder` med `10^kappa`.
        // begge skaleres af `2^e / 10^kappa`, så sidstnævnte er implicit her.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // er bufferen fuld?kør afrundingskortet med resten.
        if i == len {
            // SIKKERHED: vi har initialiseret `len` mange byte.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // gendanne invarianter
        remainder = r;
    }

    // yderligere beregning er ubrugelig (`possibly_round` fejler bestemt), så vi giver op.
    return None;

    // Vi har genereret alle anmodede cifre i `v`, som også skal være de samme som tilsvarende cifre i `v - 1 ulp`.
    // nu kontrollerer vi, om der er en unik repræsentation, der deles af både `v - 1 ulp` og `v + 1 ulp`;dette kan være det samme for genererede cifre eller for den afrundede version af disse cifre.
    //
    // hvis området indeholder flere repræsentationer af samme længde, kan vi ikke være sikre og skal returnere `None` i stedet.
    //
    // alle argumenter her skaleres af den fælles (men implicitte) værdi `k`, så:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // SIKKERHED: de første `len`-byte i `buf` skal initialiseres.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (til reference angiver den stiplede linje den nøjagtige værdi for mulige repræsentationer i et givet antal cifre.)
        //
        //
        // fejlen er for stor til, at der er mindst tre mulige repræsentationer mellem `v - 1 ulp` og `v + 1 ulp`.
        // vi kan ikke afgøre, hvilken der er korrekt.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // faktisk er 1/2 ulp nok til at introducere to mulige repræsentationer.
        // (husk at vi har brug for en unik repræsentation for både `v - 1 ulp` og `v + 1 ulp '.) Dette løber ikke over, da `ulp < ten_kappa` fra den første kontrol.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // hvis `v + 1 ulp` er tættere på den afrundede repræsentation (som allerede findes i `buf`), kan vi sikkert vende tilbage.
        // bemærk, at `v - 1 ulp`*kan* være mindre end den nuværende repræsentation, men som `1 ulp < 10^kappa / 2` er denne betingelse tilstrækkelig:
        // afstanden mellem `v - 1 ulp` og den aktuelle repræsentation kan ikke overstige `10^kappa / 2`.
        //
        // betingelsen er lig med `remainder + ulp < 10^kappa / 2`.
        // da dette let kan løbe over, skal du først kontrollere, om `remainder < 10^kappa / 2`.
        // Vi har allerede verificeret, at `ulp < 10^kappa / 2`, så længe `10^kappa` ikke overløb, er den anden kontrol i orden.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // SIKKERHED: vores opkald initialiserede den hukommelse.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------resten------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // på den anden side, hvis `v - 1 ulp` er tættere på den afrundede repræsentation, skal vi afrunde og vende tilbage.
        // af samme grund behøver vi ikke kontrollere `v + 1 ulp`.
        //
        // betingelsen er lig med `remainder - ulp >= 10^kappa / 2`.
        // igen kontrollerer vi først, om `remainder > ulp` (bemærk, at dette ikke er `remainder >= ulp`, da `10^kappa` aldrig er nul).
        //
        // bemærk også, at `remainder - ulp <= 10^kappa`, så den anden kontrol ikke overløber.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // SIKKERHED: vores opkald skal have initialiseret den hukommelse.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // tilføj kun et ekstra ciffer, når vi er blevet anmodet om den faste præcision.
                // Vi skal også kontrollere, at hvis den originale buffer var tom, kan det ekstra ciffer kun tilføjes, når `exp == limit` (edge-sag).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // SIKKERHED: vi og vores opkalder initialiserede den hukommelse.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // ellers er vi dømt (dvs. nogle værdier mellem `v - 1 ulp` og `v + 1 ulp` afrunder og andre afrunder) og giver op.
        //
        None
    }
}

/// Den nøjagtige og faste tilstandsimplementering for Grisu med Dragon fallback.
///
/// Dette skal bruges i de fleste tilfælde.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // SIKKERHED: Lånekontrollen er ikke smart nok til at lade os bruge `buf`
    // i den anden branch, så vi vasker livet her.
    // Men vi genbruger kun `buf`, hvis `format_exact_opt` returnerede `None`, så det er okay.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}