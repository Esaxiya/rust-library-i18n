//! Eksponentestimatoren.

/// Finder `k_0` sådan, at `10^(k_0-1) < mant * 2^exp <= 10^(k_0+1)`.
///
/// Dette bruges til at tilnærme `k = ceil(log_10 (mant * 2^exp))`;
/// den sande `k` er enten `k_0` eller `k_0+1`.
#[doc(hidden)]
pub fn estimate_scaling_factor(mant: u64, exp: i16) -> i16 {
    // 2 ^ (nbits-1) <mant <=2 ^ nbits hvis mant> 0
    let nbits = 64 - (mant - 1).leading_zeros() as i64;
    // 1292913986= floor(2^32 * log_10 2) undervurderer derfor altid (eller er nøjagtigt), men ikke meget.
    //
    (((nbits + exp as i64) * 1292913986) >> 32) as i16
}