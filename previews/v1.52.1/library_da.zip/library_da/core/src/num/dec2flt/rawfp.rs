//! Bit fiddling på positive IEEE 754-floats.Negative tal er ikke og behøver ikke håndteres.
//! Normale flydende numre har en kanonisk repræsentation som (frac, exp) således, at værdien er 2 <sup>exp</sup> * (1 + sum(frac[N-i] / 2<sup>i</sup>)), hvor N er antallet af bits.
//!
//! Undernormale er lidt forskellige og underlige, men det samme princip gælder.
//!
//! Her repræsenterer vi dem dog som (sig, k) med f positive, således at værdien er f *
//! 2 <sup>e</sup> .Udover at gøre "hidden bit" eksplicit, ændrer dette eksponenten ved det såkaldte mantissa-skift.
//!
//! Sagt på en anden måde, normalt er floats skrevet som (1), men her skrives de som (2):
//!
//! 1. `1.101100...11 * 2^m`
//! 2. `1101100...11 * 2^n`
//!
//! Vi kalder (1) for **fraktioneret repræsentation** og (2) for **integreret repræsentation**.
//!
//! Mange funktioner i dette modul håndterer kun normale tal.Dec2flt-rutinerne tager konservativt den universelt korrekte langsomme sti (Algoritme M) for meget små og meget store antal.
//! Den algoritme behøver kun next_float(), som håndterer undernormaler og nuller.
//!
//!
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::convert::{TryFrom, TryInto};
use crate::fmt::{Debug, LowerExp};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;
use crate::num::FpCategory;
use crate::num::FpCategory::{Infinite, Nan, Normal, Subnormal, Zero};
use crate::ops::{Add, Div, Mul, Neg};

#[derive(Copy, Clone, Debug)]
pub struct Unpacked {
    pub sig: u64,
    pub k: i16,
}

impl Unpacked {
    pub fn new(sig: u64, k: i16) -> Self {
        Unpacked { sig, k }
    }
}

/// En hjælper trait for at undgå at duplikere stort set al konverteringskoden til `f32` og `f64`.
///
/// Se forældremodulets dok. Kommentar til, hvorfor dette er nødvendigt.
///
/// Bør **aldrig** implementeres til andre typer eller bruges uden for dec2flt-modulet.
pub trait RawFloat:
    Copy + Debug + LowerExp + Mul<Output = Self> + Div<Output = Self> + Neg<Output = Self>
{
    const INFINITY: Self;
    const NAN: Self;
    const ZERO: Self;

    /// Type brugt af `to_bits` og `from_bits`.
    type Bits: Add<Output = Self::Bits> + From<u8> + TryFrom<u64>;

    /// Udfører en rå transmutation til et heltal.
    fn to_bits(self) -> Self::Bits;

    /// Udfører en rå transmutation fra et heltal.
    fn from_bits(v: Self::Bits) -> Self;

    /// Returnerer den kategori, som dette nummer falder i.
    fn classify(self) -> FpCategory;

    /// Returnerer mantissa, eksponent og underskriver som heltal.
    fn integer_decode(self) -> (u64, i16, i8);

    /// Afkoder svømmeren.
    fn unpack(self) -> Unpacked;

    /// Afstøbninger fra et lille heltal, der kan repræsenteres nøjagtigt.
    /// Panic hvis heltal ikke kan repræsenteres, sørger den anden kode i dette modul for, at det aldrig lader ske.
    fn from_int(x: u64) -> Self;

    /// Får værdien 10 <sup>e</sup> fra en forudberegnet tabel.
    /// Panics til `e >= CEIL_LOG5_OF_MAX_SIG`.
    fn short_fast_pow10(e: usize) -> Self;

    /// Hvad navnet siger.
    /// Det er lettere at hårdkode end at jonglere med iboende egenskaber og håber, at LLVM konstant folder det.
    const CEIL_LOG5_OF_MAX_SIG: i16;

    // En konservativ bundet til decimaltallet på input, der ikke kan producere overløb eller nul eller
    /// undernormale.Sandsynligvis den decimale eksponent for den maksimale normale værdi, deraf navnet.
    const MAX_NORMAL_DIGITS: usize;

    /// Når det mest betydningsfulde decimaltal har en større pladsværdi end dette, afrundes tallet bestemt til uendelig.
    ///
    const INF_CUTOFF: i64;

    /// Når det mest betydningsfulde decimaltal har en mindre værdi end dette, afrundes tallet bestemt til nul.
    ///
    const ZERO_CUTOFF: i64;

    /// Antallet af bits i eksponenten.
    const EXP_BITS: u8;

    /// Antallet af bits i signifikant,*inklusive* den skjulte bit.
    const SIG_BITS: u8;

    /// Antallet af bits i signifikant,*eksklusive* den skjulte bit.
    const EXPLICIT_SIG_BITS: u8;

    /// Den maksimale juridiske eksponent i fraktioneret repræsentation.
    const MAX_EXP: i16;

    /// Den mindste juridiske eksponent i fraktioneret repræsentation, eksklusive undernormale.
    const MIN_EXP: i16;

    /// `MAX_EXP` til integreret repræsentation, dvs. med det anvendte skift.
    const MAX_EXP_INT: i16;

    /// `MAX_EXP` kodet (dvs. med offset bias)
    const MAX_ENCODED_EXP: i16;

    /// `MIN_EXP` til integreret repræsentation, dvs. med det anvendte skift.
    const MIN_EXP_INT: i16;

    /// Den maksimale normaliserede betydning i integreret repræsentation.
    const MAX_SIG: u64;

    /// Den minimale normaliserede betydning i integreret repræsentation.
    const MIN_SIG: u64;
}

// For det meste en løsning til #34344.
macro_rules! other_constants {
    ($type: ident) => {
        const EXPLICIT_SIG_BITS: u8 = Self::SIG_BITS - 1;
        const MAX_EXP: i16 = (1 << (Self::EXP_BITS - 1)) - 1;
        const MIN_EXP: i16 = -<Self as RawFloat>::MAX_EXP + 1;
        const MAX_EXP_INT: i16 = <Self as RawFloat>::MAX_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_ENCODED_EXP: i16 = (1 << Self::EXP_BITS) - 1;
        const MIN_EXP_INT: i16 = <Self as RawFloat>::MIN_EXP - (Self::SIG_BITS as i16 - 1);
        const MAX_SIG: u64 = (1 << Self::SIG_BITS) - 1;
        const MIN_SIG: u64 = 1 << (Self::SIG_BITS - 1);

        const INFINITY: Self = $type::INFINITY;
        const NAN: Self = $type::NAN;
        const ZERO: Self = 0.0;
    };
}

impl RawFloat for f32 {
    type Bits = u32;

    const SIG_BITS: u8 = 24;
    const EXP_BITS: u8 = 8;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 11;
    const MAX_NORMAL_DIGITS: usize = 35;
    const INF_CUTOFF: i64 = 40;
    const ZERO_CUTOFF: i64 = -48;
    other_constants!(f32);

    /// Returnerer mantissa, eksponent og underskriver som heltal.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 31 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 23) & 0xff) as i16;
        let mantissa =
            if exponent == 0 { (bits & 0x7fffff) << 1 } else { (bits & 0x7fffff) | 0x800000 };
        // Eksponent bias + mantissa skift
        exponent -= 127 + 23;
        (mantissa as u64, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f32 {
        // rkruppe er usikker på, om `as` runder korrekt på alle platforme.
        debug_assert!(x as f32 == fp_to_float(Fp { f: x, e: 0 }));
        x as f32
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F32_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

impl RawFloat for f64 {
    type Bits = u64;

    const SIG_BITS: u8 = 53;
    const EXP_BITS: u8 = 11;
    const CEIL_LOG5_OF_MAX_SIG: i16 = 23;
    const MAX_NORMAL_DIGITS: usize = 305;
    const INF_CUTOFF: i64 = 310;
    const ZERO_CUTOFF: i64 = -326;
    other_constants!(f64);

    /// Returnerer mantissa, eksponent og underskriver som heltal.
    fn integer_decode(self) -> (u64, i16, i8) {
        let bits = self.to_bits();
        let sign: i8 = if bits >> 63 == 0 { 1 } else { -1 };
        let mut exponent: i16 = ((bits >> 52) & 0x7ff) as i16;
        let mantissa = if exponent == 0 {
            (bits & 0xfffffffffffff) << 1
        } else {
            (bits & 0xfffffffffffff) | 0x10000000000000
        };
        // Eksponent bias + mantissa skift
        exponent -= 1023 + 52;
        (mantissa, exponent, sign)
    }

    fn unpack(self) -> Unpacked {
        let (sig, exp, _sig) = self.integer_decode();
        Unpacked::new(sig, exp)
    }

    fn from_int(x: u64) -> f64 {
        // rkruppe er usikker på, om `as` runder korrekt på alle platforme.
        debug_assert!(x as f64 == fp_to_float(Fp { f: x, e: 0 }));
        x as f64
    }

    fn short_fast_pow10(e: usize) -> Self {
        table::F64_SHORT_POWERS[e]
    }

    fn classify(self) -> FpCategory {
        self.classify()
    }
    fn to_bits(self) -> Self::Bits {
        self.to_bits()
    }
    fn from_bits(v: Self::Bits) -> Self {
        Self::from_bits(v)
    }
}

/// Konverterer en `Fp` til den nærmeste maskinfloat-type.
/// Håndterer ikke subnormale resultater.
pub fn fp_to_float<T: RawFloat>(x: Fp) -> T {
    let x = x.normalize();
    // x.f er 64 bit, så xe har et mantissa-skift på 63
    let e = x.e + 63;
    if e > T::MAX_EXP {
        panic!("fp_to_float: exponent {} too large", e)
    } else if e > T::MIN_EXP {
        encode_normal(round_normal::<T>(x))
    } else {
        panic!("fp_to_float: exponent {} too small", e)
    }
}

/// Rund 64-bit signifikant til T::SIG_BITS bits med halv-til-lige.
/// Håndterer ikke eksponentoverløb.
pub fn round_normal<T: RawFloat>(x: Fp) -> Unpacked {
    let excess = 64 - T::SIG_BITS as i16;
    let half: u64 = 1 << (excess - 1);
    let (q, rem) = (x.f >> excess, x.f & ((1 << excess) - 1));
    assert_eq!(q << excess | rem, x.f);
    // Juster mantissaskift
    let k = x.e + excess;
    if rem < half {
        Unpacked::new(q, k)
    } else if rem == half && (q % 2) == 0 {
        Unpacked::new(q, k)
    } else if q == T::MAX_SIG {
        Unpacked::new(T::MIN_SIG, k + 1)
    } else {
        Unpacked::new(q + 1, k)
    }
}

/// Omvendt af `RawFloat::unpack()` for normaliserede tal.
/// Panics hvis signifikant eller eksponent ikke er gyldig for normaliserede tal.
pub fn encode_normal<T: RawFloat>(x: Unpacked) -> T {
    debug_assert!(
        T::MIN_SIG <= x.sig && x.sig <= T::MAX_SIG,
        "encode_normal: significand not normalized"
    );
    // Fjern den skjulte bit
    let sig_enc = x.sig & !(1 << T::EXPLICIT_SIG_BITS);
    // Juster eksponenten for eksponent bias og mantissa skift
    let k_enc = x.k + T::MAX_EXP + T::EXPLICIT_SIG_BITS as i16;
    debug_assert!(k_enc != 0 && k_enc < T::MAX_ENCODED_EXP, "encode_normal: exponent out of range");
    // Efterlad tegnbit på 0 ("+"), vores tal er alle positive
    let bits = (k_enc as u64) << T::EXPLICIT_SIG_BITS | sig_enc;
    T::from_bits(bits.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Konstruer et subnormalt.En mantissa på 0 er tilladt og konstruerer nul.
pub fn encode_subnormal<T: RawFloat>(significand: u64) -> T {
    assert!(significand < T::MIN_SIG, "encode_subnormal: not actually subnormal");
    // Kodet eksponent er 0, tegnbit er 0, så vi skal bare fortolke bitene.
    T::from_bits(significand.try_into().unwrap_or_else(|_| unreachable!()))
}

/// Omtrentlig et bignum med en Fp.Runder inden for 0.5 ULP med halv til jævn.
pub fn big_to_fp(f: &Big) -> Fp {
    let end = f.bit_length();
    assert!(end != 0, "big_to_fp: unexpectedly, input is zero");
    let start = end.saturating_sub(64);
    let leading = num::get_bits(f, start, end);
    // Vi afskærer alle bits før indekset `start`, dvs. vi skifter effektivt med et beløb på `start`, så dette er også den eksponent, vi har brug for.
    //
    let e = start as i16;
    let rounded_down = Fp { f: leading, e }.normalize();
    // Runde (half-to-even) afhængigt af de trunkerede bits.
    match num::compare_with_half_ulp(f, start) {
        Less => rounded_down,
        Equal if leading % 2 == 0 => rounded_down,
        Equal | Greater => match leading.checked_add(1) {
            Some(f) => Fp { f, e }.normalize(),
            None => Fp { f: 1 << 63, e: e + 1 },
        },
    }
}

/// Finder det største flydende punktummer, der er strengt mindre end argumentet.
/// Håndterer ikke undernormale, nul eller eksponent understrømning.
pub fn prev_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Infinite => panic!("prev_float: argument is infinite"),
        Nan => panic!("prev_float: argument is NaN"),
        Subnormal => panic!("prev_float: argument is subnormal"),
        Zero => panic!("prev_float: argument is zero"),
        Normal => {
            let Unpacked { sig, k } = x.unpack();
            if sig == T::MIN_SIG {
                encode_normal(Unpacked::new(T::MAX_SIG, k - 1))
            } else {
                encode_normal(Unpacked::new(sig - 1, k))
            }
        }
    }
}

// Find det mindste flydende nummer, der er strengt større end argumentet.
// Denne handling er mættende, dvs. next_float(inf) ==inf.
// I modsætning til de fleste koder i dette modul håndterer denne funktion nul, undernormaler og uendelighed.
// Som alle andre koder her beskæftiger den sig imidlertid ikke med NaN og negative tal.
pub fn next_float<T: RawFloat>(x: T) -> T {
    match x.classify() {
        Nan => panic!("next_float: argument is NaN"),
        Infinite => T::INFINITY,
        // Dette synes for godt til at være sandt, men det virker.
        // 0.0 er kodet som ordet helt nul.Undernormaler er 0x000m ... m hvor m er mantissen.
        // Især er den mindste subnormale 0x0 ... 01 og den største 0x000F ... F.
        // Det mindste normale tal er 0x0010 ... 0, så dette hjørnesag fungerer også.
        // Hvis inkrementet løber over mantissen, inkrementerer carry-biten eksponenten, som vi ønsker, og mantissabitene bliver nul.
        // På grund af den skjulte bitkonvention er dette også præcis det, vi vil have!
        // Endelig er f64::MAX + 1=7eff ... f + 1=7ff0 ... 0= f64::INFINITY.
        //
        Zero | Subnormal | Normal => T::from_bits(x.to_bits() + T::Bits::from(1u8)),
    }
}