//! De forskellige algoritmer fra papiret.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Antal signifikante bits i Fp
const P: u32 = 64;

// Vi gemmer simpelthen den bedste tilnærmelse til *alle* eksponenter, så variablen "h" og de tilknyttede betingelser kan udelades.
// Dette bytter ydeevne for et par kilobyte plads.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// I de fleste arkitekturer har flydende punktoperationer en eksplicit bitstørrelse, hvorfor beregningens nøjagtighed bestemmes på en operation.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// På x86 bruges x87 FPU til floatoperationer, hvis SSE/SSE2-udvidelser ikke er tilgængelige.
// x87 FPU fungerer som standard med 80 bit præcision, hvilket betyder, at operationer afrundes til 80 bit, hvilket får dobbelt afrunding, når værdier til sidst repræsenteres som
//
// 32/64 bit float værdier.For at overvinde dette kan FPU-kontrolordet indstilles, så beregningerne udføres i den ønskede præcision.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// En struktur, der bruges til at bevare den oprindelige værdi af FPU-kontrolordet, så det kan gendannes, når strukturen slippes.
    ///
    ///
    /// x87 FPU er et 16-bit register, hvis felter er som følger:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Dokumentationen for alle felterne er tilgængelig i IA-32 Architectures Software Developer's Manual (bind 1).
    ///
    /// Det eneste felt, der er relevant for følgende kode, er PC, Precision Control.
    /// Dette felt bestemmer nøjagtigheden af de operationer, der udføres af FPU.
    /// Det kan indstilles til:
    ///  - 0b00, enkelt præcision dvs. 32-bit
    ///  - 0b10, dobbelt præcision dvs. 64-bit
    ///  - 0b11, dobbelt udvidet præcision dvs. 80-bit (standardtilstand) 0b01-værdien er reserveret og bør ikke bruges.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // SIKKERHED: `fldcw`-instruktionen er blevet revideret for at kunne arbejde korrekt med
        // enhver `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Vi bruger ATT-syntaks til at understøtte LLVM 8 og LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Indstiller FPU's præcisionsfelt til `T` og returnerer en `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Beregn værdien for feltet Precision Control, der passer til `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // 32 bits
            8 => 0x0200, // 64 bit
            _ => 0x0300, // standard, 80 bit
        };

        // Få den oprindelige værdi af kontrolordet for at gendanne det senere, når `FPUControlWord`-strukturen er faldet SIKKERHED: `fnstcw`-instruktionen er blevet revideret for at kunne fungere korrekt med enhver `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Vi bruger ATT-syntaks til at understøtte LLVM 8 og LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Indstil kontrolordet til den ønskede præcision.
        // Dette opnås ved at maskere den gamle præcision (bit 8 og 9, 0x300) væk og erstatte den med det ovenfor anførte præcisionsflag.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Bellerophons hurtige sti ved hjælp af heltal og flyder i maskinstørrelse.
///
/// Dette ekstraheres til en separat funktion, så det kan forsøges, før der konstrueres en bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Vi sammenligner den nøjagtige værdi med MAX_SIG nær slutningen, dette er bare en hurtig, billig afvisning (og frigør også resten af koden fra at bekymre sig om underflow).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Den hurtige sti afhænger altafgørende af, at aritmetik afrundes til det rigtige antal bits uden nogen mellemafrunding.
    // På x86 (uden SSE eller SSE2) kræver dette, at præcisionen i x87 FPU-stakken ændres, så den direkte afrunder til 64/32-bit.
    // `set_precision`-funktionen sørger for at indstille præcisionen på arkitekturer, der kræver indstilling ved at ændre den globale tilstand (som kontrolordet for x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Sagen e <0 kan ikke foldes ind i den anden branch.
    // Negative kræfter resulterer i en gentagende brøkdel i binær, som er afrundet, hvilket forårsager reelle (og lejlighedsvis ret signifikante!) Fejl i det endelige resultat.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algoritme Bellerophon er triviel kode retfærdiggjort ved ikke-triviel numerisk analyse.
///
/// Den afrunder `` f '' til en float med 64 bit signifikant og multiplicerer den med den bedste tilnærmelse af `10^e` (i samme flydende punktformat).Dette er ofte nok til at få det korrekte resultat.
/// Men når resultatet er tæt på halvvejs mellem to tilstødende (ordinary)-flyder, betyder den sammensatte afrundingsfejl ved at multiplicere to tilnærmelser, at resultatet kan være slået fra med et par bits.
/// Når dette sker, løser den iterative algoritme R tingene op.
///
/// Den håndbølgede "close to halfway" gøres præcis ved hjælp af den numeriske analyse i papiret.
/// Med Clinger's ord:
///
/// > Slop, udtrykt i enheder med den mindst signifikante bit, er en inkluderende grænse for fejlen
/// > akkumuleret under flydepunktsberegningen af tilnærmelsen til f * 10 ^ e.(Slop er
/// > ikke er bundet til den sande fejl, men afgrænser forskellen mellem tilnærmelsen z og
/// > den bedst mulige tilnærmelse, der bruger p-bits af significand.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Sagerne abs(e) <log5(2^N) er i fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Er skråningen stor nok til at gøre en forskel, når den afrundes til n bits?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// En iterativ algoritme, der forbedrer en tilnærmelse til flydende punkt på `f * 10^e`.
///
/// Hver iteration kommer en enhed på det sidste sted tættere på, hvilket naturligvis tager frygtelig lang tid at konvergere, hvis `z0` endda er mildt slået fra.
/// Heldigvis, når den bruges som tilbageførsel for Bellerophon, er starttilnærmelsen fra højst en ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Find positive heltal `x`, `y` sådan at `x / y` er nøjagtigt `(f *10^e) / (m* 2^k)`.
        // Dette undgår ikke kun at håndtere tegnene på `e` og `k`, vi eliminerer også kraften fra to, der er fælles for `10^e` og `2^k` for at gøre antallet mindre.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Dette skrives lidt akavet, fordi vores bignums ikke understøtter negative tal, så vi bruger den absolutte værdi + tegninformation.
        // Multiplikationen med m_digits kan ikke løbe over.
        // Hvis `x` eller `y` er store nok til, at vi skal bekymre os om overløb, er de også store nok til, at `make_ratio` har reduceret brøken med en faktor på 2 ^ 64 eller mere.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Brug ikke x mere, gem en clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Har stadig brug for y, lav en kopi.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Givet `x = f` og `y = m`, hvor `f` repræsenterer input-decimal cifre som sædvanlig, og `m` er betydningen af en tilnærmelse til et flydende punkt, gør forholdet `x / y` lig med `(f *10^e) / (m* 2^k)`, muligvis reduceret med en effekt på to, som begge har til fælles.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, bortset fra at vi reducerer brøken med en kraft på to.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Dette kan ikke løbe over, fordi det kræver positiv `e` og negativ `k`, hvilket kun kan ske for værdier, der er meget tæt på 1, hvilket betyder, at `e` og `k` vil være forholdsvis lille.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Dette kan heller ikke løbe over, se ovenfor.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), hvilket igen reduceres med en fælles effekt på to.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Konceptuelt er algoritme M den enkleste måde at konvertere en decimal til en float.
///
/// Vi danner et forhold, der er lig med `f * 10^e`, og derefter kaster vi kræfter på to, indtil det giver en gyldig float significand.
/// Den binære eksponent `k` er antallet af gange, vi multiplicerer tæller eller nævner med to, dvs. at `f *10^e` til enhver tid er lig med `(u / v)* 2^k`.
/// Når vi har fundet ud af betydningen, behøver vi kun at afrunde ved at inspicere resten af divisionen, hvilket gøres i hjælpefunktioner længere nedenfor.
///
///
/// Denne algoritme er super langsom, selv med optimeringen beskrevet i `quick_start()`.
/// Det er dog den enkleste af algoritmerne at tilpasse sig til overløbs-, underflow-og subnormale resultater.
/// Denne implementering overtager, når Bellerophon og Algorithm R er overvældet.
/// Det er let at detektere understrømning og overløb: Forholdet er stadig ikke inden for rækkevidde, men minimum/maximum-eksponenten er nået.
/// I tilfælde af overløb returnerer vi simpelthen uendelig.
///
/// Håndtering af underflow og undernormaler er vanskeligere.
/// Et stort problem er, at forholdet med minimumseksponenten stadig kan være for stort til et betydningsfuldt.
/// Se underflow() for detaljer.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME mulig optimering: generaliser big_to_fp, så vi kan gøre det svarende til fp_to_float(big_to_fp(u)) her, kun uden dobbelt afrunding.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Vi er nødt til at stoppe ved minimumseksponenten, hvis vi venter til `k < T::MIN_EXP_INT`, ville vi være væk med en faktor på to.
            // Desværre betyder det, at vi skal specialtilfælde normale tal med mindsteksponenten.
            // FIXME finder en mere elegant formulering, men kør `tiny-pow10`-testen for at sikre, at den faktisk er korrekt!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Springer over de fleste algoritm-M iterationer ved at kontrollere bitlængden.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Bitlængden er et skøn over de to basale logaritmer og log(u / v) = log(u), log(v).
    // Estimatet er højst slået fra 1, men altid et underestimat, så fejlen på log(u) og log(v) er af samme tegn og annulleres (hvis begge er store).
    // Derfor er fejlen for log(u / v) også højst en.
    // Målforholdet er et, hvor u/v er inden for en betydningsfuld rækkevidde.Således er vores opsigelsesbetingelse log2(u / v), der er de signifikante bits, plus/minus en.
    // FIXME At se på den anden bit kunne forbedre estimatet og undgå nogle flere divisioner.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Underflow eller subnormal.Overlad det til hovedfunktionen.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Flyde over.Overlad det til hovedfunktionen.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Forholdet er ikke en rækkevidde inden for området med den mindste eksponent, så vi er nødt til at afrunde overskydende bits og justere eksponenten i overensstemmelse hermed.
    // Den reelle værdi ser nu sådan ud:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(repræsenteret af rem)
    //
    // Derfor, når de afrundede bits er!= 0.5 ULP, bestemmer de afrundingen alene.
    // Når de er ens, og resten er ikke-nul, skal værdien stadig afrundes.
    // Først når de afrundede bits er 1/2, og resten er nul, har vi en halv til jævn situation.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Almindelig rund-til-lige, tilsløret ved at skulle runde baseret på resten af en division.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}