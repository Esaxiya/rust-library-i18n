//! Funktioner til bignums, der ikke giver for meget mening til at blive til metoder.

// FIXME Dette moduls navn er lidt uheldigt, da andre moduler også importerer `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Test om afkortning af alle bits, der er mindre signifikante end `ones_place`, introducerer en relativ fejl mindre, lig eller større end 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Hvis alle resterende bits er nul, er det= 0.5 ULP, ellers> 0.5 Hvis der ikke er flere bits (half_bit==0), returnerer nedenstående også lig.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Konverterer en ASCII-streng, der kun indeholder decimaltal til en `u64`.
///
/// Udfører ikke kontrol for overløb eller ugyldige tegn, så hvis den, der ringer, ikke er forsigtig, er resultatet falsk og kan panic (selvom det ikke er `unsafe`).
/// Derudover behandles tomme strenge som nul.
/// Denne funktion findes pga
///
/// 1. brug af `FromStr` på `&[u8]` kræver `from_utf8_unchecked`, hvilket er dårligt, og
/// 2. at samle resultaterne af `integral.parse()` og `fractional.parse()` er mere kompliceret end hele denne funktion.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Konverterer en streng af ASCII-cifre til et bignum.
///
/// Ligesom `from_str_unchecked` er denne funktion afhængig af parseren for at udrydde ikke-cifre.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Pakker et bignum ind i et 64 bit heltal.Panics hvis antallet er for stort.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Uddrag en række bits.

/// Indeks 0 er den mindst betydningsfulde bit, og rækkevidden er halvåben som normalt.
/// Panics hvis bedt om at udtrække flere bits, end der passer ind i returtypen.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}