//! Fejltyper til konvertering til integraltyper.

use crate::convert::Infallible;
use crate::fmt;

/// Fejltypen returneres, når en kontrolleret konvertering af integraltype mislykkes.
#[stable(feature = "try_from", since = "1.34.0")]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub struct TryFromIntError(pub(crate) ());

impl TryFromIntError {
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        "out of range integral type conversion attempted"
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl fmt::Display for TryFromIntError {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(fmt)
    }
}

#[stable(feature = "try_from", since = "1.34.0")]
impl From<Infallible> for TryFromIntError {
    fn from(x: Infallible) -> TryFromIntError {
        match x {}
    }
}

#[unstable(feature = "never_type", issue = "35121")]
impl From<!> for TryFromIntError {
    fn from(never: !) -> TryFromIntError {
        // Match snarere end at tvinge for at sikre, at kode som `From<Infallible> for TryFromIntError` ovenfor fortsætter med at fungere, når `Infallible` bliver et alias til `!`.
        //
        //
        match never {}
    }
}

/// En fejl, som kan returneres ved parsing af et heltal.
///
/// Denne fejl bruges som fejltype for `from_str_radix()`-funktionerne på de primitive heltalstyper, såsom [`i8::from_str_radix`].
///
/// # Potentielle årsager
///
/// Blandt andre årsager kan `ParseIntError` kastes på grund af ledende eller efterfølgende hvidt mellemrum i strengen, fx når det opnås fra standardindgangen.
///
/// Brug af [`str::trim()`]-metoden sikrer, at der ikke er noget mellemrum tilbage inden parsing.
///
/// # Example
///
/// ```
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {}", e);
/// }
/// ```
///
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseIntError {
    pub(super) kind: IntErrorKind,
}

/// Enum til at gemme de forskellige typer fejl, der kan forårsage, at parsing af et heltal mislykkes.
///
/// # Example
///
/// ```
/// #![feature(int_error_matching)]
///
/// # fn main() {
/// if let Err(e) = i32::from_str_radix("a12", 10) {
///     println!("Failed conversion to i32: {:?}", e.kind());
/// }
/// # }
/// ```
#[unstable(
    feature = "int_error_matching",
    reason = "it can be useful to match errors when making error messages \
              for integer parsing",
    issue = "22639"
)]
#[derive(Debug, Clone, PartialEq, Eq)]
#[non_exhaustive]
pub enum IntErrorKind {
    /// Værdien, der analyseres, er tom.
    ///
    /// Blandt andre årsager konstrueres denne variant, når man analyserer en tom streng.
    Empty,
    /// Indeholder et ugyldigt tal i sin sammenhæng.
    ///
    /// Blandt andre årsager konstrueres denne variant, når man analyserer en streng, der indeholder en ikke-ASCII-tegn.
    ///
    /// Denne variant er også konstrueret, når en `+` eller `-` er forkert placeret i en streng enten alene eller midt i et tal.
    ///
    ///
    InvalidDigit,
    /// Heltal er for stort til at gemme i mål-heltalstypen.
    PosOverflow,
    /// Heltal er for lille til at gemme i mål-heltalstypen.
    NegOverflow,
    /// Værdien var nul
    ///
    /// Denne variant udsendes, når parsingestrengen har en værdi på nul, hvilket ville være ulovligt for ikke-nul-typer.
    ///
    Zero,
}

impl ParseIntError {
    /// Udsender den detaljerede årsag til, at et heltal mislykkes.
    #[unstable(
        feature = "int_error_matching",
        reason = "it can be useful to match errors when making error messages \
              for integer parsing",
        issue = "22639"
    )]
    pub fn kind(&self) -> &IntErrorKind {
        &self.kind
    }
    #[unstable(
        feature = "int_error_internals",
        reason = "available through Error trait and this method should \
                  not be exposed publicly",
        issue = "none"
    )]
    #[doc(hidden)]
    pub fn __description(&self) -> &str {
        match self.kind {
            IntErrorKind::Empty => "cannot parse integer from empty string",
            IntErrorKind::InvalidDigit => "invalid digit found in string",
            IntErrorKind::PosOverflow => "number too large to fit in target type",
            IntErrorKind::NegOverflow => "number too small to fit in target type",
            IntErrorKind::Zero => "number would be zero for non-zero type",
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseIntError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.__description().fmt(f)
    }
}