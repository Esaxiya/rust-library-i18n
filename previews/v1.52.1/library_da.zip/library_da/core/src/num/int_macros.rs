macro_rules! int_impl {
    ($SelfT:ty, $ActualT:ident, $UnsignedT:ty, $BITS:expr, $Min:expr, $Max:expr,
     $rot:expr, $rot_op:expr, $rot_result:expr, $swap_op:expr, $swapped:expr,
     $reversed:expr, $le_bytes:expr, $be_bytes:expr,
     $to_xe_bytes_doc:expr, $from_xe_bytes_doc:expr) => {
        /// Den mindste værdi, der kan repræsenteres af denne heltalstype.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN, ", stringify!($Min), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MIN: Self = !0 ^ ((!0 as $UnsignedT) >> 1) as Self;

        /// Den største værdi, der kan repræsenteres af denne heltalstype.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX, ", stringify!($Max), ");")]
        /// ```
        #[stable(feature = "assoc_int_consts", since = "1.43.0")]
        pub const MAX: Self = !Self::MIN;

        /// Størrelsen på denne heltalstype i bits.
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(int_bits_const)]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::BITS, ", stringify!($BITS), ");")]
        /// ```
        #[unstable(feature = "int_bits_const", issue = "76904")]
        pub const BITS: u32 = $BITS;

        /// Konverterer en strengskive i en given base til et heltal.
        ///
        /// Strengen forventes at være et valgfrit `+`-eller `-`-tegn efterfulgt af cifre.
        /// Ledende og efterfølgende mellemrum repræsenterer en fejl.
        /// Cifre er en delmængde af disse tegn afhængigt af `radix`:
        ///
        ///  * `0-9`
        ///  * `a-z`
        ///  * `A-Z`
        ///
        /// # Panics
        ///
        /// Denne funktion panics, hvis `radix` ikke er i området fra 2 til 36.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::from_str_radix(\"A\", 16), Ok(10));")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        pub fn from_str_radix(src: &str, radix: u32) -> Result<Self, ParseIntError> {
            from_str_radix(src, radix)
        }

        /// Returnerer antallet af dem i den binære repræsentation af `self`.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("let n = 0b100_0000", stringify!($SelfT), ";")]
        /// assert_eq!(n.count_ones(), 1);
        ///
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[doc(alias = "popcount")]
        #[doc(alias = "popcnt")]
        #[inline]
        pub const fn count_ones(self) -> u32 { (self as $UnsignedT).count_ones() }

        /// Returnerer antallet af nuller i den binære repræsentation af `self`.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.count_zeros(), 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn count_zeros(self) -> u32 {
            (!self).count_ones()
        }

        /// Returnerer antallet af førende nuller i den binære repræsentation af `self`.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]
        /// assert_eq!(n.leading_zeros(), 0);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn leading_zeros(self) -> u32 {
            (self as $UnsignedT).leading_zeros()
        }

        /// Returnerer antallet af efterfølgende nuller i den binære repræsentation af `self`.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("let n = -4", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_zeros(), 2);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn trailing_zeros(self) -> u32 {
            (self as $UnsignedT).trailing_zeros()
        }

        /// Returnerer antallet af førende i den binære repræsentation af `self`.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("let n = -1", stringify!($SelfT), ";")]

        #[doc = concat!("assert_eq!(n.leading_ones(), ", stringify!($BITS), ");")]
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn leading_ones(self) -> u32 {
            (self as $UnsignedT).leading_ones()
        }

        /// Returnerer antallet af bageste i den binære repræsentation af `self`.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("let n = 3", stringify!($SelfT), ";")]
        /// assert_eq!(n.trailing_ones(), 2);
        /// ```
        #[stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[rustc_const_stable(feature = "leading_trailing_ones", since = "1.46.0")]
        #[inline]
        pub const fn trailing_ones(self) -> u32 {
            (self as $UnsignedT).trailing_ones()
        }

        /// Flytter bitene til venstre med et specificeret beløb, `n`, der indpakker de afkortede bits til slutningen af det resulterende heltal.
        ///
        ///
        /// Bemærk, at dette ikke er den samme handling som `<<`-skiftoperatøren!
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("let n = ", $rot_op, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_result, ";")]

        #[doc = concat!("assert_eq!(n.rotate_left(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_left(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_left(n) as Self
        }

        /// Skifter bitene til højre med et bestemt beløb, `n`, der indpakker de afkortede bits til begyndelsen af det resulterende heltal.
        ///
        ///
        /// Bemærk, at dette ikke er den samme handling som `>>`-skiftoperatøren!
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        ///
        #[doc = concat!("let n = ", $rot_result, stringify!($SelfT), ";")]
        #[doc = concat!("let m = ", $rot_op, ";")]

        #[doc = concat!("assert_eq!(n.rotate_right(", $rot, "), m);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn rotate_right(self, n: u32) -> Self {
            (self as $UnsignedT).rotate_right(n) as Self
        }

        /// Vender heltalets byte rækkefølge.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// lad m= n.swap_bytes();
        ///
        #[doc = concat!("assert_eq!(m, ", $swapped, ");")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn swap_bytes(self) -> Self {
            (self as $UnsignedT).swap_bytes() as Self
        }

        /// Vender rækkefølgen af bits i heltal.
        /// Den mindst signifikante bit bliver den mest betydningsfulde bit, den anden mindst signifikante bit bliver næstmest signifikante bit osv
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("let n = ", $swap_op, stringify!($SelfT), ";")]
        /// lad m= n.reverse_bits();
        ///
        #[doc = concat!("assert_eq!(m, ", $reversed, ");")]
        #[doc = concat!("assert_eq!(0, 0", stringify!($SelfT), ".reverse_bits());")]
        /// ```
        #[stable(feature = "reverse_bits", since = "1.37.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        #[must_use]
        pub const fn reverse_bits(self) -> Self {
            (self as $UnsignedT).reverse_bits() as Self
        }

        /// Konverterer et helt tal fra stor endian til målets endianness.
        ///
        /// På store endian er dette et no-op.På lille endian byttes byte.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// hvis cfg! (target_endian= "big"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n)")]
        /// } andet {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_be(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_be(x: Self) -> Self {
            #[cfg(target_endian = "big")]
            {
                x
            }
            #[cfg(not(target_endian = "big"))]
            {
                x.swap_bytes()
            }
        }

        /// Konverterer et helt tal fra lille endian til målets endianness.
        ///
        /// På lille endian er dette et no-op.På store endian byttes byte.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// hvis cfg! (target_endian= "little"){
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n)")]
        /// } andet {
        #[doc = concat!("    assert_eq!(", stringify!($SelfT), "::from_le(n), n.swap_bytes())")]
        /// }
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn from_le(x: Self) -> Self {
            #[cfg(target_endian = "little")]
            {
                x
            }
            #[cfg(not(target_endian = "little"))]
            {
                x.swap_bytes()
            }
        }

        /// Konverterer `self` til stor endian fra målets endianness.
        ///
        /// På store endian er dette et no-op.På lille endian byttes byte.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// hvis cfg! (target_endian= "big"){
        ///     assert_eq!(n.to_be(), n)
        /// } ellers { assert_eq!(n.to_be(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_be(self) -> Self { // eller ikke være?
            #[cfg(target_endian = "big")]
            {
                self
            }
            #[cfg(not(target_endian = "big"))]
            {
                self.swap_bytes()
            }
        }

        /// Konverterer `self` til lille endian fra målets endianness.
        ///
        /// På lille endian er dette et no-op.På store endian byttes byte.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("let n = 0x1A", stringify!($SelfT), ";")]
        /// hvis cfg! (target_endian= "little"){
        ///     assert_eq!(n.to_le(), n)
        /// } ellers { assert_eq!(n.to_le(), n.swap_bytes()) }
        ///
        /// ```
        ///
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_conversions", since = "1.32.0")]
        #[inline]
        pub const fn to_le(self) -> Self {
            #[cfg(target_endian = "little")]
            {
                self
            }
            #[cfg(not(target_endian = "little"))]
            {
                self.swap_bytes()
            }
        }

        /// Kontrolleret tilføjelse af heltal.
        /// Beregner `self + rhs`, returnerer `None`, hvis der opstod overløb.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(1), Some(", stringify!($SelfT), "::MAX - 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MAX - 2).checked_add(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_add(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_add(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Ikke-markeret heltalstilsætning.Beregner `self + rhs`, forudsat at overløb ikke kan forekomme.
        /// Dette resulterer i udefineret adfærd, når
        #[doc = concat!("`self + rhs > ", stringify!($SelfT), "::MAX` or `self + rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_add(self, rhs: Self) -> Self {
            // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `unchecked_add`.
            //
            unsafe { intrinsics::unchecked_add(self, rhs) }
        }

        /// Kontrolleret heltalstraktion.
        /// Beregner `self - rhs`, returnerer `None`, hvis der opstod overløb.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(1), Some(", stringify!($SelfT), "::MIN + 1));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 2).checked_sub(3), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_sub(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_sub(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Umarkeret heltalstraktion.Beregner `self - rhs`, forudsat at overløb ikke kan forekomme.
        /// Dette resulterer i udefineret adfærd, når
        #[doc = concat!("`self - rhs > ", stringify!($SelfT), "::MAX` or `self - rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_sub(self, rhs: Self) -> Self {
            // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `unchecked_sub`.
            //
            unsafe { intrinsics::unchecked_sub(self, rhs) }
        }

        /// Kontrolleret multiplikation af heltal.
        /// Beregner `self * rhs`, returnerer `None`, hvis der opstod overløb.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(1), Some(", stringify!($SelfT), "::MAX));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_mul(2), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_mul(self, rhs: Self) -> Option<Self> {
            let (a, b) = self.overflowing_mul(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Ikke-markeret heltalsmultiplikation.Beregner `self * rhs`, forudsat at overløb ikke kan forekomme.
        /// Dette resulterer i udefineret adfærd, når
        #[doc = concat!("`self * rhs > ", stringify!($SelfT), "::MAX` or `self * rhs < ", stringify!($SelfT), "::MIN`.")]
        #[unstable(
            feature = "unchecked_math",
            reason = "niche optimization path",
            issue = "none",
        )]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub unsafe fn unchecked_mul(self, rhs: Self) -> Self {
            // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `unchecked_mul`.
            //
            unsafe { intrinsics::unchecked_mul(self, rhs) }
        }

        /// Kontrolleret heltal division.
        /// Beregner `self / rhs`, returnerer `None`, hvis `rhs == 0` eller divisionen resulterer i overløb.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div(0), None);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // SIKKERHED: div med nul og ved INT_MIN er blevet kontrolleret ovenfor
                Some(unsafe { intrinsics::unchecked_div(self, rhs) })
            }
        }

        /// Kontrolleret euklidisk division.
        /// Beregner `self.div_euclid(rhs)`, returnerer `None`, hvis `rhs == 0` eller divisionen resulterer i overløb.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).checked_div_euclid(-1), Some(", stringify!($Max), "));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_div_euclid(-1), None);")]
        #[doc = concat!("assert_eq!((1", stringify!($SelfT), ").checked_div_euclid(0), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_div_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.div_euclid(rhs))
            }
        }

        /// Kontrolleret heltal rest.
        /// Beregner `self % rhs`, returnerer `None`, hvis `rhs == 0` eller divisionen resulterer i overløb.
        ///
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem(-1), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                // SIKKERHED: div med nul og ved INT_MIN er blevet kontrolleret ovenfor
                Some(unsafe { intrinsics::unchecked_rem(self, rhs) })
            }
        }

        /// Kontrolleret euklidisk rest.
        /// Beregner `self.rem_euclid(rhs)`, returnerer `None`, hvis `rhs == 0` eller divisionen resulterer i overløb.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(2), Some(1));")]
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_rem_euclid(0), None);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_rem_euclid(-1), None);")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_rem_euclid(self, rhs: Self) -> Option<Self> {
            if unlikely!(rhs == 0 || (self == Self::MIN && rhs == -1)) {
                None
            } else {
                Some(self.rem_euclid(rhs))
            }
        }

        /// Kontrolleret negation.
        /// Beregner `-self`, returnerer `None` hvis `self == MIN`.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".checked_neg(), Some(-5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_neg(), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_neg(self) -> Option<Self> {
            let (a, b) = self.overflowing_neg();
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Kontrolleret skift til venstre.
        /// Beregner `self << rhs`, returnerer `None`, hvis `rhs` er større end eller lig med antallet af bit i `self`.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(4), Some(0x10));")]
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT), ".checked_shl(129), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shl(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shl(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Kontrolleret skift til højre.
        /// Beregner `self >> rhs`, returnerer `None`, hvis `rhs` er større end eller lig med antallet af bit i `self`.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(4), Some(0x1));")]
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".checked_shr(128), None);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_shr(self, rhs: u32) -> Option<Self> {
            let (a, b) = self.overflowing_shr(rhs);
            if unlikely!(b) {None} else {Some(a)}
        }

        /// Kontrolleret absolut værdi.
        /// Beregner `self.abs()`, returnerer `None` hvis `self == MIN`.
        ///
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-5", stringify!($SelfT), ").checked_abs(), Some(5));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.checked_abs(), None);")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_checked_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn checked_abs(self) -> Option<Self> {
            if self.is_negative() {
                self.checked_neg()
            } else {
                Some(self)
            }
        }

        /// Kontrolleret eksponentiering.
        /// Beregner `self.pow(exp)`, returnerer `None`, hvis der opstod overløb.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(8", stringify!($SelfT), ".checked_pow(2), Some(64));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.checked_pow(2), None);")]
        /// ```

        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn checked_pow(self, mut exp: u32) -> Option<Self> {
            if exp == 0 {
                return Some(1);
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = try_opt!(acc.checked_mul(base));
                }
                exp /= 2;
                base = try_opt!(base.checked_mul(base));
            }
            // da exp!=0, skal exp endelig være 1.
            // Håndter den sidste bit af eksponenten separat, da kvadrering af basen bagefter ikke er nødvendig og kan forårsage et unødvendigt overløb.
            //
            //
            Some(try_opt!(acc.checked_mul(base)))
        }

        /// Mættende heltalstilsætning.
        /// Beregner `self + rhs`, mætter ved de numeriske grænser i stedet for at løbe over.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_add(1), 101);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_add(100), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_add(-1), ", stringify!($SelfT), "::MIN);")]
        /// ```

        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_add(self, rhs: Self) -> Self {
            intrinsics::saturating_add(self, rhs)
        }

        /// Mættende heltalstraktion.
        /// Beregner `self - rhs`, mætter ved de numeriske grænser i stedet for at løbe over.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_sub(127), -27);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_sub(100), ", stringify!($SelfT), "::MIN);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_sub(-1), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_sub(self, rhs: Self) -> Self {
            intrinsics::saturating_sub(self, rhs)
        }

        /// Mættende heltal negation.
        /// Beregner `-self`, returnerer `MAX` hvis `self == MIN` i stedet for at løbe over.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_neg(), -100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_neg(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_neg(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_neg(), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_neg(self) -> Self {
            intrinsics::saturating_sub(0, self)
        }

        /// Mættende absolut værdi.
        /// Beregner `self.abs()`, returnerer `MAX` hvis `self == MIN` i stedet for at løbe over.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").saturating_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN + 1).saturating_abs(), ", stringify!($SelfT), "::MAX);")]
        /// ```

        #[stable(feature = "saturating_neg", since = "1.45.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[inline]
        pub const fn saturating_abs(self) -> Self {
            if self.is_negative() {
                self.saturating_neg()
            } else {
                self
            }
        }

        /// Mættende heltalsmultiplikation.
        /// Beregner `self * rhs`, mætter ved de numeriske grænser i stedet for at løbe over.
        ///
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".saturating_mul(12), 120);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.saturating_mul(10), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_mul(10), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_saturating_int_methods", since = "1.47.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_mul(self, rhs: Self) -> Self {
            match self.checked_mul(rhs) {
                Some(x) => x,
                None => if (self < 0) == (rhs < 0) {
                    Self::MAX
                } else {
                    Self::MIN
                }
            }
        }

        /// Mættende heltal eksponentiering.
        /// Beregner `self.pow(exp)`, mætter ved de numeriske grænser i stedet for at løbe over.
        ///
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!((-4", stringify!($SelfT), ").saturating_pow(3), -64);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(2), ", stringify!($SelfT), "::MAX);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.saturating_pow(3), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn saturating_pow(self, exp: u32) -> Self {
            match self.checked_pow(exp) {
                Some(x) => x,
                None if self < 0 && exp % 2 == 1 => Self::MIN,
                None => Self::MAX,
            }
        }

        /// Indpakning af (modular)-tilføjelse.
        /// Beregner `self + rhs`, der vikles rundt ved grænsen for typen.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_add(27), 127);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.wrapping_add(2), ", stringify!($SelfT), "::MIN + 1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_add(self, rhs: Self) -> Self {
            intrinsics::wrapping_add(self, rhs)
        }

        /// Indpakning af (modular)-subtraktion.
        /// Beregner `self - rhs`, der vikles rundt ved grænsen for typen.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".wrapping_sub(127), -127);")]
        #[doc = concat!("assert_eq!((-2", stringify!($SelfT), ").wrapping_sub(", stringify!($SelfT), "::MAX), ", stringify!($SelfT), "::MAX);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_sub(self, rhs: Self) -> Self {
            intrinsics::wrapping_sub(self, rhs)
        }

        /// Indpakning af (modular)-multiplikation.
        /// Beregner `self * rhs`, der vikles rundt ved grænsen for typen.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".wrapping_mul(12), 120);")]
        /// assert_eq!(11i8.wrapping_mul(12), -124);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_mul(self, rhs: Self) -> Self {
            intrinsics::wrapping_mul(self, rhs)
        }

        /// Indpakning af (modular)-division.Beregner `self / rhs`, der vikles rundt ved grænsen for typen.
        ///
        /// Det eneste tilfælde, hvor sådan indpakning kan forekomme, er, når man deler `MIN / -1` på en signeret type (hvor `MIN` er den negative minimale værdi for typen);dette svarer til `-MIN`, en positiv værdi, der er for stor til at repræsentere i typen.
        /// I et sådant tilfælde returnerer denne funktion `MIN` selv.
        ///
        /// # Panics
        ///
        /// Denne funktion vil panic, hvis `rhs` er 0.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div(-1), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div(self, rhs: Self) -> Self {
            self.overflowing_div(rhs).0
        }

        /// Indpakning af den euklidiske division.
        /// Beregner `self.div_euclid(rhs)`, der vikles rundt ved grænsen for typen.
        ///
        /// Indpakning finder kun sted i `MIN / -1` på en signeret type (hvor `MIN` er den negative minimale værdi for typen).
        /// Dette svarer til `-MIN`, en positiv værdi, der er for stor til at repræsentere i typen.
        /// I dette tilfælde returnerer denne metode `MIN` selv.
        ///
        /// # Panics
        ///
        /// Denne funktion vil panic, hvis `rhs` er 0.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_div_euclid(10), 10);")]
        /// assert_eq!((-128i8).wrapping_div_euclid(-1), -128);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_div_euclid(self, rhs: Self) -> Self {
            self.overflowing_div_euclid(rhs).0
        }

        /// Indpakning af (modular) resten.Beregner `self % rhs`, der vikles rundt ved grænsen for typen.
        ///
        /// En sådan omslutning forekommer faktisk aldrig matematisk;implementeringsartefakter gør `x % y` ugyldig for `MIN / -1` på en signeret type (hvor `MIN` er den minimale minimale værdi).
        ///
        /// I et sådant tilfælde returnerer denne funktion `0`.
        ///
        /// # Panics
        ///
        /// Denne funktion vil panic, hvis `rhs` er 0.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem(-1), 0);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_wrapping_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem(self, rhs: Self) -> Self {
            self.overflowing_rem(rhs).0
        }

        /// Indpakning af euklidisk rest.Beregner `self.rem_euclid(rhs)`, der vikles rundt ved grænsen for typen.
        ///
        /// Indpakning finder kun sted i `MIN % -1` på en signeret type (hvor `MIN` er den negative minimale værdi for typen).
        /// I dette tilfælde returnerer denne metode 0.
        ///
        /// # Panics
        ///
        /// Denne funktion vil panic, hvis `rhs` er 0.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_rem_euclid(10), 0);")]
        /// assert_eq!((-128i8).wrapping_rem_euclid(-1), 0);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_rem_euclid(self, rhs: Self) -> Self {
            self.overflowing_rem_euclid(rhs).0
        }

        /// Indpakning af (modular)-negation.Beregner `-self`, der vikles rundt ved grænsen for typen.
        ///
        /// Det eneste tilfælde, hvor en sådan indpakning kan forekomme, er, når man negerer `MIN` på en signeret type (hvor `MIN` er den negative minimale værdi for typen);dette er en positiv værdi, der er for stor til at repræsentere i typen.
        /// I et sådant tilfælde returnerer denne funktion `MIN` selv.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_neg(), -100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_neg(), ", stringify!($SelfT), "::MIN);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn wrapping_neg(self) -> Self {
            self.overflowing_neg().0
        }

        /// Panic-fri bitvis skift-venstre;giver `self << mask(rhs)`, hvor `mask` fjerner alle bit af `rhs` af høj ordre, der ville få skiftet til at overstige typebitbredden.
        ///
        /// Bemærk, at dette er *ikke* det samme som en roter-venstre;RHS for et indpakningsskift-venstre er begrænset til rækkevidden af typen snarere end bitene, der er flyttet ud af LHS, returneres til den anden ende.
        ///
        /// De primitive heltalstyper implementerer alle en [`rotate_left`](Self::rotate_left)-funktion, hvilket måske er det, du vil have i stedet.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(7), -128);")]
        #[doc = concat!("assert_eq!((-1", stringify!($SelfT), ").wrapping_shl(128), -1);")]
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shl(self, rhs: u32) -> Self {
            // SIKKERHED: maskeringen efter bitstørrelsen af typen sikrer, at vi ikke skifter
            // Over grænsen
            unsafe {
                intrinsics::unchecked_shl(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Panic-fri bitvis skift til højre;giver `self >> mask(rhs)`, hvor `mask` fjerner alle bit af `rhs` af høj ordre, der ville få skiftet til at overstige typebitbredden.
        ///
        /// Bemærk, at dette er *ikke* det samme som en roter-højre;RHS for et indpakningsskift-højre er begrænset til rækkevidden af typen snarere end bitene, der er flyttet ud af LHS, returneres til den anden ende.
        ///
        /// De primitive heltalstyper implementerer alle en [`rotate_right`](Self::rotate_right)-funktion, hvilket måske er det, du vil have i stedet.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!((-128", stringify!($SelfT), ").wrapping_shr(7), -1);")]
        /// assert_eq!((-128i16).wrapping_shr(64), -128);
        /// ```
        #[stable(feature = "num_wrapping", since = "1.2.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_shr(self, rhs: u32) -> Self {
            // SIKKERHED: maskeringen efter bitstørrelsen af typen sikrer, at vi ikke skifter
            // Over grænsen
            unsafe {
                intrinsics::unchecked_shr(self, (rhs & ($BITS - 1)) as $SelfT)
            }
        }

        /// Indpakning af (modular) absolut værdi.Beregner `self.abs()`, der vikles rundt ved grænsen for typen.
        ///
        /// Det eneste tilfælde, hvor en sådan indpakning kan forekomme, er når man tager den absolutte værdi af den negative minimale værdi for typen;dette er en positiv værdi, der er for stor til at repræsentere i typen.
        /// I et sådant tilfælde returnerer denne funktion `MIN` selv.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        ///
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").wrapping_abs(), 100);")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.wrapping_abs(), ", stringify!($SelfT), "::MIN);")]
        /// assert_eq!((-128i8).wrapping_abs() as u8, 128);
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        pub const fn wrapping_abs(self) -> Self {
             if self.is_negative() {
                 self.wrapping_neg()
             } else {
                 self
             }
        }

        /// Beregner den absolutte værdi af `self` uden indpakning eller panik.
        ///
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(100", stringify!($SelfT), ".unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        #[doc = concat!("assert_eq!((-100", stringify!($SelfT), ").unsigned_abs(), 100", stringify!($UnsignedT), ");")]
        /// assert_eq!((-128i8).unsigned_abs(), 128u8);
        /// ```
        #[stable(feature = "unsigned_abs", since = "1.51.0")]
        #[rustc_const_stable(feature = "unsigned_abs", since = "1.51.0")]
        #[inline]
        pub const fn unsigned_abs(self) -> $UnsignedT {
             self.wrapping_abs() as $UnsignedT
        }

        /// Indpakning af (modular)-eksponentiering.
        /// Beregner `self.pow(exp)`, der vikles rundt ved grænsen for typen.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".wrapping_pow(4), 81);")]
        /// assert_eq!(3i8.wrapping_pow(5), -13);
        /// assert_eq!(3i8.wrapping_pow(6), -39);
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn wrapping_pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc: Self = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc.wrapping_mul(base);
                }
                exp /= 2;
                base = base.wrapping_mul(base);
            }

            // da exp!=0, skal exp endelig være 1.
            // Håndter den sidste bit af eksponenten separat, da kvadrering af basen bagefter ikke er nødvendig og kan forårsage et unødvendigt overløb.
            //
            //
            acc.wrapping_mul(base)
        }

        /// Beregner `self` + `rhs`
        ///
        /// Returnerer en tupel af tilføjelsen sammen med en boolsk, der angiver, om der ville forekomme et aritmetisk overløb.
        /// Hvis et overløb ville have fundet sted, returneres den indpakkede værdi.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_add(2), (7, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MAX.overflowing_add(1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_add(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::add_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Beregner `self`, `rhs`
        ///
        /// Returnerer en tuple af subtraktionen sammen med en boolsk, der indikerer, om der vil forekomme et aritmetisk overløb.
        /// Hvis et overløb ville have fundet sted, returneres den indpakkede værdi.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_sub(2), (3, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_sub(1), (", stringify!($SelfT), "::MAX, true));")]
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_sub(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::sub_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Beregner multiplikationen af `self` og `rhs`.
        ///
        /// Returnerer en tuple af multiplikationen sammen med en boolsk, der indikerer, om der vil forekomme et aritmetisk overløb.
        /// Hvis et overløb ville have fundet sted, returneres den indpakkede værdi.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_mul(2), (10, false));")]
        /// assert_eq!(1_000_000_000i32.overflowing_mul(10), (1410065408, sandt));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_mul(self, rhs: Self) -> (Self, bool) {
            let (a, b) = intrinsics::mul_with_overflow(self as $ActualT, rhs as $ActualT);
            (a as Self, b)
        }

        /// Beregner divisoren, når `self` divideres med `rhs`.
        ///
        /// Returnerer en tuple af skillevæggen sammen med en boolsk, der angiver, om der ville opstå et aritmetisk overløb.
        /// Hvis et overløb ville forekomme, returneres selvet.
        ///
        /// # Panics
        ///
        /// Denne funktion vil panic, hvis `rhs` er 0.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self / rhs, false)
            }
        }

        /// Beregner kvotienten for den euklidiske division `self.div_euclid(rhs)`.
        ///
        /// Returnerer en tuple af skillevæggen sammen med en boolsk, der angiver, om der ville opstå et aritmetisk overløb.
        /// Hvis der opstår et overløb, returneres `self`.
        ///
        /// # Panics
        ///
        /// Denne funktion vil panic, hvis `rhs` er 0.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_div_euclid(2), (2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_div_euclid(-1), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_div_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (self, true)
            } else {
                (self.div_euclid(rhs), false)
            }
        }

        /// Beregner resten, når `self` divideres med `rhs`.
        ///
        /// Returnerer en tuple af resten efter opdeling sammen med en boolsk, der angiver, om et aritmetisk overløb ville forekomme.
        /// Hvis der opstår et overløb, returneres 0.
        ///
        /// # Panics
        ///
        /// Denne funktion vil panic, hvis `rhs` er 0.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem(-1), (0, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_overflowing_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        pub const fn overflowing_rem(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self % rhs, false)
            }
        }


        /// Overfyldte euklidiske rester.Beregner `self.rem_euclid(rhs)`.
        ///
        /// Returnerer en tuple af resten efter opdeling sammen med en boolsk, der angiver, om et aritmetisk overløb ville forekomme.
        /// Hvis der opstår et overløb, returneres 0.
        ///
        /// # Panics
        ///
        /// Denne funktion vil panic, hvis `rhs` er 0.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(5", stringify!($SelfT), ".overflowing_rem_euclid(2), (1, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_rem_euclid(-1), (0, true));")]
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_rem_euclid(self, rhs: Self) -> (Self, bool) {
            if unlikely!(self == Self::MIN && rhs == -1) {
                (0, true)
            } else {
                (self.rem_euclid(rhs), false)
            }
        }


        /// Negerer selv, overfyldt, hvis dette er lig med minimumsværdien.
        ///
        /// Returnerer en tuple af den negerede version af selvet sammen med en boolsk, der angiver, om der opstod et overløb.
        /// Hvis `self` er minimumsværdien (f.eks. `i32::MIN` for værdier af typen `i32`), returneres minimumsværdien igen, og `true` returneres for en overløbshændelse.
        ///
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(2", stringify!($SelfT), ".overflowing_neg(), (-2, false));")]
        #[doc = concat!("assert_eq!(", stringify!($SelfT), "::MIN.overflowing_neg(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[inline]
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        pub const fn overflowing_neg(self) -> (Self, bool) {
            if unlikely!(self == Self::MIN) {
                (Self::MIN, true)
            } else {
                (-self, false)
            }
        }

        /// Skifter selv efterladt af `rhs` bits.
        ///
        /// Returnerer en tuple af den skiftede version af selv sammen med en boolsk, der angiver, om forskydningsværdien var større end eller lig med antallet af bits.
        /// Hvis forskydningsværdien er for stor, maskeres værdien (N-1), hvor N er antallet af bits, og denne værdi bruges derefter til at udføre skiftet.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x1", stringify!($SelfT),".overflowing_shl(4), (0x10, false));")]
        /// assert_eq!(0x1i32.overflowing_shl(36), (0x10, sandt));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shl(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shl(rhs), (rhs > ($BITS - 1)))
        }

        /// Skifter selvret med `rhs` bits.
        ///
        /// Returnerer en tuple af den skiftede version af selv sammen med en boolsk, der angiver, om forskydningsværdien var større end eller lig med antallet af bits.
        /// Hvis forskydningsværdien er for stor, maskeres værdien (N-1), hvor N er antallet af bits, og denne værdi bruges derefter til at udføre skiftet.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        ///
        #[doc = concat!("assert_eq!(0x10", stringify!($SelfT), ".overflowing_shr(4), (0x1, false));")]
        /// assert_eq!(0x10i32.overflowing_shr(36), (0x1, sandt));
        /// ```
        #[stable(feature = "wrapping", since = "1.7.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_shr(self, rhs: u32) -> (Self, bool) {
            (self.wrapping_shr(rhs), (rhs > ($BITS - 1)))
        }

        /// Beregner den absolutte værdi af `self`.
        ///
        /// Returnerer en tuple af den absolutte version af selvet sammen med en boolsk, der indikerer, om der opstod et overløb.
        /// Hvis selv er minimumsværdien
        #[doc = concat!("(e.g., ", stringify!($SelfT), "::MIN for values of type ", stringify!($SelfT), "),")]
        /// derefter returneres minimumsværdien igen, og ægte returneres for en overløbshændelse.
        ///
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").overflowing_abs(), (10, false));")]
        #[doc = concat!("assert_eq!((", stringify!($SelfT), "::MIN).overflowing_abs(), (", stringify!($SelfT), "::MIN, true));")]
        /// ```
        #[stable(feature = "no_panic_abs", since = "1.13.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn overflowing_abs(self) -> (Self, bool) {
            (self.wrapping_abs(), self == Self::MIN)
        }

        /// Løfter sig selv til kraften i `exp` ved hjælp af eksponentiering ved at kvadre.
        ///
        /// Returnerer en tuple af eksponentieringen sammen med en bool, der angiver, om der opstod et overløb.
        ///
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(3", stringify!($SelfT), ".overflowing_pow(4), (81, false));")]
        /// assert_eq!(3i8.overflowing_pow(5), (-13, sandt));
        /// ```
        #[stable(feature = "no_panic_pow", since = "1.34.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        pub const fn overflowing_pow(self, mut exp: u32) -> (Self, bool) {
            if exp == 0 {
                return (1,false);
            }
            let mut base = self;
            let mut acc: Self = 1;
            let mut overflown = false;
            // Ridseplads til lagring af resultater af overflowing_mul.
            let mut r;

            while exp > 1 {
                if (exp & 1) == 1 {
                    r = acc.overflowing_mul(base);
                    acc = r.0;
                    overflown |= r.1;
                }
                exp /= 2;
                r = base.overflowing_mul(base);
                base = r.0;
                overflown |= r.1;
            }

            // da exp!=0, skal exp endelig være 1.
            // Håndter den sidste bit af eksponenten separat, da kvadrering af basen bagefter ikke er nødvendig og kan forårsage et unødvendigt overløb.
            //
            //
            r = acc.overflowing_mul(base);
            r.1 |= overflown;
            r
        }

        /// Løfter sig selv til kraften i `exp` ved hjælp af eksponentiering ved at kvadre.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("let x: ", stringify!($SelfT), " = 2; // or any other integer type")]
        /// assert_eq!(x.pow(5), 32);
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_pow", since = "1.50.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn pow(self, mut exp: u32) -> Self {
            if exp == 0 {
                return 1;
            }
            let mut base = self;
            let mut acc = 1;

            while exp > 1 {
                if (exp & 1) == 1 {
                    acc = acc * base;
                }
                exp /= 2;
                base = base * base;
            }

            // da exp!=0, skal exp endelig være 1.
            // Håndter den sidste bit af eksponenten separat, da kvadrering af basen bagefter ikke er nødvendig og kan forårsage et unødvendigt overløb.
            //
            //
            acc * base
        }

        /// Beregner kvotienten for euklidisk opdeling af `self` ved `rhs`.
        ///
        /// Dette beregner heltal `n` således, at `self = n * rhs + self.rem_euclid(rhs)` med `0 <= self.rem_euclid(rhs) < rhs`.
        ///
        ///
        /// Med andre ord er resultatet `self / rhs` afrundet til heltal `n` således at `self >= n * rhs`.
        /// Hvis `self > 0` er lig med runde mod nul (standard i Rust);
        /// hvis `self < 0`, er dette lig med runde mod +/-uendelig.
        ///
        /// # Panics
        ///
        /// Denne funktion vil panic, hvis `rhs` er 0, eller divisionen resulterer i overløb.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// lad b=4;
        ///
        /// assert_eq!(a.div_euclid(b), 1); //7>=4 *1 assert_eq!(a.div_euclid(-b), -1);//7>= -4*-1 assert_eq!((-a).div_euclid(b), -2);//-7>=4 *-2 assert_eq!((-a).div_euclid(-b), 2);//-7>= -4* 2
        ///
        /// ```
        ///
        ///
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn div_euclid(self, rhs: Self) -> Self {
            let q = self / rhs;
            if self % rhs < 0 {
                return if rhs > 0 { q - 1 } else { q + 1 }
            }
            q
        }


        /// Beregner den mindst ikke-negative rest af `self (mod rhs)`.
        ///
        /// Dette gøres som ved hjælp af den euklidiske divisionsalgoritme-givet `r = self.rem_euclid(rhs)`, `self = rhs * self.div_euclid(rhs) + r` og `0 <= r < abs(rhs)`.
        ///
        ///
        /// # Panics
        ///
        /// Denne funktion vil panic, hvis `rhs` er 0, eller divisionen resulterer i overløb.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        ///
        #[doc = concat!("let a: ", stringify!($SelfT), " = 7; // or any other integer type")]
        /// lad b=4;
        ///
        /// assert_eq!(a.rem_euclid(b), 3);
        /// assert_eq!((-a).rem_euclid(b), 1);
        /// assert_eq!(a.rem_euclid(-b), 3);
        /// assert_eq!((-a).rem_euclid(-b), 1);
        /// ```
        #[stable(feature = "euclidean_division", since = "1.38.0")]
        #[rustc_const_stable(feature = "const_euclidean_int_methods", since = "1.52.0")]
        #[must_use = "this returns the result of the operation, \
                      without modifying the original"]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn rem_euclid(self, rhs: Self) -> Self {
            let r = self % rhs;
            if r < 0 {
                if rhs < 0 {
                    r - rhs
                } else {
                    r + rhs
                }
            } else {
                r
            }
        }

        /// Beregner den absolutte værdi af `self`.
        ///
        /// # Overløbsadfærd
        ///
        /// Den absolutte værdi af
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// kan ikke repræsenteres som en
        #[doc = concat!("`", stringify!($SelfT), "`,")]
        /// og forsøg på at beregne det vil medføre et overløb.
        /// Dette betyder, at kode i fejlretningstilstand vil udløse en panic i denne sag, og optimeret kode vender tilbage
        ///
        #[doc = concat!("`", stringify!($SelfT), "::MIN`")]
        /// uden en panic.
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".abs(), 10);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").abs(), 10);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[allow(unused_attributes)]
        #[inline]
        #[rustc_inherit_overflow_checks]
        pub const fn abs(self) -> Self {
            // Bemærk, at nummeret [inline] ovenfor betyder, at overløbssemantikken for subtraktionen afhænger af den crate, vi bliver indrettet i.
            //
            //
            if self.is_negative() {
                -self
            } else {
                self
            }
        }

        /// Returnerer et tal, der repræsenterer tegn på `self`.
        ///
        ///  - `0` hvis tallet er nul
        ///  - `1` hvis antallet er positivt
        ///  - `-1` hvis tallet er negativt
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert_eq!(10", stringify!($SelfT), ".signum(), 1);")]
        #[doc = concat!("assert_eq!(0", stringify!($SelfT), ".signum(), 0);")]
        #[doc = concat!("assert_eq!((-10", stringify!($SelfT), ").signum(), -1);")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_sign", since = "1.47.0")]
        #[inline]
        pub const fn signum(self) -> Self {
            match self {
                n if n > 0 =>  1,
                0          =>  0,
                _          => -1,
            }
        }

        /// Returnerer `true`, hvis `self` er positiv, og `false`, hvis tallet er nul eller negativt.
        ///
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert!(10", stringify!($SelfT), ".is_positive());")]
        #[doc = concat!("assert!(!(-10", stringify!($SelfT), ").is_positive());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_positive(self) -> bool { self > 0 }

        /// Returnerer `true`, hvis `self` er negativ, og `false`, hvis tallet er nul eller positivt.
        ///
        ///
        /// # Examples
        ///
        /// Grundlæggende brug:
        ///
        /// ```
        #[doc = concat!("assert!((-10", stringify!($SelfT), ").is_negative());")]
        #[doc = concat!("assert!(!10", stringify!($SelfT), ".is_negative());")]
        /// ```
        #[stable(feature = "rust1", since = "1.0.0")]
        #[rustc_const_stable(feature = "const_int_methods", since = "1.32.0")]
        #[inline]
        pub const fn is_negative(self) -> bool { self < 0 }

        /// Returner hukommelsesrepræsentationen for dette heltal som et byte-array i stor-endian (network) byte-rækkefølge.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_be_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $be_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_be_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_be().to_ne_bytes()
        }

        /// Returner hukommelsesrepræsentationen for dette heltal som et byte-array i lille endian-byte-rækkefølge.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_le_bytes();")]
        #[doc = concat!("assert_eq!(bytes, ", $le_bytes, ");")]
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn to_le_bytes(self) -> [u8; mem::size_of::<Self>()] {
            self.to_le().to_ne_bytes()
        }

        /// Returner hukommelsesrepræsentationen for dette heltal som et byte-array i native byte-rækkefølge.
        ///
        /// Da målplatformens native endianness anvendes, skal bærbar kode i stedet bruge [`to_be_bytes`] eller [`to_le_bytes`].
        ///
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// [`to_be_bytes`]: Self::to_be_bytes
        /// [`to_le_bytes`]: Self::to_le_bytes
        ///
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let bytes = ", $swap_op, stringify!($SelfT), ".to_ne_bytes();")]
        /// assert_eq!(
        ///     bytes, hvis cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        ", $be_bytes)]
        /// } andet {
        #[doc = concat!("        ", $le_bytes)]
        /// }
        /// );
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SIKKERHED: const-lyd, fordi heltal er almindelige gamle datatyper, så vi altid kan
        // transmitter dem til arrays af bytes
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn to_ne_bytes(self) -> [u8; mem::size_of::<Self>()] {
            // SIKKERHED: heltal er almindelige gamle datatyper, så vi altid kan transmittere dem til
            // arrays af bytes
            unsafe { mem::transmute(self) }
        }

        /// Returner hukommelsesrepræsentationen for dette heltal som et byte-array i native byte-rækkefølge.
        ///
        ///
        /// [`to_ne_bytes`] bør foretrækkes frem for dette, når det er muligt.
        ///
        /// [`to_ne_bytes`]: Self::to_ne_bytes
        ///
        /// # Examples
        ///
        /// ```
        /// #![feature(num_as_ne_bytes)]
        #[doc = concat!("let num = ", $swap_op, stringify!($SelfT), ";")]
        /// lad bytes= num.as_ne_bytes();
        /// assert_eq!(
        ///     bytes, hvis cfg! (target_endian= "big"){
        ///
        #[doc = concat!("        &", $be_bytes)]
        /// } andet {
        #[doc = concat!("        &", $le_bytes)]
        /// }
        /// );
        /// ```
        #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
        #[inline]
        pub fn as_ne_bytes(&self) -> &[u8; mem::size_of::<Self>()] {
            // SIKKERHED: heltal er almindelige gamle datatyper, så vi altid kan transmittere dem til
            // arrays af bytes
            unsafe { &*(self as *const Self as *const _) }
        }

        /// Opret en heltalværdi ud fra dens repræsentation som et byte-array i stor endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_be_bytes(", $be_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// brug std::convert::TryInto;
        #[doc = concat!("fn read_be_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input=hvile;
        #[doc = concat!("    ", stringify!($SelfT), "::from_be_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_be_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_be(Self::from_ne_bytes(bytes))
        }

        /// Opret en heltalværdi ud fra dens repræsentation som et byte-array i lille endian.
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_le_bytes(", $le_bytes, ");")]
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// brug std::convert::TryInto;
        #[doc = concat!("fn read_le_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input=hvile;
        #[doc = concat!("    ", stringify!($SelfT), "::from_le_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        #[inline]
        pub const fn from_le_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            Self::from_le(Self::from_ne_bytes(bytes))
        }

        /// Opret en heltalværdi ud fra dens hukommelsesrepræsentation som et byte-array i native endianness.
        ///
        /// Da målplatformens native endianness anvendes, vil bærbar kode sandsynligvis i stedet bruge [`from_be_bytes`] eller [`from_le_bytes`].
        ///
        ///
        /// [`from_be_bytes`]: Self::from_be_bytes
        /// [`from_le_bytes`]: Self::from_le_bytes
        ///
        ///
        ///
        #[doc = $to_xe_bytes_doc]
        /// # Examples
        ///
        /// ```
        #[doc = concat!("let value = ", stringify!($SelfT), "::from_ne_bytes(if cfg!(target_endian = \"big\") {")]
        #[doc = concat!("    ", $be_bytes)]
        /// } andet {
        #[doc = concat!("    ", $le_bytes)]
        /// });
        #[doc = concat!("assert_eq!(value, ", $swap_op, ");")]
        /// ```
        ///
        /// When starting from a slice rather than an array, fallible conversion APIs can be used:
        ///
        /// ```
        ///
        /// brug std::convert::TryInto;
        #[doc = concat!("fn read_ne_", stringify!($SelfT), "(input: &mut &[u8]) -> ", stringify!($SelfT), " {")]
        #[doc = concat!("    let (int_bytes, rest) = input.split_at(std::mem::size_of::<", stringify!($SelfT), ">());")]
        /// * input=hvile;
        #[doc = concat!("    ", stringify!($SelfT), "::from_ne_bytes(int_bytes.try_into().unwrap())")]
        /// }
        /// ```
        #[stable(feature = "int_to_from_bytes", since = "1.32.0")]
        #[rustc_const_stable(feature = "const_int_conversion", since = "1.44.0")]
        // SIKKERHED: const-lyd, fordi heltal er almindelige gamle datatyper, så vi altid kan
        // transmutere til dem
        #[rustc_allow_const_fn_unstable(const_fn_transmute)]
        #[inline]
        pub const fn from_ne_bytes(bytes: [u8; mem::size_of::<Self>()]) -> Self {
            // SIKKERHED: heltal er almindelige gamle datatyper, så vi altid kan transmittere til dem
            unsafe { mem::transmute(bytes) }
        }

        /// Ny kode foretrækker at bruge
        #[doc = concat!("[`", stringify!($SelfT), "::MIN", "`] instead.")]
        /// Returnerer den mindste værdi, der kan repræsenteres af denne heltalstype.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_min_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on this type")]
        pub const fn min_value() -> Self {
            Self::MIN
        }

        /// Ny kode foretrækker at bruge
        #[doc = concat!("[`", stringify!($SelfT), "::MAX", "`] instead.")]
        /// Returnerer den største værdi, der kan repræsenteres af denne heltalstype.
        #[stable(feature = "rust1", since = "1.0.0")]
        #[inline(always)]
        #[rustc_promotable]
        #[rustc_const_stable(feature = "const_max_value", since = "1.32.0")]
        #[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on this type")]
        pub const fn max_value() -> Self {
            Self::MAX
        }
    }
}