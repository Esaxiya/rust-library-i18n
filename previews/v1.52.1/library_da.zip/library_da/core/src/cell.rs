//! Delbare, ændrede beholdere.
//!
//! Rust hukommelsessikkerhed er baseret på denne regel: Givet et objekt `T` er det kun muligt at have et af følgende:
//!
//! - At have flere uforanderlige referencer (`&T`) til objektet (også kendt som **aliasing**).
//! - At have en ændret henvisning (`&mut T`) til objektet (også kendt som **mutabilitet**).
//!
//! Dette håndhæves af Rust-kompilatoren.Der er dog situationer, hvor denne regel ikke er fleksibel nok.Nogle gange er det nødvendigt at have flere referencer til et objekt og alligevel mutere det.
//!
//! Delbare mutable beholdere findes for at tillade mutabilitet på en kontrolleret måde, selv i nærvær af aliasing.Både [`Cell<T>`] og [`RefCell<T>`] tillader at gøre dette på en enkelt tråd.
//! Imidlertid er hverken `Cell<T>` eller `RefCell<T>` trådsikre (de implementerer ikke [`Sync`]).
//! Hvis du har brug for aliasing og mutation mellem flere tråde, er det muligt at bruge [`Mutex<T>`], [`RwLock<T>`] eller [`atomic`] typer.
//!
//! Værdier af `Cell<T>`-og `RefCell<T>`-typerne kan muteres gennem delte referencer (dvs.
//! den almindelige `&T`-type), hvorimod de fleste Rust-typer kun kan muteres gennem unikke (`&mut T`) referencer.
//! Vi siger, at `Cell<T>` og `RefCell<T>` giver 'indre mutabilitet' i modsætning til typiske Rust-typer, der udviser 'arvet mutabilitet'.
//!
//! Celletyper findes i to varianter: `Cell<T>` og `RefCell<T>`.`Cell<T>` implementerer indvendig mutabilitet ved at flytte værdier ind og ud af `Cell<T>`.
//! For at bruge referencer i stedet for værdier skal man bruge typen `RefCell<T>` og erhverve en skrivelås, før man muterer.`Cell<T>` giver metoder til at hente og ændre den aktuelle indvendige værdi:
//!
//!  - For typer, der implementerer [`Copy`], henter [`get`](Cell::get)-metoden den aktuelle indre værdi.
//!  - For typer, der implementerer [`Default`], erstatter [`take`](Cell::take)-metoden den aktuelle indre værdi med [`Default::default()`] og returnerer den erstattede værdi.
//!  - For alle typer erstatter [`replace`](Cell::replace)-metoden den aktuelle indre værdi og returnerer den erstattede værdi, og [`into_inner`](Cell::into_inner)-metoden bruger `Cell<T>` og returnerer den indre værdi.
//!  Derudover erstatter [`set`](Cell::set)-metoden den indvendige værdi og slipper den erstattede værdi.
//!
//! `RefCell<T>` bruger Rust s levetid til at implementere 'dynamisk låntagning', en proces hvor man kan kræve midlertidig, eksklusiv, muterbar adgang til den indre værdi.
//! Låner til `RefCell<T>`` s spores 'ved kørsel', i modsætning til Rust s native referencetyper, som spores fuldstændigt statisk på kompileringstidspunktet.
//! Da `RefCell<T>`-lån er dynamiske, er det muligt at forsøge at låne en værdi, der allerede er lånt mutabelt;når dette sker, resulterer det i tråd panic.
//!
//! # Hvornår skal man vælge interiørmutabilitet
//!
//! Den mere almindelige nedarvede mutabilitet, hvor man skal have enestående adgang til at mutere en værdi, er et af nøglesprogselementerne, der gør det muligt for Rust at tænke stærkt over aliasing af pointer, hvilket statisk forhindrer crash bugs.
//! På grund af dette foretrækkes arvelig mutabilitet, og indre mutabilitet er noget af en sidste udvej.
//! Da celletyper muliggør mutation, hvor det ellers ikke ville være tilladt, er der lejligheder, hvor indre mutabilitet kan være passende, eller endda *skal* bruges, f.eks.
//!
//! * Vi introducerer mutabilitet 'inside' af noget uforanderligt
//! * Implementeringsoplysninger om logisk uforanderlige metoder.
//! * Muterende implementeringer af [`Clone`].
//!
//! ## Vi introducerer mutabilitet 'inside' af noget uforanderligt
//!
//! Mange delte smarte markørtyper, herunder [`Rc<T>`] og [`Arc<T>`], leverer containere, der kan klones og deles mellem flere parter.
//! Fordi de indeholdte værdier kan være multipliceret, kan de kun lånes med `&`, ikke `&mut`.
//! Uden celler ville det overhovedet være umuligt at mutere data inde i disse smarte pointer.
//!
//! Det er meget almindeligt at placere en `RefCell<T>` i delte markørtyper for at genindføre mutabilitet:
//!
//! ```
//! use std::cell::{RefCell, RefMut};
//! use std::collections::HashMap;
//! use std::rc::Rc;
//!
//! fn main() {
//!     let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//!     // Opret en ny blok for at begrænse omfanget af den dynamiske lån
//!     {
//!         let mut map: RefMut<_> = shared_map.borrow_mut();
//!         map.insert("africa", 92388);
//!         map.insert("kyoto", 11837);
//!         map.insert("piccadilly", 11826);
//!         map.insert("marbles", 38);
//!     }
//!
//!     // Bemærk, at hvis vi ikke havde ladet den tidligere låntagning af cachen falde uden for anvendelsesområdet, ville den efterfølgende låne forårsage en dynamisk tråd panic.
//!     //
//!     // Dette er den største fare ved brug af `RefCell`.
//!     let total: i32 = shared_map.borrow().values().sum();
//!     println!("{}", total);
//! }
//! ```
//!
//! Bemærk, at dette eksempel bruger `Rc<T>` og ikke `Arc<T>`.`RefCell<T>`s er til scener med en tråd.Overvej at bruge [`RwLock<T>`] eller [`Mutex<T>`], hvis du har brug for delt mutabilitet i en situation med flere tråde.
//!
//! ## Implementeringsoplysninger om logisk uforanderlige metoder
//!
//! Lejlighedsvis kan det være ønskeligt ikke at udsætte i en API for, at der sker en mutation "under the hood".
//! Dette kan skyldes, at operationen logisk er uforanderlig, men f.eks. Tvinger caching implementeringen til at udføre mutation;eller fordi du skal anvende mutation for at implementere en trait-metode, der oprindeligt blev defineret til at tage `&self`.
//!
//!
//! ```
//! # #![allow(dead_code)]
//! use std::cell::RefCell;
//!
//! struct Graph {
//!     edges: Vec<(i32, i32)>,
//!     span_tree_cache: RefCell<Option<Vec<(i32, i32)>>>
//! }
//!
//! impl Graph {
//!     fn minimum_spanning_tree(&self) -> Vec<(i32, i32)> {
//!         self.span_tree_cache.borrow_mut()
//!             .get_or_insert_with(|| self.calc_span_tree())
//!             .clone()
//!     }
//!
//!     fn calc_span_tree(&self) -> Vec<(i32, i32)> {
//!         // Dyre beregninger går her
//!         vec![]
//!     }
//! }
//! ```
//!
//! ## Muterende implementeringer af `Clone`
//!
//! Dette er simpelthen et specielt, men almindeligt tilfælde af det foregående: skjule mutabilitet for operationer, der ser ud til at være uforanderlige.
//! [`clone`](Clone::clone)-metoden forventes ikke at ændre kildeværdien og erklæres at tage `&self`, ikke `&mut self`.
//! Derfor skal enhver mutation, der sker i `clone`-metoden, bruge celletyper.
//! For eksempel opretholder [`Rc<T>`] sine referencetællinger inden for en `Cell<T>`.
//!
//! ```
//! use std::cell::Cell;
//! use std::ptr::NonNull;
//! use std::process::abort;
//! use std::marker::PhantomData;
//!
//! struct Rc<T: ?Sized> {
//!     ptr: NonNull<RcBox<T>>,
//!     phantom: PhantomData<RcBox<T>>,
//! }
//!
//! struct RcBox<T: ?Sized> {
//!     strong: Cell<usize>,
//!     refcount: Cell<usize>,
//!     value: T,
//! }
//!
//! impl<T: ?Sized> Clone for Rc<T> {
//!     fn clone(&self) -> Rc<T> {
//!         self.inc_strong();
//!         Rc {
//!             ptr: self.ptr,
//!             phantom: PhantomData,
//!         }
//!     }
//! }
//!
//! trait RcBoxPtr<T: ?Sized> {
//!
//!     fn inner(&self) -> &RcBox<T>;
//!
//!     fn strong(&self) -> usize {
//!         self.inner().strong.get()
//!     }
//!
//!     fn inc_strong(&self) {
//!         self.inner()
//!             .strong
//!             .set(self.strong()
//!                      .checked_add(1)
//!                      .unwrap_or_else(|| abort() ));
//!     }
//! }
//!
//! impl<T: ?Sized> RcBoxPtr<T> for Rc<T> {
//!    fn inner(&self) -> &RcBox<T> {
//!        unsafe {
//!            self.ptr.as_ref()
//!        }
//!    }
//! }
//! ```
//!
//! [`Arc<T>`]: ../../std/sync/struct.Arc.html
//! [`Rc<T>`]: ../../std/rc/struct.Rc.html
//! [`RwLock<T>`]: ../../std/sync/struct.RwLock.html
//! [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
//! [`atomic`]: ../../core/sync/atomic/index.html
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt::{self, Debug, Display};
use crate::marker::Unsize;
use crate::mem;
use crate::ops::{CoerceUnsized, Deref, DerefMut};
use crate::ptr;

/// En ændret hukommelsesplacering.
///
/// # Examples
///
/// I dette eksempel kan du se, at `Cell<T>` muliggør mutation inde i en uforanderlig struktur.
/// Med andre ord muliggør det "interior mutability".
///
/// ```
/// use std::cell::Cell;
///
/// struct SomeStruct {
///     regular_field: u8,
///     special_field: Cell<u8>,
/// }
///
/// let my_struct = SomeStruct {
///     regular_field: 0,
///     special_field: Cell::new(1),
/// };
///
/// let new_value = 100;
///
/// // FEJL: `my_struct` er uforanderlig
/// // my_struct.regular_field =ny_værdi;
///
/// // FUNGERER: selvom `my_struct` er uforanderlig, er `special_field` en `Cell`,
/// // som altid kan muteres
/// my_struct.special_field.set(new_value);
/// assert_eq!(my_struct.special_field.get(), new_value);
/// ```
///
/// Se [module-level documentation](self) for mere.
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
pub struct Cell<T: ?Sized> {
    value: UnsafeCell<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for Cell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for Cell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Copy> Clone for Cell<T> {
    #[inline]
    fn clone(&self) -> Cell<T> {
        Cell::new(self.get())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Cell<T> {
    /// Opretter en `Cell<T>` med `Default`-værdien for T.
    #[inline]
    fn default() -> Cell<T> {
        Cell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialEq + Copy> PartialEq for Cell<T> {
    #[inline]
    fn eq(&self, other: &Cell<T>) -> bool {
        self.get() == other.get()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: Eq + Copy> Eq for Cell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: PartialOrd + Copy> PartialOrd for Cell<T> {
    #[inline]
    fn partial_cmp(&self, other: &Cell<T>) -> Option<Ordering> {
        self.get().partial_cmp(&other.get())
    }

    #[inline]
    fn lt(&self, other: &Cell<T>) -> bool {
        self.get() < other.get()
    }

    #[inline]
    fn le(&self, other: &Cell<T>) -> bool {
        self.get() <= other.get()
    }

    #[inline]
    fn gt(&self, other: &Cell<T>) -> bool {
        self.get() > other.get()
    }

    #[inline]
    fn ge(&self, other: &Cell<T>) -> bool {
        self.get() >= other.get()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: Ord + Copy> Ord for Cell<T> {
    #[inline]
    fn cmp(&self, other: &Cell<T>) -> Ordering {
        self.get().cmp(&other.get())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for Cell<T> {
    fn from(t: T) -> Cell<T> {
        Cell::new(t)
    }
}

impl<T> Cell<T> {
    /// Opretter en ny `Cell`, der indeholder den givne værdi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> Cell<T> {
        Cell { value: UnsafeCell::new(value) }
    }

    /// Indstiller den indeholdte værdi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// c.set(10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn set(&self, val: T) {
        let old = self.replace(val);
        drop(old);
    }

    /// Bytter værdierne for to celler.
    /// Forskellen med `std::mem::swap` er, at denne funktion ikke kræver `&mut`-reference.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c1 = Cell::new(5i32);
    /// let c2 = Cell::new(10i32);
    /// c1.swap(&c2);
    /// assert_eq!(10, c1.get());
    /// assert_eq!(5, c2.get());
    /// ```
    #[inline]
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn swap(&self, other: &Self) {
        if ptr::eq(self, other) {
            return;
        }
        // SIKKERHED: Dette kan være risikabelt, hvis det kaldes fra separate tråde, men `Cell`
        // er `!Sync`, så dette sker ikke.
        // Dette ugyldiggør heller ikke nogen markører, da `Cell` sørger for, at intet andet peger på nogen af disse `Cell`s.
        //
        unsafe {
            ptr::swap(self.value.get(), other.value.get());
        }
    }

    /// Erstatter den indeholdte værdi med `val` og returnerer den gamle indeholdte værdi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let cell = Cell::new(5);
    /// assert_eq!(cell.get(), 5);
    /// assert_eq!(cell.replace(10), 5);
    /// assert_eq!(cell.get(), 10);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn replace(&self, val: T) -> T {
        // SIKKERHED: Dette kan forårsage dataløb, hvis de kaldes fra en separat tråd,
        // men `Cell` er `!Sync`, så dette sker ikke.
        mem::replace(unsafe { &mut *self.value.get() }, val)
    }

    /// Pakker værdien ud.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.into_inner();
    ///
    /// assert_eq!(five, 5);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value.into_inner()
    }
}

impl<T: Copy> Cell<T> {
    /// Returnerer en kopi af den indeholdte værdi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let five = c.get();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self) -> T {
        // SIKKERHED: Dette kan forårsage dataløb, hvis de kaldes fra en separat tråd,
        // men `Cell` er `!Sync`, så dette sker ikke.
        unsafe { *self.value.get() }
    }

    /// Opdaterer den indeholdte værdi ved hjælp af en funktion og returnerer den nye værdi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_update)]
    ///
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let new = c.update(|x| x + 1);
    ///
    /// assert_eq!(new, 6);
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[unstable(feature = "cell_update", issue = "50186")]
    pub fn update<F>(&self, f: F) -> T
    where
        F: FnOnce(T) -> T,
    {
        let old = self.get();
        let new = f(old);
        self.set(new);
        new
    }
}

impl<T: ?Sized> Cell<T> {
    /// Returnerer en rå markør til de underliggende data i denne celle.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    #[rustc_const_stable(feature = "const_cell_as_ptr", since = "1.32.0")]
    pub const fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Returnerer en ændret henvisning til de underliggende data.
    ///
    /// Dette opkald låner `Cell` mutabelt (ved kompileringstid), hvilket garanterer, at vi har den eneste reference.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let mut c = Cell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c.get(), 6);
    /// ```
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Returnerer en `&Cell<T>` fra en `&mut T`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn from_mut(t: &mut T) -> &Cell<T> {
        // SIKKERHED: `&mut` sikrer unik adgang.
        unsafe { &*(t as *mut T as *const Cell<T>) }
    }
}

impl<T: Default> Cell<T> {
    /// Tager værdien af cellen og efterlader `Default::default()` på sin plads.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let c = Cell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "move_cell", since = "1.17.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<Cell<U>> for Cell<T> {}

impl<T> Cell<[T]> {
    /// Returnerer en `&[Cell<T>]` fra en `&Cell<[T]>`
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::Cell;
    ///
    /// let slice: &mut [i32] = &mut [1, 2, 3];
    /// let cell_slice: &Cell<[i32]> = Cell::from_mut(slice);
    /// let slice_cell: &[Cell<i32>] = cell_slice.as_slice_of_cells();
    ///
    /// assert_eq!(slice_cell.len(), 3);
    /// ```
    #[stable(feature = "as_cell", since = "1.37.0")]
    pub fn as_slice_of_cells(&self) -> &[Cell<T>] {
        // SIKKERHED: `Cell<T>` har samme hukommelseslayout som `T`.
        unsafe { &*(self as *const Cell<[T]> as *const [Cell<T>]) }
    }
}

/// En ændret hukommelsesplacering med dynamisk kontrollerede låneregler
///
/// Se [module-level documentation](self) for mere.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefCell<T: ?Sized> {
    borrow: Cell<BorrowFlag>,
    value: UnsafeCell<T>,
}

/// En fejl returneret af [`RefCell::try_borrow`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already mutably borrowed", f)
    }
}

/// En fejl returneret af [`RefCell::try_borrow_mut`].
#[stable(feature = "try_borrow", since = "1.13.0")]
pub struct BorrowMutError {
    _private: (),
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Debug for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowMutError").finish()
    }
}

#[stable(feature = "try_borrow", since = "1.13.0")]
impl Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        Display::fmt("already borrowed", f)
    }
}

// Positive værdier repræsenterer antallet af aktive `Ref`.Negative værdier repræsenterer antallet af aktive `RefMut`.
// Flere `RefMut`s kan kun være aktive ad gangen, hvis de henviser til forskellige, ikke-overlappende komponenter i en `RefCell` (f.eks. Forskellige udsnit af et udsnit).
//
// `Ref` og `RefMut` er begge to ord i størrelse, og så der vil sandsynligvis aldrig være nok `Ref`s eller`RefMut`s til at overløbe halvdelen af `usize`-området.
// Således vil en `BorrowFlag` sandsynligvis aldrig løbe over eller understrømme.
// Dette er dog ikke en garanti, da et patologisk program gentagne gange kunne oprette og derefter mem::forget `Ref`s eller`RefMut`s.
// Al kode skal således eksplicit kontrollere for overløb og understrømning for at undgå usikkerhed eller i det mindste opføre sig korrekt i tilfælde af, at overløb eller understrømning sker (f.eks. Se BorrowRef::new).
//
//
//
//
//
//
type BorrowFlag = isize;
const UNUSED: BorrowFlag = 0;

#[inline(always)]
fn is_writing(x: BorrowFlag) -> bool {
    x < UNUSED
}

#[inline(always)]
fn is_reading(x: BorrowFlag) -> bool {
    x > UNUSED
}

impl<T> RefCell<T> {
    /// Opretter en ny `RefCell` indeholdende `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_refcell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> RefCell<T> {
        RefCell { value: UnsafeCell::new(value), borrow: Cell::new(UNUSED) }
    }

    /// Forbruger `RefCell` og returnerer den indpakkede værdi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let five = c.into_inner();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    #[inline]
    pub const fn into_inner(self) -> T {
        // Da denne funktion tager `self` (`RefCell`) efter værdi, verificerer compileren statisk, at den ikke i øjeblikket er lånt.
        //
        self.value.into_inner()
    }

    /// Erstatter den indpakkede værdi med en ny, returnerer den gamle værdi uden at deinitialisere nogen af dem.
    ///
    ///
    /// Denne funktion svarer til [`std::mem::replace`](../mem/fn.replace.html).
    ///
    /// # Panics
    ///
    /// Panics hvis værdien aktuelt er lånt.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace(6);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace", since = "1.24.0")]
    #[track_caller]
    pub fn replace(&self, t: T) -> T {
        mem::replace(&mut *self.borrow_mut(), t)
    }

    /// Erstatter den indpakkede værdi med en ny beregnet fra `f`, og returnerer den gamle værdi uden at deinitialisere nogen af dem.
    ///
    ///
    /// # Panics
    ///
    /// Panics hvis værdien aktuelt er lånt.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let cell = RefCell::new(5);
    /// let old_value = cell.replace_with(|&mut old| old + 1);
    /// assert_eq!(old_value, 5);
    /// assert_eq!(cell, RefCell::new(6));
    /// ```
    #[inline]
    #[stable(feature = "refcell_replace_swap", since = "1.35.0")]
    #[track_caller]
    pub fn replace_with<F: FnOnce(&mut T) -> T>(&self, f: F) -> T {
        let mut_borrow = &mut *self.borrow_mut();
        let replacement = f(mut_borrow);
        mem::replace(mut_borrow, replacement)
    }

    /// Bytter den indpakkede værdi af `self` med den indpakkede værdi af `other` uden at deinitialisere nogen af dem.
    ///
    ///
    /// Denne funktion svarer til [`std::mem::swap`](../mem/fn.swap.html).
    ///
    /// # Panics
    ///
    /// Panics hvis værdien i en af `RefCell` i øjeblikket lånes.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    /// let c = RefCell::new(5);
    /// let d = RefCell::new(6);
    /// c.swap(&d);
    /// assert_eq!(c, RefCell::new(6));
    /// assert_eq!(d, RefCell::new(5));
    /// ```
    #[inline]
    #[stable(feature = "refcell_swap", since = "1.24.0")]
    pub fn swap(&self, other: &Self) {
        mem::swap(&mut *self.borrow_mut(), &mut *other.borrow_mut())
    }
}

impl<T: ?Sized> RefCell<T> {
    /// Uformelt låner den indpakkede værdi.
    ///
    /// Lånet varer, indtil den returnerede `Ref` går ud af omfanget.
    /// Flere uforanderlige lån kan tages ud på samme tid.
    ///
    /// # Panics
    ///
    /// Panics hvis værdien i øjeblikket er gyldigt lånt.
    /// Brug en [`try_borrow`](#method.try_borrow)-variant til ikke-panik-variant.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let borrowed_five = c.borrow();
    /// let borrowed_five2 = c.borrow();
    /// ```
    ///
    /// Et eksempel på panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let m = c.borrow_mut();
    /// let b = c.borrow(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow().expect("already mutably borrowed")
    }

    /// Immunably låner den indpakkede værdi og returnerer en fejl, hvis værdien i øjeblikket er gyldigt lånt.
    ///
    ///
    /// Lånet varer, indtil den returnerede `Ref` går ud af omfanget.
    /// Flere uforanderlige lån kan tages ud på samme tid.
    ///
    /// Dette er den ikke-panik-variant af [`borrow`](#method.borrow).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(c.try_borrow().is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow().is_ok());
    /// }
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        match BorrowRef::new(&self.borrow) {
            // SIKKERHED: `BorrowRef` sikrer, at der kun er uforanderlig adgang
            // til værdien, mens den er lånt.
            Some(b) => Ok(Ref { value: unsafe { &*self.value.get() }, borrow: b }),
            None => Err(BorrowError { _private: () }),
        }
    }

    /// Låner gyldigt den indpakkede værdi.
    ///
    /// Lånet varer indtil den returnerede `RefMut` eller alle `RefMut`s, der stammer fra dens exit-omfang.
    ///
    /// Værdien kan ikke lånes, mens denne lån er aktiv.
    ///
    /// # Panics
    ///
    /// Panics hvis værdien aktuelt er lånt.
    /// Brug en [`try_borrow_mut`](#method.try_borrow_mut)-variant til ikke-panik-variant.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new("hello".to_owned());
    ///
    /// *c.borrow_mut() = "bonjour".to_owned();
    ///
    /// assert_eq!(&*c.borrow(), "bonjour");
    /// ```
    ///
    /// Et eksempel på panic:
    ///
    /// ```should_panic
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let m = c.borrow();
    ///
    /// let b = c.borrow_mut(); // this causes a panic
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut().expect("already borrowed")
    }

    /// Låner gyldigt den indpakkede værdi og returnerer en fejl, hvis værdien i øjeblikket lånes.
    ///
    ///
    /// Lånet varer indtil den returnerede `RefMut` eller alle `RefMut`s, der stammer fra dens exit-omfang.
    /// Værdien kan ikke lånes, mens denne lån er aktiv.
    ///
    /// Dette er den ikke-panik-variant af [`borrow_mut`](#method.borrow_mut).
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(c.try_borrow_mut().is_err());
    /// }
    ///
    /// assert!(c.try_borrow_mut().is_ok());
    /// ```
    #[stable(feature = "try_borrow", since = "1.13.0")]
    #[inline]
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        match BorrowRefMut::new(&self.borrow) {
            // SIKKERHED: `BorrowRef` garanterer unik adgang.
            Some(b) => Ok(RefMut { value: unsafe { &mut *self.value.get() }, borrow: b }),
            None => Err(BorrowMutError { _private: () }),
        }
    }

    /// Returnerer en rå markør til de underliggende data i denne celle.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// let ptr = c.as_ptr();
    /// ```
    #[inline]
    #[stable(feature = "cell_as_ptr", since = "1.12.0")]
    pub fn as_ptr(&self) -> *mut T {
        self.value.get()
    }

    /// Returnerer en ændret henvisning til de underliggende data.
    ///
    /// Dette opkald låner `RefCell` mutabelt (ved kompileringstid), så der er ikke behov for dynamiske kontroller.
    ///
    /// Vær dog forsigtig: denne metode forventer, at `self` kan ændres, hvilket generelt ikke er tilfældet, når du bruger en `RefCell`.
    ///
    /// Se i stedet på [`borrow_mut`]-metoden, hvis `self` ikke kan ændres.
    ///
    /// Vær også opmærksom på, at denne metode kun er beregnet til særlige omstændigheder og normalt ikke er det, du ønsker.
    /// I tvivlstilfælde skal du bruge [`borrow_mut`] i stedet.
    ///
    /// [`borrow_mut`]: RefCell::borrow_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(c, RefCell::new(6));
    /// ```
    ///
    #[inline]
    #[stable(feature = "cell_get_mut", since = "1.11.0")]
    pub fn get_mut(&mut self) -> &mut T {
        self.value.get_mut()
    }

    /// Fortryd effekten af lækkede beskyttere på lånetilstanden på `RefCell`.
    ///
    /// Dette opkald svarer til [`get_mut`], men mere specialiseret.
    /// Det låner `RefCell` mutabelt for at sikre, at der ikke findes nogen lån, og nulstiller derefter tilstanden, der sporer delte lån.
    /// Dette er relevant, hvis nogle `Ref`-eller `RefMut`-lån er lækket.
    ///
    /// [`get_mut`]: RefCell::get_mut()
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::RefCell;
    ///
    /// let mut c = RefCell::new(0);
    /// std::mem::forget(c.borrow_mut());
    ///
    /// assert!(c.try_borrow().is_err());
    /// c.undo_leak();
    /// assert!(c.try_borrow().is_ok());
    /// ```
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn undo_leak(&mut self) -> &mut T {
        *self.borrow.get_mut() = UNUSED;
        self.get_mut()
    }

    /// Immunably låner den indpakkede værdi og returnerer en fejl, hvis værdien i øjeblikket er gyldigt lånt.
    ///
    /// # Safety
    ///
    /// I modsætning til `RefCell::borrow` er denne metode usikker, fordi den ikke returnerer en `Ref`, hvorved låneflagget ikke berøres.
    /// Omvendt at låne `RefCell`, mens referencen, der returneres ved denne metode, er udefineret.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    ///
    /// {
    ///     let m = c.borrow_mut();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_err());
    /// }
    ///
    /// {
    ///     let m = c.borrow();
    ///     assert!(unsafe { c.try_borrow_unguarded() }.is_ok());
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "borrow_state", since = "1.37.0")]
    #[inline]
    pub unsafe fn try_borrow_unguarded(&self) -> Result<&T, BorrowError> {
        if !is_writing(self.borrow.get()) {
            // SIKKERHED: Vi kontrollerer, at ingen skriver aktivt nu, men det er det
            // den opkalendes ansvar for at sikre, at ingen skriver, før den returnerede reference ikke længere er i brug.
            // `self.value.get()` henviser også til den værdi, der ejes af `self`, og er således garanteret at være gyldig i `self` s levetid.
            //
            //
            Ok(unsafe { &*self.value.get() })
        } else {
            Err(BorrowError { _private: () })
        }
    }
}

impl<T: Default> RefCell<T> {
    /// Tager den indpakkede værdi og efterlader `Default::default()` på sin plads.
    ///
    /// # Panics
    ///
    /// Panics hvis værdien aktuelt er lånt.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::RefCell;
    ///
    /// let c = RefCell::new(5);
    /// let five = c.take();
    ///
    /// assert_eq!(five, 5);
    /// assert_eq!(c.into_inner(), 0);
    /// ```
    #[stable(feature = "refcell_take", since = "1.50.0")]
    pub fn take(&self) -> T {
        self.replace(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized> Send for RefCell<T> where T: Send {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for RefCell<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for RefCell<T> {
    /// # Panics
    ///
    /// Panics hvis værdien i øjeblikket er gyldigt lånt.
    #[inline]
    #[track_caller]
    fn clone(&self) -> RefCell<T> {
        RefCell::new(self.borrow().clone())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for RefCell<T> {
    /// Opretter en `RefCell<T>` med `Default`-værdien for T.
    #[inline]
    fn default() -> RefCell<T> {
        RefCell::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for RefCell<T> {
    /// # Panics
    ///
    /// Panics hvis værdien i en af `RefCell` i øjeblikket lånes.
    #[inline]
    fn eq(&self, other: &RefCell<T>) -> bool {
        *self.borrow() == *other.borrow()
    }
}

#[stable(feature = "cell_eq", since = "1.2.0")]
impl<T: ?Sized + Eq> Eq for RefCell<T> {}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for RefCell<T> {
    /// # Panics
    ///
    /// Panics hvis værdien i en af `RefCell` i øjeblikket lånes.
    #[inline]
    fn partial_cmp(&self, other: &RefCell<T>) -> Option<Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }

    /// # Panics
    ///
    /// Panics hvis værdien i en af `RefCell` i øjeblikket lånes.
    #[inline]
    fn lt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() < *other.borrow()
    }

    /// # Panics
    ///
    /// Panics hvis værdien i en af `RefCell` i øjeblikket lånes.
    #[inline]
    fn le(&self, other: &RefCell<T>) -> bool {
        *self.borrow() <= *other.borrow()
    }

    /// # Panics
    ///
    /// Panics hvis værdien i en af `RefCell` i øjeblikket lånes.
    #[inline]
    fn gt(&self, other: &RefCell<T>) -> bool {
        *self.borrow() > *other.borrow()
    }

    /// # Panics
    ///
    /// Panics hvis værdien i en af `RefCell` i øjeblikket lånes.
    #[inline]
    fn ge(&self, other: &RefCell<T>) -> bool {
        *self.borrow() >= *other.borrow()
    }
}

#[stable(feature = "cell_ord", since = "1.10.0")]
impl<T: ?Sized + Ord> Ord for RefCell<T> {
    /// # Panics
    ///
    /// Panics hvis værdien i en af `RefCell` i øjeblikket lånes.
    #[inline]
    fn cmp(&self, other: &RefCell<T>) -> Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for RefCell<T> {
    fn from(t: T) -> RefCell<T> {
        RefCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<RefCell<U>> for RefCell<T> {}

struct BorrowRef<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl<'b> BorrowRef<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRef<'b>> {
        let b = borrow.get().wrapping_add(1);
        if !is_reading(b) {
            // Forøgelse af lån kan resultere i en ikke-aflæsningsværdi (<=0) i disse tilfælde:
            // 1. Det var <0, dvs. der er skrivelån, så vi kan ikke tillade en læstlån på grund af Rust s referencealiaseringsregler
            // 2.
            // Det var isize::MAX (det maksimale antal læselån) og det løb over i isize::MIN (det maksimale antal lån til skrivning), så vi kan ikke tillade en yderligere læselån, fordi isize ikke kan repræsentere så mange læste lån (dette kan kun ske, hvis du mem::forget mere end en lille konstant mængde `Ref`s, hvilket ikke er god praksis)
            //
            //
            //
            //
            None
        } else {
            // Forøgelse af lån kan resultere i en aflæsningsværdi (> 0) i disse tilfælde:
            // 1. Det var=0, dvs. det var ikke lånt, og vi tager den først læste lån
            // 2. Det var> 0 og <isize::MAX, dvs.
            // der blev læst lån, og isize er stor nok til at repræsentere at have en mere læst lån
            borrow.set(b);
            Some(BorrowRef { borrow })
        }
    }
}

impl Drop for BorrowRef<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        self.borrow.set(borrow - 1);
    }
}

impl Clone for BorrowRef<'_> {
    #[inline]
    fn clone(&self) -> Self {
        // Da denne ref findes, ved vi, at låneflagget er en læselån.
        //
        let borrow = self.borrow.get();
        debug_assert!(is_reading(borrow));
        // Forhindre lånetælleren i at løbe over i en skriftlig lån.
        //
        assert!(borrow != isize::MAX);
        self.borrow.set(borrow + 1);
        BorrowRef { borrow: self.borrow }
    }
}

/// Indpakker en lånt reference til en værdi i en `RefCell`-boks.
/// En indpakningstype til en uforanderligt lånt værdi fra en `RefCell<T>`.
///
/// Se [module-level documentation](self) for mere.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Ref<'b, T: ?Sized + 'b> {
    value: &'b T,
    borrow: BorrowRef<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

impl<'b, T: ?Sized> Ref<'b, T> {
    /// Kopierer en `Ref`.
    ///
    /// `RefCell` er allerede umådeligt lånt, så dette kan ikke mislykkes.
    ///
    /// Dette er en tilknyttet funktion, der skal bruges som `Ref::clone(...)`.
    /// En `Clone`-implementering eller en metode vil forstyrre den udbredte brug af `r.borrow().clone()` til at klone indholdet af en `RefCell`.
    ///
    ///
    #[stable(feature = "cell_extras", since = "1.15.0")]
    #[inline]
    pub fn clone(orig: &Ref<'b, T>) -> Ref<'b, T> {
        Ref { value: orig.value, borrow: orig.borrow.clone() }
    }

    /// Opretter en ny `Ref` til en komponent i de lånte data.
    ///
    /// `RefCell` er allerede umådeligt lånt, så dette kan ikke mislykkes.
    ///
    /// Dette er en tilknyttet funktion, der skal bruges som `Ref::map(...)`.
    /// En metode vil forstyrre metoder med samme navn på indholdet af en `RefCell`, der bruges gennem `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// let b1: Ref<(u32, char)> = c.borrow();
    /// let b2: Ref<u32> = Ref::map(b1, |t| &t.0);
    /// assert_eq!(*b2, 5)
    /// ```
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Ref<'b, U>
    where
        F: FnOnce(&T) -> &U,
    {
        Ref { value: f(orig.value), borrow: orig.borrow }
    }

    /// Opretter en ny `Ref` til en valgfri komponent i de lånte data.
    /// Den originale vagt returneres som en `Err(..)`, hvis lukningen returnerer `None`.
    ///
    /// `RefCell` er allerede umådeligt lånt, så dette kan ikke mislykkes.
    ///
    /// Dette er en tilknyttet funktion, der skal bruges som `Ref::filter_map(...)`.
    /// En metode vil forstyrre metoder med samme navn på indholdet af en `RefCell`, der bruges gennem `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, Ref};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    /// let b1: Ref<Vec<u32>> = c.borrow();
    /// let b2: Result<Ref<u32>, _> = Ref::filter_map(b1, |v| v.get(1));
    /// assert_eq!(*b2.unwrap(), 2);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: Ref<'b, T>, f: F) -> Result<Ref<'b, U>, Self>
    where
        F: FnOnce(&T) -> Option<&U>,
    {
        match f(orig.value) {
            Some(value) => Ok(Ref { value, borrow: orig.borrow }),
            None => Err(orig),
        }
    }

    /// Opdeler en `Ref` i flere `Ref`'er for forskellige komponenter i de lånte data.
    ///
    /// `RefCell` er allerede umådeligt lånt, så dette kan ikke mislykkes.
    ///
    /// Dette er en tilknyttet funktion, der skal bruges som `Ref::map_split(...)`.
    /// En metode vil forstyrre metoder med samme navn på indholdet af en `RefCell`, der bruges gennem `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{Ref, RefCell};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow();
    /// let (begin, end) = Ref::map_split(borrow, |slice| slice.split_at(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// ```
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(orig: Ref<'b, T>, f: F) -> (Ref<'b, U>, Ref<'b, V>)
    where
        F: FnOnce(&T) -> (&U, &V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (Ref { value: a, borrow }, Ref { value: b, borrow: orig.borrow })
    }

    /// Konverter til en reference til de underliggende data.
    ///
    /// Den underliggende `RefCell` kan aldrig lånes om fra igen og vil altid fremstå som allerede uforanderligt lånt.
    ///
    /// Det er ikke en god ide at lække mere end et konstant antal referencer.
    /// `RefCell` kan lånes uendeligt igen, hvis der i alt kun har været et mindre antal lækager.
    ///
    /// Dette er en tilknyttet funktion, der skal bruges som `Ref::leak(...)`.
    /// En metode vil forstyrre metoder med samme navn på indholdet af en `RefCell`, der bruges gennem `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, Ref};
    /// let cell = RefCell::new(0);
    ///
    /// let value = Ref::leak(cell.borrow());
    /// assert_eq!(*value, 0);
    ///
    /// assert!(cell.try_borrow().is_ok());
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: Ref<'b, T>) -> &'b T {
        // Ved at glemme denne ref sikrer vi, at lånetælleren i RefCell ikke kan gå tilbage til UBRUGT inden for levetiden `'b`.
        // Nulstilling af referencesporingsstatus vil kræve en unik reference til den lånte RefCell.
        // Der kan ikke oprettes yderligere ændrede referencer fra den oprindelige celle.
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Ref<'b, U>> for Ref<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

impl<'b, T: ?Sized> RefMut<'b, T> {
    /// Opretter en ny `RefMut` til en komponent i de lånte data, f.eks. En enum-variant.
    ///
    /// `RefCell` er allerede lånt mutabelt, så dette kan ikke mislykkes.
    ///
    /// Dette er en tilknyttet funktion, der skal bruges som `RefMut::map(...)`.
    /// En metode vil forstyrre metoder med samme navn på indholdet af en `RefCell`, der bruges gennem `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new((5, 'b'));
    /// {
    ///     let b1: RefMut<(u32, char)> = c.borrow_mut();
    ///     let mut b2: RefMut<u32> = RefMut::map(b1, |t| &mut t.0);
    ///     assert_eq!(*b2, 5);
    ///     *b2 = 42;
    /// }
    /// assert_eq!(*c.borrow(), (42, 'b'));
    /// ```
    ///
    #[stable(feature = "cell_map", since = "1.8.0")]
    #[inline]
    pub fn map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> RefMut<'b, U>
    where
        F: FnOnce(&mut T) -> &mut U,
    {
        // FIXME(nll-rfc#40): ordne lånetjek
        let RefMut { value, borrow } = orig;
        RefMut { value: f(value), borrow }
    }

    /// Opretter en ny `RefMut` til en valgfri komponent i de lånte data.
    /// Den originale vagt returneres som en `Err(..)`, hvis lukningen returnerer `None`.
    ///
    /// `RefCell` er allerede lånt mutabelt, så dette kan ikke mislykkes.
    ///
    /// Dette er en tilknyttet funktion, der skal bruges som `RefMut::filter_map(...)`.
    /// En metode vil forstyrre metoder med samme navn på indholdet af en `RefCell`, der bruges gennem `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_filter_map)]
    ///
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let c = RefCell::new(vec![1, 2, 3]);
    ///
    /// {
    ///     let b1: RefMut<Vec<u32>> = c.borrow_mut();
    ///     let mut b2: Result<RefMut<u32>, _> = RefMut::filter_map(b1, |v| v.get_mut(1));
    ///
    ///     if let Ok(mut b2) = b2 {
    ///         *b2 += 2;
    ///     }
    /// }
    ///
    /// assert_eq!(*c.borrow(), vec![1, 4, 3]);
    /// ```
    ///
    #[unstable(feature = "cell_filter_map", reason = "recently added", issue = "81061")]
    #[inline]
    pub fn filter_map<U: ?Sized, F>(orig: RefMut<'b, T>, f: F) -> Result<RefMut<'b, U>, Self>
    where
        F: FnOnce(&mut T) -> Option<&mut U>,
    {
        // FIXME(nll-rfc#40): ordne lånetjek
        let RefMut { value, borrow } = orig;
        let value = value as *mut T;
        // SIKKERHED: funktionen holder fast i en eksklusiv reference i varigheden
        // af sit opkald gennem `orig`, og der henvises kun til markøren inde i funktionsopkaldet og lader aldrig den eksklusive reference undslippe.
        //
        //
        match f(unsafe { &mut *value }) {
            Some(value) => Ok(RefMut { value, borrow }),
            None => {
                // SIKKERHED: samme som ovenfor.
                Err(RefMut { value: unsafe { &mut *value }, borrow })
            }
        }
    }

    /// Opdeler en `RefMut` i flere `RefMut`s til forskellige komponenter i de lånte data.
    ///
    /// Den underliggende `RefCell` forbliver gyldigt lånt, indtil begge returnerede `RefMut`s går uden for anvendelsesområdet.
    ///
    /// `RefCell` er allerede lånt mutabelt, så dette kan ikke mislykkes.
    ///
    /// Dette er en tilknyttet funktion, der skal bruges som `RefMut::map_split(...)`.
    /// En metode vil forstyrre metoder med samme navn på indholdet af en `RefCell`, der bruges gennem `Deref`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::{RefCell, RefMut};
    ///
    /// let cell = RefCell::new([1, 2, 3, 4]);
    /// let borrow = cell.borrow_mut();
    /// let (mut begin, mut end) = RefMut::map_split(borrow, |slice| slice.split_at_mut(2));
    /// assert_eq!(*begin, [1, 2]);
    /// assert_eq!(*end, [3, 4]);
    /// begin.copy_from_slice(&[4, 3]);
    /// end.copy_from_slice(&[2, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "refcell_map_split", since = "1.35.0")]
    #[inline]
    pub fn map_split<U: ?Sized, V: ?Sized, F>(
        orig: RefMut<'b, T>,
        f: F,
    ) -> (RefMut<'b, U>, RefMut<'b, V>)
    where
        F: FnOnce(&mut T) -> (&mut U, &mut V),
    {
        let (a, b) = f(orig.value);
        let borrow = orig.borrow.clone();
        (RefMut { value: a, borrow }, RefMut { value: b, borrow: orig.borrow })
    }

    /// Konverter til en ændret henvisning til de underliggende data.
    ///
    /// Den underliggende `RefCell` kan ikke lånes fra igen og vises altid allerede gyldigt lånt, hvilket gør den returnerede reference den eneste til interiøret.
    ///
    ///
    /// Dette er en tilknyttet funktion, der skal bruges som `RefMut::leak(...)`.
    /// En metode vil forstyrre metoder med samme navn på indholdet af en `RefCell`, der bruges gennem `Deref`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(cell_leak)]
    /// use std::cell::{RefCell, RefMut};
    /// let cell = RefCell::new(0);
    ///
    /// let value = RefMut::leak(cell.borrow_mut());
    /// assert_eq!(*value, 0);
    /// *value = 1;
    ///
    /// assert!(cell.try_borrow_mut().is_err());
    /// ```
    ///
    #[unstable(feature = "cell_leak", issue = "69099")]
    pub fn leak(orig: RefMut<'b, T>) -> &'b mut T {
        // Ved at glemme denne BorrowRefMut sikrer vi, at lånetælleren i RefCell ikke kan gå tilbage til UNUSED inden for levetiden `'b`.
        // Nulstilling af referencesporingsstatus vil kræve en unik reference til den lånte RefCell.
        // Der kan ikke oprettes yderligere referencer fra den oprindelige celle inden for den levetid, hvilket gør den aktuelle lån til den eneste reference for den resterende levetid.
        //
        //
        mem::forget(orig.borrow);
        orig.value
    }
}

struct BorrowRefMut<'b> {
    borrow: &'b Cell<BorrowFlag>,
}

impl Drop for BorrowRefMut<'_> {
    #[inline]
    fn drop(&mut self) {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        self.borrow.set(borrow + 1);
    }
}

impl<'b> BorrowRefMut<'b> {
    #[inline]
    fn new(borrow: &'b Cell<BorrowFlag>) -> Option<BorrowRefMut<'b>> {
        // NOTE: I modsætning til BorrowRefMut::clone kaldes nyt for at oprette initialen
        // mutable reference, og derfor må der i øjeblikket ikke være nogen eksisterende referencer.
        // Således, mens klon forøger det mutable reftælling, tillader vi her eksplicit kun at gå fra UNUSED til UNUSED, 1.
        //
        match borrow.get() {
            UNUSED => {
                borrow.set(UNUSED - 1);
                Some(BorrowRefMut { borrow })
            }
            _ => None,
        }
    }

    // Kloner en `BorrowRefMut`.
    //
    // Dette er kun gyldigt, hvis hver `BorrowRefMut` bruges til at spore en ændret reference til et særskilt, ikke-overlappende interval for det originale objekt.
    //
    // Dette er ikke i en klonimpl, så koden ikke kalder dette implicit.
    #[inline]
    fn clone(&self) -> BorrowRefMut<'b> {
        let borrow = self.borrow.get();
        debug_assert!(is_writing(borrow));
        // Undgå, at lånetælleren understrømmer.
        assert!(borrow != isize::MIN);
        self.borrow.set(borrow - 1);
        BorrowRefMut { borrow: self.borrow }
    }
}

/// En indpakningstype til en gyldigt lånt værdi fra en `RefCell<T>`.
///
/// Se [module-level documentation](self) for mere.
#[stable(feature = "rust1", since = "1.0.0")]
pub struct RefMut<'b, T: ?Sized + 'b> {
    value: &'b mut T,
    borrow: BorrowRefMut<'b>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        self.value
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'b, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<RefMut<'b, U>> for RefMut<'b, T> {}

#[stable(feature = "std_guard_impls", since = "1.20.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.value.fmt(f)
    }
}

/// Kernen primitiv til indvendig mutabilitet i Rust.
///
/// Hvis du har en reference `&T`, udfører compileren normalt i Rust optimeringer baseret på den viden, at `&T` peger på uforanderlige data.At mutere disse data, f.eks. Gennem et alias eller ved at transmittere en `&T` til en `&mut T`, betragtes som udefineret adfærd.
/// `UnsafeCell<T>` fravælger garantien for uforanderlighed for `&T`: en delt reference `&UnsafeCell<T>` kan pege på data, der bliver muteret.Dette kaldes "interior mutability".
///
/// Alle andre typer, der tillader intern mutabilitet, såsom `Cell<T>` og `RefCell<T>`, bruger `UnsafeCell` internt til at indpakke deres data.
///
/// Bemærk, at kun immutabilitetsgarantien for delte referencer påvirkes af `UnsafeCell`.Den unikke garanti for ændrede referencer påvirkes ikke.Der er *ingen* lovlig måde at opnå aliasing af `&mut`, ikke engang med `UnsafeCell<T>`.
///
/// `UnsafeCell` API selv er teknisk meget enkel: [`.get()`] giver dig en rå pointer `*mut T` til dens indhold.Det er op til _you_ som abstraktionsdesigner at bruge den rå pointer korrekt.
///
/// [`.get()`]: `UnsafeCell::get`
///
/// De nøjagtige Rust-aliasingsregler er noget i bevægelse, men hovedpunkterne er ikke omstridte:
///
/// - Hvis du opretter en sikker reference med levetiden `'a` (enten en `&T`-eller `&mut T`-reference), der er tilgængelig med sikker kode (for eksempel fordi du returnerede den), skal du ikke få adgang til dataene på nogen måde, der modsiger denne reference for resten af `'a`.
/// For eksempel betyder det, at hvis du tager `*mut T` fra en `UnsafeCell<T>` og kaster den til en `&T`, skal dataene i `T` forblive uforanderlige (modulo alle `UnsafeCell`-data, der findes inden for `T`, selvfølgelig), indtil referencens levetid udløber.
/// Tilsvarende, hvis du opretter en `&mut T`-reference, der frigives til sikker kode, skal du ikke få adgang til dataene i `UnsafeCell`, før denne reference udløber.
///
/// - Du skal til enhver tid undgå dataløb.Hvis flere tråde har adgang til den samme `UnsafeCell`, skal enhver skrivning have en ordentlig ske-før-relation til alle andre adganger (eller bruge atomics).
///
/// For at hjælpe med korrekt design erklæres følgende scenarier udtrykkeligt lovligt for kode med en tråd:
///
/// 1. En `&T`-reference kan frigives til sikker kode, og der kan den eksistere sammen med andre `&T`-referencer, men ikke med en `&mut T`
///
/// 2. En `&mut T`-reference kan frigives til sikker kode, forudsat at hverken anden `&mut T` eller `&T` eksisterer sammen med den.En `&mut T` skal altid være unik.
///
/// Bemærk, at mens mutering af indholdet af en `&UnsafeCell<T>` (selvom andre `&UnsafeCell<T>` refererer til alias cellen) er ok (forudsat at du håndhæver ovenstående invarianter på en anden måde), er det stadig udefineret adfærd at have flere `&mut UnsafeCell<T>`-aliasser.
/// Det vil sige, `UnsafeCell` er en indpakning designet til at have en særlig interaktion med _shared_ accesses (_i.e._ gennem en `&UnsafeCell<_>`-reference);der er ingen magi overhovedet, når man beskæftiger sig med _exclusive_ accesses (_e.g._ gennem en `&mut UnsafeCell<_>`): hverken cellen eller den indpakkede værdi kan være alias i varigheden af den `&mut`-lån.
///
/// Dette fremvises af [`.get_mut()`] accessor, som er en _safe_ getter, der giver en `&mut T`.
///
/// [`.get_mut()`]: `UnsafeCell::get_mut`
///
/// # Examples
///
/// Her er et eksempel, der viser, hvordan man lydmutrer indholdet af en `UnsafeCell<_>`, selvom der er flere referencer, der aliaserer cellen:
///
/// ```
/// use std::cell::UnsafeCell;
///
/// let x: UnsafeCell<i32> = 42.into();
/// // Få flere/delte referencer til den samme `x`.
/// let (p1, p2): (&UnsafeCell<i32>, &UnsafeCell<i32>) = (&x, &x);
///
/// unsafe {
///     // SIKKERHED: inden for dette omfang er der ingen andre henvisninger til indholdet af 'x',
///     // så vores er effektivt unik.
///     let p1_exclusive: &mut i32 = &mut *p1.get(); // -- lån-+
///     *p1_exclusive += 27; // |
/// } // <---------- kan ikke gå ud over dette punkt -------------------+
///
/// unsafe {
///     // SIKKERHED: inden for dette omfang forventer ingen at have eksklusiv adgang til `x`s indhold,
///     // så vi kan have flere delte adgang samtidigt.
///     let p2_shared: &i32 = &*p2.get();
///     assert_eq!(*p2_shared, 42 + 27);
///     let p1_shared: &i32 = &*p1.get();
///     assert_eq!(*p1_shared, *p2_shared);
/// }
/// ```
///
/// Følgende eksempel viser, at eksklusiv adgang til en `UnsafeCell<T>` indebærer eksklusiv adgang til sin `T`:
///
/// ```rust
/// #![forbid(unsafe_code)] // med eksklusiv adgang,
///                         // `UnsafeCell` er en gennemsigtig no-op-indpakning, så der er ikke behov for `unsafe` her.
/////
/// use std::cell::UnsafeCell;
///
/// let mut x: UnsafeCell<i32> = 42.into();
///
/// // Få en kompileringstidschecket unik reference til `x`.
/// let p_unique: &mut UnsafeCell<i32> = &mut x;
/// // Med en eksklusiv reference kan vi mutere indholdet gratis.
/// *p_unique.get_mut() = 0;
/// // Eller tilsvarende:
/// x = UnsafeCell::new(0);
///
/// // Når vi ejer værdien, kan vi udtrække indholdet gratis.
/// let contents: i32 = x.into_inner();
/// assert_eq!(contents, 0);
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "unsafe_cell"]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(transparent)]
#[repr(no_niche)] // rust-lang/rust#68303.
pub struct UnsafeCell<T: ?Sized> {
    value: T,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for UnsafeCell<T> {}

impl<T> UnsafeCell<T> {
    /// Konstruerer en ny forekomst af `UnsafeCell`, som omslutter den angivne værdi.
    ///
    ///
    /// Al adgang til den indre værdi gennem metoder er `unsafe`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafe_cell_new", since = "1.32.0")]
    #[inline]
    pub const fn new(value: T) -> UnsafeCell<T> {
        UnsafeCell { value }
    }

    /// Pakker værdien ud.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.into_inner();
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> T {
        self.value
    }
}

impl<T: ?Sized> UnsafeCell<T> {
    /// Får en ændret markør til den indpakkede værdi.
    ///
    /// Dette kan kastes til en markør af enhver art.
    /// Sørg for, at adgangen er unik (ingen aktive referencer, mutable eller ej), når du caster til `&mut T`, og sørg for, at der ikke er mutationer eller mutable aliaser, når casting til `&T`
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let uc = UnsafeCell::new(5);
    ///
    /// let five = uc.get();
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_unsafecell_get", since = "1.32.0")]
    pub const fn get(&self) -> *mut T {
        // Vi kan bare kaste markøren fra `UnsafeCell<T>` til `T` på grund af #[repr(transparent)].
        // Dette udnytter libstds særlige status, der er ingen garanti for brugerkode, at dette fungerer i future versioner af compileren!
        //
        self as *const UnsafeCell<T> as *const T as *mut T
    }

    /// Returnerer en ændret henvisning til de underliggende data.
    ///
    /// Dette opkald låner `UnsafeCell` mutabelt (ved kompileringstid), hvilket garanterer, at vi har den eneste reference.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cell::UnsafeCell;
    ///
    /// let mut c = UnsafeCell::new(5);
    /// *c.get_mut() += 1;
    ///
    /// assert_eq!(*c.get_mut(), 6);
    /// ```
    #[inline]
    #[stable(feature = "unsafe_cell_get_mut", since = "1.50.0")]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.value
    }

    /// Får en ændret markør til den indpakkede værdi.
    /// Forskellen til [`get`] er, at denne funktion accepterer en rå pointer, hvilket er nyttigt for at undgå oprettelse af midlertidige referencer.
    ///
    /// Resultatet kan kastes til en markør af enhver art.
    /// Sørg for, at adgangen er unik (ingen aktive referencer, mutable eller ej), når du caster til `&mut T`, og sørg for, at der ikke foregår mutationer eller mutable alias, når du caster til `&T`.
    ///
    ///
    /// [`get`]: UnsafeCell::get()
    ///
    /// # Examples
    ///
    /// Gradvis initialisering af en `UnsafeCell` kræver `raw_get`, da opkald til `get` kræver, at der oprettes en henvisning til ikke-initialiserede data:
    ///
    /// ```
    /// #![feature(unsafe_cell_raw_get)]
    /// use std::cell::UnsafeCell;
    /// use std::mem::MaybeUninit;
    ///
    /// let m = MaybeUninit::<UnsafeCell<i32>>::uninit();
    /// unsafe { UnsafeCell::raw_get(m.as_ptr()).write(5); }
    /// let uc = unsafe { m.assume_init() };
    ///
    /// assert_eq!(uc.into_inner(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "unsafe_cell_raw_get", issue = "66358")]
    pub const fn raw_get(this: *const Self) -> *mut T {
        // Vi kan bare kaste markøren fra `UnsafeCell<T>` til `T` på grund af #[repr(transparent)].
        // Dette udnytter libstds særlige status, der er ingen garanti for brugerkode, at dette fungerer i future versioner af compileren!
        //
        this as *const T as *mut T
    }
}

#[stable(feature = "unsafe_cell_default", since = "1.10.0")]
impl<T: Default> Default for UnsafeCell<T> {
    /// Opretter en `UnsafeCell` med `Default`-værdien for T.
    fn default() -> UnsafeCell<T> {
        UnsafeCell::new(Default::default())
    }
}

#[stable(feature = "cell_from", since = "1.12.0")]
impl<T> From<T> for UnsafeCell<T> {
    fn from(t: T) -> UnsafeCell<T> {
        UnsafeCell::new(t)
    }
}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: CoerceUnsized<U>, U> CoerceUnsized<UnsafeCell<U>> for UnsafeCell<T> {}

#[allow(unused)]
fn assert_coerce_unsized(a: UnsafeCell<&i32>, b: Cell<&i32>, c: RefCell<&i32>) {
    let _: UnsafeCell<&dyn Send> = a;
    let _: Cell<&dyn Send> = b;
    let _: RefCell<&dyn Send> = c;
}