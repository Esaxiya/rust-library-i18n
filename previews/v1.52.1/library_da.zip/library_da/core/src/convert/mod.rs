//! Traits til konvertering mellem typer.
//!
//! traits i dette modul giver en måde at konvertere fra en type til en anden type.
//! Hver trait tjener et andet formål:
//!
//! - Implementér [`AsRef`] trait for billige reference-til-reference-konverteringer
//! - Implementér [`AsMut`] trait for billige mutable-til-mutable konverteringer
//! - Implementér [`From`] trait til at forbruge værdi-til-værdi-konverteringer
//! - Implementere [`Into`] trait til at forbruge værdi-til-værdi-konverteringer til typer uden for den nuværende crate
//! - [`TryFrom`] og [`TryInto`] traits opfører sig som [`From`] og [`Into`], men skal implementeres, når konverteringen kan mislykkes.
//!
//! traits i dette modul bruges ofte som trait bounds til generiske funktioner, således at argumenter af flere typer understøttes.Se dokumentationen for hver trait for eksempler.
//!
//! Som biblioteksforfatter bør du altid foretrække at implementere [`From<T>`][`From`] eller [`TryFrom<T>`][`TryFrom`] i stedet for [`Into<U>`][`Into`] eller [`TryInto<U>`][`TryInto`], da [`From`] og [`TryFrom`] giver større fleksibilitet og tilbyder tilsvarende [`Into`]-eller [`TryInto`]-implementeringer gratis takket være en tæppeimplementering i standardbiblioteket.
//! Når du målretter mod en version før Rust 1.41, kan det være nødvendigt at implementere [`Into`] eller [`TryInto`] direkte, når du konverterer til en type uden for den nuværende crate.
//!
//! # Generiske implementeringer
//!
//! - [`AsRef`] og [`AsMut`] automatisk derference, hvis den indre type er en reference
//! - [`Fra`]`<U>for T` betyder [`Into`]`</u><T><U>for U`</u>
//! - [`TryFrom`]`<U>for T` betyder [`TryInto`]`</u><T><U>for U`</u>
//! - [`From`] og [`Into`] er refleksive, hvilket betyder, at alle typer kan `into` selv og `from` selv
//!
//! Se hver trait for brugseksempler.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Identitetsfunktionen.
///
/// To ting er vigtige at bemærke om denne funktion:
///
/// - Det svarer ikke altid til en lukning som `|x| x`, da lukningen kan tvinge `x` til en anden type.
///
/// - Den flytter indgangen `x`, der sendes til funktionen.
///
/// Selvom det kan virke underligt at have en funktion, der bare returnerer input, er der nogle interessante anvendelser.
///
///
/// # Examples
///
/// Brug af `identity` til at gøre noget i en række andre, interessante funktioner:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Lad os foregive at tilføje en er en interessant funktion.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Brug af `identity` som en "do nothing" basissag i en betinget:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Gør mere interessante ting ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Brug af `identity` til at beholde `Some`-varianterne af en iterator af `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Bruges til at lave en billig reference-til-reference-konvertering.
///
/// Denne trait svarer til [`AsMut`], som bruges til konvertering mellem mutable referencer.
/// Hvis du har brug for en dyre konvertering, er det bedre at implementere [`From`] med type `&T` eller skrive en brugerdefineret funktion.
///
/// `AsRef` har den samme signatur som [`Borrow`], men [`Borrow`] er forskellig i få aspekter:
///
/// - I modsætning til `AsRef` har [`Borrow`] et tæppeimpl til enhver `T` og kan bruges til at acceptere enten en reference eller en værdi.
/// - [`Borrow`] kræver også, at [`Hash`], [`Eq`] og [`Ord`] for lånt værdi svarer til værdierne for den ejede værdi.
/// Af denne grund, hvis du kun ønsker at låne et enkelt felt i en struktur, kan du implementere `AsRef`, men ikke [`Borrow`].
///
/// **Note: Denne trait må ikke fejle **.Hvis konverteringen kan mislykkes, skal du bruge en dedikeret metode, der returnerer en [`Option<T>`] eller en [`Result<T, E>`].
///
/// # Generiske implementeringer
///
/// - `AsRef` auto-dereferences, hvis den indre type er en reference eller en mutabel reference (f.eks: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Ved at bruge trait bounds kan vi acceptere argumenter af forskellige typer, så længe de kan konverteres til den angivne type `T`.
///
/// For eksempel: Ved at oprette en generisk funktion, der tager en `AsRef<str>`, udtrykker vi, at vi vil acceptere alle referencer, der kan konverteres til [`&str`] som et argument.
/// Da både [`String`] og [`&str`] implementerer `AsRef<str>`, kan vi acceptere begge som inputargument.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Udfører konverteringen.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Bruges til at lave en billig mutable-to-mutable reference konvertering.
///
/// Denne trait svarer til [`AsRef`], men bruges til konvertering mellem mutable referencer.
/// Hvis du har brug for en dyre konvertering, er det bedre at implementere [`From`] med type `&mut T` eller skrive en brugerdefineret funktion.
///
/// **Note: Denne trait må ikke fejle **.Hvis konverteringen kan mislykkes, skal du bruge en dedikeret metode, der returnerer en [`Option<T>`] eller en [`Result<T, E>`].
///
/// # Generiske implementeringer
///
/// - `AsMut` auto-dereferences, hvis den indre type er en ændret reference (f.eks: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Ved hjælp af `AsMut` som trait bound til en generisk funktion kan vi acceptere alle mutable referencer, der kan konverteres til type `&mut T`.
/// Fordi [`Box<T>`] implementerer `AsMut<T>`, kan vi skrive en funktion `add_one`, der tager alle argumenter, der kan konverteres til `&mut u64`.
/// Fordi [`Box<T>`] implementerer `AsMut<T>`, accepterer `add_one` også argumenter af typen `&mut Box<u64>`:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Udfører konverteringen.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// En værdi-til-værdi-konvertering, der forbruger inputværdien.Det modsatte af [`From`].
///
/// Man bør undgå at implementere [`Into`] og implementere [`From`] i stedet.
/// Implementering af [`From`] giver automatisk en implementering af [`Into`] takket være implementeringen af tæpper i standardbiblioteket.
///
/// Foretrækker at bruge [`Into`] over [`From`], når du specificerer trait bounds på en generisk funktion for at sikre, at typer, der kun implementerer [`Into`], også kan bruges.
///
/// **Note: Denne trait må ikke fejle **.Hvis konverteringen kan mislykkes, skal du bruge [`TryInto`].
///
/// # Generiske implementeringer
///
/// - [`Fra`]`<T>for U` indebærer `Into<U> for T`
/// - [`Into`] er refleksiv, hvilket betyder, at `Into<T> for T` er implementeret
///
/// # Implementering af [`Into`] til konvertering til eksterne typer i gamle versioner af Rust
///
/// Før Rust 1.41, hvis destinationstypen ikke var en del af den aktuelle crate, kunne du ikke implementere [`From`] direkte.
/// Tag for eksempel denne kode:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Dette kompileres ikke i ældre versioner af sproget, fordi Rust s forældreløse regler plejede at være lidt mere strenge.
/// For at omgå dette kan du implementere [`Into`] direkte:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Det er vigtigt at forstå, at [`Into`] ikke giver en [`From`]-implementering (som [`From`] gør med [`Into`]).
/// Derfor bør du altid prøve at implementere [`From`] og derefter falde tilbage til [`Into`], hvis [`From`] ikke kan implementeres.
///
/// # Examples
///
/// [`String`] implementerer [`Into`]`<`[`Vec`] `<` [`u8`]`>>`:
///
/// For at udtrykke, at vi ønsker, at en generisk funktion skal tage alle argumenter, der kan konverteres til en bestemt type `T`, kan vi bruge en trait bound af [`Into`]`<T>`.
///
/// For eksempel: Funktionen `is_hello` tager alle argumenter, der kan konverteres til en [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Udfører konverteringen.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Bruges til at foretage værdi-til-værdi-konverteringer, mens du indtager inputværdien.Det er det gensidige ved [`Into`].
///
/// Man bør altid foretrække at implementere `From` frem for [`Into`], fordi implementering af `From` automatisk giver en implementering af [`Into`] takket være implementeringen af tæppet i standardbiblioteket.
///
///
/// Implementer kun [`Into`], når du målretter mod en version før Rust 1.41 og konverterer til en type uden for den nuværende crate.
/// `From` var ikke i stand til at udføre denne type konverteringer i tidligere versioner på grund af Rust s forældreløse regler.
/// Se [`Into`] for flere detaljer.
///
/// Foretrækker at bruge [`Into`] frem for at bruge `From`, når du angiver trait bounds på en generisk funktion.
/// På denne måde kan typer, der direkte implementerer [`Into`], også bruges som argumenter.
///
/// `From` er også meget nyttig, når du udfører fejlhåndtering.Når der konstrueres en funktion, der er i stand til at mislykkes, vil returtypen generelt have form `Result<T, E>`.
/// `From` trait forenkler fejlhåndtering ved at lade en funktion returnere en enkelt fejltype, der indkapsler flere fejltyper.Se "Examples"-sektionen og [the book][book] for flere detaljer.
///
/// **Note: Denne trait må ikke fejle **.Hvis konverteringen kan mislykkes, skal du bruge [`TryFrom`].
///
/// # Generiske implementeringer
///
/// - `From<T> for U` indebærer [`Into`]`<U>for T`</u>
/// - `From` er refleksiv, hvilket betyder, at `From<T> for T` er implementeret
///
/// # Examples
///
/// [`String`] implementerer `From<&str>`:
///
/// En eksplicit konvertering fra en `&str` til en streng udføres som følger:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Mens du udfører fejlhåndtering, er det ofte nyttigt at implementere `From` til din egen fejltype.
/// Ved at konvertere underliggende fejltyper til vores egen brugerdefinerede fejltype, der indkapsler den underliggende fejltype, kan vi returnere en enkelt fejltype uden at miste information om den underliggende årsag.
/// '?'-operatøren konverterer automatisk den underliggende fejltype til vores brugerdefinerede fejltype ved at ringe til `Into<CliError>::into`, som automatisk leveres, når `From` implementeres.
/// Compileren udleder derefter, hvilken implementering af `Into` der skal bruges.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Udfører konverteringen.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Et forsøg på konvertering, der bruger `self`, hvilket måske eller måske ikke er dyrt.
///
/// Biblioteksforfattere bør normalt ikke implementere denne trait direkte, men foretrækker at implementere [`TryFrom`] trait, som giver større fleksibilitet og giver en ækvivalent `TryInto`-implementering gratis takket være en tæppeimplementering i standardbiblioteket.
/// For yderligere oplysninger om dette, se dokumentationen til [`Into`].
///
/// # Implementering af `TryInto`
///
/// Dette har de samme begrænsninger og ræsonnement som implementering af [`Into`], se der for detaljer.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Den type, der returneres i tilfælde af en konverteringsfejl.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Udfører konverteringen.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Enkel og sikker type konvertering, der under nogle omstændigheder kan mislykkes på en kontrolleret måde.Det er det gensidige ved [`TryInto`].
///
/// Dette er nyttigt, når du laver en typekonvertering, der trivielt kan lykkes, men som muligvis også har brug for særlig håndtering.
/// For eksempel er der ingen måde at konvertere en [`i64`] til en [`i32`] ved hjælp af [`From`] trait, fordi en [`i64`] kan indeholde en værdi, som en [`i32`] ikke kan repræsentere, og konvertering mister derfor data.
///
/// Dette kan håndteres ved at trunke [`i64`] til en [`i32`] (i det væsentlige give [`i64`] s værdi modulo [`i32::MAX`]) eller ved blot at returnere [`i32::MAX`] eller ved hjælp af en anden metode.
/// [`From`] trait er beregnet til perfekte konverteringer, så `TryFrom` trait informerer programmøren, når en typekonvertering kan gå dårligt, og lader dem beslutte, hvordan de skal håndtere den.
///
/// # Generiske implementeringer
///
/// - `TryFrom<T> for U` indebærer [`TryInto`]`<U>for T`</u>
/// - [`try_from`] er refleksiv, hvilket betyder, at `TryFrom<T> for T` implementeres og ikke kan fejle-den tilknyttede `Error`-type til opkald til `T::try_from()` på en værdi af typen `T` er [`Infallible`].
/// Når [`!`]-typen er stabiliseret, vil [`Infallible`] og [`!`] være ækvivalente.
///
/// `TryFrom<T>` kan implementeres som følger:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Som beskrevet implementerer [`i32`] `TryFrom <` [`i64`]`>`:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Trunkerer `big_number` stille, kræver detektering og håndtering af trunkeringen.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Returnerer en fejl, fordi `big_number` er for stor til at passe i en `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Returnerer `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Den type, der returneres i tilfælde af en konverteringsfejl.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Udfører konverteringen.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// GENERISKE IMPLS
////////////////////////////////////////////////////////////////////////////////

// Som løfter over&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Som elevatorer over &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): udskift ovenstående impls for&/&mut med følgende mere generelle:
// // Som løfter over Deref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U:? Sized> AsRef <U>for D {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut løfter over &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): udskift ovenstående impl for &mut med følgende mere generelle:
// // AsMut løfter over DerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Størrelse> AsMut <U>til D {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Fra antyder Into
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Fra (og dermed ind i) er refleksiv
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Stabilitetsnote:** Dette impl findes endnu ikke, men vi er "reserving space" til at tilføje det i future.
/// Se [rust-lang/rust#64715][#64715] for detaljer.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): lav en principiel løsning i stedet.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom indebærer TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Ufaldbare konverteringer svarer semantisk til fejlbare konverteringer med en ubeboet fejltype.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// BETON IMPLS
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// INGEN FEJL FEJLTYPE
////////////////////////////////////////////////////////////////////////////////

/// Fejltypen for fejl, der aldrig kan ske.
///
/// Da dette enum ikke har nogen variant, kan en værdi af denne type faktisk aldrig eksistere.
/// Dette kan være nyttigt for generiske API'er, der bruger [`Result`] og parametrerer fejltypen for at indikere, at resultatet altid er [`Ok`].
///
/// For eksempel har [`TryFrom`] trait (konvertering, der returnerer en [`Result`]) en tæppeimplementering til alle typer, hvor der findes en omvendt [`Into`]-implementering.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future kompatibilitet
///
/// Dette enum har samme rolle som [the `!`“never”type][never], som er ustabil i denne version af Rust.
/// Når `!` er stabiliseret, planlægger vi at gøre `Infallible` til et typealias for det:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// ... og til sidst forældede `Infallible`.
///
/// Der er dog et tilfælde, hvor `!`-syntaks kan bruges, før `!` stabiliseres som en fuldgyldig type: i positionen for en funktions returtype.
/// Specifikt er det mulige implementeringer for to forskellige funktionspekertyper:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Da `Infallible` er enum, er denne kode gyldig.
/// Når `Infallible` imidlertid bliver et alias for never type, begynder de to `impl`s at overlappe hinanden og vil derfor ikke blive tilladt af sprogets trait-kohærensregler.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}