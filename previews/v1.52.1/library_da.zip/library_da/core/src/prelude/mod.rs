//! Libcore prelude
//!
//! Dette modul er beregnet til brugere af libcore, der ikke også linker til libstd.
//! Dette modul importeres som standard, når `#![no_std]` bruges på samme måde som standardbibliotekets prelude.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// 2015-versionen af kernen prelude.
///
/// Se [module-level documentation](self) for mere.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// 2018-versionen af kernen prelude.
///
/// Se [module-level documentation](self) for mere.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// 2021-versionen af kernen prelude.
///
/// Se [module-level documentation](self) for mere.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Tilføj flere ting.
}