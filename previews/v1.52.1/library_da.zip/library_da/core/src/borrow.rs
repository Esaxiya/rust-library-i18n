//! Et modul til arbejde med lånte data.

#![stable(feature = "rust1", since = "1.0.0")]

/// En trait til låneoplysninger.
///
/// I Rust er det almindeligt at give forskellige repræsentationer af en type til forskellige brugssager.
/// For eksempel kan lagringsplacering og-styring for en værdi specifikt vælges efter behov til en bestemt anvendelse via markørtyper såsom [`Box<T>`] eller [`Rc<T>`].
/// Ud over disse generiske indpakninger, der kan bruges med alle typer, giver nogle typer valgfri facetter, der giver potentielt dyre funktioner.
/// Et eksempel på en sådan type er [`String`], som tilføjer muligheden for at udvide en streng til den grundlæggende [`str`].
/// Dette kræver, at ekstra information holdes unødvendig for en simpel, uforanderlig streng.
///
/// Disse typer giver adgang til de underliggende data gennem henvisninger til typen af disse data.De siges at være 'lånt som' den type.
/// For eksempel kan en [`Box<T>`] lånes som `T`, mens en [`String`] kan lånes som `str`.
///
/// Typer udtrykker, at de kan lånes som en type `T` ved at implementere `Borrow<T>`, der giver en reference til en `T` i trait s [`borrow`]-metode.En type er gratis at låne som flere forskellige typer.
/// Hvis det ønsker mutabelt at låne som typen-så de underliggende data kan ændres, kan det desuden implementere [`BorrowMut<T>`].
///
/// Når der ydes implementeringer til yderligere traits, skal det overvejes, om de skal opføre sig identiske med dem af den underliggende type som en konsekvens af at fungere som en repræsentation af den underliggende type.
/// Generisk kode bruger typisk `Borrow<T>`, når den er afhængig af den samme opførsel af disse yderligere trait-implementeringer.
/// Disse traits vises sandsynligvis som yderligere trait bounds.
///
/// Især `Eq`, `Ord` og `Hash` skal være ækvivalente for lånte og ejede værdier: `x.borrow() == y.borrow()` skal give det samme resultat som `x == y`.
///
/// Hvis generisk kode blot skal fungere for alle typer, der kan give en reference til relateret type `T`, er det ofte bedre at bruge [`AsRef<T>`], da flere typer sikkert kan implementere den.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Som en dataindsamling ejer [`HashMap<K, V>`] både nøgler og værdier.Hvis nøglens faktiske data er pakket ind i en styringstype af en eller anden art, bør det dog stadig være muligt at søge efter en værdi ved hjælp af en henvisning til nøgledataene.
/// For eksempel, hvis nøglen er en streng, gemmes den sandsynligvis med hash-kortet som en [`String`], mens det skulle være muligt at søge ved hjælp af en [`&str`][`str`].
/// Således skal `insert` fungere på en `String`, mens `get` skal kunne bruge en `&str`.
///
/// Lidt forenklet ser de relevante dele af `HashMap<K, V>` sådan ud:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // felter udeladt
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Hele hash-kortet er generisk over en nøgletype `K`.Da disse nøgler er gemt med hash-kortet, skal denne type eje nøglens data.
/// Når du indsætter et nøgleværdipar, får kortet en sådan `K` og skal finde den korrekte hash-skovl og kontrollere, om nøglen allerede er til stede baseret på den `K`.Det kræver derfor `K: Hash + Eq`.
///
/// Når du søger efter en værdi på kortet, skal det dog altid være nødvendigt at oprette en sådan ejet værdi, hvis du skal give en reference til en `K` som nøglen til at søge efter.
/// For strengnøgler vil det betyde, at der skal oprettes en `String`-værdi kun til søgning efter tilfælde, hvor kun en `str` er tilgængelig.
///
/// I stedet er `get`-metoden generisk over typen af de underliggende nøgledata, kaldet `Q` i metodesignaturen ovenfor.Det hedder, at `K` låner som en `Q` ved at kræve, at `K: Borrow<Q>`.
/// Ved yderligere at kræve `Q: Hash + Eq` signalerer det kravet om, at `K` og `Q` har implementeringer af `Hash` og `Eq` traits, der giver identiske resultater.
///
/// Implementeringen af `get` er især afhængig af identiske implementeringer af `Hash` ved at bestemme nøglens hash-skovl ved at kalde `Hash::hash` på `Q`-værdien, selvom den indsatte nøglen baseret på hashværdien beregnet ud fra `K`-værdien.
///
///
/// Som en konsekvens bryder hash-kortet, hvis en `K`, der indpakker en `Q`-værdi, producerer en anden hash end `Q`.Forestil dig for eksempel, at du har en type, der ombryder en streng, men sammenligner ASCII-bogstaver, der ignorerer deres sag:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Da to lige værdier skal producere den samme hash-værdi, skal implementeringen af `Hash` også ignorere ASCII-sagen:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Kan `CaseInsensitiveString` implementere `Borrow<str>`?Det kan bestemt give en reference til en strengskive via dens indeholdte ejede streng.
/// Men fordi dens `Hash`-implementering adskiller sig, opfører den sig anderledes end `str` og må derfor faktisk ikke implementere `Borrow<str>`.
/// Hvis den ønsker at give andre adgang til den underliggende `str`, kan den gøre det via `AsRef<str>`, som ikke har nogen ekstra krav.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Uformelt låner fra en ejet værdi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// En trait til gensidig låntagning af data.
///
/// Som ledsager til [`Borrow<T>`] tillader denne trait en type at låne som en underliggende type ved at give en ændret reference.
/// Se [`Borrow<T>`] for at få flere oplysninger om låntagning som en anden type.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Mutant låner fra en ejet værdi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}