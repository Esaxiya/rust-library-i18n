#![allow(missing_docs)]
#![unstable(feature = "raw", issue = "27751")]

//! Indeholder strukturdefinitioner til layoutet af compiler indbyggede typer.
//!
//! De kan bruges som mål for transmuterer i usikker kode til direkte manipulation af de rå repræsentationer.
//!
//!
//! Deres definition skal altid matche ABI defineret i `rustc_middle::ty::layout`.
//!

/// Repræsentationen af et trait-objekt som `&dyn SomeTrait`.
///
/// Denne struktur har samme layout som typer som `&dyn SomeTrait` og `Box<dyn AnotherTrait>`.
///
/// `TraitObject` er garanteret at matche layout, men det er ikke typen af trait-objekter (f.eks. er felterne ikke direkte tilgængelige på en `&dyn SomeTrait`), og det styrer heller ikke dette layout (ændring af definitionen ændrer ikke layoutet på en `&dyn SomeTrait`).
///
/// Det er kun designet til at blive brugt af usikker kode, der skal manipulere detaljerne på lavt niveau.
///
/// Der er ingen måde at henvise til alle trait-objekter generisk, så den eneste måde at skabe værdier af denne type er med funktioner som [`std::mem::transmute`][transmute].
/// På samme måde er den eneste måde at oprette et ægte trait-objekt ud fra en `TraitObject`-værdi med `transmute`.
///
/// [transmute]: crate::intrinsics::transmute
///
/// Syntese af et trait-objekt med uoverensstemmende typer-en, hvor vtabellen ikke svarer til typen af den værdi, som datapekeren peger på-vil sandsynligvis føre til udefineret adfærd.
///
/// # Examples
///
/// ```
/// #![feature(raw)]
///
/// use std::{mem, raw};
///
/// // et eksempel trait
/// trait Foo {
///     fn bar(&self) -> i32;
/// }
///
/// impl Foo for i32 {
///     fn bar(&self) -> i32 {
///          *self + 1
///     }
/// }
///
/// let value: i32 = 123;
///
/// // lad kompilatoren oprette et trait-objekt
/// let object: &dyn Foo = &value;
///
/// // se på den rå repræsentation
/// let raw_object: raw::TraitObject = unsafe { mem::transmute(object) };
///
/// // datapekeren er adressen på `value`
/// assert_eq!(raw_object.data as *const i32, &value as *const _);
///
/// let other_value: i32 = 456;
///
/// // konstruer et nyt objekt, der peger på en anden `i32`, og pas på at bruge `i32` vtabellen fra `object`
/////
/// let synthesized: &dyn Foo = unsafe {
///      mem::transmute(raw::TraitObject {
///          data: &other_value as *const _ as *mut (),
///          vtable: raw_object.vtable,
///      })
/// };
///
/// // det skulle fungere, som om vi havde konstrueret et trait-objekt direkte ud af `other_value`
/////
/// assert_eq!(synthesized.bar(), 457);
/// ```
///
///
///
///
///
///
///
///
///
#[repr(C)]
#[derive(Copy, Clone)]
#[allow(missing_debug_implementations)]
pub struct TraitObject {
    pub data: *mut (),
    pub vtable: *mut (),
}