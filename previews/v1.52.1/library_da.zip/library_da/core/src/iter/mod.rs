//! Komponerbar ekstern iteration.
//!
//! Hvis du har fundet dig selv med en samling af en slags og har brug for at udføre en operation på elementerne i den nævnte samling, løber du hurtigt ind i 'iterators'.
//! Iteratorer bruges stærkt i idiomatisk Rust-kode, så det er værd at blive fortrolig med dem.
//!
//! Før vi forklarer mere, lad os tale om, hvordan dette modul er struktureret:
//!
//! # Organization
//!
//! Dette modul er stort set organiseret efter type:
//!
//! * [Traits] er kernedelen: disse traits definerer, hvilken type iteratorer der findes, og hvad du kan gøre med dem.Metoderne i disse traits er værd at lægge lidt ekstra studietid på.
//! * [Functions] give nogle nyttige måder at oprette nogle grundlæggende iteratorer på.
//! * [Structs] er ofte returtyperne for de forskellige metoder på dette moduls traits.Du vil normalt se på metoden, der opretter `struct`, snarere end selve `struct`.
//! For flere detaljer om hvorfor, se '[Implementering Iterator](#implementerings-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Det er det!Lad os grave i iteratorer.
//!
//! # Iterator
//!
//! Hjertet og sjælen i dette modul er [`Iterator`] trait.Kernen i [`Iterator`] ser sådan ud:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! En iterator har en metode, [`next`], som, når den kaldes, returnerer en [`Option`]`<Item>`.
//! [`next`] returnerer [`Some(Item)`], så længe der er elementer, og når de alle er opbrugt, returnerer `None` for at indikere, at iteration er afsluttet.
//! Individuelle iteratorer kan vælge at genoptage iteration, og så kan man ringe til [`next`] igen måske eller måske ikke i sidste ende begynde at returnere [`Some(Item)`] igen på et eller andet tidspunkt (se f.eks. [`TryIter`]).
//!
//!
//! ['Iterator`]' s fulde definition inkluderer også en række andre metoder, men de er standardmetoder, bygget oven på [`next`], og så får du dem gratis.
//!
//! Iteratorer kan også komponeres, og det er almindeligt at kæde dem sammen for at gøre mere komplekse former for behandling.Se [Adapters](#adapters)-afsnittet nedenfor for flere detaljer.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # De tre former for iteration
//!
//! Der er tre almindelige metoder, der kan oprette iteratorer fra en samling:
//!
//! * `iter()`, som gentages over `&T`.
//! * `iter_mut()`, som gentages over `&mut T`.
//! * `into_iter()`, som gentages over `T`.
//!
//! Forskellige ting i standardbiblioteket kan implementere en eller flere af de tre, hvor det er relevant.
//!
//! # Implementering af Iterator
//!
//! Oprettelse af en egen iterator involverer to trin: at oprette en `struct` for at holde iteratorens tilstand og derefter implementere [`Iterator`] til den `struct`.
//! Dette er grunden til, at der er så mange `struct`s i dette modul: der er en til hver iterator og iteratoradapter.
//!
//! Lad os lave en iterator ved navn `Counter`, som tæller fra `1` til `5`:
//!
//! ```
//! // For det første strukturen:
//!
//! /// En iterator, der tæller fra en til fem
//! struct Counter {
//!     count: usize,
//! }
//!
//! // vi ønsker, at vores optælling starter ved en, så lad os tilføje en new()-metode til at hjælpe.
//! // Dette er ikke strengt nødvendigt, men er praktisk.
//! // Bemærk, at vi starter `count` på nul, vi ser hvorfor i `next()`'s implementering nedenfor.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Derefter implementerer vi `Iterator` til vores `Counter`:
//!
//! impl Iterator for Counter {
//!     // vi tæller med usize
//!     type Item = usize;
//!
//!     // next() er den eneste nødvendige metode
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Forøg vores antal.Derfor startede vi på nul.
//!         self.count += 1;
//!
//!         // Kontroller, om vi er færdige med at tælle eller ej.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Og nu kan vi bruge det!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! At kalde [`next`] på denne måde bliver gentagne gange.Rust har en konstruktion, der kan kalde [`next`] på din iterator, indtil den når `None`.Lad os gå over det næste.
//!
//! Bemærk også, at `Iterator` giver en standardimplementering af metoder som `nth` og `fold`, der kalder `next` internt.
//! Det er dog også muligt at skrive en brugerdefineret implementering af metoder som `nth` og `fold`, hvis en iterator kan beregne dem mere effektivt uden at ringe til `next`.
//!
//! # `for` sløjfer og `IntoIterator`
//!
//! Rust s `for`-sløjfesyntaks er faktisk sukker for iteratorer.Her er et grundlæggende eksempel på `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Dette vil udskrive tallene et til fem, hver på deres egen linje.Men du vil bemærke noget her: vi kaldte aldrig noget på vores vector for at producere en iterator.Hvad giver?
//!
//! Der er en trait i standardbiblioteket til konvertering af noget til en iterator: [`IntoIterator`].
//! Denne trait har en metode, [`into_iter`], der konverterer den ting, der implementerer [`IntoIterator`] til en iterator.
//! Lad os se på den `for`-løkke igen, og hvad compileren konverterer den til:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust de-sukker dette til:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Først kalder vi `into_iter()` på værdien.Derefter matcher vi på iteratoren, der vender tilbage, og ringer til [`next`] igen og igen, indtil vi ser en `None`.
//! På det tidspunkt `break` vi ud af sløjfen, og vi er færdige med iterering.
//!
//! Der er endnu en subtil bit her: Standardbiblioteket indeholder en interessant implementering af [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Med andre ord implementerer alle [`Iterator`s [`IntoIterator`] ved bare at returnere sig selv.Dette betyder to ting:
//!
//! 1. Hvis du skriver en [`Iterator`], kan du bruge den med en `for`-løkke.
//! 2. Hvis du opretter en samling, vil implementering af [`IntoIterator`] til den tillade, at din samling bruges med `for`-løkken.
//!
//! # Iterering ved henvisning
//!
//! Da [`into_iter()`] tager `self` efter værdi, forbruges samlingen ved hjælp af en `for`-løkke til at gentage over en samling.Ofte vil du måske gentage en samling uden at forbruge den.
//! Mange samlinger tilbyder metoder, der giver iteratorer i forhold til referencer, konventionelt kaldet henholdsvis `iter()` og `iter_mut()`:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` ejes stadig af denne funktion.
//! ```
//!
//! Hvis en samlingstype `C` leverer `iter()`, implementerer den normalt også `IntoIterator` til `&C` med en implementering, der bare kalder `iter()`.
//! Ligeledes implementerer en samling `C`, der leverer `iter_mut()`, generelt `IntoIterator` til `&mut C` ved at delegere til `iter_mut()`.Dette muliggør en bekvem stenografi:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // samme som `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // samme som `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Mens mange samlinger tilbyder `iter()`, tilbyder ikke alle `iter_mut()`.
//! For eksempel kan mutering af nøglerne til en [`HashSet<T>`] eller [`HashMap<K, V>`] sætte samlingen i en inkonsekvent tilstand, hvis nøglehashen ændres, så disse samlinger tilbyder kun `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Funktioner, der tager en [`Iterator`] og returnerer en anden [`Iterator`], kaldes ofte 'iterator-adaptere', da de er en form for 'adapteren
//! pattern'.
//!
//! Almindelige iterator-adaptere inkluderer [`map`], [`take`] og [`filter`].
//! For mere, se deres dokumentation.
//!
//! Hvis en iteratoradapter panics, er iteratoren i en uspecificeret (men hukommelsessikker) tilstand.
//! Denne tilstand garanteres heller ikke at være den samme på tværs af versioner af Rust, så du bør undgå at stole på de nøjagtige værdier, der returneres af en iterator, der fik panik.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! Iteratorer (og iterator [adapters](#adapters)) er *dovne*. Det betyder, at bare at oprette en iterator ikke _do_ meget. Der sker ikke noget, før du ringer til [`next`].
//! Dette er undertiden en kilde til forvirring, når man opretter en iterator udelukkende for dets bivirkninger.
//! For eksempel kalder [`map`]-metoden en lukning af hvert element, den gentager sig over:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Dette udskriver ingen værdier, da vi kun oprettede en iterator i stedet for at bruge den.Compileren vil advare os om denne form for adfærd:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Den idiomatiske måde at skrive en [`map`] på for dens bivirkninger er at bruge en `for`-loop eller kalde [`for_each`]-metoden:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! En anden almindelig måde at evaluere en iterator på er at bruge [`collect`]-metoden til at producere en ny samling.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! Iteratorer behøver ikke være endelige.Som et eksempel er et åbent interval en uendelig iterator:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Det er almindeligt at bruge [`take`] iteratoradapteren til at gøre en uendelig iterator til en endelig:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Dette udskriver tallene `0` til `4`, hver på deres egen linje.
//!
//! Husk, at metoder på uendelige iteratorer, selv dem, for hvilke et resultat kan bestemmes matematisk på endelig tid, muligvis ikke afsluttes.
//! Specifikt vil metoder som [`min`], som generelt kræver passage af hvert element i iteratoren, sandsynligvis ikke vende tilbage med succes for uendelige iteratorer.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Åh nej!En uendelig løkke!
//! // `ones.min()` forårsager en uendelig løkke, så vi når ikke dette punkt!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;