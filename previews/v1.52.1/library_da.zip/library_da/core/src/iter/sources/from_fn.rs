use crate::fmt;

/// Opretter en ny iterator, hvor hver iteration kalder den medfølgende lukning `F: FnMut() -> Option<T>`.
///
/// Dette gør det muligt at oprette en brugerdefineret iterator med enhver opførsel uden at bruge den mere detaljerede syntaks til at oprette en dedikeret type og implementere [`Iterator`] trait til den.
///
/// Bemærk, at `FromFn`-iteratoren ikke antager antagelser om lukningens opførsel og derfor konservativt ikke implementerer [`FusedIterator`] eller tilsidesætter [`Iterator::size_hint()`] fra dens standard `(0, None)`.
///
///
/// Lukningen kan bruge optagelser og dets miljø til at spore tilstand på tværs af iterationer.Afhængigt af hvordan iteratoren bruges, kan dette kræve, at du angiver [`move`]-nøgleordet på lukningen.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Lad os genimplementere counter iteratoren fra [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Forøg vores antal.Derfor startede vi på nul.
///     count += 1;
///
///     // Kontroller, om vi er færdige med at tælle eller ej.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// En iterator, hvor hver iteration kalder den medfølgende lukning `F: FnMut() -> Option<T>`.
///
/// Denne `struct` er oprettet af [`iter::from_fn()`]-funktionen.
/// Se dokumentationen for mere.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}