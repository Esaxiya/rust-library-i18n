use crate::iter::{FusedIterator, TrustedLen};

/// Opretter en ny iterator, der uendeligt gentager et enkelt element.
///
/// `repeat()`-funktionen gentager en enkelt værdi igen og igen.
///
/// Uendelige iteratorer som `repeat()` bruges ofte med adaptere som [`Iterator::take()`] for at gøre dem endelige.
///
/// Hvis elementtypen af iteratoren, du har brug for, ikke implementerer `Clone`, eller hvis du ikke vil beholde det gentagne element i hukommelsen, kan du i stedet bruge [`repeat_with()`]-funktionen.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Grundlæggende brug:
///
/// ```
/// use std::iter;
///
/// // nummer fire 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // ja, stadig fire
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Går endelig med [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // det sidste eksempel var for mange firere.Lad os kun have fire firere.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... og nu er vi færdige
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// En iterator, der gentager et element uendeligt.
///
/// Denne `struct` er oprettet af [`repeat()`]-funktionen.Se dokumentationen for mere.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}