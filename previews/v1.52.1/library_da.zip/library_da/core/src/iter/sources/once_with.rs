use crate::iter::{FusedIterator, TrustedLen};

/// Opretter en iterator, der dovent genererer en værdi nøjagtigt én gang ved at påkalde den medfølgende lukning.
///
/// Dette bruges ofte til at tilpasse en enkeltværdegenerator til en [`chain()`] af andre slags iteration.
/// Måske har du en iterator, der dækker næsten alt, men du har brug for en ekstra speciel sag.
/// Måske har du en funktion, der fungerer på iteratorer, men du behøver kun at behandle en værdi.
///
/// I modsætning til [`once()`], genererer denne funktion dovent værdien efter anmodning.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Grundlæggende brug:
///
/// ```
/// use std::iter;
///
/// // den ene er det ensomste tal
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // bare en, det er alt, hvad vi får
/// assert_eq!(None, one.next());
/// ```
///
/// Kæde sammen med en anden iterator.
/// Lad os sige, at vi vil gentage hver fil i `.foo`-biblioteket, men også en konfigurationsfil,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // vi er nødt til at konvertere fra en iterator af DirEntry-s til en iterator af PathBufs, så vi bruger kort
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // nu, vores iterator kun til vores konfigurationsfil
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // kæde de to iteratorer sammen til en stor iterator
/// let files = dirs.chain(config);
///
/// // dette vil give os alle filerne i .foo såvel som .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// En iterator, der giver et enkelt element af typen `A` ved at anvende den medfølgende lukning `F: FnOnce() -> A`.
///
///
/// Denne `struct` er oprettet af [`once_with()`]-funktionen.
/// Se dokumentationen for mere.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}