/// Konvertering fra en [`Iterator`].
///
/// Ved at implementere `FromIterator` for en type definerer du, hvordan den oprettes fra en iterator.
/// Dette er almindeligt for typer, der beskriver en samling af en slags.
///
/// [`FromIterator::from_iter()`] kaldes sjældent eksplicit og bruges i stedet via [`Iterator::collect()`]-metoden.
///
/// Se [`Iterator::collect()`]'s dokumentation for flere eksempler.
///
/// Se også: [`IntoIterator`].
///
/// # Examples
///
/// Grundlæggende brug:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Brug af [`Iterator::collect()`] til implicit brug af `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Implementering af `FromIterator` til din type:
///
/// ```
/// use std::iter::FromIterator;
///
/// // En prøveindsamling, det er bare en indpakning over Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Lad os give det nogle metoder, så vi kan oprette en og tilføje ting til den.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // og vi implementerer FromIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Nu kan vi lave en ny iterator ...
/// let iter = (0..5).into_iter();
///
/// // ... og lav en MyCollection ud af det
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // indsamle værker også!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Opretter en værdi ud fra en iterator.
    ///
    /// Se [module-level documentation] for mere.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Konvertering til en [`Iterator`].
///
/// Ved at implementere `IntoIterator` for en type definerer du, hvordan den konverteres til en iterator.
/// Dette er almindeligt for typer, der beskriver en samling af en slags.
///
/// En fordel ved at implementere `IntoIterator` er, at din type vil [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Se også: [`FromIterator`].
///
/// # Examples
///
/// Grundlæggende brug:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Implementering af `IntoIterator` til din type:
///
/// ```
/// // En prøveindsamling, det er bare en indpakning over Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Lad os give det nogle metoder, så vi kan oprette en og tilføje ting til den.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // og vi implementerer IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Nu kan vi lave en ny samling ...
/// let mut c = MyCollection::new();
///
/// // ... tilføj nogle ting til det ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... og gør det derefter til en Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Det er almindeligt at bruge `IntoIterator` som en trait bound.Dette gør det muligt at ændre inputindsamlingstypen, så længe den stadig er en iterator.
/// Yderligere grænser kan specificeres ved at begrænse til
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Typen af elementer, der gentages.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Hvilken type iterator gør vi dette til?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Opretter en iterator ud fra en værdi.
    ///
    /// Se [module-level documentation] for mere.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Udvid en samling med indholdet af en iterator.
///
/// Iteratorer producerer en række værdier, og samlinger kan også betragtes som en række værdier.
/// `Extend` trait bygger bro over dette hul, så du kan udvide en samling ved at inkludere indholdet af denne iterator.
/// Når en samling udvides med en allerede eksisterende nøgle, opdateres denne post, eller i tilfælde af samlinger, der tillader flere poster med lige nøgler, indsættes denne post.
///
///
/// # Examples
///
/// Grundlæggende brug:
///
/// ```
/// // Du kan udvide en streng med nogle tegn:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Implementering af `Extend`:
///
/// ```
/// // En prøveindsamling, det er bare en indpakning over Vec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Lad os give det nogle metoder, så vi kan oprette en og tilføje ting til den.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // Da MyCollection har en liste over i32, implementerer vi Extend til i32
/// impl Extend<i32> for MyCollection {
///
///     // Dette er lidt enklere med den konkrete typesignatur: vi kan kalde udvide alt hvad der kan omdannes til en Iterator, der giver os i32'er.
///     // Fordi vi har brug for i32'er til at indsætte i MyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Implementeringen er meget ligetil: løb gennem iteratoren og add() hvert element for os selv.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // lad os udvide vores samling med yderligere tre numre
/// c.extend(vec![1, 2, 3]);
///
/// // vi har tilføjet disse elementer til slutningen
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Udvider en samling med indholdet af en iterator.
    ///
    /// Da dette er den eneste nødvendige metode til denne trait, indeholder [trait-level]-dokumenterne flere detaljer.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// // Du kan udvide en streng med nogle tegn:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Udvider en samling med nøjagtigt et element.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Reserverer kapacitet i en samling til det givne antal yderligere elementer.
    ///
    /// Standardimplementeringen gør ingenting.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}