/// En iterator, der kender dens nøjagtige længde.
///
/// Mange [`Iterator`] ved ikke, hvor mange gange de vil gentage, men nogle gør det.
/// Hvis en iterator ved, hvor mange gange den kan gentage sig, kan det være nyttigt at give adgang til disse oplysninger.
/// For eksempel, hvis du vil gentage baglæns, er en god start at vide, hvor slutningen er.
///
/// Når du implementerer en `ExactSizeIterator`, skal du også implementere [`Iterator`].
/// Når du gør det, skal implementeringen af [`Iterator::size_hint`] * returnere den nøjagtige størrelse af iteratoren.
///
/// [`len`]-metoden har en standardimplementering, så du skal normalt ikke implementere den.
/// Du kan dog muligvis give en mere performant implementering end standard, så det er fornuftigt at tilsidesætte det i dette tilfælde.
///
///
/// Bemærk, at denne trait er en sikker trait og som sådan ikke *og* ikke * kan garantere, at den returnerede længde er korrekt.
/// Dette betyder, at `unsafe`-koden **ikke** må stole på rigtigheden af [`Iterator::size_hint`].
/// Den ustabile og usikre [`TrustedLen`](super::marker::TrustedLen) trait giver denne ekstra garanti.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Grundlæggende brug:
///
/// ```
/// // et endeligt interval ved nøjagtigt, hvor mange gange det vil gentage
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// I [module-level docs] implementerede vi en [`Iterator`], `Counter`.
/// Lad os også implementere `ExactSizeIterator` til det:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Vi kan let beregne det resterende antal iterationer.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Og nu kan vi bruge det!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Returnerer den nøjagtige længde på iteratoren.
    ///
    /// Implementeringen sikrer, at iteratoren returnerer nøjagtigt `len()` flere gange en [`Some(T)`]-værdi, før den returnerer [`None`].
    ///
    /// Denne metode har en standardimplementering, så du bør normalt ikke implementere den direkte.
    /// Men hvis du kan tilbyde en mere effektiv implementering, kan du gøre det.
    /// Se [trait-level]-dokumenterne for et eksempel.
    ///
    /// Denne funktion har de samme sikkerhedsgarantier som [`Iterator::size_hint`]-funktionen.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// // et endeligt interval ved nøjagtigt, hvor mange gange det vil gentage
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Denne påstand er alt for defensiv, men den kontrollerer invarianten
        // garanteret af trait.
        // Hvis denne trait var rust-intern, kunne vi bruge debug_assert !;hævder_eq!vil også kontrollere alle Rust-brugerimplementeringer.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Returnerer `true`, hvis iteratoren er tom.
    ///
    /// Denne metode har en standardimplementering ved hjælp af [`ExactSizeIterator::len()`], så du behøver ikke at implementere den selv.
    ///
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}