// ignore-tidy-filelength Denne fil består næsten udelukkende af definitionen af `Iterator`.
// Vi kan ikke opdele det i flere filer.
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// En grænseflade til håndtering af iteratorer.
///
/// Dette er den vigtigste iterator trait.
/// For mere om begrebet iteratorer generelt, se [module-level documentation].
/// Især vil du måske vide, hvordan du [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Typen af elementer, der gentages.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Fremrykker iteratoren og returnerer den næste værdi.
    ///
    /// Returnerer [`None`], når iterationen er færdig.
    /// Individuelle iteratorimplementeringer kan vælge at genoptage iterationen, og så kan det være nødvendigt at ringe til `next()` igen eller måske ikke i sidste ende begynde at returnere [`Some(Item)`] igen på et eller andet tidspunkt.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Et opkald til next() returnerer den næste værdi ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... og derefter ingen, når det er forbi.
    /// assert_eq!(None, iter.next());
    ///
    /// // Flere opkald returnerer muligvis `None`.Her vil de altid.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Returnerer grænserne for den resterende længde på iteratoren.
    ///
    /// Specifikt returnerer `size_hint()` en tuple, hvor det første element er den nedre grænse, og det andet element er den øvre grænse.
    ///
    /// Den anden halvdel af tuplen, der returneres, er en [`Option`]`<`[`usize`] `>`.
    /// En [`None`] betyder her, at der enten ikke er nogen kendt øvre grænse, eller at den øvre grænse er større end [`usize`].
    ///
    /// # Implementeringsnoter
    ///
    /// Det håndhæves ikke, at en iteratorimplementering giver det deklarerede antal elementer.En buggy iterator kan give mindre end den nedre grænse eller mere end den øvre grænse for elementer.
    ///
    /// `size_hint()` er primært beregnet til at blive brugt til optimeringer såsom at reservere plads til iteratorens elementer, men må ikke have tillid til at f.eks. udelade grænsekontrol i usikker kode.
    /// En forkert implementering af `size_hint()` bør ikke føre til overtrædelser af hukommelsessikkerheden.
    ///
    /// Når det er sagt, skal implementeringen give et korrekt skøn, fordi det ellers ville være en overtrædelse af trait's protokol.
    ///
    /// Standardimplementeringen returnerer `(0,` [`None`]`)`, som er korrekt for enhver iterator.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Et mere komplekst eksempel:
    ///
    /// ```
    /// // De lige tal fra nul til ti.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Vi kan gentage fra nul til ti gange.
    /// // At vide, at det er fem nøjagtigt, ville ikke være muligt uden at udføre filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Lad os tilføje yderligere fem numre med chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // nu øges begge grænser med fem
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Returnering af `None` for en øvre grænse:
    ///
    /// ```
    /// // en uendelig iterator har ingen øvre grænse og den maksimalt mulige nedre grænse
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Forbruger iteratoren, tæller antallet af iterationer og returnerer den.
    ///
    /// Denne metode kalder [`next`] gentagne gange, indtil [`None`] støder på, hvilket returnerer det antal gange, det så [`Some`].
    /// Bemærk, at [`next`] skal kaldes mindst en gang, selvom iteratoren ikke har nogen elementer.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Overløbsadfærd
    ///
    /// Metoden beskytter ikke mod overløb, så tælling af elementer i en iterator med mere end [`usize::MAX`]-elementer producerer enten det forkerte resultat eller panics.
    ///
    /// Hvis debug-påstande er aktiveret, garanteres en panic.
    ///
    /// # Panics
    ///
    /// Denne funktion kan muligvis panic, hvis iteratoren har mere end [`usize::MAX`]-elementer.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Forbruger iteratoren og returnerer det sidste element.
    ///
    /// Denne metode vil evaluere iteratoren, indtil den returnerer [`None`].
    /// Mens du gør det, holder det styr på det aktuelle element.
    /// Efter at [`None`] er returneret, returnerer `last()` det sidste element, den så.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Fremmer iteratoren med `n`-elementer.
    ///
    /// Denne metode springer ivrigt over `n`-elementer ved at kalde [`next`] op til `n` gange, indtil [`None`] opstår.
    ///
    /// `advance_by(n)` returnerer [`Ok(())`][Ok], hvis iteratoren fremskridt med `n`-elementer, eller [`Err(k)`][Err], hvis [`None`] er stødt på, hvor `k` er antallet af elementer, som iteratoren fremføres med, inden elementet løber tør (dvs.
    /// længden af iteratoren).
    /// Bemærk, at `k` altid er mindre end `n`.
    ///
    /// Opkald til `advance_by(0)` bruger ikke nogen elementer og returnerer altid [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // kun `&4` blev sprunget over
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Returnerer it'-elementet i iteratoren.
    ///
    /// Som de fleste indekseringsoperationer starter optællingen fra nul, så `nth(0)` returnerer den første værdi, `nth(1)` den anden osv.
    ///
    /// Bemærk, at alle foregående elementer såvel som det returnerede element forbruges fra iteratoren.
    /// Det betyder, at de foregående elementer vil blive kasseret, og at opkald til `nth(0)` flere gange på den samme iterator vil returnere forskellige elementer.
    ///
    ///
    /// `nth()` returnerer [`None`], hvis `n` er større end eller lig med iteratorens længde.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// At ringe til `nth()` flere gange spoler ikke iteratoren tilbage:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Returnerer `None`, hvis der er mindre end `n + 1`-elementer:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Opretter en iterator, der starter ved det samme punkt, men træder ved det givne beløb ved hver iteration.
    ///
    /// Bemærk 1: Det første element i iteratoren returneres altid, uanset hvilket trin der er givet.
    ///
    /// Note 2: Det tidspunkt, hvor ignorerede elementer trækkes, er ikke fast.
    /// `StepBy` opfører sig som sekvensen `next(), nth(step-1), nth(step-1),…`, men er også fri til at opføre sig som sekvensen
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Hvilken måde, der bruges, kan ændre sig for nogle iteratorer af ydeevneårsager.
    /// Den anden måde fremmer iteratoren tidligere og kan forbruge flere genstande.
    ///
    /// `advance_n_and_return_first` svarer til:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Metoden panic, hvis det givne trin er `0`.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Tager to iteratorer og opretter en ny iterator over begge i rækkefølge.
    ///
    /// `chain()` returnerer en ny iterator, som først gentager værdier fra første iterator og derefter over værdier fra anden iterator.
    ///
    /// Med andre ord forbinder den to iteratorer sammen i en kæde.🔗
    ///
    /// [`once`] bruges ofte til at tilpasse en enkelt værdi til en kæde af andre slags iteration.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Da argumentet til `chain()` bruger [`IntoIterator`], kan vi videregive alt, hvad der kan konverteres til en [`Iterator`], ikke bare en [`Iterator`] i sig selv.
    /// For eksempel kan skiver (`&[T]`) implementere [`IntoIterator`], og så kan de overføres direkte til `chain()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Hvis du arbejder med Windows API, kan du muligvis konvertere [`OsStr`] til `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Zipper op' to iteratorer til en enkelt iterator af par.
    ///
    /// `zip()` returnerer en ny iterator, der gentages over to andre iteratorer, og returnerer en tuple, hvor det første element kommer fra det første iterator, og det andet element kommer fra det andet iterator.
    ///
    ///
    /// Med andre ord, lynlåser den to iteratorer sammen til en enkelt.
    ///
    /// Hvis en af iteratoren returnerer [`None`], returnerer [`next`] fra den zippede iterator [`None`].
    /// Hvis den første iterator returnerer [`None`], kortslutter `zip`, og `next` kaldes ikke på den anden iterator.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Da argumentet til `zip()` bruger [`IntoIterator`], kan vi videregive alt, hvad der kan konverteres til en [`Iterator`], ikke bare en [`Iterator`] i sig selv.
    /// For eksempel kan skiver (`&[T]`) implementere [`IntoIterator`], og så kan de overføres direkte til `zip()`:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` bruges ofte til at zip en uendelig iterator til en endelig.
    /// Dette fungerer, fordi den endelige iterator til sidst vil returnere [`None`] og afslutte lynlåsen.Lynlås med `(0..)` kan ligne meget på [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Opretter en ny iterator, der placerer en kopi af `separator` mellem tilstødende emner i den originale iterator.
    ///
    /// Hvis `separator` ikke implementerer [`Clone`] eller skal beregnes hver gang, skal du bruge [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Det første element fra `a`.
    /// assert_eq!(a.next(), Some(&100)); // Separatoren.
    /// assert_eq!(a.next(), Some(&1));   // Det næste element fra `a`.
    /// assert_eq!(a.next(), Some(&100)); // Separatoren.
    /// assert_eq!(a.next(), Some(&2));   // Det sidste element fra `a`.
    /// assert_eq!(a.next(), None);       // Iteratoren er færdig.
    /// ```
    ///
    /// `intersperse` kan være meget nyttigt at slutte sig til en iterators emner ved hjælp af et fælles element:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Opretter en ny iterator, der placerer et element, der er genereret af `separator`, mellem tilstødende emner i den originale iterator.
    ///
    /// Lukningen kaldes nøjagtigt en gang hver gang en genstand placeres mellem to tilstødende genstande fra den underliggende iterator;
    /// specifikt kaldes lukningen ikke, hvis den underliggende iterator giver mindre end to varer, og efter at den sidste vare er givet.
    ///
    ///
    /// Hvis iteratorens genstand implementerer [`Clone`], kan det være lettere at bruge [`intersperse`].
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Det første element fra `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Separatoren.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Det næste element fra `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Separatoren.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Det sidste element fra `v`.
    /// assert_eq!(it.next(), None);               // Iteratoren er færdig.
    /// ```
    ///
    /// `intersperse_with` kan bruges i situationer, hvor separatoren skal beregnes:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Lukningen låner mutabelt sin kontekst for at generere en vare.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Gør en lukning og opretter en iterator, der kalder lukningen på hvert element.
    ///
    /// `map()` omdanner en iterator til en anden ved hjælp af dens argument:
    /// noget der implementerer [`FnMut`].Det producerer en ny iterator, der kalder denne lukning på hvert element i den originale iterator.
    ///
    /// Hvis du er god til at tænke typer, kan du tænke på `map()` sådan:
    /// Hvis du har en iterator, der giver dig elementer af en eller anden type `A`, og du vil have en iterator af en anden type `B`, kan du bruge `map()` og passere en lukning, der tager en `A` og returnerer en `B`.
    ///
    ///
    /// `map()` ligner konceptuelt en [`for`]-løkke.Da `map()` er doven, bruges den dog bedst, når du allerede arbejder med andre iteratorer.
    /// Hvis du laver en slags looping for en bivirkning, betragtes det som mere idiomatisk at bruge [`for`] end `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Hvis du laver en slags bivirkning, foretrækker du [`for`] fremfor `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // gør ikke dette:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // den vil ikke engang udføres, da den er doven.Rust vil advare dig om dette.
    ///
    /// // Brug i stedet til:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Kalder til en lukning af hvert element i en iterator.
    ///
    /// Dette svarer til at bruge en [`for`]-løkke på iteratoren, selvom `break` og `continue` ikke er mulige fra en lukning.
    /// Det er generelt mere idiomatisk at bruge en `for`-løkke, men `for_each` kan være mere læselig, når man behandler varer i slutningen af længere iteratorkæder.
    ///
    /// I nogle tilfælde kan `for_each` også være hurtigere end en loop, fordi den bruger intern iteration på adaptere som `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// For et så lille eksempel kan en `for`-løkke være renere, men `for_each` kan være at foretrække for at bevare en funktionel stil med længere iteratorer:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Opretter en iterator, der bruger en lukning til at bestemme, om et element skal leveres.
    ///
    /// Givet et element skal lukningen returnere `true` eller `false`.Den returnerede iterator giver kun de elementer, som lukningen returnerer sandt for.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Da lukningen, der sendes til `filter()`, tager en reference, og mange iteratorer gentager sig referencer, fører dette til en muligvis forvirrende situation, hvor lukningstypen er en dobbeltreference:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // har brug for to * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Det er almindeligt at i stedet bruge destrukturer på argumentet for at fjerne en:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // både og *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// eller begge:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // to &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// af disse lag.
    ///
    /// Bemærk, at `iter.filter(f).next()` svarer til `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Opretter en iterator, der både filtrerer og kort.
    ///
    /// Den returnerede iterator giver kun de 'værdier', som den medfølgende lukning returnerer `Some(value)` for.
    ///
    /// `filter_map` kan bruges til at gøre kæder af [`filter`] og [`map`] mere koncise.
    /// Eksemplet nedenfor viser, hvordan en `map().filter().map()` kan afkortes til et enkelt opkald til `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Her er det samme eksempel, men med [`filter`] og [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Opretter en iterator, der giver den aktuelle iterationstælling såvel som den næste værdi.
    ///
    /// Den returnerede iterator giver par `(i, val)`, hvor `i` er det aktuelle iterationsindeks, og `val` er den værdi, der returneres af iteratoren.
    ///
    ///
    /// `enumerate()` holder sit tal som en [`usize`].
    /// Hvis du vil tælle med et heltal i en anden størrelse, giver [`zip`]-funktionen lignende funktionalitet.
    ///
    /// # Overløbsadfærd
    ///
    /// Metoden beskytter ikke mod overløb, så optælling af mere end [`usize::MAX`]-elementer giver enten det forkerte resultat eller panics.
    /// Hvis debug-påstande er aktiveret, garanteres en panic.
    ///
    /// # Panics
    ///
    /// Den returnerede iterator kan muligvis panic, hvis indekset, der skal returneres, ville overløbe en [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Opretter en iterator, som kan bruge [`peek`] til at se på det næste element i iteratoren uden at forbruge den.
    ///
    /// Føjer en [`peek`]-metode til en iterator.Se dokumentationen for mere information.
    ///
    /// Bemærk, at den underliggende iterator stadig er avanceret, når [`peek`] kaldes for første gang: For at hente det næste element kaldes [`next`] på den underliggende iterator, derfor eventuelle bivirkninger (dvs.
    ///
    /// alt andet end at hente den næste værdi) af [`next`]-metoden vil forekomme.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() lader os se ind i future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // vi kan peek() flere gange, iteratoren går ikke videre
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // efter at iteratoren er færdig, så er peek() det også
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Opretter en iterator, der [[springer over]] elementer baseret på et prædikat.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` tager en lukning som et argument.Det kalder denne lukning på hvert element i iteratoren og ignorerer elementer, indtil den returnerer `false`.
    ///
    /// Efter at `false` er returneret, er `skip_while()`'s-job afsluttet, og resten af elementerne leveres.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Da lukningen, der sendes til `skip_while()`, tager en reference, og mange iteratorer gentager sig over referencer, fører dette til en muligvis forvirrende situation, hvor typen af lukningsargument er en dobbelt reference:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // har brug for to * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Stop efter en første `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // mens dette ville have været falsk, da vi allerede har en falsk, bruges skip_while() ikke mere
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Opretter en iterator, der giver elementer baseret på et prædikat.
    ///
    /// `take_while()` tager en lukning som et argument.Det kalder denne lukning på hvert element i iteratoren og giver elementer, mens den returnerer `true`.
    ///
    /// Efter at `false` er returneret, er `take_while()`'s-job afsluttet, og resten af elementerne ignoreres.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Da lukningen, der sendes til `take_while()`, tager en reference, og mange iteratorer gentager sig referencer, fører dette til en muligvis forvirrende situation, hvor lukningstypen er en dobbeltreference:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // har brug for to * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Stop efter en første `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Vi har flere elementer, der er mindre end nul, men da vi allerede har en falsk, bruges take_while() ikke mere
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Fordi `take_while()` skal se på værdien for at se, om den skal inkluderes eller ej, vil forbrugende iteratorer se, at den er fjernet:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` er ikke længere der, fordi den blev brugt for at se, om iterationen skulle stoppe, men ikke blev placeret tilbage i iteratoren.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Opretter en iterator, der både giver elementer baseret på et prædikat og kort.
    ///
    /// `map_while()` tager en lukning som et argument.
    /// Det kalder denne lukning på hvert element i iteratoren og giver elementer, mens den returnerer [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Her er det samme eksempel, men med [`take_while`] og [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Stop efter en første [`None`]:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Vi har flere elementer, der kunne passe ind i u32 (4, 5), men `map_while` returnerede `None` for `-3` (som `predicate` returnerede `None`) og `collect` stopper ved den første `None`, der er stødt på.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Fordi `map_while()` skal se på værdien for at se, om den skal medtages eller ej, vil forbrugende iteratorer se, at den er fjernet:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` er ikke længere der, fordi den blev brugt for at se, om iterationen skulle stoppe, men ikke blev placeret tilbage i iteratoren.
    ///
    /// Bemærk, at i modsætning til [`take_while`] er denne iterator **ikke** sammensmeltet.
    /// Det er heller ikke specificeret, hvad denne iterator returnerer, efter at den første [`None`] er returneret.
    /// Hvis du har brug for smeltet iterator, skal du bruge [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Opretter en iterator, der springer de første `n`-elementer over.
    ///
    /// Efter at de er forbrugt, får man resten af elementerne.
    /// I stedet for at tilsidesætte denne metode direkte, i stedet for at tilsidesætte `nth`-metoden.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Opretter en iterator, der giver sine første `n`-elementer.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` bruges ofte med en uendelig iterator for at gøre den endelig:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Hvis der er mindre end `n`-elementer tilgængelige, begrænser `take` sig til størrelsen på den underliggende iterator:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// En iteratoradapter svarende til [`fold`], der holder intern tilstand og producerer en ny iterator.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` tager to argumenter: en indledende værdi, der frøer den interne tilstand, og en lukning med to argumenter, den første er en ændret henvisning til den interne tilstand, og den anden et iteratorelement.
    ///
    /// Lukningen kan tildeles den interne tilstand for at dele tilstand mellem iterationer.
    ///
    /// Ved iteration vil lukningen blive anvendt på hvert element i iteratoren, og returværdien fra lukningen, en [`Option`], gives af iteratoren.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // hver iteration multiplicerer vi tilstanden med elementet
    ///     *state = *state * x;
    ///
    ///     // så giver vi negationen af staten
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Opretter en iterator, der fungerer som kort, men flader indlejret struktur.
    ///
    /// [`map`]-adapteren er meget nyttig, men kun når lukningsargumentet producerer værdier.
    /// Hvis det i stedet producerer en iterator, er der et ekstra lag af indirektion.
    /// `flat_map()` fjerner dette ekstra lag alene.
    ///
    /// Du kan tænke på `flat_map(f)` som den semantiske ækvivalent med [`map`] ping og derefter [`flade`] ing som i `map(f).flatten()`.
    ///
    /// En anden måde at tænke på `flat_map()`: ['map'] 's lukning returnerer et element for hvert element, og `flat_map()`'s lukning returnerer en iterator for hvert element.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() returnerer en iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Opretter en iterator, der flader indlejret struktur.
    ///
    /// Dette er nyttigt, når du har en iterator af iteratorer eller en iterator af ting, der kan omdannes til iteratorer, og du vil fjerne et niveau af indirektion.
    ///
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Kortlægning og derefter fladning:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() returnerer en iterator
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Du kan også omskrive dette med hensyn til [`flat_map()`], hvilket er at foretrække i dette tilfælde, da det udtrykker hensigt mere tydeligt:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() returnerer en iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Fladning fjerner kun et niveau af indlejring ad gangen:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Her ser vi, at `flatten()` ikke udfører en "deep"-fladning.
    /// I stedet fjernes kun et niveau af indlejring.Det vil sige, hvis du `flatten()` et tredimensionelt array, bliver resultatet todimensionalt og ikke endimensionelt.
    /// For at få en endimensionel struktur skal du `flatten()` igen.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Opretter en iterator, der slutter efter den første [`None`].
    ///
    /// Når en iterator returnerer [`None`], kan future-opkald muligvis ikke give [`Some(T)`] igen.
    /// `fuse()` tilpasser en iterator og sikrer, at efter at en [`None`] er givet, vil den altid returnere [`None`] for evigt.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// // en iterator, der veksler mellem noget og ingen
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // hvis det er lige, Some(i32), ellers Ingen
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // vi kan se vores iterator gå frem og tilbage
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // når vi først smelter sammen ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // det returnerer altid `None` efter første gang.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Gør noget med hvert element i en iterator, hvor værdien videreføres.
    ///
    /// Når du bruger iteratorer, kæder du ofte flere af dem sammen.
    /// Mens du arbejder på en sådan kode, vil du måske tjekke, hvad der sker på forskellige dele i rørledningen.For at gøre det skal du indsætte et opkald til `inspect()`.
    ///
    /// Det er mere almindeligt, at `inspect()` bruges som et fejlfindingsværktøj, end at det findes i din endelige kode, men applikationer kan finde det nyttigt i visse situationer, når fejl skal logges, før de kasseres.
    ///
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // denne iteratorsekvens er kompleks.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // lad os tilføje nogle inspect()-opkald for at undersøge, hvad der sker
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Dette vil udskrive:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Logfejl inden kassering:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Dette vil udskrive:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Låner en iterator i stedet for at forbruge den.
    ///
    /// Dette er nyttigt for at tillade anvendelse af iterator-adaptere, mens du stadig bevarer ejerskabet af den originale iterator.
    ///
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // hvis vi prøver at bruge iter igen, fungerer det ikke.
    /// // Følgende linje giver "fejl: brug af flyttet værdi: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // lad os prøve det igen
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // i stedet tilføjer vi en .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // nu er det bare fint:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Omdanner en iterator til en samling.
    ///
    /// `collect()` kan tage alt iterable og gøre det til en relevant samling.
    /// Dette er en af de mere kraftfulde metoder i standardbiblioteket, der bruges i en række forskellige sammenhænge.
    ///
    /// Det mest basale mønster, hvor `collect()` bruges, er at gøre en samling til en anden.
    /// Du tager en samling, kalder [`iter`] på den, laver en masse transformationer og derefter `collect()` i slutningen.
    ///
    /// `collect()` kan også oprette forekomster af typer, der ikke er typiske samlinger.
    /// For eksempel kan en [`String`] bygges fra [`char`] s, og en iterator af [`Result<T, E>`][`Result`]-genstande kan samles i `Result<Collection<T>, E>`.
    ///
    /// Se eksemplerne nedenfor for mere.
    ///
    /// Fordi `collect()` er så generel, kan det forårsage problemer med typeforståelse.
    /// Som sådan er `collect()` en af de få gange, du ser syntaksen, der er kærligt kendt som 'turbofish': `::<>`.
    /// Dette hjælper slutningsalgoritmen med at forstå specifikt, hvilken samling du prøver at indsamle i.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Bemærk, at vi havde brug for `: Vec<i32>` på venstre side.Dette skyldes, at vi i stedet for eksempel kunne indsamle en [`VecDeque<T>`]:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Brug af 'turbofish' i stedet for at kommentere `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Fordi `collect()` kun bekymrer sig om det, du samler ind i, kan du stadig bruge et tip af delvis type, `_`, med turbofisken:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Brug af `collect()` til at lave en [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Hvis du har en liste over [`Resultat<T, E>`][`Resultat`] s, du kan bruge `collect()` til at se, om nogen af dem mislykkedes:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // giver os den første fejl
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // giver os listen over svar
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Forbruger en iterator og opretter to samlinger ud fra den.
    ///
    /// Prædikatet, der sendes til `partition()`, kan returnere `true` eller `false`.
    /// `partition()` returnerer et par, alle elementerne, som det returnerede `true` for, og alle elementerne, som det returnerede `false` for.
    ///
    ///
    /// Se også [`is_partitioned()`] og [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Omarrangerer elementerne i denne iterator *på plads* i henhold til det givne prædikat, således at alle dem, der returnerer `true`, går foran alle dem, der returnerer `false`.
    ///
    /// Returnerer antallet af fundne `true`-elementer.
    ///
    /// Den relative rækkefølge af partitionerede genstande opretholdes ikke.
    ///
    /// Se også [`is_partitioned()`] og [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Opdeling på plads mellem jævnheder og odds
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: skal vi bekymre os om, at antallet løber over?Den eneste måde at have mere end
        // `usize::MAX` mutable referencer er med ZST'er, som ikke er nyttige til partitionering ...

        // Disse lukning "factory"-funktioner findes for at undgå genericitet i `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Find gentagne gange den første `false`, og skift den med den sidste `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Kontrollerer, om elementerne i denne iterator er opdelt i henhold til det givne prædikat, således at alle dem, der returnerer `true`, går foran alle dem, der returnerer `false`.
    ///
    ///
    /// Se også [`partition()`] og [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Enten tester alle emner `true`, eller den første paragraf stopper ved `false`, og vi kontrollerer, at der ikke er flere `true`-emner efter det.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// En iteratormetode, der anvender en funktion, så længe den vender tilbage med succes og producerer en enkelt, endelig værdi.
    ///
    /// `try_fold()` tager to argumenter: en startværdi og en lukning med to argumenter: en 'accumulator' og et element.
    /// Lukningen returnerer enten med succes med den værdi, som akkumulatoren skal have til den næste iteration, eller den returnerer fiasko med en fejlværdi, der straks spredes tilbage til den, der ringer op, (short-circuiting).
    ///
    ///
    /// Den oprindelige værdi er den værdi, akkumulatoren har ved det første opkald.Hvis anvendelse af lukningen lykkedes mod hvert element i iteratoren, returnerer `try_fold()` den endelige akkumulator som succes.
    ///
    /// Foldning er nyttig, når du har en samling af noget og ønsker at producere en enkelt værdi ud fra det.
    ///
    /// # Bemærk til implementatorer
    ///
    /// Flere af de andre (forward)-metoder har standardimplementeringer med hensyn til denne, så prøv at implementere dette eksplicit, hvis det kan gøre noget bedre end standardimplementeringen af `for`-loop.
    ///
    /// Forsøg især at få dette opkald `try_fold()` til de interne dele, som denne iterator er sammensat af.
    /// Hvis der er behov for flere opkald, kan `?`-operatøren være praktisk til at kæde akkumulatorværdien sammen, men pas på eventuelle invarianter, der skal opretholdes, før de tidlige tilbagevenden.
    /// Dette er en `&mut self`-metode, så iteration skal være genoptaget efter at have ramt en fejl her.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // den afkrydsede sum af alle elementerne i arrayet
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Denne sum overløber, når 100-elementet tilføjes
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Fordi det kortsluttede, er de resterende elementer stadig tilgængelige gennem iteratoren.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// En iterator-metode, der anvender en fejlbar funktion til hvert element i iteratoren, stopper ved den første fejl og returnerer denne fejl.
    ///
    ///
    /// Dette kan også betragtes som den fejlbare form af [`for_each()`] eller som den statsløse version af [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Det kortsluttede, så de resterende emner er stadig i iteratoren:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Fold hvert element i en akkumulator ved at anvende en operation og returnere det endelige resultat.
    ///
    /// `fold()` tager to argumenter: en startværdi og en lukning med to argumenter: en 'accumulator' og et element.
    /// Lukningen returnerer den værdi, som akkumulatoren skal have for den næste iteration.
    ///
    /// Den oprindelige værdi er den værdi, akkumulatoren har ved det første opkald.
    ///
    /// Efter at have anvendt denne lukning på hvert element i iteratoren, returnerer `fold()` akkumulatoren.
    ///
    /// Denne handling kaldes undertiden 'reduce' eller 'inject'.
    ///
    /// Foldning er nyttig, når du har en samling af noget og ønsker at producere en enkelt værdi ud fra det.
    ///
    /// Note: `fold()` og lignende metoder, der krydser hele iteratoren, afsluttes muligvis ikke for uendelige iteratorer, selv ikke på traits, hvor et resultat kan bestemmes inden for en endelig tid.
    ///
    /// Note: [`reduce()`] kan bruges til at bruge det første element som den oprindelige værdi, hvis akkumulatortypen og artikeltypen er den samme.
    ///
    /// # Bemærk til implementatorer
    ///
    /// Flere af de andre (forward)-metoder har standardimplementeringer med hensyn til denne, så prøv at implementere dette eksplicit, hvis det kan gøre noget bedre end standardimplementeringen af `for`-loop.
    ///
    ///
    /// Forsøg især at få dette opkald `fold()` til de interne dele, som denne iterator er sammensat af.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // summen af alle elementerne i arrayet
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Lad os gå igennem hvert trin i iteration her:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Og så vores endelige resultat, `6`.
    ///
    /// Det er almindeligt for folk, der ikke har brugt iteratorer meget, at bruge en `for`-løkke med en liste over ting til at opbygge et resultat.Disse kan omdannes til `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // til løkke:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // de er de samme
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Reducerer elementerne til en enkelt ved gentagne gange at anvende en reducerende operation.
    ///
    /// Hvis iteratoren er tom, returnerer [`None`];Ellers returnerer resultatet af reduktionen.
    ///
    /// For iteratorer med mindst ét element er dette det samme som [`fold()`] med det første element i iteratoren som den oprindelige værdi, hvor hvert efterfølgende element foldes ind i det.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Find den maksimale værdi:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Tester, hvis hvert element i iteratoren matcher et prædikat.
    ///
    /// `all()` tager en lukning, der returnerer `true` eller `false`.Det anvender denne lukning på hvert element i iteratoren, og hvis de alle returnerer `true`, så gør `all()` det også.
    /// Hvis nogen af dem returnerer `false`, returnerer den `false`.
    ///
    /// `all()` er kortslutning;det vil med andre ord stoppe behandlingen, så snart den finder en `false`, da uanset hvad der ellers sker, bliver resultatet også `false`.
    ///
    ///
    /// En tom iterator returnerer `true`.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Stop ved den første `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // vi kan stadig bruge `iter`, da der er flere elementer.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Tester, om et element i iteratoren matcher et prædikat.
    ///
    /// `any()` tager en lukning, der returnerer `true` eller `false`.Det anvender denne lukning på hvert element i iteratoren, og hvis nogen af dem returnerer `true`, så gør `any()` det også.
    /// Hvis de alle returnerer `false`, returnerer det `false`.
    ///
    /// `any()` er kortslutning;det vil med andre ord stoppe behandlingen, så snart den finder en `true`, da uanset hvad der ellers sker, bliver resultatet også `true`.
    ///
    ///
    /// En tom iterator returnerer `false`.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Stop ved den første `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // vi kan stadig bruge `iter`, da der er flere elementer.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Søger efter et element i en iterator, der tilfredsstiller et prædikat.
    ///
    /// `find()` tager en lukning, der returnerer `true` eller `false`.
    /// Det anvender denne lukning på hvert element i iteratoren, og hvis nogen af dem returnerer `true`, returnerer `find()` [`Some(element)`].
    /// Hvis de alle returnerer `false`, returnerer det [`None`].
    ///
    /// `find()` er kortslutning;det vil med andre ord stoppe behandlingen, så snart lukningen returnerer `true`.
    ///
    /// Fordi `find()` tager en reference, og mange iteratorer gentager sig referencer, fører dette til en muligvis forvirrende situation, hvor argumentet er en dobbeltreference.
    ///
    /// Du kan se denne effekt i eksemplerne nedenfor med `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Stop ved den første `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // vi kan stadig bruge `iter`, da der er flere elementer.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Bemærk, at `iter.find(f)` svarer til `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Anvender funktion på iteratorens elementer og returnerer det første ikke-ingen-resultat.
    ///
    ///
    /// `iter.find_map(f)` svarer til `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Anvender funktion på iteratorens elementer og returnerer det første sande resultat eller den første fejl.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Søger efter et element i en iterator og returnerer dets indeks.
    ///
    /// `position()` tager en lukning, der returnerer `true` eller `false`.
    /// Den anvender denne lukning på hvert element i iteratoren, og hvis en af dem returnerer `true`, returnerer `position()` [`Some(index)`].
    /// Hvis alle returnerer `false`, returnerer det [`None`].
    ///
    /// `position()` er kortslutning;med andre ord stopper behandlingen med, så snart den finder en `true`.
    ///
    /// # Overløbsadfærd
    ///
    /// Metoden beskytter ikke mod overløb, så hvis der er mere end [`usize::MAX`] ikke-matchende elementer, producerer den enten det forkerte resultat eller panics.
    ///
    /// Hvis debug-påstande er aktiveret, garanteres en panic.
    ///
    /// # Panics
    ///
    /// Denne funktion kan muligvis panic, hvis iteratoren har mere end `usize::MAX` ikke-matchende elementer.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Stop ved den første `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // vi kan stadig bruge `iter`, da der er flere elementer.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Det returnerede indeks afhænger af iteratorstatus
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Søger efter et element i en iterator fra højre og returnerer dets indeks.
    ///
    /// `rposition()` tager en lukning, der returnerer `true` eller `false`.
    /// Det anvender denne lukning på hvert element i iteratoren, startende fra slutningen, og hvis en af dem returnerer `true`, returnerer `rposition()` [`Some(index)`].
    ///
    /// Hvis alle returnerer `false`, returnerer det [`None`].
    ///
    /// `rposition()` er kortslutning;med andre ord stopper behandlingen med, så snart den finder en `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Stop ved den første `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // vi kan stadig bruge `iter`, da der er flere elementer.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Intet behov for en overløbskontrol her, fordi `ExactSizeIterator` indebærer, at antallet af elementer passer ind i en `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Returnerer det maksimale element i en iterator.
    ///
    /// Hvis flere elementer er lige maksimale, returneres det sidste element.
    /// Hvis iteratoren er tom, returneres [`None`].
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Returnerer minimumselementet i en iterator.
    ///
    /// Hvis flere elementer er lige mindst, returneres det første element.
    /// Hvis iteratoren er tom, returneres [`None`].
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Returnerer det element, der giver den maksimale værdi fra den angivne funktion.
    ///
    ///
    /// Hvis flere elementer er lige maksimale, returneres det sidste element.
    /// Hvis iteratoren er tom, returneres [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Returnerer det element, der giver den maksimale værdi i forhold til den specificerede sammenligningsfunktion.
    ///
    ///
    /// Hvis flere elementer er lige maksimale, returneres det sidste element.
    /// Hvis iteratoren er tom, returneres [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Returnerer det element, der giver den mindste værdi fra den angivne funktion.
    ///
    ///
    /// Hvis flere elementer er lige mindst, returneres det første element.
    /// Hvis iteratoren er tom, returneres [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Returnerer det element, der giver den mindste værdi i forhold til den specificerede sammenligningsfunktion.
    ///
    ///
    /// Hvis flere elementer er lige mindst, returneres det første element.
    /// Hvis iteratoren er tom, returneres [`None`].
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Vender en iterators retning.
    ///
    /// Normalt gentages iteratorer fra venstre mod højre.
    /// Efter brug af `rev()` gentager en iterator i stedet fra højre til venstre.
    ///
    /// Dette er kun muligt, hvis iteratoren har en ende, så `rev()` fungerer kun på [`DoubleEndedIterator`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Konverterer en iterator af par til et par containere.
    ///
    /// `unzip()` forbruger en hel iterator af par og producerer to samlinger: en fra parternes venstre elementer og en fra de rigtige elementer.
    ///
    ///
    /// Denne funktion er på en eller anden måde det modsatte af [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Opretter en iterator, der kopierer alle dens elementer.
    ///
    /// Dette er nyttigt, når du har en iterator over `&T`, men du har brug for en iterator over `T`.
    ///
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // kopieret er det samme som .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Opretter en iterator, som [`klon`] er alle dens elementer.
    ///
    /// Dette er nyttigt, når du har en iterator over `&T`, men du har brug for en iterator over `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // klonet er det samme som .map(|&x| x) for heltal
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Gentager en iterator uendeligt.
    ///
    /// I stedet for at stoppe ved [`None`] starter iteratoren i stedet igen fra starten.Efter iterering igen, starter den igen.Og igen.
    /// Og igen.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Summer elementerne i en iterator.
    ///
    /// Tager hvert element, tilføjer dem sammen og returnerer resultatet.
    ///
    /// En tom iterator returnerer nulværdien af typen.
    ///
    /// # Panics
    ///
    /// Når du ringer til `sum()`, og en primitiv heltalstype returneres, vil denne metode panic, hvis beregningen flyder over, og debug-påstande er aktiveret.
    ///
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Itererer over hele iteratoren og ganger alle elementerne
    ///
    /// En tom iterator returnerer den ene værdi af typen.
    ///
    /// # Panics
    ///
    /// Når du ringer til `product()`, og en primitiv heltalstype returneres, vil metoden panic, hvis beregningen løber over og debug-påstande er aktiveret.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) sammenligner elementerne i denne [`Iterator`] med dem fra en anden.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) sammenligner elementerne i denne [`Iterator`] med dem fra en anden med hensyn til den specificerede sammenligningsfunktion.
    ///
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) sammenligner elementerne i denne [`Iterator`] med dem fra en anden.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) sammenligner elementerne i denne [`Iterator`] med dem fra en anden med hensyn til den specificerede sammenligningsfunktion.
    ///
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Bestemmer, om elementerne i denne [`Iterator`] er lig med en andens.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Bestemmer, om elementerne i denne [`Iterator`] er lig med dem til en anden med hensyn til den specificerede lighedsfunktion.
    ///
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Bestemmer, om elementerne i denne [`Iterator`] er ulige med andres.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Bestemmer, om elementerne i denne [`Iterator`] er [lexicographically](Ord#lexicographical-comparison) mindre end dem fra en anden.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Bestemmer, om elementerne i denne [`Iterator`] er [lexicographically](Ord#lexicographical-comparison) mindre eller lig med andres.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Bestemmer, om elementerne i denne [`Iterator`] er [lexicographically](Ord#lexicographical-comparison) større end dem fra en anden.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Bestemmer, om elementerne i denne [`Iterator`] er [lexicographically](Ord#lexicographical-comparison) større end eller lig med dem fra en anden.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Kontrollerer, om elementerne i denne iterator er sorteret.
    ///
    /// Det vil sige, at for hvert element `a` og dets følgende element `b` skal `a <= b` holde.Hvis iteratoren giver nøjagtigt nul eller et element, returneres `true`.
    ///
    /// Bemærk, at hvis `Self::Item` kun er `PartialOrd`, men ikke `Ord`, betyder ovenstående definition, at denne funktion returnerer `false`, hvis to på hinanden følgende punkter ikke er sammenlignelige.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Kontrollerer, om elementerne i denne iterator er sorteret ved hjælp af den givne komparatorfunktion.
    ///
    /// I stedet for at bruge `PartialOrd::partial_cmp` bruger denne funktion den givne `compare`-funktion til at bestemme rækkefølgen af to elementer.
    /// Bortset fra det svarer det til [`is_sorted`];se dokumentationen for mere information.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Kontrollerer, om elementerne i denne iterator er sorteret ved hjælp af den givne nøgleudtrækningsfunktion.
    ///
    /// I stedet for at sammenligne iteratorens elementer direkte sammenligner denne funktion elementernes nøgler som bestemt af `f`.
    /// Bortset fra det svarer det til [`is_sorted`];se dokumentationen for mere information.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Se [TrustedRandomAccess]
    // Det usædvanlige navn er at undgå navnekollisioner i metodeopløsning, se #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}