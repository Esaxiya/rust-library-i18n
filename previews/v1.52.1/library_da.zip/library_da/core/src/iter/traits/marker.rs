/// En iterator, der altid fortsætter med at give `None`, når den er opbrugt.
///
/// Det næste er at ringe til en smeltet iterator, der har returneret `None` en gang, vil garanteret returnere [`None`] igen.
/// Denne trait skal implementeres af alle iteratorer, der opfører sig på denne måde, fordi det muliggør optimering af [`Iterator::fuse()`].
///
///
/// Note: Generelt bør du ikke bruge `FusedIterator` i generiske grænser, hvis du har brug for en smeltet iterator.
/// I stedet skal du bare ringe til [`Iterator::fuse()`] på iteratoren.
/// Hvis iteratoren allerede er smeltet sammen, er den ekstra [`Fuse`]-indpakning en no-op uden præstationsstraff.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// En iterator, der rapporterer en nøjagtig længde ved hjælp af size_hint.
///
/// Iteratoren rapporterer et størrelsestip, hvor det enten er nøjagtigt (nedre grænse er lig med øvre grænse), eller den øvre grænse er [`None`].
///
/// Den øvre grænse må kun være [`None`], hvis den aktuelle iteratorlængde er større end [`usize::MAX`].
/// I så fald skal den nedre grænse være [`usize::MAX`], hvilket resulterer i en [`Iterator::size_hint()`] på `(usize::MAX, None)`.
///
/// Iteratoren skal producere nøjagtigt det antal elementer, den rapporterede eller afvige, inden den når slutningen.
///
/// # Safety
///
/// Denne trait skal kun implementeres, når kontrakten opretholdes.
/// Forbrugere af denne trait skal inspicere [`Iterator::size_hint()`]’s øvre grænse.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// En iterator, der, når man giver en vare, vil have taget mindst et element fra dens underliggende [`SourceIter`].
///
/// Opkald til enhver metode, der fremmer iteratoren, f.eks
/// [`next()`] eller [`try_fold()`], garanterer, at mindst én værdi af iteratorens underliggende kilde for hvert trin er flyttet ud, og resultatet af iteratorkæden kunne indsættes på plads, forudsat at kildens strukturelle begrænsninger tillader en sådan indsættelse.
///
/// Med andre ord indikerer denne trait, at en iteratorrørledning kan samles på plads.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}