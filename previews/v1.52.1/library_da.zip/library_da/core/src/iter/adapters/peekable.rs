use crate::iter::{adapters::SourceIter, FusedIterator, InPlaceIterable, TrustedLen};
use crate::ops::Try;

/// En iterator med en `peek()`, der returnerer en valgfri reference til det næste element.
///
///
/// Denne `struct` er oprettet ved hjælp af [`peekable`]-metoden på [`Iterator`].
/// Se dokumentationen for mere.
///
/// [`peekable`]: Iterator::peekable
/// [`Iterator`]: trait.Iterator.html
#[derive(Clone, Debug)]
#[must_use = "iterators are lazy and do nothing unless consumed"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Peekable<I: Iterator> {
    iter: I,
    /// Husk en kigget værdi, selvom den var Ingen.
    peeked: Option<Option<I::Item>>,
}

impl<I: Iterator> Peekable<I> {
    pub(in crate::iter) fn new(iter: I) -> Peekable<I> {
        Peekable { iter, peeked: None }
    }
}

// Peekable skal huske, hvis en Ingen er set i `.peek()`-metoden.
// Det sikrer, at `.peek();.peek();` eller `.peek();.next();` fremrykker kun den underliggende iterator højst én gang.
// Dette gør ikke i sig selv iteratoren smeltet.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> Iterator for Peekable<I> {
    type Item = I::Item;

    #[inline]
    fn next(&mut self) -> Option<I::Item> {
        match self.peeked.take() {
            Some(v) => v,
            None => self.iter.next(),
        }
    }

    #[inline]
    #[rustc_inherit_overflow_checks]
    fn count(mut self) -> usize {
        match self.peeked.take() {
            Some(None) => 0,
            Some(Some(_)) => 1 + self.iter.count(),
            None => self.iter.count(),
        }
    }

    #[inline]
    fn nth(&mut self, n: usize) -> Option<I::Item> {
        match self.peeked.take() {
            Some(None) => None,
            Some(v @ Some(_)) if n == 0 => v,
            Some(Some(_)) => self.iter.nth(n - 1),
            None => self.iter.nth(n),
        }
    }

    #[inline]
    fn last(mut self) -> Option<I::Item> {
        let peek_opt = match self.peeked.take() {
            Some(None) => return None,
            Some(v) => v,
            None => None,
        };
        self.iter.last().or(peek_opt)
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        let peek_len = match self.peeked {
            Some(None) => return (0, Some(0)),
            Some(Some(_)) => 1,
            None => 0,
        };
        let (lo, hi) = self.iter.size_hint();
        let lo = lo.saturating_add(peek_len);
        let hi = match hi {
            Some(x) => x.checked_add(peek_len),
            None => None,
        };
        (lo, hi)
    }

    #[inline]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let acc = match self.peeked.take() {
            Some(None) => return try { init },
            Some(Some(v)) => f(init, v)?,
            None => init,
        };
        self.iter.try_fold(acc, f)
    }

    #[inline]
    fn fold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        let acc = match self.peeked {
            Some(None) => return init,
            Some(Some(v)) => fold(init, v),
            None => init,
        };
        self.iter.fold(acc, fold)
    }
}

#[stable(feature = "double_ended_peek_iterator", since = "1.38.0")]
impl<I> DoubleEndedIterator for Peekable<I>
where
    I: DoubleEndedIterator,
{
    #[inline]
    fn next_back(&mut self) -> Option<Self::Item> {
        match self.peeked.as_mut() {
            Some(v @ Some(_)) => self.iter.next_back().or_else(|| v.take()),
            Some(None) => None,
            None => self.iter.next_back(),
        }
    }

    #[inline]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        match self.peeked.take() {
            Some(None) => try { init },
            Some(Some(v)) => match self.iter.try_rfold(init, &mut f).into_result() {
                Ok(acc) => f(acc, v),
                Err(e) => {
                    self.peeked = Some(Some(v));
                    Try::from_error(e)
                }
            },
            None => self.iter.try_rfold(init, f),
        }
    }

    #[inline]
    fn rfold<Acc, Fold>(self, init: Acc, mut fold: Fold) -> Acc
    where
        Fold: FnMut(Acc, Self::Item) -> Acc,
    {
        match self.peeked {
            Some(None) => init,
            Some(Some(v)) => {
                let acc = self.iter.rfold(init, &mut fold);
                fold(acc, v)
            }
            None => self.iter.rfold(init, fold),
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator> ExactSizeIterator for Peekable<I> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator> FusedIterator for Peekable<I> {}

impl<I: Iterator> Peekable<I> {
    /// Returnerer en henvisning til next()-værdien uden at gå videre med iteratoren.
    ///
    /// Ligesom [`next`], hvis der er en værdi, er den pakket ind i en `Some(T)`.
    /// Men hvis iterationen er overstået, returneres `None`.
    ///
    /// [`next`]: Iterator::next
    ///
    /// Da `peek()` returnerer en reference, og mange iteratorer gentager sig over referencer, kan der være en muligvis forvirrende situation, hvor returværdien er en dobbeltreference.
    /// Du kan se denne effekt i eksemplerne nedenfor.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() lader os se ind i future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // Iteratoren rykker ikke frem, selvom vi `peek` flere gange
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Når iteratoren er færdig, er det også `peek()`
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn peek(&mut self) -> Option<&I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_ref()
    }

    /// Returnerer en ændret henvisning til next()-værdien uden at gå videre til iteratoren.
    ///
    /// Ligesom [`next`], hvis der er en værdi, er den pakket ind i en `Some(T)`.
    /// Men hvis iterationen er overstået, returneres `None`.
    ///
    /// Da `peek_mut()` returnerer en reference, og mange iteratorer gentager sig over referencer, kan der være en muligvis forvirrende situation, hvor returværdien er en dobbeltreference.
    /// Du kan se denne effekt i eksemplerne nedenfor.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// #![feature(peekable_peek_mut)]
    /// let mut iter = [1, 2, 3].iter().peekable();
    ///
    /// // Som med `peek()` kan vi se ind i future uden at gå videre med iteratoren.
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.peek_mut(), Some(&mut &1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // Kig ind i iteratoren, og indstil værdien bag den ændrede reference.
    /// if let Some(p) = iter.peek_mut() {
    ///     assert_eq!(*p, &2);
    ///     *p = &5;
    /// }
    ///
    /// // Den værdi, vi lægger i, vises igen, når iteratoren fortsætter.
    /// assert_eq!(iter.collect::<Vec<_>>(), vec![&5, &3]);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "peekable_peek_mut", issue = "78302")]
    pub fn peek_mut(&mut self) -> Option<&mut I::Item> {
        let iter = &mut self.iter;
        self.peeked.get_or_insert_with(|| iter.next()).as_mut()
    }

    /// Forbruge og returnere den næste værdi af denne iterator, hvis en betingelse er sand.
    /// Hvis `func` returnerer `true` for den næste værdi af denne iterator, skal du forbruge og returnere den.
    /// Ellers skal du returnere `None`.
    /// # Examples
    /// Forbrug et tal, hvis det er lig med 0.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // Iteratorens første element er 0;forbruge det.
    /// assert_eq!(iter.next_if(|&x| x == 0), Some(0));
    /// // Den næste returnerede vare er nu 1, så `consume` returnerer `false`.
    /// assert_eq!(iter.next_if(|&x| x == 0), None);
    /// // `next_if` gemmer værdien af det næste element, hvis det ikke var lig med `expected`.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    ///
    /// Forbrug ethvert antal mindre end 10.
    ///
    /// ```
    /// let mut iter = (1..20).peekable();
    /// // Brug alle tal mindre end 10
    /// while iter.next_if(|&x| x < 10).is_some() {}
    /// // Den næste værdi, der returneres, er 10
    /// assert_eq!(iter.next(), Some(10));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if(&mut self, func: impl FnOnce(&I::Item) -> bool) -> Option<I::Item> {
        match self.next() {
            Some(matched) if func(&matched) => Some(matched),
            other => {
                // Da vi ringede til `self.next()`, forbrugte vi `self.peeked`.
                assert!(self.peeked.is_none());
                self.peeked = Some(other);
                None
            }
        }
    }

    /// Forbrug og returner det næste element, hvis det er lig med `expected`.
    /// # Example
    /// Forbrug et tal, hvis det er lig med 0.
    ///
    /// ```
    /// let mut iter = (0..5).peekable();
    /// // Iteratorens første element er 0;forbruge det.
    /// assert_eq!(iter.next_if_eq(&0), Some(0));
    /// // Den næste returnerede vare er nu 1, så `consume` returnerer `false`.
    /// assert_eq!(iter.next_if_eq(&0), None);
    /// // `next_if_eq` gemmer værdien af det næste element, hvis det ikke var lig med `expected`.
    /// assert_eq!(iter.next(), Some(1));
    /// ```
    #[stable(feature = "peekable_next_if", since = "1.51.0")]
    pub fn next_if_eq<T>(&mut self, expected: &T) -> Option<I::Item>
    where
        T: ?Sized,
        I::Item: PartialEq<T>,
    {
        self.next_if(|next| next == expected)
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I> TrustedLen for Peekable<I> where I: TrustedLen {}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<S: Iterator, I: Iterator> SourceIter for Peekable<I>
where
    I: SourceIter<Source = S>,
{
    type Source = S;

    #[inline]
    unsafe fn as_inner(&mut self) -> &mut S {
        // SIKKERHED: videresendelse af usikker funktion til usikker funktion med de samme krav
        unsafe { SourceIter::as_inner(&mut self.iter) }
    }
}

#[unstable(issue = "none", feature = "inplace_iteration")]
unsafe impl<I: InPlaceIterable> InPlaceIterable for Peekable<I> {}