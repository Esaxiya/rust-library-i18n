//! Atomtyper
//!
//! Atomtyper giver primitiv delt hukommelseskommunikation mellem tråde og er byggestenene til andre samtidige typer.
//!
//! Dette modul definerer atomversioner af et valgt antal primitive typer, herunder [`AtomicBool`], [`AtomicIsize`], [`AtomicUsize`], [`AtomicI8`], [`AtomicU16`] osv.
//! Atomtyper præsenterer operationer, der, når de bruges korrekt, synkroniserer opdateringer mellem tråde.
//!
//! Hver metode tager en [`Ordering`], som repræsenterer styrken af hukommelsesbarrieren til denne operation.Disse ordrer er de samme som [C++20 atomic orderings][1].For mere information se [nomicon][2].
//!
//! [1]: https://en.cppreference.com/w/cpp/atomic/memory_order
//! [2]: ../../../nomicon/atomics.html
//!
//! Atomiske variabler er sikre at dele mellem tråde (de implementerer [`Sync`]), men de leverer ikke selv mekanismen til deling og følger [threading model](../../../std/thread/index.html#the-threading-model) fra Rust.
//!
//! Den mest almindelige måde at dele en atomvariabel på er at placere den i en [`Arc`][arc] (en atomært referencetællet delt pointer).
//!
//! [arc]: ../../../std/sync/struct.Arc.html
//!
//! Atomtyper kan lagres i statiske variabler, initialiseret ved hjælp af de konstante initialiserere som [`AtomicBool::new`].Atomstatik bruges ofte til doven global initialisering.
//!
//! # Portability
//!
//! Alle atomtyper i dette modul er garanteret [lock-free], hvis de er tilgængelige.Dette betyder, at de ikke internt erhverver en global mutex.Atomtyper og operationer garanteres ikke at være ventefrie.
//! Dette betyder, at operationer som `fetch_or` kan implementeres med en sammenlignings-og-swap-løkke.
//!
//! Atomoperationer kan implementeres ved instruktionslaget med større atomare.For eksempel bruger nogle platforme 4-byte atominstruktioner til at implementere `AtomicI8`.
//! Bemærk, at denne emulering ikke skal påvirke korrektheden af koden, det er bare noget at være opmærksom på.
//!
//! Atomtyperne i dette modul er muligvis ikke tilgængelige på alle platforme.Atomtyperne her er dog alle tilgængelige, og de kan generelt påberåbes eksisterende.Nogle bemærkelsesværdige undtagelser er:
//!
//! * PowerPC og MIPS-platforme med 32-bit-markører har ikke `AtomicU64`-eller `AtomicI64`-typer.
//! * ARM platforme som `armv5te`, der ikke er til Linux, leverer kun `load`-og `store`-operationer og understøtter ikke Sammenlign og udskift (CAS)-operationer, såsom `swap`, `fetch_add` osv.
//! Derudover på Linux implementeres disse CAS-operationer via [operating system support], hvilket kan medføre en præstationsstraff.
//! * ARM mål med `thumbv6m` giver kun `load`-og `store`-operationer og understøtter ikke Sammenlign og udskift (CAS)-operationer, såsom `swap`, `fetch_add` osv.
//!
//! [operating system support]: https://www.kernel.org/doc/Documentation/arm/kernel_user_helpers.txt
//!
//! Bemærk, at der kan tilføjes future-platforme, som heller ikke understøtter nogle atomoperationer.Maksimal bærbar kode vil være forsigtig med, hvilke atomtyper der bruges.
//! `AtomicUsize` og `AtomicIsize` er generelt de mest bærbare, men selv da er de ikke tilgængelige overalt.
//! Til reference kræver `std`-biblioteket atomer i pointerstørrelse, selvom `core` ikke gør det.
//!
//! I øjeblikket skal du primært bruge `#[cfg(target_arch)]` til betinget kompilering i kode med atomik.Der er også en ustabil `#[cfg(target_has_atomic)]`, som kan stabiliseres i future.
//!
//! [lock-free]: https://en.wikipedia.org/wiki/Non-blocking_algorithm
//!
//! # Examples
//!
//! En simpel spinlock:
//!
//! ```
//! use std::sync::Arc;
//! use std::sync::atomic::{AtomicUsize, Ordering};
//! use std::thread;
//!
//! fn main() {
//!     let spinlock = Arc::new(AtomicUsize::new(1));
//!
//!     let spinlock_clone = Arc::clone(&spinlock);
//!     let thread = thread::spawn(move|| {
//!         spinlock_clone.store(0, Ordering::SeqCst);
//!     });
//!
//!     // Vent til den anden tråd frigør låsen
//!     while spinlock.load(Ordering::SeqCst) != 0 {}
//!
//!     if let Err(panic) = thread.join() {
//!         println!("Thread had an error: {:?}", panic);
//!     }
//! }
//! ```
//!
//! Hold et globalt antal live tråde:
//!
//! ```
//! use std::sync::atomic::{AtomicUsize, Ordering};
//!
//! static GLOBAL_THREAD_COUNT: AtomicUsize = AtomicUsize::new(0);
//!
//! let old_thread_count = GLOBAL_THREAD_COUNT.fetch_add(1, Ordering::SeqCst);
//! println!("live threads: {}", old_thread_count + 1);
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(dead_code))]
#![cfg_attr(not(target_has_atomic_load_store = "8"), allow(unused_imports))]

use self::Ordering::*;

use crate::cell::UnsafeCell;
use crate::fmt;
use crate::intrinsics;

use crate::hint::spin_loop;

/// En boolsk type, som sikkert kan deles mellem tråde.
///
/// Denne type har den samme hukommelsesrepræsentation som en [`bool`].
///
/// **Bemærk**: Denne type er kun tilgængelig på platforme, der understøtter atombelastninger og lagre af `u8`.
///
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[repr(C, align(1))]
pub struct AtomicBool {
    v: UnsafeCell<u8>,
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
impl Default for AtomicBool {
    /// Opretter en `AtomicBool` initialiseret til `false`.
    #[inline]
    fn default() -> Self {
        Self::new(false)
    }
}

// Send implementeres implicit til AtomicBool.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl Sync for AtomicBool {}

/// En rå markørtype, som sikkert kan deles mellem tråde.
///
/// Denne type har den samme hukommelsesrepræsentation som en `*mut T`.
///
/// **Bemærk**: Denne type er kun tilgængelig på platforme, der understøtter atombelastninger og lagre markører.
/// Dens størrelse afhænger af målmarkørens størrelse.
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(target_pointer_width = "16", repr(C, align(2)))]
#[cfg_attr(target_pointer_width = "32", repr(C, align(4)))]
#[cfg_attr(target_pointer_width = "64", repr(C, align(8)))]
pub struct AtomicPtr<T> {
    p: UnsafeCell<*mut T>,
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for AtomicPtr<T> {
    /// Opretter en null `AtomicPtr<T>`.
    fn default() -> AtomicPtr<T> {
        AtomicPtr::new(crate::ptr::null_mut())
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Send for AtomicPtr<T> {}
#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T> Sync for AtomicPtr<T> {}

/// Atomiske hukommelsesbestillinger
///
/// Hukommelsesordrer angiver den måde, atomoperationer synkroniserer hukommelse på.
/// I sin svageste [`Ordering::Relaxed`] synkroniseres kun den hukommelse, der direkte berøres af operationen.
/// På den anden side synkroniserer et butiksbelastningspar af [`Ordering::SeqCst`]-operationer anden hukommelse, samtidig med at den samlede rækkefølge af sådanne operationer bevares på tværs af alle tråde.
///
///
/// Rust's hukommelsesbestillinger er [the same as those of C++20](https://en.cppreference.com/w/cpp/atomic/memory_order).
///
/// For mere information se [nomicon].
///
/// [nomicon]: ../../../nomicon/atomics.html
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
#[non_exhaustive]
pub enum Ordering {
    /// Ingen ordrebegrænsninger, kun atomoperationer.
    ///
    /// Svarer til [`memory_order_relaxed`] i C++ 20.
    ///
    /// [`memory_order_relaxed`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Relaxed_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    Relaxed,
    /// Når det kombineres med en butik, bestilles alle tidligere operationer inden nogen belastning af denne værdi med [`Acquire`] (eller stærkere) bestilling.
    ///
    /// Især bliver alle tidligere skrivninger synlige for alle tråde, der udfører en [`Acquire`] (eller stærkere) belastning af denne værdi.
    ///
    /// Bemærk, at brug af denne bestilling til en operation, der kombinerer belastninger og lagrer, fører til en [`Relaxed`]-belastning!
    ///
    /// Denne bestilling gælder kun for operationer, der kan udføre en butik.
    ///
    /// Svarer til [`memory_order_release`] i C++ 20.
    ///
    /// [`memory_order_release`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Release,
    /// Når det er kombineret med en belastning, hvis den indlæste værdi blev skrevet ved en butiksoperation med [`Release`] (eller stærkere) bestilling, bestilles alle efterfølgende operationer efter den butik.
    /// Især vil alle efterfølgende belastninger se data skrevet før butikken.
    ///
    /// Bemærk, at brug af denne bestilling til en operation, der kombinerer belastninger og lagrer, fører til en [`Relaxed`]-butikshandling!
    ///
    /// Denne bestilling gælder kun for operationer, der kan udføre en belastning.
    ///
    /// Svarer til [`memory_order_acquire`] i C++ 20.
    ///
    /// [`memory_order_acquire`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    Acquire,
    /// Har effekterne af både [`Acquire`] og [`Release`] sammen:
    /// Til belastning bruger den [`Acquire`]-bestilling.For butikker bruger den [`Release`]-bestillingen.
    ///
    /// Bemærk, at i tilfælde af `compare_and_swap` er det muligt, at operationen ender med ikke at udføre nogen butik, og derfor har den kun [`Acquire`]-bestilling.
    ///
    /// `AcqRel` vil dog aldrig udføre [`Relaxed`]-adgang.
    ///
    /// Denne bestilling gælder kun for operationer, der kombinerer både belastninger og butikker.
    ///
    /// Svarer til [`memory_order_acq_rel`] i C++ 20.
    ///
    /// [`memory_order_acq_rel`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Release-Acquire_ordering
    #[stable(feature = "rust1", since = "1.0.0")]
    AcqRel,
    /// Ligesom [`Acquire`]/[`Release`]/[`AcqRel`](henholdsvis til belastning, lagring og belastning med butik) med den ekstra garanti, at alle tråde ser alle sekventielt konsistente operationer i samme rækkefølge .
    ///
    ///
    /// Svarer til [`memory_order_seq_cst`] i C++ 20.
    ///
    /// [`memory_order_seq_cst`]: https://en.cppreference.com/w/cpp/atomic/memory_order#Sequentially-consistent_ordering
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    SeqCst,
}

/// En [`AtomicBool`] initialiseret til `false`.
#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "1.34.0",
    reason = "the `new` function is now preferred",
    suggestion = "AtomicBool::new(false)"
)]
pub const ATOMIC_BOOL_INIT: AtomicBool = AtomicBool::new(false);

#[cfg(target_has_atomic_load_store = "8")]
impl AtomicBool {
    /// Opretter en ny `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let atomic_true  = AtomicBool::new(true);
    /// let atomic_false = AtomicBool::new(false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(v: bool) -> AtomicBool {
        AtomicBool { v: UnsafeCell::new(v as u8) }
    }

    /// Returnerer en ændret henvisning til den underliggende [`bool`].
    ///
    /// Dette er sikkert, fordi den ændrede reference garanterer, at ingen andre tråde samtidig har adgang til atommasserne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = AtomicBool::new(true);
    /// assert_eq!(*some_bool.get_mut(), true);
    /// *some_bool.get_mut() = false;
    /// assert_eq!(some_bool.load(Ordering::SeqCst), false);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut bool {
        // SIKKERHED: den ændrede reference garanterer unikt ejerskab.
        unsafe { &mut *(self.v.get() as *mut bool) }
    }

    /// Få atomadgang til en `&mut bool`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let mut some_bool = true;
    /// let a = AtomicBool::from_mut(&mut some_bool);
    /// a.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool, false);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "8")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut bool) -> &Self {
        // SIKKERHED: den ændrede reference garanterer unikt ejerskab, og
        // justering af både `bool` og `Self` er 1.
        unsafe { &*(v as *mut bool as *mut Self) }
    }

    /// Forbruger atomerne og returnerer den indeholdte værdi.
    ///
    /// Dette er sikkert, fordi overførsel af `self` efter værdi garanterer, at ingen andre tråde samtidig har adgang til atomdata.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    ///
    /// let some_bool = AtomicBool::new(true);
    /// assert_eq!(some_bool.into_inner(), true);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> bool {
        self.v.into_inner() != 0
    }

    /// Indlæser en værdi fra bool.
    ///
    /// `load` tager et [`Ordering`]-argument, der beskriver hukommelsesrækkefølgen for denne operation.
    /// Mulige værdier er [`SeqCst`], [`Acquire`] og [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics hvis `order` er [`Release`] eller [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.load(Ordering::Relaxed), true);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> bool {
        // SIKKERHED: ethvert dataløb forhindres af atomare iboende og rå
        // pointer, der er sendt ind, er gyldig, fordi vi fik den fra en reference.
        unsafe { atomic_load(self.v.get(), order) != 0 }
    }

    /// Gemmer en værdi i bool.
    ///
    /// `store` tager et [`Ordering`]-argument, der beskriver hukommelsesrækkefølgen for denne operation.
    /// Mulige værdier er [`SeqCst`], [`Release`] og [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics hvis `order` er [`Acquire`] eller [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// some_bool.store(false, Ordering::Relaxed);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, val: bool, order: Ordering) {
        // SIKKERHED: ethvert dataløb forhindres af atomare iboende og rå
        // pointer, der er sendt ind, er gyldig, fordi vi fik den fra en reference.
        unsafe {
            atomic_store(self.v.get(), val as u8, order);
        }
    }

    /// Gemmer en værdi i bool og returnerer den tidligere værdi.
    ///
    /// `swap` tager et [`Ordering`]-argument, der beskriver hukommelsesrækkefølgen for denne operation.Alle bestillingstilstande er mulige.
    /// Bemærk, at brug af [`Acquire`] gør butikken til en del af denne operation [`Relaxed`], og brug af [`Release`] gør belastningsdelen [`Relaxed`].
    ///
    ///
    /// **Note:** Denne metode er kun tilgængelig på platforme, der understøtter atomoperationer på `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.swap(false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn swap(&self, val: bool, order: Ordering) -> bool {
        // SIKKERHED: dataløb forhindres af atomare iboende egenskaber.
        unsafe { atomic_swap(self.v.get(), val as u8, order) != 0 }
    }

    /// Gemmer en værdi i [`bool`], hvis den aktuelle værdi er den samme som `current`-værdien.
    ///
    /// Returneringsværdien er altid den forrige værdi.Hvis det er lig med `current`, blev værdien opdateret.
    ///
    /// `compare_and_swap` tager også et [`Ordering`]-argument, der beskriver hukommelsesrækkefølgen for denne operation.
    /// Bemærk, at selv når du bruger [`AcqRel`], kan operationen muligvis mislykkes og derfor bare udføre en `Acquire`-belastning, men ikke have `Release`-semantik.
    /// Brug af [`Acquire`] gør butikken til en del af denne operation [`Relaxed`], hvis det sker, og brug af [`Release`] gør belastningsdelen [`Relaxed`].
    ///
    /// **Note:** Denne metode er kun tilgængelig på platforme, der understøtter atomoperationer på `u8`.
    ///
    /// # Migrerer til `compare_exchange` og `compare_exchange_weak`
    ///
    /// `compare_and_swap` svarer til `compare_exchange` med følgende kortlægning for hukommelsesbestillinger:
    ///
    /// Original |Succes |Fiasko
    /// -------- | ------- | -------
    /// Afslappet |Afslappet |Afslappet erhverve |Erhverve |Hent frigivelse |Frigivelse |Afslappet AcqRel |AcqRel |Erhverv SeqCst |SeqCst |Sekv
    ///
    /// `compare_exchange_weak` får lov til at mislykkes falskt, selv når sammenligningen lykkes, hvilket gør det muligt for kompilatoren at generere bedre samlingskode, når sammenligningen og swap bruges i en loop.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, false, Ordering::Relaxed), true);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_and_swap(true, true, Ordering::Relaxed), false);
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_and_swap(&self, current: bool, new: bool, order: Ordering) -> bool {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Gemmer en værdi i [`bool`], hvis den aktuelle værdi er den samme som `current`-værdien.
    ///
    /// Returneringsværdien er et resultat, der angiver, om den nye værdi blev skrevet og indeholdt den tidligere værdi.
    /// Ved succes er denne værdi garanteret at være lig med `current`.
    ///
    /// `compare_exchange` tager to [`Ordering`] argumenter for at beskrive hukommelsesrækkefølgen for denne operation.
    /// `success` beskriver den krævede rækkefølge for læs-modificer-skriv-operationen, der finder sted, hvis sammenligningen med `current` lykkes.
    /// `failure` beskriver den krævede rækkefølge for den belastning, der finder sted, når sammenligningen mislykkes.
    /// Brug af [`Acquire`] som succesbestilling gør butikken til en del af denne operation [`Relaxed`], og brug af [`Release`] gør den vellykkede belastning [`Relaxed`].
    ///
    /// Fejlbestillingen kan kun være [`SeqCst`], [`Acquire`] eller [`Relaxed`] og skal svare til eller svagere end succesbestillingen.
    ///
    /// **Note:** Denne metode er kun tilgængelig på platforme, der understøtter atomoperationer på `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let some_bool = AtomicBool::new(true);
    ///
    /// assert_eq!(some_bool.compare_exchange(true,
    ///                                       false,
    ///                                       Ordering::Acquire,
    ///                                       Ordering::Relaxed),
    ///            Ok(true));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    ///
    /// assert_eq!(some_bool.compare_exchange(true, true,
    ///                                       Ordering::SeqCst,
    ///                                       Ordering::Acquire),
    ///            Err(false));
    /// assert_eq!(some_bool.load(Ordering::Relaxed), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SIKKERHED: dataløb forhindres af atomare iboende egenskaber.
        match unsafe {
            atomic_compare_exchange(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Gemmer en værdi i [`bool`], hvis den aktuelle værdi er den samme som `current`-værdien.
    ///
    /// I modsætning til [`AtomicBool::compare_exchange`] får denne funktion falske fejl, selv når sammenligningen lykkes, hvilket kan resultere i mere effektiv kode på nogle platforme.
    ///
    /// Returneringsværdien er et resultat, der angiver, om den nye værdi blev skrevet og indeholdt den tidligere værdi.
    ///
    /// `compare_exchange_weak` tager to [`Ordering`] argumenter for at beskrive hukommelsesrækkefølgen for denne operation.
    /// `success` beskriver den krævede rækkefølge for læs-modificer-skriv-operationen, der finder sted, hvis sammenligningen med `current` lykkes.
    /// `failure` beskriver den krævede rækkefølge for den belastning, der finder sted, når sammenligningen mislykkes.
    /// Brug af [`Acquire`] som succesbestilling gør butikken til en del af denne operation [`Relaxed`], og brug af [`Release`] gør den vellykkede belastning [`Relaxed`].
    /// Fejlbestillingen kan kun være [`SeqCst`], [`Acquire`] eller [`Relaxed`] og skal svare til eller svagere end succesbestillingen.
    ///
    /// **Note:** Denne metode er kun tilgængelig på platforme, der understøtter atomoperationer på `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let val = AtomicBool::new(false);
    ///
    /// let new = true;
    /// let mut old = val.load(Ordering::Relaxed);
    /// loop {
    ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[doc(alias = "compare_and_swap")]
    #[cfg(target_has_atomic = "8")]
    pub fn compare_exchange_weak(
        &self,
        current: bool,
        new: bool,
        success: Ordering,
        failure: Ordering,
    ) -> Result<bool, bool> {
        // SIKKERHED: dataløb forhindres af atomare iboende egenskaber.
        match unsafe {
            atomic_compare_exchange_weak(self.v.get(), current as u8, new as u8, success, failure)
        } {
            Ok(x) => Ok(x != 0),
            Err(x) => Err(x != 0),
        }
    }

    /// Logisk "and" med en boolsk værdi.
    ///
    /// Udfører en logisk "and"-handling på den aktuelle værdi og argumentet `val` og indstiller den nye værdi til resultatet.
    ///
    /// Returnerer den forrige værdi.
    ///
    /// `fetch_and` tager et [`Ordering`]-argument, der beskriver hukommelsesrækkefølgen for denne operation.Alle bestillingstilstande er mulige.
    /// Bemærk, at brug af [`Acquire`] gør butikken til en del af denne operation [`Relaxed`], og brug af [`Release`] gør belastningsdelen [`Relaxed`].
    ///
    ///
    /// **Note:** Denne metode er kun tilgængelig på platforme, der understøtter atomoperationer på `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_and(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_and(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_and(&self, val: bool, order: Ordering) -> bool {
        // SIKKERHED: dataløb forhindres af atomare iboende egenskaber.
        unsafe { atomic_and(self.v.get(), val as u8, order) != 0 }
    }

    /// Logisk "nand" med en boolsk værdi.
    ///
    /// Udfører en logisk "nand"-handling på den aktuelle værdi og argumentet `val` og indstiller den nye værdi til resultatet.
    ///
    /// Returnerer den forrige værdi.
    ///
    /// `fetch_nand` tager et [`Ordering`]-argument, der beskriver hukommelsesrækkefølgen for denne operation.Alle bestillingstilstande er mulige.
    /// Bemærk, at brug af [`Acquire`] gør butikken til en del af denne operation [`Relaxed`], og brug af [`Release`] gør belastningsdelen [`Relaxed`].
    ///
    ///
    /// **Note:** Denne metode er kun tilgængelig på platforme, der understøtter atomoperationer på `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_nand(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst) as usize, 0);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_nand(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_nand(&self, val: bool, order: Ordering) -> bool {
        // Vi kan ikke bruge atomic_nand her, fordi det kan resultere i en bool med en ugyldig værdi.
        // Dette sker, fordi atomoperationen udføres med et 8-bit heltal internt, hvilket ville indstille de øverste 7 bit.
        //
        // Så vi bruger bare fetch_xor eller bytter i stedet.
        if val {
            // ! (x&true)== !x Vi skal vende bool om.
            //
            self.fetch_xor(true, order)
        } else {
            // ! (x&false)==true Vi skal indstille bool til true.
            //
            self.swap(true, order)
        }
    }

    /// Logisk "or" med en boolsk værdi.
    ///
    /// Udfører en logisk "or"-handling på den aktuelle værdi og argumentet `val` og indstiller den nye værdi til resultatet.
    ///
    /// Returnerer den forrige værdi.
    ///
    /// `fetch_or` tager et [`Ordering`]-argument, der beskriver hukommelsesrækkefølgen for denne operation.Alle bestillingstilstande er mulige.
    /// Bemærk, at brug af [`Acquire`] gør butikken til en del af denne operation [`Relaxed`], og brug af [`Release`] gør belastningsdelen [`Relaxed`].
    ///
    ///
    /// **Note:** Denne metode er kun tilgængelig på platforme, der understøtter atomoperationer på `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_or(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_or(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_or(&self, val: bool, order: Ordering) -> bool {
        // SIKKERHED: dataløb forhindres af atomare iboende egenskaber.
        unsafe { atomic_or(self.v.get(), val as u8, order) != 0 }
    }

    /// Logisk "xor" med en boolsk værdi.
    ///
    /// Udfører en logisk "xor"-handling på den aktuelle værdi og argumentet `val` og indstiller den nye værdi til resultatet.
    ///
    /// Returnerer den forrige værdi.
    ///
    /// `fetch_xor` tager et [`Ordering`]-argument, der beskriver hukommelsesrækkefølgen for denne operation.Alle bestillingstilstande er mulige.
    /// Bemærk, at brug af [`Acquire`] gør butikken til en del af denne operation [`Relaxed`], og brug af [`Release`] gør belastningsdelen [`Relaxed`].
    ///
    ///
    /// **Note:** Denne metode er kun tilgængelig på platforme, der understøtter atomoperationer på `u8`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), true);
    ///
    /// let foo = AtomicBool::new(true);
    /// assert_eq!(foo.fetch_xor(true, Ordering::SeqCst), true);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    ///
    /// let foo = AtomicBool::new(false);
    /// assert_eq!(foo.fetch_xor(false, Ordering::SeqCst), false);
    /// assert_eq!(foo.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_xor(&self, val: bool, order: Ordering) -> bool {
        // SIKKERHED: dataløb forhindres af atomare iboende egenskaber.
        unsafe { atomic_xor(self.v.get(), val as u8, order) != 0 }
    }

    /// Returnerer en ændret markør til den underliggende [`bool`].
    ///
    /// At lave ikke-atomare læser og skriver på det resulterende heltal kan være et dataløb.
    /// Denne metode er mest anvendelig til FFI, hvor funktionssignaturen muligvis bruger `*mut bool` i stedet for `&AtomicBool`.
    ///
    /// Det er sikkert at returnere en `*mut`-markør fra en fælles henvisning til dette atom, fordi atomtyperne arbejder med indre mutabilitet.
    /// Alle ændringer af et atom ændrer værdien gennem en delt reference og kan gøre det sikkert, så længe de bruger atomoperationer.
    /// Enhver brug af den returnerede rå markør kræver en `unsafe`-blok og skal stadig opretholde den samme begrænsning: operationer på den skal være atomare.
    ///
    ///
    /// # Examples
    ///
    /// ```ignore (extern-declaration)
    /// # fn main() {
    /// use std::sync::atomic::AtomicBool;
    /// extern "C" {
    ///     fn my_atomic_op(arg: *mut bool);
    /// }
    ///
    /// let mut atomic = AtomicBool::new(true);
    /// unsafe {
    ///     my_atomic_op(atomic.as_mut_ptr());
    /// }
    /// # }
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_mut_ptr", reason = "recently added", issue = "66893")]
    pub fn as_mut_ptr(&self) -> *mut bool {
        self.v.get() as *mut bool
    }

    /// Henter værdien og anvender en funktion til den, der returnerer en valgfri ny værdi.Returnerer en `Result` af `Ok(previous_value)`, hvis funktionen returnerede `Some(_)`, ellers `Err(previous_value)`.
    ///
    /// Note: Dette kan muligvis kalde funktionen flere gange, hvis værdien er blevet ændret fra andre tråde i mellemtiden, så længe funktionen returnerer `Some(_)`, men funktionen vil kun være anvendt en gang til den gemte værdi.
    ///
    ///
    /// `fetch_update` tager to [`Ordering`] argumenter for at beskrive hukommelsesrækkefølgen for denne operation.
    /// Den første beskriver den krævede bestilling, når operationen endelig lykkes, mens den anden beskriver den nødvendige bestilling af belastninger.
    /// Disse svarer til henholdsvis succes og fiasko ordrer på [`AtomicBool::compare_exchange`].
    ///
    /// Brug af [`Acquire`] som succesbestilling gør butikken til en del af denne operation [`Relaxed`], og brug af [`Release`] gør den endelige vellykkede belastning [`Relaxed`].
    /// (failed)-belastningsbestilling kan kun være [`SeqCst`], [`Acquire`] eller [`Relaxed`] og skal svare til eller svagere end succesbestillingen.
    ///
    /// **Note:** Denne metode er kun tilgængelig på platforme, der understøtter atomoperationer på `u8`.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicBool, Ordering};
    ///
    /// let x = AtomicBool::new(false);
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(false));
    /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| Some(!x)), Ok(true));
    /// assert_eq!(x.load(Ordering::SeqCst), false);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "8")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<bool, bool>
    where
        F: FnMut(bool) -> Option<bool>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
impl<T> AtomicPtr<T> {
    /// Opretter en ny `AtomicPtr`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let ptr = &mut 5;
    /// let atomic_ptr  = AtomicPtr::new(ptr);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_atomic_new", since = "1.32.0")]
    pub const fn new(p: *mut T) -> AtomicPtr<T> {
        AtomicPtr { p: UnsafeCell::new(p) }
    }

    /// Returnerer en ændret henvisning til den underliggende markør.
    ///
    /// Dette er sikkert, fordi den ændrede reference garanterer, at ingen andre tråde samtidig har adgang til atommasserne.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut atomic_ptr = AtomicPtr::new(&mut 10);
    /// *atomic_ptr.get_mut() = &mut 5;
    /// assert_eq!(unsafe { *atomic_ptr.load(Ordering::SeqCst) }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    pub fn get_mut(&mut self) -> &mut *mut T {
        self.p.get_mut()
    }

    /// Få atomadgang til en markør.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(atomic_from_mut)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let mut some_ptr = &mut 123 as *mut i32;
    /// let a = AtomicPtr::from_mut(&mut some_ptr);
    /// a.store(&mut 456, Ordering::Relaxed);
    /// assert_eq!(unsafe { *some_ptr }, 456);
    /// ```
    #[inline]
    #[cfg(target_has_atomic_equal_alignment = "ptr")]
    #[unstable(feature = "atomic_from_mut", issue = "76314")]
    pub fn from_mut(v: &mut *mut T) -> &Self {
        use crate::mem::align_of;
        let [] = [(); align_of::<AtomicPtr<()>>() - align_of::<*mut ()>()];
        // SAFETY:
        //  - den ændrede reference garanterer unikt ejerskab.
        //  - justeringen af `*mut T` og `Self` er den samme på alle platforme understøttet af rust, som bekræftet ovenfor.
        //
        unsafe { &*(v as *mut *mut T as *mut Self) }
    }

    /// Forbruger atomerne og returnerer den indeholdte værdi.
    ///
    /// Dette er sikkert, fordi overførsel af `self` efter værdi garanterer, at ingen andre tråde samtidig har adgang til atomdata.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicPtr;
    ///
    /// let atomic_ptr = AtomicPtr::new(&mut 5);
    /// assert_eq!(unsafe { *atomic_ptr.into_inner() }, 5);
    /// ```
    #[inline]
    #[stable(feature = "atomic_access", since = "1.15.0")]
    #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
    pub const fn into_inner(self) -> *mut T {
        self.p.into_inner()
    }

    /// Indlæser en værdi fra markøren.
    ///
    /// `load` tager et [`Ordering`]-argument, der beskriver hukommelsesrækkefølgen for denne operation.
    /// Mulige værdier er [`SeqCst`], [`Acquire`] og [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics hvis `order` er [`Release`] eller [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let value = some_ptr.load(Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn load(&self, order: Ordering) -> *mut T {
        // SIKKERHED: dataløb forhindres af atomare iboende egenskaber.
        unsafe { atomic_load(self.p.get(), order) }
    }

    /// Gemmer en værdi i markøren.
    ///
    /// `store` tager et [`Ordering`]-argument, der beskriver hukommelsesrækkefølgen for denne operation.
    /// Mulige værdier er [`SeqCst`], [`Release`] og [`Relaxed`].
    ///
    /// # Panics
    ///
    /// Panics hvis `order` er [`Acquire`] eller [`AcqRel`].
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// some_ptr.store(other_ptr, Ordering::Relaxed);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn store(&self, ptr: *mut T, order: Ordering) {
        // SIKKERHED: dataløb forhindres af atomare iboende egenskaber.
        unsafe {
            atomic_store(self.p.get(), ptr, order);
        }
    }

    /// Gemmer en værdi i markøren og returnerer den forrige værdi.
    ///
    /// `swap` tager et [`Ordering`]-argument, der beskriver hukommelsesrækkefølgen for denne operation.Alle bestillingstilstande er mulige.
    /// Bemærk, at brug af [`Acquire`] gør butikken til en del af denne operation [`Relaxed`], og brug af [`Release`] gør belastningsdelen [`Relaxed`].
    ///
    ///
    /// **Note:** Denne metode er kun tilgængelig på platforme, der understøtter atomoperationer på markører.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr = &mut 10;
    ///
    /// let value = some_ptr.swap(other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn swap(&self, ptr: *mut T, order: Ordering) -> *mut T {
        // SIKKERHED: dataløb forhindres af atomare iboende egenskaber.
        unsafe { atomic_swap(self.p.get(), ptr, order) }
    }

    /// Gemmer en værdi i markøren, hvis den aktuelle værdi er den samme som `current`-værdien.
    ///
    /// Returneringsværdien er altid den forrige værdi.Hvis det er lig med `current`, blev værdien opdateret.
    ///
    /// `compare_and_swap` tager også et [`Ordering`]-argument, der beskriver hukommelsesrækkefølgen for denne operation.
    /// Bemærk, at selv når du bruger [`AcqRel`], kan operationen muligvis mislykkes og derfor bare udføre en `Acquire`-belastning, men ikke have `Release`-semantik.
    /// Brug af [`Acquire`] gør butikken til en del af denne operation [`Relaxed`], hvis det sker, og brug af [`Release`] gør belastningsdelen [`Relaxed`].
    ///
    /// **Note:** Denne metode er kun tilgængelig på platforme, der understøtter atomoperationer på markører.
    ///
    /// # Migrerer til `compare_exchange` og `compare_exchange_weak`
    ///
    /// `compare_and_swap` svarer til `compare_exchange` med følgende kortlægning for hukommelsesbestillinger:
    ///
    /// Original |Succes |Fiasko
    /// -------- | ------- | -------
    /// Afslappet |Afslappet |Afslappet erhverve |Erhverve |Hent frigivelse |Frigivelse |Afslappet AcqRel |AcqRel |Erhverv SeqCst |SeqCst |Sekv
    ///
    /// `compare_exchange_weak` får lov til at mislykkes falskt, selv når sammenligningen lykkes, hvilket gør det muligt for kompilatoren at generere bedre samlingskode, når sammenligningen og swap bruges i en loop.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_and_swap(ptr, other_ptr, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.50.0",
        reason = "Use `compare_exchange` or `compare_exchange_weak` instead"
    )]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_and_swap(&self, current: *mut T, new: *mut T, order: Ordering) -> *mut T {
        match self.compare_exchange(current, new, order, strongest_failure_ordering(order)) {
            Ok(x) => x,
            Err(x) => x,
        }
    }

    /// Gemmer en værdi i markøren, hvis den aktuelle værdi er den samme som `current`-værdien.
    ///
    /// Returneringsværdien er et resultat, der angiver, om den nye værdi blev skrevet og indeholdt den tidligere værdi.
    /// Ved succes er denne værdi garanteret at være lig med `current`.
    ///
    /// `compare_exchange` tager to [`Ordering`] argumenter for at beskrive hukommelsesrækkefølgen for denne operation.
    /// `success` beskriver den krævede rækkefølge for læs-modificer-skriv-operationen, der finder sted, hvis sammenligningen med `current` lykkes.
    /// `failure` beskriver den krævede rækkefølge for den belastning, der finder sted, når sammenligningen mislykkes.
    /// Brug af [`Acquire`] som succesbestilling gør butikken til en del af denne operation [`Relaxed`], og brug af [`Release`] gør den vellykkede belastning [`Relaxed`].
    ///
    /// Fejlbestillingen kan kun være [`SeqCst`], [`Acquire`] eller [`Relaxed`] og skal svare til eller svagere end succesbestillingen.
    ///
    /// **Note:** Denne metode er kun tilgængelig på platforme, der understøtter atomoperationer på markører.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr = &mut 5;
    /// let some_ptr  = AtomicPtr::new(ptr);
    ///
    /// let other_ptr   = &mut 10;
    ///
    /// let value = some_ptr.compare_exchange(ptr, other_ptr,
    ///                                       Ordering::SeqCst, Ordering::Relaxed);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SIKKERHED: dataløb forhindres af atomare iboende egenskaber.
        unsafe { atomic_compare_exchange(self.p.get(), current, new, success, failure) }
    }

    /// Gemmer en værdi i markøren, hvis den aktuelle værdi er den samme som `current`-værdien.
    ///
    /// I modsætning til [`AtomicPtr::compare_exchange`] får denne funktion falske fejl, selv når sammenligningen lykkes, hvilket kan resultere i mere effektiv kode på nogle platforme.
    ///
    /// Returneringsværdien er et resultat, der angiver, om den nye værdi blev skrevet og indeholdt den tidligere værdi.
    ///
    /// `compare_exchange_weak` tager to [`Ordering`] argumenter for at beskrive hukommelsesrækkefølgen for denne operation.
    /// `success` beskriver den krævede rækkefølge for læs-modificer-skriv-operationen, der finder sted, hvis sammenligningen med `current` lykkes.
    /// `failure` beskriver den krævede rækkefølge for den belastning, der finder sted, når sammenligningen mislykkes.
    /// Brug af [`Acquire`] som succesbestilling gør butikken til en del af denne operation [`Relaxed`], og brug af [`Release`] gør den vellykkede belastning [`Relaxed`].
    /// Fejlbestillingen kan kun være [`SeqCst`], [`Acquire`] eller [`Relaxed`] og skal svare til eller svagere end succesbestillingen.
    ///
    /// **Note:** Denne metode er kun tilgængelig på platforme, der understøtter atomoperationer på markører.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let some_ptr = AtomicPtr::new(&mut 5);
    ///
    /// let new = &mut 10;
    /// let mut old = some_ptr.load(Ordering::Relaxed);
    /// loop {
    ///     match some_ptr.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) {
    ///         Ok(_) => break,
    ///         Err(x) => old = x,
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "extended_compare_and_swap", since = "1.10.0")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn compare_exchange_weak(
        &self,
        current: *mut T,
        new: *mut T,
        success: Ordering,
        failure: Ordering,
    ) -> Result<*mut T, *mut T> {
        // SIKKERHED: Dette iboende er usikkert, fordi det fungerer på en rå markør
        // men vi ved med sikkerhed, at markøren er gyldig (vi har lige fået den fra en `UnsafeCell`, som vi har som reference), og selve atomoperationen giver os mulighed for sikkert at mutere `UnsafeCell`-indholdet.
        //
        //
        unsafe { atomic_compare_exchange_weak(self.p.get(), current, new, success, failure) }
    }

    /// Henter værdien og anvender en funktion til den, der returnerer en valgfri ny værdi.Returnerer en `Result` af `Ok(previous_value)`, hvis funktionen returnerede `Some(_)`, ellers `Err(previous_value)`.
    ///
    /// Note: Dette kan muligvis kalde funktionen flere gange, hvis værdien er blevet ændret fra andre tråde i mellemtiden, så længe funktionen returnerer `Some(_)`, men funktionen vil kun være anvendt en gang til den gemte værdi.
    ///
    ///
    /// `fetch_update` tager to [`Ordering`] argumenter for at beskrive hukommelsesrækkefølgen for denne operation.
    /// Den første beskriver den krævede bestilling, når operationen endelig lykkes, mens den anden beskriver den nødvendige bestilling af belastninger.
    /// Disse svarer til henholdsvis succes og fiasko ordrer på [`AtomicPtr::compare_exchange`].
    ///
    /// Brug af [`Acquire`] som succesbestilling gør butikken til en del af denne operation [`Relaxed`], og brug af [`Release`] gør den endelige vellykkede belastning [`Relaxed`].
    /// (failed)-belastningsbestilling kan kun være [`SeqCst`], [`Acquire`] eller [`Relaxed`] og skal svare til eller svagere end succesbestillingen.
    ///
    /// **Note:** Denne metode er kun tilgængelig på platforme, der understøtter atomoperationer på markører.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(atomic_fetch_update)]
    /// use std::sync::atomic::{AtomicPtr, Ordering};
    ///
    /// let ptr: *mut _ = &mut 5;
    /// let some_ptr = AtomicPtr::new(ptr);
    ///
    /// let new: *mut _ = &mut 10;
    /// assert_eq!(some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(ptr));
    /// let result = some_ptr.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |x| {
    ///     if x == ptr {
    ///         Some(new)
    ///     } else {
    ///         None
    ///     }
    /// });
    /// assert_eq!(result, Ok(ptr));
    /// assert_eq!(some_ptr.load(Ordering::SeqCst), new);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "atomic_fetch_update", reason = "recently added", issue = "78639")]
    #[cfg(target_has_atomic = "ptr")]
    pub fn fetch_update<F>(
        &self,
        set_order: Ordering,
        fetch_order: Ordering,
        mut f: F,
    ) -> Result<*mut T, *mut T>
    where
        F: FnMut(*mut T) -> Option<*mut T>,
    {
        let mut prev = self.load(fetch_order);
        while let Some(next) = f(prev) {
            match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                x @ Ok(_) => return x,
                Err(next_prev) => prev = next_prev,
            }
        }
        Err(prev)
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_bool_from", since = "1.24.0")]
impl From<bool> for AtomicBool {
    /// Konverterer en `bool` til en `AtomicBool`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::atomic::AtomicBool;
    /// let atomic_bool = AtomicBool::from(true);
    /// assert_eq!(format!("{:?}", atomic_bool), "true")
    /// ```
    #[inline]
    fn from(b: bool) -> Self {
        Self::new(b)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_from", since = "1.23.0")]
impl<T> From<*mut T> for AtomicPtr<T> {
    #[inline]
    fn from(p: *mut T) -> Self {
        Self::new(p)
    }
}

#[allow(unused_macros)] // Denne makro ender med at være ubrugt i nogle arkitekturer.
macro_rules! if_not_8_bit {
    (u8, $($tt:tt)*) => { "" };
    (i8, $($tt:tt)*) => { "" };
    ($_:ident, $($tt:tt)*) => { $($tt)* };
}

#[cfg(target_has_atomic_load_store = "8")]
macro_rules! atomic_int {
    ($cfg_cas:meta,
     $cfg_align:meta,
     $stable:meta,
     $stable_cxchg:meta,
     $stable_debug:meta,
     $stable_access:meta,
     $stable_from:meta,
     $stable_nand:meta,
     $const_stable:meta,
     $stable_init_const:meta,
     $s_int_type:literal,
     $extra_feature:expr,
     $min_fn:ident, $max_fn:ident,
     $align:expr,
     $atomic_new:expr,
     $int_type:ident $atomic_type:ident $atomic_init:ident) => {
        /// En heltalstype, som sikkert kan deles mellem tråde.
        ///
        /// Denne type har den samme repræsentation i hukommelsen som den underliggende heltalstype, ['
        ///
        #[doc = $s_int_type]
        /// `].
        /// For mere om forskellene mellem atomtyper og ikke-atomare typer samt information om bærbarhed af denne type, se [module-level documentation].
        ///
        ///
        /// **Note:** Denne type er kun tilgængelig på platforme, der understøtter atombelastninger og lagre af [`
        ///
        #[doc = $s_int_type]
        /// `].
        ///
        /// [module-level documentation]: crate::sync::atomic
        #[$stable]
        #[repr(C, align($align))]
        pub struct $atomic_type {
            v: UnsafeCell<$int_type>,
        }

        /// Et atomært heltal initialiseret til `0`.
        #[$stable_init_const]
        #[rustc_deprecated(
            since = "1.34.0",
            reason = "the `new` function is now preferred",
            suggestion = $atomic_new,
        )]
        pub const $atomic_init: $atomic_type = $atomic_type::new(0);

        #[$stable]
        impl Default for $atomic_type {
            #[inline]
            fn default() -> Self {
                Self::new(Default::default())
            }
        }

        #[$stable_from]
        impl From<$int_type> for $atomic_type {
            #[doc = concat!("Converts an `", stringify!($int_type), "` into an `", stringify!($atomic_type), "`.")]
            #[inline]
            fn from(v: $int_type) -> Self { Self::new(v) }
        }

        #[$stable_debug]
        impl fmt::Debug for $atomic_type {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
            }
        }

        // Send implementeres implicit.
        #[$stable]
        unsafe impl Sync for $atomic_type {}

        impl $atomic_type {
            /// Opretter et nyt atomært heltal.
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let atomic_forty_two = ", stringify!($atomic_type), "::new(42);")]
            /// ```
            #[inline]
            #[$stable]
            #[$const_stable]
            pub const fn new(v: $int_type) -> Self {
                Self {v: UnsafeCell::new(v)}
            }

            /// Returnerer en ændret henvisning til det underliggende heltal.
            ///
            /// Dette er sikkert, fordi den ændrede reference garanterer, at ingen andre tråde samtidig har adgang til atommasserne.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let mut some_var = ", stringify!($atomic_type), "::new(10);")]
            /// assert_eq!(*some_var.get_mut(), 10);
            /// *some_var.get_mut() =5;
            /// assert_eq!(some_var.load(Ordering::SeqCst), 5);
            /// ```
            #[inline]
            #[$stable_access]
            pub fn get_mut(&mut self) -> &mut $int_type {
                self.v.get_mut()
            }

            #[doc = concat!("Get atomic access to a `&mut ", stringify!($int_type), "`.")]

            #[doc = if_not_8_bit! {
                $int_type,
                concat!(
                    "**Note:** This function is only available on targets where `",
                    stringify!($int_type), "` has an alignment of ", $align, " bytes."
                )
            }]
            /// # Examples
            ///
            /// ```
            /// #![feature(atomic_from_mut)]
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]
            /// lad mut noget_int=123;
            #[doc = concat!("let a = ", stringify!($atomic_type), "::from_mut(&mut some_int);")]
            /// a.store(100, Ordering::Relaxed);
            ///
            /// assert_eq! (noget_int, 100);
            /// ```
            #[inline]
            #[$cfg_align]
            #[unstable(feature = "atomic_from_mut", issue = "76314")]
            pub fn from_mut(v: &mut $int_type) -> &Self {
                use crate::mem::align_of;
                let [] = [(); align_of::<Self>() - align_of::<$int_type>()];
                // SAFETY:
                //  - den ændrede reference garanterer unikt ejerskab.
                //  - tilpasningen af `$int_type` og `Self` er den samme, som lovet af $cfg_align og bekræftet ovenfor.
                //
                unsafe { &*(v as *mut $int_type as *mut Self) }
            }

            /// Forbruger atomerne og returnerer den indeholdte værdi.
            ///
            /// Dette er sikkert, fordi overførsel af `self` efter værdi garanterer, at ingen andre tråde samtidig har adgang til atomdata.
            ///
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.into_inner(), 5);
            /// ```
            #[inline]
            #[$stable_access]
            #[rustc_const_unstable(feature = "const_cell_into_inner", issue = "78729")]
            pub const fn into_inner(self) -> $int_type {
                self.v.into_inner()
            }

            /// Indlæser en værdi fra det atomare heltal.
            ///
            /// `load` tager et [`Ordering`]-argument, der beskriver hukommelsesrækkefølgen for denne operation.
            /// Mulige værdier er [`SeqCst`], [`Acquire`] og [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics hvis `order` er [`Release`] eller [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.load(Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            pub fn load(&self, order: Ordering) -> $int_type {
                // SIKKERHED: dataløb forhindres af atomare iboende egenskaber.
                unsafe { atomic_load(self.v.get(), order) }
            }

            /// Gemmer en værdi i det atomare heltal.
            ///
            /// `store` tager et [`Ordering`]-argument, der beskriver hukommelsesrækkefølgen for denne operation.
            ///  Mulige værdier er [`SeqCst`], [`Release`] og [`Relaxed`].
            ///
            /// # Panics
            ///
            /// Panics hvis `order` er [`Acquire`] eller [`AcqRel`].
            ///
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// some_var.store(10, Ordering::Relaxed);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            pub fn store(&self, val: $int_type, order: Ordering) {
                // SIKKERHED: dataløb forhindres af atomare iboende egenskaber.
                unsafe { atomic_store(self.v.get(), val, order); }
            }

            /// Gemmer en værdi i det atomare heltal og returnerer den tidligere værdi.
            ///
            /// `swap` tager et [`Ordering`]-argument, der beskriver hukommelsesrækkefølgen for denne operation.Alle bestillingstilstande er mulige.
            /// Bemærk, at brug af [`Acquire`] gør butikken til en del af denne operation [`Relaxed`], og brug af [`Release`] gør belastningsdelen [`Relaxed`].
            ///
            ///
            /// **Bemærk**: Denne metode er kun tilgængelig på platforme, der understøtter atomoperationer på
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.swap(10, Ordering::Relaxed), 5);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn swap(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIKKERHED: dataløb forhindres af atomare iboende egenskaber.
                unsafe { atomic_swap(self.v.get(), val, order) }
            }

            /// Gemmer en værdi i det atomare heltal, hvis den aktuelle værdi er den samme som `current`-værdien.
            ///
            /// Returneringsværdien er altid den forrige værdi.Hvis det er lig med `current`, blev værdien opdateret.
            ///
            /// `compare_and_swap` tager også et [`Ordering`]-argument, der beskriver hukommelsesrækkefølgen for denne operation.
            /// Bemærk, at selv når du bruger [`AcqRel`], kan operationen muligvis mislykkes og derfor bare udføre en `Acquire`-belastning, men ikke have `Release`-semantik.
            ///
            /// Brug af [`Acquire`] gør butikken til en del af denne operation [`Relaxed`], hvis det sker, og brug af [`Release`] gør belastningsdelen [`Relaxed`].
            ///
            /// **Bemærk**: Denne metode er kun tilgængelig på platforme, der understøtter atomoperationer på
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Migrerer til `compare_exchange` og `compare_exchange_weak`
            ///
            /// `compare_and_swap` svarer til `compare_exchange` med følgende kortlægning for hukommelsesbestillinger:
            ///
            /// Original |Succes |Fiasko
            /// -------- | ------- | -------
            /// Afslappet |Afslappet |Afslappet erhverve |Erhverve |Hent frigivelse |Frigivelse |Afslappet AcqRel |AcqRel |Erhverv SeqCst |SeqCst |Sekv
            ///
            /// `compare_exchange_weak` får lov til at mislykkes falskt, selv når sammenligningen lykkes, hvilket gør det muligt for kompilatoren at generere bedre samlingskode, når sammenligningen og swap bruges i en loop.
            ///
            ///
            /// # Examples
            ///
            /// ```
            ///
            ///
            ///
            ///
            ///
            ///
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_and_swap(5, 10, Ordering::Relaxed), 5);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_and_swap(6, 12, Ordering::Relaxed), 10);
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            #[inline]
            #[$stable]
            #[rustc_deprecated(
                since = "1.50.0",
                reason = "Use `compare_exchange` or `compare_exchange_weak` instead")
            ]
            #[$cfg_cas]
            pub fn compare_and_swap(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    order: Ordering) -> $int_type {
                match self.compare_exchange(current,
                                            new,
                                            order,
                                            strongest_failure_ordering(order)) {
                    Ok(x) => x,
                    Err(x) => x,
                }
            }

            /// Gemmer en værdi i det atomare heltal, hvis den aktuelle værdi er den samme som `current`-værdien.
            ///
            /// Returneringsværdien er et resultat, der angiver, om den nye værdi blev skrevet og indeholdt den tidligere værdi.
            /// Ved succes er denne værdi garanteret at være lig med `current`.
            ///
            /// `compare_exchange` tager to [`Ordering`] argumenter for at beskrive hukommelsesrækkefølgen for denne operation.
            /// `success` beskriver den krævede rækkefølge for læs-modificer-skriv-operationen, der finder sted, hvis sammenligningen med `current` lykkes.
            /// `failure` beskriver den krævede rækkefølge for den belastning, der finder sted, når sammenligningen mislykkes.
            /// Brug af [`Acquire`] som succesbestilling gør butikken til en del af denne operation [`Relaxed`], og brug af [`Release`] gør den vellykkede belastning [`Relaxed`].
            ///
            /// Fejlbestillingen kan kun være [`SeqCst`], [`Acquire`] eller [`Relaxed`] og skal svare til eller svagere end succesbestillingen.
            ///
            /// **Bemærk**: Denne metode er kun tilgængelig på platforme, der understøtter atomoperationer på
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let some_var = ", stringify!($atomic_type), "::new(5);")]
            /// assert_eq!(some_var.compare_exchange(5, 10,                                      Ordering::Acquire,                                      Ordering::Relaxed),
            ///
            ///            Ok(5));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            ///
            /// assert_eq!(some_var.compare_exchange(6, 12,                                      Ordering::SeqCst,                                      Ordering::Acquire),
            ///            Err(10));
            /// assert_eq!(some_var.load(Ordering::Relaxed), 10);
            /// ```
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange(&self,
                                    current: $int_type,
                                    new: $int_type,
                                    success: Ordering,
                                    failure: Ordering) -> Result<$int_type, $int_type> {
                // SIKKERHED: dataløb forhindres af atomare iboende egenskaber.
                unsafe { atomic_compare_exchange(self.v.get(), current, new, success, failure) }
            }

            /// Gemmer en værdi i det atomare heltal, hvis den aktuelle værdi er den samme som `current`-værdien.
            ///
            ///
            #[doc = concat!("Unlike [`", stringify!($atomic_type), "::compare_exchange`],")]
            /// denne funktion får falsk mislykkes, selv når sammenligningen lykkes, hvilket kan resultere i mere effektiv kode på nogle platforme.
            /// Returneringsværdien er et resultat, der angiver, om den nye værdi blev skrevet og indeholdt den tidligere værdi.
            ///
            /// `compare_exchange_weak` tager to [`Ordering`] argumenter for at beskrive hukommelsesrækkefølgen for denne operation.
            /// `success` beskriver den krævede rækkefølge for læs-modificer-skriv-operationen, der finder sted, hvis sammenligningen med `current` lykkes.
            /// `failure` beskriver den krævede rækkefølge for den belastning, der finder sted, når sammenligningen mislykkes.
            /// Brug af [`Acquire`] som succesbestilling gør butikken til en del af denne operation [`Relaxed`], og brug af [`Release`] gør den vellykkede belastning [`Relaxed`].
            ///
            /// Fejlbestillingen kan kun være [`SeqCst`], [`Acquire`] eller [`Relaxed`] og skal svare til eller svagere end succesbestillingen.
            ///
            /// **Bemærk**: Denne metode er kun tilgængelig på platforme, der understøtter atomoperationer på
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let val = ", stringify!($atomic_type), "::new(4);")]
            /// lad mut gamle= val.load(Ordering::Relaxed);
            /// loop {lad nyt=gammel * 2;
            ///     match val.compare_exchange_weak(old, new, Ordering::SeqCst, Ordering::Relaxed) { Ok(_) => break, Err(x) => old = x, }}
            ///
            /// ```
            ///
            ///
            ///
            ///
            #[inline]
            #[$stable_cxchg]
            #[$cfg_cas]
            pub fn compare_exchange_weak(&self,
                                         current: $int_type,
                                         new: $int_type,
                                         success: Ordering,
                                         failure: Ordering) -> Result<$int_type, $int_type> {
                // SIKKERHED: dataløb forhindres af atomare iboende egenskaber.
                unsafe {
                    atomic_compare_exchange_weak(self.v.get(), current, new, success, failure)
                }
            }

            /// Føjes til den aktuelle værdi og returnerer den forrige værdi.
            ///
            /// Denne operation ombrydes ved overløb.
            ///
            /// `fetch_add` tager et [`Ordering`]-argument, der beskriver hukommelsesrækkefølgen for denne operation.Alle bestillingstilstande er mulige.
            /// Bemærk, at brug af [`Acquire`] gør butikken til en del af denne operation [`Relaxed`], og brug af [`Release`] gør belastningsdelen [`Relaxed`].
            ///
            ///
            /// **Bemærk**: Denne metode er kun tilgængelig på platforme, der understøtter atomoperationer på
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0);")]
            /// assert_eq!(foo.fetch_add(10, Ordering::SeqCst), 0);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_add(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIKKERHED: dataløb forhindres af atomare iboende egenskaber.
                unsafe { atomic_add(self.v.get(), val, order) }
            }

            /// Trækker fra den aktuelle værdi og returnerer den tidligere værdi.
            ///
            /// Denne operation ombrydes ved overløb.
            ///
            /// `fetch_sub` tager et [`Ordering`]-argument, der beskriver hukommelsesrækkefølgen for denne operation.Alle bestillingstilstande er mulige.
            /// Bemærk, at brug af [`Acquire`] gør butikken til en del af denne operation [`Relaxed`], og brug af [`Release`] gør belastningsdelen [`Relaxed`].
            ///
            ///
            /// **Bemærk**: Denne metode er kun tilgængelig på platforme, der understøtter atomoperationer på
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(20);")]
            /// assert_eq!(foo.fetch_sub(10, Ordering::SeqCst), 20);
            /// assert_eq!(foo.load(Ordering::SeqCst), 10);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_sub(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIKKERHED: dataløb forhindres af atomare iboende egenskaber.
                unsafe { atomic_sub(self.v.get(), val, order) }
            }

            /// Bitvis "and" med den aktuelle værdi.
            ///
            /// Udfører en bitvis "and"-operation på den aktuelle værdi og argumentet `val` og indstiller den nye værdi til resultatet.
            ///
            /// Returnerer den forrige værdi.
            ///
            /// `fetch_and` tager et [`Ordering`]-argument, der beskriver hukommelsesrækkefølgen for denne operation.Alle bestillingstilstande er mulige.
            /// Bemærk, at brug af [`Acquire`] gør butikken til en del af denne operation [`Relaxed`], og brug af [`Release`] gør belastningsdelen [`Relaxed`].
            ///
            ///
            /// **Bemærk**: Denne metode er kun tilgængelig på platforme, der understøtter atomoperationer på
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_and(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b100001);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_and(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIKKERHED: dataløb forhindres af atomare iboende egenskaber.
                unsafe { atomic_and(self.v.get(), val, order) }
            }

            /// Bitvis "nand" med den aktuelle værdi.
            ///
            /// Udfører en bitvis "nand"-operation på den aktuelle værdi og argumentet `val` og indstiller den nye værdi til resultatet.
            ///
            /// Returnerer den forrige værdi.
            ///
            /// `fetch_nand` tager et [`Ordering`]-argument, der beskriver hukommelsesrækkefølgen for denne operation.Alle bestillingstilstande er mulige.
            /// Bemærk, at brug af [`Acquire`] gør butikken til en del af denne operation [`Relaxed`], og brug af [`Release`] gør belastningsdelen [`Relaxed`].
            ///
            ///
            /// **Bemærk**: Denne metode er kun tilgængelig på platforme, der understøtter atomoperationer på
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0x13);")]
            /// assert_eq!(foo.fetch_nand(0x31, Ordering::SeqCst), 0x13);
            /// assert_eq!(foo.load(Ordering::SeqCst), ! (0x13&0x31));
            /// ```
            #[inline]
            #[$stable_nand]
            #[$cfg_cas]
            pub fn fetch_nand(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIKKERHED: dataløb forhindres af atomare iboende egenskaber.
                unsafe { atomic_nand(self.v.get(), val, order) }
            }

            /// Bitvis "or" med den aktuelle værdi.
            ///
            /// Udfører en bitvis "or"-operation på den aktuelle værdi og argumentet `val` og indstiller den nye værdi til resultatet.
            ///
            /// Returnerer den forrige værdi.
            ///
            /// `fetch_or` tager et [`Ordering`]-argument, der beskriver hukommelsesrækkefølgen for denne operation.Alle bestillingstilstande er mulige.
            /// Bemærk, at brug af [`Acquire`] gør butikken til en del af denne operation [`Relaxed`], og brug af [`Release`] gør belastningsdelen [`Relaxed`].
            ///
            ///
            /// **Bemærk**: Denne metode er kun tilgængelig på platforme, der understøtter atomoperationer på
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_or(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b111111);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_or(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIKKERHED: dataløb forhindres af atomare iboende egenskaber.
                unsafe { atomic_or(self.v.get(), val, order) }
            }

            /// Bitvis "xor" med den aktuelle værdi.
            ///
            /// Udfører en bitvis "xor"-operation på den aktuelle værdi og argumentet `val` og indstiller den nye værdi til resultatet.
            ///
            /// Returnerer den forrige værdi.
            ///
            /// `fetch_xor` tager et [`Ordering`]-argument, der beskriver hukommelsesrækkefølgen for denne operation.Alle bestillingstilstande er mulige.
            /// Bemærk, at brug af [`Acquire`] gør butikken til en del af denne operation [`Relaxed`], og brug af [`Release`] gør belastningsdelen [`Relaxed`].
            ///
            ///
            /// **Bemærk**: Denne metode er kun tilgængelig på platforme, der understøtter atomoperationer på
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(0b101101);")]
            /// assert_eq!(foo.fetch_xor(0b110011, Ordering::SeqCst), 0b101101);
            /// assert_eq!(foo.load(Ordering::SeqCst), 0b011110);
            /// ```
            #[inline]
            #[$stable]
            #[$cfg_cas]
            pub fn fetch_xor(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIKKERHED: dataløb forhindres af atomare iboende egenskaber.
                unsafe { atomic_xor(self.v.get(), val, order) }
            }

            /// Henter værdien og anvender en funktion til den, der returnerer en valgfri ny værdi.Returnerer en `Result` af `Ok(previous_value)`, hvis funktionen returnerede `Some(_)`, ellers `Err(previous_value)`.
            ///
            /// Note: Dette kan muligvis kalde funktionen flere gange, hvis værdien er blevet ændret fra andre tråde i mellemtiden, så længe funktionen returnerer `Some(_)`, men funktionen vil kun være anvendt en gang til den gemte værdi.
            ///
            ///
            /// `fetch_update` tager to [`Ordering`] argumenter for at beskrive hukommelsesrækkefølgen for denne operation.
            /// Den første beskriver den krævede bestilling, når operationen endelig lykkes, mens den anden beskriver den nødvendige bestilling af belastninger.Disse svarer til succes og fiasko ordrer fra
            ///
            ///
            ///
            ///
            #[doc = concat!("[`", stringify!($atomic_type), "::compare_exchange`]")]
            /// respectively.
            ///
            /// Brug af [`Acquire`] som succesbestilling gør butikken til en del af denne operation [`Relaxed`], og brug af [`Release`] gør den endelige vellykkede belastning [`Relaxed`].
            /// (failed)-belastningsbestilling kan kun være [`SeqCst`], [`Acquire`] eller [`Relaxed`] og skal svare til eller svagere end succesbestillingen.
            ///
            /// **Bemærk**: Denne metode er kun tilgængelig på platforme, der understøtter atomoperationer på
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```rust
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let x = ", stringify!($atomic_type), "::new(7);")]
            /// assert_eq!(x.fetch_update(Ordering::SeqCst, Ordering::SeqCst, |_| None), Err(7));
            /// assert_eq! (x.fetch_update (Bestilling: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(7));
            /// assert_eq! (x.fetch_update (Bestilling: : SeqCst, Ordering::SeqCst, | x | Some(x + 1)), Ok(8));
            /// assert_eq!(x.load(Ordering::SeqCst), 9);
            /// ```
            #[inline]
            #[stable(feature = "no_more_cas", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_update<F>(&self,
                                   set_order: Ordering,
                                   fetch_order: Ordering,
                                   mut f: F) -> Result<$int_type, $int_type>
            where F: FnMut($int_type) -> Option<$int_type> {
                let mut prev = self.load(fetch_order);
                while let Some(next) = f(prev) {
                    match self.compare_exchange_weak(prev, next, set_order, fetch_order) {
                        x @ Ok(_) => return x,
                        Err(next_prev) => prev = next_prev
                    }
                }
                Err(prev)
            }

            /// Maksimum med den aktuelle værdi.
            ///
            /// Finder det maksimale af den aktuelle værdi og argumentet `val` og indstiller den nye værdi til resultatet.
            ///
            /// Returnerer den forrige værdi.
            ///
            /// `fetch_max` tager et [`Ordering`]-argument, der beskriver hukommelsesrækkefølgen for denne operation.Alle bestillingstilstande er mulige.
            /// Bemærk, at brug af [`Acquire`] gør butikken til en del af denne operation [`Relaxed`], og brug af [`Release`] gør belastningsdelen [`Relaxed`].
            ///
            ///
            /// **Bemærk**: Denne metode er kun tilgængelig på platforme, der understøtter atomoperationer på
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_max(42, Ordering::SeqCst), 23);
            /// assert_eq!(foo.load(Ordering::SeqCst), 42);
            /// ```
            ///
            /// If you want to obtain the maximum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// lad bar=42;
            /// lad max_foo=foo.fetch_max (bar, Ordering::SeqCst).max(bar);
            /// hævde! (max_foo==42);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_max(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIKKERHED: dataløb forhindres af atomare iboende egenskaber.
                unsafe { $max_fn(self.v.get(), val, order) }
            }

            /// Minimum med den aktuelle værdi.
            ///
            /// Finder minimumet af den aktuelle værdi og argumentet `val` og indstiller den nye værdi til resultatet.
            ///
            /// Returnerer den forrige værdi.
            ///
            /// `fetch_min` tager et [`Ordering`]-argument, der beskriver hukommelsesrækkefølgen for denne operation.Alle bestillingstilstande er mulige.
            /// Bemærk, at brug af [`Acquire`] gør butikken til en del af denne operation [`Relaxed`], og brug af [`Release`] gør belastningsdelen [`Relaxed`].
            ///
            ///
            /// **Bemærk**: Denne metode er kun tilgængelig på platforme, der understøtter atomoperationer på
            ///
            ///
            #[doc = concat!("[`", $s_int_type, "`].")]
            /// # Examples
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// assert_eq!(foo.fetch_min(42, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 23);
            /// assert_eq!(foo.fetch_min(22, Ordering::Relaxed), 23);
            /// assert_eq!(foo.load(Ordering::Relaxed), 22);
            /// ```
            ///
            /// If you want to obtain the minimum value in one step, you can use the following:
            ///
            /// ```
            #[doc = concat!($extra_feature, "use std::sync::atomic::{", stringify!($atomic_type), ", Ordering};")]

            #[doc = concat!("let foo = ", stringify!($atomic_type), "::new(23);")]
            /// lad bar=12;
            /// lad min_foo=foo.fetch_min (bar, Ordering::SeqCst).min(bar);
            /// assert_eq! (min_foo, 12);
            /// ```
            #[inline]
            #[stable(feature = "atomic_min_max", since = "1.45.0")]
            #[$cfg_cas]
            pub fn fetch_min(&self, val: $int_type, order: Ordering) -> $int_type {
                // SIKKERHED: dataløb forhindres af atomare iboende egenskaber.
                unsafe { $min_fn(self.v.get(), val, order) }
            }

            /// Returnerer en ændret markør til det underliggende heltal.
            ///
            /// At lave ikke-atomare læser og skriver på det resulterende heltal kan være et dataløb.
            /// Denne metode er mest nyttig til FFI, hvor funktionssignaturen muligvis bruger
            #[doc = concat!("`*mut ", stringify!($int_type), "` instead of `&", stringify!($atomic_type), "`.")]
            /// Det er sikkert at returnere en `*mut`-markør fra en fælles henvisning til dette atom, fordi atomtyperne arbejder med indre mutabilitet.
            /// Alle ændringer af et atom ændrer værdien gennem en delt reference og kan gøre det sikkert, så længe de bruger atomoperationer.
            /// Enhver brug af den returnerede rå markør kræver en `unsafe`-blok og skal stadig opretholde den samme begrænsning: operationer på den skal være atomare.
            ///
            ///
            /// # Examples
            ///
            /// `` ignorere (extern-declaration)
            ///
            /// # fn main() {
            #[doc = concat!($extra_feature, "use std::sync::atomic::", stringify!($atomic_type), ";")]
            /// ekstern "C" {
            #[doc = concat!("    fn my_atomic_op(arg: *mut ", stringify!($int_type), ");")]
            /// }
            ///
            #[doc = concat!("let mut atomic = ", stringify!($atomic_type), "::new(1);")]

            // SIKKERHED: Sikker, så længe `my_atomic_op` er atomær.
            /// usikre {
            ///     my_atomic_op(atomic.as_mut_ptr());
            /// }
            /// # }
            /// ```
            #[inline]
            #[unstable(feature = "atomic_mut_ptr",
                   reason = "recently added",
                   issue = "66893")]
            pub fn as_mut_ptr(&self) -> *mut $int_type {
                self.v.get()
            }
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i8",
    "",
    atomic_min, atomic_max,
    1,
    "AtomicI8::new(0)",
    i8 AtomicI8 ATOMIC_I8_INIT
}
#[cfg(target_has_atomic_load_store = "8")]
atomic_int! {
    cfg(target_has_atomic = "8"),
    cfg(target_has_atomic_equal_alignment = "8"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u8",
    "",
    atomic_umin, atomic_umax,
    1,
    "AtomicU8::new(0)",
    u8 AtomicU8 ATOMIC_U8_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i16",
    "",
    atomic_min, atomic_max,
    2,
    "AtomicI16::new(0)",
    i16 AtomicI16 ATOMIC_I16_INIT
}
#[cfg(target_has_atomic_load_store = "16")]
atomic_int! {
    cfg(target_has_atomic = "16"),
    cfg(target_has_atomic_equal_alignment = "16"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u16",
    "",
    atomic_umin, atomic_umax,
    2,
    "AtomicU16::new(0)",
    u16 AtomicU16 ATOMIC_U16_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i32",
    "",
    atomic_min, atomic_max,
    4,
    "AtomicI32::new(0)",
    i32 AtomicI32 ATOMIC_I32_INIT
}
#[cfg(target_has_atomic_load_store = "32")]
atomic_int! {
    cfg(target_has_atomic = "32"),
    cfg(target_has_atomic_equal_alignment = "32"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u32",
    "",
    atomic_umin, atomic_umax,
    4,
    "AtomicU32::new(0)",
    u32 AtomicU32 ATOMIC_U32_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i64",
    "",
    atomic_min, atomic_max,
    8,
    "AtomicI64::new(0)",
    i64 AtomicI64 ATOMIC_I64_INIT
}
#[cfg(target_has_atomic_load_store = "64")]
atomic_int! {
    cfg(target_has_atomic = "64"),
    cfg(target_has_atomic_equal_alignment = "64"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    stable(feature = "integer_atomics_stable", since = "1.34.0"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u64",
    "",
    atomic_umin, atomic_umax,
    8,
    "AtomicU64::new(0)",
    u64 AtomicU64 ATOMIC_U64_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "i128",
    "#![feature(integer_atomics)]\n\n",
    atomic_min, atomic_max,
    16,
    "AtomicI128::new(0)",
    i128 AtomicI128 ATOMIC_I128_INIT
}
#[cfg(target_has_atomic_load_store = "128")]
atomic_int! {
    cfg(target_has_atomic = "128"),
    cfg(target_has_atomic_equal_alignment = "128"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    unstable(feature = "integer_atomics", issue = "32976"),
    rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
    unstable(feature = "integer_atomics", issue = "32976"),
    "u128",
    "#![feature(integer_atomics)]\n\n",
    atomic_umin, atomic_umax,
    16,
    "AtomicU128::new(0)",
    u128 AtomicU128 ATOMIC_U128_INIT
}

macro_rules! atomic_int_ptr_sized {
    ( $($target_pointer_width:literal $align:literal)* ) => { $(
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "isize",
            "",
            atomic_min, atomic_max,
            $align,
            "AtomicIsize::new(0)",
            isize AtomicIsize ATOMIC_ISIZE_INIT
        }
        #[cfg(target_has_atomic_load_store = "ptr")]
        #[cfg(target_pointer_width = $target_pointer_width)]
        atomic_int! {
            cfg(target_has_atomic = "ptr"),
            cfg(target_has_atomic_equal_alignment = "ptr"),
            stable(feature = "rust1", since = "1.0.0"),
            stable(feature = "extended_compare_and_swap", since = "1.10.0"),
            stable(feature = "atomic_debug", since = "1.3.0"),
            stable(feature = "atomic_access", since = "1.15.0"),
            stable(feature = "atomic_from", since = "1.23.0"),
            stable(feature = "atomic_nand", since = "1.27.0"),
            rustc_const_stable(feature = "const_integer_atomics", since = "1.34.0"),
            stable(feature = "rust1", since = "1.0.0"),
            "usize",
            "",
            atomic_umin, atomic_umax,
            $align,
            "AtomicUsize::new(0)",
            usize AtomicUsize ATOMIC_USIZE_INIT
        }
    )* };
}

atomic_int_ptr_sized! {
    "16" 2
    "32" 4
    "64" 8
}

#[inline]
#[cfg(target_has_atomic = "8")]
fn strongest_failure_ordering(order: Ordering) -> Ordering {
    match order {
        Release => Relaxed,
        Relaxed => Relaxed,
        SeqCst => SeqCst,
        Acquire => Acquire,
        AcqRel => Acquire,
    }
}

#[inline]
unsafe fn atomic_store<T: Copy>(dst: *mut T, val: T, order: Ordering) {
    // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `atomic_store`.
    unsafe {
        match order {
            Release => intrinsics::atomic_store_rel(dst, val),
            Relaxed => intrinsics::atomic_store_relaxed(dst, val),
            SeqCst => intrinsics::atomic_store(dst, val),
            Acquire => panic!("there is no such thing as an acquire store"),
            AcqRel => panic!("there is no such thing as an acquire/release store"),
        }
    }
}

#[inline]
unsafe fn atomic_load<T: Copy>(dst: *const T, order: Ordering) -> T {
    // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `atomic_load`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_load_acq(dst),
            Relaxed => intrinsics::atomic_load_relaxed(dst),
            SeqCst => intrinsics::atomic_load(dst),
            Release => panic!("there is no such thing as a release load"),
            AcqRel => panic!("there is no such thing as an acquire/release load"),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_swap<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `atomic_swap`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xchg_acq(dst, val),
            Release => intrinsics::atomic_xchg_rel(dst, val),
            AcqRel => intrinsics::atomic_xchg_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xchg_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xchg(dst, val),
        }
    }
}

/// Returnerer den forrige værdi (som __sync_fetch_and_add).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_add<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `atomic_add`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xadd_acq(dst, val),
            Release => intrinsics::atomic_xadd_rel(dst, val),
            AcqRel => intrinsics::atomic_xadd_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xadd_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xadd(dst, val),
        }
    }
}

/// Returnerer den forrige værdi (som __sync_fetch_and_sub).
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_sub<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `atomic_sub`.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xsub_acq(dst, val),
            Release => intrinsics::atomic_xsub_rel(dst, val),
            AcqRel => intrinsics::atomic_xsub_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xsub_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xsub(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `atomic_compare_exchange`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchg_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchg_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchg_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchg_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchg(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchg_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchg_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchg_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchg_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_compare_exchange_weak<T: Copy>(
    dst: *mut T,
    old: T,
    new: T,
    success: Ordering,
    failure: Ordering,
) -> Result<T, T> {
    // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `atomic_compare_exchange_weak`.
    let (val, ok) = unsafe {
        match (success, failure) {
            (Acquire, Acquire) => intrinsics::atomic_cxchgweak_acq(dst, old, new),
            (Release, Relaxed) => intrinsics::atomic_cxchgweak_rel(dst, old, new),
            (AcqRel, Acquire) => intrinsics::atomic_cxchgweak_acqrel(dst, old, new),
            (Relaxed, Relaxed) => intrinsics::atomic_cxchgweak_relaxed(dst, old, new),
            (SeqCst, SeqCst) => intrinsics::atomic_cxchgweak(dst, old, new),
            (Acquire, Relaxed) => intrinsics::atomic_cxchgweak_acq_failrelaxed(dst, old, new),
            (AcqRel, Relaxed) => intrinsics::atomic_cxchgweak_acqrel_failrelaxed(dst, old, new),
            (SeqCst, Relaxed) => intrinsics::atomic_cxchgweak_failrelaxed(dst, old, new),
            (SeqCst, Acquire) => intrinsics::atomic_cxchgweak_failacq(dst, old, new),
            (_, AcqRel) => panic!("there is no such thing as an acquire/release failure ordering"),
            (_, Release) => panic!("there is no such thing as a release failure ordering"),
            _ => panic!("a failure ordering can't be stronger than a success ordering"),
        }
    };
    if ok { Ok(val) } else { Err(val) }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_and<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `atomic_and`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_and_acq(dst, val),
            Release => intrinsics::atomic_and_rel(dst, val),
            AcqRel => intrinsics::atomic_and_acqrel(dst, val),
            Relaxed => intrinsics::atomic_and_relaxed(dst, val),
            SeqCst => intrinsics::atomic_and(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_nand<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `atomic_nand`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_nand_acq(dst, val),
            Release => intrinsics::atomic_nand_rel(dst, val),
            AcqRel => intrinsics::atomic_nand_acqrel(dst, val),
            Relaxed => intrinsics::atomic_nand_relaxed(dst, val),
            SeqCst => intrinsics::atomic_nand(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_or<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `atomic_or`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_or_acq(dst, val),
            Release => intrinsics::atomic_or_rel(dst, val),
            AcqRel => intrinsics::atomic_or_acqrel(dst, val),
            Relaxed => intrinsics::atomic_or_relaxed(dst, val),
            SeqCst => intrinsics::atomic_or(dst, val),
        }
    }
}

#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_xor<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `atomic_xor`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_xor_acq(dst, val),
            Release => intrinsics::atomic_xor_rel(dst, val),
            AcqRel => intrinsics::atomic_xor_acqrel(dst, val),
            Relaxed => intrinsics::atomic_xor_relaxed(dst, val),
            SeqCst => intrinsics::atomic_xor(dst, val),
        }
    }
}

/// returnerer den maksimale værdi (underskrevet sammenligning)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_max<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `atomic_max`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_max_acq(dst, val),
            Release => intrinsics::atomic_max_rel(dst, val),
            AcqRel => intrinsics::atomic_max_acqrel(dst, val),
            Relaxed => intrinsics::atomic_max_relaxed(dst, val),
            SeqCst => intrinsics::atomic_max(dst, val),
        }
    }
}

/// returnerer min værdi (underskrevet sammenligning)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_min<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `atomic_min`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_min_acq(dst, val),
            Release => intrinsics::atomic_min_rel(dst, val),
            AcqRel => intrinsics::atomic_min_acqrel(dst, val),
            Relaxed => intrinsics::atomic_min_relaxed(dst, val),
            SeqCst => intrinsics::atomic_min(dst, val),
        }
    }
}

/// returnerer den maksimale værdi (usigneret sammenligning)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umax<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `atomic_umax`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umax_acq(dst, val),
            Release => intrinsics::atomic_umax_rel(dst, val),
            AcqRel => intrinsics::atomic_umax_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umax_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umax(dst, val),
        }
    }
}

/// returnerer min værdi (usigneret sammenligning)
#[inline]
#[cfg(target_has_atomic = "8")]
unsafe fn atomic_umin<T: Copy>(dst: *mut T, val: T, order: Ordering) -> T {
    // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `atomic_umin`
    unsafe {
        match order {
            Acquire => intrinsics::atomic_umin_acq(dst, val),
            Release => intrinsics::atomic_umin_rel(dst, val),
            AcqRel => intrinsics::atomic_umin_acqrel(dst, val),
            Relaxed => intrinsics::atomic_umin_relaxed(dst, val),
            SeqCst => intrinsics::atomic_umin(dst, val),
        }
    }
}

/// Et atomhegn.
///
/// Afhængigt af den angivne rækkefølge forhindrer et hegn, at kompilatoren og CPU'en omordner visse typer hukommelsesoperationer omkring det.
/// Det skaber synkronisering med forholdet mellem det og atomoperationer eller hegn i andre tråde.
///
/// Et hegn 'A', der har (i det mindste) [`Release`], der bestiller semantik, synkroniseres med et hegn 'B' med (i det mindste) [`Acquire`]-semantik, hvis og kun hvis der findes operationer X og Y, begge arbejder på et eller andet atomobjekt 'M', således at A er sekventeret før X, Y synkroniseres før B og Y observerer ændringen til M.
/// Dette giver en sker-før-afhængighed mellem A og B.
///
/// ```text
///     Thread 1                                          Thread 2
///
/// fence(Release);      A --------------
/// x.store(3, Relaxed); X ---------    |
///                                |    |
///                                |    |
///                                -------------> Y  if x.load(Relaxed) == 3 {
///                                     |-------> B      fence(Acquire);
///                                                      ...
///                                                  }
/// ```
///
/// Atomiske operationer med [`Release`]-eller [`Acquire`]-semantik kan også synkroniseres med et hegn.
///
/// Et hegn, der har [`SeqCst`]-ordning, udover at have både [`Acquire`]-og [`Release`]-semantik, deltager i den globale programrækkefølge for de andre [`SeqCst`]-operationer og/eller hegn.
///
/// Accepterer [`Acquire`], [`Release`], [`AcqRel`] og [`SeqCst`] ordrer.
///
/// # Panics
///
/// Panics hvis `order` er [`Relaxed`].
///
/// # Examples
///
/// ```
/// use std::sync::atomic::AtomicBool;
/// use std::sync::atomic::fence;
/// use std::sync::atomic::Ordering;
///
/// // En gensidig udelukkelse primitiv baseret på spinlock.
/// pub struct Mutex {
///     flag: AtomicBool,
/// }
///
/// impl Mutex {
///     pub fn new() -> Mutex {
///         Mutex {
///             flag: AtomicBool::new(false),
///         }
///     }
///
///     pub fn lock(&self) {
///         // Vent, indtil den gamle værdi er `false`.
///         while self.flag.compare_and_swap(false, true, Ordering::Relaxed) != false {}
///         // Dette hegn synkroniseres med butikken i `unlock`.
///         fence(Ordering::Acquire);
///     }
///
///     pub fn unlock(&self) {
///         self.flag.store(false, Ordering::Release);
///     }
/// }
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn fence(order: Ordering) {
    // SIKKERHED: at bruge et atomhegn er sikkert.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_fence_acq(),
            Release => intrinsics::atomic_fence_rel(),
            AcqRel => intrinsics::atomic_fence_acqrel(),
            SeqCst => intrinsics::atomic_fence(),
            Relaxed => panic!("there is no such thing as a relaxed fence"),
        }
    }
}

/// Et kompilatorhukommelseshegn.
///
/// `compiler_fence` udsender ikke nogen maskinkode, men begrænser den slags hukommelse, som det er tilladt at ombestille compileren.Afhængigt af den givne [`Ordering`]-semantik kan compileren specifikt afvises fra at flytte læser eller skriver fra før eller efter opkaldet til den anden side af opkaldet til `compiler_fence`.Bemærk, at det **ikke** forhindrer *hardware* i at foretage en sådan ombestilling.
///
/// Dette er ikke et problem i en enkelt-threadet udførelseskontekst, men når andre tråde kan ændre hukommelse på samme tid, kræves stærkere synkroniseringsprimitiver såsom [`fence`].
///
/// Ombestillingen forhindret af de forskellige ordensemantikker er:
///
///  - med [`SeqCst`] er det ikke tilladt at ombestille læser og skriver hen over dette punkt.
///  - med [`Release`] kan foregående læsninger og skrivninger ikke flyttes forbi efterfølgende skrivninger.
///  - med [`Acquire`] kan efterfølgende læsninger og skrivninger ikke flyttes foran de foregående læsninger.
///  - med [`AcqRel`] håndhæves begge ovenstående regler.
///
/// `compiler_fence` er generelt kun nyttigt til at forhindre en tråd i at køre *med sig selv*.Det vil sige, hvis en given tråd udfører et stykke kode og derefter afbrydes og begynder at udføre kode andetsteds (mens den stadig er i samme tråd og konceptuelt stadig på den samme kerne).I traditionelle programmer kan dette kun ske, når en signalbehandler er registreret.
/// I mere lavt niveau kode kan sådanne situationer også opstå, når man håndterer afbrydelser, når man implementerer grønne tråde med forkøb osv.
/// Nysgerrige læsere opfordres til at læse Linux-kernens diskussion af [memory barriers].
///
/// # Panics
///
/// Panics hvis `order` er [`Relaxed`].
///
/// # Examples
///
/// Uden `compiler_fence` er `assert_eq!` i følgende kode *ikke* garanteret at lykkes, på trods af at alt sker i en enkelt tråd.
/// For at se hvorfor, skal du huske, at compileren frit kan bytte butikker til `IMPORTANT_VARIABLE` og `IS_READ`, da de begge er `Ordering::Relaxed`.Hvis det gør det, og signalbehandleren påberåbes lige efter at `IS_READY` er opdateret, vil signalbehandleren se `IS_READY=1`, men `IMPORTANT_VARIABLE=0`.
/// Brug af en `compiler_fence` afhjælper denne situation.
///
/// ```
/// use std::sync::atomic::{AtomicBool, AtomicUsize};
/// use std::sync::atomic::Ordering;
/// use std::sync::atomic::compiler_fence;
///
/// static IMPORTANT_VARIABLE: AtomicUsize = AtomicUsize::new(0);
/// static IS_READY: AtomicBool = AtomicBool::new(false);
///
/// fn main() {
///     IMPORTANT_VARIABLE.store(42, Ordering::Relaxed);
///     // forhindre, at tidligere skriv flyttes ud over dette punkt
///     compiler_fence(Ordering::Release);
///     IS_READY.store(true, Ordering::Relaxed);
/// }
///
/// fn signal_handler() {
///     if IS_READY.load(Ordering::Relaxed) {
///         assert_eq!(IMPORTANT_VARIABLE.load(Ordering::Relaxed), 42);
///     }
/// }
/// ```
///
/// [memory barriers]: https://www.kernel.org/doc/Documentation/memory-barriers.txt
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "compiler_fences", since = "1.21.0")]
pub fn compiler_fence(order: Ordering) {
    // SIKKERHED: at bruge et atomhegn er sikkert.
    unsafe {
        match order {
            Acquire => intrinsics::atomic_singlethreadfence_acq(),
            Release => intrinsics::atomic_singlethreadfence_rel(),
            AcqRel => intrinsics::atomic_singlethreadfence_acqrel(),
            SeqCst => intrinsics::atomic_singlethreadfence(),
            Relaxed => panic!("there is no such thing as a relaxed compiler fence"),
        }
    }
}

#[cfg(target_has_atomic_load_store = "8")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl fmt::Debug for AtomicBool {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_debug", since = "1.3.0")]
impl<T> fmt::Debug for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.load(Ordering::SeqCst), f)
    }
}

#[cfg(target_has_atomic_load_store = "ptr")]
#[stable(feature = "atomic_pointer", since = "1.24.0")]
impl<T> fmt::Pointer for AtomicPtr<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.load(Ordering::SeqCst), f)
    }
}

/// Signalerer processoren om, at den er inde i en optaget-vent spin-loop ("spin lock").
///
/// Denne funktion er udfaset til fordel for [`hint::spin_loop`].
///
/// [`hint::spin_loop`]: crate::hint::spin_loop
#[inline]
#[stable(feature = "spin_loop_hint", since = "1.24.0")]
#[rustc_deprecated(since = "1.51.0", reason = "use hint::spin_loop instead")]
pub fn spin_loop_hint() {
    spin_loop()
}