#![stable(feature = "futures_api", since = "1.36.0")]

use crate::fmt;
use crate::marker::{PhantomData, Unpin};

/// En `RawWaker` tillader implementatoren af en task executor at oprette en [`Waker`], der giver tilpasset wakeup-opførsel.
///
/// [vtable]: https://en.wikipedia.org/wiki/Virtual_method_table
///
/// Den består af en datapeger og en [virtual function pointer table (vtable)][vtable], der tilpasser `RawWaker` s opførsel.
///
///
#[derive(PartialEq, Debug)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct RawWaker {
    /// En datapeger, der kan bruges til at gemme vilkårlige data som krævet af eksekutoren.
    /// Dette kan f.eks
    /// en typeslettet markør til en `Arc`, der er knyttet til opgaven.
    /// Værdien af dette felt overføres til alle funktioner, der er en del af vtabellen som den første parameter.
    ///
    data: *const (),
    /// Pointertabel med virtuel funktion, der tilpasser denne waker's opførsel.
    vtable: &'static RawWakerVTable,
}

impl RawWaker {
    /// Opretter en ny `RawWaker` fra den medfølgende `data`-markør og `vtable`.
    ///
    /// `data`-markøren kan bruges til at gemme vilkårlige data som krævet af eksekutoren.Dette kan f.eks
    /// en typeslettet markør til en `Arc`, der er knyttet til opgaven.
    /// Værdien af denne markør sendes til alle funktioner, der er en del af `vtable` som den første parameter.
    ///
    /// `vtable` tilpasser adfærden for en `Waker`, der oprettes fra en `RawWaker`.
    /// For hver operation på `Waker` kaldes den tilknyttede funktion i `vtable` for den underliggende `RawWaker`.
    ///
    ///
    ///
    #[inline]
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    pub const fn new(data: *const (), vtable: &'static RawWakerVTable) -> RawWaker {
        RawWaker { data, vtable }
    }
}

/// En pointertabel med virtuel funktion (vtable), der specificerer adfærden for en [`RawWaker`].
///
/// Markøren, der sendes til alle funktioner inde i vtabellen, er `data`-markøren fra det medfølgende [`RawWaker`]-objekt.
///
/// Funktionerne inde i denne struktur er kun beregnet til at blive kaldt på `data`-markøren på et korrekt konstrueret [`RawWaker`]-objekt indefra [`RawWaker`]-implementeringen.
/// At ringe til en af de indeholdte funktioner ved hjælp af en hvilken som helst anden `data`-markør vil medføre udefineret adfærd.
///
///
///
///
#[stable(feature = "futures_api", since = "1.36.0")]
#[derive(PartialEq, Copy, Clone, Debug)]
pub struct RawWakerVTable {
    /// Denne funktion kaldes, når [`RawWaker`] bliver klonet, f.eks. Når den [`Waker`], hvor [`RawWaker`] er gemt, bliver klonet.
    ///
    /// Implementeringen af denne funktion skal bevare alle ressourcer, der er nødvendige for denne ekstra forekomst af en [`RawWaker`] og tilhørende opgave.
    /// Hvis du kalder `wake` på den resulterende [`RawWaker`], bør det resultere i en vækning af den samme opgave, som den originale [`RawWaker`] ville have været vækket.
    ///
    ///
    ///
    clone: unsafe fn(*const ()) -> RawWaker,

    /// Denne funktion kaldes, når `wake` kaldes på [`Waker`].
    /// Det skal vække den opgave, der er knyttet til denne [`RawWaker`].
    ///
    /// Implementeringen af denne funktion skal sørge for at frigive ressourcer, der er knyttet til denne forekomst af en [`RawWaker`] og tilknyttet opgave.
    ///
    ///
    wake: unsafe fn(*const ()),

    /// Denne funktion kaldes, når `wake_by_ref` kaldes på [`Waker`].
    /// Det skal vække den opgave, der er knyttet til denne [`RawWaker`].
    ///
    /// Denne funktion svarer til `wake`, men må ikke forbruge den medfølgende datap markør.
    ///
    wake_by_ref: unsafe fn(*const ()),

    /// Denne funktion kaldes, når en [`RawWaker`] bliver droppet.
    ///
    /// Implementeringen af denne funktion skal sørge for at frigive ressourcer, der er knyttet til denne forekomst af en [`RawWaker`] og tilknyttet opgave.
    ///
    ///
    drop: unsafe fn(*const ()),
}

impl RawWakerVTable {
    /// Opretter en ny `RawWakerVTable` fra de medfølgende `clone`-, `wake`-, `wake_by_ref`-og `drop`-funktioner.
    ///
    /// # `clone`
    ///
    /// Denne funktion kaldes, når [`RawWaker`] bliver klonet, f.eks. Når den [`Waker`], hvor [`RawWaker`] er gemt, bliver klonet.
    ///
    /// Implementeringen af denne funktion skal bevare alle ressourcer, der er nødvendige for denne ekstra forekomst af en [`RawWaker`] og tilhørende opgave.
    /// Hvis du kalder `wake` på den resulterende [`RawWaker`], bør det resultere i en vækning af den samme opgave, som den originale [`RawWaker`] ville have været vækket.
    ///
    /// # `wake`
    ///
    /// Denne funktion kaldes, når `wake` kaldes på [`Waker`].
    /// Det skal vække den opgave, der er knyttet til denne [`RawWaker`].
    ///
    /// Implementeringen af denne funktion skal sørge for at frigive ressourcer, der er knyttet til denne forekomst af en [`RawWaker`] og tilknyttet opgave.
    ///
    ///
    /// # `wake_by_ref`
    ///
    /// Denne funktion kaldes, når `wake_by_ref` kaldes på [`Waker`].
    /// Det skal vække den opgave, der er knyttet til denne [`RawWaker`].
    ///
    /// Denne funktion svarer til `wake`, men må ikke forbruge den medfølgende datap markør.
    ///
    /// # `drop`
    ///
    /// Denne funktion kaldes, når en [`RawWaker`] bliver droppet.
    ///
    /// Implementeringen af denne funktion skal sørge for at frigive ressourcer, der er knyttet til denne forekomst af en [`RawWaker`] og tilknyttet opgave.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[rustc_promotable]
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_const_stable(feature = "futures_api", since = "1.36.0")]
    #[rustc_allow_const_fn_unstable(const_fn_fn_ptr_basics)]
    pub const fn new(
        clone: unsafe fn(*const ()) -> RawWaker,
        wake: unsafe fn(*const ()),
        wake_by_ref: unsafe fn(*const ()),
        drop: unsafe fn(*const ()),
    ) -> Self {
        Self { clone, wake, wake_by_ref, drop }
    }
}

/// `Context` for en asynkron opgave.
///
/// I øjeblikket tjener `Context` kun til at give adgang til en `&Waker`, som kan bruges til at vække den aktuelle opgave.
///
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Context<'a> {
    waker: &'a Waker,
    // Sørg for, at vi er future-sikre mod afvigelsesændringer ved at tvinge levetiden til at være invariant (levetid for argumentposition er kontravariant, mens levetid for returposition er kovariant).
    //
    //
    //
    _marker: PhantomData<fn(&'a ()) -> &'a ()>,
}

impl<'a> Context<'a> {
    /// Opret en ny `Context` fra en `&Waker`.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn from_waker(waker: &'a Waker) -> Self {
        Context { waker, _marker: PhantomData }
    }

    /// Returnerer en henvisning til `Waker` for den aktuelle opgave.
    #[stable(feature = "futures_api", since = "1.36.0")]
    #[inline]
    pub fn waker(&self) -> &'a Waker {
        &self.waker
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Context<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Context").field("waker", &self.waker).finish()
    }
}

/// En `Waker` er et håndtag til at vække en opgave ved at underrette sin eksekutor om, at den er klar til at blive kørt.
///
/// Dette håndtag indkapsler en [`RawWaker`]-forekomst, der definerer den eksekutorspecifikke vækning.
///
///
/// Implementerer [`Clone`], [`Send`] og [`Sync`].
///
#[repr(transparent)]
#[stable(feature = "futures_api", since = "1.36.0")]
pub struct Waker {
    waker: RawWaker,
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Unpin for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Send for Waker {}
#[stable(feature = "futures_api", since = "1.36.0")]
unsafe impl Sync for Waker {}

impl Waker {
    /// Vågn op med den opgave, der er knyttet til denne `Waker`.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake(self) {
        // Det aktuelle wakeup-opkald delegeres gennem et virtuelt funktionsopkald til implementeringen, der er defineret af eksekutoren.
        //
        let wake = self.waker.vtable.wake;
        let data = self.waker.data;

        // Ring ikke til `drop`-waker forbruges af `wake`.
        crate::mem::forget(self);

        // SIKKERHED: Dette er sikkert, fordi `Waker::from_raw` er den eneste måde
        // at initialisere `wake` og `data`, der kræver, at brugeren anerkender, at kontrakten med `RawWaker` opretholdes.
        //
        unsafe { (wake)(data) };
    }

    /// Vågn op med den opgave, der er knyttet til denne `Waker`, uden at forbruge `Waker`.
    ///
    /// Dette svarer til `wake`, men kan være lidt mindre effektivt i det tilfælde, hvor en ejet `Waker` er tilgængelig.
    /// Denne metode bør foretrækkes frem for at ringe til `waker.clone().wake()`.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn wake_by_ref(&self) {
        // Det aktuelle wakeup-opkald delegeres gennem et virtuelt funktionsopkald til implementeringen, der er defineret af eksekutoren.
        //

        // SIKKERHED: se `wake`
        unsafe { (self.waker.vtable.wake_by_ref)(self.waker.data) }
    }

    /// Returnerer `true`, hvis denne `Waker` og en anden `Waker` har vækket den samme opgave.
    ///
    /// Denne funktion fungerer på en bedst mulig basis og kan returnere falsk, selv når 'Waker`s ville vække den samme opgave.
    /// Men hvis denne funktion returnerer `true`, er det garanteret, at `Waker`s vækker den samme opgave.
    ///
    /// Denne funktion bruges primært til optimeringsformål.
    ///
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub fn will_wake(&self, other: &Waker) -> bool {
        self.waker == other.waker
    }

    /// Opretter en ny `Waker` fra [`RawWaker`].
    ///
    /// Opførelsen af den returnerede `Waker` er udefineret, hvis den kontrakt, der er defineret i ['RawWaker'] 's og [' RawWakerVTable ']' s dokumentation ikke opretholdes.
    ///
    /// Derfor er denne metode usikker.
    #[inline]
    #[stable(feature = "futures_api", since = "1.36.0")]
    pub unsafe fn from_raw(waker: RawWaker) -> Waker {
        Waker { waker }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Clone for Waker {
    #[inline]
    fn clone(&self) -> Self {
        Waker {
            // SIKKERHED: Dette er sikkert, fordi `Waker::from_raw` er den eneste måde
            // at initialisere `clone` og `data`, der kræver, at brugeren anerkender, at kontrakten med [`RawWaker`] opretholdes.
            //
            waker: unsafe { (self.waker.vtable.clone)(self.waker.data) },
        }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl Drop for Waker {
    #[inline]
    fn drop(&mut self) {
        // SIKKERHED: Dette er sikkert, fordi `Waker::from_raw` er den eneste måde
        // at initialisere `drop` og `data`, der kræver, at brugeren anerkender, at kontrakten med `RawWaker` opretholdes.
        //
        unsafe { (self.waker.vtable.drop)(self.waker.data) }
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl fmt::Debug for Waker {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let vtable_ptr = self.waker.vtable as *const RawWakerVTable;
        f.debug_struct("Waker")
            .field("data", &self.waker.data)
            .field("vtable", &vtable_ptr)
            .finish()
    }
}