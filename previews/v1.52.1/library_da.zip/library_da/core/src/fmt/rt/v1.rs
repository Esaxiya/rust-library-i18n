//! Dette er et internt modul, der bruges af ifmt!runtime.Disse strukturer udsendes til statiske arrays for at præ-kompilere formatstrenge på forhånd.
//!
//! Disse definitioner svarer til deres `ct`-ækvivalenter, men adskiller sig ved at disse kan tildeles statisk og er lidt optimeret til runtime
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Mulige justeringer, der kan anmodes om som en del af et formateringsdirektiv.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Angivelse af, at indholdet skal være venstrejusteret.
    Left,
    /// Angivelse af, at indholdet skal være højrejusteret.
    Right,
    /// Angivelse af, at indholdet skal være centreret.
    Center,
    /// Der blev ikke anmodet om nogen justering.
    Unknown,
}

/// Brugt af [width](https://doc.rust-lang.org/std/fmt/#width)-og [precision](https://doc.rust-lang.org/std/fmt/#precision)-specifikationer.
#[derive(Copy, Clone)]
pub enum Count {
    /// Angivet med et bogstaveligt tal, gemmer værdien
    Is(usize),
    /// Specificeret ved hjælp af `$` og `*` syntakser, gemmer indekset i `args`
    Param(usize),
    /// Ikke specificeret
    Implied,
}