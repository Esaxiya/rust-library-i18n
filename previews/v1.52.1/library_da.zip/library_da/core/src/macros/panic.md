Panics den aktuelle tråd.

Dette gør det muligt for et program at afslutte med det samme og give feedback til den, der ringer op til programmet.
`panic!` skal bruges, når et program når en uoprettelig tilstand.

Denne makro er den perfekte måde at hævde betingelser i eksempel kode og i test.
`panic!` er tæt knyttet til `unwrap`-metoden i både [`Option`][ounwrap]-og [`Result`][runwrap]-enums.
Begge implementeringer kalder `panic!`, når de er indstillet til [`None`]-eller [`Err`]-varianter.

Når du bruger `panic!()`, kan du angive en strengnyttelast, der er bygget ved hjælp af [`format!`]-syntaksen.
Denne nyttelast bruges ved indsprøjtning af panic i den kaldende Rust-tråd, hvilket får tråden til panic helt.

Opførelsen af standard `std` hook, dvs.
koden, der kører direkte efter, at panic påberåbes, er at udskrive meddelelsesnyttelasten til `stderr` sammen med file/line/column-oplysningerne i `panic!()`-opkaldet.

Du kan tilsidesætte panic hook ved hjælp af [`std::panic::set_hook()`].
Inde i hook kan man få adgang til en panic som en `&dyn Any + Send`, som enten indeholder en `&str` eller `String` til regelmæssige `panic!()`-invokationer.
Til panic med en værdi af en anden type kan [`panic_any`] bruges.

[`Result`] enum er ofte en bedre løsning til gendannelse efter fejl end ved hjælp af `panic!`-makroen.
Denne makro skal bruges til at undgå at fortsætte med at bruge forkerte værdier, f.eks. Fra eksterne kilder.
Detaljerede oplysninger om fejlhåndtering findes i [book].

Se også makroen [`compile_error!`] for at få fejl under kompilering.

[ounwrap]: Option::unwrap
[runwrap]: Result::unwrap
[`std::panic::set_hook()`]: ../std/panic/fn.set_hook.html
[`panic_any`]: ../std/panic/fn.panic_any.html
[`Box`]: ../std/boxed/struct.Box.html
[`Any`]: crate::any::Any
[`format!`]: ../std/macro.format.html
[book]: ../book/ch09-00-error-handling.html

# Nuværende implementering

Hvis hovedtråden panics vil den afslutte alle dine tråde og afslutte dit program med kode `101`.

# Examples

```should_panic
# #![allow(unreachable_code)]
panic!();
panic!("this is a terrible mistake!");
panic!("this is a {} {message}", "fancy", message = "message");
std::panic::panic_any(4); // panic with the value of 4 to be collected elsewhere
```





