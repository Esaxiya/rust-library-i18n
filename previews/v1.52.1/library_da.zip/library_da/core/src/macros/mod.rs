#[doc = include_str!("panic.md")]
#[macro_export]
#[rustc_builtin_macro = "core_panic"]
#[allow_internal_unstable(edition_panic)]
#[stable(feature = "core", since = "1.6.0")]
#[rustc_diagnostic_item = "core_panic_macro"]
macro_rules! panic {
    // Udvides til enten `$crate::panic::panic_2015` eller `$crate::panic::panic_2021` afhængigt af opkaldsudgaven.
    //
    ($($arg:tt)*) => {
        /* compiler built-in */
    };
}

/// Påstår, at to udtryk er lig med hinanden (ved hjælp af [`PartialEq`]).
///
/// På panic udskriver denne makro værdierne for udtrykkene med deres fejlretningsrepræsentationer.
///
///
/// Ligesom [`assert!`] har denne makro en anden form, hvor en brugerdefineret panic-meddelelse kan leveres.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// assert_eq!(a, b);
///
/// assert_eq!(a, b, "we are testing addition with {} and {}", a, b);
/// ```
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_eq {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Genlånene nedenfor er bevidste.
                    // Uden dem initialiseres stakpladsen til lånet, selv før værdierne sammenlignes, hvilket fører til en mærkbar opbremsning.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if !(*left_val == *right_val) {
                    let kind = $crate::panicking::AssertKind::Eq;
                    // Genlånene nedenfor er bevidste.
                    // Uden dem initialiseres stakpladsen til lånet, selv før værdierne sammenlignes, hvilket fører til en mærkbar opbremsning.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Påstår, at to udtryk ikke er ens med hinanden (ved hjælp af [`PartialEq`]).
///
/// På panic udskriver denne makro værdierne for udtrykkene med deres fejlretningsrepræsentationer.
///
///
/// Ligesom [`assert!`] har denne makro en anden form, hvor en brugerdefineret panic-meddelelse kan leveres.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// assert_ne!(a, b);
///
/// assert_ne!(a, b, "we are testing that the values are not equal");
/// ```
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
#[allow_internal_unstable(core_panic)]
macro_rules! assert_ne {
    ($left:expr, $right:expr $(,)?) => ({
        match (&$left, &$right) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Genlånene nedenfor er bevidste.
                    // Uden dem initialiseres stakpladsen til lånet, selv før værdierne sammenlignes, hvilket fører til en mærkbar opbremsning.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::None);
                }
            }
        }
    });
    ($left:expr, $right:expr, $($arg:tt)+) => ({
        match (&($left), &($right)) {
            (left_val, right_val) => {
                if *left_val == *right_val {
                    let kind = $crate::panicking::AssertKind::Ne;
                    // Genlånene nedenfor er bevidste.
                    // Uden dem initialiseres stakpladsen til lånet, selv før værdierne sammenlignes, hvilket fører til en mærkbar opbremsning.
                    //
                    $crate::panicking::assert_failed(kind, &*left_val, &*right_val, $crate::option::Option::Some($crate::format_args!($($arg)+)));
                }
            }
        }
    });
}

/// Påstår, at et boolsk udtryk er `true` ved kørsel.
///
/// Dette påkalder [`panic!`]-makroen, hvis det angivne udtryk ikke kan evalueres til `true` ved kørsel.
///
/// Ligesom [`assert!`] har denne makro også en anden version, hvor en tilpasset panic-meddelelse kan leveres.
///
/// # Uses
///
/// I modsætning til [`assert!`] er `debug_assert!`-sætninger kun aktiveret i ikke-optimerede builds som standard.
/// En optimeret build udfører ikke `debug_assert!`-sætninger, medmindre `-C debug-assertions` sendes til compileren.
/// Dette gør `debug_assert!` nyttigt til kontrol, der er for dyre til at være til stede i en release-build, men kan være nyttigt under udviklingen.
/// Resultatet af at udvide `debug_assert!` er altid typekontrolleret.
///
/// En ukontrolleret påstand tillader, at et program i en inkonsekvent tilstand fortsætter med at køre, hvilket kan have uventede konsekvenser, men indfører ikke usikkerhed, så længe dette kun sker i sikker kode.
///
/// Ydelsesomkostningerne ved påstande kan dog ikke måles generelt.
/// Udskiftning af [`assert!`] med `debug_assert!` fremmes således kun efter grundig profilering, og vigtigere, kun i sikker kode!
///
/// # Examples
///
/// ```
/// // panic-meddelelsen for disse påstande er den strengede værdi af det givne udtryk.
/////
/// debug_assert!(true);
///
/// fn some_expensive_computation() -> bool { true } // en meget enkel funktion
/// debug_assert!(some_expensive_computation());
///
/// // hævde med en brugerdefineret besked
/// let x = true;
/// debug_assert!(x, "x wasn't true!");
///
/// let a = 3; let b = 27;
/// debug_assert!(a + b == 30, "a = {}, b = {}", a, b);
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "debug_assert_macro"]
macro_rules! debug_assert {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert!($($arg)*); })
}

/// Påstår, at to udtryk er lig med hinanden.
///
/// På panic udskriver denne makro værdierne for udtrykkene med deres fejlretningsrepræsentationer.
///
/// I modsætning til [`assert_eq!`] er `debug_assert_eq!`-sætninger kun aktiveret i ikke-optimerede builds som standard.
/// En optimeret build udfører ikke `debug_assert_eq!`-sætninger, medmindre `-C debug-assertions` sendes til compileren.
/// Dette gør `debug_assert_eq!` nyttigt til kontrol, der er for dyre til at være til stede i en release-build, men kan være nyttigt under udviklingen.
///
/// Resultatet af at udvide `debug_assert_eq!` er altid typekontrolleret.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 1 + 2;
/// debug_assert_eq!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! debug_assert_eq {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_eq!($($arg)*); })
}

/// Påstår, at to udtryk ikke er lig med hinanden.
///
/// På panic udskriver denne makro værdierne for udtrykkene med deres fejlretningsrepræsentationer.
///
/// I modsætning til [`assert_ne!`] er `debug_assert_ne!`-sætninger kun aktiveret i ikke-optimerede builds som standard.
/// En optimeret build udfører ikke `debug_assert_ne!`-sætninger, medmindre `-C debug-assertions` sendes til compileren.
/// Dette gør `debug_assert_ne!` nyttigt til kontrol, der er for dyre til at være til stede i en release-build, men kan være nyttigt under udviklingen.
///
/// Resultatet af at udvide `debug_assert_ne!` er altid typekontrolleret.
///
/// # Examples
///
/// ```
/// let a = 3;
/// let b = 2;
/// debug_assert_ne!(a, b);
/// ```
///
///
#[macro_export]
#[stable(feature = "assert_ne", since = "1.13.0")]
macro_rules! debug_assert_ne {
    ($($arg:tt)*) => (if $crate::cfg!(debug_assertions) { $crate::assert_ne!($($arg)*); })
}

/// Returnerer, om det givne udtryk matcher et af de givne mønstre.
///
/// Som i et `match`-udtryk kan mønsteret efterfølges af `if` og et beskyttelsesudtryk, der har adgang til navne bundet af mønsteret.
///
///
/// # Examples
///
/// ```
/// let foo = 'f';
/// assert!(matches!(foo, 'A'..='Z' | 'a'..='z'));
///
/// let bar = Some(4);
/// assert!(matches!(bar, Some(x) if x > 2));
/// ```
#[macro_export]
#[stable(feature = "matches_macro", since = "1.42.0")]
macro_rules! matches {
    ($expression:expr, $( $pattern:pat )|+ $( if $guard: expr )? $(,)?) => {
        match $expression {
            $( $pattern )|+ $( if $guard )? => true,
            _ => false
        }
    }
}

/// Udpakker et resultat eller udbreder dets fejl.
///
/// `?`-operatøren blev tilføjet for at erstatte `try!` og skulle bruges i stedet.
/// Desuden er `try` et reserveret ord i Rust 2018, så hvis du skal bruge det, skal du bruge [raw-identifier syntax][ris]: `r#try`.
///
///
/// [ris]: https://doc.rust-lang.org/nightly/rust-by-example/compatibility/raw_identifiers.html
///
/// `try!` matcher den givne [`Result`].I tilfælde af `Ok`-varianten har udtrykket værdien af den indpakkede værdi.
///
/// I tilfælde af `Err`-varianten henter den den indre fejl.`try!` udfører derefter konvertering ved hjælp af `From`.
/// Dette giver automatisk konvertering mellem specialiserede fejl og mere generelle.
/// Den resulterende fejl returneres derefter straks.
///
/// På grund af den tidlige returnering kan `try!` kun bruges i funktioner, der returnerer [`Result`].
///
/// # Examples
///
/// ```
/// use std::io;
/// use std::fs::File;
/// use std::io::prelude::*;
///
/// enum MyError {
///     FileWriteError
/// }
///
/// impl From<io::Error> for MyError {
///     fn from(e: io::Error) -> MyError {
///         MyError::FileWriteError
///     }
/// }
///
/// // Den foretrukne metode til hurtig returnerende fejl
/// fn write_to_file_question() -> Result<(), MyError> {
///     let mut file = File::create("my_best_friends.txt")?;
///     file.write_all(b"This is a list of my best friends.")?;
///     Ok(())
/// }
///
/// // Den tidligere metode til hurtig returnerende fejl
/// fn write_to_file_using_try() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     r#try!(file.write_all(b"This is a list of my best friends."));
///     Ok(())
/// }
///
/// // Dette svarer til:
/// fn write_to_file_using_match() -> Result<(), MyError> {
///     let mut file = r#try!(File::create("my_best_friends.txt"));
///     match file.write_all(b"This is a list of my best friends.") {
///         Ok(v) => v,
///         Err(e) => return Err(From::from(e)),
///     }
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "1.39.0", reason = "use the `?` operator instead")]
#[doc(alias = "?")]
macro_rules! r#try {
    ($expr:expr $(,)?) => {
        match $expr {
            $crate::result::Result::Ok(val) => val,
            $crate::result::Result::Err(err) => {
                return $crate::result::Result::Err($crate::convert::From::from(err));
            }
        }
    };
}

/// Skriver formaterede data til en buffer.
///
/// Denne makro accepterer en 'writer', en formatstreng og en liste over argumenter.
/// Argumenter formateres i henhold til den specificerede formatstreng, og resultatet sendes til forfatteren.
/// Forfatteren kan have en hvilken som helst værdi med en `write_fmt`-metode;generelt kommer dette fra en implementering af enten [`fmt::Write`] eller [`io::Write`] trait.
/// Makroen returnerer uanset `write_fmt`-metoden returnerer;almindeligvis en [`fmt::Result`] eller en [`io::Result`].
///
/// Se [`std::fmt`] for at få flere oplysninger om formatstrengssyntaks.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`fmt::Write`]: crate::fmt::Write
/// [`io::Write`]: ../std/io/trait.Write.html
/// [`fmt::Result`]: crate::fmt::Result
/// [`io::Result`]: ../std/io/type.Result.html
///
/// # Examples
///
/// ```
/// use std::io::Write;
///
/// fn main() -> std::io::Result<()> {
///     let mut w = Vec::new();
///     write!(&mut w, "test")?;
///     write!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(w, b"testformatted arguments");
///     Ok(())
/// }
/// ```
///
/// Et modul kan importere både `std::fmt::Write` og `std::io::Write` og kalde `write!` på objekter, der implementerer enten, da objekter typisk ikke implementerer begge dele.
///
/// Modulet skal dog importere traits-kvalificerede, så deres navne ikke er i konflikt:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     write!(&mut s, "{} {}", "abc", 123)?; // bruger fmt::Write::write_fmt
///     write!(&mut v, "s = {:?}", s)?; // bruger io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\"");
///     Ok(())
/// }
/// ```
///
/// Note: Denne makro kan også bruges i `no_std`-opsætninger.
/// I en `no_std`-opsætning er du ansvarlig for implementeringsoplysningerne om komponenterne.
///
/// ```no_run
/// # extern crate core;
/// use core::fmt::Write;
///
/// struct Example;
///
/// impl Write for Example {
///     fn write_str(&mut self, _s: &str) -> core::fmt::Result {
///          unimplemented!();
///     }
/// }
///
/// let mut m = Example{};
/// write!(&mut m, "Hello World").expect("Not written");
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! write {
    ($dst:expr, $($arg:tt)*) => ($dst.write_fmt($crate::format_args!($($arg)*)))
}

/// Skriv formaterede data i en buffer med en ny linje tilføjet.
///
/// På alle platforme er den nye linje LINE FEED-karakteren (`\n`/`U+000A`) alene (ingen yderligere CARRIAGE RETURN (`\r`/`U+000D`).
///
/// Se [`write!`] for at få flere oplysninger.For oplysninger om formatstrengsyntaks, se [`std::fmt`].
///
/// [`std::fmt`]: ../std/fmt/index.html
///
/// # Examples
///
/// ```
/// use std::io::{Write, Result};
///
/// fn main() -> Result<()> {
///     let mut w = Vec::new();
///     writeln!(&mut w)?;
///     writeln!(&mut w, "test")?;
///     writeln!(&mut w, "formatted {}", "arguments")?;
///
///     assert_eq!(&w[..], "\ntest\nformatted arguments\n".as_bytes());
///     Ok(())
/// }
/// ```
///
/// Et modul kan importere både `std::fmt::Write` og `std::io::Write` og kalde `write!` på objekter, der implementerer enten, da objekter typisk ikke implementerer begge dele.
/// Modulet skal dog importere traits-kvalificerede, så deres navne ikke er i konflikt:
///
/// ```
/// use std::fmt::Write as FmtWrite;
/// use std::io::Write as IoWrite;
///
/// fn main() -> Result<(), Box<dyn std::error::Error>> {
///     let mut s = String::new();
///     let mut v = Vec::new();
///
///     writeln!(&mut s, "{} {}", "abc", 123)?; // bruger fmt::Write::write_fmt
///     writeln!(&mut v, "s = {:?}", s)?; // bruger io::Write::write_fmt
///     assert_eq!(v, b"s = \"abc 123\\n\"\n");
///     Ok(())
/// }
/// ```
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(format_args_nl)]
macro_rules! writeln {
    ($dst:expr $(,)?) => (
        $crate::write!($dst, "\n")
    );
    ($dst:expr, $($arg:tt)*) => (
        $dst.write_fmt($crate::format_args_nl!($($arg)*))
    );
}

/// Angiver kode, der ikke kan nås.
///
/// Dette er nyttigt når som helst, hvor compileren ikke kan bestemme, at en eller anden kode ikke kan nås.For eksempel:
///
/// * Match arme med beskyttelsesforhold.
/// * Sløjfer, der dynamisk afsluttes.
/// * Iteratorer, der dynamisk afsluttes.
///
/// Hvis beslutningen om, at koden ikke kan nås, viser sig at være forkert, afsluttes programmet straks med en [`panic!`].
///
/// Den usikre modstykke til denne makro er [`unreachable_unchecked`]-funktionen, som vil medføre udefineret adfærd, hvis koden nås.
///
///
/// [`unreachable_unchecked`]: crate::hint::unreachable_unchecked
///
/// # Panics
///
/// Dette vil altid [`panic!`].
///
/// # Examples
///
/// Match arme:
///
/// ```
/// # #[allow(dead_code)]
/// fn foo(x: Option<i32>) {
///     match x {
///         Some(n) if n >= 0 => println!("Some(Non-negative)"),
///         Some(n) if n <  0 => println!("Some(Negative)"),
///         Some(_)           => unreachable!(), // kompiler fejl, hvis kommenteret
///         None              => println!("None")
///     }
/// }
/// ```
///
/// Iterators:
///
/// ```
/// # #[allow(dead_code)]
/// fn divide_by_three(x: u32) -> u32 { // en af de fattigste implementeringer af x/3
///     for i in 0.. {
///         if 3*i < i { panic!("u32 overflow"); }
///         if x < 3*i { return i-1; }
///     }
///     unreachable!();
/// }
/// ```
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unreachable {
    () => ({
        $crate::panic!("internal error: entered unreachable code")
    });
    ($msg:expr $(,)?) => ({
        $crate::unreachable!("{}", $msg)
    });
    ($fmt:expr, $($arg:tt)*) => ({
        $crate::panic!($crate::concat!("internal error: entered unreachable code: ", $fmt), $($arg)*)
    });
}

/// Indikerer uimplementeret kode ved at gå i panik med en besked om "not implemented".
///
/// Dette gør det muligt for din kode at tjekke, hvilket er nyttigt, hvis du prototyper eller implementerer en trait, der kræver flere metoder, som du ikke planlægger at bruge alle.
///
/// Forskellen mellem `unimplemented!` og [`todo!`] er, at mens `todo!` formidler en hensigt om at implementere funktionaliteten senere, og beskeden er "not yet implemented", fremsætter `unimplemented!` ingen sådanne krav.
/// Dens budskab er "not implemented".
/// Også nogle IDE'er markerer `todo!` S.
///
/// # Panics
///
/// Dette vil altid [`panic!`], fordi `unimplemented!` kun er en stenografi for `panic!` med en fast, specifik besked.
///
/// Ligesom `panic!` har denne makro en anden form til visning af brugerdefinerede værdier.
///
/// # Examples
///
/// Sig, at vi har en trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self) -> u8;
///     fn baz(&self);
///     fn qux(&self) -> Result<u64, ()>;
/// }
/// ```
///
/// Vi ønsker at implementere `Foo` til 'MyStruct', men af en eller anden grund giver det kun mening at implementere `bar()`-funktionen.
/// `baz()` og `qux()` skal stadig defineres i vores implementering af `Foo`, men vi kan bruge `unimplemented!` i deres definitioner for at tillade vores kode at kompilere.
///
/// Vi vil stadig have, at vores program holder op med at køre, hvis de ikke-implementerede metoder nås.
///
/// ```
/// # trait Foo {
/// #     fn bar(&self) -> u8;
/// #     fn baz(&self);
/// #     fn qux(&self) -> Result<u64, ()>;
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) -> u8 {
///         1 + 1
///     }
///
///     fn baz(&self) {
///         // Det giver ingen mening at `baz` en `MyStruct`, så vi har slet ingen logik her.
/////
///         // Dette viser "thread 'main' panicked at 'not implemented'".
///         unimplemented!();
///     }
///
///     fn qux(&self) -> Result<u64, ()> {
///         // Vi har nogle logik her, vi kan tilføje en besked til uimplementeret!for at vise vores undladelse.
///         // Dette viser: "thread 'main' panicked at 'not implemented: MyStruct isn't quxable'".
/////
/////
///         unimplemented!("MyStruct isn't quxable");
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
/// }
/// ```
///
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
macro_rules! unimplemented {
    () => ($crate::panic!("not implemented"));
    ($($arg:tt)+) => ($crate::panic!("not implemented: {}", $crate::format_args!($($arg)+)));
}

/// Angiver ufærdig kode.
///
/// Dette kan være nyttigt, hvis du prototyper og bare ønsker at få din kodetypekontrol.
///
/// Forskellen mellem [`unimplemented!`] og `todo!` er, at mens `todo!` formidler en hensigt om at implementere funktionaliteten senere, og beskeden er "not yet implemented", fremsætter `unimplemented!` ingen sådanne krav.
/// Dens budskab er "not implemented".
/// Også nogle IDE'er markerer `todo!` S.
///
/// # Panics
///
/// Dette vil altid [`panic!`].
///
/// # Examples
///
/// Her er et eksempel på nogle igangværende koder.Vi har en trait `Foo`:
///
/// ```
/// trait Foo {
///     fn bar(&self);
///     fn baz(&self);
/// }
/// ```
///
/// Vi vil implementere `Foo` på en af vores typer, men vi vil også arbejde på kun `bar()` først.For at vores kode skal kompileres, skal vi implementere `baz()`, så vi kan bruge `todo!`:
///
/// ```
/// # trait Foo {
/// #     fn bar(&self);
/// #     fn baz(&self);
/// # }
/// struct MyStruct;
///
/// impl Foo for MyStruct {
///     fn bar(&self) {
///         // implementering går her
///     }
///
///     fn baz(&self) {
///         // lad os ikke bekymre os om at implementere baz() indtil videre
///         todo!();
///     }
/// }
///
/// fn main() {
///     let s = MyStruct;
///     s.bar();
///
///     // vi bruger ikke engang baz(), så det er fint.
/// }
/// ```
///
///
///
///
#[macro_export]
#[stable(feature = "todo_macro", since = "1.40.0")]
macro_rules! todo {
    () => ($crate::panic!("not yet implemented"));
    ($($arg:tt)+) => ($crate::panic!("not yet implemented: {}", $crate::format_args!($($arg)+)));
}

/// Definitioner af indbyggede makroer.
///
/// De fleste af makroegenskaberne (stabilitet, synlighed osv.) Er taget fra kildekoden her, med undtagelse af udvidelsesfunktioner, der omdanner makroindgange til output, disse funktioner leveres af compileren.
///
///
pub(crate) mod builtin {

    /// Får kompilering til at mislykkes med den givne fejlmeddelelse, når den opstår.
    ///
    /// Denne makro skal bruges, når en crate bruger en betinget kompileringsstrategi til at give bedre fejlmeddelelser under fejlagtige forhold.
    ///
    /// Det er compiler-niveau form af [`panic!`], men udsender en fejl under *kompilering* snarere end ved *runtime*.
    ///
    /// # Examples
    ///
    /// To sådanne eksempler er makroer og `#[cfg]`-miljøer.
    ///
    /// Udsend bedre kompilatorfejl, hvis en makro overføres ugyldige værdier.
    /// Uden den endelige branch udsender compileren stadig en fejl, men fejlmeddelelsen nævner ikke de to gyldige værdier.
    ///
    /// ```compile_fail
    /// macro_rules! give_me_foo_or_bar {
    ///     (foo) => {};
    ///     (bar) => {};
    ///     ($x:ident) => {
    ///         compile_error!("This macro only accepts `foo` or `bar`");
    ///     }
    /// }
    ///
    /// give_me_foo_or_bar!(neither);
    /// // ^ will fail at compile time with message "This macro only accepts `foo` or `bar`"
    /// ```
    ///
    /// Udsend kompilatorfejl, hvis en af et antal funktioner ikke er tilgængelig.
    ///
    /// ```compile_fail
    /// #[cfg(not(any(feature = "foo", feature = "bar")))]
    /// compile_error!("Either feature \"foo\" or \"bar\" must be enabled for this crate.");
    /// ```
    ///
    #[stable(feature = "compile_error_macro", since = "1.20.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! compile_error {
        ($msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Konstruerer parametre til de andre strengformateringsmakroer.
    ///
    /// Denne makro fungerer ved at tage en formateringsstreng, der indeholder `{}`, for hvert ekstra argument, der sendes.
    /// `format_args!` forbereder de yderligere parametre for at sikre, at output kan fortolkes som en streng og kanonikaliserer argumenterne til en enkelt type.
    /// Enhver værdi, der implementerer [`Display`] trait, kan overføres til `format_args!`, ligesom enhver [`Debug`]-implementering kan overføres til en `{:?}` i formateringsstrengen.
    ///
    ///
    /// Denne makro producerer en værdi af typen [`fmt::Arguments`].Denne værdi kan overføres til makroerne i [`std::fmt`] for at udføre nyttige omdirigeringer.
    /// Alle andre formateringsmakroer ([`format!`], [`write!`], [`println!`] osv.) Proxies gennem denne.
    /// `format_args!`, i modsætning til dets afledte makroer undgår bunketildelinger.
    ///
    /// Du kan bruge den [`fmt::Arguments`]-værdi, som `format_args!` returnerer i `Debug`-og `Display`-sammenhænge som vist nedenfor.
    /// Eksemplet viser også, at `Debug` og `Display` format til det samme: den interpolerede formatstreng i `format_args!`.
    ///
    /// ```rust
    /// let debug = format!("{:?}", format_args!("{} foo {:?}", 1, 2));
    /// let display = format!("{}", format_args!("{} foo {:?}", 1, 2));
    /// assert_eq!("1 foo 2", display);
    /// assert_eq!(display, debug);
    /// ```
    ///
    /// Se dokumentationen i [`std::fmt`] for at få flere oplysninger.
    ///
    /// [`Display`]: crate::fmt::Display
    /// [`Debug`]: crate::fmt::Debug
    /// [`fmt::Arguments`]: crate::fmt::Arguments
    /// [`std::fmt`]: ../std/fmt/index.html
    /// [`format!`]: ../std/macro.format.html
    /// [`println!`]: ../std/macro.println.html
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fmt;
    ///
    /// let s = fmt::format(format_args!("hello {}", "world"));
    /// assert_eq!(s, format!("hello {}", "world"));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Samme som `format_args`, men tilføjer en ny linje til sidst.
    #[unstable(
        feature = "format_args_nl",
        issue = "none",
        reason = "`format_args_nl` is only for internal \
                  language use and is subject to change"
    )]
    #[allow_internal_unstable(fmt_internals)]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! format_args_nl {
        ($fmt:expr) => {{ /* compiler built-in */ }};
        ($fmt:expr, $($args:tt)*) => {{ /* compiler built-in */ }};
    }

    /// Inspicerer en miljøvariabel på kompileringstidspunktet.
    ///
    /// Denne makro udvides til værdien af den navngivne miljøvariabel ved kompileringstidspunktet, hvilket giver et udtryk af typen `&'static str`.
    ///
    ///
    /// Hvis miljøvariablen ikke er defineret, udsendes en kompileringsfejl.
    /// Brug ikke [`option_env!`]-makroen i stedet for ikke at udsende en kompileringsfejl.
    ///
    /// # Examples
    ///
    /// ```
    /// let path: &'static str = env!("PATH");
    /// println!("the $PATH variable at the time of compiling was: {}", path);
    /// ```
    ///
    /// Du kan tilpasse fejlmeddelelsen ved at sende en streng som den anden parameter:
    ///
    /// ```compile_fail
    /// let doc: &'static str = env!("documentation", "what's that?!");
    /// ```
    ///
    /// Hvis miljøvariablen `documentation` ikke er defineret, får du følgende fejl:
    ///
    /// ```text
    /// error: what's that?!
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
        ($name:expr, $error_msg:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Valgfrit inspicerer en miljøvariabel på kompileringstidspunktet.
    ///
    /// Hvis den navngivne miljøvariabel er til stede ved kompileringstidspunktet, udvides dette til et udtryk af typen `Option<&'static str>`, hvis værdi er `Some` af værdien af miljøvariablen.
    /// Hvis miljøvariablen ikke er til stede, udvides denne til `None`.
    /// Se [`Option<T>`][Option] for at få flere oplysninger om denne type.
    ///
    /// En kompileringstidsfejl udsendes aldrig, når du bruger denne makro, uanset om miljøvariablen er til stede eller ej.
    ///
    /// # Examples
    ///
    /// ```
    /// let key: Option<&'static str> = option_env!("SECRET_KEY");
    /// println!("the secret key might be: {:?}", key);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! option_env {
        ($name:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Sammenkæder identifikatorer til en identifikator.
    ///
    /// Denne makro tager et vilkårligt antal kommaseparerede identifikatorer og sammenkæder dem alle til en, hvilket giver et udtryk, der er en ny identifikator.
    /// Bemærk, at hygiejne gør det sådan, at denne makro ikke kan opfange lokale variabler.
    /// Som hovedregel er makroer kun tilladt i element, udsagn eller udtryk.
    /// Det betyder, at mens du kan bruge denne makro til at henvise til eksisterende variabler, funktioner eller moduler osv., Kan du ikke definere en ny med den.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(concat_idents)]
    ///
    /// # fn main() {
    /// fn foobar() -> u32 { 23 }
    ///
    /// let f = concat_idents!(foo, bar);
    /// println!("{}", f());
    ///
    /// // fn concat_idents! (ny, sjov, navn) { }//ikke anvendelig på denne måde!
    /// # }
    /// ```
    ///
    ///
    ///
    #[unstable(
        feature = "concat_idents",
        issue = "29599",
        reason = "`concat_idents` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat_idents {
        ($($e:ident),+ $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Sammenkædning af bogstaver til en statisk strengskive.
    ///
    /// Denne makro tager et vilkårligt antal komma-adskilte bogstaver, hvilket giver et udtryk af typen `&'static str`, som repræsenterer alle de sammenkædede bogstaver fra venstre mod højre.
    ///
    ///
    /// Heltals-og flydende punktlitteraturer er strenget for at blive sammenkædet.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = concat!("test", 10, 'b', true);
    /// assert_eq!(s, "test10btrue");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! concat {
        ($($e:expr),* $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Udvides til det linjenummer, som det blev påberåbt sig på.
    ///
    /// Med [`column!`] og [`file!`] giver disse makroer fejlretningsoplysninger til udviklere om placeringen inden for kilden.
    ///
    /// Det udvidede udtryk har typen `u32` og er 1-baseret, så den første linje i hver fil evalueres til 1, den anden til 2 osv.
    /// Dette stemmer overens med fejlmeddelelser fra almindelige compilere eller populære redaktører.
    /// Den returnerede linje er *ikke nødvendigvis* linjen i selve `line!`-påkaldelsen, men snarere den første makroindkaldelse, der fører op til påkaldelsen af `line!`-makroen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_line = line!();
    /// println!("defined on line: {}", current_line);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! line {
        () => {
            /* compiler built-in */
        };
    }

    /// Udvides til det kolonnenummer, hvor den blev påberåbt.
    ///
    /// Med [`line!`] og [`file!`] giver disse makroer fejlretningsoplysninger til udviklere om placeringen inden for kilden.
    ///
    /// Det udvidede udtryk har typen `u32` og er 1-baseret, så den første kolonne i hver linje evalueres til 1, den anden til 2 osv.
    /// Dette stemmer overens med fejlmeddelelser fra almindelige compilere eller populære redaktører.
    /// Den returnerede kolonne er *ikke nødvendigvis* linjen i selve `column!`-påkaldelsen, men snarere den første makroindkaldelse, der fører op til påkaldelsen af `column!`-makroen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let current_col = column!();
    /// println!("defined on column: {}", current_col);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! column {
        () => {
            /* compiler built-in */
        };
    }

    /// Udvides til filnavnet, som det blev påberåbt i.
    ///
    /// Med [`line!`] og [`column!`] giver disse makroer fejlretningsoplysninger til udviklere om placeringen inden for kilden.
    ///
    /// Det udvidede udtryk har typen `&'static str`, og den returnerede fil er ikke påkaldelsen af selve `file!`-makroen, men snarere den første makroindkaldelse, der fører op til påkaldelsen af `file!`-makroen.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let this_file = file!();
    /// println!("defined in file: {}", this_file);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! file {
        () => {
            /* compiler built-in */
        };
    }

    /// Stærker dets argumenter.
    ///
    /// Denne makro giver et udtryk af typen `&'static str`, som er en strengning af alle tokens, der sendes til makroen.
    /// Der er ingen begrænsninger for syntaksen for selve makroindkaldelsen.
    ///
    /// Bemærk, at de udvidede resultater af input tokens kan ændre sig i future.Du skal være forsigtig, hvis du stoler på output.
    ///
    /// # Examples
    ///
    /// ```
    /// let one_plus_one = stringify!(1 + 1);
    /// assert_eq!(one_plus_one, "1 + 1");
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! stringify {
        ($($t:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Inkluderer en UTF-8-kodet fil som en streng.
    ///
    /// Filen er placeret i forhold til den aktuelle fil (på samme måde som hvordan moduler findes).
    /// Den medfølgende vej fortolkes på en platformsspecifik måde ved kompileringstidspunktet.
    /// Så for eksempel vil en påkaldelse med en Windows-sti indeholdende tilbageslag `\` ikke kompileres korrekt på Unix.
    ///
    ///
    /// Denne makro giver et udtryk af typen `&'static str`, som er indholdet af filen.
    ///
    /// # Examples
    ///
    /// Antag, at der er to filer i samme bibliotek med følgende indhold:
    ///
    /// Fil 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Fil 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_str = include_str!("spanish.in");
    ///     assert_eq!(my_str, "adiós\n");
    ///     print!("{}", my_str);
    /// }
    /// ```
    ///
    /// Kompilering af 'main.rs' og kørsel af den resulterende binære udskriver "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_str {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Inkluderer en fil som en reference til et byte-array.
    ///
    /// Filen er placeret i forhold til den aktuelle fil (på samme måde som hvordan moduler findes).
    /// Den medfølgende vej fortolkes på en platformsspecifik måde ved kompileringstidspunktet.
    /// Så for eksempel vil en påkaldelse med en Windows-sti indeholdende tilbageslag `\` ikke kompileres korrekt på Unix.
    ///
    ///
    /// Denne makro giver et udtryk af typen `&'static [u8; N]`, som er indholdet af filen.
    ///
    /// # Examples
    ///
    /// Antag, at der er to filer i samme bibliotek med følgende indhold:
    ///
    /// Fil 'spanish.in':
    ///
    /// ```text
    /// adiós
    /// ```
    ///
    /// Fil 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let bytes = include_bytes!("spanish.in");
    ///     assert_eq!(bytes, b"adi\xc3\xb3s\n");
    ///     print!("{}", String::from_utf8_lossy(bytes));
    /// }
    /// ```
    ///
    /// Kompilering af 'main.rs' og kørsel af den resulterende binære udskriver "adiós".
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include_bytes {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Udvides til en streng, der repræsenterer den aktuelle modulsti.
    ///
    /// Den aktuelle modulsti kan betragtes som hierarkiet af moduler, der fører tilbage til crate root.
    /// Den første komponent i den sti, der returneres, er navnet på den crate, der aktuelt bliver kompileret.
    ///
    /// # Examples
    ///
    /// ```
    /// mod test {
    ///     pub fn foo() {
    ///         assert!(module_path!().ends_with("test"));
    ///     }
    /// }
    ///
    /// test::foo();
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! module_path {
        () => {
            /* compiler built-in */
        };
    }

    /// Evaluerer boolske kombinationer af konfigurationsflag på kompileringstidspunktet.
    ///
    /// Ud over `#[cfg]`-attributten er denne makro tilvejebragt for at tillade boolsk udtrykvurdering af konfigurationsflag.
    /// Dette fører ofte til mindre duplikeret kode.
    ///
    /// Syntaksen til denne makro er den samme syntaks som [`cfg`]-attributten.
    ///
    /// `cfg!`, i modsætning til `#[cfg]` fjerner ikke nogen kode og evalueres kun til sand eller falsk.
    /// For eksempel skal alle blokke i et if/else-udtryk være gyldige, når `cfg!` bruges til tilstanden, uanset hvad `cfg!` vurderer.
    ///
    ///
    /// [`cfg`]: ../reference/conditional-compilation.html#the-cfg-attribute
    ///
    /// # Examples
    ///
    /// ```
    /// let my_directory = if cfg!(windows) {
    ///     "windows-specific-directory"
    /// } else {
    ///     "unix-directory"
    /// };
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! cfg {
        ($($cfg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Parser en fil som et udtryk eller et element i henhold til konteksten.
    ///
    /// Filen er placeret i forhold til den aktuelle fil (på samme måde som hvordan moduler findes).Den medfølgende vej fortolkes på en platformsspecifik måde ved kompileringstidspunktet.
    /// Så for eksempel vil en påkaldelse med en Windows-sti indeholdende tilbageslag `\` ikke kompileres korrekt på Unix.
    ///
    /// Brug af denne makro er ofte en dårlig idé, for hvis filen parses som et udtryk, placeres den uhygiejnisk i den omgivende kode.
    /// Dette kan resultere i, at variabler eller funktioner adskiller sig fra, hvad filen forventede, hvis der er variabler eller funktioner, der har samme navn i den aktuelle fil.
    ///
    ///
    /// # Examples
    ///
    /// Antag, at der er to filer i samme bibliotek med følgende indhold:
    ///
    /// Fil 'monkeys.in':
    ///
    /// ```ignore (only-for-syntax-highlight)
    /// ['🙈', '🙊', '🙉']
    ///     .iter()
    ///     .cycle()
    ///     .take(6)
    ///     .collect::<String>()
    /// ```
    ///
    /// Fil 'main.rs':
    ///
    /// ```ignore (cannot-doctest-external-file-dependency)
    /// fn main() {
    ///     let my_string = include!("monkeys.in");
    ///     assert_eq!("🙈🙊🙉🙈🙊🙉", my_string);
    ///     println!("{}", my_string);
    /// }
    /// ```
    ///
    /// Kompilering af 'main.rs' og kørsel af den resulterende binære udskriver "🙈🙊🙉🙈🙊🙉".
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! include {
        ($file:expr $(,)?) => {{ /* compiler built-in */ }};
    }

    /// Påstår, at et boolsk udtryk er `true` ved kørsel.
    ///
    /// Dette påkalder [`panic!`]-makroen, hvis det angivne udtryk ikke kan evalueres til `true` ved kørsel.
    ///
    /// # Uses
    ///
    /// Påstande kontrolleres altid i både fejlfindings-og frigivelsesbygninger og kan ikke deaktiveres.
    /// Se [`debug_assert!`] for påstande, der ikke er aktiveret i udgivelsesbygninger som standard.
    ///
    /// Usikker kode kan stole på `assert!` for at håndhæve runtime invarianters, der, hvis de overtrædes, kan føre til usikkerhed.
    ///
    /// Andre anvendelsestilfælde af `assert!` inkluderer test og håndhævelse af run-time invariantere i sikker kode (hvis overtrædelse ikke kan resultere i usikkerhed).
    ///
    ///
    /// # Brugerdefinerede meddelelser
    ///
    /// Denne makro har en anden form, hvor en brugerdefineret panic-meddelelse kan leveres med eller uden argumenter til formatering.
    /// Se [`std::fmt`] for syntaks for denne formular.
    /// Udtryk, der bruges som formatargumenter, evalueres kun, hvis påstanden mislykkes.
    ///
    /// [`std::fmt`]: ../std/fmt/index.html
    ///
    /// # Examples
    ///
    /// ```
    /// // panic-meddelelsen for disse påstande er den strengede værdi af det givne udtryk.
    /////
    /// assert!(true);
    ///
    /// fn some_computation() -> bool { true } // en meget enkel funktion
    ///
    /// assert!(some_computation());
    ///
    /// // hævde med en brugerdefineret besked
    /// let x = true;
    /// assert!(x, "x wasn't true!");
    ///
    /// let a = 3; let b = 27;
    /// assert!(a + b == 30, "a = {}, b = {}", a, b);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    #[macro_export]
    #[rustc_diagnostic_item = "assert_macro"]
    #[allow_internal_unstable(core_panic, edition_panic)]
    macro_rules! assert {
        ($cond:expr $(,)?) => {{ /* compiler built-in */ }};
        ($cond:expr, $($arg:tt)+) => {{ /* compiler built-in */ }};
    }

    /// Integreret samling.
    ///
    /// Læs [unstable book] for brug.
    ///
    /// [unstable book]: ../unstable-book/library-features/asm.html
    #[unstable(
        feature = "asm",
        issue = "72016",
        reason = "inline assembly is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! asm {
        ("assembly template",
            $(operands,)*
            $(options($(option),*))?
        ) => {
            /* compiler built-in */
        };
    }

    /// LLVM-stil inline-samling.
    ///
    /// Læs [unstable book] for brug.
    ///
    /// [unstable book]: ../unstable-book/library-features/llvm-asm.html
    #[unstable(
        feature = "llvm_asm",
        issue = "70173",
        reason = "prefer using the new asm! syntax instead"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! llvm_asm {
        ("assembly template"
                        : $("output"(operand),)*
                        : $("input"(operand),)*
                        : $("clobbers",)*
                        : $("options",)*) => {
            /* compiler built-in */
        };
    }

    /// Inline-samling på modulniveau.
    #[unstable(
        feature = "global_asm",
        issue = "35119",
        reason = "`global_asm!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! global_asm {
        ("assembly") => {
            /* compiler built-in */
        };
    }

    /// Udskrifter overførte tokens til standardoutput.
    #[unstable(
        feature = "log_syntax",
        issue = "29598",
        reason = "`log_syntax!` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! log_syntax {
        ($($arg:tt)*) => {
            /* compiler built-in */
        };
    }

    /// Aktiverer eller deaktiverer sporingsfunktionalitet, der bruges til fejlretning af andre makroer.
    #[unstable(
        feature = "trace_macros",
        issue = "29598",
        reason = "`trace_macros` is not stable enough for use and is subject to change"
    )]
    #[rustc_builtin_macro]
    #[macro_export]
    macro_rules! trace_macros {
        (true) => {{ /* compiler built-in */ }};
        (false) => {{ /* compiler built-in */ }};
    }

    /// Attributmakro, der bruges til at anvende afledte makroer.
    #[cfg(not(bootstrap))]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_builtin_macro]
    pub macro derive($item:item) {
        /* compiler built-in */
    }

    /// Attributmakro anvendt på en funktion for at gøre den til en enhedstest.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test($item:item) {
        /* compiler built-in */
    }

    /// Attributmakro anvendt på en funktion for at gøre den til en benchmark-test.
    #[unstable(
        feature = "test",
        issue = "50297",
        soft,
        reason = "`bench` is a part of custom test frameworks which are unstable"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro bench($item:item) {
        /* compiler built-in */
    }

    /// En implementeringsdetalje af `#[test]`-og `#[bench]`-makroerne.
    #[unstable(
        feature = "custom_test_frameworks",
        issue = "50297",
        reason = "custom test frameworks are an unstable feature"
    )]
    #[allow_internal_unstable(test, rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro test_case($item:item) {
        /* compiler built-in */
    }

    /// Attributmakro anvendt på en statisk for at registrere den som en global tildeler.
    ///
    /// Se også [`std::alloc::GlobalAlloc`](../std/alloc/trait.GlobalAlloc.html).
    #[stable(feature = "global_allocator", since = "1.28.0")]
    #[allow_internal_unstable(rustc_attrs)]
    #[rustc_builtin_macro]
    pub macro global_allocator($item:item) {
        /* compiler built-in */
    }

    /// Holder det element, det er anvendt på, hvis den beståede sti er tilgængelig, og fjerner det ellers.
    #[unstable(
        feature = "cfg_accessible",
        issue = "64797",
        reason = "`cfg_accessible` is not fully implemented"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_accessible($item:item) {
        /* compiler built-in */
    }

    /// Udvider alle `#[cfg]`-og `#[cfg_attr]`-attributter i det kodefragment, det er anvendt på.
    #[cfg(not(bootstrap))]
    #[unstable(
        feature = "cfg_eval",
        issue = "82679",
        reason = "`cfg_eval` is a recently implemented feature"
    )]
    #[rustc_builtin_macro]
    pub macro cfg_eval($($tt:tt)*) {
        /* compiler built-in */
    }

    /// Ustabil implementeringsdetalje af `rustc`-kompilatoren må ikke bruges.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics, libstd_sys_internals)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcDecodable($item:item) {
        /* compiler built-in */
    }

    /// Ustabil implementeringsdetalje af `rustc`-kompilatoren må ikke bruges.
    #[rustc_builtin_macro]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[allow_internal_unstable(core_intrinsics)]
    #[rustc_deprecated(
        since = "1.52.0",
        reason = "rustc-serialize is deprecated and no longer supported"
    )]
    pub macro RustcEncodable($item:item) {
        /* compiler built-in */
    }
}