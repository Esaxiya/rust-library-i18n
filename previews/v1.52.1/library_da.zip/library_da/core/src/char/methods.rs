//! impl char {}

use crate::intrinsics::likely;
use crate::slice;
use crate::str::from_utf8_unchecked_mut;
use crate::unicode::printable::is_printable;
use crate::unicode::{self, conversions};

use super::*;

#[lang = "char"]
impl char {
    /// Det højeste gyldige kodepunkt, som en `char` kan have.
    ///
    /// En `char` er en [Unicode Scalar Value], hvilket betyder, at den er en [Code Point], men kun dem inden for et bestemt område.
    /// `MAX` er det højeste gyldige kodepunkt, der er et gyldigt [Unicode Scalar Value].
    ///
    /// [Unicode Scalar Value]: http://www.unicode.org/glossary/#unicode_scalar_value
    /// [Code Point]: http://www.unicode.org/glossary/#code_point
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const MAX: char = '\u{10ffff}';

    /// `U+FFFD REPLACEMENT CHARACTER` () bruges i Unicode til at repræsentere en afkodningsfejl.
    ///
    /// Det kan f.eks. Forekomme, når der gives dårligt dannede UTF-8-byte til [`String::from_utf8_lossy`](string/struct.String.html#method.from_utf8_lossy).
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const REPLACEMENT_CHARACTER: char = '\u{FFFD}';

    /// Den version af [Unicode](http://www.unicode.org/), som Unicode-delene af `char`-og `str`-metoderne er baseret på.
    ///
    /// Nye versioner af Unicode frigives regelmæssigt, og derefter opdateres alle metoder i standardbiblioteket afhængigt af Unicode.
    /// Derfor ændres adfærden for nogle `char`-og `str`-metoder og værdien af denne konstant over tid.
    /// Dette betragtes *ikke* som en brudende ændring.
    ///
    /// Versionsnummereringsskemaet er forklaret i [Unicode 11.0 or later, Section 3.1 Versions of the Unicode Standard](https://www.unicode.org/versions/Unicode11.0.0/ch03.pdf#page=4).
    ///
    ///
    ///
    #[stable(feature = "assoc_char_consts", since = "1.52.0")]
    pub const UNICODE_VERSION: (u8, u8, u8) = crate::unicode::UNICODE_VERSION;

    /// Opretter en iterator over UTF-16-kodede kodepunkter i `iter` og returnerer uparede surrogater som ``Err`s.
    ///
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// use std::char::decode_utf16;
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///         .map(|r| r.map_err(|e| e.unpaired_surrogate()))
    ///         .collect::<Vec<_>>(),
    ///     vec![
    ///         Ok('𝄞'),
    ///         Ok('m'), Ok('u'), Ok('s'),
    ///         Err(0xDD1E),
    ///         Ok('i'), Ok('c'),
    ///         Err(0xD834)
    ///     ]
    /// );
    /// ```
    ///
    /// En tabsfri dekoder kan opnås ved at erstatte `Err`-resultater med erstatningskarakteren:
    ///
    /// ```
    /// use std::char::{decode_utf16, REPLACEMENT_CHARACTER};
    ///
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = [
    ///     0xD834, 0xDD1E, 0x006d, 0x0075, 0x0073, 0xDD1E, 0x0069, 0x0063, 0xD834,
    /// ];
    ///
    /// assert_eq!(
    ///     decode_utf16(v.iter().cloned())
    ///        .map(|r| r.unwrap_or(REPLACEMENT_CHARACTER))
    ///        .collect::<String>(),
    ///     "𝄞mus�ic�"
    /// );
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn decode_utf16<I: IntoIterator<Item = u16>>(iter: I) -> DecodeUtf16<I::IntoIter> {
        super::decode::decode_utf16(iter)
    }

    /// Konverterer en `u32` til en `char`.
    ///
    /// Bemærk, at alle `char`s er gyldige [`u32`] s og kan kastes til en med
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Det omvendte er dog ikke sandt: ikke alle gyldige [`u32`] er gyldige`char`s.
    /// `from_u32()` returnerer `None`, hvis input ikke er en gyldig værdi for en `char`.
    ///
    /// For en usikker version af denne funktion, der ignorerer disse kontroller, se [`from_u32_unchecked`].
    ///
    ///
    /// [`from_u32_unchecked`]: #method.from_u32_unchecked
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x2764);
    ///
    /// assert_eq!(Some('❤'), c);
    /// ```
    ///
    /// Returnering af `None`, når input ikke er en gyldig `char`:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_u32(0x110000);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_u32(i: u32) -> Option<char> {
        super::convert::from_u32(i)
    }

    /// Konverterer en `u32` til en `char` og ignorerer gyldigheden.
    ///
    /// Bemærk, at alle `char`s er gyldige [`u32`] s og kan kastes til en med
    /// `as`:
    ///
    /// ```
    /// let c = '💯';
    /// let i = c as u32;
    ///
    /// assert_eq!(128175, i);
    /// ```
    ///
    /// Det omvendte er dog ikke sandt: ikke alle gyldige [`u32`] er gyldige`char`s.
    /// `from_u32_unchecked()` vil ignorere dette og blindt castes til `char` og muligvis skabe en ugyldig.
    ///
    ///
    /// # Safety
    ///
    /// Denne funktion er usikker, da den kan konstruere ugyldige `char`-værdier.
    ///
    /// For en sikker version af denne funktion, se [`from_u32`]-funktionen.
    ///
    /// [`from_u32`]: #method.from_u32
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = unsafe { char::from_u32_unchecked(0x2764) };
    ///
    /// assert_eq!('❤', c);
    /// ```
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub unsafe fn from_u32_unchecked(i: u32) -> char {
        // SIKKERHED: sikkerhedskontrakten skal opretholdes af den, der ringer op.
        unsafe { super::convert::from_u32_unchecked(i) }
    }

    /// Konverterer et ciffer i den givne radix til en `char`.
    ///
    /// En 'radix' her kaldes undertiden også en 'base'.
    /// En radix på to angiver et binært tal, en radix på ti, decimal og en radix på seksten, hexadecimal, for at give nogle fælles værdier.
    ///
    /// Vilkårlige stråler understøttes.
    ///
    /// `from_digit()` returnerer `None`, hvis input ikke er et ciffer i den givne radix.
    ///
    /// # Panics
    ///
    /// Panics hvis der gives en radix større end 36.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(4, 10);
    ///
    /// assert_eq!(Some('4'), c);
    ///
    /// // Decimal 11 er et enkelt ciffer i base 16
    /// let c = char::from_digit(11, 16);
    ///
    /// assert_eq!(Some('b'), c);
    /// ```
    ///
    /// Returnerer `None`, når input ikke er et ciffer:
    ///
    /// ```
    /// use std::char;
    ///
    /// let c = char::from_digit(20, 10);
    ///
    /// assert_eq!(None, c);
    /// ```
    ///
    /// At passere en stor radix og forårsage en panic:
    ///
    /// ```should_panic
    /// use std::char;
    ///
    /// // this panics
    /// char::from_digit(1, 37);
    /// ```
    ///
    #[stable(feature = "assoc_char_funcs", since = "1.52.0")]
    #[inline]
    pub fn from_digit(num: u32, radix: u32) -> Option<char> {
        super::convert::from_digit(num, radix)
    }

    /// Kontrollerer, om en `char` er et ciffer i den givne radix.
    ///
    /// En 'radix' her kaldes undertiden også en 'base'.
    /// En radix på to angiver et binært tal, en radix på ti, decimal og en radix på seksten, hexadecimal, for at give nogle fælles værdier.
    ///
    /// Vilkårlige stråler understøttes.
    ///
    /// Sammenlignet med [`is_numeric()`] genkender denne funktion kun tegnene `0-9`, `a-z` og `A-Z`.
    ///
    /// 'Digit' er defineret til kun at være følgende tegn:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// For en mere omfattende forståelse af 'digit', se [`is_numeric()`].
    ///
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Panics
    ///
    /// Panics hvis der gives en radix større end 36.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// assert!('1'.is_digit(10));
    /// assert!('f'.is_digit(16));
    /// assert!(!'f'.is_digit(10));
    /// ```
    ///
    /// At passere en stor radix og forårsage en panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.is_digit(37);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_digit(self, radix: u32) -> bool {
        self.to_digit(radix).is_some()
    }

    /// Konverterer en `char` til et ciffer i den givne radix.
    ///
    /// En 'radix' her kaldes undertiden også en 'base'.
    /// En radix på to angiver et binært tal, en radix på ti, decimal og en radix på seksten, hexadecimal, for at give nogle fælles værdier.
    ///
    /// Vilkårlige stråler understøttes.
    ///
    /// 'Digit' er defineret til kun at være følgende tegn:
    ///
    /// * `0-9`
    /// * `a-z`
    /// * `A-Z`
    ///
    /// # Errors
    ///
    /// Returnerer `None`, hvis `char` ikke henviser til et ciffer i den givne radix.
    ///
    /// # Panics
    ///
    /// Panics hvis der gives en radix større end 36.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// assert_eq!('1'.to_digit(10), Some(1));
    /// assert_eq!('f'.to_digit(16), Some(15));
    /// ```
    ///
    /// At sende et ikke-cifret resulterer i fejl:
    ///
    /// ```
    /// assert_eq!('f'.to_digit(10), None);
    /// assert_eq!('z'.to_digit(16), None);
    /// ```
    ///
    /// At passere en stor radix og forårsage en panic:
    ///
    /// ```should_panic
    /// // this panics
    /// '1'.to_digit(37);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_digit(self, radix: u32) -> Option<u32> {
        assert!(radix <= 36, "to_digit: radix is too high (maximum 36)");
        // koden er opdelt her for at forbedre eksekveringshastigheden i tilfælde, hvor `radix` er konstant og 10 eller mindre
        //
        let val = if likely(radix <= 10) {
            // Hvis ikke et ciffer, oprettes et tal større end radix.
            (self as u32).wrapping_sub('0' as u32)
        } else {
            match self {
                '0'..='9' => self as u32 - '0' as u32,
                'a'..='z' => self as u32 - 'a' as u32 + 10,
                'A'..='Z' => self as u32 - 'A' as u32 + 10,
                _ => return None,
            }
        };

        if val < radix { Some(val) } else { None }
    }

    /// Returnerer en iterator, der giver den hexadecimale Unicode-flugt af et tegn som `char`s.
    ///
    /// Dette undgår tegn med Rust-syntaksen for formen `\u{NNNNNN}`, hvor `NNNNNN` er en hexadecimal repræsentation.
    ///
    ///
    /// # Examples
    ///
    /// Som iterator:
    ///
    /// ```
    /// for c in '❤'.escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Brug af `println!` direkte:
    ///
    /// ```
    /// println!("{}", '❤'.escape_unicode());
    /// ```
    ///
    /// Begge svarer til:
    ///
    /// ```
    /// println!("\\u{{2764}}");
    /// ```
    ///
    /// Brug af `to_string`:
    ///
    /// ```
    /// assert_eq!('❤'.escape_unicode().to_string(), "\\u{2764}");
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_unicode(self) -> EscapeUnicode {
        let c = self as u32;

        // eller-ing 1 sikrer, at for c==0 koden beregner, at et ciffer skal udskrives og (hvilket er det samme) undgår (31, 32) underflow
        //
        //
        let msb = 31 - (c | 1).leading_zeros();

        // indekset for det mest signifikante hex-ciffer
        let ms_hex_digit = msb / 4;
        EscapeUnicode {
            c: self,
            state: EscapeUnicodeState::Backslash,
            hex_digit_idx: ms_hex_digit as usize,
        }
    }

    /// En udvidet version af `escape_debug`, der valgfrit tillader at undslippe udvidede Grapheme-kodepunkter.
    /// Dette giver os mulighed for at formatere tegn som ikke-mellemrumstegn bedre, når de er i starten af en streng.
    ///
    #[inline]
    pub(crate) fn escape_debug_ext(self, escape_grapheme_extended: bool) -> EscapeDebug {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            _ if escape_grapheme_extended && self.is_grapheme_extended() => {
                EscapeDefaultState::Unicode(self.escape_unicode())
            }
            _ if is_printable(self) => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDebug(EscapeDefault { state: init_state })
    }

    /// Returnerer en iterator, der giver den bogstavelige flugtkode for et tegn som `char`s.
    ///
    /// Dette undgår tegn, der ligner `Debug`-implementeringerne af `str` eller `char`.
    ///
    ///
    /// # Examples
    ///
    /// Som iterator:
    ///
    /// ```
    /// for c in '\n'.escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Brug af `println!` direkte:
    ///
    /// ```
    /// println!("{}", '\n'.escape_debug());
    /// ```
    ///
    /// Begge svarer til:
    ///
    /// ```
    /// println!("\\n");
    /// ```
    ///
    /// Brug af `to_string`:
    ///
    /// ```
    /// assert_eq!('\n'.escape_debug().to_string(), "\\n");
    /// ```
    ///
    #[stable(feature = "char_escape_debug", since = "1.20.0")]
    #[inline]
    pub fn escape_debug(self) -> EscapeDebug {
        self.escape_debug_ext(true)
    }

    /// Returnerer en iterator, der giver den bogstavelige flugtkode for et tegn som `char`s.
    ///
    /// Standard er valgt med en bias mod at producere bogstaver, der er lovlige på en række forskellige sprog, herunder C++ 11 og lignende C-familie sprog.
    /// De nøjagtige regler er:
    ///
    /// * Fanen undslippes som `\t`.
    /// * Vognretur er undsluppet som `\r`.
    /// * Linjefødning undslippes som `\n`.
    /// * Enkelt tilbud er undsluppet som `\'`.
    /// * Dobbelt tilbud er undsluppet som `\"`.
    /// * Backslash undslippes som `\\`.
    /// * Ethvert tegn i det 'udskrivbare ASCII'-område `0x20` .. `0x7e` inklusive undgår ikke.
    /// * Alle andre tegn får hexadecimal Unicode-undslip;se [`escape_unicode`].
    ///
    /// [`escape_unicode`]: #method.escape_unicode
    ///
    /// # Examples
    ///
    /// Som iterator:
    ///
    /// ```
    /// for c in '"'.escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Brug af `println!` direkte:
    ///
    /// ```
    /// println!("{}", '"'.escape_default());
    /// ```
    ///
    /// Begge svarer til:
    ///
    /// ```
    /// println!("\\\"");
    /// ```
    ///
    /// Brug af `to_string`:
    ///
    /// ```
    /// assert_eq!('"'.escape_default().to_string(), "\\\"");
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn escape_default(self) -> EscapeDefault {
        let init_state = match self {
            '\t' => EscapeDefaultState::Backslash('t'),
            '\r' => EscapeDefaultState::Backslash('r'),
            '\n' => EscapeDefaultState::Backslash('n'),
            '\\' | '\'' | '"' => EscapeDefaultState::Backslash(self),
            '\x20'..='\x7e' => EscapeDefaultState::Char(self),
            _ => EscapeDefaultState::Unicode(self.escape_unicode()),
        };
        EscapeDefault { state: init_state }
    }

    /// Returnerer antallet af byte, som denne `char` har brug for, hvis den er kodet i UTF-8.
    ///
    /// Antallet af byte er altid mellem 1 og 4 inklusive.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let len = 'A'.len_utf8();
    /// assert_eq!(len, 1);
    ///
    /// let len = 'ß'.len_utf8();
    /// assert_eq!(len, 2);
    ///
    /// let len = 'ℝ'.len_utf8();
    /// assert_eq!(len, 3);
    ///
    /// let len = '💣'.len_utf8();
    /// assert_eq!(len, 4);
    /// ```
    ///
    /// `&str`-typen garanterer, at dens indhold er UTF-8, og så kan vi sammenligne den længde, det ville tage, hvis hvert kodepunkt blev repræsenteret som en `char` vs i selve `&str`:
    ///
    ///
    /// ```
    /// // som tegn
    /// let eastern = '東';
    /// let capital = '京';
    ///
    /// // begge kan repræsenteres som tre byte
    /// assert_eq!(3, eastern.len_utf8());
    /// assert_eq!(3, capital.len_utf8());
    ///
    /// // som en &str er disse to kodet i UTF-8
    /// let tokyo = "東京";
    ///
    /// let len = eastern.len_utf8() + capital.len_utf8();
    ///
    /// // vi kan se, at de tager seks bytes i alt ...
    /// assert_eq!(6, tokyo.len());
    ///
    /// // ... ligesom &str
    /// assert_eq!(len, tokyo.len());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf8(self) -> usize {
        len_utf8(self as u32)
    }

    /// Returnerer antallet af 16-bit kodeenheder, som denne `char` har brug for, hvis kodet i UTF-16.
    ///
    ///
    /// Se dokumentationen til [`len_utf8()`] for at få flere forklaringer på dette koncept.
    /// Denne funktion er et spejl, men for UTF-16 i stedet for UTF-8.
    ///
    /// [`len_utf8()`]: #method.len_utf8
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let n = 'ß'.len_utf16();
    /// assert_eq!(n, 1);
    ///
    /// let len = '💣'.len_utf16();
    /// assert_eq!(len, 2);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_char_len_utf", since = "1.52.0")]
    #[inline]
    pub const fn len_utf16(self) -> usize {
        let ch = self as u32;
        if (ch & 0xFFFF) == ch { 1 } else { 2 }
    }

    /// Koder dette tegn som UTF-8 i den tilvejebragte bytebuffer, og returnerer derefter underdelen af bufferen, der indeholder det kodede tegn.
    ///
    ///
    /// # Panics
    ///
    /// Panics hvis bufferen ikke er stor nok.
    /// En buffer med længde fire er stor nok til at kode for enhver `char`.
    ///
    /// # Examples
    ///
    /// I begge disse eksempler tager 'ß' to byte til at kode.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = 'ß'.encode_utf8(&mut b);
    ///
    /// assert_eq!(result, "ß");
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// En buffer, der er for lille:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// 'ß'.encode_utf8(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf8(self, dst: &mut [u8]) -> &mut str {
        // SIKKERHED: `char` er ikke et surrogat, så dette er gyldigt UTF-8.
        unsafe { from_utf8_unchecked_mut(encode_utf8_raw(self as u32, dst)) }
    }

    /// Koder dette tegn som UTF-16 i den medfølgende `u16`-buffer, og returnerer derefter underdelen af bufferen, der indeholder det kodede tegn.
    ///
    ///
    /// # Panics
    ///
    /// Panics hvis bufferen ikke er stor nok.
    /// En buffer med længde 2 er stor nok til at kode for enhver `char`.
    ///
    /// # Examples
    ///
    /// I begge disse eksempler tager '𝕊' to `u16`er at kode.
    ///
    /// ```
    /// let mut b = [0; 2];
    ///
    /// let result = '𝕊'.encode_utf16(&mut b);
    ///
    /// assert_eq!(result.len(), 2);
    /// ```
    ///
    /// En buffer, der er for lille:
    ///
    /// ```should_panic
    /// let mut b = [0; 1];
    ///
    /// // this panics
    /// '𝕊'.encode_utf16(&mut b);
    /// ```
    #[stable(feature = "unicode_encode_char", since = "1.15.0")]
    #[inline]
    pub fn encode_utf16(self, dst: &mut [u16]) -> &mut [u16] {
        encode_utf16_raw(self as u32, dst)
    }

    /// Returnerer `true`, hvis denne `char` har `Alphabetic`-egenskaben.
    ///
    /// `Alphabetic` er beskrevet i kapitel 4 (Karakteregenskaber) i [Unicode Standard] og specificeret i [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// assert!('a'.is_alphabetic());
    /// assert!('京'.is_alphabetic());
    ///
    /// let c = '💝';
    /// // kærlighed er mange ting, men det er ikke alfabetisk
    /// assert!(!c.is_alphabetic());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphabetic(self) -> bool {
        match self {
            'a'..='z' | 'A'..='Z' => true,
            c => c > '\x7f' && unicode::Alphabetic(c),
        }
    }

    /// Returnerer `true`, hvis denne `char` har `Lowercase`-egenskaben.
    ///
    /// `Lowercase` er beskrevet i kapitel 4 (Karakteregenskaber) i [Unicode Standard] og specificeret i [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// assert!('a'.is_lowercase());
    /// assert!('δ'.is_lowercase());
    /// assert!(!'A'.is_lowercase());
    /// assert!(!'Δ'.is_lowercase());
    ///
    /// // De forskellige kinesiske manuskripter og tegnsætningstegn har ikke sag, og så:
    /// assert!(!'中'.is_lowercase());
    /// assert!(!' '.is_lowercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_lowercase(self) -> bool {
        match self {
            'a'..='z' => true,
            c => c > '\x7f' && unicode::Lowercase(c),
        }
    }

    /// Returnerer `true`, hvis denne `char` har `Uppercase`-egenskaben.
    ///
    /// `Uppercase` er beskrevet i kapitel 4 (Karakteregenskaber) i [Unicode Standard] og specificeret i [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// assert!(!'a'.is_uppercase());
    /// assert!(!'δ'.is_uppercase());
    /// assert!('A'.is_uppercase());
    /// assert!('Δ'.is_uppercase());
    ///
    /// // De forskellige kinesiske manuskripter og tegnsætningstegn har ikke sag, og så:
    /// assert!(!'中'.is_uppercase());
    /// assert!(!' '.is_uppercase());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_uppercase(self) -> bool {
        match self {
            'A'..='Z' => true,
            c => c > '\x7f' && unicode::Uppercase(c),
        }
    }

    /// Returnerer `true`, hvis denne `char` har `White_Space`-egenskaben.
    ///
    /// `White_Space` er specificeret i [Unicode Character Database][ucd] [`PropList.txt`].
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`PropList.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/PropList.txt
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// assert!(' '.is_whitespace());
    ///
    /// // et ikke-brudende rum
    /// assert!('\u{A0}'.is_whitespace());
    ///
    /// assert!(!'越'.is_whitespace());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_whitespace(self) -> bool {
        match self {
            ' ' | '\x09'..='\x0d' => true,
            c => c > '\x7f' && unicode::White_Space(c),
        }
    }

    /// Returnerer `true`, hvis denne `char` opfylder enten [`is_alphabetic()`] eller [`is_numeric()`].
    ///
    /// [`is_alphabetic()`]: #method.is_alphabetic
    /// [`is_numeric()`]: #method.is_numeric
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// assert!('٣'.is_alphanumeric());
    /// assert!('7'.is_alphanumeric());
    /// assert!('৬'.is_alphanumeric());
    /// assert!('¾'.is_alphanumeric());
    /// assert!('①'.is_alphanumeric());
    /// assert!('K'.is_alphanumeric());
    /// assert!('و'.is_alphanumeric());
    /// assert!('藏'.is_alphanumeric());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_alphanumeric(self) -> bool {
        self.is_alphabetic() || self.is_numeric()
    }

    /// Returnerer `true`, hvis denne `char` har den generelle kategori for kontrolkoder.
    ///
    /// Kontrolkoder (kodepunkter med den generelle kategori `Cc`) er beskrevet i kapitel 4 (Karakteregenskaber) på [Unicode Standard] og specificeret i [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// // U + 009C, STRINGTERMINATOR
    /// assert!(''.is_control());
    /// assert!(!'q'.is_control());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_control(self) -> bool {
        unicode::Cc(self)
    }

    /// Returnerer `true`, hvis denne `char` har `Grapheme_Extend`-egenskaben.
    ///
    /// `Grapheme_Extend` er beskrevet i [Unicode Standard Annex #29 (Unicode Text Segmentation)][uax29] og specificeret i [Unicode Character Database][ucd] [`DerivedCoreProperties.txt`].
    ///
    ///
    /// [uax29]: https://www.unicode.org/reports/tr29/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`DerivedCoreProperties.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/DerivedCoreProperties.txt
    ///
    #[inline]
    pub(crate) fn is_grapheme_extended(self) -> bool {
        unicode::Grapheme_Extend(self)
    }

    /// Returnerer `true`, hvis denne `char` har en af de generelle kategorier for numre.
    ///
    /// De generelle kategorier for tal (`Nd` for decimaltegn, `Nl` for bogstavlignende numeriske tegn og `No` for andre numeriske tegn) er specificeret i [Unicode Character Database][ucd] [`UnicodeData.txt`].
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// assert!('٣'.is_numeric());
    /// assert!('7'.is_numeric());
    /// assert!('৬'.is_numeric());
    /// assert!('¾'.is_numeric());
    /// assert!('①'.is_numeric());
    /// assert!(!'K'.is_numeric());
    /// assert!(!'و'.is_numeric());
    /// assert!(!'藏'.is_numeric());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is_numeric(self) -> bool {
        match self {
            '0'..='9' => true,
            c => c > '\x7f' && unicode::N(c),
        }
    }

    /// Returnerer en iterator, der giver en lille eller mindre kortlægning af denne `char` som en eller flere
    /// `char`s.
    ///
    /// Hvis denne `char` ikke har en lille kortlægning, giver iteratoren den samme `char`.
    ///
    /// Hvis denne `char` har en en-til-en-kortlægning med små bogstaver givet af [Unicode Character Database][ucd] [`UnicodeData.txt`], giver iteratoren den `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Hvis denne `char` kræver særlige overvejelser (f.eks. Flere `char`s), giver iteratoren den`char` (er), der er givet af [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Denne operation udfører en ubetinget kortlægning uden skræddersyet.Det vil sige, konverteringen er uafhængig af kontekst og sprog.
    ///
    /// I [Unicode Standard] diskuterer kapitel 4 (Karakteregenskaber) sagsmapping generelt og kapitel 3 (Conformance) drøfter standardalgoritmen til sagsomdannelse.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Som iterator:
    ///
    /// ```
    /// for c in 'İ'.to_lowercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Brug af `println!` direkte:
    ///
    /// ```
    /// println!("{}", 'İ'.to_lowercase());
    /// ```
    ///
    /// Begge svarer til:
    ///
    /// ```
    /// println!("i\u{307}");
    /// ```
    ///
    /// Brug af `to_string`:
    ///
    /// ```
    /// assert_eq!('C'.to_lowercase().to_string(), "c");
    ///
    /// // Nogle gange er resultatet mere end et tegn:
    /// assert_eq!('İ'.to_lowercase().to_string(), "i\u{307}");
    ///
    /// // Tegn, der ikke har både store og små bogstaver konverteres til sig selv.
    /////
    /// assert_eq!('山'.to_lowercase().to_string(), "山");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_lowercase(self) -> ToLowercase {
        ToLowercase(CaseMappingIter::new(conversions::to_lower(self)))
    }

    /// Returnerer en iterator, der giver den store bogstav for denne `char` som en eller flere
    /// `char`s.
    ///
    /// Hvis denne `char` ikke har en stor kortlægning, giver iteratoren den samme `char`.
    ///
    /// Hvis denne `char` har en en-til-en-kortlægning med store bogstaver givet af [Unicode Character Database][ucd] [`UnicodeData.txt`], giver iteratoren den `char`.
    ///
    /// [ucd]: https://www.unicode.org/reports/tr44/
    /// [`UnicodeData.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/UnicodeData.txt
    ///
    /// Hvis denne `char` kræver særlige overvejelser (f.eks. Flere `char`s), giver iteratoren den`char` (er), der er givet af [`SpecialCasing.txt`].
    ///
    /// [`SpecialCasing.txt`]: https://www.unicode.org/Public/UCD/latest/ucd/SpecialCasing.txt
    ///
    /// Denne operation udfører en ubetinget kortlægning uden skræddersyet.Det vil sige, konverteringen er uafhængig af kontekst og sprog.
    ///
    /// I [Unicode Standard] diskuterer kapitel 4 (Karakteregenskaber) sagsmapping generelt og kapitel 3 (Conformance) drøfter standardalgoritmen til sagsomdannelse.
    ///
    ///
    /// [Unicode Standard]: https://www.unicode.org/versions/latest/
    ///
    /// # Examples
    ///
    /// Som iterator:
    ///
    /// ```
    /// for c in 'ß'.to_uppercase() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Brug af `println!` direkte:
    ///
    /// ```
    /// println!("{}", 'ß'.to_uppercase());
    /// ```
    ///
    /// Begge svarer til:
    ///
    /// ```
    /// println!("SS");
    /// ```
    ///
    /// Brug af `to_string`:
    ///
    /// ```
    /// assert_eq!('c'.to_uppercase().to_string(), "C");
    ///
    /// // Nogle gange er resultatet mere end et tegn:
    /// assert_eq!('ß'.to_uppercase().to_string(), "SS");
    ///
    /// // Tegn, der ikke har både store og små bogstaver konverteres til sig selv.
    /////
    /// assert_eq!('山'.to_uppercase().to_string(), "山");
    /// ```
    ///
    /// # Bemærkning om lokalitet
    ///
    /// På tyrkisk har ækvivalenten 'i' på latin fem former i stedet for to:
    ///
    /// * 'Dotless': I/ı, undertiden skrevet ï
    /// * 'Dotted': I/i
    ///
    /// Bemærk, at 'i' med små bogstaver er den samme som latin.Derfor:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    /// ```
    ///
    /// Værdien af `upper_i` her er afhængig af sprogets tekst: hvis vi er i `en-US`, skal den være `"I"`, men hvis vi er i `tr_TR`, skal den være `"İ"`.
    /// `to_uppercase()` tager ikke dette i betragtning, og så:
    ///
    /// ```
    /// let upper_i = 'i'.to_uppercase().to_string();
    ///
    /// assert_eq!(upper_i, "I");
    /// ```
    ///
    /// holder på tværs af sprog.
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_uppercase(self) -> ToUppercase {
        ToUppercase(CaseMappingIter::new(conversions::to_upper(self)))
    }

    /// Kontrollerer, om værdien er inden for ASCII-området.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.32.0")]
    #[inline]
    pub const fn is_ascii(&self) -> bool {
        *self as u32 <= 0x7F
    }

    /// Gør en kopi af værdien i tilsvarende ASCII-store bogstaver.
    ///
    /// ASCII-bogstaver 'a' til 'z' er kortlagt til 'A' til 'Z', men ikke-ASCII-bogstaver er uændrede.
    ///
    /// Brug [`make_ascii_uppercase()`] for at opskifte værdien på stedet.
    ///
    /// Brug [`to_uppercase()`] for at bogstaver ASCII-tegn ud over ikke-ASCII-tegn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'a';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('A', ascii.to_ascii_uppercase());
    /// assert_eq!('❤', non_ascii.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase()`]: #method.make_ascii_uppercase
    /// [`to_uppercase()`]: #method.to_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_uppercase(&self) -> char {
        if self.is_ascii_lowercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Lav en kopi af værdien i dets ASCII-småbogstavsækvivalent.
    ///
    /// ASCII-bogstaver 'A' til 'Z' kortlægges til 'a' til 'z', men ikke-ASCII-bogstaver er uændrede.
    ///
    /// Brug [`make_ascii_lowercase()`] til at gemme værdien på plads.
    ///
    /// Brug [`to_lowercase()`] for at gemme ASCII-tegn udover ikke-ASCII-tegn.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = 'A';
    /// let non_ascii = '❤';
    ///
    /// assert_eq!('a', ascii.to_ascii_lowercase());
    /// assert_eq!('❤', non_ascii.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase()`]: #method.make_ascii_lowercase
    /// [`to_lowercase()`]: #method.to_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn to_ascii_lowercase(&self) -> char {
        if self.is_ascii_uppercase() {
            (*self as u8).ascii_change_case_unchecked() as char
        } else {
            *self
        }
    }

    /// Kontrollerer, at to værdier er et ASCII-ufølsomt match.
    ///
    /// Svarer til `to_ascii_lowercase(a) == to_ascii_lowercase(b)`.
    ///
    /// # Examples
    ///
    /// ```
    /// let upper_a = 'A';
    /// let lower_a = 'a';
    /// let lower_z = 'z';
    ///
    /// assert!(upper_a.eq_ignore_ascii_case(&lower_a));
    /// assert!(upper_a.eq_ignore_ascii_case(&upper_a));
    /// assert!(!upper_a.eq_ignore_ascii_case(&lower_z));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[rustc_const_stable(feature = "const_ascii_methods_on_intrinsics", since = "1.52.0")]
    #[inline]
    pub const fn eq_ignore_ascii_case(&self, other: &char) -> bool {
        self.to_ascii_lowercase() == other.to_ascii_lowercase()
    }

    /// Konverterer denne type til sin ASCII-store bogstavsækvivalent på stedet.
    ///
    /// ASCII-bogstaver 'a' til 'z' er kortlagt til 'A' til 'Z', men ikke-ASCII-bogstaver er uændrede.
    ///
    /// Brug [`to_ascii_uppercase()`] for at returnere en ny opskrevet værdi uden at ændre den eksisterende.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'a';
    ///
    /// ascii.make_ascii_uppercase();
    ///
    /// assert_eq!('A', ascii);
    /// ```
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        *self = self.to_ascii_uppercase();
    }

    /// Konverterer denne type til dens ASCII-ækvivalent på stedet.
    ///
    /// ASCII-bogstaver 'A' til 'Z' kortlægges til 'a' til 'z', men ikke-ASCII-bogstaver er uændrede.
    ///
    /// Brug [`to_ascii_lowercase()`] for at returnere en ny værdi med lavere værdi uden at ændre den eksisterende.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut ascii = 'A';
    ///
    /// ascii.make_ascii_lowercase();
    ///
    /// assert_eq!('a', ascii);
    /// ```
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        *self = self.to_ascii_lowercase();
    }

    /// Kontrollerer, om værdien er et ASCII-alfabetisk tegn:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z' eller
    /// - U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphabetic());
    /// assert!(uppercase_g.is_ascii_alphabetic());
    /// assert!(a.is_ascii_alphabetic());
    /// assert!(g.is_ascii_alphabetic());
    /// assert!(!zero.is_ascii_alphabetic());
    /// assert!(!percent.is_ascii_alphabetic());
    /// assert!(!space.is_ascii_alphabetic());
    /// assert!(!lf.is_ascii_alphabetic());
    /// assert!(!esc.is_ascii_alphabetic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphabetic(&self) -> bool {
        matches!(*self, 'A'..='Z' | 'a'..='z')
    }

    /// Kontrollerer, om værdien er et ASCII-stort tegn:
    /// U + 0041 'A' ..=U + 005A 'Z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_uppercase());
    /// assert!(uppercase_g.is_ascii_uppercase());
    /// assert!(!a.is_ascii_uppercase());
    /// assert!(!g.is_ascii_uppercase());
    /// assert!(!zero.is_ascii_uppercase());
    /// assert!(!percent.is_ascii_uppercase());
    /// assert!(!space.is_ascii_uppercase());
    /// assert!(!lf.is_ascii_uppercase());
    /// assert!(!esc.is_ascii_uppercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_uppercase(&self) -> bool {
        matches!(*self, 'A'..='Z')
    }

    /// Kontrollerer, om værdien er et ASCII-små bogstav:
    /// U + 0061 'a' ..=U + 007A 'z'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_lowercase());
    /// assert!(!uppercase_g.is_ascii_lowercase());
    /// assert!(a.is_ascii_lowercase());
    /// assert!(g.is_ascii_lowercase());
    /// assert!(!zero.is_ascii_lowercase());
    /// assert!(!percent.is_ascii_lowercase());
    /// assert!(!space.is_ascii_lowercase());
    /// assert!(!lf.is_ascii_lowercase());
    /// assert!(!esc.is_ascii_lowercase());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_lowercase(&self) -> bool {
        matches!(*self, 'a'..='z')
    }

    /// Kontrollerer, om værdien er et ASCII-alfanumerisk tegn:
    ///
    /// - U + 0041 'A' ..=U + 005A 'Z' eller
    /// - U + 0061 'a' ..=U + 007A 'z' eller
    /// - U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_alphanumeric());
    /// assert!(uppercase_g.is_ascii_alphanumeric());
    /// assert!(a.is_ascii_alphanumeric());
    /// assert!(g.is_ascii_alphanumeric());
    /// assert!(zero.is_ascii_alphanumeric());
    /// assert!(!percent.is_ascii_alphanumeric());
    /// assert!(!space.is_ascii_alphanumeric());
    /// assert!(!lf.is_ascii_alphanumeric());
    /// assert!(!esc.is_ascii_alphanumeric());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_alphanumeric(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='Z' | 'a'..='z')
    }

    /// Kontrollerer, om værdien er et ASCII-decimaltal:
    /// U + 0030 '0' ..=U + 0039 '9'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_digit());
    /// assert!(!uppercase_g.is_ascii_digit());
    /// assert!(!a.is_ascii_digit());
    /// assert!(!g.is_ascii_digit());
    /// assert!(zero.is_ascii_digit());
    /// assert!(!percent.is_ascii_digit());
    /// assert!(!space.is_ascii_digit());
    /// assert!(!lf.is_ascii_digit());
    /// assert!(!esc.is_ascii_digit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_digit(&self) -> bool {
        matches!(*self, '0'..='9')
    }

    /// Kontrollerer, om værdien er et ASCII-hexadecimalt tal:
    ///
    /// - U + 0030 '0' ..=U + 0039 '9', eller
    /// - U + 0041 'A' ..=U + 0046 'F', eller
    /// - U + 0061 'a' ..=U + 0066 'f'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_hexdigit());
    /// assert!(!uppercase_g.is_ascii_hexdigit());
    /// assert!(a.is_ascii_hexdigit());
    /// assert!(!g.is_ascii_hexdigit());
    /// assert!(zero.is_ascii_hexdigit());
    /// assert!(!percent.is_ascii_hexdigit());
    /// assert!(!space.is_ascii_hexdigit());
    /// assert!(!lf.is_ascii_hexdigit());
    /// assert!(!esc.is_ascii_hexdigit());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_hexdigit(&self) -> bool {
        matches!(*self, '0'..='9' | 'A'..='F' | 'a'..='f')
    }

    /// Kontrollerer, om værdien er et ASCII-tegnsætningstegn:
    ///
    /// - U + 0021 ..=U + 002F `! " # $ % & ' ( ) * + , - . /`, eller
    /// - U + 003A ..=U + 0040 `: ; < = > ? @`, eller
    /// - U + 005B ..=U + 0060 ``[\] ^ _`` eller
    /// - U + 007B ..=U + 007E `{ | } ~`
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_punctuation());
    /// assert!(!uppercase_g.is_ascii_punctuation());
    /// assert!(!a.is_ascii_punctuation());
    /// assert!(!g.is_ascii_punctuation());
    /// assert!(!zero.is_ascii_punctuation());
    /// assert!(percent.is_ascii_punctuation());
    /// assert!(!space.is_ascii_punctuation());
    /// assert!(!lf.is_ascii_punctuation());
    /// assert!(!esc.is_ascii_punctuation());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_punctuation(&self) -> bool {
        matches!(*self, '!'..='/' | ':'..='@' | '['..='`' | '{'..='~')
    }

    /// Kontrollerer, om værdien er et ASCII-grafisk tegn:
    /// U + 0021 '!' ..=U + 007E '~'.
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(uppercase_a.is_ascii_graphic());
    /// assert!(uppercase_g.is_ascii_graphic());
    /// assert!(a.is_ascii_graphic());
    /// assert!(g.is_ascii_graphic());
    /// assert!(zero.is_ascii_graphic());
    /// assert!(percent.is_ascii_graphic());
    /// assert!(!space.is_ascii_graphic());
    /// assert!(!lf.is_ascii_graphic());
    /// assert!(!esc.is_ascii_graphic());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_graphic(&self) -> bool {
        matches!(*self, '!'..='~')
    }

    /// Kontrollerer, om værdien er et ASCII-mellemrumstegn:
    /// U + 0020 RUM, U + 0009 HORISONTAL TAB, U + 000A LINJEFODRING, U + 000C FORMFODRING, eller U + 000D RETURRETUR.
    ///
    /// Rust bruger WhatWG Infra Standards [definition of ASCII whitespace][infra-aw].Der er flere andre definitioner i bred anvendelse.
    /// For eksempel inkluderer [the POSIX locale][pct] U + 000B VERTICAL TAB såvel som alle ovenstående tegn, men-fra den samme specifikation-[standardreglen for "field splitting" i Bourne shell][bfs] betragter *kun* MELLEMRUM, HORISONTAL TAB og LINJEFODRING som mellemrum.
    ///
    ///
    /// Hvis du skriver et program, der behandler et eksisterende filformat, skal du kontrollere, hvad formatets definition af mellemrum er, inden du bruger denne funktion.
    ///
    /// [infra-aw]: https://infra.spec.whatwg.org/#ascii-whitespace
    /// [pct]: http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap07.html#tag_07_03_01
    /// [bfs]: http://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#tag_18_06_05
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_whitespace());
    /// assert!(!uppercase_g.is_ascii_whitespace());
    /// assert!(!a.is_ascii_whitespace());
    /// assert!(!g.is_ascii_whitespace());
    /// assert!(!zero.is_ascii_whitespace());
    /// assert!(!percent.is_ascii_whitespace());
    /// assert!(space.is_ascii_whitespace());
    /// assert!(lf.is_ascii_whitespace());
    /// assert!(!esc.is_ascii_whitespace());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_whitespace(&self) -> bool {
        matches!(*self, '\t' | '\n' | '\x0C' | '\r' | ' ')
    }

    /// Kontrollerer, om værdien er et ASCII-kontroltegn:
    /// U + 0000 NUL ..=U + 001F ENHEDSSKILLER, eller U + 007F SLET.
    /// Bemærk, at de fleste ASCII-blanktegn er kontroltegn, men SPACE ikke.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let uppercase_a = 'A';
    /// let uppercase_g = 'G';
    /// let a = 'a';
    /// let g = 'g';
    /// let zero = '0';
    /// let percent = '%';
    /// let space = ' ';
    /// let lf = '\n';
    /// let esc: char = 0x1b_u8.into();
    ///
    /// assert!(!uppercase_a.is_ascii_control());
    /// assert!(!uppercase_g.is_ascii_control());
    /// assert!(!a.is_ascii_control());
    /// assert!(!g.is_ascii_control());
    /// assert!(!zero.is_ascii_control());
    /// assert!(!percent.is_ascii_control());
    /// assert!(!space.is_ascii_control());
    /// assert!(lf.is_ascii_control());
    /// assert!(esc.is_ascii_control());
    /// ```
    #[stable(feature = "ascii_ctype_on_intrinsics", since = "1.24.0")]
    #[rustc_const_stable(feature = "const_ascii_ctype_on_intrinsics", since = "1.47.0")]
    #[inline]
    pub const fn is_ascii_control(&self) -> bool {
        matches!(*self, '\0'..='\x1F' | '\x7F')
    }
}

#[inline]
const fn len_utf8(code: u32) -> usize {
    if code < MAX_ONE_B {
        1
    } else if code < MAX_TWO_B {
        2
    } else if code < MAX_THREE_B {
        3
    } else {
        4
    }
}

/// Koder en rå u32-værdi som UTF-8 i den leverede bytebuffer, og returnerer derefter delsnittet af bufferen, der indeholder det kodede tegn.
///
///
/// I modsætning til `char::encode_utf8` håndterer denne metode også kodepunkter i surrogatområdet.
/// (Oprettelse af en `char` i surrogatområdet er UB.) Resultatet er gyldigt [generalized UTF-8], men ikke gyldigt UTF-8.
///
/// [generalized UTF-8]: https://simonsapin.github.io/wtf-8/#generalized-utf8
///
/// # Panics
///
/// Panics hvis bufferen ikke er stor nok.
/// En buffer med længde fire er stor nok til at kode for enhver `char`.
///
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf8_raw(code: u32, dst: &mut [u8]) -> &mut [u8] {
    let len = len_utf8(code);
    match (len, &mut dst[..]) {
        (1, [a, ..]) => {
            *a = code as u8;
        }
        (2, [a, b, ..]) => {
            *a = (code >> 6 & 0x1F) as u8 | TAG_TWO_B;
            *b = (code & 0x3F) as u8 | TAG_CONT;
        }
        (3, [a, b, c, ..]) => {
            *a = (code >> 12 & 0x0F) as u8 | TAG_THREE_B;
            *b = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *c = (code & 0x3F) as u8 | TAG_CONT;
        }
        (4, [a, b, c, d, ..]) => {
            *a = (code >> 18 & 0x07) as u8 | TAG_FOUR_B;
            *b = (code >> 12 & 0x3F) as u8 | TAG_CONT;
            *c = (code >> 6 & 0x3F) as u8 | TAG_CONT;
            *d = (code & 0x3F) as u8 | TAG_CONT;
        }
        _ => panic!(
            "encode_utf8: need {} bytes to encode U+{:X}, but the buffer has {}",
            len,
            code,
            dst.len(),
        ),
    };
    &mut dst[..len]
}

/// Koder en rå u32-værdi som UTF-16 i den medfølgende `u16`-buffer, og returnerer derefter underskiven af bufferen, der indeholder det kodede tegn.
///
///
/// I modsætning til `char::encode_utf16` håndterer denne metode også kodepunkter i surrogatområdet.
/// (Oprettelse af en `char` i surrogatområdet er UB.)
///
/// # Panics
///
/// Panics hvis bufferen ikke er stor nok.
/// En buffer med længde 2 er stor nok til at kode for enhver `char`.
#[unstable(feature = "char_internals", reason = "exposed only for libstd", issue = "none")]
#[doc(hidden)]
#[inline]
pub fn encode_utf16_raw(mut code: u32, dst: &mut [u16]) -> &mut [u16] {
    // SIKKERHED: hver arm kontrollerer, om der er nok bits til at skrive i
    unsafe {
        if (code & 0xFFFF) == code && !dst.is_empty() {
            // BMP falder igennem
            *dst.get_unchecked_mut(0) = code as u16;
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 1)
        } else if dst.len() >= 2 {
            // Supplerende fly bryder ind i surrogater.
            code -= 0x1_0000;
            *dst.get_unchecked_mut(0) = 0xD800 | ((code >> 10) as u16);
            *dst.get_unchecked_mut(1) = 0xDC00 | ((code as u16) & 0x3FF);
            slice::from_raw_parts_mut(dst.as_mut_ptr(), 2)
        } else {
            panic!(
                "encode_utf16: need {} units to encode U+{:X}, but the buffer has {}",
                from_u32_unchecked(code).len_utf16(),
                code,
                dst.len(),
            )
        }
    }
}