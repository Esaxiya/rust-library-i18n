//! API'er til hukommelsesallokering

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// `AllocError`-fejlen angiver en allokeringsfejl, der kan være på grund af ressourceudtømning eller noget galt, når de givne inputargumenter kombineres med denne tildeler.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (vi har brug for dette til downstream impl af trait Error)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// En implementering af `Allocator` kan allokere, vokse, krympe og deallokere vilkårlige datablokke beskrevet via [`Layout`][].
///
/// `Allocator` er designet til at blive implementeret på ZST'er, referencer eller smarte markører, fordi det at have en allokator som `MyAlloc([u8; N])` ikke kan flyttes uden at opdatere markørerne til den tildelte hukommelse.
///
/// I modsætning til [`GlobalAlloc`][] er allokeringer i nul størrelse tilladt i `Allocator`.
/// Hvis en underliggende tildeler ikke understøtter dette (som jemalloc) eller returnerer en nul pointer (såsom `libc::malloc`), skal dette fanges af implementeringen.
///
/// ### Aktuelt tildelt hukommelse
///
/// Nogle af metoderne kræver, at en hukommelsesblok *tildeles i øjeblikket* via en allokeringsenhed.Det betyder at:
///
/// * startadressen for den hukommelsesblok blev tidligere returneret af [`allocate`], [`grow`] eller [`shrink`] og
///
/// * hukommelsesblokken er ikke efterfølgende deallocated, hvor blokke enten deallokeres direkte ved at blive sendt til [`deallocate`] eller blev ændret ved at blive sendt til [`grow`] eller [`shrink`], der returnerer `Ok`.
///
/// Hvis `grow` eller `shrink` har returneret `Err`, forbliver den beståede markør gyldig.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Hukommelsestilpasning
///
/// Nogle af metoderne kræver, at et layout *passer* til en hukommelsesblok.
/// Hvad det betyder for et layout til "fit" betyder en hukommelsesblok (eller tilsvarende for en hukommelsesblok til "fit" et layout) er, at følgende betingelser skal være:
///
/// * Blokken skal tildeles med samme justering som [`layout.align()`], og
///
/// * Den medfølgende [`layout.size()`] skal falde inden for området `min ..= max`, hvor:
///   - `min` er størrelsen på det layout, der senest blev brugt til at tildele blokken, og
///   - `max` er den seneste faktiske størrelse, der returneres fra [`allocate`], [`grow`] eller [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Hukommelsesblokke, der returneres fra en tildeler, skal pege på gyldig hukommelse og bevare deres gyldighed, indtil forekomsten og alle dens kloner er droppet,
///
/// * kloning eller flytning af tildeleren må ikke ugyldiggøre hukommelsesblokke, der returneres fra denne tildeler.En klonetildeling skal opføre sig som den samme tildeler, og
///
/// * en hvilken som helst markør til en hukommelsesblok, der er [*currently allocated*], kan sendes til en hvilken som helst anden metode til fordeleren.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Forsøg på at allokere en hukommelsesblok.
    ///
    /// Efter succes returnerer en [`NonNull<[u8]>`][NonNull], der opfylder størrelsen og justeringsgarantierne for `layout`.
    ///
    /// Den returnerede blok kan have en større størrelse end angivet af `layout.size()`, og dens indhold kan initialiseres eller måske ikke.
    ///
    /// # Errors
    ///
    /// Returnering af `Err` indikerer, at enten hukommelsen er opbrugt, eller at `layout` ikke opfylder tildelers størrelse eller justeringsbegrænsninger.
    ///
    /// Implementeringer opfordres til at returnere `Err` ved hukommelsesudmattelse snarere end at gå i panik eller afbryde, men dette er ikke et strengt krav.
    /// (Specifikt: det er *lovligt* at implementere denne trait oven på et underliggende indfødt allokeringsbibliotek, der afbryder ved hukommelsesudmattelse.)
    ///
    /// Kunder, der ønsker at afbryde beregning som svar på en allokeringsfejl, opfordres til at ringe til [`handle_alloc_error`]-funktionen i stedet for direkte at påberåbe sig `panic!` eller lignende.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Opfører sig som `allocate`, men sørger også for, at den returnerede hukommelse nul initialiseres.
    ///
    /// # Errors
    ///
    /// Returnering af `Err` indikerer, at enten hukommelsen er opbrugt, eller at `layout` ikke opfylder tildelers størrelse eller justeringsbegrænsninger.
    ///
    /// Implementeringer opfordres til at returnere `Err` ved hukommelsesudmattelse snarere end at gå i panik eller afbryde, men dette er ikke et strengt krav.
    /// (Specifikt: det er *lovligt* at implementere denne trait oven på et underliggende indfødt allokeringsbibliotek, der afbryder ved hukommelsesudmattelse.)
    ///
    /// Kunder, der ønsker at afbryde beregning som svar på en allokeringsfejl, opfordres til at ringe til [`handle_alloc_error`]-funktionen i stedet for direkte at påberåbe sig `panic!` eller lignende.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // SIKKERHED: `alloc` returnerer en gyldig hukommelsesblok
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Deallokerer den hukommelse, der henvises til af `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` skal betegne en hukommelsesblok [*currently allocated*] via denne tildeler, og
    /// * `layout` skal [*fit*] den blok af hukommelse.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Forsøg på at udvide hukommelsesblokken.
    ///
    /// Returnerer en ny [`NonNull<[u8]>`][NonNull], der indeholder en markør og den faktiske størrelse på den tildelte hukommelse.Markøren er velegnet til at gemme data beskrevet af `new_layout`.
    /// For at opnå dette kan tildeleren udvide den tildeling, der henvises til af `ptr`, så den passer til det nye layout.
    ///
    /// Hvis dette returnerer `Ok`, er ejerskabet af den hukommelsesblok, der henvises til af `ptr`, overført til denne allokator.
    /// Hukommelsen kan måske ikke være frigivet og bør betragtes som ubrugelig, medmindre den blev overført tilbage til den, der ringer op igen via denne metodes returværdi.
    ///
    /// Hvis denne metode returnerer `Err`, er ejerskabet af hukommelsesblokken ikke overført til denne alloker, og indholdet af hukommelsesblokken er uændret.
    ///
    /// # Safety
    ///
    /// * `ptr` skal angive en blok hukommelse [*currently allocated*] via denne tildeler.
    /// * `old_layout` skal [*fit*] den hukommelsesblok (`new_layout`-argumentet behøver ikke at passe den.).
    /// * `new_layout.size()` skal være større end eller lig med `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Returnerer `Err`, hvis det nye layout ikke opfylder allokeringsstørrelses-og justeringsbegrænsninger for allokatoren, eller hvis væksten ellers mislykkes.
    ///
    /// Implementeringer opfordres til at returnere `Err` ved hukommelsesudmattelse snarere end at gå i panik eller afbryde, men dette er ikke et strengt krav.
    /// (Specifikt: det er *lovligt* at implementere denne trait oven på et underliggende indfødt allokeringsbibliotek, der afbryder ved hukommelsesudmattelse.)
    ///
    /// Kunder, der ønsker at afbryde beregning som svar på en allokeringsfejl, opfordres til at ringe til [`handle_alloc_error`]-funktionen i stedet for direkte at påberåbe sig `panic!` eller lignende.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SIKKERHED: fordi `new_layout.size()` skal være større end eller lig med
        // `old_layout.size()`, både den gamle og den nye hukommelsestildeling er gyldig til læsning og skrivning af `old_layout.size()`-byte.
        // Også fordi den gamle tildeling endnu ikke var deallokeret, kan den ikke overlappe `new_ptr`.
        // Således er opkaldet til `copy_nonoverlapping` sikkert.
        // Sikkerhedskontrakten for `dealloc` skal opretholdes af den, der ringer op.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Opfører sig som `grow`, men sikrer også, at det nye indhold sættes til nul, før det returneres.
    ///
    /// Hukommelsesblokken indeholder følgende indhold efter et vellykket opkald til
    /// `grow_zeroed`:
    ///   * Bytes `0..old_layout.size()` bevares fra den oprindelige tildeling.
    ///   * Bytes `old_layout.size()..old_size` vil enten blive bevaret eller nulstillet afhængigt af tildelingsimplementeringen.
    ///   `old_size` henviser til størrelsen på hukommelsesblokken før `grow_zeroed`-opkaldet, som kan være større end den størrelse, der oprindeligt blev anmodet om, da den blev tildelt.
    ///   * Bytes `old_size..new_size` er nulstillet.`new_size` refererer til størrelsen på hukommelsesblokken, der returneres af `grow_zeroed`-opkaldet.
    ///
    /// # Safety
    ///
    /// * `ptr` skal angive en blok hukommelse [*currently allocated*] via denne tildeler.
    /// * `old_layout` skal [*fit*] den hukommelsesblok (`new_layout`-argumentet behøver ikke at passe den.).
    /// * `new_layout.size()` skal være større end eller lig med `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Returnerer `Err`, hvis det nye layout ikke opfylder allokeringsstørrelses-og justeringsbegrænsninger for allokatoren, eller hvis væksten ellers mislykkes.
    ///
    /// Implementeringer opfordres til at returnere `Err` ved hukommelsesudmattelse snarere end at gå i panik eller afbryde, men dette er ikke et strengt krav.
    /// (Specifikt: det er *lovligt* at implementere denne trait oven på et underliggende indfødt allokeringsbibliotek, der afbryder ved hukommelsesudmattelse.)
    ///
    /// Kunder, der ønsker at afbryde beregning som svar på en allokeringsfejl, opfordres til at ringe til [`handle_alloc_error`]-funktionen i stedet for direkte at påberåbe sig `panic!` eller lignende.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // SIKKERHED: fordi `new_layout.size()` skal være større end eller lig med
        // `old_layout.size()`, både den gamle og den nye hukommelsestildeling er gyldig til læsning og skrivning af `old_layout.size()`-byte.
        // Også fordi den gamle tildeling endnu ikke var deallokeret, kan den ikke overlappe `new_ptr`.
        // Således er opkaldet til `copy_nonoverlapping` sikkert.
        // Sikkerhedskontrakten for `dealloc` skal opretholdes af den, der ringer op.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Forsøg på at formindske hukommelsesblokken.
    ///
    /// Returnerer en ny [`NonNull<[u8]>`][NonNull], der indeholder en markør og den faktiske størrelse på den tildelte hukommelse.Markøren er velegnet til at gemme data beskrevet af `new_layout`.
    /// For at opnå dette kan tildeleren krympe den tildeling, der henvises til af `ptr`, så den passer til det nye layout.
    ///
    /// Hvis dette returnerer `Ok`, er ejerskabet af den hukommelsesblok, der henvises til af `ptr`, overført til denne allokator.
    /// Hukommelsen kan måske ikke være frigivet og bør betragtes som ubrugelig, medmindre den blev overført tilbage til den, der ringer op igen via denne metodes returværdi.
    ///
    /// Hvis denne metode returnerer `Err`, er ejerskabet af hukommelsesblokken ikke overført til denne alloker, og indholdet af hukommelsesblokken er uændret.
    ///
    /// # Safety
    ///
    /// * `ptr` skal angive en blok hukommelse [*currently allocated*] via denne tildeler.
    /// * `old_layout` skal [*fit*] den hukommelsesblok (`new_layout`-argumentet behøver ikke at passe den.).
    /// * `new_layout.size()` skal være mindre end eller lig med `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Returnerer `Err`, hvis det nye layout ikke lever op til fordelerens størrelse og justeringsbegrænsninger for tildeleren, eller hvis krympning ellers mislykkes.
    ///
    /// Implementeringer opfordres til at returnere `Err` ved hukommelsesudmattelse snarere end at gå i panik eller afbryde, men dette er ikke et strengt krav.
    /// (Specifikt: det er *lovligt* at implementere denne trait oven på et underliggende indfødt allokeringsbibliotek, der afbryder ved hukommelsesudmattelse.)
    ///
    /// Kunder, der ønsker at afbryde beregning som svar på en allokeringsfejl, opfordres til at ringe til [`handle_alloc_error`]-funktionen i stedet for direkte at påberåbe sig `panic!` eller lignende.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // SIKKERHED: fordi `new_layout.size()` skal være lavere end eller lig med
        // `old_layout.size()`, både den gamle og den nye hukommelsestildeling er gyldig til læsning og skrivning af `new_layout.size()`-byte.
        // Også fordi den gamle tildeling endnu ikke var deallokeret, kan den ikke overlappe `new_ptr`.
        // Således er opkaldet til `copy_nonoverlapping` sikkert.
        // Sikkerhedskontrakten for `dealloc` skal opretholdes af den, der ringer op.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Opretter en "by reference"-adapter til denne forekomst af `Allocator`.
    ///
    /// Den returnerede adapter implementerer også `Allocator` og låner simpelthen denne.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // SIKKERHED: sikkerhedskontrakten skal opretholdes af den, der ringer op
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SIKKERHED: sikkerhedskontrakten skal opretholdes af den, der ringer op
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SIKKERHED: sikkerhedskontrakten skal opretholdes af den, der ringer op
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SIKKERHED: sikkerhedskontrakten skal opretholdes af den, der ringer op
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}