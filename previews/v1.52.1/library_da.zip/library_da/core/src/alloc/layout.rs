use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Mens denne funktion bruges ét sted, og dens implementering kunne være angivet, gjorde de tidligere forsøg på at gøre det rustc langsommere:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Layout af en hukommelsesblok.
///
/// En forekomst af `Layout` beskriver et bestemt hukommelseslayout.
/// Du bygger en `Layout` op som et input til at give til en allokator.
///
/// Alle layouts har en tilhørende størrelse og en power-of-two-justering.
///
/// (Bemærk, at layout ikke *er* påkrævet for at have størrelse, der ikke er nul, selvom `GlobalAlloc` kræver, at alle hukommelsesanmodninger ikke er nul i størrelse.
/// En opkalder skal enten sørge for, at betingelser som denne er opfyldt, bruge specifikke allokatorer med løsere krav eller bruge det mere lette `Allocator`-interface.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // størrelsen på den ønskede hukommelsesblok målt i byte.
    size_: usize,

    // justering af den ønskede hukommelsesblok målt i byte.
    // Vi sikrer, at dette altid er en power-of-two, fordi API'er som `posix_memalign` kræver det, og det er en rimelig begrænsning at pålægge Layout-konstruktører.
    //
    //
    // (Vi kræver dog ikke analogt `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Konstruerer en `Layout` fra en given `size` og `align` eller returnerer `LayoutError`, hvis en af følgende betingelser ikke er opfyldt:
    ///
    /// * `align` må ikke være nul,
    ///
    /// * `align` skal være en styrke på to,
    ///
    /// * `size`, når den afrundes op til nærmeste multiplum af `align`, må den ikke løbe over (dvs. den afrundede værdi skal være mindre end eller lig med `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (power-of-two indebærer align!=0.)

        // Afrundet størrelse er:
        //   size_rounded_up=(størrelse + juster, 1)&! (juster, 1);
        //
        // Vi ved ovenfra, at justering!=0.
        // Hvis tilføjelse (justering, 1) ikke løber over, vil afrunding op være fint.
        //
        // Omvendt vil&-maskering med! (Align, 1) kun trække fra low-order-bits.
        // Således hvis overløb opstår med summen, kan&-masken ikke trække nok til at fortryde dette overløb.
        //
        //
        // Ovenstående antyder, at det er nødvendigt og tilstrækkeligt at kontrollere summeringsoverløb.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // SIKKERHED: betingelserne for `from_size_align_unchecked` har været
        // markeret ovenfor.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Opretter et layout, der omgår alle kontroller.
    ///
    /// # Safety
    ///
    /// Denne funktion er usikker, da den ikke verificerer forudsætningerne fra [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // SIKKERHED: den, der ringer op, skal sikre, at `align` er større end nul.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Minimumstørrelsen i byte for en hukommelsesblok i dette layout.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Den mindste bytejustering for en hukommelsesblok i dette layout.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Konstruerer en `Layout`, der er egnet til at holde en værdi af typen `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // SIKKERHED: justeringen garanteres af Rust at være en styrke på to og
        // kombinationen størrelse + align passer garanteret til vores adresseområde.
        // Brug derfor den ukontrollerede konstruktør her for at undgå at indsætte kode, der panics, hvis den ikke er optimeret godt nok.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Producerer layout, der beskriver en post, der kan bruges til at allokere understøtningsstruktur til `T` (som kan være en trait eller anden ikke-størrelse type som et udsnit).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SIKKERHED: se begrundelsen i `new` for, hvorfor dette bruger den usikre variant
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Producerer layout, der beskriver en post, der kan bruges til at allokere understøtningsstruktur til `T` (som kan være en trait eller anden ikke-størrelse type som et udsnit).
    ///
    /// # Safety
    ///
    /// Denne funktion er kun sikker at ringe til, hvis følgende betingelser gælder:
    ///
    /// - Hvis `T` er `Sized`, er denne funktion altid sikker at ringe til.
    /// - Hvis den usikrede hale på `T` er:
    ///     - en [slice], så skal skivens hales længde være et intialiseret heltal, og størrelsen på *hele værdien*(dynamisk halelængde + statisk størrelse præfiks) skal passe i `isize`.
    ///     - en [trait object], så skal vtabeldelen af markøren pege på en gyldig vtabel for typen `T`, der er erhvervet af en usorterende koersion, og størrelsen på *hele værdien*(dynamisk hale længde + statisk størrelse præfiks) skal passe i `isize`.
    ///
    ///     - en (unstable) [extern type], så er denne funktion altid sikker at ringe til, men kan panic eller på anden måde returnere den forkerte værdi, da den eksterne types layout ikke er kendt.
    ///     Dette er den samme adfærd som [`Layout::for_value`] på en henvisning til en ekstern type hale.
    ///     - ellers er det konservativt ikke tilladt at kalde denne funktion.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // SIKKERHED: vi videregiver forudsætningerne for disse funktioner til den, der ringer op
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // SIKKERHED: se begrundelsen i `new` for, hvorfor dette bruger den usikre variant
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Opretter en `NonNull`, der er dinglende, men godt justeret til dette layout.
    ///
    /// Bemærk, at markørens værdi muligvis kan repræsentere en gyldig markør, hvilket betyder, at denne ikke må bruges som en "not yet initialized"-sentinelværdi.
    /// Typer, som dovent tildeles, skal spore initialisering på anden måde.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // SIKKERHED: justering er garanteret ikke-nul
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Opretter et layout, der beskriver posten, der kan indeholde en værdi af det samme layout som `self`, men som også er justeret til justering `align` (målt i byte).
    ///
    ///
    /// Hvis `self` allerede opfylder den foreskrevne justering, returneres `self`.
    ///
    /// Bemærk, at denne metode ikke tilføjer nogen polstring til den samlede størrelse, uanset om det returnerede layout har en anden justering.
    /// Med andre ord, hvis `K` har størrelse 16, vil `K.align_to(32)`*stadig* have størrelse 16.
    ///
    /// Returnerer en fejl, hvis kombinationen af `self.size()` og den givne `align` overtræder betingelserne, der er anført i [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Returnerer den mængde polstring, vi skal indsætte efter `self` for at sikre, at følgende adresse vil tilfredsstille `align` (målt i byte).
    ///
    /// f.eks. hvis `self.size()` er 9, returnerer `self.padding_needed_for(4)` 3, fordi det er det mindste antal byte af polstring, der kræves for at få en 4-justeret adresse (forudsat at den tilsvarende hukommelsesblok starter ved en 4-justeret adresse).
    ///
    ///
    /// Returneringsværdien for denne funktion har ingen betydning, hvis `align` ikke er en power-of-two.
    ///
    /// Bemærk, at nytteværdien af den returnerede værdi kræver, at `align` er mindre end eller lig med justeringen af startadressen for hele den tildelte hukommelsesblok.En måde at opfylde denne begrænsning er at sikre `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Afrundet værdi er:
        //   len_rounded_up=(len + align, 1)&! (align, 1);
        // og så returnerer vi polstringsforskellen: `len_rounded_up - len`.
        //
        // Vi bruger modulær aritmetik overalt:
        //
        // 1. align er garanteret at være> 0, så align, 1 er altid gyldig.
        //
        // 2.
        // `len + align - 1` kan overløbe højst med `align - 1`, så&-masken med `!(align - 1)` vil sikre, at i tilfælde af overløb vil `len_rounded_up` i sig selv være 0.
        //
        //    Således giver den returnerede polstring, når den føjes til `len`, 0, hvilket trivielt tilfredsstiller justeringen `align`.
        //
        // (Selvfølgelig skal forsøg på at tildele hukommelsesblokke, hvis størrelse og polstring overløber på ovenstående måde, få allokeringen til at give en fejl alligevel.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Opretter et layout ved at afrunde størrelsen på dette layout op til et multiplum af layoutets justering.
    ///
    ///
    /// Dette svarer til at tilføje resultatet af `padding_needed_for` til layoutets aktuelle størrelse.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Dette kan ikke løbe over.Citat fra invarianten i Layout:
        // > `size`, når den afrundes til nærmeste multiplum af `align`,
        // > må ikke løbe over (dvs. den afrundede værdi skal være mindre end
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Opretter et layout, der beskriver posten for `n`-forekomster af `self`, med en passende mængde polstring mellem hver for at sikre, at hver forekomst får den ønskede størrelse og justering.
    /// Efter succes returnerer `(k, offs)`, hvor `k` er arrayets layout, og `offs` er afstanden mellem starten på hvert element i arrayet.
    ///
    /// Ved aritmetisk overløb returnerer `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Dette kan ikke løbe over.Citat fra invarianten i Layout:
        // > `size`, når den afrundes til nærmeste multiplum af `align`,
        // > må ikke løbe over (dvs. den afrundede værdi skal være mindre end
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // SIKKERHED: self.align er allerede kendt for at være gyldig, og alloc_size har været
        // polstret allerede.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Opretter et layout, der beskriver posten for `self` efterfulgt af `next`, inklusive enhver nødvendig polstring for at sikre, at `next` vil blive justeret korrekt, men *ingen efterfølgende polstring*.
    ///
    /// For at matche C-repræsentationslayout `repr(C)`, skal du ringe til `pad_to_align` efter at have udvidet layoutet med alle felter.
    /// (Der er ingen måde at matche standard Rust repræsentationslayout `repr(Rust)`, as it is unspecified.) på
    ///
    /// Bemærk at justeringen af det resulterende layout vil være det maksimale for `self` og `next` for at sikre justering af begge dele.
    ///
    /// Returnerer `Ok((k, offset))`, hvor `k` er layout for den sammenkædede post, og `offset` er den relative placering i byte af starten på `next` indlejret i den sammenkædede post (forudsat at selve posten starter ved forskydning 0).
    ///
    ///
    /// Ved aritmetisk overløb returnerer `LayoutError`.
    ///
    /// # Examples
    ///
    /// Sådan beregnes layoutet af en `#[repr(C)]`-struktur og forskydningen af felterne fra dens felters layout:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Husk at færdiggøre med `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // test at det fungerer
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Opretter et layout, der beskriver posten for `n`-forekomster af `self`, uden polstring mellem hver forekomst.
    ///
    /// Bemærk, i modsætning til `repeat`, garanterer `repeat_packed` ikke, at de gentagne forekomster af `self` vil blive justeret korrekt, selvom en given forekomst af `self` er korrekt justeret.
    /// Med andre ord, hvis det layout, der returneres af `repeat_packed`, bruges til at tildele en matrix, er det ikke garanteret, at alle elementer i arrayet vil blive korrekt justeret.
    ///
    /// Ved aritmetisk overløb returnerer `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Opretter et layout, der beskriver posten for `self` efterfulgt af `next` uden yderligere polstring mellem de to.
    /// Da der ikke er indsat nogen polstring, er justeringen af `next` irrelevant og er slet ikke indarbejdet * i det resulterende layout.
    ///
    ///
    /// Ved aritmetisk overløb returnerer `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Opretter et layout, der beskriver posten til en `[T; n]`.
    ///
    /// Ved aritmetisk overløb returnerer `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Parametrene, der er givet til `Layout::from_size_align` eller en anden `Layout`-konstruktør, opfylder ikke de dokumenterede begrænsninger.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (vi har brug for dette til downstream impl af trait Error)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}