use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// En hukommelsesalloker, der kan registreres som standardbibliotekets standard gennem `#[global_allocator]`-attributten.
///
/// Nogle af metoderne kræver, at en hukommelsesblok *tildeles i øjeblikket* via en allokeringsenhed.Det betyder at:
///
/// * startadressen for den hukommelsesblok blev tidligere returneret af et tidligere opkald til en allokeringsmetode såsom `alloc` og
///
/// * hukommelsesblokken er ikke efterfølgende deallocated, hvor blokke deallokeres enten ved at blive sendt til en deallocation-metode såsom `dealloc` eller ved at blive sendt til en reallocation-metode, der returnerer en ikke-nul-markør.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// `GlobalAlloc` trait er en `unsafe` trait af en række årsager, og implementatorer skal sikre, at de overholder disse kontrakter:
///
/// * Det er udefineret adfærd, hvis globale allokatorer slapper af.Denne begrænsning kan løftes i future, men i øjeblikket kan en panic fra en af disse funktioner føre til usikkerhed i hukommelsen.
///
/// * `Layout` forespørgsler og beregninger skal generelt være korrekte.Opkaldere af denne trait har tilladelse til at stole på de kontrakter, der er defineret i hver metode, og implementatorer skal sikre, at sådanne kontrakter forbliver sande.
///
/// * Du kan ikke stole på, at tildelinger faktisk sker, selvom der er eksplicit bunktildelinger i kilden.
/// Optimizer kan muligvis registrere ubrugte allokeringer, som den enten kan fjerne helt eller flytte til stakken og således aldrig påberåbe sig allokeringen.
/// Optimizer kan endvidere antage, at allokering er ufejlbarlig, så kode, der plejede at fejle på grund af allokeringsfejl, kan nu pludselig fungere, fordi optimizer arbejdede omkring behovet for en allokering.
/// Mere konkret er følgende kodeeksempel usundt, uanset om din brugerdefinerede tildeler tillader at tælle, hvor mange tildelinger der er sket.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Bemærk, at de ovennævnte optimeringer ikke er den eneste optimering, der kan anvendes.Du kan normalt ikke stole på, at bunktildelinger sker, hvis de kan fjernes uden at ændre programadfærd.
///   Uanset om tildelinger sker eller ej, er ikke en del af programadfærden, selvom det kunne detekteres via en allokator, der sporer allokeringer ved udskrivning eller på anden måde har bivirkninger.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Tildel hukommelse som beskrevet af den givne `layout`.
    ///
    /// Returnerer en markør til nyligt allokeret hukommelse eller null for at angive allokeringsfejl.
    ///
    /// # Safety
    ///
    /// Denne funktion er usikker, fordi udefineret adfærd kan resultere, hvis den, der ringer op, ikke sikrer, at `layout` har en størrelse, der ikke er nul.
    ///
    /// (Ekstraudvidelser kan give mere specifikke grænser for adfærd, f.eks. Garantere en vagtadresse eller en nulmarkør som svar på en anmodning om tildeling af nulstørrelse.)
    ///
    /// Den tildelte hukommelsesblok kan eller ikke initialiseres.
    ///
    /// # Errors
    ///
    /// Returnering af en nulmarkør indikerer, at enten hukommelsen er opbrugt, eller at `layout` ikke opfylder denne allokerings størrelse eller justeringsbegrænsninger.
    ///
    /// Implementeringer opfordres til at returnere nul ved hukommelsesudmattelse snarere end at afbryde, men dette er ikke et strengt krav.
    /// (Specifikt: det er *lovligt* at implementere denne trait oven på et underliggende indfødt allokeringsbibliotek, der afbryder ved hukommelsesudmattelse.)
    ///
    /// Kunder, der ønsker at afbryde beregning som svar på en allokeringsfejl, opfordres til at ringe til [`handle_alloc_error`]-funktionen i stedet for direkte at påberåbe sig `panic!` eller lignende.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Fordel hukommelsesblokken ved den givne `ptr`-markør med den givne `layout`.
    ///
    /// # Safety
    ///
    /// Denne funktion er usikker, fordi udefineret adfærd kan opstå, hvis den, der ringer op, ikke garanterer alt følgende:
    ///
    ///
    /// * `ptr` skal betegne en hukommelsesblok, der aktuelt er tildelt via denne tildeler,
    ///
    /// * `layout` skal være det samme layout, der blev brugt til at allokere den hukommelsesblok.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Opfører sig som `alloc`, men sikrer også, at indholdet sættes til nul, før det returneres.
    ///
    /// # Safety
    ///
    /// Denne funktion er usikker af de samme grunde som `alloc` er.
    /// Imidlertid er den tildelte hukommelsesblok garanteret initialiseret.
    ///
    /// # Errors
    ///
    /// Returnering af en nulmarkør indikerer, at enten hukommelsen er opbrugt, eller at `layout` ikke opfylder allokeringsstørrelse eller justeringsbegrænsninger, ligesom i `alloc`.
    ///
    /// Kunder, der ønsker at afbryde beregning som svar på en allokeringsfejl, opfordres til at ringe til [`handle_alloc_error`]-funktionen i stedet for direkte at påberåbe sig `panic!` eller lignende.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // SIKKERHED: sikkerhedskontrakten for `alloc` skal opretholdes af den, der ringer op.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // SIKKERHED: da tildelingen lykkedes, regionen fra `ptr`
            // af størrelse `size` er garanteret gyldig til skrivning.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Krymp eller voks en hukommelsesblok til den givne `new_size`.
    /// Blokken er beskrevet af den givne `ptr`-markør og `layout`.
    ///
    /// Hvis dette returnerer en ikke-nul-markør, er ejerskabet af den hukommelsesblok, der henvises til af `ptr`, overført til denne allokator.
    /// Hukommelsen er muligvis ikke blevet omlokaliseret og skal betragtes som ubrugelig (medmindre den selvfølgelig blev overført tilbage til den, der ringer op igen via denne metodes returværdi).
    /// Den nye hukommelsesblok tildeles med `layout`, men med `size` opdateret til `new_size`.
    /// Dette nye layout skal bruges, når du placerer den nye hukommelsesblok med `dealloc`.
    /// Området `0..min(layout.size(), new_size) `af den nye hukommelsesblok har garanteret de samme værdier som den oprindelige blok.
    ///
    /// Hvis denne metode returnerer nul, er ejerskabet af hukommelsesblokken ikke overført til denne allokator, og indholdet af hukommelsesblokken er uændret.
    ///
    /// # Safety
    ///
    /// Denne funktion er usikker, fordi udefineret adfærd kan opstå, hvis den, der ringer op, ikke garanterer alt følgende:
    ///
    /// * `ptr` skal i øjeblikket tildeles via denne tildeler,
    ///
    /// * `layout` skal være det samme layout, der blev brugt til at allokere den hukommelsesblok,
    ///
    /// * `new_size` skal være større end nul.
    ///
    /// * `new_size`, når den afrundes til det nærmeste multiplum af `layout.align()`, må den ikke løbe over (dvs. den afrundede værdi skal være mindre end `usize::MAX`).
    ///
    /// (Ekstraudvidelser kan give mere specifikke grænser for adfærd, f.eks. Garantere en vagtadresse eller en nulmarkør som svar på en anmodning om tildeling af nulstørrelse.)
    ///
    /// # Errors
    ///
    /// Returnerer nul, hvis det nye layout ikke overholder størrelses-og justeringsbegrænsningerne for allokatoren, eller hvis genallokering ellers mislykkes.
    ///
    /// Implementeringer opfordres til at returnere nul ved hukommelsesudmattelse snarere end at gå i panik eller afbryde, men dette er ikke et strengt krav.
    /// (Specifikt: det er *lovligt* at implementere denne trait oven på et underliggende indfødt allokeringsbibliotek, der afbryder ved hukommelsesudmattelse.)
    ///
    /// Kunder, der ønsker at afbryde beregning som svar på en omfordelingsfejl, opfordres til at ringe til [`handle_alloc_error`]-funktionen i stedet for direkte at påberåbe sig `panic!` eller lignende.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // SIKKERHED: den, der ringer op, skal sikre, at `new_size` ikke løber over.
        // `layout.align()` kommer fra en `Layout` og er således garanteret gyldig.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // SIKKERHED: den, der ringer op, skal sikre, at `new_layout` er større end nul.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // SIKKERHED: den tidligere tildelte blok kan ikke overlappe den nyligt tildelte blok.
            // Sikkerhedskontrakten for `dealloc` skal opretholdes af den, der ringer op.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}