//! Dette modul implementerer `Any` trait, som muliggør dynamisk typning af enhver `'static`-type gennem kørselstid.
//!
//! `Any` i sig selv kan bruges til at få en `TypeId` og har flere funktioner, når den bruges som et trait-objekt.
//! Som `&dyn Any` (et lånt trait-objekt) har den `is`-og `downcast_ref`-metoderne for at teste, om den indeholdte værdi er af en given type, og for at få en reference til den indre værdi som en type.
//! Som `&mut dyn Any` findes der også `downcast_mut`-metoden til at få en ændret henvisning til den indre værdi.
//! `Box<dyn Any>` tilføjer `downcast`-metoden, som forsøger at konvertere til en `Box<T>`.
//! Se [`Box`]-dokumentationen for alle detaljer.
//!
//! Bemærk, at `&dyn Any` er begrænset til at teste, om en værdi er af en specificeret betontype, og kan ikke bruges til at teste, om en type implementerer en trait.
//!
//! [`Box`]: ../../std/boxed/struct.Box.html
//!
//! # Smarte pointer og `dyn Any`
//!
//! Et stykke adfærd, du skal huske på, når du bruger `Any` som et trait-objekt, især med typer som `Box<dyn Any>` eller `Arc<dyn Any>`, er, at blot at kalde `.type_id()` på værdien vil producere `TypeId` af *beholderen*, ikke det underliggende trait-objekt.
//!
//! Dette kan undgås ved at konvertere den smarte markør til en `&dyn Any` i stedet, som returnerer objektets `TypeId`.
//! For eksempel:
//!
//! ```
//! use std::any::{Any, TypeId};
//!
//! let boxed: Box<dyn Any> = Box::new(3_i32);
//!
//! // Det er mere sandsynligt, at du vil have dette:
//! let actual_id = (&*boxed).type_id();
//! // ... end dette:
//! let boxed_id = boxed.type_id();
//!
//! assert_eq!(actual_id, TypeId::of::<i32>());
//! assert_eq!(boxed_id, TypeId::of::<Box<dyn Any>>());
//! ```
//!
//! # Examples
//!
//! Overvej en situation, hvor vi vil logge ud af en værdi, der sendes til en funktion.
//! Vi kender den værdi, vi arbejder på, implementerer Debug, men vi kender ikke dens konkrete type.Vi ønsker at give speciel behandling til bestemte typer: i dette tilfælde udskrive længden af strengværdier før deres værdi.
//! Vi kender ikke den konkrete type af vores værdi på kompileringstidspunktet, så vi er nødt til at bruge runtime refleksion i stedet.
//!
//! ```rust
//! use std::fmt::Debug;
//! use std::any::Any;
//!
//! // Logger-funktion til enhver type, der implementerer Debug.
//! fn log<T: Any + Debug>(value: &T) {
//!     let value_any = value as &dyn Any;
//!
//!     // Prøv at konvertere vores værdi til en `String`.
//!     // Hvis det lykkes, vil vi sende strengens længde såvel som dens værdi.
//!     // Hvis ikke, er det en anden type: udskriv den bare usminket.
//!     match value_any.downcast_ref::<String>() {
//!         Some(as_string) => {
//!             println!("String ({}): {}", as_string.len(), as_string);
//!         }
//!         None => {
//!             println!("{:?}", value);
//!         }
//!     }
//! }
//!
//! // Denne funktion ønsker at logge dens parameter ud, før den arbejder med den.
//! fn do_work<T: Any + Debug>(value: &T) {
//!     log(value);
//!     // ... gør noget andet arbejde
//! }
//!
//! fn main() {
//!     let my_string = "Hello World".to_string();
//!     do_work(&my_string);
//!
//!     let my_i8: i8 = 100;
//!     do_work(&my_i8);
//! }
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::intrinsics;

///////////////////////////////////////////////////////////////////////////////
// Enhver trait
///////////////////////////////////////////////////////////////////////////////

/// En trait til at efterligne dynamisk typning.
///
/// De fleste typer implementerer `Any`.Enhver type, der indeholder en ikke-"statisk" reference, gør det dog ikke.
/// Se [module-level documentation][mod] for flere detaljer.
///
/// [mod]: crate::any
// Denne trait er ikke usikker, selvom vi stoler på specifikationerne for den eneste impl. `type_id`-funktion i usikker kode (f.eks. `downcast`).Normalt ville det være et problem, men fordi den eneste impl. Af `Any` er en implementering af et tæppe, kan ingen anden kode implementere `Any`.
//
// Vi kunne sandsynligvis gøre denne trait usikker-det ville ikke forårsage brud, da vi kontrollerer alle implementeringerne-men vi vælger ikke at gøre det, da det begge ikke er nødvendigt og kan forvirre brugerne om sondringen mellem usikre traits og usikre metoder (dvs. `type_id` vil stadig være sikkert at ringe til, men vi vil sandsynligvis gerne angive som sådan i dokumentationen).
//
//
//
//
//
//
//
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Any: 'static {
    /// Får `TypeId` til `self`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string(s: &dyn Any) -> bool {
    ///     TypeId::of::<String>() == s.type_id()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "get_type_id", since = "1.34.0")]
    fn type_id(&self) -> TypeId;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: 'static + ?Sized> Any for T {
    fn type_id(&self) -> TypeId {
        TypeId::of::<T>()
    }
}

///////////////////////////////////////////////////////////////////////////////
// Udvidelsesmetoder til alle trait-objekter.
///////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

// Sørg for, at resultatet af f.eks. Sammenføjning af en tråd kan udskrives og dermed bruges med `unwrap`.
// I sidste ende kan det ikke længere være nødvendigt, hvis forsendelsen fungerer med opkastning.
//
#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for dyn Any + Send {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

#[stable(feature = "any_send_sync_methods", since = "1.28.0")]
impl fmt::Debug for dyn Any + Send + Sync {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("Any")
    }
}

impl dyn Any {
    /// Returnerer `true`, hvis den boksede type er den samme som `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &dyn Any) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        // Få `TypeId` af den type, denne funktion er instantieret med.
        let t = TypeId::of::<T>();

        // Få `TypeId` af typen i trait-objektet (`self`).
        let concrete = self.type_id();

        // Sammenlign begge `TypeId`s om lighed.
        t == concrete
    }

    /// Returnerer en vis henvisning til værdien i boks, hvis den er af typen `T` eller `None`, hvis den ikke er.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &dyn Any) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        if self.is::<T>() {
            // SIKKERHED: kontrollerede lige, om vi peger på den rigtige type, og vi kan stole på
            // der kontrollerer hukommelsessikkerhed, fordi vi har implementeret Any for alle typer;ingen andre impls kan eksistere, da de ville være i konflikt med vores impl.
            //
            unsafe { Some(&*(self as *const dyn Any as *const T)) }
        } else {
            None
        }
    }

    /// Returnerer en ændret henvisning til den indrammede værdi, hvis den er af typen `T` eller `None`, hvis den ikke er.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut dyn Any) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        if self.is::<T>() {
            // SIKKERHED: kontrollerede lige, om vi peger på den rigtige type, og vi kan stole på
            // der kontrollerer hukommelsessikkerhed, fordi vi har implementeret Any for alle typer;ingen andre impls kan eksistere, da de ville være i konflikt med vores impl.
            //
            unsafe { Some(&mut *(self as *mut dyn Any as *mut T)) }
        } else {
            None
        }
    }
}

impl dyn Any + Send {
    /// Videresender til metoden defineret på typen `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Videresender til metoden defineret på typen `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Videresender til metoden defineret på typen `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

impl dyn Any + Send + Sync {
    /// Videresender til metoden defineret på typen `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn is_string(s: &(dyn Any + Send + Sync)) {
    ///     if s.is::<String>() {
    ///         println!("It's a string!");
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// is_string(&0);
    /// is_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn is<T: Any>(&self) -> bool {
        <dyn Any>::is::<T>(self)
    }

    /// Videresender til metoden defineret på typen `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn print_if_string(s: &(dyn Any + Send + Sync)) {
    ///     if let Some(string) = s.downcast_ref::<String>() {
    ///         println!("It's a string({}): '{}'", string.len(), string);
    ///     } else {
    ///         println!("Not a string...");
    ///     }
    /// }
    ///
    /// print_if_string(&0);
    /// print_if_string(&"cookie monster".to_string());
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_ref<T: Any>(&self) -> Option<&T> {
        <dyn Any>::downcast_ref::<T>(self)
    }

    /// Videresender til metoden defineret på typen `Any`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    ///
    /// fn modify_if_u32(s: &mut (dyn Any + Send + Sync)) {
    ///     if let Some(num) = s.downcast_mut::<u32>() {
    ///         *num = 42;
    ///     }
    /// }
    ///
    /// let mut x = 10u32;
    /// let mut s = "starlord".to_string();
    ///
    /// modify_if_u32(&mut x);
    /// modify_if_u32(&mut s);
    ///
    /// assert_eq!(x, 42);
    /// assert_eq!(&s, "starlord");
    /// ```
    #[stable(feature = "any_send_sync_methods", since = "1.28.0")]
    #[inline]
    pub fn downcast_mut<T: Any>(&mut self) -> Option<&mut T> {
        <dyn Any>::downcast_mut::<T>(self)
    }
}

///////////////////////////////////////////////////////////////////////////////
// TypeID og dens metoder
///////////////////////////////////////////////////////////////////////////////

/// En `TypeId` repræsenterer en globalt unik identifikator for en type.
///
/// Hver `TypeId` er et uigennemsigtigt objekt, der ikke tillader inspektion af hvad der er indeni, men tillader grundlæggende operationer som kloning, sammenligning, udskrivning og visning.
///
///
/// En `TypeId` er i øjeblikket kun tilgængelig for typer, der tilskrives `'static`, men denne begrænsning kan fjernes i future.
///
/// Mens `TypeId` implementerer `Hash`, `PartialOrd` og `Ord`, er det værd at bemærke, at hash og bestilling varierer mellem Rust-udgivelser.
/// Pas på at stole på dem inde i din kode!
///
///
///
#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Debug, Hash)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct TypeId {
    t: u64,
}

impl TypeId {
    /// Returnerer `TypeId` af den type, som denne generiske funktion er blevet instantieret med.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::{Any, TypeId};
    ///
    /// fn is_string<T: ?Sized + Any>(_s: &T) -> bool {
    ///     TypeId::of::<String>() == TypeId::of::<T>()
    /// }
    ///
    /// assert_eq!(is_string(&0), false);
    /// assert_eq!(is_string(&"cookie monster".to_string()), true);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub const fn of<T: ?Sized + 'static>() -> TypeId {
        TypeId { t: intrinsics::type_id::<T>() }
    }
}

/// Returnerer navnet på en type som en strengskive.
///
/// # Note
///
/// Dette er beregnet til diagnostisk brug.
/// Det nøjagtige indhold og format på den returnerede streng er ikke specificeret bortset fra at være en beskrivelse af den bedste indsats af typen.
/// For eksempel er `"Option<String>"` og `"std::option::Option<std::string::String>"` blandt strengene, som `type_name::<Option<String>>()` kan returnere.
///
///
/// Den returnerede streng skal ikke betragtes som en unik identifikator af en type, da flere typer muligvis kan kortlægges til det samme type navn.
/// Tilsvarende er der ingen garanti for, at alle dele af en type vises i den returnerede streng: for eksempel er levetidsspecifikationer i øjeblikket ikke inkluderet.
/// Derudover kan output ændre sig mellem versioner af compileren.
///
/// Den aktuelle implementering bruger den samme infrastruktur som kompilerdiagnostik og debuginfo, men dette garanteres ikke.
///
/// # Examples
///
/// ```rust
/// assert_eq!(
///     std::any::type_name::<Option<String>>(),
///     "core::option::Option<alloc::string::String>",
/// );
/// ```
///
///
///
///
#[stable(feature = "type_name", since = "1.38.0")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name<T: ?Sized>() -> &'static str {
    intrinsics::type_name::<T>()
}

/// Returnerer navnet på typen af den pegede værdi som en strengskive.
/// Dette er det samme som `type_name::<T>()`, men kan bruges hvor typen af en variabel ikke er let tilgængelig.
///
/// # Note
///
/// Dette er beregnet til diagnostisk brug.Det nøjagtige indhold og format af strengen er ikke specificeret bortset fra at være en beskrivelse af den bedste indsats af typen.
/// For eksempel kunne `type_name_of_val::<Option<String>>(None)` returnere `"Option<String>"` eller `"std::option::Option<std::string::String>"`, men ikke `"foobar"`.
///
/// Derudover kan output ændre sig mellem versioner af compileren.
///
/// Denne funktion løser ikke trait-objekter, hvilket betyder at `type_name_of_val(&7u32 as &dyn Debug)` muligvis returnerer `"dyn Debug"`, men ikke `"u32"`.
///
/// Typenavnet skal ikke betragtes som en unik identifikator af en type;
/// flere typer kan dele det samme navn.
///
/// Den aktuelle implementering bruger den samme infrastruktur som kompilerdiagnostik og debuginfo, men dette garanteres ikke.
///
/// # Examples
///
/// Udskriver standard heltal og float typer.
///
/// ```rust
/// #![feature(type_name_of_val)]
/// use std::any::type_name_of_val;
///
/// let x = 1;
/// println!("{}", type_name_of_val(&x));
/// let y = 1.0;
/// println!("{}", type_name_of_val(&y));
/// ```
///
///
///
///
///
///
#[unstable(feature = "type_name_of_val", issue = "66359")]
#[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
pub const fn type_name_of_val<T: ?Sized>(_val: &T) -> &'static str {
    type_name::<T>()
}