//! `Clone` trait for typer, der ikke kan 'implicit kopieres'.
//!
//! I Rust er nogle enkle typer "implicitly copyable", og når du tildeler dem eller sender dem som argumenter, får modtageren en kopi og efterlader den originale værdi på plads.
//! Disse typer kræver ikke tildeling til kopiering og har ikke færdiggørere (dvs. de indeholder ikke ejede kasser eller implementerer [`Drop`]), så kompilatoren betragter dem som billige og sikre at kopiere.
//!
//! For andre typer skal kopier laves eksplicit ved konvention at implementere [`Clone`] trait og kalde [`clone`]-metoden.
//!
//! [`clone`]: Clone::clone
//!
//! Grundlæggende brugseksempel:
//!
//! ```
//! let s = String::new(); // String type implementerer Clone
//! let copy = s.clone(); // så vi kan klone det
//! ```
//!
//! For nemt at implementere Clone trait kan du også bruge `#[derive(Clone)]`.Eksempel:
//!
//! ```
//! #[derive(Clone)] // vi tilføjer klonen trait til Morpheus struct
//! struct Morpheus {
//!    blue_pill: f32,
//!    red_pill: i64,
//! }
//!
//! fn main() {
//!    let f = Morpheus { blue_pill: 0.0, red_pill: 0 };
//!    let copy = f.clone(); // og nu kan vi klone det!
//! }
//! ```
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

/// En fælles trait for muligheden for eksplicit at duplikere et objekt.
///
/// Afviger fra [`Copy`] ved, at [`Copy`] er implicit og ekstremt billig, mens `Clone` altid er eksplicit og måske eller måske ikke er dyr.
/// For at håndhæve disse egenskaber tillader Rust dig ikke at genimplementere [`Copy`], men du kan genimplementere `Clone` og køre vilkårlig kode.
///
/// Da `Clone` er mere generel end [`Copy`], kan du automatisk gøre alt, hvad [`Copy`] også er `Clone`.
///
/// ## Derivable
///
/// Denne trait kan bruges med `#[derive]`, hvis alle felter er `Clone`.Den `udlede` implementering af [`Clone`] kalder [`clone`] på hvert felt.
///
/// [`clone`]: Clone::clone
///
/// For en generisk struktur implementerer `#[derive]` `Clone` betinget ved at tilføje bundet `Clone` til generiske parametre.
///
/// ```
/// // `derive` implementerer Clone for Reading<T>når T er klon.
/// #[derive(Clone)]
/// struct Reading<T> {
///     frequency: T,
/// }
/// ```
///
/// ## Hvordan kan jeg implementere `Clone`?
///
/// Typer, der er [`Copy`], skal have en triviel implementering af `Clone`.Mere formelt:
/// hvis `T: Copy`, `x: T` og `y: &T`, svarer `let x = y.clone();` til `let x = *y;`.
/// Manuelle implementeringer bør være forsigtige med at opretholde denne uændrede;dog må usikker kode ikke stole på den for at sikre hukommelsessikkerheden.
///
/// Et eksempel er en generisk struktur, der indeholder en funktionsmarkør.I dette tilfælde kan implementeringen af `Clone` ikke `udledes`d, men kan implementeres som:
///
/// ```
/// struct Generate<T>(fn() -> T);
///
/// impl<T> Copy for Generate<T> {}
///
/// impl<T> Clone for Generate<T> {
///     fn clone(&self) -> Self {
///         *self
///     }
/// }
/// ```
///
/// ## Yderligere implementatorer
///
/// Ud over [implementors listed below][impls] implementerer følgende typer også `Clone`:
///
/// * Funktionstyper (dvs. de forskellige typer, der er defineret for hver funktion)
/// * Funktionsmarkørtyper (f.eks. `fn() -> i32`)
/// * Array-typer, for alle størrelser, hvis varetypen også implementerer `Clone` (f.eks. `[i32; 123456]`)
/// * Tupletyper, hvis hver komponent også implementerer `Clone` (f.eks. `()`, `(i32, bool)`)
/// * Lukningstyper, hvis de ikke fanger nogen værdi fra miljøet, eller hvis alle sådanne fangede værdier implementerer `Clone` selv.
///   Bemærk, at variabler, der er fanget med delt reference, altid implementerer `Clone` (selvom referenten ikke gør det), mens variabler, der er fanget ved hjælp af mutabel reference, aldrig implementerer `Clone`.
///
///
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "clone"]
#[rustc_diagnostic_item = "Clone"]
pub trait Clone: Sized {
    /// Returnerer en kopi af værdien.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(noop_method_call)]
    /// let hello = "Hello"; // &str implementerer klon
    ///
    /// assert_eq!("Hello", hello.clone());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "cloning is often expensive and is not expected to have side effects"]
    fn clone(&self) -> Self;

    /// Udfører kopitildeling fra `source`.
    ///
    /// `a.clone_from(&b)` svarer til `a = b.clone()` i funktionalitet, men kan tilsidesættes for at genbruge ressourcerne i `a` for at undgå unødvendige tildelinger.
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn clone_from(&mut self, source: &Self) {
        *self = source.clone()
    }
}

/// Hent makro, der genererer en impl af trait `Clone`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Clone($item:item) {
    /* compiler built-in */
}

// FIXME(aburka): disse strukturer bruges udelukkende af#[udlede] til at hævde, at hver komponent af en type implementerer klon eller kopi.
//
//
// Disse strukturer skal aldrig vises i brugerkode.
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsClone<T: Clone + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}
#[doc(hidden)]
#[allow(missing_debug_implementations)]
#[unstable(
    feature = "derive_clone_copy",
    reason = "deriving hack, should not be public",
    issue = "none"
)]
pub struct AssertParamIsCopy<T: Copy + ?Sized> {
    _field: crate::marker::PhantomData<T>,
}

/// Implementeringer af `Clone` til primitive typer.
///
/// Implementeringer, der ikke kan beskrives i Rust, implementeres i `traits::SelectionContext::copy_clone_conditions()` i `rustc_trait_selection`.
///
///
mod impls {

    use super::Clone;

    macro_rules! impl_clone {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Clone for $t {
                    #[inline]
                    fn clone(&self) -> Self {
                        *self
                    }
                }
            )*
        }
    }

    impl_clone! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Clone for ! {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *const T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for *mut T {
        #[inline]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Delte referencer kan klones, men mutable referencer *kan ikke*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Clone for &T {
        #[inline]
        #[rustc_diagnostic_item = "noop_method_clone"]
        fn clone(&self) -> Self {
            *self
        }
    }

    /// Delte referencer kan klones, men mutable referencer *kan ikke*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> !Clone for &mut T {}
}