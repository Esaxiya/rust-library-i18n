//! Strengmanipulation.
//!
//! For flere detaljer, se [`std::str`]-modulet.
//!
//! [`std::str`]: ../../std/str/index.html

#![stable(feature = "rust1", since = "1.0.0")]

mod converts;
mod error;
mod iter;
mod traits;
mod validations;

use self::pattern::Pattern;
use self::pattern::{DoubleEndedSearcher, ReverseSearcher, Searcher};

use crate::char;
use crate::mem;
use crate::slice::{self, SliceIndex};

pub mod pattern;

#[unstable(feature = "str_internals", issue = "none")]
#[allow(missing_docs)]
pub mod lossy;

#[stable(feature = "rust1", since = "1.0.0")]
pub use converts::{from_utf8, from_utf8_unchecked};

#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub use converts::{from_utf8_mut, from_utf8_unchecked_mut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use error::{ParseBoolError, Utf8Error};

#[stable(feature = "rust1", since = "1.0.0")]
pub use traits::FromStr;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Bytes, CharIndices, Chars, Lines, SplitWhitespace};

#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated)]
pub use iter::LinesAny;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplit, RSplitTerminator, Split, SplitTerminator};

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, SplitN};

#[stable(feature = "str_matches", since = "1.2.0")]
pub use iter::{Matches, RMatches};

#[stable(feature = "str_match_indices", since = "1.5.0")]
pub use iter::{MatchIndices, RMatchIndices};

#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use iter::EncodeUtf16;

#[stable(feature = "str_escape", since = "1.34.0")]
pub use iter::{EscapeDebug, EscapeDefault, EscapeUnicode};

#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use iter::SplitAsciiWhitespace;

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::SplitInclusive;

#[unstable(feature = "str_internals", issue = "none")]
pub use validations::next_code_point;

use iter::MatchIndicesInternal;
use iter::SplitInternal;
use iter::{MatchesInternal, SplitNInternal};

use validations::truncate_to_char_boundary;

#[inline(never)]
#[cold]
#[track_caller]
fn slice_error_fail(s: &str, begin: usize, end: usize) -> ! {
    const MAX_DISPLAY_LENGTH: usize = 256;
    let (truncated, s_trunc) = truncate_to_char_boundary(s, MAX_DISPLAY_LENGTH);
    let ellipsis = if truncated { "[...]" } else { "" };

    // 1. Over grænsen
    if begin > s.len() || end > s.len() {
        let oob_index = if begin > s.len() { begin } else { end };
        panic!("byte index {} is out of bounds of `{}`{}", oob_index, s_trunc, ellipsis);
    }

    // 2. start <=slut
    assert!(
        begin <= end,
        "begin <= end ({} <= {}) when slicing `{}`{}",
        begin,
        end,
        s_trunc,
        ellipsis
    );

    // 3. tegngrænse
    let index = if !s.is_char_boundary(begin) { begin } else { end };
    // find karakteren
    let mut char_start = index;
    while !s.is_char_boundary(char_start) {
        char_start -= 1;
    }
    // `char_start` skal være mindre end len og en char grænse
    let ch = s[char_start..].chars().next().unwrap();
    let char_range = char_start..char_start + ch.len_utf8();
    panic!(
        "byte index {} is not a char boundary; it is inside {:?} (bytes {:?}) of `{}`{}",
        index, ch, char_range, s_trunc, ellipsis
    );
}

#[lang = "str"]
#[cfg(not(test))]
impl str {
    /// Returnerer længden på `self`.
    ///
    /// Denne længde er i byte, ikke [`char`] eller grafemer.
    /// Med andre ord er det måske ikke, hvad et menneske betragter længden af strengen.
    ///
    /// [`char`]: prim@char
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let len = "foo".len();
    /// assert_eq!(3, len);
    ///
    /// assert_eq!("ƒoo".len(), 4); // fancy f!
    /// assert_eq!("ƒoo".chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_len", since = "1.32.0")]
    #[inline]
    pub const fn len(&self) -> usize {
        self.as_bytes().len()
    }

    /// Returnerer `true`, hvis `self` har en længde på nul byte.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let s = "";
    /// assert!(s.is_empty());
    ///
    /// let s = "not empty";
    /// assert!(!s.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_str_is_empty", since = "1.32.0")]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Kontrollerer, at `index`-th byte er den første byte i en UTF-8-kodepunktsekvens eller slutningen af strengen.
    ///
    ///
    /// Starten og slutningen af strengen (når `index== self.len()`) betragtes som grænser.
    ///
    /// Returnerer `false`, hvis `index` er større end `self.len()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// assert!(s.is_char_boundary(0));
    /// // start af `老`
    /// assert!(s.is_char_boundary(6));
    /// assert!(s.is_char_boundary(s.len()));
    ///
    /// // anden byte på `ö`
    /// assert!(!s.is_char_boundary(2));
    ///
    /// // tredje byte af `老`
    /// assert!(!s.is_char_boundary(8));
    /// ```
    ///
    #[stable(feature = "is_char_boundary", since = "1.9.0")]
    #[inline]
    pub fn is_char_boundary(&self, index: usize) -> bool {
        // 0 og len er altid ok.
        // Test eksplicit for 0, så det nemt kan optimere kontrollen og springe over læsning af strengdata for den sag.
        //
        if index == 0 || index == self.len() {
            return true;
        }
        match self.as_bytes().get(index) {
            None => false,
            // Dette er lidt magisk svarende til: b <128 ||b>=192
            Some(&b) => (b as i8) >= -0x40,
        }
    }

    /// Konverterer en strengskive til en byteskive.
    /// Brug [`from_utf8`]-funktionen til at konvertere byte-skiven tilbage til en strengskive.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let bytes = "bors".as_bytes();
    /// assert_eq!(b"bors", bytes);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "str_as_bytes", since = "1.32.0")]
    #[inline(always)]
    #[allow(unused_attributes)]
    #[rustc_allow_const_fn_unstable(const_fn_transmute)]
    pub const fn as_bytes(&self) -> &[u8] {
        // SIKKERHED: const-lyd, fordi vi transmitterer to typer med samme layout
        unsafe { mem::transmute(self) }
    }

    /// Konverterer en ændret strengskive til en ændret byteskive.
    ///
    /// # Safety
    ///
    /// Den, der ringer op, skal sikre, at indholdet af udsnittet er gyldigt UTF-8, inden lånet slutter, og den underliggende `str` bruges.
    ///
    ///
    /// Brug af en `str`, hvis indhold ikke er gyldigt UTF-8, er udefineret adfærd.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let mut s = String::from("Hello");
    /// let bytes = unsafe { s.as_bytes_mut() };
    ///
    /// assert_eq!(b"Hello", bytes);
    /// ```
    ///
    /// Mutability:
    ///
    /// ```
    /// let mut s = String::from("🗻∈🌏");
    ///
    /// unsafe {
    ///     let bytes = s.as_bytes_mut();
    ///
    ///     bytes[0] = 0xF0;
    ///     bytes[1] = 0x9F;
    ///     bytes[2] = 0x8D;
    ///     bytes[3] = 0x94;
    /// }
    ///
    /// assert_eq!("🍔∈🌏", s);
    /// ```
    #[stable(feature = "str_mut_extras", since = "1.20.0")]
    #[inline(always)]
    pub unsafe fn as_bytes_mut(&mut self) -> &mut [u8] {
        // SIKKERHED: rollebesætningen fra `&str` til `&[u8]` er sikker siden `str`
        // har samme layout som `&[u8]` (kun libstd kan stille denne garanti).
        // Markørafvigelsen er sikker, da den kommer fra en ændret reference, som garanteret er gyldig til skrivning.
        //
        unsafe { &mut *(self as *mut str as *mut [u8]) }
    }

    /// Konverterer en strengskive til en rå markør.
    ///
    /// Da strengskiver er et stykke byte, peger den rå markør på en [`u8`].
    /// Denne markør peger på den første byte i strengskiven.
    ///
    /// Den, der ringer op, skal sikre, at den returnerede markør aldrig skrives til.
    /// Brug [`as_mut_ptr`], hvis du har brug for at mutere indholdet af strengskivet.
    ///
    ///
    /// [`as_mut_ptr`]: str::as_mut_ptr
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let s = "Hello";
    /// let ptr = s.as_ptr();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "rustc_str_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const u8 {
        self as *const str as *const u8
    }

    /// Konverterer en ændret strengskive til en rå markør.
    ///
    /// Da strengskiver er et stykke byte, peger den rå markør på en [`u8`].
    /// Denne markør peger på den første byte i strengskiven.
    ///
    /// Det er dit ansvar at sørge for, at strengestrengen kun bliver ændret på en måde, så den forbliver gyldig UTF-8.
    ///
    ///
    #[stable(feature = "str_as_mut_ptr", since = "1.36.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut u8 {
        self as *mut str as *mut u8
    }

    /// Returnerer en underdel af `str`.
    ///
    /// Dette er det ikke-paniske alternativ til indeksering af `str`.
    /// Returnerer [`None`], når ækvivalent indekseringsoperation ville være panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = String::from("🗻∈🌏");
    ///
    /// assert_eq!(Some("🗻"), v.get(0..4));
    ///
    /// // indeks ikke på UTF-8 sekvensgrænser
    /// assert!(v.get(1..).is_none());
    /// assert!(v.get(..8).is_none());
    ///
    /// // Over grænsen
    /// assert!(v.get(..42).is_none());
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get<I: SliceIndex<str>>(&self, i: I) -> Option<&I::Output> {
        i.get(self)
    }

    /// Returnerer en ændret underdel af `str`.
    ///
    /// Dette er det ikke-paniske alternativ til indeksering af `str`.
    /// Returnerer [`None`], når ækvivalent indekseringsoperation ville være panic.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("hello");
    /// // korrekt længde
    /// assert!(v.get_mut(0..5).is_some());
    /// // Over grænsen
    /// assert!(v.get_mut(..42).is_none());
    /// assert_eq!(Some("he"), v.get_mut(0..2).map(|v| &*v));
    ///
    /// assert_eq!("hello", v);
    /// {
    ///     let s = v.get_mut(0..2);
    ///     let s = s.map(|s| {
    ///         s.make_ascii_uppercase();
    ///         &*s
    ///     });
    ///     assert_eq!(Some("HE"), s);
    /// }
    /// assert_eq!("HEllo", v);
    /// ```
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub fn get_mut<I: SliceIndex<str>>(&mut self, i: I) -> Option<&mut I::Output> {
        i.get_mut(self)
    }

    /// Returnerer en ukontrolleret underdel af `str`.
    ///
    /// Dette er det ukontrollerede alternativ til indeksering af `str`.
    ///
    /// # Safety
    ///
    /// Opkaldere af denne funktion er ansvarlige for, at disse forudsætninger er opfyldt:
    ///
    /// * Startindekset må ikke overstige slutningsindekset;
    /// * Indekser skal være inden for rammerne af det originale udsnit;
    /// * Indekser skal ligge på UTF-8 sekvensgrænser.
    ///
    /// I modsat fald kan den returnerede strengskive henvise til ugyldig hukommelse eller krænke invarianterne, der kommunikeres af typen `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let v = "🗻∈🌏";
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked(0..4));
    ///     assert_eq!("∈", v.get_unchecked(4..7));
    ///     assert_eq!("🌏", v.get_unchecked(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked<I: SliceIndex<str>>(&self, i: I) -> &I::Output {
        // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `get_unchecked`;
        // udsnittet kan udskæres, fordi `self` er en sikker reference.
        // Den returnerede markør er sikker, fordi implanter af `SliceIndex` skal garantere, at det er det.
        unsafe { &*i.get_unchecked(self) }
    }

    /// Returnerer en ændret, ikke-markeret underdel af `str`.
    ///
    /// Dette er det ukontrollerede alternativ til indeksering af `str`.
    ///
    /// # Safety
    ///
    /// Opkaldere af denne funktion er ansvarlige for, at disse forudsætninger er opfyldt:
    ///
    /// * Startindekset må ikke overstige slutningsindekset;
    /// * Indekser skal være inden for rammerne af det originale udsnit;
    /// * Indekser skal ligge på UTF-8 sekvensgrænser.
    ///
    /// I modsat fald kan den returnerede strengskive henvise til ugyldig hukommelse eller krænke invarianterne, der kommunikeres af typen `str`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = String::from("🗻∈🌏");
    /// unsafe {
    ///     assert_eq!("🗻", v.get_unchecked_mut(0..4));
    ///     assert_eq!("∈", v.get_unchecked_mut(4..7));
    ///     assert_eq!("🌏", v.get_unchecked_mut(7..11));
    /// }
    /// ```
    ///
    #[stable(feature = "str_checked_slicing", since = "1.20.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I: SliceIndex<str>>(&mut self, i: I) -> &mut I::Output {
        // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `get_unchecked_mut`;
        // udsnittet kan udskæres, fordi `self` er en sikker reference.
        // Den returnerede markør er sikker, fordi implanter af `SliceIndex` skal garantere, at det er det.
        unsafe { &mut *i.get_unchecked_mut(self) }
    }

    /// Opretter en strengskive fra en anden strengskive, der omgår sikkerhedskontrol.
    ///
    /// Dette anbefales generelt ikke, brug med forsigtighed!For et sikkert alternativ se [`str`] og [`Index`].
    ///
    ///
    /// [`Index`]: crate::ops::Index
    ///
    /// Denne nye skive går fra `begin` til `end`, inklusive `begin` men eksklusive `end`.
    ///
    /// For at få en ændret strengskive i stedet, se [`slice_mut_unchecked`]-metoden.
    ///
    /// [`slice_mut_unchecked`]: str::slice_mut_unchecked
    ///
    /// # Safety
    ///
    /// Opkaldere af denne funktion er ansvarlige for, at tre forudsætninger er opfyldt:
    ///
    /// * `begin` må ikke overstige `end`.
    /// * `begin` og `end` skal være bytepositioner i strengskiven.
    /// * `begin` og `end` skal ligge på UTF-8 sekvensgrænser.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// unsafe {
    ///     assert_eq!("Löwe 老虎 Léopard", s.slice_unchecked(0, 21));
    /// }
    ///
    /// let s = "Hello, world!";
    ///
    /// unsafe {
    ///     assert_eq!("world", s.slice_unchecked(7, 12));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_unchecked(&self, begin: usize, end: usize) -> &str {
        // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `get_unchecked`;
        // udsnittet kan udskæres, fordi `self` er en sikker reference.
        // Den returnerede markør er sikker, fordi implanter af `SliceIndex` skal garantere, at det er det.
        unsafe { &*(begin..end).get_unchecked(self) }
    }

    /// Opretter en strengskive fra en anden strengskive, der omgår sikkerhedskontrol.
    /// Dette anbefales generelt ikke, brug med forsigtighed!For et sikkert alternativ se [`str`] og [`IndexMut`].
    ///
    ///
    /// [`IndexMut`]: crate::ops::IndexMut
    ///
    /// Denne nye skive går fra `begin` til `end`, inklusive `begin` men eksklusive `end`.
    ///
    /// For at få en uforanderlig strengskive i stedet, se [`slice_unchecked`]-metoden.
    ///
    /// [`slice_unchecked`]: str::slice_unchecked
    ///
    /// # Safety
    ///
    /// Opkaldere af denne funktion er ansvarlige for, at tre forudsætninger er opfyldt:
    ///
    /// * `begin` må ikke overstige `end`.
    /// * `begin` og `end` skal være bytepositioner i strengskiven.
    /// * `begin` og `end` skal ligge på UTF-8 sekvensgrænser.
    ///
    ///
    ///
    ///
    #[stable(feature = "str_slice_mut", since = "1.5.0")]
    #[rustc_deprecated(since = "1.29.0", reason = "use `get_unchecked_mut(begin..end)` instead")]
    #[inline]
    pub unsafe fn slice_mut_unchecked(&mut self, begin: usize, end: usize) -> &mut str {
        // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `get_unchecked_mut`;
        // udsnittet kan udskæres, fordi `self` er en sikker reference.
        // Den returnerede markør er sikker, fordi implanter af `SliceIndex` skal garantere, at det er det.
        unsafe { &mut *(begin..end).get_unchecked_mut(self) }
    }

    /// Opdel en strengskive i to ved et indeks.
    ///
    /// Argumentet, `mid`, skal være en byte-offset fra begyndelsen af strengen.
    /// Det skal også være på grænsen til et UTF-8-kodepunkt.
    ///
    /// De to returnerede skiver går fra starten af strengskiven til `mid` og fra `mid` til slutningen af strengskiven.
    ///
    /// For at få mutable strengeskiver i stedet, se [`split_at_mut`]-metoden.
    ///
    /// [`split_at_mut`]: str::split_at_mut
    ///
    /// # Panics
    ///
    /// Panics hvis `mid` ikke er på en UTF-8-kodepunktsgrænse, eller hvis den er forbi slutningen af det sidste kodepunkt i strengskivet.
    ///
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let s = "Per Martin-Löf";
    ///
    /// let (first, last) = s.split_at(3);
    ///
    /// assert_eq!("Per", first);
    /// assert_eq!(" Martin-Löf", last);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at(&self, mid: usize) -> (&str, &str) {
        // is_char_boundary kontrollerer at indekset er i [0, .len()]
        if self.is_char_boundary(mid) {
            // SIKKERHED: kontrollerede netop, at `mid` er på en grænser for kul.
            unsafe { (self.get_unchecked(0..mid), self.get_unchecked(mid..self.len())) }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Opdel en ændret strengskive i to ved et indeks.
    ///
    /// Argumentet, `mid`, skal være en byte-offset fra begyndelsen af strengen.
    /// Det skal også være på grænsen til et UTF-8-kodepunkt.
    ///
    /// De to returnerede skiver går fra starten af strengskiven til `mid` og fra `mid` til slutningen af strengskiven.
    ///
    /// For at få uforanderlige strengeskiver i stedet, se [`split_at`]-metoden.
    ///
    /// [`split_at`]: str::split_at
    ///
    /// # Panics
    ///
    /// Panics hvis `mid` ikke er på en UTF-8-kodepunktsgrænse, eller hvis den er forbi slutningen af det sidste kodepunkt i strengskivet.
    ///
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let mut s = "Per Martin-Löf".to_string();
    /// {
    ///     let (first, last) = s.split_at_mut(3);
    ///     first.make_ascii_uppercase();
    ///     assert_eq!("PER", first);
    ///     assert_eq!(" Martin-Löf", last);
    /// }
    /// assert_eq!("PER Martin-Löf", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "str_split_at", since = "1.4.0")]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut str, &mut str) {
        // is_char_boundary kontrollerer at indekset er i [0, .len()]
        if self.is_char_boundary(mid) {
            let len = self.len();
            let ptr = self.as_mut_ptr();
            // SIKKERHED: kontrollerede netop, at `mid` er på en grænser for kul.
            unsafe {
                (
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr, mid)),
                    from_utf8_unchecked_mut(slice::from_raw_parts_mut(ptr.add(mid), len - mid)),
                )
            }
        } else {
            slice_error_fail(self, 0, mid)
        }
    }

    /// Returnerer en iterator over [`char`] s for en strengskive.
    ///
    /// Da en strengskive består af gyldig UTF-8, kan vi gentage gennem en strengskive med [`char`].
    /// Denne metode returnerer en sådan iterator.
    ///
    /// Det er vigtigt at huske, at [`char`] repræsenterer en Unicode Scalar Value og måske ikke svarer til din idé om, hvad en 'character' er.
    ///
    /// Iteration over grafemklynger kan være, hvad du rent faktisk vil have.
    /// Denne funktionalitet leveres ikke af Rust s standardbibliotek, tjek crates.io i stedet.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.chars().count();
    /// assert_eq!(7, count);
    ///
    /// let mut chars = word.chars();
    ///
    /// assert_eq!(Some('g'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('o'), chars.next());
    /// assert_eq!(Some('d'), chars.next());
    /// assert_eq!(Some('b'), chars.next());
    /// assert_eq!(Some('y'), chars.next());
    /// assert_eq!(Some('e'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    ///
    /// Husk, at [`char`] muligvis ikke svarer til din intuition om tegn:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let y = "y̆";
    ///
    /// let mut chars = y.chars();
    ///
    /// assert_eq!(Some('y'), chars.next()); // ikke 'y̆'
    /// assert_eq!(Some('\u{0306}'), chars.next());
    ///
    /// assert_eq!(None, chars.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chars(&self) -> Chars<'_> {
        Chars { iter: self.as_bytes().iter() }
    }

    /// Returnerer en iterator over [`char`] s for en strengskive og deres positioner.
    ///
    /// Da en strengskive består af gyldig UTF-8, kan vi gentage gennem en strengskive med [`char`].
    /// Denne metode returnerer en iterator af begge disse [`char`] samt deres bytepositioner.
    ///
    /// Iteratoren giver tupler.Positionen er først, [`char`] er anden.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let word = "goodbye";
    ///
    /// let count = word.char_indices().count();
    /// assert_eq!(7, count);
    ///
    /// let mut char_indices = word.char_indices();
    ///
    /// assert_eq!(Some((0, 'g')), char_indices.next());
    /// assert_eq!(Some((1, 'o')), char_indices.next());
    /// assert_eq!(Some((2, 'o')), char_indices.next());
    /// assert_eq!(Some((3, 'd')), char_indices.next());
    /// assert_eq!(Some((4, 'b')), char_indices.next());
    /// assert_eq!(Some((5, 'y')), char_indices.next());
    /// assert_eq!(Some((6, 'e')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    /// Husk, at [`char`] muligvis ikke svarer til din intuition om tegn:
    ///
    /// [`char`]: prim@char
    ///
    /// ```
    /// let yes = "y̆es";
    ///
    /// let mut char_indices = yes.char_indices();
    ///
    /// assert_eq!(Some((0, 'y')), char_indices.next()); // ikke (0, 'y̆')
    /// assert_eq!(Some((1, '\u{0306}')), char_indices.next());
    ///
    /// // bemærk 3 her, det sidste tegn tog to bytes
    /// assert_eq!(Some((3, 'e')), char_indices.next());
    /// assert_eq!(Some((4, 's')), char_indices.next());
    ///
    /// assert_eq!(None, char_indices.next());
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn char_indices(&self) -> CharIndices<'_> {
        CharIndices { front_offset: 0, iter: self.chars() }
    }

    /// En iterator over byte i en strengskive.
    ///
    /// Da en strengskive består af en sekvens af bytes, kan vi gentage gennem en strengskive for byte.
    /// Denne metode returnerer en sådan iterator.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let mut bytes = "bors".bytes();
    ///
    /// assert_eq!(Some(b'b'), bytes.next());
    /// assert_eq!(Some(b'o'), bytes.next());
    /// assert_eq!(Some(b'r'), bytes.next());
    /// assert_eq!(Some(b's'), bytes.next());
    ///
    /// assert_eq!(None, bytes.next());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn bytes(&self) -> Bytes<'_> {
        Bytes(self.as_bytes().iter().copied())
    }

    /// Opdeler en strengskive efter mellemrum.
    ///
    /// Den returnerede iterator returnerer strengeskiver, der er underskiver af den originale strengskive, adskilt af en hvilken som helst mængde mellemrum.
    ///
    ///
    /// 'Whitespace' er defineret i henhold til vilkårene for Unicode Derived Core Property `White_Space`.
    /// Hvis du kun vil opdele på ASCII-hvidt mellemrum i stedet, skal du bruge [`split_ascii_whitespace`].
    ///
    /// [`split_ascii_whitespace`]: str::split_ascii_whitespace
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let mut iter = "A few words".split_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Alle former for mellemrum tages i betragtning:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta\u{2009}little  \n\t lamb".split_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[stable(feature = "split_whitespace", since = "1.1.0")]
    #[inline]
    pub fn split_whitespace(&self) -> SplitWhitespace<'_> {
        SplitWhitespace { inner: self.split(IsWhitespace).filter(IsNotEmpty) }
    }

    /// Opdeler en strengskive efter ASCII-mellemrum.
    ///
    /// Den returnerede iterator returnerer strengeskiver, der er underskiver af den originale strengskive, adskilt af en hvilken som helst mængde ASCII-mellemrum.
    ///
    ///
    /// For at opdele med Unicode `Whitespace` i stedet skal du bruge [`split_whitespace`].
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let mut iter = "A few words".split_ascii_whitespace();
    ///
    /// assert_eq!(Some("A"), iter.next());
    /// assert_eq!(Some("few"), iter.next());
    /// assert_eq!(Some("words"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    /// Alle slags ASCII-mellemrum tages i betragtning:
    ///
    /// ```
    /// let mut iter = " Mary   had\ta little  \n\t lamb".split_ascii_whitespace();
    /// assert_eq!(Some("Mary"), iter.next());
    /// assert_eq!(Some("had"), iter.next());
    /// assert_eq!(Some("a"), iter.next());
    /// assert_eq!(Some("little"), iter.next());
    /// assert_eq!(Some("lamb"), iter.next());
    ///
    /// assert_eq!(None, iter.next());
    /// ```
    #[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
    #[inline]
    pub fn split_ascii_whitespace(&self) -> SplitAsciiWhitespace<'_> {
        let inner =
            self.as_bytes().split(IsAsciiWhitespace).filter(BytesIsNotEmpty).map(UnsafeBytesToStr);
        SplitAsciiWhitespace { inner }
    }

    /// En iterator over strengene i en streng som strengeskiver.
    ///
    /// Linjer afsluttes med enten en ny linje (`\n`) eller en vognretur med en linjefodring (`\r\n`).
    ///
    /// Den sidste linjeafslutning er valgfri.
    /// En streng, der slutter med en endelig linjeafslutning, returnerer de samme linjer som en ellers identisk streng uden en endelig linjeafslutning.
    ///
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let text = "foo\r\nbar\n\nbaz\n";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    /// Den endelige linjeafslutning er ikke påkrævet:
    ///
    /// ```
    /// let text = "foo\nbar\n\r\nbaz";
    /// let mut lines = text.lines();
    ///
    /// assert_eq!(Some("foo"), lines.next());
    /// assert_eq!(Some("bar"), lines.next());
    /// assert_eq!(Some(""), lines.next());
    /// assert_eq!(Some("baz"), lines.next());
    ///
    /// assert_eq!(None, lines.next());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn lines(&self) -> Lines<'_> {
        Lines(self.split_terminator('\n').map(LinesAnyMap))
    }

    /// En iterator over en streng.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.4.0", reason = "use lines() instead now")]
    #[inline]
    #[allow(deprecated)]
    pub fn lines_any(&self) -> LinesAny<'_> {
        LinesAny(self.lines())
    }

    /// Returnerer en iterator af `u16` over strengen kodet som UTF-16.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let text = "Zażółć gęślą jaźń";
    ///
    /// let utf8_len = text.len();
    /// let utf16_len = text.encode_utf16().count();
    ///
    /// assert!(utf16_len <= utf8_len);
    /// ```
    #[stable(feature = "encode_utf16", since = "1.8.0")]
    pub fn encode_utf16(&self) -> EncodeUtf16<'_> {
        EncodeUtf16 { chars: self.chars(), extra: 0 }
    }

    /// Returnerer `true`, hvis det givne mønster matcher en underskive af denne strengskive.
    ///
    /// Returnerer `false`, hvis den ikke gør det.
    ///
    /// [pattern] kan være en `&str`, [`char`], et stykke af [`char`] s eller en funktion eller lukning, der bestemmer, om et tegn matcher.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.contains("nana"));
    /// assert!(!bananas.contains("apples"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_contained_in(self)
    }

    /// Returnerer `true`, hvis det givne mønster matcher et præfiks for denne strengskive.
    ///
    /// Returnerer `false`, hvis den ikke gør det.
    ///
    /// [pattern] kan være en `&str`, [`char`], et stykke af [`char`] s eller en funktion eller lukning, der bestemmer, om et tegn matcher.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.starts_with("bana"));
    /// assert!(!bananas.starts_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with<'a, P: Pattern<'a>>(&'a self, pat: P) -> bool {
        pat.is_prefix_of(self)
    }

    /// Returnerer `true`, hvis det givne mønster matcher et suffiks af denne strengskive.
    ///
    /// Returnerer `false`, hvis den ikke gør det.
    ///
    /// [pattern] kan være en `&str`, [`char`], et stykke af [`char`] s eller en funktion eller lukning, der bestemmer, om et tegn matcher.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let bananas = "bananas";
    ///
    /// assert!(bananas.ends_with("anas"));
    /// assert!(!bananas.ends_with("nana"));
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with<'a, P>(&'a self, pat: P) -> bool
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.is_suffix_of(self)
    }

    /// Returnerer byteindekset for det første tegn i denne strengskive, der matcher mønsteret.
    ///
    /// Returnerer [`None`], hvis mønsteret ikke stemmer overens.
    ///
    /// [pattern] kan være en `&str`, [`char`], et stykke af [`char`] s eller en funktion eller lukning, der bestemmer, om et tegn matcher.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Enkle mønstre:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.find('L'), Some(0));
    /// assert_eq!(s.find('é'), Some(14));
    /// assert_eq!(s.find("pard"), Some(17));
    /// ```
    ///
    /// Mere komplekse mønstre ved hjælp af punktfri stil og lukninger:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.find(char::is_whitespace), Some(5));
    /// assert_eq!(s.find(char::is_lowercase), Some(1));
    /// assert_eq!(s.find(|c: char| c.is_whitespace() || c.is_lowercase()), Some(1));
    /// assert_eq!(s.find(|c: char| (c < 'o') && (c > 'a')), Some(4));
    /// ```
    ///
    /// Finder ikke mønsteret:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.find(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn find<'a, P: Pattern<'a>>(&'a self, pat: P) -> Option<usize> {
        pat.into_searcher(self).next_match().map(|(i, _)| i)
    }

    /// Returnerer byteindekset for det første tegn i mønsteret længst til højre i mønsteret i denne strengskive.
    ///
    /// Returnerer [`None`], hvis mønsteret ikke stemmer overens.
    ///
    /// [pattern] kan være en `&str`, [`char`], et stykke af [`char`] s eller en funktion eller lukning, der bestemmer, om et tegn matcher.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Enkle mønstre:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard Gepardi";
    ///
    /// assert_eq!(s.rfind('L'), Some(13));
    /// assert_eq!(s.rfind('é'), Some(14));
    /// assert_eq!(s.rfind("pard"), Some(24));
    /// ```
    ///
    /// Mere komplekse mønstre med lukninger:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    ///
    /// assert_eq!(s.rfind(char::is_whitespace), Some(12));
    /// assert_eq!(s.rfind(char::is_lowercase), Some(20));
    /// ```
    ///
    /// Finder ikke mønsteret:
    ///
    /// ```
    /// let s = "Löwe 老虎 Léopard";
    /// let x: &[_] = &['1', '2'];
    ///
    /// assert_eq!(s.rfind(x), None);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rfind<'a, P>(&'a self, pat: P) -> Option<usize>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        pat.into_searcher(self).next_match_back().map(|(i, _)| i)
    }

    /// En iterator over understrenge af denne strengskive adskilt af tegn matchet med et mønster.
    ///
    /// [pattern] kan være en `&str`, [`char`], et stykke af [`char`] s eller en funktion eller lukning, der bestemmer, om et tegn matcher.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratoradfærd
    ///
    /// Den returnerede iterator vil være en [`DoubleEndedIterator`], hvis mønsteret tillader en omvendt søgning, og forward/reverse-søgning giver de samme elementer.
    /// Dette gælder for f.eks. [`char`], men ikke for `&str`.
    ///
    /// Hvis mønsteret tillader en omvendt søgning, men dens resultater kan afvige fra en fremadgående søgning, kan [`rsplit`]-metoden bruges.
    ///
    /// [`rsplit`]: str::rsplit
    ///
    /// # Examples
    ///
    /// Enkle mønstre:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".split(' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a", "little", "lamb"]);
    ///
    /// let v: Vec<&str> = "".split('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".split('X').collect();
    /// assert_eq!(v, ["lion", "", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".split("::").collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    ///
    /// let v: Vec<&str> = "abc1def2ghi".split(char::is_numeric).collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    ///
    /// let v: Vec<&str> = "lionXtigerXleopard".split(char::is_uppercase).collect();
    /// assert_eq!(v, ["lion", "tiger", "leopard"]);
    /// ```
    ///
    /// Hvis mønsteret er et stykke tegn, skal du dele på hver forekomst af et af tegnene:
    ///
    /// ```
    /// let v: Vec<&str> = "2020-11-03 23:59".split(&['-', ' ', ':', '@'][..]).collect();
    /// assert_eq!(v, ["2020", "11", "03", "23", "59"]);
    /// ```
    ///
    /// Et mere komplekst mønster ved hjælp af en lukning:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".split(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "def", "ghi"]);
    /// ```
    ///
    /// Hvis en streng indeholder flere sammenhængende separatorer, vil du ende med tomme strenge i output:
    ///
    /// ```
    /// let x = "||||a||b|c".to_string();
    /// let d: Vec<_> = x.split('|').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Sammenhængende separatorer adskilles af den tomme streng.
    ///
    /// ```
    /// let x = "(///)".to_string();
    /// let d: Vec<_> = x.split('/').collect();
    ///
    /// assert_eq!(d, &["(", "", "", ")"]);
    /// ```
    ///
    /// Separatorer i starten eller slutningen af en streng er naboer af tomme strenge.
    ///
    /// ```
    /// let d: Vec<_> = "010".split("0").collect();
    /// assert_eq!(d, &["", "1", ""]);
    /// ```
    ///
    /// Når den tomme streng bruges som en separator, adskiller den hvert tegn i strengen sammen med begyndelsen og slutningen af strengen.
    ///
    /// ```
    /// let f: Vec<_> = "rust".split("").collect();
    /// assert_eq!(f, &["", "r", "u", "s", "t", ""]);
    /// ```
    ///
    /// Sammenhængende separatorer kan føre til muligvis overraskende opførsel, når det hvide mellemrum bruges som separator.Denne kode er korrekt:
    ///
    /// ```
    /// let x = "    a  b c".to_string();
    /// let d: Vec<_> = x.split(' ').collect();
    ///
    /// assert_eq!(d, &["", "", "", "", "a", "", "b", "c"]);
    /// ```
    ///
    /// Det giver _not_ dig:
    ///
    /// ```,ignore
    /// assert_eq!(d, &["a", "b", "c"]);
    /// ```
    ///
    /// Brug [`split_whitespace`] til denne opførsel.
    ///
    /// [`split_whitespace`]: str::split_whitespace
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<'a, P: Pattern<'a>>(&'a self, pat: P) -> Split<'a, P> {
        Split(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: true,
            finished: false,
        })
    }

    /// En iterator over understrenge af denne strengskive adskilt af tegn matchet med et mønster.
    /// Afviger fra iteratoren, der er produceret af `split`, idet `split_inclusive` efterlader den matchede del som afslutningen på underlaget.
    ///
    ///
    /// [pattern] kan være en `&str`, [`char`], et stykke af [`char`] s eller en funktion eller lukning, der bestemmer, om et tegn matcher.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb."
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb."]);
    /// ```
    ///
    /// Hvis det sidste element i strengen matches, vil dette element blive betragtet som terminatoren for den foregående understreng.
    /// Denne understrengning er det sidste element, der returneres af iteratoren.
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb\nlittle lamb\nlittle lamb.\n"
    ///     .split_inclusive('\n').collect();
    /// assert_eq!(v, ["Mary had a little lamb\n", "little lamb\n", "little lamb.\n"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitInclusive<'a, P> {
        SplitInclusive(SplitInternal {
            start: 0,
            end: self.len(),
            matcher: pat.into_searcher(self),
            allow_trailing_empty: false,
            finished: false,
        })
    }

    /// En iterator over understrenge af den givne strengskive adskilt af tegn matchet med et mønster og givet i omvendt rækkefølge.
    ///
    /// [pattern] kan være en `&str`, [`char`], et stykke af [`char`] s eller en funktion eller lukning, der bestemmer, om et tegn matcher.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratoradfærd
    ///
    /// Den returnerede iterator kræver, at mønsteret understøtter en omvendt søgning, og det vil være en [`DoubleEndedIterator`], hvis en forward/reverse-søgning giver de samme elementer.
    ///
    ///
    /// Til iterering forfra kan [`split`]-metoden bruges.
    ///
    /// [`split`]: str::split
    ///
    /// # Examples
    ///
    /// Enkle mønstre:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplit(' ').collect();
    /// assert_eq!(v, ["lamb", "little", "a", "had", "Mary"]);
    ///
    /// let v: Vec<&str> = "".rsplit('X').collect();
    /// assert_eq!(v, [""]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplit('X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "", "lion"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplit("::").collect();
    /// assert_eq!(v, ["leopard", "tiger", "lion"]);
    /// ```
    ///
    /// Et mere komplekst mønster ved hjælp af en lukning:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplit(|c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "def", "abc"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit<'a, P>(&'a self, pat: P) -> RSplit<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplit(self.split(pat).0)
    }

    /// En iterator over understrenge af den givne strengskive adskilt af tegn matchet med et mønster.
    ///
    /// [pattern] kan være en `&str`, [`char`], et stykke af [`char`] s eller en funktion eller lukning, der bestemmer, om et tegn matcher.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Svarer til [`split`], bortset fra at den bageste delstreng springes over, hvis den er tom.
    ///
    /// [`split`]: str::split
    ///
    /// Denne metode kan bruges til strengdata, der er _terminated_, snarere end _separated_ med et mønster.
    ///
    /// # Iteratoradfærd
    ///
    /// Den returnerede iterator vil være en [`DoubleEndedIterator`], hvis mønsteret tillader en omvendt søgning, og forward/reverse-søgning giver de samme elementer.
    /// Dette gælder for f.eks. [`char`], men ikke for `&str`.
    ///
    /// Hvis mønsteret tillader en omvendt søgning, men dens resultater kan afvige fra en fremadgående søgning, kan [`rsplit_terminator`]-metoden bruges.
    ///
    /// [`rsplit_terminator`]: str::rsplit_terminator
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".split_terminator('.').collect();
    /// assert_eq!(v, ["A", "B"]);
    ///
    /// let v: Vec<&str> = "A..B..".split_terminator(".").collect();
    /// assert_eq!(v, ["A", "", "B", ""]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_terminator<'a, P: Pattern<'a>>(&'a self, pat: P) -> SplitTerminator<'a, P> {
        SplitTerminator(SplitInternal { allow_trailing_empty: false, ..self.split(pat).0 })
    }

    /// En iterator over `self`-understrenge, adskilt af tegn matchet med et mønster og vist i omvendt rækkefølge.
    ///
    /// [pattern] kan være en `&str`, [`char`], et stykke af [`char`] s eller en funktion eller lukning, der bestemmer, om et tegn matcher.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// Svarer til [`split`], bortset fra at den bageste delstreng springes over, hvis den er tom.
    ///
    /// [`split`]: str::split
    ///
    /// Denne metode kan bruges til strengdata, der er _terminated_, snarere end _separated_ med et mønster.
    ///
    /// # Iteratoradfærd
    ///
    /// Den returnerede iterator kræver, at mønsteret understøtter en omvendt søgning, og den bliver dobbelt afsluttet, hvis en forward/reverse-søgning giver de samme elementer.
    ///
    ///
    /// Til iterering forfra kan [`split_terminator`]-metoden bruges.
    ///
    /// [`split_terminator`]: str::split_terminator
    ///
    /// # Examples
    ///
    /// ```
    /// let v: Vec<&str> = "A.B.".rsplit_terminator('.').collect();
    /// assert_eq!(v, ["B", "A"]);
    ///
    /// let v: Vec<&str> = "A..B..".rsplit_terminator(".").collect();
    /// assert_eq!(v, ["", "B", "", "A"]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplit_terminator<'a, P>(&'a self, pat: P) -> RSplitTerminator<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitTerminator(self.split_terminator(pat).0)
    }

    /// En iterator over understrenge af det givne strengeskive, adskilt af et mønster, begrænset til at returnere højst `n`-emner.
    ///
    /// Hvis `n`-understrenge returneres, indeholder den sidste understreng (det n'te understreng) resten af strengen.
    ///
    /// [pattern] kan være en `&str`, [`char`], et stykke af [`char`] s eller en funktion eller lukning, der bestemmer, om et tegn matcher.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratoradfærd
    ///
    /// Den returnerede iterator bliver ikke dobbelt sluttet, fordi den ikke er effektiv at understøtte.
    ///
    /// Hvis mønsteret tillader en omvendt søgning, kan [`rsplitn`]-metoden bruges.
    ///
    /// [`rsplitn`]: str::rsplitn
    ///
    /// # Examples
    ///
    /// Enkle mønstre:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lambda".splitn(3, ' ').collect();
    /// assert_eq!(v, ["Mary", "had", "a little lambda"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".splitn(3, "X").collect();
    /// assert_eq!(v, ["lion", "", "tigerXleopard"]);
    ///
    /// let v: Vec<&str> = "abcXdef".splitn(1, 'X').collect();
    /// assert_eq!(v, ["abcXdef"]);
    ///
    /// let v: Vec<&str> = "".splitn(1, 'X').collect();
    /// assert_eq!(v, [""]);
    /// ```
    ///
    /// Et mere komplekst mønster ved hjælp af en lukning:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".splitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["abc", "defXghi"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<'a, P: Pattern<'a>>(&'a self, n: usize, pat: P) -> SplitN<'a, P> {
        SplitN(SplitNInternal { iter: self.split(pat).0, count: n })
    }

    /// En iterator over understrenge af denne strengskive, adskilt af et mønster, der starter fra slutningen af strengen, begrænset til at returnere højst `n`-emner.
    ///
    ///
    /// Hvis `n`-understrenge returneres, indeholder den sidste understreng (det n'te understreng) resten af strengen.
    ///
    /// [pattern] kan være en `&str`, [`char`], et stykke af [`char`] s eller en funktion eller lukning, der bestemmer, om et tegn matcher.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratoradfærd
    ///
    /// Den returnerede iterator bliver ikke dobbelt sluttet, fordi den ikke er effektiv at understøtte.
    ///
    /// Til opdeling forfra kan [`splitn`]-metoden bruges.
    ///
    /// [`splitn`]: str::splitn
    ///
    /// # Examples
    ///
    /// Enkle mønstre:
    ///
    /// ```
    /// let v: Vec<&str> = "Mary had a little lamb".rsplitn(3, ' ').collect();
    /// assert_eq!(v, ["lamb", "little", "Mary had a"]);
    ///
    /// let v: Vec<&str> = "lionXXtigerXleopard".rsplitn(3, 'X').collect();
    /// assert_eq!(v, ["leopard", "tiger", "lionX"]);
    ///
    /// let v: Vec<&str> = "lion::tiger::leopard".rsplitn(2, "::").collect();
    /// assert_eq!(v, ["leopard", "lion::tiger"]);
    /// ```
    ///
    /// Et mere komplekst mønster ved hjælp af en lukning:
    ///
    /// ```
    /// let v: Vec<&str> = "abc1defXghi".rsplitn(2, |c| c == '1' || c == 'X').collect();
    /// assert_eq!(v, ["ghi", "abc1def"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<'a, P>(&'a self, n: usize, pat: P) -> RSplitN<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RSplitN(self.splitn(n, pat).0)
    }

    /// Opdeler strengen ved den første forekomst af den angivne afgrænser og returnerer præfiks før afgrænser og suffiks efter afgrænser.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".split_once('='), None);
    /// assert_eq!("cfg=foo".split_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".split_once('='), Some(("cfg", "foo=bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn split_once<'a, P: Pattern<'a>>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)> {
        let (start, end) = delimiter.into_searcher(self).next_match()?;
        Some((&self[..start], &self[end..]))
    }

    /// Opdeler strengen i den sidste forekomst af den angivne afgrænser og returnerer præfiks før afgrænser og suffiks efter afgrænser.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("cfg".rsplit_once('='), None);
    /// assert_eq!("cfg=foo".rsplit_once('='), Some(("cfg", "foo")));
    /// assert_eq!("cfg=foo=bar".rsplit_once('='), Some(("cfg=foo", "bar")));
    /// ```
    #[stable(feature = "str_split_once", since = "1.52.0")]
    #[inline]
    pub fn rsplit_once<'a, P>(&'a self, delimiter: P) -> Option<(&'a str, &'a str)>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let (start, end) = delimiter.into_searcher(self).next_match_back()?;
        Some((&self[..start], &self[end..]))
    }

    /// En iterator over de usammenhængende matches af et mønster inden for den givne strengskive.
    ///
    /// [pattern] kan være en `&str`, [`char`], et stykke af [`char`] s eller en funktion eller lukning, der bestemmer, om et tegn matcher.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratoradfærd
    ///
    /// Den returnerede iterator vil være en [`DoubleEndedIterator`], hvis mønsteret tillader en omvendt søgning, og forward/reverse-søgning giver de samme elementer.
    /// Dette gælder for f.eks. [`char`], men ikke for `&str`.
    ///
    /// Hvis mønsteret tillader en omvendt søgning, men dens resultater kan afvige fra en fremadgående søgning, kan [`rmatches`]-metoden bruges.
    ///
    /// [`rmatches`]: str::matches
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".matches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".matches(char::is_numeric).collect();
    /// assert_eq!(v, ["1", "2", "3"]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> Matches<'a, P> {
        Matches(MatchesInternal(pat.into_searcher(self)))
    }

    /// En iterator over de usammenhængende kampe af et mønster i denne strengskive, givet i omvendt rækkefølge.
    ///
    /// [pattern] kan være en `&str`, [`char`], et stykke af [`char`] s eller en funktion eller lukning, der bestemmer, om et tegn matcher.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratoradfærd
    ///
    /// Den returnerede iterator kræver, at mønsteret understøtter en omvendt søgning, og det vil være en [`DoubleEndedIterator`], hvis en forward/reverse-søgning giver de samme elementer.
    ///
    ///
    /// Til iterering forfra kan [`matches`]-metoden bruges.
    ///
    /// [`matches`]: str::matches
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let v: Vec<&str> = "abcXXXabcYYYabc".rmatches("abc").collect();
    /// assert_eq!(v, ["abc", "abc", "abc"]);
    ///
    /// let v: Vec<&str> = "1abc2abc3".rmatches(char::is_numeric).collect();
    /// assert_eq!(v, ["3", "2", "1"]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "str_matches", since = "1.2.0")]
    #[inline]
    pub fn rmatches<'a, P>(&'a self, pat: P) -> RMatches<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatches(self.matches(pat).0)
    }

    /// En iterator over de usammenhængende matches af et mønster i denne strengskive samt det indeks, som kampen starter ved.
    ///
    /// For matches af `pat` inden for `self`, der overlapper hinanden, returneres kun de indekser, der svarer til den første match.
    ///
    /// [pattern] kan være en `&str`, [`char`], et stykke af [`char`] s eller en funktion eller lukning, der bestemmer, om et tegn matcher.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratoradfærd
    ///
    /// Den returnerede iterator vil være en [`DoubleEndedIterator`], hvis mønsteret tillader en omvendt søgning, og forward/reverse-søgning giver de samme elementer.
    /// Dette gælder for f.eks. [`char`], men ikke for `&str`.
    ///
    /// Hvis mønsteret tillader en omvendt søgning, men dens resultater kan afvige fra en fremadgående søgning, kan [`rmatch_indices`]-metoden bruges.
    ///
    /// [`rmatch_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".match_indices("abc").collect();
    /// assert_eq!(v, [(0, "abc"), (6, "abc"), (12, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".match_indices("abc").collect();
    /// assert_eq!(v, [(1, "abc"), (4, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".match_indices("aba").collect();
    /// assert_eq!(v, [(0, "aba")]); // kun den første `aba`
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn match_indices<'a, P: Pattern<'a>>(&'a self, pat: P) -> MatchIndices<'a, P> {
        MatchIndices(MatchIndicesInternal(pat.into_searcher(self)))
    }

    /// En iterator over de usammenhængende kampe i et mønster inden for `self`, givet i omvendt rækkefølge sammen med kampens indeks.
    ///
    /// For matches af `pat` inden for `self`, der overlapper hinanden, returneres kun de indekser, der svarer til den sidste match.
    ///
    /// [pattern] kan være en `&str`, [`char`], et stykke af [`char`] s eller en funktion eller lukning, der bestemmer, om et tegn matcher.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Iteratoradfærd
    ///
    /// Den returnerede iterator kræver, at mønsteret understøtter en omvendt søgning, og det vil være en [`DoubleEndedIterator`], hvis en forward/reverse-søgning giver de samme elementer.
    ///
    ///
    /// Til iterering forfra kan [`match_indices`]-metoden bruges.
    ///
    /// [`match_indices`]: str::match_indices
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let v: Vec<_> = "abcXXXabcYYYabc".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(12, "abc"), (6, "abc"), (0, "abc")]);
    ///
    /// let v: Vec<_> = "1abcabc2".rmatch_indices("abc").collect();
    /// assert_eq!(v, [(4, "abc"), (1, "abc")]);
    ///
    /// let v: Vec<_> = "ababa".rmatch_indices("aba").collect();
    /// assert_eq!(v, [(2, "aba")]); // kun den sidste `aba`
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "str_match_indices", since = "1.5.0")]
    #[inline]
    pub fn rmatch_indices<'a, P>(&'a self, pat: P) -> RMatchIndices<'a, P>
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        RMatchIndices(self.match_indices(pat).0)
    }

    /// Returnerer en strengskive med fjernende og mellemliggende mellemrum fjernet.
    ///
    /// 'Whitespace' er defineret i henhold til vilkårene for Unicode Derived Core Property `White_Space`.
    ///
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld", s.trim());
    /// ```
    #[inline]
    #[must_use = "this returns the trimmed string as a slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim(&self) -> &str {
        self.trim_matches(|c: char| c.is_whitespace())
    }

    /// Returnerer en strengskive med fjernende mellemrum fjernet.
    ///
    /// 'Whitespace' er defineret i henhold til vilkårene for Unicode Derived Core Property `White_Space`.
    ///
    /// # Tekstretning
    ///
    /// En streng er en række af bytes.
    /// `start` betyder i denne sammenhæng den første position for denne byte-streng;for et sprog fra venstre mod højre som engelsk eller russisk, vil dette være venstre side, og for højre mod venstre sprog som arabisk eller hebraisk vil dette være højre side.
    ///
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!("Hello\tworld\t", s.trim_start());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('E') == s.trim_start().chars().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ע') == s.trim_start().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start(&self) -> &str {
        self.trim_start_matches(|c: char| c.is_whitespace())
    }

    /// Returnerer en strengskive med fjernet efterfølgende mellemrum.
    ///
    /// 'Whitespace' er defineret i henhold til vilkårene for Unicode Derived Core Property `White_Space`.
    ///
    /// # Tekstretning
    ///
    /// En streng er en række af bytes.
    /// `end` betyder i denne sammenhæng den sidste position for denne byte-streng;for et sprog fra venstre mod højre som engelsk eller russisk vil dette være højre side, og for sprog fra højre mod venstre som arabisk eller hebraisk vil dette være venstre side.
    ///
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    /// assert_eq!(" Hello\tworld", s.trim_end());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English  ";
    /// assert!(Some('h') == s.trim_end().chars().rev().next());
    ///
    /// let s = "  עברית  ";
    /// assert!(Some('ת') == s.trim_end().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end(&self) -> &str {
        self.trim_end_matches(|c: char| c.is_whitespace())
    }

    /// Returnerer en strengskive med fjernende mellemrum fjernet.
    ///
    /// 'Whitespace' er defineret i henhold til vilkårene for Unicode Derived Core Property `White_Space`.
    ///
    /// # Tekstretning
    ///
    /// En streng er en række af bytes.
    /// 'Left' betyder i denne sammenhæng den første position for denne byte-streng;for et sprog som arabisk eller hebraisk, der er 'højre mod venstre' snarere end 'venstre mod højre', vil dette være _right_-siden, ikke den venstre.
    ///
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!("Hello\tworld\t", s.trim_left());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "  English";
    /// assert!(Some('E') == s.trim_left().chars().next());
    ///
    /// let s = "  עברית";
    /// assert!(Some('ע') == s.trim_left().chars().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start`",
        suggestion = "trim_start"
    )]
    pub fn trim_left(&self) -> &str {
        self.trim_start()
    }

    /// Returnerer en strengskive med fjernet efterfølgende mellemrum.
    ///
    /// 'Whitespace' er defineret i henhold til vilkårene for Unicode Derived Core Property `White_Space`.
    ///
    /// # Tekstretning
    ///
    /// En streng er en række af bytes.
    /// 'Right' betyder i denne sammenhæng den sidste position for denne byte-streng;for et sprog som arabisk eller hebraisk, der er 'højre mod venstre' snarere end 'venstre mod højre', vil dette være _left_-siden, ikke den højre.
    ///
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let s = " Hello\tworld\t";
    ///
    /// assert_eq!(" Hello\tworld", s.trim_right());
    /// ```
    ///
    /// Directionality:
    ///
    /// ```
    /// let s = "English  ";
    /// assert!(Some('h') == s.trim_right().chars().rev().next());
    ///
    /// let s = "עברית  ";
    /// assert!(Some('ת') == s.trim_right().chars().rev().next());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end`",
        suggestion = "trim_end"
    )]
    pub fn trim_right(&self) -> &str {
        self.trim_end()
    }

    /// Returnerer en strengskive med alle præfikser og suffikser, der matcher et mønster, der gentagne gange er fjernet.
    ///
    /// [pattern] kan være en [`char`], et udsnit af [`char`] s eller en funktion eller lukning, der bestemmer, om et tegn matcher.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// Enkle mønstre:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_matches('1'), "foo1bar");
    /// assert_eq!("123foo1bar123".trim_matches(char::is_numeric), "foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_matches(x), "foo1bar");
    /// ```
    ///
    /// Et mere komplekst mønster ved hjælp af en lukning:
    ///
    /// ```
    /// assert_eq!("1foo1barXX".trim_matches(|c| c == '1' || c == 'X'), "foo1bar");
    /// ```
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn trim_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: DoubleEndedSearcher<'a>>,
    {
        let mut i = 0;
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((a, b)) = matcher.next_reject() {
            i = a;
            j = b; // Husk tidligste kendte match, rette det nedenfor hvis
            // sidste kamp er anderledes
        }
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SIKKERHED: `Searcher` er kendt for at returnere gyldige indekser.
        unsafe { self.get_unchecked(i..j) }
    }

    /// Returnerer en strengskive med alle præfikser, der matcher et mønster, der gentagne gange er fjernet.
    ///
    /// [pattern] kan være en `&str`, [`char`], et stykke af [`char`] s eller en funktion eller lukning, der bestemmer, om et tegn matcher.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tekstretning
    ///
    /// En streng er en række af bytes.
    /// `start` betyder i denne sammenhæng den første position for denne byte-streng;for et sprog fra venstre mod højre som engelsk eller russisk, vil dette være venstre side, og for højre mod venstre sprog som arabisk eller hebraisk vil dette være højre side.
    ///
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_start_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_start_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_start_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_start_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        let mut i = self.len();
        let mut matcher = pat.into_searcher(self);
        if let Some((a, _)) = matcher.next_reject() {
            i = a;
        }
        // SIKKERHED: `Searcher` er kendt for at returnere gyldige indekser.
        unsafe { self.get_unchecked(i..self.len()) }
    }

    /// Returnerer en strengskive med præfikset fjernet.
    ///
    /// Hvis strengen starter med mønsteret `prefix`, returneres understreng efter præfikset, pakket ind i `Some`.
    /// I modsætning til `trim_start_matches` fjerner denne metode præfikset nøjagtigt en gang.
    ///
    /// Hvis strengen ikke starter med `prefix`, returneres `None`.
    ///
    /// [pattern] kan være en `&str`, [`char`], et stykke af [`char`] s eller en funktion eller lukning, der bestemmer, om et tegn matcher.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("foo:bar".strip_prefix("foo:"), Some("bar"));
    /// assert_eq!("foo:bar".strip_prefix("bar"), None);
    /// assert_eq!("foofoo".strip_prefix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_prefix<'a, P: Pattern<'a>>(&'a self, prefix: P) -> Option<&'a str> {
        prefix.strip_prefix_of(self)
    }

    /// Returnerer en strengskive med suffikset fjernet.
    ///
    /// Hvis strengen ender med mønsteret `suffix`, returneres understrengen før suffikset, pakket ind i `Some`.
    /// I modsætning til `trim_end_matches` fjerner denne metode suffikset nøjagtigt en gang.
    ///
    /// Hvis strengen ikke ender med `suffix`, returneres `None`.
    ///
    /// [pattern] kan være en `&str`, [`char`], et stykke af [`char`] s eller en funktion eller lukning, der bestemmer, om et tegn matcher.
    ///
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!("bar:foo".strip_suffix(":foo"), Some("bar"));
    /// assert_eq!("bar:foo".strip_suffix("bar"), None);
    /// assert_eq!("foofoo".strip_suffix("foo"), Some("foo"));
    /// ```
    #[must_use = "this returns the remaining substring as a new slice, \
                  without modifying the original"]
    #[stable(feature = "str_strip", since = "1.45.0")]
    pub fn strip_suffix<'a, P>(&'a self, suffix: P) -> Option<&'a str>
    where
        P: Pattern<'a>,
        <P as Pattern<'a>>::Searcher: ReverseSearcher<'a>,
    {
        suffix.strip_suffix_of(self)
    }

    /// Returnerer en strengskive med alle suffikser, der matcher et mønster, der gentagne gange er fjernet.
    ///
    /// [pattern] kan være en `&str`, [`char`], et stykke af [`char`] s eller en funktion eller lukning, der bestemmer, om et tegn matcher.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tekstretning
    ///
    /// En streng er en række af bytes.
    /// `end` betyder i denne sammenhæng den sidste position for denne byte-streng;for et sprog fra venstre mod højre som engelsk eller russisk vil dette være højre side, og for sprog fra højre mod venstre som arabisk eller hebraisk vil dette være venstre side.
    ///
    ///
    /// # Examples
    ///
    /// Enkle mønstre:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_end_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_end_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_end_matches(x), "12foo1bar");
    /// ```
    ///
    /// Et mere komplekst mønster ved hjælp af en lukning:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_end_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[must_use = "this returns the trimmed string as a new slice, \
                  without modifying the original"]
    #[stable(feature = "trim_direction", since = "1.30.0")]
    pub fn trim_end_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        let mut j = 0;
        let mut matcher = pat.into_searcher(self);
        if let Some((_, b)) = matcher.next_reject_back() {
            j = b;
        }
        // SIKKERHED: `Searcher` er kendt for at returnere gyldige indekser.
        unsafe { self.get_unchecked(0..j) }
    }

    /// Returnerer en strengskive med alle præfikser, der matcher et mønster, der gentagne gange er fjernet.
    ///
    /// [pattern] kan være en `&str`, [`char`], et stykke af [`char`] s eller en funktion eller lukning, der bestemmer, om et tegn matcher.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tekstretning
    ///
    /// En streng er en række af bytes.
    /// 'Left' betyder i denne sammenhæng den første position for denne byte-streng;for et sprog som arabisk eller hebraisk, der er 'højre mod venstre' snarere end 'venstre mod højre', vil dette være _right_-siden, ikke den venstre.
    ///
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_left_matches('1'), "foo1bar11");
    /// assert_eq!("123foo1bar123".trim_left_matches(char::is_numeric), "foo1bar123");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_left_matches(x), "foo1bar12");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_start_matches`",
        suggestion = "trim_start_matches"
    )]
    pub fn trim_left_matches<'a, P: Pattern<'a>>(&'a self, pat: P) -> &'a str {
        self.trim_start_matches(pat)
    }

    /// Returnerer en strengskive med alle suffikser, der matcher et mønster, der gentagne gange er fjernet.
    ///
    /// [pattern] kan være en `&str`, [`char`], et stykke af [`char`] s eller en funktion eller lukning, der bestemmer, om et tegn matcher.
    ///
    /// [`char`]: prim@char
    /// [pattern]: self::pattern
    ///
    /// # Tekstretning
    ///
    /// En streng er en række af bytes.
    /// 'Right' betyder i denne sammenhæng den sidste position for denne byte-streng;for et sprog som arabisk eller hebraisk, der er 'højre mod venstre' snarere end 'venstre mod højre', vil dette være _left_-siden, ikke den højre.
    ///
    ///
    /// # Examples
    ///
    /// Enkle mønstre:
    ///
    /// ```
    /// assert_eq!("11foo1bar11".trim_right_matches('1'), "11foo1bar");
    /// assert_eq!("123foo1bar123".trim_right_matches(char::is_numeric), "123foo1bar");
    ///
    /// let x: &[_] = &['1', '2'];
    /// assert_eq!("12foo1bar12".trim_right_matches(x), "12foo1bar");
    /// ```
    ///
    /// Et mere komplekst mønster ved hjælp af en lukning:
    ///
    /// ```
    /// assert_eq!("1fooX".trim_right_matches(|c| c == '1' || c == 'X'), "1foo");
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(
        since = "1.33.0",
        reason = "superseded by `trim_end_matches`",
        suggestion = "trim_end_matches"
    )]
    pub fn trim_right_matches<'a, P>(&'a self, pat: P) -> &'a str
    where
        P: Pattern<'a, Searcher: ReverseSearcher<'a>>,
    {
        self.trim_end_matches(pat)
    }

    /// Parser denne strengskive i en anden type.
    ///
    /// Fordi `parse` er så generel, kan det forårsage problemer med typeforståelse.
    /// Som sådan er `parse` en af de få gange, du ser syntaksen, der er kærligt kendt som 'turbofish': `::<>`.
    ///
    /// Dette hjælper slutningsalgoritmen med at forstå specifikt, hvilken type du prøver at analysere.
    ///
    /// `parse` kan analysere i enhver type, der implementerer [`FromStr`] trait.
    ///

    /// # Errors
    ///
    /// Returnerer [`Err`], hvis det ikke er muligt at analysere denne strengskive i den ønskede type.
    ///
    ///
    /// [`Err`]: FromStr::Err
    ///
    /// # Examples
    ///
    /// Grundlæggende brug
    ///
    /// ```
    /// let four: u32 = "4".parse().unwrap();
    ///
    /// assert_eq!(4, four);
    /// ```
    ///
    /// Brug af 'turbofish' i stedet for at kommentere `four`:
    ///
    /// ```
    /// let four = "4".parse::<u32>();
    ///
    /// assert_eq!(Ok(4), four);
    /// ```
    ///
    /// Mangler at parse:
    ///
    /// ```
    /// let nope = "j".parse::<u32>();
    ///
    /// assert!(nope.is_err());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn parse<F: FromStr>(&self) -> Result<F, F::Err> {
        FromStr::from_str(self)
    }

    /// Kontrollerer, om alle tegn i denne streng er inden for ASCII-området.
    ///
    /// # Examples
    ///
    /// ```
    /// let ascii = "hello!\n";
    /// let non_ascii = "Grüße, Jürgen ❤";
    ///
    /// assert!(ascii.is_ascii());
    /// assert!(!non_ascii.is_ascii());
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        // Vi kan behandle hver byte som tegn her: alle multibyttegn starter med en byte, der ikke er inden for ascii-området, så vi stopper der allerede.
        //
        //
        self.as_bytes().is_ascii()
    }

    /// Kontrollerer, at to strenge er et ASCII-ufølsomt match.
    ///
    /// Samme som `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, men uden at allokere og kopiere midlertidige.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert!("Ferris".eq_ignore_ascii_case("FERRIS"));
    /// assert!("Ferrös".eq_ignore_ascii_case("FERRöS"));
    /// assert!(!"Ferrös".eq_ignore_ascii_case("FERRÖS"));
    /// ```
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &str) -> bool {
        self.as_bytes().eq_ignore_ascii_case(other.as_bytes())
    }

    /// Konverterer denne streng til dens ASCII-store bogstavsækvivalenter på stedet.
    ///
    /// ASCII-bogstaver 'a' til 'z' er kortlagt til 'A' til 'Z', men ikke-ASCII-bogstaver er uændrede.
    ///
    /// Brug [`to_ascii_uppercase()`] for at returnere en ny opskrevet værdi uden at ændre den eksisterende.
    ///
    ///
    /// [`to_ascii_uppercase()`]: #method.to_ascii_uppercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("Grüße, Jürgen ❤");
    ///
    /// s.make_ascii_uppercase();
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        // SIKKERHED: sikkert, fordi vi transmitterer to typer med samme layout.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_uppercase()
    }

    /// Konverterer denne streng til dets ASCII-småbogstavsækvivalent på stedet.
    ///
    /// ASCII-bogstaver 'A' til 'Z' kortlægges til 'a' til 'z', men ikke-ASCII-bogstaver er uændrede.
    ///
    /// Brug [`to_ascii_lowercase()`] for at returnere en ny værdi med lavere værdi uden at ændre den eksisterende.
    ///
    ///
    /// [`to_ascii_lowercase()`]: #method.to_ascii_lowercase
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("GRÜßE, JÜRGEN ❤");
    ///
    /// s.make_ascii_lowercase();
    ///
    /// assert_eq!("grÜße, jÜrgen ❤", s);
    /// ```
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        // SIKKERHED: sikkert, fordi vi transmitterer to typer med samme layout.
        let me = unsafe { self.as_bytes_mut() };
        me.make_ascii_lowercase()
    }

    /// Returner en iterator, der undslipper hver char i `self` med [`char::escape_debug`].
    ///
    ///
    /// Note: kun udvidede grafemkodepunkter, der begynder strengen, undslippes.
    ///
    /// # Examples
    ///
    /// Som iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_debug() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Brug af `println!` direkte:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_debug());
    /// ```
    ///
    /// Begge svarer til:
    ///
    /// ```
    /// println!("❤\\n!");
    /// ```
    ///
    /// Brug af `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_debug().to_string(), "❤\\n!");
    /// ```
    ///
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_debug(&self) -> EscapeDebug<'_> {
        let mut chars = self.chars();
        EscapeDebug {
            inner: chars
                .next()
                .map(|first| first.escape_debug_ext(true))
                .into_iter()
                .flatten()
                .chain(chars.flat_map(CharEscapeDebugContinue)),
        }
    }

    /// Returner en iterator, der undslipper hver char i `self` med [`char::escape_default`].
    ///
    ///
    /// # Examples
    ///
    /// Som iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_default() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Brug af `println!` direkte:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_default());
    /// ```
    ///
    /// Begge svarer til:
    ///
    /// ```
    /// println!("\\u{{2764}}\\n!");
    /// ```
    ///
    /// Brug af `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_default().to_string(), "\\u{2764}\\n!");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_default(&self) -> EscapeDefault<'_> {
        EscapeDefault { inner: self.chars().flat_map(CharEscapeDefault) }
    }

    /// Returner en iterator, der undslipper hver char i `self` med [`char::escape_unicode`].
    ///
    ///
    /// # Examples
    ///
    /// Som iterator:
    ///
    /// ```
    /// for c in "❤\n!".escape_unicode() {
    ///     print!("{}", c);
    /// }
    /// println!();
    /// ```
    ///
    /// Brug af `println!` direkte:
    ///
    /// ```
    /// println!("{}", "❤\n!".escape_unicode());
    /// ```
    ///
    /// Begge svarer til:
    ///
    /// ```
    /// println!("\\u{{2764}}\\u{{a}}\\u{{21}}");
    /// ```
    ///
    /// Brug af `to_string`:
    ///
    /// ```
    /// assert_eq!("❤\n!".escape_unicode().to_string(), "\\u{2764}\\u{a}\\u{21}");
    /// ```
    #[stable(feature = "str_escape", since = "1.34.0")]
    pub fn escape_unicode(&self) -> EscapeUnicode<'_> {
        EscapeUnicode { inner: self.chars().flat_map(CharEscapeUnicode) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for str {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for &str {
    /// Opretter en tom str
    #[inline]
    fn default() -> Self {
        ""
    }
}

#[stable(feature = "default_mut_str", since = "1.28.0")]
impl Default for &mut str {
    /// Opretter en tom, ændret str
    #[inline]
    fn default() -> Self {
        // SIKKERHED: Den tomme streng er gyldig UTF-8.
        unsafe { from_utf8_unchecked_mut(&mut []) }
    }
}

impl_fn_for_zst! {
    /// En navngivelig, klonbar fn-type
    #[derive(Clone)]
    struct LinesAnyMap impl<'a> Fn = |line: &'a str| -> &'a str {
        let l = line.len();
        if l > 0 && line.as_bytes()[l - 1] == b'\r' { &line[0 .. l - 1] }
        else { line }
    };

    #[derive(Clone)]
    struct CharEscapeDebugContinue impl Fn = |c: char| -> char::EscapeDebug {
        c.escape_debug_ext(false)
    };

    #[derive(Clone)]
    struct CharEscapeUnicode impl Fn = |c: char| -> char::EscapeUnicode {
        c.escape_unicode()
    };
    #[derive(Clone)]
    struct CharEscapeDefault impl Fn = |c: char| -> char::EscapeDefault {
        c.escape_default()
    };

    #[derive(Clone)]
    struct IsWhitespace impl Fn = |c: char| -> bool {
        c.is_whitespace()
    };

    #[derive(Clone)]
    struct IsAsciiWhitespace impl Fn = |byte: &u8| -> bool {
        byte.is_ascii_whitespace()
    };

    #[derive(Clone)]
    struct IsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b str| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct BytesIsNotEmpty impl<'a, 'b> Fn = |s: &'a &'b [u8]| -> bool {
        !s.is_empty()
    };

    #[derive(Clone)]
    struct UnsafeBytesToStr impl<'a> Fn = |bytes: &'a [u8]| -> &'a str {
        // SIKKERHED: ikke sikkert
        unsafe { from_utf8_unchecked(bytes) }
    };
}