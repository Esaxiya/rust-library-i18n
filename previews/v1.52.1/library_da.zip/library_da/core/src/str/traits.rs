//! Trait implementeringer til `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Implementerer bestilling af strenge.
///
/// Strenge ordnes [lexicographically](Ord#lexicographical-comparison) efter deres byteværdier.
/// Dette bestiller Unicode-kodepunkter baseret på deres positioner i kodekortene.
/// Dette er ikke nødvendigvis det samme som "alphabetical"-ordren, som varierer efter sprog og landestandard.
/// Sortering af strenge i henhold til kulturelt accepterede standarder kræver landespecifikke data, der ligger uden for anvendelsesområdet for `str`-typen.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Implementerer sammenligningsoperationer på strenge.
///
/// Strenge sammenlignes [lexicographically](Ord#lexicographical-comparison) med deres byteværdier.
/// Dette sammenligner Unicode-kodepunkter baseret på deres positioner i kodekortene.
/// Dette er ikke nødvendigvis det samme som "alphabetical"-ordren, som varierer efter sprog og landestandard.
/// Sammenligning af strenge i henhold til kulturelt accepterede standarder kræver landespecifikke data, der er uden for anvendelsesområdet for `str`-typen.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Implementerer substringskæring med syntaks `&self[..]` eller `&mut self[..]`.
///
/// Returnerer et udsnit af hele strengen, dvs. returnerer `&self` eller `&mut self`.Svarer til `&selv [0 ..
/// len] `eller`&mut selv [0 ..
/// len]`.
/// I modsætning til andre indekseringsoperationer kan dette aldrig panic.
///
/// Denne handling er *O*(1).
///
/// Før 1.20.0 blev disse indekseringsoperationer stadig understøttet af direkte implementering af `Index` og `IndexMut`.
///
/// Svarer til `&self[0 .. len]` eller `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Implementerer substringskæring med syntaks `&self[begin .. end]` eller `&mut self[begin .. end]`.
///
/// Returnerer et stykke af den givne streng fra byteområdet [`start`, `end`).
///
/// Denne handling er *O*(1).
///
/// Før 1.20.0 blev disse indekseringsoperationer stadig understøttet af direkte implementering af `Index` og `IndexMut`.
///
/// # Panics
///
/// Panics hvis `begin` eller `end` ikke peger på startbydeforskydningen af et tegn (som defineret af `is_char_boundary`), hvis `begin > end`, eller hvis `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // disse vil panic:
/// // byte 2 ligger inden for `ö`:
/// // &s [2 ..3];
///
/// // byte 8 ligger inden for `老`&s [1 ..
/// // 8];
///
/// // byte 100 er uden for strengen&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SIKKERHED: kontrollerede netop, at `start` og `end` er ved en grænserør,
            // og vi sender en sikker reference, så returværdien vil også være en.
            // Vi tjekkede også char-grænser, så dette er gyldigt UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SIKKERHED: kontrollerede lige, at `start` og `end` er ved en grænser for rødt.
            // Vi ved, at markøren er unik, fordi vi fik den fra `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SIKKERHED: den, der ringer op, garanterer, at `self` er inden for grænserne på `slice`
        // der opfylder alle betingelserne for `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SIKKERHED: se kommentarer til `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary kontrollerer at indekset er i [0, .len()] kan ikke genbruge `get` som ovenfor på grund af NLL-problemer
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SIKKERHED: kontrollerede netop, at `start` og `end` er ved en grænserør,
            // og vi sender en sikker reference, så returværdien vil også være en.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Implementerer substringskæring med syntaks `&self[.. end]` eller `&mut self[.. end]`.
///
/// Returnerer et udsnit af den givne streng fra byteområdet [`0`, `end`).
/// Svarer til `&self[0 .. end]` eller `&mut self[0 .. end]`.
///
/// Denne handling er *O*(1).
///
/// Før 1.20.0 blev disse indekseringsoperationer stadig understøttet af direkte implementering af `Index` og `IndexMut`.
///
/// # Panics
///
/// Panics hvis `end` ikke peger på startbyteforskydningen af et tegn (som defineret af `is_char_boundary`), eller hvis `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SIKKERHED: kontrollerede netop, at `end` er på en grænseværdi,
            // og vi sender en sikker reference, så returværdien vil også være en.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // SIKKERHED: kontrollerede netop, at `end` er på en grænseværdi,
            // og vi sender en sikker reference, så returværdien vil også være en.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // SIKKERHED: kontrollerede netop, at `end` er på en grænseværdi,
            // og vi sender en sikker reference, så returværdien vil også være en.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Implementerer substringskæring med syntaks `&self[begin ..]` eller `&mut self[begin ..]`.
///
/// Returnerer et stykke af den givne streng fra byteområdet [`start`, `len`).Svarer til `&selv [begynde ..
/// len] `eller`&mut selv [begynde ..
/// len]`.
///
/// Denne handling er *O*(1).
///
/// Før 1.20.0 blev disse indekseringsoperationer stadig understøttet af direkte implementering af `Index` og `IndexMut`.
///
/// # Panics
///
/// Panics hvis `begin` ikke peger på startbyteforskydningen af et tegn (som defineret af `is_char_boundary`), eller hvis `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SIKKERHED: kontrollerede netop, at `start` er på en grænseværdi,
            // og vi sender en sikker reference, så returværdien vil også være en.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // SIKKERHED: kontrollerede netop, at `start` er på en grænseværdi,
            // og vi sender en sikker reference, så returværdien vil også være en.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // SIKKERHED: den, der ringer op, garanterer, at `self` er inden for grænserne på `slice`
        // der opfylder alle betingelserne for `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // SIKKERHED: identisk med `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // SIKKERHED: kontrollerede netop, at `start` er på en grænseværdi,
            // og vi sender en sikker reference, så returværdien vil også være en.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Implementerer substringskæring med syntaks `&self[begin ..= end]` eller `&mut self[begin ..= end]`.
///
/// Returnerer et udsnit af den givne streng fra byteområdet [`begin`, `end`].Svarer til `&self [begin .. end + 1]` eller `&mut self[begin .. end + 1]`, undtagen hvis `end` har den maksimale værdi for `usize`.
///
/// Denne handling er *O*(1).
///
/// # Panics
///
/// Panics hvis `begin` ikke peger på starttegnets forskydning af et tegn (som defineret af `is_char_boundary`), hvis `end` ikke peger på sluttegnets forskydning af et tegn (`end + 1` er enten en startbyteforskydning eller lig med `len`), hvis `begin > end` eller hvis `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Implementerer substringskæring med syntaks `&self[..= end]` eller `&mut self[..= end]`.
///
/// Returnerer et stykke af den givne streng fra byteområdet [0, `end`].
/// Svarer til `&self [0 .. end + 1]`, undtagen hvis `end` har den maksimale værdi for `usize`.
///
/// Denne handling er *O*(1).
///
/// # Panics
///
/// Panics hvis `end` ikke peger på slutningen af byte-forskydningen af et tegn (`end + 1` er enten en start-byte-forskydning som defineret af `is_char_boundary` eller lig med `len`) eller hvis `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Parse en værdi fra en streng
///
/// `FromStr`s [`from_str`]-metode bruges ofte implicit gennem [[str`] s [`parse`]-metode.
/// Se [``parse``s dokumentation for eksempler.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` har ikke en livstidsparameter, og så kan du kun analysere typer, der ikke selv indeholder en levetidsparameter.
///
/// Med andre ord kan du analysere en `i32` med `FromStr`, men ikke en `&i32`.
/// Du kan analysere en struktur, der indeholder en `i32`, men ikke en, der indeholder en `&i32`.
///
/// # Examples
///
/// Grundlæggende implementering af `FromStr` på et eksempel på en `Point`-type:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Den tilknyttede fejl, som kan returneres fra parsing.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Parser en streng `s` for at returnere en værdi af denne type.
    ///
    /// Hvis parsing lykkes, skal du returnere værdien inde i [`Ok`], ellers returnerer en fejl, der er specifik for den indvendige [`Err`], når strengen er uformateret.
    /// Fejltypen er specifik for implementering af trait.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug med [`i32`], en type der implementerer `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Parse en `bool` fra en streng.
    ///
    /// Giver en `Result<bool, ParseBoolError>`, fordi `s` måske måske ikke kan parses.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Bemærk, i mange tilfælde er `.parse()`-metoden på `str` mere korrekt.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}