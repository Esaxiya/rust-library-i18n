//! Strengmønster API.
//!
//! Mønster API giver en generisk mekanisme til brug af forskellige mønstertyper, når du søger gennem en streng.
//!
//! For flere detaljer, se traits [`Pattern`], [`Searcher`], [`ReverseSearcher`] og [`DoubleEndedSearcher`].
//!
//! Selvom denne API er ustabil, eksponeres den via stabile API'er på [`str`]-typen.
//!
//! # Examples
//!
//! [`Pattern`] er [implemented][pattern-impls] i den stabile API til [`&str`][`str`], [`char`], udsnit af [`char`] og funktioner og lukninger, der implementerer `FnMut(char) -> bool`.
//!
//!
//! ```
//! let s = "Can you find a needle in a haystack?";
//!
//! // &str pattern
//! assert_eq!(s.find("you"), Some(4));
//! // char mønster
//! assert_eq!(s.find('n'), Some(2));
//! // skive af tegn mønster
//! assert_eq!(s.find(&['a', 'e', 'i', 'o', 'u'][..]), Some(1));
//! // lukningsmønster
//! assert_eq!(s.find(|c: char| c.is_ascii_punctuation()), Some(35));
//! ```
//!
//! [pattern-impls]: Pattern#implementors
//!
//!
//!
//!

#![unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]

use crate::cmp;
use crate::fmt;
use crate::slice::memchr;

// Pattern

/// Et strengemønster.
///
/// En `Pattern<'a>` udtrykker, at implementeringstypen kan bruges som et strengmønster til søgning i en [`&'a str`][str].
///
/// For eksempel er både `'a'` og `"aa"` mønstre, der matcher ved indeks `1` i strengen `"baaaab"`.
///
/// trait fungerer selv som en bygherre for en tilhørende [`Searcher`]-type, der gør det egentlige arbejde med at finde forekomster af mønsteret i en streng.
///
///
/// Afhængigt af mønstertypen kan opførsel af metoder som [`str::find`] og [`str::contains`] ændre sig.
/// Tabellen nedenfor beskriver nogle af disse adfærd.
///
/// | Pattern type             | Match condition                           |
/// |--------------------------|-------------------------------------------|
/// | `&str`                   | is substring                              |
/// | `char`                   | is contained in string                    |
/// | `&[char]`                | any char in slice is contained in string  |
/// | `F: FnMut(char) -> bool` | `F` returns `true` for a char in string   |
/// | `&&str`                  | is substring                              |
/// | `&String`                | is substring                              |
///
/// # Examples
///
/// ```
/// // &str
/// assert_eq!("abaaa".find("ba"), Some(1));
/// assert_eq!("abaaa".find("bac"), None);
///
/// // char
/// assert_eq!("abaaa".find('a'), Some(0));
/// assert_eq!("abaaa".find('b'), Some(1));
/// assert_eq!("abaaa".find('c'), None);
///
/// // &[char]
/// assert_eq!("ab".find(&['b', 'a'][..]), Some(0));
/// assert_eq!("abaaa".find(&['a', 'z'][..]), Some(0));
/// assert_eq!("abaaa".find(&['c', 'd'][..]), None);
///
/// // FnMut(char) -> bool
/// assert_eq!("abcdef_z".find(|ch| ch > 'd' && ch < 'y'), Some(4));
/// assert_eq!("abcddd_z".find(|ch| ch > 'd' && ch < 'y'), None);
/// ```
///
///
///
///
pub trait Pattern<'a>: Sized {
    /// Associeret søger efter dette mønster
    type Searcher: Searcher<'a>;

    /// Konstruerer den tilknyttede søger fra `self` og `haystack` til at søge i.
    ///
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher;

    /// Kontrollerer, om mønsteret matcher et vilkårligt sted i høstakken
    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self.into_searcher(haystack).next_match().is_some()
    }

    /// Kontrollerer, om mønsteret matcher foran høstakken
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        matches!(self.into_searcher(haystack).next(), SearchStep::Match(0, _))
    }

    /// Kontrollerer, om mønsteret matcher bag på høstakken
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        matches!(self.into_searcher(haystack).next_back(), SearchStep::Match(_, j) if haystack.len() == j)
    }

    /// Fjerner mønsteret fra høstakken, hvis det passer.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if let SearchStep::Match(start, len) = self.into_searcher(haystack).next() {
            debug_assert_eq!(
                start, 0,
                "The first search step from Searcher \
                 must include the first character"
            );
            // SIKKERHED: `Searcher` er kendt for at returnere gyldige indekser.
            unsafe { Some(haystack.get_unchecked(len..)) }
        } else {
            None
        }
    }

    /// Fjerner mønsteret fra bagsiden af høstakken, hvis det passer.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        if let SearchStep::Match(start, end) = self.into_searcher(haystack).next_back() {
            debug_assert_eq!(
                end,
                haystack.len(),
                "The first search step from ReverseSearcher \
                 must include the last character"
            );
            // SIKKERHED: `Searcher` er kendt for at returnere gyldige indekser.
            unsafe { Some(haystack.get_unchecked(..start)) }
        } else {
            None
        }
    }
}

// Searcher

/// Resultat af opkald til [`Searcher::next()`] eller [`ReverseSearcher::next_back()`].
#[derive(Copy, Clone, Eq, PartialEq, Debug)]
pub enum SearchStep {
    /// Udtrykker, at der er fundet et match af mønsteret på `haystack[a..b]`.
    ///
    Match(usize, usize),
    /// Udtrykker, at `haystack[a..b]` er blevet afvist som en mulig matchning af mønsteret.
    ///
    /// Bemærk, at der kan være mere end en `Reject` mellem to `Match`'er, der er ikke noget krav om, at de skal kombineres til en.
    ///
    ///
    Reject(usize, usize),
    /// Udtrykker, at hver byte af høstakken er blevet besøgt, hvilket afslutter iterationen.
    ///
    Done,
}

/// En søger efter et strengemønster.
///
/// Denne trait giver metoder til søgning efter ikke-overlappende matches af et mønster, der starter fra den forreste (left) af en streng.
///
/// Det vil blive implementeret af tilknyttede `Searcher`-typer af [`Pattern`] trait.
///
/// trait er markeret som usikker, fordi de indekser, der returneres ved [`next()`][Searcher::next]-metoderne, skal ligge på gyldige utf8-grænser i høstakken.
/// Dette gør det muligt for forbrugere af denne trait at skære høstakken uden yderligere runtime-kontrol.
///
///
///
///
pub unsafe trait Searcher<'a> {
    /// Getter for den underliggende streng, der skal søges i
    ///
    /// Returnerer altid den samme [`&str`][str].
    fn haystack(&self) -> &'a str;

    /// Udfører det næste søgetrin startende forfra.
    ///
    /// - Returnerer [`Match(a, b)`][SearchStep::Match], hvis `haystack[a..b]` matcher mønsteret.
    /// - Returnerer [`Reject(a, b)`][SearchStep::Reject], hvis `haystack[a..b]` ikke kan matche mønsteret, selv delvis.
    /// - Returnerer [`Done`][SearchStep::Done], hvis hver byte i høstakken er blevet besøgt.
    ///
    /// Strømmen af [`Match`][SearchStep::Match]-og [`Reject`][SearchStep::Reject]-værdier op til en [`Done`][SearchStep::Done] vil indeholde indeksområder, der er tilstødende, ikke-overlappende, der dækker hele høstakken og lægger på utf8-grænser.
    ///
    ///
    /// Et [`Match`][SearchStep::Match]-resultat skal indeholde hele det matchede mønster, men [`Reject`][SearchStep::Reject]-resultater kan opdeles i vilkårlige mange tilstødende fragmenter.Begge områder kan have nul længde.
    ///
    /// Som et eksempel kan mønsteret `"aaa"` og høstakken `"cbaaaaab"` muligvis producere strømmen
    /// `[Reject(0, 1), Reject(1, 2), Match(2, 5), Reject(5, 8)]`
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next(&mut self) -> SearchStep;

    /// Finder det næste [`Match`][SearchStep::Match]-resultat.Se [`next()`][Searcher::next].
    ///
    /// I modsætning til [`next()`][Searcher::next] er der ingen garanti for, at de returnerede intervaller for dette og [`next_reject`][Searcher::next_reject] vil overlappe hinanden.
    /// Dette returnerer `(start_match, end_match)`, hvor start_match er indekset for hvor kampen begynder, og end_match er indekset efter kampens afslutning.
    ///
    ///
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Finder det næste [`Reject`][SearchStep::Reject]-resultat.Se [`next()`][Searcher::next] og [`next_match()`][Searcher::next_match].
    ///
    /// I modsætning til [`next()`][Searcher::next] er der ingen garanti for, at de returnerede intervaller for dette og [`next_match`][Searcher::next_match] vil overlappe hinanden.
    ///
    ///
    #[inline]
    fn next_reject(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// En omvendt søgning efter et strengemønster.
///
/// Denne trait giver metoder til at søge efter ikke-overlappende matches af et mønster, der starter fra bagsiden (right) af en streng.
///
/// Det vil blive implementeret af tilknyttede [`Searcher`]-typer af [`Pattern`] trait, hvis mønsteret understøtter søgning efter det bagfra.
///
///
/// Indeksområdet, der returneres af denne trait, er ikke påkrævet for nøjagtigt at matche dem for fremad søgning i omvendt retning.
///
/// Af grunden til, at denne trait er markeret som usikker, se dem forælder trait [`Searcher`].
///
///
///
///
pub unsafe trait ReverseSearcher<'a>: Searcher<'a> {
    /// Udfører det næste søgetrin startende bagfra.
    ///
    /// - Returnerer [`Match(a, b)`][SearchStep::Match], hvis `haystack[a..b]` matcher mønsteret.
    /// - Returnerer [`Reject(a, b)`][SearchStep::Reject], hvis `haystack[a..b]` ikke delvis kan matche mønsteret.
    /// - Returnerer [`Done`][SearchStep::Done], hvis hver byte i høstakken er blevet besøgt
    ///
    /// Strømmen af [`Match`][SearchStep::Match]-og [`Reject`][SearchStep::Reject]-værdier op til en [`Done`][SearchStep::Done] vil indeholde indeksområder, der er tilstødende, ikke-overlappende, der dækker hele høstakken og lægger på utf8-grænser.
    ///
    ///
    /// Et [`Match`][SearchStep::Match]-resultat skal indeholde hele det matchede mønster, men [`Reject`][SearchStep::Reject]-resultater kan opdeles i vilkårlige mange tilstødende fragmenter.Begge områder kan have nul længde.
    ///
    /// Som et eksempel kan mønsteret `"aaa"` og høstakken `"cbaaaaab"` muligvis producere strømmen `[Reject(7, 8), Match(4, 7), Reject(1, 4), Reject(0, 1)]`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn next_back(&mut self) -> SearchStep;

    /// Finder det næste [`Match`][SearchStep::Match]-resultat.
    /// Se [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Match(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }

    /// Finder det næste [`Reject`][SearchStep::Reject]-resultat.
    /// Se [`next_back()`][ReverseSearcher::next_back].
    #[inline]
    fn next_reject_back(&mut self) -> Option<(usize, usize)> {
        loop {
            match self.next_back() {
                SearchStep::Reject(a, b) => return Some((a, b)),
                SearchStep::Done => return None,
                _ => continue,
            }
        }
    }
}

/// En markør trait til at udtrykke, at en [`ReverseSearcher`] kan bruges til en [`DoubleEndedIterator`]-implementering.
///
/// Til dette skal impl. Af [`Searcher`] og [`ReverseSearcher`] følge disse betingelser:
///
/// - Alle resultater af `next()` skal være identiske med resultaterne af `next_back()` i omvendt rækkefølge.
/// - `next()` og `next_back()` skal opføre sig som de to ender af en række værdier, det vil sige at de ikke kan "walk past each other".
///
/// # Examples
///
/// `char::Searcher` er en `DoubleEndedSearcher`, fordi søgning efter en [`char`] kun kræver at se på en ad gangen, som opfører sig det samme fra begge ender.
///
/// `(&str)::Searcher` er ikke en `DoubleEndedSearcher`, fordi mønsteret `"aa"` i høstakken `"aaa"` matcher som enten `"[aa]a"` eller `"a[aa]"`, afhængigt af hvilken side det søges efter.
///
///
///
///
///
///
///
///
///
pub trait DoubleEndedSearcher<'a>: ReverseSearcher<'a> {}

/////////////////////////////////////////////////////////////////////////////
// Impl for char
/////////////////////////////////////////////////////////////////////////////

/// Tilknyttet type til `<char as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSearcher<'a> {
    haystack: &'a str,
    // sikkerhedsvariant: `finger`/`finger_back` skal være et gyldigt utf8-byteindeks på `haystack`. Denne invariant kan brydes *inden for* next_match og next_match_back, men de skal gå ud med fingrene på gyldige kodepunktsgrænser.
    //
    //
    /// `finger` er det aktuelle byteindeks for den fremadrettede søgning.
    /// Forestil dig, at den eksisterer før byten ved dens indeks, dvs.
    /// `haystack[finger]` er den første byte af det udsnit, vi skal inspicere under fremadgående søgning
    ///
    finger: usize,
    /// `finger_back` er det aktuelle byteindeks for den omvendte søgning.
    /// Forestil dig, at den eksisterer efter byten ved dens indeks, dvs.
    /// høstak [finger_back, 1] er den sidste byte af det udsnit, vi skal inspicere under fremadgående søgning (og dermed den første byte, der skal inspiceres, når vi ringer til next_back()).
    ///
    finger_back: usize,
    /// Karakteren der søges efter
    needle: char,

    // sikkerhedsvariant: `utf8_size` skal være mindre end 5
    /// Antallet af byte `needle` optager, når det er kodet i utf8.
    utf8_size: usize,
    /// En utf8-kodet kopi af `needle`
    utf8_encoded: [u8; 4],
}

unsafe impl<'a> Searcher<'a> for CharSearcher<'a> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }
    #[inline]
    fn next(&mut self) -> SearchStep {
        let old_finger = self.finger;
        // SIKKERHED: 1-4 garanterer sikkerheden for `get_unchecked`
        // 1. `self.finger` og `self.finger_back` holdes på unicode-grænser (dette er uforanderligt)
        // 2. `self.finger >= 0` da det starter ved 0 og kun stiger
        // 3. `self.finger < self.finger_back` fordi ellers vil char `iter` returnere `SearchStep::Done`
        // 4.
        // `self.finger` kommer inden afslutningen af høstakken, fordi `self.finger_back` starter i slutningen og kun falder
        //
        //
        let slice = unsafe { self.haystack.get_unchecked(old_finger..self.finger_back) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next() {
            // tilføj byteforskydning af det aktuelle tegn uden genkodning som utf-8
            //
            self.finger += old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(old_finger, self.finger)
            } else {
                SearchStep::Reject(old_finger, self.finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        loop {
            // få høstakken efter den sidste karakter fundet
            let bytes = self.haystack.as_bytes().get(self.finger..self.finger_back)?;
            // den sidste byte af utf8-kodet nål SIKKERHED: vi har en invariant, der `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memchr(last_byte, bytes) {
                // Den nye finger er indekset over den byte, vi fandt, plus en, da vi memchr'd for den sidste byte af tegnet.
                //
                // Bemærk, at dette ikke altid giver os en finger på en UTF8-grænse.
                // Hvis vi *ikke* fandt vores karakter, kan vi have indekseret til den ikke-sidste byte af et 3-byte-eller 4-byte-tegn.
                // Vi kan ikke bare springe til den næste gyldige startbyte, fordi et tegn som ꁁ (U + A041 YI SYLLABLE PA), utf-8 `EA 81 81` får os til altid at finde den anden byte, når vi søger efter den tredje.
                //
                //
                // Dette er dog helt okay.
                // Mens vi har invarianten, at self.finger er på en UTF8-grænse, er denne invariant ikke påberåbt inden for denne metode (den er afhængig af i CharSearcher::next()).
                //
                // Vi forlader kun denne metode, når vi når slutningen af strengen, eller hvis vi finder noget.Når vi finder noget, sættes `finger` til en UTF8-grænse.
                //
                //
                //
                //
                //
                //
                self.finger += index + 1;
                if self.finger >= self.utf8_size {
                    let found_char = self.finger - self.utf8_size;
                    if let Some(slice) = self.haystack.as_bytes().get(found_char..self.finger) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            return Some((found_char, self.finger));
                        }
                    }
                }
            } else {
                // fandt intet, exit
                self.finger = self.finger_back;
                return None;
            }
        }
    }

    // lad next_reject bruge standardimplementeringen fra Searcher trait
}

unsafe impl<'a> ReverseSearcher<'a> for CharSearcher<'a> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let old_finger = self.finger_back;
        // SIKKERHED: se kommentaren til next() ovenfor
        let slice = unsafe { self.haystack.get_unchecked(self.finger..old_finger) };
        let mut iter = slice.chars();
        let old_len = iter.iter.len();
        if let Some(ch) = iter.next_back() {
            // træk byte-forskydning af det aktuelle tegn uden at kode igen som utf-8
            //
            self.finger_back -= old_len - iter.iter.len();
            if ch == self.needle {
                SearchStep::Match(self.finger_back, old_finger)
            } else {
                SearchStep::Reject(self.finger_back, old_finger)
            }
        } else {
            SearchStep::Done
        }
    }
    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        let haystack = self.haystack.as_bytes();
        loop {
            // få høstakken op til, men inkluderer ikke det sidste tegn, der blev søgt
            let bytes = haystack.get(self.finger..self.finger_back)?;
            // den sidste byte af utf8-kodet nål SIKKERHED: vi har en invariant, der `utf8_size < 5`
            //
            let last_byte = unsafe { *self.utf8_encoded.get_unchecked(self.utf8_size - 1) };
            if let Some(index) = memchr::memrchr(last_byte, bytes) {
                // vi søgte et stykke, der blev udlignet af self.finger, tilføj self.finger for at genvinde det oprindelige indeks
                //
                let index = self.finger + index;
                // memrchr returnerer indekset for den byte, vi ønsker at finde.
                // I tilfælde af et ASCII-tegn er dette faktisk, hvis vi ønsker, at vores nye finger skal være ("after" den fundne røde farve i paradigmet for omvendt iteration).
                //
                // For multibyte-tegn skal vi springe ned med antallet af flere byte, de har end ASCII
                //
                //
                let shift = self.utf8_size - 1;
                if index >= shift {
                    let found_char = index - shift;
                    if let Some(slice) = haystack.get(found_char..(found_char + self.utf8_size)) {
                        if slice == &self.utf8_encoded[0..self.utf8_size] {
                            // flyt fingeren til før tegnet blev fundet (dvs. ved dets startindeks)
                            self.finger_back = found_char;
                            return Some((self.finger_back, self.finger_back + self.utf8_size));
                        }
                    }
                }
                // Vi kan ikke bruge finger_back=index, størrelse + 1 her.
                // Hvis vi fandt den sidste char af en anden størrelse (eller den midterste byte af en anden karakter) er vi nødt til at bumpe finger_back ned til `index`.
                // På samme måde får `finger_back` potentialet til ikke længere at være på en grænse, men det er OK, da vi kun forlader denne funktion ved en grænse, eller når høstakken er blevet søgt fuldstændigt.
                //
                //
                // I modsætning til next_match har dette ikke problemet med gentagne byte i utf-8, fordi vi søger efter den sidste byte, og vi kan kun have fundet den sidste byte, når vi søger i omvendt rækkefølge.
                //
                //
                //
                //
                //
                self.finger_back = index;
            } else {
                self.finger_back = self.finger;
                // fandt intet, exit
                return None;
            }
        }
    }

    // lad next_reject_back bruge standardimplementeringen fra Searcher trait
}

impl<'a> DoubleEndedSearcher<'a> for CharSearcher<'a> {}

/// Søger efter tegn, der svarer til en given [`char`].
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find('o'), Some(4));
/// ```
impl<'a> Pattern<'a> for char {
    type Searcher = CharSearcher<'a>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> Self::Searcher {
        let mut utf8_encoded = [0; 4];
        let utf8_size = self.encode_utf8(&mut utf8_encoded).len();
        CharSearcher {
            haystack,
            finger: 0,
            finger_back: haystack.len(),
            needle: self,
            utf8_size,
            utf8_encoded,
        }
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        if (self as u32) < 128 {
            haystack.as_bytes().contains(&(self as u8))
        } else {
            let mut buffer = [0u8; 4];
            self.encode_utf8(&mut buffer).is_contained_in(haystack)
        }
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self.encode_utf8(&mut [0u8; 4]).is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self.encode_utf8(&mut [0u8; 4]).strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
    where
        Self::Searcher: ReverseSearcher<'a>,
    {
        self.encode_utf8(&mut [0u8; 4]).strip_suffix_of(haystack)
    }
}

/////////////////////////////////////////////////////////////////////////////
// Impl for en MultiCharEq-indpakning
/////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
trait MultiCharEq {
    fn matches(&mut self, c: char) -> bool;
}

impl<F> MultiCharEq for F
where
    F: FnMut(char) -> bool,
{
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        (*self)(c)
    }
}

impl MultiCharEq for &[char] {
    #[inline]
    fn matches(&mut self, c: char) -> bool {
        self.iter().any(|&m| m == c)
    }
}

struct MultiCharEqPattern<C: MultiCharEq>(C);

#[derive(Clone, Debug)]
struct MultiCharEqSearcher<'a, C: MultiCharEq> {
    char_eq: C,
    haystack: &'a str,
    char_indices: super::CharIndices<'a>,
}

impl<'a, C: MultiCharEq> Pattern<'a> for MultiCharEqPattern<C> {
    type Searcher = MultiCharEqSearcher<'a, C>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> MultiCharEqSearcher<'a, C> {
        MultiCharEqSearcher { haystack, char_eq: self.0, char_indices: haystack.char_indices() }
    }
}

unsafe impl<'a, C: MultiCharEq> Searcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Sammenlign længderne af den interne byte-skive-iterator for at finde længden af den aktuelle kul
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

unsafe impl<'a, C: MultiCharEq> ReverseSearcher<'a> for MultiCharEqSearcher<'a, C> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        let s = &mut self.char_indices;
        // Sammenlign længderne af den interne byte-skive-iterator for at finde længden af den aktuelle kul
        //
        let pre_len = s.iter.iter.len();
        if let Some((i, c)) = s.next_back() {
            let len = s.iter.iter.len();
            let char_len = pre_len - len;
            if self.char_eq.matches(c) {
                return SearchStep::Match(i, i + char_len);
            } else {
                return SearchStep::Reject(i, i + char_len);
            }
        }
        SearchStep::Done
    }
}

impl<'a, C: MultiCharEq> DoubleEndedSearcher<'a> for MultiCharEqSearcher<'a, C> {}

/////////////////////////////////////////////////////////////////////////////

macro_rules! pattern_methods {
    ($t:ty, $pmap:expr, $smap:expr) => {
        type Searcher = $t;

        #[inline]
        fn into_searcher(self, haystack: &'a str) -> $t {
            ($smap)(($pmap)(self).into_searcher(haystack))
        }

        #[inline]
        fn is_contained_in(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_contained_in(haystack)
        }

        #[inline]
        fn is_prefix_of(self, haystack: &'a str) -> bool {
            ($pmap)(self).is_prefix_of(haystack)
        }

        #[inline]
        fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
            ($pmap)(self).strip_prefix_of(haystack)
        }

        #[inline]
        fn is_suffix_of(self, haystack: &'a str) -> bool
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).is_suffix_of(haystack)
        }

        #[inline]
        fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str>
        where
            $t: ReverseSearcher<'a>,
        {
            ($pmap)(self).strip_suffix_of(haystack)
        }
    };
}

macro_rules! searcher_methods {
    (forward) => {
        #[inline]
        fn haystack(&self) -> &'a str {
            self.0.haystack()
        }
        #[inline]
        fn next(&mut self) -> SearchStep {
            self.0.next()
        }
        #[inline]
        fn next_match(&mut self) -> Option<(usize, usize)> {
            self.0.next_match()
        }
        #[inline]
        fn next_reject(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject()
        }
    };
    (reverse) => {
        #[inline]
        fn next_back(&mut self) -> SearchStep {
            self.0.next_back()
        }
        #[inline]
        fn next_match_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_match_back()
        }
        #[inline]
        fn next_reject_back(&mut self) -> Option<(usize, usize)> {
            self.0.next_reject_back()
        }
    };
}

/////////////////////////////////////////////////////////////////////////////
// Impl til&[char]
/////////////////////////////////////////////////////////////////////////////

// Todo: Skift/fjern på grund af uklarhed i betydning.

/// Tilknyttet type til `<&[char] as Pattern<'a>>::Searcher`.
#[derive(Clone, Debug)]
pub struct CharSliceSearcher<'a, 'b>(<MultiCharEqPattern<&'b [char]> as Pattern<'a>>::Searcher);

unsafe impl<'a, 'b> Searcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(forward);
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for CharSliceSearcher<'a, 'b> {
    searcher_methods!(reverse);
}

impl<'a, 'b> DoubleEndedSearcher<'a> for CharSliceSearcher<'a, 'b> {}

/// Søger efter tegn, der svarer til en hvilken som helst af [`char`] i skiven.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(&['l', 'l'] as &[_]), Some(2));
/// assert_eq!("Hello world".find(&['l', 'l'][..]), Some(2));
/// ```
impl<'a, 'b> Pattern<'a> for &'b [char] {
    pattern_methods!(CharSliceSearcher<'a, 'b>, MultiCharEqPattern, CharSliceSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl for F: FnMut(char)-> bool
/////////////////////////////////////////////////////////////////////////////

/// Tilknyttet type til `<F as Pattern<'a>>::Searcher`.
#[derive(Clone)]
pub struct CharPredicateSearcher<'a, F>(<MultiCharEqPattern<F> as Pattern<'a>>::Searcher)
where
    F: FnMut(char) -> bool;

impl<F> fmt::Debug for CharPredicateSearcher<'_, F>
where
    F: FnMut(char) -> bool,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("CharPredicateSearcher")
            .field("haystack", &self.0.haystack)
            .field("char_indices", &self.0.char_indices)
            .finish()
    }
}
unsafe impl<'a, F> Searcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(forward);
}

unsafe impl<'a, F> ReverseSearcher<'a> for CharPredicateSearcher<'a, F>
where
    F: FnMut(char) -> bool,
{
    searcher_methods!(reverse);
}

impl<'a, F> DoubleEndedSearcher<'a> for CharPredicateSearcher<'a, F> where F: FnMut(char) -> bool {}

/// Søger efter [`char`], der matcher det givne prædikat.
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find(char::is_uppercase), Some(0));
/// assert_eq!("Hello world".find(|c| "aeiou".contains(c)), Some(1));
/// ```
impl<'a, F> Pattern<'a> for F
where
    F: FnMut(char) -> bool,
{
    pattern_methods!(CharPredicateSearcher<'a, F>, MultiCharEqPattern, CharPredicateSearcher);
}

/////////////////////////////////////////////////////////////////////////////
// Impl for&&str
/////////////////////////////////////////////////////////////////////////////

/// Delegater til `&str` impl.
impl<'a, 'b, 'c> Pattern<'a> for &'c &'b str {
    pattern_methods!(StrSearcher<'a, 'b>, |&s| s, |s| s);
}

/////////////////////////////////////////////////////////////////////////////
// Impl til &str
/////////////////////////////////////////////////////////////////////////////

/// Ikke-tildelende søgning efter substring.
///
/// Håndterer mønsteret `""` som returnerende tomme matches ved hver tegngrænse.
///
///
/// # Examples
///
/// ```
/// assert_eq!("Hello world".find("world"), Some(6));
/// ```
impl<'a, 'b> Pattern<'a> for &'b str {
    type Searcher = StrSearcher<'a, 'b>;

    #[inline]
    fn into_searcher(self, haystack: &'a str) -> StrSearcher<'a, 'b> {
        StrSearcher::new(haystack, self)
    }

    /// Kontrollerer, om mønsteret matcher foran høstakken.
    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().starts_with(self.as_bytes())
    }

    /// Fjerner mønsteret fra høstakken, hvis det passer.
    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_prefix_of(haystack) {
            // SIKKERHED: præfikset blev netop verificeret for at eksistere.
            unsafe { Some(haystack.get_unchecked(self.as_bytes().len()..)) }
        } else {
            None
        }
    }

    /// Kontrollerer, om mønsteret matcher bag på høstakken.
    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        haystack.as_bytes().ends_with(self.as_bytes())
    }

    /// Fjerner mønsteret fra bagsiden af høstakken, hvis det passer.
    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        if self.is_suffix_of(haystack) {
            let i = haystack.len() - self.as_bytes().len();
            // SIKKERHED: suffikset blev netop verificeret for at eksistere.
            unsafe { Some(haystack.get_unchecked(..i)) }
        } else {
            None
        }
    }
}

/////////////////////////////////////////////////////////////////////////////
// To-vejs substring-søgning
/////////////////////////////////////////////////////////////////////////////

#[derive(Clone, Debug)]
/// Tilknyttet type til `<&str as Pattern<'a>>::Searcher`.
pub struct StrSearcher<'a, 'b> {
    haystack: &'a str,
    needle: &'b str,

    searcher: StrSearcherImpl,
}

#[derive(Clone, Debug)]
enum StrSearcherImpl {
    Empty(EmptyNeedle),
    TwoWay(TwoWaySearcher),
}

#[derive(Clone, Debug)]
struct EmptyNeedle {
    position: usize,
    end: usize,
    is_match_fw: bool,
    is_match_bw: bool,
}

impl<'a, 'b> StrSearcher<'a, 'b> {
    fn new(haystack: &'a str, needle: &'b str) -> StrSearcher<'a, 'b> {
        if needle.is_empty() {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::Empty(EmptyNeedle {
                    position: 0,
                    end: haystack.len(),
                    is_match_fw: true,
                    is_match_bw: true,
                }),
            }
        } else {
            StrSearcher {
                haystack,
                needle,
                searcher: StrSearcherImpl::TwoWay(TwoWaySearcher::new(
                    needle.as_bytes(),
                    haystack.len(),
                )),
            }
        }
    }
}

unsafe impl<'a, 'b> Searcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn haystack(&self) -> &'a str {
        self.haystack
    }

    #[inline]
    fn next(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                // tom nål afviser hver kul og matcher hver tom streng imellem dem
                let is_match = searcher.is_match_fw;
                searcher.is_match_fw = !searcher.is_match_fw;
                let pos = searcher.position;
                match self.haystack[pos..].chars().next() {
                    _ if is_match => SearchStep::Match(pos, pos),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.position += ch.len_utf8();
                        SearchStep::Reject(pos, searcher.position)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                // TwoWaySearcher producerer gyldige *Match*-indekser, der opdeles ved char-grænser, så længe den stemmer overens, og at høstak og nål er gyldige UTF-8 *Afvisninger* fra algoritmen kan falde på alle indekser, men vi vil gå dem manuelt til den næste tegngrænse, så de er utf-8 sikre.
                //
                //
                //
                //
                if searcher.position == self.haystack.len() {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(a, mut b) => {
                        // spring til næste rødgrænse
                        while !self.haystack.is_char_boundary(b) {
                            b += 1;
                        }
                        searcher.position = cmp::max(b, searcher.position);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // skriv `true`-og `false`-sager ud for at tilskynde compileren til at specialisere de to sager separat.
                //
                if is_long {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

unsafe impl<'a, 'b> ReverseSearcher<'a> for StrSearcher<'a, 'b> {
    #[inline]
    fn next_back(&mut self) -> SearchStep {
        match self.searcher {
            StrSearcherImpl::Empty(ref mut searcher) => {
                let is_match = searcher.is_match_bw;
                searcher.is_match_bw = !searcher.is_match_bw;
                let end = searcher.end;
                match self.haystack[..end].chars().next_back() {
                    _ if is_match => SearchStep::Match(end, end),
                    None => SearchStep::Done,
                    Some(ch) => {
                        searcher.end -= ch.len_utf8();
                        SearchStep::Reject(searcher.end, end)
                    }
                }
            }
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                if searcher.end == 0 {
                    return SearchStep::Done;
                }
                let is_long = searcher.memory == usize::MAX;
                match searcher.next_back::<RejectAndMatch>(
                    self.haystack.as_bytes(),
                    self.needle.as_bytes(),
                    is_long,
                ) {
                    SearchStep::Reject(mut a, b) => {
                        // spring til næste rødgrænse
                        while !self.haystack.is_char_boundary(a) {
                            a -= 1;
                        }
                        searcher.end = cmp::min(a, searcher.end);
                        SearchStep::Reject(a, b)
                    }
                    otherwise => otherwise,
                }
            }
        }
    }

    #[inline]
    fn next_match_back(&mut self) -> Option<(usize, usize)> {
        match self.searcher {
            StrSearcherImpl::Empty(..) => loop {
                match self.next_back() {
                    SearchStep::Match(a, b) => return Some((a, b)),
                    SearchStep::Done => return None,
                    SearchStep::Reject(..) => {}
                }
            },
            StrSearcherImpl::TwoWay(ref mut searcher) => {
                let is_long = searcher.memory == usize::MAX;
                // skriv `true` og `false` ud som `next_match`
                if is_long {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        true,
                    )
                } else {
                    searcher.next_back::<MatchOnly>(
                        self.haystack.as_bytes(),
                        self.needle.as_bytes(),
                        false,
                    )
                }
            }
        }
    }
}

/// Den interne tilstand af tovejs-substringsøgealgoritmen.
#[derive(Clone, Debug)]
struct TwoWaySearcher {
    // constants
    /// kritisk faktoriseringsindeks
    crit_pos: usize,
    /// kritisk faktoriseringsindeks for omvendt nål
    crit_pos_back: usize,
    period: usize,
    /// `byteset` er en udvidelse (ikke en del af tovejsalgoritmen);
    /// det er en 64-bit "fingerprint", hvor hver sæt bit `j` svarer til en (byte&63)==j til stede i nålen.
    ///
    byteset: u64,

    // variables
    position: usize,
    end: usize,
    /// indeks i nål, inden hvilken vi allerede har matchet
    memory: usize,
    /// indeks i nål, hvorefter vi allerede har matchet
    memory_back: usize,
}

/*
    This is the Two-Way search algorithm, which was introduced in the paper:
    Crochemore, M., Perrin, D., 1991, Two-way string-matching, Journal of the ACM 38(3):651-675.

    Here's some background information.

    A *word* is a string of symbols. The *length* of a word should be a familiar
    notion, and here we denote it for any word x by |x|.
    (We also allow for the possibility of the *empty word*, a word of length zero).

    If x is any non-empty word, then an integer p with 0 < p <= |x| is said to be a
    *period* for x iff for all i with 0 <= i <= |x| - p - 1, we have x[i] == x[i+p].
    For example, both 1 and 2 are periods for the string "aa". As another example,
    the only period of the string "abcd" is 4.

    We denote by period(x) the *smallest* period of x (provided that x is non-empty).
    This is always well-defined since every non-empty word x has at least one period,
    |x|. We sometimes call this *the period* of x.

    If u, v and x are words such that x = uv, where uv is the concatenation of u and
    v, then we say that (u, v) is a *factorization* of x.

    Let (u, v) be a factorization for a word x. Then if w is a non-empty word such
    that both of the following hold

      - either w is a suffix of u or u is a suffix of w
      - either w is a prefix of v or v is a prefix of w

    then w is said to be a *repetition* for the factorization (u, v).

    Just to unpack this, there are four possibilities here. Let w = "abc". Then we
    might have:

      - w is a suffix of u and w is a prefix of v. ex: ("lolabc", "abcde")
      - w is a suffix of u and v is a prefix of w. ex: ("lolabc", "ab")
      - u is a suffix of w and w is a prefix of v. ex: ("bc", "abchi")
      - u is a suffix of w and v is a prefix of w. ex: ("bc", "a")

    Note that the word vu is a repetition for any factorization (u,v) of x = uv,
    so every factorization has at least one repetition.

    If x is a string and (u, v) is a factorization for x, then a *local period* for
    (u, v) is an integer r such that there is some word w such that |w| = r and w is
    a repetition for (u, v).

    We denote by local_period(u, v) the smallest local period of (u, v). We sometimes
    call this *the local period* of (u, v). Provided that x = uv is non-empty, this
    is well-defined (because each non-empty word has at least one factorization, as
    noted above).

    It can be proven that the following is an equivalent definition of a local period
    for a factorization (u, v): any positive integer r such that x[i] == x[i+r] for
    all i such that |u| - r <= i <= |u| - 1 and such that both x[i] and x[i+r] are
    defined. (i.e., i > 0 and i + r < |x|).

    Using the above reformulation, it is easy to prove that

        1 <= local_period(u, v) <= period(uv)

    A factorization (u, v) of x such that local_period(u,v) = period(x) is called a
    *critical factorization*.

    The algorithm hinges on the following theorem, which is stated without proof:

    **Critical Factorization Theorem** Any word x has at least one critical
    factorization (u, v) such that |u| < period(x).

    The purpose of maximal_suffix is to find such a critical factorization.

    If the period is short, compute another factorization x = u' v' to use
    for reverse search, chosen instead so that |v'| < period(x).

*/
impl TwoWaySearcher {
    fn new(needle: &[u8], end: usize) -> TwoWaySearcher {
        let (crit_pos_false, period_false) = TwoWaySearcher::maximal_suffix(needle, false);
        let (crit_pos_true, period_true) = TwoWaySearcher::maximal_suffix(needle, true);

        let (crit_pos, period) = if crit_pos_false > crit_pos_true {
            (crit_pos_false, period_false)
        } else {
            (crit_pos_true, period_true)
        };

        // En særlig læselig forklaring på, hvad der foregår her, findes i Crochemore og Rytter's bog "Text Algorithms", kapitel 13.
        // Se specifikt koden til "Algorithm CP" på s.
        // 323.
        //
        // Hvad der foregår er, at vi har en kritisk faktorisering (u, v) af nålen, og vi vil bestemme, om u er et suffiks af&v [.. periode].
        // Hvis det er tilfældet, bruger vi "Algorithm CP1".
        // Ellers bruger vi "Algorithm CP2", som er optimeret til når nålens periode er stor.
        //
        //
        if needle[..crit_pos] == needle[period..period + crit_pos] {
            // kort periode tilfælde-perioden er nøjagtig beregne en separat kritisk faktorisering for den omvendte nål x=u 'v' hvor | v '|<period(x).
            //
            // Dette fremskyndes af den periode, der allerede er kendt.
            // Bemærk, at en sag som x= "acba" kan indregnes nøjagtigt fremad (crit_pos=1, periode=3), mens den tælles med en omtrentlig periode i omvendt rækkefølge (crit_pos=2, periode=2).
            // Vi bruger den givne omvendte faktorisering, men holder den nøjagtige periode.
            //
            //
            //
            //
            let crit_pos_back = needle.len()
                - cmp::max(
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, false),
                    TwoWaySearcher::reverse_maximal_suffix(needle, period, true),
                );

            TwoWaySearcher {
                crit_pos,
                crit_pos_back,
                period,
                byteset: Self::byteset_create(&needle[..period]),

                position: 0,
                end,
                memory: 0,
                memory_back: needle.len(),
            }
        } else {
            // lang periode-vi har en tilnærmelse til den aktuelle periode og bruger ikke memorisering.
            //
            //
            // Anslået periode med nedre grænse max(|u|, |v|) + 1.
            // Den kritiske faktorisering er effektiv at bruge til både fremad-og tilbagesøgning.
            //

            TwoWaySearcher {
                crit_pos,
                crit_pos_back: crit_pos,
                period: cmp::max(crit_pos, needle.len() - crit_pos) + 1,
                byteset: Self::byteset_create(needle),

                position: 0,
                end,
                memory: usize::MAX, // Dummy værdi for at angive, at perioden er lang
                memory_back: usize::MAX,
            }
        }
    }

    #[inline]
    fn byteset_create(bytes: &[u8]) -> u64 {
        bytes.iter().fold(0, |a, &b| (1 << (b & 0x3f)) | a)
    }

    #[inline]
    fn byteset_contains(&self, byte: u8) -> bool {
        (self.byteset >> ((byte & 0x3f) as usize)) & 1 != 0
    }

    // En af hovedideerne i Two-Way er, at vi faktoriserer nålen i to halvdele, (u, v), og begynder at prøve at finde v i høstakken ved at scanne venstre mod højre.
    // Hvis v matcher, prøver vi at matche u ved at scanne højre mod venstre.
    // Hvor langt vi kan springe, når vi støder på en uoverensstemmelse, er alt baseret på det faktum, at (u, v) er en kritisk faktorisering for nålen.
    //
    //
    #[inline]
    fn next<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next()` bruger `self.position` som markør
        let old_pos = self.position;
        let needle_last = needle.len() - 1;
        'search: loop {
            // Kontroller, at vi har plads til at søge i position + needle_last kan ikke løbe over, hvis vi antager, at skiver er afgrænset af isize's rækkevidde.
            //
            //
            let tail_byte = match haystack.get(self.position + needle_last) {
                Some(&b) => b,
                None => {
                    self.position = haystack.len();
                    return S::rejecting(old_pos, self.position);
                }
            };

            if S::use_early_reject() && old_pos != self.position {
                return S::rejecting(old_pos, self.position);
            }

            // Spring hurtigt over store portioner, der ikke er relateret til vores underlag
            if !self.byteset_contains(tail_byte) {
                self.position += needle.len();
                if !long_period {
                    self.memory = 0;
                }
                continue 'search;
            }

            // Se om den højre del af nålen passer
            let start =
                if long_period { self.crit_pos } else { cmp::max(self.crit_pos, self.memory) };
            for i in start..needle.len() {
                if needle[i] != haystack[self.position + i] {
                    self.position += i - self.crit_pos + 1;
                    if !long_period {
                        self.memory = 0;
                    }
                    continue 'search;
                }
            }

            // Se om den venstre del af nålen passer
            let start = if long_period { 0 } else { self.memory };
            for i in (start..self.crit_pos).rev() {
                if needle[i] != haystack[self.position + i] {
                    self.position += self.period;
                    if !long_period {
                        self.memory = needle.len() - self.period;
                    }
                    continue 'search;
                }
            }

            // Vi har fundet en kamp!
            let match_pos = self.position;

            // Note: tilføj self.period i stedet for needle.len() for at have overlappende kampe
            self.position += needle.len();
            if !long_period {
                self.memory = 0; // indstillet til needle.len(), self.period til overlappende kampe
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Følger idéerne i `next()`.
    //
    // Definitionerne er symmetriske med period(x) = period(reverse(x)) og local_period(u, v) = local_period(reverse(v), reverse(u)), så hvis (u, v) er en kritisk faktorisering, så er (reverse(v), reverse(u)).
    //
    //
    // I det omvendte tilfælde har vi beregnet en kritisk faktorisering x=u 'v' (felt `crit_pos_back`).Vi har brug for | u |<period(x) for den forreste sag og dermed | v '|<period(x) for omvendt.
    //
    // For at søge baglæns gennem høstakken søger vi fremad gennem en omvendt høstak med en omvendt nål, der matcher først u 'og derefter v'.
    //
    //
    //
    //
    #[inline]
    fn next_back<S>(&mut self, haystack: &[u8], needle: &[u8], long_period: bool) -> S::Output
    where
        S: TwoWayStrategy,
    {
        // `next_back()` bruger `self.end` som markør-så `next()` og `next_back()` er uafhængige.
        //
        let old_end = self.end;
        'search: loop {
            // Kontroller, at vi har plads til at søge til sidst, needle.len() vikles rundt, når der ikke er mere plads, men på grund af skivelængdebegrænsninger kan den aldrig vikle helt tilbage i længden af høstak.
            //
            //
            //
            let front_byte = match haystack.get(self.end.wrapping_sub(needle.len())) {
                Some(&b) => b,
                None => {
                    self.end = 0;
                    return S::rejecting(0, old_end);
                }
            };

            if S::use_early_reject() && old_end != self.end {
                return S::rejecting(self.end, old_end);
            }

            // Spring hurtigt over store portioner, der ikke er relateret til vores underlag
            if !self.byteset_contains(front_byte) {
                self.end -= needle.len();
                if !long_period {
                    self.memory_back = needle.len();
                }
                continue 'search;
            }

            // Se om den venstre del af nålen passer
            let crit = if long_period {
                self.crit_pos_back
            } else {
                cmp::min(self.crit_pos_back, self.memory_back)
            };
            for i in (0..crit).rev() {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.crit_pos_back - i;
                    if !long_period {
                        self.memory_back = needle.len();
                    }
                    continue 'search;
                }
            }

            // Se om den højre del af nålen passer
            let needle_end = if long_period { needle.len() } else { self.memory_back };
            for i in self.crit_pos_back..needle_end {
                if needle[i] != haystack[self.end - needle.len() + i] {
                    self.end -= self.period;
                    if !long_period {
                        self.memory_back = self.period;
                    }
                    continue 'search;
                }
            }

            // Vi har fundet en kamp!
            let match_pos = self.end - needle.len();
            // Note: under self.period i stedet for needle.len() for at have overlappende kampe
            self.end -= needle.len();
            if !long_period {
                self.memory_back = needle.len();
            }

            return S::matching(match_pos, match_pos + needle.len());
        }
    }

    // Beregn det maksimale suffiks for `arr`.
    //
    // Det maksimale suffiks er en mulig kritisk faktorisering (u, v) af `arr`.
    //
    // Returnerer (`i`, `p`) hvor `i` er startindekset for v og `p` er perioden for v.
    //
    // `order_greater` bestemmer, om den leksikale rækkefølge er `<` eller `>`.
    // Begge ordrer skal beregnes-ordren med den største `i` giver en kritisk faktorisering.
    //
    //
    // I tilfælde af lang periode er den resulterende periode ikke nøjagtig (den er for kort).
    //
    #[inline]
    fn maximal_suffix(arr: &[u8], order_greater: bool) -> (usize, usize) {
        let mut left = 0; // Svarer til jeg i avisen
        let mut right = 1; // Svarer til j i papiret
        let mut offset = 0; // Svarer til k i papiret, men starter ved 0
        // for at matche 0-baseret indeksering.
        let mut period = 1; // Svarer til p i papiret

        while let Some(&a) = arr.get(right + offset) {
            // `left` vil være indgående, når `right` er.
            let b = arr[left + offset];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Suffiks er mindre, indtil videre er hele præfikset.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Fremad gennem gentagelse af den aktuelle periode.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Suffiks er større, start forfra fra den aktuelle placering.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
        }
        (left, period)
    }

    // Beregn det maksimale suffiks for bagsiden af `arr`.
    //
    // Det maksimale suffiks er en mulig kritisk faktorisering (u ', v') af `arr`.
    //
    // Returnerer `i`, hvor `i` er startindekset for v ', bagfra;
    // vender straks tilbage, når en periode på `known_period` er nået.
    //
    // `order_greater` bestemmer, om den leksikale rækkefølge er `<` eller `>`.
    // Begge ordrer skal beregnes-ordren med den største `i` giver en kritisk faktorisering.
    //
    //
    // I tilfælde af lang periode er den resulterende periode ikke nøjagtig (den er for kort).
    fn reverse_maximal_suffix(arr: &[u8], known_period: usize, order_greater: bool) -> usize {
        let mut left = 0; // Svarer til jeg i avisen
        let mut right = 1; // Svarer til j i papiret
        let mut offset = 0; // Svarer til k i papiret, men starter ved 0
        // for at matche 0-baseret indeksering.
        let mut period = 1; // Svarer til p i papiret
        let n = arr.len();

        while right + offset < n {
            let a = arr[n - (1 + right + offset)];
            let b = arr[n - (1 + left + offset)];
            if (a < b && !order_greater) || (a > b && order_greater) {
                // Suffiks er mindre, indtil videre er hele præfikset.
                right += offset + 1;
                offset = 0;
                period = right - left;
            } else if a == b {
                // Fremad gennem gentagelse af den aktuelle periode.
                if offset + 1 == period {
                    right += offset + 1;
                    offset = 0;
                } else {
                    offset += 1;
                }
            } else {
                // Suffiks er større, start forfra fra den aktuelle placering.
                left = right;
                right += 1;
                offset = 0;
                period = 1;
            }
            if period == known_period {
                break;
            }
        }
        debug_assert!(period <= known_period);
        left
    }
}

// TwoWayStrategy giver algoritmen mulighed for enten at springe ikke-matches over så hurtigt som muligt eller arbejde i en tilstand, hvor den udsender Afvisninger relativt hurtigt.
//
trait TwoWayStrategy {
    type Output;
    fn use_early_reject() -> bool;
    fn rejecting(a: usize, b: usize) -> Self::Output;
    fn matching(a: usize, b: usize) -> Self::Output;
}

/// Spring for at matche intervaller så hurtigt som muligt
enum MatchOnly {}

impl TwoWayStrategy for MatchOnly {
    type Output = Option<(usize, usize)>;

    #[inline]
    fn use_early_reject() -> bool {
        false
    }
    #[inline]
    fn rejecting(_a: usize, _b: usize) -> Self::Output {
        None
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        Some((a, b))
    }
}

/// Emit afviser regelmæssigt
enum RejectAndMatch {}

impl TwoWayStrategy for RejectAndMatch {
    type Output = SearchStep;

    #[inline]
    fn use_early_reject() -> bool {
        true
    }
    #[inline]
    fn rejecting(a: usize, b: usize) -> Self::Output {
        SearchStep::Reject(a, b)
    }
    #[inline]
    fn matching(a: usize, b: usize) -> Self::Output {
        SearchStep::Match(a, b)
    }
}