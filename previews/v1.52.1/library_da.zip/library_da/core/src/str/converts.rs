//! Måder at oprette en `str` fra bytes skive.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Konverterer et stykke bytes til et streng stykke.
///
/// En strengskive ([`&str`]) er lavet af byte ([`u8`]), og en bitskive ([`&[u8]`][byteslice]) er lavet af bytes, så denne funktion konverterer mellem de to.
/// Ikke alle byte-skiver er gyldige strengskiver, men: [`&str`] kræver, at det er gyldigt UTF-8.
/// `from_utf8()` kontrollerer for at sikre, at byte er gyldige UTF-8, og derefter konverteres.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Hvis du er sikker på, at bytesnittet er gyldigt UTF-8, og du ikke vil påtage dig omkostningerne ved gyldighedskontrollen, er der en usikker version af denne funktion, [`from_utf8_unchecked`], som har samme adfærd, men springer kontrollen over.
///
///
/// Hvis du har brug for en `String` i stedet for en `&str`, skal du overveje [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Fordi du kan stable-tildele en `[u8; N]`, og du kan tage en [`&[u8]`][byteslice] af den, er denne funktion en måde at have en stak-allokeret streng på.Der er et eksempel på dette i eksemplet nedenfor.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Returnerer `Err`, hvis udsnittet ikke er UTF-8 med en beskrivelse af, hvorfor det medfølgende udsnit ikke er UTF-8.
///
/// # Examples
///
/// Grundlæggende brug:
///
/// ```
/// use std::str;
///
/// // nogle bytes, i en vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Vi ved, at disse byte er gyldige, så brug bare `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Forkerte byte:
///
/// ```
/// use std::str;
///
/// // nogle ugyldige byte i en vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Se dokumenterne til [`Utf8Error`] for at få flere oplysninger om, hvilke typer fejl der kan returneres.
///
/// En "stack allocated string":
///
/// ```
/// use std::str;
///
/// // nogle byte i en stakallokeret matrix
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Vi ved, at disse byte er gyldige, så brug bare `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // SIKKERHED: Løb lige validering.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Konverterer et mutabelt stykke bytes til et mutable string-stykke.
///
/// # Examples
///
/// Grundlæggende brug:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" som en ændret vector
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Da vi ved, at disse bytes er gyldige, kan vi bruge `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Forkerte byte:
///
/// ```
/// use std::str;
///
/// // Nogle ugyldige byte i en ændret vector
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Se dokumenterne til [`Utf8Error`] for at få flere oplysninger om, hvilke typer fejl der kan returneres.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // SIKKERHED: Løb lige validering.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Konverterer en bit bytes til en strengskive uden at kontrollere, at strengen indeholder gyldig UTF-8.
///
/// Se den sikre version, [`from_utf8`], for at få flere oplysninger.
///
/// # Safety
///
/// Denne funktion er usikker, fordi den ikke kontrollerer, at de byte, der sendes til den, er gyldige UTF-8.
/// Hvis denne begrænsning overtrædes, resulterer udefineret adfærd, da resten af Rust antager, at [`&str`] er gyldige UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Grundlæggende brug:
///
/// ```
/// use std::str;
///
/// // nogle bytes, i en vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // SIKKERHED: den, der ringer op, skal garantere, at byte `v` er gyldige UTF-8.
    // Stoler også på, at `&str` og `&[u8]` har samme layout.
    unsafe { mem::transmute(v) }
}

/// Konverterer en bit bytes til en strengskive uden at kontrollere, at strengen indeholder gyldig UTF-8;mutable version.
///
///
/// Se den uforanderlige version, [`from_utf8_unchecked()`] for mere information.
///
/// # Examples
///
/// Grundlæggende brug:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // SIKKERHED: den, der ringer op, skal garantere, at byte `v`
    // er gyldige UTF-8, så rollebesætningen til `*mut str` er sikker.
    // Markøren er også sikker, fordi markøren kommer fra en reference, som garanteret er gyldig til skrivning.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}