//! Definerer utf8-fejltype.

use crate::fmt;

/// Fejl, der kan opstå, når man forsøger at fortolke en sekvens af [`u8`] som en streng.
///
/// Som sådan bruger `from_utf8`-familien af funktioner og metoder til både [`String`] og [`&str`] s f.eks. Denne fejl.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Denne fejltypes metoder kan bruges til at oprette funktionalitet svarende til `String::from_utf8_lossy` uden at tildele bunkehukommelse:
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Returnerer indekset i den givne streng, hvortil gyldig UTF-8 blev verificeret.
    ///
    /// Det er det maksimale indeks, således at `from_utf8(&input[..index])` returnerer `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// use std::str;
    ///
    /// // nogle ugyldige byte i en vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 returnerer en Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // den anden byte er ugyldig her
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Giver flere oplysninger om fejlen:
    ///
    /// * `None`: slutningen af input blev nået uventet.
    ///   `self.valid_up_to()` er 1 til 3 bytes fra slutningen af input.
    ///   Hvis en byte-stream (såsom en fil eller et netværksstik) dekodes trinvist, kan dette være en gyldig `char`, hvis UTF-8-bytesekvens spænder over flere stykker.
    ///
    ///
    /// * `Some(len)`: der blev stødt på en uventet byte.
    ///   Den angivne længde er den ugyldige bytesekvens, der starter ved indekset givet af `valid_up_to()`.
    ///   Afkodning skal genoptages efter denne sekvens (efter indsættelse af en [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) i tilfælde af tabsfri afkodning.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// En fejl returneret ved parsing af en `bool` ved hjælp af [`from_str`] mislykkes
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}