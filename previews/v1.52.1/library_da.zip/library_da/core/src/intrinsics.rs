//! Compiler iboende.
//!
//! De tilsvarende definitioner findes i `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! De tilsvarende const-implementeringer findes i `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Const iboende
//!
//! Note: eventuelle ændringer i konstruktionen af iboende egenskaber bør drøftes med sprogholdet.
//! Dette inkluderer ændringer i konstruktionens stabilitet.
//!
//! For at gøre en iboende brugbar ved kompileringstid, skal man kopiere implementeringen fra <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> til `compiler/rustc_mir/src/interpret/intrinsics.rs` og tilføje en `#[rustc_const_unstable(feature = "foo", issue = "01234")]` til den iboende.
//!
//!
//! Hvis en formodning skal bruges fra en `const fn` med en `rustc_const_stable`-attribut, skal den egentlige attribut også være `rustc_const_stable`.
//! En sådan ændring bør ikke udføres uden T-lang-konsultation, fordi den bager en funktion til det sprog, der ikke kan replikeres i brugerkode uden kompilatorstøtte.
//!
//! # Volatiles
//!
//! De flygtige iboende egenskaber giver operationer, der er beregnet til at virke på I/O-hukommelse, som garanteret ikke omarrangeres af kompilatoren på tværs af andre flygtige indre.Se LLVM-dokumentationen på [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Atomens indre giver almindelige atomoperationer på maskineord med flere mulige hukommelsesordrer.De adlyder den samme semantik som C++ 11.Se LLVM-dokumentationen på [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! En hurtig opdatering på hukommelsesbestilling:
//!
//! * Erhverve, en barriere for at erhverve en lås.Efterfølgende læser og skriver finder sted efter barrieren.
//! * Slip, en barriere for frigivelse af en lås.Tidligere læser og skriver finder sted før barrieren.
//! * Sekventielt konsistente, sekventielt konsistente operationer garanteres at ske i rækkefølge.Dette er standardtilstanden til at arbejde med atomtyper og svarer til Java s `volatile`.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Denne import bruges til at forenkle intra-doc-links
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // SIKKERHED: se `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, disse iboende egenskaber tager rå pointer, fordi de muterer alias hukommelse, som ikke er gyldig for hverken `&` eller `&mut`.
    //

    /// Gemmer en værdi, hvis den aktuelle værdi er den samme som `old`-værdien.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `compare_exchange`-metoden ved at videregive [`Ordering::SeqCst`] som både `success`-og `failure`-parametre.
    ///
    /// For eksempel, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Gemmer en værdi, hvis den aktuelle værdi er den samme som `old`-værdien.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `compare_exchange`-metoden ved at videregive [`Ordering::Acquire`] som både `success`-og `failure`-parametre.
    ///
    /// For eksempel, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Gemmer en værdi, hvis den aktuelle værdi er den samme som `old`-værdien.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `compare_exchange`-metoden ved at overføre [`Ordering::Release`] som `success` og [`Ordering::Relaxed`] som `failure`-parametre.
    /// For eksempel, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Gemmer en værdi, hvis den aktuelle værdi er den samme som `old`-værdien.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `compare_exchange`-metoden ved at overføre [`Ordering::AcqRel`] som `success` og [`Ordering::Acquire`] som `failure`-parametre.
    /// For eksempel, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Gemmer en værdi, hvis den aktuelle værdi er den samme som `old`-værdien.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `compare_exchange`-metoden ved at videregive [`Ordering::Relaxed`] som både `success`-og `failure`-parametre.
    ///
    /// For eksempel, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Gemmer en værdi, hvis den aktuelle værdi er den samme som `old`-værdien.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `compare_exchange`-metoden ved at overføre [`Ordering::SeqCst`] som `success` og [`Ordering::Relaxed`] som `failure`-parametre.
    /// For eksempel, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Gemmer en værdi, hvis den aktuelle værdi er den samme som `old`-værdien.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `compare_exchange`-metoden ved at overføre [`Ordering::SeqCst`] som `success` og [`Ordering::Acquire`] som `failure`-parametre.
    /// For eksempel, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Gemmer en værdi, hvis den aktuelle værdi er den samme som `old`-værdien.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `compare_exchange`-metoden ved at overføre [`Ordering::Acquire`] som `success` og [`Ordering::Relaxed`] som `failure`-parametre.
    /// For eksempel, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Gemmer en værdi, hvis den aktuelle værdi er den samme som `old`-værdien.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `compare_exchange`-metoden ved at overføre [`Ordering::AcqRel`] som `success` og [`Ordering::Relaxed`] som `failure`-parametre.
    /// For eksempel, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Gemmer en værdi, hvis den aktuelle værdi er den samme som `old`-værdien.
    ///
    /// Den stabiliserede version af denne iboende version er tilgængelig på [`atomic`]-typerne via `compare_exchange_weak`-metoden ved at videregive [`Ordering::SeqCst`] som både `success`-og `failure`-parametre.
    ///
    /// For eksempel, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Gemmer en værdi, hvis den aktuelle værdi er den samme som `old`-værdien.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `compare_exchange_weak`-metoden ved at videregive [`Ordering::Acquire`] som både `success`-og `failure`-parametre.
    ///
    /// For eksempel, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Gemmer en værdi, hvis den aktuelle værdi er den samme som `old`-værdien.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `compare_exchange_weak`-metoden ved at overføre [`Ordering::Release`] som `success` og [`Ordering::Relaxed`] som `failure`-parametre.
    /// For eksempel, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Gemmer en værdi, hvis den aktuelle værdi er den samme som `old`-værdien.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `compare_exchange_weak`-metoden ved at overføre [`Ordering::AcqRel`] som `success` og [`Ordering::Acquire`] som `failure`-parametre.
    /// For eksempel, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Gemmer en værdi, hvis den aktuelle værdi er den samme som `old`-værdien.
    ///
    /// Den stabiliserede version af denne iboende version er tilgængelig på [`atomic`]-typerne via `compare_exchange_weak`-metoden ved at videregive [`Ordering::Relaxed`] som både `success`-og `failure`-parametre.
    ///
    /// For eksempel, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Gemmer en værdi, hvis den aktuelle værdi er den samme som `old`-værdien.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `compare_exchange_weak`-metoden ved at overføre [`Ordering::SeqCst`] som `success` og [`Ordering::Relaxed`] som `failure`-parametre.
    /// For eksempel, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Gemmer en værdi, hvis den aktuelle værdi er den samme som `old`-værdien.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `compare_exchange_weak`-metoden ved at overføre [`Ordering::SeqCst`] som `success` og [`Ordering::Acquire`] som `failure`-parametre.
    /// For eksempel, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Gemmer en værdi, hvis den aktuelle værdi er den samme som `old`-værdien.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `compare_exchange_weak`-metoden ved at overføre [`Ordering::Acquire`] som `success` og [`Ordering::Relaxed`] som `failure`-parametre.
    /// For eksempel, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Gemmer en værdi, hvis den aktuelle værdi er den samme som `old`-værdien.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `compare_exchange_weak`-metoden ved at overføre [`Ordering::AcqRel`] som `success` og [`Ordering::Relaxed`] som `failure`-parametre.
    /// For eksempel, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Indlæser markørens aktuelle værdi.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `load`-metoden ved at sende [`Ordering::SeqCst`] som `order`.
    /// For eksempel, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Indlæser markørens aktuelle værdi.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `load`-metoden ved at sende [`Ordering::Acquire`] som `order`.
    /// For eksempel, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Indlæser markørens aktuelle værdi.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `load`-metoden ved at sende [`Ordering::Relaxed`] som `order`.
    /// For eksempel, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Gemmer værdien på den angivne hukommelsesplacering.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `store`-metoden ved at sende [`Ordering::SeqCst`] som `order`.
    /// For eksempel, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Gemmer værdien på den angivne hukommelsesplacering.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `store`-metoden ved at sende [`Ordering::Release`] som `order`.
    /// For eksempel, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Gemmer værdien på den angivne hukommelsesplacering.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `store`-metoden ved at sende [`Ordering::Relaxed`] som `order`.
    /// For eksempel, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Gemmer værdien på den angivne hukommelsesplacering og returnerer den gamle værdi.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `swap`-metoden ved at sende [`Ordering::SeqCst`] som `order`.
    /// For eksempel, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Gemmer værdien på den angivne hukommelsesplacering og returnerer den gamle værdi.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `swap`-metoden ved at sende [`Ordering::Acquire`] som `order`.
    /// For eksempel, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Gemmer værdien på den angivne hukommelsesplacering og returnerer den gamle værdi.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `swap`-metoden ved at sende [`Ordering::Release`] som `order`.
    /// For eksempel, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Gemmer værdien på den angivne hukommelsesplacering og returnerer den gamle værdi.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `swap`-metoden ved at sende [`Ordering::AcqRel`] som `order`.
    /// For eksempel, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Gemmer værdien på den angivne hukommelsesplacering og returnerer den gamle værdi.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `swap`-metoden ved at sende [`Ordering::Relaxed`] som `order`.
    /// For eksempel, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Føjes til den aktuelle værdi og returnerer den forrige værdi.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `fetch_add`-metoden ved at sende [`Ordering::SeqCst`] som `order`.
    /// For eksempel, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Føjes til den aktuelle værdi og returnerer den forrige værdi.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `fetch_add`-metoden ved at sende [`Ordering::Acquire`] som `order`.
    /// For eksempel, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Føjes til den aktuelle værdi og returnerer den forrige værdi.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `fetch_add`-metoden ved at sende [`Ordering::Release`] som `order`.
    /// For eksempel, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Føjes til den aktuelle værdi og returnerer den forrige værdi.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `fetch_add`-metoden ved at sende [`Ordering::AcqRel`] som `order`.
    /// For eksempel, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Føjes til den aktuelle værdi og returnerer den forrige værdi.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `fetch_add`-metoden ved at sende [`Ordering::Relaxed`] som `order`.
    /// For eksempel, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Træk fra den aktuelle værdi, og returner den tidligere værdi.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `fetch_sub`-metoden ved at sende [`Ordering::SeqCst`] som `order`.
    /// For eksempel, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Træk fra den aktuelle værdi, og returner den tidligere værdi.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `fetch_sub`-metoden ved at sende [`Ordering::Acquire`] som `order`.
    /// For eksempel, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Træk fra den aktuelle værdi, og returner den tidligere værdi.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `fetch_sub`-metoden ved at sende [`Ordering::Release`] som `order`.
    /// For eksempel, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Træk fra den aktuelle værdi, og returner den tidligere værdi.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `fetch_sub`-metoden ved at sende [`Ordering::AcqRel`] som `order`.
    /// For eksempel, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Træk fra den aktuelle værdi, og returner den tidligere værdi.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `fetch_sub`-metoden ved at sende [`Ordering::Relaxed`] som `order`.
    /// For eksempel, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitvis og med den aktuelle værdi, returnerer den forrige værdi.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `fetch_and`-metoden ved at sende [`Ordering::SeqCst`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis og med den aktuelle værdi, returnerer den forrige værdi.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `fetch_and`-metoden ved at sende [`Ordering::Acquire`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis og med den aktuelle værdi, returnerer den forrige værdi.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `fetch_and`-metoden ved at sende [`Ordering::Release`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis og med den aktuelle værdi, returnerer den forrige værdi.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `fetch_and`-metoden ved at sende [`Ordering::AcqRel`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis og med den aktuelle værdi, returnerer den forrige værdi.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `fetch_and`-metoden ved at sende [`Ordering::Relaxed`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitvis nand med den aktuelle værdi og returnerer den forrige værdi.
    ///
    /// Den stabiliserede version af denne iboende version er tilgængelig på [`AtomicBool`]-typen via `fetch_nand`-metoden ved at lade [`Ordering::SeqCst`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis nand med den aktuelle værdi og returnerer den forrige værdi.
    ///
    /// Den stabiliserede version af denne iboende version er tilgængelig på [`AtomicBool`]-typen via `fetch_nand`-metoden ved at lade [`Ordering::Acquire`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis nand med den aktuelle værdi og returnerer den forrige værdi.
    ///
    /// Den stabiliserede version af denne iboende version er tilgængelig på [`AtomicBool`]-typen via `fetch_nand`-metoden ved at lade [`Ordering::Release`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis nand med den aktuelle værdi og returnerer den forrige værdi.
    ///
    /// Den stabiliserede version af denne iboende version er tilgængelig på [`AtomicBool`]-typen via `fetch_nand`-metoden ved at lade [`Ordering::AcqRel`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis nand med den aktuelle værdi og returnerer den forrige værdi.
    ///
    /// Den stabiliserede version af denne iboende version er tilgængelig på [`AtomicBool`]-typen via `fetch_nand`-metoden ved at lade [`Ordering::Relaxed`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitvis eller med den aktuelle værdi, der returnerer den forrige værdi.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `fetch_or`-metoden ved at sende [`Ordering::SeqCst`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis eller med den aktuelle værdi, der returnerer den forrige værdi.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `fetch_or`-metoden ved at sende [`Ordering::Acquire`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis eller med den aktuelle værdi, der returnerer den forrige værdi.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `fetch_or`-metoden ved at sende [`Ordering::Release`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis eller med den aktuelle værdi, der returnerer den forrige værdi.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `fetch_or`-metoden ved at sende [`Ordering::AcqRel`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis eller med den aktuelle værdi, der returnerer den forrige værdi.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `fetch_or`-metoden ved at sende [`Ordering::Relaxed`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitvis x eller med den aktuelle værdi, og returner den forrige værdi.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `fetch_xor`-metoden ved at sende [`Ordering::SeqCst`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis x eller med den aktuelle værdi, og returner den forrige værdi.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `fetch_xor`-metoden ved at sende [`Ordering::Acquire`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis x eller med den aktuelle værdi, og returner den forrige værdi.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `fetch_xor`-metoden ved at sende [`Ordering::Release`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis x eller med den aktuelle værdi, og returner den forrige værdi.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `fetch_xor`-metoden ved at sende [`Ordering::AcqRel`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitvis x eller med den aktuelle værdi, og returner den forrige værdi.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig på [`atomic`]-typerne via `fetch_xor`-metoden ved at sende [`Ordering::Relaxed`] som `order`.
    /// For eksempel, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maksimum med den aktuelle værdi ved hjælp af en underskrevet sammenligning.
    ///
    /// Den stabiliserede version af dette indre er tilgængelig på de [`atomic`]-signerede heltalstyper via `fetch_max`-metoden ved at sende [`Ordering::SeqCst`] som `order`.
    /// For eksempel, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum med den aktuelle værdi ved hjælp af en underskrevet sammenligning.
    ///
    /// Den stabiliserede version af dette indre er tilgængelig på de [`atomic`]-signerede heltalstyper via `fetch_max`-metoden ved at sende [`Ordering::Acquire`] som `order`.
    /// For eksempel, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum med den aktuelle værdi ved hjælp af en underskrevet sammenligning.
    ///
    /// Den stabiliserede version af dette indre er tilgængelig på de [`atomic`]-signerede heltalstyper via `fetch_max`-metoden ved at sende [`Ordering::Release`] som `order`.
    /// For eksempel, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum med den aktuelle værdi ved hjælp af en underskrevet sammenligning.
    ///
    /// Den stabiliserede version af dette indre er tilgængelig på de [`atomic`]-signerede heltalstyper via `fetch_max`-metoden ved at sende [`Ordering::AcqRel`] som `order`.
    /// For eksempel, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum med den aktuelle værdi.
    ///
    /// Den stabiliserede version af dette indre er tilgængelig på de [`atomic`]-signerede heltalstyper via `fetch_max`-metoden ved at sende [`Ordering::Relaxed`] som `order`.
    /// For eksempel, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum med den aktuelle værdi ved hjælp af en underskrevet sammenligning.
    ///
    /// Den stabiliserede version af dette indre er tilgængelig på de [`atomic`]-signerede heltalstyper via `fetch_min`-metoden ved at sende [`Ordering::SeqCst`] som `order`.
    /// For eksempel, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum med den aktuelle værdi ved hjælp af en underskrevet sammenligning.
    ///
    /// Den stabiliserede version af dette indre er tilgængelig på de [`atomic`]-signerede heltalstyper via `fetch_min`-metoden ved at sende [`Ordering::Acquire`] som `order`.
    /// For eksempel, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum med den aktuelle værdi ved hjælp af en underskrevet sammenligning.
    ///
    /// Den stabiliserede version af dette indre er tilgængelig på de [`atomic`]-signerede heltalstyper via `fetch_min`-metoden ved at sende [`Ordering::Release`] som `order`.
    /// For eksempel, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum med den aktuelle værdi ved hjælp af en underskrevet sammenligning.
    ///
    /// Den stabiliserede version af dette indre er tilgængelig på de [`atomic`]-signerede heltalstyper via `fetch_min`-metoden ved at sende [`Ordering::AcqRel`] som `order`.
    /// For eksempel, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum med den aktuelle værdi ved hjælp af en underskrevet sammenligning.
    ///
    /// Den stabiliserede version af dette indre er tilgængelig på de [`atomic`]-signerede heltalstyper via `fetch_min`-metoden ved at sende [`Ordering::Relaxed`] som `order`.
    /// For eksempel, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum med den aktuelle værdi ved hjælp af en usigneret sammenligning.
    ///
    /// Den stabiliserede version af dette indre er tilgængelig på [`atomic`] usignerede heltalstyper via `fetch_min`-metoden ved at sende [`Ordering::SeqCst`] som `order`.
    /// For eksempel, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum med den aktuelle værdi ved hjælp af en usigneret sammenligning.
    ///
    /// Den stabiliserede version af dette indre er tilgængelig på [`atomic`] usignerede heltalstyper via `fetch_min`-metoden ved at sende [`Ordering::Acquire`] som `order`.
    /// For eksempel, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum med den aktuelle værdi ved hjælp af en usigneret sammenligning.
    ///
    /// Den stabiliserede version af dette indre er tilgængelig på [`atomic`] usignerede heltalstyper via `fetch_min`-metoden ved at sende [`Ordering::Release`] som `order`.
    /// For eksempel, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum med den aktuelle værdi ved hjælp af en usigneret sammenligning.
    ///
    /// Den stabiliserede version af dette indre er tilgængelig på [`atomic`] usignerede heltalstyper via `fetch_min`-metoden ved at sende [`Ordering::AcqRel`] som `order`.
    /// For eksempel, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum med den aktuelle værdi ved hjælp af en usigneret sammenligning.
    ///
    /// Den stabiliserede version af dette indre er tilgængelig på [`atomic`] usignerede heltalstyper via `fetch_min`-metoden ved at sende [`Ordering::Relaxed`] som `order`.
    /// For eksempel, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maksimum med den aktuelle værdi ved hjælp af en usigneret sammenligning.
    ///
    /// Den stabiliserede version af dette indre er tilgængelig på [`atomic`] usignerede heltalstyper via `fetch_max`-metoden ved at sende [`Ordering::SeqCst`] som `order`.
    /// For eksempel, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum med den aktuelle værdi ved hjælp af en usigneret sammenligning.
    ///
    /// Den stabiliserede version af dette indre er tilgængelig på [`atomic`] usignerede heltalstyper via `fetch_max`-metoden ved at sende [`Ordering::Acquire`] som `order`.
    /// For eksempel, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum med den aktuelle værdi ved hjælp af en usigneret sammenligning.
    ///
    /// Den stabiliserede version af dette indre er tilgængelig på [`atomic`] usignerede heltalstyper via `fetch_max`-metoden ved at sende [`Ordering::Release`] som `order`.
    /// For eksempel, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum med den aktuelle værdi ved hjælp af en usigneret sammenligning.
    ///
    /// Den stabiliserede version af dette indre er tilgængelig på [`atomic`] usignerede heltalstyper via `fetch_max`-metoden ved at sende [`Ordering::AcqRel`] som `order`.
    /// For eksempel, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maksimum med den aktuelle værdi ved hjælp af en usigneret sammenligning.
    ///
    /// Den stabiliserede version af dette indre er tilgængelig på [`atomic`] usignerede heltalstyper via `fetch_max`-metoden ved at sende [`Ordering::Relaxed`] som `order`.
    /// For eksempel, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// `prefetch` iboende er et tip til kodegeneratoren for at indsætte en prefetch-instruktion, hvis den understøttes;ellers er det en no-op.
    /// Forhentninger har ingen indflydelse på programmets opførsel, men kan ændre dets præstationsegenskaber.
    ///
    /// `locality`-argumentet skal være et konstant heltal og er en tidsmæssig lokalitetsspecifikator, der spænder fra (0), ingen lokalitet til (3), ekstremt lokalt gemt i cache.
    ///
    ///
    /// Denne iboende har ikke en stabil modstykke.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// `prefetch` iboende er et tip til kodegeneratoren for at indsætte en prefetch-instruktion, hvis den understøttes;ellers er det en no-op.
    /// Forhentninger har ingen indflydelse på programmets opførsel, men kan ændre dets præstationsegenskaber.
    ///
    /// `locality`-argumentet skal være et konstant heltal og er en tidsmæssig lokalitetsspecifikator, der spænder fra (0), ingen lokalitet til (3), ekstremt lokalt gemt i cache.
    ///
    ///
    /// Denne iboende har ikke en stabil modstykke.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// `prefetch` iboende er et tip til kodegeneratoren for at indsætte en prefetch-instruktion, hvis den understøttes;ellers er det en no-op.
    /// Forhentninger har ingen indflydelse på programmets opførsel, men kan ændre dets præstationsegenskaber.
    ///
    /// `locality`-argumentet skal være et konstant heltal og er en tidsmæssig lokalitetsspecifikator, der spænder fra (0), ingen lokalitet til (3), ekstremt lokalt gemt i cache.
    ///
    ///
    /// Denne iboende har ikke en stabil modstykke.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// `prefetch` iboende er et tip til kodegeneratoren for at indsætte en prefetch-instruktion, hvis den understøttes;ellers er det en no-op.
    /// Forhentninger har ingen indflydelse på programmets opførsel, men kan ændre dets præstationsegenskaber.
    ///
    /// `locality`-argumentet skal være et konstant heltal og er en tidsmæssig lokalitetsspecifikator, der spænder fra (0), ingen lokalitet til (3), ekstremt lokalt gemt i cache.
    ///
    ///
    /// Denne iboende har ikke en stabil modstykke.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Et atomhegn.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig i [`atomic::fence`] ved at sende [`Ordering::SeqCst`] som `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Et atomhegn.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig i [`atomic::fence`] ved at sende [`Ordering::Acquire`] som `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Et atomhegn.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig i [`atomic::fence`] ved at sende [`Ordering::Release`] som `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Et atomhegn.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig i [`atomic::fence`] ved at sende [`Ordering::AcqRel`] som `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// En hukommelsesbarriere, der kun er kompilator.
    ///
    /// Hukommelsesadgang vil ikke blive ordnet på tværs af denne barriere af compileren, men der udsendes ingen instruktioner til den.
    /// Dette er passende til operationer på den samme tråd, der kan forebygges, f.eks. Når der interageres med signalhåndterere.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig i [`atomic::compiler_fence`] ved at sende [`Ordering::SeqCst`] som `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// En hukommelsesbarriere, der kun er kompilator.
    ///
    /// Hukommelsesadgang vil ikke blive ordnet på tværs af denne barriere af compileren, men der udsendes ingen instruktioner til den.
    /// Dette er passende til operationer på den samme tråd, der kan forebygges, f.eks. Når der interageres med signalhåndterere.
    ///
    /// Den stabiliserede version af dette indre er tilgængelig i [`atomic::compiler_fence`] ved at lade [`Ordering::Acquire`] passere som `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// En hukommelsesbarriere, der kun er kompilator.
    ///
    /// Hukommelsesadgang vil ikke blive ordnet på tværs af denne barriere af compileren, men der udsendes ingen instruktioner til den.
    /// Dette er passende til operationer på den samme tråd, der kan forebygges, f.eks. Når der interageres med signalhåndterere.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig i [`atomic::compiler_fence`] ved at sende [`Ordering::Release`] som `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// En hukommelsesbarriere, der kun er kompilator.
    ///
    /// Hukommelsesadgang vil ikke blive ordnet på tværs af denne barriere af compileren, men der udsendes ingen instruktioner til den.
    /// Dette er passende til operationer på den samme tråd, der kan forebygges, f.eks. Når der interageres med signalhåndterere.
    ///
    /// Den stabiliserede version af dette iboende er tilgængelig i [`atomic::compiler_fence`] ved at sende [`Ordering::AcqRel`] som `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Magisk iboende, der får sin betydning fra attributter knyttet til funktionen.
    ///
    /// For eksempel bruger dataflow dette til at indsprøjte statiske påstande, så `rustc_peek(potentially_uninitialized)` faktisk ville dobbelttjekke, at dataflow faktisk beregnede, at det ikke var initialiseret på det tidspunkt i kontrolflowet.
    ///
    ///
    /// Dette iboende bør ikke bruges uden for compileren.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Afbryder udførelsen af processen.
    ///
    /// En mere brugervenlig og stabil version af denne handling er [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Informerer optimizer om, at dette punkt i koden ikke kan nås, hvilket muliggør yderligere optimeringer.
    ///
    /// NB, dette er meget forskelligt fra `unreachable!()` makroen: I modsætning til makroen, som panics, når den udføres, er det *udefineret adfærd* at nå kode markeret med denne funktion.
    ///
    ///
    /// Den stabiliserede version af dette iboende er [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Informerer optimizer om, at en tilstand altid er sand.
    /// Hvis betingelsen er falsk, er adfærden udefineret.
    ///
    /// Der genereres ingen kode til dette iboende, men optimeringsprogrammet vil forsøge at bevare den (og dens tilstand) mellem passeringer, hvilket kan forstyrre optimering af omgivende kode og reducere ydeevnen.
    /// Det bør ikke bruges, hvis invarianten kan blive opdaget af optimeren alene, eller hvis den ikke muliggør nogen væsentlige optimeringer.
    ///
    /// Denne iboende har ikke en stabil modstykke.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Tip til kompilatoren, at branch-tilstand sandsynligvis vil være sand.
    /// Returnerer den værdi, der er sendt til den.
    ///
    /// Enhver anden anvendelse end med `if`-udsagn vil sandsynligvis ikke have nogen effekt.
    ///
    /// Denne iboende har ikke en stabil modstykke.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Tip til kompilatoren, at branch-tilstand sandsynligvis er falsk.
    /// Returnerer den værdi, der er sendt til den.
    ///
    /// Enhver anden anvendelse end med `if`-udsagn vil sandsynligvis ikke have nogen effekt.
    ///
    /// Denne iboende har ikke en stabil modstykke.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Udfører en breakpoint-fælde til inspektion af en debugger.
    ///
    /// Denne iboende har ikke en stabil modstykke.
    pub fn breakpoint();

    /// Størrelsen på en type i byte.
    ///
    /// Mere specifikt er dette forskydningen i byte mellem på hinanden følgende emner af samme type, herunder justeringspolstring.
    ///
    ///
    /// Den stabiliserede version af dette iboende er [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Den mindste justering af en type.
    ///
    /// Den stabiliserede version af dette iboende er [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Den foretrukne tilpasning af en type.
    ///
    /// Denne iboende har ikke en stabil modstykke.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Størrelsen på den refererede værdi i byte.
    ///
    /// Den stabiliserede version af dette iboende er [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Den krævede justering af den refererede værdi.
    ///
    /// Den stabiliserede version af dette iboende er [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Får en statisk strengskive indeholdende navnet på en type.
    ///
    /// Den stabiliserede version af dette iboende er [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Får et id, der er globalt unikt for den angivne type.
    /// Denne funktion returnerer den samme værdi for en type uanset hvilken crate den påberåbes i.
    ///
    ///
    /// Den stabiliserede version af dette iboende er [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// En vagt for usikre funktioner, der aldrig kan udføres, hvis `T` er ubeboet:
    /// Dette vil statisk enten panic eller ikke gøre noget.
    ///
    /// Denne iboende har ikke en stabil modstykke.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// En vagt for usikre funktioner, der aldrig kan udføres, hvis `T` ikke tillader initialisering af nul: Dette vil statisk enten panic eller intet gøre.
    ///
    ///
    /// Denne iboende har ikke en stabil modstykke.
    pub fn assert_zero_valid<T>();

    /// En vagt for usikre funktioner, der aldrig kan udføres, hvis `T` har ugyldige bitmønstre: Dette vil statisk enten panic eller gøre ingenting.
    ///
    ///
    /// Denne iboende har ikke en stabil modstykke.
    pub fn assert_uninit_valid<T>();

    /// Får en henvisning til en statisk `Location`, der angiver, hvor den blev kaldt.
    ///
    /// Overvej at bruge [`core::panic::Location::caller`](crate::panic::Location::caller) i stedet.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Flytter en værdi uden for omfanget uden at køre droplim.
    ///
    /// Dette eksisterer udelukkende for [`mem::forget_unsized`];normal `forget` bruger `ManuallyDrop` i stedet.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Genfortolker bits af en værdi af en type som en anden type.
    ///
    /// Begge typer skal have samme størrelse.
    /// Hverken originalen eller resultatet kan være en [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` svarer semantisk til en bitvis bevægelse af en type til en anden.Den kopierer bitene fra kildeværdien til destinationsværdien og glemmer derefter originalen.
    /// Det svarer til Cs `memcpy` under emhætten, ligesom `transmute_copy`.
    ///
    /// Fordi `transmute` er en biværdibetjening, er justering af *transmuterede værdier i sig selv* ikke et problem.
    /// Som med enhver anden funktion sikrer compileren allerede, at både `T` og `U` er korrekt justeret.
    /// Når der transmitteres værdier, der *peger andetsteds*(såsom markører, referencer, felter ...), skal den, der ringer, dog sikre korrekt tilpasning af de pegede værdier.
    ///
    /// `transmute` er **utroligt** usikker.Der er et stort antal måder at forårsage [undefined behavior][ub] med denne funktion.`transmute` skal være den absolutte sidste udvej.
    ///
    /// [nomicon](../../nomicon/transmutes.html) har yderligere dokumentation.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Der er et par ting, som `transmute` virkelig er nyttigt til.
    ///
    /// Sådan omdannes en markør til en funktionsmarkør.Dette er *ikke* bærbart til maskiner, hvor funktionspegere og datapekere har forskellige størrelser.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Forlængelse af en levetid eller forkortelse af en uændret levetid.Dette er avanceret, meget usikkert Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Fortvivl ikke: mange anvendelser af `transmute` kan opnås på andre måder.
    /// Nedenfor er almindelige anvendelser af `transmute`, som kan erstattes med mere sikre konstruktioner.
    ///
    /// Drejning af rå bytes(`&[u8]`) til `u32`, `f64` osv .:
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // brug `u32::from_ne_bytes` i stedet
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // eller brug `u32::from_le_bytes` eller `u32::from_be_bytes` til at specificere sluttheden
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Sådan omdannes en markør til en `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Brug i stedet en `as`-rollebesætning
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Sådan omdannes en `*mut T` til en `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Brug en reborrow i stedet
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Sådan omdannes en `&mut T` til en `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Sæt nu `as` sammen og genlån, bemærk, at kædingen af `as` `as` ikke er i transit
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Sådan omdannes en `&str` til en `&[u8]`:
    ///
    /// ```
    /// // dette er ikke en god måde at gøre dette på.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Du kan bruge `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Eller brug bare en byte-streng, hvis du har kontrol over strengen bogstaveligt
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Sådan omdannes en `Vec<&T>` til en `Vec<Option<&T>>`.
    ///
    /// For at transmutere den indre type af indholdet af en container, skal du sørge for ikke at krænke nogen af containerens invarianter.
    /// For `Vec` betyder det, at både størrelsen *og justeringen* af de indre typer skal matche.
    /// Andre containere kan stole på størrelsen på typen, tilpasningen eller endda `TypeId`, i hvilket tilfælde transmutering overhovedet ikke ville være mulig uden at krænke containerinvarianterne.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // klon vector, da vi vil genbruge dem senere
    /// let v_clone = v_orig.clone();
    ///
    /// // Brug af transmute: dette er afhængig af det uspecificerede datalayout af `Vec`, hvilket er en dårlig idé og kan forårsage udefineret adfærd.
    /////
    /// // Det er dog ingen kopi.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Dette er den foreslåede, sikre måde.
    /// // Det kopierer dog hele vector til et nyt array.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Dette er den rigtige kopi, usikre måde at "transmuting" en `Vec` på uden at stole på datalayoutet.
    /// // I stedet for bogstaveligt talt at ringe til `transmute` udfører vi en pointer cast, men med hensyn til at konvertere den originale indre type (`&i32`) til den nye (`Option<&i32>`) har dette alle de samme forbehold.
    /////
    /// // Ud over ovenstående oplysninger, se også [`from_raw_parts`]-dokumentationen.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Opdater dette, når vec_into_raw_parts er stabiliseret.
    ///     // Sørg for, at den originale vector ikke tabes.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Implementering af `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Der er flere måder at gøre dette på, og der er flere problemer med følgende (transmute)-måde.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // første: transmute er ikke typesikker;alt det kontrollerer er, at T og
    ///         // U er af samme størrelse.
    ///         // For det andet lige her har du to mutable referencer, der peger på den samme hukommelse.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Dette slipper af med sikkerhedsproblemerne;`&mut *` vil* kun *give dig en `&mut T` fra en `&mut T` eller `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // dog har du stadig to ændrede referencer, der peger på den samme hukommelse.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Sådan gør standardbiblioteket det.
    /// // Dette er den bedste metode, hvis du har brug for at gøre noget som dette
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Dette har nu tre ændrede referencer, der peger på samme hukommelse.`slice`, rværdien ret.0 og rværdien ret.1.
    ///         // `slice` bruges aldrig efter `let ptr = ...`, og man kan derfor behandle det som "dead", og derfor har man kun to ægte mutable skiver.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Selvom dette gør den iboende konst stabil, har vi nogle brugerdefinerede koder i konst fn
    // kontrol, der forhindrer brugen inden for `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Returnerer `true`, hvis den aktuelle type angivet som `T` kræver droplim;returnerer `false`, hvis den faktiske type, der leveres til `T`, implementerer `Copy`.
    ///
    ///
    /// Hvis den aktuelle type hverken kræver droplim eller implementerer `Copy`, er returværdien af denne funktion uspecificeret.
    ///
    /// Den stabiliserede version af dette iboende er [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Beregner forskydningen fra en markør.
    ///
    /// Dette er implementeret som et iboende for at undgå at konvertere til og fra et heltal, da konverteringen ville smide aliasinginformation.
    ///
    /// # Safety
    ///
    /// Både start-og resulterende markør skal være enten i grænser eller en byte forbi slutningen af et tildelt objekt.
    /// Hvis en af markørerne er uden for grænserne, eller hvis der opstår aritmetisk overløb, vil enhver yderligere anvendelse af den returnerede værdi resultere i udefineret adfærd.
    ///
    ///
    /// Den stabiliserede version af dette iboende er [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Beregner forskydningen fra en markør, potentielt indpakning.
    ///
    /// Dette implementeres som et iboende for at undgå at konvertere til og fra et heltal, da konverteringen hæmmer visse optimeringer.
    ///
    /// # Safety
    ///
    /// I modsætning til `offset` iboende begrænser denne iboende ikke den resulterende markør til at pege ind i eller en byte forbi enden af et tildelt objekt, og den ombrydes med to's komplementaritmetik.
    /// Den resulterende værdi er ikke nødvendigvis gyldig til at blive brugt til faktisk at få adgang til hukommelse.
    ///
    /// Den stabiliserede version af dette iboende er [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Svarer til det passende `llvm.memcpy.p0i8.0i8.*` iboende med en størrelse på `count`*`size_of::<T>()` og en justering af
    ///
    /// `min_align_of::<T>()`
    ///
    /// Den flygtige parameter er indstillet til `true`, så den optimeres ikke, medmindre størrelsen er lig med nul.
    ///
    /// Denne iboende har ikke en stabil modstykke.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Svarer til den passende `llvm.memmove.p0i8.0i8.*` iboende, med en størrelse på `count* size_of::<T>()` og en justering på
    ///
    /// `min_align_of::<T>()`
    ///
    /// Den flygtige parameter er indstillet til `true`, så den optimeres ikke, medmindre størrelsen er lig med nul.
    ///
    /// Denne iboende har ikke en stabil modstykke.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Svarer til det passende `llvm.memset.p0i8.*` iboende med en størrelse på `count* size_of::<T>()` og en justering på `min_align_of::<T>()`.
    ///
    ///
    /// Den flygtige parameter er indstillet til `true`, så den optimeres ikke, medmindre størrelsen er lig med nul.
    ///
    /// Denne iboende har ikke en stabil modstykke.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Udfører en flygtig belastning fra `src`-markøren.
    ///
    /// Den stabiliserede version af dette iboende er [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Udfører en ustabil butik til `dst`-markøren.
    ///
    /// Den stabiliserede version af dette iboende er [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Udfører en flygtig belastning fra `src`-markøren Markøren skal ikke justeres.
    ///
    ///
    /// Denne iboende har ikke en stabil modstykke.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Udfører en ustabil butik til `dst`-markøren.
    /// Markøren skal ikke være justeret.
    ///
    /// Denne iboende har ikke en stabil modstykke.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Returnerer kvadratroden af en `f32`
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Returnerer kvadratroden af en `f64`
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Hæver en `f32` til et helt tal.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Hæver en `f64` til et helt tal.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Returnerer sinus på en `f32`.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Returnerer sinus på en `f64`.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Returnerer cosinus til en `f32`.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Returnerer cosinus til en `f64`.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Hæver en `f32` til en `f32`-effekt.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Hæver en `f64` til en `f64`-effekt.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Returnerer eksponentialet for en `f32`.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Returnerer eksponentialet for en `f64`.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Returnerer 2 hævet i kraft af en `f32`.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Returnerer 2 hævet i kraft af en `f64`.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Returnerer den naturlige logaritme for en `f32`.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Returnerer den naturlige logaritme for en `f64`.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Returnerer base 10 logaritmen til en `f32`.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Returnerer base 10 logaritmen til en `f64`.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Returnerer base 2-logaritmen for en `f32`.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Returnerer base 2-logaritmen for en `f64`.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Returnerer `a * b + c` for `f32`-værdier.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Returnerer `a * b + c` for `f64`-værdier.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Returnerer den absolutte værdi af en `f32`.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Returnerer den absolutte værdi af en `f64`.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Returnerer mindst to `f32`-værdier.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Returnerer mindst to `f64`-værdier.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Returnerer maksimalt to `f32`-værdier.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Returnerer maksimalt to `f64`-værdier.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Kopierer tegnet fra `y` til `x` til `f32`-værdier.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Kopierer tegnet fra `y` til `x` til `f64`-værdier.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Returnerer det største heltal mindre end eller lig med en `f32`.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Returnerer det største heltal mindre end eller lig med en `f64`.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Returnerer det mindste heltal større end eller lig med en `f32`.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Returnerer det mindste heltal større end eller lig med en `f64`.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Returnerer heltalets del af en `f32`.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Returnerer heltalets del af en `f64`.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Returnerer det nærmeste heltal til en `f32`.
    /// Kan hæve en unøjagtig undtagelse med flydende punkt, hvis argumentet ikke er et heltal.
    pub fn rintf32(x: f32) -> f32;
    /// Returnerer det nærmeste heltal til en `f64`.
    /// Kan hæve en unøjagtig undtagelse med flydende punkt, hvis argumentet ikke er et heltal.
    pub fn rintf64(x: f64) -> f64;

    /// Returnerer det nærmeste heltal til en `f32`.
    ///
    /// Denne iboende har ikke en stabil modstykke.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Returnerer det nærmeste heltal til en `f64`.
    ///
    /// Denne iboende har ikke en stabil modstykke.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Returnerer det nærmeste heltal til en `f32`.Afrunder halvvejs sager væk fra nul.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Returnerer det nærmeste heltal til en `f64`.Afrunder halvvejs sager væk fra nul.
    ///
    /// Den stabiliserede version af dette iboende er
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Flyttilsætning, der tillader optimeringer baseret på algebraiske regler.
    /// Kan antage, at input er endelige.
    ///
    /// Denne iboende har ikke en stabil modstykke.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Float subtraktion, der tillader optimeringer baseret på algebraiske regler.
    /// Kan antage, at input er endelige.
    ///
    /// Denne iboende har ikke en stabil modstykke.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Flydemultiplikation, der tillader optimeringer baseret på algebraiske regler.
    /// Kan antage, at input er endelige.
    ///
    /// Denne iboende har ikke en stabil modstykke.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Float division, der tillader optimeringer baseret på algebraiske regler.
    /// Kan antage, at input er endelige.
    ///
    /// Denne iboende har ikke en stabil modstykke.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Float rest, der tillader optimeringer baseret på algebraiske regler.
    /// Kan antage, at input er endelige.
    ///
    /// Denne iboende har ikke en stabil modstykke.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Konverter med LLVMs fptoui/fptosi, som muligvis returnerer undef for værdier uden for området
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Stabiliseret som [`f32::to_int_unchecked`] og [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Returnerer antallet af bit, der er indstillet i et heltal `T`
    ///
    /// De stabiliserede versioner af dette indre er tilgængelige på de heltals primitiver via `count_ones`-metoden.
    /// For eksempel,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Returnerer antallet af førende usættede bit (zeroes) i et heltal `T`.
    ///
    /// De stabiliserede versioner af dette indre er tilgængelige på de heltals primitiver via `leading_zeros`-metoden.
    /// For eksempel,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// En `x` med værdien `0` returnerer bitbredden på `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Ligesom `ctlz`, men ekstra usikker, da den returnerer `undef`, når den får en `x` med værdien `0`.
    ///
    ///
    /// Denne iboende har ikke en stabil modstykke.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Returnerer antallet af efterfølgende usættede bit (zeroes) i et heltal `T`.
    ///
    /// De stabiliserede versioner af dette indre er tilgængelige på de heltals primitiver via `trailing_zeros`-metoden.
    /// For eksempel,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// En `x` med værdien `0` returnerer bitbredden på `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Ligesom `cttz`, men ekstra usikker, da den returnerer `undef`, når den får en `x` med værdien `0`.
    ///
    ///
    /// Denne iboende har ikke en stabil modstykke.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Vender bytes i et heltal `T`.
    ///
    /// De stabiliserede versioner af dette indre er tilgængelige på de heltals primitiver via `swap_bytes`-metoden.
    /// For eksempel,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Vender bitene i et heltal type `T`.
    ///
    /// De stabiliserede versioner af dette indre er tilgængelige på de heltals primitiver via `reverse_bits`-metoden.
    /// For eksempel,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Udfører markeret heltal tilføjelse.
    ///
    /// De stabiliserede versioner af dette indre er tilgængelige på de heltals primitiver via `overflowing_add`-metoden.
    /// For eksempel,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Udfører kontrolleret heltalstraktion
    ///
    /// De stabiliserede versioner af dette indre er tilgængelige på de heltals primitiver via `overflowing_sub`-metoden.
    /// For eksempel,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Udfører kontrolleret heltalsmultiplikation
    ///
    /// De stabiliserede versioner af dette indre er tilgængelige på de heltals primitiver via `overflowing_mul`-metoden.
    /// For eksempel,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Udfører en nøjagtig opdeling, hvilket resulterer i udefineret adfærd, hvor `x % y != 0` eller `y == 0` eller `x == T::MIN && y == -1`
    ///
    ///
    /// Denne iboende har ikke en stabil modstykke.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Udfører en ukontrolleret division, hvilket resulterer i udefineret adfærd, hvor `y == 0` eller `x == T::MIN && y == -1`
    ///
    ///
    /// Sikker indpakning til dette iboende er tilgængelig på de heltals primitiver via `checked_div`-metoden.
    /// For eksempel,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Returnerer resten af en ukontrolleret division, hvilket resulterer i udefineret adfærd, når `y == 0` eller `x == T::MIN && y == -1`
    ///
    ///
    /// Sikker indpakning til dette iboende er tilgængelig på de heltals primitiver via `checked_rem`-metoden.
    /// For eksempel,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Udfører et ukontrolleret venstre skift, hvilket resulterer i udefineret adfærd, når `y < 0` eller `y >= N`, hvor N er bredden af T i bits.
    ///
    ///
    /// Sikker indpakning til dette iboende er tilgængelig på de heltals primitiver via `checked_shl`-metoden.
    /// For eksempel,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Udfører et ukontrolleret højre skift, hvilket resulterer i udefineret adfærd, når `y < 0` eller `y >= N`, hvor N er bredden af T i bit.
    ///
    ///
    /// Sikker indpakning til dette iboende er tilgængelig på de heltals primitiver via `checked_shr`-metoden.
    /// For eksempel,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Returnerer resultatet af en ikke-markeret tilføjelse, hvilket resulterer i udefineret adfærd, når `x + y > T::MAX` eller `x + y < T::MIN`.
    ///
    ///
    /// Denne iboende har ikke en stabil modstykke.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Returnerer resultatet af en ukontrolleret subtraktion, hvilket resulterer i udefineret adfærd, når `x - y > T::MAX` eller `x - y < T::MIN`.
    ///
    ///
    /// Denne iboende har ikke en stabil modstykke.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Returnerer resultatet af en ukontrolleret multiplikation, hvilket resulterer i udefineret adfærd, når `x *y > T::MAX` eller `x* y < T::MIN`.
    ///
    ///
    /// Denne iboende har ikke en stabil modstykke.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Udfører drej til venstre.
    ///
    /// De stabiliserede versioner af dette indre er tilgængelige på de heltals primitiver via `rotate_left`-metoden.
    /// For eksempel,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Udfører rotere til højre.
    ///
    /// De stabiliserede versioner af dette indre er tilgængelige på de heltals primitiver via `rotate_right`-metoden.
    /// For eksempel,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Returnerer (a + b) mod 2 <sup>N</sup>, hvor N er bredden af T i bit.
    ///
    /// De stabiliserede versioner af dette indre er tilgængelige på de heltals primitiver via `wrapping_add`-metoden.
    /// For eksempel,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Returnerer (a, b) mod 2 <sup>N</sup>, hvor N er bredden af T i bit.
    ///
    /// De stabiliserede versioner af dette indre er tilgængelige på de heltals primitiver via `wrapping_sub`-metoden.
    /// For eksempel,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Returnerer (a * b) mod 2 <sup>N</sup>, hvor N er bredden af T i bit.
    ///
    /// De stabiliserede versioner af dette indre er tilgængelige på de heltals primitiver via `wrapping_mul`-metoden.
    /// For eksempel,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Beregner `a + b`, mætter ved numeriske grænser.
    ///
    /// De stabiliserede versioner af dette indre er tilgængelige på de heltals primitiver via `saturating_add`-metoden.
    /// For eksempel,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Beregner `a - b`, mætter ved numeriske grænser.
    ///
    /// De stabiliserede versioner af dette indre er tilgængelige på de heltals primitiver via `saturating_sub`-metoden.
    /// For eksempel,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Returnerer værdien af diskriminanten for varianten i 'v';
    /// hvis `T` ikke har nogen diskriminant, returnerer `0`.
    ///
    /// Den stabiliserede version af dette iboende er [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Returnerer antallet af varianter af typen `T` støbt til en `usize`;
    /// hvis `T` ikke har nogen varianter, returnerer `0`.Ubeboede varianter tælles.
    ///
    /// Den til at være stabiliserede version af denne iboende er [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust s "try catch"-konstruktion, der påkalder funktionsmarkøren `try_fn` med datapekeren `data`.
    ///
    /// Det tredje argument er en funktion kaldet hvis der opstår en panic.
    /// Denne funktion fører datapekeren og en markør til det målspecifikke undtagelsesobjekt, der blev fanget.
    ///
    /// For mere information se kompilatorens kilde såvel som std s fangstimplementering.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Udsender en `!nontemporal`-butik i henhold til LLVM (se deres dokumenter).
    /// Vil sandsynligvis aldrig blive stabil.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Se dokumentationen til `<*const T>::offset_from` for detaljer.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Se dokumentationen til `<*const T>::guaranteed_eq` for detaljer.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Se dokumentationen til `<*const T>::guaranteed_ne` for detaljer.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Tildel ved kompileringstidspunktet.Bør ikke kaldes ved kørselstid.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Nogle funktioner er defineret her, fordi de ved et uheld blev gjort tilgængelige i dette modul på stabil.
// Se <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` falder også ind i denne kategori, men det kan ikke pakkes ind på grund af kontrollen af, at `T` og `U` har samme størrelse.)
//

/// Kontrollerer, om `ptr` er korrekt justeret i forhold til `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Kopierer `count *size_of::<T>()`-byte fra `src` til `dst`.Kilden og destinationen må* ikke * overlappe hinanden.
///
/// For hukommelsesregioner, der muligvis overlapper hinanden, skal du bruge [`copy`] i stedet.
///
/// `copy_nonoverlapping` svarer semantisk til Cs [`memcpy`], men med argumentordenen byttet.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Adfærd er udefineret, hvis nogen af følgende betingelser overtrædes:
///
/// * `src` skal være [valid] for læsning af `count * size_of::<T>()` bytes.
///
/// * `dst` skal være [valid] for skrivning af `count * size_of::<T>()`-byte.
///
/// * Både `src` og `dst` skal være korrekt justeret.
///
/// * Hukommelsesområdet, der begynder ved `src` med en størrelse på 'tælle *
///   størrelse_af: :<T>() `byte skal *ikke* overlappe hukommelsesområdet, der begynder ved `dst` med samme størrelse.
///
/// Ligesom [`read`] opretter `copy_nonoverlapping` en bitvis kopi af `T`, uanset om `T` er [`Copy`].
/// Hvis `T` ikke er [`Copy`], kan *begge* værdierne i regionen, der begynder ved `*src`, og regionen, der begynder ved `* dst`, [violate memory safety][read-ownership].
///
///
/// Bemærk, at selvom den effektivt kopierede størrelse (`count * size_of: :<T>()`) er `0`, skal markørerne være ikke-NULL og korrekt justeret.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Manuel implementering af [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Flytter alle elementerne i `src` til `dst` og efterlader `src` tomme.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Sørg for, at `dst` har tilstrækkelig kapacitet til at rumme hele `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Opkaldet til offset er altid sikkert, fordi `Vec` aldrig tildeler mere end `isize::MAX` byte.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Afkort `src` uden at tabe indholdet.
///         // Vi gør dette først for at undgå problemer i tilfælde af noget længere nede i panics.
///         src.set_len(0);
///
///         // De to regioner kan ikke overlappe hinanden, fordi mutable referencer ikke alias, og to forskellige vectors ikke kan eje den samme hukommelse.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Giv `dst` besked om, at det nu indeholder indholdet af `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Udfør kun disse kontroller ved kørselstid
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Ikke i panik for at holde codegen-påvirkningen mindre.
        abort();
    }*/

    // SIKKERHED: sikkerhedskontrakten for `copy_nonoverlapping` skal være
    // opretholdt af den, der ringer op.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Kopierer `count * size_of::<T>()`-byte fra `src` til `dst`.Kilden og destinationen kan overlappe hinanden.
///
/// Hvis kilden og destinationen *aldrig* overlapper hinanden, kan [`copy_nonoverlapping`] bruges i stedet.
///
/// `copy` svarer semantisk til Cs [`memmove`], men med argumentordenen byttet.
/// Kopiering finder sted, som om bytes blev kopieret fra `src` til et midlertidigt array og derefter kopieret fra arrayet til `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Adfærd er udefineret, hvis nogen af følgende betingelser overtrædes:
///
/// * `src` skal være [valid] for læsning af `count * size_of::<T>()` bytes.
///
/// * `dst` skal være [valid] for skrivning af `count * size_of::<T>()`-byte.
///
/// * Både `src` og `dst` skal være korrekt justeret.
///
/// Ligesom [`read`] opretter `copy` en bitvis kopi af `T`, uanset om `T` er [`Copy`].
/// Hvis `T` ikke er [`Copy`], kan brug af både værdierne i regionen, der begynder ved `*src`, og regionen, der begynder ved `* dst`, [violate memory safety][read-ownership].
///
///
/// Bemærk, at selvom den effektivt kopierede størrelse (`count * size_of: :<T>()`) er `0`, skal markørerne være ikke-NULL og korrekt justeret.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Opret effektivt en Rust vector fra en usikker buffer:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` skal være korrekt justeret efter sin type og ikke-nul.
/// /// * `ptr` skal være gyldig til læsning af `elts` sammenhængende elementer af typen `T`.
/// /// * Disse elementer må ikke bruges efter at have kaldt denne funktion, medmindre `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // SIKKERHED: Vores forudsætning sikrer, at kilden er justeret og gyldig,
///     // og `Vec::with_capacity` sikrer, at vi har brugbar plads til at skrive dem.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // SIKKERHED: Vi skabte det med denne meget kapacitet tidligere,
///     // og den tidligere `copy` har initialiseret disse elementer.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Udfør kun disse kontroller ved kørselstid
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Ikke i panik for at holde codegen-påvirkningen mindre.
        abort();
    }*/

    // SIKKERHED: sikkerhedskontrakten for `copy` skal opretholdes af den, der ringer op.
    unsafe { copy(src, dst, count) }
}

/// Indstiller `count * size_of::<T>()` byte hukommelse, der starter ved `dst` til `val`.
///
/// `write_bytes` svarer til Cs [`memset`], men indstiller `count * size_of::<T>()` bytes til `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Adfærd er udefineret, hvis nogen af følgende betingelser overtrædes:
///
/// * `dst` skal være [valid] for skrivning af `count * size_of::<T>()`-byte.
///
/// * `dst` skal være korrekt justeret.
///
/// Derudover skal den, der ringer op, sikre, at skrivning af `count * size_of::<T>()`-byte til det givne hukommelsesområde resulterer i en gyldig værdi på `T`.
/// Brug af et hukommelsesområde, der er skrevet som en `T`, der indeholder en ugyldig værdi på `T`, er udefineret adfærd.
///
/// Bemærk, at selvom den effektivt kopierede størrelse (`count * size_of: :<T>()`) er `0`, skal markøren være ikke-NULL og korrekt justeret.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Grundlæggende brug:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Oprettelse af en ugyldig værdi:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Lækager den tidligere tilbageholdte værdi ved at overskrive `Box<T>` med en nul-markør.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // På dette tidspunkt resulterer brugen eller slippe af `v` i udefineret adfærd.
/// // drop(v); // ERROR
///
/// // Selv lækker `v` "uses" det, og dermed er udefineret adfærd.
/// // mem::forget(v); // ERROR
///
/// // Faktisk er `v` ugyldig i henhold til grundlæggende type layout invarianter, så *enhver* operation, der rører ved den, er udefineret adfærd.
/////
/// // lad v2 =v;//FEJL
///
/// unsafe {
///     // Lad os i stedet lægge en gyldig værdi
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Nu er kassen i orden
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // SIKKERHED: sikkerhedskontrakten for `write_bytes` skal opretholdes af den, der ringer op.
    unsafe { write_bytes(dst, val, count) }
}