#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// En future repræsenterer en asynkron beregning.
///
/// En future er en værdi, der muligvis ikke er færdig med at beregne endnu.
/// Denne type "asynchronous value" gør det muligt for en tråd at fortsætte med at udføre nyttigt arbejde, mens den venter på, at værdien bliver tilgængelig.
///
///
/// # `poll`-metoden
///
/// Kernemetoden i future, `poll`,*forsøger* at løse future til en endelig værdi.
/// Denne metode blokerer ikke, hvis værdien ikke er klar.
/// I stedet planlægges den aktuelle opgave at blive vækket, når det er muligt at gøre yderligere fremskridt ved at `polle 'igen.
/// `context`, der sendes til `poll`-metoden, kan give en [`Waker`], som er et håndtag til at vække den aktuelle opgave.
///
/// Når du bruger en future, ringer du normalt ikke til `poll` direkte, men i stedet for `.await` værdien.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Den type værdi, der produceres ved afslutningen.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Forsøg at løse future til en endelig værdi ved at registrere den aktuelle opgave til wakeup, hvis værdien endnu ikke er tilgængelig.
    ///
    /// # Returneringsværdi
    ///
    /// Denne funktion returnerer:
    ///
    /// - [`Poll::Pending`] hvis future ikke er klar endnu
    /// - [`Poll::Ready(val)`] med resultatet `val` af denne future, hvis den blev færdig.
    ///
    /// Når en future er færdig, bør klienter ikke `poll` den igen.
    ///
    /// Når en future ikke er klar endnu, returnerer `poll` `Poll::Pending` og gemmer en klon af [`Waker`], der er kopieret fra den aktuelle [`Context`].
    /// Denne [`Waker`] vækkes derefter, når future kan gøre fremskridt.
    /// For eksempel vil en future, der venter på, at en sokkel bliver læsbar, ringe til `.clone()` på [`Waker`] og gemme den.
    /// Når et signal ankommer et andet sted, der angiver, at stikket er læsbart, kaldes [`Waker::wake`], og stikket future's opgave vækkes.
    /// Når en opgave er vækket, skal den forsøge at `poll` future igen, hvilket måske eller måske ikke producerer en endelig værdi.
    ///
    /// Bemærk, at ved flere opkald til `poll` skal kun [`Waker`] fra [`Context`], der er sendt til det seneste opkald, være planlagt til at modtage en vækning.
    ///
    /// # Runtime egenskaber
    ///
    /// Futures alene er *inaktive*;de skal være *aktivt*`afstemt` for at gøre fremskridt, hvilket betyder, at hver gang den aktuelle opgave vækkes, skal den aktivt"igen"afvente futures, som den stadig har interesse i.
    ///
    /// `poll`-funktionen kaldes ikke gentagne gange i en tæt loop-i stedet skal den kun kaldes, når future indikerer, at den er klar til at gøre fremskridt (ved at ringe til `wake()`).
    /// Hvis du er fortrolig med `poll(2)`-eller `select(2)`-syscalls på Unix, er det værd at bemærke, at futures typisk *ikke* lider de samme problemer som "all wakeups must poll all events";de ligner mere `epoll(4)`.
    ///
    /// En implementering af `poll` skal stræbe efter at vende tilbage hurtigt og bør ikke blokere.Tilbagevenden forhindrer hurtigt unødvendigt tilstopning af tråde eller hændelsesløkker.
    /// Hvis det vides på forhånd, at et opkald til `poll` kan ende med at tage et stykke tid, skal arbejdet aflades til en trådpulje (eller noget lignende) for at sikre, at `poll` kan vende tilbage hurtigt.
    ///
    /// # Panics
    ///
    /// Når en future er afsluttet (returneret `Ready` fra `poll`), kan kald til `poll`-metoden igen panic, blokere for evigt eller forårsage andre slags problemer;`Future` trait stiller ingen krav til virkningerne af et sådant opkald.
    /// Da `poll`-metoden ikke er markeret som `unsafe`, gælder Rust s sædvanlige regler: opkald må aldrig forårsage udefineret adfærd (hukommelseskorruption, forkert brug af `unsafe`-funktioner eller lignende) uanset future's tilstand.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}