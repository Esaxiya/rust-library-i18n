use crate::future::Future;

/// Konvertering til en `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// Det output, som future producerer ved afslutningen.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// Hvilken slags future forvandler vi dette til?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Opretter en future ud fra en værdi.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}