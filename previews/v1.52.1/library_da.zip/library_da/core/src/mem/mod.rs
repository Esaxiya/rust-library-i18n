//! Grundlæggende funktioner til håndtering af hukommelse.
//!
//! Dette modul indeholder funktioner til forespørgsel om størrelse og justering af typer, initialisering og manipulering af hukommelse.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Tager ejerskab og "forgets" om værdien **uden at køre dens destruktør**.
///
/// Alle ressourcer, som værdien administrerer, såsom bunkehukommelse eller et filhåndtag, vil blive hængende for evigt i en uopnåelig tilstand.Det garanterer dog ikke, at henvisninger til denne hukommelse forbliver gyldige.
///
/// * Se [`Box::leak`], hvis du vil lække hukommelse.
/// * Hvis du vil hente en rå markør til hukommelsen, se [`Box::into_raw`].
/// * Hvis du vil bortskaffe en værdi korrekt og køre dens destruktor, se [`mem::drop`].
///
/// # Safety
///
/// `forget` er ikke markeret som `unsafe`, fordi Rust s sikkerhedsgarantier ikke inkluderer en garanti for, at destruktører altid kører.
/// For eksempel kan et program oprette en referencecyklus ved hjælp af [`Rc`][rc] eller ringe til [`process::exit`][exit] for at afslutte uden at køre destruktører.
/// Således tillader `mem::forget` fra sikker kode ikke grundlæggende ændringer i Rust s sikkerhedsgarantier.
///
/// Når det er sagt, er lækagende ressourcer som hukommelse eller I/O-objekter normalt uønskede.
/// Behovet opstår i nogle specialiserede brugssager til FFI eller usikker kode, men selv da foretrækkes [`ManuallyDrop`] typisk.
///
/// Da det er tilladt at glemme en værdi, skal enhver `unsafe`-kode, du skriver, tillade denne mulighed.Du kan ikke returnere en værdi og forvente, at den, der ringer, nødvendigvis vil køre værdiens destruktor.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Den kanoniske sikre brug af `mem::forget` er at omgå en værdis destruktor implementeret af `Drop` trait.For eksempel lækker dette en `File`, dvs.
/// genvinde den plads, der er taget af variablen, men luk aldrig den underliggende systemressource:
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Dette er nyttigt, når ejerskabet af den underliggende ressource tidligere blev overført til kode uden for Rust, for eksempel ved at transmittere den rå filbeskrivelse til C-kode.
///
/// # Forholdet til `ManuallyDrop`
///
/// Mens `mem::forget` også kan bruges til at overføre *hukommelse* ejerskab, er det fejlbehæftet.
/// [`ManuallyDrop`] skal bruges i stedet.Overvej for eksempel denne kode:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Byg en `String` ved hjælp af indholdet af `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // lækker `v`, fordi hukommelsen nu styres af `s`
/// mem::forget(v);  // FEJL, v er ugyldig og må ikke overføres til en funktion
/// assert_eq!(s, "Az");
/// // `s` falder implicit og dets hukommelse afsættes.
/// ```
///
/// Der er to problemer med ovenstående eksempel:
///
/// * Hvis der blev tilføjet mere kode mellem opbygningen af `String` og påkaldelsen af `mem::forget()`, ville en panic inde i den medføre dobbelt fri, fordi den samme hukommelse håndteres af både `v` og `s`.
/// * Efter at have ringet til `v.as_mut_ptr()` og transmitteret ejerskabet af dataene til `s`, er `v`-værdien ugyldig.
/// Selv når en værdi lige flyttes til `mem::forget` (som ikke inspicerer den), har nogle typer strenge krav til deres værdier, der gør dem ugyldige, når de dingler eller ikke længere ejes.
/// Brug af ugyldige værdier på nogen måde, herunder at overføre dem til eller returnere dem fra funktioner, udgør udefineret adfærd og kan bryde antagelser fra compileren.
///
/// Skift til `ManuallyDrop` undgår begge problemer:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Inden vi adskiller `v` i dens rå dele, skal du sørge for, at den ikke falder ned!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Adskil nu `v`.Disse operationer kan ikke panic, så der kan ikke være en lækage.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Endelig skal du opbygge en `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` falder implicit og dets hukommelse afsættes.
/// ```
///
/// `ManuallyDrop` forhindrer robust dobbeltfri, fordi vi deaktiverer `v`s destruktør, inden vi gør noget andet.
/// `mem::forget()` tillader ikke dette, fordi det bruger sit argument og tvinger os kun til at ringe til det efter at have trukket alt, hvad vi har brug for, fra `v`.
/// Selv hvis der blev introduceret en panic mellem konstruktion af `ManuallyDrop` og bygning af strengen (hvilket ikke kan ske i koden som vist), ville det resultere i en lækage og ikke en dobbeltfri.
/// Med andre ord fejler `ManuallyDrop` på siden af utæthed i stedet for at fejle på siden af (dobbelt-) fald.
///
/// `ManuallyDrop` forhindrer os også i at skulle til "touch" `v` efter at have overført ejerskabet til `s`-det sidste trin i at interagere med `v` for at bortskaffe det uden at køre dets destruktor undgås helt.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Ligesom [`forget`], men accepterer også ikke-størrede værdier.
///
/// Denne funktion er bare et mellemlag, der skal fjernes, når `unsized_locals`-funktionen bliver stabiliseret.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Returnerer størrelsen på en type i byte.
///
/// Mere specifikt er dette forskydningen i bytes mellem på hinanden følgende elementer i en matrix med den elementtype inklusive justeringspolstring.
///
/// Således har `[T; n]` for enhver type `T` og længde `n` en størrelse på `n * size_of::<T>()`.
///
/// Generelt er størrelsen på en type ikke stabil på tværs af kompileringer, men specifikke typer som primitiver er.
///
/// Den følgende tabel angiver størrelsen på primitiver.
///
/// Type |størrelse_af: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// Desuden har `usize` og `isize` samme størrelse.
///
/// Typerne `*const T`, `&T`, `Box<T>`, `Option<&T>` og `Option<Box<T>>` har alle samme størrelse.
/// Hvis `T` er dimensioneret, har alle disse typer samme størrelse som `usize`.
///
/// En markørs mutabilitet ændrer ikke dens størrelse.Som sådan har `&T` og `&mut T` samme størrelse.
/// Ligeledes for `*const T` og `* mut T`.
///
/// # Størrelse på `#[repr(C)]`-genstande
///
/// `C`-repræsentationen for varer har et defineret layout.
/// Med dette layout er størrelsen på varer også stabil, så længe alle felter har en stabil størrelse.
///
/// ## Structs størrelse
///
/// For `structs` bestemmes størrelsen af følgende algoritme.
///
/// For hvert felt i strukturen bestilt efter deklarationsordre:
///
/// 1. Tilføj feltets størrelse.
/// 2. Rund den aktuelle størrelse op til det nærmeste multiplum af det næste felts [alignment].
///
/// Til sidst afrundes størrelsen på strukturen til det nærmeste multiplum af dens [alignment].
/// Justeringen af strukturen er normalt den største justering af alle dens felter;dette kan ændres ved brug af `repr(align(N))`.
///
/// I modsætning til `C` afrundes nulstørrelser ikke op til en byte i størrelse.
///
/// ## Enums størrelse
///
/// Enums, der ikke bærer andre data end den diskriminerende, har samme størrelse som C-enums på den platform, de er sammensat til.
///
/// ## Størrelse af fagforeninger
///
/// Størrelsen af en union er størrelsen på dens største felt.
///
/// I modsætning til `C` afrundes fagforeninger med nul ikke op til en byte i størrelse.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Nogle primitiver
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Nogle arrays
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Markørstørrelse lighed
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Brug af `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Størrelsen på det første felt er 1, så tilføj 1 til størrelsen.Størrelse er 1.
/// // Justeringen af det andet felt er 2, så tilføj 1 til størrelsen for polstring.Størrelse er 2.
/// // Størrelsen på det andet felt er 2, så tilføj 2 til størrelsen.Størrelse er 4.
/// // Justeringen af det tredje felt er 1, så tilføj 0 til størrelsen for polstring.Størrelse er 4.
/// // Størrelsen på det tredje felt er 1, så tilføj 1 til størrelsen.Størrelse er 5.
/// // Endelig er strukturens justering 2 (fordi den største justering blandt dens felter er 2), så tilføj 1 til størrelsen til polstring.
/// // Størrelse er 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tuple-strukturer følger de samme regler.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Bemærk, at omorganisering af felterne kan sænke størrelsen.
/// // Vi kan fjerne begge polstringsbyte ved at sætte `third` før `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Unionstørrelse er størrelsen på det største felt.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Returnerer størrelsen på den pegede værdi i byte.
///
/// Dette er normalt det samme som `size_of::<T>()`.
/// Men når `T`*ikke har* nogen statisk kendt størrelse, f.eks. En skive [`[T]`][slice] eller en [trait object], kan `size_of_val` bruges til at få den dynamisk kendte størrelse.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // SIKKERHED: `val` er en reference, så det er en gyldig rå pointer
    unsafe { intrinsics::size_of_val(val) }
}

/// Returnerer størrelsen på den pegede værdi i byte.
///
/// Dette er normalt det samme som `size_of::<T>()`.Imidlertid, når `T`*ikke har* nogen statisk kendt størrelse, f.eks. Et stykke [`[T]`][slice] eller en [trait object], så kan `size_of_val_raw` bruges til at få den dynamisk kendte størrelse.
///
/// # Safety
///
/// Denne funktion er kun sikker at ringe til, hvis følgende betingelser gælder:
///
/// - Hvis `T` er `Sized`, er denne funktion altid sikker at ringe til.
/// - Hvis den usikrede hale på `T` er:
///     - en [slice], så skal længden af skivehalen være et initialiseret heltal, og størrelsen på *hele værdien*(dynamisk hale-længde + statisk størrelse præfiks) skal passe i `isize`.
///     - en [trait object], så skal vtabeldelen af markøren pege på en gyldig vtabel, der er erhvervet af en ikke-størrelse tvang, og størrelsen på *hele værdien*(dynamisk hale længde + statisk størrelse præfiks) skal passe i `isize`.
///
///     - en (unstable) [extern type], så er denne funktion altid sikker at ringe til, men kan panic eller på anden måde returnere den forkerte værdi, da den eksterne types layout ikke er kendt.
///     Dette er den samme adfærd som [`size_of_val`] på en henvisning til en type med en ekstern type hale.
///     - ellers er det konservativt ikke tilladt at kalde denne funktion.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SIKKERHED: den, der ringer op, skal angive en gyldig rå pointer
    unsafe { intrinsics::size_of_val(val) }
}

/// Returnerer den [ABI]-krævede minimumsjustering af en type.
///
/// Hver henvisning til en værdi af typen `T` skal være et multiplum af dette tal.
///
/// Dette er den justering, der bruges til strukturfelter.Det kan være mindre end den foretrukne justering.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Returnerer den [ABI] krævede mindste justering af typen af den værdi, som `val` peger på.
///
/// Hver henvisning til en værdi af typen `T` skal være et multiplum af dette tal.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // SIKKERHED: val er en reference, så det er en gyldig rå pointer
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Returnerer den [ABI]-krævede minimumsjustering af en type.
///
/// Hver henvisning til en værdi af typen `T` skal være et multiplum af dette tal.
///
/// Dette er den justering, der bruges til strukturfelter.Det kan være mindre end den foretrukne justering.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Returnerer den [ABI] krævede mindste justering af typen af den værdi, som `val` peger på.
///
/// Hver henvisning til en værdi af typen `T` skal være et multiplum af dette tal.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // SIKKERHED: val er en reference, så det er en gyldig rå pointer
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Returnerer den [ABI] krævede mindste justering af typen af den værdi, som `val` peger på.
///
/// Hver henvisning til en værdi af typen `T` skal være et multiplum af dette tal.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Denne funktion er kun sikker at ringe til, hvis følgende betingelser gælder:
///
/// - Hvis `T` er `Sized`, er denne funktion altid sikker at ringe til.
/// - Hvis den usikrede hale på `T` er:
///     - en [slice], så skal længden af skivehalen være et initialiseret heltal, og størrelsen på *hele værdien*(dynamisk hale-længde + statisk størrelse præfiks) skal passe i `isize`.
///     - en [trait object], så skal vtabeldelen af markøren pege på en gyldig vtabel, der er erhvervet af en ikke-størrelse tvang, og størrelsen på *hele værdien*(dynamisk hale længde + statisk størrelse præfiks) skal passe i `isize`.
///
///     - en (unstable) [extern type], så er denne funktion altid sikker at ringe til, men kan panic eller på anden måde returnere den forkerte værdi, da den eksterne types layout ikke er kendt.
///     Dette er den samme adfærd som [`align_of_val`] på en henvisning til en type med en ekstern type hale.
///     - ellers er det konservativt ikke tilladt at kalde denne funktion.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // SIKKERHED: den, der ringer op, skal angive en gyldig rå pointer
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Returnerer `true`, hvis faldværdier af typen `T` betyder noget.
///
/// Dette er rent et optimeringstip og kan implementeres konservativt:
/// det returnerer muligvis `true` for typer, der faktisk ikke behøver at blive droppet.
/// Som sådan vil altid returnere `true` være en gyldig implementering af denne funktion.Men hvis denne funktion faktisk returnerer `false`, kan du være sikker på at droppe `T` ikke har nogen bivirkning.
///
/// Implementeringer på lavt niveau af ting som samlinger, der skal slippe deres data manuelt, skal bruge denne funktion for at undgå unødigt forsøg på at slippe alt deres indhold, når de ødelægges.
///
/// Dette gør muligvis ikke en forskel i udgivelsesbygninger (hvor en sløjfe, der ikke har nogen bivirkninger, let opdages og elimineres), men er ofte en stor gevinst for fejlfindingsbygninger.
///
/// Bemærk, at [`drop_in_place`] allerede udfører denne kontrol, så hvis din arbejdsbyrde kan reduceres til et lille antal [`drop_in_place`]-opkald, er det unødvendigt at bruge dette.
/// Bemærk især, at du kan [`drop_in_place`] et stykke, og det vil gøre en enkelt behovsdrop-kontrol for alle værdier.
///
/// Typer som Vec er derfor bare `drop_in_place(&mut self[..])` uden at bruge `needs_drop` eksplicit.
/// Typer som [`HashMap`] skal derimod slippe værdier en ad gangen og skal bruge denne API.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Her er et eksempel på, hvordan en samling kan gøre brug af `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // slip dataene
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Returnerer værdien af typen `T`, der er repræsenteret af byte-mønsteret med nul.
///
/// Dette betyder, at f.eks. Ikke polstringsbyte i `(u8, u16)` nulstilles.
///
/// Der er ingen garanti for, at et byte-mønster helt nul repræsenterer en gyldig værdi af en eller anden type `T`.
/// F.eks. Er byte-mønsteret helt nul ikke en gyldig værdi for referencetyper (`&T`, `&mut T`) og funktionspegere.
/// Brug af `zeroed` på sådanne typer forårsager øjeblikkelig [undefined behavior][ub], fordi [the Rust compiler assumes][inv], at der altid er en gyldig værdi i en variabel, som den anser for initialiseret.
///
///
/// Dette har den samme effekt som [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Det er undertiden nyttigt for FFI, men bør generelt undgås.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Korrekt brug af denne funktion: initialisering af et heltal med nul.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Forkert* brug af denne funktion: initialisering af en reference med nul.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Udefineret adfærd!
/// let _y: fn() = unsafe { mem::zeroed() }; // Og igen!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // SIKKERHED: den, der ringer op, skal garantere, at en alt-nul-værdi er gyldig for `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Omgår Rust s normale hukommelsesinitialiseringskontrol ved at foregive at producere en værdi af typen `T`, mens du slet ikke gør noget.
///
/// **Denne funktion er udfaset.** Brug [`MaybeUninit<T>`] i stedet.
///
/// Årsagen til afskrivning er, at funktionen stort set ikke kan bruges korrekt: den har samme effekt som [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Som [`assume_init` documentation][assume_init] forklarer, er [the Rust compiler assumes][inv], at værdierne initialiseres korrekt.
/// Som en konsekvens kaldes f.eks
/// `mem::uninitialized::<bool>()` forårsager øjeblikkelig udefineret adfærd for returnering af en `bool`, der ikke helt sikkert hverken er `true` eller `false`.
/// Værre, virkelig uinitialiseret hukommelse som det, der returneres her, er speciel, fordi compileren ved, at den ikke har en fast værdi.
/// Dette gør det udefineret adfærd at have ikke-initialiserede data i en variabel, selvom variablen har en heltalstype.
/// (Bemærk, at reglerne omkring ikke-initialiserede heltal endnu ikke er afsluttet, men indtil de er det, tilrådes det at undgå dem.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // SIKKERHED: den, der ringer op, skal garantere, at en enhedsværdi er gyldig for `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Bytter værdierne på to mutable placeringer uden at deinitialisere nogen af dem.
///
/// * Hvis du vil bytte med en standard-eller dummy-værdi, se [`take`].
/// * Hvis du vil bytte med en bestået værdi og returnere den gamle værdi, se [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // SIKKERHED: de rå pointer er oprettet ud fra sikre, ændrede referencer, der tilfredsstiller alle
    // begrænsninger på `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Erstatter `dest` med standardværdien `T` og returnerer den forrige `dest`-værdi.
///
/// * Se [`swap`], hvis du vil erstatte værdierne for to variabler.
/// * Hvis du vil erstatte med en bestået værdi i stedet for standardværdien, se [`replace`].
///
/// # Examples
///
/// Et simpelt eksempel:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` tillader at tage ejerskab af et strukturfelt ved at erstatte det med en "empty"-værdi.
/// Uden `take` kan du løbe ind i problemer som disse:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Bemærk, at `T` ikke nødvendigvis implementerer [`Clone`], så det kan ikke engang klone og nulstille `self.buf`.
/// Men `take` kan bruges til at adskille den oprindelige værdi af `self.buf` fra `self`, så den kan returneres:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Flytter `src` ind i den refererede `dest` og returnerer den forrige `dest`-værdi.
///
/// Ingen af værdierne tabes.
///
/// * Se [`swap`], hvis du vil erstatte værdierne for to variabler.
/// * Se [`take`], hvis du vil erstatte den med en standardværdi.
///
/// # Examples
///
/// Et simpelt eksempel:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` tillader forbrug af et strukturfelt ved at erstatte det med en anden værdi.
/// Uden `replace` kan du løbe ind i problemer som disse:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Bemærk, at `T` ikke nødvendigvis implementerer [`Clone`], så vi kan ikke engang klone `self.buf[i]` for at undgå flytningen.
/// Men `replace` kan bruges til at adskille den oprindelige værdi ved dette indeks fra `self`, så den kan returneres:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // SIKKERHED: Vi læser fra `dest` men skriver direkte `src` ind i den bagefter,
    // sådan at den gamle værdi ikke duplikeres.
    // Intet tabes, og intet her kan panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Bortskaffer en værdi.
///
/// Dette gøres ved at kalde argumentets implementering af [`Drop`][drop].
///
/// Dette gør effektivt intet for typer, der implementerer `Copy`, f.eks
/// integers.
/// Sådanne værdier kopieres og _then_ flyttes ind i funktionen, så værdien fortsætter efter dette funktionsopkald.
///
///
/// Denne funktion er ikke magisk;det er bogstaveligt defineret som
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Da `_x` flyttes ind i funktionen, slettes den automatisk, før funktionen vender tilbage.
///
/// [drop]: Drop
///
/// # Examples
///
/// Grundlæggende brug:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // slip eksplicit vector
/// ```
///
/// Da [`RefCell`] håndhæver lånereglerne under kørsel, kan `drop` frigive en [`RefCell`]-lån:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // opgive den mutable lån på dette slot
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// Heltal og andre typer, der implementerer [`Copy`], påvirkes ikke af `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // en kopi af `x` flyttes og droppes
/// drop(y); // en kopi af `y` flyttes og droppes
///
/// println!("x: {}, y: {}", x, y.0); // stadig tilgængelig
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Fortolker `src` som at have typen `&U` og læser derefter `src` uden at flytte den indeholdte værdi.
///
/// Denne funktion antager usikkert, at markøren `src` er gyldig for [`size_of::<U>`][size_of]-byte ved at transmittere `&T` til `&U` og derefter læse `&U` (bortset fra at dette gøres på en måde, der er korrekt, selv når `&U` stiller strengere justeringskrav end `&T`).
/// Det vil også usikkert oprette en kopi af den indeholdte værdi i stedet for at flytte ud af `src`.
///
/// Det er ikke en kompileringstidsfejl, hvis `T` og `U` har forskellige størrelser, men det opfordres stærkt til kun at påkalde denne funktion, hvor `T` og `U` har samme størrelse.Denne funktion udløser [undefined behavior][ub], hvis `U` er større end `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Kopier dataene fra 'foo_array' og behandl dem som en 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Rediger de kopierede data
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Indholdet af 'foo_array' skulle ikke have ændret sig
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Hvis U har et højere justeringskrav, er src muligvis ikke passende justeret.
    if align_of::<U>() > align_of::<T>() {
        // SIKKERHED: `src` er en reference, som garanteret er gyldig til læsning.
        // Den, der ringer op, skal garantere, at den faktiske transmutation er sikker.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // SIKKERHED: `src` er en reference, som garanteret er gyldig til læsning.
        // Vi kontrollerede lige, at `src as *const U` var korrekt justeret.
        // Den, der ringer op, skal garantere, at den faktiske transmutation er sikker.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Uigennemsigtig type, der repræsenterer diskriminanten af en enum.
///
/// Se [`discriminant`]-funktionen i dette modul for mere information.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Disse trait-implementeringer kan ikke udledes, fordi vi ikke ønsker nogen grænser for T.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Returnerer en værdi, der entydigt identificerer enum-varianten i `v`.
///
/// Hvis `T` ikke er enum, vil kald af denne funktion ikke resultere i udefineret adfærd, men returværdien er ikke specificeret.
///
///
/// # Stability
///
/// Diskriminanten af en enum-variant kan ændre sig, hvis definitionen af enum ændres.
/// En diskriminant af en eller anden variant skifter ikke mellem kompileringer med den samme kompilator.
///
/// # Examples
///
/// Dette kan bruges til at sammenligne enums, der bærer data, mens man ser bort fra de faktiske data:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Returnerer antallet af varianter i enumtypen `T`.
///
/// Hvis `T` ikke er enum, vil kald af denne funktion ikke resultere i udefineret adfærd, men returværdien er ikke specificeret.
/// Ligeledes, hvis `T` er et enum med flere varianter end `usize::MAX`, er returværdien ikke specificeret.
/// Ubeboede varianter tælles.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}