use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// En indpakningstype til konstruktion af ikke-initialiserede forekomster af `T`.
///
/// # Initialisering invariant
///
/// Compileren antager generelt, at en variabel initialiseres korrekt i henhold til kravene til variabelens type.For eksempel skal en variabel af referencetypen være justeret og ikke-NULL.
/// Dette er en invariant, der skal *altid* opretholdes, selv i usikker kode.
/// Som en konsekvens forårsager nul initialisering af en variabel af referencetype øjeblikkelig [undefined behavior][ub], uanset om denne reference nogensinde bliver vant til at få adgang til hukommelse:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // udefineret adfærd!⚠️
/// // Den tilsvarende kode med `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // udefineret adfærd!⚠️
/// ```
///
/// Dette udnyttes af compileren til forskellige optimeringer, såsom fjernelse af kørselstimer og optimering af `enum`-layout.
///
/// På samme måde kan helt uinitialiseret hukommelse have noget indhold, mens en `bool` altid skal være `true` eller `false`.Derfor er oprettelse af en ikke-initialiseret `bool` udefineret adfærd:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // udefineret adfærd!⚠️
/// // Den tilsvarende kode med `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // udefineret adfærd!⚠️
/// ```
///
/// Desuden er ikke-initialiseret hukommelse speciel, fordi den ikke har en fast værdi ("fixed" betyder "it won't change without being written to").Læsning af den samme ikke-initialiserede byte flere gange kan give forskellige resultater.
/// Dette gør det udefineret adfærd at have ikke-initialiserede data i en variabel, selvom variablen har en heltalstype, som ellers kan indeholde ethvert *fast* bitmønster:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // udefineret adfærd!⚠️
/// // Den tilsvarende kode med `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // udefineret adfærd!⚠️
/// ```
/// (Bemærk, at reglerne omkring ikke-initialiserede heltal endnu ikke er afsluttet, men indtil de er det, tilrådes det at undgå dem.)
///
/// Derudover skal du huske, at de fleste typer har yderligere invarianter ud over blot at blive betragtet som initialiseret på typeniveau.
/// For eksempel betragtes en `1`-initialiseret [`Vec<T>`] som initialiseret (under den nuværende implementering; dette udgør ikke en stabil garanti), fordi det eneste krav, som kompilatoren ved om det, er, at datapegeren skal være ikke-nul.
/// Oprettelse af en sådan `Vec<T>` forårsager ikke *øjeblikkelig* udefineret adfærd, men vil medføre udefineret adfærd med de mest sikre handlinger (inklusive at droppe den).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` tjener til at muliggøre usikker kode til at håndtere ikke-initialiserede data.
/// Det er et signal til compileren, der angiver, at dataene her muligvis *ikke* initialiseres:
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Opret en eksplicit uinitialiseret reference.
/// // Compileren ved, at data inde i en `MaybeUninit<T>` kan være ugyldige, og derfor er dette ikke UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Indstil den til en gyldig værdi.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Uddrag initialiserede data-dette er kun tilladt *efter* korrekt initialisering af `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Compileren ved så ikke at foretage forkerte antagelser eller optimeringer af denne kode.
///
/// Du kan tænke på `MaybeUninit<T>` som at være lidt ligesom `Option<T>`, men uden nogen sporing af kørselstiden og uden nogen sikkerhedskontrol.
///
/// ## out-pointers
///
/// Du kan bruge `MaybeUninit<T>` til at implementere "out-pointers": i stedet for at returnere data fra en funktion, skal du sende det en markør til noget (uninitialized)-hukommelse for at sætte resultatet i det.
/// Dette kan være nyttigt, når det er vigtigt for den, der ringer op, at styre, hvordan den hukommelse, resultatet gemmes i, tildeles, og du vil undgå unødvendige bevægelser.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` taber ikke det gamle indhold, hvilket er vigtigt.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Nu ved vi, at `v` er initialiseret!Dette sikrer også, at vector falder ordentligt.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Initialisering af et array element-for-element
///
/// `MaybeUninit<T>` kan bruges til at initialisere et stort array element-for-element:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Opret et ikke-initialiseret array af `MaybeUninit`.
///     // `assume_init` er sikker, fordi den type, vi hævder at have initialiseret her, er en flok `MaybeUninit`s, som ikke kræver initialisering.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // At droppe en `MaybeUninit` gør ingenting.
///     // Brug af rå pointer-tildeling i stedet for `ptr::write` medfører således ikke, at den gamle ikke-initialiserede værdi droppes.
/////
///     // Også hvis der er en panic under denne loop, har vi en hukommelseslækage, men der er ikke noget hukommelsessikkerhedsproblem.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Alt er initialiseret.
///     // Transmuter array til den initialiserede type.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Du kan også arbejde med delvist initialiserede arrays, som kan findes i datastrukturer på lavt niveau.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Opret et ikke-initialiseret array af `MaybeUninit`.
/// // `assume_init` er sikker, fordi den type, vi hævder at have initialiseret her, er en flok `MaybeUninit`s, som ikke kræver initialisering.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Tæl antallet af elementer, vi har tildelt.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // For hvert element i arrayet skal du slippe, hvis vi tildelte det.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Initialisering af en struktur felt for felt
///
/// Du kan bruge `MaybeUninit<T>` og [`std::ptr::addr_of_mut`]-makroen til at initialisere strukturer felt for felt:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Initialisering af `name`-feltet
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Initialisering af `list`-feltet Hvis der er en panic her, lækker `String` i `name`-feltet.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Alle felter initialiseres, så vi kalder `assume_init` for at få en initialiseret Foo.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` er garanteret at have samme størrelse, justering og ABI som `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Husk dog, at en type *indeholdende* en `MaybeUninit<T>` ikke nødvendigvis er det samme layout;Rust garanterer generelt ikke, at felterne i en `Foo<T>` har samme rækkefølge som en `Foo<U>`, selvom `T` og `U` har samme størrelse og justering.
///
/// Desuden fordi en hvilken som helst bitværdi er gyldig for en `MaybeUninit<T>`, kan kompilatoren ikke anvende non-zero/niche-filling-optimeringer, hvilket potentielt resulterer i en større størrelse:
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Hvis `T` er FFI-sikkert, er det også `MaybeUninit<T>`.
///
/// Mens `MaybeUninit` er `#[repr(transparent)]` (hvilket indikerer, at det garanterer samme størrelse, justering og ABI som `T`), ændrer dette ikke * nogen af de tidligere forbehold.
/// `Option<T>` og `Option<MaybeUninit<T>>` kan stadig have forskellige størrelser, og typer, der indeholder et felt af typen `T`, kan være anbragt (og dimensioneret) forskelligt, end hvis dette felt var `MaybeUninit<T>`.
/// `MaybeUninit` er en unionstype, og `#[repr(transparent)]` på fagforeninger er ustabil (se [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Over tid kan de nøjagtige garantier for `#[repr(transparent)]` på fagforeninger udvikle sig, og `MaybeUninit` forbliver måske eller måske ikke `#[repr(transparent)]`.
/// Når det er sagt, vil `MaybeUninit<T>`*altid* garantere, at den har samme størrelse, justering og ABI som `T`;det er bare sådan, at den måde, `MaybeUninit` implementerer den garanti på, kan udvikle sig.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang vare, så vi kan pakke andre typer ind i det.Dette er nyttigt for generatorer.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Vi ringer ikke til `T::clone()`, vi kan ikke vide, om vi er initialiseret nok til det.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Opretter en ny `MaybeUninit<T>` initialiseret med den givne værdi.
    /// Det er sikkert at ringe til [`assume_init`] på returværdien af denne funktion.
    ///
    /// Bemærk at at slippe en `MaybeUninit<T>` aldrig vil kalde `T`s drop code.
    /// Det er dit ansvar at sikre, at `T` droppes, hvis den blev initialiseret.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Opretter en ny `MaybeUninit<T>` i uinitialiseret tilstand.
    ///
    /// Bemærk at at slippe en `MaybeUninit<T>` aldrig vil kalde `T`s drop code.
    /// Det er dit ansvar at sikre, at `T` droppes, hvis den blev initialiseret.
    ///
    /// Se [type-level documentation][MaybeUninit] for nogle eksempler.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Opret et nyt array med `MaybeUninit<T>`-emner i uinitialiseret tilstand.
    ///
    /// Note: i en future Rust-version kan denne metode blive unødvendig, når matrix bogstavelig syntaks tillader [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Eksemplet nedenfor kunne derefter bruge `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Returnerer et (muligvis mindre) udsnit af data, der faktisk blev læst
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // SIKKERHED: En ikke-initialiseret `[MaybeUninit<_>; LEN]` er gyldig.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Opretter en ny `MaybeUninit<T>` i uinitialiseret tilstand, hvor hukommelsen er fyldt med `0` bytes.Det afhænger af `T`, om det allerede giver korrekt initialisering.
    ///
    /// For eksempel initialiseres `MaybeUninit<usize>::zeroed()`, men `MaybeUninit<&'static i32>::zeroed()` skyldes ikke, at referencer ikke må være nul.
    ///
    /// Bemærk at at slippe en `MaybeUninit<T>` aldrig vil kalde `T`s drop code.
    /// Det er dit ansvar at sikre, at `T` droppes, hvis den blev initialiseret.
    ///
    /// # Example
    ///
    /// Korrekt brug af denne funktion: initialisering af en struktur med nul, hvor alle felter i strukturen kan holde bitmønsteret 0 som en gyldig værdi.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Forkert* brug af denne funktion: at ringe til `x.zeroed().assume_init()`, når `0` ikke er et gyldigt bitmønster for typen:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Inde i et par opretter vi en `NotZero`, der ikke har en gyldig diskriminant.
    /// // Dette er udefineret adfærd.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // SIKKERHED: `u.as_mut_ptr()` peger på allokeret hukommelse.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Indstiller værdien af `MaybeUninit<T>`.
    /// Dette overskriver enhver tidligere værdi uden at tabe den, så pas på ikke at bruge dette to gange, medmindre du vil springe over at køre destruktoren.
    ///
    /// For din bekvemmelighed returnerer dette også en ændret henvisning til (nu sikkert initialiseret) indholdet af `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // SIKKERHED: Vi initialiserede netop denne værdi.
        unsafe { self.assume_init_mut() }
    }

    /// Får en markør til den indeholdte værdi.
    /// Læsning fra denne markør eller omdannelse til en reference er udefineret adfærd, medmindre `MaybeUninit<T>` initialiseres.
    /// At skrive til hukommelsen, som denne markør (non-transitively) peger på, er udefineret adfærd (undtagen inde i en `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Korrekt brug af denne metode:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Opret en reference til `MaybeUninit<T>`.Dette er okay, fordi vi initialiserede det.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Forkert* brug af denne metode:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Vi har oprettet en henvisning til en ikke-initialiseret vector!Dette er udefineret adfærd.⚠️
    /// ```
    ///
    /// (Bemærk, at reglerne omkring henvisninger til ikke-initialiserede data endnu ikke er afsluttet, men indtil de er det, anbefales det at undgå dem.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` og `ManuallyDrop` er begge `repr(transparent)`, så vi kan kaste markøren.
        self as *const _ as *const T
    }

    /// Får en ændret markør til den indeholdte værdi.
    /// Læsning fra denne markør eller omdannelse til en reference er udefineret adfærd, medmindre `MaybeUninit<T>` initialiseres.
    ///
    /// # Examples
    ///
    /// Korrekt brug af denne metode:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Opret en reference til `MaybeUninit<Vec<u32>>`.
    /// // Dette er okay, fordi vi initialiserede det.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Forkert* brug af denne metode:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Vi har oprettet en henvisning til en ikke-initialiseret vector!Dette er udefineret adfærd.⚠️
    /// ```
    ///
    /// (Bemærk, at reglerne omkring henvisninger til ikke-initialiserede data endnu ikke er afsluttet, men indtil de er det, anbefales det at undgå dem.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` og `ManuallyDrop` er begge `repr(transparent)`, så vi kan kaste markøren.
        self as *mut _ as *mut T
    }

    /// Uddrag værdien fra `MaybeUninit<T>`-containeren.Dette er en fantastisk måde at sikre, at dataene bliver droppet, fordi den resulterende `T` er underlagt den sædvanlige drophåndtering.
    ///
    /// # Safety
    ///
    /// Det er op til den, der ringer op, at garantere, at `MaybeUninit<T>` virkelig er i initialiseret tilstand.At kalde dette, når indholdet endnu ikke er initialiseret, forårsager øjeblikkelig udefineret adfærd.
    /// [type-level documentation][inv] indeholder flere oplysninger om denne initialiseringsvariant.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Derudover skal du huske, at de fleste typer har yderligere invarianter ud over blot at blive betragtet som initialiseret på typeniveau.
    /// For eksempel betragtes en `1`-initialiseret [`Vec<T>`] som initialiseret (under den nuværende implementering; dette udgør ikke en stabil garanti), fordi det eneste krav, som kompilatoren ved om det, er, at datapegeren skal være ikke-nul.
    ///
    /// Oprettelse af en sådan `Vec<T>` forårsager ikke *øjeblikkelig* udefineret adfærd, men vil medføre udefineret adfærd med de mest sikre handlinger (inklusive at droppe den).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Korrekt brug af denne metode:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Forkert* brug af denne metode:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` endnu ikke var initialiseret, så denne sidste linje forårsagede udefineret adfærd.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // SIKKERHED: den, der ringer op, skal garantere, at `self` initialiseres.
        // Dette betyder også, at `self` skal være en `value`-variant.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Læser værdien fra `MaybeUninit<T>`-containeren.Den resulterende `T` er underlagt den sædvanlige drophåndtering.
    ///
    /// Når det er muligt, foretrækkes det at bruge [`assume_init`] i stedet, hvilket forhindrer duplikering af indholdet af `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Det er op til den, der ringer op, at garantere, at `MaybeUninit<T>` virkelig er i initialiseret tilstand.At kalde dette, når indholdet endnu ikke er fuldstændigt initialiseret, forårsager udefineret adfærd.
    /// [type-level documentation][inv] indeholder flere oplysninger om denne initialiseringsvariant.
    ///
    /// Desuden efterlader dette en kopi af de samme data i `MaybeUninit<T>`.
    /// Når du bruger flere kopier af dataene (ved at ringe til `assume_init_read` flere gange eller først ringe til `assume_init_read` og derefter [`assume_init`]), er det dit ansvar at sikre, at disse data faktisk kan kopieres.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Korrekt brug af denne metode:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` er `Copy`, så vi kan læse flere gange.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Det er okay at kopiere en `None`-værdi, så vi kan læse flere gange.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Forkert* brug af denne metode:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Vi oprettede nu to eksemplarer af den samme vector, hvilket førte til en dobbeltfri ⚠️ når de begge bliver droppet!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // SIKKERHED: den, der ringer op, skal garantere, at `self` initialiseres.
        // Læsning fra `self.as_ptr()` er sikker, da `self` skal initialiseres.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Sletter den indeholdte værdi på plads.
    ///
    /// Hvis du har ejerskab af `MaybeUninit`, kan du bruge [`assume_init`] i stedet.
    ///
    /// # Safety
    ///
    /// Det er op til den, der ringer op, at garantere, at `MaybeUninit<T>` virkelig er i initialiseret tilstand.At kalde dette, når indholdet endnu ikke er fuldstændigt initialiseret, forårsager udefineret adfærd.
    ///
    /// Derudover skal alle yderligere invarianter af typen `T` være opfyldt, da `Drop`-implementeringen af `T` (eller dens medlemmer) kan stole på dette.
    /// For eksempel betragtes en `1`-initialiseret [`Vec<T>`] som initialiseret (under den nuværende implementering; dette udgør ikke en stabil garanti), fordi det eneste krav, som kompilatoren ved om det, er, at datapegeren skal være ikke-nul.
    ///
    /// At slippe en sådan `Vec<T>` vil dog medføre udefineret adfærd.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // SIKKERHED: den, der ringer op, skal garantere, at `self` initialiseres og
        // opfylder alle invariantere i `T`.
        // At slippe værdien på plads er sikkert, hvis det er tilfældet.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Får en delt reference til den indeholdte værdi.
    ///
    /// Dette kan være nyttigt, når vi ønsker at få adgang til en `MaybeUninit`, der er initialiseret, men ikke har ejerskab af `MaybeUninit` (hvilket forhindrer brugen af `.assume_init()`).
    ///
    /// # Safety
    ///
    /// At kalde dette, når indholdet endnu ikke er initialiseret, forårsager udefineret adfærd: det er op til den, der ringer op, at garantere, at `MaybeUninit<T>` virkelig er i en initialiseret tilstand.
    ///
    ///
    /// # Examples
    ///
    /// ### Korrekt brug af denne metode:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Initialiser `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Nu hvor vores `MaybeUninit<_>` er kendt for at være initialiseret, er det okay at oprette en delt reference til den:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // SIKKERHED: `x` er initialiseret.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Forkerte* anvendelser af denne metode:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Vi har oprettet en henvisning til en ikke-initialiseret vector!Dette er udefineret adfærd.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Initialiser `MaybeUninit` ved hjælp af `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Henvisning til en ikke-initialiseret `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // SIKKERHED: den, der ringer op, skal garantere, at `self` initialiseres.
        // Dette betyder også, at `self` skal være en `value`-variant.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Får en ændret (unique)-reference til den indeholdte værdi.
    ///
    /// Dette kan være nyttigt, når vi ønsker at få adgang til en `MaybeUninit`, der er initialiseret, men ikke har ejerskab af `MaybeUninit` (hvilket forhindrer brugen af `.assume_init()`).
    ///
    /// # Safety
    ///
    /// At kalde dette, når indholdet endnu ikke er initialiseret, forårsager udefineret adfærd: det er op til den, der ringer op, at garantere, at `MaybeUninit<T>` virkelig er i en initialiseret tilstand.
    /// For eksempel kan `.assume_init_mut()` ikke bruges til at initialisere en `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Korrekt brug af denne metode:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Initialiserer *alle* byte i inputbufferen.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Initialiser `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Nu ved vi, at `buf` er initialiseret, så vi kunne `.assume_init()` det.
    /// // Brug af `.assume_init()` kan dog udløse en `memcpy` fra 2048 byte.
    /// // For at hævde, at vores buffer er initialiseret uden at kopiere den, opgraderer vi `&mut MaybeUninit<[u8; 2048]>` til en `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // SIKKERHED: `buf` er initialiseret.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Nu kan vi bruge `buf` som et normalt stykke:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Forkerte* anvendelser af denne metode:
    ///
    /// Du kan ikke bruge `.assume_init_mut()` til at initialisere en værdi:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Vi har oprettet en (mutable)-reference til en ikke-initialiseret `bool`!
    ///     // Dette er udefineret adfærd.⚠️
    /// }
    /// ```
    ///
    /// For eksempel kan du ikke [`Read`] ind i en ikke-initialiseret buffer:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) henvisning til ikke-initialiseret hukommelse!
    ///                             // Dette er udefineret adfærd.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Du kan heller ikke bruge direkte feltadgang til gradvis initialisering felt-for-felt:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) henvisning til ikke-initialiseret hukommelse!
    ///                  // Dette er udefineret adfærd.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) henvisning til ikke-initialiseret hukommelse!
    ///                  // Dette er udefineret adfærd.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Vi stoler i øjeblikket på, at ovenstående er forkert, dvs. vi har henvisninger til ikke-initialiserede data (f.eks. I `libcore/fmt/float.rs`).
    // Vi bør træffe en endelig beslutning om reglerne inden stabilisering.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // SIKKERHED: den, der ringer op, skal garantere, at `self` initialiseres.
        // Dette betyder også, at `self` skal være en `value`-variant.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Uddrag værdierne fra en række `MaybeUninit`-containere.
    ///
    /// # Safety
    ///
    /// Det er op til den, der ringer op, at garantere, at alle elementerne i arrayet er i en initialiseret tilstand.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // SIKKERHED: Nu sikkert, da vi initialiserede alle elementer
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Den, der ringer op, garanterer, at alle elementer i arrayet initialiseres
        // * `MaybeUninit<T>` og T er garanteret at have det samme layout
        // * MaybeUnint falder ikke, så der er ingen dobbeltfriheder og dermed er konverteringen sikker
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Forudsat at alle elementerne er initialiseret, skal du få et stykke til dem.
    ///
    /// # Safety
    ///
    /// Det er op til den, der ringer op, at garantere, at `MaybeUninit<T>`-elementerne virkelig er i en initialiseret tilstand.
    ///
    /// At kalde dette, når indholdet endnu ikke er fuldstændigt initialiseret, forårsager udefineret adfærd.
    ///
    /// Se [`assume_init_ref`] for flere detaljer og eksempler.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // SIKKERHED: at kaste skive til en `*const [T]` er sikkert, da den opkaldende garanterer det
        // `slice` initialiseres, og `MaybeUninit` garanteres at have samme layout som `T`.
        // Den opnåede markør er gyldig, da den henviser til hukommelse, der ejes af `slice`, som er en reference og dermed garanteret at være gyldig til læsning.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Forudsat at alle elementerne er initialiseret, skal du få en ændret del af dem.
    ///
    /// # Safety
    ///
    /// Det er op til den, der ringer op, at garantere, at `MaybeUninit<T>`-elementerne virkelig er i en initialiseret tilstand.
    ///
    /// At kalde dette, når indholdet endnu ikke er fuldstændigt initialiseret, forårsager udefineret adfærd.
    ///
    /// Se [`assume_init_mut`] for flere detaljer og eksempler.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // SIKKERHED: svarer til sikkerhedsanvisninger for `slice_get_ref`, men vi har en
        // mutable reference, som også garanteres at være gyldig til skrivning.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Får en markør til det første element i arrayet.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Får en ændret markør til det første element i arrayet.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Kopierer elementerne fra `src` til `this` og returnerer en ændret henvisning til det nu initaliserede indhold af `this`.
    ///
    /// Hvis `T` ikke implementerer `Copy`, skal du bruge [`write_slice_cloned`]
    ///
    /// Dette svarer til [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Denne funktion vil panic, hvis de to skiver har forskellige længder.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SIKKERHED: vi har netop kopieret alle elementerne i len til den ledige kapacitet
    /// // de første src.len()-elementer i vec er gyldige nu.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // SIKKERHED: &[T] og&[MaybeUninit<T>] har samme layout
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // SIKKERHED: Gyldige elementer er netop blevet kopieret til `this`, så det er initaliseret
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Kloner elementerne fra `src` til `this` og returnerer en ændret henvisning til det nu initaliserede indhold af `this`.
    /// Eventuelle allerede initaliserede elementer vil ikke blive droppet.
    ///
    /// Hvis `T` implementerer `Copy`, skal du bruge [`write_slice`]
    ///
    /// Dette svarer til [`slice::clone_from_slice`], men taber ikke eksisterende elementer.
    ///
    /// # Panics
    ///
    /// Denne funktion vil panic, hvis de to skiver har forskellige længder, eller hvis implementeringen af `Clone` panics.
    ///
    /// Hvis der er en panic, slettes de allerede klonede elementer.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // SIKKERHED: Vi har lige klonet alle elementerne i len i den ledige kapacitet
    /// // de første src.len()-elementer i vec er gyldige nu.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // i modsætning til copy_from_slice kalder dette ikke clone_from_slice på udsnittet, det er fordi `MaybeUninit<T: Clone>` ikke implementerer Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // SIKKERHED: dette rå stykke indeholder kun initialiserede objekter
                // det er derfor, det er tilladt at droppe det.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Vi skal eksplicit skære dem i samme længde
        // for grænsekontrol, der skal fjernes, og optimeringsprogrammet genererer memcpy til enkle tilfælde (for eksempel T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // vagt er nødvendig b/c panic kan ske under en klon
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // SIKKERHED: Gyldige elementer er netop blevet skrevet i `this`, så det er initaliseret
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}