use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// En indpakning, der forhindrer kompilatoren i automatisk at kalde 'T''s destruktor.
/// Denne indpakning koster 0.
///
/// `ManuallyDrop<T>` er underlagt de samme layoutoptimeringer som `T`.
/// Som en konsekvens har det *ingen indvirkning* på de antagelser, som compileren antager om dets indhold.
/// For eksempel er initialisering af en `ManuallyDrop<&mut T>` med [`mem::zeroed`] udefineret adfærd.
/// Hvis du har brug for at håndtere ikke-initialiserede data, skal du bruge [`MaybeUninit<T>`] i stedet.
///
/// Bemærk, at adgang til værdien inde i en `ManuallyDrop<T>` er sikker.
/// Dette betyder, at en `ManuallyDrop<T>`, hvis indhold er blevet droppet, ikke må eksponeres via en offentlig sikker API.
/// Tilsvarende er `ManuallyDrop::drop` usikker.
///
/// # `ManuallyDrop` og slip ordren.
///
/// Rust har en veldefineret [drop order] af værdier.
/// For at sikre, at felter eller lokale falder i en bestemt rækkefølge, skal du omordne erklæringerne, så den implicitte dropordre er den rigtige.
///
/// Det er muligt at bruge `ManuallyDrop` til at kontrollere drop-ordren, men dette kræver usikker kode og er svært at gøre korrekt i nærvær af afvikling.
///
///
/// Hvis du f.eks. Vil sikre dig, at et bestemt felt falder efter de andre, skal du gøre det til det sidste felt i en struktur:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` slettes efter `children`.
///     // Rust garanterer, at felter falder i erklæringsrækkefølgen.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Indpak en værdi, der skal slettes manuelt.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Du kan stadig betjene værdien sikkert
    /// assert_eq!(*x, "Hello");
    /// // Men `Drop` køres ikke her
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Uddrag værdien fra `ManuallyDrop`-containeren.
    ///
    /// Dette gør det muligt at droppe værdien igen.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Dette dropper `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Får værdien fra `ManuallyDrop<T>`-containeren ud.
    ///
    /// Denne metode er primært beregnet til flytning af værdier i drop.
    /// I stedet for at bruge [`ManuallyDrop::drop`] til manuelt at droppe værdien, kan du bruge denne metode til at tage værdien og bruge den uanset ønsket.
    ///
    /// Når det er muligt, foretrækkes det at bruge [`into_inner`][`ManuallyDrop::into_inner`] i stedet, hvilket forhindrer duplikering af indholdet af `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Denne funktion flytter semantisk den indeholdte værdi ud uden at forhindre yderligere anvendelse og efterlader tilstanden for denne container uændret.
    /// Det er dit ansvar at sikre, at denne `ManuallyDrop` ikke bruges igen.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // SIKKERHED: vi læser fra en reference, som er garanteret
        // at være gyldig til læsninger.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Sænker den indeholdte værdi manuelt.Dette svarer nøjagtigt til at kalde [`ptr::drop_in_place`] med en markør til den indeholdte værdi.
    /// Medmindre den indeholdte værdi er en pakket struktur, kaldes destruktoren på stedet uden at flytte værdien og kan således bruges til sikkert at slippe [pinned]-data.
    ///
    /// Hvis du har ejerskab af værdien, kan du bruge [`ManuallyDrop::into_inner`] i stedet.
    ///
    /// # Safety
    ///
    /// Denne funktion kører destruktoren for den indeholdte værdi.
    /// Bortset fra ændringer foretaget af destruktøren selv, forbliver hukommelsen uændret, og så vidt kompilatoren stadig har et bitmønster, der er gyldigt for typen `T`.
    ///
    ///
    /// Denne "zombie"-værdi bør dog ikke udsættes for sikker kode, og denne funktion skal ikke kaldes mere end én gang.
    /// At bruge en værdi, efter at den er blevet droppet, eller slippe en værdi flere gange, kan forårsage udefineret adfærd (afhængigt af hvad `drop` gør).
    /// Dette forhindres normalt af typesystemet, men brugere af `ManuallyDrop` skal opretholde disse garantier uden hjælp fra compileren.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // SIKKERHED: vi taber den værdi, der peges på ved en ændret reference
        // som garanteret er gyldig til skrivning.
        // Det er op til den, der ringer op, at sikre sig, at `slot` ikke tabes igen.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}