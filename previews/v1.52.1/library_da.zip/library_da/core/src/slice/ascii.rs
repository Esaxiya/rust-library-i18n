//! Funktioner på ASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Kontrollerer, om alle byte i dette udsnit er inden for ASCII-området.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Kontrollerer, at to skiver er et ASCII-ufølsomt match.
    ///
    /// Samme som `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, men uden at allokere og kopiere midlertidige.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Konverterer dette udsnit til dets tilsvarende ASCII-store bogstaver på stedet.
    ///
    /// ASCII-bogstaver 'a' til 'z' er kortlagt til 'A' til 'Z', men ikke-ASCII-bogstaver er uændrede.
    ///
    /// Brug [`to_ascii_uppercase`] for at returnere en ny opskrevet værdi uden at ændre den eksisterende.
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Konverterer dette stykke til dets ASCII-småbogstavsækvivalent på stedet.
    ///
    /// ASCII-bogstaver 'A' til 'Z' kortlægges til 'a' til 'z', men ikke-ASCII-bogstaver er uændrede.
    ///
    /// Brug [`to_ascii_lowercase`] for at returnere en ny værdi med lavere værdi uden at ændre den eksisterende.
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Returnerer `true`, hvis nogen byte i ordet `v` er nonascii (>=128).
/// Snarfed fra `../str/mod.rs`, som gør noget lignende til utf8-validering.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Optimeret ASCII-test, der bruger usize-at-a-time operationer i stedet for byte-at-a-time operationer (når det er muligt).
///
/// Algoritmen, vi bruger her, er ret enkel.Hvis `s` er for kort, skal vi bare kontrollere hver byte og være færdig med den.Ellers:
///
/// - Læs det første ord med en ikke-justeret belastning.
/// - Juster markøren, læs efterfølgende ord til slutningen med justerede belastninger.
/// - Læs den sidste `usize` fra `s` med en ikke-justeret belastning.
///
/// Hvis nogen af disse belastninger producerer noget, som `contains_nonascii` (above) returnerer sandt for, ved vi, at svaret er falsk.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Hvis vi ikke ville få noget ud af ordet ad gangen-implementeringen, skal du falde tilbage til en skalær løkke.
    //
    // Vi gør dette også for arkitekturer, hvor `size_of::<usize>()` ikke er tilstrækkelig tilpasning til `usize`, fordi det er en underlig edge-sag.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Vi læser altid det første ord ujusteret, hvilket betyder, at `align_offset` er
    // 0, vi læste den samme værdi igen for den justerede læsning.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // SIKKERHED: Vi bekræfter `len < USIZE_SIZE` ovenfor.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Vi kontrollerede dette ovenfor noget implicit.
    // Bemærk, at `offset_to_aligned` enten er `align_offset` eller `USIZE_SIZE`, begge er eksplicit kontrolleret ovenfor.
    //
    debug_assert!(offset_to_aligned <= len);

    // SIKKERHED: word_ptr er den (korrekt justerede) størrelses ptr, vi bruger til at læse
    // den midterste del af skiven.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` er byteindekset på `word_ptr`, der bruges til loop-end-kontrol.
    let mut byte_pos = offset_to_aligned;

    // Paranoia kontrollerer om tilpasning, da vi er ved at lave en masse ujusterede belastninger.
    // I praksis bør dette dog være umuligt at udelukke en fejl i `align_offset`.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Læs efterfølgende ord indtil det sidst justerede ord, undtagen det sidste justerede ord i sig selv, der skal udføres i halekontrol senere, for at sikre, at halen altid er højst en `usize` til ekstra branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Fornuftskontrol, om læsningen er inden for grænser
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Og at vores antagelser om `byte_pos` holder.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // SIKKERHED: Vi ved, at `word_ptr` er korrekt justeret (pga
        // 'align_offset'), og vi ved, at vi har nok byte mellem `word_ptr` og slutningen
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // SIKKERHED: Vi ved, at `byte_pos <= len - USIZE_SIZE`, hvilket betyder det
        // efter denne `add` vil `word_ptr` højst være forbi enden.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Sanity check for at sikre, at der virkelig kun er en `usize` tilbage.
    // Dette bør garanteres af vores loop-tilstand.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // SIKKERHED: Dette er afhængig af `len >= USIZE_SIZE`, som vi kontrollerer i starten.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}