// ignore-tidy-filelength

//! Slice management og manipulation.
//!
//! For flere detaljer se [`std::slice`].
//!
//! [`std::slice`]: ../../std/slice/index.html

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering::{self, Greater, Less};
use crate::marker::Copy;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ops::{FnMut, Range, RangeBounds};
use crate::option::Option;
use crate::option::Option::{None, Some};
use crate::ptr;
use crate::result::Result;
use crate::result::Result::{Err, Ok};
use crate::slice;

#[unstable(
    feature = "slice_internals",
    issue = "none",
    reason = "exposed from core to be reused in std; use the memchr crate"
)]
/// Ren rust memchr implementering, taget fra rust-memchr
pub mod memchr;

mod ascii;
mod cmp;
mod index;
mod iter;
mod raw;
mod rotate;
mod sort;
mod specialize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Chunks, ChunksMut, Windows};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{Iter, IterMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use iter::{RSplitN, RSplitNMut, Split, SplitMut, SplitN, SplitNMut};

#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use iter::{RSplit, RSplitMut};

#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use iter::{ChunksExact, ChunksExactMut};

#[stable(feature = "rchunks", since = "1.31.0")]
pub use iter::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};

#[unstable(feature = "array_chunks", issue = "74985")]
pub use iter::{ArrayChunks, ArrayChunksMut};

#[unstable(feature = "array_windows", issue = "75027")]
pub use iter::ArrayWindows;

#[unstable(feature = "slice_group_by", issue = "80552")]
pub use iter::{GroupBy, GroupByMut};

#[stable(feature = "split_inclusive", since = "1.51.0")]
pub use iter::{SplitInclusive, SplitInclusiveMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use raw::{from_raw_parts, from_raw_parts_mut};

#[stable(feature = "from_ref", since = "1.28.0")]
pub use raw::{from_mut, from_ref};

// Denne funktion er kun offentlig, fordi der ikke er nogen anden måde at afprøve heapsort på.
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub use sort::heapsort;

#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use index::SliceIndex;

#[unstable(feature = "slice_range", issue = "76393")]
pub use index::range;

#[lang = "slice"]
#[cfg(not(test))]
impl<T> [T] {
    /// Returnerer antallet af elementer i udsnittet.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_len", since = "1.32.0")]
    #[inline]
    // SIKKERHED: const-lyd, fordi vi transmitterer længdefeltet som en størrelse (som det skal være)
    #[rustc_allow_const_fn_unstable(const_fn_union)]
    pub const fn len(&self) -> usize {
        #[cfg(bootstrap)]
        {
            // SIKKERHED: dette er sikkert, fordi `&[T]` og `FatPtr<T>` har samme layout.
            // Kun `std` kan stille denne garanti.
            unsafe { crate::ptr::Repr { rust: self }.raw.len }
        }
        #[cfg(not(bootstrap))]
        {
            // FIXME: Udskift med `crate::ptr::metadata(self)`, når det er konststabilt.
            // I skrivende stund forårsager dette en "Const-stable functions can only call other const-stable functions"-fejl.
            //

            // SIKKERHED: Adgang til værdien fra `PtrRepr`-unionen er sikker, da * konst T
            // og PtrComponents<T>har de samme hukommelseslayouter.
            // Kun std kan stille denne garanti.
            unsafe { crate::ptr::PtrRepr { const_ptr: self }.components.metadata }
        }
    }

    /// Returnerer `true`, hvis udsnittet har en længde på 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert!(!a.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_is_empty", since = "1.32.0")]
    #[inline]
    pub const fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Returnerer det første element i udsnittet eller `None`, hvis det er tomt.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&10), v.first());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.first());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first(&self) -> Option<&T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Returnerer en ændret markør til det første element i udsnittet eller `None`, hvis det er tomt.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(first) = x.first_mut() {
    ///     *first = 5;
    /// }
    /// assert_eq!(x, &[5, 1, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn first_mut(&mut self) -> Option<&mut T> {
        if let [first, ..] = self { Some(first) } else { None }
    }

    /// Returnerer det første og resten af elementerne i udsnittet eller `None`, hvis det er tomt.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first() {
    ///     assert_eq!(first, &0);
    ///     assert_eq!(elements, &[1, 2]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first(&self) -> Option<(&T, &[T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Returnerer det første og resten af elementerne i udsnittet eller `None`, hvis det er tomt.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((first, elements)) = x.split_first_mut() {
    ///     *first = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[3, 4, 5]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_first_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [first, tail @ ..] = self { Some((first, tail)) } else { None }
    }

    /// Returnerer det sidste og resten af elementerne i udsnittet eller `None`, hvis det er tomt.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last() {
    ///     assert_eq!(last, &2);
    ///     assert_eq!(elements, &[0, 1]);
    /// }
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last(&self) -> Option<(&T, &[T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Returnerer det sidste og resten af elementerne i udsnittet eller `None`, hvis det er tomt.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some((last, elements)) = x.split_last_mut() {
    ///     *last = 3;
    ///     elements[0] = 4;
    ///     elements[1] = 5;
    /// }
    /// assert_eq!(x, &[4, 5, 3]);
    /// ```
    #[stable(feature = "slice_splits", since = "1.5.0")]
    #[inline]
    pub fn split_last_mut(&mut self) -> Option<(&mut T, &mut [T])> {
        if let [init @ .., last] = self { Some((last, init)) } else { None }
    }

    /// Returnerer det sidste element i udsnittet eller `None`, hvis det er tomt.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&30), v.last());
    ///
    /// let w: &[i32] = &[];
    /// assert_eq!(None, w.last());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last(&self) -> Option<&T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Returnerer en ændret markør til det sidste element i udsnittet.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(last) = x.last_mut() {
    ///     *last = 10;
    /// }
    /// assert_eq!(x, &[0, 1, 10]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn last_mut(&mut self) -> Option<&mut T> {
        if let [.., last] = self { Some(last) } else { None }
    }

    /// Returnerer en henvisning til et element eller underdel afhængigt af typen af indeks.
    ///
    /// - Hvis der gives en position, returneres en henvisning til elementet i den position eller `None`, hvis den er uden for grænserne.
    ///
    /// - Hvis der gives et interval, returneres underskærmen, der svarer til det område, eller `None`, hvis den er uden for grænserne.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert_eq!(Some(&40), v.get(1));
    /// assert_eq!(Some(&[10, 40][..]), v.get(0..2));
    /// assert_eq!(None, v.get(3));
    /// assert_eq!(None, v.get(0..4));
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get<I>(&self, index: I) -> Option<&I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get(self)
    }

    /// Returnerer en ændret henvisning til et element eller underdel afhængigt af typen af indeks (se [`get`]) eller `None`, hvis indekset er uden for grænserne.
    ///
    ///
    /// [`get`]: slice::get
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [0, 1, 2];
    ///
    /// if let Some(elem) = x.get_mut(1) {
    ///     *elem = 42;
    /// }
    /// assert_eq!(x, &[0, 42, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn get_mut<I>(&mut self, index: I) -> Option<&mut I::Output>
    where
        I: SliceIndex<Self>,
    {
        index.get_mut(self)
    }

    /// Returnerer en henvisning til et element eller underdel uden at foretage grænsekontrol.
    ///
    /// For et sikkert alternativ se [`get`].
    ///
    /// # Safety
    ///
    /// At kalde denne metode med et indeks uden for grænserne er *[udefineret adfærd]*, selvom den resulterende reference ikke bruges.
    ///
    ///
    /// [`get`]: slice::get
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), &2);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked<I>(&self, index: I) -> &I::Output
    where
        I: SliceIndex<Self>,
    {
        // SIKKERHED: den, der ringer op, skal overholde de fleste af sikkerhedskravene til `get_unchecked`;
        // udsnittet kan udskæres, fordi `self` er en sikker reference.
        // Den returnerede markør er sikker, fordi implanter af `SliceIndex` skal garantere, at det er det.
        unsafe { &*index.get_unchecked(self) }
    }

    /// Returnerer en ændret henvisning til et element eller en underdel uden at foretage grænsekontrol.
    ///
    /// For et sikkert alternativ se [`get_mut`].
    ///
    /// # Safety
    ///
    /// At kalde denne metode med et indeks uden for grænserne er *[udefineret adfærd]*, selvom den resulterende reference ikke bruges.
    ///
    ///
    /// [`get_mut`]: slice::get_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    ///
    /// unsafe {
    ///     let elem = x.get_unchecked_mut(1);
    ///     *elem = 13;
    /// }
    /// assert_eq!(x, &[1, 13, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(&mut self, index: I) -> &mut I::Output
    where
        I: SliceIndex<Self>,
    {
        // SIKKERHED: den, der ringer op, skal overholde sikkerhedskravene til `get_unchecked_mut`;
        // udsnittet kan udskæres, fordi `self` er en sikker reference.
        // Den returnerede markør er sikker, fordi implanter af `SliceIndex` skal garantere, at det er det.
        unsafe { &mut *index.get_unchecked_mut(self) }
    }

    /// Returnerer en rå markør til udsnitets buffer.
    ///
    /// Den, der ringer op, skal sikre, at udsnittet overlever markøren, som denne funktion returnerer, ellers peger det på skrald.
    ///
    /// Den, der ringer op, skal også sikre, at den hukommelse, som markøren (non-transitively) peger på, aldrig skrives til (undtagen inde i en `UnsafeCell`) ved hjælp af denne markør eller en hvilken som helst markør, der stammer fra den.
    /// Hvis du har brug for at mutere indholdet af udsnittet, skal du bruge [`as_mut_ptr`].
    ///
    /// Ændring af beholderen, som dette udsnit henviser til, kan medføre, at dens buffer omfordeles, hvilket også vil gøre eventuelle henvisninger til den ugyldige.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(x.get_unchecked(i), &*x_ptr.add(i));
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_stable(feature = "const_slice_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(&self) -> *const T {
        self as *const [T] as *const T
    }

    /// Returnerer en usikker, muterbar markør til udsnitets buffer.
    ///
    /// Den, der ringer op, skal sikre, at udsnittet overlever markøren, som denne funktion returnerer, ellers peger det på skrald.
    ///
    /// Ændring af beholderen, som dette udsnit henviser til, kan medføre, at dens buffer omfordeles, hvilket også vil gøre eventuelle henvisninger til den ugyldige.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         *x_ptr.add(i) += 2;
    ///     }
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        self as *mut [T] as *mut T
    }

    /// Returnerer de to rå pointer, der spænder over skiven.
    ///
    /// Det returnerede interval er halvåbent, hvilket betyder, at slutmarkøren peger *en forbi* det sidste element i udsnittet.
    /// På denne måde er en tom skive repræsenteret af to lige markører, og forskellen mellem de to markører repræsenterer størrelsen på skiven.
    ///
    /// Se [`as_ptr`] for advarsler om brugen af disse markører.Slutmarkøren kræver ekstra forsigtighed, da den ikke peger på et gyldigt element i udsnittet.
    ///
    /// Denne funktion er nyttig til interaktion med udenlandske grænseflader, der bruger to pegepinde til at henvise til en række elementer i hukommelsen, som det er almindeligt i C++ .
    ///
    ///
    /// Det kan også være nyttigt at kontrollere, om en markør til et element refererer til et element i dette udsnit:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let x = &a[1] as *const _;
    /// let y = &5 as *const _;
    ///
    /// assert!(a.as_ptr_range().contains(&x));
    /// assert!(!a.as_ptr_range().contains(&y));
    /// ```
    ///
    /// [`as_ptr`]: slice::as_ptr
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_ptr_range(&self) -> Range<*const T> {
        let start = self.as_ptr();
        // SIKKERHED: `add` her er sikker, fordi:
        //
        //   - Begge markører er en del af det samme objekt, da det også tæller at pege direkte forbi objektet.
        //
        //   - Størrelsen på skiven er aldrig større end isize::MAX bytes, som nævnt her:
        //       - https://github.com/rust-lang/unsafe-code-guidelines/issues/102#issuecomment-473340447
        //       - https://doc.rust-lang.org/reference/behavior-considered-undefined.html
        //       - https://doc.rust-lang.org/core/slice/fn.from_raw_parts.html#safety(This doesn't seem normative yet, but the very same assumption is made in many places, including the Index implementation of slices.)
        //
        //
        //   - Der er ingen indpakning involveret, da skiver ikke vikles forbi enden af adresseområdet.
        //
        // Se dokumentationen til pointer::add.
        //
        //
        //
        //
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Returnerer de to usikre mutable markører, der spænder over udsnittet.
    ///
    /// Det returnerede interval er halvåbent, hvilket betyder, at slutmarkøren peger *en forbi* det sidste element i udsnittet.
    /// På denne måde er en tom skive repræsenteret af to lige markører, og forskellen mellem de to markører repræsenterer størrelsen på skiven.
    ///
    /// Se [`as_mut_ptr`] for advarsler om brugen af disse markører.
    /// Slutmarkøren kræver ekstra forsigtighed, da den ikke peger på et gyldigt element i udsnittet.
    ///
    /// Denne funktion er nyttig til interaktion med udenlandske grænseflader, der bruger to pegepinde til at henvise til en række elementer i hukommelsen, som det er almindeligt i C++ .
    ///
    ///
    /// [`as_mut_ptr`]: slice::as_mut_ptr
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_ptr_range", since = "1.48.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn as_mut_ptr_range(&mut self) -> Range<*mut T> {
        let start = self.as_mut_ptr();
        // SIKKERHED: Se as_ptr_range() ovenfor for hvorfor `add` her er sikkert.
        let end = unsafe { start.add(self.len()) };
        start..end
    }

    /// Bytter to elementer i skiven.
    ///
    /// # Arguments
    ///
    /// * a, Indekset for det første element
    /// * b, indekset for det andet element
    ///
    /// # Panics
    ///
    /// Panics hvis `a` eller `b` er uden for grænserne.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = ["a", "b", "c", "d"];
    /// v.swap(1, 3);
    /// assert!(v == ["a", "d", "c", "b"]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn swap(&mut self, a: usize, b: usize) {
        // Kan ikke tage to mutable lån fra en vector, så brug i stedet rå pointer.
        let pa = ptr::addr_of_mut!(self[a]);
        let pb = ptr::addr_of_mut!(self[b]);
        // SIKKERHED: `pa` og `pb` er oprettet ud fra sikre mutable referencer og henviser
        // til elementer i udsnittet og er derfor garanteret at være gyldige og justerede.
        // Bemærk at adgang til elementerne bag `a` og `b` er markeret og vil panic når det er uden for grænserne.
        //
        unsafe {
            ptr::swap(pa, pb);
        }
    }

    /// Vender rækkefølgen af elementerne i skiven på plads.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 2, 3];
    /// v.reverse();
    /// assert!(v == [3, 2, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn reverse(&mut self) {
        let mut i: usize = 0;
        let ln = self.len();

        // For meget små typer fungerer alle individuelle læsninger i den normale sti dårligt.
        // Vi kan gøre det bedre, givet effektiv, ikke-justeret load/store, ved at indlæse et større stykke og vende et register.
        //

        // Ideelt set ville LLVM gøre dette for os, da det ved bedre end vi gør, om ikke-justerede læsninger er effektive (da det f.eks. Skifter mellem forskellige ARM-versioner) og hvad den bedste klumpstørrelse ville være.
        // Desværre, fra LLVM 4.0 (2017-05) ruller den kun løkken, så vi skal selv gøre det.
        // (Hypotese: omvendt er besværligt, fordi siderne kan justeres forskelligt-vil være, når længden er ulige-så der er ingen måde at udsende præ-og efterfølgende brug af fuldt justeret SIMD i midten.)
        //
        //
        //
        //
        //

        let fast_unaligned = cfg!(any(target_arch = "x86", target_arch = "x86_64"));

        if fast_unaligned && mem::size_of::<T>() == 1 {
            // Brug llvm.bswap iboende til at vende u8'er i en størrelse
            let chunk = mem::size_of::<usize>();
            while i + chunk - 1 < ln / 2 {
                // SIKKERHED: Der er flere ting at kontrollere her:
                //
                // - Bemærk, at `chunk` enten er 4 eller 8 på grund af CFG-kontrollen ovenfor.Så `chunk - 1` er positiv.
                // - Indeksering med indeks `i` er fint, da loopcheck garanterer
                //   `i + chunk - 1 < ln / 2`
                //   <=> `i < ln / 2 - (chunk - 1) < ln / 2 < ln`.
                // - Indeksering med indeks `ln - i - chunk = ln - (i + chunk)` er fint:
                //   - `i + chunk > 0` er trivielt sandt.
                //   - Loopcheck garanterer:
                //     `i + chunk - 1 < ln / 2`
                //     <=> `i + chunk ≤ ln / 2 ≤ ln`, så subtraktion understrømmer således ikke.
                // - `read_unaligned`-og `write_unaligned`-opkaldene er fine:
                //   - `pa` peger på indeks `i` hvor `i < ln / 2 - (chunk - 1)` (se ovenfor) og `pb` peger på indeks `ln - i - chunk`, så begge er mindst `chunk` mange byte væk fra slutningen af `self`.
                //
                //   - Enhver initialiseret hukommelse er gyldig `usize`.
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut usize);
                    let vb = ptr::read_unaligned(pb as *mut usize);
                    ptr::write_unaligned(pa as *mut usize, vb.swap_bytes());
                    ptr::write_unaligned(pb as *mut usize, va.swap_bytes());
                }
                i += chunk;
            }
        }

        if fast_unaligned && mem::size_of::<T>() == 2 {
            // Brug Rotate-by-16 til at vende u16s i en u32
            let chunk = mem::size_of::<u32>() / 2;
            while i + chunk - 1 < ln / 2 {
                // SIKKERHED: En ikke-justeret u32 kan læses fra `i`, hvis `i + 1 < ln`
                // (og naturligvis `i < ln`), fordi hvert element er 2 byte, og vi læser 4.
                //
                // `i + chunk - 1 < ln / 2` # mens tilstand
                // `i + 2 - 1 < ln / 2`
                // `i + 1 < ln / 2`
                //
                // Da det er mindre end længden divideret med 2, skal den være i grænser.
                //
                // Dette betyder også, at betingelsen `0 < i + chunk <= ln` altid respekteres, hvilket sikrer, at `pb`-markøren kan bruges sikkert.
                //
                //
                //
                //
                unsafe {
                    let ptr = self.as_mut_ptr();
                    let pa = ptr.add(i);
                    let pb = ptr.add(ln - i - chunk);
                    let va = ptr::read_unaligned(pa as *mut u32);
                    let vb = ptr::read_unaligned(pb as *mut u32);
                    ptr::write_unaligned(pa as *mut u32, vb.rotate_left(16));
                    ptr::write_unaligned(pb as *mut u32, va.rotate_left(16));
                }
                i += chunk;
            }
        }

        while i < ln / 2 {
            // SIKKERHED: `i` er ringere end halvdelen af skiven så
            // adgang til `i` og `ln - i - 1` er sikker (`i` starter ved 0 og går ikke længere end `ln / 2 - 1`).
            // De resulterende markører `pa` og `pb` er derfor gyldige og justerede og kan læses fra og skrives til.
            //
            //
            unsafe {
                // Usikker bytte for at undgå grænsekontrol i sikker bytte.
                let ptr = self.as_mut_ptr();
                let pa = ptr.add(i);
                let pb = ptr.add(ln - i - 1);
                ptr::swap(pa, pb);
            }
            i += 1;
        }
    }

    /// Returnerer en iterator over udsnittet.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &[1, 2, 4];
    /// let mut iterator = x.iter();
    ///
    /// assert_eq!(iterator.next(), Some(&1));
    /// assert_eq!(iterator.next(), Some(&2));
    /// assert_eq!(iterator.next(), Some(&4));
    /// assert_eq!(iterator.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter::new(self)
    }

    /// Returnerer en iterator, der tillader ændring af hver værdi.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = &mut [1, 2, 4];
    /// for elem in x.iter_mut() {
    ///     *elem += 2;
    /// }
    /// assert_eq!(x, &[3, 4, 6]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        IterMut::new(self)
    }

    /// Returnerer en iterator over alle sammenhængende windows af længde `size`.
    /// windows overlapning.
    /// Hvis udsnittet er kortere end `size`, returnerer iteratoren ingen værdier.
    ///
    /// # Panics
    ///
    /// Panics hvis `size` er 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['r', 'u', 's', 't'];
    /// let mut iter = slice.windows(2);
    /// assert_eq!(iter.next().unwrap(), &['r', 'u']);
    /// assert_eq!(iter.next().unwrap(), &['u', 's']);
    /// assert_eq!(iter.next().unwrap(), &['s', 't']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Hvis udsnittet er kortere end `size`:
    ///
    /// ```
    /// let slice = ['f', 'o', 'o'];
    /// let mut iter = slice.windows(4);
    /// assert!(iter.next().is_none());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn windows(&self, size: usize) -> Windows<'_, T> {
        let size = NonZeroUsize::new(size).expect("size is zero");
        Windows::new(self, size)
    }

    /// Returnerer en iterator over `chunk_size`-elementer af udsnittet ad gangen, startende i begyndelsen af udsnittet.
    ///
    /// Biterne er skiver og overlapper ikke hinanden.Hvis `chunk_size` ikke deler længden af skiven, har den sidste del ikke længden `chunk_size`.
    ///
    /// Se [`chunks_exact`] for en variant af denne iterator, der returnerer klumper af altid nøjagtigt `chunk_size`-elementer, og [`rchunks`] for den samme iterator, men starter ved slutningen af udsnittet.
    ///
    ///
    /// # Panics
    ///
    /// Panics hvis `chunk_size` er 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert_eq!(iter.next().unwrap(), &['m']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    /// [`rchunks`]: slice::rchunks
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks(&self, chunk_size: usize) -> Chunks<'_, T> {
        assert_ne!(chunk_size, 0);
        Chunks::new(self, chunk_size)
    }

    /// Returnerer en iterator over `chunk_size`-elementer af udsnittet ad gangen, startende i begyndelsen af udsnittet.
    ///
    /// Biterne er skiftelige skiver og overlapper ikke hinanden.Hvis `chunk_size` ikke deler længden af skiven, har den sidste del ikke længden `chunk_size`.
    ///
    /// Se [`chunks_exact_mut`] for en variant af denne iterator, der returnerer klumper af altid nøjagtigt `chunk_size`-elementer, og [`rchunks_mut`] for den samme iterator, men starter ved slutningen af udsnittet.
    ///
    ///
    /// # Panics
    ///
    /// Panics hvis `chunk_size` er 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 3]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn chunks_mut(&mut self, chunk_size: usize) -> ChunksMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksMut::new(self, chunk_size)
    }

    /// Returnerer en iterator over `chunk_size`-elementer af udsnittet ad gangen, startende i begyndelsen af udsnittet.
    ///
    /// Biterne er skiver og overlapper ikke hinanden.
    /// Hvis `chunk_size` ikke opdeler længden af udsnittet, vil de sidste op til `chunk_size-1`-elementer blive udeladt og kan hentes fra iteratorens `remainder`-funktion.
    ///
    ///
    /// På grund af at hver del har nøjagtigt `chunk_size`-elementer, kan compileren ofte optimere den resulterende kode bedre end i tilfælde af [`chunks`].
    ///
    /// Se [`chunks`] for en variant af denne iterator, der også returnerer resten som en mindre klump, og [`rchunks_exact`] for den samme iterator, men starter ved slutningen af udsnittet.
    ///
    /// # Panics
    ///
    /// Panics hvis `chunk_size` er 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.chunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks_exact`]: slice::rchunks_exact
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact(&self, chunk_size: usize) -> ChunksExact<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExact::new(self, chunk_size)
    }

    /// Returnerer en iterator over `chunk_size`-elementer af udsnittet ad gangen, startende i begyndelsen af udsnittet.
    ///
    /// Biterne er skiftelige skiver og overlapper ikke hinanden.
    /// Hvis `chunk_size` ikke opdeler længden af udsnittet, udelades de sidste op til `chunk_size-1`-elementer og kan hentes fra iteratorens `into_remainder`-funktion.
    ///
    ///
    /// På grund af at hver del har nøjagtigt `chunk_size`-elementer, kan compileren ofte optimere den resulterende kode bedre end i tilfælde af [`chunks_mut`].
    ///
    /// Se [`chunks_mut`] for en variant af denne iterator, der også returnerer resten som en mindre klump, og [`rchunks_exact_mut`] for den samme iterator, men starter ved slutningen af udsnittet.
    ///
    /// # Panics
    ///
    /// Panics hvis `chunk_size` er 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.chunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "chunks_exact", since = "1.31.0")]
    #[inline]
    pub fn chunks_exact_mut(&mut self, chunk_size: usize) -> ChunksExactMut<'_, T> {
        assert_ne!(chunk_size, 0);
        ChunksExactMut::new(self, chunk_size)
    }

    /// Opdeler skiven i et stykke `N`-element-arrays, forudsat at der ikke er nogen rest.
    ///
    ///
    /// # Safety
    ///
    /// Dette kaldes kun når
    /// - Skiven opdeles nøjagtigt i `N`-elementbiter (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &[char] = &['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &[[char; 1]] =
    ///     // SIKKERHED: 1-elementstykker har aldrig resten
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &[[char; 3]] =
    ///     // SIKKERHED: Skivelængden (6) er et multiplum af 3
    ///     unsafe { slice.as_chunks_unchecked() };
    /// assert_eq!(chunks, &[['l', 'o', 'r'], ['e', 'm', '!']]);
    ///
    /// // Disse ville være usunde:
    /// // lad bidder: &[[_;5]]= slice.as_chunks_unchecked()//Skivelængden er ikke et multiplum af 5 let bidder:&[[_;0]]= slice.as_chunks_unchecked()//Nul-længde klumper er aldrig tilladt
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked<const N: usize>(&self) -> &[[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SIKKERHED: Vores forudsætning er præcis, hvad der er nødvendigt for at kalde dette
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SIKKERHED: Vi kaster et stykke `new_len * N`-elementer i
        // et stykke `new_len` mange `N`-elementstykker.
        unsafe { from_raw_parts(self.as_ptr().cast(), new_len) }
    }

    /// Opdeler skiven i et stykke `N`-element-arrays, der starter i begyndelsen af skiven, og en resten skiver med en længde, der er mindre end `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics hvis `N` er 0. Denne kontrol bliver sandsynligvis ændret til en kompileringstidsfejl, før denne metode stabiliseres.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (chunks, remainder) = slice.as_chunks();
    /// assert_eq!(chunks, &[['l', 'o'], ['r', 'e']]);
    /// assert_eq!(remainder, &['m']);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks<const N: usize>(&self) -> (&[[T; N]], &[T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at(len * N);
        // SIKKERHED: Vi var allerede i panik for nul og sikrede ved konstruktion
        // at længden af underdelen er et multiplum af N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (array_slice, remainder)
    }

    /// Opdeler skiven i et stykke `N`-element-arrays, der starter ved slutningen af skiven, og et resten skiver med en længde, der er strengt mindre end `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics hvis `N` er 0. Denne kontrol bliver sandsynligvis ændret til en kompileringstidsfejl, før denne metode stabiliseres.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let (remainder, chunks) = slice.as_rchunks();
    /// assert_eq!(remainder, &['l']);
    /// assert_eq!(chunks, &[['o', 'r'], ['e', 'm']]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks<const N: usize>(&self) -> (&[T], &[[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at(self.len() - len * N);
        // SIKKERHED: Vi var allerede i panik for nul og sikrede ved konstruktion
        // at længden af underdelen er et multiplum af N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked() };
        (remainder, array_slice)
    }

    /// Returnerer en iterator over `N`-elementer af udsnittet ad gangen, startende i begyndelsen af udsnittet.
    ///
    /// Stykkerne er matrixreferencer og overlapper ikke hinanden.
    /// Hvis `N` ikke opdeler længden af udsnittet, udelades de sidste op til `N-1`-elementer og kan hentes fra iteratorens `remainder`-funktion.
    ///
    ///
    /// Denne metode er det const generiske ækvivalent med [`chunks_exact`].
    ///
    /// # Panics
    ///
    /// Panics hvis `N` er 0. Denne kontrol bliver sandsynligvis ændret til en kompileringstidsfejl, før denne metode stabiliseres.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.array_chunks();
    /// assert_eq!(iter.next().unwrap(), &['l', 'o']);
    /// assert_eq!(iter.next().unwrap(), &['r', 'e']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['m']);
    /// ```
    ///
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks<const N: usize>(&self) -> ArrayChunks<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunks::new(self)
    }

    /// Opdeler skiven i et stykke `N`-element-arrays, forudsat at der ikke er nogen rest.
    ///
    ///
    /// # Safety
    ///
    /// Dette kaldes kun når
    /// - Skiven opdeles nøjagtigt i `N`-elementbiter (aka `self.len() % N == 0`).
    /// - `N != 0`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let slice: &mut [char] = &mut ['l', 'o', 'r', 'e', 'm', '!'];
    /// let chunks: &mut [[char; 1]] =
    ///     // SIKKERHED: 1-elementstykker har aldrig resten
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[0] = ['L'];
    /// assert_eq!(chunks, &[['L'], ['o'], ['r'], ['e'], ['m'], ['!']]);
    /// let chunks: &mut [[char; 3]] =
    ///     // SIKKERHED: Skivelængden (6) er et multiplum af 3
    ///     unsafe { slice.as_chunks_unchecked_mut() };
    /// chunks[1] = ['a', 'x', '?'];
    /// assert_eq!(slice, &['L', 'o', 'r', 'a', 'x', '?']);
    ///
    /// // Disse ville være usunde:
    /// // lad bidder: &[[_;5]]= slice.as_chunks_unchecked_mut()//Skivelængden er ikke et multiplum af 5 let bidder:&[[_;0]]= slice.as_chunks_unchecked_mut()//Nul-længde klumper er aldrig tilladt
    /////
    /// ```
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub unsafe fn as_chunks_unchecked_mut<const N: usize>(&mut self) -> &mut [[T; N]] {
        debug_assert_ne!(N, 0);
        debug_assert_eq!(self.len() % N, 0);
        let new_len =
            // SIKKERHED: Vores forudsætning er præcis, hvad der er nødvendigt for at kalde dette
            unsafe { crate::intrinsics::exact_div(self.len(), N) };
        // SIKKERHED: Vi kaster et stykke `new_len * N`-elementer i
        // et stykke `new_len` mange `N`-elementstykker.
        unsafe { from_raw_parts_mut(self.as_mut_ptr().cast(), new_len) }
    }

    /// Opdeler skiven i et stykke `N`-element-arrays, der starter i begyndelsen af skiven, og en resten skiver med en længde, der er mindre end `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics hvis `N` er 0. Denne kontrol bliver sandsynligvis ændret til en kompileringstidsfejl, før denne metode stabiliseres.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (chunks, remainder) = v.as_chunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 9]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_chunks_mut<const N: usize>(&mut self) -> (&mut [[T; N]], &mut [T]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (multiple_of_n, remainder) = self.split_at_mut(len * N);
        // SIKKERHED: Vi var allerede i panik for nul og sikrede ved konstruktion
        // at længden af underdelen er et multiplum af N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (array_slice, remainder)
    }

    /// Opdeler skiven i et stykke `N`-element-arrays, der starter ved slutningen af skiven, og et resten skiver med en længde, der er strengt mindre end `N`.
    ///
    ///
    /// # Panics
    ///
    /// Panics hvis `N` er 0. Denne kontrol bliver sandsynligvis ændret til en kompileringstidsfejl, før denne metode stabiliseres.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_as_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// let (remainder, chunks) = v.as_rchunks_mut();
    /// remainder[0] = 9;
    /// for chunk in chunks {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[9, 1, 1, 2, 2]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_as_chunks", issue = "74985")]
    #[inline]
    pub fn as_rchunks_mut<const N: usize>(&mut self) -> (&mut [T], &mut [[T; N]]) {
        assert_ne!(N, 0);
        let len = self.len() / N;
        let (remainder, multiple_of_n) = self.split_at_mut(self.len() - len * N);
        // SIKKERHED: Vi var allerede i panik for nul og sikrede ved konstruktion
        // at længden af underdelen er et multiplum af N.
        let array_slice = unsafe { multiple_of_n.as_chunks_unchecked_mut() };
        (remainder, array_slice)
    }

    /// Returnerer en iterator over `N`-elementer af udsnittet ad gangen, startende i begyndelsen af udsnittet.
    ///
    /// Biterne er mutable array-referencer og overlapper ikke hinanden.
    /// Hvis `N` ikke opdeler længden af udsnittet, vil de sidste op til `N-1`-elementer blive udeladt og kan hentes fra iteratorens `into_remainder`-funktion.
    ///
    ///
    /// Denne metode er det const generiske ækvivalent med [`chunks_exact_mut`].
    ///
    /// # Panics
    ///
    /// Panics hvis `N` er 0. Denne kontrol bliver sandsynligvis ændret til en kompileringstidsfejl, før denne metode stabiliseres.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_chunks)]
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.array_chunks_mut() {
    ///     *chunk = [count; 2];
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[1, 1, 2, 2, 0]);
    /// ```
    ///
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    #[unstable(feature = "array_chunks", issue = "74985")]
    #[inline]
    pub fn array_chunks_mut<const N: usize>(&mut self) -> ArrayChunksMut<'_, T, N> {
        assert_ne!(N, 0);
        ArrayChunksMut::new(self)
    }

    /// Returnerer en iterator, der overlapper windows af `N`-elementer i et udsnit, begyndende ved begyndelsen af udsnittet.
    ///
    ///
    /// Dette er det const generiske ækvivalent med [`windows`].
    ///
    /// Hvis `N` er større end udsnittets størrelse, returnerer den ingen windows.
    ///
    /// # Panics
    ///
    /// Panics hvis `N` er 0.
    /// Denne kontrol ændres sandsynligvis til en kompileringstidsfejl, før denne metode bliver stabiliseret.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(array_windows)]
    /// let slice = [0, 1, 2, 3];
    /// let mut iter = slice.array_windows();
    /// assert_eq!(iter.next().unwrap(), &[0, 1]);
    /// assert_eq!(iter.next().unwrap(), &[1, 2]);
    /// assert_eq!(iter.next().unwrap(), &[2, 3]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`windows`]: slice::windows
    #[unstable(feature = "array_windows", issue = "75027")]
    #[inline]
    pub fn array_windows<const N: usize>(&self) -> ArrayWindows<'_, T, N> {
        assert_ne!(N, 0);
        ArrayWindows::new(self)
    }

    /// Returnerer en iterator over `chunk_size`-elementer af udsnittet ad gangen, startende i slutningen af udsnittet.
    ///
    /// Biterne er skiver og overlapper ikke hinanden.Hvis `chunk_size` ikke deler længden af skiven, har den sidste del ikke længden `chunk_size`.
    ///
    /// Se [`rchunks_exact`] for en variant af denne iterator, der returnerer klumper af altid nøjagtigt `chunk_size`-elementer, og [`chunks`] for den samme iterator, men starter ved begyndelsen af udsnittet.
    ///
    ///
    /// # Panics
    ///
    /// Panics hvis `chunk_size` er 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert_eq!(iter.next().unwrap(), &['l']);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// [`rchunks_exact`]: slice::rchunks_exact
    /// [`chunks`]: slice::chunks
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks(&self, chunk_size: usize) -> RChunks<'_, T> {
        assert!(chunk_size != 0);
        RChunks::new(self, chunk_size)
    }

    /// Returnerer en iterator over `chunk_size`-elementer af udsnittet ad gangen, startende i slutningen af udsnittet.
    ///
    /// Biterne er skiftelige skiver og overlapper ikke hinanden.Hvis `chunk_size` ikke deler længden af skiven, har den sidste del ikke længden `chunk_size`.
    ///
    /// Se [`rchunks_exact_mut`] for en variant af denne iterator, der returnerer klumper af altid nøjagtigt `chunk_size`-elementer, og [`chunks_mut`] for den samme iterator, men starter ved begyndelsen af udsnittet.
    ///
    ///
    /// # Panics
    ///
    /// Panics hvis `chunk_size` er 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[3, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`rchunks_exact_mut`]: slice::rchunks_exact_mut
    /// [`chunks_mut`]: slice::chunks_mut
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_mut(&mut self, chunk_size: usize) -> RChunksMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksMut::new(self, chunk_size)
    }

    /// Returnerer en iterator over `chunk_size`-elementer af udsnittet ad gangen, startende i slutningen af udsnittet.
    ///
    /// Biterne er skiver og overlapper ikke hinanden.
    /// Hvis `chunk_size` ikke opdeler længden af udsnittet, vil de sidste op til `chunk_size-1`-elementer blive udeladt og kan hentes fra iteratorens `remainder`-funktion.
    ///
    /// På grund af at hver del har nøjagtigt `chunk_size`-elementer, kan compileren ofte optimere den resulterende kode bedre end i tilfælde af [`chunks`].
    ///
    /// Se [`rchunks`] for en variant af denne iterator, der også returnerer resten som et mindre stykke, og [`chunks_exact`] for den samme iterator, men starter i begyndelsen af udsnittet.
    ///
    ///
    /// # Panics
    ///
    /// Panics hvis `chunk_size` er 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = ['l', 'o', 'r', 'e', 'm'];
    /// let mut iter = slice.rchunks_exact(2);
    /// assert_eq!(iter.next().unwrap(), &['e', 'm']);
    /// assert_eq!(iter.next().unwrap(), &['o', 'r']);
    /// assert!(iter.next().is_none());
    /// assert_eq!(iter.remainder(), &['l']);
    /// ```
    ///
    /// [`chunks`]: slice::chunks
    /// [`rchunks`]: slice::rchunks
    /// [`chunks_exact`]: slice::chunks_exact
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact(&self, chunk_size: usize) -> RChunksExact<'_, T> {
        assert!(chunk_size != 0);
        RChunksExact::new(self, chunk_size)
    }

    /// Returnerer en iterator over `chunk_size`-elementer af udsnittet ad gangen, startende i slutningen af udsnittet.
    ///
    /// Biterne er skiftelige skiver og overlapper ikke hinanden.
    /// Hvis `chunk_size` ikke opdeler længden af udsnittet, udelades de sidste op til `chunk_size-1`-elementer og kan hentes fra iteratorens `into_remainder`-funktion.
    ///
    /// På grund af at hver del har nøjagtigt `chunk_size`-elementer, kan compileren ofte optimere den resulterende kode bedre end i tilfælde af [`chunks_mut`].
    ///
    /// Se [`rchunks_mut`] for en variant af denne iterator, der også returnerer resten som et mindre stykke, og [`chunks_exact_mut`] for den samme iterator, men starter i begyndelsen af udsnittet.
    ///
    ///
    /// # Panics
    ///
    /// Panics hvis `chunk_size` er 0.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &mut [0, 0, 0, 0, 0];
    /// let mut count = 1;
    ///
    /// for chunk in v.rchunks_exact_mut(2) {
    ///     for elem in chunk.iter_mut() {
    ///         *elem += count;
    ///     }
    ///     count += 1;
    /// }
    /// assert_eq!(v, &[0, 2, 2, 1, 1]);
    /// ```
    ///
    /// [`chunks_mut`]: slice::chunks_mut
    /// [`rchunks_mut`]: slice::rchunks_mut
    /// [`chunks_exact_mut`]: slice::chunks_exact_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "rchunks", since = "1.31.0")]
    #[inline]
    pub fn rchunks_exact_mut(&mut self, chunk_size: usize) -> RChunksExactMut<'_, T> {
        assert!(chunk_size != 0);
        RChunksExactMut::new(self, chunk_size)
    }

    /// Returnerer en iterator over skiven, der producerer ikke-overlappende kørsler af elementer ved hjælp af prædikatet til at adskille dem.
    ///
    /// Prædikatet kaldes på to elementer, der følger sig selv, det betyder, at predikatet kaldes på `slice[0]` og `slice[1]`, derefter på `slice[1]` og `slice[2]` og så videre.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&[3, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Denne metode kan bruges til at udtrække de sorterede underudgaver:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &[1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&[1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3][..]));
    /// assert_eq!(iter.next(), Some(&[2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by<F>(&self, pred: F) -> GroupBy<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupBy::new(self, pred)
    }

    /// Returnerer en iterator over udsnittet, der producerer ikke-overlappende, mutable kørsler af elementer ved hjælp af prædikatet til at adskille dem.
    ///
    /// Prædikatet kaldes på to elementer, der følger sig selv, det betyder, at predikatet kaldes på `slice[0]` og `slice[1]`, derefter på `slice[1]` og `slice[2]` og så videre.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 1, 3, 3, 2, 2, 2];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a == b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 1][..]));
    /// assert_eq!(iter.next(), Some(&mut [3, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 2, 2][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Denne metode kan bruges til at udtrække de sorterede underudgaver:
    ///
    /// ```
    /// #![feature(slice_group_by)]
    ///
    /// let slice = &mut [1, 1, 2, 3, 2, 3, 2, 3, 4];
    ///
    /// let mut iter = slice.group_by_mut(|a, b| a <= b);
    ///
    /// assert_eq!(iter.next(), Some(&mut [1, 1, 2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3][..]));
    /// assert_eq!(iter.next(), Some(&mut [2, 3, 4][..]));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_group_by", issue = "80552")]
    #[inline]
    pub fn group_by_mut<F>(&mut self, pred: F) -> GroupByMut<'_, T, F>
    where
        F: FnMut(&T, &T) -> bool,
    {
        GroupByMut::new(self, pred)
    }

    /// Opdeler en skive i to ved et indeks.
    ///
    /// Den første vil indeholde alle indekser fra `[0, mid)` (undtagen selve indekset `mid`) og det andet vil indeholde alle indekser fra `[mid, len)` (eksklusive indekset `len` selv).
    ///
    ///
    /// # Panics
    ///
    /// Panics hvis `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// {
    ///    let (left, right) = v.split_at(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// {
    ///     let (left, right) = v.split_at(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at(&self, mid: usize) -> (&[T], &[T]) {
        assert!(mid <= self.len());
        // SIKKERHED: `[ptr; mid]` og `[mid; len]` er inde i `self`, hvilket
        // opfylder kravene i `from_raw_parts_mut`.
        unsafe { self.split_at_unchecked(mid) }
    }

    /// Opdeler en ændret skive i to ved et indeks.
    ///
    /// Den første vil indeholde alle indekser fra `[0, mid)` (undtagen selve indekset `mid`) og det andet vil indeholde alle indekser fra `[mid, len)` (eksklusive indekset `len` selv).
    ///
    ///
    /// # Panics
    ///
    /// Panics hvis `mid > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// let (left, right) = v.split_at_mut(2);
    /// assert_eq!(left, [1, 0]);
    /// assert_eq!(right, [3, 0, 5, 6]);
    /// left[1] = 2;
    /// right[1] = 4;
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_at_mut(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        assert!(mid <= self.len());
        // SIKKERHED: `[ptr; mid]` og `[mid; len]` er inde i `self`, hvilket
        // opfylder kravene i `from_raw_parts_mut`.
        unsafe { self.split_at_mut_unchecked(mid) }
    }

    /// Opdeler en skive i to ved et indeks uden at foretage grænsekontrol.
    ///
    /// Den første vil indeholde alle indekser fra `[0, mid)` (undtagen selve indekset `mid`) og det andet vil indeholde alle indekser fra `[mid, len)` (eksklusive indekset `len` selv).
    ///
    ///
    /// For et sikkert alternativ se [`split_at`].
    ///
    /// # Safety
    ///
    /// At kalde denne metode med et indeks uden for grænserne er *[udefineret adfærd]*, selvom den resulterende reference ikke bruges.Den, der ringer op, skal sikre sig, at `0 <= mid <= self.len()`.
    ///
    /// [`split_at`]: slice::split_at
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let v = [1, 2, 3, 4, 5, 6];
    ///
    /// unsafe {
    ///    let (left, right) = v.split_at_unchecked(0);
    ///    assert_eq!(left, []);
    ///    assert_eq!(right, [1, 2, 3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(2);
    ///     assert_eq!(left, [1, 2]);
    ///     assert_eq!(right, [3, 4, 5, 6]);
    /// }
    ///
    /// unsafe {
    ///     let (left, right) = v.split_at_unchecked(6);
    ///     assert_eq!(left, [1, 2, 3, 4, 5, 6]);
    ///     assert_eq!(right, []);
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_unchecked(&self, mid: usize) -> (&[T], &[T]) {
        // SIKKERHED: Opkalderen skal kontrollere, at `0 <= mid <= self.len()`
        unsafe { (self.get_unchecked(..mid), self.get_unchecked(mid..)) }
    }

    /// Opdeler en ændret skive i to ved et indeks uden at foretage grænsekontrol.
    ///
    /// Den første vil indeholde alle indekser fra `[0, mid)` (undtagen selve indekset `mid`) og det andet vil indeholde alle indekser fra `[mid, len)` (eksklusive indekset `len` selv).
    ///
    ///
    /// For et sikkert alternativ se [`split_at_mut`].
    ///
    /// # Safety
    ///
    /// At kalde denne metode med et indeks uden for grænserne er *[udefineret adfærd]*, selvom den resulterende reference ikke bruges.Den, der ringer op, skal sikre sig, at `0 <= mid <= self.len()`.
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```compile_fail
    /// #![feature(slice_split_at_unchecked)]
    ///
    /// let mut v = [1, 0, 3, 0, 5, 6];
    /// // scoped to restrict the lifetime of the borrows
    /// unsafe {
    ///     let (left, right) = v.split_at_mut_unchecked(2);
    ///     assert_eq!(left, [1, 0]);
    ///     assert_eq!(right, [3, 0, 5, 6]);
    ///     left[1] = 2;
    ///     right[1] = 4;
    /// }
    /// assert_eq!(v, [1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "slice_split_at_unchecked", reason = "new API", issue = "76014")]
    #[inline]
    unsafe fn split_at_mut_unchecked(&mut self, mid: usize) -> (&mut [T], &mut [T]) {
        let len = self.len();
        let ptr = self.as_mut_ptr();

        // SIKKERHED: Opkalderen skal kontrollere, at `0 <= mid <= self.len()`.
        //
        // `[ptr; mid]` og `[mid; len]` overlapper ikke, så det er fint at returnere en ændret reference.
        //
        unsafe { (from_raw_parts_mut(ptr, mid), from_raw_parts_mut(ptr.add(mid), len - mid)) }
    }

    /// Returnerer en iterator over underklasser adskilt af elementer, der matcher `pred`.
    /// Det matchede element er ikke indeholdt i underlicenser.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Hvis det første element matches, vil et tomt stykke være det første element, der returneres af iteratoren.
    /// Tilsvarende, hvis det sidste element i udsnittet matches, er et tomt stykke det sidste element, der returneres af iteratoren:
    ///
    ///
    /// ```
    /// let slice = [10, 40, 33];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Hvis to matchede elementer er direkte tilstødende, vil der være en tom skive mellem dem:
    ///
    /// ```
    /// let slice = [10, 6, 33, 20];
    /// let mut iter = slice.split(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10]);
    /// assert_eq!(iter.next().unwrap(), &[]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split<F>(&self, pred: F) -> Split<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        Split::new(self, pred)
    }

    /// Returnerer en iterator over mutable underlices adskilt af elementer, der matcher `pred`.
    /// Det matchede element er ikke indeholdt i underlicenser.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_mut(|num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 1]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn split_mut<F>(&mut self, pred: F) -> SplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitMut::new(self, pred)
    }

    /// Returnerer en iterator over underklasser adskilt af elementer, der matcher `pred`.
    /// Det matchede element er indeholdt i slutningen af den forrige underdel som en terminator.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [10, 40, 33, 20];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert_eq!(iter.next().unwrap(), &[20]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    /// Hvis det sidste element i udsnittet matches, vil dette element blive betragtet som terminatoren for det foregående udsnit.
    ///
    /// Dette stykke vil være det sidste element, der returneres af iteratoren.
    ///
    /// ```
    /// let slice = [3, 10, 40, 33];
    /// let mut iter = slice.split_inclusive(|num| num % 3 == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[3]);
    /// assert_eq!(iter.next().unwrap(), &[10, 40, 33]);
    /// assert!(iter.next().is_none());
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive<F>(&self, pred: F) -> SplitInclusive<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusive::new(self, pred)
    }

    /// Returnerer en iterator over mutable underlices adskilt af elementer, der matcher `pred`.
    /// Det matchede element er indeholdt i den forrige underdel som en terminator.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.split_inclusive_mut(|num| *num % 3 == 0) {
    ///     let terminator_idx = group.len()-1;
    ///     group[terminator_idx] = 1;
    /// }
    /// assert_eq!(v, [10, 40, 1, 20, 1, 1]);
    /// ```
    ///
    #[stable(feature = "split_inclusive", since = "1.51.0")]
    #[inline]
    pub fn split_inclusive_mut<F>(&mut self, pred: F) -> SplitInclusiveMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitInclusiveMut::new(self, pred)
    }

    /// Returnerer en iterator over underpartier adskilt af elementer, der matcher `pred`, startende i slutningen af udsnittet og arbejder baglæns.
    /// Det matchede element er ikke indeholdt i underlicenser.
    ///
    /// # Examples
    ///
    /// ```
    /// let slice = [11, 22, 33, 0, 44, 55];
    /// let mut iter = slice.rsplit(|num| *num == 0);
    ///
    /// assert_eq!(iter.next().unwrap(), &[44, 55]);
    /// assert_eq!(iter.next().unwrap(), &[11, 22, 33]);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Som med `split()`, hvis det første eller sidste element matches, vil et tomt stykke være det første (eller sidste) element, der returneres af iteratoren.
    ///
    ///
    /// ```
    /// let v = &[0, 1, 1, 2, 3, 5, 8];
    /// let mut it = v.rsplit(|n| *n % 2 == 0);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next().unwrap(), &[3, 5]);
    /// assert_eq!(it.next().unwrap(), &[1, 1]);
    /// assert_eq!(it.next().unwrap(), &[]);
    /// assert_eq!(it.next(), None);
    /// ```
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit<F>(&self, pred: F) -> RSplit<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplit::new(self, pred)
    }

    /// Returnerer en iterator over mutable underkliser adskilt af elementer, der matcher `pred`, startende i slutningen af skiven og arbejder baglæns.
    /// Det matchede element er ikke indeholdt i underlicenser.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [100, 400, 300, 200, 600, 500];
    ///
    /// let mut count = 0;
    /// for group in v.rsplit_mut(|num| *num % 3 == 0) {
    ///     count += 1;
    ///     group[0] = count;
    /// }
    /// assert_eq!(v, [3, 400, 300, 2, 600, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "slice_rsplit", since = "1.27.0")]
    #[inline]
    pub fn rsplit_mut<F>(&mut self, pred: F) -> RSplitMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitMut::new(self, pred)
    }

    /// Returnerer en iterator over underudgaver adskilt af elementer, der matcher `pred`, begrænset til at returnere højst `n`-emner.
    /// Det matchede element er ikke indeholdt i underlicenser.
    ///
    /// Det sidste returnerede element, hvis der er noget, vil indeholde resten af udsnittet.
    ///
    /// # Examples
    ///
    /// Udskriv skiven delt en gang med tal, der kan deles med 3 (dvs. `[10, 40]`, `[20, 60, 50]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn<F>(&self, n: usize, pred: F) -> SplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitN::new(self.split(pred), n)
    }

    /// Returnerer en iterator over underudgaver adskilt af elementer, der matcher `pred`, begrænset til at returnere højst `n`-emner.
    /// Det matchede element er ikke indeholdt i underlicenser.
    ///
    /// Det sidste returnerede element, hvis der er noget, vil indeholde resten af udsnittet.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.splitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(v, [1, 40, 30, 1, 60, 50]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn splitn_mut<F>(&mut self, n: usize, pred: F) -> SplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        SplitNMut::new(self.split_mut(pred), n)
    }

    /// Returnerer en iterator over underudskrifter adskilt af elementer, der matcher `pred`, begrænset til at returnere højst `n`-emner.
    /// Dette starter i slutningen af skiven og fungerer baglæns.
    /// Det matchede element er ikke indeholdt i underlicenser.
    ///
    /// Det sidste returnerede element, hvis der er noget, vil indeholde resten af udsnittet.
    ///
    /// # Examples
    ///
    /// Udskriv skiveopdelingen en gang, startende fra slutningen, med tal, der kan deles med 3 (dvs. `[50]`, `[10, 40, 30, 20]`):
    ///
    /// ```
    /// let v = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in v.rsplitn(2, |num| *num % 3 == 0) {
    ///     println!("{:?}", group);
    /// }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn<F>(&self, n: usize, pred: F) -> RSplitN<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitN::new(self.rsplit(pred), n)
    }

    /// Returnerer en iterator over underudskrifter adskilt af elementer, der matcher `pred`, begrænset til at returnere højst `n`-emner.
    /// Dette starter i slutningen af skiven og fungerer baglæns.
    /// Det matchede element er ikke indeholdt i underlicenser.
    ///
    /// Det sidste returnerede element, hvis der er noget, vil indeholde resten af udsnittet.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = [10, 40, 30, 20, 60, 50];
    ///
    /// for group in s.rsplitn_mut(2, |num| *num % 3 == 0) {
    ///     group[0] = 1;
    /// }
    /// assert_eq!(s, [1, 40, 30, 20, 60, 1]);
    /// ```
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn rsplitn_mut<F>(&mut self, n: usize, pred: F) -> RSplitNMut<'_, T, F>
    where
        F: FnMut(&T) -> bool,
    {
        RSplitNMut::new(self.rsplit_mut(pred), n)
    }

    /// Returnerer `true`, hvis udsnittet indeholder et element med den givne værdi.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.contains(&30));
    /// assert!(!v.contains(&50));
    /// ```
    ///
    /// Hvis du ikke har en `&T`, men bare en `&U` sådan, at `T: Borrow<U>` (f.eks
    /// `String: Lån<str>`), kan du bruge `iter().any`:
    ///
    /// ```
    /// let v = [String::from("hello"), String::from("world")]; // et stykke `String`
    /// assert!(v.iter().any(|e| e == "hello")); // søg med `&str`
    /// assert!(!v.iter().any(|e| e == "hi"));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq,
    {
        cmp::SliceContains::slice_contains(x, self)
    }

    /// Returnerer `true`, hvis `needle` er et præfiks for udsnittet.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.starts_with(&[10]));
    /// assert!(v.starts_with(&[10, 40]));
    /// assert!(!v.starts_with(&[50]));
    /// assert!(!v.starts_with(&[10, 50]));
    /// ```
    ///
    /// Returnerer altid `true`, hvis `needle` er et tomt stykke:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.starts_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.starts_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn starts_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let n = needle.len();
        self.len() >= n && needle == &self[..n]
    }

    /// Returnerer `true`, hvis `needle` er et suffiks af udsnittet.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [10, 40, 30];
    /// assert!(v.ends_with(&[30]));
    /// assert!(v.ends_with(&[40, 30]));
    /// assert!(!v.ends_with(&[50]));
    /// assert!(!v.ends_with(&[50, 30]));
    /// ```
    ///
    /// Returnerer altid `true`, hvis `needle` er et tomt stykke:
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert!(v.ends_with(&[]));
    /// let v: &[u8] = &[];
    /// assert!(v.ends_with(&[]));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn ends_with(&self, needle: &[T]) -> bool
    where
        T: PartialEq,
    {
        let (m, n) = (self.len(), needle.len());
        m >= n && needle == &self[m - n..]
    }

    /// Returnerer en underdel med præfikset fjernet.
    ///
    /// Hvis udsnittet starter med `prefix`, returneres delsnittet efter præfikset, pakket ind i `Some`.
    /// Hvis `prefix` er tom, skal du blot returnere det originale stykke.
    ///
    /// Hvis udsnittet ikke starter med `prefix`, returneres `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_prefix(&[10]), Some(&[40, 30][..]));
    /// assert_eq!(v.strip_prefix(&[10, 40]), Some(&[30][..]));
    /// assert_eq!(v.strip_prefix(&[50]), None);
    /// assert_eq!(v.strip_prefix(&[10, 50]), None);
    ///
    /// let prefix : &str = "he";
    /// assert_eq!(b"hello".strip_prefix(prefix.as_bytes()),
    ///            Some(b"llo".as_ref()));
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_prefix<P: SlicePattern<Item = T> + ?Sized>(&self, prefix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Denne funktion skal omskrives, hvis og når SlicePattern bliver mere sofistikeret.
        let prefix = prefix.as_slice();
        let n = prefix.len();
        if n <= self.len() {
            let (head, tail) = self.split_at(n);
            if head == prefix {
                return Some(tail);
            }
        }
        None
    }

    /// Returnerer en underdel med suffikset fjernet.
    ///
    /// Hvis udsnittet slutter med `suffix`, returneres undersnittet før suffikset, pakket ind i `Some`.
    /// Hvis `suffix` er tom, skal du blot returnere det originale stykke.
    ///
    /// Hvis udsnittet ikke ender med `suffix`, returneres `None`.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = &[10, 40, 30];
    /// assert_eq!(v.strip_suffix(&[30]), Some(&[10, 40][..]));
    /// assert_eq!(v.strip_suffix(&[40, 30]), Some(&[10][..]));
    /// assert_eq!(v.strip_suffix(&[50]), None);
    /// assert_eq!(v.strip_suffix(&[50, 30]), None);
    /// ```
    #[must_use = "returns the subslice without modifying the original"]
    #[stable(feature = "slice_strip", since = "1.51.0")]
    pub fn strip_suffix<P: SlicePattern<Item = T> + ?Sized>(&self, suffix: &P) -> Option<&[T]>
    where
        T: PartialEq,
    {
        // Denne funktion skal omskrives, hvis og når SlicePattern bliver mere sofistikeret.
        let suffix = suffix.as_slice();
        let (len, n) = (self.len(), suffix.len());
        if n <= len {
            let (head, tail) = self.split_at(len - n);
            if tail == suffix {
                return Some(head);
            }
        }
        None
    }

    /// Binær søger i dette sorterede udsnit efter et givet element.
    ///
    /// Hvis værdien findes, returneres [`Result::Ok`] indeholdende indekset for det matchende element.
    /// Hvis der er flere kampe, kan en af kampene returneres.
    /// Hvis værdien ikke findes, returneres [`Result::Err`] med indekset, hvor et matchende element kunne indsættes, mens den sorterede rækkefølge opretholdes.
    ///
    ///
    /// Se også [`binary_search_by`], [`binary_search_by_key`] og [`partition_point`].
    ///
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Slår op på en række på fire elementer.
    /// Den første findes med en enestående bestemt position;den anden og den tredje findes ikke;den fjerde kunne matche enhver position i `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// assert_eq!(s.binary_search(&13),  Ok(9));
    /// assert_eq!(s.binary_search(&4),   Err(7));
    /// assert_eq!(s.binary_search(&100), Err(13));
    /// let r = s.binary_search(&1);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    /// Hvis du vil indsætte et element i en sorteret vector, mens du opretholder sorteringsrækkefølgen:
    ///
    /// ```
    /// let mut s = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    /// let num = 42;
    /// let idx = s.binary_search(&num).unwrap_or_else(|x| x);
    /// s.insert(idx, num);
    /// assert_eq!(s, [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|p| p.cmp(x))
    }

    /// Binær søger i dette sorterede udsnit med en komparatorfunktion.
    ///
    /// Komparatorfunktionen skal implementere en ordre, der er i overensstemmelse med sorteringsrækkefølgen for det underliggende udsnit, og returnere en ordrekode, der angiver, om dens argument er `Less`, `Equal` eller `Greater` det ønskede mål.
    ///
    ///
    /// Hvis værdien findes, returneres [`Result::Ok`] med indekset for det matchende element.Hvis der er flere kampe, kan en af kampene returneres.
    /// Hvis værdien ikke findes, returneres [`Result::Err`] med indekset, hvor et matchende element kunne indsættes, mens den sorterede rækkefølge opretholdes.
    ///
    /// Se også [`binary_search`], [`binary_search_by_key`] og [`partition_point`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Slår op på en række på fire elementer.Den første findes med en enestående bestemt position;den anden og den tredje findes ikke;den fjerde kunne matche enhver position i `[1, 4]`.
    ///
    /// ```
    /// let s = [0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55];
    ///
    /// let seek = 13;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Ok(9));
    /// let seek = 4;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(7));
    /// let seek = 100;
    /// assert_eq!(s.binary_search_by(|probe| probe.cmp(&seek)), Err(13));
    /// let seek = 1;
    /// let r = s.binary_search_by(|probe| probe.cmp(&seek));
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let mut size = self.len();
        let mut left = 0;
        let mut right = size;
        while left < right {
            let mid = left + size / 2;

            // SIKKERHED: opkaldet er gjort sikkert af følgende invariantere:
            // - `mid >= 0`
            // - `mid < size`: `mid` er begrænset af `[left; right)` bundet.
            let cmp = f(unsafe { self.get_unchecked(mid) });

            // Årsagen til, at vi bruger if/else-kontrolflow i stedet for at matche, er fordi match omorganiserer sammenligningsoperationer, som er perfekt følsom.
            //
            // Dette er x86 asm til u8: https://rust.godbolt.org/z/8Y8Pra.
            if cmp == Less {
                left = mid + 1;
            } else if cmp == Greater {
                right = mid;
            } else {
                return Ok(mid);
            }

            size = right - left;
        }
        Err(left)
    }

    /// Binær søger i dette sorterede udsnit med en nøgleudvindingsfunktion.
    ///
    /// Antager, at udsnittet er sorteret efter nøglen, for eksempel med [`sort_by_key`] ved hjælp af den samme nøgleudtrækningsfunktion.
    ///
    /// Hvis værdien findes, returneres [`Result::Ok`] indeholdende indekset for det matchende element.
    /// Hvis der er flere kampe, kan en af kampene returneres.
    /// Hvis værdien ikke findes, returneres [`Result::Err`] med indekset, hvor et matchende element kunne indsættes, mens den sorterede rækkefølge opretholdes.
    ///
    ///
    /// Se også [`binary_search`], [`binary_search_by`] og [`partition_point`].
    ///
    /// [`sort_by_key`]: slice::sort_by_key
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`partition_point`]: slice::partition_point
    ///
    /// # Examples
    ///
    /// Slår op på en række med fire elementer i et par par sorteret efter deres andet elementer.
    /// Den første findes med en enestående bestemt position;den anden og den tredje findes ikke;den fjerde kunne matche enhver position i `[1, 4]`.
    ///
    /// ```
    /// let s = [(0, 0), (2, 1), (4, 1), (5, 1), (3, 1),
    ///          (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)];
    ///
    /// assert_eq!(s.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(s.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(s.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = s.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(match r { Ok(1..=4) => true, _ => false, });
    /// ```
    ///
    ///
    ///
    ///
    // Lint rustdoc::broken_intra_doc_links er tilladt, da `slice::sort_by_key` er i crate `alloc`, og som sådan ikke eksisterer endnu, når man bygger `core`.
    //
    // links til downstream crate: #74481.Da primitive kun er dokumenteret i libstd (#73423), fører dette aldrig til ødelagte links i praksis.
    //
    #[cfg_attr(not(bootstrap), allow(rustdoc::broken_intra_doc_links))]
    #[cfg_attr(bootstrap, allow(broken_intra_doc_links))]
    #[stable(feature = "slice_binary_search_by_key", since = "1.10.0")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }

    /// Sorterer skiven, men bevarer muligvis ikke rækkefølgen af lige elementer.
    ///
    /// Denne slags er ustabil (dvs. kan omorganisere lige store elementer), på stedet (dvs. allokerer ikke) og *O*(*n*\*log(* n*)) worst-case.
    ///
    /// # Nuværende implementering
    ///
    /// Den nuværende algoritme er baseret på [pattern-defeating quicksort][pdqsort] af Orson Peters, som kombinerer det hurtige gennemsnitstilfælde af randomiseret quicksort med det hurtigste værste tilfælde af heapsort, samtidig med at der opnås lineær tid på skiver med visse mønstre.
    /// Det bruger en vis randomisering for at undgå degenererede tilfælde, men med en fast seed til altid at give deterministisk adfærd.
    ///
    /// Det er typisk hurtigere end stabil sortering undtagen i nogle få specielle tilfælde, fx når skiven består af flere sammenkædede sorterede sekvenser.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort_unstable();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable(&mut self)
    where
        T: Ord,
    {
        sort::quicksort(self, |a, b| a.lt(b));
    }

    /// Sorterer skiven med en komparatorfunktion, men bevarer muligvis ikke rækkefølgen af lige elementer.
    ///
    /// Denne slags er ustabil (dvs. kan omorganisere lige store elementer), på stedet (dvs. allokerer ikke) og *O*(*n*\*log(* n*)) worst-case.
    ///
    /// Komparatorfunktionen skal definere en samlet rækkefølge for elementerne i udsnittet.Hvis ordren ikke er total, er rækkefølgen af elementerne uspecificeret.En ordre er en samlet ordre, hvis den er (for alle `a`, `b` og `c`):
    ///
    /// * total og antisymmetrisk: nøjagtigt en af `a < b`, `a == b` eller `a > b` er sand, og
    /// * transitive, `a < b` og `b < c` indebærer `a < c`.Det samme skal gælde for både `==` og `>`.
    ///
    /// For eksempel, mens [`f64`] ikke implementerer [`Ord`] fordi `NaN != NaN`, kan vi bruge `partial_cmp` som vores sorteringsfunktion, når vi ved, at udsnittet ikke indeholder en `NaN`.
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_unstable_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// # Nuværende implementering
    ///
    /// Den nuværende algoritme er baseret på [pattern-defeating quicksort][pdqsort] af Orson Peters, som kombinerer det hurtige gennemsnitstilfælde af randomiseret quicksort med det hurtigste værste tilfælde af heapsort, samtidig med at der opnås lineær tid på skiver med visse mønstre.
    /// Det bruger en vis randomisering for at undgå degenererede tilfælde, men med en fast seed til altid at give deterministisk adfærd.
    ///
    /// Det er typisk hurtigere end stabil sortering undtagen i nogle få specielle tilfælde, fx når skiven består af flere sammenkædede sorterede sekvenser.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_unstable_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // omvendt sortering
    /// v.sort_unstable_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        sort::quicksort(self, |a, b| compare(a, b) == Ordering::Less);
    }

    /// Sorterer skiven med en nøgleudvindingsfunktion, men bevarer muligvis ikke rækkefølgen af lige elementer.
    ///
    /// Denne slags er ustabil (dvs. kan omorganisere lige store elementer), på plads (dvs. allokerer ikke) og *O*(m\* * n *\* log(*n*)) worst-case, hvor nøglefunktionen er *O*(*m*).
    ///
    /// # Nuværende implementering
    ///
    /// Den nuværende algoritme er baseret på [pattern-defeating quicksort][pdqsort] af Orson Peters, som kombinerer det hurtige gennemsnitstilfælde af randomiseret quicksort med det hurtigste værste tilfælde af heapsort, samtidig med at der opnås lineær tid på skiver med visse mønstre.
    /// Det bruger en vis randomisering for at undgå degenererede tilfælde, men med en fast seed til altid at give deterministisk adfærd.
    ///
    /// På grund af sin nøgleopkaldsstrategi er [`sort_unstable_by_key`](#method.sort_unstable_by_key) sandsynligvis langsommere end [`sort_by_cached_key`](#method.sort_by_cached_key) i tilfælde, hvor nøglefunktionen er dyr.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_unstable_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "sort_unstable", since = "1.20.0")]
    #[inline]
    pub fn sort_unstable_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        sort::quicksort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Omarranger skiven, så elementet ved `index` er i sin endelige sorterede position.
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable() instead")]
    #[inline]
    pub fn partition_at_index(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        self.select_nth_unstable(index)
    }

    /// Omarranger skiven med en komparatorfunktion, så elementet ved `index` er i sin endelige sorterede position.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use select_nth_unstable_by() instead")]
    #[inline]
    pub fn partition_at_index_by<F>(
        &mut self,
        index: usize,
        compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        self.select_nth_unstable_by(index, compare)
    }

    /// Omarranger skiven med en nøgleudtrækningsfunktion, så elementet ved `index` er i sin endelige sorterede position.
    ///
    #[unstable(feature = "slice_partition_at_index", issue = "55300")]
    #[rustc_deprecated(since = "1.49.0", reason = "use the select_nth_unstable_by_key() instead")]
    #[inline]
    pub fn partition_at_index_by_key<K, F>(
        &mut self,
        index: usize,
        f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        self.select_nth_unstable_by_key(index, f)
    }

    /// Omarranger skiven, så elementet ved `index` er i sin endelige sorterede position.
    ///
    /// Denne ombestilling har den yderligere egenskab, at enhver værdi på position `i < index` vil være mindre end eller lig med enhver værdi på en position `j > index`.
    /// Derudover er denne ombestilling ustabil (dvs.
    /// et vilkårligt antal lige elementer kan ende i position `index`) på plads (dvs.
    /// tildeler ikke) og *O*(*n*) worst-case.
    /// Denne funktion er også kendt som "kth element" i andre biblioteker.
    /// Den returnerer en triplet af følgende værdier: alle elementer mindre end den ved det givne indeks, værdien ved det givne indeks og alle elementer større end den ved det givne indeks.
    ///
    ///
    /// # Nuværende implementering
    ///
    /// Den aktuelle algoritme er baseret på quickselect-delen af den samme quicksort-algoritme, der bruges til [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics når `index >= len()`, hvilket betyder at det altid panics på tomme skiver.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Find medianen
    /// v.select_nth_unstable(2);
    ///
    /// // Vi er kun garanteret, at udsnittet vil være et af følgende, baseret på den måde, vi sorterer på det angivne indeks.
    /////
    /// assert!(v == [-3, -5, 1, 2, 4] ||
    ///         v == [-5, -3, 1, 2, 4] ||
    ///         v == [-3, -5, 1, 4, 2] ||
    ///         v == [-5, -3, 1, 4, 2]);
    /// ```
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable(&mut self, index: usize) -> (&mut [T], &mut T, &mut [T])
    where
        T: Ord,
    {
        let mut f = |a: &T, b: &T| a.lt(b);
        sort::partition_at_index(self, index, &mut f)
    }

    /// Omarranger skiven med en komparatorfunktion, så elementet ved `index` er i sin endelige sorterede position.
    ///
    /// Denne ombestilling har den yderligere egenskab, at enhver værdi på position `i < index` vil være mindre end eller lig med en værdi på en position `j > index` ved hjælp af komparatorfunktionen.
    /// Derudover er denne ombestilling ustabil (dvs. et vilkårligt antal lige elementer kan ende i position `index`), på plads (dvs. allokerer ikke) og *O*(*n*) i værste fald.
    /// Denne funktion er også kendt som "kth element" i andre biblioteker.
    /// Det returnerer en triplet af følgende værdier: alle elementer mindre end den ved det givne indeks, værdien ved det givne indeks og alle elementer større end den ved det givne indeks ved hjælp af den medfølgende komparatorfunktion.
    ///
    ///
    /// # Nuværende implementering
    ///
    /// Den aktuelle algoritme er baseret på quickselect-delen af den samme quicksort-algoritme, der bruges til [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics når `index >= len()`, hvilket betyder at det altid panics på tomme skiver.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Find medianen, som om udsnittet blev sorteret i faldende rækkefølge.
    /// v.select_nth_unstable_by(2, |a, b| b.cmp(a));
    ///
    /// // Vi er kun garanteret, at udsnittet vil være et af følgende, baseret på den måde, vi sorterer på det angivne indeks.
    /////
    /// assert!(v == [2, 4, 1, -5, -3] ||
    ///         v == [2, 4, 1, -3, -5] ||
    ///         v == [4, 2, 1, -5, -3] ||
    ///         v == [4, 2, 1, -3, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by<F>(
        &mut self,
        index: usize,
        mut compare: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        let mut f = |a: &T, b: &T| compare(a, b) == Less;
        sort::partition_at_index(self, index, &mut f)
    }

    /// Omarranger skiven med en nøgleudtrækningsfunktion, så elementet ved `index` er i sin endelige sorterede position.
    ///
    /// Denne ombestilling har den yderligere egenskab, at enhver værdi på position `i < index` vil være mindre end eller lig med enhver værdi på en position `j > index` ved hjælp af nøgleudtrækningsfunktionen.
    /// Derudover er denne ombestilling ustabil (dvs. et vilkårligt antal lige elementer kan ende i position `index`), på plads (dvs. allokerer ikke) og *O*(*n*) i værste fald.
    /// Denne funktion er også kendt som "kth element" i andre biblioteker.
    /// Det returnerer en triplet af følgende værdier: alle elementer mindre end den ene ved det givne indeks, værdien ved det givne indeks og alle elementer større end den ved den givne indeks ved hjælp af den medfølgende nøgleudvindingsfunktion.
    ///
    ///
    /// # Nuværende implementering
    ///
    /// Den aktuelle algoritme er baseret på quickselect-delen af den samme quicksort-algoritme, der bruges til [`sort_unstable`].
    ///
    /// [`sort_unstable`]: slice::sort_unstable
    ///
    /// # Panics
    ///
    /// Panics når `index >= len()`, hvilket betyder at det altid panics på tomme skiver.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// // Returner medianen, som om arrayet var sorteret efter absolut værdi.
    /// v.select_nth_unstable_by_key(2, |a| a.abs());
    ///
    /// // Vi er kun garanteret, at udsnittet vil være et af følgende, baseret på den måde, vi sorterer på det angivne indeks.
    /////
    /// assert!(v == [1, 2, -3, 4, -5] ||
    ///         v == [1, 2, -3, -5, 4] ||
    ///         v == [2, 1, -3, 4, -5] ||
    ///         v == [2, 1, -3, -5, 4]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_select_nth_unstable", since = "1.49.0")]
    #[inline]
    pub fn select_nth_unstable_by_key<K, F>(
        &mut self,
        index: usize,
        mut f: F,
    ) -> (&mut [T], &mut T, &mut [T])
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        let mut g = |a: &T, b: &T| f(a).lt(&f(b));
        sort::partition_at_index(self, index, &mut g)
    }

    /// Flytter alle på hinanden følgende gentagne elementer til slutningen af udsnittet i henhold til [`PartialEq`] trait-implementeringen.
    ///
    ///
    /// Returnerer to skiver.Den første indeholder ingen gentagne gentagne elementer.
    /// Den anden indeholder alle duplikaterne i ingen specificeret rækkefølge.
    ///
    /// Hvis udsnittet er sorteret, indeholder det første returnerede udsnit ingen dubletter.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [1, 2, 2, 3, 3, 2, 1, 1];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup();
    ///
    /// assert_eq!(dedup, [1, 2, 3, 2, 1]);
    /// assert_eq!(duplicates, [2, 3, 1]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup(&mut self) -> (&mut [T], &mut [T])
    where
        T: PartialEq,
    {
        self.partition_dedup_by(|a, b| a == b)
    }

    /// Flytter alle undtagen de første på hinanden følgende elementer til slutningen af skiven, der tilfredsstiller en given ligestillingsrelation.
    ///
    /// Returnerer to skiver.Den første indeholder ingen gentagne gentagne elementer.
    /// Den anden indeholder alle duplikaterne i ingen specificeret rækkefølge.
    ///
    /// `same_bucket`-funktionen sendes henvisninger til to elementer fra udsnittet og skal afgøre, om elementerne sammenligner ens.
    /// Elementerne sendes i modsat rækkefølge fra deres rækkefølge i udsnittet, så hvis `same_bucket(a, b)` returnerer `true`, flyttes `a` i slutningen af udsnittet.
    ///
    ///
    /// Hvis udsnittet er sorteret, indeholder det første returnerede udsnit ingen dubletter.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = ["foo", "Foo", "BAZ", "Bar", "bar", "baz", "BAZ"];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(dedup, ["foo", "BAZ", "Bar", "baz"]);
    /// assert_eq!(duplicates, ["bar", "Foo", "BAZ"]);
    /// ```
    ///
    ///
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by<F>(&mut self, mut same_bucket: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        // Selvom vi har en ændret henvisning til `self`, kan vi ikke foretage *vilkårlige* ændringer.`same_bucket`-opkaldene kunne panic, så vi skal sikre, at udsnittet til enhver tid er i en gyldig tilstand.
        //
        // Den måde, vi håndterer dette på er ved at bruge swaps;vi gentager alle elementerne og bytter, når vi går, så i sidste ende er de elementer, vi ønsker at beholde, foran, og dem, vi ønsker at afvise, er bagest.
        // Vi kan derefter opdele skiven.
        // Denne handling er stadig `O(n)`.
        //
        // Eksempel: Vi starter i denne tilstand, hvor `r` repræsenterer "næste
        // læs "og `w` repræsenterer" næste_skrivning ".
        //
        //           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //           w
        //
        // Sammenligning af self[r] mod selv [w-1] er dette ikke en duplikat, så vi bytter self[r] og self[w] (ingen effekt som r==w) og forøger derefter både r og w og efterlader os med:
        //
        //               r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Sammenligning af self[r] mod selv [w-1] er denne værdi en duplikat, så vi øger `r`, men lader alt andet være uændret:
        //
        //                   r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 1 | 2 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //               w
        //
        // Sammenligning af self[r] mod selv [w-1] er dette ikke en duplikat, så skift self[r] og self[w] og fremad r og w:
        //
        //                       r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 1 | 3 | 3 |
        //     +---+---+---+---+---+---+
        //                   w
        //
        // Ikke en kopi, gentag:
        //
        //                           r
        //     +---+---+---+---+---+---+
        //     | 0 | 1 | 2 | 3 | 1 | 3 |
        //     +---+---+---+---+---+---+
        //                       w
        //
        // Duplicate, advance r. End af skive.Opdel ved w.
        //
        //
        //
        //
        //
        //
        //
        //

        let len = self.len();
        if len <= 1 {
            return (self, &mut []);
        }

        let ptr = self.as_mut_ptr();
        let mut next_read: usize = 1;
        let mut next_write: usize = 1;

        // SIKKERHED: `while`-tilstanden garanterer `next_read` og `next_write`
        // er mindre end `len`, så de er inde i `self`.
        // `prev_ptr_write` peger på et element før `ptr_write`, men `next_write` starter ved 1, så `prev_ptr_write` er aldrig mindre end 0 og er inde i udsnittet.
        // Dette opfylder kravene til derferference `ptr_read`, `prev_ptr_write` og `ptr_write` og til brug af `ptr.add(next_read)`, `ptr.add(next_write - 1)` og `prev_ptr_write.offset(1)`.
        //
        //
        // `next_write` øges også højst en gang pr. loop højst, hvilket betyder, at der ikke springes noget element over, når det muligvis skal udskiftes.
        //
        // `ptr_read` og `prev_ptr_write` peger aldrig på det samme element.Dette kræves for at `&mut *ptr_read`, `&mut* prev_ptr_write` er sikkert.
        // Forklaringen er simpelthen, at `next_read >= next_write` altid er sand, så `next_read > next_write - 1` også er.
        //
        //
        //
        //
        //
        unsafe {
            // Undgå grænsekontrol ved at bruge rå pointer.
            while next_read < len {
                let ptr_read = ptr.add(next_read);
                let prev_ptr_write = ptr.add(next_write - 1);
                if !same_bucket(&mut *ptr_read, &mut *prev_ptr_write) {
                    if next_read != next_write {
                        let ptr_write = prev_ptr_write.offset(1);
                        mem::swap(&mut *ptr_read, &mut *ptr_write);
                    }
                    next_write += 1;
                }
                next_read += 1;
            }
        }

        self.split_at_mut(next_write)
    }

    /// Flytter alle undtagen de første på hinanden følgende elementer til slutningen af udsnittet, der løser samme nøgle.
    ///
    ///
    /// Returnerer to skiver.Den første indeholder ingen gentagne gentagne elementer.
    /// Den anden indeholder alle duplikaterne i ingen specificeret rækkefølge.
    ///
    /// Hvis udsnittet er sorteret, indeholder det første returnerede udsnit ingen dubletter.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_partition_dedup)]
    ///
    /// let mut slice = [10, 20, 21, 30, 30, 20, 11, 13];
    ///
    /// let (dedup, duplicates) = slice.partition_dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(dedup, [10, 20, 30, 20, 11]);
    /// assert_eq!(duplicates, [21, 30, 13]);
    /// ```
    #[unstable(feature = "slice_partition_dedup", issue = "54279")]
    #[inline]
    pub fn partition_dedup_by_key<K, F>(&mut self, mut key: F) -> (&mut [T], &mut [T])
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.partition_dedup_by(|a, b| key(a) == key(b))
    }

    /// Roterer skiven på plads, så de første `mid`-elementer i skiven bevæger sig til enden, mens de sidste `self.len() - mid`-elementer bevæger sig fremad.
    /// Efter at have ringet til `rotate_left`, bliver elementet tidligere ved indeks `mid` det første element i udsnittet.
    ///
    /// # Panics
    ///
    /// Denne funktion vil panic, hvis `mid` er større end længden på skiven.Bemærk, at `mid == self.len()` gør _not_ panic og er en no-op rotation.
    ///
    /// # Complexity
    ///
    /// Tager lineær (i `self.len()`) tid.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_left(2);
    /// assert_eq!(a, ['c', 'd', 'e', 'f', 'a', 'b']);
    /// ```
    ///
    /// Rotering af en underdel:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_left(1);
    /// assert_eq!(a, ['a', 'c', 'd', 'e', 'b', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        let p = self.as_mut_ptr();

        // SIKKERHED: Området `[p.add(mid) - mid, p.add(mid) + k)` er trivielt
        // gyldig til læsning og skrivning, som krævet af `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Roterer skiven på plads, så de første `self.len() - k`-elementer i skiven bevæger sig til enden, mens de sidste `k`-elementer bevæger sig fremad.
    /// Efter at have ringet til `rotate_right`, bliver elementet tidligere ved indeks `self.len() - k` det første element i udsnittet.
    ///
    /// # Panics
    ///
    /// Denne funktion vil panic, hvis `k` er større end længden på skiven.Bemærk, at `k == self.len()` gør _not_ panic og er en no-op rotation.
    ///
    /// # Complexity
    ///
    /// Tager lineær (i `self.len()`) tid.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a.rotate_right(2);
    /// assert_eq!(a, ['e', 'f', 'a', 'b', 'c', 'd']);
    /// ```
    ///
    /// Drej en underdel:
    ///
    /// ```
    /// let mut a = ['a', 'b', 'c', 'd', 'e', 'f'];
    /// a[1..5].rotate_right(1);
    /// assert_eq!(a, ['a', 'e', 'b', 'c', 'd', 'f']);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_rotate", since = "1.26.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        let p = self.as_mut_ptr();

        // SIKKERHED: Området `[p.add(mid) - mid, p.add(mid) + k)` er trivielt
        // gyldig til læsning og skrivning, som krævet af `ptr_rotate`.
        unsafe {
            rotate::ptr_rotate(mid, p.add(mid), k);
        }
    }

    /// Fylder `self` med elementer ved at klone `value`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![0; 10];
    /// buf.fill(1);
    /// assert_eq!(buf, vec![1; 10]);
    /// ```
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill", since = "1.50.0")]
    pub fn fill(&mut self, value: T)
    where
        T: Clone,
    {
        specialize::SpecFill::spec_fill(self, value);
    }

    /// Fylder `self` med elementer, der returneres ved gentagne gange at ringe til en lukning.
    ///
    /// Denne metode bruger en lukning til at skabe nye værdier.Hvis du hellere vil [`Clone`] en given værdi, skal du bruge [`fill`].
    /// Hvis du vil bruge [`Default`] trait til at generere værdier, kan du videregive [`Default::default`] som argument.
    ///
    ///
    /// [`fill`]: slice::fill
    ///
    /// # Examples
    ///
    /// ```
    /// let mut buf = vec![1; 10];
    /// buf.fill_with(Default::default);
    /// assert_eq!(buf, vec![0; 10]);
    /// ```
    ///
    #[doc(alias = "memset")]
    #[stable(feature = "slice_fill_with", since = "1.51.0")]
    pub fn fill_with<F>(&mut self, mut f: F)
    where
        F: FnMut() -> T,
    {
        for el in self {
            *el = f();
        }
    }

    /// Kopierer elementerne fra `src` til `self`.
    ///
    /// Længden af `src` skal være den samme som `self`.
    ///
    /// Hvis `T` implementerer `Copy`, kan det være mere effektiv at bruge [`copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Denne funktion vil panic, hvis de to skiver har forskellige længder.
    ///
    /// # Examples
    ///
    /// Kloning af to elementer fra et stykke i et andet:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Da skiverne skal have samme længde, skiver vi kildeskiven fra fire elementer til to.
    /// // Det vil panic, hvis vi ikke gør dette.
    /////
    /// dst.clone_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust håndhæver, at der kun kan være en ændret reference uden uforanderlige referencer til et bestemt stykke data i et bestemt omfang.
    /// På grund af dette vil forsøg på at bruge `clone_from_slice` på et enkelt stykke resultere i en kompileringsfejl:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].clone_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// For at omgå dette kan vi bruge [`split_at_mut`] til at oprette to forskellige underskiver fra en skive:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.clone_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`copy_from_slice`]: slice::copy_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    ///
    #[stable(feature = "clone_from_slice", since = "1.7.0")]
    pub fn clone_from_slice(&mut self, src: &[T])
    where
        T: Clone,
    {
        self.spec_clone_from(src);
    }

    /// Kopierer alle elementer fra `src` til `self` ved hjælp af en memcpy.
    ///
    /// Længden af `src` skal være den samme som `self`.
    ///
    /// Hvis `T` ikke implementerer `Copy`, skal du bruge [`clone_from_slice`].
    ///
    /// # Panics
    ///
    /// Denne funktion vil panic, hvis de to skiver har forskellige længder.
    ///
    /// # Examples
    ///
    /// Kopiering af to elementer fra et stykke til et andet:
    ///
    /// ```
    /// let src = [1, 2, 3, 4];
    /// let mut dst = [0, 0];
    ///
    /// // Da skiverne skal have samme længde, skiver vi kildeskiven fra fire elementer til to.
    /// // Det vil panic, hvis vi ikke gør dette.
    /////
    /// dst.copy_from_slice(&src[2..]);
    ///
    /// assert_eq!(src, [1, 2, 3, 4]);
    /// assert_eq!(dst, [3, 4]);
    /// ```
    ///
    /// Rust håndhæver, at der kun kan være en ændret reference uden uforanderlige referencer til et bestemt stykke data i et bestemt omfang.
    /// På grund af dette vil forsøg på at bruge `copy_from_slice` på et enkelt stykke resultere i en kompileringsfejl:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// slice[..2].copy_from_slice(&slice[3..]); // compile fail!
    /// ```
    ///
    /// For at omgå dette kan vi bruge [`split_at_mut`] til at oprette to forskellige underskiver fra en skive:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.copy_from_slice(&right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 4, 5]);
    /// ```
    ///
    /// [`clone_from_slice`]: slice::clone_from_slice
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    ///
    #[doc(alias = "memcpy")]
    #[stable(feature = "copy_from_slice", since = "1.9.0")]
    pub fn copy_from_slice(&mut self, src: &[T])
    where
        T: Copy,
    {
        // panic-kodestien blev sat i en kold funktion for ikke at blæse opringningsstedet.
        //
        #[inline(never)]
        #[cold]
        #[track_caller]
        fn len_mismatch_fail(dst_len: usize, src_len: usize) -> ! {
            panic!(
                "source slice length ({}) does not match destination slice length ({})",
                src_len, dst_len,
            );
        }

        if self.len() != src.len() {
            len_mismatch_fail(self.len(), src.len());
        }

        // SIKKERHED: `self` er pr. Definition gyldig for `self.len()`-elementer, og `src` var
        // kontrolleret for at have samme længde.
        // Skiverne kan ikke overlappe hinanden, fordi mutable referencer er eksklusive.
        unsafe {
            ptr::copy_nonoverlapping(src.as_ptr(), self.as_mut_ptr(), self.len());
        }
    }

    /// Kopierer elementer fra en del af skiven til en anden del af sig selv ved hjælp af en memmove.
    ///
    /// `src` er området inden for `self` at kopiere fra.
    /// `dest` er startindekset for området inden for `self`, der skal kopieres til, som har samme længde som `src`.
    /// De to områder kan overlappe hinanden.
    /// Enderne af de to områder skal være mindre end eller lig med `self.len()`.
    ///
    /// # Panics
    ///
    /// Denne funktion vil panic, hvis begge områder overstiger slutningen af udsnittet, eller hvis slutningen af `src` er inden starten.
    ///
    ///
    /// # Examples
    ///
    /// Kopiering af fire byte inden for et udsnit:
    ///
    /// ```
    /// let mut bytes = *b"Hello, World!";
    ///
    /// bytes.copy_within(1..5, 8);
    ///
    /// assert_eq!(&bytes, b"Hello, Wello!");
    /// ```
    ///
    #[stable(feature = "copy_within", since = "1.37.0")]
    #[track_caller]
    pub fn copy_within<R: RangeBounds<usize>>(&mut self, src: R, dest: usize)
    where
        T: Copy,
    {
        let Range { start: src_start, end: src_end } = slice::range(src, ..self.len());
        let count = src_end - src_start;
        assert!(dest <= self.len() - count, "dest is out of bounds");
        // SIKKERHED: Betingelserne for `ptr::copy` er alle kontrolleret ovenfor,
        // ligesom dem til `ptr::add`.
        unsafe {
            ptr::copy(self.as_ptr().add(src_start), self.as_mut_ptr().add(dest), count);
        }
    }

    /// Bytter alle elementer i `self` med dem i `other`.
    ///
    /// Længden af `other` skal være den samme som `self`.
    ///
    /// # Panics
    ///
    /// Denne funktion vil panic, hvis de to skiver har forskellige længder.
    ///
    /// # Example
    ///
    /// Bytte to elementer på tværs af skiver:
    ///
    /// ```
    /// let mut slice1 = [0, 0];
    /// let mut slice2 = [1, 2, 3, 4];
    ///
    /// slice1.swap_with_slice(&mut slice2[2..]);
    ///
    /// assert_eq!(slice1, [3, 4]);
    /// assert_eq!(slice2, [1, 2, 0, 0]);
    /// ```
    ///
    /// Rust håndhæver, at der kun kan være en ændret henvisning til et bestemt stykke data i et bestemt omfang.
    ///
    /// På grund af dette vil forsøg på at bruge `swap_with_slice` på et enkelt stykke resultere i en kompileringsfejl:
    ///
    /// ```compile_fail
    /// let mut slice = [1, 2, 3, 4, 5];
    /// slice[..2].swap_with_slice(&mut slice[3..]); // compile fail!
    /// ```
    ///
    /// For at omgå dette kan vi bruge [`split_at_mut`] til at oprette to forskellige mutable underskiver fra en skive:
    ///
    /// ```
    /// let mut slice = [1, 2, 3, 4, 5];
    ///
    /// {
    ///     let (left, right) = slice.split_at_mut(2);
    ///     left.swap_with_slice(&mut right[1..]);
    /// }
    ///
    /// assert_eq!(slice, [4, 5, 3, 1, 2]);
    /// ```
    ///
    /// [`split_at_mut`]: slice::split_at_mut
    ///
    ///
    #[stable(feature = "swap_with_slice", since = "1.27.0")]
    pub fn swap_with_slice(&mut self, other: &mut [T]) {
        assert!(self.len() == other.len(), "destination and source slices have different lengths");
        // SIKKERHED: `self` er pr. Definition gyldig for `self.len()`-elementer, og `src` var
        // kontrolleret for at have samme længde.
        // Skiverne kan ikke overlappe hinanden, fordi mutable referencer er eksklusive.
        unsafe {
            ptr::swap_nonoverlapping(self.as_mut_ptr(), other.as_mut_ptr(), self.len());
        }
    }

    /// Funktion til at beregne længderne på den midterste og efterfølgende skive til `align_to{,_mut}`.
    fn align_to_offsets<U>(&self) -> (usize, usize) {
        // Hvad vi skal gøre ved `rest` er at finde ud af, hvilket multipel af U'er vi kan lægge i et laveste antal T'er.
        //
        // Og hvor mange `T`er vi har brug for til hver sådan "multiple".
        //
        // Overvej for eksempel T=u8 U=u16.Så kan vi sætte 1 U i 2 Ts.Enkel.
        // Overvej nu for eksempel et tilfælde, hvor size_of: :<T>=16, størrelse_af::<U>=24.</u>
        // Vi kan placere 2 Us i stedet for hver 3 Ts i `rest`-skiven.
        // Lidt mere kompliceret.
        //
        // Formel til beregning af dette er:
        //
        // Us= lcm(size_of::<T>, size_of::<U>)/size_of: : <U>Ts= lcm(size_of::<T>, size_of::<U>)/size_of::</u><T>
        //
        // Udvidet og forenklet:
        //
        // Us=størrelse_af: :<T>/gcd(size_of::<T>, size_of::<U>) Ts=size_of::<U>/gcd(size_of::<T>, size_of::<U>)</u>
        //
        // Heldigvis da alt dette evalueres konstant ... præstation her betyder ikke noget!
        #[inline]
        fn gcd(a: usize, b: usize) -> usize {
            use crate::intrinsics;
            // iterativ steins algoritme Vi skal stadig fremstille denne `const fn` (og vende tilbage til rekursiv algoritme, hvis vi gør det), fordi det at stole på llvm for at udgøre alt dette er ... godt, det gør mig ubehagelig.
            //
            //

            // SIKKERHED: `a` og `b` kontrolleres for at være værdier, der ikke er nul.
            let (ctz_a, mut ctz_b) = unsafe {
                if a == 0 {
                    return b;
                }
                if b == 0 {
                    return a;
                }
                (intrinsics::cttz_nonzero(a), intrinsics::cttz_nonzero(b))
            };
            let k = ctz_a.min(ctz_b);
            let mut a = a >> ctz_a;
            let mut b = b;
            loop {
                // fjern alle faktorer på 2 fra b
                b >>= ctz_b;
                if a > b {
                    mem::swap(&mut a, &mut b);
                }
                b = b - a;
                // SIKKERHED: `b` er markeret for ikke-nul.
                unsafe {
                    if b == 0 {
                        break;
                    }
                    ctz_b = intrinsics::cttz_nonzero(b);
                }
            }
            a << k
        }
        let gcd: usize = gcd(mem::size_of::<T>(), mem::size_of::<U>());
        let ts: usize = mem::size_of::<U>() / gcd;
        let us: usize = mem::size_of::<T>() / gcd;

        // Bevæbnet med denne viden kan vi finde, hvor mange U'er vi kan passe!
        let us_len = self.len() / ts * us;
        // Og hvor mange `T`'er vil være i den bageste skive!
        let ts_len = self.len() % ts;
        (us_len, ts_len)
    }

    /// Transmuter skiven til en skive af en anden type, og sørg for, at justeringen af typerne opretholdes.
    ///
    /// Denne metode opdeler udsnittet i tre forskellige udsnit: præfikset, korrekt justeret mellemstykke af en ny type og suffikset.
    /// Metoden kan muligvis gøre den midterste skive størst mulig længde for en given type og inputskive, men kun din algoritmes ydeevne skal afhænge af det, ikke dens korrekthed.
    ///
    /// Det er tilladt, at alle inputdata returneres som præfikset eller suffikset.
    ///
    /// Denne metode har intet formål, når enten inputelement `T` eller outputelement `U` er nulstørrelse og returnerer det originale stykke uden at opdele noget.
    ///
    /// # Safety
    ///
    /// Denne metode er i det væsentlige en `transmute` med hensyn til elementerne i den returnerede midterskive, så alle de sædvanlige forbehold, der vedrører `transmute::<T, U>`, gælder også her.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// unsafe {
    ///     let bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to<U>(&self) -> (&[T], &[U], &[T]) {
        // Bemærk, at det meste af denne funktion evalueres konstant,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // håndter ZST'er specielt, hvilket er-håndter dem slet ikke.
            return (self, &[], &[]);
        }

        // Find først, på hvilket tidspunkt vi deler mellem den første og 2. skive.
        // Nemt med ptr.align_offset.
        let ptr = self.as_ptr();
        // SIKKERHED: Se `align_to_mut`-metoden for en detaljeret sikkerhedskommentar.
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &[], &[])
        } else {
            let (left, rest) = self.split_at(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            // SIKKERHED: nu er `rest` bestemt justeret, så `from_raw_parts` nedenfor er okay,
            // da opkalderen garanterer, at vi kan transmittere `T` til `U` sikkert.
            unsafe {
                (
                    left,
                    from_raw_parts(rest.as_ptr() as *const U, us_len),
                    from_raw_parts(rest.as_ptr().add(rest.len() - ts_len), ts_len),
                )
            }
        }
    }

    /// Transmuter skiven til en skive af en anden type, og sørg for, at justeringen af typerne opretholdes.
    ///
    /// Denne metode opdeler udsnittet i tre forskellige udsnit: præfikset, korrekt justeret mellemstykke af en ny type og suffikset.
    /// Metoden kan muligvis gøre den midterste skive størst mulig længde for en given type og inputskive, men kun din algoritmes ydeevne skal afhænge af det, ikke dens korrekthed.
    ///
    /// Det er tilladt, at alle inputdata returneres som præfikset eller suffikset.
    ///
    /// Denne metode har intet formål, når enten inputelement `T` eller outputelement `U` er nulstørrelse og returnerer det originale stykke uden at opdele noget.
    ///
    /// # Safety
    ///
    /// Denne metode er i det væsentlige en `transmute` med hensyn til elementerne i den returnerede midterskive, så alle de sædvanlige forbehold, der vedrører `transmute::<T, U>`, gælder også her.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// unsafe {
    ///     let mut bytes: [u8; 7] = [1, 2, 3, 4, 5, 6, 7];
    ///     let (prefix, shorts, suffix) = bytes.align_to_mut::<u16>();
    ///     // less_efficient_algorithm_for_bytes(prefix);
    ///     // more_efficient_algorithm_for_aligned_shorts(shorts);
    ///     // less_efficient_algorithm_for_bytes(suffix);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_align_to", since = "1.30.0")]
    pub unsafe fn align_to_mut<U>(&mut self) -> (&mut [T], &mut [U], &mut [T]) {
        // Bemærk, at det meste af denne funktion evalueres konstant,
        if mem::size_of::<U>() == 0 || mem::size_of::<T>() == 0 {
            // håndter ZST'er specielt, hvilket er-håndter dem slet ikke.
            return (self, &mut [], &mut []);
        }

        // Find først, på hvilket tidspunkt vi deler mellem den første og 2. skive.
        // Nemt med ptr.align_offset.
        let ptr = self.as_ptr();
        // SIKKERHED: Her sikrer vi, at vi bruger justerede markører til U til
        // resten af metoden.Dette gøres ved at sende en markør til&[T] med en justering målrettet mod U.
        // `crate::ptr::align_offset` kaldes med en korrekt justeret og gyldig markør `ptr` (den kommer fra en henvisning til `self`) og med en størrelse, der er en styrke på to (da den kommer fra justeringen for U), der opfylder dens sikkerhedsmæssige begrænsninger.
        //
        //
        //
        //
        let offset = unsafe { crate::ptr::align_offset(ptr, mem::align_of::<U>()) };
        if offset > self.len() {
            (self, &mut [], &mut [])
        } else {
            let (left, rest) = self.split_at_mut(offset);
            let (us_len, ts_len) = rest.align_to_offsets::<U>();
            let rest_len = rest.len();
            let mut_ptr = rest.as_mut_ptr();
            // Vi kan ikke bruge `rest` igen efter dette, hvilket ville ugyldiggøre dets alias `mut_ptr`!SIKKERHED: se kommentarer til `align_to`.
            //
            unsafe {
                (
                    left,
                    from_raw_parts_mut(mut_ptr as *mut U, us_len),
                    from_raw_parts_mut(mut_ptr.add(rest_len - ts_len), ts_len),
                )
            }
        }
    }

    /// Kontrollerer, om elementerne i dette udsnit er sorteret.
    ///
    /// Det vil sige, at for hvert element `a` og dets følgende element `b` skal `a <= b` holde.Hvis udsnittet giver nøjagtigt nul eller et element, returneres `true`.
    ///
    /// Bemærk, at hvis `Self::Item` kun er `PartialOrd`, men ikke `Ord`, betyder ovenstående definition, at denne funktion returnerer `false`, hvis to på hinanden følgende punkter ikke er sammenlignelige.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    /// let empty: [i32; 0] = [];
    ///
    /// assert!([1, 2, 2, 9].is_sorted());
    /// assert!(![1, 3, 2, 4].is_sorted());
    /// assert!([0].is_sorted());
    /// assert!(empty.is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted(&self) -> bool
    where
        T: PartialOrd,
    {
        self.is_sorted_by(|a, b| a.partial_cmp(b))
    }

    /// Kontrollerer, om elementerne i dette udsnit sorteres ved hjælp af den givne komparatorfunktion.
    ///
    /// I stedet for at bruge `PartialOrd::partial_cmp` bruger denne funktion den givne `compare`-funktion til at bestemme rækkefølgen af to elementer.
    /// Bortset fra det svarer det til [`is_sorted`];se dokumentationen for mere information.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by<F>(&self, mut compare: F) -> bool
    where
        F: FnMut(&T, &T) -> Option<Ordering>,
    {
        self.iter().is_sorted_by(|a, b| compare(*a, *b))
    }

    /// Kontrollerer, om elementerne i dette udsnit sorteres ved hjælp af den givne nøgleudtrækningsfunktion.
    ///
    /// I stedet for at sammenligne skiveelementerne direkte sammenligner denne funktion elementernes nøgler som bestemt af `f`.
    /// Bortset fra det svarer det til [`is_sorted`];se dokumentationen for mere information.
    ///
    /// [`is_sorted`]: slice::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    pub fn is_sorted_by_key<F, K>(&self, f: F) -> bool
    where
        F: FnMut(&T) -> K,
        K: PartialOrd,
    {
        self.iter().is_sorted_by_key(f)
    }

    /// Returnerer indekset for delingspunktet i henhold til det givne prædikat (indekset for det første element i den anden partition).
    ///
    /// Skivet antages at være opdelt i henhold til det givne prædikat.
    /// Dette betyder, at alle elementer, for hvilke prædikatet returnerer sandt, er i starten af udsnittet, og alle elementer, for hvilke prædikatet returnerer falsk, er i slutningen.
    ///
    /// For eksempel er [7, 15, 3, 5, 4, 12, 6] en partitioneret under prædikatet x% 2!=0 (alle ulige tal er i starten, alt lige i slutningen).
    ///
    /// Hvis dette udsnit ikke er opdelt, er det returnerede resultat uspecificeret og meningsløst, da denne metode udfører en slags binær søgning.
    ///
    /// Se også [`binary_search`], [`binary_search_by`] og [`binary_search_by_key`].
    ///
    /// [`binary_search`]: slice::binary_search
    /// [`binary_search_by`]: slice::binary_search_by
    /// [`binary_search_by_key`]: slice::binary_search_by_key
    ///
    /// # Examples
    ///
    /// ```
    /// let v = [1, 2, 3, 3, 5, 6, 7];
    /// let i = v.partition_point(|&x| x < 5);
    ///
    /// assert_eq!(i, 4);
    /// assert!(v[..i].iter().all(|&x| x < 5));
    /// assert!(v[i..].iter().all(|&x| !(x < 5)));
    /// ```
    ///
    ///
    ///
    #[stable(feature = "partition_point", since = "1.52.0")]
    pub fn partition_point<P>(&self, mut pred: P) -> usize
    where
        P: FnMut(&T) -> bool,
    {
        let mut left = 0;
        let mut right = self.len();

        while left != right {
            let mid = left + (right - left) / 2;
            // SIKKERHED: Når `left < right`, `left <= mid < right`.
            // Derfor øges `left` altid, og `right` falder altid, og en af dem vælges.I begge tilfælde er `left <= right` tilfreds.Derfor, hvis `left < right` i et trin, er `left <= right` tilfreds i det næste trin.
            //
            // Derfor, så længe `left != right`, er `0 <= left < right <= len` tilfreds, og hvis denne sag også er tilfreds.
            //
            //
            //
            let value = unsafe { self.get_unchecked(mid) };
            if pred(value) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        left
    }
}

trait CloneFromSpec<T> {
    fn spec_clone_from(&mut self, src: &[T]);
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Clone,
{
    default fn spec_clone_from(&mut self, src: &[T]) {
        assert!(self.len() == src.len(), "destination and source slices have different lengths");
        // NOTE: Vi skal eksplicit skære dem i samme længde
        // for at gøre det lettere for optimeren at fjerne grænsekontrol.
        // Men da det ikke kan påberåbes, har vi også en eksplicit specialisering for T: Copy.
        let len = self.len();
        let src = &src[..len];
        for i in 0..len {
            self[i].clone_from(&src[i]);
        }
    }
}

impl<T> CloneFromSpec<T> for [T]
where
    T: Copy,
{
    fn spec_clone_from(&mut self, src: &[T]) {
        self.copy_from_slice(src);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for &[T] {
    /// Opretter et tomt stykke.
    fn default() -> Self {
        &[]
    }
}

#[stable(feature = "mut_slice_default", since = "1.5.0")]
impl<T> Default for &mut [T] {
    /// Opretter en ændret tom skive.
    fn default() -> Self {
        &mut []
    }
}

#[unstable(feature = "slice_pattern", reason = "stopgap trait for slice patterns", issue = "56345")]
/// Mønstre i skiver, der i øjeblikket kun bruges af `strip_prefix` og `strip_suffix`.
/// På et future-punkt håber vi at generalisere `core::str::Pattern` (som i skrivende stund er begrænset til `str`) til skiver, og så vil denne trait blive erstattet eller afskaffet.
///
pub trait SlicePattern {
    /// Elementtypen af det udsnit, der matches.
    type Item;

    /// I øjeblikket har forbrugerne af `SlicePattern` brug for et stykke.
    fn as_slice(&self) -> &[Self::Item];
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T> SlicePattern for [T] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}

#[stable(feature = "slice_strip", since = "1.51.0")]
impl<T, const N: usize> SlicePattern for [T; N] {
    type Item = T;

    #[inline]
    fn as_slice(&self) -> &[Self::Item] {
        self
    }
}