//! Skivesortering
//!
//! Dette modul indeholder en sorteringsalgoritme baseret på Orson Peters 'mønsterbekæmpende quicksort, offentliggjort på: <https://github.com/orlp/pdqsort>
//!
//!
//! Ustabil sortering er kompatibel med libcore, fordi den ikke tildeler hukommelse i modsætning til vores stabile sorteringsimplementering.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Når de smides, kopieres fra `src` til `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // SIKKERHED: Dette er en hjælperklasse.
        //          Se dets anvendelse for korrekthed.
        //          Man skal nemlig være sikker på, at `src` og `dst` ikke overlapper som krævet af `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Flytter det første element til højre, indtil det støder på et større eller lige element.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SIKKERHED: De usikre handlinger nedenfor indebærer indeksering uden en bundet kontrol (`get_unchecked` og `get_unchecked_mut`)
    // og kopieringshukommelse (`ptr::copy_nonoverlapping`).
    //
    // en.Indeksering:
    //  1. Vi kontrollerede størrelsen på arrayet til>=2.
    //  2. Alt det indeksering, som vi vil gøre, er højst altid mellem {0 <= index < len}.
    //
    // b.Hukommelseskopiering
    //  1. Vi får henvisninger til referencer, som garanteret er gyldige.
    //  2. De kan ikke overlappe hinanden, fordi vi får henvisninger til forskelindekserne for udsnittet.
    //     Nemlig `i` og `i-1`.
    //  3. Hvis skiven er korrekt justeret, er elementerne korrekt justeret.
    //     Det er den, der ringer op, at sørge for, at udsnittet er korrekt justeret.
    //
    // Se kommentarerne nedenfor for yderligere detaljer.
    unsafe {
        // Hvis de to første elementer ikke er i orden ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Læs det første element i en stabelallokeret variabel.
            // Hvis en følgende sammenligningsoperation panics, vil `hole` blive droppet og automatisk skrive elementet tilbage i udsnittet.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Flyt 'i'-elementet ét sted til venstre, og forskyd således hullet til højre.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` bliver droppet og kopierer således `tmp` i det resterende hul i `v`.
        }
    }
}

/// Flytter det sidste element til venstre, indtil det møder et mindre eller lige element.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // SIKKERHED: De usikre handlinger nedenfor indebærer indeksering uden en bundet kontrol (`get_unchecked` og `get_unchecked_mut`)
    // og kopieringshukommelse (`ptr::copy_nonoverlapping`).
    //
    // en.Indeksering:
    //  1. Vi kontrollerede størrelsen på arrayet til>=2.
    //  2. Alt det indeksering, som vi vil gøre, er højst altid mellem `0 <= index < len-1`.
    //
    // b.Hukommelseskopiering
    //  1. Vi får henvisninger til referencer, som garanteret er gyldige.
    //  2. De kan ikke overlappe hinanden, fordi vi får henvisninger til forskelindekserne for udsnittet.
    //     Nemlig `i` og `i+1`.
    //  3. Hvis skiven er korrekt justeret, er elementerne korrekt justeret.
    //     Det er den, der ringer op, at sørge for, at udsnittet er korrekt justeret.
    //
    // Se kommentarerne nedenfor for yderligere detaljer.
    unsafe {
        // Hvis de sidste to elementer ikke er i orden ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Læs det sidste element i en stack-allokeret variabel.
            // Hvis en følgende sammenligningsoperation panics, vil `hole` blive droppet og automatisk skrive elementet tilbage i udsnittet.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Flyt 'i'-elementet ét sted til højre, og forskyd således hullet til venstre.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` bliver droppet og kopierer således `tmp` i det resterende hul i `v`.
        }
    }
}

/// Deler delvist et stykke ved at flytte flere ordrer uden for ordre.
///
/// Returnerer `true`, hvis udsnittet er sorteret i slutningen.Denne funktion er *O*(*n*) i værste fald.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Maksimalt antal tilstødende par, der ikke er i orden, der skiftes.
    const MAX_STEPS: usize = 5;
    // Hvis udsnittet er kortere end dette, skal du ikke flytte nogen elementer.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // SIKKERHED: Vi foretog allerede eksplicit kontrol med `i < len`.
        // Alle vores efterfølgende indekseringer ligger kun i området `0 <= index < len`
        unsafe {
            // Find det næste par tilstødende ude af ordre-elementer.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Er vi færdige?
        if i == len {
            return true;
        }

        // Skift ikke elementer på korte arrays, det har en præstationsomkostning.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Byt det fundne par af elementer.Dette sætter dem i korrekt rækkefølge.
        v.swap(i - 1, i);

        // Skift det mindre element til venstre.
        shift_tail(&mut v[..i], is_less);
        // Skift det større element til højre.
        shift_head(&mut v[i..], is_less);
    }

    // Det lykkedes ikke at sortere udsnittet i det begrænsede antal trin.
    false
}

/// Sorterer et stykke ved hjælp af indsættelsessortering, hvilket er *O*(*n*^ 2) i værste fald.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Sorterer `v` ved hjælp af heapsort, hvilket garanterer *O*(*n*\*log(* n*)) worst-case.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Denne binære bunke respekterer den uforanderlige `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Børn af `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Vælg det større barn.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Stop hvis invarianten holder på `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Byt `node` med det større barn, flyt et trin ned, og fortsæt sigtningen.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Byg bunken i lineær tid.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Pop maksimale elementer fra bunken.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Partitioner `v` i elementer, der er mindre end `pivot`, efterfulgt af elementer, der er større end eller lig med `pivot`.
///
///
/// Returnerer antallet af elementer, der er mindre end `pivot`.
///
/// Partitionering udføres blok for blok for at minimere omkostningerne ved forgreningsoperationer.
/// Denne idé præsenteres i [BlockQuicksort][pdf]-papiret.
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Antal elementer i en typisk blok.
    const BLOCK: usize = 128;

    // Partitioneringsalgoritmen gentager følgende trin indtil afslutning:
    //
    // 1. Spor en blok fra venstre side for at identificere elementer, der er større end eller lig med drejetappen.
    // 2. Spor en blok fra højre side for at identificere elementer, der er mindre end omdrejningspunktet.
    // 3. Udveksle de identificerede elementer mellem venstre og højre side.
    //
    // Vi har følgende variabler for en blok af elementer:
    //
    // 1. `block` - Antal elementer i blokken.
    // 2. `start` - Start pointer i `offsets`-arrayet.
    // 3. `end` - Afslut markøren i `offsets`-arrayet.
    // 4. `forskydninger, indekser for ordrer uden for ordren inden for blokken.

    // Den aktuelle blok på venstre side (fra `l` til `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Den aktuelle blok på højre side (fra `r.sub(block_r)` to `r`).
    // SIKKERHED: Dokumentationen til .add() nævner specifikt, at `vec.as_ptr().add(vec.len())` altid er sikker`
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Når vi får VLA'er, så prøv at oprette et array med længden `min(v.len(), 2 * BLOCK) `snarere
    // end to arrays med fast størrelse i længden `BLOCK`.VLA'er kan være mere cacheeffektive.

    // Returnerer antallet af elementer mellem markørerne `l` (inclusive) og `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Vi er færdige med partitionering blok-for-blok, når `l` og `r` kommer meget tæt på.
        // Derefter laver vi noget patch-up-arbejde for at opdele de resterende elementer imellem.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Antal resterende elementer (stadig ikke sammenlignet med drejetappen).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Juster blokstørrelser, så venstre og højre blok ikke overlapper hinanden, men justeres perfekt for at dække hele det resterende hul.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Spor `block_l`-elementer fra venstre side.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // SIKKERHED: De usikre handlinger nedenfor involverer brugen af `offset`.
                //         I henhold til de betingelser, der kræves af funktionen, opfylder vi dem, fordi:
                //         1. `offsets_l` er stakallokeret og betragtes således som separat tildelt objekt.
                //         2. Funktionen `is_less` returnerer en `bool`.
                //            Casting af en `bool` vil aldrig løbe over `isize`.
                //         3. Vi har garanteret, at `block_l` bliver `<= BLOCK`.
                //            Plus blev `end_l` oprindeligt indstillet til startmarkøren på `offsets_`, som blev erklæret på stakken.
                //            Således ved vi, at selv i værste tilfælde (alle påkald af `is_less` returnerer falsk) vil vi kun højst være 1 byte, der passerer slutningen.
                //        En anden usikkerhedshandling her er dereferencing `elem`.
                //        Imidlertid var `elem` oprindeligt startmarkøren til det udsnit, der altid er gyldigt.
                unsafe {
                    // Grenløs sammenligning.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Spor `block_r`-elementer fra højre side.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // SIKKERHED: De usikre handlinger nedenfor involverer brugen af `offset`.
                //         I henhold til de betingelser, der kræves af funktionen, opfylder vi dem, fordi:
                //         1. `offsets_r` er stakallokeret og betragtes således som separat tildelt objekt.
                //         2. Funktionen `is_less` returnerer en `bool`.
                //            Casting af en `bool` vil aldrig løbe over `isize`.
                //         3. Vi har garanteret, at `block_r` bliver `<= BLOCK`.
                //            Plus blev `end_r` oprindeligt indstillet til startmarkøren på `offsets_`, som blev erklæret på stakken.
                //            Således ved vi, at selv i værste tilfælde (alle påkald af `is_less` returnerer sandt) vil vi kun højst være 1 byte, der passerer slutningen.
                //        En anden usikkerhedshandling her er dereferencing `elem`.
                //        Imidlertid var `elem` oprindeligt `1 *sizeof(T)` efter slutningen, og vi reducerer den med `1* sizeof(T)`, inden vi får adgang til den.
                //        Plus, `block_r` blev hævdet at være mindre end `BLOCK`, og `elem` vil derfor højst pege på begyndelsen af udsnittet.
                unsafe {
                    // Grenløs sammenligning.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Antal ude af ordreelementer, der skal skiftes mellem venstre og højre side.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // I stedet for at bytte et par ad gangen er det mere effektivt at udføre en cyklisk permutation.
            // Dette svarer ikke strengt til at bytte, men giver et lignende resultat ved hjælp af færre hukommelsesoperationer.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Alle ordrer i den venstre blok blev flyttet.Gå til næste blok.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Alle ude af ordre-elementer i den højre blok blev flyttet.Gå til den forrige blok.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Alt der er tilbage nu er højst en blok (enten venstre eller højre) med elementer, der ikke er i orden, der skal flyttes.
    // Sådanne resterende elementer kan simpelthen flyttes til slutningen inden for deres blok.
    //

    if start_l < end_l {
        // Den venstre blok forbliver.
        // Flyt de resterende elementer, der ikke er i orden, længst til højre.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Den rigtige blok forbliver.
        // Flyt de resterende elementer, der ikke er i orden, længst til venstre.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Intet andet at gøre, vi er færdige.
        width(v.as_mut_ptr(), l)
    }
}

/// Partitioner `v` i elementer, der er mindre end `v[pivot]`, efterfulgt af elementer, der er større end eller lig med `v[pivot]`.
///
///
/// Returnerer en tuple på:
///
/// 1. Antal elementer mindre end `v[pivot]`.
/// 2. Sandt, hvis `v` allerede var partitioneret.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Placer drejetappen i begyndelsen af skiven.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Læs drejningen i en stack-allokeret variabel for effektivitet.
        // Hvis en følgende sammenligningsoperation panics, vil pivoten automatisk blive skrevet tilbage i udsnittet.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Find det første par element, der ikke er i orden.
        let mut l = 0;
        let mut r = v.len();

        // SIKKERHED: Usikkerheden nedenfor indebærer indeksering af en matrix.
        // For det første: Vi kontrollerer allerede grænserne her med `l < r`.
        // For den anden: Vi har oprindeligt `l == 0` og `r == v.len()`, og vi kontrollerede, at `l < r` ved hver indekseringshandling.
        //                     Herfra ved vi, at `r` skal være mindst `r == l`, hvilket blev vist at være gyldigt fra den første.
        unsafe {
            // Find det første element, der er større end eller lig med omdrejningspunktet.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Find det sidste element, der er mindre end omdrejningspunktet.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` går ud af omfanget og skriver pivoten (som er en stakallokeret variabel) tilbage i det udsnit, hvor det oprindeligt var.
        // Dette trin er afgørende for at sikre sikkerhed!
        //
    };

    // Placer drejetappen mellem de to skillevægge.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Partitioner `v` i elementer svarende til `v[pivot]` efterfulgt af elementer større end `v[pivot]`.
///
/// Returnerer antallet af elementer svarende til omdrejningspunktet.
/// Det antages, at `v` ikke indeholder elementer, der er mindre end omdrejningspunktet.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Placer drejetappen i begyndelsen af skiven.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Læs drejningen i en stack-allokeret variabel for effektivitet.
    // Hvis en følgende sammenligningsoperation panics, vil pivoten automatisk blive skrevet tilbage i udsnittet.
    // SIKKERHED: Markøren her er gyldig, fordi den hentes fra en henvisning til et udsnit.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Del nu skiven.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // SIKKERHED: Usikkerheden nedenfor indebærer indeksering af en matrix.
        // For det første: Vi kontrollerer allerede grænserne her med `l < r`.
        // For den anden: Vi har oprindeligt `l == 0` og `r == v.len()`, og vi kontrollerede, at `l < r` ved hver indekseringshandling.
        //                     Herfra ved vi, at `r` skal være mindst `r == l`, hvilket blev vist at være gyldigt fra den første.
        unsafe {
            // Find det første element, der er større end omdrejningspunktet.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Find det sidste element svarende til omdrejningspunktet.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Er vi færdige?
            if l >= r {
                break;
            }

            // Byt det fundne par ude af ordre-elementer.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Vi fandt `l`-elementer svarende til omdrejningspunktet.Tilføj 1 til konto for selve drejningen.
    l + 1

    // `_pivot_guard` går ud af omfanget og skriver pivoten (som er en stakallokeret variabel) tilbage i det udsnit, hvor det oprindeligt var.
    // Dette trin er afgørende for at sikre sikkerhed!
}

/// Spredt nogle elementer rundt i et forsøg på at bryde mønstre, der kan forårsage ubalancerede partitioner i quicksort.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Pseudorandom nummergenerator fra "Xorshift RNGs" papiret af George Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Tag tilfældige tal modulo dette nummer.
        // Nummeret passer ind i `usize`, fordi `len` ikke er større end `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Nogle drejekandidater vil være i nærheden af dette indeks.Lad os randomisere dem.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Generer et tilfældigt tal modulo `len`.
            // For at undgå dyre operationer tager vi dog først den modulo en effekt på to og sænkes derefter med `len`, indtil den passer ind i området `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` er garanteret mindre end `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Vælger en pivot i `v` og returnerer indekset og `true`, hvis udsnittet sandsynligvis allerede er sorteret.
///
/// Elementer i `v` kan ombestilles i processen.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Minimumslængde for at vælge metian-of-medians-metoden.
    // Kortere skiver bruger den enkle median-af-tre-metode.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Maksimalt antal swaps, der kan udføres i denne funktion.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Tre indekser, hvor vi skal vælge en omdrejningspunkt.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Tæller det samlede antal swaps, vi skal udføre under sortering af indekser.
    let mut swaps = 0;

    if len >= 8 {
        // Bytter indekser, så `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Bytter indekser, så `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Finder medianen for `v[a - 1], v[a], v[a + 1]` og gemmer indekset i `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Find medianer i kvartererne `a`, `b` og `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Find medianen blandt `a`, `b` og `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Det maksimale antal swaps blev udført.
        // Chancerne er, at skiven er faldende eller for det meste faldende, så reversering hjælper sandsynligvis med at sortere det hurtigere.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Sorterer `v` rekursivt.
///
/// Hvis udsnittet havde en forgænger i det originale array, er det angivet som `pred`.
///
/// `limit` er antallet af tilladte ubalancerede partitioner, før du skifter til `heapsort`.
/// Hvis nul, skifter denne funktion straks til heapsort.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Skiver på op til denne længde sorteres ved hjælp af indsættelsessortering.
    const MAX_INSERTION: usize = 20;

    // Sandt nok, hvis den sidste partition var rimeligt afbalanceret.
    let mut was_balanced = true;
    // Sandt, hvis den sidste partition ikke blandede elementer (udsnittet var allerede opdelt).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Meget korte skiver sorteres ved hjælp af indsættelsessortering.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Hvis der blev taget for mange dårlige drejevalg, skal du blot falde tilbage til heapsort for at garantere `O(n * log(n))` worst-case.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Hvis den sidste partition var ubalanceret, så prøv at bryde mønstre i skiven ved at blande nogle elementer rundt.
        // Forhåbentlig vælger vi en bedre drejning denne gang.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Vælg en pivot, og prøv at gætte, om udsnittet allerede er sorteret.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Hvis den sidste partitionering var anstændigt afbalanceret og ikke blandede elementer, og hvis drejevalg forudsiger, er udsnittet sandsynligvis allerede sorteret ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Prøv at identificere flere ude af ordre-elementer og skifte dem til korrekte positioner.
            // Hvis skiven ender med at blive sorteret fuldstændigt, er vi færdige.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Hvis den valgte drejning er lig med forgængeren, er det det mindste element i udsnittet.
        // Del skiven i elementer, der er lig med og elementer, der er større end omdrejningspunktet.
        // Denne sag rammes normalt, når udsnittet indeholder mange duplikatelementer.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Fortsæt med at sortere elementer, der er større end pivoten.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Opdel skiven.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Opdel skiven i `left`, `pivot` og `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Bliv kun tilbage på den kortere side for at minimere det samlede antal rekursive opkald og forbruge mindre stakplads.
        // Fortsæt bare med den længere side (dette svarer til halenrekursion).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Sorterer `v` ved hjælp af mønster-besejrende quicksort, hvilket er *O*(*n*\*log(* n*)) worst-case.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Sortering har ingen meningsfuld opførsel på typer med nulstørrelse.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Begræns antallet af ubalancerede partitioner til `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // For skiver op til denne længde er det sandsynligvis hurtigere at bare sortere dem.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Vælg en drejetap
        let (pivot, _) = choose_pivot(v, is_less);

        // Hvis den valgte drejning er lig med forgængeren, er det det mindste element i udsnittet.
        // Del skiven i elementer, der er lig med og elementer, der er større end omdrejningspunktet.
        // Denne sag rammes normalt, når udsnittet indeholder mange duplikatelementer.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Hvis vi har bestået vores indeks, er vi gode.
                if mid > index {
                    return;
                }

                // Ellers skal du fortsætte med at sortere elementer, der er større end omdrejningspunktet.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Opdel skiven i `left`, `pivot` og `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Hvis midt==indeks, så er vi færdige, da partition() garanterede, at alle elementer efter midten er større end eller lig med midten.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Sortering har ingen meningsfuld opførsel på typer med nulstørrelse.Gøre ingenting.
    } else if index == v.len() - 1 {
        // Find max-element, og placer det i matrixens sidste position.
        // Vi kan bruge `unwrap()` her, fordi vi ved, at v ikke må være tom.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Find min element, og placer det i arrayets første position.
        // Vi kan bruge `unwrap()` her, fordi vi ved, at v ikke må være tom.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}