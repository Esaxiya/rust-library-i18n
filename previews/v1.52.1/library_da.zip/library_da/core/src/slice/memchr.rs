// Original implementering taget fra rust-memchr.
// Copyright 2015 Andrew Gallant, bluss og Nicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Brug afkortning.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Returnerer `true`, hvis `x` indeholder nogen nulbyte.
///
/// Fra *Matters Computational*, J. Arndt:
///
/// "Ideen er at trække en fra hver af byte og derefter se efter byte, hvor lånet forplantes hele vejen til det mest betydningsfulde
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Returnerer det første indeks, der matcher byten `x` i `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Hurtig sti til små skiver
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Scan efter en enkelt byteværdi ved at læse to `usize` ord ad gangen.
    //
    // Opdel `text` i tre dele
    // - ujusteret indledende del, før den første ordjusterede adresse i teksten
    // - krop, scan med 2 ord ad gangen
    // - den sidste tilbageværende del, <2 ordstørrelse

    // søg op til en justeret grænse
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // søg i tekstens brødtekst
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // SIKKERHED: tidens prædikat garanterer en afstand på mindst 2 * usize_bytes
        // mellem forskydningen og slutningen af skiven.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // pause, hvis der er en matchende byte
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Find byte efter det punkt, hvor kroppens sløjfe stoppede.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Returnerer det sidste indeks, der matcher byten `x` i `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Scan efter en enkelt byteværdi ved at læse to `usize` ord ad gangen.
    //
    // Opdel `text` i tre dele:
    // - ujusteret hale efter den sidste ordjusterede adresse i tekst,
    // - body, scannet med 2 ord ad gangen,
    // - de første resterende byte, <2 ordstørrelse.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Vi kalder dette bare for at få længden af præfikset og suffikset.
        // I midten behandler vi altid to klumper på én gang.
        // SIKKERHED: transmutering af `[u8]` til `[usize]` er sikkert bortset fra størrelsesforskelle, der håndteres af `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Søg i tekstens brødtekst, og sørg for, at vi ikke krydser min_aligned_offset.
    // offset er altid justeret, så bare at teste `>` er tilstrækkelig og undgår muligt overløb.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // SIKKERHED: forskydning starter ved len, suffix.len(), så længe den er større end
        // min_aligned_offset (prefix.len()) den resterende afstand er mindst 2 * klump_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Break hvis der er en matchende byte.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Find byte før det punkt, hvor kroppen sløjfe stoppede.
    text[..offset].iter().rposition(|elt| *elt == x)
}