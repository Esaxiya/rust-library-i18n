//! Makroer brugt af iteratorer af skive.

// Inlining is_empty og len gør en enorm præstationsforskel
macro_rules! is_empty {
    // Den måde, vi koder længden af en ZST-iterator, fungerer dette både for ZST og ikke-ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// For at slippe af med nogle grænsekontroller (se `position`) beregner vi længden på en noget uventet måde.
// (Testet af 'codegen/slice-position-bounds-check'.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // vi bruges undertiden inden for en usikker blok

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Denne _cannot_ bruger `unchecked_sub`, fordi vi er afhængige af indpakning for at repræsentere længden af lange ZST-skive-iteratorer.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Vi ved, at `start <= end`, så kan gøre det bedre end `offset_from`, som skal håndtere signeret.
            // Ved at indstille passende flag her kan vi fortælle LLVM dette, hvilket hjælper det med at fjerne grænsekontrol.
            // SIKKERHED: Efter typen invariant, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Ved også at fortælle LLVM, at markørerne er adskilt med et nøjagtigt multiplum af typestørrelsen, kan det optimere `len() == 0` ned til `start == end` i stedet for `(end - start) < size`.
            //
            // SIKKERHED: Efter typen invariant er markørerne justeret så
            //         afstanden mellem dem skal være et multiplum af pointeestørrelsen
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Den delte definition af `Iter` og `IterMut` iteratorerne
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Returnerer det første element og flytter starten af iteratoren fremad med 1.
        // Forbedrer ydeevnen meget sammenlignet med en inline-funktion.
        // Iteratoren må ikke være tom.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Returnerer det sidste element og bevæger enden af iteratoren bagud med 1.
        // Forbedrer ydeevnen meget sammenlignet med en inline-funktion.
        // Iteratoren må ikke være tom.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Krymper iteratoren, når T er en ZST, ved at flytte enden af iteratoren bagud med `n`.
        // `n` må ikke overstige `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Hjælperfunktion til oprettelse af et udsnit fra iteratoren.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // SIKKERHED: iteratoren blev oprettet fra et stykke med markør
                // `self.ptr` og længde `len!(self)`.
                // Dette garanterer, at alle forudsætninger for `from_raw_parts` er opfyldt.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Hjælpefunktion til at flytte starten af iteratoren fremad med `offset`-elementer, hvilket returnerer den gamle start.
            //
            // Usikker, fordi forskydningen ikke må overstige `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // SIKKERHED: opkalderen garanterer, at `offset` ikke overstiger `self.len()`,
                    // så denne nye markør er inde i `self` og dermed garanteret at være ikke-nul.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Hjælperfunktion til at flytte enden af iteratoren bagud med `offset`-elementer, hvilket returnerer den nye ende.
            //
            // Usikker, fordi forskydningen ikke må overstige `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // SIKKERHED: opkalderen garanterer, at `offset` ikke overstiger `self.len()`,
                    // som garanteret ikke overløber en `isize`.
                    // Den resulterende markør er også inden for grænserne af `slice`, hvilket opfylder de andre krav til `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // kunne implementeres med skiver, men dette undgår grænsekontrol

                // SIKKERHED: `assume`-opkald er sikre, da et udsnit starter
                // skal være ikke-nul, og skiver over ikke-ZST'er skal også have en ikke-nul-slutmarkør.
                // Opkaldet til `next_unchecked!` er sikkert, da vi først kontrollerer, om iteratoren er tom.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Denne iterator er nu tom.
                    if mem::size_of::<T>() == 0 {
                        // Vi er nødt til at gøre det på denne måde, da `ptr` måske aldrig er 0, men `end` kan være (på grund af indpakning).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // SIKKERHED: slutningen kan ikke være 0, hvis T ikke er ZST, fordi ptr ikke er 0, og slut>> ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // SIKKERHED: Vi er inden for grænser.`post_inc_start` gør det rigtige, selv for ZST'er.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Vi tilsidesætter standardimplementeringen, som bruger `try_fold`, fordi denne enkle implementering genererer mindre LLVM IR og er hurtigere at kompilere.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Vi tilsidesætter standardimplementeringen, som bruger `try_fold`, fordi denne enkle implementering genererer mindre LLVM IR og er hurtigere at kompilere.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Vi tilsidesætter standardimplementeringen, som bruger `try_fold`, fordi denne enkle implementering genererer mindre LLVM IR og er hurtigere at kompilere.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Vi tilsidesætter standardimplementeringen, som bruger `try_fold`, fordi denne enkle implementering genererer mindre LLVM IR og er hurtigere at kompilere.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Vi tilsidesætter standardimplementeringen, som bruger `try_fold`, fordi denne enkle implementering genererer mindre LLVM IR og er hurtigere at kompilere.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Vi tilsidesætter standardimplementeringen, som bruger `try_fold`, fordi denne enkle implementering genererer mindre LLVM IR og er hurtigere at kompilere.
            // `assume` undgår også en grænsekontrol.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // SIKKERHED: Vi er garanteret i grænser af loop-invarianten:
                        // når `i >= n`, returnerer `self.next()` `None` og sløjfen går i stykker.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Vi tilsidesætter standardimplementeringen, som bruger `try_fold`, fordi denne enkle implementering genererer mindre LLVM IR og er hurtigere at kompilere.
            // `assume` undgår også en grænsekontrol.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // SIKKERHED: `i` skal være lavere end `n`, da den starter ved `n`
                        // og falder kun.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // SIKKERHED: den, der ringer op, skal garantere, at `i` er inden for
                // det underliggende udsnit, så `i` kan ikke overløbe en `isize`, og de returnerede referencer er garanteret at henvise til et element i udsnittet og dermed garanteret at være gyldige.
                //
                // Bemærk også, at den, der ringer op, også garanterer, at vi aldrig bliver ringet op med det samme indeks igen, og at der ikke kaldes andre metoder, der får adgang til denne underdel, så det er gyldigt, at den returnerede reference kan ændres i tilfælde af
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // kunne implementeres med skiver, men dette undgår grænsekontrol

                // SIKKERHED: `assume`-opkald er sikre, da en skives startmarkør skal være ikke-nul,
                // og skiver over ikke-ZST'er skal også have en ikke-nul-slutmarkør.
                // Opkaldet til `next_back_unchecked!` er sikkert, da vi først kontrollerer, om iteratoren er tom.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Denne iterator er nu tom.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // SIKKERHED: Vi er inden for grænser.`pre_dec_end` gør det rigtige, selv for ZST'er.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}