//! Gratis funktioner til at oprette `&[T]` og `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Danner et stykke fra en markør og en længde.
///
/// `len`-argumentet er antallet af **elementer**, ikke antallet af byte.
///
/// # Safety
///
/// Adfærd er udefineret, hvis nogen af følgende betingelser overtrædes:
///
/// * `data` skal være [valid] for at læse for `len * mem::size_of::<T>()` mange byte, og det skal være korrekt justeret.Dette betyder især:
///
///     * Hele hukommelsesområdet for dette udsnit skal være indeholdt i et enkelt tildelt objekt!
///       Skiver kan aldrig spænde over flere tildelte objekter.Se [below](#incorrect-usage) for et eksempel, der forkert ikke tager dette i betragtning.
///     * `data` skal være ikke-nul og justeres selv for skiver med nul længde.
///     En af grundene til dette er, at optimeringer af enumlayout kan stole på, at referencer (inklusive skiver af enhver længde) er justeret og ikke-null for at skelne dem fra andre data.
///     Du kan få en markør, der kan bruges som `data` til skiver uden længde ved hjælp af [`NonNull::dangling()`].
///
/// * `data` skal pege på `len` fortløbende korrekt initialiserede værdier af typen `T`.
///
/// * Den hukommelse, der henvises til af det returnerede udsnit, må ikke muteres i hele levetiden `'a`, undtagen inde i en `UnsafeCell`.
///
/// * Den samlede størrelse `len * mem::size_of::<T>()` af udsnittet må ikke være større end `isize::MAX`.
///   Se sikkerhedsdokumentationen for [`pointer::offset`].
///
/// # Caveat
///
/// Levetiden for den returnerede skive udledes af dens anvendelse.
/// For at forhindre utilsigtet misbrug foreslås det at binde levetiden til den kilde, der er sikker i sammenhængen, f.eks. Ved at give en hjælperfunktion, der tager levetiden for en værtsværdi for udsnittet eller ved eksplicit kommentar.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // manifestere et stykke for et enkelt element
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Forkert brug
///
/// Følgende `join_slices`-funktion er **usund** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Påstanden ovenfor sikrer, at `fst` og `snd` er sammenhængende, men de kan stadig være indeholdt i _different allocated objects_, i hvilket tilfælde oprettelse af dette udsnit er udefineret adfærd.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` og `b` er forskellige tildelte objekter ...
///     let a = 42;
///     let b = 27;
///     // ... som ikke desto mindre kan anbringes sammenhængende i hukommelsen: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Udfører den samme funktionalitet som [`from_raw_parts`], bortset fra at et ændret udsnit returneres.
///
/// # Safety
///
/// Adfærd er udefineret, hvis nogen af følgende betingelser overtrædes:
///
/// * `data` skal være [valid] for både læser og skriver for `len * mem::size_of::<T>()` mange byte, og det skal være korrekt justeret.Dette betyder især:
///
///     * Hele hukommelsesområdet for dette udsnit skal være indeholdt i et enkelt tildelt objekt!
///       Skiver kan aldrig spænde over flere tildelte objekter.
///     * `data` skal være ikke-nul og justeres selv for skiver med nul længde.
///     En af grundene til dette er, at optimeringer af enumlayout kan stole på, at referencer (inklusive skiver af enhver længde) er justeret og ikke-null for at skelne dem fra andre data.
///
///     Du kan få en markør, der kan bruges som `data` til skiver uden længde ved hjælp af [`NonNull::dangling()`].
///
/// * `data` skal pege på `len` fortløbende korrekt initialiserede værdier af typen `T`.
///
/// * Hukommelsen, der henvises til af det returnerede udsnit, må ikke tilgås gennem nogen anden markør (ikke afledt af returværdien) i hele `'a` levetid.
///   Både læse-og skriveadgang er forbudt.
///
/// * Den samlede størrelse `len * mem::size_of::<T>()` af udsnittet må ikke være større end `isize::MAX`.
///   Se sikkerhedsdokumentationen for [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Konverterer en henvisning til T til et stykke længde 1 (uden kopiering).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Konverterer en henvisning til T til et stykke længde 1 (uden kopiering).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}