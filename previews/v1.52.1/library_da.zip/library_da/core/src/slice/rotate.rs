// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Roterer området `[mid-left, mid+right)` således, at elementet ved `mid` bliver det første element.Tilsvarende roterer området `left`-elementerne til venstre eller `right`-elementerne til højre.
///
/// # Safety
///
/// Det angivne interval skal være gyldigt til læsning og skrivning.
///
/// # Algorithm
///
/// Algoritme 1 bruges til små værdier på `left + right` eller til store `T`.
/// Elementerne flyttes ind i deres endelige positioner en ad gangen startende ved `mid - left` og fremad med `right` trin modulo `left + right`, således at kun en midlertidig er nødvendig.
/// Til sidst ankommer vi tilbage til `mid - left`.
/// Men hvis `gcd(left + right, right)` ikke er 1, springede ovenstående trin over elementer.
/// For eksempel:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Heldigvis er antallet af springede elementer mellem de færdige elementer altid lige, så vi kan bare udligne vores startposition og gøre flere runder (det samlede antal runder er `gcd(left + right, right)` value).
///
/// Slutresultatet er, at alle elementer færdiggøres én gang og kun én gang.
///
/// Algoritme 2 bruges, hvis `left + right` er stor, men `min(left, right)` er lille nok til at passe ind i en stakbuffer.
/// `min(left, right)`-elementerne kopieres til bufferen, `memmove` påføres de andre, og dem på bufferen flyttes tilbage i hullet på den modsatte side af, hvor de stammer fra.
///
/// Algoritmer, der kan vektoriseres, overgår ovenstående, når `left + right` bliver stor nok.
/// Algoritme 1 kan vektoriseres ved at klumpe og udføre mange runder på én gang, men der er for få runder i gennemsnit, indtil `left + right` er enorm, og det værste tilfælde af en enkelt runde er altid der.
/// I stedet bruger algoritme 3 gentagen swapping af `min(left, right)`-elementer, indtil der er tilbage et mindre rotationsproblem.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// når `left < right` sker byttet fra venstre i stedet.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. nedenstående algoritmer kan mislykkes, hvis disse tilfælde ikke er markeret
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algoritme 1 Microbenchmarks angiver, at den gennemsnitlige ydeevne for tilfældige skift er bedre hele vejen indtil omkring `left + right == 32`, men i værste fald går ydeevnen jævnt omkring 16.
            // 24 blev valgt som mellemgrund.
            // Hvis størrelsen på `T` er større end 4 `usize`s, overgår denne algoritme også andre algoritmer.
            //
            //
            let x = unsafe { mid.sub(left) };
            // begyndelsen af første runde
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` kan findes før hånd ved at beregne `gcd(left + right, right)`, men det er hurtigere at lave en sløjfe, der beregner gcd'en som en bivirkning og derefter udfører resten af klumpen
            //
            //
            let mut gcd = right;
            // benchmarks afslører, at det er hurtigere at bytte midlertidige hele vejen igennem i stedet for at læse en midlertidig én gang, kopiere baglæns og derefter skrive den midlertidige i slutningen.
            // Dette skyldes muligvis, at bytte eller udskifte midlertidige kun bruger en hukommelsesadresse i sløjfen i stedet for at skulle styre to.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // i stedet for at inkrementere `i` og derefter kontrollere, om det er uden for grænserne, kontrollerer vi, om `i` vil gå uden for grænserne ved næste trin.
                // Dette forhindrer indpakning af markører eller `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // slutningen af første runde
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // denne betingede skal være her, hvis `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // afslut klumpen med flere runder
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` er ikke en type af nul størrelse, så det er okay at dividere med dens størrelse.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algoritme 2 `[T; 0]` her skal sikre, at dette er passende justeret til T
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algoritme 3 Der er en alternativ måde at bytte på, der involverer at finde, hvor den sidste swap af denne algoritme ville være, og bytte ved hjælp af den sidste del i stedet for at bytte tilstødende klumper som denne algoritme gør, men denne måde er stadig hurtigere.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algoritme 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}