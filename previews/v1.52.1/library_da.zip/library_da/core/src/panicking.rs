//! Panic support til libcore
//!
//! Kernebiblioteket kan ikke definere panik, men det *erklærer* panik.
//! Dette betyder, at funktionerne inde i libcore er tilladt til panic, men for at være nyttige skal en opstrøms crate definere panik for, at libcore kan bruges.
//! Den nuværende grænseflade til panik er:
//!
//! ```
//! fn panic_impl(pi: &core::panic::PanicInfo<'_>) -> !
//! # { loop {} }
//! ```
//!
//! Denne definition giver mulighed for panik med nogen generel besked, men det tillader ikke at mislykkes med en `Box<Any>`-værdi.
//! (`PanicInfo` indeholder bare en `&(dyn Any + Send)`, som vi udfylder en dummy-værdi i 'PanicInfo: : internal_constructor'.) Årsagen til dette er, at libcore ikke har lov til at allokere.
//!
//!
//! Dette modul indeholder et par andre panikfunktioner, men det er bare de nødvendige langelementer til compileren.Alle panics kanaliseres gennem denne ene funktion.
//! Det aktuelle symbol erklæres via `#[panic_handler]`-attributten.
//!
//!
//!

#![allow(dead_code, missing_docs)]
#![unstable(
    feature = "core_panic",
    reason = "internal details of the implementation of the `panic!` and related macros",
    issue = "none"
)]

use crate::fmt;
use crate::panic::{Location, PanicInfo};

/// Den underliggende implementering af libcores `panic!`-makro, når der ikke bruges nogen formatering.
#[cold]
// aldrig inline, medmindre panic_immediate_abort for at undgå, at kode opblæses på opkaldsstederne så meget som muligt
//
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic"] // nødvendigt af codegen til panic ved overløb og andre `Assert` MIR-terminatorer
pub fn panic(expr: &'static str) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // Brug Arguments::new_v1 i stedet for format_args! ("{}", Expr) for potentielt at reducere størrelsesomkostningerne.
    // Format_args!makro bruger str's Display trait til at skrive expr, som kalder Formatter::pad, som skal imødekomme strengafkortning og polstring (selvom ingen bruges her).
    //
    // Brug af Arguments::new_v1 muliggør muligvis, at kompilatoren udelader Formatter::pad fra output binær, hvilket sparer op til et par kilobyte.
    //
    //
    panic_fmt(fmt::Arguments::new_v1(&[expr], &[]));
}

#[inline]
#[track_caller]
#[lang = "panic_str"] // behov for konstatevalueret panics
pub fn panic_str(expr: &str) -> ! {
    panic_fmt(format_args!("{}", expr));
}

#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[track_caller]
#[lang = "panic_bounds_check"] // nødvendigt af codegen til panic på OOB array/slice-adgang
fn panic_bounds_check(index: usize, len: usize) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    panic!("index out of bounds: the len is {} but the index is {}", len, index)
}

/// Den underliggende implementering af libcores `panic!`-makro, når der bruges formatering.
#[cold]
#[cfg_attr(not(feature = "panic_immediate_abort"), inline(never))]
#[cfg_attr(feature = "panic_immediate_abort", inline)]
#[track_caller]
pub fn panic_fmt(fmt: fmt::Arguments<'_>) -> ! {
    if cfg!(feature = "panic_immediate_abort") {
        super::intrinsics::abort()
    }

    // BEMÆRK Denne funktion krydser aldrig FFI-grænsen;Det er et Rust-til-Rust-opkald, der bliver løst til `#[panic_handler]`-funktionen.
    //
    extern "Rust" {
        #[lang = "panic_impl"]
        fn panic_impl(pi: &PanicInfo<'_>) -> !;
    }

    let pi = PanicInfo::internal_constructor(Some(&fmt), Location::caller());

    // SIKKERHED: `panic_impl` er defineret i sikker Rust-kode og er derfor sikker at ringe til.
    unsafe { panic_impl(&pi) }
}

#[derive(Debug)]
#[doc(hidden)]
pub enum AssertKind {
    Eq,
    Ne,
}

/// Intern funktion til `assert_eq!`-og `assert_ne!`-makroer
#[cold]
#[track_caller]
#[doc(hidden)]
pub fn assert_failed<T, U>(
    kind: AssertKind,
    left: &T,
    right: &U,
    args: Option<fmt::Arguments<'_>>,
) -> !
where
    T: fmt::Debug + ?Sized,
    U: fmt::Debug + ?Sized,
{
    #[track_caller]
    fn inner(
        kind: AssertKind,
        left: &dyn fmt::Debug,
        right: &dyn fmt::Debug,
        args: Option<fmt::Arguments<'_>>,
    ) -> ! {
        let op = match kind {
            AssertKind::Eq => "==",
            AssertKind::Ne => "!=",
        };

        match args {
            Some(args) => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`: {}"#,
                op, left, right, args
            ),
            None => panic!(
                r#"assertion failed: `(left {} right)`
  left: `{:?}`,
 right: `{:?}`"#,
                op, left, right,
            ),
        }
    }
    inner(kind, &left, &right, args)
}