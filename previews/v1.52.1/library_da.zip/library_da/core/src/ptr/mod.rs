//! Administrer hukommelse manuelt gennem rå pointer.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Mange funktioner i dette modul tager rå pointer som argumenter og læser fra eller skriver til dem.For at dette kan være sikkert, skal disse markører være *gyldige*.
//! Hvorvidt en markør er gyldig, afhænger af den funktion, den bruges til (læs eller skriv), og omfanget af den hukommelse, der er adgang til (dvs. hvor mange byte der er read/written).
//! De fleste funktioner bruger `*mut T` og `* const T` til kun at få adgang til en enkelt værdi, i hvilket tilfælde dokumentationen udelader størrelsen og antager implicit, at den er `size_of::<T>()`-byte.
//!
//! De nøjagtige regler for gyldighed er endnu ikke fastlagt.Garantierne på dette tidspunkt er meget minimale:
//!
//! * En [null]-markør er *aldrig* gyldig, ikke engang for adgang til [size zero][zst].
//! * For at en markør er gyldig, er det nødvendigt, men ikke altid tilstrækkeligt, at markøren er *derferenceable*: hukommelsesområdet for den givne størrelse, der starter ved markøren, skal alle være inden for rammerne af et enkelt tildelt objekt.
//!
//! Bemærk, at i Rust betragtes hver (stack-allocated)-variabel som et separat tildelt objekt.
//! * Selv for [size zero][zst]-operationer må markøren ikke pege på en deallokeret hukommelse, dvs. deallocation gør markører ugyldige selv for nulstørrelsesoperationer.
//! At caste et ikke-nul heltal *bogstaveligt* til en markør er dog gyldigt for adgang i nulstørrelse, selvom der tilfældigvis findes en hukommelse på den adresse og bliver deallokeret.
//! Dette svarer til at skrive din egen tildeler: tildeling af objekter i nulstørrelse er ikke særlig svært.
//! Den kanoniske måde at få en markør, der er gyldig til adgang til nulstørrelse, er [`NonNull::dangling`].
//! * Al adgang udført af funktioner i dette modul er *ikke-atomisk* i betydningen [atomic operations], der bruges til at synkronisere mellem tråde.
//! Dette betyder, at det er udefineret adfærd at udføre to samtidige adgang til den samme placering fra forskellige tråde, medmindre begge adgang kun læses fra hukommelsen.
//! Bemærk, at dette eksplicit inkluderer [`read_volatile`] og [`write_volatile`]: Flygtige adganger kan ikke bruges til synkronisering mellem tråde.
//! * Resultatet af at caste en henvisning til en markør er gyldigt, så længe det underliggende objekt er live, og ingen reference (kun rå pointere) bruges til at få adgang til den samme hukommelse.
//!
//! Disse aksiomer er sammen med omhyggelig brug af [`offset`] til markørregning nok til korrekt implementering af mange nyttige ting i usikker kode.
//! Der vil i sidste ende blive stillet stærkere garantier, da [aliasing]-reglerne bestemmes.
//! For mere information, se [book] samt afsnittet i referencen afsat til [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Gyldige råmarkører som defineret ovenfor er ikke nødvendigvis korrekt justeret (hvor "proper"-justering er defineret af pointetypen, dvs. at `*const T` skal være justeret til `mem::align_of::<T>()`).
//! Imidlertid kræver de fleste funktioner, at deres argumenter er korrekt justeret, og vil udtrykkeligt angive dette krav i deres dokumentation.
//! Bemærkelsesværdige undtagelser fra dette er [`read_unaligned`] og [`write_unaligned`].
//!
//! Når en funktion kræver korrekt tilpasning, gør den det, selvom adgangen har størrelse 0, dvs. selvom hukommelsen faktisk ikke berøres.Overvej at bruge [`NonNull::dangling`] i sådanne tilfælde.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Udfører destruktoren (hvis nogen) af den pegede værdi.
///
/// Dette svarer semantisk til at ringe til [`ptr::read`] og kassere resultatet, men har følgende fordele:
///
/// * Det er *påkrævet* at bruge `drop_in_place` til at droppe ikke-størrede typer som trait-objekter, fordi de ikke kan læses ud på stakken og droppes normalt.
///
/// * Optimereren er venligere at gøre dette over [`ptr::read`], når man slipper manuelt tildelt hukommelse (f.eks. I implementeringerne af `Box`/`Rc`/`Vec`), da compileren ikke behøver at bevise, at det er sundt at fremhæve kopien.
///
///
/// * Det kan bruges til at slippe [pinned]-data, når `T` ikke er `repr(packed)` (fastgjorte data må ikke flyttes, før de slippes).
///
/// Ikke-justerede værdier kan ikke slippes på plads, de skal kopieres til en justeret placering først ved hjælp af [`ptr::read_unaligned`].For pakkede strukturer udføres dette træk automatisk af compileren.
/// Dette betyder, at felterne med pakkede strækninger ikke tabes på plads.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Adfærd er udefineret, hvis nogen af følgende betingelser overtrædes:
///
/// * `to_drop` skal være [valid] til både læsning og skrivning.
///
/// * `to_drop` skal være korrekt justeret.
///
/// * Værdien `to_drop` peger på skal være gyldig for at droppe, hvilket kan betyde, at den skal opretholde yderligere invarianter, dette er typeafhængigt.
///
/// Derudover, hvis `T` ikke er [`Copy`], kan brug af den påpegede værdi efter opkald til `drop_in_place` forårsage udefineret adfærd.Bemærk, at `*to_drop = foo` tæller som en anvendelse, fordi det får værdien til at falde igen.
/// [`write()`] kan bruges til at overskrive data uden at få dem til at blive droppet.
///
/// Bemærk, at selvom `T` har størrelse `0`, skal markøren være ikke-NULL og være korrekt justeret.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Fjern det sidste element manuelt fra en vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Få en rå markør til det sidste element i `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Afkort `v` for at forhindre, at det sidste element tabes.
///     // Vi gør det først for at forhindre problemer, hvis `drop_in_place` under panics.
///     v.set_len(1);
///     // Uden et opkald `drop_in_place` ville det sidste element aldrig blive droppet, og den hukommelse, det administrerer, ville lækkes.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Sørg for, at det sidste element blev droppet.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Bemærk, at compileren udfører denne kopi automatisk, når du slipper pakkede structs, dvs. du behøver normalt ikke bekymre dig om sådanne problemer, medmindre du ringer `drop_in_place` manuelt.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Kode her betyder ikke noget, dette erstattes af den ægte droplim af compileren.
    //

    // SIKKERHED: se kommentar ovenfor
    unsafe { drop_in_place(to_drop) }
}

/// Opretter en null rå markør.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Opretter en null-mutabel rå markør.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Manuelt impl. Nødvendigt for at undgå `T: Clone` bundet.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Manuel implementering nødvendig for at undgå `T: Copy` bundet.
impl<T> Copy for FatPtr<T> {}

/// Danner en rå skive fra en markør og en længde.
///
/// `len`-argumentet er antallet af **elementer**, ikke antallet af byte.
///
/// Denne funktion er sikker, men faktisk at bruge returværdien er usikker.
/// Se dokumentationen til [`slice::from_raw_parts`] for sikkerhedskrav til udsnit.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // Opret en skivemarkør, når du starter med en markør til det første element
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // SIKKERHED: Adgang til værdien fra `Repr`-unionen er sikker, da * const [T]
        //
        // og FatPtr har de samme hukommelseslayouter.Kun std kan stille denne garanti.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Udfører den samme funktionalitet som [`slice_from_raw_parts`], bortset fra at en rå ændret skive returneres i modsætning til en rå uforanderlig skive.
///
///
/// Se dokumentationen til [`slice_from_raw_parts`] for flere detaljer.
///
/// Denne funktion er sikker, men faktisk at bruge returværdien er usikker.
/// Se dokumentationen til [`slice::from_raw_parts_mut`] for sikkerhedskrav til udsnit.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // tildel en værdi ved et indeks i udsnittet
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // SIKKERHED: Adgang til værdien fra `Repr`-unionen er sikker, da * mut [T]
        // og FatPtr har de samme hukommelseslayouter
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Byt værdierne på to mutable placeringer af samme type uden at deinitialisere heller.
///
/// Men med de følgende to undtagelser svarer denne funktion semantisk til [`mem::swap`]:
///
///
/// * Det fungerer på rå pointer i stedet for referencer.
/// Når der findes referencer, bør [`mem::swap`] foretrækkes.
///
/// * De to pegede værdier kan overlappe hinanden.
/// Hvis værdierne overlapper hinanden, bruges den overlappende hukommelsesregion fra `x`.
/// Dette demonstreres i det andet eksempel nedenfor.
///
/// # Safety
///
/// Adfærd er udefineret, hvis nogen af følgende betingelser overtrædes:
///
/// * Både `x` og `y` skal være [valid] for både læsning og skrivning.
///
/// * Både `x` og `y` skal være korrekt justeret.
///
/// Bemærk, at selvom `T` har størrelse `0`, skal markørerne være ikke-NULL og korrekt justeret.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Byt to ikke-overlappende regioner:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // dette er `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // dette er `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Byt to overlappende regioner:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // dette er `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // dette er `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Indekserne `1..3` for segmentet overlapper mellem `x` og `y`.
///     // Rimelige resultater ville være for dem at være `[2, 3]`, så indeks `0..3` er `[1, 2, 3]` (matchende `y` før `swap`);eller for at de skal være `[0, 1]`, så indeks `1..4` er `[0, 1, 2]` (matchende `x` før `swap`).
/////
///     // Denne implementering er defineret for at tage sidstnævnte valg.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Giv os lidt ridseplads til at arbejde med.
    // Vi behøver ikke bekymre os om dråber: `MaybeUninit` gør intet, når det droppes.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Udfør swap-SIKKERHED: den, der ringer op, skal garantere, at `x` og `y` er gyldige til skrivning og korrekt justeret.
    // `tmp` kan ikke overlappe hverken `x` eller `y`, fordi `tmp` netop blev tildelt på stakken som et separat tildelt objekt.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` og `y` kan overlappe hinanden
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Byt `count * size_of::<T>()` bytes mellem de to hukommelsesregioner, der begynder ved `x` og `y`.
/// De to regioner må *ikke* overlappe hinanden.
///
/// # Safety
///
/// Adfærd er udefineret, hvis nogen af følgende betingelser overtrædes:
///
/// * Både `x` og `y` skal være [valid] for både læsning og skrivning af `count *
///   størrelse_af: :<T>() `bytes.
///
/// * Både `x` og `y` skal være korrekt justeret.
///
/// * Hukommelsesområdet, der begynder ved `x` med en størrelse på 'tælle *
///   størrelse_af: :<T>() `byte skal *ikke* overlappe hukommelsesområdet, der begynder ved `y` med samme størrelse.
///
/// Bemærk, at selvom den effektivt kopierede størrelse (`count * size_of: :<T>()`) er `0`, skal markørerne være ikke-NULL og korrekt justeret.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Grundlæggende brug:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // SIKKERHED: den, der ringer op, skal garantere, at `x` og `y` er
    // gyldig til skrivning og korrekt justeret.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // For typer, der er mindre end nedenstående blokoptimering, skal du bare bytte direkte for at undgå pessimisering af kodegen.
    //
    if mem::size_of::<T>() < 32 {
        // SIKKERHED: den, der ringer op, skal garantere, at `x` og `y` er gyldige
        // til skriver, korrekt justeret og ikke-overlappende.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Tilgangen her er at bruge simd til at bytte x&y effektivt.
    // Test viser, at bytte af enten 32 byte eller 64 byte ad gangen er mest effektiv for Intel Haswell E-processorer.
    // LLVM er mere i stand til at optimere, hvis vi giver en struct en #[repr(simd)], selvom vi faktisk ikke bruger denne struct direkte.
    //
    //
    // FIXME repr(simd) brudt på emscripten og redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Loop gennem x&y, kopier dem `Block` ad gangen Optimizer skal rulle sløjfen fuldt ud for de fleste typer NB
    // Vi kan ikke bruge en for loop, da `range` impl kalder `mem::swap` rekursivt
    //
    let mut i = 0;
    while i + block_size <= len {
        // Opret noget uinitialiseret hukommelse som ridseplads Ved at erklære `t` her undgår du at justere stakken, når denne sløjfe ikke er brugt
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // SIKKERHED: Som `i < len`, og som den, der ringer op, skal garantere, at `x` og `y` er gyldige
        // for `len` byte skal `x + i` og `y + i` være gyldige adresser, der opfylder sikkerhedskontrakten for `add`.
        //
        // Den, der ringer op, skal også garantere, at `x` og `y` er gyldige til skrivning, korrekt justeret og ikke-overlappende, hvilket opfylder sikkerhedskontrakten for `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Byt en blok af byte af x&y ved at bruge t som en midlertidig buffer. Dette skal optimeres til effektive SIMD-operationer, hvor det er tilgængeligt
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Byt eventuelle resterende byte
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // SIKKERHED: se forrige sikkerhedskommentar.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Flytter `src` ind i den spidse `dst` og returnerer den forrige `dst`-værdi.
///
/// Ingen af værdierne tabes.
///
/// Denne funktion svarer semantisk til [`mem::replace`], bortset fra at den fungerer på rå markører i stedet for referencer.
/// Når der findes referencer, bør [`mem::replace`] foretrækkes.
///
/// # Safety
///
/// Adfærd er udefineret, hvis nogen af følgende betingelser overtrædes:
///
/// * `dst` skal være [valid] til både læsning og skrivning.
///
/// * `dst` skal være korrekt justeret.
///
/// * `dst` skal pege på en korrekt initialiseret værdi af typen `T`.
///
/// Bemærk, at selvom `T` har størrelse `0`, skal markøren være ikke-NULL og være korrekt justeret.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` ville have den samme effekt uden at kræve den usikre blok.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // SIKKERHED: den, der ringer op, skal garantere, at `dst` er gyldig
    // kastet til en ændret reference (gyldig til skrivning, justeret, initialiseret) og kan ikke overlappe `src`, da `dst` skal pege på et særskilt allokeret objekt.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // kan ikke overlappe hinanden
    }
    src
}

/// Læser værdien fra `src` uden at flytte den.Dette efterlader hukommelsen i `src` uændret.
///
/// # Safety
///
/// Adfærd er udefineret, hvis nogen af følgende betingelser overtrædes:
///
/// * `src` skal være [valid] for læsning.
///
/// * `src` skal være korrekt justeret.Brug [`read_unaligned`], hvis dette ikke er tilfældet.
///
/// * `src` skal pege på en korrekt initialiseret værdi af typen `T`.
///
/// Bemærk, at selvom `T` har størrelse `0`, skal markøren være ikke-NULL og være korrekt justeret.
///
/// # Examples
///
/// Grundlæggende brug:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Manuel implementering af [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Opret en bitvis kopi af værdien ved `a` i `tmp`.
///         let tmp = ptr::read(a);
///
///         // Afslutning på dette tidspunkt (enten ved eksplicit at returnere eller ved at ringe til en funktion, som panics) ville få værdien i `tmp` til at falde, mens den samme værdi stadig refereres af `a`.
///         // Dette kan udløse udefineret adfærd, hvis `T` ikke er `Copy`.
/////
/////
///
///         // Opret en bitvis kopi af værdien ved `b` i `a`.
///         // Dette er sikkert, fordi mutable referencer ikke kan alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Som ovenfor kan afslutning her udløse udefineret adfærd, fordi den samme værdi henvises til af `a` og `b`.
/////
///
///         // Flyt `tmp` til `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` er blevet flyttet (`write` overtager ejerskabet af sit andet argument), så intet droppes implicit her.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Ejerskab af den returnerede værdi
///
/// `read` opretter en bitvis kopi af `T`, uanset om `T` er [`Copy`].
/// Hvis `T` ikke er [`Copy`], kan brug af både den returnerede værdi og værdien ved `*src` krænke hukommelsessikkerheden.
/// Bemærk, at tildeling til `*src` tæller som en anvendelse, fordi den vil forsøge at droppe værdien ved `* src`.
///
/// [`write()`] kan bruges til at overskrive data uden at få dem til at blive droppet.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` peger nu på den samme underliggende hukommelse som `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Tildeling til `s2` får sin oprindelige værdi til at falde.
///     // Ud over dette punkt skal `s` ikke længere bruges, da den underliggende hukommelse er frigjort.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Tildeling til `s` vil medføre, at den gamle værdi slettes igen, hvilket resulterer i udefineret adfærd.
/////
///     // s= String::from("bar");//FEJL
///
///     // `ptr::write` kan bruges til at overskrive en værdi uden at tabe den.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SIKKERHED: den, der ringer op, skal garantere, at `src` er gyldig til læsning.
    // `src` kan ikke overlappe `tmp`, fordi `tmp` netop blev tildelt på stakken som et separat tildelt objekt.
    //
    //
    // Da vi lige har skrevet en gyldig værdi i `tmp`, er den garanteret initialiseret korrekt.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Læser værdien fra `src` uden at flytte den.Dette efterlader hukommelsen i `src` uændret.
///
/// I modsætning til [`read`] fungerer `read_unaligned` med ikke-justerede markører.
///
/// # Safety
///
/// Adfærd er udefineret, hvis nogen af følgende betingelser overtrædes:
///
/// * `src` skal være [valid] for læsning.
///
/// * `src` skal pege på en korrekt initialiseret værdi af typen `T`.
///
/// Ligesom [`read`] opretter `read_unaligned` en bitvis kopi af `T`, uanset om `T` er [`Copy`].
/// Hvis `T` ikke er [`Copy`], kan både den returnerede værdi og værdien ved `*src` bruge [violate memory safety][read-ownership].
///
/// Bemærk, at selvom `T` har størrelse `0`, skal markøren være ikke-NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## På `packed`-strukturer
///
/// Det er i øjeblikket umuligt at oprette rå pointer til ikke-justerede felter i en pakket struktur.
///
/// Forsøg på at oprette en rå markør til et `unaligned`-strukturfelt med et udtryk som `&packed.unaligned as *const FieldType` opretter en mellemliggende ikke-justeret reference, før den konverteres til en rå markør.
///
/// At denne reference er midlertidig og straks cast er ubetydelig, da compileren altid forventer, at referencer justeres korrekt.
/// Som et resultat forårsager brug af `&packed.unaligned as *const FieldType` øjeblikkelig* udefineret adfærd * i dit program.
///
/// Et eksempel på, hvad der ikke skal gøres, og hvordan dette relaterer til `read_unaligned`, er:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Her forsøger vi at tage adressen på et 32-bit heltal, der ikke er justeret.
///     let unaligned =
///         // Her oprettes en midlertidig ikke-justeret reference, som resulterer i udefineret adfærd, uanset om referencen bruges eller ej.
/////
///         &packed.unaligned
///         // Casting til en rå markør hjælper ikke;fejlen skete allerede.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Det er dog sikkert at få adgang til ikke-justerede felter direkte med f.eks. `packed.unaligned`.
///
///
///
///
///
///
// FIXME: Opdater dokumenter baseret på resultatet af RFC #2582 og venner.
/// # Examples
///
/// Læs en størrelsesværdi fra en bytebuffer:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // SIKKERHED: den, der ringer op, skal garantere, at `src` er gyldig til læsning.
    // `src` kan ikke overlappe `tmp`, fordi `tmp` netop blev tildelt på stakken som et separat tildelt objekt.
    //
    //
    // Da vi lige har skrevet en gyldig værdi i `tmp`, er den garanteret initialiseret korrekt.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Overskriver en hukommelsesplacering med den givne værdi uden at læse eller slippe den gamle værdi.
///
/// `write` taber ikke indholdet af `dst`.
/// Dette er sikkert, men det kan lækker allokeringer eller ressourcer, så man skal være opmærksom på ikke at overskrive et objekt, der skal droppes.
///
///
/// Derudover falder det ikke `src`.Semantisk flyttes `src` til det sted, som `dst` peger på.
///
/// Dette er passende til initialisering af ikke-initialiseret hukommelse eller overskrivning af hukommelse, der tidligere har været [`read`] fra.
///
/// # Safety
///
/// Adfærd er udefineret, hvis nogen af følgende betingelser overtrædes:
///
/// * `dst` skal være [valid] til skrivning.
///
/// * `dst` skal være korrekt justeret.Brug [`write_unaligned`], hvis dette ikke er tilfældet.
///
/// Bemærk, at selvom `T` har størrelse `0`, skal markøren være ikke-NULL og være korrekt justeret.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Grundlæggende brug:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Manuel implementering af [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Opret en bitvis kopi af værdien ved `a` i `tmp`.
///         let tmp = ptr::read(a);
///
///         // Afslutning på dette tidspunkt (enten ved eksplicit at returnere eller ved at ringe til en funktion, som panics) ville få værdien i `tmp` til at falde, mens den samme værdi stadig refereres af `a`.
///         // Dette kan udløse udefineret adfærd, hvis `T` ikke er `Copy`.
/////
/////
///
///         // Opret en bitvis kopi af værdien ved `b` i `a`.
///         // Dette er sikkert, fordi mutable referencer ikke kan alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Som ovenfor kan afslutning her udløse udefineret adfærd, fordi den samme værdi henvises til af `a` og `b`.
/////
///
///         // Flyt `tmp` til `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` er blevet flyttet (`write` overtager ejerskabet af sit andet argument), så intet droppes implicit her.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Vi kalder det indre direkte for at undgå funktionsopkald i den genererede kode, da `intrinsics::copy_nonoverlapping` er en indpakningsfunktion.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // SIKKERHED: den, der ringer op, skal garantere, at `dst` er gyldig til skrivning.
    // `dst` kan ikke overlappe `src`, fordi den, der ringer op, har ændret adgang til `dst`, mens `src` ejes af denne funktion.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Overskriver en hukommelsesplacering med den givne værdi uden at læse eller slippe den gamle værdi.
///
/// I modsætning til [`write()`] er markøren muligvis ikke justeret.
///
/// `write_unaligned` taber ikke indholdet af `dst`.Dette er sikkert, men det kan lækker allokeringer eller ressourcer, så man skal være opmærksom på ikke at overskrive et objekt, der skal droppes.
///
/// Derudover falder det ikke `src`.Semantisk flyttes `src` til det sted, som `dst` peger på.
///
/// Dette er passende til initialisering af ikke-initialiseret hukommelse eller overskrivning af hukommelse, der tidligere er blevet læst med [`read_unaligned`].
///
/// # Safety
///
/// Adfærd er udefineret, hvis nogen af følgende betingelser overtrædes:
///
/// * `dst` skal være [valid] til skrivning.
///
/// Bemærk, at selvom `T` har størrelse `0`, skal markøren være ikke-NULL.
///
/// [valid]: self#safety
///
/// ## På `packed`-strukturer
///
/// Det er i øjeblikket umuligt at oprette rå pointer til ikke-justerede felter i en pakket struktur.
///
/// Forsøg på at oprette en rå markør til et `unaligned`-strukturfelt med et udtryk som `&packed.unaligned as *const FieldType` opretter en mellemliggende ikke-justeret reference, før den konverteres til en rå markør.
///
/// At denne reference er midlertidig og straks cast er ubetydelig, da compileren altid forventer, at referencer justeres korrekt.
/// Som et resultat forårsager brug af `&packed.unaligned as *const FieldType` øjeblikkelig* udefineret adfærd * i dit program.
///
/// Et eksempel på, hvad der ikke skal gøres, og hvordan dette relaterer til `write_unaligned`, er:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Her forsøger vi at tage adressen på et 32-bit heltal, der ikke er justeret.
///     let unaligned =
///         // Her oprettes en midlertidig ikke-justeret reference, som resulterer i udefineret adfærd, uanset om referencen bruges eller ej.
/////
///         &mut packed.unaligned
///         // Casting til en rå markør hjælper ikke;fejlen skete allerede.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Det er dog sikkert at få adgang til ikke-justerede felter direkte med f.eks. `packed.unaligned`.
///
///
///
///
///
///
///
///
///
// FIXME: Opdater dokumenter baseret på resultatet af RFC #2582 og venner.
/// # Examples
///
/// Skriv en størrelsesværdi til en bytebuffer:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // SIKKERHED: den, der ringer op, skal garantere, at `dst` er gyldig til skrivning.
    // `dst` kan ikke overlappe `src`, fordi den, der ringer op, har ændret adgang til `dst`, mens `src` ejes af denne funktion.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Vi kalder det indre direkte for at undgå funktionsopkald i den genererede kode.
        intrinsics::forget(src);
    }
}

/// Udfører en flygtig aflæsning af værdien fra `src` uden at flytte den.Dette efterlader hukommelsen i `src` uændret.
///
/// Flygtige operationer er beregnet til at virke på I/O-hukommelse og garanteres ikke at blive fjernet eller omorganiseret af compileren på tværs af andre flygtige operationer.
///
/// # Notes
///
/// Rust har i øjeblikket ikke en streng og formelt defineret hukommelsesmodel, så den nøjagtige semantik af, hvad "volatile" betyder her, kan ændres over tid.
/// Når det er sagt, vil semantikken næsten altid ende med at ligne [C11's definition of volatile][c11].
///
/// Compileren bør ikke ændre den relative rækkefølge eller antallet af flygtige hukommelsesoperationer.
/// Flygtige hukommelsesoperationer på nulstørrelsestyper (f.eks. Hvis en nulstørrelsestype sendes til `read_volatile`) er dog noops og kan ignoreres.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Adfærd er udefineret, hvis nogen af følgende betingelser overtrædes:
///
/// * `src` skal være [valid] for læsning.
///
/// * `src` skal være korrekt justeret.
///
/// * `src` skal pege på en korrekt initialiseret værdi af typen `T`.
///
/// Ligesom [`read`] opretter `read_volatile` en bitvis kopi af `T`, uanset om `T` er [`Copy`].
/// Hvis `T` ikke er [`Copy`], kan både den returnerede værdi og værdien ved `*src` bruge [violate memory safety][read-ownership].
/// Det er næsten helt sikkert forkert at opbevare typer, der ikke er ['Copy'] i flygtig hukommelse.
///
/// Bemærk, at selvom `T` har størrelse `0`, skal markøren være ikke-NULL og være korrekt justeret.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Ligesom i C, har en operation, der er flygtig, ingen betydning for spørgsmål, der involverer samtidig adgang fra flere tråde.Flygtige adganger opfører sig nøjagtigt som ikke-atomiske adganger i den henseende.
///
/// Især er et løb mellem en `read_volatile` og enhver skriveoperation til samme sted udefineret adfærd.
///
/// # Examples
///
/// Grundlæggende brug:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Ikke i panik for at holde codegen-påvirkningen mindre.
        abort();
    }
    // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Udfører en ustabil skrivning af en hukommelsesplacering med den givne værdi uden at læse eller slippe den gamle værdi.
///
/// Flygtige operationer er beregnet til at virke på I/O-hukommelse og garanteres ikke at blive fjernet eller omorganiseret af compileren på tværs af andre flygtige operationer.
///
/// `write_volatile` taber ikke indholdet af `dst`.Dette er sikkert, men det kan lækker allokeringer eller ressourcer, så man skal være opmærksom på ikke at overskrive et objekt, der skal droppes.
///
/// Derudover falder det ikke `src`.Semantisk flyttes `src` til det sted, som `dst` peger på.
///
/// # Notes
///
/// Rust har i øjeblikket ikke en streng og formelt defineret hukommelsesmodel, så den nøjagtige semantik af, hvad "volatile" betyder her, kan ændres over tid.
/// Når det er sagt, vil semantikken næsten altid ende med at ligne [C11's definition of volatile][c11].
///
/// Compileren bør ikke ændre den relative rækkefølge eller antallet af flygtige hukommelsesoperationer.
/// Imidlertid er flygtige hukommelsesoperationer på nulstørrelsestyper (f.eks. Hvis en nulstørrelsestype sendes til `write_volatile`) noops og kan ignoreres.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Adfærd er udefineret, hvis nogen af følgende betingelser overtrædes:
///
/// * `dst` skal være [valid] til skrivning.
///
/// * `dst` skal være korrekt justeret.
///
/// Bemærk, at selvom `T` har størrelse `0`, skal markøren være ikke-NULL og være korrekt justeret.
///
/// [valid]: self#safety
///
/// Ligesom i C, har en operation, der er flygtig, ingen betydning for spørgsmål, der involverer samtidig adgang fra flere tråde.Flygtige adganger opfører sig nøjagtigt som ikke-atomiske adganger i den henseende.
///
/// Især er et løb mellem en `write_volatile` og enhver anden operation (læsning eller skrivning) på samme sted udefineret adfærd.
///
/// # Examples
///
/// Grundlæggende brug:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Ikke i panik for at holde codegen-påvirkningen mindre.
        abort();
    }
    // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Juster markøren `p`.
///
/// Beregn forskydning (i form af elementer i `stride`-skridt), der skal anvendes på markøren `p`, så markøren `p` bliver justeret til `a`.
///
/// Note: Denne implementering er omhyggeligt skræddersyet til ikke panic.Det er UB for dette at panic.
/// Den eneste reelle ændring, der kan foretages her, er ændring af `INV_TABLE_MOD_16` og tilhørende konstanter.
///
/// Hvis vi nogensinde beslutter at gøre det muligt at kalde det indre med `a`, der ikke er en power-of-two, vil det sandsynligvis være mere forsigtigt at bare skifte til en naiv implementering snarere end at prøve at tilpasse dette til at imødekomme denne ændring.
///
///
/// Eventuelle spørgsmål går til@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Direkte brug af disse iboende egenskaber forbedrer kodegen markant på opt-niveau <=
    // 1, hvor metodeversionerne af disse operationer ikke er angivet.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Beregn multiplikativ modulær invers af `x` modulo `m`.
    ///
    /// Denne implementering er skræddersyet til `align_offset` og har følgende forudsætninger:
    ///
    /// * `m` er en power-of-two;
    /// * `x < m`; (hvis `x ≥ m`, send i stedet `x % m`)
    ///
    /// Implementering af denne funktion må ikke panic.Nogensinde.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Multiplikativ modulær invers tabel modulo 2⁴=16.
        ///
        /// Bemærk, at denne tabel ikke indeholder værdier, hvor invers ikke findes (dvs. for `0⁻¹ mod 16`, `2⁻¹ mod 16` osv.)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo, som `INV_TABLE_MOD_16` er beregnet til.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // SIKKERHED: `m` kræves for at være en power-of-two, derfor ikke-nul.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Vi gentager "up" ved hjælp af følgende formel:
            //
            // $$ xy ≡ 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // indtil 2²ⁿ ≥ m.Derefter kan vi reducere til vores ønskede `m` ved at tage resultatet `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) mod n
                //
                // Bemærk, at vi bruger indpakningsoperationer her med vilje-den originale formel bruger f.eks. Subtraktion `mod n`.
                // Det er helt fint at gøre dem `mod usize::MAX` i stedet, fordi vi alligevel tager resultatet `mod n` i slutningen.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // SIKKERHED: `a` er en power-of-two, derfor ikke-nul.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` sag kan beregnes mere simpelt gennem `-p (mod a)`, men det hæmmer LLVMs evne til at vælge instruktioner som `lea`.I stedet beregner vi
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // som distribuerer operationer rundt om den bærende, men pessimerer `and` tilstrækkeligt til, at LLVM er i stand til at udnytte de forskellige optimeringer, den kender til.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Allerede justeret.Yay!
        return 0;
    } else if stride == 0 {
        // Hvis markøren ikke er justeret, og elementet er nul-størrelse, vil ingen mængde elementer nogensinde justere markøren.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // SIKKERHED: a er power-of-two og derfor ikke-nul.stride==0 sagen behandles ovenfor.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // SIKKERHED: gcdpow har en øvre grænse, der højst er antallet af bit i en størrelse.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // SIKKERHED: gcd er altid større eller lig med 1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Denne branch løser følgende lineære kongruensligning:
        //
        // ` p + so = 0 mod a `
        //
        // `p` her er pointerværdien, `s`, stride af `T`, `o` offset i `T`s, og `a`, den ønskede justering.
        //
        // Med `g = gcd(a, s)`, og ovenstående betingelse, der hævder, at `p` også er delelig med `g`, kan vi betegne `a' = a/g`, `s' = s/g`, `p' = p/g`, så svarer dette til:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Den første periode er "the relative alignment of `p` to `a`" (divideret med `g`), den anden periode er "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (igen divideret med `g`).
        //
        // Opdeling med `g` er nødvendig for at gøre det omvendte velformet, hvis `a` og `s` ikke er co-prime.
        //
        // Desuden er resultatet produceret af denne løsning ikke "minimal", så det er nødvendigt at tage resultatet `o mod lcm(s, a)`.Vi kan erstatte `lcm(s, a)` med bare en `a'`.
        //
        //
        //
        //
        //

        // SIKKERHED: `gcdpow` har en øvre grænse, der ikke er større end antallet af efterfølgende 0-bits i `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // SIKKERHED: `a2` er ikke-nul.Skift af `a` med `gcdpow` kan ikke skifte nogen af de indstillede bits ud
        // i `a` (hvoraf den har nøjagtigt en).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // SIKKERHED: `gcdpow` har en øvre grænse, der ikke er større end antallet af efterfølgende 0-bits i `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // SIKKERHED: `gcdpow` har en øvre grænse, der ikke er større end antallet af efterfølgende 0-bits
        // `a`.
        // Desuden kan subtraktionen ikke løbe over, fordi `a2 = a >> gcdpow` altid vil være strengt større end `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // SIKKERHED: `a2` er en power-of-two, som bevist ovenfor.`s2` er strengt mindre end `a2`
        // fordi `(s % a) >> gcdpow` er strengt mindre end `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Kan slet ikke justeres.
    usize::MAX
}

/// Sammenligner rå råd til ligestilling.
///
/// Dette er det samme som at bruge `==`-operatøren, men mindre generisk:
/// argumenterne skal være `*const T` rå pointer, ikke noget, der implementerer `PartialEq`.
///
/// Dette kan bruges til at sammenligne `&T`-referencer (som implicerer til `*const T` implicit) efter deres adresse i stedet for at sammenligne de værdier, de peger på (hvilket er, hvad `PartialEq for &T`-implementeringen gør).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Skiver sammenlignes også efter deres længde (fede pointer):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits sammenlignes også ved deres implementering:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Markører har lige adresser.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Objekter har lige adresser, men `Trait` har forskellige implementeringer.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Konvertering af henvisningen til en `*const u8` sammenlignes efter adresse.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash en rå markør.
///
/// Dette kan bruges til at hash en `&T`-reference (som implicit tvinges til `*const T`) efter dens adresse i stedet for den værdi, den peger på (hvilket er, hvad `Hash for &T`-implementeringen gør).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Impls til funktionsmarkører
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Den mellemliggende støbning som størrelse er påkrævet til AVR
                // således at kildefunktionsmarkørens adresseområde bevares i den endelige funktionsmarkør.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Den mellemliggende støbning som størrelse er påkrævet til AVR
                // således at kildefunktionsmarkørens adresseområde bevares i den endelige funktionsmarkør.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Ingen variadiske funktioner med 0 parametre
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Opret en `const` rå markør til et sted uden at oprette en mellemreference.
///
/// Oprettelse af en reference med `&`/`&mut` er kun tilladt, hvis markøren er korrekt justeret og peger på initialiserede data.
/// I tilfælde, hvor disse krav ikke holder, skal der anvendes rå pegepinde i stedet.
/// `&expr as *const _` opretter imidlertid en reference, inden den kaster den til en rå markør, og denne reference er underlagt de samme regler som alle andre referencer.
///
/// Denne makro kan oprette en rå pointer *uden* at oprette en reference først.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` ville skabe en ikke-justeret reference og dermed være udefineret adfærd!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Opret en `mut` rå markør til et sted uden at oprette en mellemreference.
///
/// Oprettelse af en reference med `&`/`&mut` er kun tilladt, hvis markøren er korrekt justeret og peger på initialiserede data.
/// I tilfælde, hvor disse krav ikke holder, skal der anvendes rå pegepinde i stedet.
/// `&mut expr as *mut _` opretter dog en reference, før den kaster den til en rå markør, og denne reference er underlagt de samme regler som alle andre referencer.
///
/// Denne makro kan oprette en rå pointer *uden* at oprette en reference først.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` ville skabe en ikke-justeret reference og dermed være udefineret adfærd!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` tvinger kopiering af feltet i stedet for at oprette en reference.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}