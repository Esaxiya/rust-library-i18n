use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::mem;
use crate::slice::{self, SliceIndex};

#[lang = "const_ptr"]
impl<T: ?Sized> *const T {
    /// Returnerer `true`, hvis markøren er nul.
    ///
    /// Bemærk, at ikke-størrede typer har mange mulige nulmarkører, da kun rådatapekeren tages i betragtning, ikke deres længde, vtabel osv.
    /// Derfor kan to markører, der er nulige, muligvis stadig ikke svare til hinanden.
    ///
    /// ## Adfærd under konstruktionsevaluering
    ///
    /// Når denne funktion bruges under konstruktionsevaluering, returnerer den muligvis `false` for markører, der viser sig at være nul ved kørsel.
    /// Specifikt, når en markør til en eller anden hukommelse forskydes uden for dens grænser på en sådan måde, at den resulterende markør er nul, returnerer funktionen stadig `false`.
    ///
    /// Der er ingen måde for CTFE at kende den absolutte position for den hukommelse, så vi kan ikke vide, om markøren er nul eller ej.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let s: &str = "Follow the rabbit";
    /// let ptr: *const u8 = s.as_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Sammenlign via en rollebesætning med en tynd markør, så fede markører overvejer kun deres "data"-del for nullitet.
        //
        (self as *const u8).guaranteed_eq(null())
    }

    /// Kastes til en markør af en anden type.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *const U {
        self as _
    }

    /// Nedbryde en (muligvis bred) markør til er adresse-og metadatakomponenter.
    ///
    /// Markøren kan senere rekonstrueres med [`from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*const (), <T as super::Pointee>::Metadata) {
        (self.cast(), metadata(self))
    }

    /// Returnerer `None`, hvis markøren er nul, eller ellers returnerer en delt reference til den værdi, der er pakket i `Some`.Hvis værdien muligvis ikke er initialiseret, skal [`as_uninit_ref`] bruges i stedet.
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref
    ///
    /// # Safety
    ///
    /// Når du kalder denne metode, skal du sikre dig, at *enten* markøren er NULL *eller* at alt dette er sandt:
    ///
    /// * Markøren skal være korrekt justeret.
    ///
    /// * Det skal være "dereferencable" i den forstand, der er defineret i [the module documentation].
    ///
    /// * Markøren skal pege på en initialiseret forekomst af `T`.
    ///
    /// * Du skal håndhæve Rust s aliasingsregler, da den returnerede levetid `'a` er tilfældigt valgt og ikke nødvendigvis afspejler den faktiske levetid for dataene.
    ///   Især i hele denne levetid må den hukommelse, som markøren peger på, ikke blive muteret (undtagen inde i `UnsafeCell`).
    ///
    /// Dette gælder, selvom resultatet af denne metode er ubrugt!
    /// (Den del om at blive initialiseret er endnu ikke helt besluttet, men indtil det er den eneste sikre tilgang er at sikre, at de faktisk initialiseres.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Null-ukontrolleret version
    ///
    /// Hvis du er sikker på, at markøren aldrig kan være nul og leder efter en slags `as_ref_unchecked`, der returnerer `&T` i stedet for `Option<&T>`, skal du vide, at du kan henvise markøren direkte.
    ///
    ///
    /// ```
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // SIKKERHED: den, der ringer op, skal garantere, at `self` er gyldig
        // til en reference, hvis den ikke er nul.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Returnerer `None`, hvis markøren er nul, eller ellers returnerer en delt reference til den værdi, der er indpakket i `Some`.
    /// I modsætning til [`as_ref`] kræver dette ikke, at værdien skal initialiseres.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Når du kalder denne metode, skal du sikre dig, at *enten* markøren er NULL *eller* at alt dette er sandt:
    ///
    /// * Markøren skal være korrekt justeret.
    ///
    /// * Det skal være "dereferencable" i den forstand, der er defineret i [the module documentation].
    ///
    /// * Du skal håndhæve Rust s aliasingsregler, da den returnerede levetid `'a` er tilfældigt valgt og ikke nødvendigvis afspejler den faktiske levetid for dataene.
    ///
    ///   Især i hele denne levetid må den hukommelse, som markøren peger på, ikke blive muteret (undtagen inde i `UnsafeCell`).
    ///
    /// Dette gælder, selvom resultatet af denne metode er ubrugt!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *const u8 = &10u8 as *const u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // SIKKERHED: den, der ringer op, skal garantere, at `self` opfylder alle
        // krav til en reference.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Beregner forskydningen fra en markør.
    ///
    /// `count` er i enheder af T;f.eks. repræsenterer en `count` på 3 en markørforskydning på `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Hvis en af følgende betingelser overtrædes, er resultatet udefineret adfærd:
    ///
    /// * Både start-og resulterende markør skal være enten i grænser eller en byte forbi slutningen af det samme tildelte objekt.
    /// Bemærk, at i Rust betragtes hver (stack-allocated)-variabel som et separat tildelt objekt.
    ///
    /// * Den beregnede forskydning,**i byte**, kan ikke overløbe en `isize`.
    ///
    /// * Forskydningen, der er inden for grænserne, kan ikke stole på "wrapping around" adresseområdet.Det vil sige, at den uendelige præcisionssum **i byte** skal passe ind i en størrelse.
    ///
    /// Compileren og standardbiblioteket forsøger generelt at sikre, at allokeringer aldrig når en størrelse, hvor en forskydning er et problem.
    /// For eksempel sikrer `Vec` og `Box`, at de aldrig tildeler mere end `isize::MAX` byte, så `vec.as_ptr().add(vec.len())` er altid sikkert.
    ///
    /// De fleste platforme kan fundamentalt ikke engang konstruere en sådan fordeling.
    /// For eksempel kan ingen kendt 64-bit platform nogensinde tjene en anmodning om 2 <sup>63</sup> byte på grund af sidetabellbegrænsninger eller opdeling af adresseområdet.
    /// Imidlertid kan nogle 32-bit og 16-bit platforme med succes servere en anmodning om mere end `isize::MAX` bytes med ting som fysisk adresseudvidelse.
    ///
    /// Som sådan kan hukommelse erhvervet direkte fra allokatorer eller hukommelseskortede filer * være for stor til at håndtere denne funktion.
    ///
    /// Overvej at bruge [`wrapping_offset`] i stedet, hvis disse begrænsninger er vanskelige at opfylde.
    /// Den eneste fordel ved denne metode er, at den muliggør mere aggressive compileroptimeringer.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1) as char);
    ///     println!("{}", *ptr.offset(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `offset`.
        unsafe { intrinsics::offset(self, count) }
    }

    /// Beregner forskydningen fra en markør ved hjælp af indpakningsaritmetik.
    ///
    /// `count` er i enheder af T;f.eks. repræsenterer en `count` på 3 en markørforskydning på `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Denne handling i sig selv er altid sikker, men det er ikke at bruge den resulterende markør.
    ///
    /// Den resulterende markør forbliver knyttet til det samme tildelte objekt, som `self` peger på.
    /// Det kan *ikke* bruges til at få adgang til et andet tildelt objekt.Bemærk, at i Rust betragtes hver (stack-allocated)-variabel som et separat tildelt objekt.
    ///
    /// Med andre ord gør `let z = x.wrapping_offset((y as isize) - (x as isize))`*ikke*`z` det samme som `y`, selvom vi antager, at `T` har størrelse `1`, og der ikke er noget overløb: `z` er stadig knyttet til objektet `x` er knyttet til, og derferference er det udefineret adfærd, medmindre `x` og `y` peger ind i det samme tildelte objekt.
    ///
    /// Sammenlignet med [`offset`] forsinker denne metode grundlæggende kravet om at forblive inden for det samme tildelte objekt: [`offset`] er øjeblikkelig udefineret adfærd ved krydsning af objektgrænser;`wrapping_offset` producerer en markør, men fører stadig til udefineret adfærd, hvis en markør derferenseres, når den er uden for det objekt, den er knyttet til.
    /// [`offset`] kan optimeres bedre og foretrækkes derfor i præstationsfølsom kode.
    ///
    /// Den forsinkede kontrol tager kun højde for værdien af den markør, der blev henvist til, ikke de mellemliggende værdier, der blev brugt under beregningen af det endelige resultat.
    /// For eksempel er `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` altid det samme som `x`.Med andre ord er det tilladt at forlade det tildelte objekt og derefter genindtaste det senere.
    ///
    /// Hvis du har brug for at krydse objektgrænser, skal du kaste markøren til et heltal og gøre aritmetikken der.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// // Iterér ved hjælp af en rå markør i trin på to elementer
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// // Denne løkke udskriver "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *const T
    where
        T: Sized,
    {
        // SIKKERHED: `arith_offset` iboende har ingen forudsætninger for at blive kaldt.
        unsafe { intrinsics::arith_offset(self, count) }
    }

    /// Beregner afstanden mellem to markører.Den returnerede værdi er i enheder af T: afstanden i byte divideres med `mem::size_of::<T>()`.
    ///
    /// Denne funktion er den omvendte af [`offset`].
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Safety
    ///
    /// Hvis en af følgende betingelser overtrædes, er resultatet udefineret adfærd:
    ///
    /// * Både start-og anden markør skal være enten i grænser eller en byte forbi slutningen af det samme tildelte objekt.
    /// Bemærk, at i Rust betragtes hver (stack-allocated)-variabel som et separat tildelt objekt.
    ///
    /// * Begge markører skal være *afledt af* en markør til det samme objekt.
    ///   (Se nedenfor for et eksempel.)
    ///
    /// * Afstanden mellem markørerne i byte skal være et nøjagtigt multiplum af størrelsen på `T`.
    ///
    /// * Afstanden mellem markørerne,**i byte**, kan ikke overløbe en `isize`.
    ///
    /// * Afstanden inden for grænser kan ikke stole på "wrapping around" adresseområdet.
    ///
    /// Rust-typer er aldrig større end `isize::MAX` og Rust-tildelinger vikles aldrig rundt om pladsen, så to markører inden for en værdi af enhver Rust-type `T` vil altid opfylde de sidste to betingelser.
    ///
    /// Standardbiblioteket sikrer også generelt, at tildelinger aldrig når en størrelse, hvor en forskydning er et problem.
    /// For eksempel sikrer `Vec` og `Box`, at de aldrig tildeler mere end `isize::MAX` byte, så `ptr_into_vec.offset_from(vec.as_ptr())` opfylder altid de sidste to betingelser.
    ///
    /// De fleste platforme kan fundamentalt ikke engang konstruere en så stor allokering.
    /// For eksempel kan ingen kendt 64-bit platform nogensinde tjene en anmodning om 2 <sup>63</sup> byte på grund af sidetabellbegrænsninger eller opdeling af adresseområdet.
    /// Imidlertid kan nogle 32-bit og 16-bit platforme med succes servere en anmodning om mere end `isize::MAX` bytes med ting som fysisk adresseudvidelse.
    /// Som sådan kan hukommelse erhvervet direkte fra allokatorer eller hukommelseskortede filer * være for stor til at håndtere denne funktion.
    /// (Bemærk, at [`offset`] og [`add`] også har en lignende begrænsning og derfor heller ikke kan bruges på så store tildelinger.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Denne funktion panics hvis `T` er en nulstørrelse type ("ZST").
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let a = [0; 5];
    /// let ptr1: *const i32 = &a[1];
    /// let ptr2: *const i32 = &a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Forkert* brug:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8)) as *const u8;
    /// let ptr2 = Box::into_raw(Box::new(1u8)) as *const u8;
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Lav ptr2_other en "alias" af ptr2, men afledt af ptr1.
    /// let ptr2_other = (ptr1 as *const u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Da ptr2_other og ptr2 stammer fra pegepinde til forskellige objekter, er beregning af deres forskydning udefineret adfærd, selvom de peger på den samme adresse!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Udefineret adfærd
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        let pointee_size = mem::size_of::<T>();
        assert!(0 < pointee_size && pointee_size <= isize::MAX as usize);
        // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `ptr_offset_from`.
        unsafe { intrinsics::ptr_offset_from(self, origin) }
    }

    /// Returnerer, om to pegepinde er garanteret at være ens.
    ///
    /// Ved kørsel opfører denne funktion sig som `self == other`.
    /// I nogle sammenhænge (f.eks. Kompileringstidevaluering) er det imidlertid ikke altid muligt at bestemme lighed mellem to markører, så denne funktion kan med urette returnere `false` for markører, der senere faktisk viser sig at være lige.
    ///
    /// Men når det returnerer `true`, er markeringerne garanteret lige.
    ///
    /// Denne funktion er spejlet på [`guaranteed_ne`], men ikke dens inverse.Der er sammenligninger, som begge funktioner returnerer `false` for.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Returværdien kan ændre sig afhængigt af compilerversionen, og usikker kode afhænger muligvis ikke af resultatet af denne funktion for lydstyrke.
    /// Det foreslås kun at bruge denne funktion til ydeevneoptimeringer, hvor falske `false`-returværdier ved denne funktion ikke påvirker resultatet, men kun ydeevnen.
    /// Konsekvenserne af at bruge denne metode til at få runtime og kompileringskode til at opføre sig anderledes er ikke blevet undersøgt.
    /// Denne metode bør ikke bruges til at indføre sådanne forskelle, og den bør heller ikke stabiliseres, før vi har en bedre forståelse af dette problem.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self, other)
    }

    /// Returnerer, om to pegepinde er garanteret at være ulige.
    ///
    /// Ved kørsel opfører denne funktion sig som `self != other`.
    /// I nogle sammenhænge (f.eks. Evaluering af kompileringstid) er det imidlertid ikke altid muligt at bestemme uligheden mellem to markører, så denne funktion kan med urette returnere `false` for markører, der senere faktisk viser sig at være ulige.
    ///
    /// Men når det returnerer `true`, er markeringerne garanteret ulige.
    ///
    /// Denne funktion er spejlet på [`guaranteed_eq`], men ikke dens inverse.Der er sammenligninger, som begge funktioner returnerer `false` for.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Returværdien kan ændre sig afhængigt af compilerversionen, og usikker kode afhænger muligvis ikke af resultatet af denne funktion for lydstyrke.
    /// Det foreslås kun at bruge denne funktion til ydeevneoptimeringer, hvor falske `false`-returværdier ved denne funktion ikke påvirker resultatet, men kun ydeevnen.
    /// Konsekvenserne af at bruge denne metode til at få runtime og kompileringskode til at opføre sig anderledes er ikke blevet undersøgt.
    /// Denne metode bør ikke bruges til at indføre sådanne forskelle, og den bør heller ikke stabiliseres, før vi har en bedre forståelse af dette problem.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_ne(self, other: *const T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self, other)
    }

    /// Beregner forskydningen fra en markør (bekvemmelighed for `.offset(count as isize)`).
    ///
    /// `count` er i enheder af T;f.eks. repræsenterer en `count` på 3 en markørforskydning på `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Hvis en af følgende betingelser overtrædes, er resultatet udefineret adfærd:
    ///
    /// * Både start-og resulterende markør skal være enten i grænser eller en byte forbi slutningen af det samme tildelte objekt.
    /// Bemærk, at i Rust betragtes hver (stack-allocated)-variabel som et separat tildelt objekt.
    ///
    /// * Den beregnede forskydning,**i byte**, kan ikke overløbe en `isize`.
    ///
    /// * Forskydningen i grænser kan ikke stole på "wrapping around" adresseområdet.Det vil sige, at den uendelige præcisionssum skal passe i en `usize`.
    ///
    /// Compileren og standardbiblioteket forsøger generelt at sikre, at allokeringer aldrig når en størrelse, hvor en forskydning er et problem.
    /// For eksempel sikrer `Vec` og `Box`, at de aldrig tildeler mere end `isize::MAX` byte, så `vec.as_ptr().add(vec.len())` er altid sikkert.
    ///
    /// De fleste platforme kan fundamentalt ikke engang konstruere en sådan fordeling.
    /// For eksempel kan ingen kendt 64-bit platform nogensinde tjene en anmodning om 2 <sup>63</sup> byte på grund af sidetabellbegrænsninger eller opdeling af adresseområdet.
    /// Imidlertid kan nogle 32-bit og 16-bit platforme med succes servere en anmodning om mere end `isize::MAX` bytes med ting som fysisk adresseudvidelse.
    ///
    /// Som sådan kan hukommelse erhvervet direkte fra allokatorer eller hukommelseskortede filer * være for stor til at håndtere denne funktion.
    ///
    /// Overvej at bruge [`wrapping_add`] i stedet, hvis disse begrænsninger er vanskelige at opfylde.
    /// Den eneste fordel ved denne metode er, at den muliggør mere aggressive compileroptimeringer.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Beregner forskydningen fra en markør (bekvemmelighed for `.offset ((tælle som isize).wrapping_neg())`).
    ///
    /// `count` er i enheder af T;f.eks. repræsenterer en `count` på 3 en markørforskydning på `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Hvis en af følgende betingelser overtrædes, er resultatet udefineret adfærd:
    ///
    /// * Både start-og resulterende markør skal være enten i grænser eller en byte forbi slutningen af det samme tildelte objekt.
    /// Bemærk, at i Rust betragtes hver (stack-allocated)-variabel som et separat tildelt objekt.
    ///
    /// * Den beregnede forskydning må ikke overstige `isize::MAX`**byte**.
    ///
    /// * Forskydningen, der er inden for grænserne, kan ikke stole på "wrapping around" adresseområdet.Det vil sige, at den uendelige præcisionssum skal passe i en størrelse.
    ///
    /// Compileren og standardbiblioteket forsøger generelt at sikre, at allokeringer aldrig når en størrelse, hvor en forskydning er et problem.
    /// For eksempel sikrer `Vec` og `Box`, at de aldrig tildeler mere end `isize::MAX` byte, så `vec.as_ptr().add(vec.len()).sub(vec.len())` er altid sikkert.
    ///
    /// De fleste platforme kan fundamentalt ikke engang konstruere en sådan fordeling.
    /// For eksempel kan ingen kendt 64-bit platform nogensinde tjene en anmodning om 2 <sup>63</sup> byte på grund af sidetabellbegrænsninger eller opdeling af adresseområdet.
    /// Imidlertid kan nogle 32-bit og 16-bit platforme med succes servere en anmodning om mere end `isize::MAX` bytes med ting som fysisk adresseudvidelse.
    ///
    /// Som sådan kan hukommelse erhvervet direkte fra allokatorer eller hukommelseskortede filer * være for stor til at håndtere denne funktion.
    ///
    /// Overvej at bruge [`wrapping_sub`] i stedet, hvis disse begrænsninger er vanskelige at opfylde.
    /// Den eneste fordel ved denne metode er, at den muliggør mere aggressive compileroptimeringer.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Beregner forskydningen fra en markør ved hjælp af indpakningsaritmetik.
    /// (bekvemmelighed for `.wrapping_offset(count as isize)`)
    ///
    /// `count` er i enheder af T;f.eks. repræsenterer en `count` på 3 en markørforskydning på `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Denne handling i sig selv er altid sikker, men det er ikke at bruge den resulterende markør.
    ///
    /// Den resulterende markør forbliver knyttet til det samme tildelte objekt, som `self` peger på.
    /// Det kan *ikke* bruges til at få adgang til et andet tildelt objekt.Bemærk, at i Rust betragtes hver (stack-allocated)-variabel som et separat tildelt objekt.
    ///
    /// Med andre ord gør `let z = x.wrapping_add((y as usize) - (x as usize))`*ikke*`z` det samme som `y`, selvom vi antager, at `T` har størrelse `1`, og der ikke er noget overløb: `z` er stadig knyttet til objektet `x` er knyttet til, og derferference er det udefineret adfærd, medmindre `x` og `y` peger ind i det samme tildelte objekt.
    ///
    /// Sammenlignet med [`add`] forsinker denne metode grundlæggende kravet om at forblive inden for det samme tildelte objekt: [`add`] er øjeblikkelig udefineret adfærd ved krydsning af objektgrænser;`wrapping_add` producerer en markør, men fører stadig til udefineret adfærd, hvis en markør derferenseres, når den er uden for det objekt, den er knyttet til.
    /// [`add`] kan optimeres bedre og foretrækkes derfor i præstationsfølsom kode.
    ///
    /// Den forsinkede kontrol tager kun højde for værdien af den markør, der blev henvist til, ikke de mellemliggende værdier, der blev brugt under beregningen af det endelige resultat.
    /// For eksempel er `x.wrapping_add(o).wrapping_sub(o)` altid det samme som `x`.Med andre ord er det tilladt at forlade det tildelte objekt og derefter genindtaste det senere.
    ///
    /// Hvis du har brug for at krydse objektgrænser, skal du kaste markøren til et heltal og gøre aritmetikken der.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// // Iterér ved hjælp af en rå markør i trin på to elementer
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Denne løkke udskriver "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Beregner forskydningen fra en markør ved hjælp af indpakningsaritmetik.
    /// (bekvemmelighed for `.wrapping_offset ((tælle som isize).wrapping_neg())`)
    ///
    /// `count` er i enheder af T;f.eks. repræsenterer en `count` på 3 en markørforskydning på `3 * size_of::<T>()` bytes.
    ///
    /// # Safety
    ///
    /// Denne handling i sig selv er altid sikker, men det er ikke at bruge den resulterende markør.
    ///
    /// Den resulterende markør forbliver knyttet til det samme tildelte objekt, som `self` peger på.
    /// Det kan *ikke* bruges til at få adgang til et andet tildelt objekt.Bemærk, at i Rust betragtes hver (stack-allocated)-variabel som et separat tildelt objekt.
    ///
    /// Med andre ord gør `let z = x.wrapping_sub((x as usize) - (y as usize))`*ikke*`z` det samme som `y`, selvom vi antager, at `T` har størrelse `1`, og der ikke er noget overløb: `z` er stadig knyttet til objektet `x` er knyttet til, og derferference er det udefineret adfærd, medmindre `x` og `y` peger ind i det samme tildelte objekt.
    ///
    /// Sammenlignet med [`sub`] forsinker denne metode grundlæggende kravet om at forblive inden for det samme tildelte objekt: [`sub`] er øjeblikkelig udefineret adfærd ved krydsning af objektgrænser;`wrapping_sub` producerer en markør, men fører stadig til udefineret adfærd, hvis en markør derferenseres, når den er uden for det objekt, den er knyttet til.
    /// [`sub`] kan optimeres bedre og foretrækkes derfor i præstationsfølsom kode.
    ///
    /// Den forsinkede kontrol tager kun højde for værdien af den markør, der blev henvist til, ikke de mellemliggende værdier, der blev brugt under beregningen af det endelige resultat.
    /// For eksempel er `x.wrapping_add(o).wrapping_sub(o)` altid det samme som `x`.Med andre ord er det tilladt at forlade det tildelte objekt og derefter genindtaste det senere.
    ///
    /// Hvis du har brug for at krydse objektgrænser, skal du kaste markøren til et heltal og gøre aritmetikken der.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// // Iterér ved hjælp af en rå markør i trin på to elementer (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Denne løkke udskriver "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Indstiller markørværdien til `ptr`.
    ///
    /// Hvis `self` er en (fat)-markør til en ikke-dimensioneret type, påvirker denne handling kun markørdelen, mens det for (thin)-markører til størrelsestyper har samme effekt som en simpel opgave.
    ///
    /// Den resulterende markør vil have herkomst af `val`, dvs. for en fedtmarkør er denne operation semantisk den samme som at oprette en ny fedtmarkør med datapunktværdien på `val` men metadataene til `self`.
    ///
    ///
    /// # Examples
    ///
    /// Denne funktion er primært nyttig til at tillade byte-vis markørregning på potentielt fede markører:
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &arr[0] as *const dyn Debug;
    /// let thin = ptr as *const u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *const i32), 3);
    ///     println!("{:?}", &*ptr); // udskriver "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *const u8) -> Self {
        let thin = &mut self as *mut *const T as *mut *const u8;
        // SIKKERHED: I tilfælde af en tynd markør er denne handling identisk
        // til en simpel opgave.
        // I tilfælde af en fedtmarkør med den aktuelle implementering af fedtmarkørlayout er det første felt i en sådan markør altid datapunkten, som ligeledes tildeles.
        //
        unsafe { *thin = val };
        self
    }

    /// Læser værdien fra `self` uden at flytte den.
    /// Dette efterlader hukommelsen i `self` uændret.
    ///
    /// Se [`ptr::read`] for sikkerhedshensyn og eksempler.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `read`.
        unsafe { read(self) }
    }

    /// Udfører en flygtig aflæsning af værdien fra `self` uden at flytte den.Dette efterlader hukommelsen i `self` uændret.
    ///
    /// Flygtige operationer er beregnet til at virke på I/O-hukommelse og garanteres ikke at blive fjernet eller omorganiseret af compileren på tværs af andre flygtige operationer.
    ///
    ///
    /// Se [`ptr::read_volatile`] for sikkerhedshensyn og eksempler.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Læser værdien fra `self` uden at flytte den.
    /// Dette efterlader hukommelsen i `self` uændret.
    ///
    /// I modsætning til `read` er markøren muligvis ikke justeret.
    ///
    /// Se [`ptr::read_unaligned`] for sikkerhedshensyn og eksempler.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Kopierer `count * size_of<T>`-byte fra `self` til `dest`.
    /// Kilden og destinationen kan overlappe hinanden.
    ///
    /// NOTE: dette har den *samme* argumentrækkefølge som [`ptr::copy`].
    ///
    /// Se [`ptr::copy`] for sikkerhedshensyn og eksempler.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Kopierer `count * size_of<T>`-byte fra `self` til `dest`.
    /// Kilden og destinationen overlapper muligvis *ikke*.
    ///
    /// NOTE: dette har den *samme* argumentordre som [`ptr::copy_nonoverlapping`].
    ///
    /// Se [`ptr::copy_nonoverlapping`] for sikkerhedshensyn og eksempler.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Beregner den forskydning, der skal anvendes på markøren for at gøre den justeret til `align`.
    ///
    /// Hvis det ikke er muligt at justere markøren, returnerer implementeringen `usize::MAX`.
    /// Det er tilladt for implementeringen at *altid* returnere `usize::MAX`.
    /// Kun din algoritmes præstation kan afhænge af at få en anvendelig forskydning her, ikke dens korrekthed.
    ///
    /// Forskydningen udtrykkes i antallet af `T`-elementer og ikke byte.Den returnerede værdi kan bruges med `wrapping_add`-metoden.
    ///
    /// Der er ingen garantier overhovedet for, at udligning af markøren ikke løber over eller går ud over den tildeling, som markøren peger på.
    ///
    /// Det er op til den, der ringer op, at sikre, at den returnerede forskydning er korrekt i alle andre udtryk end justering.
    ///
    /// # Panics
    ///
    /// Funktionen panics, hvis `align` ikke er en power-of-two.
    ///
    /// # Examples
    ///
    /// Adgang til tilstødende `u8` som `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // mens markøren kan justeres via `offset`, peger den uden for tildelingen
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // SIKKERHED: `align` er kontrolleret til at være en effekt på 2 ovenfor
        unsafe { align_offset(self, align) }
    }
}

#[lang = "const_slice_ptr"]
impl<T> *const [T] {
    /// Returnerer længden af en rå skive.
    ///
    /// Den returnerede værdi er antallet af **elementer**, ikke antallet af byte.
    ///
    /// Denne funktion er sikker, selv når den rå skive ikke kan kastes til en skivereference, fordi markøren er nul eller ikke justeret.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    ///
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // SIKKERHED: dette er sikkert, fordi `*const [T]` og `FatPtr<T>` har samme layout.
            // Kun `std` kan stille denne garanti.
            unsafe { Repr { rust: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Returnerer en rå markør til udsnitets buffer.
    ///
    /// Dette svarer til støbning af `self` til `*const T`, men mere typesikker.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *const [i8] = ptr::slice_from_raw_parts(ptr::null(), 3);
    /// assert_eq!(slice.as_ptr(), 0 as *const i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_ptr(self) -> *const T {
        self as *const T
    }

    /// Returnerer en rå markør til et element eller underdel uden at foretage grænsekontrol.
    ///
    /// Det er *[udefineret adfærd]* at kalde denne metode med et indeks uden for grænserne, eller når `self` ikke kan udskydes, selvom den resulterende markør ikke bruges.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &[1, 2, 4] as *const [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked(1), x.as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked<I>(self, index: I) -> *const I::Output
    where
        I: SliceIndex<[T]>,
    {
        // SIKKERHED: den, der ringer op, sørger for, at `self` kan fjernes og `index` inden for rammerne.
        unsafe { index.get_unchecked(self) }
    }

    /// Returnerer `None`, hvis markøren er nul, eller ellers returnerer et delt stykke til den værdi, der er pakket i `Some`.
    /// I modsætning til [`as_ref`] kræver dette ikke, at værdien skal initialiseres.
    ///
    /// [`as_ref`]: #method.as_ref
    ///
    /// # Safety
    ///
    /// Når du kalder denne metode, skal du sikre dig, at *enten* markøren er NULL *eller* at alt dette er sandt:
    ///
    /// * Markøren skal være [valid] for at læse for `ptr.len() * mem::size_of::<T>()` mange byte, og den skal være korrekt justeret.Dette betyder især:
    ///
    ///     * Hele hukommelsesområdet for dette udsnit skal være indeholdt i et enkelt tildelt objekt!
    ///       Skiver kan aldrig spænde over flere tildelte objekter.
    ///
    ///     * Markøren skal være justeret selv for skiver med nul længde.
    ///     En af grundene til dette er, at optimeringer af enumlayout kan stole på, at referencer (inklusive skiver af enhver længde) er justeret og ikke-null for at skelne dem fra andre data.
    ///
    ///     Du kan få en markør, der kan bruges som `data` til skiver uden længde ved hjælp af [`NonNull::dangling()`].
    ///
    /// * Den samlede størrelse `ptr.len() * mem::size_of::<T>()` af udsnittet må ikke være større end `isize::MAX`.
    ///   Se sikkerhedsdokumentationen for [`pointer::offset`].
    ///
    /// * Du skal håndhæve Rust s aliasingsregler, da den returnerede levetid `'a` er tilfældigt valgt og ikke nødvendigvis afspejler den faktiske levetid for dataene.
    ///   Især i hele denne levetid må den hukommelse, som markøren peger på, ikke blive muteret (undtagen inde i `UnsafeCell`).
    ///
    /// Dette gælder, selvom resultatet af denne metode er ubrugt!
    ///
    /// Se også [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }
}

// Ligestilling for markører
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *const T {
    #[inline]
    fn eq(&self, other: &*const T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *const T {}

// Sammenligning for markører
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *const T {
    #[inline]
    fn cmp(&self, other: &*const T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *const T {
    #[inline]
    fn partial_cmp(&self, other: &*const T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*const T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*const T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*const T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*const T) -> bool {
        *self >= *other
    }
}