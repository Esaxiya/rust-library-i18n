use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// En indpakning omkring en rå ikke-nul `*mut T`, der indikerer, at indehaveren af denne indpakning ejer referenten.
/// Nyttig til at bygge abstraktioner som `Box<T>`, `Vec<T>`, `String` og `HashMap<K, V>`.
///
/// I modsætning til `*mut T` opfører `Unique<T>` sig "as if", det var en forekomst af `T`.
/// Det implementerer `Send`/`Sync`, hvis `T` er `Send`/`Sync`.
/// Det indebærer også den slags stærke alias-garantier, som en forekomst af `T` kan forvente:
/// markørens referent skal ikke ændres uden en unik sti til dens egen Unikke.
///
/// Hvis du er usikker på, om det er korrekt at bruge `Unique` til dine formål, kan du overveje at bruge `NonNull`, som har svagere semantik.
///
///
/// I modsætning til `*mut T` skal markøren altid være ikke-nul, selvom markøren aldrig bliver refereret til.
/// Dette er for at enums kan bruge denne forbudte værdi som en diskriminant-`Option<Unique<T>>` har samme størrelse som `Unique<T>`.
/// Markøren kan dog stadig dingle, hvis den ikke refereres til.
///
/// I modsætning til `*mut T` er `Unique<T>` kovariant i forhold til `T`.
/// Dette skal altid være korrekt for enhver type, der overholder Uniques aliasingskrav.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: denne markør har ingen konsekvenser for varians, men er nødvendig
    // for dropck at forstå, at vi logisk set ejer en `T`.
    //
    // For detaljer, se:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` pointere er `Send`, hvis `T` er `Send`, fordi de data, de henviser til, ikke er alias.
/// Bemærk, at denne aliasing-invariant ikke styrkes af typesystemet;abstraktionen ved hjælp af `Unique` skal håndhæve den.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` pointere er `Sync`, hvis `T` er `Sync`, fordi de data, de henviser til, ikke er alias.
/// Bemærk, at denne aliasing-invariant ikke styrkes af typesystemet;abstraktionen ved hjælp af `Unique` skal håndhæve den.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Opretter en ny `Unique`, der er dinglende, men godt justeret.
    ///
    /// Dette er nyttigt til initialisering af typer, der dovnt tildeles, som `Vec::new` gør.
    ///
    /// Bemærk, at markørværdien muligvis kan repræsentere en gyldig markør til en `T`, hvilket betyder, at denne ikke må bruges som en "not yet initialized"-sentinelværdi.
    /// Typer, som dovent tildeles, skal spore initialisering på anden måde.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // SIKKERHED: mem::align_of() returnerer en gyldig, ikke-nul-markør.Det
        // betingelserne for at ringe til new_unchecked() respekteres således.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Opretter en ny `Unique`.
    ///
    /// # Safety
    ///
    /// `ptr` skal være ikke-nul.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SIKKERHED: den, der ringer op, skal garantere, at `ptr` ikke er nul.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Opretter en ny `Unique`, hvis `ptr` ikke er nul.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SIKKERHED: Markøren er allerede kontrolleret og er ikke nul.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Henter den underliggende `*mut`-markør.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Indleder indholdet.
    ///
    /// Den resulterende levetid er bundet til sig selv, så dette opfører sig "as if", det var faktisk en forekomst af T, der bliver lånt.
    /// Hvis der er behov for en længere (unbound) levetid, skal du bruge `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SIKKERHED: den, der ringer op, skal garantere, at `self` opfylder alle
        // krav til en reference.
        unsafe { &*self.as_ptr() }
    }

    /// Du kan henvise til indholdet omhyggeligt.
    ///
    /// Den resulterende levetid er bundet til sig selv, så dette opfører sig "as if", det var faktisk en forekomst af T, der bliver lånt.
    /// Hvis der er behov for en længere (unbound) levetid, skal du bruge `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SIKKERHED: den, der ringer op, skal garantere, at `self` opfylder alle
        // krav til en ændret reference.
        unsafe { &mut *self.as_ptr() }
    }

    /// Kastes til en markør af en anden type.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // SIKKERHED: Unique::new_unchecked() skaber en ny unikhed og behov
        // den givne markør ikke er nul.
        // Da vi passerer os selv som en markør, kan det ikke være nul.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SIKKERHED: En ændret reference kan ikke være nul
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}