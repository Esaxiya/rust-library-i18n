#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Giver markørens metadatatype for enhver type, der peges på.
///
/// # Markør metadata
///
/// Rå markørtyper og referencetyper i Rust kan betragtes som lavet af to dele:
/// en datapeger, der indeholder hukommelsesadressen for værdien og nogle metadata.
///
/// For typer med statisk størrelse (der implementerer `Sized` traits) såvel som for `extern`-typer siges det, at markører er "tynde": metadata er nulstørrelse, og dens type er `()`.
///
///
/// Markører til [dynamically-sized types][dst] siges at være `brede` eller `fede`, de har ikke-størrelse metadata:
///
/// * For strukturer, hvis sidste felt er en sommertid, er metadata metadata for det sidste felt
/// * For `str`-typen er metadata længden i byte som `usize`
/// * For udsnitstyper som `[T]` er metadata længden i varer som `usize`
/// * For trait-objekter som `dyn SomeTrait` er metadata [`DynMetadata<Self>`][DynMetadata] (f.eks. `DynMetadata<dyn SomeTrait>`)
///
/// I future kan Rust-sproget få nye typer typer, der har forskellige markørmetadata.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # `Pointee` trait
///
/// Pointen med denne trait er dens `Metadata`-tilknyttede type, som er `()` eller `usize` eller `DynMetadata<_>` som beskrevet ovenfor.
/// Det implementeres automatisk for enhver type.
/// Det kan antages at være implementeret i en generisk sammenhæng, selv uden en tilsvarende binding.
///
/// # Usage
///
/// Rå pegepinde kan nedbrydes til datadressen og metadatakomponenterne med deres [`to_raw_parts`]-metode.
///
/// Alternativt kan metadata alene ekstraheres med [`metadata`]-funktionen.
/// En reference kan videregives til [`metadata`] og implicit tvinges.
///
/// En (possibly-wide)-markør kan sættes sammen fra sin adresse og metadata med [`from_raw_parts`] eller [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Typen for metadata i markører og henvisninger til `Self`.
    #[lang = "metadata_type"]
    // NOTE: Opbevar trait bounds i `static_assert_expected_bounds_for_metadata`
    //
    // i `library/core/src/ptr/metadata.rs` synkroniseret med dem her:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Markører til typer, der implementerer dette trait-alias, er `tynde`.
///
/// Dette inkluderer statisk-Sized-typer og `extern`-typer.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: stabiliser ikke dette, før trait-aliasser er stabile på sproget?
pub trait Thin = Pointee<Metadata = ()>;

/// Uddrag metadata-komponenten i en markør.
///
/// Værdier af typen `*mut T`, `&T` eller `&mut T` kan overføres direkte til denne funktion, da de implicit tvinges til `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // SIKKERHED: Adgang til værdien fra `PtrRepr`-unionen er sikker, da * konst T
    // og PtrComponents<T>har de samme hukommelseslayouter.
    // Kun std kan stille denne garanti.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Danner en (possibly-wide) rå pointer fra en datadresse og metadata.
///
/// Denne funktion er sikker, men den returnerede markør er ikke nødvendigvis sikker for forskydning.
/// For skiver, se dokumentationen til [`slice::from_raw_parts`] for at få sikkerhedskrav.
/// For trait-objekter skal metadataene komme fra en markør til den samme underliggende slettede type.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // SIKKERHED: Adgang til værdien fra `PtrRepr`-unionen er sikker, da * konst T
    // og PtrComponents<T>har de samme hukommelseslayouter.
    // Kun std kan stille denne garanti.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Udfører den samme funktionalitet som [`from_raw_parts`], bortset fra at en rå `*mut`-markør returneres i modsætning til en rå `* const`-markør.
///
///
/// Se dokumentationen til [`from_raw_parts`] for flere detaljer.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // SIKKERHED: Adgang til værdien fra `PtrRepr`-unionen er sikker, da * konst T
    // og PtrComponents<T>har de samme hukommelseslayouter.
    // Kun std kan stille denne garanti.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Manuel implementering nødvendig for at undgå `T: Copy` bundet.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Manuelt impl. Nødvendigt for at undgå `T: Clone` bundet.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Metadataene for en `Dyn = dyn SomeTrait` trait-objekttype.
///
/// Det er en markør til en vtabel (virtuel opkaldstabel), der repræsenterer al den nødvendige information til at manipulere den betontype, der er gemt inde i et trait-objekt.
/// Tabellen indeholder især:
///
/// * type størrelse
/// * typejustering
/// * en markør til typens `drop_in_place` impl (kan være en no-op for almindelig-gamle-data)
/// * henvisninger til alle metoderne til typens implementering af trait
///
/// Bemærk, at de første tre er specielle, fordi de er nødvendige for at tildele, slippe og deallocere ethvert trait-objekt.
///
/// Det er muligt at navngive denne struktur med en typeparameter, der ikke er et `dyn` trait-objekt (for eksempel `DynMetadata<u64>`), men ikke at opnå en meningsfuld værdi af denne struktur.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Det fælles præfiks for alle vtabeller.Det efterfølges af funktionsmarkører til trait-metoder.
///
/// Privat implementeringsdetalje af `DynMetadata::size_of` osv.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Returnerer størrelsen på den type, der er knyttet til denne vtabel.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Returnerer justeringen af den type, der er knyttet til denne vtabel.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Returnerer størrelse og justering sammen som en `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // SIKKERHED: Compileren udsendte denne vtabel til en konkret Rust-type, som
        // er kendt for at have et gyldigt layout.Samme begrundelse som i `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Manuelle impl. Er nødvendige for at undgå `Dyn: $Trait`-grænser.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}