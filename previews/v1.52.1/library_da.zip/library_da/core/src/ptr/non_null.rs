use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` men ikke-nul og covariant.
///
/// Dette er ofte den rigtige ting at bruge, når man bygger datastrukturer ved hjælp af rå pegepinde, men i sidste ende er det farligere at bruge på grund af dets yderligere egenskaber.Hvis du ikke er sikker på, om du skal bruge `NonNull<T>`, skal du bare bruge `*mut T`!
///
/// I modsætning til `*mut T` skal markøren altid være ikke-nul, selvom markøren aldrig bliver derferenseret.Dette er for at enums kan bruge denne forbudte værdi som en diskriminant-`Option<NonNull<T>>` har samme størrelse som `* mut T`.
/// Markøren kan dog stadig dingle, hvis den ikke refereres til.
///
/// I modsætning til `*mut T` blev `NonNull<T>` valgt til at være covariant i forhold til `T`.Dette gør det muligt at bruge `NonNull<T>` ved opbygning af covariant-typer, men indfører risikoen for usundhed, hvis den bruges i en type, der faktisk ikke burde være covariant.
/// (Det modsatte valg blev foretaget for `*mut T`, selvom usundheden teknisk set kun kunne være forårsaget af at kalde usikre funktioner.)
///
/// Kovarians er korrekt for de mest sikre abstraktioner, såsom `Box`, `Rc`, `Arc`, `Vec` og `LinkedList`.Dette er tilfældet, fordi de leverer en offentlig API, der følger de normale delte XOR-ændrede regler for Rust.
///
/// Hvis din type ikke sikkert kan være covariant, skal du sikre dig, at den indeholder et yderligere felt for at give invarians.Ofte vil dette felt være en [`PhantomData`]-type som `PhantomData<Cell<T>>` eller `PhantomData<&'a mut T>`.
///
/// Bemærk, at `NonNull<T>` har en `From`-forekomst til `&T`.Dette ændrer dog ikke det faktum, at mutering gennem en (markør afledt af en) delt reference er udefineret adfærd, medmindre mutationen sker inde i en [`UnsafeCell<T>`].Det samme gælder for oprettelse af en ændret reference fra en delt reference.
///
/// Når du bruger denne `From`-forekomst uden en `UnsafeCell<T>`, er det dit ansvar at sikre, at `as_mut` aldrig kaldes op, og `as_ptr` aldrig bruges til mutation.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` markører er ikke `Send`, fordi de data, de henviser til, muligvis er alias.
// NB, dette impl er unødvendigt, men burde give bedre fejlmeddelelser.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` markører er ikke `Sync`, fordi de data, de henviser til, muligvis er alias.
// NB, dette impl er unødvendigt, men burde give bedre fejlmeddelelser.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Opretter en ny `NonNull`, der er dinglende, men godt justeret.
    ///
    /// Dette er nyttigt til initialisering af typer, der dovnt tildeles, som `Vec::new` gør.
    ///
    /// Bemærk, at markørværdien muligvis kan repræsentere en gyldig markør til en `T`, hvilket betyder, at denne ikke må bruges som en "not yet initialized"-sentinelværdi.
    /// Typer, som dovent tildeles, skal spore initialisering på anden måde.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // SIKKERHED: mem::align_of() returnerer en ikke-nul-størrelse, som derefter kastes
        // til en * mut T.
        // Derfor er `ptr` ikke nul, og betingelserne for at ringe til new_unchecked() overholdes.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Returnerer en delt referencer til værdien.I modsætning til [`as_ref`] kræver dette ikke, at værdien skal initialiseres.
    ///
    /// Se [`as_uninit_mut`] for den mutable modstykke.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Når du kalder denne metode, skal du sikre dig, at alt det følgende er sandt:
    ///
    /// * Markøren skal være korrekt justeret.
    ///
    /// * Det skal være "dereferencable" i den forstand, der er defineret i [the module documentation].
    ///
    /// * Du skal håndhæve Rust s aliasingsregler, da den returnerede levetid `'a` er tilfældigt valgt og ikke nødvendigvis afspejler den faktiske levetid for dataene.
    ///
    ///   Især i hele denne levetid må den hukommelse, som markøren peger på, ikke blive muteret (undtagen inde i `UnsafeCell`).
    ///
    /// Dette gælder, selvom resultatet af denne metode er ubrugt!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // SIKKERHED: den, der ringer op, skal garantere, at `self` opfylder alle
        // krav til en reference.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Returnerer en unik henvisning til værdien.I modsætning til [`as_mut`] kræver dette ikke, at værdien skal initialiseres.
    ///
    /// For den delte modstykke se [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Når du kalder denne metode, skal du sikre dig, at alt det følgende er sandt:
    ///
    /// * Markøren skal være korrekt justeret.
    ///
    /// * Det skal være "dereferencable" i den forstand, der er defineret i [the module documentation].
    ///
    /// * Du skal håndhæve Rust s aliasingsregler, da den returnerede levetid `'a` er tilfældigt valgt og ikke nødvendigvis afspejler den faktiske levetid for dataene.
    ///
    ///   Især i løbet af denne levetid må den hukommelse, som markøren peger på, ikke få adgang (læst eller skrevet) gennem nogen anden markør.
    ///
    /// Dette gælder, selvom resultatet af denne metode er ubrugt!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // SIKKERHED: den, der ringer op, skal garantere, at `self` opfylder alle
        // krav til en reference.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Opretter en ny `NonNull`.
    ///
    /// # Safety
    ///
    /// `ptr` skal være ikke-nul.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SIKKERHED: den, der ringer op, skal garantere, at `ptr` ikke er nul.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Opretter en ny `NonNull`, hvis `ptr` ikke er nul.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // SIKKERHED: Markøren er allerede markeret og er ikke nul
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Udfører den samme funktionalitet som [`std::ptr::from_raw_parts`], bortset fra at en `NonNull`-markør returneres i modsætning til en rå `*const`-markør.
    ///
    ///
    /// Se dokumentationen til [`std::ptr::from_raw_parts`] for flere detaljer.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // SIKKERHED: Resultatet af `ptr::from::raw_parts_mut` er ikke-nul, fordi `data_address` er.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Nedbryde en (muligvis bred) markør til er adresse-og metadatakomponenter.
    ///
    /// Markøren kan senere rekonstrueres med [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Henter den underliggende `*mut`-markør.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Returnerer en delt reference til værdien.Hvis værdien muligvis ikke er initialiseret, skal [`as_uninit_ref`] bruges i stedet.
    ///
    /// Se [`as_mut`] for den mutable modstykke.
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Når du kalder denne metode, skal du sikre dig, at alt det følgende er sandt:
    ///
    /// * Markøren skal være korrekt justeret.
    ///
    /// * Det skal være "dereferencable" i den forstand, der er defineret i [the module documentation].
    ///
    /// * Markøren skal pege på en initialiseret forekomst af `T`.
    ///
    /// * Du skal håndhæve Rust s aliasingsregler, da den returnerede levetid `'a` er tilfældigt valgt og ikke nødvendigvis afspejler den faktiske levetid for dataene.
    ///
    ///   Især i hele denne levetid må den hukommelse, som markøren peger på, ikke blive muteret (undtagen inde i `UnsafeCell`).
    ///
    /// Dette gælder, selvom resultatet af denne metode er ubrugt!
    /// (Den del om at blive initialiseret er endnu ikke helt besluttet, men indtil det er den eneste sikre tilgang er at sikre, at de faktisk initialiseres.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // SIKKERHED: den, der ringer op, skal garantere, at `self` opfylder alle
        // krav til en reference.
        unsafe { &*self.as_ptr() }
    }

    /// Returnerer en unik reference til værdien.Hvis værdien muligvis ikke er initialiseret, skal [`as_uninit_mut`] bruges i stedet.
    ///
    /// For den delte modstykke se [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Når du kalder denne metode, skal du sikre dig, at alt det følgende er sandt:
    ///
    /// * Markøren skal være korrekt justeret.
    ///
    /// * Det skal være "dereferencable" i den forstand, der er defineret i [the module documentation].
    ///
    /// * Markøren skal pege på en initialiseret forekomst af `T`.
    ///
    /// * Du skal håndhæve Rust s aliasingsregler, da den returnerede levetid `'a` er tilfældigt valgt og ikke nødvendigvis afspejler den faktiske levetid for dataene.
    ///
    ///   Især i løbet af denne levetid må den hukommelse, som markøren peger på, ikke få adgang (læst eller skrevet) gennem nogen anden markør.
    ///
    /// Dette gælder, selvom resultatet af denne metode er ubrugt!
    /// (Den del om at blive initialiseret er endnu ikke helt besluttet, men indtil det er den eneste sikre tilgang er at sikre, at de faktisk initialiseres.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // SIKKERHED: den, der ringer op, skal garantere, at `self` opfylder alle
        // krav til en ændret reference.
        unsafe { &mut *self.as_ptr() }
    }

    /// Kastes til en markør af en anden type.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // SIKKERHED: `self` er en `NonNull`-markør, der nødvendigvis ikke er nul
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Opretter en ikke-nul rå skive fra en tynd markør og en længde.
    ///
    /// `len`-argumentet er antallet af **elementer**, ikke antallet af byte.
    ///
    /// Denne funktion er sikker, men derferference for returværdien er usikker.
    /// Se dokumentationen til [`slice::from_raw_parts`] for sikkerhedskrav til udsnit.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // Opret en skivemarkør, når du starter med en markør til det første element
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Bemærk, at dette eksempel kunstigt demonstrerer brugen af denne metode, men `lad skære= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // SIKKERHED: `data` er en `NonNull`-markør, der nødvendigvis ikke er nul
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Returnerer længden af en rå skive, der ikke er nul.
    ///
    /// Den returnerede værdi er antallet af **elementer**, ikke antallet af byte.
    ///
    /// Denne funktion er sikker, selv når den ikke-nul rå skive ikke kan henvises til en skive, fordi markøren ikke har en gyldig adresse.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Returnerer en ikke-nul-markør til udsnitets buffer.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // SIKKERHED: Vi ved, at `self` ikke er nul.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Returnerer en rå markør til udsnitets buffer.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Returnerer en delt reference til et udsnit af muligvis ikke-initialiserede værdier.I modsætning til [`as_ref`] kræver dette ikke, at værdien skal initialiseres.
    ///
    /// Se [`as_uninit_slice_mut`] for den mutable modstykke.
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Når du kalder denne metode, skal du sikre dig, at alt det følgende er sandt:
    ///
    /// * Markøren skal være [valid] for at læse for `ptr.len() * mem::size_of::<T>()` mange byte, og den skal være korrekt justeret.Dette betyder især:
    ///
    ///     * Hele hukommelsesområdet for dette udsnit skal være indeholdt i et enkelt tildelt objekt!
    ///       Skiver kan aldrig spænde over flere tildelte objekter.
    ///
    ///     * Markøren skal være justeret selv for skiver med nul længde.
    ///     En af grundene til dette er, at optimeringer af enumlayout kan stole på, at referencer (inklusive skiver af enhver længde) er justeret og ikke-null for at skelne dem fra andre data.
    ///
    ///     Du kan få en markør, der kan bruges som `data` til skiver uden længde ved hjælp af [`NonNull::dangling()`].
    ///
    /// * Den samlede størrelse `ptr.len() * mem::size_of::<T>()` af udsnittet må ikke være større end `isize::MAX`.
    ///   Se sikkerhedsdokumentationen for [`pointer::offset`].
    ///
    /// * Du skal håndhæve Rust s aliasingsregler, da den returnerede levetid `'a` er tilfældigt valgt og ikke nødvendigvis afspejler den faktiske levetid for dataene.
    ///   Især i hele denne levetid må den hukommelse, som markøren peger på, ikke blive muteret (undtagen inde i `UnsafeCell`).
    ///
    /// Dette gælder, selvom resultatet af denne metode er ubrugt!
    ///
    /// Se også [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Returnerer en unik henvisning til et udsnit af muligvis ikke-initialiserede værdier.I modsætning til [`as_mut`] kræver dette ikke, at værdien skal initialiseres.
    ///
    /// For den delte modstykke se [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Når du kalder denne metode, skal du sikre dig, at alt det følgende er sandt:
    ///
    /// * Markøren skal være [valid] for at læse og skrive for `ptr.len() * mem::size_of::<T>()` mange byte, og den skal være korrekt justeret.Dette betyder især:
    ///
    ///     * Hele hukommelsesområdet for dette udsnit skal være indeholdt i et enkelt tildelt objekt!
    ///       Skiver kan aldrig spænde over flere tildelte objekter.
    ///
    ///     * Markøren skal være justeret selv for skiver med nul længde.
    ///     En af grundene til dette er, at optimeringer af enumlayout kan stole på, at referencer (inklusive skiver af enhver længde) er justeret og ikke-null for at skelne dem fra andre data.
    ///
    ///     Du kan få en markør, der kan bruges som `data` til skiver uden længde ved hjælp af [`NonNull::dangling()`].
    ///
    /// * Den samlede størrelse `ptr.len() * mem::size_of::<T>()` af udsnittet må ikke være større end `isize::MAX`.
    ///   Se sikkerhedsdokumentationen for [`pointer::offset`].
    ///
    /// * Du skal håndhæve Rust s aliasingsregler, da den returnerede levetid `'a` er tilfældigt valgt og ikke nødvendigvis afspejler den faktiske levetid for dataene.
    ///   Især i løbet af denne levetid må den hukommelse, som markøren peger på, ikke få adgang (læst eller skrevet) gennem nogen anden markør.
    ///
    /// Dette gælder, selvom resultatet af denne metode er ubrugt!
    ///
    /// Se også [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Dette er sikkert, da `memory` er gyldig til læser og skriver for `memory.len()` mange byte.
    /// // Bemærk, at opkald til `memory.as_mut()` ikke er tilladt her, da indholdet muligvis ikke er initialiseret.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // SIKKERHED: den, der ringer op, skal opretholde sikkerhedskontrakten for `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Returnerer en rå markør til et element eller underdel uden at foretage grænsekontrol.
    ///
    /// Det er *[udefineret adfærd]* at kalde denne metode med et indeks uden for grænserne, eller når `self` ikke kan udskydes, selvom den resulterende markør ikke bruges.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // SIKKERHED: den, der ringer op, sørger for, at `self` kan fjernes og `index` inden for rammerne.
        // Som en konsekvens kan den resulterende markør ikke være NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // SIKKERHED: En unik markør kan ikke være nul, så betingelserne for
        // new_unchecked() respekteres.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // SIKKERHED: En ændret reference kan ikke være nul.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // SIKKERHED: En reference kan ikke være ugyldig, så betingelserne for
        // new_unchecked() respekteres.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}