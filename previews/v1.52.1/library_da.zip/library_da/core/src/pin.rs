//! Typer, der fastgør data til deres placering i hukommelsen.
//!
//! Det er undertiden nyttigt at have objekter, der garanteret ikke bevæger sig, i den forstand at deres placering i hukommelsen ikke ændrer sig og dermed kan stole på.
//! Et godt eksempel på et sådant scenario ville være at opbygge selvhenvisende strukturer, da flytning af et objekt med markører til sig selv vil ugyldiggøre dem, hvilket kan forårsage udefineret adfærd.
//!
//! På et højt niveau sikrer en [`Pin<P>`], at pointeren for enhver markørtype `P` har en stabil placering i hukommelsen, hvilket betyder, at den ikke kan flyttes andetsteds, og dens hukommelse kan ikke omfordeles, før den bliver droppet.Vi siger, at pointee er "pinned".Ting bliver mere subtile, når man diskuterer typer, der kombineres fastgjort med ikke-fastgjorte data;[see below](#projections-and-structural-pinning) for flere detaljer.
//!
//! Som standard er alle typer i Rust bevægelige.
//! Rust tillader overførsel af alle typer byværdier, og almindelige smart-pointer-typer som [`Box<T>`] og `&mut T` tillader udskiftning og flytning af de værdier, de indeholder: du kan flytte ud af en [`Box<T>`], eller du kan bruge [`mem::swap`].
//! [`Pin<P>`] indpakker en markør type `P`, så [`Pin`]`<`[`Box`] `<T>>`fungerer meget som en almindelig
//!
//! [`Box<T>`]: when a [`Pin`]`<`[`Box`] `<T>>`bliver droppet, så gør dets indhold, og hukommelsen bliver
//!
//! deallocated.Tilsvarende er [`Pin`]`<&mut T>`meget lig `&mut T`.Imidlertid lader [`Pin<P>`] ikke klienter faktisk få en [`Box<T>`] eller `&mut T` til fastgjorte data, hvilket betyder, at du ikke kan bruge operationer som [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` har brug for `&mut T`, men vi kan ikke få det.
//!     // Vi sidder fast, vi kan ikke bytte indholdet af disse referencer.
//!     // Vi kunne bruge `Pin::get_unchecked_mut`, men det er usikkert af en grund:
//!     // vi har ikke lov til at bruge det til at flytte ting ud af `Pin`.
//! }
//! ```
//!
//! Det er værd at gentage, at [`Pin<P>`]*ikke* ændrer det faktum, at en Rust-kompilator betragter alle typer bevægelige.[`mem::swap`] kan stadig kaldes til enhver `T`.I stedet forhindrer [`Pin<P>`], at visse *værdier*(peget på af markører indpakket i [`Pin<P>`]) flyttes ved at gøre det umuligt at kalde metoder, der kræver `&mut T` på dem (som [`mem::swap`]).
//!
//! [`Pin<P>`] kan bruges til at pakke enhver markørtype `P`, og som sådan interagerer den med [`Deref`] og [`DerefMut`].En [`Pin<P>`], hvor `P: Deref` skal betragtes som en "`P`-style pointer" til en fastgjort `P::Target`-så en [`Pin`]`<`[`Box`] `<T>>`er en ejet markør til en fastgjort `T` og en [`Pin`] `<` [`Rc`]`<T>>`er en referencetællet markør til en fastgjort `T`.
//! For korrekthed er [`Pin<P>`] afhængig af implementeringerne af [`Deref`] og [`DerefMut`] for ikke at bevæge sig ud af deres `self`-parameter og kun altid returnere en markør til fastgjorte data, når de kaldes på en fastgjort markør.
//!
//! # `Unpin`
//!
//! Mange typer er altid frit bevægelige, selv når de er fastgjort, fordi de ikke stoler på at have en stabil adresse.Dette inkluderer alle basistyperne (som [`bool`], [`i32`] og referencer) samt typer, der udelukkende består af disse typer.Typer, der ikke er ligeglade med at fastgøre, implementerer [`Unpin`] auto-trait, som annullerer effekten af [`Pin<P>`].
//! For `T: Unpin`, [`Pin`]`<`[`Box`] `<T>>`og [`Box<T>`] fungerer identisk, ligesom [`Pin`] `<&mut T>` og `&mut T`.
//!
//! Bemærk, at fastgørelse og [`Unpin`] kun påvirker den pegede type `P::Target`, ikke selve markørtypen `P`, der blev pakket ind i [`Pin<P>`].For eksempel, hvorvidt [`Box<T>`] er [`Unpin`] eller ej, har ingen indflydelse på opførslen af [`Pin`]`<`[`Box`] `<T>>`(her er `T` den pegede type).
//!
//! # Eksempel: selvhenvisende struktur
//!
//! Før vi går i flere detaljer for at forklare de garantier og valg, der er forbundet med `Pin<T>`, diskuterer vi nogle eksempler på, hvordan det kan bruges.
//! Du er velkommen til [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Dette er en selvhenvisende struktur, fordi skivefeltet peger på datafeltet.
//! // Vi kan ikke informere kompilatoren om det med en normal reference, da dette mønster ikke kan beskrives med de sædvanlige låneregler.
//! //
//! // I stedet bruger vi en rå markør, selvom en der vides ikke at være nul, da vi ved, at den peger på strengen.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // For at sikre, at dataene ikke bevæger sig, når funktionen vender tilbage, placerer vi dem i bunken, hvor de forbliver i objektets levetid, og den eneste måde at få adgang til den ville være gennem en markør til den.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // vi opretter kun markøren, når dataene er på plads, ellers vil de allerede være flyttet, før vi selv startede
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // vi ved, at dette er sikkert, fordi ændring af et felt ikke flytter hele strukturen
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Markøren skal pege på den rigtige placering, så længe strukturen ikke er flyttet.
//! //
//! // I mellemtiden er vi fri til at flytte markøren rundt.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Da vores type ikke implementerer Unpin, kompileres dette ikke:
//! // lad mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Eksempel: påtrængende dobbeltkoblet liste
//!
//! På en påtrængende dobbeltkoblet liste tildeler samlingen faktisk ikke hukommelsen til selve elementerne.
//! Tildeling styres af klienterne, og elementer kan leve på en stakramme, der lever kortere end samlingen gør.
//!
//! For at få dette til at fungere har hvert element peger på sin forgænger og efterfølger på listen.Elementer kan kun tilføjes, når de er fastgjort, fordi flytning af elementerne rundt vil ugyldiggøre markørerne.Desuden vil [`Drop`]-implementeringen af et linket listeelement lappe henvisningerne til sin forgænger og efterfølger for at fjerne sig selv fra listen.
//!
//! Afgørende er, at vi skal være i stand til at stole på, at [`drop`] kaldes.Hvis et element kunne omfordeles eller på anden måde ugyldiggøres uden at kalde [`drop`], ville markørerne ind i det fra dets tilstødende elementer blive ugyldige, hvilket ville bryde datastrukturen.
//!
//! Derfor kommer fastgørelse også med en [`drop`]-relateret garanti.
//!
//! # `Drop` guarantee
//!
//! Formålet med fastgørelse er at kunne stole på placeringen af nogle data i hukommelsen.
//! For at få dette til at fungere er ikke kun flytning af data begrænset;deallokering, genbrug eller på anden måde ugyldiggørelse af den hukommelse, der bruges til lagring af data, er også begrænset.
//! Konkret, for fastgjorte data skal du bevare den uforanderlige, at *hukommelsen ikke bliver ugyldiggjort eller genopbygget fra det øjeblik, den bliver fastgjort, indtil [`drop`] kaldes*.Kun når [`drop`] vender tilbage eller panics, kan hukommelsen muligvis genbruges.
//!
//! Hukommelse kan være "invalidated" ved deallocation, men også ved at erstatte en [`Some(v)`] med [`None`] eller kalde [`Vec::set_len`] til "kill" nogle elementer fra en vector.Det kan genbruges ved at bruge [`ptr::write`] til at overskrive det uden først at ringe til destruktoren.Intet af dette er tilladt for fastgjorte data uden at ringe til [`drop`].
//!
//! Dette er nøjagtigt den slags garanti for, at den påtrængende linkede liste fra det foregående afsnit skal fungere korrekt.
//!
//! Bemærk, at denne garanti *ikke* betyder, at hukommelsen ikke lækker!Det er stadig helt okay ikke nogensinde at kalde [`drop`] på et fastgjort element (f.eks. Kan du stadig ringe til [`mem::forget`] på en [`Pin`]`<`[`Box`] `<T>>`).I eksemplet med den dobbeltkoblede liste forbliver elementet bare på listen.Du må dog ikke frigøre eller genbruge lageret *uden at ringe til [`drop`]*.
//!
//! # `Drop` implementation
//!
//! Hvis din type bruger fastgørelse (som de to eksempler ovenfor), skal du være forsigtig, når du implementerer [`Drop`].[`drop`]-funktionen tager `&mut self`, men dette kaldes *selvom din type tidligere var fastgjort*!Det er som om compileren automatisk kaldes [`Pin::get_unchecked_mut`].
//!
//! Dette kan aldrig forårsage et problem i sikker kode, fordi implementering af en type, der er afhængig af fastgørelse, kræver usikker kode, men vær opmærksom på, at beslutningen om at gøre brug af fastgørelse i din type (for eksempel ved at implementere en eller anden handling på [`Pin`]`<&Selv>`eller [`Pin`] `<&mut Self>`) har også konsekvenser for din [`Drop`]-implementering: hvis et element af din type kunne have været fastgjort, skal du behandle [`Drop`] som implicit at tage [`Pin`]`<&mut Selv>`.
//!
//!
//! For eksempel kan du implementere `Drop` som følger:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` er okay, fordi vi ved, at denne værdi aldrig bruges igen efter at være faldet.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Faktisk drop code går her.
//!         }
//!     }
//! }
//! ```
//!
//! Funktionen `inner_drop` har den type, som [`drop`]*skal* have, så dette sørger for, at du ikke ved et uheld bruger `self`/`this` på en måde, der er i konflikt med fastgørelse.
//!
//! Desuden, hvis din type er `#[repr(packed)]`, vil compileren automatisk flytte felter rundt for at være i stand til at droppe dem.Det kan endda gøre det for felter, der tilfældigvis er tilstrækkeligt justeret.Som en konsekvens kan du ikke bruge fastgørelse med en `#[repr(packed)]`-type.
//!
//! # Fremskrivninger og strukturel fastgørelse
//!
//! Når man arbejder med fastgjorte strukturer, opstår spørgsmålet, hvordan man kan få adgang til felterne i denne struktur i en metode, der kun tager [`Pin`]`<&mut Struct>`.
//! Den sædvanlige tilgang er at skrive hjælpemetoder (såkaldte *projektioner*), der forvandler [`Pin`]`<&mut Struct>`til en reference til feltet, men hvilken type skal denne reference have?Er det [`Pin`]`<&mut Field>`eller `&mut Field`?
//! Det samme spørgsmål opstår med felterne i en `enum`, og også når man overvejer container/wrapper-typer som [`Vec<T>`], [`Box<T>`] eller [`RefCell<T>`].
//! (Dette spørgsmål gælder for både mutable og delte referencer, vi bruger bare det mere almindelige tilfælde af mutable referencer her til illustration.)
//!
//! Det viser sig, at det faktisk er op til forfatteren af datastrukturen at afgøre, om den fastgjorte projektion for et bestemt felt forvandler [`Pin`]`<&mut Struct>`til [`Pin`] `<&mut Field>` eller `&mut Field`.Der er dog nogle begrænsninger, og den vigtigste begrænsning er *konsistens*:
//! hvert felt kan *enten* projiceres til en fastgjort reference,*eller* få fjernet fastgørelse som en del af projektionen.
//! Hvis begge gøres for det samme felt, vil det sandsynligvis være usundt!
//!
//! Som forfatter af en datastruktur kan du beslutte for hvert felt, om du fastgør "propagates" til dette felt eller ej.
//! Fastgørelse, der formerer sig, kaldes også "structural", fordi det følger strukturens struktur.
//! I de følgende underafsnit beskriver vi de overvejelser, der skal tages for begge valg.
//!
//! ## Fastgørelse *er ikke* strukturel for `field`
//!
//! Det kan virke kontraintuitivt, at feltet for en fastgjort struktur muligvis ikke er fastgjort, men det er faktisk det nemmeste valg: hvis en [`Pin`]`<&mut Field>`aldrig oprettes, kan intet gå galt!Så hvis du beslutter, at et felt ikke har strukturel fastgørelse, skal du kun sikre, at du aldrig opretter en fastgjort henvisning til dette felt.
//!
//! Felter uden strukturel fastgørelse kan have en projektionsmetode, der forvandler [`Pin`]`<&mut Struct>`til `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Dette er okay, fordi `field` aldrig betragtes som fastgjort.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Du kan også `impl Unpin for Struct`*, selvom* typen `field` ikke er [`Unpin`].Hvad den type synes om fastgørelse er ikke relevant, når der aldrig oprettes nogen [`Pin`]`<&mut Field>`.
//!
//! ## Fastgørelse *er* strukturel for `field`
//!
//! Den anden mulighed er at beslutte, at fastgørelse er "structural" for `field`, hvilket betyder, at hvis strukturen er fastgjort, så er feltet også.
//!
//! Dette gør det muligt at skrive en projektion, der skaber et [`Pin`]`<&mut-felt>`, og således vidne til, at feltet er fastgjort:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Dette er okay, fordi `field` er fastgjort, når `self` er.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Imidlertid kommer strukturel fastgørelse med et par ekstra krav:
//!
//! 1. Strukturen må kun være [`Unpin`], hvis alle strukturfelterne er [`Unpin`].Dette er standard, men [`Unpin`] er en sikker trait, så som forfatteren af strukturen er det dit ansvar *ikke* at tilføje noget som `impl<T> Unpin for Struct<T>`.
//! (Bemærk, at tilføjelse af en projiceringshandling kræver usikker kode, så det faktum, at [`Unpin`] er en sikker trait, bryder ikke princippet om, at du kun skal bekymre dig om noget af dette, hvis du bruger 'usikker'.)
//! 2. Destruktøren af strukturen må ikke flytte strukturelle felter ud af sit argument.Dette er det nøjagtige punkt, der blev rejst i [previous section][drop-impl]: `drop` tager `&mut self`, men strukturen (og dermed dens felter) var muligvis blevet fastgjort før.
//!     Du skal garantere, at du ikke flytter et felt inden for din [`Drop`]-implementering.
//!     Især som tidligere forklaret betyder det, at din struct *ikke* skal være `#[repr(packed)]`.
//!     Se dette afsnit for, hvordan du skriver [`drop`] på en måde, som compileren kan hjælpe dig med ikke ved et uheld at bryde fastgørelse.
//! 3. Du skal sikre dig, at du opretholder [`Drop` guarantee][drop-guarantee]:
//!     når din struktur er fastgjort, overskrives eller deallokeres ikke hukommelsen, der indeholder indholdet, uden at kalde indholdets destruktører.
//!     Dette kan være vanskeligt, som vidne af [`VecDeque<T>`]: Destruktoren af [`VecDeque<T>`] kan undlade at kalde [`drop`] på alle elementer, hvis en af destruktørerne panics.Dette overtræder [`Drop`]-garantien, fordi det kan føre til, at elementer omfordeles, uden at deres destruktør kaldes.([`VecDeque<T>`] har ingen fremspringende fremspring, så dette forårsager ikke usundhed.)
//! 4. Du må ikke tilbyde andre handlinger, der kan føre til, at data flyttes ud af de strukturelle felter, når din type er fastgjort.For eksempel, hvis strukturen indeholder en [`Option<T>`], og der er en 'tag'-lignende operation med typen `fn(Pin<&mut Struct<T>>) -> Option<T>`, kan denne operation bruges til at flytte en `T` ud af en fastgjort `Struct<T>`-hvilket betyder, at fastgørelse ikke kan være strukturel for det felt, der holder dette data.
//!
//!     For et mere komplekst eksempel på at flytte data ud af en fastgjort type, forestil dig om [`RefCell<T>`] havde en metode `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Så kunne vi gøre følgende:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Dette er katastrofalt, det betyder, at vi først kan fastgøre indholdet af [`RefCell<T>`] (ved hjælp af `RefCell::get_pin_mut`) og derefter flytte det indhold ved hjælp af den ændrede reference, vi fik senere.
//!
//! ## Examples
//!
//! For en type som [`Vec<T>`] giver begge muligheder (strukturel fastgørelse eller ej) mening.
//! En [`Vec<T>`] med strukturel fastgørelse kunne have `get_pin`/`get_pin_mut`-metoder til at få fastgjorte referencer til elementer.Det kunne dog *ikke* tillade at kalde [`pop`][Vec::pop] på en fastgjort [`Vec<T>`], fordi det ville flytte (strukturelt fastgjort) indholdet!Det kunne heller ikke tillade [`push`][Vec::push], som muligvis omfordeles og dermed også flytter indholdet.
//!
//! En [`Vec<T>`] uden strukturel fastgørelse kunne `impl<T> Unpin for Vec<T>`, fordi indholdet aldrig fastgøres, og selve [`Vec<T>`] er fint med at blive flyttet også.
//! På det tidspunkt har fastgørelse slet ikke nogen effekt på vector.
//!
//! I standardbiblioteket har markørtyper generelt ikke strukturel fastgørelse, og derfor tilbyder de ikke fastgørelsesfremskrivninger.Dette er grunden til, at `Box<T>: Unpin` gælder for alle `T`.
//! Det er fornuftigt at gøre dette for markørtyper, fordi flytning af `Box<T>` faktisk ikke flytter `T`: [`Box<T>`] kan være frit bevægelig (også kaldet `Unpin`), selvom `T` ikke er det.Faktisk, selv [`Pin`]`<`[`Box`] `<T>>`og [`Pin`] `<&mut T>` er altid [`Unpin`] selv af samme grund: deres indhold (`T`) er fastgjort, men selve markørerne kan flyttes uden at flytte de fastgjorte data.
//! For både [`Box<T>`] og [`Pin`]`<`[`Box`] `<T>>`, om indholdet er fastgjort, er helt uafhængigt af, om markøren er fastgjort, hvilket betyder at fastgørelse er *ikke* strukturel.
//!
//! Når du implementerer en [`Future`]-kombinator, har du normalt brug for strukturel fastgørelse til de indlejrede futures, da du skal få fastgjorte referencer til dem for at ringe til [`poll`].
//! Men hvis din kombinator indeholder andre data, der ikke behøver at blive fastgjort, kan du gøre disse felter ikke strukturelle og dermed frit få adgang til dem med en ændret reference, selv når du bare har [`Pin`]`<&mut Self>`(sådan som i din egen [`poll`]-implementering).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// En fastgjort markør.
///
/// Dette er en indpakning omkring en slags markør, der gør markøren "pin" til sin værdi på plads, hvilket forhindrer, at den værdi, der henvises til af den pågældende markør, flyttes, medmindre den implementerer [`Unpin`].
///
///
/// *Se [`pin` module]-dokumentationen for en forklaring på fastgørelse.*
///
/// [`pin` module]: self
///
// Note: `Clone`-afledningen nedenfor forårsager usundhed, da det er muligt at implementere
// `Clone` til ændrede referencer.
// Se <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> for flere detaljer.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Følgende implementeringer udledes ikke for at undgå sundhedsproblemer.
// `&self.pointer` bør ikke være tilgængelig for upålidelige trait-implementeringer.
//
// Se <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> for flere detaljer.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Konstruer en ny `Pin<P>` omkring en markør til nogle data af en type, der implementerer [`Unpin`].
    ///
    /// I modsætning til `Pin::new_unchecked` er denne metode sikker, fordi markøren `P` henviser til en [`Unpin`]-type, som annullerer fastgørelsesgarantierne.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // SIKKERHED: den værdi, der peges på, er `Unpin`, og har derfor ingen krav
        // omkring fastgørelse.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Udpakker denne `Pin<P>`, der returnerer den underliggende markør.
    ///
    /// Dette kræver, at dataene i denne `Pin` er [`Unpin`], så vi kan ignorere de fastgørende invarianter, når de pakkes ud.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Konstruer en ny `Pin<P>` omkring en henvisning til nogle data af en type, der måske eller måske ikke implementerer `Unpin`.
    ///
    /// Hvis `pointer` derferences til en `Unpin`-type, skal `Pin::new` bruges i stedet.
    ///
    /// # Safety
    ///
    /// Denne konstruktør er usikker, fordi vi ikke kan garantere, at de data, der er peget på af `pointer`, er fastgjort, hvilket betyder, at dataene ikke flyttes eller deres lagring ugyldiggøres, før de bliver droppet.
    /// Hvis den konstruerede `Pin<P>` ikke garanterer, at dataene, som `P` peger på, er fastgjort, er det en overtrædelse af API-kontrakten og kan føre til udefineret adfærd i senere (safe)-operationer.
    ///
    /// Ved at bruge denne metode laver du en promise om `P::Deref`-og `P::DerefMut`-implementeringerne, hvis de findes.
    /// Vigtigst er det, at de ikke må flytte ud af deres `self`-argumenter: `Pin::as_mut` og `Pin::as_ref` kalder `DerefMut::deref_mut` og `Deref::deref`*på den fastgjorte markør* og forventer, at disse metoder opretholder de fastgørende invarianter.
    /// Desuden ved at kalde denne metode promise, at referencen `P` dereferences til ikke flyttes ud af igen;især skal det ikke være muligt at få en `&mut P::Target` og derefter bevæge sig ud af denne reference (ved hjælp af for eksempel [`mem::swap`]).
    ///
    ///
    /// For eksempel er det ikke sikkert at kalde `Pin::new_unchecked` på en `&'a mut T`, for mens du er i stand til at fastgøre den i den givne levetid `'a`, har du ingen kontrol over, om den holdes fastgjort, når `'a` slutter:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Dette skulle betyde, at pointee `a` aldrig kan bevæge sig igen.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Adressen på `a` skiftede til `b`s stakplads, så `a` blev flyttet, selvom vi tidligere har fastgjort det!Vi har overtrådt den fastgørende API-kontrakt.
    /////
    /// }
    /// ```
    ///
    /// Når en værdi er fastgjort, skal den forblive fastgjort for evigt (medmindre dens type implementerer `Unpin`).
    ///
    /// Tilsvarende er det ikke sikkert at ringe til `Pin::new_unchecked` på en `Rc<T>`, fordi der kan være aliasser til de samme data, der ikke er underlagt fastgørelsesbegrænsningerne:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Dette skulle betyde, at pointeren aldrig kan bevæge sig igen.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Nu, hvis `x` var den eneste reference, har vi en ændret henvisning til data, som vi fastgjorde ovenfor, som vi kunne bruge til at flytte den som vi har set i det foregående eksempel.
    ///     // Vi har overtrådt den fastgørende API-kontrakt.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Får en fastgjort delt reference fra denne fastgjorte markør.
    ///
    /// Dette er en generisk metode til at gå fra `&Pin<Pointer<T>>` til `Pin<&T>`.
    /// Det er sikkert, fordi pointeren som en del af kontrakten med `Pin::new_unchecked` ikke kan bevæge sig, efter at `Pin<Pointer<T>>` blev oprettet.
    ///
    /// "Malicious" implementeringer af `Pointer::Deref` er ligeledes udelukket af `Pin::new_unchecked`-kontrakten.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // SIKKERHED: se dokumentation om denne funktion
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Udpakker denne `Pin<P>`, der returnerer den underliggende markør.
    ///
    /// # Safety
    ///
    /// Denne funktion er usikker.Du skal garantere, at du fortsætter med at behandle markøren `P` som fastgjort, når du har kaldt denne funktion, så invarianterne på `Pin`-typen kan opretholdes.
    /// Hvis koden ved hjælp af den resulterende `P` ikke fortsætter med at opretholde de fastgørende invarianter, er det en krænkelse af API-kontrakten og kan føre til udefineret adfærd i senere (safe)-operationer.
    ///
    ///
    /// Hvis de underliggende data er [`Unpin`], bør [`Pin::into_inner`] bruges i stedet.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Får en fastgjort mutabel reference fra denne fastgjorte markør.
    ///
    /// Dette er en generisk metode til at gå fra `&mut Pin<Pointer<T>>` til `Pin<&mut T>`.
    /// Det er sikkert, fordi pointeren som en del af kontrakten med `Pin::new_unchecked` ikke kan bevæge sig, efter at `Pin<Pointer<T>>` blev oprettet.
    ///
    /// "Malicious" implementeringer af `Pointer::DerefMut` er ligeledes udelukket af `Pin::new_unchecked`-kontrakten.
    ///
    /// Denne metode er nyttig, når du foretager flere opkald til funktioner, der bruger den fastgjorte type.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // gør noget
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` bruger `self`, så genlån `Pin<&mut Self>` via `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // SIKKERHED: se dokumentation om denne funktion
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Tildeler en ny værdi til hukommelsen bag den fastgjorte reference.
    ///
    /// Dette overskriver fastgjorte data, men det er okay: dets destruktør køres, før de overskrives, så ingen fastgørelsesgaranti overtrædes.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Konstruerer en ny pin ved at kortlægge den indvendige værdi.
    ///
    /// For eksempel, hvis du ønskede at få en `Pin` af et felt med noget, kunne du bruge dette til at få adgang til dette felt i en linje kode.
    /// Der er dog flere gotchas med disse "pinning projections";
    /// se [`pin` module]-dokumentationen for yderligere detaljer om dette emne.
    ///
    /// # Safety
    ///
    /// Denne funktion er usikker.
    /// Du skal garantere, at de data, du returnerer, ikke bevæger sig, så længe argumentværdien ikke bevæger sig (for eksempel fordi det er et af felterne i den værdi), og også at du ikke bevæger dig ud af det argument, du modtager til den indvendige funktion.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // SIKKERHED: sikkerhedskontrakten for `new_unchecked` skal være
        // opretholdt af den, der ringer op.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Får en delt reference ud af en nål.
    ///
    /// Dette er sikkert, fordi det ikke er muligt at flytte ud af en delt reference.
    /// Det kan virke som om der er et problem her med interiørmutabilitet: faktisk er det * muligt at flytte en `T` ud af en `&RefCell<T>`.
    /// Dette er dog ikke et problem, så længe der ikke også findes en `Pin<&T>`, der peger på de samme data, og `RefCell<T>` lader dig ikke oprette en fastgjort henvisning til dens indhold.
    ///
    /// Se diskussionen om ["pinning projections"] for yderligere detaljer.
    ///
    /// Note: `Pin` implementerer også `Deref` til målet, som kan bruges til at få adgang til den indre værdi.
    /// `Deref` giver dog kun en reference, der lever så længe som lånet til `Pin`, ikke levetiden for selve `Pin`.
    /// Denne metode gør det muligt at omdanne `Pin` til en reference med samme levetid som den originale `Pin`.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Konverterer denne `Pin<&mut T>` til en `Pin<&T>` med samme levetid.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Får en ændret henvisning til dataene inde i denne `Pin`.
    ///
    /// Dette kræver, at dataene i denne `Pin` er `Unpin`.
    ///
    /// Note: `Pin` implementerer også `DerefMut` til dataene, som kan bruges til at få adgang til den indre værdi.
    /// `DerefMut` giver dog kun en reference, der lever så længe som lånet til `Pin`, ikke levetiden for selve `Pin`.
    ///
    /// Denne metode gør det muligt at omdanne `Pin` til en reference med samme levetid som den originale `Pin`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Får en ændret henvisning til dataene inde i denne `Pin`.
    ///
    /// # Safety
    ///
    /// Denne funktion er usikker.
    /// Du skal garantere, at du aldrig flytter dataene ud af den ændrede reference, du modtager, når du kalder denne funktion, så invarianterne på `Pin`-typen kan opretholdes.
    ///
    ///
    /// Hvis de underliggende data er `Unpin`, bør `Pin::get_mut` bruges i stedet.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Konstruer en ny pin ved at kortlægge den indvendige værdi.
    ///
    /// For eksempel, hvis du ønskede at få en `Pin` af et felt med noget, kunne du bruge dette til at få adgang til dette felt i en linje kode.
    /// Der er dog flere gotchas med disse "pinning projections";
    /// se [`pin` module]-dokumentationen for yderligere detaljer om dette emne.
    ///
    /// # Safety
    ///
    /// Denne funktion er usikker.
    /// Du skal garantere, at de data, du returnerer, ikke bevæger sig, så længe argumentværdien ikke bevæger sig (for eksempel fordi det er et af felterne i den værdi), og også at du ikke bevæger dig ud af det argument, du modtager til den indvendige funktion.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // SIKKERHED: den, der ringer op, er ansvarlig for ikke at flytte
        // værdi ud af denne reference.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // SIKKERHED: da værdien af `this` garanteret ikke er
        // er flyttet ud, er dette opkald til `new_unchecked` sikkert.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Få en fastgjort reference fra en statisk reference.
    ///
    /// Dette er sikkert, fordi `T` lånes i `'static`-levetiden, som aldrig slutter.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // SIKKERHED: Den 'statiske låntagning garanterer, at dataene ikke bliver
        // moved/invalidated indtil det bliver droppet (hvilket aldrig er).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Få en fastgjort mutabel reference fra en statisk mutabel reference.
    ///
    /// Dette er sikkert, fordi `T` lånes i `'static`-levetiden, som aldrig slutter.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // SIKKERHED: Den 'statiske låntagning garanterer, at dataene ikke bliver
        // moved/invalidated indtil det bliver droppet (hvilket aldrig er).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: dette betyder, at enhver impl. af `CoerceUnsized`, der tillader tvang fra
// en type, der implementerer `Deref<Target=impl !Unpin>` til en type, der impliserer `Deref<Target=Unpin>`, er usund.
// Enhver sådan impl. Ville sandsynligvis være usund af andre grunde, så vi skal bare passe på ikke at lade sådanne impls lande i std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}