/// Bruges til indekseringsoperationer (`container[index]`) i uforanderlige sammenhænge.
///
/// `container[index]` er faktisk syntaktisk sukker til `*container.index(index)`, men kun når det bruges som en uforanderlig værdi.
/// Hvis der ønskes en mutabel værdi, bruges [`IndexMut`] i stedet.
/// Dette tillader pæne ting som `let value = v[index]`, hvis typen `value` implementerer [`Copy`].
///
/// # Examples
///
/// Følgende eksempel implementerer `Index` på en skrivebeskyttet `NucleotideCount`-container, der gør det muligt at hente individuelle tællinger med indekssyntaks.
///
///
/// ```
/// use std::ops::Index;
///
/// enum Nucleotide {
///     A,
///     C,
///     G,
///     T,
/// }
///
/// struct NucleotideCount {
///     a: usize,
///     c: usize,
///     g: usize,
///     t: usize,
/// }
///
/// impl Index<Nucleotide> for NucleotideCount {
///     type Output = usize;
///
///     fn index(&self, nucleotide: Nucleotide) -> &Self::Output {
///         match nucleotide {
///             Nucleotide::A => &self.a,
///             Nucleotide::C => &self.c,
///             Nucleotide::G => &self.g,
///             Nucleotide::T => &self.t,
///         }
///     }
/// }
///
/// let nucleotide_count = NucleotideCount {a: 14, c: 9, g: 10, t: 12};
/// assert_eq!(nucleotide_count[Nucleotide::A], 14);
/// assert_eq!(nucleotide_count[Nucleotide::C], 9);
/// assert_eq!(nucleotide_count[Nucleotide::G], 10);
/// assert_eq!(nucleotide_count[Nucleotide::T], 12);
/// ```
///
#[lang = "index"]
#[rustc_on_unimplemented(
    message = "the type `{Self}` cannot be indexed by `{Idx}`",
    label = "`{Self}` cannot be indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "]")]
#[doc(alias = "[")]
#[doc(alias = "[]")]
pub trait Index<Idx: ?Sized> {
    /// Den returnerede type efter indeksering.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Output: ?Sized;

    /// Udfører indeksering af (`container[index]`)-operationen.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index(&self, index: Idx) -> &Self::Output;
}

/// Bruges til indekseringsoperationer (`container[index]`) i mutable sammenhænge.
///
/// `container[index]` er faktisk syntaktisk sukker til `*container.index_mut(index)`, men kun når det bruges som en ændret værdi.
/// Hvis der kræves en uforanderlig værdi, bruges [`Index`] trait i stedet.
/// Dette giver gode ting som `v[index] = value`.
///
/// # Examples
///
/// En meget enkel implementering af en `Balance`-struktur, der har to sider, hvor hver kan indekseres mutabelt og uforanderligt.
///
/// ```
/// use std::ops::{Index, IndexMut};
///
/// #[derive(Debug)]
/// enum Side {
///     Left,
///     Right,
/// }
///
/// #[derive(Debug, PartialEq)]
/// enum Weight {
///     Kilogram(f32),
///     Pound(f32),
/// }
///
/// struct Balance {
///     pub left: Weight,
///     pub right: Weight,
/// }
///
/// impl Index<Side> for Balance {
///     type Output = Weight;
///
///     fn index(&self, index: Side) -> &Self::Output {
///         println!("Accessing {:?}-side of balance immutably", index);
///         match index {
///             Side::Left => &self.left,
///             Side::Right => &self.right,
///         }
///     }
/// }
///
/// impl IndexMut<Side> for Balance {
///     fn index_mut(&mut self, index: Side) -> &mut Self::Output {
///         println!("Accessing {:?}-side of balance mutably", index);
///         match index {
///             Side::Left => &mut self.left,
///             Side::Right => &mut self.right,
///         }
///     }
/// }
///
/// let mut balance = Balance {
///     right: Weight::Kilogram(2.5),
///     left: Weight::Pound(1.5),
/// };
///
/// // I dette tilfælde er `balance[Side::Right]` sukker for `*balance.index(Side::Right)`, da vi kun* læser * `balance[Side::Right]` og ikke skriver det.
/////
/////
/// assert_eq!(balance[Side::Right], Weight::Kilogram(2.5));
///
/// // I dette tilfælde er `balance[Side::Left]` imidlertid sukker for `*balance.index_mut(Side::Left)`, da vi skriver `balance[Side::Left]`.
/////
/////
/// balance[Side::Left] = Weight::Kilogram(3.0);
/// ```
///
///
#[lang = "index_mut"]
#[rustc_on_unimplemented(
    on(
        _Self = "&str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "str",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    on(
        _Self = "std::string::String",
        note = "you can use `.chars().nth()` or `.bytes().nth()`
see chapter in The Book <https://doc.rust-lang.org/book/ch08-02-strings.html#indexing-into-strings>"
    ),
    message = "the type `{Self}` cannot be mutably indexed by `{Idx}`",
    label = "`{Self}` cannot be mutably indexed by `{Idx}`"
)]
#[stable(feature = "rust1", since = "1.0.0")]
#[doc(alias = "[")]
#[doc(alias = "]")]
#[doc(alias = "[]")]
pub trait IndexMut<Idx: ?Sized>: Index<Idx> {
    /// Udfører den mutable indekserings (`container[index]`)-handling.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[track_caller]
    fn index_mut(&mut self, index: Idx) -> &mut Self::Output;
}