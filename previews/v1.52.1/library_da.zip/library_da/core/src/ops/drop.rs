/// Brugerdefineret kode inden for destruktoren.
///
/// Når en værdi ikke længere er nødvendig, kører Rust en "destructor" på den værdi.
/// Den mest almindelige måde, hvorpå en værdi ikke længere er nødvendig, er når den går uden for anvendelsesområdet.Destruktører kan stadig køre under andre omstændigheder, men vi vil fokusere på mulighederne for eksemplerne her.
/// For at lære om nogle af disse andre sager, se [the reference] sektionen om destruktører.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// Denne destruktor består af to komponenter:
/// - Et opkald til `Drop::drop` for den værdi, hvis denne specielle `Drop` trait er implementeret for sin type.
/// - Den automatisk genererede "drop glue", der rekursivt kalder destruktørerne for alle felter af denne værdi.
///
/// Da Rust automatisk kalder destruktørerne for alle indeholdte felter, behøver du i de fleste tilfælde ikke at implementere `Drop`.
/// Men der er nogle tilfælde, hvor det er nyttigt, for eksempel for typer, der administrerer en ressource direkte.
/// Denne ressource kan være hukommelse, det kan være en filbeskrivelse, det kan være et netværksstik.
/// Når en værdi af denne type ikke længere skal bruges, skal den "clean up" sin ressource ved at frigøre hukommelsen eller lukke filen eller stikket.
/// Dette er en destruktørs job, og derfor `Drop::drop` s job.
///
/// ## Examples
///
/// For at se destruktører i aktion, lad os se på følgende program:
///
/// ```rust
/// struct HasDrop;
///
/// impl Drop for HasDrop {
///     fn drop(&mut self) {
///         println!("Dropping HasDrop!");
///     }
/// }
///
/// struct HasTwoDrops {
///     one: HasDrop,
///     two: HasDrop,
/// }
///
/// impl Drop for HasTwoDrops {
///     fn drop(&mut self) {
///         println!("Dropping HasTwoDrops!");
///     }
/// }
///
/// fn main() {
///     let _x = HasTwoDrops { one: HasDrop, two: HasDrop };
///     println!("Running!");
/// }
/// ```
///
/// Rust vil først kalde `Drop::drop` for `_x` og derefter for både `_x.one` og `_x.two`, hvilket betyder at kørsel af dette vil udskrive
///
/// ```text
/// Running!
/// Dropping HasTwoDrops!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// Selvom vi fjerner implementeringen af `Drop` til `HasTwoDrop`, kaldes destruktører af dens felter stadig.
/// Dette ville resultere i
///
/// ```test
/// Running!
/// Dropping HasDrop!
/// Dropping HasDrop!
/// ```
///
/// ## Du kan ikke ringe til `Drop::drop` selv
///
/// Da `Drop::drop` bruges til at rydde op i en værdi, kan det være farligt at bruge denne værdi, efter at metoden er blevet kaldt.
/// Da `Drop::drop` ikke overtager sin input, forhindrer Rust misbrug ved ikke at tillade dig at ringe til `Drop::drop` direkte.
///
/// Med andre ord, hvis du forsøgte at eksplicit kalde `Drop::drop` i ovenstående eksempel, ville du få en compiler-fejl.
///
/// Hvis du eksplicit vil kalde destruktoren for en værdi, kan [`mem::drop`] bruges i stedet.
///
/// [`mem::drop`]: drop
///
/// ## Drop ordre
///
/// Hvilken af vores to `HasDrop` falder dog først?For strukturer er det den samme rækkefølge, som de er erklæret: først `one`, derefter `two`.
/// Hvis du gerne vil prøve dette selv, kan du ændre `HasDrop` ovenfor for at indeholde nogle data, som et heltal, og derefter bruge det i `println!` inde i `Drop`.
/// Denne adfærd er garanteret af sproget.
///
/// I modsætning til structs falder lokale variabler i omvendt rækkefølge:
///
/// ```rust
/// struct Foo;
///
/// impl Drop for Foo {
///     fn drop(&mut self) {
///         println!("Dropping Foo!")
///     }
/// }
///
/// struct Bar;
///
/// impl Drop for Bar {
///     fn drop(&mut self) {
///         println!("Dropping Bar!")
///     }
/// }
///
/// fn main() {
///     let _foo = Foo;
///     let _bar = Bar;
/// }
/// ```
///
/// Dette udskrives
///
/// ```text
/// Dropping Bar!
/// Dropping Foo!
/// ```
///
/// Se [the reference] for de fulde regler.
///
/// [the reference]: https://doc.rust-lang.org/reference/destructors.html
///
/// ## `Copy` og `Drop` er eksklusive
///
/// Du kan ikke implementere både [`Copy`] og `Drop` på samme type.Typer, der er `Copy`, bliver implicit duplikeret af compileren, hvilket gør det meget svært at forudsige, hvornår og hvor ofte destruktører vil blive udført.
///
/// Som sådan kan disse typer ikke have destruktorer.
///
///
///
///
///
///
///
///
///
///
#[lang = "drop"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Drop {
    /// Udfører destruktoren for denne type.
    ///
    /// Denne metode kaldes implicit, når værdien går uden for omfanget, og kan ikke kaldes eksplicit (dette er kompileringsfejl [E0040]).
    /// [`mem::drop`]-funktionen i prelude kan dog bruges til at kalde argumentets `Drop`-implementering.
    ///
    /// Når denne metode er blevet kaldt, er `self` endnu ikke blevet omlokaliseret.
    /// Det sker kun, når metoden er slut.
    /// Hvis dette ikke var tilfældet, ville `self` være en dinglende reference.
    ///
    /// # Panics
    ///
    /// I betragtning af at en [`panic!`] vil kalde `drop`, når den afvikles, vil enhver [`panic!`] i en `drop`-implementering sandsynligvis afbrydes.
    ///
    /// Bemærk, at selvom dette panics, anses værdien for at være faldet;
    /// du må ikke få `drop` til at blive kaldt igen.
    /// Dette håndteres normalt automatisk af compileren, men når du bruger usikker kode, kan det undertiden forekomme utilsigtet, især når du bruger [`ptr::drop_in_place`].
    ///
    ///
    /// [E0040]: ../../error-index.html#E0040 [`panic!`]: crate::panic!
    /// [`mem::drop`]: drop
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn drop(&mut self);
}