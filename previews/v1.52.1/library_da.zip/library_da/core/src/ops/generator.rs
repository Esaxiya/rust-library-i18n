use crate::marker::Unpin;
use crate::pin::Pin;

/// Resultatet af en genoptagelse af en generator.
///
/// Dette enum returneres fra `Generator::resume`-metoden og indikerer de mulige returværdier for en generator.
/// I øjeblikket svarer dette til enten et ophængningspunkt (`Yielded`) eller et slutpunkt (`Complete`).
///
#[derive(Clone, Copy, PartialEq, PartialOrd, Eq, Ord, Debug, Hash)]
#[lang = "generator_state"]
#[unstable(feature = "generator_trait", issue = "43122")]
pub enum GeneratorState<Y, R> {
    /// Generatoren suspenderet med en værdi.
    ///
    /// Denne tilstand indikerer, at en generator er suspenderet og typisk svarer til en `yield`-sætning.
    /// Værdien i denne variant svarer til det udtryk, der sendes til `yield`, og giver generatorer mulighed for at give en værdi hver gang de giver.
    ///
    ///
    Yielded(Y),

    /// Generatoren afsluttet med en returværdi.
    ///
    /// Denne tilstand indikerer, at en generator er færdig med udførelsen med den angivne værdi.
    /// Når en generator har returneret `Complete`, betragtes det som en programmeringsfejl at ringe til `resume` igen.
    ///
    Complete(R),
}

/// trait implementeret af indbyggede generatorer.
///
/// Generatorer, også ofte omtalt som coroutines, er i øjeblikket et eksperimentelt sprogfunktion i Rust.
/// Tilføjet i [RFC 2033]-generatorer er i øjeblikket beregnet til primært at tilvejebringe en byggesten til async/await-syntaks, men vil sandsynligvis også omfatte en ergonomisk definition af iteratorer og andre primitiver.
///
///
/// Syntaksen og semantikken for generatorer er ustabil og vil kræve en yderligere RFC for stabilisering.På dette tidspunkt er syntaksen dog lukningslignende:
///
/// ```rust
/// #![feature(generators, generator_trait)]
///
/// use std::ops::{Generator, GeneratorState};
/// use std::pin::Pin;
///
/// fn main() {
///     let mut generator = || {
///         yield 1;
///         return "foo"
///     };
///
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Yielded(1) => {}
///         _ => panic!("unexpected return from resume"),
///     }
///     match Pin::new(&mut generator).resume(()) {
///         GeneratorState::Complete("foo") => {}
///         _ => panic!("unexpected return from resume"),
///     }
/// }
/// ```
///
/// Mere dokumentation af generatorer kan findes i den ustabile bog.
///
/// [RFC 2033]: https://github.com/rust-lang/rfcs/pull/2033
///
///
///
///
#[lang = "generator"]
#[unstable(feature = "generator_trait", issue = "43122")]
#[fundamental]
pub trait Generator<R = ()> {
    /// Den type værdi, som denne generator giver.
    ///
    /// Denne tilknyttede type svarer til `yield`-udtrykket og de værdier, der må returneres, hver gang en generator giver.
    ///
    /// For eksempel vil en iterator-som-en-generator sandsynligvis have denne type som `T`, den type der gentages.
    ///
    type Yield;

    /// Den type værdi, som denne generator returnerer.
    ///
    /// Dette svarer til typen returneret fra en generator enten med en `return`-sætning eller implicit som det sidste udtryk for en generator bogstaveligt.
    /// For eksempel vil futures bruge dette som `Result<T, E>`, da det repræsenterer en afsluttet future.
    ///
    ///
    type Return;

    /// Genoptager udførelsen af denne generator.
    ///
    /// Denne funktion genoptager udførelsen af generatoren eller starter udførelsen, hvis den ikke allerede har gjort det.
    /// Dette opkald vender tilbage til generatorens sidste ophængningspunkt og genoptager udførelsen fra den nyeste `yield`.
    /// Generatoren fortsætter med at udføre, indtil den enten giver eller returnerer, på hvilket tidspunkt denne funktion vender tilbage.
    ///
    /// # Returneringsværdi
    ///
    /// `GeneratorState`-enum, der returneres fra denne funktion, angiver, i hvilken tilstand generatoren er i ved returnering.
    /// Hvis `Yielded`-varianten returneres, har generatoren nået et ophængningspunkt, og der er givet en værdi.
    /// Generatorer i denne tilstand er tilgængelige for genoptagelse på et senere tidspunkt.
    ///
    /// Hvis `Complete` returneres, er generatoren helt færdig med den angivne værdi.Det er ugyldigt, at generatoren genoptages igen.
    ///
    /// # Panics
    ///
    /// Denne funktion kan muligvis panic, hvis den kaldes, efter at `Complete`-varianten er returneret tidligere.
    /// Mens generatorbogstaver på sproget garanteres panic ved genoptagelse efter `Complete`, er dette ikke garanteret for alle implementeringer af `Generator` trait.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn resume(self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return>;
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R>, R> Generator<R> for Pin<&mut G> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[unstable(feature = "generator_trait", issue = "43122")]
impl<G: ?Sized + Generator<R> + Unpin, R> Generator<R> for &mut G {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> GeneratorState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}