/// Bruges til uforanderlige dereferencesoperationer, som `*v`.
///
/// Ud over at blive brugt til eksplicitte dereferensoperationer med (unary) `*`-operatøren i uforanderlige sammenhænge, bruges `Deref` også implicit af compileren under mange omstændigheder.
/// Denne mekanisme kaldes ['`Deref` coercion'][more].
/// I ændrede sammenhænge anvendes [`DerefMut`].
///
/// Implementering af `Deref` til smarte pointer gør det let at få adgang til data bag dem, hvorfor de implementerer `Deref`.
/// På den anden side blev reglerne vedrørende `Deref` og [`DerefMut`] designet specielt til at rumme smarte markører.
/// På grund af dette skal **`Deref` kun implementeres til smarte pointer** for at undgå forvirring.
///
/// Af lignende grunde skal **denne trait aldrig mislykkes**.Fejl under dereferference kan være ekstremt forvirrende, når `Deref` påberåbes implicit.
///
/// # Mere om `Deref` tvang
///
/// Hvis `T` implementerer `Deref<Target = U>`, og `x` er en værdi af typen `T`, så:
///
/// * I uforanderlige sammenhænge svarer `*x` (hvor `T` hverken er en reference eller en rå pointer) svarer til `* Deref::deref(&x)`.
/// * Værdier af typen `&T` tvinges til værdier af typen `&U`
/// * `T` implementerer implicit alle (immutable)-metoder af typen `U`.
///
/// For flere detaljer, besøg [the chapter in *The Rust Programming Language*][book] samt referenceafsnittene om [the dereference operator][ref-deref-op], [method resolution] og [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// En struktur med et enkelt felt, der er tilgængeligt ved at derfereferere strukturen.
///
/// ```
/// use std::ops::Deref;
///
/// struct DerefExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// let x = DerefExample { value: 'a' };
/// assert_eq!('a', *x);
/// ```
///
///
///
///
///
///
///
#[lang = "deref"]
#[doc(alias = "*")]
#[doc(alias = "&*")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Deref"]
pub trait Deref {
    /// Den resulterende type efter dereferference.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_target"]
    #[cfg_attr(not(bootstrap), lang = "deref_target")]
    type Target: ?Sized;

    /// Afviger værdien.
    #[must_use]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_diagnostic_item = "deref_method"]
    fn deref(&self) -> &Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &T {
    type Target = T;

    #[rustc_diagnostic_item = "noop_method_deref"]
    fn deref(&self) -> &T {
        *self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !DerefMut for &T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for &mut T {
    type Target = T;

    fn deref(&self) -> &T {
        *self
    }
}

/// Bruges til mutable dereferferenceoperationer, som i `*v = 1;`.
///
/// Ud over at blive brugt til eksplicitte dereferencesoperationer med (unary) `*`-operatøren i mutable sammenhænge, bruges `DerefMut` også implicit af compileren under mange omstændigheder.
/// Denne mekanisme kaldes ['`Deref` coercion'][more].
/// I uforanderlige sammenhænge anvendes [`Deref`].
///
/// Implementering af `DerefMut` til smarte pointer gør det nemt at mutere data bag dem, hvorfor de implementerer `DerefMut`.
/// På den anden side blev reglerne vedrørende [`Deref`] og `DerefMut` designet specielt til at rumme smarte markører.
/// På grund af dette bør **`DerefMut` kun implementeres til smarte pointere** for at undgå forvirring.
///
/// Af lignende grunde skal **denne trait aldrig mislykkes**.Fejl under dereferference kan være ekstremt forvirrende, når `DerefMut` påberåbes implicit.
///
/// # Mere om `Deref` tvang
///
/// Hvis `T` implementerer `DerefMut<Target = U>`, og `x` er en værdi af typen `T`, så:
///
/// * I ændrede sammenhænge svarer `*x` (hvor `T` hverken er en reference eller en rå markør) svarende til `* DerefMut::deref_mut(&mut x)`.
/// * Værdier af typen `&mut T` tvinges til værdier af typen `&mut U`
/// * `T` implementerer implicit alle (mutable)-metoder af typen `U`.
///
/// For flere detaljer, besøg [the chapter in *The Rust Programming Language*][book] samt referenceafsnittene om [the dereference operator][ref-deref-op], [method resolution] og [type coercions].
///
///
/// [book]: ../../book/ch15-02-deref.html
/// [more]: #more-on-deref-coercion
/// [ref-deref-op]: ../../reference/expressions/operator-expr.html#the-dereference-operator
/// [method resolution]: ../../reference/expressions/method-call-expr.html
/// [type coercions]: ../../reference/type-coercions.html
///
/// # Examples
///
/// En struktur med et enkelt felt, som kan ændres ved at derfereferere strukturen.
///
/// ```
/// use std::ops::{Deref, DerefMut};
///
/// struct DerefMutExample<T> {
///     value: T
/// }
///
/// impl<T> Deref for DerefMutExample<T> {
///     type Target = T;
///
///     fn deref(&self) -> &Self::Target {
///         &self.value
///     }
/// }
///
/// impl<T> DerefMut for DerefMutExample<T> {
///     fn deref_mut(&mut self) -> &mut Self::Target {
///         &mut self.value
///     }
/// }
///
/// let mut x = DerefMutExample { value: 'a' };
/// *x = 'b';
/// assert_eq!('b', *x);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "deref_mut"]
#[doc(alias = "*")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DerefMut: Deref {
    /// Mutere derfererer værdien.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn deref_mut(&mut self) -> &mut Self::Target;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> DerefMut for &mut T {
    fn deref_mut(&mut self) -> &mut T {
        *self
    }
}

/// Angiver, at en struct kan bruges som en modtagemetode uden `arbitrary_self_types`-funktionen.
///
/// Dette implementeres af stdlib-markørtyper som `Box<T>`, `Rc<T>`, `&T` og `Pin<P>`.
#[lang = "receiver"]
#[unstable(feature = "receiver_trait", issue = "none")]
#[doc(hidden)]
pub trait Receiver {
    // Empty.
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &T {}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for &mut T {}