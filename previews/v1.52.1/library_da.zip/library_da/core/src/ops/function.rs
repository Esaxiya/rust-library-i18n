/// Den version af opkaldsoperatøren, der tager en uforanderlig modtager.
///
/// Forekomster af `Fn` kan kaldes gentagne gange uden at mutere tilstand.
///
/// *Denne trait (`Fn`) må ikke forveksles med [function pointers] (`fn`).*
///
/// `Fn` implementeres automatisk af lukninger, der kun tager uforanderlige referencer til fangede variabler eller slet ikke fanger noget, samt (safe) [function pointers] (med nogle forbehold, se deres dokumentation for flere detaljer).
///
/// Derudover for enhver type `F`, der implementerer `Fn`, implementerer `&F` også `Fn`.
///
/// Da både [`FnMut`] og [`FnOnce`] er supertræk af `Fn`, kan enhver forekomst af `Fn` bruges som en parameter, hvor en [`FnMut`] eller [`FnOnce`] forventes.
///
/// Brug `Fn` som en bund, når du vil acceptere en parameter af funktionslignende type og har brug for at kalde den gentagne gange og uden at mutere tilstand (f.eks. Når du kalder den samtidigt).
/// Hvis du ikke har brug for så strenge krav, skal du bruge [`FnMut`] eller [`FnOnce`] som grænser.
///
/// Se [chapter on closures in *The Rust Programming Language*][book] for at få flere oplysninger om dette emne.
///
/// Bemærk også den specielle syntaks for `Fn` traits (f.eks
/// `Fn(usize, bool) -> brug størrelse ').De, der er interesseret i de tekniske detaljer i dette, kan henvise til [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Opkald til en lukning
///
/// ```
/// let square = |x| x * x;
/// assert_eq!(square(5), 25);
/// ```
///
/// ## Brug af en `Fn`-parameter
///
/// ```
/// fn call_with_one<F>(func: F) -> usize
///     where F: Fn(usize) -> usize {
///     func(1)
/// }
///
/// let double = |x| x * 2;
/// assert_eq!(call_with_one(double), 2);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{Fn}<{Args}>` closure, found `{Self}`",
    label = "expected an `Fn<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // så regex kan stole på den `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait Fn<Args>: FnMut<Args> {
    /// Udfører opkaldsoperationen.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call(&self, args: Args) -> Self::Output;
}

/// Den version af opkaldsoperatøren, der tager en ændret modtager.
///
/// Forekomster af `FnMut` kan kaldes gentagne gange og kan mutere tilstand.
///
/// `FnMut` implementeres automatisk ved lukninger, der tager foranderlige referencer til indfangede variabler såvel som alle typer, der implementerer [`Fn`], f.eks. (safe) [function pointers] (da `FnMut` er et supertrav af [`Fn`]).
/// Derudover for enhver type `F`, der implementerer `FnMut`, implementerer `&mut F` også `FnMut`.
///
/// Da [`FnOnce`] er et supertrait af `FnMut`, kan enhver forekomst af `FnMut` bruges, hvor en [`FnOnce`] forventes, og da [`Fn`] er en undertekst af `FnMut`, kan enhver forekomst af [`Fn`] bruges, hvor `FnMut` forventes.
///
/// Brug `FnMut` som en bund, når du vil acceptere en parameter af funktionslignende type og har brug for at kalde den gentagne gange, samtidig med at den tillader at mutere tilstanden.
/// Hvis du ikke ønsker, at parameteren skal mutere tilstand, skal du bruge [`Fn`] som en bundet;Hvis du ikke har brug for at ringe til det gentagne gange, skal du bruge [`FnOnce`].
///
/// Se [chapter on closures in *The Rust Programming Language*][book] for at få flere oplysninger om dette emne.
///
/// Bemærk også den specielle syntaks for `Fn` traits (f.eks
/// `Fn(usize, bool) -> brug størrelse ').De, der er interesseret i de tekniske detaljer i dette, kan henvise til [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Opkald til en omskifteligt fangende lukning
///
/// ```
/// let mut x = 5;
/// {
///     let mut square_x = || x *= x;
///     square_x();
/// }
/// assert_eq!(x, 25);
/// ```
///
/// ## Brug af en `FnMut`-parameter
///
/// ```
/// fn do_twice<F>(mut func: F)
///     where F: FnMut()
/// {
///     func();
///     func();
/// }
///
/// let mut x: usize = 1;
/// {
///     let add_two_to_x = || x += 2;
///     do_twice(add_two_to_x);
/// }
///
/// assert_eq!(x, 5);
/// ```
///
///
///
///
///
///
///
///
///
#[lang = "fn_mut"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnMut}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnMut<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // så regex kan stole på den `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnMut<Args>: FnOnce<Args> {
    /// Udfører opkaldsoperationen.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output;
}

/// Den version af opkaldsoperatøren, der tager en by-value-modtager.
///
/// Forekomster af `FnOnce` kan kaldes, men kan muligvis ikke kaldes flere gange.På grund af dette, hvis det eneste, der kendes ved en type, er, at den implementerer `FnOnce`, kan den kun kaldes en gang.
///
/// `FnOnce` implementeres automatisk af lukninger, der kan forbruge fangede variabler, såvel som alle typer, der implementerer [`FnMut`], f.eks. (safe) [function pointers] (da `FnOnce` er et supertrait af [`FnMut`]).
///
///
/// Da både [`Fn`] og [`FnMut`] er undertræk til `FnOnce`, kan enhver forekomst af [`Fn`] eller [`FnMut`] bruges, hvor en `FnOnce` forventes.
///
/// Brug `FnOnce` som en bund, når du vil acceptere en parameter af funktionslignende type og kun behøver at kalde den en gang.
/// Hvis du har brug for at kalde parameteren gentagne gange, skal du bruge [`FnMut`] som en bundet;hvis du også har brug for det for ikke at mutere tilstand, skal du bruge [`Fn`].
///
/// Se [chapter on closures in *The Rust Programming Language*][book] for at få flere oplysninger om dette emne.
///
/// Bemærk også den specielle syntaks for `Fn` traits (f.eks
/// `Fn(usize, bool) -> brug størrelse ').De, der er interesseret i de tekniske detaljer i dette, kan henvise til [the relevant section in the *Rustonomicon*][nomicon].
///
/// [book]: ../../book/ch13-01-closures.html
/// [function pointers]: fn
/// [nomicon]: ../../nomicon/hrtb.html
///
/// # Examples
///
/// ## Brug af en `FnOnce`-parameter
///
/// ```
/// fn consume_with_relish<F>(func: F)
///     where F: FnOnce() -> String
/// {
///     // `func` forbruger de fangede variabler, så den kan ikke køres mere end én gang.
/////
///     println!("Consumed: {}", func());
///
///     println!("Delicious!");
///
///     // Forsøg på at påkalde `func()` igen kaster en `use of moved value`-fejl for `func`.
/////
/// }
///
/// let x = String::from("x");
/// let consume_and_return_x = move || x;
/// consume_with_relish(consume_and_return_x);
///
/// // `consume_and_return_x` kan ikke længere påberåbes på dette tidspunkt
/// ```
///
///
///
///
///
///
///
///
#[lang = "fn_once"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_paren_sugar]
#[rustc_on_unimplemented(
    on(
        Args = "()",
        note = "wrap the `{Self}` in a closure with no arguments: `|| {{ /* code */ }}`"
    ),
    message = "expected a `{FnOnce}<{Args}>` closure, found `{Self}`",
    label = "expected an `FnOnce<{Args}>` closure, found `{Self}`"
)]
#[fundamental] // så regex kan stole på den `&str: !FnMut`
#[must_use = "closures are lazy and do nothing unless called"]
pub trait FnOnce<Args> {
    /// Den returnerede type efter opkaldsoperatøren er brugt.
    #[lang = "fn_once_output"]
    #[stable(feature = "fn_once_output", since = "1.12.0")]
    type Output;

    /// Udfører opkaldsoperationen.
    #[unstable(feature = "fn_traits", issue = "29625")]
    extern "rust-call" fn call_once(self, args: Args) -> Self::Output;
}

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> Fn<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call(&self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &F
    where
        F: Fn<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (**self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &F
    where
        F: Fn<A>,
    {
        type Output = F::Output;

        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnMut<A> for &mut F
    where
        F: FnMut<A>,
    {
        extern "rust-call" fn call_mut(&mut self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<A, F: ?Sized> FnOnce<A> for &mut F
    where
        F: FnMut<A>,
    {
        type Output = F::Output;
        extern "rust-call" fn call_once(self, args: A) -> F::Output {
            (*self).call_mut(args)
        }
    }
}