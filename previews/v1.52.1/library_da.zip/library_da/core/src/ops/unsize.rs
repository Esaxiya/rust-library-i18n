use crate::marker::Unsize;

/// Trait, der indikerer, at dette er en markør eller en indpakning til en, hvor unsizing kan udføres på pointeren.
///
/// Se [DST coercion RFC][dst-coerce] og [the nomicon entry on coercion][nomicon-coerce] for at få flere detaljer.
///
/// For indbyggede markørtyper vil markører til `T` tvinge hen til markører til `U`, hvis `T: Unsize<U>` ved at konvertere fra en tynd markør til en fed markør.
///
/// For tilpassede typer fungerer tvangen her ved at tvinge `Foo<T>` til `Foo<U>`, forudsat at der findes en impl. Af `CoerceUnsized<Foo<U>> for Foo<T>`.
/// En sådan impl kan kun skrives, hvis `Foo<T>` kun har et enkelt ikke-fantomdatafelt, der involverer `T`.
/// Hvis typen af dette felt er `Bar<T>`, skal der eksistere en implementering af `CoerceUnsized<Bar<U>> for Bar<T>`.
/// Tvangen fungerer ved at tvinge `Bar<T>`-feltet ind i `Bar<U>` og udfylde resten af felterne fra `Foo<T>` for at oprette en `Foo<U>`.
/// Dette vil effektivt bore ned til et markørfelt og tvinge det.
///
/// Generelt til smarte pointer implementerer du `CoerceUnsized<Ptr<U>> for Ptr<T> where T: Unsize<U>, U: ?Sized` med en valgfri `?Sized` bundet til selve `T`.
/// For indpakningstyper, der direkte integrerer `T` som `Cell<T>` og `RefCell<T>`, kan du implementere `CoerceUnsized<Wrap<U>> for Wrap<T> where T: CoerceUnsized<U>` direkte.
///
/// Dette vil lade tvang af typer som `Cell<Box<T>>` arbejde.
///
/// [`Unsize`][unsize] bruges til at markere typer, der kan tvinges til sommertid, hvis de er bag markører.Det implementeres automatisk af compileren.
///
/// [dst-coerce]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [unsize]: crate::marker::Unsize
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
///
///
///
///
///
///
#[unstable(feature = "coerce_unsized", issue = "27732")]
#[lang = "coerce_unsized"]
pub trait CoerceUnsized<T: ?Sized> {
    // Empty.
}

// &mut T-> &mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a mut U> for &'a mut T {}
// &mut T-> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b mut T {}
// &mut T-> * mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for &'a mut T {}
// &mut T-> * konst. U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a mut T {}

// &T -> &U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, 'b: 'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<&'a U> for &'b T {}
// &T -> * const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for &'a T {}

// *mut T->* mut U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*mut U> for *mut T {}
// *mut T->* const U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *mut T {}

// *konst T->* konst U
#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<*const U> for *const T {}

/// Dette bruges til genstandssikkerhed for at kontrollere, at en metodes modtager type kan sendes videre.
///
/// Et eksempel på implementering af trait:
///
/// ```
/// # #![feature(dispatch_from_dyn, unsize)]
/// # use std::{ops::DispatchFromDyn, marker::Unsize};
/// # struct Rc<T: ?Sized>(std::rc::Rc<T>);
/// impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T>
/// where
///     T: Unsize<U>,
/// {}
/// ```
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
#[lang = "dispatch_from_dyn"]
pub trait DispatchFromDyn<T> {
    // Empty.
}

// &T -> &U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a U> for &'a T {}
// &mut T-> &mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<'a, T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<&'a mut U> for &'a mut T {}
// *konst T->* konst U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*const U> for *const T {}
// *mut T->* mut U
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<*mut U> for *mut T {}