//! Overbelastbare operatører.
//!
//! Implementering af disse traits giver dig mulighed for at overbelaste visse operatører.
//!
//! Nogle af disse traits importeres af prelude, så de er tilgængelige i alle Rust-programmer.Kun operatører, der er bakket op af traits, kan overbelastes.
//! For eksempel kan tilføjelsesoperatøren (`+`) overbelastes gennem [`Add`] trait, men da tildelingsoperatøren (`=`) ikke har nogen understøttelse trait, er der ingen måde at overbelaste dens semantik.
//! Derudover indeholder dette modul ingen mekanisme til oprettelse af nye operatører.
//! Hvis der kræves traiteløs overbelastning eller brugerdefinerede operatører, skal du se på makroer eller compiler-plugins for at udvide Rust s syntaks.
//!
//! Implementeringer af operatør traits bør være overraskende i deres respektive sammenhænge under hensyntagen til deres sædvanlige betydninger og [operator precedence].
//! For eksempel, når implementering af [`Mul`], skal operationen have en vis lighed med multiplikation (og dele forventede egenskaber som associativitet).
//!
//! Bemærk, at `&&`-og `||`-operatørerne kortslutter, dvs. de kun vurderer deres anden operand, hvis det bidrager til resultatet.Da denne adfærd ikke kan håndhæves af traits, understøttes `&&` og `||` ikke som overbelastningsoperatører.
//!
//! Mange af operatørerne tager deres operander efter værdi.I ikke-generiske sammenhænge, der involverer indbyggede typer, er dette normalt ikke et problem.
//! Brug af disse operatorer i generisk kode kræver dog en vis opmærksomhed, hvis værdier skal genbruges i modsætning til at lade operatørerne forbruge dem.En mulighed er at lejlighedsvis bruge [`clone`].
//! En anden mulighed er at stole på de involverede typer, der giver yderligere operatørimplementeringer til referencer.
//! For eksempel for en brugerdefineret type `T`, som formodes at understøtte tilføjelse, er det sandsynligvis en god idé at have både `T` og `&T` til at implementere traits [`Add<T>`][`Add`] og [`Add<&T>`][`Add`], så generisk kode kan skrives uden unødvendig kloning.
//!
//!
//! # Examples
//!
//! Dette eksempel opretter en `Point`-struktur, der implementerer [`Add`] og [`Sub`], og viser derefter tilføjelse og fratrækning af to `punkt`er.
//!
//! ```rust
//! use std::ops::{Add, Sub};
//!
//! #[derive(Debug, Copy, Clone, PartialEq)]
//! struct Point {
//!     x: i32,
//!     y: i32,
//! }
//!
//! impl Add for Point {
//!     type Output = Self;
//!
//!     fn add(self, other: Self) -> Self {
//!         Self {x: self.x + other.x, y: self.y + other.y}
//!     }
//! }
//!
//! impl Sub for Point {
//!     type Output = Self;
//!
//!     fn sub(self, other: Self) -> Self {
//!         Self {x: self.x - other.x, y: self.y - other.y}
//!     }
//! }
//!
//! assert_eq!(Point {x: 3, y: 3}, Point {x: 1, y: 0} + Point {x: 2, y: 3});
//! assert_eq!(Point {x: -1, y: -3}, Point {x: 1, y: 0} - Point {x: 2, y: 3});
//! ```
//!
//! Se dokumentationen for hver trait for et eksempel på implementering.
//!
//! [`Fn`], [`FnMut`] og [`FnOnce`] traits implementeres af typer, der kan påberåbes som funktioner.Bemærk, at [`Fn`] tager `&self`, [`FnMut`] tager `&mut self` og [`FnOnce`] tager `self`.
//! Disse svarer til de tre slags metoder, der kan påberåbes på en forekomst: kald-for-reference, call-by-mutable-reference og call-by-value.
//! Den mest almindelige anvendelse af disse traits er at fungere som grænser for funktioner på højere niveau, der tager funktioner eller lukninger som argumenter.
//!
//! At tage en [`Fn`] som parameter:
//!
//! ```rust
//! fn call_with_one<F>(func: F) -> usize
//!     where F: Fn(usize) -> usize
//! {
//!     func(1)
//! }
//!
//! let double = |x| x * 2;
//! assert_eq!(call_with_one(double), 2);
//! ```
//!
//! At tage en [`FnMut`] som parameter:
//!
//! ```rust
//! fn do_twice<F>(mut func: F)
//!     where F: FnMut()
//! {
//!     func();
//!     func();
//! }
//!
//! let mut x: usize = 1;
//! {
//!     let add_two_to_x = || x += 2;
//!     do_twice(add_two_to_x);
//! }
//!
//! assert_eq!(x, 5);
//! ```
//!
//! At tage en [`FnOnce`] som parameter:
//!
//! ```rust
//! fn consume_with_relish<F>(func: F)
//!     where F: FnOnce() -> String
//! {
//!     // `func` forbruger de fangede variabler, så den kan ikke køres mere end én gang
//!     //
//!     println!("Consumed: {}", func());
//!
//!     println!("Delicious!");
//!
//!     // Forsøg på at påkalde `func()` igen kaster en `use of moved value`-fejl for `func`
//!     //
//! }
//!
//! let x = String::from("x");
//! let consume_and_return_x = move || x;
//! consume_with_relish(consume_and_return_x);
//!
//! // `consume_and_return_x` kan ikke længere påberåbes på dette tidspunkt
//! ```
//!
//! [`clone`]: Clone::clone
//! [operator precedence]: ../../reference/expressions.html#expression-precedence
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

mod arith;
mod bit;
mod control_flow;
mod deref;
mod drop;
mod function;
mod generator;
mod index;
mod range;
mod r#try;
mod unsize;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::arith::{Add, Div, Mul, Neg, Rem, Sub};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::arith::{AddAssign, DivAssign, MulAssign, RemAssign, SubAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::bit::{BitAnd, BitOr, BitXor, Not, Shl, Shr};
#[stable(feature = "op_assign_traits", since = "1.8.0")]
pub use self::bit::{BitAndAssign, BitOrAssign, BitXorAssign, ShlAssign, ShrAssign};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::deref::{Deref, DerefMut};

#[unstable(feature = "receiver_trait", issue = "none")]
pub use self::deref::Receiver;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::drop::Drop;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::function::{Fn, FnMut, FnOnce};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::index::{Index, IndexMut};

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::range::{Range, RangeFrom, RangeFull, RangeTo};

#[stable(feature = "inclusive_range", since = "1.26.0")]
pub use self::range::{Bound, RangeBounds, RangeInclusive, RangeToInclusive};

#[unstable(feature = "try_trait", issue = "42327")]
pub use self::r#try::Try;

#[unstable(feature = "generator_trait", issue = "43122")]
pub use self::generator::{Generator, GeneratorState};

#[unstable(feature = "coerce_unsized", issue = "27732")]
pub use self::unsize::CoerceUnsized;

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
pub use self::unsize::DispatchFromDyn;

#[unstable(feature = "control_flow_enum", reason = "new API", issue = "75744")]
pub use self::control_flow::ControlFlow;