/// En trait til tilpasning af `?`-operatørens opførsel.
///
/// En type, der implementerer `Try`, er en, der har en kanonisk måde at se den på i form af en success/failure-dikotomi.
/// Denne trait tillader både at udtrække disse succes-eller fiaskoværdier fra en eksisterende instans og oprette en ny instans fra en succes-eller fiaskoværdi.
///
///
#[unstable(feature = "try_trait", issue = "42327")]
#[rustc_on_unimplemented(
    on(
        all(
            any(from_method = "from_error", from_method = "from_ok"),
            from_desugaring = "QuestionMark"
        ),
        message = "the `?` operator can only be used in {ItemContext} \
                    that returns `Result` or `Option` \
                    (or another type that implements `{Try}`)",
        label = "cannot use the `?` operator in {ItemContext} that returns `{Self}`",
        enclosing_scope = "this function should return `Result` or `Option` to accept `?`"
    ),
    on(
        all(from_method = "into_result", from_desugaring = "QuestionMark"),
        message = "the `?` operator can only be applied to values \
                    that implement `{Try}`",
        label = "the `?` operator cannot be applied to type `{Self}`"
    )
)]
#[doc(alias = "?")]
#[lang = "try"]
pub trait Try {
    /// Typen af denne værdi, når den betragtes som vellykket.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Ok;
    /// Typen af denne værdi, når den betragtes som mislykket.
    #[unstable(feature = "try_trait", issue = "42327")]
    type Error;

    /// Anvender "?"-operatøren.En returnering af `Ok(t)` betyder, at udførelsen skal fortsætte normalt, og resultatet af `?` er værdien `t`.
    /// En returnering af `Err(e)` betyder, at udførelse skal branch til det inderste, der omslutter `catch`, eller vende tilbage fra funktionen.
    ///
    /// Hvis et `Err(e)`-resultat returneres, vil værdien `e` være "wrapped" i returtypen for det vedlagte område (som selv skal implementere `Try`).
    ///
    /// Specifikt returneres værdien `X::from_error(From::from(e))`, hvor `X` er returtypen for den indesluttende funktion.
    ///
    ///
    ///
    #[lang = "into_result"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn into_result(self) -> Result<Self::Ok, Self::Error>;

    /// Indpak en fejlværdi for at konstruere det sammensatte resultat.
    /// For eksempel er `Result::Err(x)` og `Result::from_error(x)` ækvivalente.
    #[lang = "from_error"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_error(v: Self::Error) -> Self;

    /// Indpak en OK-værdi for at konstruere det sammensatte resultat.
    /// For eksempel er `Result::Ok(x)` og `Result::from_ok(x)` ækvivalente.
    #[lang = "from_ok"]
    #[unstable(feature = "try_trait", issue = "42327")]
    fn from_ok(v: Self::Ok) -> Self;
}