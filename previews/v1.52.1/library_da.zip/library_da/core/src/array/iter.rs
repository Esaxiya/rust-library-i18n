//! Definerer den `IntoIter`-ejede iterator til arrays.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// En byværdi [array] iterator.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Dette er det array, vi gentager.
    ///
    /// Elementer med indeks `i`, hvor `alive.start <= i < alive.end` endnu ikke er givet, og er gyldige matrixindgange.
    /// Elementer med indeks `i < alive.start` eller `i >= alive.end` er allerede leveret og må ikke tilgås mere!Disse døde elementer kan endda være i en fuldstændig uinitialiseret tilstand!
    ///
    ///
    /// Så invarianterne er:
    /// - `data[alive]` lever (dvs. indeholder gyldige elementer)
    /// - `data[..alive.start]` og `data[alive.end..]` er døde (dvs. elementerne var allerede læst og må ikke berøres længere!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// De elementer i `data`, der endnu ikke er leveret.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Opretter en ny iterator over den givne `array`.
    ///
    /// *Bemærk*: denne metode kan blive udfaset i future efter [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Typen `value` er en `i32` her i stedet for `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // SIKKERHED: Den transmute her er faktisk sikker.Dokumenterne fra `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` er garanteret at have samme størrelse og justering
        // > som `T`.
        //
        // Dokumenterne viser endda en transmute fra en matrix af `MaybeUninit<T>` til en matrix af `T`.
        //
        //
        // Dermed tilfredsstiller denne initialisering invarianterne.

        // FIXME(LukasKalbertodt): faktisk bruge `mem::transmute` her, når det fungerer med const generics:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Indtil da kan vi bruge `mem::transmute_copy` til at oprette en bitvis kopi som en anden type og derefter glemme `array`, så den ikke tabes.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Returnerer et uforanderligt stykke af alle elementer, der endnu ikke er givet.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // SIKKERHED: Vi ved, at alle elementer i `alive` er initialiseret korrekt.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Returnerer en ændret del af alle elementer, der endnu ikke er givet.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // SIKKERHED: Vi ved, at alle elementer i `alive` er initialiseret korrekt.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Få det næste indeks forfra.
        //
        // Forøgelse af `alive.start` med 1 opretholder invarianten vedrørende `alive`.
        // På grund af denne ændring er den levende zone i kort tid ikke `data[alive]` længere, men `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Læs elementet fra arrayet.
            // SIKKERHED: `idx` er et indeks i den tidligere "alive"-region i
            // array.At læse dette element betyder, at `data[idx]` betragtes som død nu (dvs. ikke røre ved).
            // Da `idx` var starten på den levende zone, er den levende zone nu `data[alive]` igen og gendanner alle invarianter.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Få det næste indeks bagfra.
        //
        // Ved at sænke `alive.end` med 1 opretholdes invarianten angående `alive`.
        // På grund af denne ændring er den levende zone i kort tid ikke `data[alive]` længere, men `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Læs elementet fra arrayet.
            // SIKKERHED: `idx` er et indeks i den tidligere "alive"-region i
            // array.At læse dette element betyder, at `data[idx]` betragtes som død nu (dvs. ikke røre ved).
            // Da `idx` var slutningen på den levende zone, er den levende zone nu `data[alive]` igen og gendanner alle invarianter.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // SIKKERHED: Dette er sikkert: `as_mut_slice` returnerer nøjagtigt underskiven
        // af elementer, der endnu ikke er flyttet ud, og som stadig skal droppes.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Understrømmer aldrig på grund af den uforanderlige `alive.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Iteratoren rapporterer faktisk den korrekte længde.
// Antallet af "alive"-elementer (der stadig vil blive givet) er længden af området `alive`.
// Dette interval er reduceret i længden i enten `next` eller `next_back`.
// Det reduceres altid med 1 i disse metoder, men kun hvis `Some(_)` returneres.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Bemærk, vi behøver ikke rigtig at matche det nøjagtige samme levende interval, så vi kan bare klone til forskydning 0 uanset hvor `self` er.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Klon alle levende elementer.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Skriv en klon i det nye array, og opdater derefter dets levende rækkevidde.
            // Hvis vi kloner panics, slipper vi de tidligere poster korrekt.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Udskriv kun de elementer, der ikke blev leveret endnu: vi har ikke længere adgang til de leverede elementer.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}