use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// En grænseflade til håndtering af asynkrone iteratorer.
///
/// Dette er hovedstrømmen trait.
/// For mere om begrebet streams generelt, se [module-level documentation].
/// Især vil du måske vide, hvordan du [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Den type varer, der leveres af strømmen.
    type Item;

    /// Forsøg at trække den næste værdi af denne stream ud, registrere den aktuelle opgave til wakeup, hvis værdien endnu ikke er tilgængelig, og returnere `None`, hvis strømmen er opbrugt.
    ///
    /// # Returneringsværdi
    ///
    /// Der er flere mulige returværdier, der hver angiver en særskilt strømtilstand:
    ///
    /// - `Poll::Pending` betyder, at denne streams næste værdi ikke er klar endnu.Implementeringer vil sikre, at den aktuelle opgave underrettes, når den næste værdi muligvis er klar.
    ///
    /// - `Poll::Ready(Some(val))` betyder, at streamen med succes har produceret en værdi, `val`, og kan producere yderligere værdier ved efterfølgende `poll_next`-opkald.
    ///
    /// - `Poll::Ready(None)` betyder, at streamen er afsluttet, og `poll_next` ikke skal påberåbes igen.
    ///
    /// # Panics
    ///
    /// Når en stream er færdig (returneret `Ready(None)` from `poll_next`), opkald til `poll_next`-metoden igen kan panic, blokere for evigt eller forårsage andre former for problemer; `Stream` trait stiller ingen krav til virkningerne af et sådant opkald.
    ///
    /// Da `poll_next`-metoden ikke er markeret som `unsafe`, gælder Rust s sædvanlige regler: opkald må aldrig forårsage udefineret adfærd (hukommelseskorruption, forkert brug af `unsafe`-funktioner eller lignende) uanset streamens tilstand.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Returnerer grænserne for den resterende længde af strømmen.
    ///
    /// Specifikt returnerer `size_hint()` en tuple, hvor det første element er den nedre grænse, og det andet element er den øvre grænse.
    ///
    /// Den anden halvdel af tuplen, der returneres, er en [`Option`]`<`[`usize`] `>`.
    /// En [`None`] betyder her, at der enten ikke er nogen kendt øvre grænse, eller at den øvre grænse er større end [`usize`].
    ///
    /// # Implementeringsnoter
    ///
    /// Det håndhæves ikke, at en streamimplementering giver det deklarerede antal elementer.En buggy stream kan give mindre end den nedre grænse eller mere end den øvre grænse for elementer.
    ///
    /// `size_hint()` er primært beregnet til at blive brugt til optimeringer såsom at reservere plads til elementerne i strømmen, men må ikke have tillid til at f.eks. udelade grænsekontrol i usikker kode.
    /// En forkert implementering af `size_hint()` bør ikke føre til overtrædelser af hukommelsessikkerheden.
    ///
    /// Når det er sagt, skal implementeringen give et korrekt skøn, fordi det ellers ville være en overtrædelse af trait's protokol.
    ///
    /// Standardimplementeringen returnerer `(0,` [`None`]`)`, som er korrekt for enhver stream.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}