//! Komponerbar asynkron iteration.
//!
//! Hvis futures er asynkrone værdier, er streams asynkrone iteratorer.
//! Hvis du har fundet dig selv med en asynkron samling af en slags og har brug for at udføre en operation på elementerne i den nævnte samling, løber du hurtigt ind i 'streams'.
//! Streams bruges stærkt i idiomatisk asynkron Rust-kode, så det er værd at blive fortrolig med dem.
//!
//! Før vi forklarer mere, lad os tale om, hvordan dette modul er struktureret:
//!
//! # Organization
//!
//! Dette modul er stort set organiseret efter type:
//!
//! * [Traits] er kernedelen: disse traits definerer, hvilken slags streams der findes, og hvad du kan gøre med dem.Metoderne i disse traits er værd at lægge lidt ekstra studietid på.
//! * Funktioner giver nogle nyttige måder at oprette nogle grundlæggende streams på.
//! * Structs er ofte returneringstyperne for de forskellige metoder på dette moduls traits.Du vil normalt se på metoden, der opretter `struct`, snarere end selve `struct`.
//! For flere detaljer om hvorfor, se '[Implementing Stream](#implementerings-stream)'.
//!
//! [Traits]: #traits
//!
//! Det er det!Lad os grave i vandløb.
//!
//! # Stream
//!
//! Hjertet og sjælen i dette modul er [`Stream`] trait.Kernen i [`Stream`] ser sådan ud:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! I modsætning til `Iterator` skelner `Stream` mellem [`poll_next`]-metoden, der bruges ved implementering af en `Stream`, og en (to-be-implemented) `next`-metode, der bruges ved forbrug af en stream.
//!
//! Forbrugere af `Stream` behøver kun at overveje `next`, som når de kaldes, returnerer en future, som giver `Option<Stream::Item>`.
//!
//! future, der returneres af `next`, giver `Some(Item)`, så længe der er elementer, og når de alle er opbrugt, vil de give `None` for at indikere, at iteration er afsluttet.
//! Hvis vi venter på noget asynkront at løse, venter future, indtil strømmen er klar til at give igen.
//!
//! Individuelle streams kan vælge at genoptage iteration, og så kan man ringe til `next` igen eller måske ikke med tiden give `Some(Item)` igen på et eller andet tidspunkt.
//!
//! ['Stream'] 's fulde definition inkluderer også en række andre metoder, men de er standardmetoder, bygget oven på [`poll_next`], og så får du dem gratis.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Implementering af stream
//!
//! Oprettelse af en egen stream involverer to trin: Oprettelse af en `struct` for at holde streamens tilstand og derefter implementering af [`Stream`] for den `struct`.
//!
//! Lad os lave en stream ved navn `Counter`, der tæller fra `1` til `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // For det første strukturen:
//!
//! /// En strøm, der tæller fra en til fem
//! struct Counter {
//!     count: usize,
//! }
//!
//! // vi ønsker, at vores optælling starter ved en, så lad os tilføje en new()-metode til at hjælpe.
//! // Dette er ikke strengt nødvendigt, men er praktisk.
//! // Bemærk, at vi starter `count` på nul, vi ser hvorfor i `poll_next()`'s implementering nedenfor.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Derefter implementerer vi `Stream` til vores `Counter`:
//!
//! impl Stream for Counter {
//!     // vi tæller med usize
//!     type Item = usize;
//!
//!     // poll_next() er den eneste nødvendige metode
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Forøg vores antal.Derfor startede vi på nul.
//!         self.count += 1;
//!
//!         // Kontroller, om vi er færdige med at tælle eller ej.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Strømme er *dovne*.Dette betyder, at bare at oprette en stream ikke _do_ meget.Intet sker virkelig, før du ringer til `next`.
//! Dette er undertiden en kilde til forvirring, når man opretter en strøm udelukkende for dens bivirkninger.
//! Compileren vil advare os om denne form for adfærd:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;