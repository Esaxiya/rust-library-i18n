#![stable(feature = "core_hint", since = "1.27.0")]

//! Tip til kompilatoren, der påvirker, hvordan kode skal udsendes eller optimeres.
//! Tip kan være kompileringstid eller runtime.

use crate::intrinsics;

/// Informerer kompilatoren om, at dette punkt i koden ikke kan nås, hvilket muliggør yderligere optimeringer.
///
/// # Safety
///
/// At nå denne funktion er helt *udefineret adfærd*(UB).Især antager compileren, at al UB aldrig må ske, og vil derfor fjerne alle grene, der når et opkald til `unreachable_unchecked()`.
///
/// Som alle tilfælde af UB, hvis denne antagelse viser sig at være forkert, dvs. at `unreachable_unchecked()`-opkaldet faktisk kan nås blandt alle mulige kontrolflow, vil compileren anvende den forkerte optimeringsstrategi og kan undertiden endda ødelægge tilsyneladende ikke-relateret kode og forårsage vanskeligt-problemer med fejlretning.
///
///
/// Brug kun denne funktion, når du kan bevise, at koden aldrig kalder den.
/// Ellers overvej at bruge [`unreachable!`]-makroen, som ikke tillader optimeringer, men som panic, når den udføres.
///
/// # Example
///
/// ```
/// fn div_1(a: u32, b: u32) -> u32 {
///     use std::hint::unreachable_unchecked;
///
///     // `b.saturating_add(1)` er altid positiv (ikke nul), derfor returnerer `checked_div` aldrig `None`.
/////
///     // Derfor er den anden branch ikke tilgængelig.
///     a.checked_div(b.saturating_add(1))
///         .unwrap_or_else(|| unsafe { unreachable_unchecked() })
/// }
///
/// assert_eq!(div_1(7, 0), 7);
/// assert_eq!(div_1(9, 1), 4);
/// assert_eq!(div_1(11, u32::MAX), 0);
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "unreachable", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
pub const unsafe fn unreachable_unchecked() -> ! {
    // SIKKERHED: sikkerhedskontrakten for `intrinsics::unreachable` skal
    // opretholdes af den, der ringer op.
    unsafe { intrinsics::unreachable() }
}

/// Afsender en maskininstruktion for at signalisere processoren, at den kører i en optaget-vent spin-loop ("spin lock").
///
/// Efter modtagelse af spin-loop-signalet kan processoren optimere sin opførsel ved f.eks. At spare strøm eller skifte hyper-tråde.
///
/// Denne funktion er forskellig fra [`thread::yield_now`], som direkte giver systemets planlægning, mens `spin_loop` ikke interagerer med operativsystemet.
///
/// En almindelig brugssag til `spin_loop` implementerer afgrænset optimistisk spinding i en CAS-loop i synkroniseringsprimitiver.
/// For at undgå problemer som prioritetsinversion anbefales det kraftigt, at spin-loop'en afsluttes efter en begrænset mængde iterationer, og der foretages en passende blokerende syscall.
///
///
/// **Bemærk**: På platforme, der ikke understøtter modtagelse af spin-loop-tip, gør denne funktion slet ikke noget.
///
/// # Examples
///
/// ```
/// use std::sync::atomic::{AtomicBool, Ordering};
/// use std::sync::Arc;
/// use std::{hint, thread};
///
/// // En delt atomværdi, som tråde bruger til at koordinere
/// let live = Arc::new(AtomicBool::new(false));
///
/// // I en baggrundstråd indstiller vi til sidst værdien
/// let bg_work = {
///     let live = live.clone();
///     thread::spawn(move || {
///         // Gør noget arbejde, og gør derefter værdien levende
///         do_some_work();
///         live.store(true, Ordering::Release);
///     })
/// };
///
/// // Tilbage på vores nuværende tråd venter vi på, at værdien skal indstilles
/// while !live.load(Ordering::Acquire) {
///     // Spin-løkken er et tip til CPU'en, at vi venter, men sandsynligvis ikke meget længe
/////
///     hint::spin_loop();
/// }
///
/// // Værdien er nu indstillet
/// # fn do_some_work() {}
/// do_some_work();
/// bg_work.join()?;
/// # Ok::<(), Box<dyn core::any::Any + Send + 'static>>(())
/// ```
///
/// [`thread::yield_now`]: ../../std/thread/fn.yield_now.html
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "renamed_spin_loop", since = "1.49.0")]
pub fn spin_loop() {
    #[cfg(all(any(target_arch = "x86", target_arch = "x86_64"), target_feature = "sse2"))]
    {
        #[cfg(target_arch = "x86")]
        {
            // SIKKERHED: `cfg` attr sikrer, at vi kun udfører dette på x86-mål.
            unsafe { crate::arch::x86::_mm_pause() };
        }

        #[cfg(target_arch = "x86_64")]
        {
            // SIKKERHED: `cfg` attr sikrer, at vi kun udfører dette på x86_64-mål.
            unsafe { crate::arch::x86_64::_mm_pause() };
        }
    }

    #[cfg(any(target_arch = "aarch64", all(target_arch = "arm", target_feature = "v6")))]
    {
        #[cfg(target_arch = "aarch64")]
        {
            // SIKKERHED: `cfg` attr sikrer, at vi kun udfører dette på aarch64-mål.
            unsafe { crate::arch::aarch64::__yield() };
        }
        #[cfg(target_arch = "arm")]
        {
            // SIKKERHED: `cfg` attr sikrer, at vi kun udfører dette på armmål
            // med support til v6-funktionen.
            unsafe { crate::arch::arm::__yield() };
        }
    }
}

/// En identitetsfunktion, som *__ antyder __* til compileren for at være maksimalt pessimistisk over, hvad `black_box` kunne gøre.
///
/// I modsætning til [`std::convert::identity`] opfordres en Rust-kompilator til at antage, at `black_box` kan bruge `dummy` på enhver mulig gyldig måde, som Rust-koden er tilladt uden at indføre udefineret adfærd i opkaldskoden.
///
/// Denne egenskab gør `black_box` nyttig til at skrive kode, hvor visse optimeringer ikke ønskes, såsom benchmarks.
///
/// Bemærk dog, at `black_box` kun (og kun kan leveres) på "best-effort"-basis.I hvilket omfang det kan blokere optimeringer kan variere afhængigt af den anvendte platform og kodegen-backend.
/// Programmer kan ikke stole på `black_box` for *korrekthed* på nogen måde.
///
/// [`std::convert::identity`]: crate::convert::identity
///
///
///
#[cfg_attr(not(miri), inline)]
#[cfg_attr(miri, inline(never))]
#[unstable(feature = "test", issue = "50297")]
#[cfg_attr(miri, allow(unused_mut))]
pub fn black_box<T>(mut dummy: T) -> T {
    // Vi er nødt til at "use" argumentet på en eller anden måde kan LLVM ikke introspektere, og på mål, der understøtter det, kan vi typisk udnytte integreret samling til at gøre dette.
    // LLVMs fortolkning af inline-samling er, at det, ja, en sort boks.
    // Dette er ikke den største implementering, da det sandsynligvis deoptimerer mere, end vi ønsker, men det er hidtil godt nok.
    //
    //

    #[cfg(not(miri))] // Dette er bare et tip, så det er fint at springe over i Miri.
    // SIKKERHED: den integrerede samling er en no-op.
    unsafe {
        // FIXME: Kan ikke bruge `asm!`, fordi den ikke understøtter MIPS og andre arkitekturer.
        llvm_asm!("" : : "r"(&mut dummy) : "memory" : "volatile");
    }

    dummy
}