//! Primitive traits og typer, der repræsenterer grundlæggende egenskaber for typer.
//!
//! Rust-typer kan klassificeres på forskellige nyttige måder alt efter deres iboende egenskaber.
//! Disse klassifikationer er repræsenteret som traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Typer, der kan overføres på tværs af trådgrænser.
///
/// Denne trait implementeres automatisk, når kompilatoren finder det passende.
///
/// Et eksempel på en type, der ikke er 'Send', er referencetællingsmarkøren [`rc::Rc`][`Rc`].
/// Hvis to tråde forsøger at klone ['Rc'], der peger på den samme reference-tællede værdi, kan de prøve at opdatere referencetallet på samme tid, hvilket er [undefined behavior][ub], fordi [`Rc`] ikke bruger atomoperationer.
///
/// Dens fætter [`sync::Arc`][arc] bruger atomoperationer (medfører noget overhead) og er således `Send`.
///
/// Se [the Nomicon](../../nomicon/send-and-sync.html) for flere detaljer.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Typer med en konstant størrelse kendt ved kompileringstidspunktet.
///
/// Alle typeparametre har en implicit grænse for `Sized`.Den specielle syntaks `?Sized` kan bruges til at fjerne denne bund, hvis den ikke er passende.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // struct FooUse(Foo<[i32]>);//fejl: Størrelse er ikke implementeret til [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Den ene undtagelse er den implicitte `Self`-type af en trait.
/// En trait har ikke en implicit `Sized`-bundet, da dette er inkompatibelt med [trait-objekt], hvor trait pr. Definition har brug for at arbejde med alle mulige implementatorer og dermed kunne være af enhver størrelse.
///
///
/// Selvom Rust giver dig mulighed for at binde `Sized` til en trait, kan du ikke bruge den til at danne et trait-objekt senere:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // lad y: &dyn Bar= &Impl;//fejl: trait `Bar` kan ikke gøres til et objekt
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // for Standard, for eksempel, hvilket kræver, at `[T]: !Default` kan evalueres
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Typer, der kan være "unsized" til en dynamisk størrelse type.
///
/// For eksempel implementerer den store arraytype `[i8; 2]` `Unsize<[i8]>` og `Unsize<dyn fmt::Debug>`.
///
/// Alle implementeringer af `Unsize` leveres automatisk af compileren.
///
/// `Unsize` er implementeret til:
///
/// - `[T; N]` er `Unsize<[T]>`
/// - `T` er `Unsize<dyn Trait>`, når `T: Trait`
/// - `Foo<..., T, ...>` er `Unsize<Foo<..., U, ...>>`, hvis:
///   - `T: Unsize<U>`
///   - Foo er en struktur
///   - Kun det sidste felt i `Foo` har en type, der involverer `T`
///   - `T` er ikke en del af typen af andre felter
///   - `Bar<T>: Unsize<Bar<U>>`, hvis det sidste felt i `Foo` har typen `Bar<T>`
///
/// `Unsize` bruges sammen med [`ops::CoerceUnsized`] for at tillade "user-defined"-containere såsom [`Rc`] at indeholde typer af dynamisk størrelse.
/// Se [DST coercion RFC][RFC982] og [the nomicon entry on coercion][nomicon-coerce] for at få flere detaljer.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Påkrævet trait til konstanter, der bruges i mønsteroverensstemmelser.
///
/// Enhver type, der stammer `PartialEq`, implementerer automatisk denne trait * uanset om dens typeparametre implementerer `Eq`.
///
/// Hvis et `const`-element indeholder en type, der ikke implementerer denne trait, implementerer den typen enten (1.) ikke `PartialEq` (hvilket betyder, at konstanten ikke giver den sammenligningsmetode, som kodegenerering antager, at er tilgængelig) eller (2.), den implementerer *sin egen* version af `PartialEq` (som vi antager ikke er i overensstemmelse med en sammenligning med strukturel lighed).
///
///
/// I et af de to scenarier ovenfor afviser vi brugen af en sådan konstant i et mønstermatch.
///
/// Se også [structural match RFC][RFC1445] og [issue 63438], som motiverede migrering fra attributbaseret design til denne trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Påkrævet trait til konstanter, der bruges i mønsteroverensstemmelser.
///
/// Enhver type, der stammer `Eq`, implementerer automatisk denne trait,*uanset* om dens typeparametre implementerer `Eq`.
///
/// Dette er et hack til at omgå en begrænsning i vores typesystem.
///
/// # Background
///
/// Vi ønsker at kræve, at typer konstanter, der bruges i mønsteroverensstemmelser, har attributten `#[derive(PartialEq, Eq)]`.
///
/// I en mere ideel verden kunne vi kontrollere dette krav ved blot at kontrollere, at den givne type implementerer både `StructuralPartialEq` trait *og*`Eq` trait.
/// Du kan dog have ADT'er, der *gør*`derive(PartialEq, Eq)`, og være en sag, som vi ønsker, at compileren skal acceptere, og alligevel undgår konstantens type at implementere `Eq`.
///
/// Nemlig en sag som denne:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Problemet i ovenstående kode er, at `Wrap<fn(&())>` ikke implementerer `PartialEq` eller `Eq`, fordi `for <'a> fn(&'a _)` does not implement those traits.)
///
/// Derfor kan vi ikke stole på naiv kontrol for `StructuralPartialEq` og blot `Eq`.
///
/// Som et hack til at omgå dette bruger vi to separate traits injiceret af hver af de to afledte (`#[derive(PartialEq)]` og `#[derive(Eq)]`) og kontrollerer, at begge er til stede som en del af kontrol af strukturel match.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Typer, hvis værdier kan kopieres ved blot at kopiere bits.
///
/// Som standard har variable bindinger 'flyt semantik'.Med andre ord:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` er flyttet til `y`, og kan derfor ikke bruges
///
/// // println! ("{: ?}", x);//fejl: brug af flyttet værdi
/// ```
///
/// Men hvis en type implementerer `Copy`, har den i stedet 'kopisemantik':
///
/// ```
/// // Vi kan udlede en `Copy`-implementering.
/// // `Clone` er også påkrævet, da det er et supertrait af `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` er en kopi af `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Det er vigtigt at bemærke, at i disse to eksempler er den eneste forskel, om du har adgang til `x` efter opgaven.
/// Under emhætten kan både en kopi og et træk resultere i, at bits kopieres i hukommelsen, selvom dette undertiden optimeres væk.
///
/// ## Hvordan kan jeg implementere `Copy`?
///
/// Der er to måder at implementere `Copy` på din type.Det enkleste er at bruge `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Du kan også implementere `Copy` og `Clone` manuelt:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Der er en lille forskel mellem de to: `derive`-strategien placerer også en `Copy` bundet til typeparametre, hvilket ikke altid er ønsket.
///
/// ## Hvad er forskellen mellem `Copy` og `Clone`?
///
/// Kopier sker implicit, for eksempel som en del af en opgave `y = x`.`Copy` s opførsel kan ikke overbelastes.det er altid en simpel bitvis kopi.
///
/// Kloning er en eksplicit handling, `x.clone()`.Implementeringen af [`Clone`] kan give enhver typespecifik adfærd, der er nødvendig for at duplikere værdier sikkert.
/// For eksempel skal implementeringen af [`Clone`] til [`String`] kopiere den pegede strengbuffer i bunken.
/// En simpel bitvis kopi af [`String`]-værdier ville blot kopiere markøren, hvilket førte til en dobbelt fri nedad linjen.
/// Af denne grund er [`String`] [`Clone`], men ikke `Copy`.
///
/// [`Clone`] er et supertrait af `Copy`, så alt, hvad der er `Copy`, skal også implementere [`Clone`].
/// Hvis en type er `Copy`, behøver dens [`Clone`]-implementering kun at returnere `*self` (se eksemplet ovenfor).
///
/// ## Hvornår kan min type være `Copy`?
///
/// En type kan implementere `Copy`, hvis alle dens komponenter implementerer `Copy`.For eksempel kan denne struktur være `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// En struktur kan være `Copy`, og [`i32`] er `Copy`, derfor er `Point` berettiget til at være `Copy`.
/// Derimod overvej
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Struct `PointList` kan ikke implementere `Copy`, fordi [`Vec<T>`] ikke er `Copy`.Hvis vi forsøger at udlede en `Copy`-implementering, får vi en fejl:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Delte referencer (`&T`) er også `Copy`, så en type kan være `Copy`, selv når den indeholder delte referencer af typerne `T`, der er *ikke*`Copy`.
/// Overvej følgende struktur, som kan implementere `Copy`, fordi den kun indeholder en *delt reference* til vores ikke-`Kopi` type `PointList` ovenfra:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Hvornår *kan* min type ikke være `Copy`?
///
/// Nogle typer kan ikke kopieres sikkert.For eksempel ville kopiering af `&mut T` skabe en alias, der kan ændres.
/// Kopiering af [`String`] vil duplikere ansvaret for styring af ['String'] 's buffer, hvilket fører til en dobbeltfri.
///
/// Generelt i sidstnævnte tilfælde kan enhver type, der implementerer [`Drop`], ikke være `Copy`, fordi den administrerer en eller anden ressource udover sine egne [`size_of::<T>`]-byte.
///
/// Hvis du forsøger at implementere `Copy` på en struktur eller enum, der indeholder data, der ikke er 'Kopier', får du fejlen [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Hvornår *skal* min type være `Copy`?
///
/// Generelt set, hvis din type _can_ implementerer `Copy`, skal den.
/// Husk dog, at implementering af `Copy` er en del af den offentlige API af din type.
/// Hvis typen muligvis ikke bliver 'Kopiér' i future, kan det være klogt at udelade `Copy`-implementeringen nu for at undgå en brudt API-ændring.
///
/// ## Yderligere implementatorer
///
/// Ud over [implementors listed below][impls] implementerer følgende typer også `Copy`:
///
/// * Funktionstyper (dvs. de forskellige typer, der er defineret for hver funktion)
/// * Funktionsmarkørtyper (f.eks. `fn() -> i32`)
/// * Array-typer, for alle størrelser, hvis varetypen også implementerer `Copy` (f.eks. `[i32; 123456]`)
/// * Tupletyper, hvis hver komponent også implementerer `Copy` (f.eks. `()`, `(i32, bool)`)
/// * Lukningstyper, hvis de ikke fanger nogen værdi fra miljøet, eller hvis alle sådanne fangede værdier implementerer `Copy` selv.
///   Bemærk, at variabler, der er fanget med delt reference, altid implementerer `Copy` (selvom referenten ikke gør det), mens variabler, der er fanget ved hjælp af mutabel reference, aldrig implementerer `Copy`.
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Dette tillader kopiering af en type, der ikke implementerer `Copy` på grund af utilfredse levetidsgrænser (kopiering af `A<'_>`, når kun `A<'static>: Copy` og `A<'_>: Clone`).
// Vi har denne egenskab her for nu kun fordi der er en hel del eksisterende specialiseringer på `Copy`, der allerede findes i standardbiblioteket, og der er ingen måde at have denne opførsel sikkert lige nu.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Hent makro, der genererer en impl af trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Typer, hvor det er sikkert at dele referencer mellem tråde.
///
/// Denne trait implementeres automatisk, når kompilatoren finder det passende.
///
/// Den nøjagtige definition er: en type `T` er [`Sync`], hvis og kun hvis `&T` er [`Send`].
/// Med andre ord, hvis der ikke er nogen mulighed for [undefined behavior][ub] (inklusive dataløb), når `&T`-referencer sendes mellem tråde.
///
/// Som man kunne forvente, er primitive typer som [`u8`] og [`f64`] alle [`Sync`], og det samme er enkle aggregattyper, der indeholder dem, som tupler, structs og enums.
/// Flere eksempler på basale [`Sync`]-typer inkluderer "immutable"-typer som `&T`, og dem med simpel nedarvet mutabilitet, såsom [`Box<T>`][box], [`Vec<T>`][vec] og de fleste andre samlingstyper.
///
/// (Generiske parametre skal være [`Sync`] for at deres container skal være [`Sync`].)
///
/// En noget overraskende konsekvens af definitionen er, at `&mut T` er `Sync` (hvis `T` er `Sync`), selvom det ser ud til, at det kan give usynkroniseret mutation.
/// Tricket er, at en ændret reference bag en delt reference (dvs. `& &mut T`) bliver skrivebeskyttet, som om det var en `& &T`.
/// Derfor er der ingen risiko for et dataløb.
///
/// Typer, der ikke er `Sync`, er dem, der har "interior mutability" i en ikke-trådsikker form, såsom [`Cell`][cell] og [`RefCell`][refcell].
/// Disse typer muliggør mutation af deres indhold, selv gennem en uforanderlig, delt reference.
/// For eksempel tager `set`-metoden på [`Cell<T>`][cell] `&self`, så den kræver kun en delt reference [`&Cell<T>`][cell].
/// Metoden udfører ingen synkronisering, så [`Cell`][cell] kan ikke være `Sync`.
///
/// Et andet eksempel på en ikke-'Sync'-type er referencetællingsmarkøren [`Rc`][rc].
/// Under en hvilken som helst reference [`&Rc<T>`][rc] kan du klone en ny [`Rc<T>`][rc] ved at ændre referencetællingerne på en ikke-atomær måde.
///
/// I tilfælde, hvor man har brug for trådsikker indvendig mutabilitet, giver Rust [atomic data types] samt eksplicit låsning via [`sync::Mutex`][mutex] og [`sync::RwLock`][rwlock].
/// Disse typer sikrer, at enhver mutation ikke kan forårsage dataløb, hvorfor typerne er `Sync`.
/// Ligeledes giver [`sync::Arc`][arc] en trådsikker analog af [`Rc`][rc].
///
/// Alle typer med indvendig mutabilitet skal også bruge [`cell::UnsafeCell`][unsafecell]-indpakningen omkring value(s), som kan muteres gennem en delt reference.
/// Manglende at gøre dette er [undefined behavior][ub].
/// For eksempel er [`transmute`][transmute]-ing fra `&T` til `&mut T` ugyldig.
///
/// Se [the Nomicon][nomicon-send-and-sync] for at få flere oplysninger om `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): når support til at tilføje noter i `rustc_on_unimplemented` lander i beta, og det er blevet udvidet til at kontrollere, om en lukning er overalt i kravkæden, skal du udvide den som sådan (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Nulstørrelsestype bruges til at markere ting, som "act like" de ejer en `T`.
///
/// Tilføjelse af et `PhantomData<T>`-felt til din type fortæller kompilatoren, at din type fungerer som om den gemmer en værdi af typen `T`, selvom den ikke rigtig gør det.
/// Disse oplysninger bruges til beregning af visse sikkerhedsegenskaber.
///
/// For en mere detaljeret forklaring på, hvordan du bruger `PhantomData<T>`, se [the Nomicon](../../nomicon/phantom-data.html).
///
/// # En uhyggelig note 👻👻👻
///
/// Selvom de begge har skræmmende navne, er `PhantomData` og 'fantomtyper' beslægtede, men ikke identiske.En fantomtypeparameter er simpelthen en typeparameter, som aldrig bruges.
/// I Rust får dette ofte compileren til at klage, og løsningen er at tilføje en "dummy"-brug ved hjælp af `PhantomData`.
///
/// # Examples
///
/// ## Ubrugte levetidsparametre
///
/// Måske er den mest almindelige brugssag til `PhantomData` en struktur, der har en ubrugt levetidsparameter, typisk som en del af en usikker kode.
/// For eksempel er her en struct `Slice`, der har to markører af typen `*const T`, der sandsynligvis peger i en matrix et eller andet sted:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Hensigten er, at de underliggende data kun er gyldige i hele `'a`, så `Slice` bør ikke overleve `'a`.
/// Denne hensigt udtrykkes imidlertid ikke i koden, da der ikke er nogen anvendelser af `'a` s levetid, og det er derfor ikke klart, hvilke data det gælder for.
/// Vi kan rette dette ved at fortælle kompilatoren at handle *som om*`Slice`-strukturen indeholdt en reference `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Dette kræver også igen kommentaren `T: 'a`, hvilket indikerer, at eventuelle referencer i `T` er gyldige i løbet af `'a`.
///
/// Ved initialisering af en `Slice` angiver du simpelthen værdien `PhantomData` for feltet `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Ubrugte typeparametre
///
/// Det sker nogle gange, at du har ubrugte typeparametre, der angiver, hvilken type data en struct er "tied" til, selvom disse data faktisk ikke findes i selve strukturen.
/// Her er et eksempel, hvor dette opstår med [FFI].
/// Den udenlandske grænseflade bruger håndtag af typen `*mut ()` til at henvise til Rust-værdier af forskellige typer.
/// Vi sporer Rust-typen ved hjælp af en fantomtypeparameter på struct `ExternalResource`, der omslutter et håndtag.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Ejerskab og drop check
///
/// Tilføjelse af et felt af typen `PhantomData<T>` angiver, at din type ejer data af typen `T`.Dette indebærer igen, at når din type droppes, kan den droppe en eller flere forekomster af typen `T`.
/// Dette har betydning for Rust-kompilatorens [drop check]-analyse.
///
/// Hvis din struct faktisk ikke *ejer* dataene af typen `T`, er det bedre at bruge en referencetype som `PhantomData<&'a T>` (ideally) eller `PhantomData<*const T>` (hvis der ikke er nogen levetid) for ikke at angive ejerskab.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Compiler-intern trait bruges til at angive typen af enum-diskriminanter.
///
/// Denne trait implementeres automatisk for alle typer og tilføjer ingen garantier til [`mem::Discriminant`].
/// Det er **udefineret adfærd** at transmittere mellem `DiscriminantKind::Discriminant` og `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Den type diskriminant, der skal tilfredsstille trait bounds krævet af `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Compiler-intern trait bruges til at bestemme, om en type indeholder nogen `UnsafeCell` internt, men ikke gennem en indirektion.
///
/// Dette påvirker for eksempel, om en `static` af denne type placeres i statisk skrivehukommelse eller skrivbar statisk hukommelse.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Typer, der kan flyttes sikkert efter at være fastgjort.
///
/// Rust selv har ingen forestilling om faste typer og anser bevægelser (f.eks. Gennem tildeling eller [`mem::replace`]) for altid at være sikre.
///
/// [`Pin`][Pin]-typen bruges i stedet for at forhindre bevægelser gennem typesystemet.Markører `P<T>` indpakket i [`Pin<P<T>>`][Pin] indpakningen kan ikke flyttes ud af.
/// Se [`pin` module]-dokumentationen for at få flere oplysninger om fastgørelse.
///
/// Implementering af `Unpin` trait til `T` løfter begrænsningerne for at fastgøre typen, hvilket derefter tillader flytning af `T` ud af [`Pin<P<T>>`][Pin] med funktioner som [`mem::replace`].
///
///
/// `Unpin` har slet ingen konsekvenser for ikke-fastgjorte data.
/// Især flytter [`mem::replace`] med glæde `!Unpin`-data (det fungerer for enhver `&mut T`, ikke kun når `T: Unpin`).
/// Du kan dog ikke bruge [`mem::replace`] på data indpakket i en [`Pin<P<T>>`][Pin], fordi du ikke kan få den `&mut T`, du har brug for, og *det* er det, der får dette system til at fungere.
///
/// Så dette kan for eksempel kun gøres på typer, der implementerer `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Vi har brug for en ændret reference for at ringe til `mem::replace`.
/// // Vi kan få en sådan reference ved at (implicitly) påberåber `Pin::deref_mut`, men det er kun muligt, fordi `String` implementerer `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Denne trait implementeres automatisk til næsten alle typer.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// En markørtype, der ikke implementerer `Unpin`.
///
/// Hvis en type indeholder en `PhantomPinned`, implementerer den ikke `Unpin` som standard.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Implementeringer af `Copy` til primitive typer.
///
/// Implementeringer, der ikke kan beskrives i Rust, implementeres i `traits::SelectionContext::copy_clone_conditions()` i `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Delte referencer kan kopieres, men mutable referencer *kan ikke*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}