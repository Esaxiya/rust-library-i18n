# `rustc-std-workspace-core` crate

Denne crate er en shim og tom crate, som simpelthen afhænger af `libcore` og reeksporterer alt dens indhold.
crate er kernen i at give standardbiblioteket mulighed for at afhænge af crates fra crates.io

Crates på crates.io, som standardbiblioteket afhænger af, skal afhænge af `rustc-std-workspace-core` crate fra crates.io, som er tomt.

Vi bruger `[patch]` til at tilsidesætte den til denne crate i dette lager.
Som et resultat trækker crates på crates.io en afhængighed edge til `libcore`, den version, der er defineret i dette lager.
Det skulle trække alle afhængighedskanter for at sikre, at Cargo bygger crates med succes!

Bemærk, at crates på crates.io skal afhænge af denne crate med navnet `core` for at alt skal fungere korrekt.For at gøre det kan de bruge:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Ved brug af `package`-nøglen omdøbes crate til `core`, hvilket betyder, at det vil se ud

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

når Cargo påkalder compileren og opfylder det implicitte `extern crate core`-direktiv, der indsprøjtes af compileren.




