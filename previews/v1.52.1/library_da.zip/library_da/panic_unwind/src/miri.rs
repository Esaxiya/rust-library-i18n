//! Afvikling af panics til Miri.
use alloc::boxed::Box;
use core::any::Any;

// Den type nyttelast, som Miri-motoren formerer sig ved at afvikle for os.
// Skal være markørstørrelse.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Miri-leveret ekstern funktion til at begynde at slappe af.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Den nyttelast, vi sender til `miri_start_panic`, vil være nøjagtigt det argument, vi får i `cleanup` nedenfor.
    // Så vi bokser det bare op en gang for at få noget markørstørrelse.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Gendan den underliggende `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}