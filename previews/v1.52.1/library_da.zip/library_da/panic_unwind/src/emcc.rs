//! Afvikling for *emscripten* mål.
//!
//! Mens Rust s sædvanlige afviklingsimplementering til Unix-platforme kalder direkte på libunwind API'erne, på Emscripten kalder vi i stedet til C++ -afviklings-API'erne.
//! Dette er bare en hjælp, da Emscripten's runtime altid implementerer disse API'er og ikke implementerer libunwind.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// Dette matcher layoutet af std::type_info i C++
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // Den førende `\x01`-byte her er faktisk et magisk signal til LLVM om at *ikke* anvende noget andet manglende som præfiks med et `_`-tegn.
    //
    //
    // Dette symbol er den vtabel, der bruges af C++ 's `std::type_info`.
    // Objekter af typen `std::type_info`, typebeskrivere, har en markør til denne tabel.
    // Typebeskrivere henvises til af C++ EH-strukturer defineret ovenfor, og som vi konstruerer nedenfor.
    //
    // Bemærk, at den reelle størrelse er større end 3 størrelser, men vi har kun brug for vores vtabel for at pege på det tredje element.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info til en rust_panic klasse
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // Normalt bruger vi .as_ptr().add(2), men dette fungerer ikke i en const-sammenhæng.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // Dette bruger forsætligt ikke det normale navneskema, fordi vi ikke vil have, at C++ kan producere eller fange Rust panics.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // Dette er nødvendigt, fordi C++ -kode kan registrere vores udførelse med std::exception_ptr og kaste den flere gange, muligvis endda i en anden tråd.
    //
    //
    caught: AtomicBool,

    // Dette skal være en mulighed, fordi objektets levetid følger C++ semantik: når catch_unwind flytter boksen ud af undtagelsen, skal den stadig efterlade undtagelsesobjektet i en gyldig tilstand, fordi dets destruktør stadig kaldes af __cxa_end_catch.
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try faktisk giver os en peger på denne struktur.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // Da cleanup() ikke har lov til at panic, afbryder vi bare i stedet.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}