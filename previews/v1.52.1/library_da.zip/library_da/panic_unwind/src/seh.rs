//! Windows SEH
//!
//! På Windows (i øjeblikket kun på MSVC) er standard undtagelseshåndteringsmekanismen Structured Exception Handling (SEH).
//! Dette er helt anderledes end dværgbaseret undtagelseshåndtering (f.eks. Hvad andre unix-platforme bruger) med hensyn til kompiler-interner, så det kræves, at LLVM har en hel del ekstra support til SEH.
//!
//! I en nøddeskal er det, der sker her:
//!
//! 1. `panic`-funktionen kalder standard Windows-funktionen `_CxxThrowException` for at kaste en C++ -lignende undtagelse, der udløser afviklingsprocessen.
//! 2.
//! Alle landingsplader, der genereres af compileren, bruger personlighedsfunktionen `__CxxFrameHandler3`, en funktion i CRT, og afviklingskoden i Windows bruger denne personlighedsfunktion til at udføre al oprydningskode på stakken.
//!
//! 3. Alle compiler-genererede opkald til `invoke` har en landingsplade indstillet som en `cleanuppad` LLVM-instruktion, som indikerer starten på oprydningsrutinen.
//! Personligheden (i trin 2, defineret i CRT) er ansvarlig for at køre oprydningsrutiner.
//! 4. Til sidst udføres "catch"-koden i `try` iboende (genereret af compileren) og indikerer, at styringen skal komme tilbage til Rust.
//! Dette gøres via en `catchswitch` plus en `catchpad` instruktion i LLVM IR termer, og til sidst returneres normal kontrol til programmet med en `catchret` instruktion.
//!
//! Nogle specifikke forskelle fra den gcc-baserede undtagelseshåndtering er:
//!
//! * Rust har ingen brugerdefineret personlighedsfunktion, det er i stedet *altid*`__CxxFrameHandler3`.Derudover udføres der ingen ekstra filtrering, så vi ender med at fange C++ -undtagelser, der tilfældigvis ligner den slags, vi kaster.
//! Bemærk, at at kaste en undtagelse i Rust er udefineret adfærd alligevel, så dette skal være fint.
//! * Vi har nogle data, der skal transmitteres over afviklingsgrænsen, specifikt en `Box<dyn Any + Send>`.Som med undtagelser fra dværg gemmes disse to markører som en nyttelast i selve undtagelsen.
//! På MSVC er der dog ikke behov for en ekstra bunktildeling, fordi opkaldstakken bevares, mens filterfunktioner udføres.
//! Dette betyder, at markørerne sendes direkte til `_CxxThrowException`, som derefter gendannes i filterfunktionen for at blive skrevet til stakrammen på `try` iboende.
//!
//! [win64]: https://docs.microsoft.com/en-us/cpp/build/exception-handling-x64
//! [llvm]: http://llvm.org/docs/ExceptionHandling.html#background-on-windows-exceptions
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(nonstandard_style)]

use alloc::boxed::Box;
use core::any::Any;
use core::mem::{self, ManuallyDrop};
use libc::{c_int, c_uint, c_void};

struct Exception {
    // Dette skal være en mulighed, fordi vi fanger undtagelsen ved reference, og dens destruktor udføres af C++ runtime.
    // Når vi tager boksen ud af undtagelsen, er vi nødt til at lade undtagelsen være i en gyldig tilstand for at dens destruktør skal køre uden at dobbeltkaste boksen.
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

// Først og fremmest en hel masse typedefinitioner.Der er et par platformsspecifikke underlige ting her, og meget, der bare er åbenlyst kopieret fra LLVM.Formålet med alt dette er at implementere `panic`-funktionen nedenfor gennem et opkald til `_CxxThrowException`.
//
// Denne funktion tager to argumenter.Den første er en markør til de data, vi sender ind, som i dette tilfælde er vores trait-objekt.Temmelig let at finde!Den næste er dog mere kompliceret.
// Dette er en markør til en `_ThrowInfo`-struktur, og det er generelt kun beregnet til bare at beskrive den undtagelse, der smides.
//
// I øjeblikket er definitionen af denne type [1] lidt behåret, og den vigtigste underlighed (og forskellen fra online-artiklen) er, at på 32-bit er markørerne pegepinde, men på 64-bit udtrykkes pointerne som 32-bit forskydninger fra `__ImageBase` symbol.
//
// `ptr_t` og `ptr!` makroen i nedenstående moduler bruges til at udtrykke dette.
//
// Labyrinten af typedefinitioner følger også nøje, hvad LLVM udsender til denne slags operation.For eksempel, hvis du kompilerer denne C++ -kode på MSVC og udsender LLVM IR:
//
//      #include <stdint.h>
//
//      struct rust_panic {
//          rust_panic(const rust_panic&);
//          ~rust_panic();
//
//          uint64_t x[2];};
//
//      ugyldigt foo() { rust_panic a = {0, 1};
//          smide en;}
//
// Det er i det væsentlige det, vi prøver at efterligne.De fleste af nedenstående konstante værdier blev bare kopieret fra LLVM,
//
// Under alle omstændigheder er disse strukturer alle konstrueret på en lignende måde, og det er bare noget detaljeret for os.
//
// [1]: http://www.geoffchappell.com/studies/msvc/language/predefined/
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

#[cfg(target_arch = "x86")]
#[macro_use]
mod imp {
    pub type ptr_t = *mut u8;

    macro_rules! ptr {
        (0) => {
            core::ptr::null_mut()
        };
        ($e:expr) => {
            $e as *mut u8
        };
    }
}

#[cfg(not(target_arch = "x86"))]
#[macro_use]
mod imp {
    pub type ptr_t = u32;

    extern "C" {
        pub static __ImageBase: u8;
    }

    macro_rules! ptr {
        (0) => (0);
        ($e:expr) => {
            (($e as usize) - (&imp::__ImageBase as *const _ as usize)) as u32
        }
    }
}

#[repr(C)]
pub struct _ThrowInfo {
    pub attributes: c_uint,
    pub pmfnUnwind: imp::ptr_t,
    pub pForwardCompat: imp::ptr_t,
    pub pCatchableTypeArray: imp::ptr_t,
}

#[repr(C)]
pub struct _CatchableTypeArray {
    pub nCatchableTypes: c_int,
    pub arrayOfCatchableTypes: [imp::ptr_t; 1],
}

#[repr(C)]
pub struct _CatchableType {
    pub properties: c_uint,
    pub pType: imp::ptr_t,
    pub thisDisplacement: _PMD,
    pub sizeOrOffset: c_int,
    pub copyFunction: imp::ptr_t,
}

#[repr(C)]
pub struct _PMD {
    pub mdisp: c_int,
    pub pdisp: c_int,
    pub vdisp: c_int,
}

#[repr(C)]
pub struct _TypeDescriptor {
    pub pVFTable: *const u8,
    pub spare: *mut u8,
    pub name: [u8; 11],
}

// Bemærk, at vi med vilje ignorerer regler om navnemangling her: vi vil ikke have, at C++ skal kunne fange Rust panics ved blot at erklære en `struct rust_panic`.
//
//
// Når du ændrer, skal du sørge for, at typenavnstrengen nøjagtigt svarer til den, der bruges i `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//
const TYPE_NAME: [u8; 11] = *b"rust_panic\0";

static mut THROW_INFO: _ThrowInfo = _ThrowInfo {
    attributes: 0,
    pmfnUnwind: ptr!(0),
    pForwardCompat: ptr!(0),
    pCatchableTypeArray: ptr!(0),
};

static mut CATCHABLE_TYPE_ARRAY: _CatchableTypeArray =
    _CatchableTypeArray { nCatchableTypes: 1, arrayOfCatchableTypes: [ptr!(0)] };

static mut CATCHABLE_TYPE: _CatchableType = _CatchableType {
    properties: 0,
    pType: ptr!(0),
    thisDisplacement: _PMD { mdisp: 0, pdisp: -1, vdisp: 0 },
    sizeOrOffset: mem::size_of::<Exception>() as c_int,
    copyFunction: ptr!(0),
};

extern "C" {
    // Den førende `\x01`-byte her er faktisk et magisk signal til LLVM om at *ikke* anvende noget andet manglende som præfiks med et `_`-tegn.
    //
    //
    // Dette symbol er den vtabel, der bruges af C++ 's `std::type_info`.
    // Objekter af typen `std::type_info`, typebeskrivere, har en markør til denne tabel.
    // Typebeskrivere henvises til af C++ EH-strukturer defineret ovenfor, og som vi konstruerer nedenfor.
    //
    #[link_name = "\x01??_7type_info@@6B@"]
    static TYPE_INFO_VTABLE: *const u8;
}

// Denne type deskriptor bruges kun, når du kaster en undtagelse.
// Fangstdelen håndteres af den iboende prøve, der genererer sin egen TypeDescriptor.
//
// Dette er fint, da MSVC-runtime bruger strengesammenligning på typenavnet til at matche TypeDescriptors snarere end pointerens lighed.
//
static mut TYPE_DESCRIPTOR: _TypeDescriptor = _TypeDescriptor {
    pVFTable: unsafe { &TYPE_INFO_VTABLE } as *const _ as *const _,
    spare: core::ptr::null_mut(),
    name: TYPE_NAME,
};

// Destructor bruges, hvis C++ -koden beslutter at fange undtagelsen og slippe den uden at udbrede den.
// Fangstdelen af prøveens indre sætter det første ord i undtagelsesobjektet til 0, så det springes over af destruktøren.
//
// Bemærk, at x86 Windows bruger "thiscall"-opkaldskonventionen til C++ -medlemfunktioner i stedet for standard "C"-opkaldskonventionen.
//
// Exception_copy-funktionen er lidt speciel her: den påberåbes af MSVC-runtime under en try/catch-blok, og den panic, som vi genererer her, bruges som resultat af undtagelseskopien.
//
// Dette bruges af C++ runtime til at understøtte indfangning af undtagelser med std::exception_ptr, som vi ikke kan understøtte, fordi Box<dyn Any>er ikke klonbar.
//
//
//
//
//
macro_rules! define_cleanup {
    ($abi:tt) => {
        unsafe extern $abi fn exception_cleanup(e: *mut Exception) {
            if let Exception { data: Some(b) } = e.read() {
                drop(b);
                super::__rust_drop_panic();
            }
        }
        #[unwind(allowed)]
        unsafe extern $abi fn exception_copy(_dest: *mut Exception,
                                             _src: *mut Exception)
                                             -> *mut Exception {
            panic!("Rust panics cannot be copied");
        }
    }
}
cfg_if::cfg_if! {
   if #[cfg(target_arch = "x86")] {
       define_cleanup!("thiscall");
   } else {
       define_cleanup!("C");
   }
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    use core::intrinsics::atomic_store;

    // _CxxThrowException udføres helt på denne stakramme, så der er ikke behov for ellers at overføre `data` til bunken.
    // Vi sender bare en stakmarkør til denne funktion.
    //
    // ManuallyDrop er nødvendig her, da vi ikke ønsker, at undtagelse skal droppes, når du afvikler.
    // I stedet vil det blive droppet af exception_cleanup, som påberåbes af C++ runtime.
    //
    //
    let mut exception = ManuallyDrop::new(Exception { data: Some(data) });
    let throw_ptr = &mut exception as *mut _ as *mut _;

    // Dette ... kan virke overraskende og med rette.På 32-bit MSVC er markørerne mellem disse strukturer netop det, pointer.
    // På 64-bit MSVC udtrykkes markørerne mellem strukturer imidlertid snarere som 32-bit forskydninger fra `__ImageBase`.
    //
    // Derfor kan vi på 32-bit MSVC erklære alle disse markører i 'statisk' ovenfor.
    // På 64-bit MSVC bliver vi nødt til at udtrykke subtraktion af markører i statik, som Rust ikke tillader i øjeblikket, så vi kan faktisk ikke gøre det.
    //
    // Den næstbedste ting er derefter at udfylde disse strukturer ved kørsel (panik er allerede "slow path" alligevel).
    // Så her fortolker vi alle disse markørfelter som 32-bit heltal og gemmer derefter den relevante værdi i den (atomisk, da samtidig panics kan ske).
    //
    // Teknisk set vil runtime sandsynligvis udføre en ikke-atomisk aflæsning af disse felter, men i teorien læser de aldrig den *forkerte* værdi, så det skal ikke være så dårligt ...
    //
    // Under alle omstændigheder er vi grundlæggende nødt til at gøre noget som dette, indtil vi kan udtrykke flere operationer i statik (og det kan vi muligvis aldrig gøre).
    //
    //
    //
    //
    //
    //
    //
    //
    atomic_store(&mut THROW_INFO.pmfnUnwind as *mut _ as *mut u32, ptr!(exception_cleanup) as u32);
    atomic_store(
        &mut THROW_INFO.pCatchableTypeArray as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE_ARRAY as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE_ARRAY.arrayOfCatchableTypes[0] as *mut _ as *mut u32,
        ptr!(&CATCHABLE_TYPE as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.pType as *mut _ as *mut u32,
        ptr!(&TYPE_DESCRIPTOR as *const _) as u32,
    );
    atomic_store(
        &mut CATCHABLE_TYPE.copyFunction as *mut _ as *mut u32,
        ptr!(exception_copy) as u32,
    );

    extern "system" {
        #[unwind(allowed)]
        fn _CxxThrowException(pExceptionObject: *mut c_void, pThrowInfo: *mut u8) -> !;
    }

    _CxxThrowException(throw_ptr, &mut THROW_INFO as *mut _ as *mut _);
}

pub unsafe fn cleanup(payload: *mut u8) -> Box<dyn Any + Send> {
    // En NULL nyttelast her betyder, at vi er kommet her fra fangsten (...) på __rust_try.
    // Dette sker, når en udenlandsk undtagelse, der ikke er Rust, er fanget.
    if payload.is_null() {
        super::__rust_foreign_exception();
    } else {
        let exception = &mut *(payload as *mut Exception);
        exception.data.take().unwrap()
    }
}

// Dette kræves af compileren for at eksistere (f.eks. Er det et lang element), men det kaldes aldrig af compileren, fordi __C_specific_handler eller_except_handler3 er den personlighedsfunktion, der altid bruges.
//
// Derfor er dette bare en afbrydende stub.
//
#[lang = "eh_personality"]
#[cfg(not(test))]
fn rust_eh_personality() {
    core::intrinsics::abort()
}