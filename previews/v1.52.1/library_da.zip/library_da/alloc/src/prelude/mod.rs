//! Tildelingen Prelude
//!
//! Formålet med dette modul er at lindre import af almindeligt anvendte genstande af `alloc` crate ved at tilføje en globimport til toppen af modulerne:
//!
//!
//! ```
//! # #![allow(unused_imports)]
//! #![feature(alloc_prelude)]
//! extern crate alloc;
//! use alloc::prelude::v1::*;
//! ```

#![unstable(feature = "alloc_prelude", issue = "58935")]

pub mod v1;