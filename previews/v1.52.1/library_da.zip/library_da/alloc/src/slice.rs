//! En dynamisk størrelse visning i en sammenhængende sekvens, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Skiver er et syn på en hukommelsesblok repræsenteret som en markør og en længde.
//!
//! ```
//! // skære en Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // tvinger en matrix til et udsnit
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Skiver kan enten ændres eller deles.
//! Den delte skivetype er `&[T]`, mens den skiftelige skivetype er `&mut [T]`, hvor `T` repræsenterer elementtypen.
//! For eksempel kan du mutere den hukommelsesblok, som en ændret skive peger på:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Her er nogle af de ting, dette modul indeholder:
//!
//! ## Structs
//!
//! Der er flere strukturer, der er nyttige til udsnit, såsom [`Iter`], som repræsenterer iteration over et udsnit.
//!
//! ## Trait Implementeringer
//!
//! Der er flere implementeringer af almindelige traits til skiver.Nogle eksempler inkluderer:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`] til skiver, hvis elementtype er [`Eq`] eller [`Ord`].
//! * [`Hash`] - til skiver, hvis elementtype er [`Hash`].
//!
//! ## Iteration
//!
//! Skiverne implementerer `IntoIterator`.Iteratoren giver henvisninger til skiveelementerne.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Den ændrede skive giver muterbare referencer til elementerne:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Denne iterator giver muterede referencer til udsnitets elementer, så mens elementets type er `i32`, er iteratorens elementtype `&mut i32`.
//!
//!
//! * [`.iter`] og [`.iter_mut`] er de eksplicitte metoder til at returnere standard iteratorerne.
//! * Yderligere metoder, der returnerer iteratorer, er [`.split`], [`.splitn`], [`.chunks`], [`.windows`] og mere.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Mange af anvendelserne i dette modul bruges kun i testkonfigurationen.
// Det er renere at bare slå advarslen unused_imports fra end at rette dem.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Grundlæggende metoder til udvidelse af udsnit
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) nødvendigt til implementering af `vec!` makro under test NB, se `hack` modulet i denne fil for flere detaljer.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) nødvendigt til implementering af `Vec::clone` under test NB, se `hack`-modulet i denne fil for flere detaljer.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Med cfg(test) `impl [T]` er ikke tilgængelig, disse tre funktioner er faktisk metoder, der er i `impl [T]`, men ikke i `core::slice::SliceExt`, vi skal levere disse funktioner til `test_permutations`-testen
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Vi bør ikke tilføje inline-attribut til dette, da dette hovedsagelig bruges i `vec!`-makro og forårsager perf regression.
    // Se #71204 for diskussion og perf. Resultater.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // Elementer blev mærket initialiseret i sløjfen nedenfor
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) er nødvendigt for LLVM at fjerne grænsekontrol og har bedre kodegenerer end zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // vec blev tildelt og initialiseret ovenfor til mindst denne længde.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // tildelt ovenfor med kapaciteten `s`, og initialiser til `s.len()` i ptr::copy_to_non_overlapping nedenfor.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Sorterer skiven.
    ///
    /// Denne slags er stabil (dvs. omarrangerer ikke lige store elementer) og *O*(*n*\*log(* n*)) worst-case.
    ///
    /// Når det er relevant, foretrækkes ustabil sortering, fordi den generelt er hurtigere end stabil sortering, og den ikke tildeler ekstra hukommelse.
    /// Se [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Nuværende implementering
    ///
    /// Den nuværende algoritme er en adaptiv, iterativ fusionssort inspireret af [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Det er designet til at være meget hurtigt i tilfælde, hvor udsnittet næsten er sorteret eller består af to eller flere sorterede sekvenser sammenkædet efter hinanden.
    ///
    ///
    /// Det tildeler også midlertidig lagring halvdelen af størrelsen på `self`, men for korte skiver bruges en ikke-tildelende indsættelsessort i stedet.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Sorterer skiven med en komparatorfunktion.
    ///
    /// Denne slags er stabil (dvs. omarrangerer ikke lige store elementer) og *O*(*n*\*log(* n*)) worst-case.
    ///
    /// Komparatorfunktionen skal definere en samlet rækkefølge for elementerne i udsnittet.Hvis ordren ikke er total, er rækkefølgen af elementerne uspecificeret.
    /// En ordre er en samlet ordre, hvis den er (for alle `a`, `b` og `c`):
    ///
    /// * total og antisymmetrisk: nøjagtigt en af `a < b`, `a == b` eller `a > b` er sand, og
    /// * transitive, `a < b` og `b < c` indebærer `a < c`.Det samme skal gælde for både `==` og `>`.
    ///
    /// For eksempel, mens [`f64`] ikke implementerer [`Ord`] fordi `NaN != NaN`, kan vi bruge `partial_cmp` som vores sorteringsfunktion, når vi ved, at udsnittet ikke indeholder en `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Når det er relevant, foretrækkes ustabil sortering, fordi den generelt er hurtigere end stabil sortering, og den ikke tildeler ekstra hukommelse.
    /// Se [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Nuværende implementering
    ///
    /// Den nuværende algoritme er en adaptiv, iterativ fusionssort inspireret af [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Det er designet til at være meget hurtigt i tilfælde, hvor udsnittet næsten er sorteret eller består af to eller flere sorterede sekvenser sammenkædet efter hinanden.
    ///
    /// Det tildeler også midlertidig lagring halvdelen af størrelsen på `self`, men for korte skiver bruges en ikke-tildelende indsættelsessort i stedet.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // omvendt sortering
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Sorterer skiven med en nøgleudvindingsfunktion.
    ///
    /// Denne sortering er stabil (dvs. omorganiserer ikke lige store elementer) og *O*(*m*\* * n *\* log(*n*)) worst-case, hvor nøglefunktionen er *O*(*m*).
    ///
    /// Til dyre nøglefunktioner (f.eks
    /// funktioner, der ikke er enkle ejendomsadgang eller grundlæggende handlinger), vil [`sort_by_cached_key`](slice::sort_by_cached_key) sandsynligvis være betydeligt hurtigere, da det ikke genberegner elementtaster.
    ///
    ///
    /// Når det er relevant, foretrækkes ustabil sortering, fordi den generelt er hurtigere end stabil sortering, og den ikke tildeler ekstra hukommelse.
    /// Se [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Nuværende implementering
    ///
    /// Den nuværende algoritme er en adaptiv, iterativ fusionssort inspireret af [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Det er designet til at være meget hurtigt i tilfælde, hvor udsnittet næsten er sorteret eller består af to eller flere sorterede sekvenser sammenkædet efter hinanden.
    ///
    /// Det tildeler også midlertidig lagring halvdelen af størrelsen på `self`, men for korte skiver bruges en ikke-tildelende indsættelsessort i stedet.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Sorterer skiven med en nøgleudvindingsfunktion.
    ///
    /// Under sortering kaldes nøglefunktionen kun én gang pr. Element.
    ///
    /// Denne sortering er stabil (dvs. omorganiserer ikke lige store elementer) og *O*(*m*\* * n *+* n *\* log(*n*)) worst-case, hvor nøglefunktionen er *O*(*m*) .
    ///
    /// For enkle nøglefunktioner (f.eks. Funktioner, der er adgang til ejendom eller grundlæggende handlinger), er [`sort_by_key`](slice::sort_by_key) sandsynligvis hurtigere.
    ///
    /// # Nuværende implementering
    ///
    /// Den nuværende algoritme er baseret på [pattern-defeating quicksort][pdqsort] af Orson Peters, som kombinerer det hurtige gennemsnitstilfælde af randomiseret quicksort med det hurtigste værste tilfælde af heapsort, samtidig med at der opnås lineær tid på skiver med visse mønstre.
    /// Det bruger en vis randomisering for at undgå degenererede tilfælde, men med en fast seed til altid at give deterministisk adfærd.
    ///
    /// I værste fald tildeler algoritmen midlertidig lagring i en `Vec<(K, usize)>` længden af udsnittet.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Hjælpemakro til indeksering af vores vector efter den mindst mulige type for at reducere allokering.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Elementerne i `indices` er unikke, da de er indekseret, så enhver slags vil være stabil i forhold til den originale skive.
                // Vi bruger `sort_unstable` her, fordi det kræver mindre hukommelsestildeling.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Kopierer `self` til en ny `Vec`.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Her kan `s` og `x` ændres uafhængigt.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Kopierer `self` til en ny `Vec` med en allokator.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Her kan `s` og `x` ændres uafhængigt.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, se `hack`-modulet i denne fil for flere detaljer.
        hack::to_vec(self, alloc)
    }

    /// Konverterer `self` til en vector uden kloner eller allokering.
    ///
    /// Den resulterende vector kan konverteres tilbage til en kasse via `Vec<T>`into_boxed_slice`-metoden.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` kan ikke bruges mere, fordi den er blevet konverteret til `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, se `hack`-modulet i denne fil for flere detaljer.
        hack::into_vec(self)
    }

    /// Opretter en vector ved at gentage et stykke `n` gange.
    ///
    /// # Panics
    ///
    /// Denne funktion vil panic, hvis kapaciteten ville løbe over.
    ///
    /// # Examples
    ///
    /// Grundlæggende brug:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// En panic ved overløb:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Hvis `n` er større end nul, kan den opdeles som `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` er tallet repræsenteret af '1' bit til venstre i `n`, og `rem` er den resterende del af `n`.
        //
        //

        // Brug af `Vec` til at få adgang til `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` gentagelse sker ved at fordoble `buf` `expn`-gange.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Hvis `m > 0`, er der resterende bits op til den længste venstre '1'.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` har kapacitet på `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) gentagelse udføres ved at kopiere de første `rem` gentagelser fra selve `buf`.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Dette er ikke-overlappende siden `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` svarer til `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Fladder et stykke `T` i en enkelt værdi `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Fladder et stykke `T` i en enkelt værdi `Self::Output`, hvor en given separator placeres mellem hver.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Fladder et stykke `T` i en enkelt værdi `Self::Output`, hvor en given separator placeres mellem hver.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Returnerer en vector, der indeholder en kopi af dette udsnit, hvor hver byte er tilknyttet dets tilsvarende ASCII-store bogstaver.
    ///
    ///
    /// ASCII-bogstaver 'a' til 'z' er kortlagt til 'A' til 'Z', men ikke-ASCII-bogstaver er uændrede.
    ///
    /// Brug [`make_ascii_uppercase`] for at opskifte værdien på stedet.
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Returnerer en vector, der indeholder en kopi af dette udsnit, hvor hver byte er kortlagt til dets ASCII-ækvivalent.
    ///
    ///
    /// ASCII-bogstaver 'A' til 'Z' kortlægges til 'a' til 'z', men ikke-ASCII-bogstaver er uændrede.
    ///
    /// Brug [`make_ascii_lowercase`] til at gemme værdien på plads.
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Udvidelse traits til udsnit over specifikke typer data
////////////////////////////////////////////////////////////////////////////////

/// Hjælper trait for [`[T]: : concat`](udsnit::concat).
///
/// Note: `Item`-parameteren bruges ikke i denne trait, men den tillader, at impls er mere generiske.
/// Uden det får vi denne fejl:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Dette skyldes, at der kunne eksistere `V`-typer med flere `Borrow<[_]>`-impls, således at flere `T`-typer ville gælde:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Den resulterende type efter sammenkædning
    type Output;

    /// Implementering af [`[T]: : concat`](udsnit::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Hjælper trait for [`[T]: : join`](udsnit::join)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Den resulterende type efter sammenkædning
    type Output;

    /// Implementering af [`[T]: : join`](udsnit::join)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Standard trait implementeringer til skiver
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // slip noget i målet, der ikke overskrives
        target.truncate(self.len());

        // target.len <= self.len på grund af afkortningen ovenfor, så skiverne her er altid inden for rammerne.
        //
        let (init, tail) = self.split_at(target.len());

        // genbrug de indeholdte værdier allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Indsætter `v[0]` i den for-sorterede sekvens `v[1..]`, så hele `v[..]` bliver sorteret.
///
/// Dette er den integrerede subrutine for indsættelsessortering.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Der er tre måder at implementere indsættelse her:
            //
            // 1. Byt tilstødende elementer, indtil den første kommer til sin endelige destination.
            //    Men på denne måde kopierer vi data mere end nødvendigt.
            //    Hvis elementerne er store strukturer (dyre at kopiere), vil denne metode være langsom.
            //
            // 2. Iterér indtil det rigtige sted for det første element er fundet.
            // Skift derefter elementerne efterfulgt af det for at give plads til det og placer det til sidst i det resterende hul.
            // Dette er en god metode.
            //
            // 3. Kopier det første element til en midlertidig variabel.Iterér indtil det rigtige sted for det er fundet.
            // Når vi går sammen, skal du kopiere hvert gennemkørt element ind i spalten forud for det.
            // Endelig kopierer du data fra den midlertidige variabel til det resterende hul.
            // Denne metode er meget god.
            // Benchmarks viste lidt bedre ydeevne end med 2. metode.
            //
            // Alle metoder blev benchmarket, og den 3. viste de bedste resultater.Så vi valgte den ene.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Mellemstatus for indsættelsesprocessen spores altid af `hole`, som tjener to formål:
            // 1. Beskytter integriteten af `v` fra panics i `is_less`.
            // 2. Fylder det resterende hul i `v` til sidst.
            //
            // Panic sikkerhed:
            //
            // Hvis `is_less` panics på et hvilket som helst tidspunkt under processen, vil `hole` falde ned og fylde hullet i `v` med `tmp`, hvilket sikrer, at `v` stadig holder hvert objekt, det oprindeligt holdt nøjagtigt en gang.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` bliver droppet og kopierer således `tmp` i det resterende hul i `v`.
        }
    }

    // Når de smides, kopieres fra `src` til `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Fletter ikke-faldende kørsler `v[..mid]` og `v[mid..]` ved hjælp af `buf` som midlertidig lagring og gemmer resultatet i `v[..]`.
///
/// # Safety
///
/// De to skiver skal være tomme og `mid` skal være inden for grænserne.
/// Buffer `buf` skal være lang nok til at indeholde en kopi af det kortere stykke.
/// `T` må heller ikke være af nul størrelse.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Fusionsprocessen kopierer først det kortere løb til `buf`.
    // Derefter spores den nyligt kopierede kørsel og den længere kørsel fremad (eller baglæns), sammenligner deres næste uforbrugte elementer og kopierer den mindre (eller større) til `v`.
    //
    // Så snart det kortere løb er fuldt forbrugt, er processen færdig.Hvis den længere løb bliver forbrugt først, skal vi kopiere det, der er tilbage af den kortere løb, i det resterende hul i `v`.
    //
    // Den mellemliggende tilstand af processen spores altid af `hole`, som tjener to formål:
    // 1. Beskytter integriteten af `v` fra panics i `is_less`.
    // 2. Fylder det resterende hul i `v`, hvis den længere løb bliver forbrugt først.
    //
    // Panic sikkerhed:
    //
    // Hvis `is_less` panics på et hvilket som helst tidspunkt under processen, vil `hole` falde ned og udfylde hullet i `v` med det uforbrugte interval i `buf`, hvilket sikrer, at `v` stadig holder hvert objekt, det oprindeligt holdt nøjagtigt en gang.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Venstre løb er kortere.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Oprindeligt peger disse henvisninger på begyndelsen af deres arrays.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Forbruge den mindre side.
            // Hvis det er lige, foretrækker du venstre løb for at opretholde stabilitet.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Den rigtige løbetur er kortere.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Oprindeligt peger disse markører forbi enderne af deres arrays.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Forbruge den større side.
            // Hvis det er lige, foretrækker det rigtige løb for at opretholde stabilitet.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Endelig bliver `hole` droppet.
    // Hvis det kortere løb ikke blev brugt fuldt ud, kopieres det, der stadig er tilbage, til hullet i `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Når det falder ned, kopieres området `start..end` til `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` er ikke en type af nul størrelse, så det er okay at dividere med dens størrelse.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Denne fusionssort låner nogle (men ikke alle) ideer fra TimSort, som er beskrevet detaljeret [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// Algoritmen identificerer strengt faldende og ikke-faldende efterfølgende, som kaldes naturlige kørsler.Der er en stak af ventende kørsler, der endnu ikke skal flettes.
/// Hver nyligt fundet kørsel skubbes på stakken, og derefter flettes nogle par tilstødende kørsler, indtil disse to invarianter er tilfredse:
///
/// 1. for hver `i` i `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. for hver `i` i `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Invarianterne sikrer, at den samlede køretid er *O*(*n*\*log(* n*)) worst-case.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Skiver på op til denne længde sorteres ved hjælp af indsættelsessortering.
    const MAX_INSERTION: usize = 20;
    // Meget korte kørsler udvides ved hjælp af indsætningssortering for at spænde i det mindste så mange elementer.
    const MIN_RUN: usize = 10;

    // Sortering har ingen meningsfuld opførsel på typer med nulstørrelse.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Korte arrays sorteres på plads via indsættelsessortering for at undgå allokeringer.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Tildel en buffer, der skal bruges som ridsehukommelse.Vi beholder længden 0, så vi kan gemme den i overfladiske kopier af indholdet af `v` uden at risikere, at lægerne kører på kopier, hvis `is_less` panics.
    //
    // Når du fletter to sorterede kørsler, indeholder denne buffer en kopi af den kortere kørsel, som altid har længden på højst `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // For at identificere naturlige kørsler i `v` krydser vi det baglæns.
    // Det kan virke som en underlig beslutning, men overvej det faktum, at fusioner oftere går i den modsatte retning (forwards).
    // Ifølge benchmarks er sammenlægning fremad lidt hurtigere end sammenlægning bagud.
    // Afslutningsvis forbedrer identifikationen af kørsler ved at køre bagud ydeevnen.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Find det næste naturlige løb, og vend det, hvis det strengt faldende.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Indsæt nogle flere elementer i løbet, hvis det er for kort.
        // Indsættelsessortering er hurtigere end flettsortering på korte sekvenser, så dette forbedrer ydeevnen betydeligt.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Skub dette løb på stakken.
        runs.push(Run { start, len: end - start });
        end = start;

        // Flet nogle par tilstødende kørsler for at tilfredsstille invarianterne.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Endelig skal nøjagtigt et løb forblive i stakken.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Undersøger stakken af kørsler og identificerer det næste par kørsler, der skal flettes.
    // Mere specifikt, hvis `Some(r)` returneres, betyder det, at `runs[r]` og `runs[r + 1]` skal flettes næste.
    // Hvis algoritmen fortsætter med at opbygge en ny kørsel i stedet, returneres `None`.
    //
    // TimSort er berygtet for sine buggy-implementeringer, som beskrevet her:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Historiens kerne er: vi skal håndhæve invarianterne på de fire øverste kørsler på stakken.
    // Håndhævelse af dem på bare top tre er ikke tilstrækkelig til at sikre, at invarianterne stadig holder *alle* kørsler i stakken.
    //
    // Denne funktion kontrollerer korrekt invarianter for de top fire kørsler.
    // Derudover, hvis topkørslen starter ved indeks 0, vil det altid kræve en fletningsoperation, indtil stakken er fuldt sammenklappet for at fuldføre sorteringen.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}