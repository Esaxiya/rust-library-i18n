#![stable(feature = "wake_trait", since = "1.51.0")]
//! Typer og Traits til arbejde med asynkrone opgaver.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Implementeringen af at vække en opgave på en eksekutor.
///
/// Denne trait kan bruges til at oprette en [`Waker`].
/// En eksekutor kan definere en implementering af denne trait og bruge den til at konstruere en Waker til at overføre de opgaver, der udføres på den eksekutor.
///
/// Denne trait er et hukommelsessikkert og ergonomisk alternativ til at konstruere en [`RawWaker`].
/// Det understøtter det almindelige eksekutørdesign, hvor de data, der bruges til at vække en opgave, er gemt i en [`Arc`].
/// Nogle eksekutorer (især dem til indlejrede systemer) kan ikke bruge denne API, hvorfor [`RawWaker`] findes som et alternativ til disse systemer.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// En grundlæggende `block_on`-funktion, der tager en future og kører den til færdiggørelse på den aktuelle tråd.
///
/// **Note:** Dette eksempel handler korrekthed for enkelhed.
/// For at forhindre blokeringer skal implementeringer af produktionskvalitet også håndtere mellemliggende opkald til `thread::unpark` såvel som indlejrede indkaldelser.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// En waker, der vækker den aktuelle tråd, når den kaldes.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Kør en future til færdiggørelse på den aktuelle tråd.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Fastgør future, så den kan polles.
///     let mut fut = Box::pin(fut);
///
///     // Opret en ny kontekst, der skal sendes til future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Kør future til færdiggørelse.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Væk denne opgave.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Vågn denne opgave uden at forbruge vækkeren.
    ///
    /// Hvis en eksekutor understøtter en billigere måde at vågne op uden at forbruge waker, bør den tilsidesætte denne metode.
    /// Som standard kloner den [`Arc`] og kalder [`wake`] på klonen.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // SIKKERHED: Dette er sikkert, fordi raw_waker konstruerer sikkert
        // en RawWaker fra Arc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Denne private funktion til konstruktion af en RawWaker bruges snarere end
// indlejring af dette i `From<Arc<W>> for RawWaker`-impl. for at sikre, at sikkerheden ved `From<Arc<W>> for Waker` ikke afhænger af den korrekte trait-forsendelse, i stedet kalder begge impls denne funktion direkte og eksplicit.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Forøg referencetallet for buen for at klone den.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Vågn efter værdi, flyt Arcen til Wake::wake-funktionen
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Vågn ved henvisning, pak wakeren i ManuallyDrop for at undgå at tabe den
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Reducer referencetællingen for buen ved fald
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}