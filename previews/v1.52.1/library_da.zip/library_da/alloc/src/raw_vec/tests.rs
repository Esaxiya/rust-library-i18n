use super::*;
use std::cell::Cell;

#[test]
fn allocator_param() {
    use crate::alloc::AllocError;

    // At skrive en test af integration mellem tredjepartsallokatorer og `RawVec` er lidt vanskelig, fordi `RawVec` API ikke udsætter fejlbare tildelingsmetoder, så vi kan ikke kontrollere, hvad der sker, når allokeringen er opbrugt (ud over at detektere en panic).
    //
    //
    // I stedet kontrollerer dette bare, at `RawVec`-metoderne i det mindste går gennem Allocator API, når det reserverer lager.
    //
    //
    //
    //
    //

    // En dum fordeling, der bruger en fast mængde brændstof, før tildelingsforsøg begynder at mislykkes.
    //
    struct BoundedAlloc {
        fuel: Cell<usize>,
    }
    unsafe impl Allocator for BoundedAlloc {
        fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
            let size = layout.size();
            if size > self.fuel.get() {
                return Err(AllocError);
            }
            match Global.allocate(layout) {
                ok @ Ok(_) => {
                    self.fuel.set(self.fuel.get() - size);
                    ok
                }
                err @ Err(_) => err,
            }
        }
        unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
            unsafe { Global.deallocate(ptr, layout) }
        }
    }

    let a = BoundedAlloc { fuel: Cell::new(500) };
    let mut v: RawVec<u8, _> = RawVec::with_capacity_in(50, a);
    assert_eq!(v.alloc.fuel.get(), 450);
    v.reserve(50, 150); // (forårsager en reallokering og bruger således 50 + 150=200 enheder brændstof)
    assert_eq!(v.alloc.fuel.get(), 250);
}

#[test]
fn reserve_does_not_overallocate() {
    {
        let mut v: RawVec<u32> = RawVec::new();
        // For det første tildeler `reserve` ligesom `reserve_exact`.
        v.reserve(0, 9);
        assert_eq!(9, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 7);
        assert_eq!(7, v.capacity());
        // 97 er mere end det dobbelte af 7, så `reserve` skal fungere som `reserve_exact`.
        //
        v.reserve(7, 90);
        assert_eq!(97, v.capacity());
    }

    {
        let mut v: RawVec<u32> = RawVec::new();
        v.reserve(0, 12);
        assert_eq!(12, v.capacity());
        v.reserve(12, 3);
        // 3 er mindre end halvdelen af 12, så `reserve` skal vokse eksponentielt.
        // På tidspunktet for skrivningen er denne test vækstfaktor 2, så ny kapacitet er 24, men vækstfaktor på 1.5 er også OK.
        //
        // Derfor er `>= 18` påstået.
        assert!(v.capacity() >= 12 + 12 / 2);
    }
}