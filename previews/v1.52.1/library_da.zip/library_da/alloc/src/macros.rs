/// Opretter en [`Vec`], der indeholder argumenterne.
///
/// `vec!` tillader at 'Vec`s defineres med den samme syntaks som array-udtryk.
/// Der er to former for denne makro:
///
/// - Opret en [`Vec`], der indeholder en given liste over elementer:
///
/// ```
/// let v = vec![1, 2, 3];
/// assert_eq!(v[0], 1);
/// assert_eq!(v[1], 2);
/// assert_eq!(v[2], 3);
/// ```
///
/// - Opret en [`Vec`] fra et givet element og størrelse:
///
/// ```
/// let v = vec![1; 3];
/// assert_eq!(v, [1, 1, 1]);
/// ```
///
/// Bemærk, at i modsætning til array-udtryk understøtter denne syntaks alle elementer, der implementerer [`Clone`], og antallet af elementer behøver ikke at være konstant.
///
/// Dette bruger `clone` til at duplikere et udtryk, så man skal være forsigtig med at bruge dette med typer, der har en ikke-standard `Clone`-implementering.
/// For eksempel `vec![Rc::new(1);5] `opretter en vector med fem referencer til den samme boksede heltalværdi, ikke fem referencer, der peger på uafhængigt heltal i boks.
///
///
/// Bemærk også, at `vec![expr; 0]` er tilladt og producerer en tom vector.
/// Dette vil dog stadig evaluere `expr` og straks slippe den resulterende værdi, så vær opmærksom på bivirkninger.
///
/// [`Vec`]: crate::vec::Vec
///
///
///
///
///
#[cfg(not(test))]
#[doc(alias = "alloc")]
#[doc(alias = "malloc")]
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow_internal_unstable(box_syntax, liballoc_internals)]
macro_rules! vec {
    () => (
        $crate::__rust_force_expr!($crate::vec::Vec::new())
    );
    ($elem:expr; $n:expr) => (
        $crate::__rust_force_expr!($crate::vec::from_elem($elem, $n))
    );
    ($($x:expr),+ $(,)?) => (
        $crate::__rust_force_expr!(<[_]>::into_vec(box [$($x),+]))
    );
}

// HACK(japaric): med cfg(test) er den iboende `[T]::into_vec`-metode, som kræves til denne makrodefinition, ikke tilgængelig.
// Brug i stedet `slice::into_vec`-funktionen, som kun er tilgængelig med cfg(test) NB Se slice::hack-modulet i slice.rs for mere information
//
//
#[cfg(test)]
macro_rules! vec {
    () => (
        $crate::vec::Vec::new()
    );
    ($elem:expr; $n:expr) => (
        $crate::vec::from_elem($elem, $n)
    );
    ($($x:expr),*) => (
        $crate::slice::into_vec(box [$($x),*])
    );
    ($($x:expr,)*) => (vec![$($x),*])
}

/// Opretter en `String` ved hjælp af interpolering af runtime-udtryk.
///
/// Det første argument `format!` modtager er en formatstreng.Dette skal være en streng bogstavelig.Formateringsstrengens styrke er i `` {} 's indeholdt.
///
/// Yderligere parametre, der sendes til `format!`, erstatter '{}' s inden for formateringsstrengen i den angivne rækkefølge, medmindre navngivne eller positionsparametre bruges;se [`std::fmt`] for mere information.
///
///
/// En almindelig anvendelse af `format!` er sammenkædning og interpolering af strenge.
/// Den samme konvention bruges med [`print!`]-og [`write!`]-makroer afhængigt af strengens tilsigtede destination.
///
/// Brug [`to_string`]-metoden til at konvertere en enkelt værdi til en streng.Dette bruger [`Display`]-formateringen trait.
///
/// [`std::fmt`]: ../std/fmt/index.html
/// [`print!`]: ../std/macro.print.html
/// [`write!`]: core::write
/// [`to_string`]: crate::string::ToString
/// [`Display`]: core::fmt::Display
///
/// # Panics
///
/// `format!` panics hvis en formatering af trait-implementering returnerer en fejl.
/// Dette indikerer en forkert implementering, da `fmt::Write for String` aldrig selv returnerer en fejl.
///
/// # Examples
///
/// ```
/// format!("test");
/// format!("hello {}", "world!");
/// format!("x = {}, y = {y}", 10, y = 30);
/// ```
///
///
///
///
///
#[macro_export]
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "format_macro")]
macro_rules! format {
    ($($arg:tt)*) => {{
        let res = $crate::fmt::format($crate::__export::format_args!($($arg)*));
        res
    }}
}

/// Tving AST-knude til et udtryk for at forbedre diagnostik i mønsterposition.
#[doc(hidden)]
#[macro_export]
#[unstable(feature = "liballoc_internals", issue = "none", reason = "implementation detail")]
macro_rules! __rust_force_expr {
    ($e:expr) => {
        $e
    };
}