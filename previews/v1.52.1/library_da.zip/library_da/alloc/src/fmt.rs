//! Hjælpeprogrammer til formatering og udskrivning af `String`s.
//!
//! Dette modul indeholder understøttelse af runtime til [`format!`]-syntaksudvidelsen.
//! Denne makro implementeres i compileren for at udsende opkald til dette modul for at formatere argumenter ved kørsel i strenge.
//!
//! # Usage
//!
//! [`format!`]-makroen er beregnet til at være kendt for dem, der kommer fra Cs `printf`/`fprintf`-funktioner eller Python s `str.format`-funktion.
//!
//! Nogle eksempler på [`format!`]-udvidelsen er:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" med førende nuller
//! ```
//!
//! Fra disse kan du se, at det første argument er en formatstreng.Det kræves af compileren, at dette er en streng bogstavelig;det kan ikke være en variabel, der sendes ind (for at udføre gyldighedskontrol).
//! Compileren analyserer derefter formatstrengen og bestemmer, om listen med argumenter, der er angivet, er egnet til at overføres til denne formatstreng.
//!
//! Brug [`to_string`]-metoden til at konvertere en enkelt værdi til en streng.Dette bruger [`Display`]-formateringen trait.
//!
//! ## Positionsparametre
//!
//! Hvert formateringsargument får lov til at specificere, hvilket værdiargument det refererer til, og hvis det udelades antages det at være "the next argument".
//! For eksempel vil formatstrengen `{} {} {}` tage tre parametre, og de vil blive formateret i samme rækkefølge som de er givet.
//! Formatstrengen `{2} {1} {0}` vil dog formatere argumenter i omvendt rækkefølge.
//!
//! Ting kan blive lidt vanskelige, når du begynder at blande de to typer positionsspecifikatorer."next argument"-specifikatoren kan betragtes som en iterator over argumentet.
//! Hver gang en "next argument"-specifikator ses, rykker iteratoren frem.Dette fører til adfærd som denne:
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Den interne iterator over argumentet er ikke blevet avanceret, da den første `{}` ses, så den udskriver det første argument.Derefter når iteratoren har nået den anden `{}`, er den kommet videre til det andet argument.
//! I det væsentlige påvirker parametre, der udtrykkeligt navngiver deres argument, ikke parametre, der ikke navngiver et argument med hensyn til positionsspecifikatorer.
//!
//! En formatstreng kræves for at bruge alle dens argumenter, ellers er det en kompileringstidsfejl.Du kan henvise til det samme argument mere end én gang i formatstrengen.
//!
//! ## Navngivne parametre
//!
//! Rust i sig selv har ikke en Python-lignende ækvivalent af navngivne parametre til en funktion, men [`format!`]-makroen er en syntaksudvidelse, der gør det muligt at udnytte navngivne parametre.
//! Navngivne parametre er anført i slutningen af argumentlisten og har syntaksen:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! For eksempel bruger følgende [`format!`]-udtryk alle navngivne argumenter:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Det er ikke gyldigt at placere positionsparametre (dem uden navne) efter argumenter, der har navne.Som med positionsparametre er det ikke gyldigt at angive navngivne parametre, der ikke bruges af formatstrengen.
//!
//! # Formatering af parametre
//!
//! Hvert argument, der formateres, kan omdannes med et antal formateringsparametre (svarende til `format_spec` i [the syntax](#syntax)). Disse parametre påvirker strengrepræsentationen af det, der formateres.
//!
//! ## Width
//!
//! ```
//! // Alle disse udskriver "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Dette er en parameter til "minimum width", som formatet skal tage op.
//! Hvis værdiens streng ikke udfylder så mange tegn, vil den polstring, der er angivet af fill/alignment, blive brugt til at optage den nødvendige plads (se nedenfor).
//!
//! Værdien for bredden kan også angives som en [`usize`] i listen over parametre ved at tilføje et postfix `$`, hvilket indikerer, at det andet argument er en [`usize`], der angiver bredden.
//!
//! Henvisning til et argument med dollar-syntaksen påvirker ikke "next argument"-tælleren, så det er normalt en god ide at henvise til argumenter efter position eller bruge navngivne argumenter.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Valgfri udfyldningskarakter og justering leveres normalt sammen med [`width`](#width)-parameteren.Det skal defineres før `width`, lige efter `:`.
//! Dette indikerer, at hvis den værdi, der formateres, er mindre end `width`, vil der blive udskrevet nogle ekstra tegn omkring den.
//! Fyldning findes i følgende varianter til forskellige justeringer:
//!
//! * `[fill]<` - argumentet er venstrejusteret i `width`-kolonner
//! * `[fill]^` - argumentet er centreret i `width`-kolonner
//! * `[fill]>` - argumentet er højrejusteret i `width`-kolonner
//!
//! Standard [fill/alignment](#fillalignment) for ikke-numerik er et mellemrum og venstrejusteret.Standard for numeriske formater er også et mellemrumstegn, men med højrejustering.
//! Hvis `0`-flag (se nedenfor) er specificeret for numerik, er det implicitte udfyldningstegn `0`.
//!
//! Bemærk, at justering muligvis ikke implementeres af nogle typer.Især er det generelt ikke implementeret til `Debug` trait.
//! En god måde at sikre, at der anvendes polstring, er at formatere dit input og derefter putte denne resulterende streng for at få din output:
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Hej Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Disse er alle flag, der ændrer formaterings opførsel.
//!
//! * `+` - Dette er beregnet til numeriske typer og indikerer, at tegnet altid skal udskrives.Positive tegn udskrives aldrig som standard, og det negative tegn udskrives kun som standard for `Signed` trait.
//! Dette flag angiver, at det korrekte tegn (`+` eller `-`) altid skal udskrives.
//! * `-` - I øjeblikket ikke brugt
//! * `#` - Dette flag angiver, at "alternate"-udskrivningsformen skal bruges.De alternative former er:
//!     * `#?` - udskriv [`Debug`]-formateringen pænt
//!     * `#x` - går foran argumentet med en `0x`
//!     * `#X` - går foran argumentet med en `0x`
//!     * `#b` - går foran argumentet med en `0b`
//!     * `#o` - går foran argumentet med en `0o`
//! * `0` - Dette bruges til at angive for heltalformater, at polstring til `width` både skal udføres med et `0`-tegn såvel som at være tegn-opmærksom.
//! Et format som `{:08}` ville give `00000001` for heltal `1`, mens det samme format ville give `-0000001` for heltal `-1`.
//! Bemærk, at den negative version har et færre nul end den positive version.
//!         Bemærk, at polstringsnuller altid placeres efter tegnet (hvis der er noget) og før cifrene.Når det bruges sammen med `#`-flag, gælder en lignende regel: polstringsnuller indsættes efter præfikset, men før cifrene.
//!         Præfikset er inkluderet i den samlede bredde.
//!
//! ## Precision
//!
//! For ikke-numeriske typer kan dette betragtes som en "maximum width".
//! Hvis den resulterende streng er længere end denne bredde, afkortes den ned til så mange tegn, og den afkortede værdi udsendes med korrekt `fill`, `alignment` og `width`, hvis disse parametre er indstillet.
//!
//! For integrale typer ignoreres dette.
//!
//! For flydende punkttyper angiver dette, hvor mange cifre der skal udskrives efter decimaltegnet.
//!
//! Der er tre mulige måder at specificere den ønskede `precision` på:
//!
//! 1. Et heltal `.N`:
//!
//!    hele `N` i sig selv er præcisionen.
//!
//! 2. Et heltal eller navn efterfulgt af dollartegn `.N$`:
//!
//!    brug format *argument*`N` (som skal være en `usize`) som præcision.
//!
//! 3. En stjerne `.*`:
//!
//!    `.*` betyder, at denne `{...}` er forbundet med *to* formatindgange snarere end en: den første indgang holder `usize`-præcisionen, og den anden indeholder værdien, der skal udskrives.
//!    Bemærk, at i dette tilfælde, hvis man bruger formatstrengen `{<arg>:<spec>.*}`, henviser `<arg>`-delen til*-værdien *, der skal udskrives, og `precision` skal komme i inputet før `<arg>`.
//!
//! For eksempel udskriver følgende opkald alle de samme ting `Hello x is 0.01000`:
//!
//! ```
//! // Hej {arg 0 ("x")} er {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Hej {arg 1 ("x")} er {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Hej {arg 0 ("x")} er {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Hej {next arg ("x")} er {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Hej {next arg ("x")} er {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Hej {next arg ("x")} er {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Mens disse:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! udskriv tre væsentligt forskellige ting:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! I nogle programmeringssprog afhænger opførslen af strengformateringsfunktioner af operativsystemets lokalindstilling.
//! Formatfunktionerne leveret af Rust s standardbibliotek har ikke noget landestandardbegreb og vil producere de samme resultater på alle systemer uanset brugerkonfiguration.
//!
//! For eksempel vil følgende kode altid udskrive `1.5`, selvom systemets sprog bruger en anden decimalseparator end en prik.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! De bogstavelige tegn `{` og `}` kan inkluderes i en streng ved at gå foran dem med det samme tegn.For eksempel undslippes `{`-tegnet med `{{`, og `}`-tegnet undslippes med `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! For at opsummere, her kan du finde den fulde grammatik af formatstrenge.
//! Syntaksen for det anvendte formateringssprog hentes fra andre sprog, så det bør ikke være for fremmed.Argumenter er formateret med Python-lignende syntaks, hvilket betyder at argumenter er omgivet af `{}` i stedet for den C-lignende `%`.
//! Den aktuelle grammatik for formateringens syntaks er:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! I ovenstående grammatik indeholder `text` muligvis ikke `'{'`-eller `'}'`-tegn.
//!
//! # Formatering af traits
//!
//! Når du anmoder om, at et argument formateres med en bestemt type, beder du faktisk om, at et argument tilskrives en bestemt trait.
//! Dette gør det muligt at formatere flere faktiske typer via `{:x}` (som [`i8`] såvel som [`isize`]).Den aktuelle kortlægning af typer til traits er:
//!
//! * *intet* ⇒ [`Display`]
//! * `?` ⇒ [`Debug`]
//! * `x?` ⇒ [`Debug`] med små og små hexadecimale heltal
//! * `X?` ⇒ [`Debug`] med store og små hexadecimale heltal
//! * `o` ⇒ [`Octal`]
//! * `x` ⇒ [`LowerHex`]
//! * `X` ⇒ [`UpperHex`]
//! * `p` ⇒ [`Pointer`]
//! * `b` ⇒ [`Binary`]
//! * `e` ⇒ [`LowerExp`]
//! * `E` ⇒ [`UpperExp`]
//!
//! Hvad dette betyder er, at enhver form for argument, der implementerer [`fmt::Binary`][`Binary`] trait, derefter kan formateres med `{:b}`.Implementeringer leveres til disse traits til et antal primitive typer også af standardbiblioteket.
//!
//! Hvis der ikke er angivet noget format (som i `{}` eller `{:6}`), er formatet trait det anvendte [`Display`] trait.
//!
//! Når du implementerer et format trait til din egen type, bliver du nødt til at implementere en metode til signaturen:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // vores brugerdefinerede type
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Din type sendes som `self`-reference, og derefter skal funktionen udsende output til `f.buf`-strømmen.Det er op til hvert format trait-implementering at korrekt overholde de ønskede formateringsparametre.
//! Værdierne for disse parametre vises i felterne i [`Formatter`]-strukturen.For at hjælpe med dette giver [`Formatter`]-strukturen også nogle hjælpermetoder.
//!
//! Derudover er returværdien af denne funktion [`fmt::Result`], som er et typealias for [`Resultat`]`<(),`[`std: : fmt::Error`] `>`.
//! Formatering af implementeringer skal sikre, at de udbreder fejl fra [`Formatter`] (f.eks. Når du ringer til [`write!`]).
//! De bør dog aldrig returnere fejl falsk.
//! Det vil sige, at en formateringsimplementering kun må returnere en fejl, hvis den indsendte [`Formatter`] returnerer en fejl.
//! Dette skyldes, i modsætning til hvad funktionssignaturen kan antyde, er strengformatering en ufejlbarlig handling.
//! Denne funktion returnerer kun et resultat, fordi skrivning til den underliggende strøm muligvis mislykkes, og det skal give en måde at formidle det faktum, at der er opstået en fejl tilbage i stakken.
//!
//! Et eksempel på implementering af formateringen traits vil se ud:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // `f`-værdien implementerer `Write` trait, hvilket er hvad der skrives!makro forventer.
//!         // Bemærk, at denne formatering ignorerer de forskellige flag, der leveres til formatering af strenge.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Forskellige traits tillader forskellige former for output af en type.
//! // Betydningen af dette format er at udskrive størrelsen af en vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Respekter formateringsflagene ved hjælp af hjælpemetoden `pad_integral` på Formatter-objektet.
//!         // Se metodedokumentationen for detaljer, og funktionen `pad` kan bruges til at padde strenge.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` mod `fmt::Debug`
//!
//! Disse to formateringer traits har forskellige formål:
//!
//! - [`fmt::Display`][`Display`] implementeringer hævder, at typen altid kan repræsenteres som en UTF-8-streng.Det forventes **ikke**, at alle typer implementerer [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] implementeringer skal implementeres for **alle** offentlige typer.
//!   Output repræsenterer typisk den interne tilstand så trofast som muligt.
//!   Formålet med [`Debug`] trait er at lette fejlretning af Rust-koden.I de fleste tilfælde er det tilstrækkeligt og anbefales at bruge `#[derive(Debug)]`.
//!
//! Nogle eksempler på output fra begge traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Relaterede makroer
//!
//! Der er et antal relaterede makroer i [`format!`]-familien.Dem, der i øjeblikket er implementeret, er:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Dette og [`writeln!`] er to makroer, der bruges til at udsende formatstrengen til en bestemt strøm.Dette bruges til at forhindre mellemallokeringer af formatstrenge og i stedet direkte skrive output.
//! Under emhætten påkalder denne funktion faktisk [`write_fmt`]-funktionen, der er defineret på [`std::io::Write`] trait.
//! Eksempel på anvendelse er:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Dette og [`println!`] udsender deres output til stdout.På samme måde som [`write!`]-makroen er målet med disse makroer at undgå mellemliggende allokeringer ved udskrivning af output.Eksempel på anvendelse er:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! [`eprint!`]-og [`eprintln!`]-makroerne er identiske med henholdsvis [`print!`] og [`println!`], bortset fra at de udsender deres output til stderr.
//!
//! ### `format_args!`
//!
//! Dette er en nysgerrig makro, der bruges til sikkert at passere et uigennemsigtigt objekt, der beskriver formatstrengen.Dette objekt kræver ingen bunktildelinger for at oprette, og det refererer kun til oplysninger på stakken.
//! Under emhætten implementeres alle de relaterede makroer i forhold til dette.
//! For det første er nogle eksempler på brug:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Resultatet af [`format_args!`] makroen er en værdi af typen [`fmt::Arguments`].
//! Denne struktur kan derefter sendes til [`write`]-og [`format`]-funktionerne inde i dette modul for at behandle formatstrengen.
//! Målet med denne makro er at forhindre yderligere fordeling af mellemliggende fordelinger, når der behandles formateringsstrenge.
//!
//! For eksempel kan et logbibliotek bruge standardformateringssyntaxen, men det vil internt passere denne struktur, indtil det er bestemt, hvor output skal gå til.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// `format`-funktionen tager en [`Arguments`]-struktur og returnerer den resulterende formaterede streng.
///
///
/// [`Arguments`]-forekomsten kan oprettes med [`format_args!`]-makroen.
///
/// # Examples
///
/// Grundlæggende brug:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Bemærk, at brug af [`format!`] kan være at foretrække.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}