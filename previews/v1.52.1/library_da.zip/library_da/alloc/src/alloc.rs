//! API'er til hukommelsesallokering

#![stable(feature = "alloc_module", since = "1.28.0")]

#[cfg(not(test))]
use core::intrinsics;
use core::intrinsics::{min_align_of_val, size_of_val};

use core::ptr::Unique;
#[cfg(not(test))]
use core::ptr::{self, NonNull};

#[stable(feature = "alloc_module", since = "1.28.0")]
#[doc(inline)]
pub use core::alloc::*;

#[cfg(test)]
mod tests;

extern "Rust" {
    // Dette er de magiske symboler, der skal kaldes den globale tildeler.rustc genererer dem til at ringe til `__rg_alloc` osv.
    // hvis der er en `#[global_allocator]`-attribut (koden, der udvider den attributmakro, genererer disse funktioner) eller at kalde standardimplementeringerne i libstd (`__rdl_alloc` osv.)
    //
    // i `library/std/src/alloc.rs`) ellers.
    // rustc fork af LLVM special-cases også disse funktionsnavne for at kunne optimere dem som henholdsvis `malloc`, `realloc` og `free`.
    //
    //
    #[rustc_allocator]
    #[rustc_allocator_nounwind]
    fn __rust_alloc(size: usize, align: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_dealloc(ptr: *mut u8, size: usize, align: usize);
    #[rustc_allocator_nounwind]
    fn __rust_realloc(ptr: *mut u8, old_size: usize, align: usize, new_size: usize) -> *mut u8;
    #[rustc_allocator_nounwind]
    fn __rust_alloc_zeroed(size: usize, align: usize) -> *mut u8;
}

/// Den globale hukommelsesalloker.
///
/// Denne type implementerer [`Allocator`] trait ved at videresende opkald til den allokator, der er registreret med `#[global_allocator]`-attributten, hvis der er en, eller `std` crate s standard.
///
///
/// Note: mens denne type er ustabil, kan du få adgang til den funktionalitet, den giver via [free functions in `alloc`](self#functions).
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, Default, Debug)]
#[cfg(not(test))]
pub struct Global;

#[cfg(test)]
pub use std::alloc::Global;

/// Tildel hukommelse med den globale tildeler.
///
/// Denne funktion videresender opkald til [`GlobalAlloc::alloc`]-metoden for den allokator, der er registreret med `#[global_allocator]`-attributten, hvis der er en, eller `std` crate s standard.
///
///
/// Denne funktion forventes at blive udfaset til fordel for `alloc`-metoden af [`Global`]-typen, når den og [`Allocator`] trait bliver stabile.
///
/// # Safety
///
/// Se [`GlobalAlloc::alloc`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc(layout);
///
///     *(ptr as *mut u16) = 42;
///     assert_eq!(*(ptr as *mut u16), 42);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc(layout.size(), layout.align()) }
}

/// Fordel hukommelsen med den globale tildeler.
///
/// Denne funktion videresender opkald til [`GlobalAlloc::dealloc`]-metoden for den allokator, der er registreret med `#[global_allocator]`-attributten, hvis der er en, eller `std` crate s standard.
///
///
/// Denne funktion forventes at blive udfaset til fordel for `dealloc`-metoden af [`Global`]-typen, når den og [`Allocator`] trait bliver stabile.
///
/// # Safety
///
/// Se [`GlobalAlloc::dealloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn dealloc(ptr: *mut u8, layout: Layout) {
    unsafe { __rust_dealloc(ptr, layout.size(), layout.align()) }
}

/// Omfordel hukommelsen med den globale allokator.
///
/// Denne funktion videresender opkald til [`GlobalAlloc::realloc`]-metoden for den allokator, der er registreret med `#[global_allocator]`-attributten, hvis der er en, eller `std` crate s standard.
///
///
/// Denne funktion forventes at blive udfaset til fordel for `realloc`-metoden af [`Global`]-typen, når den og [`Allocator`] trait bliver stabile.
///
/// # Safety
///
/// Se [`GlobalAlloc::realloc`].
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn realloc(ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
    unsafe { __rust_realloc(ptr, layout.size(), layout.align(), new_size) }
}

/// Tildel nul-initialiseret hukommelse med den globale tildeler.
///
/// Denne funktion videresender opkald til [`GlobalAlloc::alloc_zeroed`]-metoden for den tildeler, der er registreret med `#[global_allocator]`-attributten, hvis der er en, eller `std` crate s standard.
///
///
/// Denne funktion forventes at blive udfaset til fordel for `alloc_zeroed`-metoden af [`Global`]-typen, når den og [`Allocator`] trait bliver stabile.
///
/// # Safety
///
/// Se [`GlobalAlloc::alloc_zeroed`].
///
/// # Examples
///
/// ```
/// use std::alloc::{alloc_zeroed, dealloc, Layout};
///
/// unsafe {
///     let layout = Layout::new::<u16>();
///     let ptr = alloc_zeroed(layout);
///
///     assert_eq!(*(ptr as *mut u16), 0);
///
///     dealloc(ptr, layout);
/// }
/// ```
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[inline]
pub unsafe fn alloc_zeroed(layout: Layout) -> *mut u8 {
    unsafe { __rust_alloc_zeroed(layout.size(), layout.align()) }
}

#[cfg(not(test))]
impl Global {
    #[inline]
    fn alloc_impl(&self, layout: Layout, zeroed: bool) -> Result<NonNull<[u8]>, AllocError> {
        match layout.size() {
            0 => Ok(NonNull::slice_from_raw_parts(layout.dangling(), 0)),
            // SIKKERHED: `layout` er ikke nul i størrelse,
            size => unsafe {
                let raw_ptr = if zeroed { alloc_zeroed(layout) } else { alloc(layout) };
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, size))
            },
        }
    }

    // SIKKERHED: Samme som `Allocator::grow`
    #[inline]
    unsafe fn grow_impl(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
        zeroed: bool,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        match old_layout.size() {
            0 => self.alloc_impl(new_layout, zeroed),

            // SIKKERHED: `new_size` er ikke-nul, da `old_size` er større end eller lig med `new_size`
            // som krævet af sikkerhedsforholdene.Andre betingelser skal opretholdes af den, der ringer op
            old_size if old_layout.align() == new_layout.align() => unsafe {
                let new_size = new_layout.size();

                // `realloc` kontrollerer sandsynligvis for `new_size >= old_layout.size()` eller noget lignende.
                intrinsics::assume(new_size >= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                if zeroed {
                    raw_ptr.add(old_size).write_bytes(0, new_size - old_size);
                }
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // SIKKERHED: fordi `new_layout.size()` skal være større end eller lig med `old_size`,
            // både den gamle og den nye hukommelsestildeling er gyldig til læsning og skrivning af `old_size`-byte.
            // Også fordi den gamle tildeling endnu ikke var deallokeret, kan den ikke overlappe `new_ptr`.
            // Således er opkaldet til `copy_nonoverlapping` sikkert.
            // Sikkerhedskontrakten for `dealloc` skal opretholdes af den, der ringer op.
            old_size => unsafe {
                let new_ptr = self.alloc_impl(new_layout, zeroed)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
#[cfg(not(test))]
unsafe impl Allocator for Global {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, false)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        self.alloc_impl(layout, true)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if layout.size() != 0 {
            // SIKKERHED: `layout` er ikke nul i størrelse,
            // andre betingelser skal opretholdes af den, der ringer op
            unsafe { dealloc(ptr.as_ptr(), layout) }
        }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SIKKERHED: alle betingelser skal opretholdes af den, der ringer op
        unsafe { self.grow_impl(ptr, old_layout, new_layout, false) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SIKKERHED: alle betingelser skal opretholdes af den, der ringer op
        unsafe { self.grow_impl(ptr, old_layout, new_layout, true) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        match new_layout.size() {
            // SIKKERHED: betingelserne skal opretholdes af den, der ringer op
            0 => unsafe {
                self.deallocate(ptr, old_layout);
                Ok(NonNull::slice_from_raw_parts(new_layout.dangling(), 0))
            },

            // SIKKERHED: `new_size` er ikke-nul.Andre betingelser skal opretholdes af den, der ringer op
            new_size if old_layout.align() == new_layout.align() => unsafe {
                // `realloc` kontrollerer sandsynligvis for `new_size <= old_layout.size()` eller noget lignende.
                intrinsics::assume(new_size <= old_layout.size());

                let raw_ptr = realloc(ptr.as_ptr(), old_layout, new_size);
                let ptr = NonNull::new(raw_ptr).ok_or(AllocError)?;
                Ok(NonNull::slice_from_raw_parts(ptr, new_size))
            },

            // SIKKERHED: fordi `new_size` skal være mindre end eller lig med `old_layout.size()`,
            // både den gamle og den nye hukommelsestildeling er gyldig til læsning og skrivning af `new_size`-byte.
            // Også fordi den gamle tildeling endnu ikke var deallokeret, kan den ikke overlappe `new_ptr`.
            // Således er opkaldet til `copy_nonoverlapping` sikkert.
            // Sikkerhedskontrakten for `dealloc` skal opretholdes af den, der ringer op.
            new_size => unsafe {
                let new_ptr = self.allocate(new_layout)?;
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_size);
                self.deallocate(ptr, old_layout);
                Ok(new_ptr)
            },
        }
    }
}

/// Tildeleren til unikke pointer.
// Denne funktion må ikke slappe af.Hvis det gør det, mislykkes MIR-kodegen.
#[cfg(not(test))]
#[lang = "exchange_malloc"]
#[inline]
unsafe fn exchange_malloc(size: usize, align: usize) -> *mut u8 {
    let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

#[cfg_attr(not(test), lang = "box_free")]
#[inline]
// Denne signatur skal være den samme som `Box`, ellers sker der en ICE.
// Når der tilføjes en ekstra parameter til `Box` (som `A: Allocator`), skal denne også tilføjes her.
// For eksempel, hvis `Box` ændres til `struct Box<T: ?Sized, A: Allocator>(Unique<T>, A)`, skal denne funktion også ændres til `fn box_free<T: ?Sized, A: Allocator>(Unique<T>, A)`.
//
//
pub(crate) unsafe fn box_free<T: ?Sized, A: Allocator>(ptr: Unique<T>, alloc: A) {
    unsafe {
        let size = size_of_val(ptr.as_ref());
        let align = min_align_of_val(ptr.as_ref());
        let layout = Layout::from_size_align_unchecked(size, align);
        alloc.deallocate(ptr.cast().into(), layout)
    }
}

// # Allokeringsfejlbehandler

extern "Rust" {
    // Dette er det magiske symbol for at kalde den globale allokeringsfejlhåndterer.
    // rustc genererer det til at ringe til `__rg_oom`, hvis der er en `#[alloc_error_handler]` eller ellers kalde standardimplementeringerne under (`__rdl_oom`).
    //
    #[rustc_allocator_nounwind]
    fn __rust_alloc_error_handler(size: usize, align: usize) -> !;
}

/// Afbryd på hukommelsesallokeringsfejl eller-fejl.
///
/// Opkaldere af API'er til hukommelsesallokering, der ønsker at afbryde beregning som svar på en allokeringsfejl, opfordres til at kalde denne funktion i stedet for direkte at påberåbe `panic!` eller lignende.
///
///
/// Standardfunktionen for denne funktion er at udskrive en besked til standardfejl og afbryde processen.
/// Det kan udskiftes med [`set_alloc_error_hook`] og [`take_alloc_error_hook`].
///
/// [`set_alloc_error_hook`]: ../../std/alloc/fn.set_alloc_error_hook.html
/// [`take_alloc_error_hook`]: ../../std/alloc/fn.take_alloc_error_hook.html
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
#[cfg(not(test))]
#[rustc_allocator_nounwind]
#[cold]
pub fn handle_alloc_error(layout: Layout) -> ! {
    unsafe {
        __rust_alloc_error_handler(layout.size(), layout.align());
    }
}

// Til allokeringstest kan `std::alloc::handle_alloc_error` bruges direkte.
#[cfg(test)]
pub use std::alloc::handle_alloc_error;

#[cfg(not(any(target_os = "hermit", test)))]
#[doc(hidden)]
#[allow(unused_attributes)]
#[unstable(feature = "alloc_internals", issue = "none")]
pub mod __alloc_error_handler {
    use crate::alloc::Layout;

    // kaldes via genereret `__rust_alloc_error_handler`

    // hvis der ikke er nogen `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rdl_oom(size: usize, _align: usize) -> ! {
        panic!("memory allocation of {} bytes failed", size)
    }

    // hvis der er en `#[alloc_error_handler]`
    #[rustc_std_internal_symbol]
    pub unsafe extern "C" fn __rg_oom(size: usize, align: usize) -> ! {
        let layout = unsafe { Layout::from_size_align_unchecked(size, align) };
        extern "Rust" {
            #[lang = "oom"]
            fn oom_impl(layout: Layout) -> !;
        }
        unsafe { oom_impl(layout) }
    }
}

/// Specialiser kloner i forudallokeret, ikke-initialiseret hukommelse.
/// Brugt af `Box::clone` og `Rc`/`Arc::make_mut`.
pub(crate) trait WriteCloneIntoRaw: Sized {
    unsafe fn write_clone_into_raw(&self, target: *mut Self);
}

impl<T: Clone> WriteCloneIntoRaw for T {
    #[inline]
    default unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Når du har tildelt *først*, kan optimeringsprogrammet muligvis oprette den klonede værdi på stedet, springe det lokale over og flytte.
        //
        unsafe { target.write(self.clone()) };
    }
}

impl<T: Copy> WriteCloneIntoRaw for T {
    #[inline]
    unsafe fn write_clone_into_raw(&self, target: *mut Self) {
        // Vi kan altid kopiere på plads uden nogensinde at involvere en lokal værdi.
        unsafe { target.copy_from_nonoverlapping(self, 1) };
    }
}