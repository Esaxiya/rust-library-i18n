use core::iter::TrustedLen;
use core::ptr::{self};

use super::{SpecExtend, Vec};

/// En anden specialisering trait til Vec::from_iter, der er nødvendig for manuelt at prioritere overlappende specialiseringer, se [`SpecFromIter`](super::SpecFromIter) for detaljer.
///
///
pub(super) trait SpecFromIterNested<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Udrul den første iteration, da vector vil blive udvidet til denne iteration i hvert tilfælde, når iterablen ikke er tom, men sløjfen i extend_desugared() vil ikke se vector være fuld i de få efterfølgende loop-iterationer.
        //
        // Så vi får en bedre forudsigelse af branch.
        //
        //
        let mut vector = match iterator.next() {
            None => return Vec::new(),
            Some(element) => {
                let (lower, _) = iterator.size_hint();
                let mut vector = Vec::with_capacity(lower.saturating_add(1));
                unsafe {
                    ptr::write(vector.as_mut_ptr(), element);
                    vector.set_len(1);
                }
                vector
            }
        };
        // skal delegere til spec_extend(), da extend() selv delegerer til spec_from for tomme Vecs
        //
        <Vec<T> as SpecExtend<T, I>>::spec_extend(&mut vector, iterator);
        vector
    }
}

impl<T, I> SpecFromIterNested<T, I> for Vec<T>
where
    I: TrustedLen<Item = T>,
{
    fn from_iter(iterator: I) -> Self {
        let mut vector = match iterator.size_hint() {
            (_, Some(upper)) => Vec::with_capacity(upper),
            _ => Vec::new(),
        };
        // skal delegere til spec_extend(), da extend() selv delegerer til spec_from for tomme Vecs
        //
        vector.spec_extend(iterator);
        vector
    }
}