use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Specialiseringsmarkør til opsamling af en iteratorrørledning til en Vec, mens kildetildeling genbruges, dvs.
/// udførelse af rørledningen på plads.
///
/// SourceIter-overordnede trait er nødvendig for, at specialfunktionen får adgang til den allokering, der skal genbruges.
/// Men det er ikke tilstrækkeligt, at specialiseringen er gyldig.
/// Se yderligere grænser på impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// Den std-interne SourceIter/InPlaceIterable traits implementeres kun af adapterkæder <Adapter<Adapter<IntoIter>>> (alle ejet af core/std).
// Yderligere grænser for adapterimplementeringerne (ud over `impl<I: Trait> Trait for Adapter<I>`) afhænger kun af andre traits, der allerede er markeret som specialisering traits (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. markøren afhænger ikke af levetiden for brugerleverede typer.Modul kopihullet, som flere andre specialiseringer allerede er afhængige af.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Yderligere krav, som ikke kan udtrykkes via trait bounds.Vi stoler på konstant i stedet:
        // a) ingen ZST'er, da der ikke ville være nogen allokering til genbrug og markøraritmetik ville panic b) størrelse matcher som krævet af Alloc-kontrakt c) justeringer matcher som krævet af Alloc-kontrakt
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // tilbagefald til mere generiske implementeringer
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // brug prøvefold siden
        // - det vektoriserer bedre for nogle iterator-adaptere
        // - i modsætning til de fleste interne iterationsmetoder tager det kun et &mut-selv
        // - det lader os tråde skrivemarkøren gennem dens indre og få den tilbage til sidst
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // iteration lykkedes, slip ikke hovedet
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // kontrollere, om SourceIter-kontrakten blev opretholdt med forbehold: hvis de ikke var det, kommer vi måske ikke engang til dette punkt
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // tjek InPlaceIterable kontrakt.Dette er kun muligt, hvis iteratoren overhovedet avancerede kildemarkøren.
        // Hvis den bruger ukontrolleret adgang via TrustedRandomAccess, forbliver kildemarkøren i sin oprindelige position, og vi kan ikke bruge den som reference
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // slip eventuelle resterende værdier i kildens hale, men forhindrer fald i selve tildelingen, når IntoIter går ud af rækkevidde, hvis dråben panics så lækker vi også alle elementer, der er indsamlet i dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // InPlaceIterable-kontrakten kan ikke verificeres nøjagtigt her, da try_fold har en eksklusiv reference til kildemarkøren, alt hvad vi kan gøre er at kontrollere, om den stadig er inden for rækkevidde
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}