// Indstil længden på vec, når `SetLenOnDrop`-værdien går uden for anvendelsesområdet.
//
// Idéen er: Længdefeltet i SetLenOnDrop er en lokal variabel, som optimeringsprogrammet vil se, ikke er et alias med nogen butikker gennem Vecs datapeger.
// Dette er en løsning til aliasanalyseproblem #32155
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}