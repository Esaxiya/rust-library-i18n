//! En sammenhængende dyrkbar array-type med bunke-allokeret indhold, skrevet `Vec<T>`.
//!
//! Vectors har `O(1)` indeksering, amortiseret `O(1)` push (til slutningen) og `O(1)` pop (fra slutningen).
//!
//!
//! Vectors sikrer, at de aldrig tildeler mere end `isize::MAX` bytes.
//!
//! # Examples
//!
//! Du kan eksplicit oprette en [`Vec`] med [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... eller ved hjælp af [`vec!`]-makroen:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // ti nuller
//! ```
//!
//! Du kan [`push`]-værdier i slutningen af en vector (som vil vokse vector efter behov):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Popping-værdier fungerer på samme måde:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors understøtter også indeksering (gennem [`Index`] og [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// En sammenhængende dyrkbar array-type, skrevet som `Vec<T>` og udtalt 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// [`vec!`]-makroen leveres for at gøre initialiseringen mere bekvem:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Det kan også initialisere hvert element i en `Vec<T>` med en given værdi.
/// Dette kan være mere effektivt end at udføre allokering og initialisering i separate trin, især når man initialiserer en vector med nuller:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Følgende er ækvivalente, men potentielt langsommere:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// For mere information, se [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Brug en `Vec<T>` som en effektiv stak:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Udskriver 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// `Vec`-typen giver adgang til værdier efter indeks, fordi den implementerer [`Index`] trait.Et eksempel vil være mere eksplicit:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // det viser '2'
/// ```
///
/// Vær dog forsigtig: Hvis du prøver at få adgang til et indeks, der ikke findes i `Vec`, vil din software panic!Du kan ikke gøre dette:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Brug [`get`] og [`get_mut`], hvis du vil kontrollere, om indekset er i `Vec`.
///
/// # Slicing
///
/// En `Vec` kan ændres.På den anden side er skiver skrivebeskyttede objekter.
/// Brug [`&`] for at få en [slice][prim@slice].Eksempel:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... og det er alt!
/// // du kan også gøre det sådan:
/// let u: &[usize] = &v;
/// // eller sådan:
/// let u: &[_] = &v;
/// ```
///
/// I Rust er det mere almindeligt at videregive skiver som argumenter snarere end vectors, når du bare vil give læseadgang.Det samme gælder for [`String`] og [`&str`].
///
/// # Kapacitet og omfordeling
///
/// Kapaciteten for en vector er mængden af plads, der er tildelt future-elementer, der føjes til vector.Dette må ikke forveksles med *længden* af en vector, som specificerer antallet af faktiske elementer inden for vector.
/// Hvis en vector-længde overstiger dens kapacitet, øges dens kapacitet automatisk, men dens elementer skal omfordeles.
///
/// For eksempel ville en vector med kapacitet 10 og længde 0 være en tom vector med plads til 10 flere elementer.Hvis du skubber 10 eller færre elementer på vector, ændres ikke dens kapacitet eller forårsager genallokering.
/// Men hvis vector's længde øges til 11, bliver den nødt til at omfordele, hvilket kan være langsomt.Af denne grund anbefales det at bruge [`Vec::with_capacity`] når det er muligt for at specificere, hvor stor vector forventes at blive.
///
/// # Guarantees
///
/// På grund af sin utroligt grundlæggende karakter giver `Vec` mange garantier for sit design.Dette sikrer, at det generelt er så lavt overhead som muligt og kan manipuleres korrekt på primitive måder af usikker kode.Bemærk, at disse garantier henviser til en ukvalificeret `Vec<T>`.
/// Hvis der tilføjes yderligere typeparametre (f.eks. For at understøtte brugerdefinerede tildelere), kan tilsidesættelse af deres standarder muligvis ændre adfærd.
///
/// Mest grundlæggende er og vil `Vec` altid være en (pointer, kapacitet, længde) triplet.Ikke mere, ikke mindre.Rækkefølgen af disse felter er helt uspecificeret, og du skal bruge de relevante metoder til at ændre disse.
/// Markøren vil aldrig være nul, så denne type er nul-markør-optimeret.
///
/// Markøren peger dog muligvis ikke på tildelt hukommelse.
/// Især hvis du konstruerer en `Vec` med kapacitet 0 via [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`] eller ved at kalde [`shrink_to_fit`] på en tom Vec, tildeler den ikke hukommelse.Tilsvarende, hvis du gemmer nulstørrelsestyper inde i en `Vec`, tildeler den ikke plads til dem.
/// *Bemærk, at i dette tilfælde rapporterer `Vec` muligvis ikke en [`capacity`] på 0*.
/// `Vec` tildeler hvis og kun hvis [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// Generelt er `Vec`s tildelingsoplysninger meget subtile-hvis du har til hensigt at tildele hukommelse ved hjælp af en `Vec` og bruge den til noget andet (enten til at overføre til usikker kode eller til at opbygge din egen hukommelsesstøttede samling), skal du være sikker for at omplacere denne hukommelse ved at bruge `from_raw_parts` til at gendanne `Vec` og derefter slippe den.
///
/// Hvis en `Vec`*har* allokeret hukommelse, er hukommelsen, den peger på, på bunken (som defineret af allokeringen Rust er konfigureret til at bruge som standard), og dens markør peger på [`len`] initialiserede, sammenhængende elementer i rækkefølge (hvad du ville se om du tvang det til et udsnit), efterfulgt af [`kapacitet`]`,`[`len`] logisk uinitialiserede, sammenhængende elementer.
///
///
/// En vector indeholdende elementerne `'a'` og `'b'` med kapacitet 4 kan visualiseres som nedenfor.Den øverste del er `Vec`-strukturen, den indeholder en markør til tildelingshovedet i bunken, længden og kapaciteten.
/// Den nederste del er tildelingen på bunken, en sammenhængende hukommelsesblok.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** repræsenterer hukommelse, der ikke er initialiseret, se [`MaybeUninit`].
/// - Note: ABI er ikke stabil, og `Vec` giver ingen garantier for dets hukommelseslayout (inklusive rækkefølgen af felter).
///
/// `Vec` udfører aldrig en "small optimization", hvor elementer faktisk er gemt på stakken af to grunde:
///
/// * Det ville gøre det vanskeligere for usikker kode at manipulere en `Vec` korrekt.Indholdet af en `Vec` ville ikke have en stabil adresse, hvis den kun blev flyttet, og det ville være sværere at afgøre, om en `Vec` faktisk havde tildelt hukommelse.
///
/// * Det ville straffe den generelle sag og medføre yderligere branch ved enhver adgang.
///
/// `Vec` vil aldrig automatisk krympe sig selv, selvom det er helt tomt.Dette sikrer, at der ikke forekommer unødvendige tildelinger eller deallokeringer.Tømning af en `Vec` og derefter udfyldning af den op til den samme [`len`] skulle ikke medføre opkald til fordeleren.Hvis du ønsker at frigøre ubrugt hukommelse, skal du bruge [`shrink_to_fit`] eller [`shrink_to`].
///
/// [`push`] og [`insert`] vil aldrig (re) allokere, hvis den rapporterede kapacitet er tilstrækkelig.[`push`] og [`insert`] * tildeler ((re)) hvis [`len`]`==`[`kapacitet`].Det vil sige, den rapporterede kapacitet er helt nøjagtig og kan stole på.Det kan endda bruges til manuelt at frigøre den hukommelse, der tildeles af en `Vec`, hvis det ønskes.
/// Metoder til indsættelse af bulk *kan* allokere igen, selv når det ikke er nødvendigt.
///
/// `Vec` garanterer ikke nogen særlig vækststrategi ved omfordeling, når den er fuld, eller når [`reserve`] kaldes.Den nuværende strategi er grundlæggende, og det kan vise sig ønskeligt at bruge en ikke-konstant vækstfaktor.Uanset hvilken strategi der anvendes, garanteres naturligvis *O*(1) amortiseret [`push`].
///
/// `vec![x; n]`, `vec![a, b, c, d]` og [`Vec::with_capacity(n)`][`Vec::with_capacity`] producerer alle en `Vec` med nøjagtigt den ønskede kapacitet.
/// Hvis [`len`]`==`[`kapacitet`], (som det er tilfældet med [`vec!`]-makroen), kan en `Vec<T>` konverteres til og fra en [`Box<[T]>`][owned slice] uden at omfordele eller flytte elementerne.
///
/// `Vec` overskriver ikke specifikt data, der fjernes fra det, men bevarer det heller ikke specifikt.Dens uinitialiserede hukommelse er ridseplads, som den kan bruge, uanset hvordan den vil.Det vil generelt bare gøre, hvad der er mest effektivt eller på anden måde let at implementere.Stol ikke på fjernede data, der skal slettes af sikkerhedsmæssige årsager.
/// Selvom du taber en `Vec`, kan dens buffer simpelthen genbruges af en anden `Vec`.
/// Selvom du først nulstiller en `Vec`s hukommelse, kan det faktisk ikke ske, fordi optimeringsprogrammet ikke betragter dette som en bivirkning, der skal bevares.
/// Der er et tilfælde, som vi ikke vil bryde, men ved at bruge `unsafe`-kode til at skrive til den overskydende kapacitet og derefter øge længden for at matche er altid gyldig.
///
/// I øjeblikket garanterer `Vec` ikke den rækkefølge, i hvilken elementer droppes.
/// Ordren har ændret sig tidligere og kan ændre sig igen.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Iboende metoder
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Konstruerer en ny, tom `Vec<T>`.
    ///
    /// vector tildeles ikke, før elementer skubbes på den.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Konstruerer en ny, tom `Vec<T>` med den specificerede kapacitet.
    ///
    /// vector er i stand til at rumme nøjagtigt `capacity`-elementer uden genallokering.
    /// Hvis `capacity` er 0, tildeles vector ikke.
    ///
    /// Det er vigtigt at bemærke, at selvom den returnerede vector har den angivne *kapacitet*, vil vector have en nul *længde*.
    ///
    /// For en forklaring på forskellen mellem længde og kapacitet, se *[Kapacitet og omfordeling]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector indeholder ingen genstande, selvom den har kapacitet til mere
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Disse gøres alle uden genallokering ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... men dette kan gøre, at vector omfordeles
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Opretter en `Vec<T>` direkte fra de rå komponenter i en anden vector.
    ///
    /// # Safety
    ///
    /// Dette er meget usikkert på grund af antallet af invarianter, der ikke kontrolleres:
    ///
    /// * `ptr` skal tidligere være tildelt via [`String`]/`Vec<T>`` (i det mindste er det meget sandsynligt, at det er forkert, hvis det ikke var).
    /// * `T` skal have samme størrelse og justering som det, `ptr` blev tildelt.
    ///   (`T` med en mindre streng tilpasning er ikke tilstrækkelig, tilpasningen skal virkelig være lig for at opfylde [`dealloc`]-kravet om, at hukommelsen skal tildeles og placeres i samme layout.)
    ///
    /// * `length` skal være mindre end eller lig med `capacity`.
    /// * `capacity` skal være den kapacitet, som markøren blev tildelt med.
    ///
    /// Overtrædelse af disse kan medføre problemer som at ødelægge tildelers interne datastrukturer.For eksempel er det **ikke** sikkert at opbygge en `Vec<u8>` fra en markør til et C `char`-array med længden `size_t`.
    /// Det er heller ikke sikkert at bygge en fra en `Vec<u16>` og dens længde, fordi fordeleren bekymrer sig om justeringen, og disse to typer har forskellige justeringer.
    /// Bufferen blev allokeret med justering 2 (for `u16`), men efter at den blev omdannet til en `Vec<u8>`, vil den blive fordelt med justering 1.
    ///
    /// Ejerskabet af `ptr` overføres effektivt til `Vec<T>`, som derefter kan omfordele, omfordele eller ændre indholdet af hukommelsen, som markøren peger på efter ønske.
    /// Sørg for, at intet andet bruger markøren efter at have kaldt denne funktion.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Opdater dette, når vec_into_raw_parts er stabiliseret.
    ///     // Undgå at køre `v`s destruktor, så vi har fuld kontrol over tildelingen.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Træk de forskellige vigtige oplysninger om `v` ud
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Overskriv hukommelse med 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Sæt alt sammen igen til en Vec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Konstruerer en ny, tom `Vec<T, A>`.
    ///
    /// vector tildeles ikke, før elementer skubbes på den.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Konstruerer en ny, tom `Vec<T, A>` med den specificerede kapacitet med den medfølgende tildeler.
    ///
    /// vector er i stand til at rumme nøjagtigt `capacity`-elementer uden genallokering.
    /// Hvis `capacity` er 0, tildeles vector ikke.
    ///
    /// Det er vigtigt at bemærke, at selvom den returnerede vector har den angivne *kapacitet*, vil vector have en nul *længde*.
    ///
    /// For en forklaring på forskellen mellem længde og kapacitet, se *[Kapacitet og omfordeling]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector indeholder ingen genstande, selvom den har kapacitet til mere
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Disse gøres alle uden genallokering ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... men dette kan gøre, at vector omfordeles
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Opretter en `Vec<T, A>` direkte fra de rå komponenter i en anden vector.
    ///
    /// # Safety
    ///
    /// Dette er meget usikkert på grund af antallet af invarianter, der ikke kontrolleres:
    ///
    /// * `ptr` skal tidligere være tildelt via [`String`]/`Vec<T>`` (i det mindste er det meget sandsynligt, at det er forkert, hvis det ikke var).
    /// * `T` skal have samme størrelse og justering som det, `ptr` blev tildelt.
    ///   (`T` med en mindre streng tilpasning er ikke tilstrækkelig, tilpasningen skal virkelig være lig for at opfylde [`dealloc`]-kravet om, at hukommelsen skal tildeles og placeres i samme layout.)
    ///
    /// * `length` skal være mindre end eller lig med `capacity`.
    /// * `capacity` skal være den kapacitet, som markøren blev tildelt med.
    ///
    /// Overtrædelse af disse kan medføre problemer som at ødelægge tildelers interne datastrukturer.For eksempel er det **ikke** sikkert at opbygge en `Vec<u8>` fra en markør til et C `char`-array med længden `size_t`.
    /// Det er heller ikke sikkert at bygge en fra en `Vec<u16>` og dens længde, fordi fordeleren bekymrer sig om justeringen, og disse to typer har forskellige justeringer.
    /// Bufferen blev allokeret med justering 2 (for `u16`), men efter at den blev omdannet til en `Vec<u8>`, vil den blive fordelt med justering 1.
    ///
    /// Ejerskabet af `ptr` overføres effektivt til `Vec<T>`, som derefter kan omfordele, omfordele eller ændre indholdet af hukommelsen, som markøren peger på efter ønske.
    /// Sørg for, at intet andet bruger markøren efter at have kaldt denne funktion.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Opdater dette, når vec_into_raw_parts er stabiliseret.
    ///     // Undgå at køre `v`s destruktor, så vi har fuld kontrol over tildelingen.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Træk de forskellige vigtige oplysninger om `v` ud
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Overskriv hukommelse med 4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Sæt alt sammen igen til en Vec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Nedbryder en `Vec<T>` i sine rå komponenter.
    ///
    /// Returnerer den rå markør til de underliggende data, længden af vector (i elementer) og den tildelte kapacitet af dataene (i elementer).
    /// Disse er de samme argumenter i samme rækkefølge som argumenterne til [`from_raw_parts`].
    ///
    /// Efter opkald til denne funktion er den, der ringer, ansvarlig for den hukommelse, der tidligere blev administreret af `Vec`.
    /// Den eneste måde at gøre dette på er at konvertere den rå markør, længde og kapacitet tilbage til en `Vec` med [`from_raw_parts`]-funktionen, så destruktoren kan udføre oprydningen.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Vi kan nu foretage ændringer i komponenterne, såsom at transmittere råmarkøren til en kompatibel type.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Nedbryder en `Vec<T>` i sine rå komponenter.
    ///
    /// Returnerer den rå markør til de underliggende data, længden af vector (i elementer), den tildelte kapacitet af dataene (i elementerne) og fordeleren.
    /// Disse er de samme argumenter i samme rækkefølge som argumenterne til [`from_raw_parts_in`].
    ///
    /// Efter opkald til denne funktion er den, der ringer, ansvarlig for den hukommelse, der tidligere blev administreret af `Vec`.
    /// Den eneste måde at gøre dette på er at konvertere den rå pointer, længde og kapacitet tilbage til en `Vec` med [`from_raw_parts_in`]-funktionen, så destruktoren kan udføre oprydningen.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Vi kan nu foretage ændringer i komponenterne, såsom at transmittere råmarkøren til en kompatibel type.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Returnerer antallet af elementer, som vector kan rumme uden genallokering.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Reserverer kapacitet til mindst `additional` flere elementer, der skal indsættes i den givne `Vec<T>`.
    /// Samlingen reserverer muligvis mere plads for at undgå hyppige allokeringer.
    /// Efter at have ringet til `reserve`, vil kapaciteten være større end eller lig med `self.len() + additional`.
    /// Gør intet, hvis kapaciteten allerede er tilstrækkelig.
    ///
    /// # Panics
    ///
    /// Panics hvis den nye kapacitet overstiger `isize::MAX` bytes.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Forbeholder sig den mindste kapacitet for nøjagtigt `additional` flere elementer, der skal indsættes i den givne `Vec<T>`.
    ///
    /// Efter at have ringet til `reserve_exact`, vil kapaciteten være større end eller lig med `self.len() + additional`.
    /// Gør intet, hvis kapaciteten allerede er tilstrækkelig.
    ///
    /// Bemærk, at tildeleren muligvis giver samlingen mere plads, end den anmoder om.
    /// Derfor kan man ikke stole på, at kapaciteten er nøjagtig minimal.
    /// Foretrækker `reserve`, hvis der forventes future-indsættelse.
    ///
    /// # Panics
    ///
    /// Panics hvis den nye kapacitet overskrider `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Forsøger at reservere kapacitet til mindst `additional` flere elementer, der skal indsættes i den givne `Vec<T>`.
    /// Samlingen reserverer muligvis mere plads for at undgå hyppige allokeringer.
    /// Efter at have ringet til `try_reserve`, vil kapaciteten være større end eller lig med `self.len() + additional`.
    /// Gør intet, hvis kapaciteten allerede er tilstrækkelig.
    ///
    /// # Errors
    ///
    /// Hvis kapaciteten overløber, eller tildeleren rapporterer en fejl, returneres en fejl.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Forhåndsreservere hukommelsen og afslutte, hvis vi ikke kan
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Nu ved vi, at dette ikke kan OOM midt i vores komplekse arbejde
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // meget kompliceret
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Forsøger at reservere minimumskapaciteten for nøjagtigt `additional`-elementer, der skal indsættes i den givne `Vec<T>`.
    /// Efter at have ringet til `try_reserve_exact`, vil kapaciteten være større end eller lig med `self.len() + additional`, hvis den returnerer `Ok(())`.
    ///
    /// Gør intet, hvis kapaciteten allerede er tilstrækkelig.
    ///
    /// Bemærk, at tildeleren muligvis giver samlingen mere plads, end den anmoder om.
    /// Derfor kan man ikke stole på, at kapaciteten er nøjagtig minimal.
    /// Foretrækker `reserve`, hvis der forventes future-indsættelse.
    ///
    /// # Errors
    ///
    /// Hvis kapaciteten overløber, eller tildeleren rapporterer en fejl, returneres en fejl.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Forhåndsreservere hukommelsen og afslutte, hvis vi ikke kan
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Nu ved vi, at dette ikke kan OOM midt i vores komplekse arbejde
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // meget kompliceret
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Krymper kapaciteten på vector så meget som muligt.
    ///
    /// Det falder ned så tæt som muligt på længden, men allokeringen kan stadig informere vector om, at der er plads til nogle få flere elementer.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Kapaciteten er aldrig mindre end længden, og der er intet at gøre, når de er ens, så vi kan undgå panic-sagen i `RawVec::shrink_to_fit` ved kun at kalde den med større kapacitet.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Krymper kapaciteten på vector med en nedre grænse.
    ///
    /// Kapaciteten forbliver mindst lige så stor som både længden og den leverede værdi.
    ///
    ///
    /// Hvis den aktuelle kapacitet er mindre end den nedre grænse, er dette en no-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Konverterer vector til [`Box<[T]>`][owned slice].
    ///
    /// Bemærk, at dette vil tabe overskydende kapacitet.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Overskydende kapacitet fjernes:
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Forkorter vector, holder de første `len`-elementer og slipper resten.
    ///
    /// Hvis `len` er større end vector s nuværende længde, har dette ingen effekt.
    ///
    /// [`drain`]-metoden kan efterligne `truncate`, men får de overskydende elementer til at blive returneret i stedet for at blive droppet.
    ///
    ///
    /// Bemærk, at denne metode ikke har nogen effekt på vector's tildelte kapacitet.
    ///
    /// # Examples
    ///
    /// Afkortning af et fem-element vector til to elementer:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Ingen trunkering opstår, når `len` er større end vector s nuværende længde:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Afkort, når `len == 0` svarer til at kalde [`clear`]-metoden.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Dette er sikkert, fordi:
        //
        // * det stykke, der sendes til `drop_in_place`, er gyldigt;`len > self.len`-sagen undgår at oprette et ugyldigt udsnit, og
        // * `len` af vector krympes, inden der kaldes på `drop_in_place`, således at ingen værdi tabes to gange, hvis `drop_in_place` skulle være panic en gang (hvis det panics to gange, afbrydes programmet).
        //
        //
        //
        unsafe {
            // Note: Det er bevidst, at dette er `>` og ikke `>=`.
            //       Ændring af det til `>=` har i nogle tilfælde negative præstationsimplikationer.
            //       Se #78884 for mere.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Uddrag et stykke, der indeholder hele vector.
    ///
    /// Svarer til `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Uddrag et muterbart udsnit af hele vector.
    ///
    /// Svarer til `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Returnerer en rå markør til vector's buffer.
    ///
    /// Den, der ringer op, skal sikre, at vector overlever markøren, som denne funktion returnerer, ellers vil den ende med at pege på skrald.
    /// Ændring af vector kan medføre, at dens buffer omfordeles, hvilket også vil gøre eventuelle henvisninger til den ugyldige.
    ///
    /// Den, der ringer op, skal også sikre, at den hukommelse, som markøren (non-transitively) peger på, aldrig skrives til (undtagen inde i en `UnsafeCell`) ved hjælp af denne markør eller en hvilken som helst markør, der stammer fra den.
    /// Hvis du har brug for at mutere indholdet af udsnittet, skal du bruge [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Vi skygger skivemetoden med samme navn for at undgå at gå gennem `deref`, hvilket skaber en mellemreference.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Returnerer en usikker muterbar markør til vector's buffer.
    ///
    /// Den, der ringer op, skal sikre, at vector overlever markøren, som denne funktion returnerer, ellers vil den ende med at pege på skrald.
    ///
    /// Ændring af vector kan medføre, at dens buffer omfordeles, hvilket også vil gøre eventuelle henvisninger til den ugyldige.
    ///
    /// # Examples
    ///
    /// ```
    /// // Tildel vector stor nok til 4 elementer.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Initialiser elementer via rå markørskrivninger, og indstil derefter længde.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Vi skygger skivemetoden med samme navn for at undgå at gå gennem `deref_mut`, hvilket skaber en mellemreference.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Returnerer en henvisning til den underliggende tildeler.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Tvinger længden af vector til `new_len`.
    ///
    /// Dette er en operation på lavt niveau, der opretholder ingen af de normale invarianter af typen.
    /// Normalt ændres længden af en vector ved hjælp af en af de sikre operationer i stedet, såsom [`truncate`], [`resize`], [`extend`] eller [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` skal være mindre end eller lig med [`capacity()`].
    /// - Elementerne på `old_len..new_len` skal initialiseres.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Denne metode kan være nyttig i situationer, hvor vector tjener som en buffer for anden kode, især over FFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Dette er bare et minimalt skelet til dok. Eksemplet;
    /// # // Brug ikke dette som udgangspunkt for et rigtigt bibliotek.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // I henhold til FFI-metodens dokumenter, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // SIKKERHED: Når `deflateGetDictionary` returnerer `Z_OK`, fastholder det, at:
    ///     // 1. `dict_length` elementerne blev initialiseret.
    ///     // 2.
    ///     // `dict_length` <=kapaciteten (32_768), der gør `set_len` sikkert at ringe til.
    ///     unsafe {
    ///         // Foretag FFI-opkaldet ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... og opdater længden til det, der blev initialiseret.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Mens følgende eksempel er lyd, er der en hukommelseslækage, da de indre vektorer ikke blev frigjort før `set_len`-opkaldet:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` er tom, så ingen elementer skal initialiseres.
    /// // 2. `0 <= capacity` holder altid hvad `capacity` er.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Normalt her ville man bruge [`clear`] i stedet for korrekt at droppe indholdet og således ikke lækker hukommelse.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Fjerner et element fra vector og returnerer det.
    ///
    /// Det fjernede element erstattes af det sidste element i vector.
    ///
    /// Dette bevarer ikke bestilling, men er O(1).
    ///
    /// # Panics
    ///
    /// Panics hvis `index` er uden for grænserne.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Vi erstatter selv [indeks] med det sidste element.
            // Bemærk, at hvis grænsekontrollen ovenfor lykkes, skal der være et sidste element (som selv kan være [indeks]).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Indsætter et element i position `index` inden for vector og skifter alle elementene efter det til højre.
    ///
    ///
    /// # Panics
    ///
    /// Panics hvis `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // plads til det nye element
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // ufejlbarlig Stedet for at sætte den nye værdi
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Flyt alt for at skabe plads.
                // (Kopiering af det indekserede element to steder i træk.)
                ptr::copy(p, p.offset(1), len - index);
                // Skriv det i, overskriv den første kopi af elementet `index`.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Fjerner og returnerer elementet i position `index` inden for vector og skifter alle elementerne efter det til venstre.
    ///
    ///
    /// # Panics
    ///
    /// Panics hvis `index` er uden for grænserne.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // det sted, vi tager fra.
                let ptr = self.as_mut_ptr().add(index);
                // kopier det ud, uden at have en kopi af værdien på stakken og i vector på samme tid.
                //
                ret = ptr::read(ptr);

                // Skift alt ned for at udfylde det sted.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Beholder kun de elementer, der er angivet af prædikatet.
    ///
    /// Fjern med andre ord alle elementer `e`, så `f(&e)` returnerer `false`.
    /// Denne metode fungerer på plads, besøger hvert element nøjagtigt en gang i den oprindelige rækkefølge og bevarer rækkefølgen af de tilbageholdte elementer.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Da elementerne besøges nøjagtigt en gang i den oprindelige rækkefølge, kan ekstern tilstand bruges til at bestemme, hvilke elementer der skal opbevares.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Undgå dobbelt fald, hvis faldbeskyttelsen ikke udføres, da vi muligvis laver nogle huller under processen.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-behandlet len-> |^-ved siden af kontrol
        //                  | <-slettet cnt-> |
        //      | <-original_len-> |Opbevares: Elementer, som predikat returnerer sandt på.
        //
        // Hul: Flyttet eller droppet elementåbning.
        // Ikke markeret: Ikke markeret gyldige elementer.
        //
        // Denne dropvagt påberåbes, når prædikat eller `drop` af element går i panik.
        // Det skifter ukontrollerede elementer for at dække huller og `set_len` til den korrekte længde.
        // I tilfælde, hvor predikat og `drop` aldrig går i panik, optimeres det.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // SIKKERHED: Efterfølgende ikke-markerede emner skal være gyldige, da vi aldrig rører ved dem.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // SIKKERHED: Efter fyldning af huller er alle genstande i sammenhængende hukommelse.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // SIKKERHED: Ikke markeret element skal være gyldigt.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Gå frem tidligt for at undgå dobbelt fald, hvis `drop_in_place` får panik.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // SIKKERHED: Vi rører aldrig ved dette element igen efter faldet.
                unsafe { ptr::drop_in_place(cur) };
                // Vi har allerede skubbet tælleren frem.
                continue;
            }
            if g.deleted_cnt > 0 {
                // SIKKERHED: `deleted_cnt`> 0, så hulspalten må ikke overlappe det aktuelle element.
                // Vi bruger kopi til flytning og rører aldrig ved dette element igen.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Alle varer behandles.Dette kan optimeres til `set_len` af LLVM.
        drop(g);
    }

    /// Fjerner alle undtagen de første på hinanden følgende elementer i vector, der løser samme nøgle.
    ///
    ///
    /// Hvis vector er sorteret, fjerner dette alle dubletter.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Fjerner alle undtagen de første af på hinanden følgende elementer i vector, der tilfredsstiller en given ligestillingsrelation.
    ///
    /// `same_bucket`-funktionen sendes henvisninger til to elementer fra vector og skal afgøre, om elementerne sammenligner ens.
    /// Elementerne sendes i modsat rækkefølge fra deres rækkefølge i udsnittet, så hvis `same_bucket(a, b)` returnerer `true`, fjernes `a`.
    ///
    ///
    /// Hvis vector er sorteret, fjerner dette alle dubletter.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Tilføjer et element på bagsiden af en samling.
    ///
    /// # Panics
    ///
    /// Panics hvis den nye kapacitet overstiger `isize::MAX` bytes.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Dette vil panic eller afbrydes, hvis vi tildeler> isize::MAX bytes, eller hvis længdeforøgelsen ville løbe over for nulstørrelsestyper.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Fjerner det sidste element fra en vector og returnerer det, eller [`None`], hvis det er tomt.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Flytter alle elementerne i `other` til `Self` og efterlader `other` tomme.
    ///
    /// # Panics
    ///
    /// Panics hvis antallet af elementer i vector overløber en `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Føjer elementer til `Self` fra anden buffer.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Opretter en dræning iterator, der fjerner det angivne område i vector og giver de fjernede emner.
    ///
    /// Når iteratoren **er faldet**, fjernes alle elementer i området fra vector, selvom iteratoren ikke var fuldt forbrugt.
    /// Hvis iteratoren **ikke** droppes (f.eks. Med [`mem::forget`]), er det uspecificeret, hvor mange elementer der fjernes.
    ///
    /// # Panics
    ///
    /// Panics hvis startpunktet er større end slutpunktet, eller hvis slutpunktet er større end længden af vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Et komplet sortiment rydder vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Hukommelsessikkerhed
        //
        // Når Drain oprettes første gang, forkorter den længden af kilden vector for at sikre, at ingen uninitialiserede eller flyttede elementer er tilgængelige overhovedet, hvis Drain s destruktør aldrig kommer til at køre.
        //
        //
        // Drain vil ptr::read ud af de værdier, der skal fjernes.
        // Når du er færdig, kopieres den resterende hale af vecet tilbage for at dække hullet, og vector-længden gendannes til den nye længde.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // indstil self.vec-længden for at starte, for at være sikker, hvis Drain lækker
            self.set_len(start);
            // Brug lånet i IterMut til at indikere låneadfærd for hele Drain iteratoren (som &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Rydder vector og fjerner alle værdier.
    ///
    /// Bemærk, at denne metode ikke har nogen effekt på vector's tildelte kapacitet.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Returnerer antallet af elementer i vector, også kaldet dens 'length'.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Returnerer `true`, hvis vector ikke indeholder nogen elementer.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Opdeler samlingen i to ved det givne indeks.
    ///
    /// Returnerer et nyligt tildelt vector, der indeholder elementerne i området `[at, len)`.
    /// Efter opkaldet forbliver den originale vector indeholdende elementerne `[0, at)` med den tidligere kapacitet uændret.
    ///
    ///
    /// # Panics
    ///
    /// Panics hvis `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // den nye vector kan overtage den originale buffer og undgå kopien
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Usikker `set_len` og kopier elementer til `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Ændrer størrelsen på `Vec` på plads, så `len` er lig med `new_len`.
    ///
    /// Hvis `new_len` er større end `len`, udvides `Vec` med forskellen, hvor hver ekstra slot er fyldt med resultatet af at kalde lukningen `f`.
    ///
    /// Returværdierne fra `f` ender i `Vec` i den rækkefølge, de er genereret.
    ///
    /// Hvis `new_len` er mindre end `len`, afkortes `Vec` simpelthen.
    ///
    /// Denne metode bruger en lukning til at skabe nye værdier på hvert skub.Hvis du hellere vil [`Clone`] en given værdi, skal du bruge [`Vec::resize`].
    /// Hvis du vil bruge [`Default`] trait til at generere værdier, kan du videregive [`Default::default`] som det andet argument.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Forbruger og lækker `Vec` og returnerer en ændret henvisning til indholdet, `&'a mut [T]`.
    /// Bemærk, at typen `T` skal overleve den valgte levetid `'a`.
    /// Hvis typen kun har statiske referencer eller slet ingen, kan dette vælges til at være `'static`.
    ///
    /// Denne funktion svarer til [`leak`][Box::leak]-funktionen på [`Box`] bortset fra at der ikke er nogen måde at gendanne den lækkede hukommelse.
    ///
    ///
    /// Denne funktion er hovedsagelig nyttig til data, der lever resten af programmets liv.
    /// Hvis du returnerer den returnerede reference, forårsager en hukommelseslækage.
    ///
    /// # Examples
    ///
    /// Enkel brug:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Returnerer den resterende ledige kapacitet på vector som et stykke `MaybeUninit<T>`.
    ///
    /// Det returnerede stykke kan bruges til at fylde vector med data (f.eks
    /// ved at læse fra en fil) inden du markerer dataene som initialiseret ved hjælp af [`set_len`]-metoden.
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Tildel vector stor nok til 10 elementer.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Udfyld de første 3 elementer.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Marker de første 3 elementer i vector som initialiseret.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Denne metode er ikke implementeret i form af `split_at_spare_mut` for at forhindre ugyldiggørelse af markører til bufferen.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Returnerer vector-indhold som et stykke `T` sammen med den resterende ledige kapacitet på vector som et stykke `MaybeUninit<T>`.
    ///
    /// Den returnerede ledige kapacitet kan bruges til at udfylde vector med data (f.eks. Ved at læse fra en fil), før data markeres som initialiseret ved hjælp af [`set_len`]-metoden.
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Bemærk, at dette er et API på lavt niveau, som skal bruges med omhu til optimeringsformål.
    /// Hvis du har brug for at tilføje data til en `Vec`, kan du bruge [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] eller [`resize_with`], afhængigt af dine nøjagtige behov.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Reserver ekstra plads, der er stor nok til 10 elementer.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Udfyld de næste 4 elementer.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Marker de 4 elementer i vector som initialiseret.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len ignoreres og ændres aldrig
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Sikkerhed: Ændring af returneret .2 (&mut-størrelse) betragtes som det samme som at ringe til `.set_len(_)`.
    ///
    /// Denne metode bruges til at have unik adgang til alle vec-dele på én gang i `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` er garanteret gyldig for `len`-elementer
        // - `spare_ptr` peger et element forbi bufferen, så det ikke overlapper med `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Ændrer størrelsen på `Vec` på plads, så `len` er lig med `new_len`.
    ///
    /// Hvis `new_len` er større end `len`, udvides `Vec` med forskellen, hvor hvert ekstra slot er fyldt med `value`.
    ///
    /// Hvis `new_len` er mindre end `len`, afkortes `Vec` simpelthen.
    ///
    /// Denne metode kræver, at `T` implementerer [`Clone`] for at kunne klone den beståede værdi.
    /// Hvis du har brug for mere fleksibilitet (eller vil stole på [`Default`] i stedet for [`Clone`]), skal du bruge [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Kloner og tilføjer alle elementer i et stykke til `Vec`.
    ///
    /// Itererer over udsnittet `other`, kloner hvert element og tilføjer det derefter til denne `Vec`.
    /// `other` vector krydses i rækkefølge.
    ///
    /// Bemærk, at denne funktion er den samme som [`extend`], bortset fra at den er specialiseret i at arbejde med skiver i stedet.
    ///
    /// Hvis og når Rust får specialisering, vil denne funktion sandsynligvis blive udfaset (men stadig tilgængelig).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Kopierer elementer fra `src` rækkevidde til slutningen af vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` garanterer, at det givne interval er gyldigt til indeksering af mig selv
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Denne kode generaliserer `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Udvid vector med `n`-værdier ved hjælp af den givne generator.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Brug SetLenOnDrop til at omgå fejl, hvor kompilator muligvis ikke realiserer butikken gennem `ptr` til self.set_len(), ikke alias.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Skriv alle elementer undtagen det sidste
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Forøg længden i hvert trin i tilfælde af next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Vi kan skrive det sidste element direkte uden unødvendig kloning
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // Len indstillet af Scope Guard
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Fjerner gentagne gentagne elementer i vector i henhold til [`PartialEq`] trait implementeringen.
    ///
    ///
    /// Hvis vector er sorteret, fjerner dette alle dubletter.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Interne metoder og funktioner
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` skal være gyldigt indeks
    /// - `self.capacity() - self.len()` skal være `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len øges kun efter initialisering af elementer
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - opkalderen garanterer, at src er et gyldigt indeks
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Element blev lige initialiseret med `MaybeUninit::write`, så det er ok at øge len
            // - len øges efter hvert element for at forhindre lækager (se udgave #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - opkalderen garanterer, at `src` er et gyldigt indeks
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Begge markører oprettes ud fra unikke udsnithenvisninger (`&mut [_]`), så de er gyldige og ikke overlapper hinanden.
            //
            // - Elementerne er: Kopier, så det er OK at kopiere dem uden at gøre noget med de originale værdier
            // - `count` er lig med len af `source`, så kilden er gyldig for `count` læser
            // - `.reserve(count)` garanterer, at `spare.len() >= count` så reserve er gyldig til `count` skriver
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Elementerne blev lige initialiseret af `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Almindelige trait-implementeringer til Vec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): med cfg(test) er den iboende `[T]::to_vec`-metode, som kræves til denne metodedefinition, ikke tilgængelig.
    // Brug i stedet `slice::to_vec`-funktionen, som kun er tilgængelig med cfg(test) NB Se slice::hack-modulet i slice.rs for mere information
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // slip noget, der ikke overskrives
        self.truncate(other.len());

        // self.len <= other.len på grund af afkortningen ovenfor, så skiverne her er altid inden for rammerne.
        //
        let (init, tail) = other.split_at(self.len());

        // genbrug de indeholdte værdier allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Opretter en forbrugende iterator, det vil sige en, der flytter hver værdi ud af vector (fra start til slut).
    /// vector kan ikke bruges efter at have ringet til dette.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s har typen String, ikke &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // bladmetode, som forskellige SpecFrom/SpecExtend-implementeringer delegerer, når de ikke har yderligere optimeringer at anvende
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Dette er tilfældet for en generel iterator.
        //
        // Denne funktion skal være den moralske ækvivalent med:
        //
        //      for vare i iterator {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB kan ikke overløbe, da vi ville have været nødt til at tildele adresseområdet
                self.set_len(len + 1);
            }
        }
    }

    /// Opretter en splejsning iterator, der erstatter det angivne område i vector med den givne `replace_with` iterator og giver de fjernede emner.
    ///
    /// `replace_with` behøver ikke at have samme længde som `range`.
    ///
    /// `range` fjernes, selvom iteratoren ikke forbruges indtil slutningen.
    ///
    /// Det er ikke specificeret, hvor mange elementer der fjernes fra vector, hvis `Splice`-værdien lækker.
    ///
    /// Input-iteratoren `replace_with` forbruges kun, når `Splice`-værdien er faldet.
    ///
    /// Dette er optimalt, hvis:
    ///
    /// * Halen (elementer i vector efter `range`) er tom,
    /// * eller `replace_with` giver færre eller lige store elementer end 'rækkevidde'
    /// * eller den nedre grænse for dens `size_hint()` er nøjagtig.
    ///
    /// Ellers tildeles en midlertidig vector, og halen flyttes to gange.
    ///
    /// # Panics
    ///
    /// Panics hvis startpunktet er større end slutpunktet, eller hvis slutpunktet er større end længden af vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Opretter en iterator, der bruger en lukning til at bestemme, om et element skal fjernes.
    ///
    /// Hvis lukningen returnerer sand, fjernes elementet og giver det.
    /// Hvis lukningen returnerer falsk, forbliver elementet i vector og vil ikke blive givet af iteratoren.
    ///
    /// Brug af denne metode svarer til følgende kode:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // din kode her
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Men `drain_filter` er lettere at bruge.
    /// `drain_filter` er også mere effektiv, fordi den kan tilbageføre elementerne i arrayet i bulk.
    ///
    /// Bemærk, at `drain_filter` også lader dig mutere hvert element i filterlukningen, uanset om du vælger at beholde eller fjerne det.
    ///
    ///
    /// # Examples
    ///
    /// Opdeling af en matrix i jævnheder og odds ved at genbruge den oprindelige tildeling:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Beskyt mod at vi lækker (lækageforstærkning)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Udvid implementeringen, der kopierer elementer ud af referencer, før du skubber dem til Vec.
///
/// Denne implementering er specialiseret til udsnit iteratorer, hvor den bruger [`copy_from_slice`] til at tilføje hele udsnittet på én gang.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Implementerer sammenligning af vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Implementerer bestilling af vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // brug drop til [T] brug en rå skive til at henvise til elementerne i vector som den svageste nødvendige type;
            //
            // kunne undgå gyldighedsspørgsmål i visse tilfælde
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec håndterer deallocation
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Opretter en tom `Vec<T>`.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: test trækker i libstd, hvilket forårsager fejl her
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: test trækker i libstd, hvilket forårsager fejl her
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Henter hele indholdet af `Vec<T>` som en matrix, hvis dens størrelse nøjagtigt svarer til den ønskede matrix.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Hvis længden ikke stemmer overens, kommer input tilbage i `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Hvis du har det godt med bare at få et præfiks af `Vec<T>`, kan du først ringe til [`.truncate(N)`](Vec::truncate).
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // SIKKERHED: `.set_len(0)` er altid lyd.
        unsafe { vec.set_len(0) };

        // SIKKERHED: En `Vec`s markør er altid justeret korrekt, og
        // justeringen, som arrayet har brug for, er den samme som elementerne.
        // Vi kontrollerede tidligere, at vi har tilstrækkelige varer.
        // Varerne vil ikke falde dobbelt, da `set_len` beder `Vec` om ikke også at tabe dem.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}