#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Indholdet af den nye hukommelse er ikke-initialiseret.
    Uninitialized,
    /// Den nye hukommelse nulstilles garanteret.
    Zeroed,
}

/// Et værktøj på lavt niveau til mere ergonomisk allokering, omfordeling og deallokering af en hukommelsesbuffer på bunken uden at skulle bekymre sig om alle de involverede hjørnesager.
///
/// Denne type er fremragende til opbygning af dine egne datastrukturer som Vec og VecDeque.
/// I særdeleshed:
///
/// * Producerer `Unique::dangling()` på nul-størrelse typer.
/// * Producerer `Unique::dangling()` på allokering uden længde.
/// * Undgår at frigøre `Unique::dangling()`.
/// * Fanger alle overløb i kapacitetsberegninger (promoverer dem til "capacity overflow" panics).
/// * Beskytter mod 32-bit-systemer, der tildeler mere end isize::MAX bytes.
/// * Beskytter mod overfyldning af din længde.
/// * Opfordrer til `handle_alloc_error` for fejlbare tildelinger.
/// * Indeholder en `ptr::Unique` og giver brugeren dermed alle relaterede fordele.
/// * Bruger det overskud, der returneres fra tildeleren, til at bruge den største tilgængelige kapacitet.
///
/// Denne type inspicerer alligevel ikke den hukommelse, den administrerer.Når det er droppet *frigør det* hukommelsen, men det *prøver ikke* at slippe dets indhold.
/// Det er op til brugeren af `RawVec` at håndtere de faktiske ting *gemt* inde i en `RawVec`.
///
/// Bemærk, at overskuddet af nul-størrelse typer altid er uendeligt, så `capacity()` returnerer altid `usize::MAX`.
/// Dette betyder, at du skal være forsigtig, når du afrunder denne type med en `Box<[T]>`, da `capacity()` ikke giver længden.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Dette eksisterer, fordi `#[unstable]` `const fn`s ikke behøver at være i overensstemmelse med `min_const_fn`, og derfor kan de heller ikke kaldes i`min_const_fn`s.
    ///
    /// Hvis du ændrer `RawVec<T>::new` eller afhængigheder, skal du sørge for ikke at introducere noget, der virkelig overtræder `min_const_fn`.
    ///
    /// NOTE: Vi kunne undgå dette hack og kontrollere overensstemmelse med en eller anden `#[rustc_force_min_const_fn]`-attribut, der kræver overensstemmelse med `min_const_fn`, men tillader ikke nødvendigvis at kalde den i `stable(...) const fn`/brugerkode, der ikke aktiverer `foo`, når `#[rustc_const_unstable(feature = "foo", issue = "01234")]` er til stede.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Opretter den størst mulige `RawVec` (på systembunken) uden tildeling.
    /// Hvis `T` har positiv størrelse, udgør dette en `RawVec` med kapacitet `0`.
    /// Hvis `T` er nulstørrelse, laver det en `RawVec` med kapacitet `usize::MAX`.
    /// Nyttig til implementering af forsinket tildeling.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Opretter en `RawVec` (på systembunken) med nøjagtig kapacitet og justeringskrav til en `[T; capacity]`.
    /// Dette svarer til at ringe til `RawVec::new`, når `capacity` er `0` eller `T` er nul.
    /// Bemærk, at hvis `T` ikke har nogen størrelse, betyder det, at du *ikke* får en `RawVec` med den ønskede kapacitet.
    ///
    /// # Panics
    ///
    /// Panics hvis den anmodede kapacitet overstiger `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Aborterer på OOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Ligesom `with_capacity`, men garanterer, at bufferen er nulstillet.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Genopretter en `RawVec` fra en markør og kapacitet.
    ///
    /// # Safety
    ///
    /// `ptr` skal tildeles (på systembunken) og med den givne `capacity`.
    /// `capacity` kan ikke overstige `isize::MAX` for typer af størrelse.(kun en bekymring på 32-bit-systemer).
    /// ZST vektorer kan have en kapacitet op til `usize::MAX`.
    /// Hvis `ptr` og `capacity` kommer fra en `RawVec`, er dette garanteret.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Tiny Vecs er dumme.Spring til:
    // - 8, hvis elementstørrelsen er 1, fordi en bunkeallokering sandsynligvis afrunder en anmodning på mindre end 8 byte til mindst 8 byte.
    //
    // - 4, hvis elementerne er i moderat størrelse (<=1 KiB).
    // - 1 ellers for at undgå at spilde for meget plads til meget korte Vecs.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Ligesom `new`, men parametreret over valget af allokator for den returnerede `RawVec`.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` betyder "unallocated".nulstørrelsestyper ignoreres.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Ligesom `with_capacity`, men parametreret over valget af allokator for den returnerede `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Ligesom `with_capacity_zeroed`, men parametreret over valget af allokator for den returnerede `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Konverterer en `Box<[T]>` til en `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Konverterer hele bufferen til `Box<[MaybeUninit<T>]>` med den angivne `len`.
    ///
    /// Bemærk, at dette korrekt rekonstruerer eventuelle `cap`-ændringer, der måtte være udført.(Se beskrivelse af typen for detaljer.)
    ///
    /// # Safety
    ///
    /// * `len` skal være større end eller lig med den senest anmodede kapacitet, og
    /// * `len` skal være mindre end eller lig med `self.capacity()`.
    ///
    /// Bemærk, at den anmodede kapacitet og `self.capacity()` kan variere, da en allokator kunne samle og returnere en større hukommelsesblok end anmodet om.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Sanity-check den ene halvdel af sikkerhedskravet (vi kan ikke kontrollere den anden halvdel).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Vi undgår `unwrap_or_else` her, fordi det spreder mængden af genereret LLVM IR.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Genopretter en `RawVec` fra en markør, kapacitet og tildeler.
    ///
    /// # Safety
    ///
    /// `ptr` skal tildeles (via den givne allocator `alloc`) og med den givne `capacity`.
    /// `capacity` kan ikke overstige `isize::MAX` for typer af størrelse.
    /// (kun en bekymring på 32-bit-systemer).
    /// ZST vektorer kan have en kapacitet op til `usize::MAX`.
    /// Hvis `ptr` og `capacity` kommer fra en `RawVec` oprettet via `alloc`, er dette garanteret.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Får en rå markør til starten af tildelingen.
    /// Bemærk, at dette er `Unique::dangling()`, hvis `capacity == 0` eller `T` er nul.
    /// I det første tilfælde skal du være forsigtig.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Henter kapaciteten for tildelingen.
    ///
    /// Dette vil altid være `usize::MAX`, hvis `T` er nul.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Returnerer en delt reference til tildeleren, der bakker op om denne `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Vi har et tildelt stykke hukommelse, så vi kan omgå runtime-kontroller for at få vores nuværende layout.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Sikrer, at bufferen indeholder mindst nok plads til at indeholde `len + additional`-elementer.
    /// Hvis det ikke allerede har tilstrækkelig kapacitet, vil det allokere nok plads plus behagelig slap plads til at blive amortiseret *O*(1) adfærd.
    ///
    /// Begrænser denne adfærd, hvis det unødvendigt ville forårsage sig panic.
    ///
    /// Hvis `len` overstiger `self.capacity()`, kan dette muligvis ikke tildele den ønskede plads.
    /// Dette er ikke rigtig usikkert, men den usikre kode *du* skriver, der er afhængig af denne funktions opførsel, kan gå i stykker.
    ///
    /// Dette er ideelt til implementering af en bulk-push-operation som `extend`.
    ///
    /// # Panics
    ///
    /// Panics hvis den nye kapacitet overstiger `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Aborterer på OOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // reserve ville have afbrudt eller få panik, hvis len oversteg `isize::MAX`, så dette er sikkert at gøre ukontrolleret nu.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Det samme som `reserve`, men vender tilbage ved fejl i stedet for at gå i panik eller afbryde.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Sikrer, at bufferen indeholder mindst nok plads til at indeholde `len + additional`-elementer.
    /// Hvis det ikke allerede gør det, omfordeles den mindste mulige mængde hukommelse, der er nødvendig.
    /// Generelt vil dette være nøjagtig den mængde hukommelse, der er nødvendig, men i princippet kan allokeringen give mere tilbage, end vi bad om.
    ///
    ///
    /// Hvis `len` overstiger `self.capacity()`, kan dette muligvis ikke tildele den ønskede plads.
    /// Dette er ikke rigtig usikkert, men den usikre kode *du* skriver, der er afhængig af denne funktions opførsel, kan gå i stykker.
    ///
    /// # Panics
    ///
    /// Panics hvis den nye kapacitet overstiger `isize::MAX` bytes.
    ///
    /// # Aborts
    ///
    /// Aborterer på OOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Det samme som `reserve_exact`, men vender tilbage ved fejl i stedet for at gå i panik eller afbryde.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Krymper tildelingen ned til det angivne beløb.
    /// Hvis det givne beløb er 0, deallocates faktisk helt.
    ///
    /// # Panics
    ///
    /// Panics hvis det givne beløb er *større* end den aktuelle kapacitet.
    ///
    /// # Aborts
    ///
    /// Aborterer på OOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Returnerer, hvis bufferen skal vokse for at opfylde den nødvendige ekstra kapacitet.
    /// Bruges hovedsagelig til at muliggøre indlejring af reserveopkald uden indlejring af `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Denne metode instantieres normalt mange gange.Så vi ønsker, at det skal være så lille som muligt for at forbedre kompileringstiderne.
    // Men vi ønsker også, at så meget af dets indhold skal være statisk beregningsbar som muligt for at få den genererede kode til at køre hurtigere.
    // Derfor er denne metode nøje skrevet, så al den kode, der afhænger af `T`, er inden i den, mens så meget af koden, der ikke afhænger af `T`, er i funktioner, der ikke er generiske over `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Dette sikres ved de kaldende sammenhænge.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Da vi returnerer en kapacitet på `usize::MAX`, når `elem_size` er
            // 0, at komme til her betyder nødvendigvis, at `RawVec` er overfyldt.
            return Err(CapacityOverflow);
        }

        // Intet vi virkelig kan gøre ved disse kontroller, desværre.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Dette garanterer eksponentiel vækst.
        // Fordoblingen kan ikke løbe over, fordi `cap <= isize::MAX` og typen `cap` er `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` er ikke-generisk over `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Begrænsningerne for denne metode er meget de samme som dem på `grow_amortized`, men denne metode instantieres normalt sjældnere, så den er mindre kritisk.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Da vi returnerer en kapacitet på `usize::MAX`, når typestørrelsen er
            // 0, at komme til her betyder nødvendigvis, at `RawVec` er overfyldt.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` er ikke-generisk over `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Denne funktion er uden for `RawVec` for at minimere kompileringstider.Se kommentaren ovenfor `RawVec::grow_amortized` for detaljer.
// (`A`-parameteren er ikke signifikant, fordi antallet af forskellige `A`-typer set i praksis er meget mindre end antallet af `T`-typer.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Kontroller for fejlen her for at minimere størrelsen på `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Tildeler kontrollerer for ligestilling ved tilpasning
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Frigør hukommelsen, der ejes af `RawVec`*uden at* forsøge at slippe indholdet.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Central funktion til håndtering af reservefejl.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Vi skal garantere følgende:
// * Vi tildeler aldrig `> isize::MAX` byte-størrelse objekter.
// * Vi overløber ikke `usize::MAX` og tildeler faktisk for lidt.
//
// På 64-bit er vi bare nødt til at kontrollere for overløb, da forsøg på at tildele `> isize::MAX`-byte helt sikkert vil mislykkes.
// På 32-bit og 16-bit er vi nødt til at tilføje en ekstra vagt til dette, hvis vi kører på en platform, der kan bruge alle 4 GB i brugerplads, f.eks. PAE eller x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// En central funktion, der er ansvarlig for rapportering af kapacitetsoverløb.
// Dette vil sikre, at kodegenerering relateret til disse panics er minimal, da der kun er en placering, som panics snarere end en flok i hele modulet.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}