use core::marker::PhantomData;
use core::ptr::NonNull;

/// Modellerer en genoptagelse af en unik reference, når du ved, at genoplivningen og alle dens efterkommere (dvs. alle markører og referencer, der stammer fra den) ikke vil blive brugt mere på et tidspunkt, hvorefter du vil bruge den originale unikke reference igen .
///
///
/// Lånekontrollen håndterer normalt denne stabling af lån til dig, men nogle kontrolflow, der udfører denne stabling, er for komplicerede til at kompilatoren kan følge.
/// En `DormantMutRef` giver dig mulighed for at kontrollere låntagning selv, mens du stadig udtrykker dens stablede natur og indkapsler den rå pointerkode, der er nødvendig for at gøre dette uden udefineret adfærd.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Tag et unikt lån, og genlån det straks.
    /// For kompilatoren er levetiden for den nye reference den samme som levetiden for den oprindelige reference, men du promise for at bruge den i en kortere periode.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // SIKKERHED: vi holder lånet igennem 'a via `_marker`, og vi udsætter
        // kun denne reference, så den er unik.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Gå tilbage til den unikke lån, der oprindeligt blev fanget.
    ///
    /// # Safety
    ///
    /// Genudlånet skal være afsluttet, dvs. referencen, der returneres af `new`, og alle henvisninger og referencer, der stammer fra den, må ikke bruges mere.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // SIKKERHED: vores egne sikkerhedsforhold betyder, at denne reference igen er unik.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;