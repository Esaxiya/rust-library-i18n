use core::intrinsics;
use core::mem;
use core::ptr;

/// Dette erstatter værdien bag den unikke `v`-reference ved at kalde den relevante funktion.
///
///
/// Hvis der opstår en panic i `change`-lukningen, afbrydes hele processen.
#[allow(dead_code)] // opbevares som illustration og til brug af future
#[inline]
pub fn take_mut<T>(v: &mut T, change: impl FnOnce(T) -> T) {
    replace(v, |value| (change(value), ()))
}

/// Dette erstatter værdien bag den unikke `v`-reference ved at kalde den relevante funktion og returnerer et opnået resultat undervejs.
///
///
/// Hvis der opstår en panic i `change`-lukningen, afbrydes hele processen.
#[inline]
pub fn replace<T, R>(v: &mut T, change: impl FnOnce(T) -> (T, R)) -> R {
    struct PanicGuard;
    impl Drop for PanicGuard {
        fn drop(&mut self) {
            intrinsics::abort()
        }
    }
    let guard = PanicGuard;
    let value = unsafe { ptr::read(v) };
    let (new_value, ret) = change(value);
    unsafe {
        ptr::write(v, new_value);
    }
    mem::forget(guard);
    ret
}