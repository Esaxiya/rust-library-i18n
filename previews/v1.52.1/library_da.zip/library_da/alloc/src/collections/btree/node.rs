// Dette er et forsøg på en implementering efter idealet
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Da Rust faktisk ikke har afhængige typer og polymorf rekursion, nøder vi os med masser af usikkerhed.
//

// Et hovedmål med dette modul er at undgå kompleksitet ved at behandle træet som en generisk (hvis underligt formet) beholder og undgå at håndtere de fleste af B-Tree-invarianterne.
//
// Som sådan er dette modul ligeglad med, om posterne er sorteret, hvilke noder der kan være for fulde eller endda hvad underfulde betyder.Vi stoler dog på et par invarianter:
//
// - Træer skal have ensartet depth/height.Dette betyder, at hver sti ned til et blad fra en given node har nøjagtig samme længde.
// - En node med længden `n` har `n`-nøgler, `n`-værdier og `n + 1`-kanter.
//   Dette indebærer, at selv en tom node har mindst en edge.
//   For en bladknude betyder "having an edge" kun, at vi kan identificere en position i knuden, da bladkanter er tomme og ikke behøver nogen datarepræsentation.
// I en intern node identificerer en edge begge en position og indeholder en markør til en undernode.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Den underliggende repræsentation af bladnoder og en del af repræsentationen af interne noder.
struct LeafNode<K, V> {
    /// Vi vil være covariant i `K` og `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Denne node indeks i den overordnede node's `edges` array.
    /// `*node.parent.edges[node.parent_idx]` skal være den samme som `node`.
    /// Dette garanteres kun, at det initialiseres, når `parent` ikke er nul.
    parent_idx: MaybeUninit<u16>,

    /// Antallet af nøgler og værdier, som denne node gemmer.
    len: u16,

    /// Arrays, der lagrer de faktiske data for noden.
    /// Kun de første `len`-elementer i hver matrix initialiseres og er gyldige.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Initialiserer en ny `LeafNode` på plads.
    unsafe fn init(this: *mut Self) {
        // Som en generel politik forlader vi felter uinitialiserede, hvis de kan være, da dette skal være både lidt hurtigere og lettere at spore i Valgrind.
        //
        unsafe {
            // parent_idx, nøgler og vals er alle MaybeUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Opretter en ny box `LeafNode`.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Den underliggende repræsentation af interne noder.Som med 'LeafNode' skal disse skjules bag 'BoxedNode' for at forhindre, at uinitialiserede nøgler og værdier tabes.
/// Enhver markør til en `InternalNode` kan kastes direkte til en markør til den underliggende `LeafNode`-del af knudepunktet, hvilket gør det muligt for koden at virke på blad-og interne noder generisk uden selv at skulle kontrollere, hvilken af de to en markør peger på.
///
/// Denne egenskab er aktiveret ved brug af `repr(C)`.
///
#[repr(C)]
// gdb_providers.py bruger denne type navn til introspektion.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Henvisningerne til børnene på denne knude.
    /// `len + 1` af disse betragtes som initialiseret og gyldig, bortset fra at nær slutningen, mens træet holdes gennem lånetype `Dying`, hænger nogle af disse markører.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Opretter en ny box `InternalNode`.
    ///
    /// # Safety
    /// En invariant af interne noder er, at de har mindst en initialiseret og gyldig edge.
    /// Denne funktion opsætter ikke en sådan edge.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Vi behøver kun at initialisere dataene;kanterne er MaybeUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// En styret, ikke-nul-markør til en node.Dette er enten en ejet markør til `LeafNode<K, V>` eller en ejet markør til `InternalNode<K, V>`.
///
/// `BoxedNode` indeholder dog ingen oplysninger om, hvilken af de to typer noder den faktisk indeholder, og er delvist på grund af denne mangel på information ikke en separat type og har ingen destruktor.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Rodknudepunktet på et ejet træ.
///
/// Bemærk, at dette ikke har en destruktor og skal renses manuelt.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Returnerer et nyt ejet træ med sin egen rodnode, der oprindeligt er tom.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` må ikke være nul.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Låner gensidigt den ejede rodnode.
    /// I modsætning til `reborrow_mut` er dette sikkert, fordi returværdien ikke kan bruges til at ødelægge roden, og der kan ikke være andre referencer til træet.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Lån let mutabelt den ejede rodnode.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Irreversibelt overgår til en reference, der tillader gennemkørsel og tilbyder destruktive metoder og lidt andet.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Tilføjer en ny intern node med en enkelt edge, der peger på den forrige rodnode, gør den nye node til rodnoden, og returner den.
    /// Dette øger højden med 1 og er det modsatte af `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, bortset fra at vi bare glemte, at vi er interne nu:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Fjerner den interne rodknude ved hjælp af dens første underordnede som den nye rodknude.
    /// Da det kun er meningen, at det skal kaldes, når rodknudepunktet kun har et barn, foretages der ingen oprydning på nogen af nøglerne, værdierne og andre børn.
    ///
    /// Dette reducerer højden med 1 og er det modsatte af `push_internal_level`.
    ///
    /// Kræver eksklusiv adgang til `Root`-objektet, men ikke til rodnoden;
    /// det ugyldiggør ikke andre håndtag eller referencer til rodnoden.
    ///
    /// Panics hvis der ikke er noget internt niveau, dvs. hvis rodnoden er et blad.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // SIKKERHED: vi hævdede at være interne.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // SIKKERHED: vi lånte `self` udelukkende, og dens lånetype er eksklusiv.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // SIKKERHED: den første edge initialiseres altid.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` er altid kovariant i `K` og `V`, selv når `BorrowType` er `Mut`.
// Dette er teknisk forkert, men kan ikke resultere i usikkerhed på grund af intern brug af `NodeRef`, fordi vi forbliver helt generiske over `K` og `V`.
//
// Men når en offentlig type indpakker `NodeRef`, skal du sørge for, at den har den korrekte varians.
//
/// En henvisning til en node.
///
/// Denne type har et antal parametre, der styrer, hvordan den fungerer:
/// - `BorrowType`: En dummy-type, der beskriver låntagningen og bærer hele livet.
///    - Når dette er `Immut<'a>`, fungerer `NodeRef` omtrent som `&'a Node`.
///    - Når dette er `ValMut<'a>`, fungerer `NodeRef` omtrent som `&'a Node` med hensyn til nøgler og træstruktur, men tillader også, at mange ændrede referencer til værdier i hele træet eksisterer sammen.
///    - Når dette er `Mut<'a>`, fungerer `NodeRef` omtrent som `&'a mut Node`, selvom indsætningsmetoder tillader, at en ændret markør til en værdi eksisterer sammen.
///    - Når dette er `Owned`, fungerer `NodeRef` omtrent som `Box<Node>`, men har ikke en destruktor og skal renses manuelt.
///    - Når dette er `Dying`, fungerer `NodeRef` stadig omtrent som `Box<Node>`, men har metoder til at ødelægge træet lidt efter lidt, og almindelige metoder, selvom de ikke er markeret som usikre at ringe til, kan påkalde UB, hvis de kaldes forkert.
///
///   Da enhver `NodeRef` tillader navigering gennem træet, gælder `BorrowType` effektivt for hele træet, ikke kun selve noden.
/// - `K` og `V`: Dette er de typer nøgler og værdier, der er gemt i noderne.
/// - `Type`: Dette kan være `Leaf`, `Internal` eller `LeafOrInternal`.
/// Når dette er `Leaf`, peger `NodeRef` på en bladnode, når dette er `Internal`, peger `NodeRef` på en intern node, og når dette er `LeafOrInternal`, kan `NodeRef` pege på begge typer noder.
///   `Type` hedder `NodeType`, når det bruges uden for `NodeRef`.
///
/// Både `BorrowType` og `NodeType` begrænser, hvilke metoder vi implementerer, for at udnytte statisk sikkerhed.Der er begrænsninger i den måde, vi kan anvende sådanne begrænsninger på:
/// - For hver type parameter kan vi kun definere en metode enten generisk eller for en bestemt type.
/// For eksempel kan vi ikke definere en metode som `into_kv` generisk for alle `BorrowType` eller en gang for alle typer, der har en levetid, fordi vi ønsker, at den skal returnere `&'a`-referencer.
///   Derfor definerer vi det kun for den mindst kraftfulde type `Immut<'a>`.
/// - Vi kan ikke få implicit tvang fra f.eks. `Mut<'a>` til `Immut<'a>`.
///   Derfor skal vi eksplicit kalde `reborrow` på en mere kraftfuld `NodeRef` for at nå en metode som `into_kv`.
///
/// Alle metoder på `NodeRef`, der returnerer en slags reference, enten:
/// - Tag `self` efter værdi, og returner den levetid, der bæres af `BorrowType`.
///   Nogle gange er vi nødt til at ringe til `reborrow_mut` for at påkalde en sådan metode.
/// - Tag `self` som reference, og (implicitly) returnerer referencens levetid i stedet for den levetid, der bæres af `BorrowType`.
/// På den måde garanterer lånekontrollen, at `NodeRef` forbliver lånt, så længe den returnerede reference bruges.
///   Metoderne, der understøtter insert, bøjer denne regel ved at returnere en rå markør, dvs. en reference uden nogen levetid.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Antallet af niveauer, som knudepunktet og niveauet af blade er adskilt, en konstant af knudepunktet, der ikke kan beskrives fuldstændigt af `Type`, og som selve knudepunktet ikke lagrer.
    /// Vi behøver kun at gemme rodknudepunktets højde og udlede hver anden knudepunktshøjde fra den.
    /// Skal være nul, hvis `Type` er `Leaf` og ikke-nul, hvis `Type` er `Internal`.
    ///
    ///
    height: usize,
    /// Markøren til bladet eller den interne knude.
    /// Definitionen af `InternalNode` sikrer, at markøren er gyldig på begge måder.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Pak en nodereference ud, der var pakket som `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Eksponerer dataene for en intern node.
    ///
    /// Returnerer en rå ptr for at undgå ugyldiggørelse af andre referencer til denne node.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // SIKKERHED: den statiske nodetype er `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Låner eksklusiv adgang til dataene i en intern node.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Finder længden på noden.Dette er antallet af taster eller værdier.
    /// Antallet af kanter er `len() + 1`.
    /// Bemærk, at selvom det er sikkert, kan det at ringe til denne funktion have den bivirkning, at ugyldige referencer, som usikker kode har oprettet, ugyldes.
    ///
    pub fn len(&self) -> usize {
        // Afgørende er, at vi kun får adgang til `len`-feltet her.
        // Hvis BorrowType er marker::ValMut, kan der være udestående mutable referencer til værdier, som vi ikke må ugyldiggøre.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Returnerer antallet af niveauer, som knudepunktet og bladene er adskilt fra hinanden.
    /// Nul højde betyder, at noden er selve et blad.
    /// Hvis du ser træer med roden øverst, siger tallet, i hvilken højde noden vises.
    /// Hvis du ser træer med blade på toppen, siger tallet, hvor højt træet strækker sig over knuden.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Fjerner midlertidigt en anden, uforanderlig henvisning til den samme knude.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Eksponerer bladdelen af ethvert blad eller intern knude.
    ///
    /// Returnerer en rå ptr for at undgå ugyldiggørelse af andre referencer til denne node.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Noden skal være gyldig i mindst LeafNode-delen.
        // Dette er ikke en reference i NodeRef-typen, fordi vi ikke ved, om den skal være unik eller delt.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Finder forælder til den aktuelle node.
    /// Returnerer `Ok(handle)`, hvis den aktuelle node faktisk har en forælder, hvor `handle` peger på edge for den overordnede, der peger på den aktuelle node.
    ///
    /// Returnerer `Err(self)`, hvis den aktuelle node ikke har nogen overordnet, hvilket giver den originale `NodeRef` tilbage.
    ///
    /// Metodenavnet forudsætter, at du billedtræer med rodnoden øverst.
    ///
    /// `edge.descend().ascend().unwrap()` og `node.ascend().unwrap().descend()` skal begge efter succes ikke gøre noget.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Vi er nødt til at bruge rå pegepunkter til noder, fordi hvis BorrowType er marker::ValMut, kan der være udestående mutable referencer til værdier, som vi ikke må ugyldiggøre.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Bemærk, at `self` skal være ikke-frit.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Bemærk, at `self` skal være ikke-frit.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Eksponerer bladdelen af ethvert blad eller intern knude i et uforanderligt træ.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // SIKKERHED: der kan ikke være nogen ændrede referencer til dette træ lånt som `Immut`.
        unsafe { &*ptr }
    }

    /// Låner en visning til de nøgler, der er gemt i noden.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Svarende til `ascend`, får en henvisning til en nodes overordnede node, men deallokerer også den aktuelle node i processen.
    /// Dette er usikkert, fordi den aktuelle node stadig vil være tilgængelig på trods af at den er omplaceret.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Gør compileren usikre de statiske oplysninger om, at denne node er en `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Giver usikker sikkerhed til compileren de statiske oplysninger om, at denne node er en `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Fjerner midlertidigt en anden, ændret henvisning til den samme node.Pas på, da denne metode er meget farlig, dobbelt så da den måske ikke straks ser ud til at være farlig.
    ///
    /// Fordi ændrede markører kan strejfe overalt omkring træet, kan den returnerede markør let bruges til at gøre den oprindelige markør dinglende, uden for grænserne eller ugyldig under stablede låneregler.
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) overvej at tilføje endnu en type parameter til `NodeRef`, der begrænser brugen af navigationsmetoder på genudlånte markører, hvilket forhindrer denne usikkerhed.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Låner eksklusiv adgang til bladdelen af ethvert blad eller intern knude.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // SIKKERHED: vi har eksklusiv adgang til hele knudepunktet.
        unsafe { &mut *ptr }
    }

    /// Tilbyder eksklusiv adgang til bladdelen af ethvert blad eller intern knude.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // SIKKERHED: vi har eksklusiv adgang til hele knudepunktet.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Låner eksklusiv adgang til et element i nøgleopbevaringsområdet.
    ///
    /// # Safety
    /// `index` er inden for grænserne 0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // SIKKERHED: den, der ringer op, kan ikke kalde yderligere metoder på egen hånd
        // indtil referencen til nøglesnit er droppet, da vi har unik adgang i lånets levetid.
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Låner eksklusiv adgang til et element eller et stykke af nodens værdilagringsområde.
    ///
    /// # Safety
    /// `index` er inden for grænserne 0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // SIKKERHED: den, der ringer op, kan ikke kalde yderligere metoder på egen hånd
        // indtil referencen for værdiskive er droppet, da vi har unik adgang i lånets levetid.
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Låner eksklusiv adgang til et element eller et stykke af nodens lagerområde til edge-indhold.
    ///
    /// # Safety
    /// `index` er inden for grænserne 0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // SIKKERHED: den, der ringer op, kan ikke kalde yderligere metoder på egen hånd
        // indtil edge-skivehenvisningen er droppet, da vi har unik adgang i lånets levetid.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Noden har mere end `idx` initialiserede elementer.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Vi opretter kun en henvisning til det ene element, vi er interesseret i, for at undgå alias med udestående referencer til andre elementer, især dem, der returneres til den, der ringer op i tidligere gentagelser.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Vi skal tvinge os til uspecificerede array-markører på grund af Rust-udgave #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Låner eksklusiv adgang til nodens længde.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Indstiller knudepunktslinket til dets overordnede edge uden at ugyldiggøre andre referencer til knudepunktet.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Rydder rodets link til sin forælder edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Tilføjer et nøgleværdipar til slutningen af noden.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Hver vare, der returneres af `range`, er et gyldigt edge-indeks for noden.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Tilføjer et nøgleværdipar og et edge for at gå til højre for dette par til slutningen af noden.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Kontrollerer, om en node er en `Internal`-node eller en `Leaf`-node.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// En henvisning til et specifikt nøgleværdipar eller edge inden for en node.
/// `Node`-parameteren skal være en `NodeRef`, mens `Type` enten kan være `KV` (betyder et håndtag på et nøgleværdipar) eller `Edge` (betyder et håndtag på et edge).
///
/// Bemærk, at selv `Leaf`-noder kan have `Edge`-håndtag.
/// I stedet for at repræsentere en markør til et underordnet knudepunkt repræsenterer disse de rum, hvor underordnede markører vil gå mellem nøgleværdiparene.
/// For eksempel i en node med længde 2 ville der være 3 mulige edge-placeringer, en til venstre for noden, en mellem de to par og en til højre for noden.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Vi har ikke brug for den fulde generalitet af `#[derive(Clone)]`, da den eneste gang `Node` vil være 'klonbar', er når det er en uforanderlig reference og derfor `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Henter den node, der indeholder edge eller nøgleværdipar dette håndtag peger på.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Returnerer placeringen af dette håndtag i noden.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Opretter et nyt håndtag til et nøgleværdipar i `node`.
    /// Usikker, fordi den, der ringer op, skal sikre, at `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Kunne være en offentlig implementering af PartialEq, men kun brugt i dette modul.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Tager midlertidigt et andet, uforanderligt håndtag ud på samme sted.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Vi kan ikke bruge Handle::new_kv eller Handle::new_edge, fordi vi ikke kender vores type
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Giver usikker sikkerhed til compileren de statiske oplysninger om, at håndtagets knude er en `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Tager midlertidigt et andet, foranderligt håndtag ud på samme sted.
    /// Pas på, da denne metode er meget farlig, dobbelt så da den måske ikke straks ser ud til at være farlig.
    ///
    ///
    /// For detaljer, se `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Vi kan ikke bruge Handle::new_kv eller Handle::new_edge, fordi vi ikke kender vores type
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Opretter et nyt håndtag til en edge i `node`.
    /// Usikker, fordi den, der ringer op, skal sikre, at `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Givet et edge-indeks, hvor vi vil indsætte i en node fyldt til kapacitet, beregner et fornuftigt KV-indeks for et splitpunkt, og hvor man skal udføre indsættelsen.
///
/// Målet med splitpunktet er, at dets nøgle og værdi ender i en overordnet node;
/// nøglerne, værdierne og kanterne til venstre for splitpunktet bliver det venstre barn;
/// nøglerne, værdierne og kanterne til højre for splitpunktet bliver det rigtige barn.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust-udgave #74834 forsøger at forklare disse symmetriske regler.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Indsætter et nyt nøgleværdipar mellem nøgleværdiparene til højre og venstre for denne edge.
    /// Denne metode antager, at der er nok plads i noden til, at det nye par kan passe.
    ///
    /// Den returnerede markør peger på den indsatte værdi.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Indsætter et nyt nøgleværdipar mellem nøgleværdiparene til højre og venstre for denne edge.
    /// Denne metode opdeler noden, hvis der ikke er plads nok.
    ///
    /// Den returnerede markør peger på den indsatte værdi.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Retter den overordnede markør og indeks i den underordnede node, som denne edge linker til.
    /// Dette er nyttigt, når rækkefølgen af kanter er blevet ændret,
    fn correct_parent_link(self) {
        // Opret backpointer uden at ugyldiggøre andre referencer til noden.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Indsætter et nyt nøgleværdipar og et edge, der går til højre for det nye par mellem dette edge og nøgleværdiparet til højre for dette edge.
    /// Denne metode antager, at der er nok plads i noden til, at det nye par kan passe.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Indsætter et nyt nøgleværdipar og et edge, der går til højre for det nye par mellem dette edge og nøgleværdiparet til højre for dette edge.
    /// Denne metode opdeler noden, hvis der ikke er plads nok.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Indsætter et nyt nøgleværdipar mellem nøgleværdiparene til højre og venstre for denne edge.
    /// Denne metode opdeler noden, hvis der ikke er plads nok, og forsøger at indsætte den afskårne del i den overordnede node rekursivt, indtil roden er nået.
    ///
    ///
    /// Hvis det returnerede resultat er en `Fit`, kan dens håndtagsknude være denne edge-knude eller en forfader.
    /// Hvis det returnerede resultat er en `Split`, vil `left`-feltet være rodnoden.
    /// Den returnerede markør peger på den indsatte værdi.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Finder den knude, som denne edge peger på.
    ///
    /// Metodenavnet forudsætter, at du billedtræer med rodnoden øverst.
    ///
    /// `edge.descend().ascend().unwrap()` og `node.ascend().unwrap().descend()` skal begge efter succes ikke gøre noget.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Vi er nødt til at bruge rå pegepunkter til noder, fordi hvis BorrowType er marker::ValMut, kan der være udestående mutable referencer til værdier, som vi ikke må ugyldiggøre.
        // Der er ingen bekymring for at få adgang til højdefeltet, fordi denne værdi kopieres.
        // Vær opmærksom på, at når nodemarkøren først er refereret, får vi adgang til kanterne med en reference (Rust udgave #73987) og ugyldiggør andre referencer til eller inde i arrayet, hvis der er nogen.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Vi kan ikke kalde separate nøgle-og værdimetoder, fordi opkald til den anden annullerer referencen, der returneres af den første.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Udskift nøglen og værdien, som KV-håndtaget henviser til.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Hjælper implementeringer af `split` til en bestemt `NodeType` ved at tage sig af bladdata.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Opdeler den underliggende knude i tre dele:
    ///
    /// - Noden trunkeres til kun at indeholde nøgleværdiparene til venstre for dette håndtag.
    /// - Nøglen og værdien, som dette håndtag peger på, udvindes.
    /// - Alle nøgleværdipar til højre for dette håndtag placeres i en nyligt tildelt node.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Fjerner det nøgleværdipar, som dette håndtag peger på, og returnerer det sammen med edge, som nøgleværdiparet kollapset i.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Opdeler den underliggende knude i tre dele:
    ///
    /// - Noden er afkortet til kun at indeholde kanter og nøgleværdipar til venstre for dette håndtag.
    /// - Nøglen og værdien, som dette håndtag peger på, udvindes.
    /// - Alle kanter og nøgleværdipar til højre for dette håndtag placeres i et nyligt allokeret knudepunkt.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Repræsenterer en session til evaluering og udførelse af en balanceringshandling omkring et internt nøgleværdipar.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Vælger en afbalanceringskontekst, der involverer noden som barn, således mellem KV straks til venstre eller til højre i forældernoden.
    /// Returnerer en `Err`, hvis der ikke er nogen forælder.
    /// Panics hvis forældrene er tomme.
    ///
    /// Foretrækker venstre side for at være optimal, hvis den givne node på en eller anden måde er underfuld, hvilket kun betyder her, at den har færre elementer end sin venstre søskende og end dens højre søskende, hvis de findes.
    /// I så fald er fletning med det venstre søskende hurtigere, da vi kun behøver at flytte nodens N-elementer i stedet for at skifte dem til højre og flytte mere end N-elementer foran.
    /// At stjæle fra det venstre søskende er også typisk hurtigere, da vi kun har brug for at skifte nodens N-elementer til højre i stedet for at skifte mindst N af søskendets elementer til venstre.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Returnerer om fletning er mulig, dvs. om der er plads nok i en node til at kombinere den centrale KV med begge tilstødende underordnede noder.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Udfører en fusion og lader en lukning beslutte, hvad de skal returnere.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // SIKKERHED: højden på de knudepunkter, der flettes, er en under højden
                // af noden på denne edge, således over nul, så de er interne.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Fletter forældrenes nøgleværdipar og begge tilstødende underordnede noder i venstre undernode og returnerer den krympede forældernode.
    ///
    ///
    /// Panics medmindre vi `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Fletter forældrenes nøgleværdipar og begge tilstødende underordnede noder i den venstre undernode og returnerer den underliggende node.
    ///
    ///
    /// Panics medmindre vi `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Fletter forældrenes nøgleværdipar og begge tilstødende underordnede noder i venstre barneknude og returnerer edge-håndtaget i det barneknudepunkt, hvor det sporede barn edge endte,
    ///
    ///
    /// Panics medmindre vi `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Fjerner et nøgleværdipar fra det venstre barn og placerer det i forældrenes nøgleværdilagring, mens det gamle overordnede nøgleværdipar skubbes ind i det rigtige barn.
    ///
    /// Returnerer et håndtag til edge i det rigtige barn svarende til hvor den originale edge, der er specificeret af `track_right_edge_idx`, endte.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Fjerner et nøgleværdipar fra det højre barn og placerer det i forældrenes nøgleværdilagring, mens det gamle overordnede nøgleværdipar skubbes på det venstre barn.
    ///
    /// Returnerer et håndtag til edge i det venstre barn angivet af `track_left_edge_idx`, som ikke bevægede sig.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Dette stjæler svarende til `steal_left`, men stjæler flere elementer på én gang.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Sørg for, at vi stjæler sikkert.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Flyt bladdata.
            {
                // Gør plads til stjålne elementer i det rigtige barn.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Flyt elementer fra venstre barn til højre.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Flyt det stjålne par til venstre mest til forældren.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Flyt forældres nøgleværdipar til det rigtige barn.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Gør plads til stjålne kanter.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Stjæl kanter.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Den symmetriske klon af `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Sørg for, at vi stjæler sikkert.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Flyt bladdata.
            {
                // Flyt det mest stjålne par til forældren.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Flyt forældres nøgleværdipar til det venstre barn.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Flyt elementer fra det højre barn til det venstre.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Udfyld hul, hvor stjålne elementer plejede at være.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Stjæl kanter.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Fyld hul, hvor stjålne kanter plejede at være.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Fjerner alle statiske oplysninger, der hævder, at denne node er en `Leaf`-node.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Fjerner alle statiske oplysninger, der hævder, at denne node er en `Internal`-node.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Kontrollerer, om den underliggende node er en `Internal`-node eller en `Leaf`-node.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Flyt suffikset efter `self` fra en node til en anden.`right` skal være tom.
    /// Den første edge af `right` forbliver uændret.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Resultat af indsættelse, når en node skulle udvides ud over dens kapacitet.
pub struct SplitResult<'a, K, V, NodeType> {
    // Ændret knude i eksisterende træ med elementer og kanter, der hører til venstre for `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Nogle nøgler og værdier er opdelt for at blive indsat et andet sted.
    pub kv: (K, V),
    // Ejet, uafhængig, ny node med elementer og kanter, der hører til højre for `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Om nodereferencer af denne lånetype tillader passage til andre noder i træet.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Traversal er ikke nødvendigt, det sker ved hjælp af resultatet af `borrow_mut`.
        // Ved at deaktivere traversal og kun oprette nye referencer til rødder ved vi, at enhver reference af `Owned`-typen er til en rodknude.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Indsætter en værdi i et udsnit af initialiserede elementer efterfulgt af et ikke-initialiseret element.
///
/// # Safety
/// Skiven har mere end `idx`-elementer.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Fjerner og returnerer en værdi fra et udsnit af alle initialiserede elementer og efterlader et efterfølgende ikke-initialiseret element.
///
///
/// # Safety
/// Skiven har mere end `idx`-elementer.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Flytter elementerne i et `distance`-udsnit til venstre.
///
/// # Safety
/// Skiven har mindst `distance`-elementer.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Flytter elementerne i et `distance`-udsnit til højre.
///
/// # Safety
/// Skiven har mindst `distance`-elementer.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Flytter alle værdier fra et stykke initialiserede elementer til et stykke ikke-initialiserede elementer og efterlader `src` som alle ikke-initialiserede.
///
/// Fungerer som `dst.copy_from_slice(src)`, men kræver ikke, at `T` er `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;