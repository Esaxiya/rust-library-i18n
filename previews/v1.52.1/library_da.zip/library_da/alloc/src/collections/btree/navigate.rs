use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Tager midlertidigt en anden, uforanderlig ækvivalent af det samme interval ud.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Finder de forskellige bladkanter, der afgrænser et specificeret interval i et træ.
    /// Returnerer enten et par forskellige håndtag i det samme træ eller et par tomme indstillinger.
    ///
    /// # Safety
    ///
    /// Medmindre `BorrowType` er `Immut`, skal du ikke bruge de dobbelte håndtag til at besøge den samme KV to gange.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Svarer til `(root1.first_leaf_edge(), root2.last_leaf_edge())` men mere effektiv.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Finder parret bladkanter, der afgrænser et bestemt interval i et træ.
    ///
    /// Resultatet er kun meningsfuldt, hvis træet er ordnet efter nøgle, ligesom træet i en `BTreeMap` er.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // SIKKERHED: vores lånetype er uforanderlig.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Finder det par bladkanter, der afgrænser et helt træ.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Opdeler en unik reference i et par bladkanter, der afgrænser et specificeret interval.
    /// Resultatet er ikke-unikke referencer, der tillader (some)-mutation, som skal bruges omhyggeligt.
    ///
    /// Resultatet er kun meningsfuldt, hvis træet er ordnet efter nøgle, ligesom træet i en `BTreeMap` er.
    ///
    ///
    /// # Safety
    /// Brug ikke de dobbelte håndtag til at besøge den samme KV to gange.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Deler en unik reference i et par bladkanter, der afgrænser træets fulde rækkevidde.
    /// Resultaterne er ikke-unikke referencer, der tillader mutation (kun af værdier), så de skal bruges med forsigtighed.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Vi duplikerer roden NodeRef her-vi besøger aldrig den samme KV to gange og ender aldrig med overlappende værdireferencer.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Deler en unik reference i et par bladkanter, der afgrænser træets fulde rækkevidde.
    /// Resultaterne er ikke-unikke referencer, der tillader massiv destruktiv mutation, så de skal bruges med den største omhu.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Vi duplikerer rod NodeRef her-vi får aldrig adgang til den på en måde, der overlapper referencer opnået fra roden.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Givet et blad edge-håndtag, returnerer [`Result::Ok`] med et håndtag til det tilstødende KV på højre side, som enten er i samme bladknude eller i en forfædrenode.
    ///
    /// Hvis bladet edge er det sidste i træet, returneres [`Result::Err`] med rodnoden.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Givet et blad edge-håndtag, returnerer [`Result::Ok`] med et håndtag til det nærliggende KV på venstre side, som enten er i samme bladknude eller i en forfædrenode.
    ///
    /// Hvis bladet edge er det første i træet, returneres [`Result::Err`] med rodnoden.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Givet et internt edge-håndtag, returnerer [`Result::Ok`] med et håndtag til det tilstødende KV på højre side, som enten er i den samme interne node eller i en forfædrenode.
    ///
    /// Hvis den interne edge er den sidste i træet, returneres [`Result::Err`] med rodnoden.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Givet et blad edge-håndtag til et døende træ, returnerer det næste blad edge på højre side og nøgleværdiparet imellem, som enten er i samme bladknude, i en forfædrenode eller ikke-eksisterende.
    ///
    ///
    /// Denne metode deallocates også enhver node(s) den når slutningen af.
    /// Dette indebærer, at hvis der ikke findes flere nøgleværdipar, vil hele resten af træet være blevet omfordelt, og der er intet tilbage at vende tilbage.
    ///
    /// # Safety
    /// Den givne edge må ikke tidligere være returneret af modstykke `deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Givet et blad edge-håndtag i et døende træ, returnerer det næste blad edge på venstre side og nøgleværdiparet imellem, som enten er i samme bladknude, i en forfædrenode eller ikke-eksisterende.
    ///
    ///
    /// Denne metode deallocates også enhver node(s) den når slutningen af.
    /// Dette indebærer, at hvis der ikke findes flere nøgleværdipar, vil hele resten af træet være blevet omfordelt, og der er intet tilbage at vende tilbage.
    ///
    /// # Safety
    /// Den givne edge må ikke tidligere være returneret af modstykke `deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Distribuerer en bunke noder fra bladet op til roden.
    /// Dette er den eneste måde at deallocere resten af et træ på, efter at `deallocating_next` og `deallocating_next_back` har nibbet på begge sider af træet og har ramt den samme edge.
    /// Da det kun er beregnet til at blive kaldt, når alle nøgler og værdier er returneret, foretages der ingen oprydning på nogen af tasterne eller værdierne.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Flytter bladet edge-håndtaget til det næste blad edge og returnerer referencer til nøglen og værdien imellem.
    ///
    ///
    /// # Safety
    /// Der skal være en anden KV i den kørte retning.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Flytter bladet edge til det forrige blad edge og returnerer referencer til nøglen og værdien imellem.
    ///
    ///
    /// # Safety
    /// Der skal være en anden KV i den kørte retning.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Flytter bladet edge-håndtaget til det næste blad edge og returnerer referencer til nøglen og værdien imellem.
    ///
    ///
    /// # Safety
    /// Der skal være en anden KV i den kørte retning.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // At gøre dette sidste er hurtigere ifølge benchmarks.
        kv.into_kv_valmut()
    }

    /// Flytter bladet edge til det forrige blad og returnerer referencer til nøglen og værdien imellem.
    ///
    ///
    /// # Safety
    /// Der skal være en anden KV i den kørte retning.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // At gøre dette sidste er hurtigere ifølge benchmarks.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Flytter bladet edge-håndtaget til det næste blad edge og returnerer nøglen og værdien imellem, ved at placere en hvilken som helst node, der er tilbage, mens den tilsvarende edge efterlades i sin overordnede node.
    ///
    /// # Safety
    /// - Der skal være en anden KV i den kørte retning.
    /// - At KV ikke tidligere blev returneret af modstykke `next_back_unchecked` på nogen kopi af håndtagene, der blev brugt til at krydse træet.
    ///
    /// Den eneste sikre måde at fortsætte med det opdaterede håndtag er at sammenligne det, droppe det, kalde denne metode igen under forudsætning af dens sikkerhedsforhold eller ringe til modstykke `next_back_unchecked` underlagt dets sikkerhedsforhold.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Flytter bladet edge-håndtaget til det forrige blad edge og returnerer nøglen og værdien imellem, ved at placere en hvilken som helst node, der er tilbage, mens den tilsvarende edge efterlades i sin overordnede node.
    ///
    /// # Safety
    /// - Der skal være en anden KV i den kørte retning.
    /// - Det blad edge blev ikke tidligere returneret af modstykke `next_unchecked` på nogen kopi af håndtagene, der blev brugt til at krydse træet.
    ///
    /// Den eneste sikre måde at fortsætte med det opdaterede håndtag er at sammenligne det, droppe det, kalde denne metode igen under forudsætning af dens sikkerhedsforhold eller ringe til modstykke `next_unchecked` underlagt dets sikkerhedsforhold.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Returnerer bladet edge til venstre i eller under en node, med andre ord det edge, du har brug for først, når du navigerer fremad (eller sidst, når du navigerer bagud).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Returnerer bladet edge til højre i eller under en node, med andre ord det edge, du har brug for sidst, når du navigerer fremad (eller først, når du navigerer bagud).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Besøger bladnoder og interne KV'er i rækkefølge efter stigende nøgler og besøger også interne noder som en helhed i dybden i første orden, hvilket betyder, at interne noder går forud for deres individuelle KV'er og deres underordnede noder.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Beregner antallet af elementer i et (under) træ.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Returnerer bladet edge tættest på en KV til navigering fremad.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Returnerer bladet edge tættest på en KV til bagud navigering.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}