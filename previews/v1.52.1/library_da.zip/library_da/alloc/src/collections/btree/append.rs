use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Tilføjer alle nøgleværdipar fra foreningen af to stigende iteratorer, der øger en `length`-variabel undervejs.Sidstnævnte gør det lettere for den, der ringer op, at undgå en lækage, når en drophandler går i panik.
    ///
    /// Hvis begge iteratorer producerer den samme nøgle, falder denne metode parret fra venstre iterator og tilføjer parret fra højre iterator.
    ///
    /// Hvis du vil have træet til at ende i en streng stigende rækkefølge, som for en `BTreeMap`, skal begge iteratorer producere nøgler i strengt stigende rækkefølge, hver større end alle nøgler i træet, inklusive eventuelle nøgler, der allerede er i træet ved indrejsen.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Vi forbereder os på at flette `left` og `right` til en sorteret sekvens i lineær tid.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // I mellemtiden bygger vi et træ fra den sorterede sekvens i lineær tid.
        self.bulk_push(iter, length)
    }

    /// Skubber alle nøgleværdipar til slutningen af træet og forøger en `length`-variabel undervejs.
    /// Sidstnævnte gør det lettere for den, der ringer op, at undgå lækage, når iteratoren går i panik.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Iterer gennem alle nøgleværdipar og skubber dem ind i noder på det rigtige niveau.
        for (key, value) in iter {
            // Prøv at skubbe nøgleværdipar ind i den aktuelle bladknude.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Ingen plads tilbage, gå op og skub der.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Fundet en knude med plads tilbage, skub her.
                                open_node = parent;
                                break;
                            } else {
                                // Gå op igen.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Vi er øverst, opretter en ny rodknude og skubber derhen.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Skub nøgleværdipar og nyt højre undertræ.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Gå ned til det højre blad igen.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Forøg længden for hver iteration for at sikre, at kortet taber de tilføjede elementer, selvom iteratoren går i panik.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// En iterator til fletning af to sorterede sekvenser i en
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Hvis to taster er ens, returnerer nøgleværdipar fra den rigtige kilde.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}