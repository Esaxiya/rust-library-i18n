use core::borrow::Borrow;
use core::cmp::Ordering;
use core::ops::{Bound, RangeBounds};

use super::node::{marker, ForceResult::*, Handle, NodeRef};

use SearchBound::*;
use SearchResult::*;

pub enum SearchBound<T> {
    /// En inkluderende forpligtet til at kigge efter, ligesom `Bound::Included(T)`.
    Included(T),
    /// En eksklusiv forpligtet til at kigge efter, ligesom `Bound::Excluded(T)`.
    Excluded(T),
    /// En ubetinget inkluderende bund, ligesom `Bound::Unbounded`.
    AllIncluded,
    /// En ubetinget eksklusiv bånd.
    AllExcluded,
}

impl<T> SearchBound<T> {
    pub fn from_range(range_bound: Bound<T>) -> Self {
        match range_bound {
            Bound::Included(t) => Included(t),
            Bound::Excluded(t) => Excluded(t),
            Bound::Unbounded => AllIncluded,
        }
    }
}

pub enum SearchResult<BorrowType, K, V, FoundType, GoDownType> {
    Found(Handle<NodeRef<BorrowType, K, V, FoundType>, marker::KV>),
    GoDown(Handle<NodeRef<BorrowType, K, V, GoDownType>, marker::Edge>),
}

pub enum IndexResult {
    KV(usize),
    Edge(usize),
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Slår en given nøgle op i et (under) træ ledet af noden, rekursivt.
    /// Returnerer en `Found` med håndtaget til den matchende KV, hvis nogen.
    /// Ellers returnerer en `GoDown` med håndtaget på bladet edge hvor nøglen hører hjemme.
    ///
    /// Resultatet er kun meningsfuldt, hvis træet er ordnet efter nøgle, ligesom træet i en `BTreeMap` er.
    ///
    pub fn search_tree<Q: ?Sized>(
        mut self,
        key: &Q,
    ) -> SearchResult<BorrowType, K, V, marker::LeafOrInternal, marker::Leaf>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        loop {
            self = match self.search_node(key) {
                Found(handle) => return Found(handle),
                GoDown(handle) => match handle.force() {
                    Leaf(leaf) => return GoDown(leaf),
                    Internal(internal) => internal.descend(),
                },
            }
        }
    }

    /// Faldes ned til den nærmeste node, hvor edge, der matcher den nedre grænse for området, er forskellig fra edge, der matcher den øvre grænse, dvs. den nærmeste node, der har mindst en nøgle indeholdt i området.
    ///
    ///
    /// Hvis fundet, returnerer en `Ok` med den node, indekserer paret edge i den, der afgrænser området, og det tilsvarende par af grænser til fortsættelse af søgningen i underordnede noder, hvis noden er intern.
    ///
    /// Hvis den ikke findes, returneres en `Err` med bladet edge, der matcher hele sortimentet.
    ///
    /// Resultatet er kun meningsfuldt, hvis træet er ordnet efter nøgle.
    ///
    ///
    ///
    ///
    pub fn search_tree_for_bifurcation<'r, Q: ?Sized, R>(
        mut self,
        range: &'r R,
    ) -> Result<
        (
            NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
            usize,
            usize,
            SearchBound<&'r Q>,
            SearchBound<&'r Q>,
        ),
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>,
    >
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // Indlejring af disse variabler bør undgås.
        // Vi antager, at de grænser, der er rapporteret af `range`, er de samme, men en kontradiktorisk implementering kan ændre sig mellem opkald (#81138).
        let (start, end) = (range.start_bound(), range.end_bound());
        match (start, end) {
            (Bound::Excluded(s), Bound::Excluded(e)) if s == e => {
                panic!("range start and end are equal and excluded in BTreeMap")
            }
            (Bound::Included(s) | Bound::Excluded(s), Bound::Included(e) | Bound::Excluded(e))
                if s > e =>
            {
                panic!("range start is greater than range end in BTreeMap")
            }
            _ => {}
        }
        let mut lower_bound = SearchBound::from_range(start);
        let mut upper_bound = SearchBound::from_range(end);
        loop {
            let (lower_edge_idx, lower_child_bound) = self.find_lower_bound_index(lower_bound);
            let (upper_edge_idx, upper_child_bound) = self.find_upper_bound_index(upper_bound);
            if lower_edge_idx > upper_edge_idx {
                panic!("Ord is ill-defined in BTreeMap range")
            }
            if lower_edge_idx < upper_edge_idx {
                return Ok((
                    self,
                    lower_edge_idx,
                    upper_edge_idx,
                    lower_child_bound,
                    upper_child_bound,
                ));
            }
            let common_edge = unsafe { Handle::new_edge(self, lower_edge_idx) };
            match common_edge.force() {
                Leaf(common_edge) => return Err(common_edge),
                Internal(common_edge) => {
                    self = common_edge.descend();
                    lower_bound = lower_child_bound;
                    upper_bound = upper_child_bound;
                }
            }
        }
    }

    /// Finder en edge i noden, der afgrænser den nedre grænse for et interval.
    /// Returnerer også den nedre grænse, der skal bruges til at fortsætte søgningen i den matchende underordnede node, hvis `self` er en intern node.
    ///
    ///
    /// Resultatet er kun meningsfuldt, hvis træet er ordnet efter nøgle.
    pub fn find_lower_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_lower_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }

    /// Klon af `find_lower_bound_edge` til den øvre grænse.
    pub fn find_upper_bound_edge<'r, Q>(
        self,
        bound: SearchBound<&'r Q>,
    ) -> (Handle<Self, marker::Edge>, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        let (edge_idx, bound) = self.find_upper_bound_index(bound);
        let edge = unsafe { Handle::new_edge(self, edge_idx) };
        (edge, bound)
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Slår en given nøgle i noden op uden rekursion.
    /// Returnerer en `Found` med håndtaget til den matchende KV, hvis nogen.
    /// Ellers returnerer en `GoDown` med håndtaget på edge, hvor nøglen muligvis findes (hvis noden er intern), eller hvor nøglen kan indsættes.
    ///
    ///
    /// Resultatet er kun meningsfuldt, hvis træet er ordnet efter nøgle, ligesom træet i en `BTreeMap` er.
    ///
    pub fn search_node<Q: ?Sized>(self, key: &Q) -> SearchResult<BorrowType, K, V, Type, Type>
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        match self.find_key_index(key) {
            IndexResult::KV(idx) => Found(unsafe { Handle::new_kv(self, idx) }),
            IndexResult::Edge(idx) => GoDown(unsafe { Handle::new_edge(self, idx) }),
        }
    }

    /// Returnerer enten KV-indekset i den node, hvor nøglen (eller en ækvivalent) findes, eller edge-indekset, hvor nøglen hører til.
    ///
    ///
    /// Resultatet er kun meningsfuldt, hvis træet er ordnet efter nøgle, ligesom træet i en `BTreeMap` er.
    ///
    fn find_key_index<Q: ?Sized>(&self, key: &Q) -> IndexResult
    where
        Q: Ord,
        K: Borrow<Q>,
    {
        let node = self.reborrow();
        let keys = node.keys();
        for (i, k) in keys.iter().enumerate() {
            match key.cmp(k.borrow()) {
                Ordering::Greater => {}
                Ordering::Equal => return IndexResult::KV(i),
                Ordering::Less => return IndexResult::Edge(i),
            }
        }
        IndexResult::Edge(keys.len())
    }

    /// Finder et edge-indeks i noden, der afgrænser den nedre grænse for et interval.
    /// Returnerer også den nedre grænse, der skal bruges til at fortsætte søgningen i den matchende underordnede node, hvis `self` er en intern node.
    ///
    ///
    /// Resultatet er kun meningsfuldt, hvis træet er ordnet efter nøgle.
    fn find_lower_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (0, AllIncluded),
            AllExcluded => (self.len(), AllExcluded),
        }
    }

    /// Klon af `find_lower_bound_index` til den øvre grænse.
    fn find_upper_bound_index<'r, Q>(
        &self,
        bound: SearchBound<&'r Q>,
    ) -> (usize, SearchBound<&'r Q>)
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
    {
        match bound {
            Included(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx + 1, AllExcluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            Excluded(key) => match self.find_key_index(key) {
                IndexResult::KV(idx) => (idx, AllIncluded),
                IndexResult::Edge(idx) => (idx, bound),
            },
            AllIncluded => (self.len(), AllIncluded),
            AllExcluded => (0, AllExcluded),
        }
    }
}