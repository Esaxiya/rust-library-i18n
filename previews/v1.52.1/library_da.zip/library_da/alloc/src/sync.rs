#![stable(feature = "rust1", since = "1.0.0")]

//! Trådsikre henvisningstællere.
//!
//! Se [`Arc<T>`][Arc]-dokumentationen for flere detaljer.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// En blød grænse for antallet af referencer, der kan foretages til en `Arc`.
///
/// Hvis du går over denne grænse, afbrydes dit program (dog ikke nødvendigvis) ved _exactly_ `MAX_REFCOUNT + 1`-referencer.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer understøtter ikke hukommelseshegn.
// For at undgå falske positive rapporter i Arc/Weak implementering skal du bruge atombelastninger til synkronisering i stedet.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// En trådsikker henvisningstæller.'Arc' står for 'Atomically Reference Counted'.
///
/// Typen `Arc<T>` giver delt ejerskab af en værdi af typen `T`, allokeret i bunken.Påkaldelse af [`clone`][clone] på `Arc` producerer en ny `Arc`-forekomst, der peger på den samme allokering på bunken som kilden `Arc`, samtidig med at en referencetælling øges.
/// Når den sidste `Arc`-markør til en given allokering ødelægges, slettes også den værdi, der er gemt i denne allokering (ofte omtalt som "inner value").
///
/// Delte referencer i Rust tillader ikke mutation som standard, og `Arc` er ingen undtagelse: Du kan generelt ikke få en muterbar reference til noget inde i en `Arc`.Hvis du har brug for at mutere gennem en `Arc`, skal du bruge [`Mutex`][mutex], [`RwLock`][rwlock] eller en af [`Atomic`][atomic]-typerne.
///
/// ## Trådsikkerhed
///
/// I modsætning til [`Rc<T>`] bruger `Arc<T>` atomoperationer til sin referenceoptælling.Dette betyder, at det er trådsikkert.Ulempen er, at atomoperationer er dyrere end almindelig hukommelsesadgang.Hvis du ikke deler referencetællede tildelinger mellem tråde, skal du overveje at bruge [`Rc<T>`] til lavere omkostninger.
/// [`Rc<T>`] er en sikker standard, fordi compileren fanger ethvert forsøg på at sende en [`Rc<T>`] mellem tråde.
/// Dog kan et bibliotek muligvis vælge `Arc<T>` for at give bibliotekets forbrugere mere fleksibilitet.
///
/// `Arc<T>` implementerer [`Send`] og [`Sync`], så længe `T` implementerer [`Send`] og [`Sync`].
/// Hvorfor kan du ikke placere en ikke-trådsikker type `T` i en `Arc<T>` for at gøre den trådsikker?Dette kan være en smule kontraintuitivt i starten: når alt kommer til alt, er det ikke meningen med `Arc<T>` trådsikkerhed?Nøglen er denne: `Arc<T>` gør det trådsikkert at have flere ejerskaber af de samme data, men det føjer ikke trådsikkerhed til sine data.
///
/// Overvej `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] er ikke [`Sync`], og hvis `Arc<T>` altid var [`Send`], `Arc <` [`RefCell<T>`]`>`ville også være det.
/// Men så ville vi have et problem:
/// [`RefCell<T>`] er ikke trådsikkerdet holder styr på lånetællingen ved hjælp af ikke-atomare operationer.
///
/// I sidste ende betyder det, at du muligvis skal parre `Arc<T>` med en slags [`std::sync`]-type, normalt [`Mutex<T>`][mutex].
///
/// ## Breaking cycles med `Weak`
///
/// [`downgrade`][downgrade]-metoden kan bruges til at oprette en ikke-ejer [`Weak`]-markør.En [`Weak`]-markør kan være [`opgradering`][opgradering] d til en `Arc`, men dette returnerer [`None`], hvis værdien, der er gemt i tildelingen, allerede er faldet.
/// Med andre ord holder `Weak`-markører ikke værdien inde i tildelingen i live;dog *holder de* tildelingen (backing-butikken for værdien) i live.
///
/// En cyklus mellem `Arc`-markører vil aldrig blive fordelt.
/// Af denne grund bruges [`Weak`] til at bryde cyklusser.For eksempel kan et træ have stærke `Arc`-markører fra forældernoder til børn og [`Weak`]-markører fra børn tilbage til deres forældre.
///
/// # Kloning af referencer
///
/// Oprettelse af en ny reference fra en eksisterende referencetællet markør sker ved hjælp af `Clone` trait implementeret til [`Arc<T>`][Arc] og [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // De to syntakser nedenfor er ækvivalente.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b og foo er alle buer, der peger på den samme hukommelsesplacering
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` automatisk henvises til `T` (via [`Deref`][deref] trait), så du kan kalde `T`s metoder på en værdi af typen `Arc<T>`.For at undgå navnesammenstød med `T`s metoder, er metoderne i selve `Arc<T>` tilknyttede funktioner, kaldet ved hjælp af [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Arc<T>implementeringer af traits som `Clone` kan også kaldes ved hjælp af fuldt kvalificeret syntaks.
/// Nogle mennesker foretrækker at bruge fuldt kvalificeret syntaks, mens andre foretrækker at bruge metode-opkaldssyntaks.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Metodeopkaldssyntaks
/// let arc2 = arc.clone();
/// // Fuldt kvalificeret syntaks
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] afviger ikke automatisk til `T`, fordi den indre værdi muligvis allerede er faldet.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Deling af uforanderlige data mellem tråde:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Bemærk, at vi **ikke** kører disse tests her.
// windows-bygherrer bliver super utilfredse, hvis en tråd overlever hovedtråden og derefter afslutter på samme tid (noget blokerer), så vi undgår dette helt ved ikke at køre disse tests.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Deling af en ændret [`AtomicUsize`]:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Se [`rc` documentation][rc_examples] for flere eksempler på referencetælling generelt.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` er en version af [`Arc`], der indeholder en ikke-ejerhenvisning til den administrerede tildeling.
/// Man får adgang til tildelingen ved at kalde [`upgrade`] på `Weak`-markøren, som returnerer en [`Option`]`<`[`Arc ']`<T>> `.
///
/// Da en `Weak`-reference ikke tæller med i ejerskabet, forhindrer den ikke, at værdien, der er gemt i tildelingen, droppes, og `Weak` i sig selv giver ingen garantier for, at værdien stadig er til stede.
///
/// Således kan det returnere [`None`], når [`opgradering`] d.
/// Bemærk dog, at en `Weak`-reference *forhindrer* allokering af selve tildelingen (backing-butikken).
///
/// En `Weak`-markør er nyttig til at holde en midlertidig reference til den allokering, der administreres af [`Arc`], uden at forhindre, at dens indre værdi falder ned.
/// Det bruges også til at forhindre cirkulære referencer mellem [`Arc`]-markører, da gensidige ejerskabsreferencer aldrig ville tillade, at hverken [`Arc`] droppes.
/// For eksempel kan et træ have stærke [`Arc`]-markører fra forældrenoder til børn og `Weak`-markører fra børn tilbage til deres forældre.
///
/// Den typiske måde at få en `Weak`-markør på er at ringe til [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Dette er en `NonNull`, der gør det muligt at optimere størrelsen af denne type i enums, men det er ikke nødvendigvis en gyldig markør.
    //
    // `Weak::new` indstiller dette til `usize::MAX`, så det ikke behøver at tildele plads på bunken.
    // Det er ikke en værdi, som en reel markør nogensinde vil have, fordi RcBox har justering mindst 2.
    // Dette er kun muligt, når `T: Sized`;unsized `T` dingler aldrig.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Dette er repr(C) til future-bevis mod mulig feltbestilling, hvilket ville forstyrre ellers sikker [into|from]_raw() af transmuterbare indre typer.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // værdien usize::MAX fungerer som en vagtpost for midlertidig "locking" evnen til at opgradere svage pointer eller nedgradere stærke;dette bruges til at undgå løb i `make_mut` og `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Konstruerer en ny `Arc<T>`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Start den svage markør tæller som 1, hvilket er den svage markør, der holdes af alle de stærke markører (kinda), se std/rc.rs for mere info
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Konstruerer en ny `Arc<T>` ved hjælp af en svag reference til sig selv.
    /// Forsøg på at opgradere den svage reference, før denne funktion vender tilbage, resulterer i en `None`-værdi.
    /// Imidlertid kan den svage reference klones frit og opbevares til brug på et senere tidspunkt.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Konstruer det indre i "uninitialized"-tilstand med en enkelt svag reference.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Det er vigtigt, at vi ikke opgiver ejerskabet af den svage markør, ellers frigøres hukommelsen muligvis, når `data_fn` vender tilbage.
        // Hvis vi virkelig ønskede at passere ejerskab, kunne vi oprette en ekstra svag markør for os selv, men dette ville resultere i yderligere opdateringer til det svage referencetal, som ellers ikke er nødvendigt.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Nu kan vi initialisere den indre værdi korrekt og gøre vores svage reference til en stærk reference.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Ovenstående skriv til datafeltet skal være synlig for alle tråde, der observerer et stærkt antal, der ikke er nul.
            // Derfor har vi brug for mindst "Release" bestilling for at synkronisere med `compare_exchange_weak` i `Weak::upgrade`.
            //
            // "Acquire" bestilling er ikke påkrævet.
            // Når vi overvejer den mulige opførsel af `data_fn`, behøver vi kun se på, hvad den kunne gøre med en henvisning til en ikke-opgraderbar `Weak`:
            //
            // - Det kan *klone*`Weak`, hvilket øger det svage referencetal.
            // - Det kan droppe disse kloner og reducere det svage referencetal (men aldrig til nul).
            //
            // Disse bivirkninger påvirker os ikke på nogen måde, og ingen andre bivirkninger er mulige med sikker kode alene.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Stærke referencer skal samlet have en delt svag reference, så kør ikke destruktoren for vores gamle svage reference.
        //
        mem::forget(weak);
        strong
    }

    /// Konstruerer en ny `Arc` med ikke-initialiseret indhold.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Udskudt initialisering:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstruerer en ny `Arc` med ikke-initialiseret indhold, hvor hukommelsen er fyldt med `0` bytes.
    ///
    ///
    /// Se [`MaybeUninit::zeroed`][zeroed] for eksempler på korrekt og forkert brug af denne metode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Konstruerer en ny `Pin<Arc<T>>`.
    /// Hvis `T` ikke implementerer `Unpin`, bliver `data` fastgjort i hukommelsen og kan ikke flyttes.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Konstruerer en ny `Arc<T>` og returnerer en fejl, hvis tildelingen mislykkes.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Start den svage markør tæller som 1, hvilket er den svage markør, der holdes af alle de stærke markører (kinda), se std/rc.rs for mere info
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Konstruerer en ny `Arc` med ikke-initialiseret indhold og returnerer en fejl, hvis tildelingen mislykkes.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Udskudt initialisering:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Konstruerer en ny `Arc` med ikke-initialiseret indhold, hvor hukommelsen udfyldes med `0`-byte, og returnerer en fejl, hvis tildelingen mislykkes.
    ///
    ///
    /// Se [`MaybeUninit::zeroed`][zeroed] for eksempler på korrekt og forkert brug af denne metode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Returnerer den indre værdi, hvis `Arc` har nøjagtigt en stærk reference.
    ///
    /// Ellers returneres en [`Err`] med den samme `Arc`, som blev sendt ind.
    ///
    ///
    /// Dette vil lykkes, selvom der er fremragende svage referencer.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Lav en svag markør for at rydde op i den implicitte stærk-svage reference
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Konstruerer en ny atom-referencetællet skive med ikke-initialiseret indhold.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Udskudt initialisering:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Konstruerer et nyt atomisk referencetællet stykke med uinitialiseret indhold, hvor hukommelsen er fyldt med `0` bytes.
    ///
    ///
    /// Se [`MaybeUninit::zeroed`][zeroed] for eksempler på korrekt og forkert brug af denne metode.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Konverterer til `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Som med [`MaybeUninit::assume_init`] er det op til den, der ringer op, at garantere, at den indre værdi virkelig er i en initialiseret tilstand.
    ///
    /// At kalde dette, når indholdet endnu ikke er initialiseret, forårsager øjeblikkelig udefineret adfærd.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Udskudt initialisering:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Konverterer til `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Som med [`MaybeUninit::assume_init`] er det op til den, der ringer op, at garantere, at den indre værdi virkelig er i en initialiseret tilstand.
    ///
    /// At kalde dette, når indholdet endnu ikke er initialiseret, forårsager øjeblikkelig udefineret adfærd.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Udskudt initialisering:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Forbruger `Arc` og returnerer den indpakkede markør.
    ///
    /// For at undgå hukommelseslækage skal markøren konverteres tilbage til en `Arc` ved hjælp af [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Giver en rå markør til dataene.
    ///
    /// Tællingerne påvirkes ikke på nogen måde, og `Arc` forbruges ikke.
    /// Markøren er gyldig, så længe der er stærke optællinger i `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // SIKKERHED: Dette kan ikke gennemgå Deref::deref eller RcBoxPtr::inner, fordi
        // dette er nødvendigt for at bevare raw/mut herkomst, således at f.eks
        // `get_mut` kan skrive gennem markøren, efter at Rc er gendannet via `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Konstruerer en `Arc<T>` fra en rå markør.
    ///
    /// Den rå markør skal tidligere være returneret ved et opkald til [`Arc<U>::into_raw`][into_raw], hvor `U` skal have samme størrelse og justering som `T`.
    /// Dette er trivielt sandt, hvis `U` er `T`.
    /// Bemærk, at hvis `U` ikke er `T`, men har samme størrelse og justering, er det grundlæggende som at transmittere referencer af forskellige typer.
    /// Se [`mem::transmute`][transmute] for at få flere oplysninger om, hvilke begrænsninger der gælder i dette tilfælde.
    ///
    /// Brugeren af `from_raw` skal sørge for, at en bestemt værdi på `T` kun tabes en gang.
    ///
    /// Denne funktion er usikker, fordi forkert brug kan føre til usikkerhed i hukommelsen, selvom der aldrig er adgang til den returnerede `Arc<T>`.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Konverter tilbage til en `Arc` for at forhindre lækage.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Yderligere opkald til `Arc::from_raw(x_ptr)` ville være hukommelsesfarlige.
    /// }
    ///
    /// // Hukommelsen blev frigjort, da `x` gik uden for anvendelsesområdet ovenfor, så `x_ptr` dingler nu!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Vend forskydningen for at finde den originale ArcInner.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Opretter en ny [`Weak`]-markør til denne tildeling.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Dette afslappet er OK, fordi vi kontrollerer værdien i CAS nedenfor.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // kontrollere, om den svage tæller i øjeblikket er "locked";hvis ja, drej.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: denne kode ignorerer i øjeblikket muligheden for overløb
            // ind i usize::MAX;generelt skal både Rc og Arc justeres for at håndtere overløb.
            //

            // I modsætning til Clone() har vi brug for, at dette er en erhvervslæsning for at synkronisere med skrivningen, der kommer fra `is_unique`, så begivenhederne før denne skrivning sker før denne læsning.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Sørg for, at vi ikke opretter en dinglende svag
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Henter antallet af [`Weak`]-markører til denne fordeling.
    ///
    /// # Safety
    ///
    /// Denne metode er i sig selv sikker, men brug af den korrekt kræver ekstra omhu.
    /// En anden tråd kan til enhver tid ændre det svage antal, inklusive potentielt mellem at kalde denne metode og reagere på resultatet.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Denne påstand er deterministisk, fordi vi ikke har delt `Arc` eller `Weak` mellem tråde.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Hvis den svage optælling i øjeblikket er låst, var værdien af optællingen 0 lige før du tog låsen.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Får antallet af stærke (`Arc`)-markører til denne fordeling.
    ///
    /// # Safety
    ///
    /// Denne metode er i sig selv sikker, men brug af den korrekt kræver ekstra omhu.
    /// En anden tråd kan til enhver tid ændre det stærke antal, inklusive potentielt mellem at kalde denne metode og reagere på resultatet.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Denne påstand er deterministisk, fordi vi ikke har delt `Arc` mellem tråde.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Forøger det stærke referencetal på `Arc<T>` forbundet med den medfølgende markør en.
    ///
    /// # Safety
    ///
    /// Markøren skal være opnået gennem `Arc::into_raw`, og den tilknyttede `Arc`-forekomst skal være gyldig (dvs.
    /// det stærke antal skal være mindst 1) i løbet af denne metode.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Denne påstand er deterministisk, fordi vi ikke har delt `Arc` mellem tråde.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Behold Arc, men rør ikke ved genindtælling ved at indpakke den i ManuallyDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Forøg nu genoptællingen, men slip heller ikke ny genantælling
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Reducerer det stærke referencetal på `Arc<T>` forbundet med den medfølgende markør én.
    ///
    /// # Safety
    ///
    /// Markøren skal være opnået gennem `Arc::into_raw`, og den tilknyttede `Arc`-forekomst skal være gyldig (dvs.
    /// det stærke antal skal være mindst 1), når denne metode påberåbes.
    /// Denne metode kan bruges til at frigive det endelige `Arc` og baglager, men **bør ikke** kaldes, efter at den endelige `Arc` er frigivet.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Disse påstande er deterministiske, fordi vi ikke har delt `Arc` mellem tråde.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Denne usikkerhed er ok, for mens denne lysbue er i live, er vi garanteret, at den indre markør er gyldig.
        // Desuden ved vi, at selve `ArcInner`-strukturen er `Sync`, fordi de indre data også er `Sync`, så det er ok at låne en uforanderlig markør til dette indhold.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Ikke-inline-del af `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Ødelæg dataene på dette tidspunkt, selvom vi muligvis ikke frigør selve boksallokeringen (der kan stadig være svage markører, der ligger rundt).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Slip den svage ref samlet, som alle stærke referencer har
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Returnerer `true`, hvis de to `Arc`s peger på den samme allokering (i en vene svarende til [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Tildeler en `ArcInner<T>` med tilstrækkelig plads til en muligvis ikke-størrelse indre værdi, hvor værdien har det tilvejebragte layout.
    ///
    /// Funktionen `mem_to_arcinner` kaldes med datapekeren og skal returnere en (potentielt fed)-peger til `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Beregn layout ved hjælp af det givne værdilayout.
        // Tidligere blev layout beregnet på udtrykket `&*(ptr as* const ArcInner<T>)`, men dette skabte en forkert justeret reference (se #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Tildel en `ArcInner<T>` med tilstrækkelig plads til en muligvis ikke-størrelse indre værdi, hvor værdien har det tilvejebragte layout, og returnerer en fejl, hvis tildelingen mislykkes.
    ///
    ///
    /// Funktionen `mem_to_arcinner` kaldes med datapekeren og skal returnere en (potentielt fed)-peger til `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Beregn layout ved hjælp af det givne værdilayout.
        // Tidligere blev layout beregnet på udtrykket `&*(ptr as* const ArcInner<T>)`, men dette skabte en forkert justeret reference (se #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Initialiser ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Tildel en `ArcInner<T>` med tilstrækkelig plads til en ikke-dimensioneret indre værdi.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Tildel til `ArcInner<T>` ved hjælp af den givne værdi.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopier værdi som byte
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Gratis tildelingen uden at droppe indholdet
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Tildeler en `ArcInner<[T]>` med den givne længde.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Kopier elementer fra skive til nyligt tildelt Arc <\[T\]>
    ///
    /// Usikker, fordi den, der ringer op, enten skal tage ejerskab eller binde `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Konstruerer en `Arc<[T]>` fra en iterator, der vides at være af en bestemt størrelse.
    ///
    /// Adfærd er udefineret, hvis størrelsen er forkert.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic beskytter mens kloning af T-elementer.
        // I tilfælde af en panic slettes elementer, der er skrevet i den nye ArcInner, hvorefter hukommelsen frigøres.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Markør til første element
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Fri bane.Glem vagten, så den ikke frigør den nye ArcInner.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Specialisering trait anvendt til `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Opretter en klon af `Arc`-markøren.
    ///
    /// Dette skaber en anden markør til den samme fordeling, hvilket øger det stærke referencetal.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Brug af en afslappet rækkefølge er okay her, da viden om den originale reference forhindrer andre tråde i at fejlagtigt slette objektet.
        //
        // Som forklaret i [Boost documentation][1], kan forøgelse af referencetælleren altid gøres med memory_order_relaxed: Nye referencer til et objekt kan kun dannes ud fra en eksisterende reference, og overførsel af en eksisterende reference fra en tråd til en anden skal allerede give enhver krævet synkronisering.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Vi er dog nødt til at beskytte mod massive refoptællinger, hvis nogen er 'mem: : glemmer'buer.
        // Hvis vi ikke gør dette, kan antallet løbe over, og brugerne vil bruge dem efter gratis.
        // Vi mætter racily til `isize::MAX` under den antagelse, at der ikke er ~2 milliarder tråde, der øger referencetallet på én gang.
        //
        // Denne branch vil aldrig blive taget i noget realistisk program.
        //
        // Vi afbryder, fordi et sådant program er utroligt degenereret, og vi er ligeglade med at støtte det.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Foretager en ændret henvisning til den givne `Arc`.
    ///
    /// Hvis der er andre `Arc`-eller [`Weak`]-markører til den samme allokering, opretter `make_mut` en ny allokering og påberåber sig [`clone`][clone] på den indre værdi for at sikre unikt ejerskab.
    /// Dette kaldes også klon-på-skriv.
    ///
    /// Bemærk, at dette adskiller sig fra [`Rc::make_mut`] s adfærd, som adskiller eventuelle resterende `Weak`-markører.
    ///
    /// Se også [`get_mut`][get_mut], som mislykkes snarere end kloning.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Vil ikke klone noget
    /// let mut other_data = Arc::clone(&data); // Vil ikke klone indre data
    /// *Arc::make_mut(&mut data) += 1;         // Kloner indre data
    /// *Arc::make_mut(&mut data) += 1;         // Vil ikke klone noget
    /// *Arc::make_mut(&mut other_data) *= 2;   // Vil ikke klone noget
    ///
    /// // Nu peger `data` og `other_data` på forskellige tildelinger.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Bemærk, at vi både har en stærk og en svag reference.
        // Således frigiver kun vores stærke reference ikke i sig selv, at hukommelsen bliver deallokeret.
        //
        // Brug Acquire for at sikre, at vi ser enhver skrivning til `weak`, der sker, før frigivelsen skriver (dvs. reduktioner) til `strong`.
        // Da vi har en svag optælling, er der ingen chance for, at ArcInner selv kunne omfordeles.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Der findes en anden stærk markør, så vi skal klone.
            // Forud tildel hukommelse for at tillade skrivning af den klonede værdi direkte.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Afslappet er tilstrækkeligt i ovenstående, fordi dette grundlæggende er en optimering: vi kører altid med svage pegepinde, der bliver droppet.
            // I værste fald tildelte vi en ny Arc unødigt.
            //

            // Vi fjernede den sidste stærke ref, men der er yderligere svage ref.
            // Vi flytter indholdet til en ny bue og annullerer de andre svage ref.
            //

            // Bemærk, at det ikke er muligt for læsning af `weak` at give usize::MAX (dvs. låst), da det svage antal kun kan låses af en tråd med en stærk reference.
            //
            //

            // Materialiser vores egen implicitte svage markør, så den kan rydde op i ArcInner efter behov.
            //
            let _weak = Weak { ptr: this.ptr };

            // Kan bare stjæle dataene, alt der er tilbage er svagheder
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Vi var den eneste reference af begge slags;bump back up den stærke ref tælling.
            //
            this.inner().strong.store(1, Release);
        }

        // Som med `get_mut()` er usikkerheden ok, fordi vores reference enten var unik til at begynde med eller blev en efter kloning af indholdet.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Returnerer en ændret reference til den givne `Arc`, hvis der ikke er andre `Arc`-eller [`Weak`]-markører til den samme allokering.
    ///
    ///
    /// Returnerer [`None`] ellers, fordi det ikke er sikkert at mutere en delt værdi.
    ///
    /// Se også [`make_mut`][make_mut], som vil [`clone`][clone] den indre værdi, når der er andre markører.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Denne usikkerhed er ok, fordi vi er garanteret, at den returnerede markør er den *eneste* markør, der nogensinde vil blive returneret til T.
            // Vores referencetælling er garanteret 1 på dette tidspunkt, og vi krævede, at selve buen var `mut`, så vi returnerer den eneste mulige reference til de indre data.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Returnerer en ændret reference i den givne `Arc` uden kontrol.
    ///
    /// Se også [`get_mut`], som er sikkert og foretager passende kontrol.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Alle andre `Arc`-eller [`Weak`]-pegepinde til den samme fordeling må ikke henvises til i løbet af det returnerede lån.
    ///
    /// Dette er trivielt tilfældet, hvis der ikke findes sådanne markører, f.eks. Umiddelbart efter `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Vi er omhyggelige med at *ikke* oprette en reference, der dækker "count"-felterne, da dette ville være alias med samtidig adgang til referencetællingerne (f.eks.
        // af `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Bestem, om dette er den unikke reference (inklusive svage refs) til de underliggende data.
    ///
    ///
    /// Bemærk, at dette kræver låsning af den svage ref-optælling.
    fn is_unique(&mut self) -> bool {
        // låse antallet af svage markører, hvis vi ser ud til at være den eneste svage pointerholder.
        //
        // Erhvervelsesetiketten her sikrer et hændelsesforhold med enhver skrivning til `strong` (især i `Weak::upgrade`) før nedbrydninger af `weak`-antallet (via `Weak::drop`, der bruger frigivelse).
        // Hvis den opgraderede svage ref aldrig blev droppet, vil CAS her mislykkes, så vi er ligeglade med at synkronisere.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Dette skal være en `Acquire` for at synkronisere med nedgangen i `strong`-tælleren i `drop`-den eneste adgang, der sker, når nogen, men den sidste reference, slettes.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Udgivelsesskrivningen her synkroniseres med en læsning i `downgrade`, hvilket effektivt forhindrer ovenstående læsning af `strong` i at ske efter skrivningen.
            //
            //
            self.inner().weak.store(1, Release); // frigør låsen
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Slipper `Arc`.
    ///
    /// Dette mindsker den stærke referencetælling.
    /// Hvis det stærke referencetal når nul, er de eneste andre referencer (hvis nogen) [`Weak`], så vi `drop` den indre værdi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Udskriver ikke noget
    /// drop(foo2);   // Udskriver "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Da `fetch_sub` allerede er atomisk, behøver vi ikke synkronisere med andre tråde, medmindre vi skal slette objektet.
        // Den samme logik gælder for nedenstående `fetch_sub` til `weak`-antallet.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Dette hegn er nødvendigt for at forhindre omorganisering af brugen af dataene og sletning af dataene.
        // Da det er markeret `Release`, synkroniseres faldet i referencetallet med dette `Acquire`-hegn.
        // Dette betyder, at brug af data sker, før referencetællingen reduceres, hvilket sker før dette hegn, hvilket sker inden sletningen af dataene.
        //
        // Som forklaret i [Boost documentation][1],
        //
        // > Det er vigtigt at håndhæve enhver mulig adgang til objektet i et
        // > tråd (gennem en eksisterende reference) til *ske før* sletning
        // > objektet i en anden tråd.Dette opnås med en "release"
        // > efter at have henvist en reference (enhver adgang til objektet
        // > gennem denne henvisning skal naturligvis ske før), og en
        // > "acquire" før sletning af objektet.
        //
        // Især mens indholdet af en bue normalt ikke kan ændres, er det muligt at få interiør til at skrive til noget som en Mutex<T>.
        // Da en Mutex ikke erhverves, når den slettes, kan vi ikke stole på dens synkroniseringslogik for at gøre skrivning i tråd A synlig for en destruktor, der kører i tråd B.
        //
        //
        // Bemærk også, at Acquire-hegnet her sandsynligvis kunne erstattes med en Acquire-belastning, hvilket kunne forbedre ydeevnen i stærkt stridende situationer.Se [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Forsøg på at nedskyde `Arc<dyn Any + Send + Sync>` til en konkret type.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Konstruerer en ny `Weak<T>` uden at tildele nogen hukommelse.
    /// At kalde [`upgrade`] på returværdien giver altid [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Hjælpertype, der giver adgang til referencetællinger uden at fremsætte påstande om datafeltet.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Returnerer en rå markør til objektet `T`, som denne `Weak<T>` peger på.
    ///
    /// Markøren er kun gyldig, hvis der er nogle stærke referencer.
    /// Markøren kan være dinglende, ujusteret eller endda [`null`] på anden måde.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Begge peger på det samme objekt
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Den stærke her holder den i live, så vi stadig kan få adgang til objektet.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Men ikke længere.
    /// // Vi kan gøre weak.as_ptr(), men adgang til markøren vil føre til udefineret adfærd.
    /// // assert_eq! ("hej", usikker {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Hvis markøren hænger tilbage, returnerer vi sentinel direkte.
            // Dette kan ikke være en gyldig nyttelastadresse, da nyttelasten er mindst lige så justeret som ArcInner (usize).
            ptr as *const T
        } else {
            // SIKKERHED: Hvis is_dangling returnerer false, kan markøren henvises.
            // Nyttelasten kan blive droppet på dette tidspunkt, og vi er nødt til at opretholde herkomst, så brug rå markørmanipulation.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Forbruger `Weak<T>` og gør det til en rå markør.
    ///
    /// Dette konverterer den svage markør til en rå markør, mens det stadig bevares ejerskabet af en svag reference (det svage antal ændres ikke af denne operation).
    /// Det kan omdannes til `Weak<T>` med [`from_raw`].
    ///
    /// De samme begrænsninger for adgang til markørens mål som med [`as_ptr`] gælder.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Konverterer en rå pointer, der tidligere er oprettet af [`into_raw`], tilbage til `Weak<T>`.
    ///
    /// Dette kan bruges til sikkert at få en stærk reference (ved at ringe til [`upgrade`] senere) eller til at placere det svage antal ved at droppe `Weak<T>`.
    ///
    /// Det tager ejerskab af en svag reference (med undtagelse af pointer oprettet af [`new`], da disse ikke ejer noget; metoden fungerer stadig på dem).
    ///
    /// # Safety
    ///
    /// Markøren skal stamme fra [`into_raw`] og skal stadig have sin potentielle svage reference.
    ///
    /// Det er tilladt for den stærke optælling at være 0 på tidspunktet for kaldet til dette.
    /// Ikke desto mindre tager dette ejerskab af en svag reference, der i øjeblikket er repræsenteret som en rå markør (den svage optælling ændres ikke af denne operation), og den skal derfor parres med et tidligere opkald til [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Reducer den sidste svage optælling.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Se Weak::as_ptr for kontekst om, hvordan inputmarkøren afledes.

        let ptr = if is_dangling(ptr as *mut T) {
            // Dette er en dinglende svag.
            ptr as *mut ArcInner<T>
        } else {
            // Ellers er vi garanteret, at markøren kom fra en svag svindel.
            // SIKKERHED: data_offset er sikkert at ringe til, da ptr refererer til en reel (potentielt droppet) T.
            let offset = unsafe { data_offset(ptr) };
            // Således vender vi offset for at få hele RcBox.
            // SIKKERHED: markøren stammer fra en svag, så denne forskydning er sikker.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // SIKKERHED: Vi har nu genoprettet den originale svage markør, så vi kan oprette den svage.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Forsøger at opgradere `Weak`-markøren til en [`Arc`], idet den indre værdi forsinkes, hvis den lykkes.
    ///
    ///
    /// Returnerer [`None`], hvis den indre værdi siden er faldet.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Ødelæg alle stærke henvisninger.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Vi bruger en CAS-loop til at øge den stærke optælling i stedet for en fetch_add, da denne funktion aldrig skal tage referencetallet fra nul til en.
        //
        //
        let inner = self.inner()?;

        // Afslappet belastning, fordi enhver skrivning af 0, som vi kan observere, efterlader feltet i en permanent nul-tilstand (så en "stale"-læsning af 0 er fint), og enhver anden værdi bekræftes via CAS nedenfor.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Se kommentarer i `Arc::clone` for hvorfor vi gør dette (for `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Afslappet er fint for fejlsagen, fordi vi ikke har nogen forventninger til den nye stat.
            // Erhvervelse er nødvendig for, at successagen synkroniseres med `Arc::new_cyclic`, når den indre værdi kan initialiseres, efter at `Weak`-referencer allerede er oprettet.
            // I så fald forventer vi at observere den fuldt initialiserede værdi.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null markeret ovenfor
                Err(old) => n = old,
            }
        }
    }

    /// Får antallet af stærke (`Arc`)-markører, der peger på denne tildeling.
    ///
    /// Hvis `self` blev oprettet ved hjælp af [`Weak::new`], returnerer dette 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Får en tilnærmelse af antallet af `Weak`-markører, der peger på denne tildeling.
    ///
    /// Hvis `self` blev oprettet ved hjælp af [`Weak::new`], eller hvis der ikke er nogen resterende stærke markører, returnerer dette 0.
    ///
    /// # Accuracy
    ///
    /// På grund af implementeringsdetaljer kan den returnerede værdi være slået fra med 1 i begge retninger, når andre tråde manipulerer nogen `Arc`s eller`Weak`s, der peger på den samme allokering.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Da vi observerede, at der var mindst en stærk markør efter at have læst den svage optælling, ved vi, at den implicitte svage reference (til stede når nogen stærke referencer er i live) stadig eksisterede, da vi observerede den svage optælling, og kan derfor sikkert trække den.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Returnerer `None`, når markøren dingler, og der ikke er tildelt `ArcInner`, (dvs. når denne `Weak` blev oprettet af `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Vi er omhyggelige med at *ikke* oprette en reference, der dækker "data"-feltet, da feltet kan blive muteret samtidigt (for eksempel hvis den sidste `Arc` droppes, vil datafeltet blive droppet på plads).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Returnerer `true`, hvis de to `svage` peger på den samme allokering (svarende til [`ptr::eq`]), eller hvis begge ikke peger på nogen allokering (fordi de blev oprettet med `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Da dette sammenligner henvisninger, betyder det, at `Weak::new()` vil svare til hinanden, selvom de ikke peger på nogen fordeling.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Sammenligning af `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Opretter en klon af `Weak`-markøren, der peger på den samme fordeling.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Se kommentarer i Arc::clone() for hvorfor dette er afslappet.
        // Dette kan bruge en fetch_add (ignorerer låsen), fordi den svage optælling kun er låst, hvor der *ingen andre* svage peger findes.
        //
        // (Så vi kan ikke køre denne kode i så fald).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Se kommentarer i Arc::clone() for hvorfor vi gør dette (for mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Konstruerer en ny `Weak<T>` uden at tildele hukommelse.
    /// At kalde [`upgrade`] på returværdien giver altid [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Slipper `Weak`-markøren.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Udskriver ikke noget
    /// drop(foo);        // Udskriver "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Hvis vi finder ud af, at vi var den sidste svage markør, er det tid til at placere dataene helt.Se diskussionen i Arc::drop() om hukommelsesbestillingerne
        //
        // Det er ikke nødvendigt at kontrollere for den låste tilstand her, fordi den svage optælling kun kan låses, hvis der netop var en svag ref, hvilket betyder, at fald kun senere kunne køre TIL den resterende svage ref, hvilket kun kan ske, når låsen frigøres.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Vi laver denne specialisering her og ikke som en mere generel optimering på `&T`, fordi det ellers ville tilføje en omkostning til al lighedskontrol af refs.
/// Vi antager, at `Arc`s bruges til at gemme store værdier, der er langsomme til at klone, men også svære at kontrollere for lighed, hvilket får disse omkostninger til at betale sig lettere.
///
/// Det er også mere sandsynligt at have to `Arc`-kloner, der peger på den samme værdi, end to `&T`s.
///
/// Vi kan kun gøre dette, når `T: Eq` som `PartialEq` måske bevidst er refleksiv.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Lighed for to `Arc`s.
    ///
    /// To `Arc`s er ens, hvis deres indre værdier er ens, selvom de er gemt i forskellige tildelinger.
    ///
    /// Hvis `T` også implementerer `Eq` (antyder refleksivitet af lighed), er to `Arc`s, der peger på den samme allokering, altid ens.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Ulighed for to `Arc`s.
    ///
    /// To `Arc`s er ulige, hvis deres indre værdier er ulige.
    ///
    /// Hvis `T` også implementerer `Eq` (antyder refleksivitet af lighed), er to `Arc`s, der peger på den samme værdi, aldrig ulige.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Delvis sammenligning for to `Arc`s.
    ///
    /// De to sammenlignes ved at kalde `partial_cmp()` på deres indre værdier.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Mindre end sammenligning for to `Arc`s.
    ///
    /// De to sammenlignes ved at kalde `<` på deres indre værdier.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// 'Mindre end eller lig med' sammenligning for to `Arc`s.
    ///
    /// De to sammenlignes ved at kalde `<=` på deres indre værdier.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Større end sammenligning for to `Arc`s.
    ///
    /// De to sammenlignes ved at kalde `>` på deres indre værdier.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 'Større end eller lig med' sammenligning for to `Arc`s.
    ///
    /// De to sammenlignes ved at kalde `>=` på deres indre værdier.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Sammenligning for to `Arc`s.
    ///
    /// De to sammenlignes ved at kalde `cmp()` på deres indre værdier.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Opretter en ny `Arc<T>` med `Default`-værdien for `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Tildel et referencetællet stykke, og udfyld det ved at klone 'v''s emner.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Tildel en referencetællet `str` og kopier `v` ind i den.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Tildel en referencetællet `str` og kopier `v` ind i den.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Flyt et objekt i boks til en ny, referencetælletildeling.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Tildel en referencetællet skive, og flyt 'v''s emner ind i den.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Lad Vec frigøre hukommelsen, men ikke ødelægge dens indhold
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Tager hvert element i `Iterator` og samler det i en `Arc<[T]>`.
    ///
    /// # Ydeevneegenskaber
    ///
    /// ## Den generelle sag
    ///
    /// Generelt sker indsamling i `Arc<[T]>` ved først at indsamle i en `Vec<T>`.Det vil sige, når du skriver følgende:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// dette opfører sig som om vi skrev:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Det første sæt tildelinger sker her.
    ///     .into(); // En anden tildeling til `Arc<[T]>` sker her.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Dette tildeles så mange gange som nødvendigt til konstruktion af `Vec<T>`, og derefter tildeles det én gang til omdannelse af `Vec<T>` til `Arc<[T]>`.
    ///
    ///
    /// ## Iteratorer af kendt længde
    ///
    /// Når din `Iterator` implementerer `TrustedLen` og har en nøjagtig størrelse, foretages der en enkelt tildeling til `Arc<[T]>`.For eksempel:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Her sker bare en enkelt tildeling.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Specialisering trait brugt til indsamling i `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Dette er tilfældet for en `TrustedLen` iterator.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // SIKKERHED: Vi skal sikre, at iteratoren har en nøjagtig længde, og det har vi.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Fald tilbage til normal implementering.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Få forskydningen inden for en `ArcInner` for nyttelasten bag en markør.
///
/// # Safety
///
/// Markøren skal pege på (og have gyldige metadata til) en tidligere gyldig forekomst af T, men T må slettes.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Juster den usikre værdi til slutningen af ArcInner.
    // Fordi RcBox er repr(C), vil det altid være det sidste felt i hukommelsen.
    // SIKKERHED: da de eneste mulige typer er skiver, trait objekter,
    // og eksterne typer, er sikkerhedskravet for input i øjeblikket tilstrækkeligt til at opfylde kravene til align_of_val_raw;dette er en implementeringsdetalje af det sprog, der muligvis ikke er afhængig af uden for std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}