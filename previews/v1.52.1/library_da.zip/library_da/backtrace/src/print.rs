#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// En formatering til backtraces.
///
/// Denne type kan bruges til at udskrive en backtrace uanset hvor selve backtrace kommer fra.
/// Hvis du har en `Backtrace`-type, bruger `Debug`-implementeringen allerede dette udskrivningsformat.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Udskrivningsformerne, som vi kan udskrive
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Udskriver en terser-backtrace, der ideelt set kun indeholder relevant information
    Short,
    /// Udskriver et backtrace, der indeholder alle mulige oplysninger
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Opret en ny `BacktraceFmt`, som skriver output til den medfølgende `fmt`.
    ///
    /// `format`-argumentet styrer den stil, hvor backtrace udskrives, og `print_path`-argumentet bruges til at udskrive `BytesOrWideString`-forekomsterne af filnavne.
    /// Denne type selv udskriver ikke filnavne, men denne tilbagekaldelse er nødvendig for at gøre det.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Udskriver en indledning til det bagspor, der skal udskrives.
    ///
    /// Dette kræves på nogle platforme, for at backtraces bliver fuldt symboliseret senere, og ellers skulle dette bare være den første metode, du kalder efter oprettelse af en `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Tilføjer en ramme til backtrace-output.
    ///
    /// Denne forpligtelse returnerer en RAII-forekomst af en `BacktraceFrameFmt`, som kan bruges til faktisk at udskrive en ramme, og ved destruktion øges den ramtælleren.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Fuldfører backtrace-output.
    ///
    /// Dette er i øjeblikket et no-op, men tilføjes for future-kompatibilitet med backtrace-formater.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // I øjeblikket en no-op-- inklusive denne hook for at muliggøre future tilføjelser.
        Ok(())
    }
}

/// En formatering til kun en ramme af et backtrace.
///
/// Denne type oprettes af `BacktraceFmt::frame`-funktionen.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Udskriver en `BacktraceFrame` med denne rammeformater.
    ///
    /// Dette udskriver rekursivt alle `BacktraceSymbol`-forekomster inden for `BacktraceFrame`.
    ///
    /// # Nødvendige funktioner
    ///
    /// Denne funktion kræver, at `std`-funktionen i `backtrace` crate er aktiveret, og `std`-funktionen er aktiveret som standard.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Udskriver en `BacktraceSymbol` i en `BacktraceFrame`.
    ///
    /// # Nødvendige funktioner
    ///
    /// Denne funktion kræver, at `std`-funktionen i `backtrace` crate er aktiveret, og `std`-funktionen er aktiveret som standard.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: dette er ikke godt, at vi ikke ender med at udskrive noget
            // med ikke-utf8 filnavne.
            // Heldigvis er næsten alt utf8, så dette skal ikke være så dårligt.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Udskriver en rå sporet `Frame` og `Symbol`, typisk inden for de rå tilbagekald af denne crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Tilføjer en rå ramme til backtrace-output.
    ///
    /// Denne metode tager, i modsætning til den foregående, de rå argumenter, hvis de kommer fra forskellige steder.
    /// Bemærk, at dette kan kaldes flere gange for en ramme.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Føjer en rå ramme til backtrace-output, inklusive kolonneoplysninger.
    ///
    /// Denne metode, som den foregående, tager de rå argumenter, hvis de kommer fra forskellige placeringer.
    /// Bemærk, at dette kan kaldes flere gange for en ramme.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia er ude af stand til at symbolisere inden for en proces, så det har et specielt format, som kan bruges til at symbolisere senere.
        // Udskriv det i stedet for at udskrive adresser i vores eget format her.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Ingen grund til at udskrive "null"-rammer, det betyder stort set bare, at systemets backtrace var lidt ivrig efter at spore super langt tilbage.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // For at reducere TCB-størrelse i Sgx-enklave ønsker vi ikke at implementere symbolopløsningsfunktionalitet.
        // Vi kan snarere udskrive forskydningen af adressen her, som senere kan kortlægges til korrekt funktion.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Udskriv rammens indeks samt rammens valgfri instruktionsmarkør.
        // Hvis vi er ud over det første symbol på denne ramme, udskriver vi bare passende mellemrum.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Skriv derefter symbolnavnet ud ved hjælp af den alternative formatering for at få flere oplysninger, hvis vi er en fuld backtrace.
        // Her håndterer vi også symboler, der ikke har noget navn,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Og sidst skal du udskrive filename/line-nummeret, hvis det er tilgængeligt.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line er udskrevet på linjer under symbolnavnet, så udskriv noget passende mellemrum for at rette op på os.
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Delegér til vores interne tilbagekald for at udskrive filnavnet og derefter udskrive linjenummeret.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Tilføj kolonnenummer, hvis det er tilgængeligt.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Vi holder kun af det første symbol på en ramme
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}