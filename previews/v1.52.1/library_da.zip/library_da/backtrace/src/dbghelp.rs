//! Et modul til at styre dbghelp-bindinger på Windows
//!
//! Backtraces på Windows (i det mindste til MSVC) drives stort set gennem `dbghelp.dll` og de forskellige funktioner, den indeholder.
//! Disse funktioner er i øjeblikket indlæst *dynamisk* i stedet for at linke til `dbghelp.dll` statisk.
//! Dette gøres i øjeblikket af standardbiblioteket (og kræves i teorien der), men er et forsøg på at hjælpe med at reducere de statiske dll-afhængigheder i et bibliotek, da backtraces typisk er ret valgfri.
//!
//! Når det er sagt, indlæses `dbghelp.dll` næsten altid med succes på Windows.
//!
//! Bemærk dog, at da vi indlæser al denne support dynamisk, kan vi faktisk ikke bruge de rå definitioner i `winapi`, men snarere er vi nødt til selv at definere funktionstegnetyperne og bruge det.
//! Vi ønsker ikke rigtig at være i gang med at duplikere winapi, så vi har en Cargo-funktion `verify-winapi`, der hævder, at alle bindinger matcher dem i winapi, og denne funktion er aktiveret på CI.
//!
//! Endelig bemærker du her, at dll til `dbghelp.dll` aldrig aflæsses, og det er i øjeblikket forsætligt.
//! Tanken er, at vi globalt kan cache det og bruge det mellem opkald til API'en og undgå dyre loads/unloads.
//! Hvis dette er et problem for lækagedetektorer eller noget lignende, kan vi krydse broen, når vi kommer derhen.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Arbejd omkring `SymGetOptions` og `SymSetOptions`, som ikke er til stede i selve winapi.
// Ellers bruges dette kun, når vi dobbelttjekker typer mod winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Ikke defineret i winapi endnu
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Dette er defineret i winapi, men det er forkert (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Ikke defineret i winapi endnu
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Denne makro bruges til at definere en `Dbghelp`-struktur, der internt indeholder alle de funktionsmarkører, vi kan indlæse.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// Den indlæste DLL til `dbghelp.dll`
            dll: HMODULE,

            // Hver funktionsmarkør for hver funktion, vi muligvis bruger
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Oprindeligt har vi ikke indlæst DLL
            dll: 0 as *mut _,
            // Initialer alle funktioner er nul for at sige, at de skal indlæses dynamisk.
            //
            $($name: 0,)*
        };

        // Bekvemmelighed typedef for hver funktionstype.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Forsøg på at åbne `dbghelp.dll`.
            /// Returnerer succes, hvis det fungerer, eller fejl, hvis `LoadLibraryW` mislykkes.
            ///
            /// Panics hvis biblioteket allerede er indlæst.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Funktion for hver metode, vi gerne vil bruge.
            // Når den kaldes, læser den enten cachefunktionsmarkøren eller indlæser den og returnerer den indlæste værdi.
            // Belastninger hævdes at lykkes.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Bekvemmelighedsproxy til at bruge oprydningslåse til reference til dbghelp-funktioner.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Initialiser al nødvendig support for at få adgang til `dbghelp` API-funktioner fra denne crate.
///
///
/// Bemærk, at denne funktion er **sikker**, den har sin egen synkronisering internt.
/// Bemærk også, at det er sikkert at kalde denne funktion flere gange rekursivt.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Den første ting, vi skal gøre, er at synkronisere denne funktion.Dette kan kaldes samtidigt fra andre tråde eller rekursivt inden for en tråd.
        // Bemærk, at det er vanskeligere end det, fordi det, vi bruger her, `dbghelp`,*også* skal synkroniseres med alle andre opkaldere til `dbghelp` i denne proces.
        //
        // Der er typisk ikke så mange opkald til `dbghelp` inden for samme proces, og vi kan sandsynligvis antage, at vi er de eneste, der får adgang til det.
        // Der er dog en primær anden bruger, som vi er bekymrede over, hvilket ironisk nok er os selv, men i standardbiblioteket.
        // Rust-standardbiblioteket afhænger af denne crate for understøttelse af backtrace, og denne crate findes også på crates.io.
        // Dette betyder, at hvis standardbiblioteket udskriver en panic-backtrace, kan det køre med denne crate, der kommer fra crates.io, hvilket forårsager segfaults.
        //
        // For at hjælpe med at løse dette synkroniseringsproblem anvender vi et Windows-specifikt trick her (det er trods alt en Windows-specifik begrænsning om synkronisering).
        // Vi opretter en *session-lokal* med navnet mutex for at beskytte dette opkald.
        // Hensigten her er, at standardbiblioteket og denne crate ikke behøver at dele Rust-niveau-API'er for at synkronisere her, men i stedet kan arbejde bag kulisserne for at sikre, at de synkroniseres med hinanden.
        //
        // På den måde når denne funktion kaldes gennem standardbiblioteket eller gennem crates.io, kan vi være sikre på, at den samme mutex erhverves.
        //
        // Så alt dette er at sige, at det første vi gør her er, at vi atomisk opretter en `HANDLE`, som er en navngivet mutex på Windows.
        // Vi synkroniserer lidt med andre tråde, der deler denne funktion specifikt, og sikrer, at der kun oprettes et håndtag pr. Forekomst af denne funktion.
        // Bemærk, at håndtaget aldrig lukkes, når det først er gemt i det globale.
        //
        // Når vi faktisk har gået i lås, erhverver vi det simpelthen, og vores `Init`-håndtag, vi uddeler, er ansvarlig for at droppe det til sidst.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Okay, pis!Nu hvor vi alle er sikkert synkroniseret, lad os faktisk begynde at behandle alt.
        // Først skal vi sikre, at `dbghelp.dll` faktisk indlæses i denne proces.
        // Vi gør dette dynamisk for at undgå en statisk afhængighed.
        // Dette er historisk gjort for at arbejde omkring underlige forbindelsesproblemer og er beregnet til at gøre binære filer lidt mere bærbare, da dette stort set kun er et fejlfindingsværktøj.
        //
        //
        // Når vi har åbnet `dbghelp.dll`, skal vi kalde nogle initialiseringsfunktioner i det, og det er beskrevet mere detaljeret nedenfor.
        // Vi gør dog kun en gang, så vi har en global boolsk, der angiver, om vi er færdige endnu eller ej.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Sørg for, at `SYMOPT_DEFERRED_LOADS`-flag er indstillet, for ifølge MSVCs egne dokumenter om dette: "This is the fastest, most efficient way to use the symbol handler.", så lad os gøre det!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Initialiser faktisk symboler med MSVC.Bemærk, at dette kan mislykkes, men vi ignorerer det.
        // Der er ikke masser af kendt teknik til dette i sig selv, men LLVM synes internt at ignorere returværdien her, og et af saneringsbibliotekerne i LLVM udskriver en skræmmende advarsel, hvis dette mislykkes, men dybest set ignorerer det i det lange løb.
        //
        //
        // Et tilfælde, hvor dette kommer meget op for Rust, er at standardbiblioteket og denne crate på crates.io begge vil konkurrere om `SymInitializeW`.
        // Standardbiblioteket ønskede historisk at initialisere derefter oprydning det meste af tiden, men nu det bruger denne crate betyder det, at nogen først kommer til initialisering, og den anden afhenter initialiseringen.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}