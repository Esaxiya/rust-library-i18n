//! Symbolikstrategi ved hjælp af DWARF-parsingskoden i libbacktrace.
//!
//! Libbacktrace C-biblioteket, typisk distribueret med gcc, understøtter ikke kun generering af et backtrace (som vi faktisk ikke bruger), men også symboliserer backtrace og håndtering af dværgfejlfindingsoplysninger om ting som inline-rammer og hvad der ikke er.
//!
//!
//! Dette er relativt kompliceret på grund af mange forskellige bekymringer her, men den grundlæggende idé er:
//!
//! * Først kalder vi `backtrace_syminfo`.Dette får symboloplysninger fra den dynamiske symboltabel, hvis vi kan.
//! * Dernæst kalder vi `backtrace_pcinfo`.Dette parser debuginfo-tabeller, hvis de er tilgængelige, og giver os mulighed for at gendanne oplysninger om indbyggede rammer, filnavne, linjenumre osv.
//!
//! Der er masser af trickery ved at få dværgtabellerne ind i libbacktrace, men forhåbentlig er det ikke verdens ende og er tydeligt nok, når du læser nedenfor.
//!
//! Dette er standardstrategien for symbolisering af platforme, der ikke er MSVC og ikke OSX.I libstd er dette dog standardstrategien for OSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Hvis det er muligt foretrækker `function`-navnet, der kommer fra debuginfo og typisk kan være mere præcist for f.eks. Indbyggede rammer.
                // Hvis det ikke er til stede, skal du dog falde tilbage til det symboltabelnavn, der er angivet i `symname`.
                //
                // Bemærk, at `function` undertiden kan føles noget mindre nøjagtigt, for eksempel at være opført som `try<i32,closure>` ikke er i stedet for `std::panicking::try::do_call`.
                //
                // Det er ikke rigtig klart hvorfor, men generelt ser `function`-navnet mere præcist ud.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // gør ingenting for nu
}

/// Type af `data`-markøren sendt til `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Når denne tilbagekaldelse påberåbes fra `backtrace_syminfo`, når vi begynder at løse, går vi længere for at ringe til `backtrace_pcinfo`.
    // `backtrace_pcinfo`-funktionen konsulterer fejlretningsoplysninger og forsøger at gøre ting som at gendanne file/line-oplysninger såvel som inline-rammer.
    // Bemærk dog, at `backtrace_pcinfo` kan mislykkes eller ikke gøre meget, hvis der ikke er fejlretningsoplysninger, så hvis det sker, er vi sikker på at ringe til tilbagekaldet med mindst et symbol fra `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Type af `data`-markøren sendt til `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Libbacktrace API understøtter oprettelse af en tilstand, men den understøtter ikke ødelæggelse af en tilstand.
// Jeg mener personligt, at dette betyder, at en stat er beregnet til at blive skabt og derefter leve for evigt.
//
// Jeg ville elske at registrere en at_exit()-handler, der rydder op i denne tilstand, men libbacktrace giver ingen måde at gøre det på.
//
// Med disse begrænsninger har denne funktion en statisk cachelagret tilstand, der beregnes første gang dette anmodes om.
//
// Husk, at backtracing alle sker serielt (en global lås).
//
// Bemærk, at manglen på synkronisering her skyldes kravet om, at `resolve` er eksternt synkroniseret.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Brug ikke threadsafe-funktioner i libbacktrace, da vi altid kalder det synkroniseret.
        //
        0,
        error_cb,
        ptr::null_mut(), // ingen ekstra data
    );

    return STATE;

    // Bemærk, at for at libbacktrace overhovedet skal fungere, skal den finde DWARF-fejlretningsinfo for den aktuelle eksekverbare.Det gør det typisk via en række mekanismer, herunder, men ikke begrænset til:
    //
    // * /proc/self/exe på understøttede platforme
    // * Filnavnet sendte eksplicit ind, når staten oprettede
    //
    // Libbacktrace-biblioteket er et stort stykke C-kode.Dette betyder naturligvis, at det har hukommelsessikkerhedsproblemer, især når man håndterer misdannet debuginfo.
    // Libstd er historisk stødt på masser af disse.
    //
    // Hvis /proc/self/exe bruges, kan vi typisk ignorere disse, da vi antager, at libbacktrace er "mostly correct" og ellers ikke gør underlige ting med "attempted to be correct" dværg-fejlretningsinfo.
    //
    //
    // Hvis vi sender et filnavn, er det dog muligt på nogle platforme (som BSD'er), hvor en ondsindet aktør kan få en vilkårlig fil til at blive placeret på det sted.
    // Dette betyder, at hvis vi fortæller libbacktrace om et filnavn, bruger det muligvis en vilkårlig fil, der muligvis forårsager segfaults.
    // Hvis vi ikke fortæller libbacktrace noget, så gør det ikke noget på platforme, der ikke understøtter stier som /proc/self/exe!
    //
    // I betragtning af alt det prøver vi så hårdt som muligt at *ikke* videregive et filnavn, men vi skal på platforme, der slet ikke understøtter /proc/self/exe.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Bemærk, at vi ideelt set ville bruge `std::env::current_exe`, men vi kan ikke kræve `std` her.
            //
            // Brug `_NSGetExecutablePath` til at indlæse den aktuelle eksekverbare sti i et statisk område (som hvis det er for lille bare give op).
            //
            //
            // Bemærk, at vi seriøst stoler på libbacktrace her for ikke at dø af korrupte eksekverbare filer, men det gør det bestemt ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows har en tilstand til åbning af filer, hvor den ikke kan slettes, efter den er åbnet.
            // Det er generelt, hvad vi vil have her, fordi vi vil sikre, at vores eksekverbare ikke ændrer sig under os, efter at vi har afleveret den til libbacktrace, forhåbentlig mindsker evnen til at videregive vilkårlige data til libbacktrace (som kan blive forkert behandlet).
            //
            //
            // I betragtning af at vi danser lidt her for at forsøge at få en slags lås på vores eget image:
            //
            // * Få hånd om den aktuelle proces, indlæs dens filnavn.
            // * Åbn en fil til det filnavn med de rigtige flag.
            // * Genindlæs den aktuelle proces filnavn, og sørg for, at det er det samme
            //
            // Hvis alt dette går, har vi i teorien faktisk åbnet vores procesfil, og vi er garanteret, at det ikke vil ændre sig.FWIW en masse af dette er historisk kopieret fra libstd, så dette er min bedste fortolkning af, hvad der skete.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Dette lever i statisk hukommelse, så vi kan returnere det ..
                static mut BUF: [i8; N] = [0; N];
                // ... og dette lever på stakken, da det er midlertidigt
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // lækker forsætligt `handle` her, fordi det at have det åbent skal bevare vores lås på dette filnavn.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Vi ønsker at returnere et stykke, der er nul-afsluttet, så hvis alt blev udfyldt, og det svarer til den samlede længde, så sidestil det med fiasko.
                //
                //
                // Ellers når du vender tilbage til succes, skal du sørge for, at nulbyte er inkluderet i udsnittet.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // backtrace-fejl fejes i øjeblikket under tæppet
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Ring til `backtrace_syminfo` API, som (fra læsning af koden) skal ringe til `syminfo_cb` nøjagtigt en gang (eller mislykkes med en fejl antagelig).
    // Vi håndterer derefter mere inden for `syminfo_cb`.
    //
    // Bemærk, at vi gør dette, da `syminfo` vil se symboltabellen og finde symbolnavne, selvom der ikke er nogen fejlretningsoplysninger i binærprogrammet.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}