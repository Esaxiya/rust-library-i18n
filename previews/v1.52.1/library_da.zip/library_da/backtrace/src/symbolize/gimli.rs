//! Understøttelse af symbolisering ved hjælp af `gimli` crate på crates.io
//!
//! Dette er standardimplementering af symbolisering for Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'statisk levetid er en løgn at hacke rundt manglende støtte til selvhenvisende strukturer.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Konverter til 'statiske levetider, da symbolerne kun skal låne `map` og `stash`, og vi bevarer dem nedenfor.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // For at indlæse indfødte biblioteker på Windows, se nogle diskussioner om rust-lang/rust#71060 for de forskellige strategier her.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // MinGW-biblioteker understøtter i øjeblikket ikke ASLR (rust-lang/rust#16514), men DLL'er kan stadig flyttes rundt i adresseområdet.
            // Det ser ud til, at adresser i debuginfo alle er, som om dette bibliotek blev indlæst på sin "image base", som er et felt i dets COFF-filoverskrifter.
            // Da dette er, hvad debuginfo ser ud til at liste, analyserer vi symboltabellen og gemmer adresser, som om biblioteket også var indlæst på "image base".
            //
            // Biblioteket kan dog ikke indlæses på "image base".
            // (formodentlig kan der læses noget andet der?) Det er her `bias`-feltet kommer til spil, og vi skal finde ud af værdien af `bias` her.Desværre er det dog ikke klart, hvordan man erhverver dette fra et indlæst modul.
            // Hvad vi dog har, er den faktiske belastningsadresse (`modBaseAddr`).
            //
            // Som lidt af en cop-out for nu mmap vi filen, læser filens headeroplysninger og slipper derefter mmap.Dette er spild, fordi vi sandsynligvis genåbner mmap senere, men dette skal fungere godt nok indtil videre.
            //
            // Når vi har `image_base` (ønsket belastningsplacering) og `base_addr` (faktisk belastningsplacering), kan vi udfylde `bias` (forskel mellem den faktiske og ønskede) og derefter er den angivne adresse for hvert segment `image_base`, da det er hvad filen siger.
            //
            //
            // For nu ser det ud til, at vi i modsætning til ELF/MachO kan klare et segment pr. Bibliotek ved at bruge `modBaseSize` som hele størrelsen.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS bruger Mach-O-filformatet og bruger DYLD-specifikke API'er til at indlæse en liste over indfødte biblioteker, der er en del af applikationen.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Hent navnet på dette bibliotek, der svarer til stien til, hvor det også skal indlæses.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Indlæs billedoverskriften på dette bibliotek og deleger til `object` for at analysere alle belastningskommandoer, så vi kan finde ud af alle de involverede segmenter her.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Iterer over segmenterne og registrer kendte regioner for segmenter, som vi finder.
            // Derudover registrerer du oplysninger om tekstsegmenter til senere behandling, se kommentarer nedenfor.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Bestem "slide" for dette bibliotek, som ender med at være den bias, vi bruger til at finde ud af, hvor i hukommelsen objekter er indlæst.
            // Dette er dog lidt underlig beregning og er resultatet af at prøve et par ting i naturen og se, hvad der holder fast.
            //
            // Den generelle idé er, at `bias` plus et segment's `stated_virtual_memory_address` vil være, hvor i det faktiske adresseområde segmentet befinder sig.
            // Den anden ting, vi er afhængige af, er dog, at en reel adresse minus `bias` er indekset til at slå op i symboltabellen og debuginfo.
            //
            // Det viser sig imidlertid, at disse beregninger for systembelastede biblioteker er forkerte.For indfødte eksekverbare filer ser det dog ud til at være korrekt.
            // Løfter noget logik fra LLDB's kilde, har det noget specielt kabinet til den første `__TEXT`-sektion indlæst fra filoffset 0 med en ikke-nul-størrelse.
            // Af en eller anden grund, når dette er til stede, ser det ud til at betyde, at symboltabellen er relativt til kun vmaddr-diaset til biblioteket.
            // Hvis det *ikke* er til stede, er symboltabellen i forhold til vmaddr-dias plus segmentets angivne adresse.
            //
            // For at håndtere denne situation, hvis vi *ikke* finder et tekstafsnit ved fil offset nul, øger vi bias med de første tekstafsnit angivet adresse og reducerer også alle angivne adresser med det beløb.
            //
            // På den måde vises symboltabellen altid i forhold til bibliotekets biasbeløb.
            // Dette ser ud til at have de rigtige resultater til symbolisering via symboltabellen.
            //
            // Ærligt talt er jeg ikke helt sikker på, om dette er rigtigt, eller om der er noget andet, der skal angive, hvordan man gør dette.
            // For nu ser det ud til at fungere godt nok (?), og vi skal altid være i stand til at finjustere dette over tid, hvis det er nødvendigt.
            //
            // For mere information, se #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Andet Unix (f.eks
        // Linux)-platforme bruger ELF som et objektfilformat og implementerer typisk en API kaldet `dl_iterate_phdr` til at indlæse indfødte biblioteker.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` skal være en gyldig henvisning.
        // `vec` skal være en gyldig markør til en `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 understøtter ikke indbygget debuginfo, men build-systemet placerer debuginfo på stien `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Alt andet skal bruge ELF, men ved ikke, hvordan man indlæser indfødte biblioteker.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Alle kendte delte biblioteker, der er blevet indlæst.
    libraries: Vec<Library>,

    /// Mappings cache, hvor vi gemmer analyserede dværgoplysninger.
    ///
    /// Denne liste har en fast kapacitet for hele sin løftid, som aldrig øges.
    /// `usize`-elementet i hvert par er et indeks i `libraries` over, hvor `usize::max_value()` repræsenterer den aktuelle eksekverbare.
    ///
    /// `Mapping` er tilsvarende analyseret dværginformation.
    ///
    /// Bemærk, at dette dybest set er en LRU-cache, og vi skifter ting rundt herinde, når vi symboliserer adresser.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Segmenter af dette bibliotek indlæst i hukommelsen, og hvor de er indlæst.
    segments: Vec<LibrarySegment>,
    /// "bias" i dette bibliotek, typisk hvor det indlæses i hukommelsen.
    /// Denne værdi føjes til hvert segments angivne adresse for at få den faktiske virtuelle hukommelsesadresse, som segmentet indlæses i.
    /// Derudover trækkes denne bias fra reelle virtuelle hukommelsesadresser for at indeksere i debuginfo og symboltabellen.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Den angivne adresse på dette segment i objektfilen.
    /// Dette er faktisk ikke, hvor segmentet er indlæst, men snarere er denne adresse plus det indeholdende biblioteks `bias`, hvor det skal findes.
    ///
    stated_virtual_memory_address: usize,
    /// Størrelsen på dette segment i hukommelsen.
    len: usize,
}

// usikre, fordi dette kræves for at være synkroniseret eksternt
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // usikre, fordi dette kræves for at være synkroniseret eksternt
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // En meget lille, meget enkel LRU-cache til fejlfinding af info om kortlægning.
        //
        // Hitfrekvensen skal være meget høj, da den typiske stak ikke krydser mellem mange delte biblioteker.
        //
        // `addr2line::Context`-strukturer er ret dyre at skabe.
        // Dens omkostninger forventes at blive afskrevet af efterfølgende `locate`-forespørgsler, som udnytter de strukturer, der er bygget, når der konstrueres `addr2line: : Context`s for at få gode hastigheder.
        //
        // Hvis vi ikke havde denne cache, ville afskrivningen aldrig ske, og symbolsk backtraces ville være ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Test først, om denne `lib` har et segment, der indeholder `addr` (håndtering af flytning).Hvis denne kontrol består, kan vi fortsætte nedenfor og faktisk oversætte adressen.
                //
                // Bemærk, at vi bruger `wrapping_add` her for at undgå overløbskontrol.Det er blevet set i naturen, at SVMA + bias-beregningen overløber.
                // Det virker lidt underligt, at det ville ske, men der er ikke meget, vi kan gøre ved det andet end sandsynligvis bare ignorere disse segmenter, da de sandsynligvis peger ud i rummet.
                //
                // Dette kom oprindeligt op i rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Nu hvor vi ved, at `lib` indeholder `addr`, kan vi udligne med bias for at finde den angivne virutale hukommelsesadresse.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Invariant: efter at denne betingede er afsluttet uden tidligt at vende tilbage
        // fra en fejl er cacheindgangen for denne sti i indeks 0.

        if let Some(idx) = idx {
            // Når kortlægningen allerede er i cachen, skal du flytte den til forsiden.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Når kortlægningen ikke er i cachen, skal du oprette en ny kortlægning, indsætte den foran cachen og fjerne evt. Den ældste cacheindgang.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // ikke lækker `'static`-levetiden, skal du sørge for, at den er beregnet til kun os selv
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Forlæng levetiden for `sym` til `'static`, da vi desværre kræves her, men det går altid ud som en reference, så ingen henvisning til det skal alligevel vedholdes ud over denne ramme.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Til sidst skal du få en cachelagret kortlægning eller oprette en ny kortlægning til denne fil og evaluere DWARF-info for at finde file/line/name til denne adresse.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Vi var i stand til at finde rammeoplysninger til dette symbol, og `addr2line`s ramme har internt alle de skøre detaljer.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Kunne ikke finde fejlretningsoplysninger, men vi fandt dem i symboltabellen til den eksekverbare alf.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}