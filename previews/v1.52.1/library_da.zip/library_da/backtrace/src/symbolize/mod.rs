use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Løs en adresse til et symbol, og send symbolet til den angivne lukning.
///
/// Denne funktion vil slå den givne adresse op i områder som f.eks. Den lokale symboltabel, dynamisk symboltabel eller DWARF-fejlretningsinfo (afhængigt af den aktiverede implementering) for at finde symboler, der skal give.
///
///
/// Lukningen kaldes muligvis ikke, hvis opløsning ikke kunne udføres, og det kan også kaldes mere end én gang i tilfælde af indlejrede funktioner.
///
/// De viste symboler repræsenterer udførelsen ved den angivne `addr`, der returnerer file/line-par for den adresse (hvis tilgængelig).
///
/// Bemærk, at hvis du har en `Frame`, anbefales det at bruge `resolve_frame`-funktionen i stedet for denne.
///
/// # Nødvendige funktioner
///
/// Denne funktion kræver, at `std`-funktionen i `backtrace` crate er aktiveret, og `std`-funktionen er aktiveret som standard.
///
/// # Panics
///
/// Denne funktion stræber efter aldrig panic, men hvis `cb` leverede panics, vil nogle platforme tvinge en dobbelt panic til at afbryde processen.
/// Nogle platforme bruger et C-bibliotek, der internt bruger tilbagekald, som ikke kan spoles gennem, så panik fra `cb` kan udløse en procesafbrydelse.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // se kun på den øverste ramme
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Løs en tidligere optagelsesramme til et symbol, og send symbolet til den angivne lukning.
///
/// Denne funktion udfører den samme funktion som `resolve`, bortset fra at den tager en `Frame` som et argument i stedet for en adresse.
/// Dette kan gøre det muligt for nogle platformimplementeringer af backtracing at give mere nøjagtig symbolinformation eller information om f.eks. Indbyggede rammer.
///
/// Det anbefales at bruge dette, hvis du kan.
///
/// # Nødvendige funktioner
///
/// Denne funktion kræver, at `std`-funktionen i `backtrace` crate er aktiveret, og `std`-funktionen er aktiveret som standard.
///
/// # Panics
///
/// Denne funktion stræber efter aldrig panic, men hvis `cb` leverede panics, vil nogle platforme tvinge en dobbelt panic til at afbryde processen.
/// Nogle platforme bruger et C-bibliotek, der internt bruger tilbagekald, som ikke kan spoles gennem, så panik fra `cb` kan udløse en procesafbrydelse.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // se kun på den øverste ramme
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// IP-værdier fra stakrammer er typisk (always?) instruktionen *efter* det opkald, der er det faktiske stakspor.
// Symbolisering af dette på får filename/line-nummeret til at være et foran og måske i tomrummet, hvis det er nær slutningen af funktionen.
//
// Dette ser ud til at være grundlæggende altid tilfældet på alle platforme, så vi trækker altid en fra en løst ip for at løse den til den tidligere opkaldsinstruktion i stedet for at instruktionen returneres til.
//
//
// Ideelt set ville vi ikke gøre dette.
// Ideelt set ville vi kræve, at opkaldere af `resolve` API'erne her manuelt udfører -1 og tager højde for, at de ønsker placeringsoplysninger til *forrige* instruktion, ikke den aktuelle.
// Ideelt set udsætter vi også for `Frame`, hvis vi faktisk er adressen på den næste instruktion eller den aktuelle.
//
// Indtil videre er dette en temmelig niche-bekymring, så vi trækker kun internt altid en.
// Forbrugerne skal fortsætte med at arbejde og få ret gode resultater, så vi skal være gode nok.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Samme som `resolve`, kun usikkert, da det er usynkroniseret.
///
/// Denne funktion har ikke synkroniseringsgarantier, men er tilgængelig, når `std`-funktionen i denne crate ikke er kompileret i.
/// Se `resolve`-funktionen for mere dokumentation og eksempler.
///
/// # Panics
///
/// Se oplysninger om `resolve` for advarsler om `cb` panik.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Samme som `resolve_frame`, kun usikkert, da det er usynkroniseret.
///
/// Denne funktion har ikke synkroniseringsgarantier, men er tilgængelig, når `std`-funktionen i denne crate ikke er kompileret i.
/// Se `resolve_frame`-funktionen for mere dokumentation og eksempler.
///
/// # Panics
///
/// Se oplysninger om `resolve_frame` for advarsler om panik i `cb`.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// En trait, der repræsenterer opløsningen af et symbol i en fil.
///
/// Denne trait leveres som et trait-objekt til lukningen givet til `backtrace::resolve`-funktionen, og den sendes næsten, da det er ukendt, hvilken implementering der ligger bag den.
///
///
/// Et symbol kan give kontekstuelle oplysninger om en funktion, for eksempel navn, filnavn, linjenummer, præcis adresse osv.
/// Ikke alle oplysninger er altid tilgængelige med et symbol, så alle metoder returnerer en `Option`.
///
///
pub struct Symbol {
    // TODO: denne levetid bundet skal vedvares til sidst til `Symbol`,
    // men det er i øjeblikket en brudende ændring.
    // For nu er dette sikkert, da `Symbol` kun nogensinde udleveres som reference og ikke kan klones.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Returnerer navnet på denne funktion.
    ///
    /// Den returnerede struktur kan bruges til at spørge forskellige egenskaber om symbolnavnet:
    ///
    ///
    /// * `Display`-implementeringen udskriver det afbrydede symbol.
    /// * Den rå `str`-værdi af symbolet kan tilgås (hvis den er gyldig utf-8).
    /// * De rå byte til symbolnavnet kan tilgås.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Returnerer startadressen for denne funktion.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Returnerer det rå filnavn som et udsnit.
    /// Dette er hovedsageligt nyttigt i `no_std`-miljøer.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Returnerer kolonnenummeret, hvor dette symbol i øjeblikket udføres.
    ///
    /// Kun gimli giver i øjeblikket en værdi her og endda kun hvis `filename` returnerer `Some`, og det er derfor følgelig underlagt lignende forbehold.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Returnerer linjenummeret, hvor dette symbol i øjeblikket udføres.
    ///
    /// Denne returværdi er typisk `Some`, hvis `filename` returnerer `Some`, og er følgelig underlagt lignende forbehold.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Returnerer filnavnet, hvor denne funktion blev defineret.
    ///
    /// Dette er i øjeblikket kun tilgængeligt, når libbacktrace eller gimli bruges (f.eks
    /// unix andre platforme) og når en binær er kompileret med debuginfo.
    /// Hvis ingen af disse betingelser er opfyldt, vil dette sandsynligvis returnere `None`.
    ///
    /// # Nødvendige funktioner
    ///
    /// Denne funktion kræver, at `std`-funktionen i `backtrace` crate er aktiveret, og `std`-funktionen er aktiveret som standard.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Måske et parset C++ -symbol, hvis parsing af det manglede symbol som Rust mislykkedes.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Sørg for at holde denne størrelse nul, så `cpp_demangle`-funktionen ikke har nogen omkostninger, når den er deaktiveret.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// En indpakning omkring et symbolnavn for at give ergonomiske accessorer til det afviklede navn, de rå byte, den rå streng osv.
///
// Tillad død kode, når `cpp_demangle`-funktionen ikke er aktiveret.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Opretter et nyt symbolnavn ud fra de rå underliggende byte.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Returnerer det rå (mangled)-symbolnavn som en `str`, hvis symbolet er gyldigt utf-8.
    ///
    /// Brug `Display`-implementeringen, hvis du vil have en demanglet version.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Returnerer det rå symbolnavn som en liste over bytes
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Dette kan f.eks. Udskrives, hvis det afbrydede symbol faktisk ikke er gyldigt, så håndter fejlen her yndefuldt ved ikke at udbrede den udad.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Forsøg at genvinde den cachelagrede hukommelse, der bruges til at symbolisere adresser.
///
/// Denne metode vil forsøge at frigive globale datastrukturer, der ellers er cachelagret globalt eller i tråden, som typisk repræsenterer analyseret DWARF-information eller lignende.
///
///
/// # Caveats
///
/// Mens denne funktion altid er tilgængelig, gør den faktisk ikke noget på de fleste implementeringer.
/// Biblioteker som dbghelp eller libbacktrace giver ikke faciliteter til at deallocate tilstand og administrere den tildelte hukommelse.
/// Indtil videre er `gimli-symbolize`-funktionen i denne crate den eneste funktion, hvor denne funktion har nogen effekt.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}