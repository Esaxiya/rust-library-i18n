// bruges kun på Linux lige nu, så tillad død kode andetsteds
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// En simpel arenatildeling til bytebuffere.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Tildeler en buffer med den angivne størrelse og returnerer en ændret reference til den.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // SIKKERHED: dette er den eneste funktion, der nogensinde konstruerer en mutabel
        // henvisning til `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // SIKKERHED: vi fjerner aldrig elementer fra `self.buffers`, så en reference
        // til dataene inde i enhver buffer vil leve, så længe `self` gør.
        &mut buffers[i]
    }
}