use core::fmt::{self, Write};
use core::mem::{size_of, transmute};
use core::slice::from_raw_parts;
use libc::c_char;

extern "C" {
    // dl_iterate_phdr tager et tilbagekald, der modtager en dl_phdr_info-markør for hver DSO, der er linket til processen.
    // dl_iterate_phdr sikrer også, at den dynamiske linker er låst fra iteration til start til slut.
    // Hvis tilbagekaldet returnerer en værdi, der ikke er nul, afsluttes iterationen tidligt.
    // 'data' vil blive sendt som det tredje argument til tilbagekaldet ved hvert opkald.
    // 'size' giver størrelsen på dl_phdr_info.
    //
    #[allow(improper_ctypes)]
    fn dl_iterate_phdr(
        f: extern "C" fn(info: &dl_phdr_info, size: usize, data: &mut DsoPrinter<'_, '_>) -> i32,
        data: &mut DsoPrinter<'_, '_>,
    ) -> i32;
}

// Vi er nødt til at analysere build-id'et og nogle grundlæggende programoverskriftsdata, hvilket betyder, at vi også har brug for en smule ting fra ELF-spec.
//

const PT_LOAD: u32 = 1;
const PT_NOTE: u32 = 4;

// Nu skal vi replikere, bit for bit, strukturen af typen dl_phdr_info, der bruges af fuchsias nuværende dynamiske linker.
// Chrom har også denne ABI-grænse såvel som crashpad.
// Til sidst vil vi gerne flytte disse sager til at bruge alf-search, men vi bliver nødt til at give det i SDK, og det er endnu ikke gjort.
//
// Således sidder vi (og de) fast med at skulle bruge denne metode, der påløber en tæt kobling med fuchsia libc.
//

#[allow(non_camel_case_types)]
#[repr(C)]
struct dl_phdr_info {
    addr: *const u8,
    name: *const c_char,
    phdr: *const Elf_Phdr,
    phnum: u16,
    adds: u64,
    subs: u64,
    tls_modid: usize,
    tls_data: *const u8,
}

impl dl_phdr_info {
    fn program_headers(&self) -> PhdrIter<'_> {
        PhdrIter {
            phdrs: self.phdr_slice(),
            base: self.addr,
        }
    }
    // Vi har ingen måde at vide, om e_phoff og e_phnum er gyldige.
    // libc bør sikre dette for os dog, så det er sikkert at danne et stykke her.
    fn phdr_slice(&self) -> &[Elf_Phdr] {
        unsafe { from_raw_parts(self.phdr, self.phnum as usize) }
    }
}

struct PhdrIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: *const u8,
}

impl<'a> Iterator for PhdrIter<'a> {
    type Item = Phdr<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().map(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            Phdr {
                phdr,
                base: self.base,
            }
        })
    }
}

// Elf_Phdr repræsenterer en 64-bit ELF-programoverskrift i slutningen af målarkitekturen.
//
#[allow(non_camel_case_types)]
#[derive(Clone, Debug)]
#[repr(C)]
struct Elf_Phdr {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

// Phdr repræsenterer en gyldig ELF-programoverskrift og dens indhold.
struct Phdr<'a> {
    phdr: &'a Elf_Phdr,
    base: *const u8,
}

impl<'a> Phdr<'a> {
    // Vi har ingen måde at kontrollere, om p_addr eller p_memsz er gyldige.
    // Fuchsias libc analyserer først noterne, så i kraft af at være her skal disse overskrifter være gyldige.
    //
    // NoteIter kræver ikke, at de underliggende data er gyldige, men det kræver, at grænserne er gyldige.
    // Vi stoler på, at libc har sikret, at dette er tilfældet for os her.
    fn notes(&self) -> NoteIter<'a> {
        unsafe {
            NoteIter::new(
                self.base.add(self.phdr.p_offset as usize),
                self.phdr.p_memsz as usize,
            )
        }
    }
}

// Notetypen til build-id'er.
const NT_GNU_BUILD_ID: u32 = 3;

// Elf_Nhdr repræsenterer en ELF-noteoverskrift i målets slutning.
#[allow(non_camel_case_types)]
#[repr(C)]
struct Elf_Nhdr {
    n_namesz: u32,
    n_descsz: u32,
    n_type: u32,
}

// Note repræsenterer en ELF-note (header + indhold).
// Navnet efterlades som et u8-udsnit, fordi det ikke altid er nulstillet, og rust gør det let nok at kontrollere, at byte matcher en eller anden måde.
//
struct Note<'a> {
    name: &'a [u8],
    desc: &'a [u8],
    tipe: u32,
}

// NoteIter giver dig mulighed for sikkert at gentage et notesegment.
// Den afsluttes, så snart der opstår en fejl, eller der ikke er flere noter.
// Hvis du gentager sig over ugyldige data, fungerer det som om der ikke blev fundet nogen noter.
struct NoteIter<'a> {
    base: &'a [u8],
    error: bool,
}

impl<'a> NoteIter<'a> {
    // Det er en funktionsvariant, at markøren og den angivne størrelse angiver et gyldigt interval af bytes, som alle kan læses.
    // Indholdet af disse bytes kan være alt andet end området skal være gyldigt for at dette er sikkert.
    //
    unsafe fn new(base: *const u8, size: usize) -> Self {
        NoteIter {
            base: from_raw_parts(base, size),
            error: false,
        }
    }
}

// align_to justerer 'x' til 'to'-byte-justering forudsat at 'to' er en styrke på 2.
// Dette følger et standardmønster i C/C ++ ELF-parsingskode, hvor (x + til, 1)&-to bruges.
// Rust lader dig ikke benægte brug, så jeg bruger det
// 2-komplementkonvertering for at genskabe det.
fn align_to(x: usize, to: usize) -> usize {
    (x + to - 1) & (!to + 1)
}

// take_bytes_align4 forbruger antal byte fra udsnittet (hvis det findes) og sikrer desuden, at det endelige udsnit er korrekt justeret.
// Hvis enten antallet af bytes, der er anmodet om, er for stort, eller hvis udsnittet ikke kan justeres bagefter på grund af ikke nok resterende bytes, returneres ingen, og udsnittet ændres ikke.
//
//
//
fn take_bytes_align4<'a>(num: usize, bytes: &mut &'a [u8]) -> Option<&'a [u8]> {
    if bytes.len() < align_to(num, 4) {
        return None;
    }
    let (out, bytes_new) = bytes.split_at(num);
    *bytes = &bytes_new[align_to(num, 4) - num..];
    Some(out)
}

// Denne funktion har ingen reelle invarianter, som den, der ringer, skal opretholde, bortset fra måske at 'bytes' skal justeres for ydeevne (og på nogle arkitekturer korrekthed).
// Værdierne i felterne Elf_Nhdr kan være noget vrøvl, men denne funktion sikrer ikke sådan noget.
//
//
fn take_nhdr<'a>(bytes: &mut &'a [u8]) -> Option<&'a Elf_Nhdr> {
    if size_of::<Elf_Nhdr>() > bytes.len() {
        return None;
    }
    // Dette er sikkert, så længe der er nok plads, og vi bekræftede bare, at i if-erklæringen ovenfor, så dette ikke burde være usikkert.
    //
    let out = unsafe { transmute::<*const u8, &'a Elf_Nhdr>(bytes.as_ptr()) };
    // Bemærk, at sice_of: :<Elf_Nhdr>() er altid 4-byte-justeret.
    *bytes = &bytes[size_of::<Elf_Nhdr>()..];
    Some(out)
}

impl<'a> Iterator for NoteIter<'a> {
    type Item = Note<'a>;
    fn next(&mut self) -> Option<Self::Item> {
        // Kontroller, om vi er nået til slutningen.
        if self.base.len() == 0 || self.error {
            return None;
        }
        // Vi transmitterer en nhdr ud, men vi overvejer nøje den resulterende struktur.
        // Vi stoler ikke på namesz eller descsz, og vi tager ingen usikre beslutninger baseret på typen.
        //
        // Så selvom vi kommer ud af komplet skrald, skal vi stadig være i sikkerhed.
        let nhdr = take_nhdr(&mut self.base)?;
        let name = take_bytes_align4(nhdr.n_namesz as usize, &mut self.base)?;
        let desc = take_bytes_align4(nhdr.n_descsz as usize, &mut self.base)?;
        Some(Note {
            name: name,
            desc: desc,
            tipe: nhdr.n_type,
        })
    }
}

struct Perm(u32);

/// Angiver, at et segment er eksekverbart.
const PERM_X: u32 = 0b00000001;
/// Angiver, at et segment er skrivbart.
const PERM_W: u32 = 0b00000010;
/// Angiver, at et segment er læsbart.
const PERM_R: u32 = 0b00000100;

impl core::fmt::Display for Perm {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let v = self.0;
        if v & PERM_R != 0 {
            f.write_char('r')?
        }
        if v & PERM_W != 0 {
            f.write_char('w')?
        }
        if v & PERM_X != 0 {
            f.write_char('x')?
        }
        Ok(())
    }
}

/// Repræsenterer et ELF-segment ved kørselstid.
struct Segment {
    /// Giver den virtuelle runtime-adresse på dette segments indhold.
    addr: usize,
    /// Giver hukommelsesstørrelsen på dette segments indhold.
    size: usize,
    /// Giver modulets virtuelle adresse til dette segment med ELF-filen.
    mod_rel_addr: usize,
    /// Giver de tilladelser, der findes i ELF-filen.
    /// Disse tilladelser er dog ikke nødvendigvis de tilladelser, der er til stede under kørsel.
    flags: Perm,
}

/// Giver mulighed for at gentage segmenter fra en DSO.
struct SegmentIter<'a> {
    phdrs: &'a [Elf_Phdr],
    base: usize,
}

impl Iterator for SegmentIter<'_> {
    type Item = Segment;

    fn next(&mut self) -> Option<Self::Item> {
        self.phdrs.split_first().and_then(|(phdr, new_phdrs)| {
            self.phdrs = new_phdrs;
            if phdr.p_type != PT_LOAD {
                self.next()
            } else {
                Some(Segment {
                    addr: phdr.p_vaddr as usize + self.base,
                    size: phdr.p_memsz as usize,
                    mod_rel_addr: phdr.p_vaddr as usize,
                    flags: Perm(phdr.p_flags),
                })
            }
        })
    }
}

/// Repræsenterer en ELF DSO (Dynamic Shared Object).
/// Denne type henviser til de data, der er gemt i selve DSO snarere end at lave sin egen kopi.
struct Dso<'a> {
    /// Den dynamiske linker giver os altid et navn, selvom navnet er tomt.
    /// I tilfælde af den vigtigste eksekverbare navn vil dette navn være tomt.
    /// I tilfælde af et delt objekt vil det være sonamnet (se DT_SONAME).
    name: &'a str,
    /// På Fuchsia har næsten alle binære filer build-id'er, men dette er ikke en streng anmodning.
    /// Der er ingen måde at matche DSO-oplysninger med en ægte ELF-fil bagefter, hvis der ikke er nogen build_id, så vi kræver, at hver DSO har en her.
    ///
    /// DSO'er uden build_id ignoreres.
    build_id: &'a [u8],

    base: usize,
    phdrs: &'a [Elf_Phdr],
}

impl Dso<'_> {
    /// Returnerer en iterator over segmenter i denne DSO.
    fn segments(&self) -> SegmentIter<'_> {
        SegmentIter {
            phdrs: self.phdrs.as_ref(),
            base: self.base,
        }
    }
}

struct HexSlice<'a> {
    bytes: &'a [u8],
}

impl fmt::Display for HexSlice<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for byte in self.bytes {
            write!(f, "{:02x}", byte)?;
        }
        Ok(())
    }
}

fn get_build_id<'a>(info: &'a dl_phdr_info) -> Option<&'a [u8]> {
    for phdr in info.program_headers() {
        if phdr.phdr.p_type == PT_NOTE {
            for note in phdr.notes() {
                if note.tipe == NT_GNU_BUILD_ID && (note.name == b"GNU\0" || note.name == b"GNU") {
                    return Some(note.desc);
                }
            }
        }
    }
    None
}

/// Disse fejl koder for problemer, der opstår under parsing af oplysninger om hver DSO.
///
enum Error {
    /// NameError betyder, at der opstod en fejl under konvertering af en C-stilstreng til en rust-streng.
    ///
    NameError(core::str::Utf8Error),
    /// BuildIDError betyder, at vi ikke fandt et build-id.
    /// Dette kan enten være fordi DSO ikke havde noget build-ID, eller fordi segmentet, der indeholder build-ID, var forkert.
    ///
    BuildIDError,
}

/// Opkalder enten 'dso' eller 'error' for hver DSO, der er knyttet til processen af den dynamiske linker.
///
///
/// # Arguments
///
/// * `visitor` - En DsoPrinter, der har en af de spisemetoder, der kaldes for hver DSO.
fn for_each_dso(mut visitor: &mut DsoPrinter<'_, '_>) {
    extern "C" fn callback(
        info: &dl_phdr_info,
        _size: usize,
        visitor: &mut DsoPrinter<'_, '_>,
    ) -> i32 {
        // dl_iterate_phdr sikrer, at info.name peger på en gyldig placering.
        //
        let name_len = unsafe { libc::strlen(info.name) };
        let name_slice: &[u8] =
            unsafe { core::slice::from_raw_parts(info.name as *const u8, name_len) };
        let name = match core::str::from_utf8(name_slice) {
            Ok(name) => name,
            Err(err) => {
                return visitor.error(Error::NameError(err)) as i32;
            }
        };
        let build_id = match get_build_id(info) {
            Some(build_id) => build_id,
            None => {
                return visitor.error(Error::BuildIDError) as i32;
            }
        };
        visitor.dso(Dso {
            name: name,
            build_id: build_id,
            phdrs: info.phdr_slice(),
            base: info.addr as usize,
        }) as i32
    }
    unsafe { dl_iterate_phdr(callback, &mut visitor) };
}

struct DsoPrinter<'a, 'b> {
    writer: &'a mut core::fmt::Formatter<'b>,
    module_count: usize,
    error: core::fmt::Result,
}

impl DsoPrinter<'_, '_> {
    fn dso(&mut self, dso: Dso<'_>) -> bool {
        let mut write = || {
            write!(
                self.writer,
                "{{{{{{module:{:#x}:{}:elf:{}}}}}}}\n",
                self.module_count,
                dso.name,
                HexSlice {
                    bytes: dso.build_id.as_ref()
                }
            )?;
            for seg in dso.segments() {
                write!(
                    self.writer,
                    "{{{{{{mmap:{:#x}:{:#x}:load:{:#x}:{}:{:#x}}}}}}}\n",
                    seg.addr, seg.size, self.module_count, seg.flags, seg.mod_rel_addr
                )?;
            }
            self.module_count += 1;
            Ok(())
        };
        match write() {
            Ok(()) => false,
            Err(err) => {
                self.error = Err(err);
                true
            }
        }
    }
    fn error(&mut self, _error: Error) -> bool {
        false
    }
}

/// Denne funktion udskriver Fuchsia-symboliseringsmarkeringen for al information indeholdt i en DSO.
pub fn print_dso_context(out: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
    out.write_str("{{{reset}}}\n")?;
    let mut visitor = DsoPrinter {
        writer: out,
        module_count: 0,
        error: Ok(()),
    };
    for_each_dso(&mut visitor);
    visitor.error
}