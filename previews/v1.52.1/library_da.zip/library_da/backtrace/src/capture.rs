use crate::PrintFmt;
use crate::{resolve, resolve_frame, trace, BacktraceFmt, Symbol, SymbolName};
use std::ffi::c_void;
use std::fmt;
use std::path::{Path, PathBuf};
use std::prelude::v1::*;

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

/// Repræsentation af et ejet og selvstændigt backtrace.
///
/// Denne struktur kan bruges til at fange et backtrace på forskellige punkter i et program og senere bruges til at inspicere, hvad backtrace var på det tidspunkt.
///
///
/// `Backtrace` understøtter smuk udskrivning af backtraces gennem sin `Debug`-implementering.
///
/// # Nødvendige funktioner
///
/// Denne funktion kræver, at `std`-funktionen i `backtrace` crate er aktiveret, og `std`-funktionen er aktiveret som standard.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct Backtrace {
    // Rammer her er angivet fra top til bund af stakken
    frames: Vec<BacktraceFrame>,
    // Det indeks, vi mener, er den faktiske start af backtrace, idet vi udelader rammer som `Backtrace::new` og `backtrace::trace`.
    //
    actual_start_index: usize,
}

fn _assert_send_sync() {
    fn _assert<T: Send + Sync>() {}
    _assert::<Backtrace>();
}

/// Optaget version af en ramme i et backtrace.
///
/// Denne type returneres som en liste fra `Backtrace::frames` og repræsenterer en stakramme i et fanget backtrace.
///
/// # Nødvendige funktioner
///
/// Denne funktion kræver, at `std`-funktionen i `backtrace` crate er aktiveret, og `std`-funktionen er aktiveret som standard.
///
///
#[derive(Clone)]
pub struct BacktraceFrame {
    frame: Frame,
    symbols: Option<Vec<BacktraceSymbol>>,
}

#[derive(Clone)]
enum Frame {
    Raw(crate::Frame),
    #[allow(dead_code)]
    Deserialized {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
    },
}

impl Frame {
    fn ip(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.ip(),
            Frame::Deserialized { ip, .. } => ip as *mut c_void,
        }
    }

    fn symbol_address(&self) -> *mut c_void {
        match *self {
            Frame::Raw(ref f) => f.symbol_address(),
            Frame::Deserialized { symbol_address, .. } => symbol_address as *mut c_void,
        }
    }

    fn module_base_address(&self) -> Option<*mut c_void> {
        match *self {
            Frame::Raw(ref f) => f.module_base_address(),
            Frame::Deserialized {
                module_base_address,
                ..
            } => module_base_address.map(|addr| addr as *mut c_void),
        }
    }
}

/// Optaget version af et symbol i et backtrace.
///
/// Denne type returneres som en liste fra `BacktraceFrame::symbols` og repræsenterer metadataene for et symbol i et backtrace.
///
/// # Nødvendige funktioner
///
/// Denne funktion kræver, at `std`-funktionen i `backtrace` crate er aktiveret, og `std`-funktionen er aktiveret som standard.
///
///
#[derive(Clone)]
#[cfg_attr(feature = "serialize-rustc", derive(RustcDecodable, RustcEncodable))]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
pub struct BacktraceSymbol {
    name: Option<Vec<u8>>,
    addr: Option<usize>,
    filename: Option<PathBuf>,
    lineno: Option<u32>,
    colno: Option<u32>,
}

impl Backtrace {
    /// Fanger en backtrace på call-site for denne funktion og returnerer en ejet repræsentation.
    ///
    /// Denne funktion er nyttig til at repræsentere en backtrace som et objekt i Rust.Denne returnerede værdi kan sendes på tværs af tråde og udskrives andre steder, og formålet med denne værdi er at være helt selvstændig.
    ///
    /// Bemærk, at det på nogle platforme kan være ekstremt dyrt at erhverve en fuld backtrace og løse det.
    /// Hvis prisen er for stor for din applikation, anbefales det i stedet at bruge `Backtrace::new_unresolved()`, som undgår symbolopløsningstrinnet (som typisk tager længst tid) og tillader udsættelse til en senere dato.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let current_backtrace = Backtrace::new();
    /// ```
    ///
    /// # Nødvendige funktioner
    ///
    /// Denne funktion kræver, at `std`-funktionen i `backtrace` crate er aktiveret, og `std`-funktionen er aktiveret som standard.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline(never)] // vil sørge for, at der er en ramme, der skal fjernes
    pub fn new() -> Backtrace {
        let mut bt = Self::create(Self::new as usize);
        bt.resolve();
        bt
    }

    /// Svarende til `new`, bortset fra at dette ikke løser nogen symboler, fanger dette simpelthen backtrace som en liste over adresser.
    ///
    /// På et senere tidspunkt kan `resolve`-funktionen kaldes for at løse denne backtraces symboler til læsbare navne.
    /// Denne funktion eksisterer, fordi opløsningsprocessen undertiden kan tage en betydelig mængde tid, mens et hvilket som helst backtrace måske kun sjældent udskrives.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use backtrace::Backtrace;
    ///
    /// let mut current_backtrace = Backtrace::new_unresolved();
    /// println!("{:?}", current_backtrace); // ingen symbolnavne
    /// current_backtrace.resolve();
    /// println!("{:?}", current_backtrace); // symbolnavne nu til stede
    /// ```
    ///
    /// # Nødvendige funktioner
    ///
    /// Denne funktion kræver, at `std`-funktionen i `backtrace` crate er aktiveret, og `std`-funktionen er aktiveret som standard.
    ///
    ///
    ///
    #[inline(never)] // vil sørge for, at der er en ramme, der skal fjernes
    pub fn new_unresolved() -> Backtrace {
        Self::create(Self::new_unresolved as usize)
    }

    fn create(ip: usize) -> Backtrace {
        let mut frames = Vec::new();
        let mut actual_start_index = None;
        trace(|frame| {
            frames.push(BacktraceFrame {
                frame: Frame::Raw(frame.clone()),
                symbols: None,
            });

            if frame.symbol_address() as usize == ip && actual_start_index.is_none() {
                actual_start_index = Some(frames.len());
            }
            true
        });

        Backtrace {
            frames,
            actual_start_index: actual_start_index.unwrap_or(0),
        }
    }

    /// Returnerer rammerne fra det tidspunkt, hvor denne backtrace blev taget.
    ///
    /// Den første indgang i dette stykke er sandsynligvis funktionen `Backtrace::new`, og den sidste ramme er sandsynligvis noget om, hvordan denne tråd eller hovedfunktionen startede.
    ///
    ///
    /// # Nødvendige funktioner
    ///
    /// Denne funktion kræver, at `std`-funktionen i `backtrace` crate er aktiveret, og `std`-funktionen er aktiveret som standard.
    ///
    ///
    pub fn frames(&self) -> &[BacktraceFrame] {
        &self.frames[self.actual_start_index..]
    }

    /// Hvis denne backtrace blev oprettet fra `new_unresolved`, løser denne funktion alle adresser i backtrace til deres symbolske navne.
    ///
    ///
    /// Hvis denne backtrace tidligere er blevet løst eller blev oprettet via `new`, gør denne funktion intet.
    ///
    /// # Nødvendige funktioner
    ///
    /// Denne funktion kræver, at `std`-funktionen i `backtrace` crate er aktiveret, og `std`-funktionen er aktiveret som standard.
    ///
    ///
    pub fn resolve(&mut self) {
        for frame in self.frames.iter_mut().filter(|f| f.symbols.is_none()) {
            let mut symbols = Vec::new();
            {
                let sym = |symbol: &Symbol| {
                    symbols.push(BacktraceSymbol {
                        name: symbol.name().map(|m| m.as_bytes().to_vec()),
                        addr: symbol.addr().map(|a| a as usize),
                        filename: symbol.filename().map(|m| m.to_owned()),
                        lineno: symbol.lineno(),
                        colno: symbol.colno(),
                    });
                };
                match frame.frame {
                    Frame::Raw(ref f) => resolve_frame(f, sym),
                    Frame::Deserialized { ip, .. } => {
                        resolve(ip as *mut c_void, sym);
                    }
                }
            }
            frame.symbols = Some(symbols);
        }
    }
}

impl From<Vec<BacktraceFrame>> for Backtrace {
    fn from(frames: Vec<BacktraceFrame>) -> Self {
        Backtrace {
            frames,
            actual_start_index: 0,
        }
    }
}

impl Into<Vec<BacktraceFrame>> for Backtrace {
    fn into(self) -> Vec<BacktraceFrame> {
        self.frames
    }
}

impl BacktraceFrame {
    /// Samme som `Frame::ip`
    ///
    /// # Nødvendige funktioner
    ///
    /// Denne funktion kræver, at `std`-funktionen i `backtrace` crate er aktiveret, og `std`-funktionen er aktiveret som standard.
    ///
    pub fn ip(&self) -> *mut c_void {
        self.frame.ip() as *mut c_void
    }

    /// Samme som `Frame::symbol_address`
    ///
    /// # Nødvendige funktioner
    ///
    /// Denne funktion kræver, at `std`-funktionen i `backtrace` crate er aktiveret, og `std`-funktionen er aktiveret som standard.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.frame.symbol_address() as *mut c_void
    }

    /// Samme som `Frame::module_base_address`
    ///
    /// # Nødvendige funktioner
    ///
    /// Denne funktion kræver, at `std`-funktionen i `backtrace` crate er aktiveret, og `std`-funktionen er aktiveret som standard.
    ///
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.frame
            .module_base_address()
            .map(|addr| addr as *mut c_void)
    }

    /// Returnerer listen over symboler, som denne ramme svarer til.
    ///
    /// Normalt er der kun ét symbol pr. Ramme, men nogle gange returneres flere symboler, hvis et antal funktioner er indrettet i en ramme.
    /// Det første anførte symbol er "innermost function", hvorimod det sidste symbol er det yderste (sidste opkald).
    ///
    /// Bemærk, at hvis denne ramme kommer fra et uløst backtrace, vil dette returnere en tom liste.
    ///
    /// # Nødvendige funktioner
    ///
    /// Denne funktion kræver, at `std`-funktionen i `backtrace` crate er aktiveret, og `std`-funktionen er aktiveret som standard.
    ///
    ///
    ///
    ///
    pub fn symbols(&self) -> &[BacktraceSymbol] {
        self.symbols.as_ref().map(|s| &s[..]).unwrap_or(&[])
    }
}

impl BacktraceSymbol {
    /// Samme som `Symbol::name`
    ///
    /// # Nødvendige funktioner
    ///
    /// Denne funktion kræver, at `std`-funktionen i `backtrace` crate er aktiveret, og `std`-funktionen er aktiveret som standard.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.name.as_ref().map(|s| SymbolName::new(s))
    }

    /// Samme som `Symbol::addr`
    ///
    /// # Nødvendige funktioner
    ///
    /// Denne funktion kræver, at `std`-funktionen i `backtrace` crate er aktiveret, og `std`-funktionen er aktiveret som standard.
    ///
    pub fn addr(&self) -> Option<*mut c_void> {
        self.addr.map(|s| s as *mut c_void)
    }

    /// Samme som `Symbol::filename`
    ///
    /// # Nødvendige funktioner
    ///
    /// Denne funktion kræver, at `std`-funktionen i `backtrace` crate er aktiveret, og `std`-funktionen er aktiveret som standard.
    ///
    pub fn filename(&self) -> Option<&Path> {
        self.filename.as_ref().map(|p| &**p)
    }

    /// Samme som `Symbol::lineno`
    ///
    /// # Nødvendige funktioner
    ///
    /// Denne funktion kræver, at `std`-funktionen i `backtrace` crate er aktiveret, og `std`-funktionen er aktiveret som standard.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.lineno
    }

    /// Samme som `Symbol::colno`
    ///
    /// # Nødvendige funktioner
    ///
    /// Denne funktion kræver, at `std`-funktionen i `backtrace` crate er aktiveret, og `std`-funktionen er aktiveret som standard.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.colno
    }
}

impl fmt::Debug for Backtrace {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        let full = fmt.alternate();
        let (frames, style) = if full {
            (&self.frames[..], PrintFmt::Full)
        } else {
            (&self.frames[self.actual_start_index..], PrintFmt::Short)
        };

        // Når vi udskriver stier, prøver vi at fjerne cwd'en, hvis den findes, ellers udskriver vi bare stien som den er.
        // Bemærk, at vi også kun gør dette til det korte format, for hvis det er fuldt, vil vi formodentlig udskrive alt.
        //
        //
        let cwd = std::env::current_dir();
        let mut print_path =
            move |fmt: &mut fmt::Formatter<'_>, path: crate::BytesOrWideString<'_>| {
                let path = path.into_path_buf();
                if !full {
                    if let Ok(cwd) = &cwd {
                        if let Ok(suffix) = path.strip_prefix(cwd) {
                            return fmt::Display::fmt(&suffix.display(), fmt);
                        }
                    }
                }
                fmt::Display::fmt(&path.display(), fmt)
            };

        let mut f = BacktraceFmt::new(fmt, style, &mut print_path);
        f.add_context()?;
        for frame in frames {
            f.frame().backtrace_frame(frame)?;
        }
        f.finish()?;
        Ok(())
    }
}

impl Default for Backtrace {
    fn default() -> Backtrace {
        Backtrace::new()
    }
}

impl fmt::Debug for BacktraceFrame {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceFrame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

impl fmt::Debug for BacktraceSymbol {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("BacktraceSymbol")
            .field("name", &self.name())
            .field("addr", &self.addr())
            .field("filename", &self.filename())
            .field("lineno", &self.lineno())
            .field("colno", &self.colno())
            .finish()
    }
}

#[cfg(feature = "serialize-rustc")]
mod rustc_serialize_impls {
    use super::*;
    use rustc_serialize::{Decodable, Decoder, Encodable, Encoder};

    #[derive(RustcEncodable, RustcDecodable)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Decodable for BacktraceFrame {
        fn decode<D>(d: &mut D) -> Result<Self, D::Error>
        where
            D: Decoder,
        {
            let frame: SerializedFrame = SerializedFrame::decode(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }

    impl Encodable for BacktraceFrame {
        fn encode<E>(&self, e: &mut E) -> Result<(), E::Error>
        where
            E: Encoder,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .encode(e)
        }
    }
}

#[cfg(feature = "serde")]
mod serde_impls {
    use super::*;
    use serde::de::Deserializer;
    use serde::ser::Serializer;
    use serde::{Deserialize, Serialize};

    #[derive(Serialize, Deserialize)]
    struct SerializedFrame {
        ip: usize,
        symbol_address: usize,
        module_base_address: Option<usize>,
        symbols: Option<Vec<BacktraceSymbol>>,
    }

    impl Serialize for BacktraceFrame {
        fn serialize<S>(&self, s: S) -> Result<S::Ok, S::Error>
        where
            S: Serializer,
        {
            let BacktraceFrame { frame, symbols } = self;
            SerializedFrame {
                ip: frame.ip() as usize,
                symbol_address: frame.symbol_address() as usize,
                module_base_address: frame.module_base_address().map(|addr| addr as usize),
                symbols: symbols.clone(),
            }
            .serialize(s)
        }
    }

    impl<'a> Deserialize<'a> for BacktraceFrame {
        fn deserialize<D>(d: D) -> Result<Self, D::Error>
        where
            D: Deserializer<'a>,
        {
            let frame: SerializedFrame = SerializedFrame::deserialize(d)?;
            Ok(BacktraceFrame {
                frame: Frame::Deserialized {
                    ip: frame.ip,
                    symbol_address: frame.symbol_address,
                    module_base_address: frame.module_base_address,
                },
                symbols: frame.symbols,
            })
        }
    }
}