use core::ffi::c_void;
use core::fmt;

/// Inspicerer den aktuelle call-stack og sender alle aktive frames ind i lukningen, der er angivet for at beregne et stack-spor.
///
/// Denne funktion er arbejdshesten i dette bibliotek til beregning af staksporene for et program.Den givne lukning `cb` giver eksempler på en `Frame`, der repræsenterer information om den opkaldsramme på stakken.
/// Lukningen giver rammer på en top-down måde (senest kaldte funktioner først).
///
/// Lukningens returværdi er en indikation af, om backtrace skal fortsætte.En returværdi på `false` afslutter backtrace og vender straks tilbage.
///
/// Når en `Frame` er anskaffet, vil du sandsynligvis ringe til `backtrace::resolve` for at konvertere `ip` (instruktionsmarkøren) eller symboladressen til en `Symbol`, gennem hvilken navn og/eller filnavn/linjenummer kan læres.
///
///
/// Bemærk, at dette er en relativt lavt niveau funktion, og hvis du f.eks. Vil fange en backtrace, der skal inspiceres senere, kan `Backtrace`-typen være mere passende.
///
/// # Nødvendige funktioner
///
/// Denne funktion kræver, at `std`-funktionen i `backtrace` crate er aktiveret, og `std`-funktionen er aktiveret som standard.
///
/// # Panics
///
/// Denne funktion stræber efter aldrig panic, men hvis `cb` leverede panics, vil nogle platforme tvinge en dobbelt panic til at afbryde processen.
/// Nogle platforme bruger et C-bibliotek, der internt bruger tilbagekald, som ikke kan spoles gennem, så panik fra `cb` kan udløse en procesafbrydelse.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // fortsæt backtrace
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Samme som `trace`, kun usikkert, da det er usynkroniseret.
///
/// Denne funktion har ikke synkroniseringsgarantier, men er tilgængelig, når `std`-funktionen i denne crate ikke er kompileret i.
/// Se `trace`-funktionen for mere dokumentation og eksempler.
///
/// # Panics
///
/// Se oplysninger om `trace` for advarsler om `cb` panik.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// En trait, der repræsenterer en ramme af et backtrace, gav `trace`-funktionen af denne crate.
///
/// Sporingsfunktionens lukning giver rammer, og rammen sendes næsten, da den underliggende implementering ikke altid er kendt før kørselstid.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Returnerer den aktuelle instruktionsmarkør for denne ramme.
    ///
    /// Dette er normalt den næste instruktion, der skal udføres i rammen, men ikke alle implementeringer viser dette med 100% nøjagtighed (men det er generelt ret tæt).
    ///
    ///
    /// Det anbefales at videregive denne værdi til `backtrace::resolve` for at gøre den til et symbolnavn.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Returnerer den aktuelle stakmarkør for denne ramme.
    ///
    /// I tilfælde af at en backend ikke kan gendanne stakemarkøren til denne ramme, returneres en nulmarkør.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Returnerer startsymboladressen for rammen for denne funktion.
    ///
    /// Dette forsøger at spole tilbage den instruktionsmarkør, der returneres af `ip`, til funktionens start og returnere denne værdi.
    ///
    /// I nogle tilfælde returnerer backends imidlertid bare `ip` fra denne funktion.
    ///
    /// Den returnerede værdi kan undertiden bruges, hvis `backtrace::resolve` mislykkedes på `ip` angivet ovenfor.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Returnerer basisadressen på det modul, som rammen tilhører.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Dette skal komme først for at sikre, at Miri prioriterer værtsplatformen
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // kun brugt i dbghelp symboliserer
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}