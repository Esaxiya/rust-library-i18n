# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Et bibliotek til erhvervelse af backtraces ved kørsel for Rust.
Dette bibliotek har til formål at forbedre understøttelsen af standardbiblioteket ved at tilbyde en programmatisk grænseflade til at arbejde med, men det understøtter også simpelthen let udskrivning af den aktuelle backtrace som libstds panics.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

For simpelthen at fange et backtrace og udskyde håndteringen af det til et senere tidspunkt kan du bruge `Backtrace`-typen på øverste niveau.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Hvis du dog ønsker mere rå adgang til den faktiske sporingsfunktionalitet, kan du bruge `trace`-og `resolve`-funktionerne direkte.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Løs denne instruktionsmarkør til et symbolnavn
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // fortsæt til næste ramme
    });
}
```

# License

Dette projekt er licenseret under en af

 * Apache Licens, version 2.0, ([LICENSE-APACHE](LICENSE-APACHE) eller http://www.apache.org/licenses/LICENSE-2.0)
 * MIT-licens ([LICENSE-MIT](LICENSE-MIT) eller http://opensource.org/licenses/MIT)

efter eget valg.

### Contribution

Medmindre du udtrykkeligt angiver andet, skal ethvert bidrag, der med vilje er indsendt til inkludering i backtrace-rs, som defineret i Apache-2.0-licensen, være dobbelt licenseret som ovenfor uden yderligere vilkår eller betingelser.







