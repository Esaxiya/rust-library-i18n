#![feature(no_core)]
#![no_core]

// Se rustc-std-workspace-core for, hvorfor denne crate er nødvendig.

// Omdøb crate for at undgå konflikt med tildelingsmodulet i liballoc.
extern crate alloc as foo;

pub use foo::*;