# backtrace-rs

[Documentation](https://docs.rs/backtrace)

Raibhurari yekuwana kumashure kumashure panguva yekumhanya ye Rust.
Raibhurari iyi inovavarira kusimudzira rutsigiro rweyakajairwa raibhurari nekupa iyo programmatic interface yekushanda nayo, asi zvakare inotsigira zviri nyore kupurinda yazvino backtrace senge libstd's panics.

## Install

```toml
[dependencies]
backtrace = "0.3"
```

## Usage

Kuti ungobata backtrace uye defer uchibata nayo kusvika nguva inotevera, unogona kushandisa yepamusoro-nhanho `Backtrace` mhando.

```rust
use backtrace::Backtrace;

fn main() {
    let bt = Backtrace::new();

    // do_some_work();

    println!("{:?}", bt);
}
```

Kana, zvakadaro, iwe uchizoda imwe mbishi kuwana kune chaiyo yekutsvagisa mashandiro, unogona kushandisa iyo `trace` uye `resolve` inoshanda zvakananga.

```rust
fn main() {
    backtrace::trace(|frame| {
        let ip = frame.ip();
        let symbol_address = frame.symbol_address();

        // Sarudza ichi chinongedzo chezita kuzita rechiratidzo
        backtrace::resolve_frame(frame, |symbol| {
            if let Some(name) = symbol.name() {
                // ...
            }
            if let Some(filename) = symbol.filename() {
                // ...
            }
        });

        true // ramba uchienda kune inotevera furemu
    });
}
```

# License

Iyi purogiramu inobvumirwa pasi peimwe ye

 * Apache License, Shanduro 2.0, ([LICENSE-APACHE](LICENSE-APACHE) kana http://www.apache.org/licenses/LICENSE-2.0)
 * MIT rezinesi ([LICENSE-MIT](LICENSE-MIT) kana http://opensource.org/licenses/MIT)

pane yako sarudzo.

### Contribution

Kunze kwekunge iwe ukataura zvakajeka neimwe nzira, chero mupiro wakapihwa nemaune kuiswa mukati backtrace-rs newe, sekutsanangurwa kwazvinoitwa mu Apache-2.0 rezinesi, ichave maviri marezinesi seari pamusoro, pasina mamwe mazwi kana mamiriro.







