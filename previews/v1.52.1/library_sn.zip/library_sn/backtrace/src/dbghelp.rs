//! Module yekubatsira mukugadzirisa dbghelp zvisungo pa Windows
//!
//! Backtraces pa Windows (ingangoita yeMSVC) inonyanya kupihwa simba kuburikidza ne `dbghelp.dll` nemabasa akasiyana ayo arimo.
//! Aya mabasa parizvino akatakurwa *zvine simba* pane kubatanidza kune `dbghelp.dll` zvakaenzana.
//! Izvi parizvino zvinoitwa neyakajairwa raibhurari (uye iri mune dzidziso inodiwa ipapo), asi kuyedza kubatsira kudzikisira kutsamira dll kutsamira kweraibhurari sezvo kumashure kumashure kwakajairika kusarudzika.
//!
//! Izvo zviri kutaurwa, `dbghelp.dll` kazhinji inogara ichibudirira kutakura pa Windows.
//!
//! Ziva kunyange hazvo kuti sezvo isu tiri kurodha iyi yese rutsigiro musimba isu hatigone kunyatso shandisa tsananguro mbishi mu `winapi`, asi asi isu tinofanirwa kutsanangudza mhando dzekunongedzera pabasa isu pachedu toishandisa izvo.
//! Hatidi kunyatso kuve mubhizinesi rekunyepera winapi, saka isu tine Cargo ficha `verify-winapi` iyo inosimbisa kuti zvese zvisungo zvinowirirana izvo zviri mu winapi uye chimiro ichi chinogoneswa paCI.
//!
//! Chekupedzisira, iwe uchacherekedza pano kuti iyo dll ye `dbghelp.dll` haina kumboburitswa, uye izvozvi ndezve chinangwa.
//! Kufunga ndekwekuti isu tinogona kuichengetedza pasirese uye nekuishandisa pakati pekufonera kuAPI, tichidzivirira inodhura loads/unloads.
//! Kana iri riri dambudziko rema leak detectors kana chimwe chinhu chakadai tinogona kuyambuka zambuko kana tasvika ipapo.
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(non_snake_case)]

use super::windows::*;
use core::mem;
use core::ptr;

// Shanda uchitenderedza `SymGetOptions` uye `SymSetOptions` usipo muwinapi pachayo.
// Zvikasadaro izvi zvinongoshandiswa chete kana isu tiri vaviri-tichitarisa mhando kurwisa winapi.
//
#[cfg(feature = "verify-winapi")]
mod dbghelp {
    use crate::windows::*;
    pub use winapi::um::dbghelp::{
        StackWalk64, SymCleanup, SymFromAddrW, SymFunctionTableAccess64, SymGetLineFromAddrW64,
        SymGetModuleBase64, SymInitializeW,
    };

    extern "system" {
        // Hazvina kutsanangurwa mu winapi parizvino
        pub fn SymGetOptions() -> u32;
        pub fn SymSetOptions(_: u32);

        // Izvi zvinotsanangurwa mu winapi, asi zvisirizvo (FIXME winapi-rs#768)
        pub fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD,
        ) -> BOOL;

        // Hazvina kutsanangurwa mu winapi parizvino
        pub fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW,
        ) -> BOOL;
        pub fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64,
        ) -> BOOL;
    }

    pub fn assert_equal_types<T>(a: T, _b: T) -> T {
        a
    }
}

// Iyi macro inoshandiswa kutsanangura chimiro che `Dbghelp` icho mukati chine zvese zvinongedzo zvebasa zvatingangotakure.
//
macro_rules! dbghelp {
    (extern "system" {
        $(fn $name:ident($($arg:ident: $argty:ty),*) -> $ret: ty;)*
    }) => (
        pub struct Dbghelp {
            /// Iyo yakaremerwa DLL ye `dbghelp.dll`
            dll: HMODULE,

            // Imwe neimwe yekushandisa pointer pabasa rega rega ratinga shandisa
            $($name: usize,)*
        }

        static mut DBGHELP: Dbghelp = Dbghelp {
            // Pakutanga hatina kutakura iyo DLL
            dll: 0 as *mut _,
            // Kutanga mabasa ese akaiswa kune zero kuti vataure kuti inofanirwa kutakuriswa zvine simba.
            //
            $($name: 0,)*
        };

        // Yakareruka typedef kune yega yega basa mhando.
        $(pub type $name = unsafe extern "system" fn($($argty),*) -> $ret;)*

        impl Dbghelp {
            /// Kuedza kuvhura `dbghelp.dll`.
            /// Inodzorera kubudirira kana ikashanda kana kukanganisa kana `LoadLibraryW` ikatadza.
            ///
            /// Panics kana raibhurari yatotakurwa.
            fn ensure_open(&mut self) -> Result<(), ()> {
                if !self.dll.is_null() {
                    return Ok(())
                }
                let lib = b"dbghelp.dll\0";
                unsafe {
                    self.dll = LoadLibraryA(lib.as_ptr() as *const i8);
                    if self.dll.is_null() {
                        Err(())
                    }  else {
                        Ok(())
                    }
                }
            }

            // Basa renzira imwe neimwe yatinoda kushandisa.
            // Kana ichidaidzwa inogona kuverenga iyo yakachengetwa basa pointer kana kurodha pasi uye kudzosa iro rakatakurwa kukosha.
            // Mitoro inosimbiswa kuti ibudirire.
            $(pub fn $name(&mut self) -> Option<$name> {
                unsafe {
                    if self.$name == 0 {
                        let name = concat!(stringify!($name), "\0");
                        self.$name = self.symbol(name.as_bytes())?;
                    }
                    let ret = mem::transmute::<usize, $name>(self.$name);
                    #[cfg(feature = "verify-winapi")]
                    dbghelp::assert_equal_types(ret, dbghelp::$name);
                    Some(ret)
                }
            })*

            fn symbol(&self, symbol: &[u8]) -> Option<usize> {
                unsafe {
                    match GetProcAddress(self.dll, symbol.as_ptr() as *const _) as usize {
                        0 => None,
                        n => Some(n),
                    }
                }
            }
        }

        // Nyore proxy yekushandisa yekuchenesa makiyi kunongedzera dbghelp mabasa.
        //
        #[allow(dead_code)]
        impl Init {
            $(pub fn $name(&self) -> $name {
                unsafe {
                    DBGHELP.$name().unwrap()
                }
            })*

            pub fn dbghelp(&self) -> *mut Dbghelp {
                unsafe {
                    &mut DBGHELP
                }
            }
        }
    )

}

const SYMOPT_DEFERRED_LOADS: DWORD = 0x00000004;

dbghelp! {
    extern "system" {
        fn SymGetOptions() -> DWORD;
        fn SymSetOptions(options: DWORD) -> ();
        fn SymInitializeW(
            handle: HANDLE,
            path: PCWSTR,
            invade: BOOL
        ) -> BOOL;
        fn SymCleanup(handle: HANDLE) -> BOOL;
        fn StackWalk64(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME64,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64
        ) -> BOOL;
        fn SymFunctionTableAccess64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> PVOID;
        fn SymGetModuleBase64(
            hProcess: HANDLE,
            AddrBase: DWORD64
        ) -> DWORD64;
        fn SymFromAddrW(
            hProcess: HANDLE,
            Address: DWORD64,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromAddrW64(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
        fn StackWalkEx(
            MachineType: DWORD,
            hProcess: HANDLE,
            hThread: HANDLE,
            StackFrame: LPSTACKFRAME_EX,
            ContextRecord: PVOID,
            ReadMemoryRoutine: PREAD_PROCESS_MEMORY_ROUTINE64,
            FunctionTableAccessRoutine: PFUNCTION_TABLE_ACCESS_ROUTINE64,
            GetModuleBaseRoutine: PGET_MODULE_BASE_ROUTINE64,
            TranslateAddress: PTRANSLATE_ADDRESS_ROUTINE64,
            Flags: DWORD
        ) -> BOOL;
        fn SymFromInlineContextW(
            hProcess: HANDLE,
            Address: DWORD64,
            InlineContext: ULONG,
            Displacement: PDWORD64,
            Symbol: PSYMBOL_INFOW
        ) -> BOOL;
        fn SymGetLineFromInlineContextW(
            hProcess: HANDLE,
            dwAddr: DWORD64,
            InlineContext: ULONG,
            qwModuleBaseAddress: DWORD64,
            pdwDisplacement: PDWORD,
            Line: PIMAGEHLP_LINEW64
        ) -> BOOL;
    }
}

pub struct Init {
    lock: HANDLE,
}

/// Kutanga rutsigiro rwese rwakakosha kuti uwane `dbghelp` API mabasa kubva kune iyi crate.
///
///
/// Ziva kuti basa iri **rakachengeteka**, iro remukati rine yayo yekuenderana.
/// Ziva zvakare kuti zvakachengeteka kudaidza iri basa kakawanda kakawanda richidzokorora.
///
pub fn init() -> Result<Init, ()> {
    use core::sync::atomic::{AtomicUsize, Ordering::SeqCst};

    unsafe {
        // Chekutanga chinhu chatinofanira kuita kuwiriranisa iri basa.Izvi zvinogona kudaidzwa panguva imwe chete kubva kune dzimwe shinda kana kudzokorora mukati meimwe tambo.
        // Ziva kuti zvakanyanyisa kupfuura izvo asi nekuti izvo zvatiri kushandisa pano, `dbghelp`,*zvakare* inoda kuwiriraniswa nevamwe vese vanofona ku `dbghelp` mune ino maitiro.
        //
        // Kazhinji hapana kunyatso kufona ku `dbghelp` mukati meichi chiitiko uye isu tinogona kufunga zvakachengeteka kuti ndisu chete tiri kuchiwana.
        // Iko kune, zvakadaro, mumwe wekutanga mumwe mushandisi isu tinofanirwa kunetseka kuti ndezvipi zvisinganzwisisike pachedu, asi mune yakajairwa raibhurari.
        // Iyo Rust yakajairwa raibhurari inoenderana neiyi crate yekutsigira backtrace rutsigiro, uye iyi crate iripowo pa crates.io.
        // Izvi zvinoreva kuti kana raibhurari yakajairwa iri kudhinda backtrace ye panic inogona kumhanya neiyi crate ichibva ku crates.io, ichikonzera kusarongeka.
        //
        // Kubatsira kugadzirisa iri dambudziko rekuwiriranisa isu tinoshandisa Windows-yakatarwa hunyengeri apa (iri, shure kwezvose, Windows-yakatarwa kurambidzwa nezve kuwiriranisa).
        // Isu tinogadzira *chikamu-chemuno* chinonzi mutex kuchengetedza iyi foni.
        // Chinangwa apa ndechekuti raibhurari yakajairwa uye iyi crate haifanire kugovana Rust-level APIs kuti ienderane pano asi inogona kushanda kuseri kwezviitiko kuti ive nechokwadi chekuti vari kuwiririrana.
        //
        // Nenzira iyoyo kana basa iri rodaidzwa kuburikidza neyakajairwa raibhurari kana kuburikidza ne crates.io tinogona kuva nechokwadi chekuti iyo imwechete mutex iri kuwanikwa.
        //
        // Saka zvese izvi ndezvekuti chinhu chekutanga chatinoita apa isu patomiki tinogadzira `HANDLE` inova inonzi mutex pa Windows.
        // Isu tinowirirana zvishoma nedzimwe tambo kugovana iri basa zvakanyatso uye kuona kuti mubato mumwe chete unogadzirwa semuenzaniso wechiitiko ichi.
        // Ziva kuti mubato hauna kumbobvira wavharwa kana wangochengetwa mupasi rose.
        //
        // Mushure mekunge isu taenda chaizvo kukiya isu tinongoiwana, uye yedu `Init` mubato watinotambidza kunze inozove nebasa rekuirasa pakupedzisira.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        //
        static LOCK: AtomicUsize = AtomicUsize::new(0);
        let mut lock = LOCK.load(SeqCst);
        if lock == 0 {
            lock = CreateMutexA(
                ptr::null_mut(),
                0,
                "Local\\RustBacktraceMutex\0".as_ptr() as _,
            ) as usize;
            if lock == 0 {
                return Err(());
            }
            if let Err(other) = LOCK.compare_exchange(0, lock, SeqCst, SeqCst) {
                debug_assert!(other != 0);
                CloseHandle(lock as HANDLE);
                lock = other;
            }
        }
        debug_assert!(lock != 0);
        let lock = lock as HANDLE;
        let r = WaitForSingleObjectEx(lock, INFINITE, FALSE);
        debug_assert_eq!(r, 0);
        let ret = Init { lock };

        // Ok, phew!Iye zvino zvatiri tese takaenderana, ngatitangei kugadzirisa zvese.
        // Kutanga kumusoro tinofanirwa kuona kuti `dbghelp.dll` iri kutakurwa mune ino maitiro.
        // Isu tinoita izvi nesimba kuti tidzivise kutsamira kwakadzikama.
        // Izvi zvakaitwa kare kuti zvishande zvakatenderedza nyaya dzekubatanidza uye inoitirwa kuti mabhinari anyatso kutakurika nekuti izvi zvinongova zvekugadzirisa zvinokanganisa.
        //
        //
        // Kana tangovhura `dbghelp.dll` tinoda kudaidza mamwe mabasa ekutanga mairi, uye izvi zvakadzama pazasi.
        // Isu tinongoita izvi kamwe chete, zvakadaro, saka isu tine yepasi rose boolean inoratidza kuti tapedza here kana kwete.
        //
        //
        //
        //
        DBGHELP.ensure_open()?;

        static mut INITIALIZED: bool = false;
        if INITIALIZED {
            return Ok(ret);
        }

        let orig = DBGHELP.SymGetOptions().unwrap()();

        // Ive shuwa kuti iyo `SYMOPT_DEFERRED_LOADS` mureza yakaiswa, nekuti zvinoenderana nemaMSVC's chaiwo maodhi nezve izvi: "This is the fastest, most efficient way to use the symbol handler.", saka ngatiitei izvozvo!
        //
        //
        DBGHELP.SymSetOptions().unwrap()(orig | SYMOPT_DEFERRED_LOADS);

        // Chaizvoizvo tanga zviratidzo neMSVC.Ziva kuti izvi zvinogona kutadza, asi isu tinozvisiya.
        // Iko hakuna toni yehunyanzvi hwepamberi peichi chimwe nechimwe, asi LLVM mukati inoita kunge isingafarire kukosha kwekudzoka pano uye imwe yemaraibhurari esanitizer muLLVM inodhindisa yambiro inotyisa kana izvi zvikatadza asi zvichingozvisiya mukufamba kwenguva.
        //
        //
        // Imwe kesi izvi zvinouya zvakanyanya ku Rust ndeyekuti raibhurari yakajairwa uye iyi crate pa crates.io vese vari vaviri vanoda kukwikwidza `SymInitializeW`.
        // Raibhurari yakajairwa kare yaida kutanga yobva yachenesa nguva zhinji, asi ikozvino zvairi kushandisa iyi crate zvinoreva kuti mumwe munhu achatanga kutanga uye imwe ichatora iko kutanga.
        //
        //
        //
        //
        //
        //
        DBGHELP.SymInitializeW().unwrap()(GetCurrentProcess(), ptr::null_mut(), TRUE);
        INITIALIZED = true;
        Ok(ret)
    }
}

impl Drop for Init {
    fn drop(&mut self) {
        unsafe {
            let r = ReleaseMutex(self.lock);
            debug_assert!(r != 0);
        }
    }
}