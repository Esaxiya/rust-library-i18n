//! Yekufananidzira zano uchishandisa iyo DWARF-parsing kodhi mu libbacktrace.
//!
//! Iyo libbacktrace C raibhurari, inowanzo kugoverwa ne gcc, inotsigira kwete chete kugadzira backtrace (iyo yatisinganyatso kushandisa) asi zvakare inomiririra iyo yekumashure uye kubata diki dhigi ruzivo pamusoro pezvinhu zvakaita kunge akaiswa mafuremu uye chii.
//!
//!
//! Izvi zvakaomarara nekuda kwekuwanda kwekunetseka kwakasiyana apa, asi zano rekutanga nderekuti:
//!
//! * Kutanga tinodaidza `backtrace_syminfo`.Izvi zvinowana ruzivo rwechiratidzo kubva patafura yechiratidzo ine simba kana tichigona.
//! * Tevere isu tinodaidza `backtrace_pcinfo`.Izvi zvicharatidza debuginfo matafura kana aripo uye anotibvumidza kuti titorezve ruzivo nezve inline mafuremu, mazita emafaira, mitsara nhamba, nezvimwe.
//!
//! Kune hunyengeri hwakawanda nezve kutora matafura epadiki mu libbacktrace, asi ndinovimba haazi magumo epasi uye akajeka zvakakwana kana uchiverenga pazasi.
//!
//! Iyi ndiyo yakasarudzika yekufananidzira zano kune asiri-MSVC uye asiri-OSX mapuratifomu.Mune libstd kunyangwe iyi iri yega sarudzo yeOSX.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![allow(bad_style)]

extern crate backtrace_sys as bt;

use core::{marker, ptr, slice};
use libc::{self, c_char, c_int, c_void, uintptr_t};

use crate::symbolize::{ResolveWhat, SymbolName};
use crate::types::BytesOrWideString;

pub enum Symbol<'a> {
    Syminfo {
        pc: uintptr_t,
        symname: *const c_char,
        _marker: marker::PhantomData<&'a ()>,
    },
    Pcinfo {
        pc: uintptr_t,
        filename: *const c_char,
        lineno: c_int,
        function: *const c_char,
        symname: *const c_char,
    },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        let symbol = |ptr: *const c_char| unsafe {
            if ptr.is_null() {
                None
            } else {
                let len = libc::strlen(ptr);
                Some(SymbolName::new(slice::from_raw_parts(
                    ptr as *const u8,
                    len,
                )))
            }
        };
        match *self {
            Symbol::Syminfo { symname, .. } => symbol(symname),
            Symbol::Pcinfo {
                function, symname, ..
            } => {
                // Kana zvichikwanisika sarudza zita re `function` iro rinobva ku debuginfo uye rinogona kazhinji kuve rakaringana kune emitsetse mafuremu semuenzaniso.
                // Kana izvo zvisipo kunyange uchidzokera kuzita retafura yezita rakatsanangurwa mu `symname`.
                //
                // Ziva kuti dzimwe nguva `function` inogona kunzwa isinganyatsoita mushe, semuenzaniso kunyorwa se `try<i32,closure>` isntead ye `std::panicking::try::do_call`.
                //
                // Hazvinyatso kujekesa kuti sei, asi zvakazara zita re `function` rinoratidzika kunge rakarurama.
                //
                //
                //
                if let Some(sym) = symbol(function) {
                    return Some(sym);
                }
                symbol(symname)
            }
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        let pc = match *self {
            Symbol::Syminfo { pc, .. } => pc,
            Symbol::Pcinfo { pc, .. } => pc,
        };
        if pc == 0 {
            None
        } else {
            Some(pc as *mut _)
        }
    }

    fn filename_bytes(&self) -> Option<&[u8]> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { filename, .. } => {
                let ptr = filename as *const u8;
                if ptr.is_null() {
                    return None;
                }
                unsafe {
                    let len = libc::strlen(filename);
                    Some(slice::from_raw_parts(ptr, len))
                }
            }
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.filename_bytes().map(BytesOrWideString::Bytes)
    }

    #[cfg(feature = "std")]
    pub fn filename(&self) -> Option<&::std::path::Path> {
        use std::path::Path;

        #[cfg(unix)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::ffi::OsStr;
            use std::os::unix::prelude::*;
            Some(Path::new(OsStr::from_bytes(bytes)))
        }

        #[cfg(windows)]
        fn bytes2path(bytes: &[u8]) -> Option<&Path> {
            use std::str;
            str::from_utf8(bytes).ok().map(Path::new)
        }

        self.filename_bytes().and_then(bytes2path)
    }

    pub fn lineno(&self) -> Option<u32> {
        match *self {
            Symbol::Syminfo { .. } => None,
            Symbol::Pcinfo { lineno, .. } => Some(lineno as u32),
        }
    }

    pub fn colno(&self) -> Option<u32> {
        None
    }
}

extern "C" fn error_cb(_data: *mut c_void, _msg: *const c_char, _errnum: c_int) {
    // usaite chero chinhu ikozvino
}

/// Rudzi rwe `data` pointer rwakapfuura mu `syminfo_cb`
struct SyminfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    pc: usize,
}

extern "C" fn syminfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    symname: *const c_char,
    _symval: uintptr_t,
    _symsize: uintptr_t,
) {
    let mut bomb = crate::Bomb { enabled: true };

    // Kana kiyi yekufona ikakumbirwa kubva ku `backtrace_syminfo` patinotanga kugadzirisa tinopfuurira kunodaidza `backtrace_pcinfo`.
    // Basa re `backtrace_pcinfo` rinobvunzurudza ruzivo rwekugadzirisa uye kuedza kuita zvinhu zvakadai sekudzorera file/line ruzivo pamwe chete nemapuranga akaiswa.
    // Ziva kunyange hazvo iyo `backtrace_pcinfo` inogona kutadza kana kusaita zvakawanda kana pasina info yekukanganisa, saka kana izvozvo zvikaitika isu tine chokwadi chekufona iyo yekudzosa nekamwe chiratidzo kubva ku `syminfo_cb`.
    //
    //
    //
    //
    unsafe {
        let syminfo_state = &mut *(data as *mut SyminfoState<'_>);
        let mut pcinfo_state = PcinfoState {
            symname,
            called: false,
            cb: syminfo_state.cb,
        };
        bt::backtrace_pcinfo(
            init_state(),
            syminfo_state.pc as uintptr_t,
            pcinfo_cb,
            error_cb,
            &mut pcinfo_state as *mut _ as *mut _,
        );
        if !pcinfo_state.called {
            (pcinfo_state.cb)(&super::Symbol {
                inner: Symbol::Syminfo {
                    pc: pc,
                    symname: symname,
                    _marker: marker::PhantomData,
                },
            });
        }
    }

    bomb.enabled = false;
}

/// Rudzi rwe `data` pointer rwakapfuura mu `pcinfo_cb`
struct PcinfoState<'a> {
    cb: &'a mut (dyn FnMut(&super::Symbol) + 'a),
    symname: *const c_char,
    called: bool,
}

extern "C" fn pcinfo_cb(
    data: *mut c_void,
    pc: uintptr_t,
    filename: *const c_char,
    lineno: c_int,
    function: *const c_char,
) -> c_int {
    let mut bomb = crate::Bomb { enabled: true };

    unsafe {
        let state = &mut *(data as *mut PcinfoState<'_>);
        state.called = true;
        (state.cb)(&super::Symbol {
            inner: Symbol::Pcinfo {
                pc: pc,
                filename: filename,
                lineno: lineno,
                symname: state.symname,
                function,
            },
        });
    }

    bomb.enabled = false;
    return 0;
}

// Iyo libbacktrace API inotsigira kugadzira nyika, asi haitsigire kuparadza nyika.
// Ini pachangu ndinotora izvi kureva kuti nyika inofanirwa kugadzirwa ndobva ndararama nekusingaperi.
//
// Ndingafarire kunyoresa at_exit() inobata iyo inoshambidza nyika ino, asi libbacktrace haipe nzira yekuzviita.
//
// Nezvipingamupinyi izvi, iri basa rine mamiriro akachengetedzwa mamiriro ayo anoverengerwa kekutanga nguva iyi painokumbirwa.
//
// Rangarira kuti kudzosera kumashure zvese kunoitika zvakateerana (imwe yepasi rose kukiya).
//
// Cherekedza kushomeka kwekuenderana apa kunoenderana nechinodiwa chekuti `resolve` iwiriraniswe kunze.
//
//
//
unsafe fn init_state() -> *mut bt::backtrace_state {
    static mut STATE: *mut bt::backtrace_state = 0 as *mut _;

    if !STATE.is_null() {
        return STATE;
    }

    STATE = bt::backtrace_create_state(
        load_filename(),
        // Usashandise threadsafe kugona kwe libbacktrace sezvo isu tichigara tichiidaidza nenzira inoenderana.
        //
        0,
        error_cb,
        ptr::null_mut(), // hapana imwe data
    );

    return STATE;

    // Ziva kuti kuitira libbacktrace kuti ishande pane zvese inoda kutsvaga iyo DWARF yekukanganisa info yezvazvino inogoneka.Inowanzoita izvozvo kuburikidza nenzira dzinoverengeka dzinosanganisira, asi isina kuganhurirwa kune:
    //
    // * /proc/self/exe pamapuratifomu akatsigirwa
    // * Iro zita rezita rakapfuura zvakajeka kana ichigadzira nyika
    //
    // Iyo libbacktrace raibhurari idhi rakakura reC kodhi.Izvi zvinowanzoreva kuti ine ndangariro kuchengetedzeka kusagadzikana, kunyanya kana uchibata malformed debuginfo.
    // Libstd yakamhanyira mune yakawanda yeaya nhoroondo.
    //
    // Kana /proc/self/exe ikashandiswa saka isu tinogona kazhinji kushaya hanya izvi sezvo isu tichifungidzira kuti libbacktrace ndeye "mostly correct" uye neimwe nzira haiite zvinhu zvisinganzwisisike ne "attempted to be correct" dwarf debug info.
    //
    //
    // Kana tikapfuura muzita rezita, zvisinei, ipapo zvinokwanisika kune mamwe mapuratifomu (senge BSDs) apo mutambi ane huipi anogona kukonzera faira rekumanikidza kuiswa panzvimbo iyoyo.
    // Izvi zvinoreva kuti kana isu tichiudza libbacktrace nezve zita rezita rinogona kunge riri kushandisa irinomiraira faira, pamwe zvichikonzera kusarongeka.
    // Kana isu tikasaudza libbacktrace chero chinhu kunyangwe zvakadaro hazvizoite chero chinhu pamapuratifomu asingatsigire nzira senge /proc/self/exe!
    //
    // Tichifunga zvese izvo zvatinoedza zvakaoma sezvinobvira kuti *kwete* kupfuura muzita refaira, asi isu tinofanirwa pamapuratifomu asingatsigire /proc/self/exe zvachose.
    //
    //
    //
    //
    //
    //
    //
    //
    cfg_if::cfg_if! {
        if #[cfg(any(target_os = "macos", target_os = "ios"))] {
            // Ziva kuti zvine musoro tinoshandisa `std::env::current_exe`, asi isu hatigone `std` pano.
            //
            // Shandisa `_NSGetExecutablePath` kurodha yazvino nzira inoitwa munzvimbo yakaoma (iyo kana iri diki ingoregedza).
            //
            //
            // Ziva kuti isu tiri kunyatsovimba libbacktrace pano kuti isafe pane yakashata inoitwa, asi zvinodaro ...
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                const N: usize = 256;
                static mut BUF: [u8; N] = [0; N];
                extern {
                    fn _NSGetExecutablePath(
                        buf: *mut libc::c_char,
                        bufsize: *mut u32,
                    ) -> libc::c_int;
                }
                let mut sz: u32 = BUF.len() as u32;
                let ptr = BUF.as_mut_ptr() as *mut libc::c_char;
                if _NSGetExecutablePath(ptr, &mut sz) == 0 {
                    ptr
                } else {
                    ptr::null()
                }
            }
        } else if #[cfg(windows)] {
            use crate::windows::*;

            // Windows ine nzira yekuvhura mafaera uko mushure mekuvhurwa kwayo haigone kudzimwa.
            // Izvo zvirizvo zvatinoda pano nekuti isu tinoda kuona kuti yedu inogoneka haisi kuchinja kubva pasi pedu mushure mekunge tamboiisa ku libbacktrace, netariro kudzikisira kugona kupfuudza mukumanikidza dhata mu libbacktrace (iyo inogona kusabatwa zvisirizvo).
            //
            //
            // Tichifunga kuti tinoita zvishoma zvekutamba pano kuyedza kutora mhando yekiyi pane yedu pachedu mufananidzo:
            //
            // * Tora mubato kune yazvino maitiro, kurodha iro zita rezita.
            // * Vhura faira kune iro zita rezita nemireza chaiyo.
            // * Dzokororazve iyo yazvino maitiro faira rezita, kuve nechokwadi kuti rakafanana
            //
            // Kana izvo zvese zvikapfuura isu murondedzero tanyatso kuvhura yedu nzira faira uye isu takavimbiswa kuti hazvizoshanduke.FWIW boka reizvi rinoteedzerwa kubva ku libstd nhoroondo, saka uku ndiko kududzira kwangu kwakanyanya kwezvaiitika.
            //
            //
            //
            //
            //
            //
            //
            unsafe fn load_filename() -> *const libc::c_char {
                load_filename_opt().unwrap_or(ptr::null())
            }

            unsafe fn load_filename_opt() -> Result<*const libc::c_char, ()> {
                const N: usize = 256;
                // Izvi zvinogara mukumira kuyeuka kuti tikwanise kuzvidzorera ..
                static mut BUF: [i8; N] = [0; N];
                // ... uye izvi zvinogara padura sezvo zviri zvenguva pfupi
                let mut stack_buf = [0; N];
                let name1 = query_full_name(&mut BUF)?;

                let handle = CreateFileA(
                    name1.as_ptr(),
                    GENERIC_READ,
                    FILE_SHARE_READ | FILE_SHARE_WRITE,
                    ptr::null_mut(),
                    OPEN_EXISTING,
                    0,
                    ptr::null_mut(),
                );
                if handle.is_null() {
                    return Err(());
                }

                let name2 = query_full_name(&mut stack_buf)?;
                if name1 != name2 {
                    CloseHandle(handle);
                    return Err(())
                }
                // nemaune kuburitsa `handle` apa nekuti kuva neiyo yakavhurwa kunofanirwa kuchengetedza kukiya kwedu pazita refaira iri.
                //
                Ok(name1.as_ptr())
            }

            unsafe fn query_full_name(buf: &mut [i8]) -> Result<&[i8], ()> {
                let dll = GetModuleHandleA(b"kernel32.dll\0".as_ptr() as *const i8);
                if dll.is_null() {
                    return Err(())
                }
                let ptrQueryFullProcessImageNameA =
                    GetProcAddress(dll, b"QueryFullProcessImageNameA\0".as_ptr() as *const _) as usize;
                if ptrQueryFullProcessImageNameA == 0
                {
                    return Err(());
                }
                use core::mem;
                let p1 = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, GetCurrentProcessId());
                let mut len = buf.len() as u32;
                let pfnQueryFullProcessImageNameA : extern "system" fn(
                    hProcess: HANDLE,
                    dwFlags: DWORD,
                    lpExeName: LPSTR,
                    lpdwSize: PDWORD,
                ) -> BOOL = mem::transmute(ptrQueryFullProcessImageNameA);

                let rc = pfnQueryFullProcessImageNameA(p1, 0, buf.as_mut_ptr(), &mut len);
                CloseHandle(p1);

                // Tinoda kudzorera chidimbu chakagumiswa, saka kana zvese zvikazadzwa mukati uye zvakaenzana nehurefu hwese zvino zvifanane nekutadza.
                //
                //
                // Zvikasadaro kana uchidzoka kubudirira ita shuwa kuti nul byte inosanganisirwa muchidimbu.
                //
                //
                if rc == 0 || len == buf.len() as u32 {
                    Err(())
                } else {
                    assert_eq!(buf[len as usize], 0);
                    Ok(&buf[..(len + 1) as usize])
                }
            }
        } else if #[cfg(target_os = "vxworks")] {
            unsafe fn load_filename() -> *const libc::c_char {
                use libc;
                use core::mem;

                const N: usize = libc::VX_RTP_NAME_LENGTH as usize + 1;
                static mut BUF: [libc::c_char; N] = [0; N];

                let mut rtp_desc : libc::RTP_DESC = mem::zeroed();
                if (libc::rtpInfoGet(0, &mut rtp_desc as *mut libc::RTP_DESC) == 0) {
                    BUF.copy_from_slice(&rtp_desc.pathName);
                    BUF.as_ptr()
                } else {
                    ptr::null()
                }
            }
        } else {
            unsafe fn load_filename() -> *const libc::c_char {
                ptr::null()
            }
        }
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let symaddr = what.address_or_ip() as usize;

    // backtrace zvikanganiso parizvino zvakatsvairwa pasi peteki
    let state = init_state();
    if state.is_null() {
        return;
    }

    // Fonera iyo `backtrace_syminfo` API iyo (kubva pakuverenga kodhi) inofanira kufonera `syminfo_cb` chaizvo kamwe (kana kutadza nekanganiso zvimwe).
    // Isu tobva tabata zvakawanda mukati me `syminfo_cb`.
    //
    // Ziva kuti tinoita izvi sezvo `syminfo` ichatarisa tafura yechiratidzo, kutsvaga mazita ezviratidzo kunyangwe kana pasina ruzivo rwekutsvagisa mubhanari.
    //
    //
    let mut syminfo_state = SyminfoState { pc: symaddr, cb };
    bt::backtrace_syminfo(
        state,
        symaddr as uintptr_t,
        syminfo_cb,
        error_cb,
        &mut syminfo_state as *mut _ as *mut _,
    );
}

pub unsafe fn clear_symbol_cache() {}