// inoshandiswa chete pa Linux izvozvi, saka rega kodhi yakafa kumwe kunhu
#![cfg_attr(not(target_os = "linux"), allow(dead_code))]

use alloc::vec;
use alloc::vec::Vec;
use core::cell::UnsafeCell;

/// Iyo yakapusa nhandare inogovera ye byte buffers.
pub struct Stash {
    buffers: UnsafeCell<Vec<Vec<u8>>>,
}

impl Stash {
    pub fn new() -> Stash {
        Stash {
            buffers: UnsafeCell::new(Vec::new()),
        }
    }

    /// Inopa buffer yehukuru hwakatsanangurwa uye inodzosera inogona kuchinjika kwariri.
    ///
    pub fn allocate(&self, size: usize) -> &mut [u8] {
        // KUCHENGETEKA: iri ndiro chete basa rinombogadzira chinoshanduka
        // kureva `self.buffers`.
        let buffers = unsafe { &mut *self.buffers.get() };
        let i = buffers.len();
        buffers.push(vec![0; size]);
        // Kachengeteka: hatimbobvisa zvinhu kubva ku `self.buffers`, saka chirevo
        // kune iyo data mukati mechero buffer ichagara sekureba sezvinoita `self`.
        &mut buffers[i]
    }
}