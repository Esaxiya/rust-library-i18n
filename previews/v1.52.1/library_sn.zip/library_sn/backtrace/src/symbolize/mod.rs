use core::{fmt, str};

cfg_if::cfg_if! {
    if #[cfg(feature = "std")] {
        use std::path::Path;
        use std::prelude::v1::*;
    }
}

use super::backtrace::Frame;
use super::types::BytesOrWideString;
use core::ffi::c_void;
use rustc_demangle::{try_demangle, Demangle};

/// Gadzirisa kero kune chiratidzo, uchipfuudza iyo chiratidzo kune yakavharwa.
///
/// Iri basa rinotarisa kumusoro kero yakapihwa munzvimbo dzakaita setafura yemuno chiratidzo, tafura ine simba chiratidzo, kana DWARF dhigi info (zvinoenderana neyakaitwa kuitiswa) kutsvaga zviratidzo zvekupa.
///
///
/// Kuvhara kwacho kunogona kusadaidzwa kana resolution ikatadza kuitwa, uye zvakare inogona kudaidzwa kanopfuura kamwe mune zviitiko zvakamisikidzwa.
///
/// Zviratidzo zvakaburitswa zvinomirira kuuraya pane yakatsanangurwa `addr`, ichidzosa file/line mapaundi ekero iyoyo (kana iripo).
///
/// Ziva kuti kana uine `Frame` saka zvinokurudzirwa kushandisa iyo `resolve_frame` basa panzvimbo yeiyi.
///
/// # Zvinodiwa maficha
///
/// Iri basa rinoda kuti `std` chimiro che `backtrace` crate chigoneswe, uye iyo `std` ficha inogoneswa nekutadza.
///
/// # Panics
///
/// Iri basa rinovavarira kusamboita panic, asi kana iyo `cb` yakapa panics ipapo mamwe mapuratifomu anomanikidza panic yakapetwa kuti ibvise maitiro.
/// Mamwe mapuratifomu anoshandisa raibhurari yeC iyo mukati inoshandisa macallbacks ayo asingakwanise kuvhurika kuburikidza, saka kuvhunduka kubva ku `cb` kunogona kukonzera maitiro kubvisa.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         let ip = frame.ip();
///
///         backtrace::resolve(ip, |symbol| {
///             // ...
///         });
///
///         false // tarisa chete pafuremu yepamusoro
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve<F: FnMut(&Symbol)>(addr: *mut c_void, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_unsynchronized(addr, cb) }
}

/// Gadzirisa yakambotorwa furemu kune chiratidzo, uchipfuudza iyo chiratidzo kune iyo yakatarwa kuvhara.
///
/// Iyi functin inoita basa rakafanana ne `resolve` kunze kwekuti inotora `Frame` sekupokana panzvimbo yekero.
/// Izvi zvinogona kubvumidza kumwe kuitisa kwepuratifomu yekumisikidza kumashure kuti ipe yakajeka ruzivo rwechiratidzo kana ruzivo nezve ari mukati memafuremu semuenzaniso.
///
/// Zvinokurudzirwa kushandisa izvi kana uchikwanisa.
///
/// # Zvinodiwa maficha
///
/// Iri basa rinoda kuti `std` chimiro che `backtrace` crate chigoneswe, uye iyo `std` ficha inogoneswa nekutadza.
///
/// # Panics
///
/// Iri basa rinovavarira kusamboita panic, asi kana iyo `cb` yakapa panics ipapo mamwe mapuratifomu anomanikidza panic yakapetwa kuti ibvise maitiro.
/// Mamwe mapuratifomu anoshandisa raibhurari yeC iyo mukati inoshandisa macallbacks ayo asingakwanise kuvhurika kuburikidza, saka kuvhunduka kubva ku `cb` kunogona kukonzera maitiro kubvisa.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         backtrace::resolve_frame(frame, |symbol| {
///             // ...
///         });
///
///         false // tarisa chete pafuremu yepamusoro
///     });
/// }
/// ```
///
///
///
///
///
#[cfg(feature = "std")]
pub fn resolve_frame<F: FnMut(&Symbol)>(frame: &Frame, cb: F) {
    let _guard = crate::lock::lock();
    unsafe { resolve_frame_unsynchronized(frame, cb) }
}

pub enum ResolveWhat<'a> {
    Address(*mut c_void),
    Frame(&'a Frame),
}

impl<'a> ResolveWhat<'a> {
    #[allow(dead_code)]
    fn address_or_ip(&self) -> *mut c_void {
        match self {
            ResolveWhat::Address(a) => adjust_ip(*a),
            ResolveWhat::Frame(f) => adjust_ip(f.ip()),
        }
    }
}

// IP values kubva kumatanda emafuremu anowanzo ari (always?) iwo kuraira *mushure me* kufona ndiyo chaiyo stack trace.
// Kufananidza izvi pane kunokonzeresa kuti nhamba ye filename/line ive imwe kumberi uye pamwe ive void kana yave pedyo nekuguma kwebasa.
//
// Izvi zvinoita kunge zvinogara zvichingoitika pane ese mapuratifomu, saka tinogara tichitora imwe kubva kugadziriswa ip kuti igadzirise kune yapfuura yekuraira kuraira panzvimbo pekurairwa kunodzoserwa.
//
//
// Sezvineiwo isu hatingazviite izvi.
// Sezvineiwo isu tingangoda vanoshevedza ma `resolve` APIs pano kuti zviitwe nemaoko -1 uye account kuti ivo vanoda ruzivo rwekugara kune *yapfuura* kuraira, kwete izvozvi.
// Sezvineiwo isu taizofumurawo pa `Frame` kana tiri zvechokwadi kero yemirairo inotevera kana yazvino.
//
// Izvozvi kunyangwe ichi chiri chakanakisa niche kunetsekana saka isu mukati medu nguva dzose tinobvisa imwe.
// Vatengi vanofanirwa kuramba vachishanda uye vachiwana mibairo yakanaka, saka isu tinofanirwa kukwana zvakakwana.
//
//
//
//
//
//
fn adjust_ip(a: *mut c_void) -> *mut c_void {
    if a.is_null() {
        a
    } else {
        (a as usize - 1) as *mut c_void
    }
}

/// Zvakafanana ne `resolve`, chete haina kuchengeteka sezvo isina kuenderana.
///
/// Iri basa harina maconconization guarentee asi rinowanikwa kana `std` chimiro cheiyi crate isina kunyorwa mukati.
/// Ona iro `resolve` basa kune mamwe magwaro uye mienzaniso.
///
/// # Panics
///
/// Ona ruzivo pane `resolve` yemapako pa `cb` kuvhunduka.
///
pub unsafe fn resolve_unsynchronized<F>(addr: *mut c_void, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Address(addr), &mut cb)
}

/// Zvakafanana ne `resolve_frame`, chete haina kuchengeteka sezvo isina kuenderana.
///
/// Iri basa harina maconconization guarentee asi rinowanikwa kana `std` chimiro cheiyi crate isina kunyorwa mukati.
/// Ona iro `resolve_frame` basa kune mamwe magwaro uye mienzaniso.
///
/// # Panics
///
/// Ona ruzivo pane `resolve_frame` yemapako pa `cb` kuvhunduka.
///
pub unsafe fn resolve_frame_unsynchronized<F>(frame: &Frame, mut cb: F)
where
    F: FnMut(&Symbol),
{
    imp::resolve(ResolveWhat::Frame(frame), &mut cb)
}

/// trait inomiririra resolution yechiratidzo mufaira.
///
/// Iyi trait inoburitswa sechinhu che trait pakuvhara kwakapihwa basa re `backtrace::resolve`, uye rinotumirwa sezvisingazivikanwe kuti kumisikidza kuri shure kwayo.
///
///
/// Chiratidzo chinogona kupa ruzivo rwezvakanangana nezve chiitiko, semuenzaniso zita, zita rezita, nhamba yemutsara, kero chaiyo, nezvimwe.
/// Haasi ese ruzivo anogara aripo muchiratidzo, zvisinei, saka nzira dzese dzinodzosa `Option`.
///
///
pub struct Symbol {
    // TODO: hupenyu hwese hwakasungwa hunoda kuomerwa pakupedzisira kusvika `Symbol`,
    // asi parizvino shanduko iri kutyora.
    // Parizvino izvi zvakachengeteka nekuti `Symbol` inongogoneswa nereferenzi uye haigone kuumbwa.
    inner: imp::Symbol<'static>,
}

impl Symbol {
    /// Inodzorera zita rebasa iri.
    ///
    /// Chimiro chakadzoserwa chinogona kushandiswa kubvunza akasiyana maseru nezve zita rechiratidzo:
    ///
    ///
    /// * Kuitwa kwe `Display` kuchapurinda chiratidzo chakadzikiswa.
    /// * Iyo yakasvibirira `str` kukosha kwechiratidzo inogona kuwanikwa (kana ichinyatsoita utf-8).
    /// * Mabheti akasvibirira ezita rechiratidzo anogona kuwanikwa.
    ///
    pub fn name(&self) -> Option<SymbolName<'_>> {
        self.inner.name()
    }

    /// Inodzorera kero yekutanga yebasa iri.
    pub fn addr(&self) -> Option<*mut c_void> {
        self.inner.addr().map(|p| p as *mut _)
    }

    /// Inodzorera iyo yakasvibirira zita rezita sechidimbu.
    /// Izvi zvinonyanya kubatsira kune `no_std` nharaunda.
    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        self.inner.filename_raw()
    }

    /// Inodzorera iyo nhamba yekoramu kune iko iko iko iko iko iko iko chiratidzo.
    ///
    /// Chete gimli parizvino inopa kukosha pano uye kunyangwe ipapo chete kana `filename` inodzosera `Some`, uye saka zviri ipapo zvichiteerana nekutongwa kwakafanana.
    ///
    pub fn colno(&self) -> Option<u32> {
        self.inner.colno()
    }

    /// Inodzorera iyo nhamba yemutsara uko iko iko iko iko iko kuita chiratidzo.
    ///
    /// Iyi kukosha kwekudzoka inowanzo `Some` kana `filename` ichidzosa `Some`, uye nekudaro iri pasi pemapako akafanana.
    ///
    pub fn lineno(&self) -> Option<u32> {
        self.inner.lineno()
    }

    /// Inodzorera zita refaira pakatsanangurwa basa iri.
    ///
    /// Izvi zviripo parizvino zvinongowanikwa kana libbacktrace kana gimli iri kushandiswa (semuenzaniso
    /// unix mapuratifomu mamwe) uye kana bhanari ikabatanidzwa ne debuginfo.
    /// Kana imwe yeaya mamiriro akasangana saka izvi zvinogona kudzoka `None`.
    ///
    /// # Zvinodiwa maficha
    ///
    /// Iri basa rinoda kuti `std` chimiro che `backtrace` crate chigoneswe, uye iyo `std` ficha inogoneswa nekutadza.
    ///
    ///
    #[cfg(feature = "std")]
    #[allow(unreachable_code)]
    pub fn filename(&self) -> Option<&Path> {
        self.inner.filename()
    }
}

impl fmt::Debug for Symbol {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut d = f.debug_struct("Symbol");
        if let Some(name) = self.name() {
            d.field("name", &name);
        }
        if let Some(addr) = self.addr() {
            d.field("addr", &addr);
        }

        #[cfg(feature = "std")]
        {
            if let Some(filename) = self.filename() {
                d.field("filename", &filename);
            }
        }

        if let Some(lineno) = self.lineno() {
            d.field("lineno", &lineno);
        }
        d.finish()
    }
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        // Pamwe chiratidzo chakakamurwa cheC++ , kana kuchinjisa iyo mangled chiratidzo se Rust chakundikana.
        //
        struct OptionCppSymbol<'a>(Option<::cpp_demangle::BorrowedSymbol<'a>>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(input: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(::cpp_demangle::BorrowedSymbol::new(input).ok())
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(None)
            }
        }
    } else {
        use core::marker::PhantomData;

        // Ita shuwa yekuchengeta iyi zero-saizi, kuti iyo `cpp_demangle` chimiro irege kuve nemutengo kana yakaremara.
        //
        struct OptionCppSymbol<'a>(PhantomData<&'a ()>);

        impl<'a> OptionCppSymbol<'a> {
            fn parse(_: &'a [u8]) -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }

            fn none() -> OptionCppSymbol<'a> {
                OptionCppSymbol(PhantomData)
            }
        }
    }
}

/// Kuputira kwakatenderedza zita rechiratidzo kuti upe ergonomic vanopinda kune iro zita rakadzikiswa, mabhureti akasvinwa, tambo mbishi, nezvimwe.
///
// Rega kodhi yakafa kana iyo `cpp_demangle` ficha isina kubvumidzwa.
#[allow(dead_code)]
pub struct SymbolName<'a> {
    bytes: &'a [u8],
    demangled: Option<Demangle<'a>>,
    cpp_demangled: OptionCppSymbol<'a>,
}

impl<'a> SymbolName<'a> {
    /// Inogadzira zita nyowani yechiratidzo kubva kune yakasvibirira yepasi mabheti.
    pub fn new(bytes: &'a [u8]) -> SymbolName<'a> {
        let str_bytes = str::from_utf8(bytes).ok();
        let demangled = str_bytes.and_then(|s| try_demangle(s).ok());

        let cpp = if demangled.is_none() {
            OptionCppSymbol::parse(bytes)
        } else {
            OptionCppSymbol::none()
        };

        SymbolName {
            bytes: bytes,
            demangled: demangled,
            cpp_demangled: cpp,
        }
    }

    /// Inodzorera yakashama (mangled) zita rechiratidzo se `str` kana chiratidzo chiri chechokwadi utf-8.
    ///
    /// Shandisa iyo `Display` kuitisa kana iwe uchida iyo yakadzvanywa vhezheni.
    pub fn as_str(&self) -> Option<&'a str> {
        self.demangled
            .as_ref()
            .map(|s| s.as_str())
            .or_else(|| str::from_utf8(self.bytes).ok())
    }

    /// Inodzorera iro zita rechiratidzo mbishi senge runyorwa rwemabheti
    pub fn as_bytes(&self) -> &'a [u8] {
        self.bytes
    }
}

fn format_symbol_name(
    fmt: fn(&str, &mut fmt::Formatter<'_>) -> fmt::Result,
    mut bytes: &[u8],
    f: &mut fmt::Formatter<'_>,
) -> fmt::Result {
    while bytes.len() > 0 {
        match str::from_utf8(bytes) {
            Ok(name) => {
                fmt(name, f)?;
                break;
            }
            Err(err) => {
                fmt("\u{FFFD}", f)?;

                match err.error_len() {
                    Some(len) => bytes = &bytes[err.valid_up_to() + len..],
                    None => break,
                }
            }
        }
    }
    Ok(())
}

cfg_if::cfg_if! {
    if #[cfg(feature = "cpp_demangle")] {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else if let Some(ref cpp) = self.cpp_demangled.0 {
                    cpp.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    } else {
        impl<'a> fmt::Display for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Display::fmt, self.bytes, f)
                }
            }
        }
    }
}

cfg_if::cfg_if! {
    if #[cfg(all(feature = "std", feature = "cpp_demangle"))] {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                use std::fmt::Write;

                if let Some(ref s) = self.demangled {
                    return s.fmt(f)
                }

                // Izvi zvinogona kupurinda kana chiratidzo chakadonhedzwa chisiri chaicho chinoshanda, saka bata chikanganiso apa nerunako nekusachiparadzira kunze.
                //
                //
                if let Some(ref cpp) = self.cpp_demangled.0 {
                    let mut s = String::new();
                    if write!(s, "{}", cpp).is_ok() {
                        return s.fmt(f)
                    }
                }

                format_symbol_name(fmt::Debug::fmt, self.bytes, f)
            }
        }
    } else {
        impl<'a> fmt::Debug for SymbolName<'a> {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                if let Some(ref s) = self.demangled {
                    s.fmt(f)
                } else {
                    format_symbol_name(fmt::Debug::fmt, self.bytes, f)
                }
            }
        }
    }
}

/// Kuedza kudzoreredza iyo cached memory yakashandiswa kufananidzira kero.
///
/// Iyi nzira ichaedza kuburitsa chero epasirese data data zvimiro zvakambovharirwa pasirese kana mune tambo iyo inowanzo mirira yakaparadzaniswa DWARF ruzivo kana zvakafanana.
///
///
/// # Caveats
///
/// Nepo basa iri richiwanikwa nguva dzose harinyatsoita chero chinhu pane akawanda maitiro.
/// Raibhurari senge dbghelp kana libbacktrace haipe zvivakwa zvekutamisa nyika uye kubata iyo yakapihwa ndangariro.
/// Parizvino iyo `gimli-symbolize` ficha yeiyi crate ndiyo yega ficha apo iri basa rine chero chinokanganisa.
///
///
///
#[cfg(feature = "std")]
pub fn clear_symbol_cache() {
    let _guard = crate::lock::lock();
    unsafe {
        imp::clear_symbol_cache();
    }
}

cfg_if::cfg_if! {
    if #[cfg(miri)] {
        mod miri;
        use miri as imp;
    } else if #[cfg(all(windows, target_env = "msvc", not(target_vendor = "uwp")))] {
        mod dbghelp;
        use dbghelp as imp;
    } else if #[cfg(all(
        feature = "libbacktrace",
        any(unix, all(windows, not(target_vendor = "uwp"), target_env = "gnu")),
        not(target_os = "fuchsia"),
        not(target_os = "emscripten"),
        not(target_env = "uclibc"),
        not(target_env = "libnx"),
    ))] {
        mod libbacktrace;
        use libbacktrace as imp;
    } else if #[cfg(all(
        feature = "gimli-symbolize",
        any(unix, windows),
        not(target_vendor = "uwp"),
        not(target_os = "emscripten"),
    ))] {
        mod gimli;
        use gimli as imp;
    } else {
        mod noop;
        use noop as imp;
    }
}