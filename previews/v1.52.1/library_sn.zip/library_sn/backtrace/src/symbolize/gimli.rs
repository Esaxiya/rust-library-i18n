//! Tsigiro yekufananidzira uchishandisa iyo `gimli` crate pa crates.io
//!
//! Uku ndiko kuteedzera kwekufananidzira kwe Rust.

use self::gimli::read::EndianSlice;
use self::gimli::NativeEndian as Endian;
use self::mmap::Mmap;
use self::stash::Stash;
use super::BytesOrWideString;
use super::ResolveWhat;
use super::SymbolName;
use addr2line::gimli;
use core::convert::TryInto;
use core::mem;
use core::u32;
use libc::c_void;
use mystd::ffi::OsString;
use mystd::fs::File;
use mystd::path::Path;
use mystd::prelude::v1::*;

#[cfg(backtrace_in_libstd)]
mod mystd {
    pub use crate::*;
}
#[cfg(not(backtrace_in_libstd))]
extern crate std as mystd;

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        #[path = "gimli/mmap_windows.rs"]
        mod mmap;
    } else if #[cfg(any(
        target_os = "android",
        target_os = "freebsd",
        target_os = "fuchsia",
        target_os = "ios",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "solaris",
    ))] {
        #[path = "gimli/mmap_unix.rs"]
        mod mmap;
    } else {
        #[path = "gimli/mmap_fake.rs"]
        mod mmap;
    }
}

mod stash;

const MAPPINGS_CACHE_SIZE: usize = 4;

struct Mapping {
    // 'static hupenyu manyepo ekunyepedzera kushomeka kwerutsigiro rwekuzvimiririra-kuzvimiririra.
    cx: Context<'static>,
    _map: Mmap,
    _stash: Stash,
}

impl Mapping {
    fn mk<F>(data: Mmap, mk: F) -> Option<Mapping>
    where
        F: for<'a> Fn(&'a [u8], &'a Stash) -> Option<Context<'a>>,
    {
        let stash = Stash::new();
        let cx = mk(&data, &stash)?;
        Some(Mapping {
            // Chinja kuve 'static yehupenyu sezvo zviratidzo zvinofanirwa kungokwereta `map` uye `stash` uye tiri kuzvichengeta pazasi.
            //
            cx: unsafe { core::mem::transmute::<Context<'_>, Context<'static>>(cx) },
            _map: data,
            _stash: stash,
        })
    }
}

struct Context<'a> {
    dwarf: addr2line::Context<EndianSlice<'a, Endian>>,
    object: Object<'a>,
}

impl<'data> Context<'data> {
    fn new(stash: &'data Stash, object: Object<'data>) -> Option<Context<'data>> {
        fn load_section<'data, S>(stash: &'data Stash, obj: &Object<'data>) -> S
        where
            S: gimli::Section<gimli::EndianSlice<'data, Endian>>,
        {
            let data = obj.section(stash, S::section_name()).unwrap_or(&[]);
            S::from(EndianSlice::new(data, Endian))
        }

        let dwarf = addr2line::Context::from_sections(
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            load_section(stash, &object),
            gimli::EndianSlice::new(&[], Endian),
        )
        .ok()?;
        Some(Context { dwarf, object })
    }
}

fn mmap(path: &Path) -> Option<Mmap> {
    let file = File::open(path).ok()?;
    let len = file.metadata().ok()?.len().try_into().ok()?;
    unsafe { Mmap::map(&file, len) }
}

cfg_if::cfg_if! {
    if #[cfg(windows)] {
        use core::mem::MaybeUninit;
        use super::super::windows::*;
        use mystd::os::windows::prelude::*;
        use alloc::vec;

        mod coff;
        use self::coff::Object;

        // Zve kurodha maraibhurari echinyakare pa Windows, ona kumwe kukurukurirana pa rust-lang/rust#71060 yezano dzakasiyana pano.
        //
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe { add_loaded_images(&mut ret); }
            return ret;
        }

        unsafe fn add_loaded_images(ret: &mut Vec<Library>) {
            let snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
            if snap == INVALID_HANDLE_VALUE {
                return;
            }

            let mut me = MaybeUninit::<MODULEENTRY32W>::zeroed().assume_init();
            me.dwSize = mem::size_of_val(&me) as DWORD;
            if Module32FirstW(snap, &mut me) == TRUE {
                loop {
                    if let Some(lib) = load_library(&me) {
                        ret.push(lib);
                    }

                    if Module32NextW(snap, &mut me) != TRUE {
                        break;
                    }
                }

            }

            CloseHandle(snap);
        }

        unsafe fn load_library(me: &MODULEENTRY32W) -> Option<Library> {
            let pos = me
                .szExePath
                .iter()
                .position(|i| *i == 0)
                .unwrap_or(me.szExePath.len());
            let name = OsString::from_wide(&me.szExePath[..pos]);

            // Minibhurari dzeMinGW parizvino hazvitsigire ASLR (rust-lang/rust#16514), asi maDLL anogona kutamisirwa munzvimbo yekero.
            // Zvinotaridza kuti makero mune dhegi info ndeye-kana raibhurari iyi yakaiswa pa "image base" yayo, unova munda mune yayo COFF faira misoro.
            // Sezvo izvi zviri izvo debuginfo zvinoita kunge zvinonyorwa isu tinoratidzira tafura yechiratidzo uye tinochengeta kero sekunge kuti raibhurari yakatakurwa ku "image base" futi.
            //
            // Iyo raibhurari inogona kusatakurwa pa "image base", zvakadaro.
            // (zvimwe chimwe chinhu chingangotakurwa ipapo?) Apa ndipo panotamba munda we `bias`, uye tinoda kuona kukosha kwe `bias` pano.Nehurombo kunyangwe hazvo zvisiri pachena maitiro ekuwana izvi kubva mune yakatakurwa module.
            // Zvatinazvo, zvisinei, ndiyo chaiyo kero yekutakura (`modBaseAddr`).
            //
            // Sechinguva chekoputi-kunze izvozvi isu mmap iyo faira, verenga iyo faira musoro wemashoko, wobva wadonhedza iyo mmap.Izvi zvinoparadza nekuti isu tingangozovhurazve iyo mmap gare gare, asi izvi zvinofanirwa kushanda nemazvo zvakakwana izvozvi.
            //
            // Kana tangova ne `image_base` (inodiwa nzvimbo yekutakura) uye iyo `base_addr` (chaiko nzvimbo yekutakura) tinogona kuzadza iyo `bias` (mutsauko pakati peicho chaicho uye chaunoda) uyezve kero yakataurwa yechikamu chimwe nechimwe ndiyo `image_base` nekuti ndizvo zvinotaurwa nefaira.
            //
            //
            // Parizvino zvinoita sekunge kusiyana ne ELF/MachO tinogona kuita nechikamu chimwe chete kuraibhurari, tichishandisa `modBaseSize` sehukuru hwese.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mmap = mmap(name.as_ref())?;
            let image_base = coff::get_image_base(&mmap)?;
            let base_addr = me.modBaseAddr as usize;
            Some(Library {
                name,
                bias: base_addr.wrapping_sub(image_base),
                segments: vec![LibrarySegment {
                    stated_virtual_memory_address: image_base,
                    len: me.modBaseSize as usize,
                }],
            })
        }
    } else if #[cfg(any(
        target_os = "macos",
        target_os = "ios",
        target_os = "tvos",
        target_os = "watchos",
    ))] {
        // macOS inoshandisa iyo Mach-O fomati fomati uye inoshandisa DYLD-yakatarwa maAPI kurodha runyorwa rwemaraibhurari eko ari chikamu chekushandisa.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod macho;
        use self::macho::Object;

        #[allow(deprecated)]
        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            let images = unsafe { libc::_dyld_image_count() };
            for i in 0..images {
                ret.extend(native_library(i));
            }
            return ret;
        }

        #[allow(deprecated)]
        fn native_library(i: u32) -> Option<Library> {
            use object::macho;
            use object::read::macho::{MachHeader, Segment};
            use object::{Bytes, NativeEndian};

            // Tora zita reraibhurari inoenderana nenzira yekukwirisa nayo.
            //
            let name = unsafe {
                let name = libc::_dyld_get_image_name(i);
                if name.is_null() {
                    return None;
                }
                CStr::from_ptr(name)
            };

            // Takura musoro wemufananidzo weraibhurari iyi uye tumira ku `object` kuti utarise mirairo yese yemitoro kuti tikwanise kuona zvikamu zvese zvinobatanidzwa pano.
            //
            //
            let (mut load_commands, endian) = unsafe {
                let header = libc::_dyld_get_image_header(i);
                if header.is_null() {
                    return None;
                }
                match (*header).magic {
                    macho::MH_MAGIC => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader32<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    macho::MH_MAGIC_64 => {
                        let endian = NativeEndian;
                        let header = &*(header as *const macho::MachHeader64<NativeEndian>);
                        let data = core::slice::from_raw_parts(
                            header as *const _ as *const u8,
                            mem::size_of_val(header) + header.sizeofcmds.get(endian) as usize
                        );
                        (header.load_commands(endian, Bytes(data)).ok()?, endian)
                    }
                    _ => return None,
                }
            };

            // Iterate pamusoro pezvikamu uye kunyoresa matunhu anozivikanwa ezvikamu zvatinowana.
            // Kuwedzera kurekodha ruzivo bout zvinyorwa zvemukati zvekugadzirisa gare gare, ona zvataurwa pazasi.
            //
            let mut segments = Vec::new();
            let mut first_text = 0;
            let mut text_fileoff_zero = false;
            while let Some(cmd) = load_commands.next().ok()? {
                if let Some((seg, _)) = cmd.segment_32().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
                if let Some((seg, _)) = cmd.segment_64().ok()? {
                    if seg.name() == b"__TEXT" {
                        first_text = segments.len();
                        if seg.fileoff(endian) == 0 && seg.filesize(endian) > 0 {
                            text_fileoff_zero = true;
                        }
                    }
                    segments.push(LibrarySegment {
                        len: seg.vmsize(endian).try_into().ok()?,
                        stated_virtual_memory_address: seg.vmaddr(endian).try_into().ok()?,
                    });
                }
            }

            // Sarudza iyo "slide" yeiri raibhurari iyo inopedzisira yave kuve kusarura kwatinoshandisa kuona kuti kupi mune zvendangariro zvinhu zvinotakurwa.
            // Ichi chidiki cheakashomeka kuverenga asi uye mhedzisiro yekuedza zvinhu zvishoma musango uye kuona izvo zvinonamira.
            //
            // Pfungwa yakajairika ndeyekuti `bias` pamwe nechikamu che `stated_virtual_memory_address` ichave iri munzvimbo chaiyo yekero iyo chikamu chinogara.
            // Chimwe chinhu chatinovimba nacho ndechekuti kero chaiyo inobvisa iyo `bias` ndiyo indekisi yekutarisa kumusoro kwetafura yechiratidzo uye debuginfo.
            //
            // Zvinoitika, hazvo, kuti kune masisitimu akatakurwa raibhurari idzi kuverenga hakuna kunaka.Kune vemo vanoita, zvisinei, zvinoita sezvakanaka.
            // Kusimudza imwe pfungwa kubva kunobva LLDB kune imwe yakakosha-casing yechikamu chekutanga che `__TEXT` chakatakurwa kubva kufaira offset 0 ine nonzero saizi.
            // Chero chikonzero chipi zvacho kana izvi zviripo zvinoita sekureva kuti tafura yechiratidzo inoenderana neiyo chete vmaddr slide yeraibhurari.
            // Kana *isiri* iripo saka tafura yechiratidzo inoenderana neiyo vmaddr slide pamwe nekero yakataurwa kero.
            //
            // Kugadzirisa mamiriro ezvinhu aya kana isu * tikasawana chikamu chemavara pafaira kukanzura zero ndipo patinowedzera kusarura nekero yekutanga yezvinyorwa zvakataurwa uye nekudzora kero dzese dzakataurwa nemari iyoyo zvakare.
            //
            // Nenzira iyoyo tafura yechiratidzo inogara ichionekwa ichienderana nemari yereibhurari.
            // Izvi zvinoita kunge zvine mhedzisiro chaiyo yekumiririra kuburikidza netafura yezviratidzo.
            //
            // Kutendeseka ini handina chokwadi zvachose kana ichi chiri chokwadi kana paine chimwe chinhu chinofanira kuratidza maitiro ekuita izvi.
            // Parizvino kunyange izvi zvichiita senge zvinoshanda nemazvo (?) uye isu tinofanirwa kugara tichikwanisa kuita izvi nekufamba kwenguva kana zvichidikanwa.
            //
            // Kuti uwane rumwe rumwe ruzivo ona #318
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            let mut slide = unsafe { libc::_dyld_get_image_vmaddr_slide(i) as usize };
            if !text_fileoff_zero {
                let adjust = segments[first_text].stated_virtual_memory_address;
                for segment in segments.iter_mut() {
                    segment.stated_virtual_memory_address -= adjust;
                }
                slide += adjust;
            }

            Some(Library {
                name: OsStr::from_bytes(name.to_bytes()).to_owned(),
                segments,
                bias: slide,
            })
        }
    } else if #[cfg(any(
        target_os = "linux",
        target_os = "fuchsia",
    ))] {
        // Imwe Unix (semuenzaniso
        // Linux) mapuratifomu anoshandisa ELF sechinhu faira fomati uye inowanzo shandisa API inonzi `dl_iterate_phdr` kurodha maraibhurari eko.
        //

        use mystd::os::unix::prelude::*;
        use mystd::ffi::{OsStr, CStr};

        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            let mut ret = Vec::new();
            unsafe {
                libc::dl_iterate_phdr(Some(callback), &mut ret as *mut Vec<_> as *mut _);
            }
            return ret;
        }

        // `info` anofanirwa kuve anonongedzera anoshanda.
        // `vec` inofanirwa kuve inongedzo inoshanda kune `std::Vec`.
        unsafe extern "C" fn callback(
            info: *mut libc::dl_phdr_info,
            _size: libc::size_t,
            vec: *mut libc::c_void,
        ) -> libc::c_int {
            let info = &*info;
            let libs = &mut *(vec as *mut Vec<Library>);
            let is_main_prog = info.dlpi_name.is_null() || *info.dlpi_name == 0;
            let name = if is_main_prog {
                if libs.is_empty() {
                    mystd::env::current_exe().map(|e| e.into()).unwrap_or_default()
                } else {
                    OsString::new()
                }
            } else {
                let bytes = CStr::from_ptr(info.dlpi_name).to_bytes();
                OsStr::from_bytes(bytes).to_owned()
            };
            let headers = core::slice::from_raw_parts(info.dlpi_phdr, info.dlpi_phnum as usize);
            libs.push(Library {
                name,
                segments: headers
                    .iter()
                    .map(|header| LibrarySegment {
                        len: (*header).p_memsz as usize,
                        stated_virtual_memory_address: (*header).p_vaddr as usize,
                    })
                    .collect(),
                bias: info.dlpi_addr as usize,
            });
            0
        }
    } else if #[cfg(target_env = "libnx")] {
        // DevkitA64 haisi natively inotsigira info yekukanganisa, asi iyo yekuvaka system ichaisa debug info munzira `romfs:/debug_info.elf`.
        //
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            extern "C" {
                static __start__: u8;
            }

            let bias = unsafe { &__start__ } as *const u8 as usize;

            let mut ret = Vec::new();
            let mut segments = Vec::new();
            segments.push(LibrarySegment {
                stated_virtual_memory_address: 0,
                len: usize::max_value() - bias,
            });

            let path = "romfs:/debug_info.elf";
            ret.push(Library {
                name: path.into(),
                segments,
                bias,
            });

            ret
        }
    } else {
        // Zvese zvimwe zvinofanirwa kushandisa ELF, asi haizive maitirwo enzvimbo emaraibhurari.
        //

        use mystd::os::unix::prelude::*;
        mod elf;
        use self::elf::Object;

        fn native_libraries() -> Vec<Library> {
            Vec::new()
        }
    }
}

#[derive(Default)]
struct Cache {
    /// Ese anozivikanwa akagovana maraibhurari akaiswa.
    libraries: Vec<Library>,

    /// Mappings cache kwatinochengetera yakadzvanywa diki ruzivo.
    ///
    /// Iyi rondedzero ine yakamisikidzwa chinzvimbo cheayo ese nguva yehupenyu iyo isingatombo wedzera.
    /// Iyo `usize` chinhu chega roga roga indekisi mu `libraries` pamusoro apo `usize::max_value()` inomiririra yazvino inogoneka.
    ///
    /// Iyo `Mapping` inowirirana yakadzvanywa diki ruzivo.
    ///
    /// Ziva kuti ichi chingori cache yeRRU uye tichave tichichinja zvinhu kutenderedza muno sezvatiri kufananidzira kero.
    ///
    mappings: Vec<(usize, Mapping)>,
}

struct Library {
    name: OsString,
    /// Zvikamu zveiri raibhurari zvakaiswa mundangariro, uye kwadzakatakurwa.
    segments: Vec<LibrarySegment>,
    /// Iyo "bias" yeraibhurari ino, kazhinji kwayakaiswa mundangariro.
    /// Iyi kukosha inowedzerwa kune yega yega chikamu chakataurwa kero kuti uwane chaiyo chaiyo kero kero iyo chidimbu chakaiswa mukati.
    /// Pamusoro pezvo uku kusarudzika kunobviswa kubva kune chaiwo mamemori kero kunongedzera ku debuginfo uye tafura yechiratidzo.
    ///
    ///
    bias: usize,
}

struct LibrarySegment {
    /// Kero yakataurwa yechikamu ichi mufaira rechinhu.
    /// Uku hakusi iko iko iko iko iko chikamu chakatakurwa, asi asi kero iyi pamwe neiyo raibhurari `bias` ndipo pekuiwana.
    ///
    stated_virtual_memory_address: usize,
    /// Saizi yeiyo ths chikamu mundangariro.
    len: usize,
}

// isina kuchengeteka nekuti izvi zvinodikanwa kuti zviwirirane kunze
pub unsafe fn clear_symbol_cache() {
    Cache::with_global(|cache| cache.mappings.clear());
}

impl Cache {
    fn new() -> Cache {
        Cache {
            mappings: Vec::with_capacity(MAPPINGS_CACHE_SIZE),
            libraries: native_libraries(),
        }
    }

    // isina kuchengeteka nekuti izvi zvinodikanwa kuti zviwirirane kunze
    unsafe fn with_global(f: impl FnOnce(&mut Self)) {
        // Iyo diki kwazvo, yakapusa kwazvo LRU cache ye debug info mappings.
        //
        // Iyo yekurova rate inofanirwa kuve yakakwira kwazvo, sezvo yakajairwa stack haiyambuke pakati pemaraibhurari mazhinji akagovaniswa.
        //
        // Zvivakwa zve `addr2line::Context` zvinodhura kwazvo kugadzira.
        // Mutengo waro unotarisirwa kuverengerwa neinotevera mibvunzo ye `locate`, iyo inowedzera zvivakwa zvakavakwa pakuvaka `addr2line: : Context`s kuti uwane yakanaka yekumhanyisa.
        //
        // Dai isu tisina cache iyi, iyo amortization yaisazomboitika, uye yekufananidzira kumashure kwaizove ssssllllooooowwww.
        //
        //
        static mut MAPPINGS_CACHE: Option<Cache> = None;

        f(MAPPINGS_CACHE.get_or_insert_with(|| Cache::new()))
    }

    fn avma_to_svma(&self, addr: *const u8) -> Option<(usize, *const u8)> {
        self.libraries
            .iter()
            .enumerate()
            .filter_map(|(i, lib)| {
                // Kutanga kumusoro, bvunzo kana iyi `lib` iine chero chikamu chine iyo `addr` (inobata kutamisirwa).Kana cheki iyi ikapfuura saka tinogona kuenderera pasi uye kunyatso dudzira kero.
                //
                // Ziva kuti isu tiri kushandisa `wrapping_add` pano kudzivirira mafashama macheki.Izvo zvakaonekwa musango kuti iyo SVMA + bias computation inopfachukira.
                // Zvinotaridza kunge zvisinganzwisisike izvo zvaizoitika asi hapana huwandu hwakawanda hwatingaite nezvazvo kunze kwekungoregeredza izvo zvikamu sezvo vangangonongedzera muchadenga.
                //
                // Izvi pakutanga zvakauya mu rust-lang/backtrace-rs#329.
                //
                //
                //
                //
                //
                if !lib.segments.iter().any(|s| {
                    let svma = s.stated_virtual_memory_address;
                    let start = svma.wrapping_add(lib.bias);
                    let end = start.wrapping_add(s.len);
                    let address = addr as usize;
                    start <= address && address < end
                }) {
                    return None;
                }

                // Zvino zvatave kuziva `lib` iine `addr`, tinogona kugadzirisa nekatsika kuti tiwane yakataurwa virutal memory kero.
                //
                let svma = (addr as usize).wrapping_sub(lib.bias);
                Some((i, svma as *const u8))
            })
            .next()
    }

    fn mapping_for_lib<'a>(&'a mut self, lib: usize) -> Option<&'a mut Context<'a>> {
        let idx = self.mappings.iter().position(|(idx, _)| *idx == lib);

        // Invariant: mushure meiyi mamiriro anopedzisa pasina kutanga kudzoka
        // kubva pakukanganisa, iyo cache yekupinda iyi nzira iri pane index 0.

        if let Some(idx) = idx {
            // Kana iyo mepu yatove mune cache, fambisa kumberi.
            if idx != 0 {
                let entry = self.mappings.remove(idx);
                self.mappings.insert(0, entry);
            }
        } else {
            // Kana iyo mepu isiri mune cache, gadzira mepu nyowani, isveta kumberi kweiyo cache, uye kudzinga chekare chekupinda kana zvichidikanwa.
            //
            //
            let name = &self.libraries[lib].name;
            let mapping = Mapping::new(name.as_ref())?;

            if self.mappings.len() == MAPPINGS_CACHE_SIZE {
                self.mappings.pop();
            }

            self.mappings.insert(0, (lib, mapping));
        }

        let cx: &'a mut Context<'static> = &mut self.mappings[0].1.cx;
        // usaburitse iyo `'static` yehupenyu, ita shuwa kuti yakaverengerwa isu pachedu
        //
        Some(unsafe { mem::transmute::<&'a mut Context<'static>, &'a mut Context<'a>>(cx) })
    }
}

pub unsafe fn resolve(what: ResolveWhat<'_>, cb: &mut dyn FnMut(&super::Symbol)) {
    let addr = what.address_or_ip();
    let mut call = |sym: Symbol<'_>| {
        // Wedzera hupenyu hwese hwe `sym` kusvika `'static` sezvo isu zvinosuwisa kuti tinoda kusvika pano, asi zviri ony zvichingobuda sereferenzi saka hapana chirevo kwazviri chinofanirwa kuenderera kupfuura iyi fureni zvakadaro.
        //
        //
        let sym = mem::transmute::<Symbol<'_>, Symbol<'static>>(sym);
        (cb)(&super::Symbol { inner: sym });
    };

    Cache::with_global(|cache| {
        let (lib, addr) = match cache.avma_to_svma(addr as *const u8) {
            Some(pair) => pair,
            None => return,
        };

        // Pakupedzisira, tora mepu yakachengetwa kana gadzira mepu nyowani yeiyi faira, uye ongorora iyo DWARF info kuti uwane iyo file/line/name yekero iyi.
        //
        let cx = match cache.mapping_for_lib(lib) {
            Some(cx) => cx,
            None => return,
        };
        let mut any_frames = false;
        if let Ok(mut frames) = cx.dwarf.find_frames(addr as u64) {
            while let Ok(Some(frame)) = frames.next() {
                any_frames = true;
                call(Symbol::Frame {
                    addr: addr as *mut c_void,
                    location: frame.location,
                    name: frame.function.map(|f| f.name.slice()),
                });
            }
        }
        if !any_frames {
            if let Some((object_cx, object_addr)) = cx.object.search_object_map(addr as u64) {
                if let Ok(mut frames) = object_cx.dwarf.find_frames(object_addr) {
                    while let Ok(Some(frame)) = frames.next() {
                        any_frames = true;
                        call(Symbol::Frame {
                            addr: addr as *mut c_void,
                            location: frame.location,
                            name: frame.function.map(|f| f.name.slice()),
                        });
                    }
                }
            }
        }
        if !any_frames {
            if let Some(name) = cx.object.search_symtab(addr as u64) {
                call(Symbol::Symtab {
                    addr: addr as *mut c_void,
                    name,
                });
            }
        }
    });
}

pub enum Symbol<'a> {
    /// Isu takakwanisa kutsvaga furemu ruzivo rwechiratidzo ichi, uye `addr2line`'s furemu mukati ine zvese nitty gritty ruzivo.
    ///
    Frame {
        addr: *mut c_void,
        location: Option<addr2line::Location<'a>>,
        name: Option<&'a [u8]>,
    },
    /// Hatina kuwana ruzivo rwekugadzirisa dambudziko, asi takahuwana mutafura yechiratidzo cheiyo elf inogoneka.
    ///
    Symtab { addr: *mut c_void, name: &'a [u8] },
}

impl Symbol<'_> {
    pub fn name(&self) -> Option<SymbolName<'_>> {
        match self {
            Symbol::Frame { name, .. } => {
                let name = name.as_ref()?;
                Some(SymbolName::new(name))
            }
            Symbol::Symtab { name, .. } => Some(SymbolName::new(name)),
        }
    }

    pub fn addr(&self) -> Option<*mut c_void> {
        match self {
            Symbol::Frame { addr, .. } => Some(*addr),
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename_raw(&self) -> Option<BytesOrWideString<'_>> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(BytesOrWideString::Bytes(file.as_bytes()))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn filename(&self) -> Option<&Path> {
        match self {
            Symbol::Frame { location, .. } => {
                let file = location.as_ref()?.file?;
                Some(Path::new(file))
            }
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn lineno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.line,
            Symbol::Symtab { .. } => None,
        }
    }

    pub fn colno(&self) -> Option<u32> {
        match self {
            Symbol::Frame { location, .. } => location.as_ref()?.column,
            Symbol::Symtab { .. } => None,
        }
    }
}