use core::ffi::c_void;
use core::fmt;

/// Inoongorora iyo yazvino kufona-stack, ichipfuudza ese maforamu anoshanda mukuvhara kwakapihwa kuti uverenge stack trace.
///
/// Iri basa nderekushandira kweraibhurari iyi pakuverenga matanho ekuteedzera echirongwa.Iko kuvharwa kwakapihwa `cb` kwakapihwa zviitiko zve `Frame` zvinomiririra ruzivo nezve iyo furemu yekufona iri mudura.
/// Kuvhara kunounzwa mafuremu mune yepamusoro-pasi fashoni (ichangodaidzwa kunzi mabasa kutanga).
///
/// Iko kuvhara kwekudzoka kukosha chiratidzo chekuti backtrace inofanirwa kuenderera.Kukosha kwekudzoka kwe `false` kunogumisa iyo backtrace uye kudzoka nekukasira.
///
/// Kana `Frame` yawanikwa iwe ungangoda kudaidza `backtrace::resolve` kuti ushandure iyo `ip` (yekuraira pointer) kana kero yechiratidzo kuva `Symbol` kuburikidza nayo iro zita uye/kana zita rezita/nhamba yemutsara inogona kudzidzwa.
///
///
/// Ziva kuti iri ibasa repasi-soro uye kana uchida, semuenzaniso, kutora backtrace kuti uongororwe gare gare, ipapo mhando ye `Backtrace` inogona kunge yakakodzera.
///
/// # Zvinodiwa maficha
///
/// Iri basa rinoda kuti `std` chimiro che `backtrace` crate chigoneswe, uye iyo `std` ficha inogoneswa nekutadza.
///
/// # Panics
///
/// Iri basa rinovavarira kusamboita panic, asi kana iyo `cb` yakapa panics ipapo mamwe mapuratifomu anomanikidza panic yakapetwa kuti ibvise maitiro.
/// Mamwe mapuratifomu anoshandisa raibhurari yeC iyo mukati inoshandisa macallbacks ayo asingakwanise kuvhurika kuburikidza, saka kuvhunduka kubva ku `cb` kunogona kukonzera maitiro kubvisa.
///
/// # Example
///
/// ```
/// extern crate backtrace;
///
/// fn main() {
///     backtrace::trace(|frame| {
///         // ...
///
///         true // enderera kumashure
///     });
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[cfg(feature = "std")]
pub fn trace<F: FnMut(&Frame) -> bool>(cb: F) {
    let _guard = crate::lock::lock();
    unsafe { trace_unsynchronized(cb) }
}

/// Zvakafanana ne `trace`, chete haina kuchengeteka sezvo isina kuenderana.
///
/// Iri basa harina maconconization guarentee asi rinowanikwa kana `std` chimiro cheiyi crate isina kunyorwa mukati.
/// Ona iro `trace` basa kune mamwe magwaro uye mienzaniso.
///
/// # Panics
///
/// Ona ruzivo pane `trace` yemapako pa `cb` kuvhunduka.
///
pub unsafe fn trace_unsynchronized<F: FnMut(&Frame) -> bool>(mut cb: F) {
    trace_imp(&mut cb)
}

/// trait inomiririra furemu rimwe rekuseri, rakapa kune `trace` basa reiyi crate.
///
/// Kuvharirwa kwebasa rekutsvaga kuchave kwakaunzwa mafuremu, uye furemu iri rinotumirwa sezvo iko kuitisa kwacho kusingawanzo kuzivikanwa kusvika nguva yekumhanya.
///
///
///
#[derive(Clone)]
pub struct Frame {
    pub(crate) inner: FrameImp,
}

impl Frame {
    /// Inodzorera yazvino kuraira pointer yeiyi furemu.
    ///
    /// Izvi zvinowanzo kuve rairo inotevera yekuita mufuremu, asi kwete ese ekuteedzera anonyora izvi ne100% kurongeka (asi kazhinji iri padyo padyo).
    ///
    ///
    /// Zvinokurudzirwa kupfuudza iyi kukosha ku `backtrace::resolve` kuti ishandure rive zita rechiratidzo.
    ///
    ///
    pub fn ip(&self) -> *mut c_void {
        self.inner.ip()
    }

    /// Inodzorera yazvino stack pointer yeiyi furemu.
    ///
    /// Muchiitiko chekuti backend haigone kudzosera stack pointer yeiyi furemu, null pointer inodzoserwa.
    ///
    pub fn sp(&self) -> *mut c_void {
        self.inner.sp()
    }

    /// Inodzorera kero yekutanga yechiratidzo yefuremu reiri basa.
    ///
    /// Izvi zvichaedza kudzoreredza iyo yekuraira pointer yakadzoserwa ne `ip` kutanga kwebasa, ichidzosa iyo kukosha.
    ///
    /// Mune zvimwe zviitiko, zvakadaro, kumashure kunongodzosera `ip` kubva pane iri basa.
    ///
    /// Iko kwakadzoserwa kukosha dzimwe nguva kunogona kushandiswa kana `backtrace::resolve` ikakundikana pane `ip` yakapihwa pamusoro.
    ///
    pub fn symbol_address(&self) -> *mut c_void {
        self.inner.symbol_address()
    }

    /// Inodzorera base kero yemo module iyo furemu iri.
    pub fn module_base_address(&self) -> Option<*mut c_void> {
        self.inner.module_base_address()
    }
}

impl fmt::Debug for Frame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Frame")
            .field("ip", &self.ip())
            .field("symbol_address", &self.symbol_address())
            .finish()
    }
}

cfg_if::cfg_if! {
    // Izvi zvinoda kuuya pekutanga, kuve nechokwadi chekuti Miri anotora pekutanga pamusoro peiyo inomiririra chikuva
    //
    if #[cfg(miri)] {
        pub(crate) mod miri;
        use self::miri::trace as trace_imp;
        pub(crate) use self::miri::Frame as FrameImp;
    } else if #[cfg(
        any(
            all(
                unix,
                not(target_os = "emscripten"),
                not(all(target_os = "ios", target_arch = "arm")),
            ),
            all(
                target_env = "sgx",
                target_vendor = "fortanix",
            ),
        )
    )] {
        mod libunwind;
        use self::libunwind::trace as trace_imp;
        pub(crate) use self::libunwind::Frame as FrameImp;
    } else if #[cfg(all(windows, not(target_vendor = "uwp")))] {
        mod dbghelp;
        use self::dbghelp::trace as trace_imp;
        pub(crate) use self::dbghelp::Frame as FrameImp;
        #[cfg(target_env = "msvc")] // chete inoshandiswa mu dbghelp inomiririra
        pub(crate) use self::dbghelp::StackFrame;
    } else {
        mod noop;
        use self::noop::trace as trace_imp;
        pub(crate) use self::noop::Frame as FrameImp;
    }
}