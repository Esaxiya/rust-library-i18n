#[cfg(feature = "std")]
use super::{BacktraceFrame, BacktraceSymbol};
use super::{BytesOrWideString, Frame, SymbolName};
use core::ffi::c_void;
use core::fmt;

const HEX_WIDTH: usize = 2 + 2 * core::mem::size_of::<usize>();

#[cfg(target_os = "fuchsia")]
mod fuchsia;

/// Mufomati wezvekumashure.
///
/// Rudzi urwu runogona kushandiswa kupurinda backtrace zvisinei nekuti iko backtrace pachayo kunobva kupi.
/// Kana iwe uine `Backtrace` mhando saka yayo `Debug` kuitisa yatove kushandisa iyi yekudhinda fomati.
///
pub struct BacktraceFmt<'a, 'b> {
    fmt: &'a mut fmt::Formatter<'b>,
    frame_index: usize,
    format: PrintFmt,
    print_path:
        &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result + 'b),
}

/// Maitiro ekudhinda atinogona kuprinta
#[derive(Copy, Clone, Eq, PartialEq)]
pub enum PrintFmt {
    /// Tinoprinta terser backtrace iyo inongori chete ine ruzivo rwakakodzera
    Short,
    /// Tinoprinta backtrace ine zvese zvingaite ruzivo
    Full,
    #[doc(hidden)]
    __Nonexhaustive,
}

impl<'a, 'b> BacktraceFmt<'a, 'b> {
    /// Gadzira `BacktraceFmt` nyowani iyo inonyora kuburitsa kune yakapihwa `fmt`.
    ///
    /// Iyo `format` nharo inodzora maitiro mune iyo backtrace yakadhindwa, uye iyo `print_path` nharo ichashandiswa kupurinda iyo `BytesOrWideString` zviitiko zvemafaira mazita.
    /// Rudzi urwu pacharwo haruite chero kudhinda kwemazita emafaira, asi iyi callback inodikanwa kuti idaro.
    ///
    ///
    ///
    pub fn new(
        fmt: &'a mut fmt::Formatter<'b>,
        format: PrintFmt,
        print_path: &'a mut (dyn FnMut(&mut fmt::Formatter<'_>, BytesOrWideString<'_>) -> fmt::Result
                     + 'b),
    ) -> Self {
        BacktraceFmt {
            fmt,
            frame_index: 0,
            format,
            print_path,
        }
    }

    /// Tinodhindisa nhanganyaya yekudzokera kumashure yave kuda kudhindwa.
    ///
    /// Izvi zvinodikanwa kune mamwe mapuratifomu ekumashure ekufananidzira zvizere, uye zvikasadaro ino ingori nzira yekutanga yaunosheedza mushure mekugadzira `BacktraceFmt`.
    ///
    ///
    pub fn add_context(&mut self) -> fmt::Result {
        #[cfg(target_os = "fuchsia")]
        fuchsia::print_dso_context(self.fmt)?;
        Ok(())
    }

    /// Inowedzera furemu kune backtrace kuburitsa.
    ///
    /// Ichi chibvumirano chinodzosera RAII muenzaniso we `BacktraceFrameFmt` iyo inogona kushandiswa kupurinda furemu, uye paruparadziko ichawedzera iyo counter counter.
    ///
    ///
    pub fn frame(&mut self) -> BacktraceFrameFmt<'_, 'a, 'b> {
        BacktraceFrameFmt {
            fmt: self,
            symbol_index: 0,
        }
    }

    /// Inopedzisa iyo backtrace kuburitsa.
    ///
    /// Ino parizvino haina-op asi inowedzerwa kuenderana kwe future nemafomati ekudzokera shure.
    ///
    pub fn finish(&mut self) -> fmt::Result {
        // Parizvino hapana-op-inosanganisira iyi hook kubvumira future kuwedzerwa.
        Ok(())
    }
}

/// Iyo fomati yeimwe chete furemu ye backtrace.
///
/// Mhando iyi inogadzirwa ne `BacktraceFmt::frame` basa.
pub struct BacktraceFrameFmt<'fmt, 'a, 'b> {
    fmt: &'fmt mut BacktraceFmt<'a, 'b>,
    symbol_index: usize,
}

impl BacktraceFrameFmt<'_, '_, '_> {
    /// Tinoprinda `BacktraceFrame` neiyi fomati fomati.
    ///
    /// Izvi zvichadzokororazve kudhinda ese `BacktraceSymbol` zviitiko mukati me `BacktraceFrame`.
    ///
    /// # Zvinodiwa maficha
    ///
    /// Iri basa rinoda kuti `std` chimiro che `backtrace` crate chigoneswe, uye iyo `std` ficha inogoneswa nekutadza.
    ///
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_frame(&mut self, frame: &BacktraceFrame) -> fmt::Result {
        let symbols = frame.symbols();
        for symbol in symbols {
            self.backtrace_symbol(frame, symbol)?;
        }
        if symbols.is_empty() {
            self.print_raw(frame.ip(), None, None, None)?;
        }
        Ok(())
    }

    /// Tinoprinda `BacktraceSymbol` mukati me `BacktraceFrame`.
    ///
    /// # Zvinodiwa maficha
    ///
    /// Iri basa rinoda kuti `std` chimiro che `backtrace` crate chigoneswe, uye iyo `std` ficha inogoneswa nekutadza.
    ///
    #[cfg(feature = "std")]
    pub fn backtrace_symbol(
        &mut self,
        frame: &BacktraceFrame,
        symbol: &BacktraceSymbol,
    ) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            // TODO: izvi hazvina kunaka kuti hatipedzisi kudhinda chero chinhu
            // iine asiri-utf8 mazita emafaira.
            // Nekutenda dzinenge zvese i utf8 saka izvi hazvifanirwe kunge zvakanyanya kunyanyisa.
            symbol
                .filename()
                .and_then(|p| Some(BytesOrWideString::Bytes(p.to_str()?.as_bytes()))),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Tinodhindisa yakatsvakwa yakateedzerwa `Frame` uye `Symbol`, kazhinji kubva mukati mayo mbishi callbacks yeiyi crate.
    ///
    pub fn symbol(&mut self, frame: &Frame, symbol: &super::Symbol) -> fmt::Result {
        self.print_raw_with_column(
            frame.ip(),
            symbol.name(),
            symbol.filename_raw(),
            symbol.lineno(),
            symbol.colno(),
        )?;
        Ok(())
    }

    /// Inowedzera furemu mbishi kune backtrace kuburitsa.
    ///
    /// Iyi nzira, kusiyana neyakapfuura, inotora nharo dzakasarudzika kuitira kana vari kunobva kunzvimbo dzakasiyana.
    /// Ziva kuti izvi zvinogona kudaidzwa kakawanda nguva yefuremu rimwe.
    ///
    pub fn print_raw(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
    ) -> fmt::Result {
        self.print_raw_with_column(frame_ip, symbol_name, filename, lineno, None)
    }

    /// Inowedzera furemu mbishi kune backtrace kuburitsa, inosanganisira ruzivo ruzivo.
    ///
    /// Iyi nzira, senge yapfuura, inotora nharo dzakasarudzika kuitira kana vari kunobva kunzvimbo dzakasiyana.
    /// Ziva kuti izvi zvinogona kudaidzwa kakawanda nguva yefuremu rimwe.
    ///
    pub fn print_raw_with_column(
        &mut self,
        frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Fuchsia haigone kuratidzira mukati mekuita saka ine fomati yakasarudzika iyo inogona kushandiswa kuratidza gare gare.
        // Dhinda iyo panzvimbo yekudhinda kero mune edu fomati pano.
        //
        if cfg!(target_os = "fuchsia") {
            self.print_raw_fuchsia(frame_ip)?;
        } else {
            self.print_raw_generic(frame_ip, symbol_name, filename, lineno, colno)?;
        }
        self.symbol_index += 1;
        Ok(())
    }

    #[allow(unused_mut)]
    fn print_raw_generic(
        &mut self,
        mut frame_ip: *mut c_void,
        symbol_name: Option<SymbolName<'_>>,
        filename: Option<BytesOrWideString<'_>>,
        lineno: Option<u32>,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Hapana chikonzero chekupurinda "null" mafuremu, zvinongoreva kuti iyo system backtrace yanga ichida kwazvo kudzoka kumashure zvakanyanya kure.
        //
        if let PrintFmt::Short = self.fmt.format {
            if frame_ip.is_null() {
                return Ok(());
            }
        }

        // Kuti tideredze saizi yeTCB muSgx enclave, isu hatidi kushandisa chiratidzo chekugadzirisa mashandiro.
        // Asi, isu tinokwanisa kupurinda kukanganisa kwekero pano, iyo inogona kuzotorwa mepu kugadzirisa basa.
        //
        #[cfg(all(feature = "std", target_env = "sgx", target_vendor = "fortanix"))]
        {
            let image_base = std::os::fortanix_sgx::mem::image_base();
            frame_ip = usize::wrapping_sub(frame_ip as usize, image_base as _) as _;
        }

        // Dhinda indekisi yefuremu pamwe neyakaisirwa kuraira poindi yefuremu.
        // Kana isu tiri pamusoro pechiratidzo chekutanga cheiyi furemu kunyangwe isu tichingodhinda yakakodzera whitespace.
        //
        if self.symbol_index == 0 {
            write!(self.fmt.fmt, "{:4}: ", self.fmt.frame_index)?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$?} - ", frame_ip, HEX_WIDTH)?;
            }
        } else {
            write!(self.fmt.fmt, "      ")?;
            if let PrintFmt::Full = self.fmt.format {
                write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH + 3)?;
            }
        }

        // Tevere kumusoro nyora zita rechiratidzo, uchishandisa imwe nzira yekufomati kuti uwane rumwe ruzivo kana tiri yakazara backtrace.
        // Pano isu tinobatawo zviratidzo zvisina zita,
        //
        match (symbol_name, &self.fmt.format) {
            (Some(name), PrintFmt::Short) => write!(self.fmt.fmt, "{:#}", name)?,
            (Some(name), PrintFmt::Full) => write!(self.fmt.fmt, "{}", name)?,
            (None, _) | (_, PrintFmt::__Nonexhaustive) => write!(self.fmt.fmt, "<unknown>")?,
        }
        self.fmt.fmt.write_str("\n")?;

        // Uye chekupedzisira, purinda iyo filename/line nhamba kana dziripo.
        if let (Some(file), Some(line)) = (filename, lineno) {
            self.print_fileline(file, line, colno)?;
        }

        Ok(())
    }

    fn print_fileline(
        &mut self,
        file: BytesOrWideString<'_>,
        line: u32,
        colno: Option<u32>,
    ) -> fmt::Result {
        // Filename/line dzakadhindwa pamitsara pazasi pezita rechiratidzo, saka purinda imwe whitespace yakakodzera kuti urongedze-kurudyi pachedu
        //
        if let PrintFmt::Full = self.fmt.format {
            write!(self.fmt.fmt, "{:1$}", "", HEX_WIDTH)?;
        }
        write!(self.fmt.fmt, "             at ")?;

        // Tumira kune yedu yemukati yekufona kuti uprinte iro zita rezita uye wobva wadhindisa iyo nhamba yemutsetse.
        //
        (self.fmt.print_path)(self.fmt.fmt, file)?;
        write!(self.fmt.fmt, ":{}", line)?;

        // Wedzera nhamba yekoramu, kana iripo.
        if let Some(colno) = colno {
            write!(self.fmt.fmt, ":{}", colno)?;
        }

        write!(self.fmt.fmt, "\n")?;
        Ok(())
    }

    fn print_raw_fuchsia(&mut self, frame_ip: *mut c_void) -> fmt::Result {
        // Isu tinongotarisira nezve chiratidzo chekutanga chemafuremu
        if self.symbol_index == 0 {
            self.fmt.fmt.write_str("{{{bt:")?;
            write!(self.fmt.fmt, "{}:{:?}", self.fmt.frame_index, frame_ip)?;
            self.fmt.fmt.write_str("}}}\n")?;
        }
        Ok(())
    }
}

impl Drop for BacktraceFrameFmt<'_, '_, '_> {
    fn drop(&mut self) {
        self.fmt.frame_index += 1;
    }
}