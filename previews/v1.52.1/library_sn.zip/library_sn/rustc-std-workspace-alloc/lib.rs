#![feature(no_core)]
#![no_core]

// Ona rustc-std-workspace-core yekuti nei crate ichidikanwa.

// Dzorerazve zita re crate kuti udzivise kupokana neyakagoverwa module mu liballoc.
extern crate alloc as foo;

pub use foo::*;