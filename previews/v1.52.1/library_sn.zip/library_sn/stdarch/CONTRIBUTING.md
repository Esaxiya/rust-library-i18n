# Ichipa ku stdarch

Iyo `stdarch` crate inodarika kuda kugamuchira mipiro!Kutanga iwe ungangoda kuongorora iyo yekuchengetera uye uve nechokwadi chekuti bvunzo dzinokupfuura iwe:

```
$ git clone https://github.com/rust-lang/stdarch
$ cd stdarch
$ TARGET="<your-target-arch>" ci/run.sh
```

Iko `<your-target-arch>` ndiyo yakanangwa katatu sezvaishandiswa ne `rustup`, eg `x86_x64-unknown-linux-gnu` (isina chero yakatangira `nightly-` kana yakafanana).
Ziva zvakare kuti ino repository inoda chiteshi chehusiku che Rust!
Idzo bvunzo dziri pamusoro dzinotoda husiku rust kuve yakasarudzika pane yako system, kuseta iyo shandisa `rustup default nightly` (uye `rustup default stable` kudzosera).

Kana chero matanho ari pamusoro asingashande, [please let us know][new]!

Tevere kumusoro iwe unogona [find an issue][issues] kubatsira kunze, isu tasarudza mashoma ane [`help wanted`][help] uye [`impl-period`][impl] ma tag ayo anogona kunyanya kushandisa rumwe rubatsiro. 
Unogona kunge uchifarira zvikuru [#40][vendor], uchiita zvese zvevatengesi zvenguva pa x86.Iyo nyaya ine mamwe makanongedzo akanaka nezve kwekutangira!

Kana iwe uine mibvunzo yakajairika inzwa wakasununguka kune [join us on gitter][gitter] uye bvunza kutenderedza!Inzwa wakasununguka kubaya chero@BurntSushi kana@alexcrichton nemibvunzo.

[gitter]: https://gitter.im/rust-impl-period/WG-libs-simd

# Maitiro ekunyora mienzaniso ye stdarch intrinsics

Iko kune mashoma maficha anofanirwa kuve akagoneswa kune yakapihwa yemukati kuti ishande nemazvo uye iyo muenzaniso inofanirwa kungomhanyiswa chete ne `cargo test --doc` kana chimiro chikatsigirwa neCPU.

Nekuda kweizvozvo, iyo default `fn main` inogadzirwa ne `rustdoc` haishande (kazhinji).
Funga kushandisa zvinotevera segwara kuona yako muenzaniso ichishanda sezvanga zvichitarisirwa.

```rust
/// # // Isu tinoda cfg_target_feature kuona kuti muenzaniso ndewe chete
/// # // inomhanya ne `cargo test --doc` apo iyo CPU inotsigira chimiro
/// # #![feature(cfg_target_feature)]
/// # // Isu tinoda target_feature yeiyo yemukati kuti ishande
/// # #![feature(target_feature)]
/// #
/// # // rustdoc nekumisikidza inoshandisa `extern crate stdarch`, asi isu tinoda iyo
/// # // `#[macro_use]`
/// # # [macro_use] extern crate stdarch;
/// #
/// # // Basa chairoiro chairo
/// # fn main() {
/// #     // Mhanya chete izvi kana `<target feature>` ikatsigirwa
/// #     kana cfg_feature_enabled! ("<target feature>"){
/// #         // Gadzira `worker` basa rinongoitwa chete kana chinhu chakanangwa
/// #         // inotsigirwa uye kuona kuti `target_feature` inogoneswa kune mushandi wako
/// #         // function
/// #         #[target_feature(enable = "<target feature>")]
/// #         zvisina kuchengeteka fn worker() {
/// // Nyora muenzaniso wako pano.Feature chaiwo intrinsics achashanda pano!Enda musango!
///
/// #         }
///
/// #         isina kuchengeteka { worker(); }
/// #     }
/// # }
```

Kana imwe syntax iri pamusoro isingaratidzike seyakajairika, iyo [Documentation as tests] chikamu che [Rust Book] inotsanangura syntax ye `rustdoc` chaizvo.
Senguva dzose, inzwa wakasununguka ku [join us on gitter][gitter] uye utibvunze kana iwe ukarova chero snags, uye tinokutenda nekubatsira kunatsiridza zvinyorwa zve `stdarch`!

# Mamwe Miedzo Yekuyedza

Zvinowanzo kurudzirwa kuti iwe ushandise `ci/run.sh` kumhanyisa bvunzo.
Nekudaro izvi zvinogona kusashandira iwe, semuenzaniso kana uri pa Windows.

Muchiitiko ichocho unogona kudonha kumhanya `cargo +nightly test` uye `cargo +nightly test --release -p core_arch` yekuyedza kodhi yekodhi.
Ziva kuti izvi zvinoda kuti chishandiso chehusiku chehusiku chiiswe uye ye `rustc` kuti izive nezve chako chakanangwa katatu uye CPU yayo.
Kunyanya iwe unofanirwa kuseta iyo `TARGET` nharaunda inoshanduka sezvaungaita ye `ci/run.sh`.
Mukuwedzera iwe unofanirwa kuseta `RUSTCFLAGS` (inoda iyo `C`) kuratidza tarisiro maficha, semuenzaniso `RUSTCFLAGS="-C -target-features=+avx2"`.
Iwe unogona zvakare kuseta `-C -target-cpu=native` kana iwe uri "just" uchikura uchipesana neyako yazvino CPU.

Yambirwa kuti kana iwe ukashandisa aya mamwe mairairo, [things may go less smoothly than they would with `ci/run.sh`][ci-run-good], semuenzaniso
kuraira kwedzidzo bvunzo dzinogona kutadza nekuti disassembler akavatumidza zvakasiyana, semuenzaniso
inogona kuburitsa `vaesenc` pachinzvimbo che `aesenc` mirairo kunyangwe ivo vachiita zvakafanana.
Zvakare mirairo iyi inoita bvunzo shoma pane zvaiwanzoitwa, saka usashamisika kuti paunopedzisira wadhonza-kukumbira zvimwe zvikanganiso zvinogona kuratidza bvunzo dzisina kuvharwa pano.

[new]: https://github.com/rust-lang/stdarch/issues/new
[issues]: https://github.com/rust-lang/stdarch/issues
[help]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22
[impl]: https://github.com/rust-lang/stdarch/issues?q=is%3Aissue+is%3Aopen+label%3Aimpl-period
[vendor]: https://github.com/rust-lang/stdarch/issues/40
[Documentation as tests]: https://doc.rust-lang.org/book/first-edition/documentation.html#documentation-as-tests
[Rust Book]: https://doc.rust-lang.org/book/first-edition
[ci-run-good]: https://github.com/rust-lang/stdarch/issues/931#issuecomment-711412126






