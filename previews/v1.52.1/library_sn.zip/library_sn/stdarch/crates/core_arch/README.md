`core::arch` - Rust yepakati raibhurari yekuvakisa-yakatarwa masisitimu
=======

[![core_arch_crate_badge]][core_arch_crate_link] [![core_arch_docs_badge]][core_arch_docs_link]

Iyo `core::arch` module inoshandisa mapurani-anoenderana nemainsins (eg SIMD).

# Usage 

`core::arch` inowanikwa sechikamu che `libcore` uye inotumiswazve kunze ne `libstd`.Sarudza kuishandisa kuburikidza ne `core::arch` kana `std::arch` kupfuura kuburikidza neiyi crate.
Zvinhu zvisina kugadzikana zvinowanzo kuwanika muhusiku Rust kuburikidza ne `feature(stdsimd)`.

Uchishandisa `core::arch` kuburikidza ne crate inoda husiku Rust, uye inogona (uye inoita) kutyora kazhinji.Mhosva chete dzaunofanirwa kufunga nezvekuishandisa kuburikidza ne crate ndeidzi:

* kana iwe uchida kuzvinyorazve `core::arch` iwe, semuenzaniso, pamwe nechinangwa-maficha akagoneswa ayo asina kupihwa simba re `libcore`/`libstd`.
Note: kana iwe uchida kuinyorazve iyo isiri-yakajairwa tarisiro, ndokumbira usarudze kushandisa `xargo` uye kuumbazve `libcore`/`libstd` sezvakakodzera panzvimbo pekushandisa iyi crate.
  
* kushandisa zvimwe zvinhu zvinogona kunge zvisingawanikwe kunyangwe kuseri kwekusagadzikana kwe Rust maficha.Isu tinoedza kuchengetedza izvi kushoma.
Kana iwe uchida kushandisa zvimwe zvezvinhu izvi, ndokumbira uvhure nyaya kuti tikwanise kuifumura muhusiku Rust uye iwe ugone kuishandisa kubva ipapo.

# Documentation

* [Documentation - i686][i686]
* [Documentation - x86\_64][x86_64]
* [Documentation - arm][arm]
* [Documentation - aarch64][aarch64]
* [Documentation - powerpc][powerpc]
* [Documentation - powerpc64][powerpc64]
* [How to get started][contrib]
* [How to help implement intrinsics][help-implement]

[contrib]: https://github.com/rust-lang/stdarch/blob/master/CONTRIBUTING.md
[help-implement]: https://github.com/rust-lang/stdarch/issues/40
[i686]: https://rust-lang.github.io/stdarch/i686/core_arch/
[x86_64]: https://rust-lang.github.io/stdarch/x86_64/core_arch/
[arm]: https://rust-lang.github.io/stdarch/arm/core_arch/
[aarch64]: https://rust-lang.github.io/stdarch/aarch64/core_arch/
[powerpc]: https://rust-lang.github.io/stdarch/powerpc/core_arch/
[powerpc64]: https://rust-lang.github.io/stdarch/powerpc64/core_arch/

# License

`core_arch` inogoverwa zvakanyanya pasi pematemu ese ari maviri MIT rezinesi uye Apache License (Vhezheni 2.0), ine zvikamu zvakafukidzwa neakasiyana marezinesi eBDS.

Ona LICENSE-APACHE, uye LICENSE-MIT kuti uwane rumwe ruzivo.

# Contribution

Kunze kwekunge iwe ukanyatso taura neimwe nzira, chero mupiro wakapihwa nemaune kuiswa mu `core_arch` newe, sekutsanangurwa kwazvinoitwa mu Apache-2.0 rezinesi, ichave maviri marezinesi seari pamusoro, pasina mamwe mazwi kana mamiriro.


[core_arch_crate_badge]: https://img.shields.io/crates/v/core_arch.svg
[core_arch_crate_link]: https://crates.io/crates/core_arch
[core_arch_docs_badge]: https://docs.rs/core_arch/badge.svg
[core_arch_docs_link]: https://docs.rs/core_arch/












