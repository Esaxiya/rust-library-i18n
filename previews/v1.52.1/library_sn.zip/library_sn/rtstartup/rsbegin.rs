// rsbegin.o uye rsend.o ndiyo inonzi "compiler runtime startup objects".
// Iwo ane kodhi inodikanwa kuti itange nemazvo compiler runtime.
//
// Kana chifananidzo chinogoneka kana dylib chakabatanidzwa, ese mushandisi kodhi nemaraibhurari ari "sandwiched" pakati peaya mafaera echinhu, saka kodhi kana data kubva ku rsbegin.o inova yekutanga muzvikamu zvakasiyana zvemufananidzo, nepo kodhi uye data kubva ku rsend.o kuva zvekupedzisira.
// Mhedzisiro iyi inogona kushandiswa kuisa zviratidzo pakutanga kana kumagumo echikamu, pamwe nekuisa chero anodiwa mahedhiyo kana tsoka.
//
// Ziva kuti iyo chaiyo module yekupinda poindi inowanikwa muC yekumhanyisa nguva yekutanga chinhu (inowanzoidzwa inonzi `crtX.o`), iyo inosheedzera kutanga kwekutanga mabhureki ezvimwe zvinhu zvenguva yekumhanya (yakanyoreswa kuburikidza neimwezve yakasarudzika chikamu chechikamu).
//
//
//
//
//
//

#![feature(no_core)]
#![feature(lang_items)]
#![feature(auto_traits)]
#![crate_type = "rlib"]
#![no_core]
#![allow(non_camel_case_types)]

#[lang = "sized"]
trait Sized {}
#[lang = "sync"]
auto trait Sync {}
#[lang = "copy"]
trait Copy {}
#[lang = "freeze"]
auto trait Freeze {}

#[lang = "drop_in_place"]
#[inline]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    drop_in_place(to_drop);
}

#[cfg(all(target_os = "windows", target_arch = "x86", target_env = "gnu"))]
pub mod eh_frames {
    #[no_mangle]
    #[link_section = ".eh_frame"]
    // Makisi kutanga kweiyo stack furemu kusunungura info chikamu
    pub static __EH_FRAME_BEGIN__: [u8; 0] = [];

    // Tsvaira nzvimbo yeindress yemukati-yekuchengetedza bhuku.
    // Izvi zvinotsanangurwa se `struct object` mu $ GCC/unwind-dw2-fde.h.
    static mut OBJ: [isize; 6] = [0; 6];

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                impl ::Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    // Unwind info registration/deregistration maitiro.
    // Ona maodhi e libpanic_unwind.
    extern "C" {
        fn rust_eh_register_frames(eh_frame_begin: *const u8, object: *mut u8);
        fn rust_eh_unregister_frames(eh_frame_begin: *const u8, object: *mut u8);
    }

    unsafe extern "C" fn init() {
        // rejista kusunungura info pane module kutanga
        rust_eh_register_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    unsafe extern "C" fn uninit() {
        // kunyoresa pakuvhara
        rust_eh_unregister_frames(&__EH_FRAME_BEGIN__ as *const u8, &mut OBJ as *mut _ as *mut u8);
    }

    // MinGW-yakatarwa init/uninit maitiro ekunyoresa
    pub mod mingw_init {
        // Zvinhu zvekutanga zveMinGW (crt0.o/dllcrt0.o) zvinokumbira vavaki vepasirese muzvikamu zve .ctors uye .dtors pakutanga uye kubuda.
        // Muchiitiko cheDLLs, izvi zvinoitwa kana iyo DLL yatakurwa uye kuburitswa.
        //
        // Iyo yekubatanidza ichagadzirisa zvikamu, izvo zvinoona kuti edu ekudzosera kumashure ari kumagumo erondedzero.
        // Sezvo vavaki vachimhanyisa zvakateedzana, izvi zvinovimbisa kuti edu ekudzosera kumashure ndiwo ekutanga uye ekupedzisira akaurayiwa.
        //
        //

        #[link_section = ".ctors.65535"] // .ctors. *: C kutanga callbacks
        pub static P_INIT: unsafe extern "C" fn() = super::init;

        #[link_section = ".dtors.65535"] // .dtors. *: C kugumisa callbacks
        pub static P_UNINIT: unsafe extern "C" fn() = super::uninit;
    }
}