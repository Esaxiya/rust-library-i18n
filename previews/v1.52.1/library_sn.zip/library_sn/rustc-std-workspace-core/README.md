# Iyo `rustc-std-workspace-core` crate

Iyi crate ndeye shim uye isina chinhu crate iyo inongotarisana ne `libcore` uye kuongororazve zvese zvirimo.
crate ndiyo crux yekupa raibhurari yakajairwa kutsamira pa crates kubva ku crates.io

Crates pa crates.io kuti raibhurari yakajairwa inoenderana nezvinodiwa kuvimba ne `rustc-std-workspace-core` crate kubva ku crates.io, iyo isina chinhu.

Isu tinoshandisa `[patch]` kuipfuudza kune ino crate mune ino repository.
Nekuda kweizvozvo, crates pa crates.io ichatora inotsamira edge kusvika `libcore`, iyo vhezheni inotsanangurwa mune ino repository.
Izvo zvinofanirwa kukwevera ese ekuvimbika mativi kuona Cargo inovaka crates zvinobudirira!

Ziva kuti crates pa crates.io inoda kuvimba neiyi crate ine zita `core` kuti zvese zvishande nemazvo.Kuti vaite izvo zvavanogona kushandisa:

```toml
core = { version = "1.0.0", optional = true, package = 'rustc-std-workspace-core' }
```

Kubudikidza nekushandiswa kweiyo `package` kiyi iyo crate inotumidzwazve zita rekuti `core`, zvichireva kuti ichaita senge

```
--extern core=.../librustc_std_workspace_core-XXXXXXX.rlib
```

apo Cargo inosheedzera iyo compiler, ichigutsa iyo yakasarudzika `extern crate core` rairo jekiseni nemusanganisi.




