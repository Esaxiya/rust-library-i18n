# Iyo `rustc-std-workspace-std` crate

Ona zvinyorwa zve `rustc-std-workspace-core` crate.