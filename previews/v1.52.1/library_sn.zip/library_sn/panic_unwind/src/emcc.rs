//! Kusunungura kwe *emscripten* chinangwa.
//!
//! Ipo Rust yakajairwa kusunungura kuitisa kwe Unix mapuratifomu anodana mu libunwind APIs zvakananga, paEmscripten isu panzvimbo iyoyo tinoshevedza muC++ kusunungura maAPIs.
//! Uku kungori kufarirwa sezvo nguva yekumhanya yeEmscripten inogara ichizadzisa iwo maAPI uye isingaite libunwind.
//!
//!
//!

use alloc::boxed::Box;
use core::any::Any;
use core::intrinsics;
use core::mem;
use core::ptr;
use core::sync::atomic::{AtomicBool, Ordering};
use libc::{self, c_int};
use unwind as uw;

// Izvi zvinoenderana nemamiriro e std::type_info muC++
#[repr(C)]
struct TypeInfo {
    vtable: *const usize,
    name: *const u8,
}
unsafe impl Sync for TypeInfo {}

extern "C" {
    // Iyo inotungamira `\x01` byte pano iri chaiyo chiratidzo chemashiripiti kuLLVM ku *kwete* kushandisa chero kumwe kunhuhwirira sekufananidza nehunhu hwe `_`.
    //
    //
    // Ichi chiratidzo ndiyo vtable inoshandiswa neC++ 's `std::type_info`.
    // Zvinhu zverudzi `std::type_info`, zvitsananguro zvemhando, zvine pointer kune tafura iyi.
    // Rondedzero dzerudzi dzinotsanangurwa neC++ EH zvivakwa zvinotsanangurwa pamusoro uye zvatinovaka pazasi.
    //
    // Ziva kuti saizi chaiyo yakakura kudarika katatu usize, asi isu tinongoda vtable yedu kunongedza kuchinhu chechitatu.
    //
    //
    #[link_name = "\x01_ZTVN10__cxxabiv117__class_type_infoE"]
    static CLASS_TYPE_INFO_VTABLE: [usize; 3];
}

// std::type_info yekirasi_nguva yekirasi
#[lang = "eh_catch_typeinfo"]
static EXCEPTION_TYPE_INFO: TypeInfo = TypeInfo {
    // Kazhinji taizoshandisa .as_ptr().add(2) asi izvi hazvishande mune yechimiro mamiriro.
    vtable: unsafe { &CLASS_TYPE_INFO_VTABLE[2] },
    // Izvi nemaune hazvishandise rakajairika zita mangling scheme nekuti isu hatidi kuti C++ igone kuburitsa kana kubata Rust panics.
    //
    name: b"rust_panic\0".as_ptr(),
};

struct Exception {
    // Izvi zvinodikanwa nekuti C++ kodhi inogona kutora maitiro edu ne std::exception_ptr uye kuidzorera kakawanda, pamwe kunyangwe mune imwe tambo.
    //
    //
    caught: AtomicBool,

    // Izvi zvinofanirwa kuve Sarudzo nekuti hupenyu hwechinhu chinotevera C++ semantics: kana kubata_unwind kuburitsa Bhokisi kunze kwekunze rinofanira kunge richiri kusiya chinhu chakasarudzika munzvimbo inoshanda nekuti muparadzi wacho achiri kudaidzwa na __cxa_end_catch.
    //
    //
    //
    data: Option<Box<dyn Any + Send>>,
}

pub unsafe fn cleanup(ptr: *mut u8) -> Box<dyn Any + Send> {
    // intrinsics::try chaizvo inotipa pointer kune ichi chimiro.
    #[repr(C)]
    struct CatchData {
        ptr: *mut u8,
        is_rust_panic: bool,
    }
    let catch_data = &*(ptr as *mut CatchData);

    let adjusted_ptr = __cxa_begin_catch(catch_data.ptr as *mut libc::c_void) as *mut Exception;
    let out = if catch_data.is_rust_panic {
        let was_caught = (*adjusted_ptr).caught.swap(true, Ordering::SeqCst);
        if was_caught {
            // Sezvo cleanup() isingatenderwe ku panic, isu tinongobvisa pachinzvimbo.
            intrinsics::abort();
        }
        (*adjusted_ptr).data.take().unwrap()
    } else {
        super::__rust_foreign_exception();
    };
    __cxa_end_catch();
    out
}

pub unsafe fn panic(data: Box<dyn Any + Send>) -> u32 {
    let sz = mem::size_of_val(&data);
    let exception = __cxa_allocate_exception(sz) as *mut Exception;
    if exception.is_null() {
        return uw::_URC_FATAL_PHASE1_ERROR as u32;
    }
    ptr::write(exception, Exception { caught: AtomicBool::new(false), data: Some(data) });
    __cxa_throw(exception as *mut _, &EXCEPTION_TYPE_INFO, exception_cleanup);
}

extern "C" fn exception_cleanup(ptr: *mut libc::c_void) -> *mut libc::c_void {
    unsafe {
        if let Some(b) = (ptr as *mut Exception).read().data {
            drop(b);
            super::__rust_drop_panic();
        }
        ptr
    }
}

#[lang = "eh_personality"]
unsafe extern "C" fn rust_eh_personality(
    version: c_int,
    actions: uw::_Unwind_Action,
    exception_class: uw::_Unwind_Exception_Class,
    exception_object: *mut uw::_Unwind_Exception,
    context: *mut uw::_Unwind_Context,
) -> uw::_Unwind_Reason_Code {
    __gxx_personality_v0(version, actions, exception_class, exception_object, context)
}

extern "C" {
    fn __cxa_allocate_exception(thrown_size: libc::size_t) -> *mut libc::c_void;
    fn __cxa_begin_catch(thrown_exception: *mut libc::c_void) -> *mut libc::c_void;
    fn __cxa_end_catch();
    fn __cxa_throw(
        thrown_exception: *mut libc::c_void,
        tinfo: *const TypeInfo,
        dest: extern "C" fn(*mut libc::c_void) -> *mut libc::c_void,
    ) -> !;
    fn __gxx_personality_v0(
        version: c_int,
        actions: uw::_Unwind_Action,
        exception_class: uw::_Unwind_Exception_Class,
        exception_object: *mut uw::_Unwind_Exception,
        context: *mut uw::_Unwind_Context,
    ) -> uw::_Unwind_Reason_Code;
}