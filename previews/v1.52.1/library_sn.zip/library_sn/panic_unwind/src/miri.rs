//! Kusunungura panics yaMiri.
use alloc::boxed::Box;
use core::any::Any;

// Rudzi rwekubhadharisa iyo injini yeMiri inoparadzira kuburikidza nekusunungura kwatiri.
// Inofanirwa kunge iri pointer.
type Payload = Box<Box<dyn Any + Send>>;

extern "Rust" {
    /// Miri-yakapihwa extern basa kutanga kusunungura.
    fn miri_start_panic(payload: *mut u8) -> !;
}

pub unsafe fn panic(payload: Box<dyn Any + Send>) -> u32 {
    // Mubhadharo watinopfuudza ku `miri_start_panic` unenge uri iwo nharo watinowana mu `cleanup` pazasi.
    // Saka isu tinongo zvibhokisi kamwe chete, kuti titore chimwe chinhu chakayera-saizi.
    let payload_box: Payload = Box::new(payload);
    miri_start_panic(Box::into_raw(payload_box) as *mut u8)
}

pub unsafe fn cleanup(payload_box: *mut u8) -> Box<dyn Any + Send> {
    // Dzoreredza iri pasi pe `Box`.
    let payload_box: Payload = Box::from_raw(payload_box as *mut _);
    *payload_box
}