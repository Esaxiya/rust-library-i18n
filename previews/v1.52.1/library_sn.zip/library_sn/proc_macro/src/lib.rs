//! Raibhurari yekutsigira yevanyori ve macro pavanotsanangura macros matsva.
//!
//! Raibhurari iyi, yakapihwa neyakagovaniswa kugovera, inopa mhando dzinodyiwa mukati mekupindirana kwetsananguro dzakatsanangurwa macro dzakadai sekushanda-kunge macro `#[proc_macro]`, macro hunhu `#[proc_macro_attribute]` uye tsika dzinowana hunhu`#[proc_macro_derive]`.
//!
//!
//! Ona [the book] zvimwe.
//!
//! [the book]: ../book/ch19-06-macros.html#procedural-macros-for-generating-code-from-attributes
//!
//!

#![stable(feature = "proc_macro_lib", since = "1.15.0")]
#![deny(missing_docs)]
#![doc(
    html_root_url = "https://doc.rust-lang.org/nightly/",
    html_playground_url = "https://play.rust-lang.org/",
    issue_tracker_base_url = "https://github.com/rust-lang/rust/issues/",
    test(no_crate_inject, attr(deny(warnings))),
    test(attr(allow(dead_code, deprecated, unused_variables, unused_mut)))
)]
#![feature(rustc_allow_const_fn_unstable)]
#![feature(nll)]
#![feature(staged_api)]
#![feature(const_fn)]
#![feature(const_fn_fn_ptr_basics)]
#![feature(allow_internal_unstable)]
#![feature(decl_macro)]
#![feature(extern_types)]
#![feature(in_band_lifetimes)]
#![feature(negative_impls)]
#![feature(auto_traits)]
#![feature(restricted_std)]
#![feature(rustc_attrs)]
#![feature(min_specialization)]
#![recursion_limit = "256"]

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
pub mod bridge;

mod diagnostic;

#[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
pub use diagnostic::{Diagnostic, Level, MultiSpan};

use std::cmp::Ordering;
use std::ops::{Bound, RangeBounds};
use std::path::PathBuf;
use std::str::FromStr;
use std::{error, fmt, iter, mem};

/// Inotarisa kuti proc_macro yakaitwa kuti iwanikwe kuchirongwa chirikuitika.
///
/// Iyo proc_macro crate inongogadzirirwa kushandiswa mukati mekuitwa kwemaitiro macros.Ese mashandiro mune ino crate panic kana ikakumbirwa kubva kunze kwenzira macro, senge kubva pakuvaka script kana yuniti bvunzo kana zvakajairika Rust binary.
///
/// Tichifunga nezve Rust maraibhurari akagadzirirwa kutsigira macro uye asiri-macro mashandisiro kesi, `proc_macro::is_available()` inopa isingavhunduke nzira yekuona kana zvivakwa zvichidikanwa kushandisa iyo API ye proc_macro iripo.
/// Inodzosera ichokwadi kana ikakumbirwa kubva mukati meyako macro, manyepo kana ikakumbirwa kubva kune chero imwe bhanari.
///
///
///
///
///
///
///
#[unstable(feature = "proc_macro_is_available", issue = "71436")]
pub fn is_available() -> bool {
    bridge::Bridge::is_available()
}

/// Rudzi rukuru rwakapihwa neiyi crate, inomiririra rwizi rwe tokens, kana, zvakanyanya, kuteedzana kwe token miti.
/// Rudzi runopa mafafitera ekuti iterating pamusoro peiyo token miti uye, nekupesana, kuunganidza akati wandei e token miti murukova rumwe.
///
///
/// Izvi zvese zviri zviviri kuiswa uye kubuda kwe `#[proc_macro]`, `#[proc_macro_attribute]` uye `#[proc_macro_derive]` tsananguro.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Clone)]
pub struct TokenStream(bridge::client::TokenStream);

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for TokenStream {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for TokenStream {}

/// Kanganiso yakadzoserwa kubva ku `TokenStream::from_str`.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
#[derive(Debug)]
pub struct LexError {
    _inner: (),
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl fmt::Display for LexError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot parse string into token stream")
    }
}

#[stable(feature = "proc_macro_lexerror_impls", since = "1.44.0")]
impl error::Error for LexError {}

#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Send for LexError {}
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl !Sync for LexError {}

impl TokenStream {
    /// Inodzorera `TokenStream` isina chinhu isina token miti.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new() -> TokenStream {
        TokenStream(bridge::client::TokenStream::new())
    }

    /// Cheki kana iyi `TokenStream` isina chinhu.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }
}

/// Kuedza kudambura tambo kuita tokens uye kuenzanisa avo tokens kupinda token rwizi.
/// Inogona kukundikana nekuda kwezvikonzero zvinoverengeka, semuenzaniso, kana tambo iine zvisina kuenzana delimiters kana mavara asipo mumutauro.
///
/// Ese tokens murukova rwakatambanudzwa anowana `Span::call_site()` spans.
///
/// NOTE: zvimwe zvikanganiso zvinogona kukonzera panics panzvimbo yekudzosa `LexError`.Isu tinochengetera kodzero yekuchinja idzi mhosho kuva `LexError`s gare gare.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl FromStr for TokenStream {
    type Err = LexError;

    fn from_str(src: &str) -> Result<TokenStream, LexError> {
        Ok(TokenStream(bridge::client::TokenStream::from_str(src)))
    }
}

// NB, iro bhiriji rinongopa `to_string`, shandisa `fmt::Display` zvichibva pairi (iyo reverse yehukama hwese pakati pevaviri).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenStream {
    fn to_string(&self) -> String {
        self.0.to_string()
    }
}

/// Tinodhindisa rwizi rwe token kunge tambo iyo inofanirwa kunge isingachinjike ichidzokera kumashure muiyo token rukova (modulo spans), kunze kwekungodaro `TokenTree: : Group`s ine `Delimiter::None` delimiters uye isina nhamba manhamba.
///
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Display for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Anodhindira token muchimiro chakanakira kugadzirisa debugging.
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl fmt::Debug for TokenStream {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("TokenStream ")?;
        f.debug_list().entries(self.clone()).finish()
    }
}

#[stable(feature = "proc_macro_token_stream_default", since = "1.45.0")]
impl Default for TokenStream {
    fn default() -> Self {
        TokenStream::new()
    }
}

#[unstable(feature = "proc_macro_quote", issue = "54722")]
pub use quote::{quote, quote_span};

/// Inogadzira token rwizi ine imwechete token muti.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<TokenTree> for TokenStream {
    fn from(tree: TokenTree) -> TokenStream {
        TokenStream(bridge::client::TokenStream::from_token_tree(match tree {
            TokenTree::Group(tt) => bridge::TokenTree::Group(tt.0),
            TokenTree::Punct(tt) => bridge::TokenTree::Punct(tt.0),
            TokenTree::Ident(tt) => bridge::TokenTree::Ident(tt.0),
            TokenTree::Literal(tt) => bridge::TokenTree::Literal(tt.0),
        }))
    }
}

/// Inounganidza yakati wandei ye token miti murukova rumwe chete.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl iter::FromIterator<TokenTree> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenTree>>(trees: I) -> Self {
        trees.into_iter().map(TokenStream::from).collect()
    }
}

/// Kushanda kwe "flattening" pa token hova, inounganidza token miti kubva kune dzakawanda token hova kuita rukova rumwe chete.
///
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl iter::FromIterator<TokenStream> for TokenStream {
    fn from_iter<I: IntoIterator<Item = TokenStream>>(streams: I) -> Self {
        let mut builder = bridge::client::TokenStreamBuilder::new();
        streams.into_iter().for_each(|stream| builder.push(stream.0));
        TokenStream(builder.build())
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenTree> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenTree>>(&mut self, trees: I) {
        self.extend(trees.into_iter().map(TokenStream::from));
    }
}

#[stable(feature = "token_stream_extend", since = "1.30.0")]
impl Extend<TokenStream> for TokenStream {
    fn extend<I: IntoIterator<Item = TokenStream>>(&mut self, streams: I) {
        // FIXME(eddyb) Shandisa yakagadziriswa kuitisa if/when inogoneka.
        *self = iter::once(mem::replace(self, Self::new())).chain(streams).collect();
    }
}

/// Ruzhinji rwekushandisa ruzivo rweiyo `TokenStream` mhando, senge maiterator.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub mod token_stream {
    use crate::{bridge, Group, Ident, Literal, Punct, TokenStream, TokenTree};

    /// Iyo iterator pamusoro pe `TokenStream '' TokenTree`s.
    /// Iyo iteration i "shallow", semuenzaniso, iyo iterator haidzokere mumapoka akaganhurwa, uye inodzosera mapoka ese se token miti.
    ///
    #[derive(Clone)]
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub struct IntoIter(bridge::client::TokenStreamIter);

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl Iterator for IntoIter {
        type Item = TokenTree;

        fn next(&mut self) -> Option<TokenTree> {
            self.0.next().map(|tree| match tree {
                bridge::TokenTree::Group(tt) => TokenTree::Group(Group(tt)),
                bridge::TokenTree::Punct(tt) => TokenTree::Punct(Punct(tt)),
                bridge::TokenTree::Ident(tt) => TokenTree::Ident(Ident(tt)),
                bridge::TokenTree::Literal(tt) => TokenTree::Literal(Literal(tt)),
            })
        }
    }

    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    impl IntoIterator for TokenStream {
        type Item = TokenTree;
        type IntoIter = IntoIter;

        fn into_iter(self) -> IntoIter {
            IntoIter(self.0.into_iter())
        }
    }
}

/// `quote!(..)` inogamuchira zvinomiririra tokens uye inowedzera kuita `TokenStream` inotsanangura kuiswa.
/// Semuenzaniso, `quote!(a + b)` inogadzira chirevo, icho, kana chikaongororwa, chinogadzira iyo `TokenStream` `[Ident("a"), Punct('+', Alone), Ident("b")]`.
///
///
/// Kubvunzurudza kunoitwa ne `$`, uye kunoshanda nekutora imwechete inotevera chiziviso sezwi risina kutaurwa.
/// Kuti utore `$` pachayo, shandisa `$$`.
#[unstable(feature = "proc_macro_quote", issue = "54722")]
#[allow_internal_unstable(proc_macro_def_site)]
#[rustc_builtin_macro]
pub macro quote($($t:tt)*) {
    /* compiler built-in */
}

#[unstable(feature = "proc_macro_internals", issue = "27812")]
#[doc(hidden)]
mod quote;

/// Dunhu rekodhi kodhi, pamwe neruzivo rwekuwedzera macro.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Copy, Clone)]
pub struct Span(bridge::client::Span);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Span {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Span {}

macro_rules! diagnostic_method {
    ($name:ident, $level:expr) => {
        /// Inogadzira `Diagnostic` nyowani ine yakapihwa `message` pasipanishi `self`.
        ///
        #[unstable(feature = "proc_macro_diagnostic", issue = "54140")]
        pub fn $name<T: Into<String>>(self, message: T) -> Diagnostic {
            Diagnostic::spanned(self, $level, message)
        }
    };
}

impl Span {
    /// Iyo span inogadzirisa pane macro tsananguro saiti.
    #[unstable(feature = "proc_macro_def_site", issue = "54724")]
    pub fn def_site() -> Span {
        Span(bridge::client::Span::def_site())
    }

    /// Iyo nguva yekukumbira kweanhasi maitiro maitiro.
    /// Zviziviso zvakagadzirwa nehurefu uhwu zvichagadziriswa sekunge zvakanyorwa zvakanangana kunzvimbo yekufona (nzvimbo yekufona-saiti) uye imwe kodhi pane macro yekufona saiti inozogona kureva kwavari zvakare.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn call_site() -> Span {
        Span(bridge::client::Span::call_site())
    }

    /// Iyo span inomiririra hutsanana hwe `macro_rules`, uye dzimwe nguva inogadziriswa pa macro tsananguro saiti (misiyano yemuno, zvinyorwa, `$crate`) uye dzimwe nguva kune macro yekufona saiti (zvese zvimwe).
    ///
    /// Iyo span nzvimbo inotorwa kubva kune yekufona-saiti.
    ///
    #[stable(feature = "proc_macro_mixed_site", since = "1.45.0")]
    pub fn mixed_site() -> Span {
        Span(bridge::client::Span::mixed_site())
    }

    /// Iyo yekutanga sosi faira mune ino span inonongedza.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_file(&self) -> SourceFile {
        SourceFile(self.0.source_file())
    }

    /// Iyo `Span` ye tokens mune yapfuura macro yekuwedzera kubva iyo `self` yakagadzirwa kubva, kana iripo.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn parent(&self) -> Option<Span> {
        self.0.parent().map(Span)
    }

    /// Iyo span yekodhi yekodhi yekodhi iyo `self` yakagadzirwa kubva.
    /// Kana iyi `Span` isina kugadzirwa kubva kumamwe macro ekuwedzera ipapo kukosha kwekudzoka kwakafanana ne `*self`.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source(&self) -> Span {
        Span(self.0.source())
    }

    /// Inotora iyo yekutanga line/column mune sosi faira yeiyo span.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn start(&self) -> LineColumn {
        self.0.start()
    }

    /// Inotora iyo yekupedzisira line/column mune sosi faira yeiyo span.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn end(&self) -> LineColumn {
        self.0.end()
    }

    /// Inogadzira itsva span inosanganisira `self` uye `other`.
    ///
    /// Inodzorera `None` kana `self` uye `other` zvichibva kumafaira akasiyana.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn join(&self, other: Span) -> Option<Span> {
        self.0.join(other.0).map(Span)
    }

    /// Inogadzira span nyowani ine yakafanana line/column ruzivo se `self` asi izvo zvinogadzirisa zviratidzo sekunge zvaive pa `other`.
    ///
    #[stable(feature = "proc_macro_span_resolved_at", since = "1.45.0")]
    pub fn resolved_at(&self, other: Span) -> Span {
        Span(self.0.resolved_at(other.0))
    }

    /// Inogadzira chipanera chitsva chine maitiro akafanana ekugadzirisa maitiro se `self` asi iine line/column ruzivo rwe `other`.
    ///
    #[stable(feature = "proc_macro_span_located_at", since = "1.45.0")]
    pub fn located_at(&self, other: Span) -> Span {
        other.resolved_at(*self)
    }

    /// Inofananidza kusvika kumatanho kuona kana ivo vakaenzana.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn eq(&self, other: &Span) -> bool {
        self.0 == other.0
    }

    /// Inodzorera chinyorwa chinyorwa kuseri kwespani.
    /// Izvi zvinochengetedza iyo yekutanga sosi kodhi, inosanganisira nzvimbo uye makomendi.
    /// Iyo inongodzosera mhedzisiro kana iyo span inowirirana kune chaiyo sosi kodhi.
    ///
    /// Note: Mhedzisiro inoonekwa yemacro inofanirwa kungovimba ne tokens uye kwete pane ino zvinyorwa.
    ///
    /// Mhedzisiro yeiri basa kuyedza kwakanakisa kushandiswa kuongororwa chete.
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn source_text(&self) -> Option<String> {
        self.0.source_text()
    }

    diagnostic_method!(error, Level::Error);
    diagnostic_method!(warning, Level::Warning);
    diagnostic_method!(note, Level::Note);
    diagnostic_method!(help, Level::Help);
}

/// Tinoprinda chipanera muchimiro chakanakira kugadzirisa.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Span {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Mutsara-wekolamu vaviri anomiririra kutanga kana kupera kwe `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct LineColumn {
    /// Iyo 1-yakamisikidzwa mutsara muiyo faira faira panotangira span kana kupera (inclusive).
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub line: usize,
    /// Iyo 0-indexed ikholamu (mune UTF-8 mavara) mune sosi faira panotangira span kana kupera (inclusive).
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub column: usize,
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Send for LineColumn {}
#[unstable(feature = "proc_macro_span", issue = "54725")]
impl !Sync for LineColumn {}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Ord for LineColumn {
    fn cmp(&self, other: &Self) -> Ordering {
        self.line.cmp(&other.line).then(self.column.cmp(&other.column))
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialOrd for LineColumn {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Iyo sosi faira reyakapihwa `Span`.
#[unstable(feature = "proc_macro_span", issue = "54725")]
#[derive(Clone)]
pub struct SourceFile(bridge::client::SourceFile);

impl SourceFile {
    /// Inotora nzira inoenda kune ino sosi faira.
    ///
    /// ### Note
    /// Kana iyo kodhi span yakabatana neiyi `SourceFile` yakagadzirwa neyekunze macro, iyi macro, iyi inogona kunge isiri iyo chaiyo nzira pane iyo fileystem.
    /// Shandisa [`is_real`] kutarisa.
    ///
    /// Ziva zvakare kuti kunyangwe `is_real` ichidzosa `true`, kana `--remap-path-prefix` ikapasiswa pamutsetse wekuraira, iyo nzira yakapihwa inogona kunge isiri yechokwadi.
    ///
    ///
    /// [`is_real`]: Self::is_real
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn path(&self) -> PathBuf {
        PathBuf::from(self.0.path())
    }

    /// Inodzorera `true` kana iri faira rechokwadi iri faira rechokwadi, uye isina kugadzirwa nekuwedzera kwemacro kwekunze.
    ///
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn is_real(&self) -> bool {
        // Uku kubira kudzamara nzvimbo dzepakati dzaitwa uye tinokwanisa kuve nemanyowani mafaira ematanho anogadzirwa mune ekunze macros.
        //
        // https://github.com/rust-lang/rust/pull/43604#issuecomment-333334368
        self.0.is_real()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl fmt::Debug for SourceFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("SourceFile")
            .field("path", &self.path())
            .field("is_real", &self.is_real())
            .finish()
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl PartialEq for SourceFile {
    fn eq(&self, other: &Self) -> bool {
        self.0.eq(&other.0)
    }
}

#[unstable(feature = "proc_macro_span", issue = "54725")]
impl Eq for SourceFile {}

/// token imwe chete kana kuteedzana kwakateerana kwe token miti (semuenzaniso, `[1, (), ..]`).
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub enum TokenTree {
    /// Rukova rwe token rwakakomberedzwa nemabracket delimiters.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Group(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Group),
    /// Chitupa.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Ident(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Ident),
    /// Imwe punctuation hunhu (`+ +`, `,`, `$`, nezvimwewo).
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Punct(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Punct),
    /// Hunhu chaihwo (`'a'`), tambo (`"hello"`), nhamba (`2.3`), nezvimwe.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Literal(#[stable(feature = "proc_macro_lib2", since = "1.29.0")] Literal),
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for TokenTree {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for TokenTree {}

impl TokenTree {
    /// Inodzosera kureba kwemuti uyu, kuendesa kune iyo `span` nzira yeiyo yaive token kana rwizi rwakatemerwa.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        match *self {
            TokenTree::Group(ref t) => t.span(),
            TokenTree::Ident(ref t) => t.span(),
            TokenTree::Punct(ref t) => t.span(),
            TokenTree::Literal(ref t) => t.span(),
        }
    }

    /// Inogadzira iyo span ye *chete iyi token*.
    ///
    /// Ziva kuti kana iyi token iri `Group` saka nzira iyi haizogadzirise span yeimwe neimwe yemukati tokens, izvi zvinongopa nzira ye `set_span` yemusiyano wega wega.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        match *self {
            TokenTree::Group(ref mut t) => t.set_span(span),
            TokenTree::Ident(ref mut t) => t.set_span(span),
            TokenTree::Punct(ref mut t) => t.set_span(span),
            TokenTree::Literal(ref mut t) => t.set_span(span),
        }
    }
}

/// Prints token muti muchimiro chakanakira kugadzirisa.
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Imwe yeaya ane zita mune rakarongeka mhando mune yakatorwa debug, saka usazvinetse pamwe neyekuwedzera dura rekunongedzera
        //
        match *self {
            TokenTree::Group(ref tt) => tt.fmt(f),
            TokenTree::Ident(ref tt) => tt.fmt(f),
            TokenTree::Punct(ref tt) => tt.fmt(f),
            TokenTree::Literal(ref tt) => tt.fmt(f),
        }
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Group> for TokenTree {
    fn from(g: Group) -> TokenTree {
        TokenTree::Group(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Ident> for TokenTree {
    fn from(g: Ident) -> TokenTree {
        TokenTree::Ident(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Punct> for TokenTree {
    fn from(g: Punct) -> TokenTree {
        TokenTree::Punct(g)
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl From<Literal> for TokenTree {
    fn from(g: Literal) -> TokenTree {
        TokenTree::Literal(g)
    }
}

// NB, iro bhiriji rinongopa `to_string`, shandisa `fmt::Display` zvichibva pairi (iyo reverse yehukama hwese pakati pevaviri).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for TokenTree {
    fn to_string(&self) -> String {
        match *self {
            TokenTree::Group(ref t) => t.to_string(),
            TokenTree::Ident(ref t) => t.to_string(),
            TokenTree::Punct(ref t) => t.to_string(),
            TokenTree::Literal(ref t) => t.to_string(),
        }
    }
}

/// Tinopurinda token muti kunge tambo iyo inofanirwa kunge isingarasike kushandurwa ichidzoka mu token imwechete yemuti (modulo spans), kunze kwekungodaro `TokenTree: : Group`s ine `Delimiter::None` delimiters uye isina nhamba manhamba.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for TokenTree {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

/// Yakatemerwa token rwizi.
///
/// `Group` mukati ine `TokenStream` iyo yakakomberedzwa ne`Delimiter`s.
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Group(bridge::client::Group);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Group {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Group {}

/// Inotsanangura maitiro akateedzana e token miti inogadziriswa.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Delimiter {
    /// `( ... )`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Parenthesis,
    /// `{ ... }`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Brace,
    /// `[ ... ]`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Bracket,
    /// `Ø ... Ø`
    /// Anomisikidzwa delimiter, anogona, semuenzaniso, kuoneka akatenderedza tokens ichibva ku "macro variable" `$var`.
    /// Izvo zvakakosha kuchengetedza zvinokosheswa neanoshanda muzviitiko zvakaita se `$var * 3` apo `$var` iri `1 + 2`.
    /// Vanodzora vakasarudzika vanogona kusararama kutenderera kwe token rwizi kuburikidza netambo.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    None,
}

impl Group {
    /// Inogadzira `Group` nyowani ine yakapihwa delimiter uye token rwizi.
    ///
    /// Uyu mugadziri achaisa span yeboka iri kusvika `Span::call_site()`.
    /// Kuti uchinje span iwe unogona kushandisa iyo `set_span` nzira pazasi.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(delimiter: Delimiter, stream: TokenStream) -> Group {
        Group(bridge::client::Group::new(delimiter, stream.0))
    }

    /// Inodzosera iyo delimita yeiyi `Group`
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn delimiter(&self) -> Delimiter {
        self.0.delimiter()
    }

    /// Inodzorera iyo `TokenStream` ye tokens iyo yakatemwa muiyi `Group`.
    ///
    /// Ziva kuti iyo yakadzoserwa token rwizi haina kusanganisira iyo delimita yakadzoserwa pamusoro.
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn stream(&self) -> TokenStream {
        TokenStream(self.0.stream())
    }

    /// Inodzorera iyo span kune vanogadzirisa ino token rwizi, yakatambanudza iyo `Group` yese.
    ///
    ///
    /// ```text
    /// pub fn span(&self) -> Span {
    ///            ^^^^^^^
    /// ```
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Inodzosera iyo span inonongedza kune yekuvhura delimita yeiri boka.
    ///
    /// ```text
    /// pub fn span_open(&self) -> Span {
    ///                 ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_open(&self) -> Span {
        Span(self.0.span_open())
    }

    /// Inodzosera iyo span inonongedzera kune yekuvhara delimita yeboka iri.
    ///
    /// ```text
    /// pub fn span_close(&self) -> Span {
    ///                        ^
    /// ```
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn span_close(&self) -> Span {
        Span(self.0.span_close())
    }

    /// Inogadzirisa iyo span yeiyi `Group`'s delimiters, asi kwete yayo yemukati tokens.
    ///
    /// Iyi nzira icha **kwete** kuseta span yezvose zvemukati tokens zvakarongedzwa neboka iri, asi asi zvinongomisa chete hurefu hweiyo delimiter tokens padanho re `Group`.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }
}

// NB, iro bhiriji rinongopa `to_string`, shandisa `fmt::Display` zvichibva pairi (iyo reverse yehukama hwese pakati pevaviri).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Group {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Tinodhindisa boka iri seyetambo inofanirwa kushandurika isingarasike ichidzokera muboka rimwe chete (modulo spans), kunze kwekuda kwekuti `TokenTree: : Group`s ine `Delimiter::None` delimiters.
///
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Group {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Group")
            .field("delimiter", &self.delimiter())
            .field("stream", &self.stream())
            .field("span", &self.span())
            .finish()
    }
}

/// `Punct` imwe punctuation hunhu se `+`, `-` kana `#`.
///
/// Vazhinji-hunhu vanoshanda se `+=` vanomiririrwa sezviitiko zviviri zve `Punct` nemhando dzakasiyana dze `Spacing` dzakadzorerwa.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
#[derive(Clone)]
pub struct Punct(bridge::client::Punct);

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Send for Punct {}
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl !Sync for Punct {}

/// Kunyangwe `Punct` inoteverwa nekukurumidza neimwe `Punct` kana kuteverwa neimwe token kana whitespace.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub enum Spacing {
    /// semuenzaniso, `+` iri `Alone` mu `+ =`, `+ident` kana `+()`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Alone,
    /// semuenzaniso, `+` iri `Joint` mu `+=` kana `'#`.
    /// Pamusoro pezvo, kamwechete quote `'` inogona kujoina nemazita ekugadzira nguva yeupenyu `'ident`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    Joint,
}

impl Punct {
    /// Inogadzira `Punct` nyowani kubva kune yakapihwa hunhu uye nzvimbo.
    /// Iyo nharo ye `ch` inofanira kunge iri yechokwadi punctuation hunhu inobvumidzwa nemutauro, zvikasadaro iro basa richava panic.
    ///
    /// Iyo yakadzoserwa `Punct` ichave iine default span ye `Span::call_site()` iyo inogona kuenderera mberi yakagadzirirwa neiyo `set_span` nzira pazasi.
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(ch: char, spacing: Spacing) -> Punct {
        Punct(bridge::client::Punct::new(ch, spacing))
    }

    /// Inodzorera kukosha kweiyi punctuation hunhu se `char`.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn as_char(&self) -> char {
        self.0.as_char()
    }

    /// Inodzorera kusiyaniswa kweiyi punctuation hunhu, ichiratidza kana ichingoteverwa nekukurumidza neimwe `Punct` mune token rwizi, saka ivo vanogona kuve vanobatanidzwa kuita yakawanda-hunhu opareta (`Joint`), kana inoteverwa neimwe token kana whitespace (`Alone`) saka mushandi ane chokwadi kupera.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn spacing(&self) -> Spacing {
        self.0.spacing()
    }

    /// Inodzorera iyo span yeiyi punctuation hunhu.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Gadzira iyo span yeiyi punctuation hunhu.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, iro bhiriji rinongopa `to_string`, shandisa `fmt::Display` zvichibva pairi (iyo reverse yehukama hwese pakati pevaviri).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Punct {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Tinodhindisa hunhu hwetambo setambo inofanirwa kushandurwa isingarasikirwe ichidzokera muhunhu hwakafanana.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Punct {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Punct")
            .field("ch", &self.as_char())
            .field("spacing", &self.spacing())
            .field("span", &self.span())
            .finish()
    }
}

#[stable(feature = "proc_macro_punct_eq", since = "1.50.0")]
impl PartialEq<char> for Punct {
    fn eq(&self, rhs: &char) -> bool {
        self.as_char() == *rhs
    }
}

#[stable(feature = "proc_macro_punct_eq_flipped", since = "1.52.0")]
impl PartialEq<Punct> for char {
    fn eq(&self, rhs: &Punct) -> bool {
        *self == rhs.as_char()
    }
}

/// Chitarisiko (`ident`).
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Ident(bridge::client::Ident);

impl Ident {
    /// Inogadzira `Ident` nyowani neiyo yakapihwa `string` pamwe neiyo yakataurwa `span`.
    /// Iyo nharo ye `string` inofanira kunge iri chitupa chakakodzera chinotenderwa nemutauro (kusanganisira mazwi akakosha, semuenzaniso `self` kana `fn`).Zvikasadaro, basa racho richava panic.
    ///
    /// Ziva kuti `span`, parizvino iri mu rustc, inogadzirisa ruzivo rwehutsanana rweichi chinongedzo.
    ///
    /// Kubva panguva ino `Span::call_site()` inonyatsopinda mu "call-site" hutsanana zvichireva kuti zvitupa zvakagadzirwa nehurefu uhwu zvichagadziriswa sekunge zvakanyorwa zvakananga kunzvimbo yemacro kufona, uye imwe kodhi pane macro yekufona saiti inokwanisa kureva naivowo.
    ///
    ///
    /// Gare gare spans senge `Span::def_site()` inobvumidza kusarudza-mukati kune "definition-site" hutsanana zvichireva kuti zvitupa zvakagadzirwa neiyi span zvichagadziriswa panzvimbo yedudziro yemacro uye imwe kodhi pane macro yekufona saiti haizokwanisa kureva kwavari.
    ///
    /// Nekuda kwekukosha kwazvino kwehutsanana uyu muvaki, kusiyana nedzimwe tokens, inoda kuti `Span` inyorwe pakuvaka.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn new(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, false))
    }

    /// Zvakafanana ne `Ident::new`, asi zvinogadzira yakasvibisa chinongedzo (`r#ident`).
    /// Iyo nharo ye `string` ive inozivikanwa chinobvumidzwa nemutauro (kusanganisira mazwi akakosha, semuenzaniso `fn`).
    /// Mazwi akakosha anoshandiswa muzvikamu zvegwara (semuenzaniso
    /// `self`, `super`) haina kutsigirwa, uye inokonzeresa panic.
    #[stable(feature = "proc_macro_raw_ident", since = "1.47.0")]
    pub fn new_raw(string: &str, span: Span) -> Ident {
        Ident(bridge::client::Ident::new(string, span.0, true))
    }

    /// Inodzorera iyo span yeiyi `Ident`, inosanganisira tambo yese yakadzoserwa ne [`to_string`](Self::to_string).
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Inogadzirisa iyo span yeiyi `Ident`, pamwe ichichinja mamiriro ayo ehutsanana.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0 = self.0.with_span(span.0);
    }
}

// NB, iro bhiriji rinongopa `to_string`, shandisa `fmt::Display` zvichibva pairi (iyo reverse yehukama hwese pakati pevaviri).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Ident {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Tinoprinta chitarisiko setambo inofanirwa kushandurika isingarasike ichidzokera kune imwechete chitupa.
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Ident {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Ident")
            .field("ident", &self.to_string())
            .field("span", &self.span())
            .finish()
    }
}

/// Tambo chaiyo (`"hello"`), byte tambo (`b"hello"`), hunhu (`'a'`), byte hunhu (`b'a'`), iyo nhamba kana nhamba yekuyangarara ine kana isina chinokwana (`1`, `1u8`, `2.3`, `2.3f32`).
///
/// Boolean zvinyorwa zvakaita se `true` uye `false` hazvisi zvepano, iwo ma`Id`s.
///
#[derive(Clone)]
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
pub struct Literal(bridge::client::Literal);

macro_rules! suffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Inogadzira nyowani yakakwenenzverwa manhamba chaiwo neicho chakatarwa kukosha.
        ///
        /// Iri basa richagadzira iyo yakazara senge `1u32` uko kukosha kwakaringana kwakatsanangurwa ndicho chikamu chekutanga che token uye chakabatana chakaringanawo kumagumo.
        /// Zvinyorwa zvakagadzirwa kubva kumanhamba asina kunaka zvinogona kusapona kutenderera-kutenderera kuburikidza ne `TokenStream` kana tambo uye zvinogona kutyorwa kuita maviri tokens (`-` uye chaiyo chaiyo).
        ///
        ///
        /// Zvinyorwa zvakagadzirwa kuburikidza nenzira iyi zvine `Span::call_site()` span nekukasira, iyo inogona kugadziridzwa nenzira ye `set_span` pazasi.
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::typed_integer(&n.to_string(), stringify!($kind)))
        }
    )*)
}

macro_rules! unsuffixed_int_literals {
    ($($name:ident => $kind:ident,)*) => ($(
        /// Inogadzira nyowani isina kukwana isina kukwana chaiyo ine mutengo wakatarwa.
        ///
        /// Iri basa rinogadzira iyo yakazara senge `1` uko kukosha kwenhamba kwakatsanangurwa ndicho chikamu chekutanga che token.
        /// Hapana chinokwana chakatsanangurwa pane iyi token, zvichireva kuti kukumbira senge `Literal::i8_unsuffixed(1)` kwakaenzana ne `Literal::u32_unsuffixed(1)`.
        /// Zvinyorwa zvinogadzirwa kubva kumanhamba asina kunaka zvinogona kusararama zvichikwira kuburikidza ne `TokenStream` kana tambo uye zvinogona kutyorwa kuita maviri tokens (`-` uye chaiyo chaiyo).
        ///
        ///
        /// Zvinyorwa zvakagadzirwa kuburikidza nenzira iyi zvine `Span::call_site()` span nekukasira, iyo inogona kugadziridzwa nenzira ye `set_span` pazasi.
        ///
        ///
        ///
        ///
        ///
        #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
        pub fn $name(n: $kind) -> Literal {
            Literal(bridge::client::Literal::integer(&n.to_string()))
        }
    )*)
}

impl Literal {
    suffixed_int_literals! {
        u8_suffixed => u8,
        u16_suffixed => u16,
        u32_suffixed => u32,
        u64_suffixed => u64,
        u128_suffixed => u128,
        usize_suffixed => usize,
        i8_suffixed => i8,
        i16_suffixed => i16,
        i32_suffixed => i32,
        i64_suffixed => i64,
        i128_suffixed => i128,
        isize_suffixed => isize,
    }

    unsuffixed_int_literals! {
        u8_unsuffixed => u8,
        u16_unsuffixed => u16,
        u32_unsuffixed => u32,
        u64_unsuffixed => u64,
        u128_unsuffixed => u128,
        usize_unsuffixed => usize,
        i8_unsuffixed => i8,
        i16_unsuffixed => i16,
        i32_unsuffixed => i32,
        i64_unsuffixed => i64,
        i128_unsuffixed => i128,
        isize_unsuffixed => isize,
    }

    /// Inogadzira nyowani isina kunamirwa inoyerera-poindi chaiyo.
    ///
    /// Uyu muvaki akafanana neavo vakaita sa `Literal::i8_unsuffixed` uko kukosha kweiyo float inoburitswa yakananga mu token asi hapana chinomiririra chinoshandiswa, saka zvinogona kufungidzirwa kuve `f64` gare gare mune iyo compiler.
    ///
    /// Zvinyorwa zvinogadzirwa kubva kumanhamba asina kunaka zvinogona kusararama zvichikwira kuburikidza ne `TokenStream` kana tambo uye zvinogona kutyorwa kuita maviri tokens (`-` uye chaiyo chaiyo).
    ///
    /// # Panics
    ///
    /// Iri basa rinoda kuti iyo float yakatarwa ipere, semuenzaniso kana iri infinity kana NaN iri basa richava panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_unsuffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Inogadzira nyowani yakakwenenzverwa-inoyerera-poindi chaiyo.
    ///
    /// Uyu muvaki achagadzira chaiyo senge `1.0f32` uko kukosha kwakatsanangurwa ndicho chikamu chekutanga che token uye `f32` ndicho chinokwana che token.
    /// Iyi token ichagara ichifungidzirwa kuve `f32` mune inosanganisa.
    /// Zvinyorwa zvinogadzirwa kubva kumanhamba asina kunaka zvinogona kusararama zvichikwira kuburikidza ne `TokenStream` kana tambo uye zvinogona kutyorwa kuita maviri tokens (`-` uye chaiyo chaiyo).
    ///
    ///
    /// # Panics
    ///
    /// Iri basa rinoda kuti iyo float yakatarwa ipere, semuenzaniso kana iri infinity kana NaN iri basa richava panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f32_suffixed(n: f32) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f32(&n.to_string()))
    }

    /// Inogadzira nyowani isina kunamirwa inoyerera-poindi chaiyo.
    ///
    /// Uyu muvaki akafanana neavo vakaita sa `Literal::i8_unsuffixed` uko kukosha kweiyo float inoburitswa yakananga mu token asi hapana chinomiririra chinoshandiswa, saka zvinogona kufungidzirwa kuve `f64` gare gare mune iyo compiler.
    ///
    /// Zvinyorwa zvinogadzirwa kubva kumanhamba asina kunaka zvinogona kusararama zvichikwira kuburikidza ne `TokenStream` kana tambo uye zvinogona kutyorwa kuita maviri tokens (`-` uye chaiyo chaiyo).
    ///
    /// # Panics
    ///
    /// Iri basa rinoda kuti iyo float yakatarwa ipere, semuenzaniso kana iri infinity kana NaN iri basa richava panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_unsuffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::float(&n.to_string()))
    }

    /// Inogadzira nyowani yakakwenenzverwa-inoyerera-poindi chaiyo.
    ///
    /// Uyu muvaki achagadzira chaiyo senge `1.0f64` uko kukosha kwakatsanangurwa ndicho chikamu chekutanga che token uye `f64` ndicho chinokwana che token.
    /// Iyi token ichagara ichifungidzirwa kuve `f64` mune inosanganisa.
    /// Zvinyorwa zvinogadzirwa kubva kumanhamba asina kunaka zvinogona kusararama zvichikwira kuburikidza ne `TokenStream` kana tambo uye zvinogona kutyorwa kuita maviri tokens (`-` uye chaiyo chaiyo).
    ///
    ///
    /// # Panics
    ///
    /// Iri basa rinoda kuti iyo float yakatarwa ipere, semuenzaniso kana iri infinity kana NaN iri basa richava panic.
    ///
    ///
    ///
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn f64_suffixed(n: f64) -> Literal {
        if !n.is_finite() {
            panic!("Invalid float literal {}", n);
        }
        Literal(bridge::client::Literal::f64(&n.to_string()))
    }

    /// Tambo chaiyo.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn string(string: &str) -> Literal {
        Literal(bridge::client::Literal::string(string))
    }

    /// Hunhu chaihwo.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn character(ch: char) -> Literal {
        Literal(bridge::client::Literal::character(ch))
    }

    /// Tete tambo chaiyo.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn byte_string(bytes: &[u8]) -> Literal {
        Literal(bridge::client::Literal::byte_string(bytes))
    }

    /// Inodzorera iyo span inosanganisira izvo chaizvo.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn span(&self) -> Span {
        Span(self.0.span())
    }

    /// Inogadzirisa iyo span inosanganisirwa ino chaiyo.
    #[stable(feature = "proc_macro_lib2", since = "1.29.0")]
    pub fn set_span(&mut self, span: Span) {
        self.0.set_span(span.0);
    }

    /// Inodzorera `Span` inova subset ye `self.span()` ine chete mabheti enzvimbo mune `range`.
    /// Inodzorera `None` kana iyo ingango-kutemerwa span iri kunze kwemiganhu ye `self`.
    ///
    // FIXME(SergioBenitez): tarisa kuti iyo byte renji inotanga uye inopera pamuganhu we UTF-8 weiko rinobva.
    // kana zvisina kudaro, zvingangoita kuti panic ichaitika kumwe kunhu kana chinyorwa chemavara chikadhindwa.
    // FIXME(SergioBenitez): hapana nzira yekuti mushandisi azive izvo chaizvo `self.span()` mepu, saka nzira iyi parizvino inogona kungodaidzwa bofu.
    // Semuenzaniso, `to_string()` yemunhu 'c' inodzosera "'\u{63}'";hapana nzira yekuti mushandisi azive kana chinyorwa chinyorwa chaive 'c' kana kuti yaive '\u{63}'.
    //
    //
    //
    //
    #[unstable(feature = "proc_macro_span", issue = "54725")]
    pub fn subspan<R: RangeBounds<usize>>(&self, range: R) -> Option<Span> {
        // HACK(eddyb) chimwe chinhu chakafanana ne `Option::cloned`, asi che `Bound<&T>`.
        fn cloned_bound<T: Clone>(bound: Bound<&T>) -> Bound<T> {
            match bound {
                Bound::Included(x) => Bound::Included(x.clone()),
                Bound::Excluded(x) => Bound::Excluded(x.clone()),
                Bound::Unbounded => Bound::Unbounded,
            }
        }

        self.0.subspan(cloned_bound(range.start_bound()), cloned_bound(range.end_bound())).map(Span)
    }
}

// NB, iro bhiriji rinongopa `to_string`, shandisa `fmt::Display` zvichibva pairi (iyo reverse yehukama hwese pakati pevaviri).
//
#[stable(feature = "proc_macro_lib", since = "1.15.0")]
impl ToString for Literal {
    fn to_string(&self) -> String {
        TokenStream::from(TokenTree::from(self.clone())).to_string()
    }
}

/// Tinoprinta izvo chaizvo setambo inofanirwa kushandurika isingarasike ichidzokera kune imwecheteyo (kunze kwekukomberedza kutenderera kwenzvimbo dzinoyerera).
///
#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Display for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.to_string())
    }
}

#[stable(feature = "proc_macro_lib2", since = "1.29.0")]
impl fmt::Debug for Literal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

/// Yakateedzerwa kuwana kune zvakatipatsanuka nharaunda.
#[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
pub mod tracked_env {
    use std::env::{self, VarError};
    use std::ffi::OsStr;

    /// Dzosera nharaunda inoshanduka uye wedzera iyo kuvaka info yekuvimbika.
    /// Vaka sisitimu irikuita iyo compiler ichaziva kuti iyo musiyano yakawanikwa panguva yekusangana, uye ichakwanisa kudzosera iyo kuvaka kana kukosha kweiyo kusiana kusiana.
    ///
    /// Kunze kwekuvimbika kwekutevera basa iri rinofanirwa kunge rakaenzana ne `env::var` kubva mureibhurari yakajairwa, kunze kwekunge nharo yacho inofanira kunge iri UTF-8.
    ///
    #[unstable(feature = "proc_macro_tracked_env", issue = "74690")]
    pub fn var<K: AsRef<OsStr> + AsRef<str>>(key: K) -> Result<String, VarError> {
        let key: &str = key.as_ref();
        let value = env::var(key);
        crate::bridge::client::FreeFunctions::track_env_var(key, value.as_deref().ok());
        value
    }
}