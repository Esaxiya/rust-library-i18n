#![unstable(feature = "raw_vec_internals", reason = "implementation detail", issue = "none")]
#![doc(hidden)]

use core::alloc::LayoutError;
use core::cmp;
use core::intrinsics;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::Drop;
use core::ptr::{self, NonNull, Unique};
use core::slice;

use crate::alloc::{handle_alloc_error, Allocator, Global, Layout};
use crate::boxed::Box;
use crate::collections::TryReserveError::{self, *};

#[cfg(test)]
mod tests;

enum AllocInit {
    /// Izvo zviri mukati memurangariro mutsva hazvina kuiswa.
    Uninitialized,
    /// Iyo ndangariro nyowani inovimbiswa kuve zeroed.
    Zeroed,
}

/// Chishoma-chepasi chinoshandiswa chekuwedzera ergonomically kugovera, kuisazve nzvimbo, uye kugadzirisa buffer yekurangarira pamurwi pasina kunetseka nezve ese emakona emakesi akabatanidzwa.
///
/// Rudzi urwu rwakanakisa pakuvaka ako ega data zvimiro senge Vec uye VecDeque.
/// Zvikuru sei:
///
/// * Inogadzira `Unique::dangling()` pane zero-saizi mhando.
/// * Inogadzira `Unique::dangling()` pane zero-kureba migove.
/// * Inodzivirira kusunungura `Unique::dangling()`.
/// * Kubata kwese kufashukira mumakomputa ekugona (anovasimudzira ku "capacity overflow" panics).
/// * Guards inopesana ne32-bit masisitimu anogovera anopfuura isize::MAX byte.
/// * Varindi pamusoro pekupararira kureba kwako.
/// * Kufona `handle_alloc_error` yezvikanganiso zvisina kujeka.
/// * Ine `ptr::Unique` uye nekudaro inopa mushandisi nezvose zvakanakira mabhenefiti.
/// * Inoshandisa yakawandisa yakadzoserwa kubva kune anogovera kuti ishandise iyo hombe iripo.
///
/// Rudzi urwu haruongorore chero ndangariro kwarunogonesa.Kana yadonhedzwa *inosunungura ndangariro yayo, asi* haizo * edza kudonhedza zvirimo.
/// Zviri kumushandisi we `RawVec` kubata zvinhu chaizvo *zvakachengetwa* mukati me `RawVec`.
///
/// Ziva kuti kuwanda kwemhando zero-saizi kunogara kusingagumi, saka `capacity()` inogara ichidzosa `usize::MAX`.
/// Izvi zvinoreva kuti iwe unofanirwa kuve wakangwarira kana uchitenderera-uchitsausa rudzi urwu ne `Box<[T]>`, nekuti `capacity()` haizobudise iyo kureba.
///
///
#[allow(missing_debug_implementations)]
pub struct RawVec<T, A: Allocator = Global> {
    ptr: Unique<T>,
    cap: usize,
    alloc: A,
}

impl<T> RawVec<T, Global> {
    /// HACK(Centril): Izvi zviripo nekuti `#[unstable]` `const fn`s haidi kuenderana ne `min_const_fn` uye nekudaro havagone kudaidzwa mu`min_const_fn`s chero.
    ///
    /// Kana iwe ukachinja `RawVec<T>::new` kana kutsamira, ndapota chenjera kuti usaunze chero chinhu chinganyatso kutyora `min_const_fn`.
    ///
    /// NOTE: Tinogona kudzivirira uku kubheka uye kutarisa kuenderana nechimwe `#[rustc_force_min_const_fn]` hunhu hunoda kuenderana ne `min_const_fn` asi hazvireve kuti inobvumira kuidana mu `stable(...) const fn`/kodhi yemushandisi isingabvumidze `foo` kana `#[rustc_const_unstable(feature = "foo", issue = "01234")]` iriko.
    ///
    ///
    ///
    ///
    ///
    ///
    pub const NEW: Self = Self::new();

    /// Inogadzira yakakurisa `RawVec` (pane iyo system murwi) isina kugovera.
    /// Kana `T` ine saizi yakanaka, saka izvi zvinogadzira `RawVec` ine chinzvimbo `0`.
    /// Kana `T` iri zero-saizi, saka inogadzira `RawVec` ine huwandu `usize::MAX`.
    /// Inobatsira pakuita kunonoka kugoverwa.
    ///
    pub const fn new() -> Self {
        Self::new_in(Global)
    }

    /// Inogadzira `RawVec` (pane iyo system murwi) ine chaizvo kugona uye kuenderana zvinoda kwe `[T; capacity]`.
    /// Izvi zvakafanana nekudana `RawVec::new` apo `capacity` iri `0` kana `T` iri zero-saizi.
    /// Ziva kuti kana `T` iri zero-saizi izvi zvinoreva kuti haugone * kuwana `RawVec` nekwanisi yakakumbirwa.
    ///
    /// # Panics
    ///
    /// Panics kana huwandu hwakakumbirwa hwakapfuura `isize::MAX` byte.
    ///
    /// # Aborts
    ///
    /// Aborts paOOM.
    ///
    ///
    #[inline]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Sa `with_capacity`, asi inovimbisa iyo buffer haina zeroed.
    #[inline]
    pub fn with_capacity_zeroed(capacity: usize) -> Self {
        Self::with_capacity_zeroed_in(capacity, Global)
    }

    /// Inogadzirisazve `RawVec` kubva kunongedzera uye kugona.
    ///
    /// # Safety
    ///
    /// Iyo `ptr` inofanira kupihwa (pane system murwi), uye neinopihwa `capacity`.
    /// Iyo `capacity` haigone kudarika `isize::MAX` yemhando dzakakura.(chete kunetsekana pane 32-bit masisitimu).
    /// ZST vectors inogona kuve inokwana inosvika ku `usize::MAX`.
    /// Kana iyo `ptr` ne `capacity` zvichibva ku `RawVec`, saka izvi zvinovimbiswa.
    #[inline]
    pub unsafe fn from_raw_parts(ptr: *mut T, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, capacity, Global) }
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    // Tiny Vecs mbeveve.Enda kune:
    // - 8 kana iyo saizi saizi iri 1, nekuti chero murwi vanogovera vanogona kukomberedza chikumbiro chemasere pasi pe 8 mabheti kusvika kuma8 mabheti.
    //
    // - 4 kana zvinhu zviri pakati nepakati (<=1 KiB).
    // - 1 neimwe nzira, kudzivirira kutambisa nzvimbo yakawandisa kune mapfupi maVecs.
    const MIN_NON_ZERO_CAP: usize = if mem::size_of::<T>() == 1 {
        8
    } else if mem::size_of::<T>() <= 1024 {
        4
    } else {
        1
    };

    /// Sa `new`, asi parameterized pamusoro yesarudzo yemugovanisi yeiyo yakadzoserwa `RawVec`.
    ///
    #[rustc_allow_const_fn_unstable(const_fn)]
    pub const fn new_in(alloc: A) -> Self {
        // `cap: 0` zvinoreva "unallocated".zero-saizi mhando haina hanya.
        Self { ptr: Unique::dangling(), cap: 0, alloc }
    }

    /// Sa `with_capacity`, asi parameterized pamusoro yesarudzo yemugovanisi yeiyo yakadzoserwa `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Uninitialized, alloc)
    }

    /// Sa `with_capacity_zeroed`, asi parameterized pamusoro yesarudzo yemugovanisi yeiyo yakadzoserwa `RawVec`.
    ///
    #[inline]
    pub fn with_capacity_zeroed_in(capacity: usize, alloc: A) -> Self {
        Self::allocate_in(capacity, AllocInit::Zeroed, alloc)
    }

    /// Inoshandura `Box<[T]>` kuita `RawVec<T>`.
    pub fn from_box(slice: Box<[T], A>) -> Self {
        unsafe {
            let (slice, alloc) = Box::into_raw_with_allocator(slice);
            RawVec::from_raw_parts_in(slice.as_mut_ptr(), slice.len(), alloc)
        }
    }

    /// Inoshandura iyo yose buffer kuita `Box<[MaybeUninit<T>]>` neiyo `len` yakatsanangurwa.
    ///
    /// Ziva kuti izvi zvichagadzirisa nenzira kwayo chero `cap` shanduko dzinogona kunge dzakaitwa.(Ona rondedzero yerudzi kuti uwane rumwe ruzivo.)
    ///
    /// # Safety
    ///
    /// * `len` inofanirwa kuve yakakura kudarika kana kuenzana neinogona kukumbirwa nguva pfupi yadarika, uye
    /// * `len` inofanira kunge iri pasi kana kuenzana ne `self.capacity()`.
    ///
    /// Ziva, kuti iro rakakumbirwa chinzvimbo uye `self.capacity()` inogona kusiyana, seyakagoverwa inogona kuwedzera nzvimbo uye kudzosa yakakura memory memory kupfuura yakumbirwa.
    ///
    ///
    pub unsafe fn into_box(self, len: usize) -> Box<[MaybeUninit<T>], A> {
        // Sanity-tarisa imwe hafu yezvinodiwa zvekuchengetedza (hatigone kutarisa imwe hafu).
        debug_assert!(
            len <= self.capacity(),
            "`len` must be smaller than or equal to `self.capacity()`"
        );

        let me = ManuallyDrop::new(self);
        unsafe {
            let slice = slice::from_raw_parts_mut(me.ptr() as *mut MaybeUninit<T>, len);
            Box::from_raw_in(slice, ptr::read(&me.alloc))
        }
    }

    fn allocate_in(capacity: usize, init: AllocInit, alloc: A) -> Self {
        if mem::size_of::<T>() == 0 {
            Self::new_in(alloc)
        } else {
            // Isu tinodzivirira `unwrap_or_else` pano nekuti inovhara huwandu hweLLVM IR inogadzirwa.
            //
            let layout = match Layout::array::<T>(capacity) {
                Ok(layout) => layout,
                Err(_) => capacity_overflow(),
            };
            match alloc_guard(layout.size()) {
                Ok(_) => {}
                Err(_) => capacity_overflow(),
            }
            let result = match init {
                AllocInit::Uninitialized => alloc.allocate(layout),
                AllocInit::Zeroed => alloc.allocate_zeroed(layout),
            };
            let ptr = match result {
                Ok(ptr) => ptr,
                Err(_) => handle_alloc_error(layout),
            };

            Self {
                ptr: unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) },
                cap: Self::capacity_from_bytes(ptr.len()),
                alloc,
            }
        }
    }

    /// Inogadzirisazve `RawVec` kubva kunongedzera, kugona, uye kugovera.
    ///
    /// # Safety
    ///
    /// Iyo `ptr` inofanirwa kupihwa (kuburikidza neakapihwa mugoveri `alloc`), uye neiyo yakapihwa `capacity`.
    /// Iyo `capacity` haigone kudarika `isize::MAX` yemhando dzakakura.
    /// (chete kunetsekana pane 32-bit masisitimu).
    /// ZST vectors inogona kuve inokwana inosvika ku `usize::MAX`.
    /// Kana iyo `ptr` uye `capacity` zvichibva ku `RawVec` yakagadzirwa kuburikidza ne `alloc`, saka izvi zvinovimbiswa.
    ///
    #[inline]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, capacity: usize, alloc: A) -> Self {
        Self { ptr: unsafe { Unique::new_unchecked(ptr) }, cap: capacity, alloc }
    }

    /// Inowana pointer mbishi kusvika pakutanga kwekugoverwa.
    /// Ziva kuti iyi i `Unique::dangling()` kana `capacity == 0` kana `T` iri zero-saizi.
    /// Muchiitiko chekare, iwe unofanirwa kuve wakangwarira.
    #[inline]
    pub fn ptr(&self) -> *mut T {
        self.ptr.as_ptr()
    }

    /// Inowana chinzvimbo chemugove.
    ///
    /// Izvi zvinogara zviri `usize::MAX` kana `T` iri zero-saizi.
    #[inline(always)]
    pub fn capacity(&self) -> usize {
        if mem::size_of::<T>() == 0 { usize::MAX } else { self.cap }
    }

    /// Inodzorera yakagovaniswa mareferenzi kune anogovera kutsigira iyi `RawVec`.
    pub fn allocator(&self) -> &A {
        &self.alloc
    }

    fn current_memory(&self) -> Option<(NonNull<u8>, Layout)> {
        if mem::size_of::<T>() == 0 || self.cap == 0 {
            None
        } else {
            // Tine chakatemwa chunk chendangariro, saka tinogona kupfuura nguva dzekumhanya kuti tiwane marongero azvino.
            //
            unsafe {
                let align = mem::align_of::<T>();
                let size = mem::size_of::<T>() * self.cap;
                let layout = Layout::from_size_align_unchecked(size, align);
                Some((self.ptr.cast().into(), layout))
            }
        }
    }

    /// Inoona kuti iyo buffer ine inokwana inokwana nzvimbo yekubata `len + additional` zvinhu.
    /// Kana iyo isati yatokwana inokwana, inozogovanisa nzvimbo yakakwana pamwe neyakagadzikana nzvimbo inononoka kuti itorerwe *O*(1) maitiro.
    ///
    /// Ino ganhurira hunhu uhu kana zvikazvikonzera zvisina basa ku panic.
    ///
    /// Kana `len` ikapfuura `self.capacity()`, izvi zvinogona kutadza kugovera nzvimbo yakakumbirwa.
    /// Izvi hazvinyatso kuchengetedzeka, asi kodhi isina kuchengetedzeka *iwe* nyora inovimba nehunhu hweiri basa inogona kutyora.
    ///
    /// Izvi zvakakosha pakuita yakawanda-Push mashandiro senge `extend`.
    ///
    /// # Panics
    ///
    /// Panics kana iyo nyowani nyowani inopfuura `isize::MAX` byte.
    ///
    /// # Aborts
    ///
    /// Aborts paOOM.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![feature(raw_vec_internals)]
    /// # extern crate alloc;
    /// # use std::ptr;
    /// # use alloc::raw_vec::RawVec;
    /// struct MyVec<T> {
    ///     buf: RawVec<T>,
    ///     len: usize,
    /// }
    ///
    /// impl<T: Clone> MyVec<T> {
    ///     pub fn push_all(&mut self, elems: &[T]) {
    ///         self.buf.reserve(self.len, elems.len());
    ///         // chengetedzo ingadai yakabvisa nhumbu kana kuvhunduka kana len ikapfuura `isize::MAX` saka izvi zvakachengeteka kuita zvisina kuongororwa izvozvi.
    /////
    ///         for x in elems {
    ///             unsafe {
    ///                 ptr::write(self.buf.ptr().add(self.len), x.clone());
    ///             }
    ///             self.len += 1;
    ///         }
    ///     }
    /// }
    /// # fn main() {
    /// #   let mut vector = MyVec { buf: RawVec::new(), len: 0 };
    /// #   vector.push_all(&[1, 3, 5, 7, 9]);
    /// # }
    /// ```
    ///
    ///
    pub fn reserve(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve(len, additional));
    }

    /// Zvakafanana ne `reserve`, asi inodzoka pane zvakakanganiswa panzvimbo pekuvhunduka kana kubvisa nhumbu.
    pub fn try_reserve(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) {
            self.grow_amortized(len, additional)
        } else {
            Ok(())
        }
    }

    /// Inoona kuti iyo buffer ine inokwana inokwana nzvimbo yekubata `len + additional` zvinhu.
    /// Kana ikasatove, ichaendesa hushoma hunowanikwa huwandu hweyeuchidzo inodikanwa.
    /// Kazhinji izvi zvichave chaizvo huwandu hweyeuchidzo hunodiwa, asi musimboti mupi akasununguka kudzorera zvakapfuura zvatakakumbira.
    ///
    ///
    /// Kana `len` ikapfuura `self.capacity()`, izvi zvinogona kutadza kugovera nzvimbo yakakumbirwa.
    /// Izvi hazvinyatso kuchengetedzeka, asi kodhi isina kuchengetedzeka *iwe* nyora inovimba nehunhu hweiri basa inogona kutyora.
    ///
    /// # Panics
    ///
    /// Panics kana iyo nyowani nyowani inopfuura `isize::MAX` byte.
    ///
    /// # Aborts
    ///
    /// Aborts paOOM.
    ///
    ///
    pub fn reserve_exact(&mut self, len: usize, additional: usize) {
        handle_reserve(self.try_reserve_exact(len, additional));
    }

    /// Zvakafanana ne `reserve_exact`, asi inodzoka pane zvakakanganiswa panzvimbo pekuvhunduka kana kubvisa nhumbu.
    pub fn try_reserve_exact(
        &mut self,
        len: usize,
        additional: usize,
    ) -> Result<(), TryReserveError> {
        if self.needs_to_grow(len, additional) { self.grow_exact(len, additional) } else { Ok(()) }
    }

    /// Inoderedza mugove pasi kune iyo yakatarwa huwandu.
    /// Kana iyo mari yakapihwa iri 0, inonyatso dhizaini.
    ///
    /// # Panics
    ///
    /// Panics kana iyo mari yakapihwa iri *hombe* pane iyo yazvino chinzvimbo.
    ///
    /// # Aborts
    ///
    /// Aborts paOOM.
    pub fn shrink_to_fit(&mut self, amount: usize) {
        handle_reserve(self.shrink(amount));
    }
}

impl<T, A: Allocator> RawVec<T, A> {
    /// Inodzosera kana iyo buffer ichida kukura kuzadzisa inodiwa yekuwedzera chinzvimbo.
    /// Inonyanya kushandiswa kugadzira inline inochengeterwa-mafoni anokwanisika pasina kuisa `grow`.
    fn needs_to_grow(&self, len: usize, additional: usize) -> bool {
        additional > self.capacity().wrapping_sub(len)
    }

    fn capacity_from_bytes(excess: usize) -> usize {
        debug_assert_ne!(mem::size_of::<T>(), 0);
        excess / mem::size_of::<T>()
    }

    fn set_ptr(&mut self, ptr: NonNull<[u8]>) {
        self.ptr = unsafe { Unique::new_unchecked(ptr.cast().as_ptr()) };
        self.cap = Self::capacity_from_bytes(ptr.len());
    }

    // Iyi nzira inowanzo simbiswa kakawanda.Saka isu tinoda kuti ive diki sezvinobvira, kugadzirisa nguva dzekuunganidza.
    // Asi isu tinodawo yakawanda yezviri mukati mayo kuverengera sezvinobvira, kuita kuti iyo inogadzirwa kodhi inomhanya nekukurumidza.
    // Naizvozvo, iyi nzira yakanyatso nyorwa kuitira kuti kodhi yese inoenderana ne `T` iri mukati mayo, nepo yakawanda kodhi yacho isingatsamiri pa `T` sezvinobvira iri mumabasa asiri egeneral pamusoro pe `T`.
    //
    //
    //
    //
    fn grow_amortized(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        // Izvi zvinovimbiswa nemamiriro ekudana.
        debug_assert!(additional > 0);

        if mem::size_of::<T>() == 0 {
            // Sezvo isu tinodzosa kugona kwe `usize::MAX` apo `elem_size` iri
            // 0, kusvika pano zvinoreva kuti `RawVec` yakanyanyisa.
            return Err(CapacityOverflow);
        }

        // Hapana chatingaite chaizvo nezve macheki aya, zvinosuwisa.
        let required_cap = len.checked_add(additional).ok_or(CapacityOverflow)?;

        // Izvi zvinovimbisa kukura kwekuwedzera.
        // Kuwedzeredza hakugone kufashukira nekuti `cap <= isize::MAX` uye mhando ye `cap` i `usize`.
        let cap = cmp::max(self.cap * 2, required_cap);
        let cap = cmp::max(Self::MIN_NON_ZERO_CAP, cap);

        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` isiri-generic pamusoro pe `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    // Zvipingamupinyi munzira iyi zvakangofanana neizvo zviri pa `grow_amortized`, asi nzira iyi inowanzo simbiswa kashoma saka hainyanyo kutsoropodza.
    //
    //
    fn grow_exact(&mut self, len: usize, additional: usize) -> Result<(), TryReserveError> {
        if mem::size_of::<T>() == 0 {
            // Sezvo isu tinodzosa kugona kwe `usize::MAX` kana saizi yerudzi iri
            // 0, kusvika pano zvinoreva kuti `RawVec` yakanyanyisa.
            return Err(CapacityOverflow);
        }

        let cap = len.checked_add(additional).ok_or(CapacityOverflow)?;
        let new_layout = Layout::array::<T>(cap);

        // `finish_grow` isiri-generic pamusoro pe `T`.
        let ptr = finish_grow(new_layout, self.current_memory(), &mut self.alloc)?;
        self.set_ptr(ptr);
        Ok(())
    }

    fn shrink(&mut self, amount: usize) -> Result<(), TryReserveError> {
        assert!(amount <= self.capacity(), "Tried to shrink to a larger capacity");

        let (ptr, layout) = if let Some(mem) = self.current_memory() { mem } else { return Ok(()) };
        let new_size = amount * mem::size_of::<T>();

        let ptr = unsafe {
            let new_layout = Layout::from_size_align_unchecked(new_size, layout.align());
            self.alloc.shrink(ptr, layout, new_layout).map_err(|_| TryReserveError::AllocError {
                layout: new_layout,
                non_exhaustive: (),
            })?
        };
        self.set_ptr(ptr);
        Ok(())
    }
}

// Iri basa riri kunze kwe `RawVec` kudzikisa nguva dzekuunganidza.Ona chirevo chiri pamusoro `RawVec::grow_amortized` kuti uwane rumwe ruzivo.
// (Iyo `A` paramende haina kukosha, nekuti huwandu hwemhando dzakasiyana dze `A` dzinoonekwa mukuita ishoma kwazvo kupfuura huwandu hwemhando dze `T`.)
//
//
#[inline(never)]
fn finish_grow<A>(
    new_layout: Result<Layout, LayoutError>,
    current_memory: Option<(NonNull<u8>, Layout)>,
    alloc: &mut A,
) -> Result<NonNull<[u8]>, TryReserveError>
where
    A: Allocator,
{
    // Tarisa iko kukanganisa apa kudzikisira saizi ye `RawVec::grow_*`.
    let new_layout = new_layout.map_err(|_| CapacityOverflow)?;

    alloc_guard(new_layout.size())?;

    let memory = if let Some((ptr, old_layout)) = current_memory {
        debug_assert_eq!(old_layout.align(), new_layout.align());
        unsafe {
            // Mugoveri anotarisa kuenzanirana kuenzana
            intrinsics::assume(old_layout.align() == new_layout.align());
            alloc.grow(ptr, old_layout, new_layout)
        }
    } else {
        alloc.allocate(new_layout)
    };

    memory.map_err(|_| AllocError { layout: new_layout, non_exhaustive: () })
}

unsafe impl<#[may_dangle] T, A: Allocator> Drop for RawVec<T, A> {
    /// Inosunungura ndangariro dzinowanikwa ne `RawVec`*pasina* kuyedza kudonhedza zvirimo.
    fn drop(&mut self) {
        if let Some((ptr, layout)) = self.current_memory() {
            unsafe { self.alloc.deallocate(ptr, layout) }
        }
    }
}

// Pakati pebasa rekuchengetedza kukanganisa kubata.
#[inline]
fn handle_reserve(result: Result<(), TryReserveError>) {
    match result {
        Err(CapacityOverflow) => capacity_overflow(),
        Err(AllocError { layout, .. }) => handle_alloc_error(layout),
        Ok(()) => { /* yay */ }
    }
}

// Tinofanira kuvimbisa zvinotevera:
// * Hatimbofa takagovera `> isize::MAX` byte-saizi zvinhu.
// * Isu hatifashukire `usize::MAX` uye chaizvo tinogovera zvishoma.
//
// Pa 64-bit isu tinongoda kutarisa mafashama nekuti kuyedza kugovera `> isize::MAX` mabheti zvechokwadi kuchakundikana.
// Pa 32-bit uye 16-bit tinoda kuwedzera imwe gadhi yeizvi kana tiri kumhanya papuratifomu inogona kushandisa ese 4GB mune mushandisi-nzvimbo, semuenzaniso, PAE kana x32.
//
//

#[inline]
fn alloc_guard(alloc_size: usize) -> Result<(), TryReserveError> {
    if usize::BITS < 64 && alloc_size > isize::MAX as usize {
        Err(CapacityOverflow)
    } else {
        Ok(())
    }
}

// Rimwe repakati basa rinotarisira kuzivisa huwandu hwakawanda.
// Izvi zvichave nechokwadi chekuti kodhi yekodhi inoenderana ne panics iri shoma sezvo paine nzvimbo imwe chete iyo panics panzvimbo peboka mubato rese.
//
fn capacity_overflow() -> ! {
    panic!("capacity overflow");
}