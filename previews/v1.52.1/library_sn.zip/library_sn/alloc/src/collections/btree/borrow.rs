use core::marker::PhantomData;
use core::ptr::NonNull;

/// Models kudzoreredzwa kweimwe yakasarudzika mareferenzi, iwe paunenge uchiziva kuti iyo reborrow nezvizvarwa zvacho zvese (kureva., Zvese zvinongedzo uye mareferenzi anotorwa kubva mairi) hazvizoshandiswazve pane imwe nguva, mushure meizvozvo iwe unoda kushandisa iyo yekutanga yakasarudzika rejisiti zvakare .
///
///
/// Anokwereta anotarisa anowanzo bata iko kuunganidzwa kwezvikwereti iwe, asi kumwe kudzora kuyerera kunoitisa iyi stacking kwakanyanya kuomarara kuti compiler itevedze.
/// `DormantMutRef` inokutendera kuti utarise kuzvikwereta pachako, uchiri kuratidza chimiro chayo chakamonerwa, uye kuputira iyo mbichana kodhi kodhi inodiwa kuti uite izvi pasina kujekesa maitiro.
///
///
///
///
///
pub struct DormantMutRef<'a, T> {
    ptr: NonNull<T>,
    _marker: PhantomData<&'a mut T>,
}

unsafe impl<'a, T> Sync for DormantMutRef<'a, T> where &'a mut T: Sync {}
unsafe impl<'a, T> Send for DormantMutRef<'a, T> where &'a mut T: Send {}

impl<'a, T> DormantMutRef<'a, T> {
    /// Tora rakasarudzika chikwereti, uye nekukasira kuripa zvakare.
    /// Kune iye muunganidzi, iyo nguva yehupenyu hwereferensi nyowani yakafanana neupenyu hwese hwereferenzi yekutanga, asi iwe promise kuishandisa kwenguva pfupi.
    ///
    pub fn new(t: &'a mut T) -> (&'a mut T, Self) {
        let ptr = NonNull::from(t);
        // Kachengeteka: tinobata iyo inokwereta mukati mese 'a kuburikidza ne `_marker`, uye tinofumura
        // ichi chete chirevo, saka chakasarudzika.
        let new_ref = unsafe { &mut *ptr.as_ptr() };
        (new_ref, Self { ptr, _marker: PhantomData })
    }

    /// Dzokera kune yakasarudzika chikwereti chakatorwa pakutanga.
    ///
    /// # Safety
    ///
    /// Kubviswazve kunofanirwa kunge kwapera, kureva, chirevo chakadzoserwa ne `new` uye zvese zvinongedzo uye mareferenzi anotorwa kubva mairi, haafanire kushandiswa zvekare.
    ///
    pub unsafe fn awaken(self) -> &'a mut T {
        // Kachengeteka: edu ega mamiriro ekuchengetedza zvinoreva kuti chirevo ichi zvakare chakasiyana.
        unsafe { &mut *self.ptr.as_ptr() }
    }
}

#[cfg(test)]
mod tests;