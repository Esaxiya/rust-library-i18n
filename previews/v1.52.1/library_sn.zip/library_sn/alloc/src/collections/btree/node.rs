// Uku kuyedza pakuitwa kuchitevera kwakaringana
//
// ```
// struct BTreeMap<K, V> {
//     height: usize,
//     root: Option<Box<Node<K, V, height>>>
// }
//
// struct Node<K, V, height: usize> {
//     keys: [K; 2 * B - 1],
//     vals: [V; 2 * B - 1],
//     edges: [if height > 0 { Box<Node<K, V, height - 1>> } else { () }; 2 * B],
//     parent: Option<(NonNull<Node<K, V, height + 1>>, u16)>,
//     len: u16,
// }
// ```
//
// Sezvo Rust isingaite nemhando dzinoenderana uye nekudzoka kwepolymorphic, tinoita nezvakawanda zvisina kuchengetedzeka.
//

// Chinangwa chikuru cheiyi module ndeyekudzivirira kuomarara nekubata iwo muti seyakajairika (kana yakaumbwa zvisina kusimba) mudziyo uye kudzivirira kubata nevazhinji veB-Muti zvinopinda.
//
// Saka nekudaro, uyu module hauna hanya nekuti zvinyorwa zvacho zvakarongedzwa, ndeapi maodhi anogona kuzadzwa, kana kunyangwe zvinoreva underfull.Nekudaro, isu tinovimba nevashoma vanopinda:
//
// - Miti inofanira kunge iine yunifomu depth/height.Izvi zvinoreva kuti nzira yega yega yezasi kune shizha kubva pane yakapihwa node ine urefu hwakaenzana.
// - Iyo node yehurefu `n` ine `n` makiyi, `n` kukosha, uye `n + 1` micheto.
//   Izvi zvinoreva kuti kunyangwe isina chinhu isina chinhu ine imwechete edge.
//   Nezveshizha node, "having an edge" zvinongoreva kuti isu tinogona kuziva chinzvimbo mune iyo node, sezvo mashizha emicheto haana chinhu uye haadi chero dhata inomiririrwa.
// Munzvimbo yemukati, iyo edge zvese zvinoratidza chinzvimbo uye ine pointer kune mwana node.
//
//
//

use core::marker::PhantomData;
use core::mem::{self, MaybeUninit};
use core::ptr::{self, NonNull};
use core::slice::SliceIndex;

use crate::alloc::{Allocator, Global, Layout};
use crate::boxed::Box;

const B: usize = 6;
pub const CAPACITY: usize = 2 * B - 1;
pub const MIN_LEN_AFTER_SPLIT: usize = B - 1;
const KV_IDX_CENTER: usize = B - 1;
const EDGE_IDX_LEFT_OF_CENTER: usize = B - 1;
const EDGE_IDX_RIGHT_OF_CENTER: usize = B;

/// Icho chinomiririra chiri pasi chemashizha emashizha uye chikamu chemumiriri wemukati mafundo.
struct LeafNode<K, V> {
    /// Tinoda kuve covariant mu `K` uye `V`.
    parent: Option<NonNull<InternalNode<K, V>>>,

    /// Iyi indekisi yenongedzo mune yemubereki node ye `edges` array.
    /// `*node.parent.edges[node.parent_idx]` inofanirwa kunge yakafanana ne `node`.
    /// Izvi zvinongovimbiswa kuti zvinotangiswa kana `parent` isiri-null.
    parent_idx: MaybeUninit<u16>,

    /// Huwandu hwemakiyi uye hunhu hunochengeterwa ino node.
    len: u16,

    /// Iyo arrays inochengeta iyo chaiyo data reiyo node.
    /// Chete ekutanga `len` zvinhu zveimwe nongedzo zvinotangwa uye zvinoshanda.
    keys: [MaybeUninit<K>; CAPACITY],
    vals: [MaybeUninit<V>; CAPACITY],
}

impl<K, V> LeafNode<K, V> {
    /// Inotanga `LeafNode` nyowani-munzvimbo.
    unsafe fn init(this: *mut Self) {
        // Setsika yakajairika, isu tinosiya minda isina kuvhurwa kana ichigona, sezvo izvi zvichifanira kunge zvichikurumidza uye nyore kuteedzera muValgrind.
        //
        unsafe {
            // parent_idx, makiyi, uye vals ese ariMamweUninit
            ptr::addr_of_mut!((*this).parent).write(None);
            ptr::addr_of_mut!((*this).len).write(0);
        }
    }

    /// Inogadzira itsva boxed `LeafNode`.
    fn new() -> Box<Self> {
        unsafe {
            let mut leaf = Box::new_uninit();
            LeafNode::init(leaf.as_mut_ptr());
            leaf.assume_init()
        }
    }
}

/// Icho chinomiririra chinomiririra chemukati node.Sezvo ne`LeafNode`s, izvi zvinofanirwa kuvanzwa kuseri kwe`BoxedNode`s kudzivirira kudonhedza makiyi asina kuvhurwa uye hunhu.
/// Chero chinongedzo ku `InternalNode` chinogona kukandirwa zvakananga kunongedzera kuchikamu chepasi che `LeafNode` cheiyo node, ichibvumira kodhi kuti iite pamashizha uye mukati mawo masosi pasina kana kumbotarisa kuti ndeupi wevaviri anonongedza.
///
/// Ichi chivakwa chinogoneswa nekushandiswa kwe `repr(C)`.
///
#[repr(C)]
// gdb_providers.py inoshandisa iri zita rezita kujekesa.
struct InternalNode<K, V> {
    data: LeafNode<K, V>,

    /// Iwo anonongedzera kuvana veiyi node.
    /// `len + 1` yeaya anoonekwa seanotangwa uye anoshanda, kunze kwekunge padyo nekumagumo, apo muti unobatwa kuburikidza nekukwereta mhando `Dying`, mamwe eaya anongedzera ari akarembera.
    ///
    edges: [MaybeUninit<BoxedNode<K, V>>; 2 * B],
}

impl<K, V> InternalNode<K, V> {
    /// Inogadzira itsva boxed `InternalNode`.
    ///
    /// # Safety
    /// Iyo isingachinjiki yemukati mamodhi ndeyekuti ivo vane kana imwechete yakatangwa uye inoshanda edge.
    /// Iri basa harimise yakadaro edge.
    ///
    unsafe fn new() -> Box<Self> {
        unsafe {
            let mut node = Box::<Self>::new_uninit();
            // Isu tinongoda kutanga iyo data;iwo mativi ari MaybeUninit.
            LeafNode::init(ptr::addr_of_mut!((*node.as_mut_ptr()).data));
            node.assume_init()
        }
    }
}

/// Inotarisirwa, isina-null pointer kunongedzo.Ichi chingangova chinongedzo ku `LeafNode<K, V>` kana chinongedzo chine muridzi ku `InternalNode<K, V>`.
///
/// Nekudaro, `BoxedNode` haina kana ruzivo rwekuti ndedzipi mhando mbiri dzemanyowani ayo arimo, uye, zvishoma nekuda kwekushayikwa kweruzivo, haisi imwe yakasarudzika uye haina muparadzi.
///
///
///
type BoxedNode<K, V> = NonNull<LeafNode<K, V>>;

/// Iyo midzi node yemuti unowanikwa.
///
/// Ziva kuti izvi hazvina muparadzi, uye zvinofanirwa kucheneswa nemaoko.
pub type Root<K, V> = NodeRef<marker::Owned, K, V, marker::LeafOrInternal>;

impl<K, V> Root<K, V> {
    /// Inodzorera mutsva muridzi wemuti, une midzi yawo node iyo pakutanga isina chinhu.
    pub fn new() -> Self {
        NodeRef::new_leaf().forget_type()
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Leaf> {
    fn new_leaf() -> Self {
        Self::from_new_leaf(LeafNode::new())
    }

    fn from_new_leaf(leaf: Box<LeafNode<K, V>>) -> Self {
        NodeRef { height: 0, node: NonNull::from(Box::leak(leaf)), _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::Internal> {
    fn new_internal(child: Root<K, V>) -> Self {
        let mut new_node = unsafe { InternalNode::new() };
        new_node.edges[0].write(child.node);
        unsafe { NodeRef::from_new_internal(new_node, child.height + 1) }
    }

    /// # Safety
    /// `height` haifanire kuva zero.
    unsafe fn from_new_internal(internal: Box<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        let node = NonNull::from(Box::leak(internal)).cast();
        let mut this = NodeRef { height, node, _marker: PhantomData };
        this.borrow_mut().correct_all_childrens_parent_links();
        this
    }
}

impl<K, V, Type> NodeRef<marker::Owned, K, V, Type> {
    /// Inobvumirana inokwereta iyo muridzi midzi node.
    /// Kusiyana ne `reborrow_mut`, izvi zvakachengeteka nekuti kukosha kwekudzoka hakugone kushandiswa kuparadza mudzi, uye hakugone kuve nezvimwe zvinongedzo kumuti.
    ///
    pub fn borrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Zvishoma mutoro unokwereta iyo muridzi midzi node.
    pub fn borrow_valmut(&mut self) -> NodeRef<marker::ValMut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Kuchinjika kusingachinjiki kune rejisheni iyo inobvumidza kuyambuka uye inopa nzira dzinokuvadza uye zvimwe zvishoma.
    ///
    pub fn into_dying(self) -> NodeRef<marker::Dying, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Inowedzera nyowani nyowani yemukati ine imwechete edge ichinongedzera kune yapfuura midzi node, gadzira iyo nyowani node iyo midzi node, woidzosera.
    /// Izvi zvinowedzera kukwirira ne1 uye zvinopesana ne `pop_internal_level`.
    ///
    pub fn push_internal_level(&mut self) -> NodeRef<marker::Mut<'_>, K, V, marker::Internal> {
        super::mem::take_mut(self, |old_root| NodeRef::new_internal(old_root).forget_type());

        // `self.borrow_mut()`, kunze kwekunge isu takangokanganwa isu tiri vemukati izvozvi:
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Inobvisa iyo yemukati midzi node, ichishandisa mwana wayo wekutanga seye nyowani mudzi node.
    /// Sezvo zvakagadzirirwa chete kudaidzwa kana mudzi wemidzi uine mwana mumwe chete, hapana kuchenesa kunoitwa pane chero kiyi, kukosha uye vamwe vana.
    ///
    /// Izvi zvinoderedza kukwirira ne1 uye zvinopesana ne `push_internal_level`.
    ///
    /// Inoda kuwanikwa kwakazara kuchinhu che `Root` asi kwete kumidzi yemidzi;
    /// hazviite kuti mamwe mahandira kana mareferenzi abudise midzi midzi.
    ///
    /// Panics kana pasina chikamu chemukati, kureva kuti, kana mudzi wemidzi riri shizha.
    pub fn pop_internal_level(&mut self) {
        assert!(self.height > 0);

        let top = self.node;

        // Kachengeteka: isu takasimbisa kuve zvemukati.
        let internal_self = unsafe { self.borrow_mut().cast_to_internal_unchecked() };
        // KUCHENGETEKA: takakwereta `self` chete uye mhando yayo yekukwereta yakasarudzika.
        let internal_node = unsafe { &mut *NodeRef::as_internal_ptr(&internal_self) };
        // Kachengeteka: yekutanga edge inogara ichitangwa.
        self.node = unsafe { internal_node.edges[0].assume_init_read() };
        self.height -= 1;
        self.clear_parent_link();

        unsafe {
            Global.deallocate(top.cast(), Layout::new::<InternalNode<K, V>>());
        }
    }
}

// N.B. `NodeRef` inogara iri covariant mu `K` uye `V`, kunyangwe iyo `BorrowType` iri `Mut`.
// Izvi zvine hunyanzvi, asi hazvigone kukonzeresa kusagadzikana nekuda kwekushandisa kwemukati kwe `NodeRef` nekuti tinogara takajairwa pamusoro pe `K` ne `V`.
//
// Nekudaro, pese pese paruzhinji paruzhinji parunomhara `NodeRef`, ita shuwa kuti ine mutsauko wakaringana.
//
/// Chirevo kune iyo node.
///
/// Iyi mhando ine akati wandei ma parameter ayo anodzora maitiro ainoita:
/// - `BorrowType`: Rudzi rwechirume runotsanangura mhando yechikwereti uye inotakura hupenyu hwese.
///    - Kana iyi iri `Immut<'a>`, iyo `NodeRef` inoita zvakada kufanana ne `&'a Node`.
///    - Kana iyi iri `ValMut<'a>`, iyo `NodeRef` inoita zvakada kufanana ne `&'a Node` zvine chekuita nemakiyi uye chimiro chemuti, asi zvakare inobvumidza akawanda mareferensi ekuchinja kune kukosha mukati memuti kuti vagare.
///    - Kana iyi iri `Mut<'a>`, iyo `NodeRef` inoita zvakada kufanana ne `&'a mut Node`, kunyangwe nzira dzekuisa dzichitendera chinongedzo chinoshanduka kune kukosha kuti ugare pamwe chete.
///    - Kana iyi iri `Owned`, iyo `NodeRef` inoita zvakada kufanana ne `Box<Node>`, asi isina muparadzi, uye inofanira kucheneswa nemaoko.
///    - Kana iyi iri `Dying`, iyo `NodeRef` ichiri kuita zvakada kufanana ne `Box<Node>`, asi iine nzira dzekuparadza muti zvishoma nezvishoma, uye nzira dzakajairika, nepo dzisingaratidzwe sedzisina kufanira kufona, dzinogona kukumbira UB kana ikadaidzwa zvisizvo.
///
///   Sezvo chero `NodeRef` ichibvumidza kufamba nemuti, `BorrowType` inoshanda zvinoshanda kune iwo wese muti, kwete kungoita node pachayo.
/// - `K` uye `V`: Aya ndiwo marudzi emakiyi uye nemitengo yakachengetwa munzvimbo.
/// - `Type`: Izvi zvinogona kuva `Leaf`, `Internal`, kana `LeafOrInternal`.
/// Kana iyi iri `Leaf`, iyo `NodeRef` inonongedzera kune shizha node, kana ichi chiri `Internal` iyo `NodeRef` inonongedzera kunongedzo yemukati, uye kana iri `LeafOrInternal` iyo `NodeRef` inogona kunge ichinongedzera kune chero mhando yenode.
///   `Type` inonzi `NodeType` painoshandiswa kunze kwe `NodeRef`.
///
/// Ose ari maviri `BorrowType` uye `NodeType` anorambidza ndedzipi nzira dzatinoshandisa, kushandisa zvakadzama mhando chengetedzo.Pane zvikanganiso munzira yatinogona kushandisa kudzvinyirira kwakadai.
/// - Kune yega yega mhando paramende, isu tinogona chete kutsanangura nzira kungaite zvine hunyanzvi kana kune imwe chaiyo mhando.
/// Semuenzaniso, hatigone kutsanangura nzira senge `into_kv` zvine hunyanzvi kune ese `BorrowType`, kana kamwechete kune ese marudzi anotakura hupenyu hwese, nekuti isu tinoda kuti idzosere `&'a` mareferensi.
///   Naizvozvo, isu tinozvitsanangudza chete kune irinesimba mhando mhando `Immut<'a>`.
/// - Hatigone kumanikidzwa kubva pa `Mut<'a>` kusvika `Immut<'a>`.
///   Naizvozvo, isu tinofanirwa kufonera zvakajeka `reborrow` pane yakasimba zvikuru `NodeRef` kuitira kuti tisvike nzira yakaita se `into_kv`.
///
/// Dzese nzira pa `NodeRef` dzinodzosa imwe mhando rezita, kungave:
/// - Tora `self` nemutengo, uye dzosera hupenyu hwakatakurwa ne `BorrowType`.
///   Dzimwe nguva, kukumbira nzira yakadaro, tinoda kudaidza `reborrow_mut`.
/// - Tora `self` nereferenzi, uye (implicitly) udzorere hupenyu hwereferenzi, panzvimbo yehupenyu hwakatakurwa ne `BorrowType`.
/// Nenzira iyoyo, mutengi anokweretesa anovimbisa kuti iyo `NodeRef` inoramba yakweretwa sekureba sekuregedzerwa kwereferenzi.
///   Maitiro anotsigira kuisa kukotamisa mutemo uyu nekudzosa mbishi mbichana, kureva, chirevo chisina chero hupenyu.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
pub struct NodeRef<BorrowType, K, V, Type> {
    /// Huwandu hwezviyero izvo node uye padanho remashizha zvakaparadzana, kugara kweiyo node isingakwanise kutsanangurwa zvizere ne `Type`, uye kuti iyo node pachayo haichengete.
    /// Isu tinongoda chete kuchengetedza kukwirira kwenzvimbo yemidzi, uye tinowana imwe neimwe node kukwirira kubva pairi.
    /// Inofanira kunge iri zero kana `Type` iri `Leaf` uye isiri zero kana `Type` iri `Internal`.
    ///
    ///
    height: usize,
    /// Iyo yekunongedza kune shizha kana yemukati node.
    /// Tsananguro ye `InternalNode` inova nechokwadi chekuti chinongedzo chinoshanda chero nzira.
    node: NonNull<LeafNode<K, V>>,
    _marker: PhantomData<(BorrowType, Type)>,
}

impl<'a, K: 'a, V: 'a, Type> Copy for NodeRef<marker::Immut<'a>, K, V, Type> {}
impl<'a, K: 'a, V: 'a, Type> Clone for NodeRef<marker::Immut<'a>, K, V, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

unsafe impl<BorrowType, K: Sync, V: Sync, Type> Sync for NodeRef<BorrowType, K, V, Type> {}

unsafe impl<'a, K: Sync + 'a, V: Sync + 'a, Type> Send for NodeRef<marker::Immut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::Mut<'a>, K, V, Type> {}
unsafe impl<'a, K: Send + 'a, V: Send + 'a, Type> Send for NodeRef<marker::ValMut<'a>, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Owned, K, V, Type> {}
unsafe impl<K: Send, V: Send, Type> Send for NodeRef<marker::Dying, K, V, Type> {}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Bvisa chirevo che node icho chaive chakazara se `NodeRef::parent`.
    fn from_internal(node: NonNull<InternalNode<K, V>>, height: usize) -> Self {
        debug_assert!(height > 0);
        NodeRef { height, node: node.cast(), _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Inofumura iyo data renzvimbo yemukati.
    ///
    /// Inodzorera mbichana ptr kudzivirira kusasimbisa kumwe kunongedzera kune ino node.
    fn as_internal_ptr(this: &Self) -> *mut InternalNode<K, V> {
        // KUCHENGETEKA: iyo static node mhando ndeye `Internal`.
        this.node.as_ptr() as *mut InternalNode<K, V>
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Inokwereta yakasarudzika kuwana kune iyo data yemukati node.
    fn as_internal_mut(&mut self) -> &mut InternalNode<K, V> {
        let ptr = Self::as_internal_ptr(self);
        unsafe { &mut *ptr }
    }
}

impl<BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Inotsvaga kureba kwenzvimbo.Iyi ndiyo nhamba yemakiyi kana kukosha.
    /// Huwandu hwemakona i `len() + 1`.
    /// Ziva kuti, kunyangwe iri kuchengetedzeka, kudaidza iri basa kunogona kuve nemhedzisiro yekukanganisa mareferensi anogona kuchinjika akagadzirwa nekodhi isina kuchengetedzeka.
    ///
    pub fn len(&self) -> usize {
        // Nechisimba, isu tinongowana iyo `len` munda pano.
        // Kana BorrowType iri marker::ValMut, pangave nezvakanaka zvinochinja zvinongedzo kumitengo yatisingafanirwe kushayisa basa.
        unsafe { usize::from((*Self::as_leaf_ptr(self)).len) }
    }

    /// Inodzorera iyo nhamba yematanho ayo iyo node uye mashizha akaparadzaniswa.
    /// Kureba kweZero zvinoreva kuti node ishizha pacharo.
    /// Kana iwe uchifananidza miti ine mudzi kumusoro, iyo nhamba inotaura pakakwirira iyo node inoonekwa.
    /// Kana iwe ukafananidza miti ine mashizha kumusoro, iyo nhamba inotaura kuti yakakwira sei iyo muti unokwira pamusoro penzvimbo.
    ///
    pub fn height(&self) -> usize {
        self.height
    }

    /// Kwechinguva anotora imwe, isingachinjiki revo kune imwecheteyo node.
    pub fn reborrow(&self) -> NodeRef<marker::Immut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Inofumura chikamu chemashizha chero ripi zvaro shizha kana node yemukati.
    ///
    /// Inodzorera mbichana ptr kudzivirira kusasimbisa kumwe kunongedzera kune ino node.
    fn as_leaf_ptr(this: &Self) -> *mut LeafNode<K, V> {
        // Iyo node inofanira kuve inoshanda kune ingangoita chikamu cheLeafNode.
        // Ichi hachisi chirevo mumhando yeNodeRef nekuti isu hatizive kana ichifanira kuve yakasarudzika kana kugoverwa.
        //
        this.node.as_ptr()
    }
}

impl<BorrowType: marker::BorrowType, K, V, Type> NodeRef<BorrowType, K, V, Type> {
    /// Inotsvaga mubereki wenodhi yazvino.
    /// Inodzorera `Ok(handle)` kana iyo node yazvino iine mubereki, uko `handle` inonongedzera ku edge yemubereki inonongedzera kunodhi yazvino.
    ///
    /// Inodzorera `Err(self)` kana iyo yazvino node isina mubereki, ichidzorera iyo yekutanga `NodeRef`.
    ///
    /// Iyo nzira yezita inofungidzira iwe mifananidzo yemiti ine mudzi node pamusoro.
    ///
    /// `edge.descend().ascend().unwrap()` uye `node.ascend().unwrap().descend()` havafanirwe kuita zvese zviri zviviri, pakubudirira.
    ///
    pub fn ascend(
        self,
    ) -> Result<Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>, Self> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Isu tinofanirwa kushandisa mbishi mbishi kunodhi nekuti, kana BorrowType iri marker::ValMut, panogona kunge paine mareferenzi anoshamisa anogona kuchinjika kumitengo yatisingafanirwe kuregedza.
        //
        let leaf_ptr: *const _ = Self::as_leaf_ptr(&self);
        unsafe { (*leaf_ptr).parent }
            .as_ref()
            .map(|parent| Handle {
                node: NodeRef::from_internal(*parent, self.height + 1),
                idx: unsafe { usize::from((*leaf_ptr).parent_idx.assume_init()) },
                _marker: PhantomData,
            })
            .ok_or(self)
    }

    pub fn first_edge(self) -> Handle<Self, marker::Edge> {
        unsafe { Handle::new_edge(self, 0) }
    }

    pub fn last_edge(self) -> Handle<Self, marker::Edge> {
        let len = self.len();
        unsafe { Handle::new_edge(self, len) }
    }

    /// Ziva kuti `self` inofanirwa kunge isingaite.
    pub fn first_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, 0) }
    }

    /// Ziva kuti `self` inofanirwa kunge isingaite.
    pub fn last_kv(self) -> Handle<Self, marker::KV> {
        let len = self.len();
        assert!(len > 0);
        unsafe { Handle::new_kv(self, len - 1) }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Immut<'a>, K, V, Type> {
    /// Inofumura chikamu chemashizha chero ripi zvaro shizha kana yemukati node mumuti usingachinjiki.
    fn into_leaf(self) -> &'a LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&self);
        // KUCHENGETEKA: panogona kuve pasina zvinoshanduka zvinongedzo mumuti uyu wakakweretwa se `Immut`.
        unsafe { &*ptr }
    }

    /// Inokwereta chiono mumakiyi akachengetwa mune iyo node.
    pub fn keys(&self) -> &[K] {
        let leaf = self.into_leaf();
        unsafe {
            MaybeUninit::slice_assume_init_ref(leaf.keys.get_unchecked(..usize::from(leaf.len)))
        }
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Zvakafanana ne `ascend`, inowana chirevo kunongedzo yemubereki node, asi zvakare inotamisa iyo yazvino node mukuita.
    /// Izvi hazvina kuchengetedzeka nekuti iyo yazvino node icharamba ichiwanikwa nyangwe ichitakurwa.
    ///
    pub unsafe fn deallocate_and_ascend(
        self,
    ) -> Option<Handle<NodeRef<marker::Dying, K, V, marker::Internal>, marker::Edge>> {
        let height = self.height;
        let node = self.node;
        let ret = self.ascend().ok();
        unsafe {
            Global.deallocate(
                node.cast(),
                if height > 0 {
                    Layout::new::<InternalNode<K, V>>()
                } else {
                    Layout::new::<LeafNode<K, V>>()
                },
            );
        }
        ret
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Kusachengetedzwa kunosimbisa kumusanganisi iwo ruzivo rwekuti iyo node i `Leaf`.
    unsafe fn cast_to_leaf_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
        debug_assert!(self.height == 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Kusachengetedzwa kunosimbisa kumusanganisi iwo ruzivo rwekuti iyo node i `Internal`.
    unsafe fn cast_to_internal_unchecked(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        debug_assert!(self.height > 0);
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Kwechinguva anotora imwe, inogona kuchinjika kune imwecheteyo node.Chenjera, nekuti nzira iyi ine njodzi huru, zvakapetwa kaviri nekuti inogona kunge isingaonekwe pakarepo kuti ine njodzi.
    ///
    /// Nekuti zvinoshandurwa zvinongedzo zvinogona kutenderera chero panotenderedza muti, iyo yakadzoserwa pointer inogona kushandiswa nyore kugadzira iyo yekutanga pointer yakaturika, kunze kwemiganhu, kana kusabatika pasi pemakakomberedzwa emitemo yekukwereta
    ///
    ///
    ///
    ///
    // FIXME(@gereeter) funga kuwedzera imwezve mhando paramende ku `NodeRef` inotadzisa mashandisirwo enzira dzekufambisa pazvinongedzo zvakweretwa, kudzivirira kusagadzikana uku.
    //
    //
    unsafe fn reborrow_mut(&mut self) -> NodeRef<marker::Mut<'_>, K, V, Type> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }

    /// Inokwereta mukana wega weiyo chikamu chemashizha chero ripi zvaro shizha kana yemukati node.
    fn as_leaf_mut(&mut self) -> &mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(self);
        // KUCHENGETEKA: isu tinokwanisa chete kuwana iyo yese node.
        unsafe { &mut *ptr }
    }

    /// Inopa chete mukana weiyo chikamu chemashizha chero ripi zvaro shizha kana yemukati node.
    fn into_leaf_mut(mut self) -> &'a mut LeafNode<K, V> {
        let ptr = Self::as_leaf_ptr(&mut self);
        // KUCHENGETEKA: isu tinokwanisa chete kuwana iyo yese node.
        unsafe { &mut *ptr }
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Inokwereta mukana wega wekuwana chinhu chekiyi nzvimbo yekuchengetera.
    ///
    /// # Safety
    /// `index` iri mumiganhu ye0..CAPACITY
    unsafe fn key_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<K>], Output = Output>,
    {
        // KUCHENGETEKA: anofona haazokwanisi kufonera dzimwe nzira paari
        // kudzamara kiyi chidimbu chechidimbu chadonhedzwa, sezvo isu tine yakasarudzika mukana wehupenyu hwese hwechikwereti
        //
        unsafe { self.as_leaf_mut().keys.as_mut_slice().get_unchecked_mut(index) }
    }

    /// Inokwereta yakasarudzika kuwana kune chinhu kana chidimbu cheiyo node kukosha kwenzvimbo yekuchengetera.
    ///
    /// # Safety
    /// `index` iri mumiganhu ye0..CAPACITY
    unsafe fn val_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<V>], Output = Output>,
    {
        // KUCHENGETEKA: anofona haazokwanisi kufonera dzimwe nzira paari
        // kudzamara kukosha kwechidimbu chechidimbu chadonhedzwa, sezvo isu tiine yakasarudzika mukana wehupenyu hwese hwechikwereti
        //
        unsafe { self.as_leaf_mut().vals.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Inokwereta mukana wega wekuwana chinhu kana chidimbu cheiyo node yekuchengetera nzvimbo ye edge zvirimo.
    ///
    /// # Safety
    /// `index` iri mumiganhu ye0..CAPACITY + 1
    unsafe fn edge_area_mut<I, Output: ?Sized>(&mut self, index: I) -> &mut Output
    where
        I: SliceIndex<[MaybeUninit<BoxedNode<K, V>>], Output = Output>,
    {
        // KUCHENGETEKA: anofona haazokwanisi kufonera dzimwe nzira paari
        // kusvikira edge chidimbu chechidimbu chadonhedzwa, sezvo isu tiine yakasarudzika mukana wehupenyu hwese hwechikwereti.
        //
        unsafe { self.as_internal_mut().edges.as_mut_slice().get_unchecked_mut(index) }
    }
}

impl<'a, K, V, Type> NodeRef<marker::ValMut<'a>, K, V, Type> {
    /// # Safety
    /// - Iyo node ine inopfuura `idx` yekutanga zvinhu.
    unsafe fn into_key_val_mut_at(mut self, idx: usize) -> (&'a K, &'a mut V) {
        // Isu tinongogadzira chirevo kuchinhu chimwe chete chatinofarira, kuti tirege kunamatira nezviratidzo zvakasarudzika kune zvimwe zvinhu, kunyanya, izvo zvinodzoserwa kune anofona mukutanga iterations.
        //
        //
        let leaf = Self::as_leaf_ptr(&mut self);
        let keys = unsafe { ptr::addr_of!((*leaf).keys) };
        let vals = unsafe { ptr::addr_of_mut!((*leaf).vals) };
        // Isu tinofanirwa kumanikidza kune unsized array anonongedza nekuda kwe Rust kuburitsa #74679.
        let keys: *const [_] = keys;
        let vals: *mut [_] = vals;
        let key = unsafe { (&*keys.get_unchecked(idx)).assume_init_ref() };
        let val = unsafe { (&mut *vals.get_unchecked_mut(idx)).assume_init_mut() };
        (key, val)
    }
}

impl<'a, K: 'a, V: 'a, Type> NodeRef<marker::Mut<'a>, K, V, Type> {
    /// Inokwereta yakasarudzika mukana wehurefu hwenzvimbo.
    pub fn len_mut(&mut self) -> &mut u16 {
        &mut self.as_leaf_mut().len
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Inoisa chinongedzo cheiyo node kumubereki wayo edge, pasina kukanganisa mamwe mareferenzi kune iyo node.
    ///
    fn set_parent_link(&mut self, parent: NonNull<InternalNode<K, V>>, parent_idx: usize) {
        let leaf = Self::as_leaf_ptr(self);
        unsafe { (*leaf).parent = Some(parent) };
        unsafe { (*leaf).parent_idx.write(parent_idx as u16) };
    }
}

impl<K, V> NodeRef<marker::Owned, K, V, marker::LeafOrInternal> {
    /// Inochenesa iyo yekubatanidza midzi kumubereki wayo edge.
    fn clear_parent_link(&mut self) {
        let mut root_node = self.borrow_mut();
        let leaf = root_node.as_leaf_mut();
        leaf.parent = None;
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Leaf> {
    /// Inowedzera kiyi-kukosha vaviri kusvika kumagumo enode.
    pub fn push(&mut self, key: K, val: V) {
        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// # Safety
    /// Chinhu chega chega chinodzoserwa ne `range` ndeyechokwadi edge index yeiyo node.
    unsafe fn correct_childrens_parent_links<R: Iterator<Item = usize>>(&mut self, range: R) {
        for i in range {
            debug_assert!(i <= self.len());
            unsafe { Handle::new_edge(self.reborrow_mut(), i) }.correct_parent_link();
        }
    }

    fn correct_all_childrens_parent_links(&mut self) {
        let len = self.len();
        unsafe { self.correct_childrens_parent_links(0..=len) };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
    /// Inowedzera yakakosha-kukosha vaviri, uye edge kuenda kurudyi kwevaviri, kusvika kumagumo eiyo node.
    ///
    pub fn push(&mut self, key: K, val: V, edge: Root<K, V>) {
        assert!(edge.height == self.height - 1);

        let len = self.len_mut();
        let idx = usize::from(*len);
        assert!(idx < CAPACITY);
        *len += 1;
        unsafe {
            self.key_area_mut(idx).write(key);
            self.val_area_mut(idx).write(val);
            self.edge_area_mut(idx + 1).write(edge.node);
            Handle::new_edge(self.reborrow_mut(), idx + 1).correct_parent_link();
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Inotarisa kana node iri `Internal` node kana `Leaf` node.
    pub fn force(
        self,
    ) -> ForceResult<
        NodeRef<BorrowType, K, V, marker::Leaf>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        if self.height == 0 {
            ForceResult::Leaf(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        } else {
            ForceResult::Internal(NodeRef {
                height: self.height,
                node: self.node,
                _marker: PhantomData,
            })
        }
    }
}

/// Chirevo kune yakasarudzika kiyi-kukosha vaviri kana edge mukati meiyo node.
/// Iyo `Node` paramende inofanira kunge iri `NodeRef`, nepo `Type` inogona kunge iri `KV` (zvichiratidza mubato pane yakakosha-kukosha vaviri) kana `Edge` (zvichiratidza mubato pa edge).
///
/// Ziva kuti kunyangwe `Leaf` node inogona kuve ne `Edge` inobata.
/// Panzvimbo pekumiririra pointer kune mwana node, idzi dzinomiririra nzvimbo dzaizonongedzera vana pakati pekiyi-kukosha mapara.
/// Semuenzaniso, mune node ine kureba 2, paizove nenzvimbo nhatu dzinogona kuitika edge, imwe kuruboshwe kwenzvimbo, imwe pakati pemaviri maviri, uye imwe kurudyi kwenzvimbo.
///
///
pub struct Handle<Node, Type> {
    node: Node,
    idx: usize,
    _marker: PhantomData<Type>,
}

impl<Node: Copy, Type> Copy for Handle<Node, Type> {}
// Hatidi huwandu hwakazara hwe `#[derive(Clone)]`, sezvo inguva chete `Node` ichave `Clone` inogoneka kana iri chirevo chisingachinjiki uye saka `Copy`.
//
impl<Node: Copy, Type> Clone for Handle<Node, Type> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<Node, Type> Handle<Node, Type> {
    /// Inotora iyo node ine iyo edge kana kiyi-kukosha peya iyi yekubata mapoinzi.
    pub fn into_node(self) -> Node {
        self.node
    }

    /// Inodzorera chinzvimbo chemubato uyu mune iyo node.
    pub fn idx(&self) -> usize {
        self.idx
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV> {
    /// Inogadzira mubato mutsva kune yakakosha-kukosha vaviri mu `node`.
    /// Hazvina kuchengeteka nekuti anenge afona anofanira kuona kuti `idx < node.len()`.
    pub unsafe fn new_kv(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx < node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx) }
    }

    pub fn right_edge(self) -> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
        unsafe { Handle::new_edge(self.node, self.idx + 1) }
    }
}

impl<BorrowType, K, V, NodeType> NodeRef<BorrowType, K, V, NodeType> {
    /// Kunogona kuve kuitiswa kuruzhinji kwePartialEq, asi kunongoshandiswa mune ino module.
    fn eq(&self, other: &Self) -> bool {
        let Self { node, height, _marker } = self;
        if node.eq(&other.node) {
            debug_assert_eq!(*height, other.height);
            true
        } else {
            false
        }
    }
}

impl<BorrowType, K, V, NodeType, HandleType> PartialEq
    for Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    fn eq(&self, other: &Self) -> bool {
        let Self { node, idx, _marker } = self;
        node.eq(&other.node) && *idx == other.idx
    }
}

impl<BorrowType, K, V, NodeType, HandleType>
    Handle<NodeRef<BorrowType, K, V, NodeType>, HandleType>
{
    /// Kwechinguva anotora imwe, isingachinjiki mubato panzvimbo imwechete.
    pub fn reborrow(&self) -> Handle<NodeRef<marker::Immut<'_>, K, V, NodeType>, HandleType> {
        // Hatigone kushandisa Handle::new_kv kana Handle::new_edge nekuti hatizive mhando yedu
        Handle { node: self.node.reborrow(), idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, Type> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, Type> {
    /// Kusachengetedzwa kunosimbisa kumusanganisi iwo ruzivo rwekuti iyo yekubata node ndeye `Leaf`.
    pub unsafe fn cast_to_leaf_unchecked(
        self,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, Type> {
        let node = unsafe { self.node.cast_to_leaf_unchecked() };
        Handle { node, idx: self.idx, _marker: PhantomData }
    }
}

impl<'a, K, V, NodeType, HandleType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, HandleType> {
    /// Kwechinguva anotora imwe, inogona kuchinjika mubato panzvimbo imwechete.
    /// Ngwarira, sezvo nzira iyi iine njodzi zvakanyanya, zvakapetwa kaviri nekuti inogona kunge isingaonekwe pakarepo kuti ine njodzi.
    ///
    ///
    /// Kuti uwane rumwe ruzivo, ona `NodeRef::reborrow_mut`.
    pub unsafe fn reborrow_mut(
        &mut self,
    ) -> Handle<NodeRef<marker::Mut<'_>, K, V, NodeType>, HandleType> {
        // Hatigone kushandisa Handle::new_kv kana Handle::new_edge nekuti hatizive mhando yedu
        Handle { node: unsafe { self.node.reborrow_mut() }, idx: self.idx, _marker: PhantomData }
    }
}

impl<BorrowType, K, V, NodeType> Handle<NodeRef<BorrowType, K, V, NodeType>, marker::Edge> {
    /// Inogadzira mubato mutsva kune edge mu `node`.
    /// Hazvina kuchengeteka nekuti anenge afona anofanira kuona kuti `idx <= node.len()`.
    pub unsafe fn new_edge(node: NodeRef<BorrowType, K, V, NodeType>, idx: usize) -> Self {
        debug_assert!(idx <= node.len());

        Handle { node, idx, _marker: PhantomData }
    }

    pub fn left_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx > 0 {
            Ok(unsafe { Handle::new_kv(self.node, self.idx - 1) })
        } else {
            Err(self)
        }
    }

    pub fn right_kv(self) -> Result<Handle<NodeRef<BorrowType, K, V, NodeType>, marker::KV>, Self> {
        if self.idx < self.node.len() {
            Ok(unsafe { Handle::new_kv(self.node, self.idx) })
        } else {
            Err(self)
        }
    }
}

pub enum LeftOrRight<T> {
    Left(T),
    Right(T),
}

/// Tichipiwa edge index kwatinoda kuisa mukati meiyo node yakazadzwa kusvika pakukwanisa, inoratidzira inonzwisisika KV index yenzvimbo yekutsemura uye pekuitira kuisa.
///
/// Icho chinangwa cheiyo nzvimbo yekuparadzanisa ndeyekuti kiyi yayo uye kukosha kwayo kugumira mune yemubereki node;
/// makiyi, kukosha uye micheto kuruboshwe kwenzvimbo yakatsemurwa kuva mwana wekuruboshwe;
/// makiyi, kukosha uye micheto kurudyi kwenzvimbo yekuparadzanisa inova mwana chaiye.
fn splitpoint(edge_idx: usize) -> (usize, LeftOrRight<usize>) {
    debug_assert!(edge_idx <= CAPACITY);
    // Rust inoburitsa #74834 inoedza kutsanangura iyi mitemo yakaenzana.
    match edge_idx {
        0..EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER - 1, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_LEFT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Left(edge_idx)),
        EDGE_IDX_RIGHT_OF_CENTER => (KV_IDX_CENTER, LeftOrRight::Right(0)),
        _ => (KV_IDX_CENTER + 1, LeftOrRight::Right(edge_idx - (KV_IDX_CENTER + 1 + 1))),
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Inoisa nyowani kiyi-kukosha vaviri pakati pemakiyi-kukosha mapara kurudyi uye kuruboshwe kweiyi edge.
    /// Iyi nzira inofungidzira kuti pane yakakwana nzvimbo mune iyo node kuti vaviri vaviri vakwane.
    ///
    /// Iyo yakadzoserwa poindi inonongedzera kune yakaiswa kukosha.
    ///
    fn insert_fit(&mut self, key: K, val: V) -> *mut V {
        debug_assert!(self.node.len() < CAPACITY);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            *self.node.len_mut() = new_len as u16;

            self.node.val_area_mut(self.idx).assume_init_mut()
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Inoisa nyowani kiyi-kukosha vaviri pakati pemakiyi-kukosha mapara kurudyi uye kuruboshwe kweiyi edge.
    /// Iyi nzira inotsemura node kana pasina nzvimbo yakakwana.
    ///
    /// Iyo yakadzoserwa poindi inonongedzera kune yakaiswa kukosha.
    fn insert(mut self, key: K, val: V) -> (InsertResult<'a, K, V, marker::Leaf>, *mut V) {
        if self.node.len() < CAPACITY {
            let val_ptr = self.insert_fit(key, val);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            (InsertResult::Fit(kv), val_ptr)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            let val_ptr = insertion_edge.insert_fit(key, val);
            (InsertResult::Split(result), val_ptr)
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Inogadzirisa pointer yemubereki uye index mune yemwana node iyo inoenderana ne edge.
    /// Izvi zvinobatsira kana kurongeka kwemipendero kwachinjwa,
    fn correct_parent_link(self) {
        // Gadzira backpointer pasina kukanganisa mamwe mareferenzi kune iyo node.
        let ptr = unsafe { NonNull::new_unchecked(NodeRef::as_internal_ptr(&self.node)) };
        let idx = self.idx;
        let mut child = self.descend();
        child.set_parent_link(ptr, idx);
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::Edge> {
    /// Inoisa nyowani kiyi-kukosha vaviri uye edge iyo ichaenda kurudyi kweiyo nyowani peya pakati peiyi edge uye yakakosha-kukosha vaviri kurudyi kweiyi edge.
    /// Iyi nzira inofungidzira kuti pane yakakwana nzvimbo mune iyo node kuti vaviri vaviri vakwane.
    ///
    fn insert_fit(&mut self, key: K, val: V, edge: Root<K, V>) {
        debug_assert!(self.node.len() < CAPACITY);
        debug_assert!(edge.height == self.node.height - 1);
        let new_len = self.node.len() + 1;

        unsafe {
            slice_insert(self.node.key_area_mut(..new_len), self.idx, key);
            slice_insert(self.node.val_area_mut(..new_len), self.idx, val);
            slice_insert(self.node.edge_area_mut(..new_len + 1), self.idx + 1, edge.node);
            *self.node.len_mut() = new_len as u16;

            self.node.correct_childrens_parent_links(self.idx + 1..new_len + 1);
        }
    }

    /// Inoisa nyowani kiyi-kukosha vaviri uye edge iyo ichaenda kurudyi kweiyo nyowani peya pakati peiyi edge uye yakakosha-kukosha vaviri kurudyi kweiyi edge.
    /// Iyi nzira inotsemura node kana pasina nzvimbo yakakwana.
    ///
    fn insert(
        mut self,
        key: K,
        val: V,
        edge: Root<K, V>,
    ) -> InsertResult<'a, K, V, marker::Internal> {
        assert!(edge.height == self.node.height - 1);

        if self.node.len() < CAPACITY {
            self.insert_fit(key, val, edge);
            let kv = unsafe { Handle::new_kv(self.node, self.idx) };
            InsertResult::Fit(kv)
        } else {
            let (middle_kv_idx, insertion) = splitpoint(self.idx);
            let middle = unsafe { Handle::new_kv(self.node, middle_kv_idx) };
            let mut result = middle.split();
            let mut insertion_edge = match insertion {
                LeftOrRight::Left(insert_idx) => unsafe {
                    Handle::new_edge(result.left.reborrow_mut(), insert_idx)
                },
                LeftOrRight::Right(insert_idx) => unsafe {
                    Handle::new_edge(result.right.borrow_mut(), insert_idx)
                },
            };
            insertion_edge.insert_fit(key, val, edge);
            InsertResult::Split(result)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Inoisa nyowani kiyi-kukosha vaviri pakati pemakiyi-kukosha mapara kurudyi uye kuruboshwe kweiyi edge.
    /// Iyi nzira inopatsanura iyo node kana pasina nzvimbo yakakwana, uye ichiedza kuisa iyo yakakamurwa chikamu chikamu munzvimbo yemubereki ichidzokororazve, kudzamara mudzi wasvika.
    ///
    ///
    /// Kana mhedzisiro yakadzoserwa iri `Fit`, node yayo yekubata inogona kuve ino node ye edge kana tateguru.
    /// Kana iyo mhedzisiro yakadzoserwa iri `Split`, iyo `left` munda unozove mudzi node.
    /// Iyo yakadzoserwa poindi inonongedzera kune yakaiswa kukosha.
    pub fn insert_recursing(
        self,
        key: K,
        value: V,
    ) -> (InsertResult<'a, K, V, marker::LeafOrInternal>, *mut V) {
        let (mut split, val_ptr) = match self.insert(key, value) {
            (InsertResult::Fit(handle), ptr) => {
                return (InsertResult::Fit(handle.forget_node_type()), ptr);
            }
            (InsertResult::Split(split), val_ptr) => (split.forget_node_type(), val_ptr),
        };

        loop {
            split = match split.left.ascend() {
                Ok(parent) => match parent.insert(split.kv.0, split.kv.1, split.right) {
                    InsertResult::Fit(handle) => {
                        return (InsertResult::Fit(handle.forget_node_type()), val_ptr);
                    }
                    InsertResult::Split(split) => split.forget_node_type(),
                },
                Err(root) => {
                    return (InsertResult::Split(SplitResult { left: root, ..split }), val_ptr);
                }
            };
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Inotsvaga iyo node yakanongedzwa neiyi edge.
    ///
    /// Iyo nzira yezita inofungidzira iwe mifananidzo yemiti ine mudzi node pamusoro.
    ///
    /// `edge.descend().ascend().unwrap()` uye `node.ascend().unwrap().descend()` havafanirwe kuita zvese zviri zviviri, pakubudirira.
    ///
    pub fn descend(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        assert!(BorrowType::PERMITS_TRAVERSAL);
        // Isu tinofanirwa kushandisa mbishi mbishi kunodhi nekuti, kana BorrowType iri marker::ValMut, panogona kunge paine mareferenzi anoshamisa anogona kuchinjika kumitengo yatisingafanirwe kuregedza.
        // Iko hakuna kunetsekana nekuwana iyo yekukwira munda nekuti iwo kukosha kwakateedzerwa.
        // Chenjera kuti, kana iyo node pointer ikasabvumidzwa, isu tinosvika kumakona akarongedzwa nereferenzi (Rust kuburitsa #73987) uye nekusaremekedza chero kumwe kutaurwa kune kana mukati meakarongeka, panofanira kunge paine anenge aripo.
        //
        //
        //
        //
        let parent_ptr = NodeRef::as_internal_ptr(&self.node);
        let node = unsafe { (*parent_ptr).edges.get_unchecked(self.idx).assume_init_read() };
        NodeRef { node, height: self.node.height - 1, _marker: PhantomData }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Immut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv(self) -> (&'a K, &'a V) {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf();
        let k = unsafe { leaf.keys.get_unchecked(self.idx).assume_init_ref() };
        let v = unsafe { leaf.vals.get_unchecked(self.idx).assume_init_ref() };
        (k, v)
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn key_mut(&mut self) -> &mut K {
        unsafe { self.node.key_area_mut(self.idx).assume_init_mut() }
    }

    pub fn into_val_mut(self) -> &'a mut V {
        debug_assert!(self.idx < self.node.len());
        let leaf = self.node.into_leaf_mut();
        unsafe { leaf.vals.get_unchecked_mut(self.idx).assume_init_mut() }
    }
}

impl<'a, K, V, NodeType> Handle<NodeRef<marker::ValMut<'a>, K, V, NodeType>, marker::KV> {
    pub fn into_kv_valmut(self) -> (&'a K, &'a mut V) {
        unsafe { self.node.into_key_val_mut_at(self.idx) }
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    pub fn kv_mut(&mut self) -> (&mut K, &mut V) {
        debug_assert!(self.idx < self.node.len());
        // Hatigone kudaidza makiyi akaparadzaniswa uye nzira dzekukosha, nekuti kudaidza wechipiri hakuiti kuti chirevo chidzoreke chekutanga.
        //
        unsafe {
            let leaf = self.node.as_leaf_mut();
            let key = leaf.keys.get_unchecked_mut(self.idx).assume_init_mut();
            let val = leaf.vals.get_unchecked_mut(self.idx).assume_init_mut();
            (key, val)
        }
    }

    /// Tsiva kiyi uye kukosha izvo zvinoreva KV mubato.
    pub fn replace_kv(&mut self, k: K, v: V) -> (K, V) {
        let (key, val) = self.kv_mut();
        (mem::replace(key, k), mem::replace(val, v))
    }
}

impl<'a, K: 'a, V: 'a, NodeType> Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV> {
    /// Inobatsira kuitwa kwe `split` kune imwe `NodeType`, nekutarisira data remashizha.
    ///
    fn split_leaf_data(&mut self, new_node: &mut LeafNode<K, V>) -> (K, V) {
        debug_assert!(self.idx < self.node.len());
        let old_len = self.node.len();
        let new_len = old_len - self.idx - 1;
        new_node.len = new_len as u16;
        unsafe {
            let k = self.node.key_area_mut(self.idx).assume_init_read();
            let v = self.node.val_area_mut(self.idx).assume_init_read();

            move_to_slice(
                self.node.key_area_mut(self.idx + 1..old_len),
                &mut new_node.keys[..new_len],
            );
            move_to_slice(
                self.node.val_area_mut(self.idx + 1..old_len),
                &mut new_node.vals[..new_len],
            );

            *self.node.len_mut() = self.idx as u16;
            (k, v)
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    /// Inoparadzanisa iyo yepasi node muzvikamu zvitatu:
    ///
    /// - Iyo node yakaderedzwa kuti ingori chete nekiyi-kukosha mapara kuruboshwe rwechibato ichi.
    /// - Kiyi uye kukosha kwakanongedzwa nemubato uyu zvinobviswa.
    /// - Ese makiyi-ekukosha mapara kurudyi kwechibato ichi anoiswa mune ichangobva kupihwa node.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Leaf> {
        let mut new_node = LeafNode::new();

        let kv = self.split_leaf_data(&mut new_node);

        let right = NodeRef::from_new_leaf(new_node);
        SplitResult { left: self.node, kv, right }
    }

    /// Inobvisa kiyi-kukosha vaviri vakanongedzwa nechibato ichi vochidzosera, pamwe ne edge iyo yakakosha-kukosha vaviri yakawira mukati.
    ///
    pub fn remove(
        mut self,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let old_len = self.node.len();
        unsafe {
            let k = slice_remove(self.node.key_area_mut(..old_len), self.idx);
            let v = slice_remove(self.node.val_area_mut(..old_len), self.idx);
            *self.node.len_mut() = (old_len - 1) as u16;
            ((k, v), self.left_edge())
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    /// Inoparadzanisa iyo yepasi node muzvikamu zvitatu:
    ///
    /// - Iyo node inotemwa kuti igova iine micheto uye makiyi-kukosha mapara kuruboshwe rwechibato ichi.
    /// - Kiyi uye kukosha kwakanongedzwa nemubato uyu zvinobviswa.
    /// - Iwo ese makona uye makiyi-anokosha mapara kurudyi kwechibato ichi anoiswa mune ichangobva kupihwa node.
    ///
    ///
    pub fn split(mut self) -> SplitResult<'a, K, V, marker::Internal> {
        let old_len = self.node.len();
        unsafe {
            let mut new_node = InternalNode::new();
            let kv = self.split_leaf_data(&mut new_node.data);
            let new_len = usize::from(new_node.data.len);
            move_to_slice(
                self.node.edge_area_mut(self.idx + 1..old_len + 1),
                &mut new_node.edges[..new_len + 1],
            );

            let height = self.node.height;
            let right = NodeRef::from_new_internal(new_node, height);

            SplitResult { left: self.node, kv, right }
        }
    }
}

/// Inomiririra chikamu chekuongorora uye kuita oparesheni yekuyera kutenderedza yemukati kiyi-kukosha vaviri.
///
pub struct BalancingContext<'a, K, V> {
    parent: Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV>,
    left_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    right_child: NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    pub fn consider_for_balancing(self) -> BalancingContext<'a, K, V> {
        let self1 = unsafe { ptr::read(&self) };
        let self2 = unsafe { ptr::read(&self) };
        BalancingContext {
            parent: self,
            left_child: self1.left_edge().descend(),
            right_child: self2.right_edge().descend(),
        }
    }
}

impl<'a, K, V> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
    /// Inosarudza mamiriro ekuenzanisa anosanganisira iyo node semwana, nekudaro pakati peKV ipapo ipapo kuruboshwe kana kurudyi munzvimbo yemubereki.
    /// Inodzorera `Err` kana pasina mubereki.
    /// Panics kana mubereki asina chinhu.
    ///
    /// Unosarudza divi reruboshwe, kuti rive rakaringana kana iyo node yakapihwa neimwe nzira izere, zvichireva pano chete kuti ine zvishoma zvinhu kupfuura hama yayo yekuruboshwe uye kupfuura hama yake yekurudyi, kana zviripo.
    /// Muchiitiko ichocho, kusanganisa nehama yekuruboshwe inokurumidza, nekuti isu tinongoda kufambisa node's N zvinhu, pachinzvimbo chekuchinjisa kurudyi nekufamba kupfuura N zvinhu zviri kumberi.
    /// Kuba kubva kumunin'ina wekuruboshwe kunowanzo mhanyisa, nekuti isu tinongoda kuchinjisa node yeN zvinhu ku kurudyi, panzvimbo pekuchinja kanenge N yezvinhu zvemukoma kuruboshwe.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn choose_parent_kv(self) -> Result<LeftOrRight<BalancingContext<'a, K, V>>, Self> {
        match unsafe { ptr::read(&self) }.ascend() {
            Ok(parent_edge) => match parent_edge.left_kv() {
                Ok(left_parent_kv) => Ok(LeftOrRight::Left(BalancingContext {
                    parent: unsafe { ptr::read(&left_parent_kv) },
                    left_child: left_parent_kv.left_edge().descend(),
                    right_child: self,
                })),
                Err(parent_edge) => match parent_edge.right_kv() {
                    Ok(right_parent_kv) => Ok(LeftOrRight::Right(BalancingContext {
                        parent: unsafe { ptr::read(&right_parent_kv) },
                        left_child: self,
                        right_child: right_parent_kv.right_edge().descend(),
                    })),
                    Err(_) => unreachable!("empty internal node"),
                },
            },
            Err(root) => Err(root),
        }
    }
}

impl<'a, K, V> BalancingContext<'a, K, V> {
    pub fn left_child_len(&self) -> usize {
        self.left_child.len()
    }

    pub fn right_child_len(&self) -> usize {
        self.right_child.len()
    }

    pub fn into_left_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.left_child
    }

    pub fn into_right_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.right_child
    }

    /// Inodzorera kana kusangana kuchikwanisika, kureva kuti, kana paine nzvimbo yakakwana munzvimbo yekubatanidza iyo yepakati KV neese ari padyo nemwana node.
    ///
    pub fn can_merge(&self) -> bool {
        self.left_child.len() + 1 + self.right_child.len() <= CAPACITY
    }
}

impl<'a, K: 'a, V: 'a> BalancingContext<'a, K, V> {
    /// Inoita kubatanidza uye inoita kuti kuvhara kusarudze zvekudzoka.
    fn do_merge<
        F: FnOnce(
            NodeRef<marker::Mut<'a>, K, V, marker::Internal>,
            NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
        ) -> R,
        R,
    >(
        self,
        result: F,
    ) -> R {
        let Handle { node: mut parent_node, idx: parent_idx, _marker } = self.parent;
        let old_parent_len = parent_node.len();
        let mut left_node = self.left_child;
        let old_left_len = left_node.len();
        let mut right_node = self.right_child;
        let right_len = right_node.len();
        let new_left_len = old_left_len + 1 + right_len;

        assert!(new_left_len <= CAPACITY);

        unsafe {
            *left_node.len_mut() = new_left_len as u16;

            let parent_key = slice_remove(parent_node.key_area_mut(..old_parent_len), parent_idx);
            left_node.key_area_mut(old_left_len).write(parent_key);
            move_to_slice(
                right_node.key_area_mut(..right_len),
                left_node.key_area_mut(old_left_len + 1..new_left_len),
            );

            let parent_val = slice_remove(parent_node.val_area_mut(..old_parent_len), parent_idx);
            left_node.val_area_mut(old_left_len).write(parent_val);
            move_to_slice(
                right_node.val_area_mut(..right_len),
                left_node.val_area_mut(old_left_len + 1..new_left_len),
            );

            slice_remove(&mut parent_node.edge_area_mut(..old_parent_len + 1), parent_idx + 1);
            parent_node.correct_childrens_parent_links(parent_idx + 1..old_parent_len);
            *parent_node.len_mut() -= 1;

            if parent_node.height > 1 {
                // KUCHENGETEKA: kukwirira kwenzvimbo dziri kubatanidzwa imwe pasi pehurefu
                // yenzvimbo yeiyi edge, saka pamusoro pe zero, saka zviri zvemukati.
                let mut left_node = left_node.reborrow_mut().cast_to_internal_unchecked();
                let mut right_node = right_node.cast_to_internal_unchecked();
                move_to_slice(
                    right_node.edge_area_mut(..right_len + 1),
                    left_node.edge_area_mut(old_left_len + 1..new_left_len + 1),
                );

                left_node.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);

                Global.deallocate(right_node.node.cast(), Layout::new::<InternalNode<K, V>>());
            } else {
                Global.deallocate(right_node.node.cast(), Layout::new::<LeafNode<K, V>>());
            }
        }
        result(parent_node, left_node)
    }

    /// Inobatanidza yemubereki kiyi-kukosha vaviri uye maviri ari padyo evana node munzvimbo yekuruboshwe yemwana node uye inodzosera iyo yakadzikira mubereki node.
    ///
    ///
    /// Panics kunze kwekunge isu `.can_merge()`.
    pub fn merge_tracking_parent(self) -> NodeRef<marker::Mut<'a>, K, V, marker::Internal> {
        self.do_merge(|parent, _child| parent)
    }

    /// Inobatanidza yemubereki kiyi-kukosha vaviri uye maviri ari padyo evana node munzvimbo yekuruboshwe yemwana node uye inodzosera iyo mwana node.
    ///
    ///
    /// Panics kunze kwekunge isu `.can_merge()`.
    pub fn merge_tracking_child(self) -> NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal> {
        self.do_merge(|_parent, child| child)
    }

    /// Inobatanidza yemubereki kiyi-kukosha vaviri uye maviri ari padyo evana node munzvimbo yekuruboshwe yemwana node uye anodzosera iyo edge mubato mune iyo mwana node uko iyo yakateedzerwa mwana edge yakaguma,
    ///
    ///
    /// Panics kunze kwekunge isu `.can_merge()`.
    ///
    pub fn merge_tracking_child_edge(
        self,
        track_edge_idx: LeftOrRight<usize>,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        let old_left_len = self.left_child.len();
        let right_len = self.right_child.len();
        assert!(match track_edge_idx {
            LeftOrRight::Left(idx) => idx <= old_left_len,
            LeftOrRight::Right(idx) => idx <= right_len,
        });
        let child = self.merge_tracking_child();
        let new_idx = match track_edge_idx {
            LeftOrRight::Left(idx) => idx,
            LeftOrRight::Right(idx) => old_left_len + 1 + idx,
        };
        unsafe { Handle::new_edge(child, new_idx) }
    }

    /// Inobvisa kiyi-kukosha vaviri kubva kumwana wekuruboshwe uye ndokuiisa mune yakakosha-kukosha chengetedzo yemubereki, uku ichisundidzira iyo yekare mubereki kiyi-kukosha vaviri mumwana chaiye.
    ///
    /// Inodzorera mubato ku edge mumwana wekurudyi unoenderana nekwakatangira edge yakatarwa ne `track_right_edge_idx`.
    ///
    pub fn steal_left(
        mut self,
        track_right_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_left(1);
        unsafe { Handle::new_edge(self.right_child, 1 + track_right_edge_idx) }
    }

    /// Inobvisa kiyi-kukosha vaviri kubva kumwana wekurudyi uye ndokuisa mukiyi-kukosha kukosha kwekuchengeta kwemubereki, uku uchisundidzira wekare mubereki kiyi-kukosha vaviri kumwana wekuruboshwe.
    ///
    /// Inodzorera mubato ku edge mumwana wekuruboshwe unotsanangurwa ne `track_left_edge_idx`, iyo isina kufamba.
    ///
    pub fn steal_right(
        mut self,
        track_left_edge_idx: usize,
    ) -> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
        self.bulk_steal_right(1);
        unsafe { Handle::new_edge(self.left_child, track_left_edge_idx) }
    }

    /// Izvi zvinoita kuba zvakafanana ne `steal_left` asi inoba zvinhu zvakawanda kamwechete.
    pub fn bulk_steal_left(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Iva nechokwadi chekuti tibe zvakachengeteka.
            assert!(old_right_len + count <= CAPACITY);
            assert!(old_left_len >= count);

            let new_left_len = old_left_len - count;
            let new_right_len = old_right_len + count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Fambisa data remashizha.
            {
                // Ita nzvimbo yezvinhu zvakabiwa mumwana chaiye.
                slice_shr(right_node.key_area_mut(..new_right_len), count);
                slice_shr(right_node.val_area_mut(..new_right_len), count);

                // Fambisa zvinhu kubva kumwana wekuruboshwe kuenda kurudyi.
                move_to_slice(
                    left_node.key_area_mut(new_left_len + 1..old_left_len),
                    right_node.key_area_mut(..count - 1),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len + 1..old_left_len),
                    right_node.val_area_mut(..count - 1),
                );

                // Fambisa iro rakasara-rakabiwa vaviri vaviri kumubereki.
                let k = left_node.key_area_mut(new_left_len).assume_init_read();
                let v = left_node.val_area_mut(new_left_len).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Fambisa kiyi-kukosha kwevabereki kumwana chaiye.
                right_node.key_area_mut(count - 1).write(k);
                right_node.val_area_mut(count - 1).write(v);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Ita nzvimbo yemakona akabiwa.
                    slice_shr(right.edge_area_mut(..new_right_len + 1), count);

                    // Kuba micheto.
                    move_to_slice(
                        left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                        right.edge_area_mut(..count),
                    );

                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }

    /// Iyo yakaenzana clone ye `bulk_steal_left`.
    pub fn bulk_steal_right(&mut self, count: usize) {
        assert!(count > 0);
        unsafe {
            let left_node = &mut self.left_child;
            let old_left_len = left_node.len();
            let right_node = &mut self.right_child;
            let old_right_len = right_node.len();

            // Iva nechokwadi chekuti tibe zvakachengeteka.
            assert!(old_left_len + count <= CAPACITY);
            assert!(old_right_len >= count);

            let new_left_len = old_left_len + count;
            let new_right_len = old_right_len - count;
            *left_node.len_mut() = new_left_len as u16;
            *right_node.len_mut() = new_right_len as u16;

            // Fambisa data remashizha.
            {
                // Fambisa iwo maviri-akanyanya kubiwa mapaundi kumubereki.
                let k = right_node.key_area_mut(count - 1).assume_init_read();
                let v = right_node.val_area_mut(count - 1).assume_init_read();
                let (k, v) = self.parent.replace_kv(k, v);

                // Fambisa kiyi-kukosha kwevabereki kumwana wekuruboshwe.
                left_node.key_area_mut(old_left_len).write(k);
                left_node.val_area_mut(old_left_len).write(v);

                // Fambisa zvinhu kubva kumwana wekurudyi uchienda kuruboshwe.
                move_to_slice(
                    right_node.key_area_mut(..count - 1),
                    left_node.key_area_mut(old_left_len + 1..new_left_len),
                );
                move_to_slice(
                    right_node.val_area_mut(..count - 1),
                    left_node.val_area_mut(old_left_len + 1..new_left_len),
                );

                // Zadza mukaha paimbove nezvinhu zvakabiwa.
                slice_shl(right_node.key_area_mut(..old_right_len), count);
                slice_shl(right_node.val_area_mut(..old_right_len), count);
            }

            match (left_node.reborrow_mut().force(), right_node.reborrow_mut().force()) {
                (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                    // Kuba micheto.
                    move_to_slice(
                        right.edge_area_mut(..count),
                        left.edge_area_mut(old_left_len + 1..new_left_len + 1),
                    );

                    // Zadza mukaha pakange paine mitsara yakabiwa.
                    slice_shl(right.edge_area_mut(..old_right_len + 1), count);

                    left.correct_childrens_parent_links(old_left_len + 1..new_left_len + 1);
                    right.correct_childrens_parent_links(0..new_right_len + 1);
                }
                (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                _ => unreachable!(),
            }
        }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Leaf> {
    /// Inobvisa chero ruzivo rwekusimudzira kusimbisa kuti iyi node ndeye `Leaf` node.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> NodeRef<BorrowType, K, V, marker::Internal> {
    /// Inobvisa chero ruzivo rwekusimudzira kusimbisa kuti iyi node ndeye `Internal` node.
    pub fn forget_type(self) -> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
        NodeRef { height: self.height, node: self.node, _marker: PhantomData }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::Edge> {
        unsafe { Handle::new_edge(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V> Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV> {
    pub fn forget_node_type(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV> {
        unsafe { Handle::new_kv(self.node.forget_type(), self.idx) }
    }
}

impl<BorrowType, K, V, Type> Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, Type> {
    /// Inotarisa kuti iyo yepasi node ndeye `Internal` node kana `Leaf` node.
    pub fn force(
        self,
    ) -> ForceResult<
        Handle<NodeRef<BorrowType, K, V, marker::Leaf>, Type>,
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, Type>,
    > {
        match self.node.force() {
            ForceResult::Leaf(node) => {
                ForceResult::Leaf(Handle { node, idx: self.idx, _marker: PhantomData })
            }
            ForceResult::Internal(node) => {
                ForceResult::Internal(Handle { node, idx: self.idx, _marker: PhantomData })
            }
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::Edge> {
    /// Fambisa chinokwana mushure me `self` kubva pane imwe node kuenda kune imwe.`right` inofanira kunge isina chinhu.
    /// Yekutanga edge ye `right` inoramba isina kuchinja.
    pub fn move_suffix(
        &mut self,
        right: &mut NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>,
    ) {
        unsafe {
            let new_left_len = self.idx;
            let mut left_node = self.reborrow_mut().into_node();
            let old_left_len = left_node.len();

            let new_right_len = old_left_len - new_left_len;
            let mut right_node = right.reborrow_mut();

            assert!(right_node.len() == 0);
            assert!(left_node.height == right_node.height);

            if new_right_len > 0 {
                *left_node.len_mut() = new_left_len as u16;
                *right_node.len_mut() = new_right_len as u16;

                move_to_slice(
                    left_node.key_area_mut(new_left_len..old_left_len),
                    right_node.key_area_mut(..new_right_len),
                );
                move_to_slice(
                    left_node.val_area_mut(new_left_len..old_left_len),
                    right_node.val_area_mut(..new_right_len),
                );
                match (left_node.force(), right_node.force()) {
                    (ForceResult::Internal(mut left), ForceResult::Internal(mut right)) => {
                        move_to_slice(
                            left.edge_area_mut(new_left_len + 1..old_left_len + 1),
                            right.edge_area_mut(1..new_right_len + 1),
                        );
                        right.correct_childrens_parent_links(1..new_right_len + 1);
                    }
                    (ForceResult::Leaf(_), ForceResult::Leaf(_)) => {}
                    _ => unreachable!(),
                }
            }
        }
    }
}

pub enum ForceResult<Leaf, Internal> {
    Leaf(Leaf),
    Internal(Internal),
}

/// Mhedzisiro yekuisirwa, apo node inoda kuwedzera kupfuura kwayinoita.
pub struct SplitResult<'a, K, V, NodeType> {
    // Yakagadziriswa node mumuti uripo une zvinhu uye micheto zviri zvekuruboshwe kwe `kv`.
    pub left: NodeRef<marker::Mut<'a>, K, V, NodeType>,
    // Imwe kiyi uye kukosha kwakakamurwa, kuti iiswe kumwe kunhu.
    pub kv: (K, V),
    // Yawe, isina kunamatira, node nyowani ine zvinhu nemipendero iri kurudyi rwe `kv`.
    pub right: NodeRef<marker::Owned, K, V, NodeType>,
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Leaf> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

impl<'a, K, V> SplitResult<'a, K, V, marker::Internal> {
    pub fn forget_node_type(self) -> SplitResult<'a, K, V, marker::LeafOrInternal> {
        SplitResult { left: self.left.forget_type(), kv: self.kv, right: self.right.forget_type() }
    }
}

pub enum InsertResult<'a, K, V, NodeType> {
    Fit(Handle<NodeRef<marker::Mut<'a>, K, V, NodeType>, marker::KV>),
    Split(SplitResult<'a, K, V, NodeType>),
}

pub mod marker {
    use core::marker::PhantomData;

    pub enum Leaf {}
    pub enum Internal {}
    pub enum LeafOrInternal {}

    pub enum Owned {}
    pub enum Dying {}
    pub struct Immut<'a>(PhantomData<&'a ()>);
    pub struct Mut<'a>(PhantomData<&'a mut ()>);
    pub struct ValMut<'a>(PhantomData<&'a mut ()>);

    pub trait BorrowType {
        // Kunyangwe node mareferenzi erudzi urwu rwechikwereti anotendera kuyambuka kune mamwe maodhi mumuti.
        //
        const PERMITS_TRAVERSAL: bool = true;
    }
    impl BorrowType for Owned {
        // Traversal haina kudikanwa, zvinoitika uchishandisa mhedzisiro ye `borrow_mut`.
        // Nekuremadza kuyambuka, uye nekugadzira chete mareferenzi matsva kumidzi, tinoziva kuti kwese kutaurwa kwerudzi rwe `Owned` kune midzi node.
        //
        const PERMITS_TRAVERSAL: bool = false;
    }
    impl BorrowType for Dying {}
    impl<'a> BorrowType for Immut<'a> {}
    impl<'a> BorrowType for Mut<'a> {}
    impl<'a> BorrowType for ValMut<'a> {}

    pub enum KV {}
    pub enum Edge {}
}

/// Inoisa kukosha muchidimbu chezvinhu zvakatangwa zvichiteverwa nechinhu chisina kuvhurwa.
///
/// # Safety
/// Chidimbu chine zvinopfuura `idx` zvinhu.
unsafe fn slice_insert<T>(slice: &mut [MaybeUninit<T>], idx: usize, val: T) {
    unsafe {
        let len = slice.len();
        debug_assert!(len > idx);
        let slice_ptr = slice.as_mut_ptr();
        if len > idx + 1 {
            ptr::copy(slice_ptr.add(idx), slice_ptr.add(idx + 1), len - idx - 1);
        }
        (*slice_ptr.add(idx)).write(val);
    }
}

/// Inobvisa uye inodzosera kukosha kubva kuchidimbu chezvinhu zvese zvakatangwa, ichisiya imwe chete yekutevera isina kuvhurwa chinhu.
///
///
/// # Safety
/// Chidimbu chine zvinopfuura `idx` zvinhu.
unsafe fn slice_remove<T>(slice: &mut [MaybeUninit<T>], idx: usize) -> T {
    unsafe {
        let len = slice.len();
        debug_assert!(idx < len);
        let slice_ptr = slice.as_mut_ptr();
        let ret = (*slice_ptr.add(idx)).assume_init_read();
        ptr::copy(slice_ptr.add(idx + 1), slice_ptr.add(idx), len - idx - 1);
        ret
    }
}

/// Inoshandura zvinhu muchidimbu `distance` nzvimbo kuruboshwe.
///
/// # Safety
/// Chidimbu chine angangoita `distance` zvinhu.
unsafe fn slice_shl<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr.add(distance), slice_ptr, slice.len() - distance);
    }
}

/// Inochinjisa zvinhu muchidimbu `distance` zvinzvimbo kurudyi.
///
/// # Safety
/// Chidimbu chine angangoita `distance` zvinhu.
unsafe fn slice_shr<T>(slice: &mut [MaybeUninit<T>], distance: usize) {
    unsafe {
        let slice_ptr = slice.as_mut_ptr();
        ptr::copy(slice_ptr, slice_ptr.add(distance), slice.len() - distance);
    }
}

/// Inofambisa kukosha kwese kubva kuchidimbu chezvinhu zvakatangwa kuenda kuchidimbu chezvinhu zvisina kuvambwa, zvichisiya `src` seese asina kuvhurwa.
///
/// Inoshanda se `dst.copy_from_slice(src)` asi haidi `T` kuve `Copy`.
fn move_to_slice<T>(src: &mut [MaybeUninit<T>], dst: &mut [MaybeUninit<T>]) {
    assert!(src.len() == dst.len());
    unsafe {
        ptr::copy_nonoverlapping(src.as_ptr(), dst.as_mut_ptr(), src.len());
    }
}

#[cfg(test)]
mod tests;