use super::merge_iter::MergeIterInner;
use super::node::{self, Root};
use core::iter::FusedIterator;

impl<K, V> Root<K, V> {
    /// Inoisa ese akakosha-kukosha mapara kubva mubatanidzwa wevaviri vari kukwira iterators, vachiwedzera iyo `length` kusiana munzira.Iyo yekupedzisira inoita kuti zvive nyore kune iye anofona kuti arege kubuda kana donhi rinobata rikavhunduka.
    ///
    /// Kana mairi mairi maiterator akagadzira kiyi imwechete, nzira iyi inodonhedza vaviri kubva kuruboshwe iterator uye vanowedzera vaviri kubva kurudyi iterator.
    ///
    /// Kana iwe uchida kuti muti upedzisire muchimiro chakasimba chekukwira, senge `BTreeMap`, maiterator ese ari maviri anofanirwa kuburitsa makiyi mukukwira kwakasimba, imwe neimwe yakakura kudarika makiyi ese mumuti, kusanganisira chero makiyi atove mumuti pakapinda.
    ///
    ///
    ///
    ///
    ///
    ///
    pub fn append_from_sorted_iters<I>(&mut self, left: I, right: I, length: &mut usize)
    where
        K: Ord,
        I: Iterator<Item = (K, V)> + FusedIterator,
    {
        // Isu tinogadzirira kubatanidza `left` uye `right` mune yakasarudzika nhevedzano mune mutsara mutsara.
        let iter = MergeIter(MergeIterInner::new(left, right));

        // Zvichakadaro, isu tinovaka muti kubva kune yakarongedzwa kuteedzana mune mutsara mutsara nguva.
        self.bulk_push(iter, length)
    }

    /// Inosundira ese akakosha-kukosha mapara kusvika kumagumo emuti, ichiwedzera iyo `length` kusiana munzira.
    /// Iyo yekupedzisira inoita kuti zvive nyore kune ari kufona kuti adzivirire kubuda kana iyo iterator ichivhunduka.
    ///
    pub fn bulk_push<I>(&mut self, iter: I, length: &mut usize)
    where
        I: Iterator<Item = (K, V)>,
    {
        let mut cur_node = self.borrow_mut().last_leaf_edge().into_node();
        // Iterate kuburikidza nekiyi-kukosha mapara, ichivasundira munzvimbo dzematanho padanho chairo.
        for (key, value) in iter {
            // Edza Push key-value pair mune yazvino shizha node.
            if cur_node.len() < node::CAPACITY {
                cur_node.push(key, value);
            } else {
                // Hapana nzvimbo yasara, kwira upinze ipapo.
                let mut open_node;
                let mut test_node = cur_node.forget_type();
                loop {
                    match test_node.ascend() {
                        Ok(parent) => {
                            let parent = parent.into_node();
                            if parent.len() < node::CAPACITY {
                                // Tsvaga node ine nzvimbo yakasara, Push apa.
                                open_node = parent;
                                break;
                            } else {
                                // Endai zvakare.
                                test_node = parent.forget_type();
                            }
                        }
                        Err(_) => {
                            // Isu tiri kumusoro, gadzira nyowani midzi node uye Push ipapo.
                            open_node = self.push_internal_level();
                            break;
                        }
                    }
                }

                // Push key-value pair uye mutsva kurudyi subtree.
                let tree_height = open_node.height() - 1;
                let mut right_tree = Root::new();
                for _ in 0..tree_height {
                    right_tree.push_internal_level();
                }
                open_node.push(key, value, right_tree);

                // Enda pasi kurudyi-rakawanda shizha zvakare.
                cur_node = open_node.forget_type().last_leaf_edge().into_node();
            }

            // Yekuwedzera kureba kwese kukokorodza, kuve nechokwadi chekuti mepu inodonhedza zvinhu zvakawedzeredzwa kunyangwe ikasimudzira iyo iterator panicks.
            //
            *length += 1;
        }
        self.fix_right_border_of_plentiful();
    }
}

// Iyo iterator yekubatanidza maviri akarongedzwa akateedzana kuita imwe
struct MergeIter<K, V, I: Iterator<Item = (K, V)>>(MergeIterInner<I>);

impl<K: Ord, V, I> Iterator for MergeIter<K, V, I>
where
    I: Iterator<Item = (K, V)> + FusedIterator,
{
    type Item = (K, V);

    /// Kana makiyi maviri akaenzana, anodzosera iyo kiyi-kukosha vaviri kubva kurudyi sosi.
    fn next(&mut self) -> Option<(K, V)> {
        let (a_next, b_next) = self.0.nexts(|a: &(K, V), b: &(K, V)| K::cmp(&a.0, &b.0));
        b_next.or(a_next)
    }
}