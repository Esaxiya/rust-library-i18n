use crate::fmt::Debug;
use std::cmp::Ordering;
use std::sync::atomic::{AtomicUsize, Ordering::SeqCst};

/// Chirongwa chekupaza test dummy zviitiko zvinotarisa zvimwe zviitiko.
/// Dzimwe zviitiko zvinogona kugadzirirwa ku panic pane imwe nguva.
/// Zviitiko zviri `clone`, `drop` kana imwe isingazivikanwe `query`.
///
/// Crash test dummies anozivikanwa uye akarairwa nedhi, kuti agone kushandiswa sekiyi muBTreeMap.
/// Iko kumisikidza kushandisa nemaune hakutsamiri pane chero chinhu chinotsanangurwa mu crate, kunze kwe `Debug` trait.
///
#[derive(Debug)]
pub struct CrashTestDummy {
    id: usize,
    cloned: AtomicUsize,
    dropped: AtomicUsize,
    queried: AtomicUsize,
}

impl CrashTestDummy {
    /// Inogadzira kupaza bvunzo dummy dhizaini.Iyo `id` inosarudza kurongeka uye kuenzana kwezviitiko.
    pub fn new(id: usize) -> CrashTestDummy {
        CrashTestDummy {
            id,
            cloned: AtomicUsize::new(0),
            dropped: AtomicUsize::new(0),
            queried: AtomicUsize::new(0),
        }
    }

    /// Inogadzira chiitiko chekupaza test dummy iyo inorekodha zviitiko zvayinosangana nazvo uye sarudzo panics.
    ///
    pub fn spawn(&self, panic: Panic) -> Instance<'_> {
        Instance { origin: self, panic }
    }

    /// Inodzorera kangani zviitiko zveiyo dummy yakaumbwa.
    pub fn cloned(&self) -> usize {
        self.cloned.load(SeqCst)
    }

    /// Inodzosera kangani zviitiko zveiyo dummy zvakadonhedzwa.
    pub fn dropped(&self) -> usize {
        self.dropped.load(SeqCst)
    }

    /// Inodzorera kangani zviitiko zveiyo dummy yakave nenhengo yavo ye `query` yakokwa.
    pub fn queried(&self) -> usize {
        self.queried.load(SeqCst)
    }
}

#[derive(Debug)]
pub struct Instance<'a> {
    origin: &'a CrashTestDummy,
    panic: Panic,
}

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum Panic {
    Never,
    InClone,
    InDrop,
    InQuery,
}

impl Instance<'_> {
    pub fn id(&self) -> usize {
        self.origin.id
    }

    /// Imwe isingazivikanwe mubvunzo, mhedzisiro yacho yatove kupihwa.
    pub fn query<R>(&self, result: R) -> R {
        self.origin.queried.fetch_add(1, SeqCst);
        if self.panic == Panic::InQuery {
            panic!("panic in `query`");
        }
        result
    }
}

impl Clone for Instance<'_> {
    fn clone(&self) -> Self {
        self.origin.cloned.fetch_add(1, SeqCst);
        if self.panic == Panic::InClone {
            panic!("panic in `clone`");
        }
        Self { origin: self.origin, panic: Panic::Never }
    }
}

impl Drop for Instance<'_> {
    fn drop(&mut self) {
        self.origin.dropped.fetch_add(1, SeqCst);
        if self.panic == Panic::InDrop {
            panic!("panic in `drop`");
        }
    }
}

impl PartialOrd for Instance<'_> {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.id().partial_cmp(&other.id())
    }
}

impl Ord for Instance<'_> {
    fn cmp(&self, other: &Self) -> Ordering {
        self.id().cmp(&other.id())
    }
}

impl PartialEq for Instance<'_> {
    fn eq(&self, other: &Self) -> bool {
        self.id().eq(&other.id())
    }
}

impl Eq for Instance<'_> {}