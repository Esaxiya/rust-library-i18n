use super::map::MIN_LEN;
use super::node::{marker, ForceResult::*, Handle, LeftOrRight::*, NodeRef};

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::LeafOrInternal>, marker::KV> {
    /// Inobvisa kiyi-kukosha peya kubva pamuti, uye inodzosera iwo maviri, pamwe neiyo shizha edge rinoenderana neyaimbove maviri maviri.
    /// Zvinogoneka izvi zvinoburitsa mudzi node iri mukati, iyo inofona inofanira kubuda kubva pamepu yakabata muti.
    /// Anofona anofanirwa zvakare kudzikisa kureba kwemepu.
    ///
    pub fn remove_kv_tracking<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        match self.force() {
            Leaf(node) => node.remove_leaf_kv(handle_emptied_internal_root),
            Internal(node) => node.remove_internal_kv(handle_emptied_internal_root),
        }
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::KV> {
    fn remove_leaf_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        let (old_kv, mut pos) = self.remove();
        let len = pos.reborrow().into_node().len();
        if len < MIN_LEN {
            let idx = pos.idx();
            // Isu tinofanirwa kukanganwa kwechinguva mhando yemwana, nekuti hapana imwe yakasarudzika node mhando yevabereki varipo veshizha.
            //
            let new_pos = match pos.into_node().forget_type().choose_parent_kv() {
                Ok(Left(left_parent_kv)) => {
                    debug_assert!(left_parent_kv.right_child_len() == MIN_LEN - 1);
                    if left_parent_kv.can_merge() {
                        left_parent_kv.merge_tracking_child_edge(Right(idx))
                    } else {
                        debug_assert!(left_parent_kv.left_child_len() > MIN_LEN);
                        left_parent_kv.steal_left(idx)
                    }
                }
                Ok(Right(right_parent_kv)) => {
                    debug_assert!(right_parent_kv.left_child_len() == MIN_LEN - 1);
                    if right_parent_kv.can_merge() {
                        right_parent_kv.merge_tracking_child_edge(Left(idx))
                    } else {
                        debug_assert!(right_parent_kv.right_child_len() > MIN_LEN);
                        right_parent_kv.steal_right(idx)
                    }
                }
                Err(pos) => unsafe { Handle::new_edge(pos, idx) },
            };
            // KUCHENGETEKA: `new_pos` ndiro shizha ratakatanga kubva kana hama.
            pos = unsafe { new_pos.cast_to_leaf_unchecked() };

            // Chete kana isu tikasangana, mubereki (kana paine) akadonha, asi kusvetuka nhanho inotevera neimwe nzira hakubhadhare mumabhenji.
            //
            // Kachengeteka: Hatisi kuzoparadza kana kugadzirisa patsva shizha uko `pos` iriko
            // nekubata mubereki wayo achidzokorora;pakaipisisa isu tichaparadza kana kurongedzerazve mubereki kuburikidza nasekuru nasekuru, nokudaro chinja chinongedzo kumubereki mukati mekashizha.
            //
            //
            //
            if let Ok(parent) = unsafe { pos.reborrow_mut() }.into_node().ascend() {
                if !parent.into_node().forget_type().fix_node_and_affected_ancestors() {
                    handle_emptied_internal_root();
                }
            }
        }
        (old_kv, pos)
    }
}

impl<'a, K: 'a, V: 'a> Handle<NodeRef<marker::Mut<'a>, K, V, marker::Internal>, marker::KV> {
    fn remove_internal_kv<F: FnOnce()>(
        self,
        handle_emptied_internal_root: F,
    ) -> ((K, V), Handle<NodeRef<marker::Mut<'a>, K, V, marker::Leaf>, marker::Edge>) {
        // Bvisa KV iri padhuze kubva pane shizha rayo wozoidzosera panzvimbo yechinhu chatakakumbirwa kubvisa.
        //
        // Sarudza kuruboshwe padyo neKV, nekuda kwezvikonzero zvakanyorwa mu `choose_parent_kv`.
        let left_leaf_kv = self.left_edge().descend().last_leaf_edge().left_kv();
        let left_leaf_kv = unsafe { left_leaf_kv.ok().unwrap_unchecked() };
        let (left_kv, left_hole) = left_leaf_kv.remove_leaf_kv(handle_emptied_internal_root);

        // Iyo yemukati node inogona kunge yakabiwa kubva kana kubatanidzwa.
        // Dzokera kurudyi kuti uwane kuti iyo yekutanga KV yakaguma kupi.
        let mut internal = unsafe { left_hole.next_kv().ok().unwrap_unchecked() };
        let old_kv = internal.replace_kv(left_kv.0, left_kv.1);
        let pos = internal.next_leaf_edge();
        (old_kv, pos)
    }
}