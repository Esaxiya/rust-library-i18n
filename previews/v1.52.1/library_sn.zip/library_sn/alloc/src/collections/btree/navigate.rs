use core::borrow::Borrow;
use core::ops::RangeBounds;
use core::ptr;

use super::node::{marker, ForceResult::*, Handle, NodeRef};

pub struct LeafRange<BorrowType, K, V> {
    pub front: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
    pub back: Option<Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>>,
}

impl<BorrowType, K, V> LeafRange<BorrowType, K, V> {
    pub fn none() -> Self {
        LeafRange { front: None, back: None }
    }

    pub fn is_empty(&self) -> bool {
        self.front == self.back
    }

    /// Kwechinguva anotora imwe, isingachinjiki yakaenzana yeiyo yakafanana renji.
    pub fn reborrow(&self) -> LeafRange<marker::Immut<'_>, K, V> {
        LeafRange {
            front: self.front.as_ref().map(|f| f.reborrow()),
            back: self.back.as_ref().map(|b| b.reborrow()),
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Inotsvaga iwo akasarudzika mashizha emicheto achigadzirisa yakatarwa renji mumuti.
    /// Inodzosera chero maviri maviri emabatiro akasiyana mumuti mumwe chete kana mbiri yesarudzo isina chinhu.
    ///
    /// # Safety
    ///
    /// Kunze kwekunge `BorrowType` iri `Immut`, usashandise mabhii maviri ekushanyira iyo imwechete KV kaviri.
    unsafe fn find_leaf_edges_spanning_range<Q: ?Sized, R>(
        self,
        range: R,
    ) -> LeafRange<BorrowType, K, V>
    where
        Q: Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        match self.search_tree_for_bifurcation(&range) {
            Err(_) => LeafRange::none(),
            Ok((
                node,
                lower_edge_idx,
                upper_edge_idx,
                mut lower_child_bound,
                mut upper_child_bound,
            )) => {
                let mut lower_edge = unsafe { Handle::new_edge(ptr::read(&node), lower_edge_idx) };
                let mut upper_edge = unsafe { Handle::new_edge(node, upper_edge_idx) };
                loop {
                    match (lower_edge.force(), upper_edge.force()) {
                        (Leaf(f), Leaf(b)) => return LeafRange { front: Some(f), back: Some(b) },
                        (Internal(f), Internal(b)) => {
                            (lower_edge, lower_child_bound) =
                                f.descend().find_lower_bound_edge(lower_child_bound);
                            (upper_edge, upper_child_bound) =
                                b.descend().find_upper_bound_edge(upper_child_bound);
                        }
                        _ => unreachable!("BTreeMap has different depths"),
                    }
                }
            }
        }
    }
}

/// Yakaenzana ne `(root1.first_leaf_edge(), root2.last_leaf_edge())` asi inoshanda zvakanyanya.
fn full_range<BorrowType: marker::BorrowType, K, V>(
    root1: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    root2: NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
) -> LeafRange<BorrowType, K, V> {
    let mut min_node = root1;
    let mut max_node = root2;
    loop {
        let front = min_node.first_edge();
        let back = max_node.last_edge();
        match (front.force(), back.force()) {
            (Leaf(f), Leaf(b)) => {
                return LeafRange { front: Some(f), back: Some(b) };
            }
            (Internal(min_int), Internal(max_int)) => {
                min_node = min_int.descend();
                max_node = max_int.descend();
            }
            _ => unreachable!("BTreeMap has different depths"),
        };
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Inotsvaga iwo maviri emashizha mativi achiganhurisa yakatarwa renji mumuti.
    ///
    /// Mhedzisiro yacho inoreva chete kana muti ukarairwa nekiyi, semuti uri mu `BTreeMap` iri.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::Immut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        // Kachengeteka: yedu yekukwereta mhando haichinjiki.
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Inotsvaga iwo maviri emashizha micheto achigadzirisa muti wese.
    pub fn full_range(self) -> LeafRange<marker::Immut<'a>, K, V> {
        full_range(self, self)
    }
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::ValMut<'a>, K, V, marker::LeafOrInternal> {
    /// Inopatsanura yakasarudzika mareferenzi mune maviri emashizha micheto kutemesa yakatarwa renji.
    /// Mhedzisiro yacho ndeye asiri-akasarudzika mareferensi anotendera (some) shanduko, iyo inofanirwa kushandiswa zvine hungwaru.
    ///
    /// Mhedzisiro yacho inoreva chete kana muti ukarairwa nekiyi, semuti uri mu `BTreeMap` iri.
    ///
    ///
    /// # Safety
    /// Usashandise zvimiro zvekubata kushanyira iyo imwechete KV kaviri.
    ///
    pub fn range_search<Q, R>(self, range: R) -> LeafRange<marker::ValMut<'a>, K, V>
    where
        Q: ?Sized + Ord,
        K: Borrow<Q>,
        R: RangeBounds<Q>,
    {
        unsafe { self.find_leaf_edges_spanning_range(range) }
    }

    /// Inopatsanura yakasarudzika mareferenzi mune maviri emashizha micheto inokamura yakazara izere yemuti.
    /// Mhedzisiro yacho haina-yakasarudzika mareferensi anotendera shanduko (yemitengo chete), saka inofanirwa kushandiswa nehanya.
    ///
    pub fn full_range(self) -> LeafRange<marker::ValMut<'a>, K, V> {
        // Isu tinodzokorora mudzi NodeRef pano-hatife takashanyira iyo imwechete KV kaviri, uye hatife takaguma nekupindirana kwekukosha mareferensi.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<K, V> NodeRef<marker::Dying, K, V, marker::LeafOrInternal> {
    /// Inopatsanura yakasarudzika mareferenzi mune maviri emashizha micheto inokamura yakazara izere yemuti.
    /// Mhedzisiro yacho ndeye isiri-yakasarudzika mareferensi anotendera zvakanyanya kuparadza shanduko, saka inofanirwa kushandiswa nehanya kwazvo.
    ///
    pub fn full_range(self) -> LeafRange<marker::Dying, K, V> {
        // Isu tinodzokorora mudzi NodeRef pano-hatife takaiwana nenzira inopfuura mareferenzi akawanikwa kubva pamudzi.
        //
        let self2 = unsafe { ptr::read(&self) };
        full_range(self, self2)
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge>
{
    /// Kupiwa shizha edge mubato, inodzosera [`Result::Ok`] nemubato kune yakavakidzana KV kurudyi, iri mune imwechete shizha pfundo kana mune yemadzitateguru node.
    ///
    /// Kana iro zhizha edge iri rekupedzisira mumuti, rinodzosera [`Result::Err`] ine mudzi node.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }

    /// Kupiwa shizha edge mubato, inodzosera [`Result::Ok`] nemubato kune yakavakidzana KV kuruboshwe, irimo mune imwecheteyo shizha pfundo kana mune yemadzitateguru node.
    ///
    /// Kana iro zhizha edge iri rekutanga mumuti, rinodzosera [`Result::Err`] ine mudzi node.
    pub fn next_back_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::LeafOrInternal>,
    > {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => return Ok(kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge.forget_node_type(),
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::Edge>
{
    /// Kupihwa yemukati edge mubato, inodzosera [`Result::Ok`] nemubato kune yakavakidzana KV kurudyi, iri mune imwechete yemukati node kana mune yemadzitateguru node.
    ///
    /// Kana iyo yemukati edge iri yekupedzisira mumuti, inodzosera [`Result::Err`] ine mudzi node.
    pub fn next_kv(
        self,
    ) -> Result<
        Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>,
        NodeRef<BorrowType, K, V, marker::Internal>,
    > {
        let mut edge = self;
        loop {
            edge = match edge.right_kv() {
                Ok(internal_kv) => return Ok(internal_kv),
                Err(last_edge) => match last_edge.into_node().ascend() {
                    Ok(parent_edge) => parent_edge,
                    Err(root) => return Err(root),
                },
            }
        }
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Kupiwa shizha edge mubato mumuti unofa, unodzorera rinotevera shizha edge kurudyi, uye kiyi-kukosha vaviri pakati, iri mune imwechete shizha node, mune yemadzitateguru node, kana isipo.
    ///
    ///
    /// Iyi nzira inobatawo chero node(s) inosvika kumagumo e.
    /// Izvi zvinoreva kuti kana pasisina imwe kiyi-kukosha pairi iripo, iyo yasara yemuti inenge yatakurwa uye hapana chakasara kudzoka.
    ///
    /// # Safety
    /// Iyo yakapihwa edge haifanire kunge yakambodzoserwa nemumwe shamwari `deallocating_next_back`.
    ///
    ///
    ///
    unsafe fn deallocating_next(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.right_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Kupiwa shizha edge mubato mumuti unofa, unodzosera shizha rinotevera edge kuruboshwe, uye yakakosha-kukosha vaviri pakati, iri mune imwe chete node yemashizha, munzvimbo yemadzitateguru, kana kusavapo.
    ///
    ///
    /// Iyi nzira inobatawo chero node(s) inosvika kumagumo e.
    /// Izvi zvinoreva kuti kana pasisina imwe kiyi-kukosha pairi iripo, iyo yasara yemuti inenge yatakurwa uye hapana chakasara kudzoka.
    ///
    /// # Safety
    /// Iyo yakapihwa edge haifanire kunge yakambodzoserwa nemumwe shamwari `deallocating_next`.
    ///
    ///
    ///
    unsafe fn deallocating_next_back(self) -> Option<(Self, (K, V))> {
        let mut edge = self.forget_node_type();
        loop {
            edge = match edge.left_kv() {
                Ok(kv) => {
                    let k = unsafe { ptr::read(kv.reborrow().into_kv().0) };
                    let v = unsafe { ptr::read(kv.reborrow().into_kv().1) };
                    return Some((kv.next_back_leaf_edge(), (k, v)));
                }
                Err(last_edge) => match unsafe { last_edge.into_node().deallocate_and_ascend() } {
                    Some(parent_edge) => parent_edge.forget_node_type(),
                    None => return None,
                },
            }
        }
    }

    /// Inobvisa murwi wemapfundo kubva pashizha kusvika pamudzi.
    /// Iyi ndiyo chete nzira yekuendesa iyo yasara yemuti mushure me `deallocating_next` uye `deallocating_next_back` yanga ichingobaya pamativi ese emuti, uye yakarova imwechete edge.
    /// Sezvo zvakagadzirirwa chete kudaidzwa kana makiyi ese nemitengo zvadzoserwa, hapana kuchenesa kunoitwa pane chero kiyi kana kukosha.
    ///
    ///
    ///
    pub fn deallocating_end(self) {
        let mut edge = self.forget_node_type();
        while let Some(parent_edge) = unsafe { edge.into_node().deallocate_and_ascend() } {
            edge = parent_edge.forget_node_type();
        }
    }
}

impl<'a, K, V> Handle<NodeRef<marker::Immut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Inofambisa shizha edge rinobata kune rinotevera shizha edge uye rinodzosera mareferensi kukiyi uye kukosha pakati.
    ///
    ///
    /// # Safety
    /// Panofanira kunge paine imwe KV munzira yaifambwa.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_leaf_edge(), kv.into_kv())
        })
    }

    /// Inofambisa shizha edge rinobata kune iro rapfuura shizha edge uye rinodzosera mareferensi kukiyi uye kukosha pakati.
    ///
    ///
    /// # Safety
    /// Panofanira kunge paine imwe KV munzira yaifambwa.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a V) {
        super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (kv.next_back_leaf_edge(), kv.into_kv())
        })
    }
}

impl<'a, K, V> Handle<NodeRef<marker::ValMut<'a>, K, V, marker::Leaf>, marker::Edge> {
    /// Inofambisa shizha edge rinobata kune rinotevera shizha edge uye rinodzosera mareferensi kukiyi uye kukosha pakati.
    ///
    ///
    /// # Safety
    /// Panofanira kunge paine imwe KV munzira yaifambwa.
    pub unsafe fn next_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_leaf_edge(), kv)
        });
        // Kuita izvi zvekupedzisira kunokurumidza, zvinoenderana nezviratidzo.
        kv.into_kv_valmut()
    }

    /// Inofambisa shizha edge rinobata kune iro rapfuura shizha uye rinodzosera mareferensi kukiyi uye kukosha kuri pakati.
    ///
    ///
    /// # Safety
    /// Panofanira kunge paine imwe KV munzira yaifambwa.
    pub unsafe fn next_back_unchecked(&mut self) -> (&'a K, &'a mut V) {
        let kv = super::mem::replace(self, |leaf_edge| {
            let kv = leaf_edge.next_back_kv();
            let kv = unsafe { kv.ok().unwrap_unchecked() };
            (unsafe { ptr::read(&kv) }.next_back_leaf_edge(), kv)
        });
        // Kuita izvi zvekupedzisira kunokurumidza, zvinoenderana nezviratidzo.
        kv.into_kv_valmut()
    }
}

impl<K, V> Handle<NodeRef<marker::Dying, K, V, marker::Leaf>, marker::Edge> {
    /// Inosimudza shizha edge mubato kune rinotevera shizha edge uye rinodzosera kiyi uye kukosha pakati, kufambisa chero node yakasara kumashure ichisiya inoenderana edge mune yayo yemubereki node yakaturika.
    ///
    /// # Safety
    /// - Panofanira kunge paine imwe KV munzira yaifambwa.
    /// - Iyo KV haina kumbodzoserwa nemumwe `next_back_unchecked` pane chero kopi yemabatiro ari kushandiswa kuyambuka muti.
    ///
    /// Iyo chete nzira yakachengeteka yekuenderera neyakagadziridzwa mubato ndeye kuenzanisa iyo, kuidonhedza, kufonera iyi nzira zvakare zvichienderana nemamiriro ayo ekuchengetedza, kana kufonera shamwari `next_back_unchecked` zvichienderana nemamiriro ayo ekuchengetedza.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next().unwrap_unchecked()
        })
    }

    /// Inofambisa shizha edge rinobata kune rakapfuura shizha edge uye rinodzosera kiyi uye kukosha pakati, kufambisa chero node yakasara kumashure ichisiya inoenderana edge mune yayo yemubereki node yakaturika.
    ///
    /// # Safety
    /// - Panofanira kunge paine imwe KV munzira yaifambwa.
    /// - Shizha iro edge harina kumbodzoserwa nemumwe `next_unchecked` pane chero kopi yemabatiro ari kushandiswa kuyambuka muti.
    ///
    /// Iyo chete nzira yakachengeteka yekuenderera neyakagadziridzwa mubato ndeye kuenzanisa iyo, kuidonhedza, kufonera iyi nzira zvakare zvichienderana nemamiriro ayo ekuchengetedza, kana kufonera shamwari `next_unchecked` zvichienderana nemamiriro ayo ekuchengetedza.
    ///
    ///
    ///
    ///
    ///
    pub unsafe fn deallocating_next_back_unchecked(&mut self) -> (K, V) {
        super::mem::replace(self, |leaf_edge| unsafe {
            leaf_edge.deallocating_next_back().unwrap_unchecked()
        })
    }
}

impl<BorrowType: marker::BorrowType, K, V> NodeRef<BorrowType, K, V, marker::LeafOrInternal> {
    /// Inodzorera shizha rekuruboshwe edge mukati kana pasi penzvimbo, mune mamwe mazwi, iyo edge iwe yaunoda kutanga kana uchienda kumberi (kana kwekupedzisira kana uchidzokera kumashure).
    ///
    #[inline]
    pub fn first_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.first_edge(),
                Internal(internal) => node = internal.first_edge().descend(),
            }
        }
    }

    /// Inodzorera zhizha rekurudyi edge mukati kana pasi penzvimbo, mune mamwe mazwi, iyo edge yaunoda yekupedzisira kana uchienda kumberi (kana kutanga kana uchidzokera kumashure).
    ///
    #[inline]
    pub fn last_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        let mut node = self;
        loop {
            match node.force() {
                Leaf(leaf) => return leaf.last_edge(),
                Internal(internal) => node = internal.last_edge().descend(),
            }
        }
    }
}

pub enum Position<BorrowType, K, V> {
    Leaf(NodeRef<BorrowType, K, V, marker::Leaf>),
    Internal(NodeRef<BorrowType, K, V, marker::Internal>),
    InternalKV(Handle<NodeRef<BorrowType, K, V, marker::Internal>, marker::KV>),
}

impl<'a, K: 'a, V: 'a> NodeRef<marker::Immut<'a>, K, V, marker::LeafOrInternal> {
    /// Anoshanyira node dzemashizha uye emukati maKV achitevedza makiyi ekukwira, uye zvakare anoshanyira node dzemukati zvizere mukudzika kwekutanga odha, zvichireva kuti node dzemukati dzinotangira maKV avo ega uye node dzevana.
    ///
    ///
    pub fn visit_nodes_in_order<F>(self, mut visit: F)
    where
        F: FnMut(Position<marker::Immut<'a>, K, V>),
    {
        match self.force() {
            Leaf(leaf) => visit(Position::Leaf(leaf)),
            Internal(internal) => {
                visit(Position::Internal(internal));
                let mut edge = internal.first_edge();
                loop {
                    edge = match edge.descend().force() {
                        Leaf(leaf) => {
                            visit(Position::Leaf(leaf));
                            match edge.next_kv() {
                                Ok(kv) => {
                                    visit(Position::InternalKV(kv));
                                    kv.right_edge()
                                }
                                Err(_) => return,
                            }
                        }
                        Internal(internal) => {
                            visit(Position::Internal(internal));
                            internal.first_edge()
                        }
                    }
                }
            }
        }
    }

    /// Inoverenga huwandu hwezvinhu mune (sub) muti.
    pub fn calc_length(self) -> usize {
        let mut result = 0;
        self.visit_nodes_in_order(|pos| match pos {
            Position::Leaf(node) => result += node.len(),
            Position::Internal(node) => result += node.len(),
            Position::InternalKV(_) => (),
        });
        result
    }
}

impl<BorrowType: marker::BorrowType, K, V>
    Handle<NodeRef<BorrowType, K, V, marker::LeafOrInternal>, marker::KV>
{
    /// Inodzorera shizha edge padyo neKV yekufambisa kumberi.
    pub fn next_leaf_edge(self) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.right_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.right_edge();
                next_internal_edge.descend().first_leaf_edge()
            }
        }
    }

    /// Inodzorera shizha edge padyo neKV yekudzokera kumashure.
    pub fn next_back_leaf_edge(
        self,
    ) -> Handle<NodeRef<BorrowType, K, V, marker::Leaf>, marker::Edge> {
        match self.force() {
            Leaf(leaf_kv) => leaf_kv.left_edge(),
            Internal(internal_kv) => {
                let next_internal_edge = internal_kv.left_edge();
                next_internal_edge.descend().last_leaf_edge()
            }
        }
    }
}