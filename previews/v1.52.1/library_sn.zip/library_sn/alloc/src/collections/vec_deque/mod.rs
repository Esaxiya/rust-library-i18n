//! Mutsetse wakapetwa kaviri wakaitwa neinokura mhete bhaudhi.
//!
//! Mutsetse uyu une *O*(1) akaiswa amortized kuisa uye kubvisa kubva kumagumo maviri emudziyo.
//! Iyo zvakare ine *O*(1) kunongedza senge vector.
//! Zvinhu zvirimo hazvidiwe kuti zviteedzerwe, uye mutsetse unozotumirwa kana mhando irimo inotumirwa.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::iter::{repeat_with, FromIterator};
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop};
use core::ops::{Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice;

use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;
use crate::vec::Vec;

#[macro_use]
mod macros;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter_mut::IterMut;

mod iter_mut;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::iter::Iter;

mod iter;

use self::pair_slices::PairSlices;

mod pair_slices;

use self::ring_slices::RingSlices;

mod ring_slices;

#[cfg(test)]
mod tests;

const INITIAL_CAPACITY: usize = 7; // 2 ^ 3, 1
const MINIMUM_CAPACITY: usize = 1; // 2, 1

const MAXIMUM_ZST_CAPACITY: usize = 1 << (core::mem::size_of::<usize>() * 8 - 1); // Yakakura kwazvo inogona simba revaviri

/// Mutsetse wakapetwa kaviri wakaitwa neinokura mhete bhaudhi.
///
/// Iko kushandiswa kwe "default" kworudzi urwu semutsetse kushandisa [`push_back`] kuwedzera pamutsetse, uye [`pop_front`] kubvisa kubva pamutsara.
///
/// [`extend`] uye [`append`] Pushira kumashure nenzira iyi, uye iterating pamusoro pe `VecDeque` inoenda kumberi kuenda kumashure.
///
/// Sezvo `VecDeque` iri mhete bhendi, zvinhu zvacho hazvireve kuti zvinoenderana mundangariro.
/// Kana iwe uchida kuwana izvo zvinhu sechidimbu chimwe chete, senge yekunyatsogadzirisa, unogona kushandisa [`make_contiguous`].
/// Iyo inotenderera iyo `VecDeque` kuitira kuti zvinhu zvacho zvisaputire, uye inodzosera chimutswi chinoshanduka kune izvozvi-zvine mutsindo chinhu chinoteedzana.
///
/// [`push_back`]: VecDeque::push_back
/// [`pop_front`]: VecDeque::pop_front
/// [`extend`]: VecDeque::extend
/// [`append`]: VecDeque::append
/// [`make_contiguous`]: VecDeque::make_contiguous
///
///
///
#[cfg_attr(not(test), rustc_diagnostic_item = "vecdeque_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct VecDeque<T> {
    // muswe nemusoro zvirevo mukati meye buffer.
    // Muswe unogara uchinongedzera kuchinhu chekutanga chinogona kuverengerwa, Musoro unogara uchinongedzera panofanirwa kunyorwa dhata.
    //
    // Kana muswe==musoro iwo buffer hauna chinhu.Kureba kweye ringbuffer kunotsanangurwa sedaro pakati pezviviri.
    //
    tail: usize,
    head: usize,
    buf: RawVec<T>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> Clone for VecDeque<T> {
    fn clone(&self) -> VecDeque<T> {
        self.iter().cloned().collect()
    }

    fn clone_from(&mut self, other: &Self) {
        self.truncate(other.len());

        let mut iter = PairSlices::from(self, other);
        while let Some((dst, src)) = iter.next() {
            dst.clone_from_slice(&src);
        }

        if iter.has_remainder() {
            for remainder in iter.remainder() {
                self.extend(remainder.iter().cloned());
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T> Drop for VecDeque<T> {
    fn drop(&mut self) {
        /// Inomhanyisa muparadzi wezvinhu zvese muchidimbu painodonhedzwa (kazhinji kana panguva yekusunungura).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        let (front, back) = self.as_mut_slices();
        unsafe {
            let _back_dropper = Dropper(back);
            // shandisa donhwe re [T]
            ptr::drop_in_place(front);
        }
        // RawVec inobata dhizaini
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for VecDeque<T> {
    /// Inogadzira isina `VecDeque<T>`.
    #[inline]
    fn default() -> VecDeque<T> {
        VecDeque::new()
    }
}

impl<T> VecDeque<T> {
    /// Marginally zviri nyore
    #[inline]
    fn ptr(&self) -> *mut T {
        self.buf.ptr()
    }

    /// Marginally zviri nyore
    #[inline]
    fn cap(&self) -> usize {
        if mem::size_of::<T>() == 0 {
            // Kune zero zero saizi mhando, isu tinogara tiri pazhinji kugona
            MAXIMUM_ZST_CAPACITY
        } else {
            self.buf.capacity()
        }
    }

    /// Chinja ptr kuita chidimbu
    #[inline]
    unsafe fn buffer_as_slice(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.ptr(), self.cap()) }
    }

    /// Chinja ptr kuita mut sl
    #[inline]
    unsafe fn buffer_as_mut_slice(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.ptr(), self.cap()) }
    }

    /// Inofambisa chinhu kubva mubhafa
    #[inline]
    unsafe fn buffer_read(&mut self, off: usize) -> T {
        unsafe { ptr::read(self.ptr().add(off)) }
    }

    /// Anonyora chinhu mune iyo buffer, achiifambisa.
    #[inline]
    unsafe fn buffer_write(&mut self, off: usize, value: T) {
        unsafe {
            ptr::write(self.ptr().add(off), value);
        }
    }

    /// Inodzorera `true` kana iyo buffer iri pazere chinzvimbo.
    #[inline]
    fn is_full(&self) -> bool {
        self.cap() - self.len() == 1
    }

    /// Inodzorera iyo index mune yepasi buffer yeakapihwa zvine musoro element index.
    ///
    #[inline]
    fn wrap_index(&self, idx: usize) -> usize {
        wrap_index(idx, self.cap())
    }

    /// Inodzorera iyo index mune yepasi buffer yeakapihwa zvine musoro element index + addend.
    ///
    #[inline]
    fn wrap_add(&self, idx: usize, addend: usize) -> usize {
        wrap_index(idx.wrapping_add(addend), self.cap())
    }

    /// Inodzorera iyo index mune yepasi buffer yeakapihwa zvine musoro element index, subtrahend.
    ///
    #[inline]
    fn wrap_sub(&self, idx: usize, subtrahend: usize) -> usize {
        wrap_index(idx.wrapping_sub(subtrahend), self.cap())
    }

    /// Inoteedzera inoenderana block block yekuremara len kubva ku src kusvika dst
    #[inline]
    unsafe fn copy(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cpy dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Inoteedzera inoenderana block block yekuremara len kubva ku src kusvika dst
    #[inline]
    unsafe fn copy_nonoverlapping(&self, dst: usize, src: usize, len: usize) {
        debug_assert!(
            dst + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        debug_assert!(
            src + len <= self.cap(),
            "cno dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );
        unsafe {
            ptr::copy_nonoverlapping(self.ptr().add(src), self.ptr().add(dst), len);
        }
    }

    /// Kopa inokwanisa kuputira block ye memory len long kubva src kusvika dest.
    /// (abs(dst - src) + len) haifanirwe kunge yakakura kudarika cap() (Panofanirwa kuve nenharaunda inopfuurira inopindirana pakati pe src ne dest).
    ///
    unsafe fn wrap_copy(&self, dst: usize, src: usize, len: usize) {
        #[allow(dead_code)]
        fn diff(a: usize, b: usize) -> usize {
            if a <= b { b - a } else { a - b }
        }
        debug_assert!(
            cmp::min(diff(dst, src), self.cap() - diff(dst, src)) + len <= self.cap(),
            "wrc dst={} src={} len={} cap={}",
            dst,
            src,
            len,
            self.cap()
        );

        if src == dst || len == 0 {
            return;
        }

        let dst_after_src = self.wrap_sub(dst, src) < len;

        let src_pre_wrap_len = self.cap() - src;
        let dst_pre_wrap_len = self.cap() - dst;
        let src_wraps = src_pre_wrap_len < len;
        let dst_wraps = dst_pre_wrap_len < len;

        match (dst_after_src, src_wraps, dst_wraps) {
            (_, false, false) => {
                // src haina kuputira, dst haina kuputira
                //
                //        S...
                // 1 [_ _ A A B B C C _]
                // 2 [_ _ A A A A B B _] D.
                // .
                // .
                unsafe {
                    self.copy(dst, src, len);
                }
            }
            (false, false, true) => {
                // dst pamberi pe src, src haina kuputira, dst inoputira
                //
                //
                //    S...
                // 1 [A A B B _ _ _ C C]
                // 2 [A A B B _ _ _ A A]
                // 3 [B B B B _ _ _ A A] .. D.
                //
                unsafe {
                    self.copy(dst, src, dst_pre_wrap_len);
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                }
            }
            (true, false, true) => {
                // src pamberi pe dst, src haina kuputira, dst inoputira
                //
                //
                //              S...
                // 1 [C C _ _ _ A A B B]
                // 2 [B B _ _ _ A A B B]
                // 3 [B B _ _ _ A A A A] .. D.
                //
                unsafe {
                    self.copy(0, src + dst_pre_wrap_len, len - dst_pre_wrap_len);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
            (false, true, false) => {
                // dst pamberi pe src, src inoputira, dst haina kuputira
                //
                //
                //    .. S.
                // 1 [C C _ _ _ A A B B]
                // 2 [C C _ _ _ B B B B]
                // 3 [C C _ _ _ B B C C] D...
                //
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                }
            }
            (true, true, false) => {
                // src pamberi pe dst, src inoputira, dst haina kuputira
                //
                //
                //    .. S.
                // 1 [A A B B _ _ _ C C]
                // 2 [A A A A _ _ _ C C]
                // 3 [C C A A _ _ _ C C] D...
                //
                unsafe {
                    self.copy(dst + src_pre_wrap_len, 0, len - src_pre_wrap_len);
                    self.copy(dst, src, src_pre_wrap_len);
                }
            }
            (false, true, true) => {
                // dst pamberi pe src, src inoputira, dst inoputira
                //
                //
                //    ... S.
                // 1 [A B C D _ E F G H]
                // 2 [A B C D _ E G H H]
                // 3 [A B C D _ E G H A]
                // 4 [B C C D _ E G H A] .. D..
                //
                debug_assert!(dst_pre_wrap_len > src_pre_wrap_len);
                let delta = dst_pre_wrap_len - src_pre_wrap_len;
                unsafe {
                    self.copy(dst, src, src_pre_wrap_len);
                    self.copy(dst + src_pre_wrap_len, 0, delta);
                    self.copy(0, delta, len - dst_pre_wrap_len);
                }
            }
            (true, true, true) => {
                // src pamberi pe dst, src inoputira, dst inoputira
                //
                //
                //    .. S..
                // 1 [A B C D _ E F G H]
                // 2 [A A B D _ E F G H]
                // 3 [H A B D _ E F G H]
                // 4 [H A B D _ E F F G]... D.
                //
                debug_assert!(src_pre_wrap_len > dst_pre_wrap_len);
                let delta = src_pre_wrap_len - dst_pre_wrap_len;
                unsafe {
                    self.copy(delta, 0, len - src_pre_wrap_len);
                    self.copy(0, self.cap() - delta, delta);
                    self.copy(dst, src, dst_pre_wrap_len);
                }
            }
        }
    }

    /// Mapeche emusoro nemuswe muswe kutenderedza kuti ubate chokwadi chekuti isu takangogarwazve.
    /// Isina kuchengeteka nekuti inovimba yekare_capacity.
    #[inline]
    unsafe fn handle_capacity_increase(&mut self, old_capacity: usize) {
        let new_capacity = self.cap();

        // Fambisa chikamu chipfupi chakabatana chebhendi mhete TH
        //
        //   [o o o o o o o . ]
        //    THA [o o o o o o o . . . . . . . . . ] HT
        //   [o o . o o o o o ]
        //          THB [...ooooooo......
        //          ] HT
        //   [o o o o o . o o ]
        //              HTC [o o o o o . . . . . . . . . o o ]
        //
        //
        //
        //

        if self.tail <= self.head {
            // A Nop
            //
        } else if self.head < old_capacity - self.tail {
            // B
            unsafe {
                self.copy_nonoverlapping(old_capacity, 0, self.head);
            }
            self.head += old_capacity;
            debug_assert!(self.head > self.tail);
        } else {
            // C
            let new_tail = new_capacity - (old_capacity - self.tail);
            unsafe {
                self.copy_nonoverlapping(new_tail, self.tail, old_capacity - self.tail);
            }
            self.tail = new_tail;
            debug_assert!(self.head < self.tail);
        }
        debug_assert!(self.head < self.cap());
        debug_assert!(self.tail < self.cap());
        debug_assert!(self.cap().count_ones() == 1);
    }
}

impl<T> VecDeque<T> {
    /// Inogadzira isina `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::new();
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new() -> VecDeque<T> {
        VecDeque::with_capacity(INITIAL_CAPACITY)
    }

    /// Inogadzira isina `VecDeque` ine nzvimbo yezvinenge zvinhu `capacity`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let vector: VecDeque<u32> = VecDeque::with_capacity(10);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> VecDeque<T> {
        // +1 kubva ringbuffer yagara ichisiya imwe nzvimbo isina chinhu
        let cap = cmp::max(capacity + 1, MINIMUM_CAPACITY + 1).next_power_of_two();
        assert!(cap > capacity, "capacity overflow");

        VecDeque { tail: 0, head: 0, buf: RawVec::with_capacity(cap) }
    }

    /// Inopa chirevo kuchinhu chakapihwa index.
    ///
    /// Chinhu pane indekisi 0 ndiko kumberi kwetara.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf.get(1), Some(&4));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get(&self, index: usize) -> Option<&T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&*self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Inopa chirevo chinoshanduka kuchinhu pane yakapihwa index.
    ///
    /// Chinhu pane indekisi 0 ndiko kumberi kwetara.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// if let Some(elem) = buf.get_mut(1) {
    ///     *elem = 7;
    /// }
    ///
    /// assert_eq!(buf[1], 7);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn get_mut(&mut self, index: usize) -> Option<&mut T> {
        if index < self.len() {
            let idx = self.wrap_add(self.tail, index);
            unsafe { Some(&mut *self.ptr().add(idx)) }
        } else {
            None
        }
    }

    /// Chinja zvinhu kumaindices `i` uye `j`.
    ///
    /// `i` uye `j` inogona kunge yakaenzana.
    ///
    /// Chinhu pane indekisi 0 ndiko kumberi kwetara.
    ///
    /// # Panics
    ///
    /// Panics kana chero index iri kunze kwemiganhu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// buf.push_back(5);
    /// assert_eq!(buf, [3, 4, 5]);
    /// buf.swap(0, 2);
    /// assert_eq!(buf, [5, 4, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap(&mut self, i: usize, j: usize) {
        assert!(i < self.len());
        assert!(j < self.len());
        let ri = self.wrap_add(self.tail, i);
        let rj = self.wrap_add(self.tail, j);
        unsafe { ptr::swap(self.ptr().add(ri), self.ptr().add(rj)) }
    }

    /// Inodzorera iyo nhamba yezvinhu iyo `VecDeque` inogona kubata isina kuisazve nzvimbo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let buf: VecDeque<i32> = VecDeque::with_capacity(10);
    /// assert!(buf.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.cap() - 1
    }

    /// Inochengetedza hushoma hunyanzvi hweiyo chaiyo `additional` zvimwe zvinhu zvekuiswa mune yakapihwa `VecDeque`.
    /// Hapana chainoita kana kugona kwacho kwatova kukwana.
    ///
    /// Ziva kuti anogovera anogona kupa iyo yekuunganidza yakawanda nzvimbo kupfuura yainokumbira.
    /// Naizvozvo chinzvimbo hachigone kuvimbwa nacho kunyatsoita kushoma.
    /// Sarudza [`reserve`] kana kuiswa kwe future kuri kutarisirwa.
    ///
    /// # Panics
    ///
    /// Panics kana iyo nyowani nyowani ichizadza `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve_exact(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    ///
    /// [`reserve`]: VecDeque::reserve
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.reserve(additional);
    }

    /// Inochengetera kugona kweinenge `additional` zvimwe zvinhu zvekuiswa mune yakapihwa `VecDeque`.
    /// Iko kuunganidzira kunogona kuchengetedza imwe nzvimbo kudzivirira kudzoreredzwa patsva.
    ///
    /// # Panics
    ///
    /// Panics kana iyo nyowani nyowani ichizadza `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<i32> = vec![1].into_iter().collect();
    /// buf.reserve(10);
    /// assert!(buf.capacity() >= 11);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .expect("capacity overflow");

        if new_cap > old_cap {
            self.buf.reserve_exact(used_cap, new_cap - used_cap);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
    }

    /// Inoedza kuchengetedza hushoma hunyanzvi hweiyo chaiyo `additional` zvimwe zvinhu zvekuiswa mune yakapihwa `VecDeque<T>`.
    ///
    /// Mushure mekufona `try_reserve_exact`, chinzvimbo chichava chakakura kupfuura kana chakaenzana ne `self.len() + additional`.
    /// Hapana chainoita kana kugona kwacho kwatova kukwana.
    ///
    /// Ziva kuti anogovera anogona kupa iyo yekuunganidza yakawanda nzvimbo kupfuura yainokumbira.
    /// Naizvozvo, kugona hakugone kuvimbwa nako kuti kuve kushoma.
    /// Sarudza `reserve` kana kuiswa kwe future kuri kutarisirwa.
    ///
    /// # Errors
    ///
    /// Kana chinzvimbo chikafashukira `usize`, kana iye anogovera akamhan'ara kukundikana, ipapo kukanganisa kunodzorerwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Pre-chengetedza ndangariro, ichibuda kana tisingakwanise
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Iye zvino tinoziva izvi hazvigone OOM(Out-Of-Memory) pakati pebasa redu rakaoma
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // zvakaoma zvikuru
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.try_reserve(additional)
    }

    /// Inoedza kuchengetedza kugona kweinenge `additional` zvimwe zvinhu zvekuiswa mune yakapihwa `VecDeque<T>`.
    /// Iko kuunganidzira kunogona kuchengetedza imwe nzvimbo kudzivirira kudzoreredzwa patsva.
    /// Mushure mekufona `try_reserve`, chinzvimbo chichava chakakura kupfuura kana chakaenzana ne `self.len() + additional`.
    /// Haina chainoita kana kugona kwatova kukwana.
    ///
    /// # Errors
    ///
    /// Kana chinzvimbo chikafashukira `usize`, kana iye anogovera akamhan'ara kukundikana, ipapo kukanganisa kunodzorerwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    /// use std::collections::VecDeque;
    ///
    /// fn process_data(data: &[u32]) -> Result<VecDeque<u32>, TryReserveError> {
    ///     let mut output = VecDeque::new();
    ///
    ///     // Pre-chengetedza ndangariro, ichibuda kana tisingakwanise
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Iye zvino tinoziva izvi hazvigone OOM pakati pebasa redu rakaoma
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // zvakaoma zvikuru
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        let old_cap = self.cap();
        let used_cap = self.len() + 1;
        let new_cap = used_cap
            .checked_add(additional)
            .and_then(|needed_cap| needed_cap.checked_next_power_of_two())
            .ok_or(TryReserveError::CapacityOverflow)?;

        if new_cap > old_cap {
            self.buf.try_reserve_exact(used_cap, new_cap - used_cap)?;
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
        }
        Ok(())
    }

    /// Inoderedza kugona kwe `VecDeque` zvakanyanya sezvinobvira.
    ///
    /// Ichadonha pasi padyo padyo sezvinobvira nehurefu asi iye anogovera anogona achiri kuzivisa iyo `VecDeque` kuti kune nzvimbo yezvimwe zvishoma zvimwe zvinhu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to_fit();
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn shrink_to_fit(&mut self) {
        self.shrink_to(0);
    }

    /// Inoderedza kugona kwe `VecDeque` ine yakasungwa yakasungwa.
    ///
    /// Iyo chinzvimbo chinosara chingangoita chakakura seese ari maviri kureba uye kukosha kwakapihwa.
    ///
    ///
    /// Kana iyo yazvino kugona iri pasi peyakaderera muganho, iyi haina-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    /// buf.extend(0..4);
    /// assert_eq!(buf.capacity(), 15);
    /// buf.shrink_to(6);
    /// assert!(buf.capacity() >= 6);
    /// buf.shrink_to(0);
    /// assert!(buf.capacity() >= 4);
    /// ```
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        let min_capacity = cmp::min(min_capacity, self.capacity());
        // Hatifanire kunetseka nezvekufashukira sezvo `self.len()` kana `self.capacity()` isingambove `usize::MAX`.
        // +1 seye muridzi wenguva dzose anosiya imwe nzvimbo isina chinhu.
        let target_cap = cmp::max(cmp::max(min_capacity, self.len()) + 1, MINIMUM_CAPACITY + 1)
            .next_power_of_two();

        if target_cap < self.cap() {
            // Pane zviitiko zvitatu zvekufarira:
            //   Zvese zvinhu zviri kunze kwemiganhu inodiwa Elements ari contiguous, uye musoro wabuda pane waunoda mabhandi Elements haagunun'una, uye muswe uri kunze kweanodikanwa miganhu
            //
            //
            // Pane dzimwe nguva dzese, zvinzvimbo zvemukati hazvibatike.
            //
            // Inoratidza kuti zvinhu zviri mumusoro zvinofanirwa kufambiswa.
            //
            let head_outside = self.head == 0 || self.head >= target_cap;
            // Fambisa zvinhu kubva kunze kwenzvimbo dzaunoda (zvinzvimbo mushure me target_cap)
            if self.tail >= target_cap && head_outside {
                // TH
                //   [. . . . . . . . o o o o o o o . ]
                //    TH
                //   [o o o o o o o . ]
                unsafe {
                    self.copy_nonoverlapping(0, self.tail, self.len());
                }
                self.head = self.len();
                self.tail = 0;
            } else if self.tail != 0 && self.tail < target_cap && head_outside {
                // TH
                //   [. . . o o o o o o o . . . . . . ]
                //        H T
                //   [o o . o o o o o ]
                let len = self.wrap_sub(self.head, target_cap);
                unsafe {
                    self.copy_nonoverlapping(0, target_cap, len);
                }
                self.head = len;
                debug_assert!(self.head < self.tail);
            } else if self.tail >= target_cap {
                // HT
                //   [o o o o o . . . . . . . . . o o ]
                //              H T
                //   [o o o o o . o o ]
                debug_assert!(self.wrap_sub(self.head, 1) < target_cap);
                let len = self.cap() - self.tail;
                let new_tail = target_cap - len;
                unsafe {
                    self.copy_nonoverlapping(new_tail, self.tail, len);
                }
                self.tail = new_tail;
                debug_assert!(self.head < self.tail);
            }

            self.buf.shrink_to_fit(target_cap);

            debug_assert!(self.head < self.cap());
            debug_assert!(self.tail < self.cap());
            debug_assert!(self.cap().count_ones() == 1);
        }
    }

    /// Inopfupisa iyo `VecDeque`, ichichengeta yekutanga `len` zvinhu uye ichidonhedza zvimwe zvese.
    ///
    ///
    /// Kana `len` yakakura kudarika iyo `VecDeque`hurefu hwazvino, izvi hazvina zvazvinoita.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    /// buf.truncate(1);
    /// assert_eq!(buf, [5]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn truncate(&mut self, len: usize) {
        /// Inomhanyisa muparadzi wezvinhu zvese muchidimbu painodonhedzwa (kazhinji kana panguva yekusunungura).
        ///
        struct Dropper<'a, T>(&'a mut [T]);

        impl<'a, T> Drop for Dropper<'a, T> {
            fn drop(&mut self) {
                unsafe {
                    ptr::drop_in_place(self.0);
                }
            }
        }

        // Yakachengeteka nekuti:
        //
        // * Chero chidimbu chakapasirwa ku `drop_in_place` chinoshanda;kesi yechipiri ine `len <= front.len()` uye ichidzoka pa `len > self.len()` inova nechokwadi `begin <= back.len()` mune yekutanga kesi
        //
        // * Musoro weVecDeque unofambiswa usati washeedza `drop_in_place`, saka hapana kukosha kwakadonhedzwa kaviri kana `drop_in_place` panics
        //
        //
        unsafe {
            if len > self.len() {
                return;
            }
            let num_dropped = self.len() - len;
            let (front, back) = self.as_mut_slices();
            if len > front.len() {
                let begin = len - front.len();
                let drop_back = back.get_unchecked_mut(begin..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);
                ptr::drop_in_place(drop_back);
            } else {
                let drop_back = back as *mut _;
                let drop_front = front.get_unchecked_mut(len..) as *mut _;
                self.head = self.wrap_sub(self.head, num_dropped);

                // Ita shuwa kuti yechipiri hafu yakadonhedzwa kunyangwe kana muparadzi mune yekutanga panics.
                //
                let _back_dropper = Dropper(&mut *drop_back);
                ptr::drop_in_place(drop_front);
            }
        }
    }

    /// Inodzorera pamberi-kumashure-iterator.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// let b: &[_] = &[&5, &3, &4];
    /// let c: Vec<&i32> = buf.iter().collect();
    /// assert_eq!(&c[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter(&self) -> Iter<'_, T> {
        Iter { tail: self.tail, head: self.head, ring: unsafe { self.buffer_as_slice() } }
    }

    /// Inodzorera iyo yekumberi-kumashure-iterator iyo inodzosera zvinachinjika mareferenzi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(3);
    /// buf.push_back(4);
    /// for num in buf.iter_mut() {
    ///     *num = *num - 2;
    /// }
    /// let b: &[_] = &[&mut 3, &mut 1, &mut 2];
    /// assert_eq!(&buf.iter_mut().collect::<Vec<&mut i32>>()[..], b);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn iter_mut(&mut self) -> IterMut<'_, T> {
        // Kachengeteka: Iyo yemukati `IterMut` yekuchengetedza inopindirana inosimbiswa nekuti iyo
        // `ring` isu tinogadzira chidimbu chisingadzoreke cheupenyu hwese '_.
        IterMut {
            tail: self.tail,
            head: self.head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Inodzorera zvidimbu zviviri zvine, zvakateedzana, zviri mukati me `VecDeque`.
    ///
    /// Kana [`make_contiguous`] yaidaidzwa kare, zvese zvinhu zve `VecDeque` zvichave mune chekutanga chidimbu uye chechipiri chidimbu chichava chisina chinhu.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    /// vector.push_back(2);
    ///
    /// assert_eq!(vector.as_slices(), (&[0, 1, 2][..], &[][..]));
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// assert_eq!(vector.as_slices(), (&[9, 10][..], &[0, 1, 2][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_slices(&self) -> (&[T], &[T]) {
        unsafe {
            let buf = self.buffer_as_slice();
            RingSlices::ring_slices(buf, self.head, self.tail)
        }
    }

    /// Inodzorera zvidimbu zviviri zvine, zvakateedzana, zviri mukati me `VecDeque`.
    ///
    /// Kana [`make_contiguous`] yaidaidzwa kare, zvese zvinhu zve `VecDeque` zvichave mune chekutanga chidimbu uye chechipiri chidimbu chichava chisina chinhu.
    ///
    ///
    /// [`make_contiguous`]: VecDeque::make_contiguous
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// vector.push_front(10);
    /// vector.push_front(9);
    ///
    /// vector.as_mut_slices().0[0] = 42;
    /// vector.as_mut_slices().1[0] = 24;
    /// assert_eq!(vector.as_slices(), (&[42, 10][..], &[24, 1][..]));
    /// ```
    ///
    #[inline]
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn as_mut_slices(&mut self) -> (&mut [T], &mut [T]) {
        unsafe {
            let head = self.head;
            let tail = self.tail;
            let buf = self.buffer_as_mut_slice();
            RingSlices::ring_slices(buf, head, tail)
        }
    }

    /// Inodzorera iyo nhamba yezvinhu mu `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert_eq!(v.len(), 0);
    /// v.push_back(1);
    /// assert_eq!(v.len(), 1);
    /// ```
    #[doc(alias = "length")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        count(self.tail, self.head, self.cap())
    }

    /// Inodzorera `true` kana iyo `VecDeque` isina chinhu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// assert!(v.is_empty());
    /// v.push_front(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.tail == self.head
    }

    fn range_tail_head<R>(&self, range: R) -> (usize, usize)
    where
        R: RangeBounds<usize>,
    {
        let Range { start, end } = slice::range(range, ..self.len());
        let tail = self.wrap_add(self.tail, start);
        let head = self.wrap_add(self.tail, end);
        (tail, head)
    }

    /// Inogadzira iterator inovhara yakatarwa renji mu `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics kana pekutangira pakakura kupfuura pekupedzisira kana pekupedzisira pakakwirira kupfuura pakureba kwe vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let range = v.range(2..).copied().collect::<VecDeque<_>>();
    /// assert_eq!(range, [3]);
    ///
    /// // Rizere renji rinofukidza zvese zvirimo
    /// let all = v.range(..);
    /// assert_eq!(all.len(), 3);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range<R>(&self, range: R) -> Iter<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);
        Iter {
            tail,
            head,
            // Iwo akagovaniswa mareferenzi atinawo mu &self anochengetwa mu '_ yeIter.
            ring: unsafe { self.buffer_as_slice() },
        }
    }

    /// Inogadzira iterator inovhara yakatarwa inogona kuchinjika renji mu `VecDeque`.
    ///
    /// # Panics
    ///
    /// Panics kana pekutangira pakakura kupfuura pekupedzisira kana pekupedzisira pakakwirira kupfuura pakureba kwe vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// for v in v.range_mut(2..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![1, 2, 6]);
    ///
    /// // Rizere renji rinofukidza zvese zvirimo
    /// for v in v.range_mut(..) {
    ///   *v *= 2;
    /// }
    /// assert_eq!(v, vec![2, 4, 12]);
    /// ```
    #[inline]
    #[stable(feature = "deque_range", since = "1.51.0")]
    pub fn range_mut<R>(&mut self, range: R) -> IterMut<'_, T>
    where
        R: RangeBounds<usize>,
    {
        let (tail, head) = self.range_tail_head(range);

        // Kachengeteka: Iyo yemukati `IterMut` yekuchengetedza inopindirana inosimbiswa nekuti iyo
        // `ring` isu tinogadzira chidimbu chisingadzoreke cheupenyu hwese '_.
        IterMut {
            tail,
            head,
            ring: ptr::slice_from_raw_parts_mut(self.ptr(), self.cap()),
            phantom: PhantomData,
        }
    }

    /// Inogadzira inodhonza iterator iyo inobvisa yakatarwa renji mu `VecDeque` uye inoburitsa zvakabviswa zvinhu.
    ///
    /// Ongorora 1: Iyo element range inobviswa kunyangwe iyo iterator isina kudyiwa kusvika kumagumo.
    ///
    /// Cherekedza 2: Hazvizivikanwe kuti mangani zvinhu zvakabviswa mudhikiki, kana iyo `Drain` kukosha isina kudonhedzwa, asi iyo yekukweretesa iyo inobata inopera (semuenzaniso, nekuda kwe `mem::forget`).
    ///
    ///
    /// # Panics
    ///
    /// Panics kana pekutangira pakakura kupfuura pekupedzisira kana pekupedzisira pakakwirira kupfuura pakureba kwe vector.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let drained = v.drain(2..).collect::<VecDeque<_>>();
    /// assert_eq!(drained, [3]);
    /// assert_eq!(v, [1, 2]);
    ///
    /// // Rizere renji rinobvisa zvese zvirimo
    /// v.drain(..);
    /// assert!(v.is_empty());
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T>
    where
        R: RangeBounds<usize>,
    {
        // Kuchengetedzwa kwendangariro
        //
        // Kana iyo Drain yakatanga kugadzirwa, sosi deque inopfupikiswa kuve nechokwadi chekuti hapana asina kuvhurwa kana kufambiswa-kubva kuzvinhu anowanikwa zvachose kana muparadzi we Drain asingazombomhanya.
        //
        //
        // Drain ichaita ptr::read kunze kwemaitiro ekubvisa.
        // Kana wapedza, iyo data yasara ichazoteedzerwa kumashure kuvhara gomba, uye iwo head/tail kukosha achadzoreredzwa nemazvo.
        //
        //
        //
        let (drain_tail, drain_head) = self.range_tail_head(range);

        // Zvinhu zve deque zvakapatsanurwa kuita zvikamu zvitatu:
        // * self.tail  -> drain_tail
        // * drain_tail-> drain_head
        // * drain_head-> self.head
        //
        // T= self.tail;H= self.head;t=drain_tail;h=drain_head
        //
        // Isu tinochengeta drain_tail se self.head, uye drain_head uye self.head se after_tail uye after_head zvichiteerana pa Drain.
        // Izvi zvakare zvinotapura zvinoshanda zvakarongeka zvekuti kana iyo Drain yakaburitswa, isu takakanganwa nezve zvingangotamiswa tsika mushure mekutanga kwe drain.
        //
        //
        //        T th H
        // [. . . o o x x o o . . .]
        //
        //
        //
        let head = self.head;

        // "forget" pamusoro pehunhu mushure mekutanga kwe drain kusvikira drain yapera uye Drain muparadzi amhanya.
        //
        self.head = drain_tail;

        Drain {
            deque: NonNull::from(&mut *self),
            after_tail: drain_head,
            after_head: head,
            iter: Iter {
                tail: drain_tail,
                head: drain_head,
                // Nechisimba, isu tinongogadzira akagovaniswa mareferenzi kubva ku `self` pano uye kuverenga kubva pairi.
                // Isu hatinyore ku `self` kana kukwereta kune chinoshandurwa chinongedzo.
                // Nekudaro iyo mbichana mbichana yatakagadzira pamusoro, ye `deque`, inoramba ichishanda.
                ring: unsafe { self.buffer_as_slice() },
            },
        }
    }

    /// Inochenesa iyo `VecDeque`, ichibvisa hunhu hwese.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut v = VecDeque::new();
    /// v.push_back(1);
    /// v.clear();
    /// assert!(v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn clear(&mut self) {
        self.truncate(0);
    }

    /// Inodzorera `true` kana iyo `VecDeque` iine chinhu chakaenzana nemutengo wakapihwa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vector: VecDeque<u32> = VecDeque::new();
    ///
    /// vector.push_back(0);
    /// vector.push_back(1);
    ///
    /// assert_eq!(vector.contains(&1), true);
    /// assert_eq!(vector.contains(&10), false);
    /// ```
    #[stable(feature = "vec_deque_contains", since = "1.12.0")]
    pub fn contains(&self, x: &T) -> bool
    where
        T: PartialEq<T>,
    {
        let (a, b) = self.as_slices();
        a.contains(x) || b.contains(x)
    }

    /// Inopa chirevo kuchinhu chepamberi, kana `None` kana iyo `VecDeque` isina chinhu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.front(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front(&self) -> Option<&T> {
        self.get(0)
    }

    /// Inopa chirevo chinoshanduka kuchinhu chepamberi, kana `None` kana iyo `VecDeque` isina chinhu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.front_mut(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.front_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.front(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn front_mut(&mut self) -> Option<&mut T> {
        self.get_mut(0)
    }

    /// Inopa chirevo kuchinhu chekuseri, kana `None` kana iyo `VecDeque` isina chinhu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// assert_eq!(d.back(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back(&self) -> Option<&T> {
        self.get(self.len().wrapping_sub(1))
    }

    /// Inopa chirevo chinoshanduka kuchinhu chekumashure, kana `None` kana iyo `VecDeque` isina chinhu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// assert_eq!(d.back(), None);
    ///
    /// d.push_back(1);
    /// d.push_back(2);
    /// match d.back_mut() {
    ///     Some(x) => *x = 9,
    ///     None => (),
    /// }
    /// assert_eq!(d.back(), Some(&9));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn back_mut(&mut self) -> Option<&mut T> {
        self.get_mut(self.len().wrapping_sub(1))
    }

    /// Inobvisa chinhu chekutanga wochidzorera, kana `None` kana iyo `VecDeque` isina chinhu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_back(1);
    /// d.push_back(2);
    ///
    /// assert_eq!(d.pop_front(), Some(1));
    /// assert_eq!(d.pop_front(), Some(2));
    /// assert_eq!(d.pop_front(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_front(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            let tail = self.tail;
            self.tail = self.wrap_add(self.tail, 1);
            unsafe { Some(self.buffer_read(tail)) }
        }
    }

    /// Inobvisa chinhu chekupedzisira kubva ku `VecDeque` yochidzorera, kana `None` kana isina chinhu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.pop_back(), None);
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(buf.pop_back(), Some(3));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop_back(&mut self) -> Option<T> {
        if self.is_empty() {
            None
        } else {
            self.head = self.wrap_sub(self.head, 1);
            let head = self.head;
            unsafe { Some(self.buffer_read(head)) }
        }
    }

    /// Inogadzirira chinhu ku `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut d = VecDeque::new();
    /// d.push_front(1);
    /// d.push_front(2);
    /// assert_eq!(d.front(), Some(&2));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_front(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        self.tail = self.wrap_sub(self.tail, 1);
        let tail = self.tail;
        unsafe {
            self.buffer_write(tail, value);
        }
    }

    /// Inoisa chinhu kuseri kwe `VecDeque`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(3);
    /// assert_eq!(3, *buf.back().unwrap());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_back(&mut self, value: T) {
        if self.is_full() {
            self.grow();
        }

        let head = self.head;
        self.head = self.wrap_add(self.head, 1);
        unsafe { self.buffer_write(head, value) }
    }

    #[inline]
    fn is_contiguous(&self) -> bool {
        // FIXME: Tinofanira kufunga nezve `head == 0` kureva
        // iyo `self` inoenderana?
        self.tail <= self.head
    }

    /// Inobvisa chinhu kubva chero kupi mu `VecDeque` uye ndokuchidzosera, ichichitsiva nechinhu chekutanga.
    ///
    ///
    /// Izvi hazvichengetedze kuodha, asi ndi *O*(1).
    ///
    /// Inodzorera `None` kana `index` iri kunze kwemiganhu.
    ///
    /// Chinhu pane indekisi 0 ndiko kumberi kwetara.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_front(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_front(2), Some(3));
    /// assert_eq!(buf, [2, 1]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_front(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length && index != 0 {
            self.swap(index, 0);
        } else if index >= length {
            return None;
        }
        self.pop_front()
    }

    /// Inobvisa chinhu kubva chero kupi mu `VecDeque` uye ndokuchidzosera, ichichitsiva nechinhu chekupedzisira.
    ///
    ///
    /// Izvi hazvichengetedze kuodha, asi ndi *O*(1).
    ///
    /// Inodzorera `None` kana `index` iri kunze kwemiganhu.
    ///
    /// Chinhu pane indekisi 0 ndiko kumberi kwetara.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// assert_eq!(buf.swap_remove_back(0), None);
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.swap_remove_back(0), Some(1));
    /// assert_eq!(buf, [3, 2]);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn swap_remove_back(&mut self, index: usize) -> Option<T> {
        let length = self.len();
        if length > 0 && index < length - 1 {
            self.swap(index, length - 1);
        } else if index >= length {
            return None;
        }
        self.pop_back()
    }

    /// Inoisa chinhu pa `index` mukati me `VecDeque`, ichichinjisa zvinhu zvese nemaIndices akakurisa kupfuura kana akaenzana ne `index` akananga kumashure.
    ///
    ///
    /// Chinhu pane indekisi 0 ndiko kumberi kwetara.
    ///
    /// # Panics
    ///
    /// Panics kana `index` yakakura kudarika `VecDeque`hurefu
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut vec_deque = VecDeque::new();
    /// vec_deque.push_back('a');
    /// vec_deque.push_back('b');
    /// vec_deque.push_back('c');
    /// assert_eq!(vec_deque, &['a', 'b', 'c']);
    ///
    /// vec_deque.insert(1, 'd');
    /// assert_eq!(vec_deque, &['a', 'd', 'b', 'c']);
    /// ```
    #[stable(feature = "deque_extras_15", since = "1.5.0")]
    pub fn insert(&mut self, index: usize, value: T) {
        assert!(index <= self.len(), "index out of bounds");
        if self.is_full() {
            self.grow();
        }

        // Fambisa iyo shoma nhamba yezvinhu mune iyo mhete buffer uye isa chinhu chakapihwa
        //
        // Kunyanya len/2, 1 zvinhu zvinofambiswa. O(min(n, n-i))
        //
        // Pane matatu makuru kesi:
        //  Zvinhu zvinoenderana
        //      - yakakosha kesi kana muswe uri 0 Zvinhu hazvina kugadzikana uye yekuisa iri muchikamu chemuswe Zvimisikidzo hazvizivikanwe uye kuiswa kuri muchikamu chemusoro
        //
        //
        // Kune imwe yeaya pane mamwe maviri kesi:
        //  Insert iri padyo nemuswe Insert iri padyo nemusoro
        //
        // Kiyi: H, self.head
        //      T, self.tail o, Valid element I, Insertion element A, Chinhu icho chinofanirwa kuve mushure mekuisa poindi M, Inoratidza chinhu chakatamiswa.
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) if index == 0 => {
                // push_front
                //
                //       TIH
                //      [Aaaaaa.......
                //      .
                //      .]
                //
                //                       HT
                //      [A o o o o o o o . . . . . I]

                self.tail = self.wrap_sub(self.tail, 1);
            }
            (true, true, _) => {
                unsafe {
                    // inobatanidza, isa padyo nemuswe:
                    //
                    //             TIH
                    //      [. . . o o A o o o o . . . . . .]
                    //
                    //           TH
                    //      [. . o o I A o o o o . . . . . .]
                    //           M M
                    //
                    // inobatanidza, isa padyo nemuswe uye muswe ndewe 0:
                    //
                    //
                    //       TIH
                    //      [o o A o o o o . . . . . . . . .]
                    //
                    //                       HT
                    //      [o I A o o o o o . . . . . . . o]
                    //       MM

                    let new_tail = self.wrap_sub(self.tail, 1);

                    self.copy(new_tail, self.tail, 1);
                    // Takatamisa muswe, saka isu tinongoteedzera `index - 1` zvinhu.
                    self.copy(self.tail, self.tail + 1, index - 1);

                    self.tail = new_tail;
                }
            }
            (true, false, _) => {
                unsafe {
                    // inobatanidza, isa padyo nemusoro:
                    //
                    //             TIH
                    //      [. . . o o o o A o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o I A o o . . . . .]
                    //                       MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head = self.wrap_add(self.head, 1);
                }
            }
            (false, true, true) => {
                unsafe {
                    // discontiguous, isa padyo nemuswe, muswe chikamu:
                    //
                    //                   HTI
                    //      [o o o o o o . . . . . o o A o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . o o I A o o]
                    //                           M M

                    self.copy(self.tail - 1, self.tail, index);
                    self.tail -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // discontiguous, isa padyo nemusoro, muswe chikamu:
                    //
                    //           HTI
                    //      [o o . . . . . . . o o o o o A o]
                    //
                    //             HT
                    //      [o o o . . . . . . o o o o o I A]
                    //       MMMM

                    // kuteedzera zvinhu kusvika kumusoro mutsva
                    self.copy(1, 0, self.head);

                    // teedzera chinhu chekupedzisira munzvimbo isina chinhu pazasi petabha
                    self.copy(0, self.cap() - 1, 1);

                    // fambisa zvinhu kubva kuidx kusvika kumagumo kuenda mberi kusisanganisira ^ element
                    self.copy(idx + 1, idx, self.cap() - 1 - idx);

                    self.head += 1;
                }
            }
            (false, true, false) if idx == 0 => {
                unsafe {
                    // discontiguous, insert iri padyo nemuswe, chikamu chemusoro, uye iri pane index zero mubhavhu remukati:
                    //
                    //
                    //       IHT
                    //      [A o o o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [A o o o o o o o o o . . o o o I]
                    //                               MMM

                    // kuteedzera zvinhu kusvika kumuswe mutsva
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // teedzera chinhu chekupedzisira munzvimbo isina chinhu pazasi petabha
                    self.copy(self.cap() - 1, 0, 1);

                    self.tail -= 1;
                }
            }
            (false, true, false) => {
                unsafe {
                    // discontiguous, isa padyo nemuswe, chikamu chemusoro:
                    //
                    //             IHT
                    //      [o o o A o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o I A o o o o o o . . o o o o]
                    //       MMMMMM

                    // kuteedzera zvinhu kusvika kumuswe mutsva
                    self.copy(self.tail - 1, self.tail, self.cap() - self.tail);

                    // teedzera chinhu chekupedzisira munzvimbo isina chinhu pazasi petabha
                    self.copy(self.cap() - 1, 0, 1);

                    // fambisa zvinhu kubva ku idx-1 kusvika kumagumo kuenda mberi kusisanganisira ^ element
                    self.copy(0, 1, idx - 1);

                    self.tail -= 1;
                }
            }
            (false, false, false) => {
                unsafe {
                    // discontiguous, isa padhuze nemusoro, chikamu chemusoro:
                    //
                    //               IHT
                    //      [o o o o A o o . . . . . . o o o]
                    //
                    //                     HT
                    //      [o o o o I A o o . . . . . o o o]
                    //                 MMM

                    self.copy(idx + 1, idx, self.head - idx);
                    self.head += 1;
                }
            }
        }

        // muswe unogona kunge wakashandurwa saka tinoda kuverenga zvakare
        let new_idx = self.wrap_add(self.tail, index);
        unsafe {
            self.buffer_write(new_idx, value);
        }
    }

    /// Inobvisa uye inodzosera chinhu ku `index` kubva ku `VecDeque`.
    /// Chero ipi kumagumo iri padyo nenzvimbo yekubvisa ichaendeswa kuita nzvimbo, uye zvese zvinhu zvakakanganiswa zvichaendeswa kunzvimbo nyowani.
    ///
    /// Inodzorera `None` kana `index` iri kunze kwemiganhu.
    ///
    /// Chinhu pane indekisi 0 ndiko kumberi kwetara.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(1);
    /// buf.push_back(2);
    /// buf.push_back(3);
    /// assert_eq!(buf, [1, 2, 3]);
    ///
    /// assert_eq!(buf.remove(1), Some(2));
    /// assert_eq!(buf, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> Option<T> {
        if self.is_empty() || self.len() <= index {
            return None;
        }

        // Pane matatu makuru kesi:
        //  Zvinhu zvinokwenenzvera Zvinhu hazvina kugadzikana uye kubviswa kuri muchikamu chemuswe Zvimisikidzo hazvinzwisisike uye kubviswa kuri muchikamu chemusoro.
        //
        //      - yakakosha kesi kana zvinhu zvichinyatso kuenderana, asi self.head =0
        //
        // Kune imwe yeaya pane mamwe maviri kesi:
        //  Insert iri padyo nemuswe Insert iri padyo nemusoro
        //
        // Kiyi: H, self.head
        //      T, self.tail o, Chinhu chakakodzera x, Chinhu chakatemerwa kubvisa R, Chinoratidza chinhu chiri kubviswa M, Chinoratidza chinhu chakatamiswa.
        //
        //
        //
        //
        //
        //
        //

        let idx = self.wrap_add(self.tail, index);

        let elem = unsafe { Some(self.buffer_read(idx)) };

        let distance_to_tail = index;
        let distance_to_head = self.len() - index;

        let contiguous = self.is_contiguous();

        match (contiguous, distance_to_tail <= distance_to_head, idx >= self.tail) {
            (true, true, _) => {
                unsafe {
                    // inobatanidza, bvisa padyo nemuswe:
                    //
                    //             TRH
                    //      [. . . o o x o o o o . . . . . .]
                    //
                    //               TH
                    //      [. . . . o o o o o o . . . . . .]
                    //               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail += 1;
                }
            }
            (true, false, _) => {
                unsafe {
                    // inobatanidza, bvisa padyo nemusoro:
                    //
                    //             TRH
                    //      [. . . o o o o x o o . . . . . .]
                    //
                    //             TH
                    //      [. . . o o o o o o . . . . . . .]
                    //                     M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, true, true) => {
                unsafe {
                    // discontiguous, bvisa padyo nemuswe, chikamu chemuswe:
                    //
                    //                   HTR
                    //      [o o o o o o . . . . . o o x o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . o o o o]
                    //                               M M

                    self.copy(self.tail + 1, self.tail, index);
                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
            (false, false, false) => {
                unsafe {
                    // discontiguous, bvisa padyo nemusoro, chikamu chemusoro:
                    //
                    //               RHT
                    //      [o o o o x o o . . . . . . o o o]
                    //
                    //                   HT
                    //      [o o o o o o . . . . . . . o o o]
                    //               M M

                    self.copy(idx, idx + 1, self.head - idx - 1);
                    self.head -= 1;
                }
            }
            (false, false, true) => {
                unsafe {
                    // discontiguous, bvisa padyo nemusoro, muswe chikamu:
                    //
                    //             HTR
                    //      [o o o . . . . . . o o o o o x o]
                    //
                    //           HT
                    //      [o o . . . . . . . o o o o o o o]
                    //       MMMM
                    //
                    // kana quasi-discontiguous, bvisa padhuze nemusoro, muswe chikamu:
                    //
                    //       HTR
                    //      [. . . . . . . . . o o o o o x o]
                    //
                    //                         TH
                    //      [. . . . . . . . . o o o o o o .]
                    //                                   M

                    // dhonza muzvinhu muchikamu chemuswe
                    self.copy(idx, idx + 1, self.cap() - idx - 1);

                    // Inodzivirira kufashukira.
                    if self.head != 0 {
                        // teedzera yekutanga chinhu munzvimbo isina chinhu
                        self.copy(self.cap() - 1, 0, 1);

                        // fambisa zvinhu muchikamu chemusoro uchidzokera kumashure
                        self.copy(0, 1, self.head - 1);
                    }

                    self.head = self.wrap_sub(self.head, 1);
                }
            }
            (false, true, false) => {
                unsafe {
                    // discontiguous, bvisa padyo nemuswe, chikamu chemusoro:
                    //
                    //           RHT
                    //      [o o x o o o o o o o . . . o o o]
                    //
                    //                           HT
                    //      [o o o o o o o o o o . . . . o o]
                    //       MMMMM

                    // dhirowa muzvinhu kusvika kune idx
                    self.copy(1, 0, idx);

                    // teedzera chinhu chekupedzisira munzvimbo isina chinhu
                    self.copy(0, self.cap() - 1, 1);

                    // fambisa zvinhu kubva kumuswe kusvika kumagumo zvichienda kumberi, kusanganisa kwekupedzisira
                    self.copy(self.tail + 1, self.tail, self.cap() - self.tail - 1);

                    self.tail = self.wrap_add(self.tail, 1);
                }
            }
        }

        elem
    }

    /// Inoparadzanisa `VecDeque` kuita maviri pane yakapihwa index.
    ///
    /// Inodzorera ichangobva kupihwa `VecDeque`.
    /// `self` ine zvinhu `[0, at)`, uye iyo yakadzorerwa `VecDeque` ine zvinhu `[at, len)`.
    ///
    /// Ziva kuti kugona kwe `self` hakuchinje.
    ///
    /// Chinhu pane indekisi 0 ndiko kumberi kwetara.
    ///
    /// # Panics
    ///
    /// Panics kana `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2, 3].into_iter().collect();
    /// let buf2 = buf.split_off(1);
    /// assert_eq!(buf, [1]);
    /// assert_eq!(buf2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self {
        let len = self.len();
        assert!(at <= len, "`at` out of bounds");

        let other_len = len - at;
        let mut other = VecDeque::with_capacity(other_len);

        unsafe {
            let (first_half, second_half) = self.as_slices();

            let first_len = first_half.len();
            let second_len = second_half.len();
            if at < first_len {
                // `at` inorara muhafu yekutanga.
                let amount_in_first = first_len - at;

                ptr::copy_nonoverlapping(first_half.as_ptr().add(at), other.ptr(), amount_in_first);

                // ingo tora yese yechipiri hafu.
                ptr::copy_nonoverlapping(
                    second_half.as_ptr(),
                    other.ptr().add(amount_in_first),
                    second_len,
                );
            } else {
                // `at` iri muhafu yepiri, inoda kukoshesa muzvinhu zvatakasvetuka muhafu yekutanga.
                //
                let offset = at - first_len;
                let amount_in_second = second_len - offset;
                ptr::copy_nonoverlapping(
                    second_half.as_ptr().add(offset),
                    other.ptr(),
                    amount_in_second,
                );
            }
        }

        // Kuchenesa uko kunoperera magumo
        self.head = self.wrap_sub(self.head, other_len);
        other.head = other.wrap_index(other_len);

        other
    }

    /// Inofambisa zvese zvinhu zve `other` kuita `self`, ichisiya `other` isina chinhu.
    ///
    /// # Panics
    ///
    /// Panics kana iyo nyowani yezvinhu muzvayo ichipfuura `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = vec![1, 2].into_iter().collect();
    /// let mut buf2: VecDeque<_> = vec![3, 4].into_iter().collect();
    /// buf.append(&mut buf2);
    /// assert_eq!(buf, [1, 2, 3, 4]);
    /// assert_eq!(buf2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        // naive impl
        self.extend(other.drain(..));
    }

    /// Inochengetedza chete zvinhu zvinotsanangurwa neyakafanotaurwa.
    ///
    /// Mune mamwe mazwi, bvisa zvese zvinhu `e` zvekuti `f(&e)` inodzoka nhema.
    /// Iyi nzira inoshanda munzvimbo, ichishanyira chinhu chimwe nechimwe chaizvo kamwe muhurongwa hwepakutanga, uye inochengetedza kurongeka kwezvinhu zvakachengetedzwa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..5);
    /// buf.retain(|&x| x % 2 == 0);
    /// assert_eq!(buf, [2, 4]);
    /// ```
    ///
    /// Iyo chaiyo odha inogona kubatsira mukutevera kunze kwenyika, senge index.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.extend(1..6);
    ///
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// buf.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(buf, [2, 3, 5]);
    /// ```
    #[stable(feature = "vec_deque_retain", since = "1.4.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let len = self.len();
        let mut del = 0;
        for i in 0..len {
            if !f(&self[i]) {
                del += 1;
            } else if del > 0 {
                self.swap(i - del, i);
            }
        }
        if del > 0 {
            self.truncate(len - del);
        }
    }

    // Izvi zvinogona panic kana kubvisa nhumbu
    #[inline(never)]
    fn grow(&mut self) {
        if self.is_full() {
            let old_cap = self.cap();
            // Peta iyo saizi saizi.
            self.buf.reserve_exact(old_cap, old_cap);
            assert!(self.cap() == old_cap * 2);
            unsafe {
                self.handle_capacity_increase(old_cap);
            }
            debug_assert!(!self.is_full());
        }
    }

    /// Inogadzirisa iyo `VecDeque` mu-nzvimbo kuitira kuti `len()` ienzane ne `new_len`, kungave nekubvisa zvakawandisa zvinhu kubva kumashure kana nekuisa zvinhu zvakagadzirwa nekufonera `generator` kumashure.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize_with(5, Default::default);
    /// assert_eq!(buf, [5, 10, 15, 0, 0]);
    ///
    /// buf.resize_with(2, || unreachable!());
    /// assert_eq!(buf, [5, 10]);
    ///
    /// let mut state = 100;
    /// buf.resize_with(5, || { state += 1; state });
    /// assert_eq!(buf, [5, 10, 101, 102, 103]);
    /// ```
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with(&mut self, new_len: usize, generator: impl FnMut() -> T) {
        let len = self.len();

        if new_len > len {
            self.extend(repeat_with(generator).take(new_len - len))
        } else {
            self.truncate(new_len);
        }
    }

    /// Inogadzirisazve kuchengetedza kwemukati kwedhisiki iri saka chimwe chidimbu chinobatanidza, icho chinodzoserwa.
    ///
    /// Iyi nzira haina kugovera uye haina kuchinja marongero ezvinhu akaiswa zvinhu.Sezvo ichidzosera chinachinjika chidimbu, izvi zvinogona kushandiswa kuronga dhiri.
    ///
    /// Kana chengetedzo yemukati yangoenderana, nzira dze [`as_slices`] uye [`as_mut_slices`] dzinodzosera zvese zviri mukati me `VecDeque` mune kamwe chete.
    ///
    ///
    /// [`as_slices`]: VecDeque::as_slices
    /// [`as_mut_slices`]: VecDeque::as_mut_slices
    ///
    /// # Examples
    ///
    /// /Kurongedza zviri mukati medhikiti.
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::with_capacity(15);
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// // kusarudzika dhizaini
    /// buf.make_contiguous().sort();
    /// assert_eq!(buf.as_slices(), (&[1, 2, 3] as &[_], &[] as &[_]));
    ///
    /// // kurongedza nenzira yekudzosera kumashure
    /// buf.make_contiguous().sort_by(|a, b| b.cmp(a));
    /// assert_eq!(buf.as_slices(), (&[3, 2, 1] as &[_], &[] as &[_]));
    /// ```
    ///
    /// Kuwana isingachinjiki mukana kune inoenderana chidimbu.
    ///
    /// ```rust
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    ///
    /// buf.push_back(2);
    /// buf.push_back(1);
    /// buf.push_front(3);
    ///
    /// buf.make_contiguous();
    /// if let (slice, &[]) = buf.as_slices() {
    ///     // isu tinogona ikozvino kuva nechokwadi chekuti `slice` ine zvese zvinhu zve deque, tichine mukana usingachinjiki we `buf`.
    /////
    ///     assert_eq!(buf.len(), slice.len());
    ///     assert_eq!(slice, &[3, 2, 1] as &[_]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "deque_make_contiguous", since = "1.48.0")]
    pub fn make_contiguous(&mut self) -> &mut [T] {
        if self.is_contiguous() {
            let tail = self.tail;
            let head = self.head;
            return unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 };
        }

        let buf = self.buf.ptr();
        let cap = self.cap();
        let len = self.len();

        let free = self.tail - self.head;
        let tail_len = cap - self.tail;

        if free >= tail_len {
            // pane nzvimbo yemahara yakakwana yekuteedzera muswe kamwechete, izvi zvinoreva kuti tinotanga tachinjisa musoro nekumashure, tobva tateedzera muswe panzvimbo chaiyo.
            //
            //
            // kubva: DEFGH .... ABC
            // ku: ABCDEFGH ....
            //
            unsafe {
                ptr::copy(buf, buf.add(tail_len), self.head);
                // ...DEFGH.ABC
                ptr::copy_nonoverlapping(buf.add(self.tail), buf, tail_len);
                // ABCDEFGH....

                self.tail = 0;
                self.head = len;
            }
        } else if free > self.head {
            // FIXME: Isu parizvino hatifunge .... ABCDEFGH
            // kuenderana nekuti `head` ichave `0` mune iyi kesi.
            // Nepo isu tichizoda kushandura izvi hazvisi zvidiki sezvo nzvimbo shoma dzinotarisira `is_contiguous` kureva kuti tinogona kungochekerera tichishandisa `buf[tail..head]`.
            //
            //

            // pane nzvimbo yemahara yakakwana yekuteedzera musoro kamwechete, izvi zvinoreva kuti tinotanga tachinja muswe kuenda kumberi, tobva takopa musoro kumusoro chaiko.
            //
            //
            // kubva: FGH .... ABCDE
            // ku: ... ABCDEFGH.
            //
            unsafe {
                ptr::copy(buf.add(self.tail), buf.add(self.head), tail_len);
                // FGHABCDE....
                ptr::copy_nonoverlapping(buf, buf.add(self.head + tail_len), self.head);
                // ...ABCDEFGH.

                self.tail = self.head;
                self.head = self.wrap_add(self.tail, len);
            }
        } else {
            // yemahara idiki pane ese musoro nemuswe, izvi zvinoreva kuti tinofanirwa kunonoka "swap" muswe nemusoro.
            //
            //
            // kubva: EFGHI ... ABCD kana HIJK.ABCDEFG
            // kuenda ku: ABCDEFGHI ... kana ABCDEFGHIJK.
            let mut left_edge: usize = 0;
            let mut right_edge: usize = self.tail;
            unsafe {
                // Dambudziko rakajairika rinotaridzika seichi GHIJKLM ... ABCDEF, isati yamboshandura ABCDEFM ... GHIJKL, mushure mekupfuura kamwechete kwekuchinjisa ABCDEFGHIJM ... KL, chinja kusvika kuruboshwe edge yasvika kuchitoro chenguva pfupi.
                //                  - wobva watangidza algorithm neiyo nyowani (smaller) chitoro Dzimwe nguva iyo temp chitoro chinosvikwa kana kurudyi edge iri kumagumo kwebhafa, izvi zvinoreva kuti tarova chaiko kurongeka nema swaps mashoma!
                //
                // E.g
                // EF..ABCD ABCDEF .., mushure mechina chete swaps isu tapedza
                //
                //
                //
                //
                //
                while left_edge < len && right_edge != cap {
                    let mut right_offset = 0;
                    for i in left_edge..right_edge {
                        right_offset = (i - left_edge) % (cap - right_edge);
                        let src: isize = (right_edge + right_offset) as isize;
                        ptr::swap(buf.add(i), buf.offset(src));
                    }
                    let n_ops = right_edge - left_edge;
                    left_edge += n_ops;
                    right_edge += right_offset + 1;
                }

                self.tail = 0;
                self.head = len;
            }
        }

        let tail = self.tail;
        let head = self.head;
        unsafe { RingSlices::ring_slices(self.buffer_as_mut_slice(), head, tail).0 }
    }

    /// Anotenderera mutsara unopera kaviri `mid` nzvimbo kuruboshwe.
    ///
    /// Equivalently,
    /// - Inotenderedza chinhu `mid` munzvimbo yekutanga.
    /// - Anorova zvinhu zvekutanga zve `mid` uye anozvimanikidza kusvika kumagumo.
    /// - Inotenderera `len() - mid` nzvimbo kurudyi.
    ///
    /// # Panics
    ///
    /// Kana `mid` yakakura kudarika `len()`.
    /// Ziva kuti `mid == len()` inoita _not_ panic uye haina-op kutenderera.
    ///
    /// # Complexity
    ///
    /// Zvinotora `*O*(min(mid, len() - mid))` nguva uye hapana imwe nzvimbo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_left(3);
    /// assert_eq!(buf, [3, 4, 5, 6, 7, 8, 9, 0, 1, 2]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(i * 3 % 10, buf[0]);
    ///     buf.rotate_left(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_left(&mut self, mid: usize) {
        assert!(mid <= self.len());
        let k = self.len() - mid;
        if mid <= k {
            unsafe { self.rotate_left_inner(mid) }
        } else {
            unsafe { self.rotate_right_inner(k) }
        }
    }

    /// Anotenderera mutsara unopera kaviri `k` nzvimbo kurudyi.
    ///
    /// Equivalently,
    /// - Inotenderedza chinhu chekutanga kuita chinzvimbo `k`.
    /// - Pops ekupedzisira `k` zvinhu uye anozvimanikidza kuenda kumberi.
    /// - Inotenderera `len() - k` nzvimbo kuruboshwe.
    ///
    /// # Panics
    ///
    /// Kana `k` yakakura kudarika `len()`.
    /// Ziva kuti `k == len()` inoita _not_ panic uye haina-op kutenderera.
    ///
    /// # Complexity
    ///
    /// Zvinotora `*O*(min(k, len() - k))` nguva uye hapana imwe nzvimbo.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf: VecDeque<_> = (0..10).collect();
    ///
    /// buf.rotate_right(3);
    /// assert_eq!(buf, [7, 8, 9, 0, 1, 2, 3, 4, 5, 6]);
    ///
    /// for i in 1..10 {
    ///     assert_eq!(0, buf[i * 3 % 10]);
    ///     buf.rotate_right(3);
    /// }
    /// assert_eq!(buf, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    /// ```
    #[stable(feature = "vecdeque_rotate", since = "1.36.0")]
    pub fn rotate_right(&mut self, k: usize) {
        assert!(k <= self.len());
        let mid = self.len() - k;
        if k <= mid {
            unsafe { self.rotate_right_inner(k) }
        } else {
            unsafe { self.rotate_left_inner(mid) }
        }
    }

    // Kachengeteka: nzira mbiri dzinotevera dzinoda kuti huwandu hwekutenderera
    // kuve pasi pehafu yehurefu hwedhekisi.
    //
    // `wrap_copy` inoda kuti `min(x, cap() - x) + copy_len <= cap()`, asi kupfuura `min` haina kumbopfuura hafu yechiyero, zvisinei ne x, saka zvine mutsindo kufona pano nekuti tiri kufona nechimwe chinhu chiri pasi pehafu yehurefu, icho chisati chiri pamusoro pehafu yesimba.
    //
    //
    //

    unsafe fn rotate_left_inner(&mut self, mid: usize) {
        debug_assert!(mid * 2 <= self.len());
        unsafe {
            self.wrap_copy(self.head, self.tail, mid);
        }
        self.head = self.wrap_add(self.head, mid);
        self.tail = self.wrap_add(self.tail, mid);
    }

    unsafe fn rotate_right_inner(&mut self, k: usize) {
        debug_assert!(k * 2 <= self.len());
        self.head = self.wrap_sub(self.head, k);
        self.tail = self.wrap_sub(self.tail, k);
        unsafe {
            self.wrap_copy(self.tail, self.head, k);
        }
    }

    /// Binary inotsvaga iyi yakarongedzwa `VecDeque` yechinhu chakapihwa.
    ///
    /// Kana kukosha kwacho kukawanikwa saka [`Result::Ok`] inodzoserwa, iine indekisi yechinhu chinoenderana.
    /// Kana paine machisi akawanda, saka chero mumwe wemitambo unogona kudzoserwa.
    /// Kana kukosha kwacho kusingawanikwe [`Result::Err`] inodzoserwa, iine indekisi panogona kuiswa chinhu chinoenderana uchichengetedza zvakarongeka.
    ///
    ///
    /// # Examples
    ///
    /// Inotarisa kumusoro kwakateedzana kwezvinhu zvina.
    /// Yekutanga inowanikwa, iine chinzvimbo chakasarudzika;wechipiri newechitatu havana kuwanikwa;yechina inogona kuenderana chero chinzvimbo mu `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search(&13),  Ok(9));
    /// assert_eq!(deque.binary_search(&4),   Err(7));
    /// assert_eq!(deque.binary_search(&100), Err(13));
    /// let r = deque.binary_search(&1);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    /// Kana iwe uchida kuisa chinhu kune yakarongedzwa `VecDeque`, uku uchichengetedza mhando kurongeka:
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let mut deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    /// let num = 42;
    /// let idx = deque.binary_search(&num).unwrap_or_else(|x| x);
    /// deque.insert(idx, num);
    /// assert_eq!(deque, &[0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 42, 55]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search(&self, x: &T) -> Result<usize, usize>
    where
        T: Ord,
    {
        self.binary_search_by(|e| e.cmp(x))
    }

    /// Binary inotsvaga iyi yakarongedzwa `VecDeque` ine basa rekuenzanisa.
    ///
    /// Basa rekufananidza rinofanirwa kuita odhiyo inoenderana neakarongeka echimiro chiri pasi pe `VecDeque`, ichidzosa odha kodhi inoratidza kana nharo yayo iri `Less`, `Equal` kana `Greater` kupfuura yaidiwa tarisiro.
    ///
    ///
    /// Kana kukosha kwacho kukawanikwa saka [`Result::Ok`] inodzoserwa, iine indekisi yechinhu chinoenderana.Kana paine machisa akawandisa, saka chero imwe yemitambo inogona kudzoserwa.
    /// Kana kukosha kwacho kusingawanikwe [`Result::Err`] inodzoserwa, iine indekisi panogona kuiswa chinhu chinoenderana uchichengetedza zvakarongeka.
    ///
    /// # Examples
    ///
    /// Inotarisa kumusoro kwakateedzana kwezvinhu zvina.Yekutanga inowanikwa, iine chinzvimbo chakasarudzika;wechipiri newechitatu havana kuwanikwa;yechina inogona kuenderana chero chinzvimbo mu `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![0, 1, 1, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55].into();
    ///
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&13)),  Ok(9));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&4)),   Err(7));
    /// assert_eq!(deque.binary_search_by(|x| x.cmp(&100)), Err(13));
    /// let r = deque.binary_search_by(|x| x.cmp(&1));
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    pub fn binary_search_by<'a, F>(&'a self, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> Ordering,
    {
        let (front, back) = self.as_slices();

        if let Some(Ordering::Less | Ordering::Equal) = back.first().map(|elem| f(elem)) {
            back.binary_search_by(f).map(|idx| idx + front.len()).map_err(|idx| idx + front.len())
        } else {
            front.binary_search_by(f)
        }
    }

    /// Binary inotsvaga iyi yakarongedzwa `VecDeque` nekiyi yekubvisa basa.
    ///
    /// Inofungidzira kuti iyo `VecDeque` inorongedzwa nekiyi, semuenzaniso ne [`make_contiguous().sort_by_key()`](#method.make_contiguous) uchishandisa iyo imwechete kiyi yekubvisa basa.
    ///
    ///
    /// Kana kukosha kwacho kukawanikwa saka [`Result::Ok`] inodzoserwa, iine indekisi yechinhu chinoenderana.
    /// Kana paine machisi akawanda, saka chero mumwe wemitambo unogona kudzoserwa.
    /// Kana kukosha kwacho kusingawanikwe [`Result::Err`] inodzoserwa, iine indekisi panogona kuiswa chinhu chinoenderana uchichengetedza zvakarongeka.
    ///
    /// # Examples
    ///
    /// Inotarisa kumusoro kwakateedzana kwezvinhu zvina muchidimbu chemaviri chakarongedzwa nezvinhu zvavo zvechipiri.
    /// Yekutanga inowanikwa, iine chinzvimbo chakasarudzika;wechipiri newechitatu havana kuwanikwa;yechina inogona kuenderana chero chinzvimbo mu `[1, 4]`.
    ///
    /// ```
    /// #![feature(vecdeque_binary_search)]
    /// use std::collections::VecDeque;
    ///
    /// let deque: VecDeque<_> = vec![(0, 0), (2, 1), (4, 1), (5, 1),
    ///          (3, 1), (1, 2), (2, 3), (4, 5), (5, 8), (3, 13),
    ///          (1, 21), (2, 34), (4, 55)].into();
    ///
    /// assert_eq!(deque.binary_search_by_key(&13, |&(a, b)| b),  Ok(9));
    /// assert_eq!(deque.binary_search_by_key(&4, |&(a, b)| b),   Err(7));
    /// assert_eq!(deque.binary_search_by_key(&100, |&(a, b)| b), Err(13));
    /// let r = deque.binary_search_by_key(&1, |&(a, b)| b);
    /// assert!(matches!(r, Ok(1..=4)));
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vecdeque_binary_search", issue = "78021")]
    #[inline]
    pub fn binary_search_by_key<'a, B, F>(&'a self, b: &B, mut f: F) -> Result<usize, usize>
    where
        F: FnMut(&'a T) -> B,
        B: Ord,
    {
        self.binary_search_by(|k| f(k).cmp(b))
    }
}

impl<T: Clone> VecDeque<T> {
    /// Inogadzirisa iyo `VecDeque` mu-nzvimbo kuitira kuti `len()` ienzane new_len, kungave nekubvisa zvakawandisa zvinhu kubva kumashure kana nekumisikidza matombo e `value` kumashure.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let mut buf = VecDeque::new();
    /// buf.push_back(5);
    /// buf.push_back(10);
    /// buf.push_back(15);
    /// assert_eq!(buf, [5, 10, 15]);
    ///
    /// buf.resize(2, 0);
    /// assert_eq!(buf, [5, 10]);
    ///
    /// buf.resize(5, 20);
    /// assert_eq!(buf, [5, 10, 20, 20, 20]);
    /// ```
    ///
    #[stable(feature = "deque_extras", since = "1.16.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        self.resize_with(new_len, || value.clone());
    }
}

/// Inodzorera iyo index mune yepasi buffer yeakapihwa zvine musoro element index.
#[inline]
fn wrap_index(index: usize, size: usize) -> usize {
    // saizi inogara iri simba re2
    debug_assert!(size.is_power_of_two());
    index & (size - 1)
}

/// Verenga huwandu hwezvinhu zvakasara kuti zviverengerwe mubhafa
#[inline]
fn count(tail: usize, head: usize, size: usize) -> usize {
    // saizi inogara iri simba re2
    (head.wrapping_sub(tail)) & (size - 1)
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialEq> PartialEq for VecDeque<A> {
    fn eq(&self, other: &VecDeque<A>) -> bool {
        if self.len() != other.len() {
            return false;
        }
        let (sa, sb) = self.as_slices();
        let (oa, ob) = other.as_slices();
        if sa.len() == oa.len() {
            sa == oa && sb == ob
        } else if sa.len() < oa.len() {
            // Nguva dzose inoparadzaniswa muzvikamu zvitatu, semuenzaniso: wega: [a b c|d e f] imwe: [0 1 2 3|4 5] kumberi=3, pakati=1, [a b c] == [0 1 2]&&[d] == [3]&&[e f] == [4 5]
            //
            //
            //
            //
            let front = sa.len();
            let mid = oa.len() - front;

            let (oa_front, oa_mid) = oa.split_at(front);
            let (sb_mid, sb_back) = sb.split_at(mid);
            debug_assert_eq!(sa.len(), oa_front.len());
            debug_assert_eq!(sb_mid.len(), oa_mid.len());
            debug_assert_eq!(sb_back.len(), ob.len());
            sa == oa_front && sb_mid == oa_mid && sb_back == ob
        } else {
            let front = oa.len();
            let mid = sa.len() - front;

            let (sa_front, sa_mid) = sa.split_at(front);
            let (ob_mid, ob_back) = ob.split_at(mid);
            debug_assert_eq!(sa_front.len(), oa.len());
            debug_assert_eq!(sa_mid.len(), ob_mid.len());
            debug_assert_eq!(sb.len(), ob_back.len());
            sa_front == oa && sa_mid == ob_mid && sb == ob_back
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Eq> Eq for VecDeque<A> {}

__impl_slice_eq1! { [] VecDeque<A>, Vec<B>, }
__impl_slice_eq1! { [] VecDeque<A>, &[B], }
__impl_slice_eq1! { [] VecDeque<A>, &mut [B], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, [B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &[B; N], }
__impl_slice_eq1! { [const N: usize] VecDeque<A>, &mut [B; N], }

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: PartialOrd> PartialOrd for VecDeque<A> {
    fn partial_cmp(&self, other: &VecDeque<A>) -> Option<Ordering> {
        self.iter().partial_cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Ord> Ord for VecDeque<A> {
    #[inline]
    fn cmp(&self, other: &VecDeque<A>) -> Ordering {
        self.iter().cmp(other.iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Hash> Hash for VecDeque<A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.len().hash(state);
        // Izvo hazvigoneke kushandisa Hash::hash_slice pazvidimbu zvakadzorerwa ne as_slices nzira sezvo kureba kwavo kuchizosiyana mune mamwe madhiri akafanana.
        //
        //
        // Hasher inongovimbisa kuenzana kweiyo chaiyo seti yekufona kunzira dzayo.
        //
        //
        self.iter().for_each(|elem| elem.hash(state));
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Index<usize> for VecDeque<A> {
    type Output = A;

    #[inline]
    fn index(&self, index: usize) -> &A {
        self.get(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> IndexMut<usize> for VecDeque<A> {
    #[inline]
    fn index_mut(&mut self, index: usize) -> &mut A {
        self.get_mut(index).expect("Out of bounds access")
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> FromIterator<A> for VecDeque<A> {
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> VecDeque<A> {
        let iterator = iter.into_iter();
        let (lower, _) = iterator.size_hint();
        let mut deq = VecDeque::with_capacity(lower);
        deq.extend(iterator);
        deq
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> IntoIterator for VecDeque<T> {
    type Item = T;
    type IntoIter = IntoIter<T>;

    /// Inoshandisa iyo `VecDeque` kuita yekumberi-kumashure-iterator inoburitsa zvinhu nemutengo.
    ///
    fn into_iter(self) -> IntoIter<T> {
        IntoIter { inner: self }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a VecDeque<T> {
    type Item = &'a T;
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T> IntoIterator for &'a mut VecDeque<T> {
    type Item = &'a mut T;
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A> Extend<A> for VecDeque<A> {
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T) {
        // Iri basa rinofanirwa kunge rakaenzana nehunhu hwe:
        //
        //      yechinhu chiri mu iter.into_iter() {
        //          self.push_back(item);
        //      }
        let mut iter = iter.into_iter();
        while let Some(element) = iter.next() {
            if self.len() == self.capacity() {
                let (lower, _) = iter.size_hint();
                self.reserve(lower.saturating_add(1));
            }

            let head = self.head;
            self.head = self.wrap_add(self.head, 1);
            unsafe {
                self.buffer_write(head, element);
            }
        }
    }

    #[inline]
    fn extend_one(&mut self, elem: A) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: 'a + Copy> Extend<&'a T> for VecDeque<T> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &elem: &T) {
        self.push_back(elem);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug> fmt::Debug for VecDeque<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_list().entries(self).finish()
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<Vec<T>> for VecDeque<T> {
    /// Chinja [`Vec<T>`] kuita [`VecDeque<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Izvi zvinodzivirira kuiswazve nharaunda pazvinogoneka, asi mamiriro ezvinhu acho akaomarara, uye anogona kuchinja, uye nekudaro haifanire kuvimbwa nayo kunze kwekunge iyo `Vec<T>` yabva ku `From<VecDeque<T>>` uye isina kupihwa nzvimbo zvakare.
    ///
    ///
    fn from(mut other: Vec<T>) -> Self {
        let len = other.len();
        if mem::size_of::<T>() == 0 {
            // Iko hakuna kupihwa chaiko kweZSTs kunetsekana nezve kugona, asi `VecDeque` haigone kubata hwakareba hwakareba se `Vec`.
            //
            assert!(len < MAXIMUM_ZST_CAPACITY, "capacity overflow");
        } else {
            // Isu tinofanirwa kudzora kana simba racho risiri simba reviri, diki kwazvo kana isina kana imwe nzvimbo yemahara.
            // Isu tinoita izvi ichiri mu `Vec` saka zvinhu zvinodonha pa panic.
            //
            let min_cap = cmp::max(MINIMUM_CAPACITY, len) + 1;
            let cap = cmp::max(min_cap, other.capacity()).next_power_of_two();
            if other.capacity() != cap {
                other.reserve_exact(cap - len);
            }
        }

        unsafe {
            let (other_buf, len, capacity) = other.into_raw_parts();
            let buf = RawVec::from_raw_parts(other_buf, capacity);
            VecDeque { tail: 0, head: len, buf }
        }
    }
}

#[stable(feature = "vecdeque_vec_conversions", since = "1.10.0")]
impl<T> From<VecDeque<T>> for Vec<T> {
    /// Chinja [`VecDeque<T>`] kuita [`Vec<T>`].
    ///
    /// [`Vec<T>`]: crate::vec::Vec
    /// [`VecDeque<T>`]: crate::collections::VecDeque
    ///
    /// Izvi hazvimbofaniri kugovera zvakare, asi zvinoda kuita *O*(*n*) kufamba kwedata kana denderedzwa bhaudhi isingaitike iri pakutanga kwekugoverwa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// // Iyi iri *O*(1).
    /// let deque: VecDeque<_> = (1..5).collect();
    /// let ptr = deque.as_slices().0.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    ///
    /// // Iyi inoda kugadzirisazve data.
    /// let mut deque: VecDeque<_> = (1..5).collect();
    /// deque.push_front(9);
    /// deque.push_front(8);
    /// let ptr = deque.as_slices().1.as_ptr();
    /// let vec = Vec::from(deque);
    /// assert_eq!(vec, [8, 9, 1, 2, 3, 4]);
    /// assert_eq!(vec.as_ptr(), ptr);
    /// ```
    fn from(mut other: VecDeque<T>) -> Self {
        other.make_contiguous();

        unsafe {
            let other = ManuallyDrop::new(other);
            let buf = other.buf.ptr();
            let len = other.len();
            let cap = other.cap();

            if other.tail != 0 {
                ptr::copy(buf.add(other.tail), buf, len);
            }
            Vec::from_raw_parts(buf, len, cap)
        }
    }
}