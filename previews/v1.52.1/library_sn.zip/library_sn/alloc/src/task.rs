#![stable(feature = "wake_trait", since = "1.51.0")]
//! Mhando uye Traits yekushanda pamwe neasynchronous mabasa.
use core::mem::ManuallyDrop;
use core::task::{RawWaker, RawWakerVTable, Waker};

use crate::sync::Arc;

/// Kuitwa kwekumutsa basa pane anozadza.
///
/// Iyi trait inogona kushandiswa kugadzira [`Waker`].
/// Anouraya anogona kutsanangura kuitiswa kweiyi trait, uye oshandisa izvo kuvaka Waker kuti ipfuure kumabasa anoitwa pane iye muurayi.
///
/// Iyi trait ndeyekurangarira-yakachengeteka uye ergonomic imwe nzira yekuvaka [`RawWaker`].
/// Iyo inotsigira yakajairwa executor dhizaini umo iyo data inoshandiswa kumutsa basa inochengetwa mu [`Arc`].
/// Vamwe mafaera (kunyanya iwo eanodzika masisitimu) haakwanise kushandisa iyi API, ndosaka [`RawWaker`] iripo senge imwe yeaya masisitimu.
///
/// [arc]: ../../std/sync/struct.Arc.html
///
/// # Examples
///
/// Yekutanga `block_on` basa rinotora future uye ndokumhanyisa kuti ripedze pane yazvino tambo.
///
/// **Note:** Uyu muenzaniso unotengesa kurongeka kuti zvive nyore.
/// Kuti udzivise zvipingamupinyi, zvigadzirwa zvekugadzira-giredhi zvakare zvinoda kubata mafoni epakati ku `thread::unpark` pamwe nekukumbira kwakavakirwa.
///
///
/// ```rust
/// use std::future::Future;
/// use std::sync::Arc;
/// use std::task::{Context, Poll, Wake};
/// use std::thread::{self, Thread};
///
/// /// Iyo inomutsa inomutsa tambo yazvino painodaidzwa.
/// struct ThreadWaker(Thread);
///
/// impl Wake for ThreadWaker {
///     fn wake(self: Arc<Self>) {
///         self.0.unpark();
///     }
/// }
///
/// /// Mhanya future kuti upedze pane yazvino tambo.
/// fn block_on<T>(fut: impl Future<Output = T>) -> T {
///     // Pini iyo future saka inogona kuongororwa.
///     let mut fut = Box::pin(fut);
///
///     // Gadzira mamiriro matsva kuti apfuudzirwe ku future.
///     let t = thread::current();
///     let waker = Arc::new(ThreadWaker(t)).into();
///     let mut cx = Context::from_waker(&waker);
///
///     // Mhanya iyo future kupedzisa.
///     loop {
///         match fut.as_mut().poll(&mut cx) {
///             Poll::Ready(res) => return res,
///             Poll::Pending => thread::park(),
///         }
///     }
/// }
///
/// block_on(async {
///     println!("Hi from inside a future!");
/// });
/// ```
///
///
///
///
#[stable(feature = "wake_trait", since = "1.51.0")]
pub trait Wake {
    /// Mutsa basa iri.
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake(self: Arc<Self>);

    /// Mutsa iri basa usingapedze iro rakamutsa.
    ///
    /// Kana muurayi akatsigira nzira yakachipa yekumuka asingadye iyo inomutsa, inofanira kukunda nzira iyi.
    /// Nokusingaperi, inobatanidza iyo [`Arc`] uye inodaidza [`wake`] pane dombo.
    ///
    /// [`wake`]: Wake::wake
    ///
    #[stable(feature = "wake_trait", since = "1.51.0")]
    fn wake_by_ref(self: &Arc<Self>) {
        self.clone().wake();
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for Waker {
    fn from(waker: Arc<W>) -> Waker {
        // Kachengeteka: Izvi zvakachengeteka nekuti raw_waker inovaka zvakachengeteka
        // RawWaker kubva kuArc<W>.
        unsafe { Waker::from_raw(raw_waker(waker)) }
    }
}

#[stable(feature = "wake_trait", since = "1.51.0")]
impl<W: Wake + Send + Sync + 'static> From<Arc<W>> for RawWaker {
    fn from(waker: Arc<W>) -> RawWaker {
        raw_waker(waker)
    }
}

// NB: Iri rakavanzika basa rekugadzira RawWaker rinoshandiswa, kwete
// kuisa izvi mu `From<Arc<W>> for RawWaker` impl, kuona kuti chengetedzo ye `From<Arc<W>> for Waker` haibvi pane chaiyo trait kutumira, pachinzvimbo zvese impls inodaidza iri basa zvakananga uye zvakajeka.
//
//
//
#[inline(always)]
fn raw_waker<W: Wake + Send + Sync + 'static>(waker: Arc<W>) -> RawWaker {
    // Kuwedzera iyo yekuverenga kuverenga yeiyo arc kuti ikwanise iyo.
    unsafe fn clone_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) -> RawWaker {
        unsafe { Arc::increment_strong_count(waker as *const W) };
        RawWaker::new(
            waker as *const (),
            &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
        )
    }

    // Muka nemutengo, uchifambisa iyo Arc mu Wake::wake basa
    unsafe fn wake<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { Arc::from_raw(waker as *const W) };
        <W as Wake>::wake(waker);
    }

    // Muka nereferenzi, putira iyo inomutsa muManualDrop kuti udzivise kuidonhedza
    unsafe fn wake_by_ref<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        let waker = unsafe { ManuallyDrop::new(Arc::from_raw(waker as *const W)) };
        <W as Wake>::wake_by_ref(&waker);
    }

    // Kuderedza kuverenga kweiyo Arc pane kudonha
    unsafe fn drop_waker<W: Wake + Send + Sync + 'static>(waker: *const ()) {
        unsafe { Arc::decrement_strong_count(waker as *const W) };
    }

    RawWaker::new(
        Arc::into_raw(waker) as *const (),
        &RawWakerVTable::new(clone_waker::<W>, wake::<W>, wake_by_ref::<W>, drop_waker::<W>),
    )
}