use core::iter::{InPlaceIterable, SourceIter};
use core::mem::{self, ManuallyDrop};
use core::ptr::{self};

use super::{AsIntoIter, InPlaceDrop, SpecFromIter, SpecFromIterNested, Vec};

/// Nyanzvi yekumaka yekutora iyo iterator pombi kupinda muVec uku uchishandisazve iyo sosi yekugoverwa, kureva
/// kuita pombi munzvimbo.
///
/// Iyo SourceIter mubereki trait inodikanwa kune iyo inyanzvi basa kuti riwane mugove uyo unozoshandiswa zvakare.
/// Asi hazvina kukwana kuti hunyanzvi huve hunoshanda.
/// Ona mimwe miganho pane iyo impl.
#[rustc_unsafe_specialization_marker]
pub(super) trait SourceIterMarker: SourceIter<Source: AsIntoIter> {}

// Iyo std-yemukati SourceIter/InPlaceIterable traits inoitwa chete nemaketani eAdapter <Adapter<Adapter<IntoIter>>> (zvese zviri zve core/std).
// Mimwe miganho pane inoitwa adapter (kupfuura `impl<I: Trait> Trait for Adapter<I>`) zvinongoenderana ne traits yatotemerwa sehunyanzvi traits (Copy, TrustedRandomAccess, FusedIterator).
//
// I.e. mucherechedzo hautsamire pahupenyu hwemhando dzinopihwa nevashandisi.Modulo iyo Copy gomba, iyo yakati wandei humwe hunyanzvi hwakatovimba nahwo.
//
//
impl<T> SourceIterMarker for T where T: SourceIter<Source: AsIntoIter> + InPlaceIterable {}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T> + SourceIterMarker,
{
    default fn from_iter(mut iterator: I) -> Self {
        // Zvimwe zvinodiwa izvo zvisingakwanise kuratidzwa kuburikidza ne trait bound.Isu tinovimba const eval pachinzvimbo:
        // a) hapana maZST sezvo paisazove nemugove wekushandisazve uye pointer arithmetic yaizoita panic b) saizi mechi sezvainodiwa neAlloc kondirakiti c) kuenzanisa kuenderana kunodiwa neAlloc kondirakiti.
        //
        //
        //
        if mem::size_of::<T>() == 0
            || mem::size_of::<T>()
                != mem::size_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
            || mem::align_of::<T>()
                != mem::align_of::<<<I as SourceIter>::Source as AsIntoIter>::Item>()
        {
            // kudonha kune mamwe maitiro akajairika
            return SpecFromIterNested::from_iter(iterator);
        }

        let (src_buf, src_ptr, dst_buf, dst_end, cap) = unsafe {
            let inner = iterator.as_inner().as_into_iter();
            (
                inner.buf.as_ptr(),
                inner.ptr,
                inner.buf.as_ptr() as *mut T,
                inner.end as *const T,
                inner.cap,
            )
        };

        // shandisa kuyedza-kupeta kubvira
        // - inoita vectorize zvirinani kune mamwe maitera maiterator
        // - kusiyana nenzira dzakawanda dzemukati iteration, zvinongotora &mut yega
        // - inotibvumira kunyorera pointer yekunyora kuburikidza nemukati mayo uye kuidzosa pakupedzisira
        let sink = InPlaceDrop { inner: dst_buf, dst: dst_buf };
        let sink = iterator
            .try_fold::<_, _, Result<_, !>>(sink, write_in_place_with_drop(dst_end))
            .unwrap();
        // iteration yakabudirira, usadonhedze musoro
        let dst = ManuallyDrop::new(sink).dst;

        let src = unsafe { iterator.as_inner().as_into_iter() };
        // tarisa kana SourceIter kontrakiti yakasimudzwa bakoat: dai vanga vasiri isu tingatotadza kusvika pano
        //
        debug_assert_eq!(src_buf, src.buf.as_ptr());
        // tarisa InPlaceIterable contract.Izvi zvinongogoneka kana iyo iterator yakafambisa sosi poindi zvachose.
        // Kana ikashandisa kusatariswa kupinda kuburikidza neTrustedRandomAccess ipapo sosi yekunongedzera ichagara munzvimbo yayo yekutanga uye hatigone kuishandisa sereferenzi
        //
        if src.ptr != src_ptr {
            debug_assert!(
                dst as *const _ <= src.ptr,
                "InPlaceIterable contract violation, write pointer advanced beyond read pointer"
            );
        }

        // donhedza chero hunhu hunosara pamuswe wetsime asi tadzisa kudonhedzwa kwechipo pachako kana IntoIter yabuda pachiyero kana donhwe panics tobva tadonhedza chero zvinhu zvakaunganidzwa mu dst_buf
        //
        //
        src.forget_allocation_drop_remaining();

        let vec = unsafe {
            let len = dst.offset_from(dst_buf) as usize;
            Vec::from_raw_parts(dst_buf, len, cap)
        };

        vec
    }
}

fn write_in_place_with_drop<T>(
    src_end: *const T,
) -> impl FnMut(InPlaceDrop<T>, T) -> Result<InPlaceDrop<T>, !> {
    move |mut sink, item| {
        unsafe {
            // chibvumirano cheInPlaceIterable hachigone kusimbiswa chaizvo pano sezvo try_fold ine chirevo chega kune yekunongedzera kwatinogona chete kutarisa kana ichiri munzira
            //
            //
            debug_assert!(sink.dst as *const _ <= src_end, "InPlaceIterable contract violation");
            ptr::write(sink.dst, item);
            sink.dst = sink.dst.add(1);
        }
        Ok(sink)
    }
}