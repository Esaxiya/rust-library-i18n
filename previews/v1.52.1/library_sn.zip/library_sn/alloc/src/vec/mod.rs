//! Rudzi rwekukura rwakarongeka mhando ine murwi-yakapihwa zvirimo, zvakanyorwa `Vec<T>`.
//!
//! Vectors vane `O(1)` indexing, amortized `O(1)` Push (kusvika kumagumo) uye `O(1)` pop (kubva kumagumo).
//!
//!
//! Vectors vanoona kuti havafi vakapa zvinopfuura `isize::MAX` byte.
//!
//! # Examples
//!
//! Unogona kunyatsogadzira [`Vec`] ne [`Vec::new`]:
//!
//! ```
//! let v: Vec<i32> = Vec::new();
//! ```
//!
//! ... kana kushandisa [`vec!`] macro:
//!
//! ```
//! let v: Vec<i32> = vec![];
//!
//! let v = vec![1, 2, 3, 4, 5];
//!
//! let v = vec![0; 10]; // zero gumi
//! ```
//!
//! Unogona [`push`] kukosha kusvika kumagumo e vector (inozokura iyo vector sezvainodiwa):
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! v.push(3);
//! ```
//!
//! Popping tsika inoshanda nenzira yakafanana zvakafanana:
//!
//! ```
//! let mut v = vec![1, 2];
//!
//! let two = v.pop();
//! ```
//!
//! Vectors zvakare inotsigira indexing (kuburikidza ne [`Index`] uye [`IndexMut`] traits):
//!
//! ```
//! let mut v = vec![1, 2, 3];
//! let three = v[2];
//! v[1] = v[1] + 5;
//! ```
//!
//! [`push`]: Vec::push
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::cmp::{self, Ordering};
use core::convert::TryFrom;
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::{arith_offset, assume};
use core::iter::FromIterator;
use core::marker::PhantomData;
use core::mem::{self, ManuallyDrop, MaybeUninit};
use core::ops::{self, Index, IndexMut, Range, RangeBounds};
use core::ptr::{self, NonNull};
use core::slice::{self, SliceIndex};

use crate::alloc::{Allocator, Global};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::raw_vec::RawVec;

#[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
pub use self::drain_filter::DrainFilter;

mod drain_filter;

#[stable(feature = "vec_splice", since = "1.21.0")]
pub use self::splice::Splice;

mod splice;

#[stable(feature = "drain", since = "1.6.0")]
pub use self::drain::Drain;

mod drain;

mod cow;

pub(crate) use self::into_iter::AsIntoIter;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::into_iter::IntoIter;

mod into_iter;

use self::is_zero::IsZero;

mod is_zero;

mod source_iter_marker;

mod partial_eq;

use self::spec_from_elem::SpecFromElem;

mod spec_from_elem;

use self::set_len_on_drop::SetLenOnDrop;

mod set_len_on_drop;

use self::in_place_drop::InPlaceDrop;

mod in_place_drop;

use self::spec_from_iter_nested::SpecFromIterNested;

mod spec_from_iter_nested;

use self::spec_from_iter::SpecFromIter;

mod spec_from_iter;

use self::spec_extend::SpecExtend;

mod spec_extend;

/// Rudzi rwakakura runogona kukura, rwakanyorwa sa `Vec<T>` uye yakadudzwa 'vector'.
///
/// # Examples
///
/// ```
/// let mut vec = Vec::new();
/// vec.push(1);
/// vec.push(2);
///
/// assert_eq!(vec.len(), 2);
/// assert_eq!(vec[0], 1);
///
/// assert_eq!(vec.pop(), Some(2));
/// assert_eq!(vec.len(), 1);
///
/// vec[0] = 7;
/// assert_eq!(vec[0], 7);
///
/// vec.extend([1, 2, 3].iter().copied());
///
/// for x in &vec {
///     println!("{}", x);
/// }
/// assert_eq!(vec, [7, 1, 2, 3]);
/// ```
///
/// Iyo [`vec!`] macro inopihwa kuita kuti kutangisa kuve nyore:
///
/// ```
/// let mut vec = vec![1, 2, 3];
/// vec.push(4);
/// assert_eq!(vec, [1, 2, 3, 4]);
/// ```
///
/// Iyo inogona zvakare kutanga chimwe nechimwe chinhu che `Vec<T>` ine yakapihwa kukosha.
/// Izvi zvinogona kushanda zvakanyanya kupfuura kuita kugovera uye kutanga mumatanho akapatsanuka, kunyanya kana uchitanga vector yemazero:
///
/// ```
/// let vec = vec![0; 5];
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
///
/// // Izvi zvinotevera zvakaenzana, asi zvinogona kunonoka:
/// let mut vec = Vec::with_capacity(5);
/// vec.resize(5, 0);
/// assert_eq!(vec, [0, 0, 0, 0, 0]);
/// ```
///
/// Kuti uwane rumwe ruzivo, ona [Capacity and Reallocation](#capacity-and-reallocation).
///
/// Shandisa `Vec<T>` seyakanaka stack:
///
/// ```
/// let mut stack = Vec::new();
///
/// stack.push(1);
/// stack.push(2);
/// stack.push(3);
///
/// while let Some(top) = stack.pop() {
///     // Prints 3, 2, 1
///     println!("{}", top);
/// }
/// ```
///
/// # Indexing
///
/// Iyo `Vec` mhando inobvumidza kuwana kukosha ne index, nekuti inoshandisa iyo [`Index`] trait.Muenzaniso uchanyatso kujekesa:
///
/// ```
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[1]); // icharatidza '2'
/// ```
///
/// Nekudaro chenjera: kana iwe ukaedza kuwana index isiri mu `Vec`, software yako ichaita panic!Iwe haugone kuita izvi:
///
/// ```should_panic
/// let v = vec![0, 2, 4, 6];
/// println!("{}", v[6]); // it will panic!
/// ```
///
/// Shandisa [`get`] uye [`get_mut`] kana uchida kutarisa kuti indekisi iri mu `Vec`.
///
/// # Slicing
///
/// `Vec` inogona kuchinjika.Kune rimwe divi, zvidimbu zvinhu zvekuverenga-chete.
/// Kuti uwane [slice][prim@slice], shandisa [`&`].Muenzaniso:
///
/// ```
/// fn read_slice(slice: &[usize]) {
///     // ...
/// }
///
/// let v = vec![0, 1];
/// read_slice(&v);
///
/// // ... uye ndizvozvo chete!
/// // iwe unogona zvakare kuzviita seizvi:
/// let u: &[usize] = &v;
/// // kana seizvi:
/// let u: &[_] = &v;
/// ```
///
/// Mu Rust, zvakajairika kupfuudza zvimedu sekupokana kwete vectors kana iwe uchingoda kupa kuverenga kuverenga.Izvo zvinoenda ku [`String`] uye [`&str`].
///
/// # Unyanzvi uye reallocation
///
/// Iko kugona kwe vector ndiyo huwandu hwenzvimbo yakapihwa chero future zvinhu zvichawedzerwa pa vector.Izvi hazvifanirwe kuvhiringidzwa ne *kureba* kwe vector, iyo inotsanangura huwandu hwezvinhu chaizvo mukati me vector.
/// Kana kureba kwe vector kukapfuura kwayakakwanira, kugona kwayo kunobva kwangoerekana kwawedzerwa, asi zvinhu zvacho zvinofanirwa kugovaniswa.
///
/// Semuenzaniso, vector ine chinzvimbo gumi uye kureba 0 inogona kunge isina vector ine nzvimbo yezvimwe gumi zvinhu.Kusunda zvinhu gumi kana zvishoma pa vector hakuchinji kugona kwayo kana kukonzera kuiswazve kuitika.
/// Nekudaro, kana iyo vector kureba kukawedzerwa kusvika gumi nerimwe, ichafanirwa kuisazve nzvimbo, iyo inogona kunonoka.Neichi chikonzero, zvinokurudzirwa kushandisa [`Vec::with_capacity`] pese pazvinogoneka kutsanangura kuti vector inotarisirwa kuwana yakakura sei.
///
/// # Guarantees
///
/// Nekuda kwehunhu hwayo hunoshamisa, `Vec` inoita yakawanda yekuvimbisa nezve dhizaini yayo.Izvi zvinoita kuti ive yepasi-pamusoro kumusoro sezvinobvira mune yakajairika kesi, uye inogona kunyatso shongedzwa nenzira dzekare nenzira isina kuchengetedzeka kodhi.Ziva kuti izvi zvivimbiso zvinoreva kune isina kukodzera `Vec<T>`.
/// Kana mamwe maratidziro erudzi akawedzerwa (semuenzaniso, kutsigira vagoveri vetsika), kudarika kwavo kwakashata kunogona kuchinja maitiro.
///
/// Kunyanya zvakanyanya, `Vec` iri uye ichagara iri (pointer, kugona, kureba) katatu.Kwete, kana zvishoma.Kurongeka kweminda iyi hakuna kunyatso kutaurwa, uye iwe unofanirwa kushandisa nzira dzakakodzera kugadzirisa izvi.
/// Iyo pointer haizombovi isina basa, saka iyi mhando ndeye null-pointer-yakagadziridzwa.
///
/// Nekudaro, iyo pointer inogona kunge isinganongedze kune yakapihwa ndangariro.
/// Kunyanya, kana iwe ukavaka `Vec` ine chinzvimbo 0 kuburikidza [`Vec::new`], [`vec![]`][`vec!`], [`Vec::with_capacity(0)`][`Vec::with_capacity`], kana nekufonera [`shrink_to_fit`] paVec isina chinhu, haizogovera ndangariro.Saizvozvo, kana iwe ukachengeta zero-saizi mhando mukati me `Vec`, haizovapa nzvimbo kwavari.
/// *Ziva kuti mune iyi nyaya `Vec` inogona kusataura [`capacity`] ye0*.
/// `Vec` ichagovera kana uye chete kana [`mem: : size_of::<T>`]`() * capacity()> 0`.
/// Kazhinji, `` Vec '' ruzivo rwekugovera rune hunyengeri-kana iwe uchifunga kugovera ndangariro uchishandisa `Vec` uye woishandisa kune chimwe chinhu (kungaita kuti upfuure kune isina kuchengetedzeka kodhi, kana kuvaka yako pachako memory-yakatsigirwa muunganidzwa), ive shuwa kugadzirisa ino ndangariro uchishandisa `from_raw_parts` kudzoreredza iyo `Vec` uye wozoisiya.
///
/// Kana `Vec`*ya* gadza ndangariro, ipapo ndangariro yainongedzera iri pamurwi (sekutsanangurwa kwayakaitwa nemupi we Rust yakagadzirirwa kuti ishandiswe nekutadza), uye poindi yayo inonongedzera ku [`len`] yakatangwa, zvinhu zvinoenderana kuitira (izvo ona kana iwe wakamanikidza icho chidimbu), ichiteverwa ne [`kugona`]`,`[`len`] zvine musoro zvisina kuvhurwa, zvinoenderana zvinhu.
///
///
/// vector ine zvinhu `'a'` uye `'b'` ine chinzvimbo chechina inogona kutaridzika sezasi.Chikamu chepamusoro i `Vec` dhizaini, iine chinongedzera kumusoro wemugove mumurwi, kureba uye kugona.
/// Chikamu chepazasi kugoverwa pamurwi, inoenderana memory block.
///
/// ```text
///             ptr      len  capacity
///        +--------+--------+--------+
///        | 0x0123 |      2 |      4 |
///        +--------+--------+--------+
///             |
///             v
/// Heap   +--------+--------+--------+--------+
///        |    'a' |    'b' | uninit | uninit |
///        +--------+--------+--------+--------+
/// ```
///
/// - **uninit** inomiririra ndangariro isina kutanga, ona [`MaybeUninit`].
/// - Note: iyo ABI haina kugadzikana uye `Vec` haigadzi vimbiso nezve marongero ayo ekurangarira (kusanganisira marongero eminda).
///
/// `Vec` haizomboite "small optimization" uko zvinhu zviri chaizvo zvakachengetwa mudura nekuda kwezvikonzero zviviri:
///
/// * Zvingaite kuti zvinyanye kuomera kodhi isina kuchengetedzeka kunyatso kushandisa `Vec`.Zviri mukati me `Vec` zvaisazove nekero yakagadzikana dai yaingofambiswa, uye zvaizonyanya kunetsa kuona kana `Vec` yainge yagovera ndangariro.
///
/// * Izvo zvaizoranga iyo general kesi, zvichikonzera imwe yekuwedzera branch pane ese mukana.
///
/// `Vec` haimbozozvinonokera yega, kunyangwe isina chinhu zvachose.Izvi zvinoona kuti hapana kupihwa zvisina kukodzera kana kuisirwa kunoitika.Kuburitsa `Vec` wobva woizadza ichidzosera iyo yakafanana [`len`] haifanire kuwana mafoni kune anogovera.Kana iwe uchida kusunungura isina kushandiswa ndangariro, shandisa [`shrink_to_fit`] kana [`shrink_to`].
///
/// [`push`] uye [`insert`] haizombo (re) kugovera kana huwandu hwakataurwa hwaringana.[`push`] uye [`insert`]*icha*(re) kugovera kana [`len`]``==` [`capacity`].Ndokunge, kugona kunzi kwakanyatsokwana, uye kunogona kuvimbwa nako.Iyo inogona kutoshandiswa kushandisazve manyore memory yakapihwa ne `Vec` kana ichidikanwa.
/// Nzira dzekuisa Bulk *dzinogona* kuisazve nzvimbo, kunyangwe pazvisingadiwe.
///
/// `Vec` haina kuvimbisa chero yakatarwa nzira yekukura painogadzirisazve kana izere, kana kana [`reserve`] ichidaidzwa.Iyo yazvino zano iri yakakosha uye inogona kuratidza inoshuvira kushandisa isinga-inowirirana yekukura chinhu.Chero zano rashandiswa rinoda chokwadi garandi *O*(1) amortized [`push`].
///
/// `vec![x; n]`, `vec![a, b, c, d]`, uye [`Vec::with_capacity(n)`][`Vec::with_capacity`], zvese zvichaburitsa `Vec` ine chairo chinzvimbo chakakumbirwa.
/// Kana [`len`]`==`[`kugona`], (sezvazviri kune [`vec!`] macro), ipapo `Vec<T>` inogona kushandurwa kuenda nekubva ku [`Box<[T]>`][owned slice] isina kuisazve nzvimbo kana kufambisa zvinhu.
///
/// `Vec` haizonyora zvakanyanya chero dhata rinobviswa mariri, asi zvakare harizochengetedze.Ndangariro yayo isina kuvhurwa ndeyekutsvaira nzvimbo iyo yainogona kushandisa chero yainoda.Izvo zvinowanzo kungoita chero chinonyanya kushanda kana neimwe nzira kuitisa.Usavimba nedata rakabviswa kuti ribviswe kuitira kuchengetedza.
/// Kunyangwe iwe ukadonhedza `Vec`, buffer yayo inogona kungoshandiswazve neimwe `Vec`.
/// Kunyangwe iwe zero zero ye`Vec ndangariro kutanga, izvo zvingangodaro zvisingaitike nekuti iyo optimizer haifunge iyi parutivi-mhedzisiro iyo inofanirwa kuchengetedzwa.
/// Pane imwe nyaya yatisingazotyora, zvisinei: kushandisa `unsafe` kodhi kunyorera kune yakanyanya kuwanda, uye nekuwedzera iyo urefu kuti ifanane, inogara ichishanda.
///
/// Parizvino, `Vec` haivimbisi marongero ezvinhu zvakadonhedzwa.
/// Iwo marongero akachinja munguva yakapfuura uye anogona kuchinja zvekare.
///
/// [`get`]: ../../std/vec/struct.Vec.html#method.get
/// [`get_mut`]: ../../std/vec/struct.Vec.html#method.get_mut
/// [`String`]: crate::string::String
/// [`&str`]: type@str
/// [`shrink_to_fit`]: Vec::shrink_to_fit
/// [`shrink_to`]: Vec::shrink_to
/// [`capacity`]: Vec::capacity
/// [`mem::size_of::<T>`]: core::mem::size_of
/// [`len`]: Vec::len
/// [`push`]: Vec::push
/// [`insert`]: Vec::insert
/// [`reserve`]: Vec::reserve
/// [`MaybeUninit`]: core::mem::MaybeUninit
/// [owned slice]: Box
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "vec_type")]
pub struct Vec<T, #[unstable(feature = "allocator_api", issue = "32838")] A: Allocator = Global> {
    buf: RawVec<T, A>,
    len: usize,
}

////////////////////////////////////////////////////////////////////////////////
// Nzira dzekuzvarwa nadzo
////////////////////////////////////////////////////////////////////////////////

impl<T> Vec<T> {
    /// Inogadzira itsva, isina `Vec<T>`.
    ///
    /// vector haizogovera kudzamara zvinhu zvasundirwa pairi.
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(unused_mut)]
    /// let mut vec: Vec<i32> = Vec::new();
    /// ```
    #[inline]
    #[rustc_const_stable(feature = "const_vec_new", since = "1.39.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> Self {
        Vec { buf: RawVec::NEW, len: 0 }
    }

    /// Inogadzira nyowani, isina chinhu `Vec<T>` ine yakatarwa chinzvimbo.
    ///
    /// vector ichakwanisa kubata chaizvo `capacity` zvinhu pasina kuisazve nzvimbo.
    /// Kana `capacity` iri 0, iyo vector haizogovera.
    ///
    /// Izvo zvakakosha kuti uzive kuti kunyangwe iyo yakadzoserwa vector ine iyo *kugona* yakatsanangurwa, iyo vector ichave ne zero *kureba*.
    ///
    /// Kuti uwane tsananguro yemusiyano uripo pakati pehurefu uye kugona, ona *[Kugona uye kugadziriswazve]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    ///
    /// // vector haina zvinhu, kunyangwe iine simba rezvimwe
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Izvi zvese zvinoitwa pasina kuisazve nzvimbo ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... asi izvi zvinogona kuita kuti vector igadziriswe
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[inline]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> Self {
        Self::with_capacity_in(capacity, Global)
    }

    /// Inogadzira `Vec<T>` yakananga kubva kune yakasvibirira zvinhu zveimwe vector.
    ///
    /// # Safety
    ///
    /// Izvi hazvina kuchengetedzeka zvakanyanya, nekuda kwenhamba yevapindiri vasina kuongororwa:
    ///
    /// * `ptr` inoda kuve yakambogoverwa kuburikidza [`String`]/`Vec<T>`(zvirinani, zvingangoita kunge zvisiri izvo dai zvisiri).
    /// * `T` inoda kuve nehukuru hwakaenzana uye kuenderana seizvo `ptr` yakagoverwa nayo.
    ///   (`T` kuve nekuenderana kwakanyanyisa hakukwani, kuenderana kunonyatsoda kuenzana kuzadzikisa iyo [`dealloc`] inoda kuti ndangariro igovaniswe uye iendeswe nemamiriro akafanana.)
    ///
    /// * `length` inoda kuve shoma kana kuenzana ne `capacity`.
    /// * `capacity` inoda kuve chinzvimbo chakapihwa iyo pointer.
    ///
    /// Kutyora izvi kunogona kukonzera matambudziko sekushatisa zvemukati wedhisheni yedhairekitori.Semuenzaniso iri **kwete** yakachengeteka kuvaka `Vec<u8>` kubva kunongedzera kuenda kuC `char` yakarongedzwa nehurefu `size_t`.
    /// Izvo zvakare hazvina kuchengeteka kuvaka imwe kubva ku `Vec<u16>` uye kureba kwayo, nekuti iyo inogovera ine hanya nezve kuenderana, uye idzi mbiri mhando dzine dzakasiyana dzakasiyana.
    /// Iyo buffer yakapihwa pamwe nekuenderana 2 (ye `u16`), asi mushure mekuichinja kuita `Vec<u8>` inozotenderedzwa nekuenderana 1.
    ///
    /// Iyo muridzi we `ptr` inonyatso kuendeswa ku `Vec<T>` iyo inogona kuzogovana, kuisazve nzvimbo kana kushandura zvirimo mundangariro zvakanongedzerwa kune iye anonongedza paunoda.
    /// Ita shuwa kuti hapana chimwe chinhu chinoshandisa pointer mushure mekufona basa iri.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let v = vec![1, 2, 3];
    ///
    ///     // FIXME Gadziridza izvi kana vec_into_raw_parts yakagadzikana.
    ///     // Dzivirira kumhanya `v`'s muparadzi saka isu tiri mukutonga kwakazara kweichi chikamu.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Dhonza zvikamu zvakasiyana-siyana zvakakosha nezve `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    ///
    /// unsafe {
    ///     // Nyora ndangariro ne4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Isa zvinhu zvese kumashure pamwechete muVec
    ///     let rebuilt = Vec::from_raw_parts(p, len, cap);
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(ptr: *mut T, length: usize, capacity: usize) -> Self {
        unsafe { Self::from_raw_parts_in(ptr, length, capacity, Global) }
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Inogadzira itsva, isina `Vec<T, A>`.
    ///
    /// vector haizogovera kudzamara zvinhu zvasundirwa pairi.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// # #[allow(unused_mut)]
    /// let mut vec: Vec<i32, _> = Vec::new_in(System);
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub const fn new_in(alloc: A) -> Self {
        Vec { buf: RawVec::new_in(alloc), len: 0 }
    }

    /// Inogadzira nyowani, isina chinhu `Vec<T, A>` ine yakatarwa kugona pamwe neakapihwa mugoveri.
    ///
    /// vector ichakwanisa kubata chaizvo `capacity` zvinhu pasina kuisazve nzvimbo.
    /// Kana `capacity` iri 0, iyo vector haizogovera.
    ///
    /// Izvo zvakakosha kuti uzive kuti kunyangwe iyo yakadzoserwa vector ine iyo *kugona* yakatsanangurwa, iyo vector ichave ne zero *kureba*.
    ///
    /// Kuti uwane tsananguro yemusiyano uripo pakati pehurefu uye kugona, ona *[Kugona uye kugadziriswazve]*.
    ///
    /// [Capacity and reallocation]: #capacity-and-reallocation
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut vec = Vec::with_capacity_in(10, System);
    ///
    /// // vector haina zvinhu, kunyangwe iine simba rezvimwe
    /// assert_eq!(vec.len(), 0);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // Izvi zvese zvinoitwa pasina kuisazve nzvimbo ...
    /// for i in 0..10 {
    ///     vec.push(i);
    /// }
    /// assert_eq!(vec.len(), 10);
    /// assert_eq!(vec.capacity(), 10);
    ///
    /// // ... asi izvi zvinogona kuita kuti vector igadziriswe
    /// vec.push(11);
    /// assert_eq!(vec.len(), 11);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn with_capacity_in(capacity: usize, alloc: A) -> Self {
        Vec { buf: RawVec::with_capacity_in(capacity, alloc), len: 0 }
    }

    /// Inogadzira `Vec<T, A>` yakananga kubva kune yakasvibirira zvinhu zveimwe vector.
    ///
    /// # Safety
    ///
    /// Izvi hazvina kuchengetedzeka zvakanyanya, nekuda kwenhamba yevapindiri vasina kuongororwa:
    ///
    /// * `ptr` inoda kuve yakambogoverwa kuburikidza [`String`]/`Vec<T>`(zvirinani, zvingangoita kunge zvisiri izvo dai zvisiri).
    /// * `T` inoda kuve nehukuru hwakaenzana uye kuenderana seizvo `ptr` yakagoverwa nayo.
    ///   (`T` kuve nekuenderana kwakanyanyisa hakukwani, kuenderana kunonyatsoda kuenzana kuzadzikisa iyo [`dealloc`] inoda kuti ndangariro igovaniswe uye iendeswe nemamiriro akafanana.)
    ///
    /// * `length` inoda kuve shoma kana kuenzana ne `capacity`.
    /// * `capacity` inoda kuve chinzvimbo chakapihwa iyo pointer.
    ///
    /// Kutyora izvi kunogona kukonzera matambudziko sekushatisa zvemukati wedhisheni yedhairekitori.Semuenzaniso iri **kwete** yakachengeteka kuvaka `Vec<u8>` kubva kunongedzera kuenda kuC `char` yakarongedzwa nehurefu `size_t`.
    /// Izvo zvakare hazvina kuchengeteka kuvaka imwe kubva ku `Vec<u16>` uye kureba kwayo, nekuti iyo inogovera ine hanya nezve kuenderana, uye idzi mbiri mhando dzine dzakasiyana dzakasiyana.
    /// Iyo buffer yakapihwa pamwe nekuenderana 2 (ye `u16`), asi mushure mekuichinja kuita `Vec<u8>` inozotenderedzwa nekuenderana 1.
    ///
    /// Iyo muridzi we `ptr` inonyatso kuendeswa ku `Vec<T>` iyo inogona kuzogovana, kuisazve nzvimbo kana kushandura zvirimo mundangariro zvakanongedzerwa kune iye anonongedza paunoda.
    /// Ita shuwa kuti hapana chimwe chinhu chinoshandisa pointer mushure mekufona basa iri.
    ///
    /// [`String`]: crate::string::String
    /// [`dealloc`]: crate::alloc::GlobalAlloc::dealloc
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// use std::ptr;
    /// use std::mem;
    ///
    /// let mut v = Vec::with_capacity_in(3, System);
    /// v.push(1);
    /// v.push(2);
    /// v.push(3);
    ///
    ///     // FIXME Gadziridza izvi kana vec_into_raw_parts yakagadzikana.
    ///     // Dzivirira kumhanya `v`'s muparadzi saka isu tiri mukutonga kwakazara kweichi chikamu.
    /////
    /// let mut v = mem::ManuallyDrop::new(v);
    ///
    /// // Dhonza zvikamu zvakasiyana-siyana zvakakosha nezve `v`
    /// let p = v.as_mut_ptr();
    /// let len = v.len();
    /// let cap = v.capacity();
    /// let alloc = v.allocator();
    ///
    /// unsafe {
    ///     // Nyora ndangariro ne4, 5, 6
    ///     for i in 0..len as isize {
    ///         ptr::write(p.offset(i), 4 + i);
    ///     }
    ///
    ///     // Isa zvinhu zvese kumashure pamwechete muVec
    ///     let rebuilt = Vec::from_raw_parts_in(p, len, cap, alloc.clone());
    ///     assert_eq!(rebuilt, [4, 5, 6]);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub unsafe fn from_raw_parts_in(ptr: *mut T, length: usize, capacity: usize, alloc: A) -> Self {
        unsafe { Vec { buf: RawVec::from_raw_parts_in(ptr, capacity, alloc), len: length } }
    }

    /// Inowora `Vec<T>` muzvinhu zvayo zvisvinu.
    ///
    /// Inodzorera pointer mbishi kune data repasi, kureba kwe vector (mune zvinhu), uye iro rakapihwa iro iro data (muzvinhu).
    /// Idzi ndidzo nharo dzakaenzana muhurongwa hwakaenzana sekupokana ku [`from_raw_parts`].
    ///
    /// Mushure mekudaidza iri basa, ari kufona ndiye anoitisa ndangariro yakambotarisirwa ne `Vec`.
    /// Iyo chete nzira yekuita izvi kushandura mbishi mbichana, kureba, uye kugona kudzosera mu `Vec` ine [`from_raw_parts`] basa, ichibvumira muparadzi kuti aite iyo yekuchenesa.
    ///
    ///
    /// [`from_raw_parts`]: Vec::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let v: Vec<i32> = vec![-1, 0, 1];
    ///
    /// let (ptr, len, cap) = v.into_raw_parts();
    ///
    /// let rebuilt = unsafe {
    ///     // Isu tava kukwanisa kuita shanduko kuzvinhu, sekutambanudzira iyo mbishi mbichana kune inoenderana mhando.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts(ptr, len, cap)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut T, usize, usize) {
        let mut me = ManuallyDrop::new(self);
        (me.as_mut_ptr(), me.len(), me.capacity())
    }

    /// Inowora `Vec<T>` muzvinhu zvayo zvisvinu.
    ///
    /// Inodzorera pointer mbishi kune iri pasi data, kureba kwe vector (mune zvinhu), iro rakapihwa iro dhata (mune zvinhu), uye mugove.
    /// Idzi ndidzo nharo dzakaenzana muhurongwa hwakaenzana sekupokana ku [`from_raw_parts_in`].
    ///
    /// Mushure mekudaidza iri basa, ari kufona ndiye anoitisa ndangariro yakambotarisirwa ne `Vec`.
    /// Iyo chete nzira yekuita izvi kushandura mbishi mbichana, kureba, uye kugona kudzosera mu `Vec` ine [`from_raw_parts_in`] basa, ichibvumira muparadzi kuti aite iyo yekuchenesa.
    ///
    ///
    /// [`from_raw_parts_in`]: Vec::from_raw_parts_in
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, vec_into_raw_parts)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut v: Vec<i32, System> = Vec::new_in(System);
    /// v.push(-1);
    /// v.push(0);
    /// v.push(1);
    ///
    /// let (ptr, len, cap, alloc) = v.into_raw_parts_with_alloc();
    ///
    /// let rebuilt = unsafe {
    ///     // Isu tava kukwanisa kuita shanduko kuzvinhu, sekutambanudzira iyo mbishi mbichana kune inoenderana mhando.
    /////
    ///     let ptr = ptr as *mut u32;
    ///
    ///     Vec::from_raw_parts_in(ptr, len, cap, alloc)
    /// };
    /// assert_eq!(rebuilt, [4294967295, 0, 1]);
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts_with_alloc(self) -> (*mut T, usize, usize, A) {
        let mut me = ManuallyDrop::new(self);
        let len = me.len();
        let capacity = me.capacity();
        let ptr = me.as_mut_ptr();
        let alloc = unsafe { ptr::read(me.allocator()) };
        (ptr, len, capacity, alloc)
    }

    /// Inodzorera iyo nhamba yezvinhu iyo vector inogona kubata isina kuisazve nzvimbo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let vec: Vec<i32> = Vec::with_capacity(10);
    /// assert_eq!(vec.capacity(), 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.buf.capacity()
    }

    /// Inochengetera kugona kweinenge `additional` zvimwe zvinhu zvekuiswa mune yakapihwa `Vec<T>`.
    /// Iko kuunganidzira kunogona kuchengetedza imwe nzvimbo kudzivirira kudzoreredzwa patsva.
    /// Mushure mekufona `reserve`, chinzvimbo chichava chakakura kupfuura kana chakaenzana ne `self.len() + additional`.
    /// Haina chainoita kana kugona kwatova kukwana.
    ///
    /// # Panics
    ///
    /// Panics kana iyo nyowani nyowani inopfuura `isize::MAX` byte.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    ///
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.buf.reserve(self.len, additional);
    }

    /// Inochengetedza hushoma hunyanzvi hweiyo chaiyo `additional` zvimwe zvinhu zvekuiswa mune yakapihwa `Vec<T>`.
    ///
    /// Mushure mekufona `reserve_exact`, chinzvimbo chichava chakakura kupfuura kana chakaenzana ne `self.len() + additional`.
    /// Hapana chainoita kana kugona kwacho kwatova kukwana.
    ///
    /// Ziva kuti anogovera anogona kupa iyo yekuunganidza yakawanda nzvimbo kupfuura yainokumbira.
    /// Naizvozvo, kugona hakugone kuvimbwa nako kuti kuve kushoma.
    /// Sarudza `reserve` kana kuiswa kwe future kuri kutarisirwa.
    ///
    /// # Panics
    ///
    /// Panics kana iyo nyowani nyowani ichizadza `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.reserve_exact(10);
    /// assert!(vec.capacity() >= 11);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.buf.reserve_exact(self.len, additional);
    }

    /// Inoedza kuchengetedza kugona kweinenge `additional` zvimwe zvinhu zvekuiswa mune yakapihwa `Vec<T>`.
    /// Iko kuunganidzira kunogona kuchengetedza imwe nzvimbo kudzivirira kudzoreredzwa patsva.
    /// Mushure mekufona `try_reserve`, chinzvimbo chichava chakakura kupfuura kana chakaenzana ne `self.len() + additional`.
    /// Haina chainoita kana kugona kwatova kukwana.
    ///
    /// # Errors
    ///
    /// Kana chinzvimbo chikafashukira, kana iye anogovera akamhan'ara kukundikana, ipapo kukanganisa kunodzorerwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Pre-chengetedza ndangariro, ichibuda kana tisingakwanise
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Iye zvino tinoziva izvi hazvigone OOM pakati pebasa redu rakaoma
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // zvakaoma zvikuru
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve(self.len, additional)
    }

    /// Inoedza kuchengetedza hushoma hunyanzvi hwezvinhu chaizvo `additional` kuti zviiswe mune yakapihwa `Vec<T>`.
    /// Mushure mekufona `try_reserve_exact`, chinzvimbo chichava chakakura kupfuura kana chakaenzana ne `self.len() + additional` kana ichidzosa `Ok(())`.
    ///
    /// Hapana chainoita kana kugona kwacho kwatova kukwana.
    ///
    /// Ziva kuti anogovera anogona kupa iyo yekuunganidza yakawanda nzvimbo kupfuura yainokumbira.
    /// Naizvozvo, kugona hakugone kuvimbwa nako kuti kuve kushoma.
    /// Sarudza `reserve` kana kuiswa kwe future kuri kutarisirwa.
    ///
    /// # Errors
    ///
    /// Kana chinzvimbo chikafashukira, kana iye anogovera akamhan'ara kukundikana, ipapo kukanganisa kunodzorerwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &[u32]) -> Result<Vec<u32>, TryReserveError> {
    ///     let mut output = Vec::new();
    ///
    ///     // Pre-chengetedza ndangariro, ichibuda kana tisingakwanise
    ///     output.try_reserve_exact(data.len())?;
    ///
    ///     // Iye zvino tinoziva izvi hazvigone OOM pakati pebasa redu rakaoma
    ///     output.extend(data.iter().map(|&val| {
    ///         val * 2 + 5 // zvakaoma zvikuru
    ///     }));
    ///
    ///     Ok(output)
    /// }
    /// # process_data(&[1, 2, 3]).expect("why is the test harness OOMing on 12 bytes?");
    /// ```
    ///
    ///
    #[doc(alias = "realloc")]
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.buf.try_reserve_exact(self.len, additional)
    }

    /// Inoderedza kugona kwe vector zvakanyanya sezvinobvira.
    ///
    /// Ichadonhedza pasi padyo sezvinobvira kureba asi mugove anogona achiri kuzivisa iyo vector kuti kune nzvimbo yezvimwe zvishoma zvimwe zvinhu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to_fit();
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        // Iko kugona hakutombopfuure kureba, uye hapana chekuita kana vakaenzana, saka tinogona kudzivirira panic kesi mu `RawVec::shrink_to_fit` nekungodaidza iine hukuru hukuru.
        //
        //
        if self.capacity() > self.len {
            self.buf.shrink_to_fit(self.len);
        }
    }

    /// Inoderedza kugona kwe vector ine bhandi rakadzika.
    ///
    /// Iyo chinzvimbo chinosara chingangoita chakakura seese ari maviri kureba uye kukosha kwakapihwa.
    ///
    ///
    /// Kana iyo yazvino kugona iri pasi peyakaderera muganho, iyi haina-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    /// assert_eq!(vec.capacity(), 10);
    /// vec.shrink_to(4);
    /// assert!(vec.capacity() >= 4);
    /// vec.shrink_to(0);
    /// assert!(vec.capacity() >= 3);
    /// ```
    #[doc(alias = "realloc")]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        if self.capacity() > min_capacity {
            self.buf.shrink_to_fit(cmp::max(self.len, min_capacity));
        }
    }

    /// Inoshandura iyo vector kuita [`Box<[T]>`][owned slice].
    ///
    /// Ziva kuti izvi zvinodonhedza chero yakawandisa kugona.
    ///
    /// [owned slice]: Box
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    ///
    /// let slice = v.into_boxed_slice();
    /// ```
    ///
    /// Chero huremu hwekuwedzera hunobviswa
    ///
    /// ```
    /// let mut vec = Vec::with_capacity(10);
    /// vec.extend([1, 2, 3].iter().cloned());
    ///
    /// assert_eq!(vec.capacity(), 10);
    /// let slice = vec.into_boxed_slice();
    /// assert_eq!(slice.into_vec().capacity(), 3);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_boxed_slice(mut self) -> Box<[T], A> {
        unsafe {
            self.shrink_to_fit();
            let me = ManuallyDrop::new(self);
            let buf = ptr::read(&me.buf);
            let len = me.len();
            buf.into_box(len).assume_init()
        }
    }

    /// Inopfupisa vector, ichichengeta zvinhu zvekutanga zve `len` uye ichidonhedza zvimwe zvese.
    ///
    /// Kana `len` yakakura kudarika iyo vector urefu hwazvino, izvi hazvina zvazvinoita.
    ///
    /// Iyo [`drain`] nzira inogona kutevedzera `truncate`, asi inokonzeresa kuti zvinhu zvakawandisa zvidzorerwe pachinzvimbo chekudonhedzwa.
    ///
    ///
    /// Ziva kuti iyi nzira haina maturo pane yakapihwa masimba e vector.
    ///
    /// # Examples
    ///
    /// Kutora chinhu shanu vector kuita zvinhu zviviri:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// vec.truncate(2);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    /// Hapana truncation inoitika kana `len` yakakura kudarika iyo vector urefu hwazvino:
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(8);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    ///
    /// Truncating kana `len == 0` yakaenzana nekudana iyo [`clear`] nzira.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.truncate(0);
    /// assert_eq!(vec, []);
    /// ```
    ///
    /// [`clear`]: Vec::clear
    /// [`drain`]: Vec::drain
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, len: usize) {
        // Izvi zvakachengeteka nekuti:
        //
        // * chidimbu chakapasirwa ku `drop_in_place` chiri kushanda;iyo `len > self.len` kesi inodzivirira kuumba isiriyo slice, uye
        // * iyo `len` ye vector yakadzikira isati yadaidza `drop_in_place`, zvekuti hapana kukosha kuchadonhedzwa kaviri kuitira kuti `drop_in_place` ive panic kamwe (kana iri panics kaviri, chirongwa ichi chinobvisa).
        //
        //
        //
        unsafe {
            // Note: Ndezvekufunga kuti iyi `>` uye kwete `>=`.
            //       Kuichinjira ku `>=` kune kusashanda zvakanaka kunoitika mune zvimwe zviitiko.
            //       Ona #78884 zvimwe.
            if len > self.len {
                return;
            }
            let remaining_len = self.len - len;
            let s = ptr::slice_from_raw_parts_mut(self.as_mut_ptr().add(len), remaining_len);
            self.len = len;
            ptr::drop_in_place(s);
        }
    }

    /// Inobvisa chidimbu chine iyo vector yose.
    ///
    /// Zvakaenzana ne `&s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Write};
    /// let buffer = vec![1, 2, 3, 5, 8];
    /// io::sink().write(buffer.as_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_slice(&self) -> &[T] {
        self
    }

    /// Inobvisa chidimbu chinoshanduka che vector yese.
    ///
    /// Zvakaenzana ne `&mut s[..]`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::io::{self, Read};
    /// let mut buffer = vec![0; 3];
    /// io::repeat(0b101).read_exact(buffer.as_mut_slice()).unwrap();
    /// ```
    #[inline]
    #[stable(feature = "vec_as_slice", since = "1.7.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        self
    }

    /// Inodzorera pointer mbishi kune iyo vector's buffer.
    ///
    /// Anofona anofanirwa kuona kuti vector inodarika iyo pointer basa iri rinodzoka, kana zvikasadaro inozopedzisira yanongedzera kumarara.
    /// Kugadziridza iyo vector kunogona kukonzera bhafa rayo kuti riitwe patsva, izvo zvinogona zvakare kuita chero zvinongedzo kwariri kusashanda.
    ///
    /// Anofona anofanirwa kuonawo kuti ndangariro inonongedzera (non-transitively) inonongedza haina kumbonyorwa (kunze kwemukati me `UnsafeCell`) ichishandisa ichi pointer kana chero chinongedzo chakatorwa kwachiri.
    /// Kana iwe uchida kuchinjisa zvirimo muchidimbu, shandisa [`as_mut_ptr`].
    ///
    /// # Examples
    ///
    /// ```
    /// let x = vec![1, 2, 4];
    /// let x_ptr = x.as_ptr();
    ///
    /// unsafe {
    ///     for i in 0..x.len() {
    ///         assert_eq!(*x_ptr.add(i), 1 << i);
    ///     }
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Vec::as_mut_ptr
    ///
    ///
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_ptr(&self) -> *const T {
        // Isu tinovharisa nzira yesiki yezita rimwe chete kuti tirege kupfuura `deref`, iyo inogadzira iripakati referenzi.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Inodzorera isina kuchengeteka inogona kuchinjika poindi kune vector's buffer.
    ///
    /// Anofona anofanirwa kuona kuti vector inodarika iyo pointer basa iri rinodzoka, kana zvikasadaro inozopedzisira yanongedzera kumarara.
    ///
    /// Kugadziridza iyo vector kunogona kukonzera bhafa rayo kuti riitwe patsva, izvo zvinogona zvakare kuita chero zvinongedzo kwariri kusashanda.
    ///
    /// # Examples
    ///
    /// ```
    /// // Govera vector yakakura zvakakwana kune zvinhu zvina.
    /// let size = 4;
    /// let mut x: Vec<i32> = Vec::with_capacity(size);
    /// let x_ptr = x.as_mut_ptr();
    ///
    /// // Kutanga zvinhu kuburikidza neyakajeka pointer inonyora, wozoisa urefu.
    /// unsafe {
    ///     for i in 0..size {
    ///         *x_ptr.add(i) = i as i32;
    ///     }
    ///     x.set_len(size);
    /// }
    /// assert_eq!(&*x, &[0, 1, 2, 3]);
    /// ```
    ///
    #[stable(feature = "vec_as_ptr", since = "1.37.0")]
    #[inline]
    pub fn as_mut_ptr(&mut self) -> *mut T {
        // Isu tinovharisa nzira yechidimbu yezita rimwe chete kuti tirege kupfuura `deref_mut`, iyo inogadzira chirevo chepakati.
        //
        let ptr = self.buf.ptr();
        unsafe {
            assume(!ptr.is_null());
        }
        ptr
    }

    /// Inodzorera chirevo kune akaisirwa mugove.
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn allocator(&self) -> &A {
        self.buf.allocator()
    }

    /// Inomanikidza kureba kwe vector kusvika `new_len`.
    ///
    /// Uku kuita kwepasi-chikamu uko kunochengetedza chero cheakajairwa zvinowanzoitika zverudzi.
    /// Kazhinji kushandura kureba kwe vector kunoitwa uchishandisa imwe yeakachengeteka mashandiro panzvimbo, se [`truncate`], [`resize`], [`extend`], kana [`clear`].
    ///
    ///
    /// [`truncate`]: Vec::truncate
    /// [`resize`]: Vec::resize
    /// [`extend`]: Extend::extend
    /// [`clear`]: Vec::clear
    ///
    /// # Safety
    ///
    /// - `new_len` inofanira kunge iri pasi kana kuenzana ne [`capacity()`].
    /// - Zvinhu zviri pa `old_len..new_len` zvinofanirwa kutanga.
    ///
    /// [`capacity()`]: Vec::capacity
    ///
    /// # Examples
    ///
    /// Iyi nzira inogona kubatsira pamamiriro ezvinhu umo iyo vector iri kushanda sechigadziro cheimwe kodhi, kunyanya pamusoro peFFI:
    ///
    /// ```no_run
    /// # #![allow(dead_code)]
    /// # // Aya angori mafupa mashoma emuenzaniso weiyo doc;
    /// # // usashandise izvi senge pokutangira raibhurari chaiyo.
    /// # pub struct StreamWrapper { strm: *mut std::ffi::c_void }
    /// # const Z_OK: i32 = 0;
    /// # extern "C" {
    /// #     fn deflateGetDictionary(
    /// #         strm: *mut std::ffi::c_void,
    /// #         dictionary: *mut u8,
    /// #         dictLength: *mut usize,
    /// #     ) -> i32;
    /// # }
    /// # impl StreamWrapper {
    /// pub fn get_dictionary(&self) -> Option<Vec<u8>> {
    ///     // Neiyo nzira yeFFI nzira, "32768 bytes is always enough".
    ///     let mut dict = Vec::with_capacity(32_768);
    ///     let mut dict_length = 0;
    ///     // Kachengeteka: `deflateGetDictionary` painodzosa `Z_OK`, inobata kuti:
    ///     // 1. `dict_length` zvinhu zvakatangwa.
    ///     // 2.
    ///     // `dict_length` <=chinzvimbo (32_768) chinoita kuti `set_len` ive yakachengeteka kufona.
    ///     unsafe {
    ///         // Ita iyo FFI kufona ...
    ///         let r = deflateGetDictionary(self.strm, dict.as_mut_ptr(), &mut dict_length);
    ///         if r == Z_OK {
    ///             // ... uye wedzera urefu kune izvo zvakatangwa.
    ///             dict.set_len(dict_length);
    ///             Some(dict)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    /// # }
    /// ```
    ///
    /// Nepo muenzaniso unotevera uine mutsindo, pane ndangariro inodonha sezvo iyo yemukati vectors isina kusunungurwa pamberi pekufona kwe `set_len`:
    ///
    /// ```
    /// let mut vec = vec![vec![1, 0, 0],
    ///                    vec![0, 1, 0],
    ///                    vec![0, 0, 1]];
    /// // SAFETY:
    /// // 1. `old_len..0` haina chinhu saka hapana zvinhu zvinofanirwa kutanga.
    /// // 2. `0 <= capacity` inogara yakabata chero `capacity` iri.
    /// unsafe {
    ///     vec.set_len(0);
    /// }
    /// ```
    ///
    /// Kazhinji, apa, mumwe aigona kushandisa [`clear`] pachinzvimbo kuti anyatsodonhedza zvirimo uye nekudaro asingadonhedze ndangariro.
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn set_len(&mut self, new_len: usize) {
        debug_assert!(new_len <= self.capacity());

        self.len = new_len;
    }

    /// Inobvisa chinhu kubva ku vector ndokuchidzorera.
    ///
    /// Chinhu chakabviswa chinotsiviwa nechinhu chekupedzisira che vector.
    ///
    /// Izvi hazvichengetedze kuodha, asi i O(1).
    ///
    /// # Panics
    ///
    /// Panics kana `index` iri kunze kwemiganhu.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec!["foo", "bar", "baz", "qux"];
    ///
    /// assert_eq!(v.swap_remove(1), "bar");
    /// assert_eq!(v, ["foo", "qux", "baz"]);
    ///
    /// assert_eq!(v.swap_remove(0), "foo");
    /// assert_eq!(v, ["baz", "qux"]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn swap_remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("swap_remove index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // Isu tinotsiva self [index] nechinhu chekupedzisira.
            // Ziva kuti kana mabhureki akatarisa pamusoro achibudirira panofanirwa kuve nechinhu chekupedzisira (icho chingave icho [index] pachayo).
            //
            let last = ptr::read(self.as_ptr().add(len - 1));
            let hole = self.as_mut_ptr().add(index);
            self.set_len(len - 1);
            ptr::replace(hole, last)
        }
    }

    /// Inoisa chinhu panzvimbo `index` mukati me vector, ichichinjisa zvinhu zvese mushure mayo kurudyi.
    ///
    ///
    /// # Panics
    ///
    /// Panics kana `index > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.insert(1, 4);
    /// assert_eq!(vec, [1, 4, 2, 3]);
    /// vec.insert(4, 5);
    /// assert_eq!(vec, [1, 4, 2, 3, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, index: usize, element: T) {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("insertion index (is {}) should be <= len (is {})", index, len);
        }

        let len = self.len();
        if index > len {
            assert_failed(index, len);
        }

        // nzvimbo yechinhu chitsva
        if len == self.buf.capacity() {
            self.reserve(1);
        }

        unsafe {
            // isingakanganisi iyo nzvimbo yekuisa iyo nyowani kukosha
            //
            {
                let p = self.as_mut_ptr().add(index);
                // Shift zvese pamusoro kuti uwane nzvimbo.
                // (Kudzokorora iyo `index`th element munzvimbo mbiri dzinoteedzana.)
                ptr::copy(p, p.offset(1), len - index);
                // Nyora iyo mukati, uchinyora pasi yekutanga kopi ye`index`th element.
                //
                ptr::write(p, element);
            }
            self.set_len(len + 1);
        }
    }

    /// Inobvisa uye inodzosera chinhu pachinzvimbo `index` mukati me vector, ichichinjisa zvinhu zvese mushure mayo kuruboshwe.
    ///
    ///
    /// # Panics
    ///
    /// Panics kana `index` iri kunze kwemiganhu.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// assert_eq!(v.remove(1), 2);
    /// assert_eq!(v, [1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, index: usize) -> T {
        #[cold]
        #[inline(never)]
        fn assert_failed(index: usize, len: usize) -> ! {
            panic!("removal index (is {}) should be < len (is {})", index, len);
        }

        let len = self.len();
        if index >= len {
            assert_failed(index, len);
        }
        unsafe {
            // infallible
            let ret;
            {
                // nzvimbo yatiri kutora kubva.
                let ptr = self.as_mut_ptr().add(index);
                // teedzera iyo kunze, zvisina kuchengeteka uine kopi yeiyo kukosha pane iyo stack uye mu vector panguva imwe chete.
                //
                ret = ptr::read(ptr);

                // Shift zvese pasi kuti uzadze iyo nzvimbo.
                ptr::copy(ptr.offset(1), ptr, len - index - 1);
            }
            self.set_len(len - 1);
            ret
        }
    }

    /// Inochengetedza chete zvinhu zvinotsanangurwa neyakafanotaurwa.
    ///
    /// Mune mamwe mazwi, bvisa zvese zvinhu `e` zvekuti `f(&e)` inodzosera `false`.
    /// Iyi nzira inoshanda munzvimbo, ichishanyira chinhu chimwe nechimwe chaizvo kamwe muhurongwa hwepakutanga, uye inochengetedza kurongeka kwezvinhu zvakachengetedzwa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.retain(|&x| x % 2 == 0);
    /// assert_eq!(vec, [2, 4]);
    /// ```
    ///
    /// Nekuti zvinhu zvinoshanyirwa chaizvo kamwechete muhurongwa hwepakutanga, nyika yekunze inogona kushandiswa kusarudza kuti ndezvipi zvinhu zvekuchengetedza.
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3, 4, 5];
    /// let keep = [false, true, true, false, true];
    /// let mut iter = keep.iter();
    /// vec.retain(|_| *iter.next().unwrap());
    /// assert_eq!(vec, [2, 3, 5]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> bool,
    {
        let original_len = self.len();
        // Dzivisa kudonha kwakapetwa kana donhwe rikasaitwa, nekuti isu tingaite maburi panguva yekuita.
        //
        unsafe { self.set_len(0) };

        // Vec: [Kept, Kept, Hole, Hole, Hole, Hole, Unchecked, Unchecked]
        //      | <-yakagadziriswa len-> |^-inotevera kutarisa
        //                  | <-yakadzimwa cnt-> |
        //      | <-chepakutanga_len-> |Yakachengetwa: Elements iyo inoratidzira inodzoka ichokwadi pa.
        //
        // Hole: Kufambisa kana kudonhedza element slot.
        // Kumisikidzwa: Kumisikidzwa zvinhu zvinoshanda.
        //
        // Uyu wekudzivirira unozokumbirwa kana chirevo kana `drop` yechinhu ichivhunduka.
        // Inochinjisa zvisina kumisikidzwa zvinhu kuvhara maburi uye `set_len` kune chaiyo urefu.
        // Mune zviitiko apo predicate uye `drop` isingambovhunduke, ichagadziriswa kunze.
        struct BackshiftOnDrop<'a, T, A: Allocator> {
            v: &'a mut Vec<T, A>,
            processed_len: usize,
            deleted_cnt: usize,
            original_len: usize,
        }

        impl<T, A: Allocator> Drop for BackshiftOnDrop<'_, T, A> {
            fn drop(&mut self) {
                if self.deleted_cnt > 0 {
                    // KUCHENGETEKA: Kutevera zvinhu zvisina kumakwa zvinofanirwa kunge zvichishanda nekuti isu hatimbozvibata.
                    unsafe {
                        ptr::copy(
                            self.v.as_ptr().add(self.processed_len),
                            self.v.as_mut_ptr().add(self.processed_len - self.deleted_cnt),
                            self.original_len - self.processed_len,
                        );
                    }
                }
                // Kachengeteka: Mushure mekuzadza maburi, zvese zvinhu zviri mune inoenderana memory.
                unsafe {
                    self.v.set_len(self.original_len - self.deleted_cnt);
                }
            }
        }

        let mut g = BackshiftOnDrop { v: self, processed_len: 0, deleted_cnt: 0, original_len };

        while g.processed_len < original_len {
            // Kachengeteka: Chinhu chisina kutariswa chinofanira kunge chiri chechokwadi.
            let cur = unsafe { &mut *g.v.as_mut_ptr().add(g.processed_len) };
            if !f(cur) {
                // Tungamira kumberi kuti udzivise kudonha kaviri kana `drop_in_place` yavhunduka.
                g.processed_len += 1;
                g.deleted_cnt += 1;
                // Kachengeteka: Hatife takabata chinhu ichi zvakare mushure mekudonha.
                unsafe { ptr::drop_in_place(cur) };
                // Isu tatoenda kumberi pakaunda.
                continue;
            }
            if g.deleted_cnt > 0 {
                // Kachengeteka: `deleted_cnt`> 0, saka gomba slot harifanirwe kusangana nechazvino chinhu.
                // Isu tinoshandisa kopi yekufamba, uye usazombobata chinhu ichi zvakare.
                unsafe {
                    let hole_slot = g.v.as_mut_ptr().add(g.processed_len - g.deleted_cnt);
                    ptr::copy_nonoverlapping(cur, hole_slot, 1);
                }
            }
            g.processed_len += 1;
        }

        // Zvese zvinhu zvinogadziriswa.Izvi zvinogona kukwidziridzwa ku `set_len` neLLVM.
        drop(g);
    }

    /// Inobvisa zvese kunze kwekutanga kwezvinhu zvinoteedzana mu vector izvo zvinogadzirisa kukiyi imwechete.
    ///
    ///
    /// Kana iyo vector yakarongedzwa, izvi zvinobvisa zvese zvakapetwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![10, 20, 21, 30, 20];
    ///
    /// vec.dedup_by_key(|i| *i / 10);
    ///
    /// assert_eq!(vec, [10, 20, 30, 20]);
    /// ```
    #[stable(feature = "dedup_by", since = "1.16.0")]
    #[inline]
    pub fn dedup_by_key<F, K>(&mut self, mut key: F)
    where
        F: FnMut(&mut T) -> K,
        K: PartialEq,
    {
        self.dedup_by(|a, b| key(a) == key(b))
    }

    /// Inobvisa zvese asi yekutanga yezvinhu zvinoteedzana mu vector inogutsa yakapihwa kuenzana hukama.
    ///
    /// Basa re `same_bucket` rakapasiswa mareferenzi kuzvinhu zviviri kubva ku vector uye rinofanira kuona kana zvinhu zvacho zvichienzanisa zvakaenzana.
    /// Izvo zvinhu zvinopfuudzwa zvakapesana zvakarongeka kubva kuodha yavo muchidimbu, saka kana `same_bucket(a, b)` ichidzosa `true`, `a` inobviswa.
    ///
    ///
    /// Kana iyo vector yakarongedzwa, izvi zvinobvisa zvese zvakapetwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["foo", "bar", "Bar", "baz", "bar"];
    ///
    /// vec.dedup_by(|a, b| a.eq_ignore_ascii_case(b));
    ///
    /// assert_eq!(vec, ["foo", "bar", "baz", "bar"]);
    /// ```
    ///
    #[stable(feature = "dedup_by", since = "1.16.0")]
    pub fn dedup_by<F>(&mut self, mut same_bucket: F)
    where
        F: FnMut(&mut T, &mut T) -> bool,
    {
        let len = self.len();
        if len <= 1 {
            return;
        }

        /* INVARIANT: vec.len() > read >= write > write-1 >= 0 */
        struct FillGapOnDrop<'a, T, A: core::alloc::Allocator> {
            /* Offset of the element we want to check if it is duplicate */
            read: usize,

            /* Offset of the place where we want to place the non-duplicate
             * when we find it. */
            write: usize,

            /* The Vec that would need correction if `same_bucket` panicked */
            vec: &'a mut Vec<T, A>,
        }

        impl<'a, T, A: core::alloc::Allocator> Drop for FillGapOnDrop<'a, T, A> {
            fn drop(&mut self) {
                /* This code gets executed when `same_bucket` panics */

                /* SAFETY: invariant guarantees that `read - write`
                 * and `len - read` never overflow and that the copy is always
                 * in-bounds. */
                unsafe {
                    let ptr = self.vec.as_mut_ptr();
                    let len = self.vec.len();

                    /* How many items were left when `same_bucket` paniced.
                     * Basically vec[read..].len() */
                    let items_left = len.wrapping_sub(self.read);

                    /* Pointer to first item in vec[write..write+items_left] slice */
                    let dropped_ptr = ptr.add(self.write);
                    /* Pointer to first item in vec[read..] slice */
                    let valid_ptr = ptr.add(self.read);

                    /* Copy `vec[read..]` to `vec[write..write+items_left]`.
                     * The slices can overlap, so `copy_nonoverlapping` cannot be used */
                    ptr::copy(valid_ptr, dropped_ptr, items_left);

                    /* How many items have been already dropped
                     * Basically vec[read..write].len() */
                    let dropped = self.read.wrapping_sub(self.write);

                    self.vec.set_len(len - dropped);
                }
            }
        }

        let mut gap = FillGapOnDrop { read: 1, write: 1, vec: self };
        let ptr = gap.vec.as_mut_ptr();

        /* Drop items while going through Vec, it should be more efficient than
         * doing slice partition_dedup + truncate */

        /* SAFETY: Because of the invariant, read_ptr, prev_ptr and write_ptr
         * are always in-bounds and read_ptr never aliases prev_ptr */
        unsafe {
            while gap.read < len {
                let read_ptr = ptr.add(gap.read);
                let prev_ptr = ptr.add(gap.write.wrapping_sub(1));

                if same_bucket(&mut *read_ptr, &mut *prev_ptr) {
                    /* We have found duplicate, drop it in-place */
                    ptr::drop_in_place(read_ptr);
                } else {
                    let write_ptr = ptr.add(gap.write);

                    /* Because `read_ptr` can be equal to `write_ptr`, we either
                     * have to use `copy` or conditional `copy_nonoverlapping`.
                     * Looks like the first option is faster. */
                    ptr::copy(read_ptr, write_ptr, 1);

                    /* We have filled that place, so go further */
                    gap.write += 1;
                }

                gap.read += 1;
            }

            /* Technically we could let `gap` clean up with its Drop, but
             * when `same_bucket` is guaranteed to not panic, this bloats a little
             * the codegen, so we just do it manually */
            gap.vec.set_len(gap.write);
            mem::forget(gap);
        }
    }

    /// Inoisa chinhu kuseri kweunganidzwa.
    ///
    /// # Panics
    ///
    /// Panics kana iyo nyowani nyowani inopfuura `isize::MAX` byte.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2];
    /// vec.push(3);
    /// assert_eq!(vec, [1, 2, 3]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, value: T) {
        // Izvi zvichaita panic kana kubvisa kana tikazopa> isize::MAX byte kana kana iyo urefu yekuwedzera ichizadza yemhando dzakakura saizi.
        //
        if self.len == self.buf.capacity() {
            self.reserve(1);
        }
        unsafe {
            let end = self.as_mut_ptr().add(self.len);
            ptr::write(end, value);
            self.len += 1;
        }
    }

    /// Inobvisa chinhu chekupedzisira kubva ku vector ndokuchidzorera, kana [`None`] kana isina chinhu.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// assert_eq!(vec.pop(), Some(3));
    /// assert_eq!(vec, [1, 2]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<T> {
        if self.len == 0 {
            None
        } else {
            unsafe {
                self.len -= 1;
                Some(ptr::read(self.as_ptr().add(self.len())))
            }
        }
    }

    /// Inofambisa zvese zvinhu zve `other` kuita `Self`, ichisiya `other` isina chinhu.
    ///
    /// # Panics
    ///
    /// Panics kana iyo nhamba yezvinhu mu vector inopfuura `usize`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let mut vec2 = vec![4, 5, 6];
    /// vec.append(&mut vec2);
    /// assert_eq!(vec, [1, 2, 3, 4, 5, 6]);
    /// assert_eq!(vec2, []);
    /// ```
    #[inline]
    #[stable(feature = "append", since = "1.4.0")]
    pub fn append(&mut self, other: &mut Self) {
        unsafe {
            self.append_elements(other.as_slice() as _);
            other.set_len(0);
        }
    }

    /// Inoisa zvinhu ku `Self` kubva kune imwe buffer.
    #[inline]
    unsafe fn append_elements(&mut self, other: *const [T]) {
        let count = unsafe { (*other).len() };
        self.reserve(count);
        let len = self.len();
        unsafe { ptr::copy_nonoverlapping(other as *const T, self.as_mut_ptr().add(len), count) };
        self.len += count;
    }

    /// Inogadzira inodhonza iterator iyo inobvisa yakatarwa renji mu vector uye inoburitsa zvakabviswa zvinhu.
    ///
    /// Kana iyo iterator **yava** yakadonhedzwa, zvese zvinhu zviri mumhando zvinobviswa kubva ku vector, kunyangwe iyo iterator isina kunyatsodyiwa.
    /// Kana iyo iterator **isiri** yakadonhedzwa (iine [`mem::forget`] semuenzaniso), hazvizivikanwe kuti mangani zvinhu zvinobviswa.
    ///
    /// # Panics
    ///
    /// Panics kana pekutangira pakakura kupfuura pekupedzisira kana pekupedzisira pakakwirira kupfuura pakureba kwe vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let u: Vec<_> = v.drain(1..).collect();
    /// assert_eq!(v, &[1]);
    /// assert_eq!(u, &[2, 3]);
    ///
    /// // Rizere renji rinobvisa iyo vector
    /// v.drain(..);
    /// assert_eq!(v, &[]);
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_, T, A>
    where
        R: RangeBounds<usize>,
    {
        // Kuchengetedzwa kwendangariro
        //
        // Kana iyo Drain yakatanga kugadzirwa, inopfupisa kureba kweiyo sosi vector kuona kuti hapana asina kuvhurwa kana kufambiswa-kubva kuzvinhu anowanikwa zvachose kana muparadzi we Drain asingazombomhanya.
        //
        //
        // Drain ichaita ptr::read kunze kwemaitiro ekubvisa.
        // Kana wapedza, muswe wakasara wevc unoteedzerwa kumashure kuvhara gomba, uye iyo vector kureba inodzoserwa kuhurefu hutsva.
        //
        //
        //
        let len = self.len();
        let Range { start, end } = slice::range(range, ..len);

        unsafe {
            // seta self.vec urefu kuti utange, kuve wakachengeteka kana Drain ikaburitswa
            self.set_len(start);
            // Shandisa iyo inokwereta muIterMut kuratidza maitiro ekukwereta eiyo Drain iterator (senge &mut T).
            //
            let range_slice = slice::from_raw_parts_mut(self.as_mut_ptr().add(start), end - start);
            Drain {
                tail_start: end,
                tail_len: len - end,
                iter: range_slice.iter(),
                vec: NonNull::from(self),
            }
        }
    }

    /// Inochenesa vector, ichibvisa kukosha kwese.
    ///
    /// Ziva kuti iyi nzira haina maturo pane yakapihwa masimba e vector.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    ///
    /// v.clear();
    ///
    /// assert!(v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.truncate(0)
    }

    /// Inodzorera iyo nhamba yezvinhu mu vector, inonziwo 'length' yayo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = vec![1, 2, 3];
    /// assert_eq!(a.len(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.len
    }

    /// Inodzorera `true` kana iyo vector isina zvinhu.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = Vec::new();
    /// assert!(v.is_empty());
    ///
    /// v.push(1);
    /// assert!(!v.is_empty());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Inopatsanura kuunganidzwa kuita maviri pane yakapihwa index.
    ///
    /// Inodzorera ichangobva kupihwa vector iine zvinhu zviri mu `[at, len)`.
    /// Mushure mekufona, iyo yekutanga vector inosara iine zvinhu `[0, at)` pamwe neyakare simba rayo risina kuchinjika.
    ///
    ///
    /// # Panics
    ///
    /// Panics kana `at > len`.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// let vec2 = vec.split_off(1);
    /// assert_eq!(vec, [1]);
    /// assert_eq!(vec2, [2, 3]);
    /// ```
    #[inline]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    #[stable(feature = "split_off", since = "1.4.0")]
    pub fn split_off(&mut self, at: usize) -> Self
    where
        A: Clone,
    {
        #[cold]
        #[inline(never)]
        fn assert_failed(at: usize, len: usize) -> ! {
            panic!("`at` split index (is {}) should be <= len (is {})", at, len);
        }

        if at > self.len() {
            assert_failed(at, self.len());
        }

        if at == 0 {
            // iyo vector nyowani inogona kutora iyo yekutanga buffer uye kudzivirira iyo kopi
            return mem::replace(
                self,
                Vec::with_capacity_in(self.capacity(), self.allocator().clone()),
            );
        }

        let other_len = self.len - at;
        let mut other = Vec::with_capacity_in(other_len, self.allocator().clone());

        // Asina kuchengeteka `set_len` uye teedzera zvinhu ku `other`.
        unsafe {
            self.set_len(at);
            other.set_len(other_len);

            ptr::copy_nonoverlapping(self.as_ptr().add(at), other.as_mut_ptr(), other.len());
        }
        other
    }

    /// Inodzosera iyo `Vec` mu-nzvimbo kuitira kuti `len` ienzane ne `new_len`.
    ///
    /// Kana `new_len` yakakura kudarika `len`, iyo `Vec` inowedzerwa nemusiyano, neyakawedzera slot yakazadzwa nemhedzisiro yekufona kuvhara `f`.
    ///
    /// Iko kukosha kwekudzoka kubva ku `f` kunozopedzisira kuri mu `Vec` nenzira yavakagadzirwa.
    ///
    /// Kana `new_len` iri pasi pe `len`, iyo `Vec` inongotorwa.
    ///
    /// Iyi nzira inoshandisa kuvhara kugadzira hutsva hutsva pane yega Push.Kana iwe uchida [`Clone`] yakapihwa kukosha, shandisa [`Vec::resize`].
    /// Kana iwe uchida kushandisa iyo [`Default`] trait kuburitsa hunhu, unogona kupfuura [`Default::default`] seye nharo yechipiri.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 3];
    /// vec.resize_with(5, Default::default);
    /// assert_eq!(vec, [1, 2, 3, 0, 0]);
    ///
    /// let mut vec = vec![];
    /// let mut p = 1;
    /// vec.resize_with(4, || { p *= 2; p });
    /// assert_eq!(vec, [2, 4, 8, 16]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "vec_resize_with", since = "1.33.0")]
    pub fn resize_with<F>(&mut self, new_len: usize, f: F)
    where
        F: FnMut() -> T,
    {
        let len = self.len();
        if new_len > len {
            self.extend_with(new_len - len, ExtendFunc(f));
        } else {
            self.truncate(new_len);
        }
    }

    /// Inoshandisa uye inodonhedza iyo `Vec`, ichidzosera inogona kuchinjika kune izvo zvirimo, `&'a mut [T]`.
    /// Ziva kuti mhando `T` inofanirwa kurarama kupfuura yakasarudzwa yehupenyu `'a`.
    /// Kana iyo mhando iine chete static mareferenzi, kana pasina zvachose, saka izvi zvinogona kusarudzwa kuve `'static`.
    ///
    /// Iri basa rakafanana neiyo [`leak`][Box::leak] basa pa [`Box`] kunze kwekunge pasina imwe nzira yekudzosa iyo yakavhurika ndangariro.
    ///
    ///
    /// Iri basa rinonyanya kukosha kune data rinorarama kune yakasara yehupenyu hwepurogiramu.
    /// Kudonhedza chirevo chakadzoserwa kunokonzera kuyeuka kwendangariro.
    ///
    /// # Examples
    ///
    /// Kushandisa kuri nyore:
    ///
    /// ```
    /// let x = vec![1, 2, 3];
    /// let static_ref: &'static mut [usize] = x.leak();
    /// static_ref[0] += 1;
    /// assert_eq!(static_ref, &[2, 2, 3]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_leak", since = "1.47.0")]
    #[inline]
    pub fn leak<'a>(self) -> &'a mut [T]
    where
        A: 'a,
    {
        Box::leak(self.into_boxed_slice())
    }

    /// Inodzorera yakasara yekumira simba ye vector sechidimbu che `MaybeUninit<T>`.
    ///
    /// Slice yakadzoserwa inogona kushandiswa kuzadza vector ine data (semuenzaniso
    /// nekuverenga kubva pafaira) usati wamaka iyo data seyakatangwa uchishandisa nzira ye [`set_len`].
    ///
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_spare_capacity, maybe_uninit_extra)]
    ///
    /// // Govera vector yakakura zvakakwana kune gumi zvinhu.
    /// let mut v = Vec::with_capacity(10);
    ///
    /// // Zadza zvinhu zvitatu zvekutanga.
    /// let uninit = v.spare_capacity_mut();
    /// uninit[0].write(0);
    /// uninit[1].write(1);
    /// uninit[2].write(2);
    ///
    /// // Maka zvimisikidzo zvitatu zvekutanga zve vector sekutanga.
    /// unsafe {
    ///     v.set_len(3);
    /// }
    ///
    /// assert_eq!(&v, &[0, 1, 2]);
    /// ```
    ///
    #[unstable(feature = "vec_spare_capacity", issue = "75017")]
    #[inline]
    pub fn spare_capacity_mut(&mut self) -> &mut [MaybeUninit<T>] {
        // Note:
        // Iyi nzira haina kuitiswa maererano ne `split_at_spare_mut`, kudzivirira kusashanda kwemanongedzera kune iyo buffer.
        //
        unsafe {
            slice::from_raw_parts_mut(
                self.as_mut_ptr().add(self.len) as *mut MaybeUninit<T>,
                self.buf.capacity() - self.len,
            )
        }
    }

    /// Inodzorera vector zvemukati sechidimbu che `T`, pamwe neakasara masimba e vector sechidimbu che `MaybeUninit<T>`.
    ///
    /// Iyo yakadzoserwa spare slice inogona kushandiswa kuzadza vector ine data (semuenzaniso nekuverenga kubva kune faira) usati wamaka data sekutanga kushandisa nzira ye [`set_len`].
    ///
    /// [`set_len`]: Vec::set_len
    ///
    /// Ziva kuti iyi iri yepasi-chikamu API, iyo inofanirwa kushandiswa nekutarisira kwezvinangwa zvekugadzirisa.
    /// Kana iwe uchida kunongedza data kune `Vec` unogona kushandisa [`push`], [`extend`], [`extend_from_slice`], [`extend_from_within`], [`insert`], [`append`], [`resize`] kana [`resize_with`], zvinoenderana nezvinodiwa zvako chaizvo.
    ///
    ///
    /// [`push`]: Vec::push
    /// [`extend`]: Vec::extend
    /// [`extend_from_slice`]: Vec::extend_from_slice
    /// [`extend_from_within`]: Vec::extend_from_within
    /// [`insert`]: Vec::insert
    /// [`append`]: Vec::append
    /// [`resize`]: Vec::resize
    /// [`resize_with`]: Vec::resize_with
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_split_at_spare, maybe_uninit_extra)]
    ///
    /// let mut v = vec![1, 1, 2];
    ///
    /// // Chengetedza imwe nzvimbo yakakura zvakakwana zvinhu gumi.
    /// v.reserve(10);
    ///
    /// let (init, uninit) = v.split_at_spare_mut();
    /// let sum = init.iter().copied().sum::<u32>();
    ///
    /// // Zadza zvinhu zvinotevera zvina.
    /// uninit[0].write(sum);
    /// uninit[1].write(sum * 2);
    /// uninit[2].write(sum * 3);
    /// uninit[3].write(sum * 4);
    ///
    /// // Maka zvimiro zvina zve vector sekutanga.
    /// unsafe {
    ///     let len = v.len();
    ///     v.set_len(len + 4);
    /// }
    ///
    /// assert_eq!(&v, &[1, 1, 2, 4, 8, 12, 16]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_split_at_spare", issue = "81944")]
    #[inline]
    pub fn split_at_spare_mut(&mut self) -> (&mut [T], &mut [MaybeUninit<T>]) {
        // SAFETY:
        // - len haina hanya uye saka haina kumbochinja
        let (init, spare, _) = unsafe { self.split_at_spare_mut_with_len() };
        (init, spare)
    }

    /// Kudzivirirwa: kuchinja kwakadzorerwa .2 (&mut usize) kunoonekwa kwakafanana nekudana `.set_len(_)`.
    ///
    /// Iyi nzira inoshandiswa kuve yakasarudzika kuwana kune ese vec zvikamu kamwechete mu `extend_from_within`.
    unsafe fn split_at_spare_mut_with_len(
        &mut self,
    ) -> (&mut [T], &mut [MaybeUninit<T>], &mut usize) {
        let Range { start: ptr, end: spare_ptr } = self.as_mut_ptr_range();
        let spare_ptr = spare_ptr.cast::<MaybeUninit<T>>();
        let spare_len = self.buf.capacity() - self.len;

        // SAFETY:
        // - `ptr` inovimbiswa kuve inoshanda kune `len` zvinhu
        // - `spare_ptr` iri kunongedzera chinhu chimwe kupfuura yapfuura bhaudhi, saka haiwirirane ne `initialized`
        unsafe {
            let initialized = slice::from_raw_parts_mut(ptr, self.len);
            let spare = slice::from_raw_parts_mut(spare_ptr, spare_len);

            (initialized, spare, &mut self.len)
        }
    }
}

impl<T: Clone, A: Allocator> Vec<T, A> {
    /// Inodzosera iyo `Vec` mu-nzvimbo kuitira kuti `len` ienzane ne `new_len`.
    ///
    /// Kana `new_len` yakakura kudarika `len`, iyo `Vec` inowedzerwa nemusiyano, neyakawedzera slot yakazadzwa ne `value`.
    ///
    /// Kana `new_len` iri pasi pe `len`, iyo `Vec` inongotorwa.
    ///
    /// Iyi nzira inoda `T` kuti ishandise [`Clone`], kuti ugone kuenzanisa kukosha kwakapasiswa.
    /// Kana iwe uchida kuwanda kuchinjika (kana uchida kuvimba ne [`Default`] panzvimbo ye [`Clone`]), shandisa [`Vec::resize_with`].
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec!["hello"];
    /// vec.resize(3, "world");
    /// assert_eq!(vec, ["hello", "world", "world"]);
    ///
    /// let mut vec = vec![1, 2, 3, 4];
    /// vec.resize(2, 0);
    /// assert_eq!(vec, [1, 2]);
    /// ```
    ///
    ///
    #[stable(feature = "vec_resize", since = "1.5.0")]
    pub fn resize(&mut self, new_len: usize, value: T) {
        let len = self.len();

        if new_len > len {
            self.extend_with(new_len - len, ExtendElement(value))
        } else {
            self.truncate(new_len);
        }
    }

    /// Clones uye inoisa zvese zvinhu muchidimbu kune iyo `Vec`.
    ///
    /// Iterates pamusoro pechitsetse `other`, inonamira chinhu chimwe nechimwe, uye wozoishongedza kune iyi `Vec`.
    /// Iyo `other` vector inoyambuka mu-odha.
    ///
    /// Ziva kuti basa iri rakaenzana ne [`extend`] kunze kwekunge yakasarudzika kushanda nezvidimbu panzvimbo.
    ///
    /// Kana uye kana Rust ikawana hunyanzvi basa iri rinogona kudzikiswa (asi richiripo).
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1];
    /// vec.extend_from_slice(&[2, 3, 4]);
    /// assert_eq!(vec, [1, 2, 3, 4]);
    /// ```
    ///
    /// [`extend`]: Vec::extend
    ///
    #[stable(feature = "vec_extend_from_slice", since = "1.6.0")]
    pub fn extend_from_slice(&mut self, other: &[T]) {
        self.spec_extend(other.iter())
    }

    /// Inoteedzera zvinhu kubva ku `src` renji kusvika kumagumo e vector.
    ///
    /// ## Examples
    ///
    /// ```
    /// #![feature(vec_extend_from_within)]
    ///
    /// let mut vec = vec![0, 1, 2, 3, 4];
    ///
    /// vec.extend_from_within(2..);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4]);
    ///
    /// vec.extend_from_within(..2);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1]);
    ///
    /// vec.extend_from_within(4..8);
    /// assert_eq!(vec, [0, 1, 2, 3, 4, 2, 3, 4, 0, 1, 4, 2, 3, 4]);
    /// ```
    #[unstable(feature = "vec_extend_from_within", issue = "81656")]
    pub fn extend_from_within<R>(&mut self, src: R)
    where
        R: RangeBounds<usize>,
    {
        let range = slice::range(src, ..self.len());
        self.reserve(range.len());

        // SAFETY:
        // - `slice::range` inovimbisa kuti iyo yakapihwa renji inoshanda kune indexing pachako
        unsafe {
            self.spec_extend_from_within(range);
        }
    }
}

// Iyi kodhi inogadzira `extend_with_{element,default}`.
trait ExtendWith<T> {
    fn next(&mut self) -> T;
    fn last(self) -> T;
}

struct ExtendElement<T>(T);
impl<T: Clone> ExtendWith<T> for ExtendElement<T> {
    fn next(&mut self) -> T {
        self.0.clone()
    }
    fn last(self) -> T {
        self.0
    }
}

struct ExtendDefault;
impl<T: Default> ExtendWith<T> for ExtendDefault {
    fn next(&mut self) -> T {
        Default::default()
    }
    fn last(self) -> T {
        Default::default()
    }
}

struct ExtendFunc<F>(F);
impl<T, F: FnMut() -> T> ExtendWith<T> for ExtendFunc<F> {
    fn next(&mut self) -> T {
        (self.0)()
    }
    fn last(mut self) -> T {
        (self.0)()
    }
}

impl<T, A: Allocator> Vec<T, A> {
    /// Wedzera vector ne `n` tsika, uchishandisa jenareta yakapihwa.
    fn extend_with<E: ExtendWith<T>>(&mut self, n: usize, mut value: E) {
        self.reserve(n);

        unsafe {
            let mut ptr = self.as_mut_ptr().add(self.len());
            // Shandisa SetLenOnDrop kushanda uchitenderedza bug uko compiler ingangotadza kuona chitoro kuburikidza ne `ptr` kuburikidza ne self.set_len() haisi ma alias.
            //
            //
            let mut local_len = SetLenOnDrop::new(&mut self.len);

            // Nyora zvese zvinhu kunze kwekupedzisira
            for _ in 1..n {
                ptr::write(ptr, value.next());
                ptr = ptr.offset(1);
                // Wedzera kureba mudanho rega rega kuitira next() panics
                local_len.increment_len(1);
            }

            if n > 0 {
                // Tinogona kunyora chinhu chekupedzisira zvakananga tisina kuumbana zvisina basa
                ptr::write(ptr, value.last());
                local_len.increment_len(1);
            }

            // len yakaiswa necope guard
        }
    }
}

impl<T: PartialEq, A: Allocator> Vec<T, A> {
    /// Inobvisa zvakateedzana zvakadzokororwa zvinhu mu vector zvinoenderana ne [`PartialEq`] trait kuitiswa.
    ///
    ///
    /// Kana iyo vector yakarongedzwa, izvi zvinobvisa zvese zvakapetwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut vec = vec![1, 2, 2, 3, 2];
    ///
    /// vec.dedup();
    ///
    /// assert_eq!(vec, [1, 2, 3, 2]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn dedup(&mut self) {
        self.dedup_by(|a, b| a == b)
    }
}

////////////////////////////////////////////////////////////////////////////////
// Maitiro emukati nemabasa
////////////////////////////////////////////////////////////////////////////////

#[doc(hidden)]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_elem<T: Clone>(elem: T, n: usize) -> Vec<T> {
    <T as SpecFromElem>::from_elem(elem, n, Global)
}

#[doc(hidden)]
#[unstable(feature = "allocator_api", issue = "32838")]
pub fn from_elem_in<T: Clone, A: Allocator>(elem: T, n: usize, alloc: A) -> Vec<T, A> {
    <T as SpecFromElem>::from_elem(elem, n, alloc)
}

trait ExtendFromWithinSpec {
    /// # Safety
    ///
    /// - `src` inoda kuve inoshanda index
    /// - `self.capacity() - self.len()` inofanira kunge iri `>= src.len()`
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>);
}

impl<T: Clone, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    default unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        // SAFETY:
        // - len inowedzerwa chete mushure mekutanga zvinhu
        let (this, spare, len) = unsafe { self.split_at_spare_mut_with_len() };

        // SAFETY:
        // - caller guaratees kuti src ndeye inoshanda index
        let to_clone = unsafe { this.get_unchecked(src) };

        to_clone
            .iter()
            .cloned()
            .zip(spare.iter_mut())
            .map(|(src, dst)| dst.write(src))
            // Note:
            // - Chinhu chakangotangwa ne `MaybeUninit::write`, saka zvakanaka kuti uwedzere len
            // - len inowedzerwa mushure mechinhu chimwe nechimwe kudzivirira kubvaruka (ona nyaya #82533)
            .for_each(|_| *len += 1);
    }
}

impl<T: Copy, A: Allocator> ExtendFromWithinSpec for Vec<T, A> {
    unsafe fn spec_extend_from_within(&mut self, src: Range<usize>) {
        let count = src.len();
        {
            let (init, spare) = self.split_at_spare_mut();

            // SAFETY:
            // - caller guaratees iyo `src` indekisi inoshanda
            let source = unsafe { init.get_unchecked(src) };

            // SAFETY:
            // - Anongedzo ese ari maviri akagadzirwa kubva kune yakasarudzika slice mareferenzi (`&mut [_]`) saka iwo anoshanda uye haapindirane.
            //
            // - Zvinhu zvacho ndezvekuti: Kopa saka zvakanaka kuti uzviteedzere, pasina kuita chero chinhu nemhando yekutanga
            // - `count` yakaenzana nelen ye `source`, saka sosi inoshanda kune `count` inoverengwa
            // - `.reserve(count)` inovimbisa kuti `spare.len() >= count` saka spare inoshanda kune `count` inonyora
            //
            //
            //
            unsafe { ptr::copy_nonoverlapping(source.as_ptr(), spare.as_mut_ptr() as _, count) };
        }

        // SAFETY:
        // - Zvinhu zvacho zvakangotanga ne `copy_nonoverlapping`
        self.len += count;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Zvakajairika trait kuita kweVec
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::Deref for Vec<T, A> {
    type Target = [T];

    fn deref(&self) -> &[T] {
        unsafe { slice::from_raw_parts(self.as_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> ops::DerefMut for Vec<T, A> {
    fn deref_mut(&mut self) -> &mut [T] {
        unsafe { slice::from_raw_parts_mut(self.as_mut_ptr(), self.len) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Vec<T, A> {
    #[cfg(not(test))]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        <[T]>::to_vec_in(&**self, alloc)
    }

    // HACK(japaric): ne cfg(test) iyo yakasarudzika `[T]::to_vec` nzira, iyo inodikanwa kune iyi nzira tsananguro, haiwanikwe.
    // Panzvimbo iyoyo shandisa iyo `slice::to_vec` basa iro rinongowanikwa chete ne cfg(test) NB ona iyo slice::hack module mu slice.rs kuti uwane rumwe ruzivo
    //
    //
    #[cfg(test)]
    fn clone(&self) -> Self {
        let alloc = self.allocator().clone();
        crate::slice::to_vec(&**self, alloc)
    }

    fn clone_from(&mut self, other: &Self) {
        // donhedza chero chinhu chisingazonyorwa
        self.truncate(other.len());

        // self.len <= other.len nekuda kwetruncate iri pamusoro, saka zvimedu pano zvinogara zviri-mumiganhu.
        //
        let (init, tail) = other.split_at(self.len());

        // shandisa zvekare zvirimo allocations/resources.
        self.clone_from_slice(init);
        self.extend_from_slice(tail);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Hash, A: Allocator> Hash for Vec<T, A> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        Hash::hash(&**self, state)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> Index<I> for Vec<T, A> {
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &Self::Output {
        Index::index(&**self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "vector indices are of type `usize` or ranges of `usize`",
    label = "vector indices are of type `usize` or ranges of `usize`"
)]
impl<T, I: SliceIndex<[T]>, A: Allocator> IndexMut<I> for Vec<T, A> {
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut Self::Output {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> FromIterator<T> for Vec<T> {
    #[inline]
    fn from_iter<I: IntoIterator<Item = T>>(iter: I) -> Vec<T> {
        <Self as SpecFromIter<T, I::IntoIter>>::from_iter(iter.into_iter())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> IntoIterator for Vec<T, A> {
    type Item = T;
    type IntoIter = IntoIter<T, A>;

    /// Inogadzira inodya iterator, ndokuti, iyo inoburitsa kukosha kwese kubva mu vector (kubva pakutanga kusvika kumagumo).
    /// vector haigone kushandiswa mushure mekufona izvi.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = vec!["a".to_string(), "b".to_string()];
    /// for s in v.into_iter() {
    ///     // s ine mhando String, kwete &String
    ///     println!("{}", s);
    /// }
    /// ```
    ///
    #[inline]
    fn into_iter(self) -> IntoIter<T, A> {
        unsafe {
            let mut me = ManuallyDrop::new(self);
            let alloc = ptr::read(me.allocator());
            let begin = me.as_mut_ptr();
            let end = if mem::size_of::<T>() == 0 {
                arith_offset(begin as *const i8, me.len() as isize) as *const T
            } else {
                begin.add(me.len()) as *const T
            };
            let cap = me.buf.capacity();
            IntoIter {
                buf: NonNull::new_unchecked(begin),
                phantom: PhantomData,
                cap,
                alloc,
                ptr: begin,
                end,
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a Vec<T, A> {
    type Item = &'a T;
    type IntoIter = slice::Iter<'a, T>;

    fn into_iter(self) -> slice::Iter<'a, T> {
        self.iter()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, T, A: Allocator> IntoIterator for &'a mut Vec<T, A> {
    type Item = &'a mut T;
    type IntoIter = slice::IterMut<'a, T>;

    fn into_iter(self) -> slice::IterMut<'a, T> {
        self.iter_mut()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> Extend<T> for Vec<T, A> {
    #[inline]
    fn extend<I: IntoIterator<Item = T>>(&mut self, iter: I) {
        <Self as SpecExtend<T, I::IntoIter>>::spec_extend(self, iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, item: T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

impl<T, A: Allocator> Vec<T, A> {
    // leaf nzira iyo dzakasiyana siyana dze SpecFrom/SpecExtend dzinotumira pavanenge vasina mamwe magadziriso ekushandisa
    //
    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        // Iyi ndiyo mamiriro kune akajairwa iterator.
        //
        // Iri basa rinofanirwa kunge rakaenzana nehunhu hwe:
        //
        //      yechinhu chiri iterator {
        //          self.push(item);
        //      }
        while let Some(element) = iterator.next() {
            let len = self.len();
            if len == self.capacity() {
                let (lower, _) = iterator.size_hint();
                self.reserve(lower.saturating_add(1));
            }
            unsafe {
                ptr::write(self.as_mut_ptr().add(len), element);
                // NB haigoni kufashukira sezvo isu taizofanira kugovera nzvimbo yekero
                self.set_len(len + 1);
            }
        }
    }

    /// Inogadzira yekutsikisa iterator iyo inotsiva iyo yakatarwa renji mu vector neakapihwa `replace_with` iterator uye inoburitsa zvakabviswa zvinhu.
    ///
    /// `replace_with` haifanirwe kunge ihurefu hwakaenzana ne `range`.
    ///
    /// `range` inobviswa kunyangwe iyo iterator isina kudyiwa kusvika kumagumo.
    ///
    /// Hazvizivikanwe kuti mangani zvinhu zvinobviswa kubva ku vector kana iyo `Splice` kukosha kwaburitswa.
    ///
    /// Iyo yekuisa iterator `replace_with` inongodyiwa chete kana iyo `Splice` kukosha kwadonhedzwa.
    ///
    /// Izvi zvakanaka kana:
    ///
    /// * Iyo muswe (zvinhu mu vector mushure me `range`) haina chinhu,
    /// * kana `replace_with` inobereka mashoma kana akaenzana zvinhu pane`refu`hurefu
    /// * kana iyo yepazasi yakasungwa yayo `size_hint()` iri chaiyo.
    ///
    /// Zvikasadaro, vector yenguva pfupi inogoverwa uye muswe unofambiswa kaviri.
    ///
    /// # Panics
    ///
    /// Panics kana pekutangira pakakura kupfuura pekupedzisira kana pekupedzisira pakakwirira kupfuura pakureba kwe vector.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = vec![1, 2, 3];
    /// let new = [7, 8];
    /// let u: Vec<_> = v.splice(..2, new.iter().cloned()).collect();
    /// assert_eq!(v, &[7, 8, 3]);
    /// assert_eq!(u, &[1, 2]);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "vec_splice", since = "1.21.0")]
    pub fn splice<R, I>(&mut self, range: R, replace_with: I) -> Splice<'_, I::IntoIter, A>
    where
        R: RangeBounds<usize>,
        I: IntoIterator<Item = T>,
    {
        Splice { drain: self.drain(range), replace_with: replace_with.into_iter() }
    }

    /// Inogadzira iterator iyo inoshandisa kuvhara kuona kana chinhu chinofanira kubviswa.
    ///
    /// Kana iko kuvhara kuchidzoka kwechokwadi, saka chinhu chinobviswa uye chakapihwa.
    /// Kana iko kuvhara kuchidzoka kwenhema, chinhu chacho chinosara chiri mu vector uye hachizoburitswa neiyo iterator.
    ///
    /// Kushandisa nzira iyi kwakaenzana nekodhi inotevera:
    ///
    /// ```
    /// # let some_predicate = |x: &mut i32| { *x == 2 || *x == 3 || *x == 6 };
    /// # let mut vec = vec![1, 2, 3, 4, 5, 6];
    /// let mut i = 0;
    /// while i != vec.len() {
    ///     if some_predicate(&mut vec[i]) {
    ///         let val = vec.remove(i);
    ///         // kodhi yako pano
    ///     } else {
    ///         i += 1;
    ///     }
    /// }
    ///
    /// # assert_eq!(vec, vec![1, 4, 5]);
    /// ```
    ///
    /// Asi `drain_filter` iri nyore kushandisa.
    /// `drain_filter` inoshanda zvakare, nekuti inogona kudzosera kumashure zvinhu zvemudungwe muzhinji.
    ///
    /// Ziva kuti `drain_filter` zvakare inokutendera iwe kuchinjisa chinhu chega chega mukuvhara firita, zvisinei nekuti unosarudza kuichengeta kana kuibvisa.
    ///
    ///
    /// # Examples
    ///
    /// Kutsemura rondedzero mumanheru uye kusanzwisisika, kushandisa zvakare chikamu chekutanga:
    ///
    /// ```
    /// #![feature(drain_filter)]
    /// let mut numbers = vec![1, 2, 3, 4, 5, 6, 8, 9, 11, 13, 14, 15];
    ///
    /// let evens = numbers.drain_filter(|x| *x % 2 == 0).collect::<Vec<_>>();
    /// let odds = numbers;
    ///
    /// assert_eq!(evens, vec![2, 4, 6, 8, 14]);
    /// assert_eq!(odds, vec![1, 3, 5, 9, 11, 13, 15]);
    /// ```
    ///
    #[unstable(feature = "drain_filter", reason = "recently added", issue = "43244")]
    pub fn drain_filter<F>(&mut self, filter: F) -> DrainFilter<'_, T, F, A>
    where
        F: FnMut(&mut T) -> bool,
    {
        let old_len = self.len();

        // Chenjerera isu kuti tirege kubuda (leak amplification)
        unsafe {
            self.set_len(0);
        }

        DrainFilter { vec: self, idx: 0, del: 0, old_len, pred: filter, panic_flag: false }
    }
}

/// Wedzera kuitisa iyo inoteedzera zvinhu kunze kwezvirevo usati wasundidzira ivo kuVec.
///
/// Uku kumisikidza kwakasarudzika kune slice iterators, iko iko iko inoshandisa [`copy_from_slice`] kukwidziridza chidimbu chese kamwechete.
///
///
/// [`copy_from_slice`]: slice::copy_from_slice
#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a, T: Copy + 'a, A: Allocator + 'a> Extend<&'a T> for Vec<T, A> {
    fn extend<I: IntoIterator<Item = &'a T>>(&mut self, iter: I) {
        self.spec_extend(iter.into_iter())
    }

    #[inline]
    fn extend_one(&mut self, &item: &'a T) {
        self.push(item);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

/// Inoshandisa kuenzanisa kwe vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: PartialOrd, A: Allocator> PartialOrd for Vec<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Eq, A: Allocator> Eq for Vec<T, A> {}

/// Inoshandisa kurongedza kwe vectors, [lexicographically](core::cmp::Ord#lexicographical-comparison).
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Ord, A: Allocator> Ord for Vec<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T, A: Allocator> Drop for Vec<T, A> {
    fn drop(&mut self) {
        unsafe {
            // shandisa donhwe re [T] shandisa slice yakasvibirira kureva zvinhu zve vector senge isina kusimba inodiwa mhando;
            //
            // inogona kudzivirira mibvunzo yechokwadi mune dzimwe nguva
            ptr::drop_in_place(ptr::slice_from_raw_parts_mut(self.as_mut_ptr(), self.len))
        }
        // RawVec inobata dhizaini
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Vec<T> {
    /// Inogadzira isina `Vec<T>`.
    fn default() -> Vec<T> {
        Vec::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug, A: Allocator> fmt::Debug for Vec<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<Vec<T, A>> for Vec<T, A> {
    fn as_ref(&self) -> &Vec<T, A> {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<Vec<T, A>> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut Vec<T, A> {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T, A: Allocator> AsRef<[T]> for Vec<T, A> {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "vec_as_mut", since = "1.5.0")]
impl<T, A: Allocator> AsMut<[T]> for Vec<T, A> {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> From<&[T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &[T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &[T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_mut", since = "1.19.0")]
impl<T: Clone> From<&mut [T]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: &mut [T]) -> Vec<T> {
        s.to_vec()
    }
    #[cfg(test)]
    fn from(s: &mut [T]) -> Vec<T> {
        crate::slice::to_vec(s, Global)
    }
}

#[stable(feature = "vec_from_array", since = "1.44.0")]
impl<T, const N: usize> From<[T; N]> for Vec<T> {
    #[cfg(not(test))]
    fn from(s: [T; N]) -> Vec<T> {
        <[T]>::into_vec(box s)
    }
    #[cfg(test)]
    fn from(s: [T; N]) -> Vec<T> {
        crate::slice::into_vec(box s)
    }
}

#[stable(feature = "vec_from_cow_slice", since = "1.14.0")]
impl<'a, T> From<Cow<'a, [T]>> for Vec<T>
where
    [T]: ToOwned<Owned = Vec<T>>,
{
    fn from(s: Cow<'a, [T]>) -> Vec<T> {
        s.into_owned()
    }
}

// note: test Inodhonza mu libstd, iyo inokanganisa zvikanganiso pano
#[cfg(not(test))]
#[stable(feature = "vec_from_box", since = "1.18.0")]
impl<T, A: Allocator> From<Box<[T], A>> for Vec<T, A> {
    fn from(s: Box<[T], A>) -> Self {
        let len = s.len();
        Self { buf: RawVec::from_box(s), len }
    }
}

// note: test Inodhonza mu libstd, iyo inokanganisa zvikanganiso pano
#[cfg(not(test))]
#[stable(feature = "box_from_vec", since = "1.20.0")]
impl<T, A: Allocator> From<Vec<T, A>> for Box<[T], A> {
    fn from(v: Vec<T, A>) -> Self {
        v.into_boxed_slice()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for Vec<u8> {
    fn from(s: &str) -> Vec<u8> {
        From::from(s.as_bytes())
    }
}

#[stable(feature = "array_try_from_vec", since = "1.48.0")]
impl<T, A: Allocator, const N: usize> TryFrom<Vec<T, A>> for [T; N] {
    type Error = Vec<T, A>;

    /// Inowana zvese zvirimo mu `Vec<T>` seyakarongeka, kana saizi yayo ichinyatsoenderana neiya yeakakumbirwa rondedzero.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::convert::TryInto;
    /// assert_eq!(vec![1, 2, 3].try_into(), Ok([1, 2, 3]));
    /// assert_eq!(<Vec<i32>>::new().try_into(), Ok([]));
    /// ```
    ///
    /// Kana iyo urefu isingaenderane, iyo yekuisa inodzoka mu `Err`:
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let r: Result<[i32; 4], _> = (0..10).collect::<Vec<_>>().try_into();
    /// assert_eq!(r, Err(vec![0, 1, 2, 3, 4, 5, 6, 7, 8, 9]));
    /// ```
    ///
    /// Kana iwe wakanaka nekungowana chete chivakiso che `Vec<T>`, unogona kufonera [`.truncate(N)`](Vec::truncate) kutanga.
    ///
    /// ```
    /// use std::convert::TryInto;
    /// let mut v = String::from("hello world").into_bytes();
    /// v.sort();
    /// v.truncate(2);
    /// let [a, b]: [_; 2] = v.try_into().unwrap();
    /// assert_eq!(a, b' ');
    /// assert_eq!(b, b'd');
    /// ```
    fn try_from(mut vec: Vec<T, A>) -> Result<[T; N], Vec<T, A>> {
        if vec.len() != N {
            return Err(vec);
        }

        // Kachengeteka: `.set_len(0)` inogara iine mutsindo.
        unsafe { vec.set_len(0) };

        // Kachengeteka: A `Vec's's pointer inogara yakaenderana zvakanaka, uye
        // kuenderana kweakarongeka zvinodiwa zvakafanana nezvinhu.
        // Takatarisa kare kuti tine zvinhu zvakakwana.
        // Zvinhu zvacho hazvizodonhedze zvakapetwa sezvo `set_len` ichiudza iyo `Vec` kuti isazvidonhedzewo.
        //
        let array = unsafe { ptr::read(vec.as_ptr() as *const [T; N]) };
        Ok(array)
    }
}