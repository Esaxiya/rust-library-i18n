// Gadza kureba kwevec kana iyo `SetLenOnDrop` kukosha kwabuda pachiyero.
//
// Pfungwa ndeyekuti: Iyo kureba munda muSetLenOnDrop musiyano wemuno uyo optimizer ichaona haina alias nechero zvitoro kuburikidza neVec's data pointer.
// Uku ndiko kushanda kwe alias ongororo nyaya #32155
//
pub(super) struct SetLenOnDrop<'a> {
    len: &'a mut usize,
    local_len: usize,
}

impl<'a> SetLenOnDrop<'a> {
    #[inline]
    pub(super) fn new(len: &'a mut usize) -> Self {
        SetLenOnDrop { local_len: *len, len }
    }

    #[inline]
    pub(super) fn increment_len(&mut self, increment: usize) {
        self.local_len += increment;
    }
}

impl Drop for SetLenOnDrop<'_> {
    #[inline]
    fn drop(&mut self) {
        *self.len = self.local_len;
    }
}