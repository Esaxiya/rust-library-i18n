use core::mem::ManuallyDrop;
use core::ptr::{self};
use core::slice::{self};

use super::{IntoIter, SpecExtend, SpecFromIterNested, Vec};

/// Nyanzvi trait yakashandiswa ye Vec::from_iter
///
/// ## Girafu yekutumira:
///
/// ```text
/// +-------------+
/// |FromIterator |
/// +-+-----------+
///   |
///   v
/// +-+-------------------------------+  +---------------------+
/// |SpecFromIter                  +---->+SpecFromIterNested   |
/// |where I:                      |  |  |where I:             |
/// |  Iterator (default)----------+  |  |  Iterator (default) |
/// |  vec::IntoIter               |  |  |  TrustedLen         |
/// |  SourceIterMarker---fallback-+  |  |                     |
/// |  slice::Iter                    |  |                     |
/// |  Iterator<Item = &Clone>        |  +---------------------+
/// +---------------------------------+
/// ```
pub(super) trait SpecFromIter<T, I> {
    fn from_iter(iter: I) -> Self;
}

impl<T, I> SpecFromIter<T, I> for Vec<T>
where
    I: Iterator<Item = T>,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIterNested::from_iter(iterator)
    }
}

impl<T> SpecFromIter<T, IntoIter<T>> for Vec<T> {
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // Mhosva yakajairika iri kupfuudza vector muchiita basa iro rinobva rangounganidza mu vector.
        // Tinogona kupfupisa wedunhu izvi kana IntoIter isati yafambiswa zvachose.
        // Kana yave kumberi Tinogona zvakare kushandisa ndangariro uye kuendesa iyo data kumberi.
        // Asi isu tinongozviita chete kana iyo inoguma Vec yaisazove neakawanda mashandisiro emagetsi pane kuigadzira kuburikidza neyakajairika KubvaIterator kuitiswa kwaizoita.
        //
        // Kukamurwa ikoko hakusi kudikanwa zvakanyanya semaitiro eVec ekugovana asina kuziviswa nemaune.
        // Asi iri sarudzo inochengetedza.
        //
        let has_advanced = iterator.buf.as_ptr() as *const _ != iterator.ptr;
        if !has_advanced || iterator.len() >= iterator.cap / 2 {
            unsafe {
                let it = ManuallyDrop::new(iterator);
                if has_advanced {
                    ptr::copy(it.ptr, it.buf.as_ptr(), it.len());
                }
                return Vec::from_raw_parts(it.buf.as_ptr(), it.len(), it.cap);
            }
        }

        let mut vec = Vec::new();
        // inofanirwa kuendesa ku spec_extend() kubvira extend() pachayo nhume kune spec_from yeisina maVec
        //
        vec.spec_extend(iterator);
        vec
    }
}

impl<'a, T: 'a, I> SpecFromIter<&'a T, I> for Vec<T>
where
    I: Iterator<Item = &'a T>,
    T: Clone,
{
    default fn from_iter(iterator: I) -> Self {
        SpecFromIter::from_iter(iterator.cloned())
    }
}

// Izvi zvinoshandisa `iterator.as_slice().to_vec()` sezvo spec_extend inofanirwa kutora mamwe matanho kufunga nezvesimba rekupedzisira + kureba uye nokudaro ita basa rakawanda.
// `to_vec()` inogovera zvakananga huwandu chaihwo uye inoizadza chaizvo.
//
//
impl<'a, T: 'a + Clone> SpecFromIter<&'a T, slice::Iter<'a, T>> for Vec<T> {
    #[cfg(not(test))]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        iterator.as_slice().to_vec()
    }

    // HACK(japaric): ne cfg(test) iyo yakasarudzika `[T]::to_vec` nzira, iyo inodikanwa kune iyi nzira tsananguro, haiwanikwe.
    // Panzvimbo iyoyo shandisa iyo `slice::to_vec` basa iro rinongowanikwa chete ne cfg(test) NB ona iyo slice::hack module mu slice.rs kuti uwane rumwe ruzivo
    //
    //
    #[cfg(test)]
    fn from_iter(iterator: slice::Iter<'a, T>) -> Self {
        crate::slice::to_vec(iterator.as_slice(), crate::alloc::Global)
    }
}