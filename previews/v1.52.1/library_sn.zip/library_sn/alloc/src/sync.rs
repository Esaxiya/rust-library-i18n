#![stable(feature = "rust1", since = "1.0.0")]

//! Thread-safe reference-kuverenga zvinongedzo.
//!
//! Ona iyo [`Arc<T>`][Arc] zvinyorwa kuti uwane rumwe ruzivo.

use core::any::Any;
use core::borrow;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::hint;
use core::intrinsics::abort;
use core::iter;
use core::marker::{PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;
use core::sync::atomic;
use core::sync::atomic::Ordering::{Acquire, Relaxed, Release, SeqCst};

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::rc::is_dangling;
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

/// Iyo yakapfava muganho pane huwandu hwezvinongedzo zvinogona kuitwa kune `Arc`.
///
/// Kuenda pamusoro pemuganhu uyu kuchabvisa chirongwa chako (kunyangwe zvisiri hazvo) ku _exactly_ `MAX_REFCOUNT + 1` mareferensi.
///
const MAX_REFCOUNT: usize = (isize::MAX) as usize;

#[cfg(not(sanitize = "thread"))]
macro_rules! acquire {
    ($x:expr) => {
        atomic::fence(Acquire)
    };
}

// ThreadSanitizer haitsigire memory fenzi.
// Kuti udzivise manyepo enhema mune Arc/Weak kuitisa mashandisiro shandisa maatomu mitoro yekuwiriranisa panzvimbo.
//
#[cfg(sanitize = "thread")]
macro_rules! acquire {
    ($x:expr) => {
        $x.load(Acquire)
    };
}

/// Iyo tambo-yakachengeteka referensi-yekuverenga pointer.'Arc' inomirira 'Atomically Referensi Yakaverengwa'.
///
/// Rudzi `Arc<T>` runopa muridzi akagovana weukoshi hwerudzi `T`, yakapihwa mumurwi.Inodenha [`clone`][clone] pa `Arc` inogadzira nyowani `Arc` semuenzaniso, iyo inonongedzera kune kugoverwa kumwechete pamurwi sosi `Arc`, uku ichiwedzera kuverenga kuverenga.
/// Kana yekupedzisira `Arc` pointer kune yakapihwa mugove yaparadzwa, kukosha kwakachengetwa mune iwo mugove (unowanzo kunzi "inner value") inodonhedzwa.
///
/// Yakagovaniswa mareferenzi mu Rust isingabvumire shanduko nekukanganisa, uye `Arc` haisi iyo yakasarudzika: haugone kuwana kazhinji chinongedzo chechimwe chinhu mukati me `Arc`.Kana iwe uchida kuchinjika kuburikidza ne `Arc`, shandisa [`Mutex`][mutex], [`RwLock`][rwlock], kana imwe yemhando dze [`Atomic`][atomic].
///
/// ## Thread Kuchengetedza
///
/// Kusiyana ne [`Rc<T>`], `Arc<T>` inoshandisa maatomu mashandisirwo ayo ekuverenga kuverenga.Izvi zvinoreva kuti yakachengeteka-tambo.Izvo zvinokanganisa ndezvekuti maatomu mashandiro anodhura kupfuura zvakajairwa ndangariro kuwana.Kana usiri kugovera mareferensi-akaverengerwa mugove pakati peshinda, funga kushandisa [`Rc<T>`] pamusoro wepasi.
/// [`Rc<T>`] ndeye yakachengeteka default, nekuti iyo compiler inobata chero kuyedza kutumira [`Rc<T>`] pakati tambo.
/// Nekudaro, raibhurari inogona kusarudza `Arc<T>` kuitira kuti ipe vatengi vemaraibhurari mukana wekuchinja.
///
/// `Arc<T>` ichaita [`Send`] uye [`Sync`] sekureba iyo `T` inoshandisa [`Send`] uye [`Sync`].
/// Nei usingakwanise kuisa isiri-tambo-yakachengeteka mhando `T` mune `Arc<T>` kuti iite tambo-yakachengeteka?Izvi zvinogona kunge zvichirwisa-intuitive pakutanga: mushure mezvose, haisi iyo poindi ye `Arc<T>` tambo chengetedzo?Iko kiyi ndeiyi: `Arc<T>` inoita kuti tambo ive yakachengeteka kuve neakawanda muridzi wedhata imwe chete, asi haina kuwedzera tambo kuchengetedzeka kune yayo data.
///
/// Funga nezve `Arc <` [`RefCell<T>`]`>`.
/// [`RefCell<T>`] haisi [`Sync`], uye kana `Arc<T>` yaigara iri [`Send`], `Arc <` [`RefCell<T>`]`>`zvingave zvakadaro.
/// Asi ipapo isu tichava nedambudziko:
/// [`RefCell<T>`] haina tambo yakachengeteka;inocherekedza iyo inokweretesa kuverenga uchishandisa isiri-maatomu mashandiro.
///
/// Mukupedzisira, izvi zvinoreva kuti ungangoda kubatanidza `Arc<T>` neimwe mhando ye [`std::sync`] mhando, kazhinji [`Mutex<T>`][mutex].
///
/// ## Kuputsa macircuit ne `Weak`
///
/// Iyo [`downgrade`][downgrade] nzira inogona kushandiswa kugadzira isiri-muridzi [`Weak`] pointer.A [`Weak`] pointer inogona kuva [`kusimudzira`][kusimudzira] d kusvika pa `Arc`, asi izvi zvinodzosera [`None`] kana kukosha kwakachengetwa mumugove kwatodonhedzwa.
/// Mune mamwe mazwi, `Weak` zvinongedzo hazvichengetedze kukosha mukati mechipo chiri chipenyu;zvisinei, ivo *vanoita* chengetedza kugoverwa (chitoro chekutsigira kukosha) kuchiri kurarama.
///
/// Kutenderera pakati pe `Arc` zvinongedzo hakuzombotamisirwa.
/// Neichi chikonzero, [`Weak`] inoshandiswa kupwanya macircule.Semuenzaniso, muti unogona kuve wakasimba `Arc` zvinongedzo kubva kumubereki node kuenda kuvana, uye [`Weak`] zvinongedzo kubva kuvana vadzokera kuvabereki vavo.
///
/// # Kuumba mareferensi
///
/// Kugadzira chirevo chitsva kubva kunongedzo-yakaverengwa pointer kunoitwa uchishandisa iyo `Clone` trait yakaitwa ye [`Arc<T>`][Arc] uye [`Weak<T>`][Weak].
///
/// ```
/// use std::sync::Arc;
/// let foo = Arc::new(vec![1.0, 2.0, 3.0]);
/// // Aya ma syntaxes pazasi akaenzana.
/// let a = foo.clone();
/// let b = Arc::clone(&foo);
/// // a, b, uye foo ese maArcs anonongedzera kunzvimbo imwechete yekurangarira
/// ```
///
/// ## `Deref` behavior
///
/// `Arc<T>` otomatiki anotarisa ku `T` (kuburikidza ne [`Deref`][deref] trait), kuti ugone kudaidza nzira dze`T` pakukosha kwerudzi `Arc<T>`.Kuti udzivise kupokana kwezita nemaitiro aT, nzira dze `Arc<T>` pachadzo dzakabatana mabasa, anonzi kushandisa [fully qualified syntax]:
///
/// ```
/// use std::sync::Arc;
///
/// let my_arc = Arc::new(());
/// Arc::downgrade(&my_arc);
/// ```
///
/// `Nzvimbo<T>kumisikidza kwe traits senge `Clone` inogona kudaidzwa zvakare ichishandisa zvakakwana syntax.
/// Vamwe vanhu vanosarudza kushandisa syntax yakakwana, nepo vamwe vachida kushandisa syntax yekufona.
///
/// ```
/// use std::sync::Arc;
///
/// let arc = Arc::new(());
/// // Maitiro-kufona syntax
/// let arc2 = arc.clone();
/// // Yakakwana syntax
/// let arc3 = Arc::clone(&arc);
/// ```
///
/// [`Weak<T>`][Weak] haina auto-dereferesi kune `T`, nekuti iyo yemukati kukosha inogona kunge yatodonhedzwa.
///
/// [`Rc<T>`]: crate::rc::Rc
/// [clone]: Clone::clone
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [atomic]: core::sync::atomic
/// [`Send`]: core::marker::Send
/// [`Sync`]: core::marker::Sync
/// [deref]: core::ops::Deref
/// [downgrade]: Arc::downgrade
/// [upgrade]: Weak::upgrade
/// [`RefCell<T>`]: core::cell::RefCell
/// [`std::sync`]: ../../std/sync/index.html
/// [`Arc::clone(&from)`]: Arc::clone
/// [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
///
/// # Examples
///
/// Kugovera imwe isingachinjiki data pakati tambo:
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
// Ziva kuti isu **hatisi** kumhanya nemiedzo iyi pano.
// Vagadziri ve windows vanowana kusanyanya kufara kana tambo ikapfuura tambo huru ichibva yabuda panguva imwe chete (chimwe chinhu chakavharika) saka isu tinongodzivirira izvi zvachose nekusamhanyisa bvunzo idzi.
//
//
/// ```no_run
/// use std::sync::Arc;
/// use std::thread;
///
/// let five = Arc::new(5);
///
/// for _ in 0..10 {
///     let five = Arc::clone(&five);
///
///     thread::spawn(move || {
///         println!("{:?}", five);
///     });
/// }
/// ```
///
/// Kugovana inoshanduka [`AtomicUsize`]:
///
/// [`AtomicUsize`]: core::sync::atomic::AtomicUsize
///
/// ```no_run
/// use std::sync::Arc;
/// use std::sync::atomic::{AtomicUsize, Ordering};
/// use std::thread;
///
/// let val = Arc::new(AtomicUsize::new(5));
///
/// for _ in 0..10 {
///     let val = Arc::clone(&val);
///
///     thread::spawn(move || {
///         let v = val.fetch_add(1, Ordering::SeqCst);
///         println!("{:?}", v);
///     });
/// }
/// ```
///
/// Ona iyo [`rc` documentation][rc_examples] yemimwe mienzaniso yekuverenga kuverenga mune zvese.
///
///
/// [rc_examples]: crate::rc#examples
#[cfg_attr(not(test), rustc_diagnostic_item = "Arc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Arc<T: ?Sized> {
    ptr: NonNull<ArcInner<T>>,
    phantom: PhantomData<ArcInner<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Arc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Arc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Arc<U>> for Arc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Arc<U>> for Arc<T> {}

impl<T: ?Sized> Arc<T> {
    fn from_inner(ptr: NonNull<ArcInner<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut ArcInner<T>) -> Self {
        unsafe { Self::from_inner(NonNull::new_unchecked(ptr)) }
    }
}

/// `Weak` iri vhezheni ye [`Arc`] inobata isiri-yekunongedzera kune yakachengetedzwa kupihwa.
/// Mugove unowanikwa nekudana [`upgrade`] pane `Weak` pointer, iyo inodzosera [`Sarudzo`]`<<[`Arc`]`<T>> `.
///
/// Sezvo chirevo che `Weak` chisingatarise kuve muridzi, hazvizodzivise kukosha kwakachengetwa mumugove kubva pakudonhedzwa, uye `Weak` pachayo haipe vimbiso nezvekukosha kuchiripo.
///
/// Saka inogona kudzoka [`None`] kana [`kusimudzira`] d.
/// Ziva zvisinei hazvo kuti `Weak` rejisiti *inoita* kudzivirira kugovera iko pachako (chitoro chekutsigira) kubva mukuendeswa.
///
/// A `Weak` pointer inobatsira kuchengetedza chirevo chenguva pfupi kune kugoverwa kunoitwa ne [`Arc`] pasina kudzivirira kukosha kwayo kwemukati kubva pakudonhedzwa.
/// Iyo zvakare inoshandiswa kudzivirira denderedzwa mareferenzi pakati pe [`Arc`] zvinongedzo, sezvo kuwirirana kuva neyako mareferenzi kwaisazombobvumira chero [`Arc`] kudonhedzwa.
/// Semuenzaniso, muti unogona kuve wakasimba [`Arc`] zvinongedzo kubva kumubereki node kuenda kuvana, uye `Weak` zvinongedzo kubva kuvana vadzokera kuvabereki vavo.
///
/// Iyo chaiyo nzira yekuwana `Weak` pointer ndeyekufonera [`Arc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
#[stable(feature = "arc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Iyi i `NonNull` kubvumidza kukwidziridza saizi yerudzi urwu mune enums, asi hazvisi hazvo chinongedzo chakakodzera.
    //
    // `Weak::new` inoisa izvi ku `usize::MAX` kuti isazoda kugovera nzvimbo pamurwi.
    // Icho hachisi kukosha chinongedzo chaicho chichava nacho nekuti RcBox ine kuenderana kanenge 2.
    // Izvi zvinokwanisika chete kana `T: Sized`;unsized `T` haina kumbobvira yadzika.
    //
    ptr: NonNull<ArcInner<T>>,
}

#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Send for Weak<T> {}
#[stable(feature = "arc_weak", since = "1.4.0")]
unsafe impl<T: ?Sized + Sync + Send> Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

// Iyi i repr(C) kusvika future-proof inopesana neinogona kuita munda-kugadzirisa zvekare, izvo zvinokanganisa neimwe yakachengeteka [into|from]_raw() yemhando dzinopfuudzwa dzemukati.
//
//
#[repr(C)]
struct ArcInner<T: ?Sized> {
    strong: atomic::AtomicUsize,

    // iyo kukosha usize::MAX inoshanda semutumwa kwenguva pfupi "locking" kugona kukwidziridza mapoinzi asina kusimba kana kudzikisira akasimba;izvi zvinoshandiswa kudzivirira marudzi mu `make_mut` uye `get_mut`.
    //
    //
    weak: atomic::AtomicUsize,

    data: T,
}

unsafe impl<T: ?Sized + Sync + Send> Send for ArcInner<T> {}
unsafe impl<T: ?Sized + Sync + Send> Sync for ArcInner<T> {}

impl<T> Arc<T> {
    /// Inovaka `Arc<T>` nyowani.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(data: T) -> Arc<T> {
        // Tanga iyo isina kusimba pointer kuverenga se1 inova iyo isina poindi pointer inobatwa neese akasimba anonongedza (kinda), ona std/rc.rs kune rumwe ruzivo
        //
        let x: Box<_> = box ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        };
        Self::from_inner(Box::leak(x).into())
    }

    /// Inogadzira `Arc<T>` nyowani ichishandisa isina kusimba mareferenzi pachayo.
    /// Kuedza kukwidziridza isina kusimba mareferensi basa iri risati radzoka kunoguma ne `None` kukosha.
    /// Nekudaro, iyo isina kusimba mareferenzi inogona kuumbirwa zvakasununguka uye kuchengetwa kuti ishandiswe pane inotevera nguva.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    ///
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo {
    ///     me: Weak<Foo>,
    /// }
    ///
    /// let foo = Arc::new_cyclic(|me| Foo {
    ///     me: me.clone(),
    /// });
    /// ```
    #[inline]
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Arc<T> {
        // Gadzira zvemukati mudunhu re "uninitialized" uine chirevo chimwe chisina kusimba.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box ArcInner {
            strong: atomic::AtomicUsize::new(0),
            weak: atomic::AtomicUsize::new(1),
            data: mem::MaybeUninit::<T>::uninit(),
        })
        .into();
        let init_ptr: NonNull<ArcInner<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Izvo zvakakosha kuti isu tirege kuve varidzi veisina kusimba pointer, kana zvisina kudaro ndangariro inogona kusunungurwa nenguva iyo `data_fn` inodzoka.
        // Kana isu tichinyatsoda kupfuura muridzi, tinogona kuzvigadzirira yakawedzera pointer pachedu, asi izvi zvinoguma nekuwedzeredzwa kune isina kusimba mareferensi kuverenga izvo zvingangodaro zvisina kudikanwa neimwe nzira.
        //
        //
        //
        //
        let data = data_fn(&weak);

        // Iye zvino isu tinogona kunyatsogona kukosha kwemukati uye nekushandura yedu isina kusimba mareferensi kuita yakasimba referenzi.
        //
        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).data), data);

            // Izvi zviri pamusoro nyora kumunda wedata zvinofanirwa kuoneka kune chero tambo dzinoona isina zero zero yakasimba kuverenga.
            // Naizvozvo tinoda kumbodaira "Release" kuitira kuti tibvumirane ne `compare_exchange_weak` mu `Weak::upgrade`.
            //
            // "Acquire" kuodha hakuna kudikanwa.
            // Kana tichitarisa maitiro anogona kuitika e `data_fn` isu tinongoda kutarisa izvo zvayingaite nereferenzi kune isingasimudzirwe `Weak`:
            //
            // - Iyo inogona *kuumbiridza* iyo `Weak`, ichiwedzera iyo isina kusimba mareferensi kuverenga.
            // - Inogona kudonhedza iwo maonesheni, ichideredza isina kusimba mareferensi kuverenga (asi usamboita zero).
            //
            // Iyi mhedzisiro haikanganisa isu neimwe nzira, uye hapana mimwe mhedzisiro inogoneka nekodhi yakachengeteka yega.
            //
            //
            let prev_value = (*inner).strong.fetch_add(1, Release);
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
        }

        let strong = Arc::from_inner(init_ptr);

        // Mareferenzi akasimba anofanirwa pamwechete kuve neakagovana isina kusimba mareferensi, saka usamhanyisa anoparadza renhoroondo yedu isina simba
        //
        mem::forget(weak);
        strong
    }

    /// Inovaka `Arc` nyowani nezvisina kunyorwa zvirimo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Kutanga kusarudzika:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Inovaka `Arc` nyowani nezvisina kuvhurwa zvirimo, ndangariro dzichizadzwa ne `0` byte.
    ///
    ///
    /// Ona [`MaybeUninit::zeroed`][zeroed] yemienzaniso yekushandisa nenzira kwayo uye isiriyo iyi nzira.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Arc<mem::MaybeUninit<T>> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Inovaka `Pin<Arc<T>>` nyowani.
    /// Kana `T` isingaite `Unpin`, ipapo `data` ichapendwa mundangariro uye isingakwanise kufambiswa.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(data: T) -> Pin<Arc<T>> {
        unsafe { Pin::new_unchecked(Arc::new(data)) }
    }

    /// Inovaka `Arc<T>` nyowani, ichidzosera kukanganisa kana mugove ukatadza.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::sync::Arc;
    ///
    /// let five = Arc::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    #[inline]
    pub fn try_new(data: T) -> Result<Arc<T>, AllocError> {
        // Tanga iyo isina kusimba pointer kuverenga se1 inova iyo isina poindi pointer inobatwa neese akasimba anonongedza (kinda), ona std/rc.rs kune rumwe ruzivo
        //
        let x: Box<_> = Box::try_new(ArcInner {
            strong: atomic::AtomicUsize::new(1),
            weak: atomic::AtomicUsize::new(1),
            data,
        })?;
        Ok(Self::from_inner(Box::leak(x).into()))
    }

    /// Inovaka `Arc` nyowani nezvisina kuvhurwa zvirimo, ichidzosera kukanganisa kana mugove ukatadza.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Kutanga kusarudzika:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Inovaka `Arc` nyowani nezvisina kuvhurwa zvirimo, ndangariro dzichizadzwa ne `0` byte, ichidzosera kukanganisa kana mugove ukatadza.
    ///
    ///
    /// Ona [`MaybeUninit::zeroed`][zeroed] yemienzaniso yekushandisa nenzira kwayo uye isiriyo iyi nzira.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit, allocator_api)]
    ///
    /// use std::sync::Arc;
    ///
    /// let zero = Arc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Arc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Arc::from_ptr(Arc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut ArcInner<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Inodzorera iyo yemukati kukosha, kana iyo `Arc` iine chaiyo imwechete yakasimba referensi.
    ///
    /// Zvikasadaro, [`Err`] inodzoserwa neiyo imwechete `Arc` iyo yakapfuudzwa mukati.
    ///
    ///
    /// Izvi zvichabudirira kunyangwe paine mareferenzi asina kusimba mareferenzi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new(3);
    /// assert_eq!(Arc::try_unwrap(x), Ok(3));
    ///
    /// let x = Arc::new(4);
    /// let _y = Arc::clone(&x);
    /// assert_eq!(*Arc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if this.inner().strong.compare_exchange(1, 0, Relaxed, Relaxed).is_err() {
            return Err(this);
        }

        acquire!(this.inner().strong);

        unsafe {
            let elem = ptr::read(&this.ptr.as_ref().data);

            // Gadzira chinongedzo chisina kusimba kuchenesa chirevo chakasimba-chisina kusimba
            let _weak = Weak { ptr: this.ptr };
            mem::forget(this);

            Ok(elem)
        }
    }
}

impl<T> Arc<[T]> {
    /// Inovaka nyowani yeatomiki rejista-yakaverengwa slice ine isina kuvhurwa zvirimo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Kutanga kusarudzika:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe { Arc::from_ptr(Arc::allocate_for_slice(len)) }
    }

    /// Inogadzira nyowani inongedzo-yakaverengwa slice ine isina kuvhurwa zvirimo, ndangariro dzichizadzwa ne `0` mabheti.
    ///
    ///
    /// Ona [`MaybeUninit::zeroed`][zeroed] yemienzaniso yekushandisa nenzira kwayo uye isiriyo iyi nzira.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::sync::Arc;
    ///
    /// let values = Arc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: ../../std/mem/union.MaybeUninit.html#method.zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Arc<[mem::MaybeUninit<T>]> {
        unsafe {
            Arc::from_ptr(Arc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut ArcInner<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Arc<mem::MaybeUninit<T>> {
    /// Inotendeuka kuenda ku `Arc<T>`.
    ///
    /// # Safety
    ///
    /// Sezvo ne [`MaybeUninit::assume_init`], zviri kune iye anofona kuti ave nechokwadi chekuti kukosha kwemukati kuri muchinzvimbo chakatangwa.
    ///
    /// Kufonera izvi kana zvirimo zvisati zvatanga zvizere zvinokonzeresa kusanzwisisika maitiro.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut five = Arc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Kutanga kusarudzika:
    ///     Arc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<T> {
        Arc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Arc<[mem::MaybeUninit<T>]> {
    /// Inotendeuka kuenda ku `Arc<[T]>`.
    ///
    /// # Safety
    ///
    /// Sezvo ne [`MaybeUninit::assume_init`], zviri kune iye anofona kuti ave nechokwadi chekuti kukosha kwemukati kuri muchinzvimbo chakatangwa.
    ///
    /// Kufonera izvi kana zvirimo zvisati zvatanga zvizere zvinokonzeresa kusanzwisisika maitiro.
    ///
    /// [`MaybeUninit::assume_init`]: ../../std/mem/union.MaybeUninit.html#method.assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut values = Arc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Kutanga kusarudzika:
    ///     Arc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Arc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Arc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Arc<[T]> {
        unsafe { Arc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Inoshandisa iyo `Arc`, ichidzorera iyo yakaputirwa pointer.
    ///
    /// Kuti udzivise kuyeuka kwekurangarira iyo pointer inofanirwa kushandurwa ive `Arc` uchishandisa [`Arc::from_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Inopa pointer mbishi kune iyo data.
    ///
    /// Huwandu hahukanganisirwe munzira ipi neipi uye iyo `Arc` haina kudyiwa.
    /// Iyo pointer inoshanda chero bedzi paine zviyero zvine simba mu `Arc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let y = Arc::clone(&x);
    /// let x_ptr = Arc::as_ptr(&x);
    /// assert_eq!(x_ptr, Arc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(this.ptr);

        // Kachengeteka: Izvi hazvigone kupfuura Deref::deref kana RcBoxPtr::inner nekuti
        // izvi zvinotarisirwa kuchengetedza raw/mut provenance yakadai eg
        // `get_mut` unogona kunyora kuburikidza nechinongedzo mushure mekunge iyo Rc yadzoreredzwa kuburikidza ne `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).data) }
    }

    /// Inogadzira `Arc<T>` kubva kune yakasviba pointer.
    ///
    /// Iyo poindi mbishi inofanirwa kunge yakambodzoserwa nekufona ku [`Arc<U>::into_raw`][into_raw] uko `U` inofanira kunge iine saizi yakafanana uye kuenderana se `T`.
    /// Izvi ichokwadi zvishoma kana `U` iri `T`.
    /// Ziva kuti kana `U` isiri `T` asi iine saizi yakaenzana uye kuenderana, izvi zvakangofanana nekutenderera mareferenzi emhando dzakasiyana.
    /// Ona [`mem::transmute`][transmute] kuti uwane rumwe ruzivo nezve izvo zvinorambidzwa pano.
    ///
    /// Mushandisi we `from_raw` anofanirwa kuona kuti chakakosha kukosha kwe `T` chinongodonhedzwa kamwe chete.
    ///
    /// Iri basa harina kuchengeteka nekuti kushandiswa zvisirizvo kunogona kutungamira mukusagadzikana kwendangariro, kunyangwe iyo `Arc<T>` yakadzoserwa isingawanikwe.
    ///
    /// [into_raw]: Arc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x = Arc::new("hello".to_owned());
    /// let x_ptr = Arc::into_raw(x);
    ///
    /// unsafe {
    ///     // Chinja kudzokera ku `Arc` kudzivirira kubuda.
    ///     let x = Arc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Kuenderera mberi kwekufona ku `Arc::from_raw(x_ptr)` kwaizove kurangarira-kusachengeteka.
    /// }
    ///
    /// // Ndangariro dzakasunungurwa `x` payakabuda pachiyero pamusoro, saka `x_ptr` yava kuturika!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        unsafe {
            let offset = data_offset(ptr);

            // Dzorera izvo zvakakanganiswa kuti uwane iyo yekutanga ArcInner.
            let arc_ptr = (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset));

            Self::from_ptr(arc_ptr)
        }
    }

    /// Inogadzira nyowani [`Weak`] pointer kune ichi chikamu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        // Izvi Relaxed zvakanaka nekuti tiri kutarisa kukosha muCAS pazasi.
        //
        let mut cur = this.inner().weak.load(Relaxed);

        loop {
            // tarisa kana pakaunda isina kusimba ikozvino "locked";kana zvirizvo, spin.
            if cur == usize::MAX {
                hint::spin_loop();
                cur = this.inner().weak.load(Relaxed);
                continue;
            }

            // NOTE: kodhi iyi parizvino inofuratira mukana wekufashukira
            // kupinda usize::MAX;kazhinji zvese Rc uye Arc inoda kugadziridzwa kuti ibate nekufashukira.
            //

            // Kusiyana ne Clone(), isu tinoda kuti ive Acquire kuverenga kuti tibvumirane neyekunyora kunobva ku `is_unique`, kuitira kuti zviitiko zvisati zvaitika nyora zviitike izvi zvisati zvaverengwa.
            //
            //
            match this.inner().weak.compare_exchange_weak(cur, cur + 1, Acquire, Relaxed) {
                Ok(_) => {
                    // Ita shuwa kuti isu hatigadzi inorembera Inoshaya simba
                    debug_assert!(!is_dangling(this.ptr.as_ptr()));
                    return Weak { ptr: this.ptr };
                }
                Err(old) => cur = old,
            }
        }
    }

    /// Inowana iyo nhamba ye [`Weak`] zvinongedzo kune ichi chikamu.
    ///
    /// # Safety
    ///
    /// Iyi nzira pachayo yakachengeteka, asi kuishandisa nemazvo inoda kuwedzerwa kutarisirwa.
    /// Imwe tambo inogona kuchinja isina kusimba kuverenga chero nguva, kusanganisira zvingangoita pakati pekufona iyi nzira uye kuita pane mhedzisiro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _weak_five = Arc::downgrade(&five);
    ///
    /// // Ichi chirevo chinogadzirisa nekuti hatina kugovana iyo `Arc` kana `Weak` pakati peshinda.
    /////
    /// assert_eq!(1, Arc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        let cnt = this.inner().weak.load(SeqCst);
        // Kana iyo isina kusimba kuverenga parizvino yakavharwa, kukosha kweiyo kuverenga kwaive 0 chinguva usati watora kukiya.
        //
        if cnt == usize::MAX { 0 } else { cnt - 1 }
    }

    /// Inowana iyo nhamba yeakasimba (`Arc`) anongedzera kune ichi chikamu.
    ///
    /// # Safety
    ///
    /// Iyi nzira pachayo yakachengeteka, asi kuishandisa nemazvo inoda kuwedzerwa kutarisirwa.
    /// Imwe tambo inogona kuchinja kuverenga kwakasimba chero nguva, kusanganisira zvingangoita pakati pekufona iyi nzira uye kuita pane mhedzisiro.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let _also_five = Arc::clone(&five);
    ///
    /// // Ichi chirevo chinogadzirisa nekuti hatina kugovana iyo `Arc` pakati peshinda.
    /////
    /// assert_eq!(2, Arc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "arc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong.load(SeqCst)
    }

    /// Kuwedzera kwakasimba kunongedzera kuverenga pane `Arc<T>` inosangana neye yakapihwa pointer neimwe.
    ///
    /// # Safety
    ///
    /// Iyo pointer inofanira kunge yakawanikwa kuburikidza ne `Arc::into_raw`, uye inosanganisirwa `Arc` semuenzaniso inofanira kunge ichishanda (kureva
    /// iyo yakasimba kuverenga inofanirwa kuve ingangoita 1) kwenguva yeiyi nzira.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Ichi chirevo chinogadzirisa nekuti hatina kugovana iyo `Arc` pakati peshinda.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn increment_strong_count(ptr: *const T) {
        // Chengetedza Arc, asi usabata bata nekuputira muManualDrop
        let arc = unsafe { mem::ManuallyDrop::new(Arc::<T>::from_raw(ptr)) };
        // Zvino wedzera kuverenga, asi usadonhedze kuverenga zvakare
        let _arc_clone: mem::ManuallyDrop<_> = arc.clone();
    }

    /// Kuderedza kwakasimba kunongedzera kuverenga pane `Arc<T>` inosangana neye yakapihwa pointer neimwe.
    ///
    /// # Safety
    ///
    /// Iyo pointer inofanira kunge yakawanikwa kuburikidza ne `Arc::into_raw`, uye inosanganisirwa `Arc` semuenzaniso inofanira kunge ichishanda (kureva
    /// kuverenga kwakasimba kunofanirwa kuve kanenge 1) kana uchikumbira nzira iyi.
    /// Iyi nzira inogona kushandiswa kuburitsa yekupedzisira `Arc` uye yekutsigira yekuchengetedza, asi **haifanire** kudaidzwa mushure mekupedzisira `Arc` yaburitswa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// unsafe {
    ///     let ptr = Arc::into_raw(five);
    ///     Arc::increment_strong_count(ptr);
    ///
    ///     // Izvo zvirevo ndezvekufunga nekuti hatina kugovana iyo `Arc` pakati peshinda.
    /////
    ///     let five = Arc::from_raw(ptr);
    ///     assert_eq!(2, Arc::strong_count(&five));
    ///     Arc::decrement_strong_count(ptr);
    ///     assert_eq!(1, Arc::strong_count(&five));
    /// }
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_mutate_strong_count", since = "1.51.0")]
    pub unsafe fn decrement_strong_count(ptr: *const T) {
        unsafe { mem::drop(Arc::from_raw(ptr)) };
    }

    #[inline]
    fn inner(&self) -> &ArcInner<T> {
        // Uku kusagadzikana kwakanaka nekuti apo arc iyi iri mupenyu takavimbiswa kuti pointer yemukati inoshanda.
        // Uyezve, isu tinoziva kuti iyo `ArcInner` chimiro pachayo i `Sync` nekuti iyo yemukati data i `Sync` futi, saka isu tiri ok kukweretesa kunze isingachinjiki pointer kune izvi zvirimo.
        //
        //
        //
        unsafe { self.ptr.as_ref() }
    }

    // Isina-yakamisikidzwa chikamu che `drop`.
    #[inline(never)]
    unsafe fn drop_slow(&mut self) {
        // Paradza iyo data panguva ino, kunyangwe isu tisingakwanise kusunungura iro bhokisi kugoverwa iro pacharo (panogona kunge paine asina simba mapaipi akarara akatenderedza).
        //
        unsafe { ptr::drop_in_place(Self::get_mut_unchecked(self)) };

        // Donhedza zvisina kusimba Ref pamwe zvakabatwa neese akasimba mareferenzi
        drop(Weak { ptr: self.ptr });
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Inodzorera `true` kana iwo maviri `Arc` anongedzera kune kugoverwa kwakafanana (mune tsinga yakafanana ne [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    /// let same_five = Arc::clone(&five);
    /// let other_five = Arc::new(5);
    ///
    /// assert!(Arc::ptr_eq(&five, &same_five));
    /// assert!(!Arc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: ?Sized> Arc<T> {
    /// Inogovanisa `ArcInner<T>` ine nzvimbo yakakwana yeinogona kunge isina-saizi yemukati kukosha uko kukosha kune dhizaini yakapihwa.
    ///
    /// Basa `mem_to_arcinner` inodaidzwa neinongedzo yedata uye rinofanira kudzosa (inogona mafuta) pointer ye `ArcInner<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> *mut ArcInner<T> {
        // Verenga marongerwo uchishandisa iyo yakapihwa kukosha dhizaini.
        // Pakutanga, dhizaini yaiverengerwa pane chirevo `&*(ptr as* const ArcInner<T>)`, asi izvi zvakagadzira zvisirizvo mareferenzi (ona #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Arc::try_allocate_for_layout(value_layout, allocate, mem_to_arcinner)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Inogovanisa `ArcInner<T>` ine nzvimbo yakakwana yeinogona kunge isina-saizi yemukati kukosha uko kukosha kune dhizaini yakapihwa, kudzorera kukanganisa kana mugove ukatadza.
    ///
    ///
    /// Basa `mem_to_arcinner` inodaidzwa neinongedzo yedata uye rinofanira kudzosa (inogona mafuta) pointer ye `ArcInner<T>`.
    ///
    ///
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_arcinner: impl FnOnce(*mut u8) -> *mut ArcInner<T>,
    ) -> Result<*mut ArcInner<T>, AllocError> {
        // Verenga marongerwo uchishandisa iyo yakapihwa kukosha dhizaini.
        // Pakutanga, dhizaini yaiverengerwa pane chirevo `&*(ptr as* const ArcInner<T>)`, asi izvi zvakagadzira zvisirizvo mareferenzi (ona #54908).
        //
        //
        let layout = Layout::new::<ArcInner<()>>().extend(value_layout).unwrap().0.pad_to_align();

        let ptr = allocate(layout)?;

        // Kutanga iyo ArcInner
        let inner = mem_to_arcinner(ptr.as_non_null_ptr().as_ptr());
        debug_assert_eq!(unsafe { Layout::for_value(&*inner) }, layout);

        unsafe {
            ptr::write(&mut (*inner).strong, atomic::AtomicUsize::new(1));
            ptr::write(&mut (*inner).weak, atomic::AtomicUsize::new(1));
        }

        Ok(inner)
    }

    /// Inogovera `ArcInner<T>` ine nzvimbo yakakwana yeiyo isina kukosheswa yemukati kukosha.
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut ArcInner<T> {
        // Govera iyo `ArcInner<T>` uchishandisa kukosha kwakapihwa.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut ArcInner<T>).set_ptr_value(mem) as *mut ArcInner<T>,
            )
        }
    }

    fn from_box(v: Box<T>) -> Arc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopa kukosha senge mabheti
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).data as *mut _ as *mut u8,
                value_size,
            );

            // Sunungura mugove usingadonhedze zvirimo
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Arc<[T]> {
    /// Inopa `ArcInner<[T]>` nehurefu hwakapihwa.
    unsafe fn allocate_for_slice(len: usize) -> *mut ArcInner<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut ArcInner<[T]>,
            )
        }
    }

    /// Kopa zvinhu kubva pane slice kuenda kuchangobva kupihwa Arc <\[T\]>
    ///
    /// Hazvina kuchengeteka nekuti anenge afona anofanira kutora muridzi kana kusunga `T: Copy`.
    unsafe fn copy_from_slice(v: &[T]) -> Arc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());

            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).data as *mut [T] as *mut T, v.len());

            Self::from_ptr(ptr)
        }
    }

    /// Inogadzira `Arc<[T]>` kubva kune iterator inozivikanwa kuva yeimwe saizi.
    ///
    /// Maitiro haana kujekeswa kana saizi ikanganisa.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Arc<[T]> {
        // Panic chengetedza paunenge uchigadzira T zvinhu.
        // Kana paine panic, zvinhu zvakanyorwa muArcInner nyowani zvinokandwa, ipapo ndangariro dzosunungurwa.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Chinongedzera kuchinhu chekutanga
            let elems = &mut (*ptr).data as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Zvese zviri pachena.Kanganwa murindi kuitira kuti irege kusunungura iyo ArcInner nyowani.
            mem::forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Nyanzvi trait yakashandiswa ye `From<&[T]>`.
trait ArcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> ArcFromSlice<T> for Arc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Arc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Arc<T> {
    /// Inoita Clone yeiyo `Arc` pointer.
    ///
    /// Izvi zvinogadzira imwe pointer kune imwecheteyo mugove, ichiwedzera yakasimba mareferensi kuverenga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let _ = Arc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Arc<T> {
        // Kushandisa kurongeka kwekusununguka kwakanaka pano, sezvo ruzivo rweyepakutanga mareferenzi runodzivirira dzimwe tambo kubva mukukanganisa kubvisa chinhu.
        //
        // Sezvakatsanangurwa mu [Boost documentation][1], Kuwedzera remberi kadhi kunogona kugara kuchiitwa neyememory_order_relaxed: Zvitsva zvinongedzo kuchinhu zvinogona chete kuumbwa kubva kune iriko rejisheni, uye kupfuudza iriko mareferenzi kubva kune imwe tambo kuenda kune imwe inofanira kutopa chero chinowirirana chinodiwa.
        //
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        //
        //
        //
        //
        //
        let old_size = self.inner().strong.fetch_add(1, Relaxed);

        // Nekudaro isu tinofanirwa kungwarira pakuramba kukuru kwekuti kana mumwe munhu ari `mem: : kukanganwa`Arcs.
        // Tikasaita izvi kuverenga kunogona kufashukira uye vashandisi vanozoshandisa-mushure memahara.
        // Isu tinomhara zvine mutsindo ku `isize::MAX` pane fungidziro yekuti hapana ~2 bhiriyoni tambo dzinowedzera huwandu hwereferensi kamwechete.
        //
        // Iyi branch haizombotorwa mune chero chaicho chirongwa.
        //
        // Isu tinobvisa nekuti chirongwa chakadai chinodzikira zvisingaite, uye isu hatine basa nekuchitsigira.
        //
        //
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Arc<T> {
    type Target = T;

    #[inline]
    fn deref(&self) -> &T {
        &self.inner().data
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Arc<T> {}

impl<T: Clone> Arc<T> {
    /// Inoita chirevo chinoshandurwa mune yakapihwa `Arc`.
    ///
    /// Kana paine mamwe ma `Arc` kana [`Weak`] anonongedzera kune kugoverwa kumwe chete, saka `make_mut` ichagadzira kugoverwa kutsva uye kukumbira [`clone`][clone] pane kukosha kwemukati kuve nechokwadi chemuridzi wega.
    /// Izvi zvinonziwo se clone-on-write.
    ///
    /// Ziva kuti izvi zvinopesana nehunhu hwe [`Rc::make_mut`] iyo inosanganisa chero anosiiwa `Weak` zvinongedzo.
    ///
    /// Onawo [`get_mut`][get_mut], inozokundikana pane kuumbana.
    ///
    /// [clone]: Clone::clone
    /// [get_mut]: Arc::get_mut
    /// [`Rc::make_mut`]: super::rc::Rc::make_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut data = Arc::new(5);
    ///
    /// *Arc::make_mut(&mut data) += 1;         // Hapana chaunonamira
    /// let mut other_data = Arc::clone(&data); // Haizofananidza data remukati
    /// *Arc::make_mut(&mut data) += 1;         // Clones data remukati
    /// *Arc::make_mut(&mut data) += 1;         // Hapana chaunonamira
    /// *Arc::make_mut(&mut other_data) *= 2;   // Hapana chaunonamira
    ///
    /// // Iye zvino `data` uye `other_data` vanongedzera kune akasiyana magovaniswa.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        // Ziva kuti isu tinobata zvese zvine simba chirevo uye chisina kusimba chirevo
        // Nekudaro, kuburitsa yedu yakasimba referensi chete hakuzoiti, pachezvayo, kunokanganisa ndangariro.
        //
        // Shandisa Wana kuti uone kuti tinoona chero anonyora ku `weak` zvinoitika kusati kwaburitswa kunyorera (kureva., Kuderera) ku `strong`.
        // Sezvo isu takabata isina kusimba kuverenga, hapana mukana wekuti ArcInner pachayo inogona kuendeswa.
        //
        //
        //
        if this.inner().strong.compare_exchange(1, 0, Acquire, Relaxed).is_err() {
            // Imwe pointer yakasimba iripo, saka isu tinofanirwa kuenzanisa.
            // Pre-govera ndangariro kubvumidza kunyora iyo yakasanganiswa kukosha zvakananga.
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = arc.assume_init();
            }
        } else if this.inner().weak.load(Relaxed) != 1 {
            // Relaxed inokwana pane zvataurwa pamusoro apa nekuti uku ndiko kuita kwakazara: isu tinogara tichimhanya nezviratidzo zvisina kusimba zvichidonhedzwa.
            // Chakaipisisa nyaya, isu tinopedzisira tapihwa Arc nyowani zvisina basa.
            //

            // Isu takabvisa iyo yekupedzisira yakasimba Ref, asi pane zvimwe zvisina kusimba Refs zvasara.
            // Tichafambisa zvirimo kuArc nyowani, uye nekusaremekedza mamwe asina simba Ref.
            //

            // Ziva kuti hazviite kuti kuverenga kwe `weak` kuburitse usize::MAX (kureva, kukiyiwa), nekuti iyo isina kusimba kuverenga inogona kungovharwa netambo ine chirevo chakasimba.
            //
            //

            // Shongedza yedu yega isina kusimba pointer, kuti igone kuchenesa iyo ArcInner sezviri kudikanwa.
            //
            let _weak = Weak { ptr: this.ptr };

            // Unogona kungoba iyo data, zvese zvasara ndeye Weaks
            let mut arc = Self::new_uninit();
            unsafe {
                let data = Arc::get_mut_unchecked(&mut arc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);
                ptr::write(this, arc.assume_init());
            }
        } else {
            // Isu takanga tiri vega mareferenzi emhando ipi neipi;bump back up iyo yakasimba ref kuverenga.
            //
            this.inner().strong.store(1, Release);
        }

        // Sezvakaita `get_mut()`, iko kusagadzikana kuri kwakanaka nekuti kwedu mareferenzi angave akasarudzika kutanga nawo, kana kuve imwe pakunyora zvirimo.
        //
        unsafe { Self::get_mut_unchecked(this) }
    }
}

impl<T: ?Sized> Arc<T> {
    /// Inodzorera chinongedzo chinoshandurwa mune yakapihwa `Arc`, kana pasina imwe `Arc` kana [`Weak`] zvinongedzo kune zvakafanana kugoverwa.
    ///
    ///
    /// Inodzorera [`None`] neimwe nzira, nekuti hazvina kuchengetedzeka kuchinjisa kukosha kwakagovaniswa.
    ///
    /// Onawo [`make_mut`][make_mut], inova [`clone`][clone] kukosha kwemukati kana paine zvimwe zvinongedzo.
    ///
    /// [make_mut]: Arc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(3);
    /// *Arc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Arc::clone(&x);
    /// assert!(Arc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "arc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if this.is_unique() {
            // Uku kusagadzikana kwakanaka nekuti isu takavimbiswa kuti pointer yakadzoserwa ndiyo *chete* pointer inombodzoserwa kuna T.
            // Yedu mareferensi kuverenga inovimbiswa kuve 1 panguva ino, uye isu taida iyo Arc pachayo kuve `mut`, saka isu tiri kudzosera iro chete rinogoneka renongedzo kune yemukati data.
            //
            //
            //
            unsafe { Some(Arc::get_mut_unchecked(this)) }
        } else {
            None
        }
    }

    /// Inodzorera zvinogona kuchinjika mune yakapihwa `Arc`, pasina cheki.
    ///
    /// Onawo [`get_mut`], iri yakachengeteka uye inoita yakakodzera macheki.
    ///
    /// [`get_mut`]: Arc::get_mut
    ///
    /// # Safety
    ///
    /// Chero ipi imwe `Arc` kana [`Weak`] zvinongedzera kune zvakafanana kugoverwa hazvifanire kuratidzwa kwenguva iyo yakadzorerwa chikwereti.
    ///
    /// Izvi zvishoma kesi kana pasina zvinongedzo zvakadaro, semuenzaniso nekukurumidza mushure me `Arc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::sync::Arc;
    ///
    /// let mut x = Arc::new(String::new());
    /// unsafe {
    ///     Arc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Isu takangwarira *kwete* kugadzira rejista inovhara iyo "count" minda, sezvo izvi zvaizove alias pamwe panguva imwechete yekuwana mareferensi kuverenga (semuenzaniso.
        // ne `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).data }
    }

    /// Sarudza kana ichi chiri chirevo chakasarudzika (kusanganisira chisina simba Refs) kune iri pasi data.
    ///
    ///
    /// Ziva kuti izvi zvinoda kukiya iyo isina kusimba Ref kuverenga.
    fn is_unique(&mut self) -> bool {
        // kiya iyo isina kuneta pointer kuverenga kana isu tichiita senge tisina kusimba pointer mubati.
        //
        // Iko kunotora pano kunovimbisa zvinoitika-pamberi pehukama nechero anonyora kuna `strong` (kunyanya mu `Weak::upgrade`) kusati kwadzikira kweiyo `weak` kuverenga (kuburikidza ne `Weak::drop`, iyo inoshandisa kuburitsa).
        // Kana iyo yakakwidziridzwa isina kusimba Ref isina kumbobvira yadonhedzwa, iyo CAS pano inokundikana saka isu hatine basa nekuenderana.
        //
        //
        //
        if self.inner().weak.compare_exchange(1, usize::MAX, Acquire, Relaxed).is_ok() {
            // Izvi zvinofanirwa kunge zviri `Acquire` kuwiriranisa pamwe nekuderera kwekambani ye `strong` mu `drop`-iko chete kuwana kunoitika kana paine chero asi rezita rekupedzisira riri kudonhedzwa.
            //
            //
            let unique = self.inner().strong.load(Acquire) == 1;

            // Kusunungurwa nyora pano kunoenderana nekuverenga mu `downgrade`, zvichinyatso kudzivirira kuverenga kwepamusoro kwe `strong` kuti zviitike mushure mekunyora.
            //
            //
            self.inner().weak.store(1, Release); // kusunungura kukiya
            unique
        } else {
            false
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Arc<T> {
    /// Anodonha iyo `Arc`.
    ///
    /// Izvi zvinodzora yakasimba referensi kuverenga.
    /// Kana iyo yakasimba mareferensi kuverenga inosvika zero saka mamwe chete mareferenzi (kana aripo) ari [`Weak`], saka isu `drop` kukosha kwemukati.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Arc::new(Foo);
    /// let foo2 = Arc::clone(&foo);
    ///
    /// drop(foo);    // Hazvidhindise chero chinhu
    /// drop(foo2);   // Prints "dropped!"
    /// ```
    #[inline]
    fn drop(&mut self) {
        // Nekuti `fetch_sub` yatove atomic, isu hatidi kuwiriranisa nedzimwe tambo kunze kwekunge tichizodzima chinhu.
        // Pfungwa imwe chete iyi inoshanda kune iri pazasi `fetch_sub` kune iyo `weak` kuverenga.
        //
        if self.inner().strong.fetch_sub(1, Release) != 1 {
            return;
        }

        // Iyi fenzi inodiwa kudzivirira kugadzirisazve mashandisiro e data uye kubviswa kwedata.
        // Nekuti yakamisirwa `Release`, kudzikira kwereferensi kuverenga kunowirirana neiyi `Acquire` fenzi.
        // Izvi zvinoreva kuti kushandiswa kwedata kunoitika usati waderedza mareferensi kuverenga, kunoitika pamberi peiyi fenzi, inoitika pasati pabviswa iyo data.
        //
        // Sezvakatsanangurwa mu [Boost documentation][1],
        //
        // > Izvo zvakakosha kumanikidza chero mukana unokwanisika kuwana chinhu mune imwe
        // > tambo (kuburikidza nereferenzi iripo) kuti *zviitike pamberi* kubvisa
        // > chinhu icho mune imwe tambo.Izvi zvinowanikwa ne "release"
        // > mashandiro mushure mekudonhedza mareferensi (chero mukana wechinhu
        // > kuburikidza neichi chirevo chinofanira kunge chakaitika zvisati zvaitika), uye an
        // > "acquire" kushanda usati wabvisa chinhu.
        //
        // Kunyanya, nepo zviri mukati meArc kazhinji zvisingachinjiki, zvinoita kuti mukati unyore kune chimwe chinhu senge Mutex<T>.
        // Sezvo Mutex isingawanikwe painobviswa, hatigone kuvimba nepfungwa yayo yekubvumirana kuti inyorwe mu thread A inoonekwa kune muparadzi anomhanya mune tambo B.
        //
        //
        // Ziva zvakare kuti Tenga fenzi pano inogona kutsiviwa neAtora mutoro, iyo inogona kuvandudza mashandiro mumamiriro ezvinhu ane nharo.Ona [2].
        //
        // [1]: (www.boost.org/doc/libs/1_55_0/doc/html/atomic/usage_examples.html)
        // [2]: (https://github.com/rust-lang/rust/pull/41714)
        //
        //
        //
        //
        //
        //
        //
        acquire!(self.inner().strong);

        unsafe {
            self.drop_slow();
        }
    }
}

impl Arc<dyn Any + Send + Sync> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Kuedza kudzikisira `Arc<dyn Any + Send + Sync>` kune yekongiri mhando.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::sync::Arc;
    ///
    /// fn print_if_string(value: Arc<dyn Any + Send + Sync>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Arc::new(my_string));
    /// print_if_string(Arc::new(0i8));
    /// ```
    pub fn downcast<T>(self) -> Result<Arc<T>, Self>
    where
        T: Any + Send + Sync + 'static,
    {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<ArcInner<T>>();
            mem::forget(self);
            Ok(Arc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T> Weak<T> {
    /// Inovaka `Weak<T>` nyowani, isina kugovera chero ndangariro.
    /// Kufonera [`upgrade`] pamutengo wekudzoka kunogara kuchipa [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut ArcInner<T>).expect("MAX is not 0") }
    }
}

/// Rudzi rwemubatsiri kubvumidza kuwana iyo mareferensi kuverenga pasina kuita chero zvirevo nezve iyo data shamba.
///
struct WeakInner<'a> {
    weak: &'a atomic::AtomicUsize,
    strong: &'a atomic::AtomicUsize,
}

impl<T: ?Sized> Weak<T> {
    /// Inodzorera pointer mbishi kuchinhu `T` chakanongedzwa neiyi `Weak<T>`.
    ///
    /// Iyo pointer inoshanda chete kana paine mamwe mareferenzi akasimba.
    /// Iyo pointer inogona kunge yakarembera, isina kuisirwa kana kunyange [`null`] neimwe nzira.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::ptr;
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// // Ose ari maviri anonongedzera kuchinhu chimwe chete
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Vakasimba pano vanozvichengeta zviri zvipenyu, saka tinogona kuwana chinhu.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Asi kwete zvekare.
    /// // Tinogona kuita weak.as_ptr(), asi kuwana iyo pointer kunotungamira kune isina kujekeswa maitiro.
    /// // assert_eq! ("hello", haina kuchengeteka {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut ArcInner<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Kana pointer yakarembera, tinodzorera iyo sentinel zvakananga.
            // Iyi haigone kuve yakakodzera kero yekubhadhara, sezvo mubhadharo wacho unenge wakabatana seArcInner (usize).
            ptr as *const T
        } else {
            // Kachengeteka: kana kuri_kurembera kunodzoka kwenhema, ipapo chinongedzo hachioneke.
            // Mubhadharo unogona kudonhedzwa panguva ino, uye isu tinofanirwa kuchengetedza mvumo, saka shandisa mbichana mbichana.
            //
            unsafe { ptr::addr_of_mut!((*ptr).data) }
        }
    }

    /// Inoshandisa iyo `Weak<T>` uye inoichinja ichiita poindi mbishi.
    ///
    /// Izvi zvinoshandura pointer isina kusimba kuita pointer mbishi, ichiri kuchengetedza muridzi weimwe isina kusimba mareferenzi (iyo isina kusimba kuverenga haina kuchinjwa neichi chiitiko).
    /// Inogona kudzoserwa mu `Weak<T>` ne [`from_raw`].
    ///
    /// Iyo mimwe mirawo yekuwana iyo tariso yechinongedzo sekunge [`as_ptr`] inoshanda.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    /// let weak = Arc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Arc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Arc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Inoshandura pointer mbishi yakambogadzirwa ne [`into_raw`] kudzokera ku `Weak<T>`.
    ///
    /// Izvi zvinogona kushandiswa kuchengetedza zvakachengeteka chirevo (nekufona [`upgrade`] gare gare) kana kuendesa isina kusimba kuverenga nekudonhedza `Weak<T>`.
    ///
    /// Zvinotora humiriri hweimwe isina kusimba mareferensi (kunze kwemanongedzo akagadzirwa ne [`new`], sezvo izvi zvisina chinhu, nzira yacho ichiri kushanda pavari).
    ///
    /// # Safety
    ///
    /// Iyo pointer inofanirwa kunge yakabva ku [`into_raw`] uye inofanira kunge iine yayo isinganetse mareferenzi.
    ///
    /// Zvinotenderwa kuti kuverengera kwakasimba kuve 0 panguva yekufona iyi.
    /// Zvakangodaro, izvi zvinotora muridzi weimwe isina kusimba mareferenzi parizvino inomiririrwa seyakajeka pointer (iyo isina kusimba kuverenga haina kuchinjwa neichi chiitiko) uye nekudaro chinofanira kuve chakapetwa neakambofona ku [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let strong = Arc::new("hello".to_owned());
    ///
    /// let raw_1 = Arc::downgrade(&strong).into_raw();
    /// let raw_2 = Arc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Arc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Arc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Kuderedza yekupedzisira isina kusimba kuverenga.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`new`]: Weak::new
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`forget`]: std::mem::forget
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Ona Weak::as_ptr yemamiriro ekuti poindi yekuisa inotorwa sei.

        let ptr = if is_dangling(ptr as *mut T) {
            // Uku kurembera Kuneta.
            ptr as *mut ArcInner<T>
        } else {
            // Zvikasadaro, isu takavimbiswa kuti pointer yakabva kune isinganetsi Weak.
            // SAFETY: data_offset yakachengeteka kufona, se ptr inongedzera chaiyo (inogona kudonhedzwa) T.
            let offset = unsafe { data_offset(ptr) };
            // Nekudaro, isu tinodzosera kukanganisa kuti tiwane iyo yose RcBox.
            // Kachengeteka: iyo pointer yakatanga kubva kune Weak, saka iyi offset yakachengeteka.
            unsafe { (ptr as *mut ArcInner<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // KUCHENGETEKA: isu ikozvino tadzorera iyo yekutanga Weak pointer, saka tinogona kugadzira iyo isina Simba.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }
}

impl<T: ?Sized> Weak<T> {
    /// Kuedza kukwidziridza `Weak` pointer kune [`Arc`], kunonoka kudonha kweiyo yemukati kukosha kana ikabudirira.
    ///
    ///
    /// Inodzorera [`None`] kana kukosha kwemukati kubva kwadzikiswa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// let weak_five = Arc::downgrade(&five);
    ///
    /// let strong_five: Option<Arc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Paradza mapoinzi ese akasimba.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "arc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Arc<T>> {
        // Isu tinoshandisa chiuno cheCAS kuwedzera huwandu hwakasimba panzvimbo pe fetch_add sezvo iri basa risingafanire kutora referensi kuverenga kubva zero kuenda kune imwe.
        //
        //
        let inner = self.inner()?;

        // Relaxed mutoro nekuti chero kunyora kwe0 kwatinogona kuona kunosiya munda mune zvachose zero mamiriro (saka "stale" kuverenga kwe0 kwakanaka), uye chero imwe kukosha inosimbiswa kuburikidza neCAS pazasi.
        //
        //
        //
        let mut n = inner.strong.load(Relaxed);

        loop {
            if n == 0 {
                return None;
            }

            // Ona zvirevo mu `Arc::clone` nezve nei tichiitira izvi (zve `mem::forget`).
            if n > MAX_REFCOUNT {
                abort();
            }

            // Relaxed yakanaka pamhosva yekutadza nekuti isu hatine tarisiro nezve nyika nyowani.
            // Kuwana kunodiwa kuti kesi yekubudirira iwirirane ne `Arc::new_cyclic`, apo kukosha kwemukati kunogona kutanga mushure me `Weak` mareferenzi atogadzirwa.
            // Muchiitiko ichocho, isu tinotarisira kuona kukosha kwakazara kwakatangwa.
            //
            match inner.strong.compare_exchange_weak(n, n + 1, Acquire, Relaxed) {
                Ok(_) => return Some(Arc::from_inner(self.ptr)), // null yakaongororwa pamusoro
                Err(old) => n = old,
            }
        }
    }

    /// Inowana iyo nhamba yeakasimba (`Arc`) anongedzera anongedzera kuichi chikamu.
    ///
    /// Kana `self` yakagadzirwa ichishandisa [`Weak::new`], izvi zvinodzoka 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong.load(SeqCst) } else { 0 }
    }

    /// Inowana fungidziro yenhamba yezvinongedzo zve `Weak` zvichinongedzera kuichi chikamu.
    ///
    /// Kana `self` yakagadzirwa ichishandisa [`Weak::new`], kana kana pasina zvirevo zvakasimba zvakasara, izvi zvinodzoka 0.
    ///
    /// # Accuracy
    ///
    /// Nekuda kwemashoko ekushandisa, iyo yakadzoserwa kukosha inogona kubviswa ne1 kune imwe nzira kana imwe tambo iri kubata chero `Arc`s kana`Weak`s inonongedzera kune imwecheteyo kugoverwa.
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                let weak = inner.weak.load(SeqCst);
                let strong = inner.strong.load(SeqCst);
                if strong == 0 {
                    0
                } else {
                    // Sezvo takaona kuti pakanga paine imwechete pointer yakasimba mushure mekuverenga iyo isina kusimba kuverenga, tinoziva kuti chirevo chisina kusimba chirevo (chiripo pese panenge paine mareferenzi akasimba ari mupenyu) aive achiri patakaona iyo isina kusimba kuverenga, uye nekudaro tinogona kuibvisa zvakachengeteka.
                    //
                    //
                    //
                    //
                    weak - 1
                }
            })
            .unwrap_or(0)
    }

    /// Inodzorera `None` apo iyo pointer yakaturika uye hapana yakapihwa `ArcInner`, (kureva., Apo iyi `Weak` yakagadzirwa na `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Isu takangwarira *kwete* kugadzira rejista inovhara iyo "data" munda, sezvo munda unogona kuchinjika panguva imwe chete (semuenzaniso, kana iyo yekupedzisira `Arc` ikadonhedzwa, iyo data data inokandwa munzvimbo).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Inodzorera `true` kana iwo maviri `Weak` anongedzera kugove rakafanana (rakafanana ne [`ptr::eq`]), kana kana ese ari maviri asinganongedze kune chero kupihwa (nekuti ivo vakasikwa ne `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Sezvo izvi zvichifananidza zvinongedzo zvinoreva kuti `Weak::new()` ichaenzana, kunyangwe ivo vasinganongedze kune chero kupihwa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let first_rc = Arc::new(5);
    /// let first = Arc::downgrade(&first_rc);
    /// let second = Arc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(5);
    /// let third = Arc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Kuenzanisa `Weak::new`.
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Arc::new(());
    /// let third = Arc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Inoita dombo reiyo `Weak` pointer iyo inonongedzera kuichi chikamu chakafanana.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// let weak_five = Arc::downgrade(&Arc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        let inner = if let Some(inner) = self.inner() {
            inner
        } else {
            return Weak { ptr: self.ptr };
        };
        // Ona zvirevo mu Arc::clone() yekuti nei izvi zvakasununguka.
        // Izvi zvinogona kushandisa fetch_add (kufuratira iro kiyi) nekuti iyo isina kusimba kuverenga inongokiyiwa uko *hapana zvimwe* zvisina kunongedzera zviripo.
        //
        // (Saka hatigone kunge tichimhanyisa kodhi iyi mune izvo).
        let old_size = inner.weak.fetch_add(1, Relaxed);

        // Ona zvirevo mu Arc::clone() nezve nei tichiitira izvi (zve mem::forget).
        if old_size > MAX_REFCOUNT {
            abort();
        }

        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Inogadzira `Weak<T>` nyowani, isina kugovera ndangariro.
    /// Kufonera [`upgrade`] pamutengo wekudzoka kunogara kuchipa [`None`].
    ///
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

#[stable(feature = "arc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Anodonha iyo `Weak` pointer.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::{Arc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Arc::new(Foo);
    /// let weak_foo = Arc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Hazvidhindise chero chinhu
    /// drop(foo);        // Prints "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        // Kana isu tikaziva kuti isu taive yekupedzisira isina kusimba pointer, saka inguva yayo yekumisikidza iyo data zvachose.Ona nhaurirano mu Arc::drop() nezve kurongeka kwekuyeuka
        //
        // Hazvina basa kuti utarise mamiriro akakiyiwa pano, nekuti iyo isina kusimba kuverenga inogona kuvharwa chete kana paine imwe isina kusimba Ref, zvichireva kuti kudonha kwaigona kungo mhanyisa ON iyo yasara isina kusimba Ref, iyo inogona kungoitika chete mushure mekuburitswa kwekiyi.
        //
        //
        //
        //
        //
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        if inner.weak.fetch_sub(1, Release) == 1 {
            acquire!(inner.weak);
            unsafe { Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr())) }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait ArcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Arc<T>) -> bool;
    fn ne(&self, other: &Arc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    default fn eq(&self, other: &Arc<T>) -> bool {
        **self == **other
    }
    #[inline]
    default fn ne(&self, other: &Arc<T>) -> bool {
        **self != **other
    }
}

/// Tiri kuita hunyanzvi pano, uye kwete sekuwedzera kwakawanda pa `&T`, nekuti zvaizowedzera mutengo kune eseququque cheki pane Refs.
/// Isu tinofungidzira kuti `Arc`s inoshandiswa kuchengetera akakosha maitiro, ayo anononoka kuumbika, asi zvakare anorema kutarisa kuenzana, zvichikonzera mutengo uyu kubhadhara zviri nyore.
///
/// Izvo zvakare zvinowanzoita kuve nemaviri `Arc` macones, ayo anonongedzera kune yakafanana kukosha, kupfuura maviri `&T`s.
///
/// Tinogona chete kuita izvi kana `T: Eq` se `PartialEq` inogona kunge isingaiti nemaune.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + crate::rc::MarkerEq> ArcEqIdent<T> for Arc<T> {
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        Arc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        !Arc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Arc<T> {
    /// Kuenzana kwemaviri `Arc`s.
    ///
    /// Maviri `Arc`s akaenzana kana iwo emukati kukosha akaenzana, kunyangwe kana akachengetwa munzvimbo dzakasiyana.
    ///
    /// Kana `T` ichizadzawo `Eq` (zvinoreva kufungidzira kwekuenzana), ma`Arc` maviri anonongedzera kune kugoverwa kwakafanana anogara akaenzana.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five == Arc::new(5));
    /// ```
    ///
    #[inline]
    fn eq(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::eq(self, other)
    }

    /// Kusaenzana kwemaviri `Arc`s.
    ///
    /// Maviri `Arc`s haana kuenzana kana iwo emukati maitiro asina kuenzana.
    ///
    /// Kana `T` ikashandisawo `Eq` (zvichireva kusagadzikana kwekuenzana), ma`Arc` maviri anonongedzera kuhumwechete kukosha haatomboenzana.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five != Arc::new(6));
    /// ```
    #[inline]
    fn ne(&self, other: &Arc<T>) -> bool {
        ArcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Arc<T> {
    /// Kuenzanisa kusarura kwemaviri `Arc`s.
    ///
    /// Ivo vaviri vanofananidzwa nekudana `partial_cmp()` pane yavo yemukati tsika.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Arc::new(6)));
    /// ```
    fn partial_cmp(&self, other: &Arc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Zvishoma-pane kuenzanisa maviri `Arc`s.
    ///
    /// Ivo vaviri vanofananidzwa nekudana `<` pane yavo yemukati tsika.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five < Arc::new(6));
    /// ```
    fn lt(&self, other: &Arc<T>) -> bool {
        *(*self) < *(*other)
    }

    /// 'Zvishoma pane kana zvakaenzana ne' enzaniso yemaviri `Arc`s.
    ///
    /// Ivo vaviri vanofananidzwa nekudana `<=` pane yavo yemukati tsika.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five <= Arc::new(5));
    /// ```
    fn le(&self, other: &Arc<T>) -> bool {
        *(*self) <= *(*other)
    }

    /// Yakakura-kupfuura kuenzanisa maviri `Arc`s.
    ///
    /// Ivo vaviri vanofananidzwa nekudana `>` pane yavo yemukati tsika.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five > Arc::new(4));
    /// ```
    fn gt(&self, other: &Arc<T>) -> bool {
        *(*self) > *(*other)
    }

    /// 'Yakakura kudarika kana yakaenzana ne' enzaniso yemaviri `Arc`s.
    ///
    /// Ivo vaviri vanofananidzwa nekudana `>=` pane yavo yemukati tsika.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert!(five >= Arc::new(5));
    /// ```
    fn ge(&self, other: &Arc<T>) -> bool {
        *(*self) >= *(*other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Arc<T> {
    /// Kufananidza kwemaviri `Arc`s.
    ///
    /// Ivo vaviri vanofananidzwa nekudana `cmp()` pane yavo yemukati tsika.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Arc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Arc::new(6)));
    /// ```
    fn cmp(&self, other: &Arc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Arc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Arc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Arc<T> {
    /// Inogadzira `Arc<T>` nyowani, iine iyo `Default` kukosha kwe `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::sync::Arc;
    ///
    /// let x: Arc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    fn default() -> Arc<T> {
        Arc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Arc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Arc<T> {
    fn from(t: T) -> Self {
        Arc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Arc<[T]> {
    /// Govera chidimbu-chakaverengwa slice uye wochizadza nekubatanidza zvinhu zve`v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Arc<[T]> {
        <Self as ArcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Arc<str> {
    /// Govera chirevo-chakaverengwa `str` uye teedzera `v` mairi.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let shared: Arc<str> = Arc::from("eggplant");
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Arc<str> {
        let arc = Arc::<[u8]>::from(v.as_bytes());
        unsafe { Arc::from_raw(Arc::into_raw(arc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Arc<str> {
    /// Govera chirevo-chakaverengwa `str` uye teedzera `v` mairi.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: String = "eggplant".to_owned();
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Arc<str> {
        Arc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Arc<T> {
    /// Fambisa chinhu chakarongedzwa kune chitsva, chinongedzo-chakaverengwa mugove
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Box<str> = Box::from("eggplant");
    /// let shared: Arc<str> = Arc::from(unique);
    /// assert_eq!("eggplant", &shared[..]);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Arc<T> {
        Arc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Arc<[T]> {
    /// Govera chidimbu chakaverengwa uye fambisa zvinhu zve`v mukati maro.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::sync::Arc;
    /// let unique: Vec<i32> = vec![1, 2, 3];
    /// let shared: Arc<[i32]> = Arc::from(unique);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Arc<[T]> {
        unsafe {
            let arc = Arc::copy_from_slice(&v);

            // Rega iyo Vec isunungure ndangariro yayo, asi kwete kuparadza zvirimo
            v.set_len(0);

            arc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Arc<B>
where
    B: ToOwned + ?Sized,
    Arc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Arc<B> {
        match cow {
            Cow::Borrowed(s) => Arc::from(s),
            Cow::Owned(s) => Arc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Arc<[T]>> for Arc<[T; N]> {
    type Error = Arc<[T]>;

    fn try_from(boxed_slice: Arc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Arc::from_raw(Arc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Arc<[T]> {
    /// Inotora chinhu chimwe nechimwe mu `Iterator` uye ichiiisa mu `Arc<[T]>`.
    ///
    /// # Maitiro ekuita
    ///
    /// ## Nyaya yakajairwa
    ///
    /// Mune kesi yakajairika, kuunganidza mu `Arc<[T]>` kunoitwa nekutanga kuunganidza mune `Vec<T>`.Ndokunge, pakunyora zvinotevera:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// izvi zvinoita sekunge isu takanyora:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Iyo yekutanga seti yezvikamu inoitika pano.
    ///     .into(); // Chikamu chechipiri che `Arc<[T]>` chinoitika pano.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Izvi zvinogovera zvakapetwa kakawanda pazvinodiwa pakuvaka iyo `Vec<T>` uyezve ichagovera kamwe chete yekushandura `Vec<T>` kuita `Arc<[T]>`.
    ///
    ///
    /// ## MaIterator ehurefu hwunozivikanwa
    ///
    /// Kana `Iterator` yako ikashandisa `TrustedLen` uye iri yehukuru chaihwo, mugove mumwe uchaitirwa iyo `Arc<[T]>`.Semuyenzaniso:
    ///
    /// ```rust
    /// # use std::sync::Arc;
    /// let evens: Arc<[u8]> = (0..10).collect(); // Kungopihwa kamwe chete kunoitika pano.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToArcSlice::to_arc_slice(iter.into_iter())
    }
}

/// Nyanzvi trait inoshandiswa kuunganidza mu `Arc<[T]>`.
trait ToArcSlice<T>: Iterator<Item = T> + Sized {
    fn to_arc_slice(self) -> Arc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToArcSlice<T> for I {
    default fn to_arc_slice(self) -> Arc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToArcSlice<T> for I {
    fn to_arc_slice(self) -> Arc<[T]> {
        // Iyi ndiyo kesi yeiyo `TrustedLen` iterator.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // Kachengeteka: Tinofanirwa kuona kuti iterator ine kureba chaiko uye tinayo.
                Arc::from_iter_exact(self, low)
            }
        } else {
            // Dzokera kumashure kuita kwakajairwa.
            self.collect::<Vec<T>>().into()
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Arc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Arc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Arc<T> {}

/// Tora chinogumburwa mukati me `ArcInner` yemubhadharo uri kuseri kwechinongedzo.
///
/// # Safety
///
/// Iyo pointer inofanirwa kunongedzera ku (uye iine metadata inoshanda ye) chiitiko chaimboita cheT, asi iyo T inobvumidzwa kudonhedzwa.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Gadzirisa iyo isina kukosheswa kukosha kusvika kumagumo eArcInner.
    // Nekuti RcBox i repr(C), ichagara iri ndima yekupedzisira mundangariro.
    // KUCHENGETEKA: sezvo iwo chete asina saizi mhando anokwanisika zvidimbu, trait zvinhu,
    // uye mhando dzekunze, iyo yekuchengetedza chengetedzo inodikanwa parizvino yakakwana kuzadzikisa izvo zvinodiwa zve align_of_val_raw;iyi idhisheni yekumisikidza yemutauro uyo ungasavimba nawo kunze kwe std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<ArcInner<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}