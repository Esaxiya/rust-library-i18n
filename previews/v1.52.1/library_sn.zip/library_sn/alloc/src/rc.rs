//! Imwe-yakasungirirwa kunongedzera-kuverenga zvinongedzo.'Rc' inomirira 'Referensi
//! Counted'.
//!
//! Rudzi [`Rc<T>`][`Rc`] runopa muridzi akagovana wekukosha kwerudzi `T`, yakapihwa mumurwi.
//! Inodenha [`clone`][clone] pa [`Rc`] inogadzira nyowani nyowani kune imwecheteyo mugove mumurwi.
//! Kana yekupedzisira [`Rc`] pointer kune yakapihwa mugove yaparadzwa, kukosha kwakachengetwa mune iwo mugove (unowanzo kunzi "inner value") inodonhedzwa.
//!
//! Yakagovaniswa mareferenzi mu Rust isingabvumire shanduko nekukanganisa, uye [`Rc`] haisi iyo yakasarudzika: haugone kuwana chirevo chinoshanduka kuchinhu chiri mukati me [`Rc`].
//! Kana iwe uchida kuchinjika, isa [`Cell`] kana [`RefCell`] mukati me [`Rc`];ona [an example of mutability inside an `Rc`][mutability].
//!
//! [`Rc`] inoshandisa isiri-atomisi kuverenga kuverenga.
//! Izvi zvinoreva kuti pamusoro wakanyanya kuderera, asi [`Rc`] haigone kutumirwa pakati peshinda, uye nekudaro [`Rc`] haiite [`Send`][send].
//! Nekuda kweizvozvo, iyo Rust compiler ichaongorora *panguva yekubatanidza* yausiri kutumira [`Rc`] s pakati peshinda.
//! Kana iwe uchida yakawanda-yakapetwa, kuverenga kweatomu kuverenga, shandisa [`sync::Arc`][arc].
//!
//! Iyo [`downgrade`][downgrade] nzira inogona kushandiswa kugadzira isiri-muridzi [`Weak`] pointer.
//! A [`Weak`] pointer inogona kuva [`kusimudzira`][kusimudzira] d kusvika pa [`Rc`], asi izvi zvinodzosera [`None`] kana kukosha kwakachengetwa mumugove kwatodonhedzwa.
//! Mune mamwe mazwi, `Weak` zvinongedzo hazvichengetedze kukosha mukati mechipo chiri chipenyu;zvisinei, ivo *vanoita* chengetedza mugove (chitoro chekutsigira chemukati kukosha) chiri mupenyu.
//!
//! Kutenderera pakati pe [`Rc`] zvinongedzo hakuzombotamisirwa.
//! Neichi chikonzero, [`Weak`] inoshandiswa kupwanya macircule.
//! Semuenzaniso, muti unogona kuve wakasimba [`Rc`] zvinongedzo kubva kumubereki node kuenda kuvana, uye [`Weak`] zvinongedzo kubva kuvana vadzokera kuvabereki vavo.
//!
//! `Rc<T>` otomatiki anotarisa ku `T` (kuburikidza ne [`Deref`] trait), kuti ugone kudaidza nzira dze`T` pakukosha kwerudzi [`Rc<T>`][`Rc`].
//! Kuti udzivise kupokana kwezita nemaitiro aT, nzira dze [`Rc<T>`][`Rc`] pachadzo dzakabatana mabasa, anonzi kushandisa [fully qualified syntax]:
//!
//! ```
//! use std::rc::Rc;
//!
//! let my_rc = Rc::new(());
//! Rc::downgrade(&my_rc);
//! ```
//!
//! `Rc<T>kumisikidza kwe traits senge `Clone` inogona kudaidzwa zvakare ichishandisa zvakakwana syntax.
//! Vamwe vanhu vanosarudza kushandisa syntax yakakwana, nepo vamwe vachida kushandisa syntax yekufona.
//!
//! ```
//! use std::rc::Rc;
//!
//! let rc = Rc::new(());
//! // Maitiro-kufona syntax
//! let rc2 = rc.clone();
//! // Yakakwana syntax
//! let rc3 = Rc::clone(&rc);
//! ```
//!
//! [`Weak<T>`][`Weak`] haina auto-dereferesi kune `T`, nekuti iyo yemukati kukosha inogona kunge yatodonhedzwa.
//!
//! # Kuumba mareferensi
//!
//! Kugadzira chirevo chitsva kune kugoverwa kwakafanana seye iripo chirevo chakaverengwa pointer kunoitwa uchishandisa `Clone` trait yakaitirwa [`Rc<T>`][`Rc`] uye [`Weak<T>`][`Weak`].
//!
//!
//! ```
//! use std::rc::Rc;
//!
//! let foo = Rc::new(vec![1.0, 2.0, 3.0]);
//! // Aya ma syntaxes pazasi akaenzana.
//! let a = foo.clone();
//! let b = Rc::clone(&foo);
//! // a uye b zvese zvinonongedzera kunzvimbo imwechete yekurangarira sa foo.
//! ```
//!
//! Iyo `Rc::clone(&from)` syntax ndiyo inonyanya kusanzwisisika nekuti inoburitsa zvakajeka zvinorehwa nekodhi.
//! Mumuenzaniso uri pamusoro, iyi syntax inoita kuti zvive nyore kuona kuti kodhi iyi iri kugadzira referensi nyowani pane kutevedzera zvese zvirimo zve foo.
//!
//! # Examples
//!
//! Chimbofunga mamiriro ezvinhu apo seti ye`Gadget`s ndeyayo yakapihwa `Owner`.
//! Isu tinoda kuve neyedu `Gadget`inongedzera kune yavo `Owner`.Hatigone kuita izvi nehunhu hwakasarudzika, nekuti anopfuura gadget rimwe chete anogona kunge ari e `Owner` imwechete.
//! [`Rc`] inotibvumidza kugovana `Owner` pakati pezvakawanda `Gadget`s, uye ita kuti `Owner` igare yakapihwa chero chero ma `Gadget` poindi pairi.
//!
//! ```
//! use std::rc::Rc;
//!
//! struct Owner {
//!     name: String,
//!     // ... mimwe minda
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... mimwe minda
//! }
//!
//! fn main() {
//!     // Gadzira chirevo-chakaverengwa `Owner`.
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!         }
//!     );
//!
//!     // Gadzira `Gadget`s zviri zve `gadget_owner`.
//!     // Kubatanidza iyo `Rc<Owner>` kunotipa iyo nyowani nyowani kune imwecheteyo `Owner` mugove, kuwedzera iyo mareferensi kuverenga mune iyi nzira.
//!     //
//!     let gadget1 = Gadget {
//!         id: 1,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!     let gadget2 = Gadget {
//!         id: 2,
//!         owner: Rc::clone(&gadget_owner),
//!     };
//!
//!     // Bvisa yedu yemunharaunda inoshanduka `gadget_owner`.
//!     drop(gadget_owner);
//!
//!     // Kunyangwe tichidonhedza `gadget_owner`, isu tichiri kukwanisa kupurinda zita re `Owner` ye`Gadget`s.
//!     // Izvi zvinodaro nekuti isu takangodonhedza imwe chete `Rc<Owner>`, kwete iyo `Owner` yainongedzera.
//!     // Chero bedzi paine mamwe ma `Rc<Owner>` anonongedzera kuichi chikamu chakafanana che `Owner`, inoramba ichirarama.
//!     // Iyo yekufungidzira yemunda `gadget1.owner.name` inoshanda nekuti `Rc<Owner>` inozvitarisa yega ku `Owner`.
//!     //
//!     //
//!     println!("Gadget {} owned by {}", gadget1.id, gadget1.owner.name);
//!     println!("Gadget {} owned by {}", gadget2.id, gadget2.owner.name);
//!
//!     // Pakupera kwebasa, `gadget1` uye `gadget2` zvaparadzwa, uye pamwe chete nazvo mareferensi ekupedzisira akaverengwa ku `Owner` yedu.
//!     // Gadget Man ikozvino inoparadzwa futi.
//!     //
//! }
//! ```
//!
//! Kana zvatinoda zvikachinja, uye tichidawo kukwanisa kuyambuka kubva ku `Owner` kuenda ku `Gadget`, tinosangana nematambudziko.
//! Iyo [`Rc`] pointer kubva ku `Owner` kusvika `Gadget` inosvitsa kutenderera.
//! Izvi zvinoreva kuti yavo mareferensi kuverenga haangatombosvika pa0, uye kupihwa kwacho hakuzomboparadzwa:
//! ndangariro inodonha.Kuti titenderedze izvi, tinogona kushandisa zvinongedzo zve [`Weak`].
//!
//! Rust chaizvo zvinoita kuti zvive zvakaoma kuburitsa chiuno ichi pakutanga.Kuti upedze nemhando mbiri dzinonongedzera kune imwe, imwe yacho inoda kutendeuka.
//! Izvi zvakaoma nekuti [`Rc`] inosimudzira kuchengetedzwa kwendangariro nekungopa chete mareferenzi akagovaniswa kune kukosha kwainoputira, uye izvi hazvibvumidze kutendeuka kwakananga.
//! Tinofanirwa kuputira chikamu chemutengo watinoshuvira kuchinja mu [`RefCell`], iyo inopa *mukati kugadzikana*: nzira yekuzadzikisa shanduko kuburikidza neyakagovaniswa mareferensi.
//! [`RefCell`] inosimbisa iyo Rust yekukwereta mitemo panguva yekumhanya.
//!
//! ```
//! use std::rc::Rc;
//! use std::rc::Weak;
//! use std::cell::RefCell;
//!
//! struct Owner {
//!     name: String,
//!     gadgets: RefCell<Vec<Weak<Gadget>>>,
//!     // ... mimwe minda
//! }
//!
//! struct Gadget {
//!     id: i32,
//!     owner: Rc<Owner>,
//!     // ... mimwe minda
//! }
//!
//! fn main() {
//!     // Gadzira chirevo-chakaverengwa `Owner`.
//!     // Ziva kuti taisa `Muridzi'vector ye`Gadget`s mukati me `RefCell` kuti tigone kuichinjisa kuburikidza neyakagovaniswa mareferenzi.
//!     //
//!     let gadget_owner: Rc<Owner> = Rc::new(
//!         Owner {
//!             name: "Gadget Man".to_string(),
//!             gadgets: RefCell::new(vec![]),
//!         }
//!     );
//!
//!     // Gadzira `Gadget`s zviri zve `gadget_owner`, sepakutanga.
//!     let gadget1 = Rc::new(
//!         Gadget {
//!             id: 1,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!     let gadget2 = Rc::new(
//!         Gadget {
//!             id: 2,
//!             owner: Rc::clone(&gadget_owner),
//!         }
//!     );
//!
//!     // Wedzera `Gadget`s kune yavo `Owner`.
//!     {
//!         let mut gadgets = gadget_owner.gadgets.borrow_mut();
//!         gadgets.push(Rc::downgrade(&gadget1));
//!         gadgets.push(Rc::downgrade(&gadget2));
//!
//!         // `RefCell` simba kukwereta kunopera pano.
//!     }
//!
//!     // Iterate pamusoro pedu `Gadget`s, tichiprinta ruzivo rwavo kunze.
//!     for gadget_weak in gadget_owner.gadgets.borrow().iter() {
//!
//!         // `gadget_weak` iri `Weak<Gadget>`.
//!         // Sezvo ma `Weak` anonongedza asingakwanise kuvimbisa kuti kugovera kuchiripo, tinoda kufonera `upgrade`, iyo inodzosera `Option<Rc<Gadget>>`.
//!         //
//!         //
//!         // Mune ino kesi isu tinoziva kuti kugoverwa kuchiripo, saka isu tinongori `unwrap` iyo `Option`.
//!         // Mune chirongwa chakaomesesa, ungangoda nyasha yekukanganisa kubata kwe `None` mhedzisiro.
//!         //
//!
//!         let gadget = gadget_weak.upgrade().unwrap();
//!         println!("Gadget {} owned by {}", gadget.id, gadget.owner.name);
//!     }
//!
//!     // Pakupera kwebasa, `gadget_owner`, `gadget1`, uye `gadget2` zvinoparadzwa.
//!     // Ikozvino hapana yakasimba (`Rc`) anonongedzera kumagajeti, saka ivo vanoparadzwa.
//!     // Aya zeroes mareferensi akaverenga paGadget Man, saka anoparadzwa futi.
//!     //
//! }
//! ```
//!
//! [clone]: Clone::clone
//! [`Cell`]: core::cell::Cell
//! [`RefCell`]: core::cell::RefCell
//! [send]: core::marker::Send
//! [arc]: crate::sync::Arc
//! [`Deref`]: core::ops::Deref
//! [downgrade]: Rc::downgrade
//! [upgrade]: Weak::upgrade
//! [mutability]: core::cell#introducing-mutability-inside-of-something-immutable
//! [fully qualified syntax]: https://doc.rust-lang.org/book/ch19-03-advanced-traits.html#fully-qualified-syntax-for-disambiguation-calling-methods-with-the-same-name
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[cfg(not(test))]
use crate::boxed::Box;
#[cfg(test)]
use std::boxed::Box;

use core::any::Any;
use core::borrow;
use core::cell::Cell;
use core::cmp::Ordering;
use core::convert::{From, TryFrom};
use core::fmt;
use core::hash::{Hash, Hasher};
use core::intrinsics::abort;
use core::iter;
use core::marker::{self, PhantomData, Unpin, Unsize};
use core::mem::{self, align_of_val_raw, forget, size_of_val};
use core::ops::{CoerceUnsized, Deref, DispatchFromDyn, Receiver};
use core::pin::Pin;
use core::ptr::{self, NonNull};
use core::slice::from_raw_parts_mut;

use crate::alloc::{
    box_free, handle_alloc_error, AllocError, Allocator, Global, Layout, WriteCloneIntoRaw,
};
use crate::borrow::{Cow, ToOwned};
use crate::string::String;
use crate::vec::Vec;

#[cfg(test)]
mod tests;

// Iyi i repr(C) kusvika future-proof inopesana neinogona kuita munda-kugadzirisa zvekare, izvo zvinokanganisa neimwe yakachengeteka [into|from]_raw() yemhando dzinopfuudzwa dzemukati.
//
//
#[repr(C)]
struct RcBox<T: ?Sized> {
    strong: Cell<usize>,
    weak: Cell<usize>,
    value: T,
}

/// Imwe-yakamisikidzwa-yekuverenga-yekuverenga pointer.'Rc' inomirira 'Referensi
/// Counted'.
///
/// Ona iyo [module-level documentation](./index.html) kuti uwane rumwe ruzivo.
///
/// Maitiro ekuzvarwa nawo e `Rc` ese anoshanda mabasa, zvinoreva kuti unofanirwa kuvadaidza semuenzaniso, [`Rc::get_mut(&mut value)`][get_mut] pachinzvimbo che `value.get_mut()`.
/// Izvi zvinodzivirira kupokana nenzira dzerudzi rwemukati `T`.
///
/// [get_mut]: Rc::get_mut
///
#[cfg_attr(not(test), rustc_diagnostic_item = "Rc")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Rc<T: ?Sized> {
    ptr: NonNull<RcBox<T>>,
    phantom: PhantomData<RcBox<T>>,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Send for Rc<T> {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !marker::Sync for Rc<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Rc<U>> for Rc<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Rc<U>> for Rc<T> {}

impl<T: ?Sized> Rc<T> {
    #[inline(always)]
    fn inner(&self) -> &RcBox<T> {
        // Uku kusagadzikana kwakanaka nekuti nepo Rc iri mupenyu isu takavimbiswa kuti pointer yemukati inoshanda.
        //
        unsafe { self.ptr.as_ref() }
    }

    fn from_inner(ptr: NonNull<RcBox<T>>) -> Self {
        Self { ptr, phantom: PhantomData }
    }

    unsafe fn from_ptr(ptr: *mut RcBox<T>) -> Self {
        Self::from_inner(unsafe { NonNull::new_unchecked(ptr) })
    }
}

impl<T> Rc<T> {
    /// Inovaka `Rc<T>` nyowani.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn new(value: T) -> Rc<T> {
        // Iko kune isina kusimba pointer muridzi weayo ese akasimba anonongedzera, izvo zvinovimbisa kuti asina kusimba muparadzi haatombo sununura mugove apa musimba muparadzi ari kumhanya, kunyangwe iyo isina kusimba pointer yakachengetwa mukati meiyo yakasimba iyo.
        //
        //
        //
        Self::from_inner(
            Box::leak(box RcBox { strong: Cell::new(1), weak: Cell::new(1), value }).into(),
        )
    }

    /// Inogadzira `Rc<T>` nyowani ichishandisa isina kusimba mareferenzi pachayo.
    /// Kuedza kukwidziridza isina kusimba mareferensi basa iri risati radzoka kunoguma ne `None` kukosha.
    ///
    /// Nekudaro, iyo isina kusimba mareferenzi inogona kuumbirwa zvakasununguka uye kuchengetwa kuti ishandiswe pane inotevera nguva.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(arc_new_cyclic)]
    /// #![allow(dead_code)]
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Gadget {
    ///     self_weak: Weak<Self>,
    ///     // ... mimwe minda
    /// }
    /// impl Gadget {
    ///     pub fn new() -> Rc<Self> {
    ///         Rc::new_cyclic(|self_weak| {
    ///             Gadget { self_weak: self_weak.clone(), /* ... */ }
    ///         })
    ///     }
    /// }
    /// ```
    #[unstable(feature = "arc_new_cyclic", issue = "75861")]
    pub fn new_cyclic(data_fn: impl FnOnce(&Weak<T>) -> T) -> Rc<T> {
        // Gadzira zvemukati mudunhu re "uninitialized" uine chirevo chimwe chisina kusimba.
        //
        let uninit_ptr: NonNull<_> = Box::leak(box RcBox {
            strong: Cell::new(0),
            weak: Cell::new(1),
            value: mem::MaybeUninit::<T>::uninit(),
        })
        .into();

        let init_ptr: NonNull<RcBox<T>> = uninit_ptr.cast();

        let weak = Weak { ptr: init_ptr };

        // Izvo zvakakosha kuti isu tirege kuve varidzi veisina kusimba pointer, kana zvisina kudaro ndangariro inogona kusunungurwa nenguva iyo `data_fn` inodzoka.
        // Kana isu tichinyatsoda kupfuura muridzi, tinogona kuzvigadzirira yakawedzera pointer pachedu, asi izvi zvinoguma nekuwedzeredzwa kune isina kusimba mareferensi kuverenga izvo zvingangodaro zvisina kudikanwa neimwe nzira.
        //
        //
        //
        //
        let data = data_fn(&weak);

        unsafe {
            let inner = init_ptr.as_ptr();
            ptr::write(ptr::addr_of_mut!((*inner).value), data);

            let prev_value = (*inner).strong.get();
            debug_assert_eq!(prev_value, 0, "No prior strong references should exist");
            (*inner).strong.set(1);
        }

        let strong = Rc::from_inner(init_ptr);

        // Mareferenzi akasimba anofanirwa pamwechete kuve neakagovana isina kusimba mareferensi, saka usamhanyisa anoparadza renhoroondo yedu isina simba
        //
        mem::forget(weak);
        strong
    }

    /// Inovaka `Rc` nyowani nezvisina kunyorwa zvirimo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Kutanga kusarudzika:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Inovaka `Rc` nyowani nezvisina kuvhurwa zvirimo, ndangariro dzichizadzwa ne `0` byte.
    ///
    ///
    /// Ona [`MaybeUninit::zeroed`][zeroed] yemienzaniso yekushandisa nenzira kwayo uye isiriyo iyi nzira.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed() -> Rc<mem::MaybeUninit<T>> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            ))
        }
    }

    /// Inovaka `Rc<T>` nyowani, ichidzosera kukanganisa kana mugove ukatadza
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use std::rc::Rc;
    ///
    /// let five = Rc::try_new(5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn try_new(value: T) -> Result<Rc<T>, AllocError> {
        // Iko kune isina kusimba pointer muridzi weayo ese akasimba anonongedzera, izvo zvinovimbisa kuti asina kusimba muparadzi haatombo sununura mugove apa musimba muparadzi ari kumhanya, kunyangwe iyo isina kusimba pointer yakachengetwa mukati meiyo yakasimba iyo.
        //
        //
        //
        Ok(Self::from_inner(
            Box::leak(Box::try_new(RcBox { strong: Cell::new(1), weak: Cell::new(1), value })?)
                .into(),
        ))
    }

    /// Inovaka `Rc` nyowani nezvisina kunyorwa zvirimo, ichidzosera kukanganisa kana mugove ukatadza
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::try_new_uninit()?;
    ///
    /// let five = unsafe {
    ///     // Kutanga kusarudzika:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_uninit() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }

    /// Inovaka `Rc` nyowani nezvisina kunyorwa zvirimo, ndangariro dzichizadzwa ne `0` byte, ichidzosera kukanganisa kana mugove uchitadza
    ///
    ///
    /// Ona [`MaybeUninit::zeroed`][zeroed] yemienzaniso yekushandisa nenzira kwayo uye isiriyo iyi nzira.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api, new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let zero = Rc::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "allocator_api", issue = "32838")]
    // #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn try_new_zeroed() -> Result<Rc<mem::MaybeUninit<T>>, AllocError> {
        unsafe {
            Ok(Rc::from_ptr(Rc::try_allocate_for_layout(
                Layout::new::<T>(),
                |layout| Global.allocate_zeroed(layout),
                |mem| mem as *mut RcBox<mem::MaybeUninit<T>>,
            )?))
        }
    }
    /// Inovaka `Pin<Rc<T>>` nyowani.
    /// Kana `T` isingaite `Unpin`, ipapo `value` ichapendwa mundangariro uye isingakwanise kufambiswa.
    #[stable(feature = "pin", since = "1.33.0")]
    pub fn pin(value: T) -> Pin<Rc<T>> {
        unsafe { Pin::new_unchecked(Rc::new(value)) }
    }

    /// Inodzorera iyo yemukati kukosha, kana iyo `Rc` iine chaiyo imwechete yakasimba referensi.
    ///
    /// Zvikasadaro, [`Err`] inodzoserwa neiyo imwechete `Rc` iyo yakapfuudzwa mukati.
    ///
    ///
    /// Izvi zvichabudirira kunyangwe paine mareferenzi asina kusimba mareferenzi.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new(3);
    /// assert_eq!(Rc::try_unwrap(x), Ok(3));
    ///
    /// let x = Rc::new(4);
    /// let _y = Rc::clone(&x);
    /// assert_eq!(*Rc::try_unwrap(x).unwrap_err(), 4);
    /// ```
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn try_unwrap(this: Self) -> Result<T, Self> {
        if Rc::strong_count(&this) == 1 {
            unsafe {
                let val = ptr::read(&*this); // teedzera chinhu chirimo

                // Ratidza kune Vasina simba kuti havagone kusimudzirwa nekuderedza huwandu hwakasimba, uyezve bvisa iyo yakajeka "strong weak" pointer ukuwo uchibata pfungwa yekudonha nekungogadzira Fake Fake.
                //
                //
                //
                this.inner().dec_strong();
                let _weak = Weak { ptr: this.ptr };
                forget(this);
                Ok(val)
            }
        } else {
            Err(this)
        }
    }
}

impl<T> Rc<[T]> {
    /// Inovaka chidimbu chitsva-chakaverengwa chidimbu nezvisina kuiswa mukati.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Kutanga kusarudzika:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_uninit_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe { Rc::from_ptr(Rc::allocate_for_slice(len)) }
    }

    /// Inovaka chidimbu chitsva-chakaverengwa slice nezvisina kuvhurwa zvirimo, ndangariro dzichizadzwa ne `0` byte.
    ///
    ///
    /// Ona [`MaybeUninit::zeroed`][zeroed] yemienzaniso yekushandisa nenzira kwayo uye isiriyo iyi nzira.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    ///
    /// use std::rc::Rc;
    ///
    /// let values = Rc::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    pub fn new_zeroed_slice(len: usize) -> Rc<[mem::MaybeUninit<T>]> {
        unsafe {
            Rc::from_ptr(Rc::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate_zeroed(layout),
                |mem| {
                    ptr::slice_from_raw_parts_mut(mem as *mut T, len)
                        as *mut RcBox<[mem::MaybeUninit<T>]>
                },
            ))
        }
    }
}

impl<T> Rc<mem::MaybeUninit<T>> {
    /// Inotendeuka kuenda ku `Rc<T>`.
    ///
    /// # Safety
    ///
    /// Sezvo ne [`MaybeUninit::assume_init`], zviri kune iye anofona kuti ave nechokwadi chekuti kukosha kwemukati kuri muchinzvimbo chakatangwa.
    ///
    /// Kufonera izvi kana zvirimo zvisati zvatanga zvizere zvinokonzeresa kusanzwisisika maitiro.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut five = Rc::<u32>::new_uninit();
    ///
    /// let five = unsafe {
    ///     // Kutanga kusarudzika:
    ///     Rc::get_mut_unchecked(&mut five).as_mut_ptr().write(5);
    ///
    ///     five.assume_init()
    /// };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<T> {
        Rc::from_inner(mem::ManuallyDrop::new(self).ptr.cast())
    }
}

impl<T> Rc<[mem::MaybeUninit<T>]> {
    /// Inotendeuka kuenda ku `Rc<[T]>`.
    ///
    /// # Safety
    ///
    /// Sezvo ne [`MaybeUninit::assume_init`], zviri kune iye anofona kuti ave nechokwadi chekuti kukosha kwemukati kuri muchinzvimbo chakatangwa.
    ///
    /// Kufonera izvi kana zvirimo zvisati zvatanga zvizere zvinokonzeresa kusanzwisisika maitiro.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(new_uninit)]
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut values = Rc::<[u32]>::new_uninit_slice(3);
    ///
    /// let values = unsafe {
    ///     // Kutanga kusarudzika:
    ///     Rc::get_mut_unchecked(&mut values)[0].as_mut_ptr().write(1);
    ///     Rc::get_mut_unchecked(&mut values)[1].as_mut_ptr().write(2);
    ///     Rc::get_mut_unchecked(&mut values)[2].as_mut_ptr().write(3);
    ///
    ///     values.assume_init()
    /// };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    ///
    ///
    #[unstable(feature = "new_uninit", issue = "63291")]
    #[inline]
    pub unsafe fn assume_init(self) -> Rc<[T]> {
        unsafe { Rc::from_ptr(mem::ManuallyDrop::new(self).ptr.as_ptr() as _) }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Inoshandisa iyo `Rc`, ichidzorera iyo yakaputirwa pointer.
    ///
    /// Kuti udzivise kuyeuka kwekurangarira iyo pointer inofanirwa kushandurwa ive `Rc` uchishandisa [`Rc::from_raw`][from_raw].
    ///
    ///
    /// [from_raw]: Rc::from_raw
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub fn into_raw(this: Self) -> *const T {
        let ptr = Self::as_ptr(&this);
        mem::forget(this);
        ptr
    }

    /// Inopa pointer mbishi kune iyo data.
    ///
    /// Huwandu hahukanganisirwe munzira ipi neipi uye iyo `Rc` haina kudyiwa.
    /// Iyo pointer inoshanda chero bedzi paine zviyero zvine simba mu `Rc`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let y = Rc::clone(&x);
    /// let x_ptr = Rc::as_ptr(&x);
    /// assert_eq!(x_ptr, Rc::as_ptr(&y));
    /// assert_eq!(unsafe { &*x_ptr }, "hello");
    /// ```
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn as_ptr(this: &Self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(this.ptr);

        // Kachengeteka: Izvi hazvigone kupfuura Deref::deref kana Rc::inner nekuti
        // izvi zvinotarisirwa kuchengetedza raw/mut provenance yakadai eg
        // `get_mut` unogona kunyora kuburikidza nechinongedzo mushure mekunge iyo Rc yadzoreredzwa kuburikidza ne `from_raw`.
        unsafe { ptr::addr_of_mut!((*ptr).value) }
    }

    /// Inogadzira `Rc<T>` kubva kune yakasviba pointer.
    ///
    /// Iyo poindi mbishi inofanirwa kunge yakambodzoserwa nekufona ku [`Rc<U>::into_raw`][into_raw] uko `U` inofanira kunge iine saizi yakafanana uye kuenderana se `T`.
    /// Izvi ichokwadi zvishoma kana `U` iri `T`.
    /// Ziva kuti kana `U` isiri `T` asi iine saizi yakaenzana uye kuenderana, izvi zvakangofanana nekutenderera mareferenzi emhando dzakasiyana.
    /// Ona [`mem::transmute`][transmute] kuti uwane rumwe ruzivo nezve izvo zvinorambidzwa pano.
    ///
    /// Mushandisi we `from_raw` anofanirwa kuona kuti chakakosha kukosha kwe `T` chinongodonhedzwa kamwe chete.
    ///
    /// Iri basa harina kuchengeteka nekuti kushandiswa zvisirizvo kunogona kutungamira mukusagadzikana kwendangariro, kunyangwe iyo `Rc<T>` yakadzoserwa isingawanikwe.
    ///
    /// [into_raw]: Rc::into_raw
    /// [transmute]: core::mem::transmute
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x = Rc::new("hello".to_owned());
    /// let x_ptr = Rc::into_raw(x);
    ///
    /// unsafe {
    ///     // Chinja kudzokera ku `Rc` kudzivirira kubuda.
    ///     let x = Rc::from_raw(x_ptr);
    ///     assert_eq!(&*x, "hello");
    ///
    ///     // Kuenderera mberi kwekufona ku `Rc::from_raw(x_ptr)` kwaizove kurangarira-kusachengeteka.
    /// }
    ///
    /// // Ndangariro dzakasunungurwa `x` payakabuda pachiyero pamusoro, saka `x_ptr` yava kuturika!
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rc_raw", since = "1.17.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        let offset = unsafe { data_offset(ptr) };

        // Dzorerazve kukanganisa kuti uwane yekutanga RcBox.
        let rc_ptr =
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) };

        unsafe { Self::from_ptr(rc_ptr) }
    }

    /// Inogadzira nyowani [`Weak`] pointer kune ichi chikamu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn downgrade(this: &Self) -> Weak<T> {
        this.inner().inc_weak();
        // Ita shuwa kuti isu hatigadzi inorembera Inoshaya simba
        debug_assert!(!is_dangling(this.ptr.as_ptr()));
        Weak { ptr: this.ptr }
    }

    /// Inowana iyo nhamba ye [`Weak`] zvinongedzo kune ichi chikamu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _weak_five = Rc::downgrade(&five);
    ///
    /// assert_eq!(1, Rc::weak_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn weak_count(this: &Self) -> usize {
        this.inner().weak() - 1
    }

    /// Inowana iyo nhamba yeakasimba (`Rc`) anongedzera kune ichi chikamu.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let _also_five = Rc::clone(&five);
    ///
    /// assert_eq!(2, Rc::strong_count(&five));
    /// ```
    #[inline]
    #[stable(feature = "rc_counts", since = "1.15.0")]
    pub fn strong_count(this: &Self) -> usize {
        this.inner().strong()
    }

    /// Inodzorera `true` kana pasina imwe `Rc` kana [`Weak`] zvinongedzo kune ichi chikamu.
    ///
    #[inline]
    fn is_unique(this: &Self) -> bool {
        Rc::weak_count(this) == 0 && Rc::strong_count(this) == 1
    }

    /// Inodzorera chinongedzo chinoshandurwa mune yakapihwa `Rc`, kana pasina imwe `Rc` kana [`Weak`] zvinongedzo kune zvakafanana kugoverwa.
    ///
    ///
    /// Inodzorera [`None`] neimwe nzira, nekuti hazvina kuchengetedzeka kuchinjisa kukosha kwakagovaniswa.
    ///
    /// Onawo [`make_mut`][make_mut], inova [`clone`][clone] kukosha kwemukati kana paine zvimwe zvinongedzo.
    ///
    /// [make_mut]: Rc::make_mut
    /// [clone]: Clone::clone
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(3);
    /// *Rc::get_mut(&mut x).unwrap() = 4;
    /// assert_eq!(*x, 4);
    ///
    /// let _y = Rc::clone(&x);
    /// assert!(Rc::get_mut(&mut x).is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        if Rc::is_unique(this) { unsafe { Some(Rc::get_mut_unchecked(this)) } } else { None }
    }

    /// Inodzorera zvinogona kuchinjika mune yakapihwa `Rc`, pasina cheki.
    ///
    /// Onawo [`get_mut`], iri yakachengeteka uye inoita yakakodzera macheki.
    ///
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Safety
    ///
    /// Chero ipi imwe `Rc` kana [`Weak`] zvinongedzera kune zvakafanana kugoverwa hazvifanire kuratidzwa kwenguva iyo yakadzorerwa chikwereti.
    ///
    /// Izvi zvishoma kesi kana pasina zvinongedzo zvakadaro, semuenzaniso nekukurumidza mushure me `Rc::new`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(get_mut_unchecked)]
    ///
    /// use std::rc::Rc;
    ///
    /// let mut x = Rc::new(String::new());
    /// unsafe {
    ///     Rc::get_mut_unchecked(&mut x).push_str("foo")
    /// }
    /// assert_eq!(*x, "foo");
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "get_mut_unchecked", issue = "63292")]
    pub unsafe fn get_mut_unchecked(this: &mut Self) -> &mut T {
        // Isu takangwarira *kwete* kugadzira rejista inovhara iyo "count" minda, sezvo izvi zvichipesana nekuwana kune zvinongedzo kuverenga (semuenzaniso.
        // ne `Weak`).
        unsafe { &mut (*this.ptr.as_ptr()).value }
    }

    #[inline]
    #[stable(feature = "ptr_eq", since = "1.17.0")]
    /// Inodzorera `true` kana ma`Rc` maviri achinongedzera kumugove wakafanana (mutsinga yakafanana ne [`ptr::eq`]).
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    /// let same_five = Rc::clone(&five);
    /// let other_five = Rc::new(5);
    ///
    /// assert!(Rc::ptr_eq(&five, &same_five));
    /// assert!(!Rc::ptr_eq(&five, &other_five));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        this.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

impl<T: Clone> Rc<T> {
    /// Inoita chirevo chinoshandurwa mune yakapihwa `Rc`.
    ///
    /// Kana paine zvimwe zvinongedzo zve `Rc` kune kugoverwa kumwe chete, saka `make_mut` ichaita [`clone`] kukosha kwemukati kuchikamu chitsva chekuona wega muridzi.
    /// Izvi zvinonziwo se clone-on-write.
    ///
    /// Kana pasina zvimwe zvinongedzo zve `Rc` kune ichi chikamu, saka ma [`Weak`] anonongedzera kune ichi chikamu achave akaparadzaniswa.
    ///
    /// Onawo [`get_mut`], inozokundikana pane kuumbana.
    ///
    /// [`clone`]: Clone::clone
    /// [`get_mut`]: Rc::get_mut
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(5);
    ///
    /// *Rc::make_mut(&mut data) += 1;        // Hapana chaunonamira
    /// let mut other_data = Rc::clone(&data);    // Haizofananidza data remukati
    /// *Rc::make_mut(&mut data) += 1;        // Clones data remukati
    /// *Rc::make_mut(&mut data) += 1;        // Hapana chaunonamira
    /// *Rc::make_mut(&mut other_data) *= 2;  // Hapana chaunonamira
    ///
    /// // Iye zvino `data` uye `other_data` vanongedzera kune akasiyana magovaniswa.
    /// assert_eq!(*data, 8);
    /// assert_eq!(*other_data, 12);
    /// ```
    ///
    /// [`Weak`] zvinongedzo zvichabviswa:
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let mut data = Rc::new(75);
    /// let weak = Rc::downgrade(&data);
    ///
    /// assert!(75 == *data);
    /// assert!(75 == *weak.upgrade().unwrap());
    ///
    /// *Rc::make_mut(&mut data) += 1;
    ///
    /// assert!(76 == *data);
    /// assert!(weak.upgrade().is_none());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rc_unique", since = "1.4.0")]
    pub fn make_mut(this: &mut Self) -> &mut T {
        if Rc::strong_count(this) != 1 {
            // Wakatora dhata, kune mamwe maRcs.
            // Pre-govera ndangariro kubvumidza kunyora iyo yakasanganiswa kukosha zvakananga.
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                (**this).write_clone_into_raw(data.as_mut_ptr());
                *this = rc.assume_init();
            }
        } else if Rc::weak_count(this) != 0 {
            // Unogona kungoba iyo data, zvese zvasara ndeye Weaks
            let mut rc = Self::new_uninit();
            unsafe {
                let data = Rc::get_mut_unchecked(&mut rc);
                data.as_mut_ptr().copy_from_nonoverlapping(&**this, 1);

                this.inner().dec_strong();
                // Bvisa chose chakasimba-chisina simba ref (hapana chikonzero chekugadzira chisina kusimba Weak pano-tinoziva mamwe maWeaks anogona kutichenesa)
                //
                this.inner().dec_weak();
                ptr::write(this, rc.assume_init());
            }
        }
        // Uku kusagadzikana kwakanaka nekuti isu takavimbiswa kuti pointer yakadzoserwa ndiyo *chete* pointer inombodzoserwa kuna T.
        // Yedu mareferensi kuverenga inovimbiswa kuve 1 panguva ino, uye isu taida iyo `Rc<T>` pachayo kuve `mut`, saka tiri kudzorera chete inogona kuitirwa mareferenzi kune kugoverwa.
        //
        //
        //
        unsafe { &mut this.ptr.as_mut().value }
    }
}

impl Rc<dyn Any> {
    #[inline]
    #[stable(feature = "rc_downcast", since = "1.29.0")]
    /// Kuedza kudzikisira `Rc<dyn Any>` kune yekongiri mhando.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::any::Any;
    /// use std::rc::Rc;
    ///
    /// fn print_if_string(value: Rc<dyn Any>) {
    ///     if let Ok(string) = value.downcast::<String>() {
    ///         println!("String ({}): {}", string.len(), string);
    ///     }
    /// }
    ///
    /// let my_string = "Hello World".to_string();
    /// print_if_string(Rc::new(my_string));
    /// print_if_string(Rc::new(0i8));
    /// ```
    pub fn downcast<T: Any>(self) -> Result<Rc<T>, Rc<dyn Any>> {
        if (*self).is::<T>() {
            let ptr = self.ptr.cast::<RcBox<T>>();
            forget(self);
            Ok(Rc::from_inner(ptr))
        } else {
            Err(self)
        }
    }
}

impl<T: ?Sized> Rc<T> {
    /// Inogovanisa `RcBox<T>` ine nzvimbo yakakwana yeinogona kunge isina-saizi yemukati kukosha uko kukosha kune dhizaini yakapihwa.
    ///
    /// Basa `mem_to_rcbox` inodaidzwa neinongedzo yedata uye rinofanira kudzosa (inogona mafuta) pointer ye `RcBox<T>`.
    ///
    ///
    unsafe fn allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> *mut RcBox<T> {
        // Verenga marongerwo uchishandisa iyo yakapihwa kukosha dhizaini.
        // Pakutanga, dhizaini yaiverengerwa pane chirevo `&*(ptr as* const RcBox<T>)`, asi izvi zvakagadzira zvisirizvo mareferenzi (ona #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();
        unsafe {
            Rc::try_allocate_for_layout(value_layout, allocate, mem_to_rcbox)
                .unwrap_or_else(|_| handle_alloc_error(layout))
        }
    }

    /// Inogovanisa `RcBox<T>` ine nzvimbo yakakwana yeinogona kunge isina-saizi yemukati kukosha uko kukosha kune dhizaini yakapihwa, kudzorera kukanganisa kana mugove ukatadza.
    ///
    ///
    /// Basa `mem_to_rcbox` inodaidzwa neinongedzo yedata uye rinofanira kudzosa (inogona mafuta) pointer ye `RcBox<T>`.
    ///
    ///
    #[inline]
    unsafe fn try_allocate_for_layout(
        value_layout: Layout,
        allocate: impl FnOnce(Layout) -> Result<NonNull<[u8]>, AllocError>,
        mem_to_rcbox: impl FnOnce(*mut u8) -> *mut RcBox<T>,
    ) -> Result<*mut RcBox<T>, AllocError> {
        // Verenga marongerwo uchishandisa iyo yakapihwa kukosha dhizaini.
        // Pakutanga, dhizaini yaiverengerwa pane chirevo `&*(ptr as* const RcBox<T>)`, asi izvi zvakagadzira zvisirizvo mareferenzi (ona #54908).
        //
        //
        let layout = Layout::new::<RcBox<()>>().extend(value_layout).unwrap().0.pad_to_align();

        // Govera iro dhizaini.
        let ptr = allocate(layout)?;

        // Kutanga iyo RcBox
        let inner = mem_to_rcbox(ptr.as_non_null_ptr().as_ptr());
        unsafe {
            debug_assert_eq!(Layout::for_value(&*inner), layout);

            ptr::write(&mut (*inner).strong, Cell::new(1));
            ptr::write(&mut (*inner).weak, Cell::new(1));
        }

        Ok(inner)
    }

    /// Inogovera `RcBox<T>` ine nzvimbo yakakwana yeisina kukosha yemukati kukosha
    unsafe fn allocate_for_ptr(ptr: *const T) -> *mut RcBox<T> {
        // Govera iyo `RcBox<T>` uchishandisa kukosha kwakapihwa.
        unsafe {
            Self::allocate_for_layout(
                Layout::for_value(&*ptr),
                |layout| Global.allocate(layout),
                |mem| (ptr as *mut RcBox<T>).set_ptr_value(mem),
            )
        }
    }

    fn from_box(v: Box<T>) -> Rc<T> {
        unsafe {
            let (box_unique, alloc) = Box::into_unique(v);
            let bptr = box_unique.as_ptr();

            let value_size = size_of_val(&*bptr);
            let ptr = Self::allocate_for_ptr(bptr);

            // Kopa kukosha senge mabheti
            ptr::copy_nonoverlapping(
                bptr as *const T as *const u8,
                &mut (*ptr).value as *mut _ as *mut u8,
                value_size,
            );

            // Sunungura mugove usingadonhedze zvirimo
            box_free(box_unique, alloc);

            Self::from_ptr(ptr)
        }
    }
}

impl<T> Rc<[T]> {
    /// Inopa `RcBox<[T]>` nehurefu hwakapihwa.
    unsafe fn allocate_for_slice(len: usize) -> *mut RcBox<[T]> {
        unsafe {
            Self::allocate_for_layout(
                Layout::array::<T>(len).unwrap(),
                |layout| Global.allocate(layout),
                |mem| ptr::slice_from_raw_parts_mut(mem as *mut T, len) as *mut RcBox<[T]>,
            )
        }
    }

    /// Kopa zvinhu kubva kuchidimbu kusvika kuchangobva kupihwa Rc <\[T\]>
    ///
    /// Hazvina kuchengeteka nekuti anenge afona anofanira kutora muridzi kana kusunga `T: Copy`
    unsafe fn copy_from_slice(v: &[T]) -> Rc<[T]> {
        unsafe {
            let ptr = Self::allocate_for_slice(v.len());
            ptr::copy_nonoverlapping(v.as_ptr(), &mut (*ptr).value as *mut [T] as *mut T, v.len());
            Self::from_ptr(ptr)
        }
    }

    /// Inogadzira `Rc<[T]>` kubva kune iterator inozivikanwa kuva yeimwe saizi.
    ///
    /// Maitiro haana kujekeswa kana saizi ikanganisa.
    unsafe fn from_iter_exact(iter: impl iter::Iterator<Item = T>, len: usize) -> Rc<[T]> {
        // Panic chengetedza paunenge uchigadzira T zvinhu.
        // Kana paine panic, zvinhu zvakanyorwa muRcBox nyowani zvinokandwa, ipapo ndangariro dzosunungurwa.
        //
        struct Guard<T> {
            mem: NonNull<u8>,
            elems: *mut T,
            layout: Layout,
            n_elems: usize,
        }

        impl<T> Drop for Guard<T> {
            fn drop(&mut self) {
                unsafe {
                    let slice = from_raw_parts_mut(self.elems, self.n_elems);
                    ptr::drop_in_place(slice);

                    Global.deallocate(self.mem, self.layout);
                }
            }
        }

        unsafe {
            let ptr = Self::allocate_for_slice(len);

            let mem = ptr as *mut _ as *mut u8;
            let layout = Layout::for_value(&*ptr);

            // Chinongedzera kuchinhu chekutanga
            let elems = &mut (*ptr).value as *mut [T] as *mut T;

            let mut guard = Guard { mem: NonNull::new_unchecked(mem), elems, layout, n_elems: 0 };

            for (i, item) in iter.enumerate() {
                ptr::write(elems.add(i), item);
                guard.n_elems += 1;
            }

            // Zvese zviri pachena.Kanganwa murindi kuitira kuti isasunungure iyo RcBox nyowani.
            forget(guard);

            Self::from_ptr(ptr)
        }
    }
}

/// Nyanzvi trait yakashandiswa ye `From<&[T]>`.
trait RcFromSlice<T> {
    fn from_slice(slice: &[T]) -> Self;
}

impl<T: Clone> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    default fn from_slice(v: &[T]) -> Self {
        unsafe { Self::from_iter_exact(v.iter().cloned(), v.len()) }
    }
}

impl<T: Copy> RcFromSlice<T> for Rc<[T]> {
    #[inline]
    fn from_slice(v: &[T]) -> Self {
        unsafe { Rc::copy_from_slice(v) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Deref for Rc<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &T {
        &self.inner().value
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<T: ?Sized> Receiver for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized> Drop for Rc<T> {
    /// Anodonha iyo `Rc`.
    ///
    /// Izvi zvinodzora yakasimba referensi kuverenga.
    /// Kana iyo yakasimba mareferensi kuverenga inosvika zero saka mamwe chete mareferenzi (kana aripo) ari [`Weak`], saka isu `drop` kukosha kwemukati.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo  = Rc::new(Foo);
    /// let foo2 = Rc::clone(&foo);
    ///
    /// drop(foo);    // Hazvidhindise chero chinhu
    /// drop(foo2);   // Prints "dropped!"
    /// ```
    fn drop(&mut self) {
        unsafe {
            self.inner().dec_strong();
            if self.inner().strong() == 0 {
                // kuparadza chinhu chirimo
                ptr::drop_in_place(Self::get_mut_unchecked(self));

                // bvisa iyo yakasarudzika "strong weak" pointer izvozvi zvatakaparadza zvirimo.
                //
                self.inner().dec_weak();

                if self.inner().weak() == 0 {
                    Global.deallocate(self.ptr.cast(), Layout::for_value(self.ptr.as_ref()));
                }
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Clone for Rc<T> {
    /// Inoita Clone yeiyo `Rc` pointer.
    ///
    /// Izvi zvinogadzira imwe pointer kune imwecheteyo mugove, ichiwedzera yakasimba mareferensi kuverenga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let _ = Rc::clone(&five);
    /// ```
    #[inline]
    fn clone(&self) -> Rc<T> {
        self.inner().inc_strong();
        Self::from_inner(self.ptr)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Rc<T> {
    /// Inogadzira `Rc<T>` nyowani, iine iyo `Default` kukosha kwe `T`.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let x: Rc<i32> = Default::default();
    /// assert_eq!(*x, 0);
    /// ```
    #[inline]
    fn default() -> Rc<T> {
        Rc::new(Default::default())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
trait RcEqIdent<T: ?Sized + PartialEq> {
    fn eq(&self, other: &Rc<T>) -> bool;
    fn ne(&self, other: &Rc<T>) -> bool;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    default fn eq(&self, other: &Rc<T>) -> bool {
        **self == **other
    }

    #[inline]
    default fn ne(&self, other: &Rc<T>) -> bool {
        **self != **other
    }
}

// Kubvumidza kubvumidza hunyanzvi pa `Eq` kunyangwe `Eq` iine nzira.
#[rustc_unsafe_specialization_marker]
pub(crate) trait MarkerEq: PartialEq<Self> {}

impl<T: Eq> MarkerEq for T {}

/// Tiri kuita hunyanzvi pano, uye kwete sekuwedzera kwakawanda pa `&T`, nekuti zvaizowedzera mutengo kune eseququque cheki pane Refs.
/// Isu tinofungidzira kuti `Rc`s anoshandiswa kuchengetera akakosha maitiro, ayo anononoka kuumbika, asi zvakare anorema kutarisa kuenzana, zvichikonzera mutengo uyu kubhadhara zviri nyore.
///
/// Izvo zvakare zvinowanzoita kuve nemaviri `Rc` macones, ayo anonongedzera kune yakafanana kukosha, kupfuura maviri `&T`s.
///
/// Tinogona chete kuita izvi kana `T: Eq` se `PartialEq` inogona kunge isingaiti nemaune.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + MarkerEq> RcEqIdent<T> for Rc<T> {
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        Rc::ptr_eq(self, other) || **self == **other
    }

    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        !Rc::ptr_eq(self, other) && **self != **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq> PartialEq for Rc<T> {
    /// Kuenzana kwemaviri `Rc`s.
    ///
    /// Maviri `Rc`s akaenzana kana iwo emukati kukosha akaenzana, kunyangwe kana akachengetwa munzvimbo dzakasiyana.
    ///
    /// Kana `T` ichizadzawo `Eq` (zvichireva kusagadzikana kwekuenzana), ma`Rc` maviri anonongedzera kune kugoverwa kwakafanana anogara akaenzana.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five == Rc::new(5));
    /// ```
    ///
    ///
    #[inline]
    fn eq(&self, other: &Rc<T>) -> bool {
        RcEqIdent::eq(self, other)
    }

    /// Kuenzana kwemaviri `Rc`s.
    ///
    /// Maviri `Rc`s haana kuenzana kana iwo emukati maitiro asina kuenzana.
    ///
    /// Kana `T` ichizadzawo `Eq` (zvichireva kusagadzikana kwekuenzana), ma`Rc` maviri anonongedzera kune kugoverwa kumwechete haatomboenzana.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five != Rc::new(6));
    /// ```
    ///
    #[inline]
    fn ne(&self, other: &Rc<T>) -> bool {
        RcEqIdent::ne(self, other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq> Eq for Rc<T> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd> PartialOrd for Rc<T> {
    /// Kuenzanisa kwakasarudzika kwema`Rc`s maviri.
    ///
    /// Ivo vaviri vanofananidzwa nekudana `partial_cmp()` pane yavo yemukati tsika.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Some(Ordering::Less), five.partial_cmp(&Rc::new(6)));
    /// ```
    #[inline(always)]
    fn partial_cmp(&self, other: &Rc<T>) -> Option<Ordering> {
        (**self).partial_cmp(&**other)
    }

    /// Zvishoma-pane kuenzanisa maviri `Rc`s.
    ///
    /// Ivo vaviri vanofananidzwa nekudana `<` pane yavo yemukati tsika.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five < Rc::new(6));
    /// ```
    #[inline(always)]
    fn lt(&self, other: &Rc<T>) -> bool {
        **self < **other
    }

    /// 'Zvishoma pane kana zvakaenzana ne' enzaniso yevaviri `Rc`s.
    ///
    /// Ivo vaviri vanofananidzwa nekudana `<=` pane yavo yemukati tsika.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five <= Rc::new(5));
    /// ```
    #[inline(always)]
    fn le(&self, other: &Rc<T>) -> bool {
        **self <= **other
    }

    /// Yakakura-kupfuura kuenzanisa maviri `Rc`s.
    ///
    /// Ivo vaviri vanofananidzwa nekudana `>` pane yavo yemukati tsika.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five > Rc::new(4));
    /// ```
    #[inline(always)]
    fn gt(&self, other: &Rc<T>) -> bool {
        **self > **other
    }

    /// 'Mukuru kudarika kana akaenzana ne'kuenzanisa kweaviri `Rc`s.
    ///
    /// Ivo vaviri vanofananidzwa nekudana `>=` pane yavo yemukati tsika.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert!(five >= Rc::new(5));
    /// ```
    #[inline(always)]
    fn ge(&self, other: &Rc<T>) -> bool {
        **self >= **other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord> Ord for Rc<T> {
    /// Kufananidza kwe`Rc`s maviri.
    ///
    /// Ivo vaviri vanofananidzwa nekudana `cmp()` pane yavo yemukati tsika.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::cmp::Ordering;
    ///
    /// let five = Rc::new(5);
    ///
    /// assert_eq!(Ordering::Less, five.cmp(&Rc::new(6)));
    /// ```
    #[inline]
    fn cmp(&self, other: &Rc<T>) -> Ordering {
        (**self).cmp(&**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash> Hash for Rc<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Display> fmt::Display for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> fmt::Pointer for Rc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&(&**self as *const T), f)
    }
}

#[stable(feature = "from_for_ptrs", since = "1.6.0")]
impl<T> From<T> for Rc<T> {
    fn from(t: T) -> Self {
        Rc::new(t)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: Clone> From<&[T]> for Rc<[T]> {
    /// Govera chidimbu-chakaverengwa slice uye wochizadza nekubatanidza zvinhu zve`v`.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: &[i32] = &[1, 2, 3];
    /// let shared: Rc<[i32]> = Rc::from(original);
    /// assert_eq!(&[1, 2, 3], &shared[..]);
    /// ```
    #[inline]
    fn from(v: &[T]) -> Rc<[T]> {
        <Self as RcFromSlice<T>>::from_slice(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<&str> for Rc<str> {
    /// Govera chirevo-chakaverengwa tambo chidimbu uye teedzera `v` mairi.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let shared: Rc<str> = Rc::from("statue");
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: &str) -> Rc<str> {
        let rc = Rc::<[u8]>::from(v.as_bytes());
        unsafe { Rc::from_raw(Rc::into_raw(rc) as *const str) }
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl From<String> for Rc<str> {
    /// Govera chirevo-chakaverengwa tambo chidimbu uye teedzera `v` mairi.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: String = "statue".to_owned();
    /// let shared: Rc<str> = Rc::from(original);
    /// assert_eq!("statue", &shared[..]);
    /// ```
    #[inline]
    fn from(v: String) -> Rc<str> {
        Rc::from(&v[..])
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T: ?Sized> From<Box<T>> for Rc<T> {
    /// Fambisa chinhu chakarongedzwa kune chitsva, chirevo chakaverengwa, kugoverwa.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<i32> = Box::new(1);
    /// let shared: Rc<i32> = Rc::from(original);
    /// assert_eq!(1, *shared);
    /// ```
    #[inline]
    fn from(v: Box<T>) -> Rc<T> {
        Rc::from_box(v)
    }
}

#[stable(feature = "shared_from_slice", since = "1.21.0")]
impl<T> From<Vec<T>> for Rc<[T]> {
    /// Govera chidimbu chakaverengwa uye fambisa zvinhu zve`v mukati maro.
    ///
    /// # Example
    ///
    /// ```
    /// # use std::rc::Rc;
    /// let original: Box<Vec<i32>> = Box::new(vec![1, 2, 3]);
    /// let shared: Rc<Vec<i32>> = Rc::from(original);
    /// assert_eq!(vec![1, 2, 3], *shared);
    /// ```
    #[inline]
    fn from(mut v: Vec<T>) -> Rc<[T]> {
        unsafe {
            let rc = Rc::copy_from_slice(&v);

            // Rega iyo Vec isunungure ndangariro yayo, asi kwete kuparadza zvirimo
            v.set_len(0);

            rc
        }
    }
}

#[stable(feature = "shared_from_cow", since = "1.45.0")]
impl<'a, B> From<Cow<'a, B>> for Rc<B>
where
    B: ToOwned + ?Sized,
    Rc<B>: From<&'a B> + From<B::Owned>,
{
    #[inline]
    fn from(cow: Cow<'a, B>) -> Rc<B> {
        match cow {
            Cow::Borrowed(s) => Rc::from(s),
            Cow::Owned(s) => Rc::from(s),
        }
    }
}

#[stable(feature = "boxed_slice_try_from", since = "1.43.0")]
impl<T, const N: usize> TryFrom<Rc<[T]>> for Rc<[T; N]> {
    type Error = Rc<[T]>;

    fn try_from(boxed_slice: Rc<[T]>) -> Result<Self, Self::Error> {
        if boxed_slice.len() == N {
            Ok(unsafe { Rc::from_raw(Rc::into_raw(boxed_slice) as *mut [T; N]) })
        } else {
            Err(boxed_slice)
        }
    }
}

#[stable(feature = "shared_from_iter", since = "1.37.0")]
impl<T> iter::FromIterator<T> for Rc<[T]> {
    /// Inotora chinhu chimwe nechimwe mu `Iterator` uye ichiiisa mu `Rc<[T]>`.
    ///
    /// # Maitiro ekuita
    ///
    /// ## Nyaya yakajairwa
    ///
    /// Mune kesi yakajairika, kuunganidza mu `Rc<[T]>` kunoitwa nekutanga kuunganidza mune `Vec<T>`.Ndokunge, pakunyora zvinotevera:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0).collect();
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// izvi zvinoita sekunge isu takanyora:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).filter(|&x| x % 2 == 0)
    ///     .collect::<Vec<_>>() // Iyo yekutanga seti yezvikamu inoitika pano.
    ///     .into(); // Chikamu chechipiri che `Rc<[T]>` chinoitika pano.
    /// # assert_eq!(&*evens, &[0, 2, 4, 6, 8]);
    /// ```
    ///
    /// Izvi zvinogovera zvakapetwa kakawanda pazvinodiwa pakuvaka iyo `Vec<T>` uyezve ichagovera kamwe chete yekushandura `Vec<T>` kuita `Rc<[T]>`.
    ///
    ///
    /// ## MaIterator ehurefu hwunozivikanwa
    ///
    /// Kana `Iterator` yako ikashandisa `TrustedLen` uye iri yehukuru chaihwo, mugove mumwe uchaitirwa iyo `Rc<[T]>`.Semuyenzaniso:
    ///
    /// ```rust
    /// # use std::rc::Rc;
    /// let evens: Rc<[u8]> = (0..10).collect(); // Kungopihwa kamwe chete kunoitika pano.
    /// # assert_eq!(&*evens, &*(0..10).collect::<Vec<_>>());
    /// ```
    ///
    ///
    fn from_iter<I: iter::IntoIterator<Item = T>>(iter: I) -> Self {
        ToRcSlice::to_rc_slice(iter.into_iter())
    }
}

/// Nyanzvi trait inoshandiswa kuunganidza mu `Rc<[T]>`.
trait ToRcSlice<T>: Iterator<Item = T> + Sized {
    fn to_rc_slice(self) -> Rc<[T]>;
}

impl<T, I: Iterator<Item = T>> ToRcSlice<T> for I {
    default fn to_rc_slice(self) -> Rc<[T]> {
        self.collect::<Vec<T>>().into()
    }
}

impl<T, I: iter::TrustedLen<Item = T>> ToRcSlice<T> for I {
    fn to_rc_slice(self) -> Rc<[T]> {
        // Iyi ndiyo kesi yeiyo `TrustedLen` iterator.
        let (low, high) = self.size_hint();
        if let Some(high) = high {
            debug_assert_eq!(
                low,
                high,
                "TrustedLen iterator's size hint is not exact: {:?}",
                (low, high)
            );

            unsafe {
                // Kachengeteka: Tinofanirwa kuona kuti iterator ine kureba chaiko uye tinayo.
                Rc::from_iter_exact(self, low)
            }
        } else {
            // Dzokera kumashure kuita kwakajairwa.
            self.collect::<Vec<T>>().into()
        }
    }
}

/// `Weak` iri vhezheni ye [`Rc`] inobata isiri-yekunongedzera kune yakachengetedzwa kupihwa.Mugove unowanikwa nekufonera [`upgrade`] pane iyo `Weak` pointer, iyo inodzosera [`Option`]`<`[`Rc`] `<T>>`.
///
/// Sezvo chirevo che `Weak` chisingatarise kuve muridzi, hazvizodzivise kukosha kwakachengetwa mumugove kubva pakudonhedzwa, uye `Weak` pachayo haipe vimbiso nezvekukosha kuchiripo.
/// Saka inogona kudzoka [`None`] kana [`kusimudzira`] d.
/// Ziva zvisinei hazvo kuti `Weak` rejisiti *inoita* kudzivirira kugovera iko pachako (chitoro chekutsigira) kubva mukuendeswa.
///
/// A `Weak` pointer inobatsira kuchengetedza chirevo chenguva pfupi kune kugoverwa kunoitwa ne [`Rc`] pasina kudzivirira kukosha kwayo kwemukati kubva pakudonhedzwa.
/// Iyo zvakare inoshandiswa kudzivirira denderedzwa mareferenzi pakati pe [`Rc`] zvinongedzo, sezvo kuwirirana kuva neyako mareferenzi kwaisazombobvumira chero [`Rc`] kudonhedzwa.
/// Semuenzaniso, muti unogona kuve wakasimba [`Rc`] zvinongedzo kubva kumubereki node kuenda kuvana, uye `Weak` zvinongedzo kubva kuvana vadzokera kuvabereki vavo.
///
/// Iyo chaiyo nzira yekuwana `Weak` pointer ndeyekufonera [`Rc::downgrade`].
///
/// [`upgrade`]: Weak::upgrade
///
///
///
///
///
///
///
#[stable(feature = "rc_weak", since = "1.4.0")]
pub struct Weak<T: ?Sized> {
    // Iyi i `NonNull` kubvumidza kukwidziridza saizi yerudzi urwu mune enums, asi hazvisi hazvo chinongedzo chakakodzera.
    //
    // `Weak::new` inoisa izvi ku `usize::MAX` kuti isazoda kugovera nzvimbo pamurwi.
    // Icho hachisi kukosha chinongedzo chaicho chichava nacho nekuti RcBox ine kuenderana kanenge 2.
    // Izvi zvinokwanisika chete kana `T: Sized`;unsized `T` haina kumbobvira yadzika.
    //
    ptr: NonNull<RcBox<T>>,
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Send for Weak<T> {}
#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> !marker::Sync for Weak<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> CoerceUnsized<Weak<U>> for Weak<T> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Weak<U>> for Weak<T> {}

impl<T> Weak<T> {
    /// Inovaka `Weak<T>` nyowani, isina kugovera chero ndangariro.
    /// Kufonera [`upgrade`] pamutengo wekudzoka kunogara kuchipa [`None`].
    ///
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Weak::new();
    /// assert!(empty.upgrade().is_none());
    /// ```
    #[stable(feature = "downgraded_weak", since = "1.10.0")]
    pub fn new() -> Weak<T> {
        Weak { ptr: NonNull::new(usize::MAX as *mut RcBox<T>).expect("MAX is not 0") }
    }
}

pub(crate) fn is_dangling<T: ?Sized>(ptr: *mut T) -> bool {
    let address = ptr as *mut () as usize;
    address == usize::MAX
}

/// Rudzi rwemubatsiri kubvumidza kuwana iyo mareferensi kuverenga pasina kuita chero zvirevo nezve iyo data shamba.
///
struct WeakInner<'a> {
    weak: &'a Cell<usize>,
    strong: &'a Cell<usize>,
}

impl<T: ?Sized> Weak<T> {
    /// Inodzorera pointer mbishi kuchinhu `T` chakanongedzwa neiyi `Weak<T>`.
    ///
    /// Iyo pointer inoshanda chete kana paine mamwe mareferenzi akasimba.
    /// Iyo pointer inogona kunge yakarembera, isina kuisirwa kana kunyange [`null`] neimwe nzira.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::ptr;
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// // Ose ari maviri anonongedzera kuchinhu chimwe chete
    /// assert!(ptr::eq(&*strong, weak.as_ptr()));
    /// // Vakasimba pano vanozvichengeta zviri zvipenyu, saka tinogona kuwana chinhu.
    /// assert_eq!("hello", unsafe { &*weak.as_ptr() });
    ///
    /// drop(strong);
    /// // Asi kwete zvekare.
    /// // Tinogona kuita weak.as_ptr(), asi kuwana iyo pointer kunotungamira kune isina kujekeswa maitiro.
    /// // assert_eq! ("hello", haina kuchengeteka {&*weak.as_ptr() });
    /// ```
    ///
    /// [`null`]: core::ptr::null
    #[stable(feature = "rc_as_ptr", since = "1.45.0")]
    pub fn as_ptr(&self) -> *const T {
        let ptr: *mut RcBox<T> = NonNull::as_ptr(self.ptr);

        if is_dangling(ptr) {
            // Kana pointer yakarembera, tinodzorera iyo sentinel zvakananga.
            // Iyi haigone kuve yakakodzera kero yekubhadhara, sezvo mubhadharo wacho unenge wakabatana seRcBox (usize).
            ptr as *const T
        } else {
            // Kachengeteka: kana kuri_kurembera kunodzoka kwenhema, ipapo chinongedzo hachioneke.
            // Mubhadharo unogona kudonhedzwa panguva ino, uye isu tinofanirwa kuchengetedza mvumo, saka shandisa mbichana mbichana.
            //
            unsafe { ptr::addr_of_mut!((*ptr).value) }
        }
    }

    /// Inoshandisa iyo `Weak<T>` uye inoichinja ichiita poindi mbishi.
    ///
    /// Izvi zvinoshandura pointer isina kusimba kuita pointer mbishi, ichiri kuchengetedza muridzi weimwe isina kusimba mareferenzi (iyo isina kusimba kuverenga haina kuchinjwa neichi chiitiko).
    /// Inogona kudzoserwa mu `Weak<T>` ne [`from_raw`].
    ///
    /// Iyo mimwe mirawo yekuwana iyo tariso yechinongedzo sekunge [`as_ptr`] inoshanda.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    /// let weak = Rc::downgrade(&strong);
    /// let raw = weak.into_raw();
    ///
    /// assert_eq!(1, Rc::weak_count(&strong));
    /// assert_eq!("hello", unsafe { &*raw });
    ///
    /// drop(unsafe { Weak::from_raw(raw) });
    /// assert_eq!(0, Rc::weak_count(&strong));
    /// ```
    ///
    /// [`from_raw`]: Weak::from_raw
    /// [`as_ptr`]: Weak::as_ptr
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub fn into_raw(self) -> *const T {
        let result = self.as_ptr();
        mem::forget(self);
        result
    }

    /// Inoshandura pointer mbishi yakambogadzirwa ne [`into_raw`] kudzokera ku `Weak<T>`.
    ///
    /// Izvi zvinogona kushandiswa kuchengetedza zvakachengeteka chirevo (nekufona [`upgrade`] gare gare) kana kuendesa isina kusimba kuverenga nekudonhedza `Weak<T>`.
    ///
    /// Zvinotora humiriri hweimwe isina kusimba mareferensi (kunze kwemanongedzo akagadzirwa ne [`new`], sezvo izvi zvisina chinhu, nzira yacho ichiri kushanda pavari).
    ///
    /// # Safety
    ///
    /// Iyo pointer inofanirwa kunge yakabva ku [`into_raw`] uye inofanira kunge iine yayo isinganetse mareferenzi.
    ///
    /// Zvinotenderwa kuti kuverengera kwakasimba kuve 0 panguva yekufona iyi.
    /// Zvakangodaro, izvi zvinotora muridzi weimwe isina kusimba mareferenzi parizvino inomiririrwa seyakajeka pointer (iyo isina kusimba kuverenga haina kuchinjwa neichi chiitiko) uye nekudaro chinofanira kuve chakapetwa neakambofona ku [`into_raw`].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let strong = Rc::new("hello".to_owned());
    ///
    /// let raw_1 = Rc::downgrade(&strong).into_raw();
    /// let raw_2 = Rc::downgrade(&strong).into_raw();
    ///
    /// assert_eq!(2, Rc::weak_count(&strong));
    ///
    /// assert_eq!("hello", &*unsafe { Weak::from_raw(raw_1) }.upgrade().unwrap());
    /// assert_eq!(1, Rc::weak_count(&strong));
    ///
    /// drop(strong);
    ///
    /// // Kuderedza yekupedzisira isina kusimba kuverenga.
    /// assert!(unsafe { Weak::from_raw(raw_2) }.upgrade().is_none());
    /// ```
    ///
    /// [`into_raw`]: Weak::into_raw
    /// [`upgrade`]: Weak::upgrade
    /// [`new`]: Weak::new
    ///
    ///
    ///
    ///
    #[stable(feature = "weak_into_raw", since = "1.45.0")]
    pub unsafe fn from_raw(ptr: *const T) -> Self {
        // Ona Weak::as_ptr yemamiriro ekuti poindi yekuisa inotorwa sei.

        let ptr = if is_dangling(ptr as *mut T) {
            // Uku kurembera Kuneta.
            ptr as *mut RcBox<T>
        } else {
            // Zvikasadaro, isu takavimbiswa kuti pointer yakabva kune isinganetsi Weak.
            // SAFETY: data_offset yakachengeteka kufona, se ptr inongedzera chaiyo (inogona kudonhedzwa) T.
            let offset = unsafe { data_offset(ptr) };
            // Nekudaro, isu tinodzosera kukanganisa kuti tiwane iyo yose RcBox.
            // Kachengeteka: iyo pointer yakatanga kubva kune Weak, saka iyi offset yakachengeteka.
            unsafe { (ptr as *mut RcBox<T>).set_ptr_value((ptr as *mut u8).offset(-offset)) }
        };

        // KUCHENGETEKA: isu ikozvino tadzorera iyo yekutanga Weak pointer, saka tinogona kugadzira iyo isina Simba.
        Weak { ptr: unsafe { NonNull::new_unchecked(ptr) } }
    }

    /// Kuedza kukwidziridza `Weak` pointer kune [`Rc`], kunonoka kudonha kweiyo yemukati kukosha kana ikabudirira.
    ///
    ///
    /// Inodzorera [`None`] kana kukosha kwemukati kubva kwadzikiswa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let five = Rc::new(5);
    ///
    /// let weak_five = Rc::downgrade(&five);
    ///
    /// let strong_five: Option<Rc<_>> = weak_five.upgrade();
    /// assert!(strong_five.is_some());
    ///
    /// // Paradza mapoinzi ese akasimba.
    /// drop(strong_five);
    /// drop(five);
    ///
    /// assert!(weak_five.upgrade().is_none());
    /// ```
    #[stable(feature = "rc_weak", since = "1.4.0")]
    pub fn upgrade(&self) -> Option<Rc<T>> {
        let inner = self.inner()?;
        if inner.strong() == 0 {
            None
        } else {
            inner.inc_strong();
            Some(Rc::from_inner(self.ptr))
        }
    }

    /// Inowana iyo nhamba yeakasimba (`Rc`) anongedzera anongedzera kuichi chikamu.
    ///
    /// Kana `self` yakagadzirwa ichishandisa [`Weak::new`], izvi zvinodzoka 0.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn strong_count(&self) -> usize {
        if let Some(inner) = self.inner() { inner.strong() } else { 0 }
    }

    /// Inowana iyo nhamba ye `Weak` zvinongedzo zvichinongedzera kuichi chikamu.
    ///
    /// Kana pasina zvinongedzo zvine simba zvasara, izvi zvinodzoka zero.
    #[stable(feature = "weak_counts", since = "1.41.0")]
    pub fn weak_count(&self) -> usize {
        self.inner()
            .map(|inner| {
                if inner.strong() > 0 {
                    inner.weak() - 1 // bvisa iyo isina kusimba ptr
                } else {
                    0
                }
            })
            .unwrap_or(0)
    }

    /// Inodzorera `None` apo iyo pointer yakaturika uye hapana yakapihwa `RcBox`, (kureva., Apo iyi `Weak` yakagadzirwa na `Weak::new`).
    ///
    #[inline]
    fn inner(&self) -> Option<WeakInner<'_>> {
        if is_dangling(self.ptr.as_ptr()) {
            None
        } else {
            // Isu takangwarira *kwete* kugadzira rejista inovhara iyo "data" munda, sezvo munda unogona kuchinjika panguva imwe chete (semuenzaniso, kana iyo yekupedzisira `Rc` ikadonhedzwa, iyo data data inokandwa munzvimbo).
            //
            //
            Some(unsafe {
                let ptr = self.ptr.as_ptr();
                WeakInner { strong: &(*ptr).strong, weak: &(*ptr).weak }
            })
        }
    }

    /// Inodzorera `true` kana iwo maviri `Weak` anongedzera kugove rakafanana (rakafanana ne [`ptr::eq`]), kana kana ese ari maviri asinganongedze kune chero kupihwa (nekuti ivo vakasikwa ne `Weak::new()`).
    ///
    ///
    /// # Notes
    ///
    /// Sezvo izvi zvichifananidza zvinongedzo zvinoreva kuti `Weak::new()` ichaenzana, kunyangwe ivo vasinganongedze kune chero kupihwa.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Rc;
    ///
    /// let first_rc = Rc::new(5);
    /// let first = Rc::downgrade(&first_rc);
    /// let second = Rc::downgrade(&first_rc);
    ///
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(5);
    /// let third = Rc::downgrade(&third_rc);
    ///
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// Kuenzanisa `Weak::new`.
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let first = Weak::new();
    /// let second = Weak::new();
    /// assert!(first.ptr_eq(&second));
    ///
    /// let third_rc = Rc::new(());
    /// let third = Rc::downgrade(&third_rc);
    /// assert!(!first.ptr_eq(&third));
    /// ```
    ///
    /// [`ptr::eq`]: core::ptr::eq
    ///
    ///
    #[inline]
    #[stable(feature = "weak_ptr_eq", since = "1.39.0")]
    pub fn ptr_eq(&self, other: &Self) -> bool {
        self.ptr.as_ptr() == other.ptr.as_ptr()
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Drop for Weak<T> {
    /// Anodonha iyo `Weak` pointer.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// struct Foo;
    ///
    /// impl Drop for Foo {
    ///     fn drop(&mut self) {
    ///         println!("dropped!");
    ///     }
    /// }
    ///
    /// let foo = Rc::new(Foo);
    /// let weak_foo = Rc::downgrade(&foo);
    /// let other_weak_foo = Weak::clone(&weak_foo);
    ///
    /// drop(weak_foo);   // Hazvidhindise chero chinhu
    /// drop(foo);        // Prints "dropped!"
    ///
    /// assert!(other_weak_foo.upgrade().is_none());
    /// ```
    fn drop(&mut self) {
        let inner = if let Some(inner) = self.inner() { inner } else { return };

        inner.dec_weak();
        // iyo isina kusimba kuverenga inotanga na1, uye inongoenda kune zero kana ese mapoinzi akasimba akanyangarika.
        //
        if inner.weak() == 0 {
            unsafe {
                Global.deallocate(self.ptr.cast(), Layout::for_value_raw(self.ptr.as_ptr()));
            }
        }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized> Clone for Weak<T> {
    /// Inoita dombo reiyo `Weak` pointer iyo inonongedzera kuichi chikamu chakafanana.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::{Rc, Weak};
    ///
    /// let weak_five = Rc::downgrade(&Rc::new(5));
    ///
    /// let _ = Weak::clone(&weak_five);
    /// ```
    #[inline]
    fn clone(&self) -> Weak<T> {
        if let Some(inner) = self.inner() {
            inner.inc_weak()
        }
        Weak { ptr: self.ptr }
    }
}

#[stable(feature = "rc_weak", since = "1.4.0")]
impl<T: ?Sized + fmt::Debug> fmt::Debug for Weak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "(Weak)")
    }
}

#[stable(feature = "downgraded_weak", since = "1.10.0")]
impl<T> Default for Weak<T> {
    /// Inovaka `Weak<T>` nyowani, ichigovera ndangariro ye `T` pasina kuitangisa.
    /// Kufonera [`upgrade`] pamutengo wekudzoka kunogara kuchipa [`None`].
    ///
    /// [`None`]: Option
    /// [`upgrade`]: Weak::upgrade
    ///
    /// # Examples
    ///
    /// ```
    /// use std::rc::Weak;
    ///
    /// let empty: Weak<i64> = Default::default();
    /// assert!(empty.upgrade().is_none());
    /// ```
    fn default() -> Weak<T> {
        Weak::new()
    }
}

// NOTE: Takatarisa_kuwedzera pano kuti tibate ne mem::forget zvakachengeteka.Zvikuru sei
// kana iwe mem::forget Rcs (kana Wakaneta), iyo Ref-kuverenga inogona kufashukira, uye ipapo unogona kusunungura mugove uku uchisarudzika maRcs (kana Weaks) aripo.
//
// Isu tinobvisa nekuti iyi mamiriro akashata zvekuti isu hatine hanya nezvinoitika-hapana chaiyo chirongwa chinofanira kumbosangana neichi.
//
// Izvi zvinofanirwa kunge zvisina basa pamusoro nekuti haufanire kuumbiridza izvi zvakanyanya mu Rust nekuda kwekuva muridzi uye kufamba-semantics.
//
//

#[doc(hidden)]
trait RcInnerPtr {
    fn weak_ref(&self) -> &Cell<usize>;
    fn strong_ref(&self) -> &Cell<usize>;

    #[inline]
    fn strong(&self) -> usize {
        self.strong_ref().get()
    }

    #[inline]
    fn inc_strong(&self) {
        let strong = self.strong();

        // Tinoda kubvisa kufashukira pachinzvimbo chekudonhedza kukosha.
        // Iyo yekuverenga kuverenga haimbozove zero kana izvi zvadaidzwa;
        // zvisinei, isu tinoisa nhumbu pano kuti tipe zano LLVM pane imwe nzira yakashaikwa optimization.
        //
        if strong == 0 || strong == usize::MAX {
            abort();
        }
        self.strong_ref().set(strong + 1);
    }

    #[inline]
    fn dec_strong(&self) {
        self.strong_ref().set(self.strong() - 1);
    }

    #[inline]
    fn weak(&self) -> usize {
        self.weak_ref().get()
    }

    #[inline]
    fn inc_weak(&self) {
        let weak = self.weak();

        // Tinoda kubvisa kufashukira pachinzvimbo chekudonhedza kukosha.
        // Iyo yekuverenga kuverenga haimbozove zero kana izvi zvadaidzwa;
        // zvisinei, isu tinoisa nhumbu pano kuti tipe zano LLVM pane imwe nzira yakashaikwa optimization.
        //
        if weak == 0 || weak == usize::MAX {
            abort();
        }
        self.weak_ref().set(weak + 1);
    }

    #[inline]
    fn dec_weak(&self) {
        self.weak_ref().set(self.weak() - 1);
    }
}

impl<T: ?Sized> RcInnerPtr for RcBox<T> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        &self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        &self.strong
    }
}

impl<'a> RcInnerPtr for WeakInner<'a> {
    #[inline(always)]
    fn weak_ref(&self) -> &Cell<usize> {
        self.weak
    }

    #[inline(always)]
    fn strong_ref(&self) -> &Cell<usize> {
        self.strong
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> borrow::Borrow<T> for Rc<T> {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized> AsRef<T> for Rc<T> {
    fn as_ref(&self) -> &T {
        &**self
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized> Unpin for Rc<T> {}

/// Tora chinogumburwa mukati me `RcBox` yemubhadharo uri kuseri kwechinongedzo.
///
/// # Safety
///
/// Iyo pointer inofanirwa kunongedzera ku (uye iine metadata inoshanda ye) chiitiko chaimboita cheT, asi iyo T inobvumidzwa kudonhedzwa.
///
unsafe fn data_offset<T: ?Sized>(ptr: *const T) -> isize {
    // Gadzirisa iyo isina kukosheswa kukosha kusvika kumagumo eRcBox.
    // Nekuti RcBox i repr(C), ichagara iri ndima yekupedzisira mundangariro.
    // KUCHENGETEKA: sezvo iwo chete asina saizi mhando anokwanisika zvidimbu, trait zvinhu,
    // uye mhando dzekunze, iyo yekuchengetedza chengetedzo inodikanwa parizvino yakakwana kuzadzikisa izvo zvinodiwa zve align_of_val_raw;iyi idhisheni yekumisikidza yemutauro uyo ungasavimba nawo kunze kwe std.
    //
    //
    unsafe { data_offset_align(align_of_val_raw(ptr)) }
}

#[inline]
fn data_offset_align(align: usize) -> isize {
    let layout = Layout::new::<RcBox<()>>();
    (layout.size() + layout.padding_needed_for(align)) as isize
}