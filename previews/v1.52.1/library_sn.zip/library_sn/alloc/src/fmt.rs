//! Zvishandiso zvekumisikidza nekudhinda `String`s.
//!
//! Iyi module ine runtime yekutsigira yeiyo [`format!`] syntax yekuwedzera.
//! Iyi macro inoitwa mukomisheni kuburitsa mafoni kune iyi module kuitira kuti ifomati nharo panguva yekumhanya kuita tambo.
//!
//! # Usage
//!
//! Iyo [`format!`] macro inoitirwa kuve inozivikanwa kune vanobva kuC's `printf`/`fprintf` mashandiro kana Python's `str.format` basa.
//!
//! Mimwe mienzaniso yekuwedzera kwe [`format!`] ndeiyi:
//!
//! ```
//! format!("Hello");                 // => "Hello"
//! format!("Hello, {}!", "world");   // => "Hello, world!"
//! format!("The number is {}", 1);   // => "The number is 1"
//! format!("{:?}", (3, 4));          // => "(3, 4)"
//! format!("{value}", value=4);      // => "4"
//! format!("{} {}", 1, 2);           // => "1 2"
//! format!("{:04}", 42);             // => "0042" ine zero inotungamira
//! ```
//!
//! Kubva pane izvi, iwe unogona kuona kuti yekutanga nharo tambo yefomati.Zvinotarisirwa nemunyori kuti iyi ive tambo chaiyo;haikwanise kuve musiyano wakapfuudzwa mukati (kuitira kuti uone kutendeka).
//! Iyo compiler inozo paratidzira fomati tambo uye voona kana rondedzero yenharo dzakapihwa yakakodzera kupfuudza kune iyi fomati tambo
//!
//! Kuti ushandure kukosha kamwe kuita tambo, shandisa nzira ye [`to_string`].Izvi zvinoshandisa [`Display`] fomati trait.
//!
//! ## Mamiriro ezvinhu
//!
//! Nhaurwa yega yega yekumisikidza inobvumidzwa kutsanangura kukosha kwekupokana kwairi kureva, uye kana ikasiiwa inofungidzirwa kuve "the next argument".
//! Semuenzaniso, fomati tambo `{} {} {}` yaizotora matatu ma parameter, uye iwo aizo fomatiwa nenzira imwecheteyo yavakapihwa.
//! Iyo fomati tambo `{2} {1} {0}`, zvisinei, yaizo fomata nharo nenzira yakadzoserwa
//!
//! Zvinhu zvinogona kuwana zvishoma zvinonyengera kana iwe ukangotanga kupindirana nemhando mbiri dzenzvimbo dzinotsanangudza.Iyo "next argument" yekutsanangudza inogona kufungidzirwa seye iterator pamusoro pekupokana.
//! Nguva imwe neimwe iyo "next argument" yekutsanangudza ichionekwa, iyo iterator inofambira mberi.Izvi zvinotungamira kune hunhu hwakadai.
//!
//! ```
//! format!("{1} {} {0} {}", 1, 2); // => "2 1 1 2"
//! ```
//!
//! Iyo yemukati iterator pamusoro pekupokana haina kumbofambiswa nenguva iyo yekutanga `{}` ichionekwa, saka inodhinda iyo yekutanga nharo.Zvino paunosvika wechipiri `{}`, iyo iterator yakafambira mberi kuenda kunharo yechipiri.
//! Chaizvoizvo, paramita dzinonyatsotumidza zita nharo dzadzo hadzibate paramende dzisingatumidze nharo maererano nemaonero echimiro.
//!
//! Tambo fomati inodiwa kuti ishandise zvese zvayo nharo, zvikasadaro iko kwekuunganidza-nguva kukanganisa.Iwe unogona kureva kune imwechete nharo kanopfuura kamwe mu fomati tambo.
//!
//! ## Yakatumidzwa parameter
//!
//! Rust pachayo haina Python-yakafanana nemazita akafanirwa kuita basa, asi [`format!`] macro inowedzera syntax iyo inobvumidza kuti ishandise mazita anonzi parameter.
//! Mazita ematanho akanyorwa panoperera runyorwa rwekupokana uye ane syntax:
//!
//! ```text
//! identifier '=' expression
//! ```
//!
//! Semuenzaniso, zvinotevera [`format!`] zvirevo zvese zvinoshandiswa zvine zita nharo:
//!
//! ```
//! format!("{argument}", argument = "test");   // => "test"
//! format!("{name} {}", 1, name = 2);          // => "2 1"
//! format!("{a} {c} {b}", a="a", b='b', c=3);  // => "a 3 b"
//! ```
//!
//! Hazvibvumirwe kuisa positional parameter (iwo asina mazita) mushure mekupokana kune mazita.Kufanana nemamiriro eparamende, hazvibvumirwe kupa mazita ane ma parameter asina kushandiswa netambo yefomati.
//!
//! # Kugadzira Parameter
//!
//! Nharo yega yega iri kumisikidzwa inogona kushandurwa neakawanda mafomati ekumisikidza (anoenderana ne `format_spec` mu [the syntax](#syntax)). Aya ma parameter anokanganisa tambo inomiririra izvo zviri kuumbwa.
//!
//! ## Width
//!
//! ```
//! // Ese aya anodhinda "Hello x !"
//! println!("Hello {:5}!", "x");
//! println!("Hello {:1$}!", "x", 5);
//! println!("Hello {1:0$}!", 5, "x");
//! println!("Hello {:width$}!", "x", width = 5);
//! ```
//!
//! Iyi paramende ye "minimum width" iyo fomati inofanira kutora.
//! Kana tambo yemutengo ikasazadza mavara mazhinji, ipapo padding yakatarwa ne fill/alignment inozoshandiswa kutora nzvimbo inodiwa (ona pazasi).
//!
//! Iko kukosha kwehupamhi kunogona zvakare kupihwa se [`usize`] mune runyorwa rweparamendi nekuwedzera postfix `$`, zvichiratidza kuti nharo yechipiri i [`usize`] inotsanangura hupamhi.
//!
//! Kureva kukakavadzana nedhora syntax hakukanganisi kadhi ye "next argument", saka kazhinji zano rakanaka kutaura kune nharo nechinzvimbo, kana kushandisa mazita ane nharo.
//!
//! ## Fill/Alignment
//!
//! ```
//! assert_eq!(format!("Hello {:<5}!", "x"),  "Hello x    !");
//! assert_eq!(format!("Hello {:-<5}!", "x"), "Hello x----!");
//! assert_eq!(format!("Hello {:^5}!", "x"),  "Hello   x  !");
//! assert_eq!(format!("Hello {:>5}!", "x"),  "Hello     x!");
//! ```
//!
//! Iyo yekusarudzika yekuzadza hunhu uye kuenderana kunowanikwa zvakajairika pamwe chete ne [`width`](#width) paramende.Inofanira kutsanangurwa pamberi pe `width`, chaipo mushure me `:`.
//! Izvi zvinoratidza kuti kana kukosha kuri kuumbwa kuri kudiki pane `width` mamwe mavara anozodhindwa pauri.
//! Kuzadza kunouya mune anotevera akasiyana ematanho akasiyana:
//!
//! * `[fill]<` - iyo nharo yakasarudzika-yakatarisana mumakoramu e `width`
//! * `[fill]^` - iyo nharo yakamisidzana-yakatarisana mukati me `width` makoramu
//! * `[fill]>` - iyo nharo yakaringana-yakatarisana mumakoramu e `width`
//!
//! Iyo yakasarudzika [fill/alignment](#fillalignment) yeisina-manhamba inzvimbo uye kuruboshwe-yakatarisana.Iko kusarudzika kwemafomati manhamba zvakare iri nzvimbo yemunhu asi nekurudyi-kurudyi.
//! Kana iyo mureza we `0` (ona pazasi) yakatsanangurwa yenhamba, saka iyo yakazara yekuzadza hunhu i `0`.
//!
//! Ziva kuti kuenderana hakugone kuitiswa nemamwe marudzi.Kunyanya, haiwanzo kuitirwa iyo `Debug` trait.
//! Nzira yakanaka yekuona kuti padding inoshandiswa kuisa fomati yako yekuisa, wobva waisa iyi tambo inoguma kuti uwane chako chabuda.
//!
//! ```
//! println!("Hello {:^15}!", format!("{:?}", Some("hi"))); // => "Mhoro Some("hi")!"
//! ```
//!
//! ## Sign/`#`/`0`
//!
//! ```
//! assert_eq!(format!("Hello {:+}!", 5), "Hello +5!");
//! assert_eq!(format!("{:#x}!", 27), "0x1b!");
//! assert_eq!(format!("Hello {:05}!", 5),  "Hello 00005!");
//! assert_eq!(format!("Hello {:05}!", -5), "Hello -0005!");
//! assert_eq!(format!("{:#010x}!", 27), "0x0000001b!");
//! ```
//!
//! Idzi dzose mireza dzinoshandura hunhu hwemufomati.
//!
//! * `+` - Izvi zvinoitirwa mhando dzemhando uye zvinoratidza kuti chiratidzo chinofanira kugara chakadhindwa.Zviratidzo zvakanaka hazvina kumbobvira zvadhindwa nekutadza, uye chiratidzo chisina kunaka chinongodhindwa nekutadza kwe `Signed` trait.
//! Mureza uyu unoratidza kuti chiratidzo chakakodzera (`+` kana `-`) chinofanira kugara chakadhindwa.
//! * `-` - Parizvino haina kushandiswa
//! * `#` - Mureza uyu unoratidza kuti "alternate" fomu yekudhinda inofanira kushandiswa.Mamwe mafomu ndeaya:
//!     * `#?` - runako-purinda iyo [`Debug`] fomati
//!     * `#x` - inotangira nharo ne `0x`
//!     * `#X` - inotangira nharo ne `0x`
//!     * `#b` - inotangira nharo ne `0b`
//!     * `#o` - inotangira nharo ne `0o`
//! * `0` - Izvi zvinoshandiswa kuratidza mafomati manhamba kuti padding kuenda ku `width` inofanira kuitwa zvese ne `0` hunhu pamwe nekuziva-saina.
//! Fomati senge `{:08}` yaizoburitsa `00000001` yeiyo yakazara `1`, nepo iyo fomati yakafanana yaizoburitsa `-0000001` yeiyo yakazara `-1`.
//! Cherekedza kuti iro rakashata vhezheni rine imwe shoma zero kupfuura iyo yakanaka vhezheni.
//!         Ziva kuti padding zeros inogara ichiiswa mushure mechiratidzo (kana paine) uye pamberi pehuwandu.Kana uchishandiswa pamwe chete neiyo `#` mureza, mutemo wakafanana unoshanda: padding zeros inoiswa mushure mekutanga asi pamberi pehuwandu.
//!         Icho chirevo chekutanga chakabatanidzwa muhupamhi hwakazara.
//!
//! ## Precision
//!
//! Kune asiri-nhamba mhando, izvi zvinogona kutariswa se "maximum width".
//! Kana tambo inoguma yareba kupfuura upamhi uhu, zvino inodonhedzwa pasi kune aya mavara uye iyo yakaderedzwa kukosha inoburitswa ne `fill` chaiyo, `alignment` uye `width` kana iwo ma parameter akaiswa.
//!
//! Zvemhando dzakabatana, izvi zvinofuratirwa.
//!
//! Yemhando dzinoyangarara-poindi, izvi zvinoratidza kuti mangani manhamba mushure meinongedzo inofanirwa kudhindwa.
//!
//! Pane nzira nhatu dzinogona kutsanangurwa dzinodiwa `precision`:
//!
//! 1. Yakazara `.N`:
//!
//!    iyo nhamba `N` pachayo ndiyo chaiyo.
//!
//! 2. Iyo nhamba kana zita rinoteverwa nedhora chiratidzo `.N$`:
//!
//!    shandisa fomati *nharo*`N` (iyo inofanirwa kunge iri `usize`) seye chaiyo.
//!
//! 3. Nyeredzi `.*`:
//!
//!    `.*` zvinoreva kuti iyi `{...}` inosanganisirwa ne *maviri* mafomati pane imwe chete: yekutanga yekuisa inobata `usize` chaiyo, uye yechipiri inobata kukosha kwekupurinda.
//!    Ziva kuti mune ino kesi, kana munhu akashandisa fomati tambo `{<arg>:<spec>.*}`, ipapo chikamu che `<arg>` chinoreva iyo* kukosha * kupurinda, uye iyo `precision` inofanirwa kuuya mune yekuisa pamberi pe `<arg>`.
//!
//! Semuenzaniso, zvinotevera zvinoshevedza zvese kudhinda chinhu chimwe chete `Hello x is 0.01000`:
//!
//! ```
//! // Mhoro {arg 0 ("x")} ndi {arg 1 (0.01) with precision specified inline (5)}
//! println!("Hello {0} is {1:.5}", "x", 0.01);
//!
//! // Mhoro {arg 1 ("x")} ndi {arg 2 (0.01) with precision specified in arg 0 (5)}
//! println!("Hello {1} is {2:.0$}", 5, "x", 0.01);
//!
//! // Mhoro {arg 0 ("x")} ndi {arg 2 (0.01) with precision specified in arg 1 (5)}
//! println!("Hello {0} is {2:.1$}", "x", 5, 0.01);
//!
//! // Mhoro {next arg ("x")} ndi {second of next two args (0.01) with precision specified in first of next two args (5)}
//! //
//! println!("Hello {} is {:.*}",    "x", 5, 0.01);
//!
//! // Mhoro {next arg ("x")} ndi {arg 2 (0.01) with precision specified in its predecessor (5)}
//! //
//! println!("Hello {} is {2:.*}",   "x", 5, 0.01);
//!
//! // Mhoro {next arg ("x")} ndi {arg "number" (0.01) with precision specified in arg "prec" (5)}
//! //
//! println!("Hello {} is {number:.prec$}", "x", prec = 5, number = 0.01);
//! ```
//!
//! Kunyange izvi:
//!
//! ```
//! println!("{}, `{name:.*}` has 3 fractional digits", "Hello", 3, name=1234.56);
//! println!("{}, `{name:.*}` has 3 characters", "Hello", 3, name="1234.56");
//! println!("{}, `{name:>8.*}` has 3 right-aligned characters", "Hello", 3, name="1234.56");
//! ```
//!
//! purinda zvinhu zvitatu zvakasiyana zvakanyanya:
//!
//! ```text
//! Hello, `1234.560` has 3 fractional digits
//! Hello, `123` has 3 characters
//! Hello, `     123` has 3 right-aligned characters
//! ```
//!
//! ## Localization
//!
//! Mune mimwe mitauro yekuronga, hunhu hwetambo yekumisikidza mabasa kunoenderana neanoshanda masisitimu enzvimbo.
//! Iwo mafomati mabasa anopihwa ne Rust raibhurari yakajairwa haina chero pfungwa yenzvimbo uye ichaunza zvakafanana mhedzisiro pane ese masisitimu zvisinei nemashandisirwo emushandisi.
//!
//! Semuenzaniso, iyo inotevera kodhi inogara ichipurinda `1.5` kunyangwe iyo system locale ikashandisa decimal decimal kusiana pane dot.
//!
//! ```
//! println!("The value is {}", 1.5);
//! ```
//!
//! # Escaping
//!
//! Mavara chaiwo `{` uye `}` anogona kuverengerwa mutambo nekuvatangira nehunhu hwakafanana.Semuenzaniso, `{` hunhu hwapunyuka ne `{{` uye `}` hunhu hwapunyuka ne `}}`.
//!
//! ```
//! assert_eq!(format!("Hello {{}}"), "Hello {}");
//! assert_eq!(format!("{{ Hello"), "{ Hello");
//! ```
//!
//! # Syntax
//!
//! Kupfupisa, pano iwe unogona kuwana yakazara girama yema fomati tambo.
//! Iyo syntax yemutauro wekumisikidza wakashandiswa inotorwa kubva kune mimwe mitauro, saka haifanire kunge iri yekumwe vatorwa.Nharo dzakarongwa ne Python-senge syntax, zvichireva kuti nharo dzakakomberedzwa ne `{}` pachinzvimbo cheC-senge `%`.
//! Iyo chaiyo girama yeiyo fomati syntax ndeiyi:
//!
//! ```text
//! format_string := text [ maybe_format text ] *
//! maybe_format := '{' '{' | '}' '}' | format
//! format := '{' [ argument ] [ ':' format_spec ] '}'
//! argument := integer | identifier
//!
//! format_spec := [[fill]align][sign]['#']['0'][width]['.' precision]type
//! fill := character
//! align := '<' | '^' | '>'
//! sign := '+' | '-'
//! width := count
//! precision := count | '*'
//! type := '' | '?' | 'x?' | 'X?' | identifier
//! count := parameter | integer
//! parameter := argument '$'
//! ```
//! Mune girama iri pamusoro, `text` inogona kunge iine chero `'{'` kana `'}'` mavara.
//!
//! # Kugadzira traits
//!
//! Kana uchikumbira kuti nharo inyorwe nerumwe rudzi, iwe uri kunyatso kukumbira kuti nharo inongedze kune imwe trait.
//! Izvi zvinobvumidza akawanda chaiwo marudzi kuti aumbirwe kuburikidza ne `{:x}` (se [`i8`] pamwe ne [`isize`]).Mepu yazvino yemhando ku traits ndeiyi:
//!
//! * *hapana* ⇒ [`Display`]
//! * `?` 00 [`Debug`]
//! * `x?` 00 [`Debug`] ine yakaderera-kesi hexadecimal manhamba
//! * `X?` 00 [`Debug`] ine yepamusoro-kesi hexadecimal manhamba
//! * `o` 00 [`Octal`]
//! * `x` 00 [`LowerHex`]
//! * `X` 00 [`UpperHex`]
//! * `p` 00 [`Pointer`]
//! * `b` 00 [`Binary`]
//! * `e` 00 [`LowerExp`]
//! * `E` 00 [`UpperExp`]
//!
//! Izvi zvinoreva kuti chero mhando yenharo inoshandisa iyo [`fmt::Binary`][`Binary`] trait inogona kuzomisikidzwa ne `{:b}`.Maitirwo anopihwa aya ma traits emhando dzinoverengeka dzeruzivo neraibhurari yakajairwa futi.
//!
//! Kana pasina fomati yakatsanangurwa (senge `{}` kana `{:6}`), ipapo fomati trait yakashandiswa ndiyo [`Display`] trait.
//!
//! Paunenge uchiita fomati trait yerudzi rwako, uchafanirwa kuita nzira yesiginecha:
//!
//! ```
//! # #![allow(dead_code)]
//! # use std::fmt;
//! # struct Foo; // yedu tsika mhando
//! # impl fmt::Display for Foo {
//! fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//! # write!(f, "testing, testing")
//! # } }
//! ```
//!
//! Rudzi rwako ruchapfuudzwa se `self` nereferenzi, uyezve iro basa rinofanira kuburitsa goho murwizi rwe `f.buf`.Izvo zviri kune yega fomati trait kuitisa kunyatso kutevedzera kune akakumbirwa mafomati parameter.
//! Iko kukosha kweiyi parameter kunonyorwa muminda yeiyo [`Formatter`] struct.Kuti ubatsire neizvi, iyo [`Formatter`] dhizaini zvakare inopa dzimwe nzira dzekubatsira.
//!
//! Pamusoro pezvo, kukosha kwekudzoka kweiri basa i [`fmt::Result`] inova mhando alias ye [`Mhedzisiro`]`<(),`[`std: : fmt::Error`] `>`.
//! Kugadziridza kumisikidza kunofanirwa kuona kuti vanofambisa zvikanganiso kubva ku [`Formatter`] (semuenzaniso, pavanosheedza [`write!`]).
//! Nekudaro, ivo havafanirwe kumbodzosera zvikanganiso zvisirizvo.
//! Ndokunge, kumisikidza kuitisa kunofanirwa uye kunogona kungodzosera kukanganisa kana iyo yakapfuura-mu [`Formatter`] ichidzosera kukanganisa.
//! Izvi zvinodaro nekuti, zvinopesana nezvinogona kuratidzwa nesigineti yebasa, fomati yekumisikidza kuita kusingakundike.
//! Iri basa rinongodzosera mhedzisiro nekuti kunyorera kurukova ruri pasi kunogona kukundikana uye kunofanirwa kupa nzira yekuparadzira chokwadi chekuti kukanganisa kwakaitika kudzosera mudura.
//!
//! Muenzaniso wekumisikidza fomati traits yaizoita kunge:
//!
//! ```
//! use std::fmt;
//!
//! #[derive(Debug)]
//! struct Vector2D {
//!     x: isize,
//!     y: isize,
//! }
//!
//! impl fmt::Display for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         // Iko `f` kukosha inoshandisa iyo `Write` trait, zvinova ndizvo zvakanyorwa!macro iri kutarisira.
//!         // Ziva kuti fomati iyi inofuratira mireza dzakasiyana dzakapihwa fomati tambo.
//!         //
//!         write!(f, "({}, {})", self.x, self.y)
//!     }
//! }
//!
//! // Yakasiyana traits inobvumidza akasiyana mafomu ekuburitsa erudzi.
//! // Zvinoreva fomati iyi kudhinda ukuru hwe vector.
//! impl fmt::Binary for Vector2D {
//!     fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
//!         let magnitude = (self.x * self.x + self.y * self.y) as f64;
//!         let magnitude = magnitude.sqrt();
//!
//!         // Remekedza mafomati ekumisikidza uchishandisa nzira yekubatsira `pad_integral` pane iyo Formatter chinhu.
//!         // Ona iyo nzira zvinyorwa zvemashoko, uye basa `pad` rinogona kushandiswa kupeta tambo.
//!         //
//!         //
//!         let decimals = f.precision().unwrap_or(3);
//!         let string = format!("{:.*}", decimals, magnitude);
//!         f.pad_integral(true, "", &string)
//!     }
//! }
//!
//! fn main() {
//!     let myvector = Vector2D { x: 3, y: 4 };
//!
//!     println!("{}", myvector);       // => "(3, 4)"
//!     println!("{:?}", myvector);     // => "Vector2D {x: 3, y:4}"
//!     println!("{:10.3b}", myvector); // => "     5.000"
//! }
//! ```
//!
//! ### `fmt::Display` vs `fmt::Debug`
//!
//! Aya mafomati maviri e traits ane zvinangwa zvakasiyana:
//!
//! - [`fmt::Display`][`Display`] mashandisiro anosimbisa kuti mhando inogona kumiririrwa nokutendeka setambo ye UTF-8 nguva dzose.Izvo **hazvisi** zvinotarisirwa kuti mhando dzese dzishandise iyo [`Display`] trait.
//! - [`fmt::Debug`][`Debug`] kuitiswa kunofanirwa kuitirwa kune **ese** mhando yeruzhinji.
//!   Kuburitsa kunowanzo mirira nyika yemukati sekutendeka sezvinobvira.
//!   Chinangwa che [`Debug`] trait ndechekugadzirisa debugging Rust kodhi.Muzviitiko zvakawanda, kushandisa `#[derive(Debug)]` kwakaringana uye kunorumbidzwa.
//!
//! Mimwe mienzaniso yezvinobuda kubva kune ese traits:
//!
//! ```
//! assert_eq!(format!("{} {:?}", 3, 4), "3 4");
//! assert_eq!(format!("{} {:?}", 'a', 'b'), "a 'b'");
//! assert_eq!(format!("{} {:?}", "foo\n", "bar\n"), "foo\n \"bar\\n\"");
//! ```
//!
//! # Yakabatana macros
//!
//! Kune akati wandei akafanana macros mumhuri ye [`format!`].Iwo ari kuitwa parizvino ndeaya:
//!
//! ```ignore (only-for-syntax-highlight)
//! format!      // described above
//! write!       // first argument is a &mut io::Write, the destination
//! writeln!     // same as write but appends a newline
//! print!       // the format string is printed to the standard output
//! println!     // same as print but appends a newline
//! eprint!      // the format string is printed to the standard error
//! eprintln!    // same as eprint but appends a newline
//! format_args! // described below.
//! ```
//!
//! ### `write!`
//!
//! Aya ne [`writeln!`] macro maviri anoshandiswa kuburitsa tambo yefomati kurukova rwakatarwa.Izvi zvinoshandiswa kudzivirira kugoverwa kwepakati kwetambo dzefomati uye panzvimbo pacho nyora zvakabuda.
//! Pasi pehodhi, iri basa riri kunyatso kukumbira iyo [`write_fmt`] basa rakatsanangurwa pa [`std::io::Write`] trait.
//! Semuenzaniso mashandisiro ndeaya:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::io::Write;
//! let mut w = Vec::new();
//! write!(&mut w, "Hello {}!", "world");
//! ```
//!
//! ### `print!`
//!
//! Izvi uye [`println!`] zvinoburitsa zvavanobuda ku stdout.Saizvozvowo kune [`write!`] macro, chinangwa cheaya macros ndechekudzivirira kugoverwa kwepakati kana uchidhinda zvinobuda.Semuenzaniso mashandisiro ndeaya:
//!
//! ```
//! print!("Hello {}!", "world");
//! println!("I have a newline {}", "character at the end");
//! ```
//!
//! ### `eprint!`
//!
//! Iyo [`eprint!`] uye [`eprintln!`] macros zvakafanana ne [`print!`] uye [`println!`], zvichiteerana, kunze kwekunge dzaburitsa zvadzo ku stderr.
//!
//! ### `format_args!`
//!
//! Iyi macro yekuda kuziva inoshandiswa kupfuura zvakachengeteka ichitenderedza opaque chinhu chinotsanangura fomati tambo.Chinhu ichi hachidi chero murwi kugoverwa kuti chigadzire, uye zvinongoreva ruzivo pane stack.
//! Pasi pehood, ese macro anoenderana anoitwa maererano neizvi.
//! Kutanga kubva, mumwe muenzaniso mashandisiro ndeaya:
//!
//! ```
//! # #![allow(unused_must_use)]
//! use std::fmt;
//! use std::io::{self, Write};
//!
//! let mut some_writer = io::stdout();
//! write!(&mut some_writer, "{}", format_args!("print with a {}", "macro"));
//!
//! fn my_fmt_fn(args: fmt::Arguments) {
//!     write!(&mut io::stdout(), "{}", args);
//! }
//! my_fmt_fn(format_args!(", or a {} too", "function"));
//! ```
//!
//! Mhedzisiro ye [`format_args!`] macro kukosha kwerudzi [`fmt::Arguments`].
//! Ichi chimiro chinogona kubva chapfuudzwa kune iyo [`write`] uye [`format`] inoshanda mukati meiyi module kuitira kugadzirisa fomati tambo.
//! Chinangwa cheiyi macro ndechekutowedzera kudzivirira kugoverwa kwepakati kana uchibata netambo dzekumisikidza.
//!
//! Semuenzaniso, raibhurari yekucheka matanda inogona kushandisa yakajairika fomati syntax, asi yaizopfuura mukati ichitenderedza ichi chimiro kusvika zvatemwa kwazvinofanira kuenda.
//!
//! [`fmt::Result`]: Result
//! [`Result`]: core::result::Result
//! [`std::fmt::Error`]: Error
//! [`write!`]: core::write
//! [`write`]: core::write
//! [`format!`]: crate::format
//! [`to_string`]: crate::string::ToString
//! [`writeln!`]: core::writeln
//! [`write_fmt`]: ../../std/io/trait.Write.html#method.write_fmt
//! [`std::io::Write`]: ../../std/io/trait.Write.html
//! [`print!`]: ../../std/macro.print.html
//! [`println!`]: ../../std/macro.println.html
//! [`eprint!`]: ../../std/macro.eprint.html
//! [`eprintln!`]: ../../std/macro.eprintln.html
//! [`format_args!`]: core::format_args
//! [`fmt::Arguments`]: Arguments
//! [`format`]: crate::format
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[unstable(feature = "fmt_internals", issue = "none")]
pub use core::fmt::rt;
#[stable(feature = "fmt_flags_align", since = "1.28.0")]
pub use core::fmt::Alignment;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::Error;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{write, ArgumentV1, Arguments};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Binary, Octal};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Debug, Display};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{DebugList, DebugMap, DebugSet, DebugStruct, DebugTuple};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{Formatter, Result, Write};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerExp, UpperExp};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::fmt::{LowerHex, Pointer, UpperHex};

use crate::string;

/// Basa re `format` rinotora [`Arguments`] dhizaini uye rinodzosera rakakonzerwa fomati tambo.
///
///
/// Iyo [`Arguments`] semuenzaniso inogona kugadzirwa ne [`format_args!`] macro.
///
/// # Examples
///
/// Kushandiswa kwekutanga:
///
/// ```
/// use std::fmt;
///
/// let s = fmt::format(format_args!("Hello, {}!", "world"));
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// Ndokumbira utarise kuti kushandisa [`format!`] kungave kuri nani.
/// Example:
///
/// ```
/// let s = format!("Hello, {}!", "world");
/// assert_eq!(s, "Hello, world!");
/// ```
///
/// [`format_args!`]: core::format_args
/// [`format!`]: crate::format
#[stable(feature = "rust1", since = "1.0.0")]
pub fn format(args: Arguments<'_>) -> string::String {
    let capacity = args.estimated_capacity();
    let mut output = string::String::with_capacity(capacity);
    output.write_fmt(args).expect("a formatting trait implementation returned an error");
    output
}