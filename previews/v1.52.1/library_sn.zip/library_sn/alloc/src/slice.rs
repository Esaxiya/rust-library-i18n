//! Maonero akasimba-musimba mune akateedzana, `[T]`.
//!
//! *[See also the slice primitive type](slice).*
//!
//! Zvimedu zviono muchivako chendangariro chinomiririrwa sechirevo uye kureba.
//!
//! ```
//! // kucheka Vec
//! let vec = vec![1, 2, 3];
//! let int_slice = &vec[..];
//! // kumanikidza rondedzero kuchidimbu
//! let str_slice: &[&str] = &["one", "two", "three"];
//! ```
//!
//! Zvimedu zvinogona kuchinjika kana kugoverwa.
//! Rudzi rwakagovaniswa slice i `&[T]`, nepo chinoshanduka slice yerudzi i `&mut [T]`, uko `T` inomiririra iyo element mhando.
//! Semuenzaniso, iwe unogona kuchinjisa bhokisi rendangariro iro rinoshanduka slice rinonongedzera ku:
//!
//! ```
//! let x = &mut [1, 2, 3];
//! x[1] = 7;
//! assert_eq!(x, &[1, 7, 3]);
//! ```
//!
//! Hezvino zvimwe zvezvinhu zvine module iyi.
//!
//! ## Structs
//!
//! Kune akatiwandei structs anobatsira zvidimbu, senge [`Iter`], inomiririra iteration pamusoro pechidimbu.
//!
//! ## Trait Maitiro
//!
//! Iko kune akati wandei mashandiro ezvakajairwa traits yezvimedu.Mimwe mienzaniso inosanganisira:
//!
//! * [`Clone`]
//! * [`Eq`], [`Ord`], yezvidimbu zvine mhando yezvinhu zviri [`Eq`] kana [`Ord`].
//! * [`Hash`] - yezvidimbu zvine mhando yechinhu chiri [`Hash`].
//!
//! ## Iteration
//!
//! Iwo zvidimbu zvinoshandisa `IntoIterator`.Iyo iterator inoburitsa mareferenzi kune zvidimbu zvezvinhu.
//!
//! ```
//! let numbers = &[0, 1, 2];
//! for n in numbers {
//!     println!("{} is a number!", n);
//! }
//! ```
//!
//! Chidimbu chinoshanduka chinoburitsa zvinongedzo zvinoshanduka kune izvo zvinhu:
//!
//! ```
//! let mut scores = [7, 8, 9];
//! for score in &mut scores[..] {
//!     *score += 1;
//! }
//! ```
//!
//! Iyi iterator inoburitsa mareferenzi anogona kuchinjika kuzvinhu zvechidimbu, saka nepo mhando yechinhu chacho chiri `i32`, iyo mhando yeiyo iterator i `&mut i32`.
//!
//!
//! * [`.iter`] uye [`.iter_mut`] ndiyo nzira dzakajeka dzekudzosa maiterator asipo.
//! * Dzimwe nzira dzinodzosera iterators i [`.split`], [`.splitn`], [`.chunks`], [`.windows`] uye nezvimwe.
//!
//! [`Hash`]: core::hash::Hash
//! [`.iter`]: slice::iter
//! [`.iter_mut`]: slice::iter_mut
//! [`.split`]: slice::split
//! [`.splitn`]: slice::splitn
//! [`.chunks`]: slice::chunks
//! [`.windows`]: slice::windows
//!
//!
//!
//!
//!
//!
//!
//!
#![stable(feature = "rust1", since = "1.0.0")]
// Mazhinji ekushandisirwa mune ino module anongoshandiswa mukumisikidza bvunzo.
// Kwakachena kungo bvisa isina kushandiswa_imports yambiro pane kuigadzirisa.
#![cfg_attr(test, allow(unused_imports, dead_code))]

use core::borrow::{Borrow, BorrowMut};
use core::cmp::Ordering::{self, Less};
use core::mem::{self, size_of};
use core::ptr;

use crate::alloc::{Allocator, Global};
use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::vec::Vec;

#[unstable(feature = "slice_range", issue = "76393")]
pub use core::slice::range;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunks;
#[unstable(feature = "array_chunks", issue = "74985")]
pub use core::slice::ArrayChunksMut;
#[unstable(feature = "array_windows", issue = "75027")]
pub use core::slice::ArrayWindows;
#[stable(feature = "slice_get_slice", since = "1.28.0")]
pub use core::slice::SliceIndex;
#[stable(feature = "from_ref", since = "1.28.0")]
pub use core::slice::{from_mut, from_ref};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{from_raw_parts, from_raw_parts_mut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Chunks, Windows};
#[stable(feature = "chunks_exact", since = "1.31.0")]
pub use core::slice::{ChunksExact, ChunksExactMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{ChunksMut, Split, SplitMut};
#[unstable(feature = "slice_group_by", issue = "80552")]
pub use core::slice::{GroupBy, GroupByMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{Iter, IterMut};
#[stable(feature = "rchunks", since = "1.31.0")]
pub use core::slice::{RChunks, RChunksExact, RChunksExactMut, RChunksMut};
#[stable(feature = "slice_rsplit", since = "1.27.0")]
pub use core::slice::{RSplit, RSplitMut};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::slice::{RSplitN, RSplitNMut, SplitN, SplitNMut};

////////////////////////////////////////////////////////////////////////////////
// Basic slice yekuwedzera nzira
////////////////////////////////////////////////////////////////////////////////

// HACK(japaric) inodiwa pakuitwa kwe `vec!` macro panguva yekuyedza NB, ona iyo `hack` module mune ino faira kuti uwane rumwe ruzivo.
//
#[cfg(test)]
pub use hack::into_vec;

// HACK(japaric) inodiwa pakuitwa kwe `Vec::clone` panguva yekuyedza NB, ona iyo `hack` module mune ino faira kuti uwane rumwe ruzivo.
//
#[cfg(test)]
pub use hack::to_vec;

// HACK(japaric): Iine cfg(test) `impl [T]` isipo, aya matatu mashandiro inzira dziri mu `impl [T]` asi kwete mu `core::slice::SliceExt`, tinoda kupa mabasa aya ku `test_permutations` bvunzo
//
//
//
mod hack {
    use core::alloc::Allocator;

    use crate::boxed::Box;
    use crate::vec::Vec;

    // Hatifanire kuwedzera inline hunhu kune izvi sezvo izvi zvichishandiswa mu `vec!` macro zvakanyanya uye zvichikonzera kudzora kweperf.
    // Ona #71204 yekukurukurirana uye mhedzisiro mhedzisiro.
    //
    pub fn into_vec<T, A: Allocator>(b: Box<[T], A>) -> Vec<T, A> {
        unsafe {
            let len = b.len();
            let (b, alloc) = Box::into_raw_with_allocator(b);
            Vec::from_raw_parts_in(b as *mut T, len, len, alloc)
        }
    }

    #[inline]
    pub fn to_vec<T: ConvertVec, A: Allocator>(s: &[T], alloc: A) -> Vec<T, A> {
        T::to_vec(s, alloc)
    }

    pub trait ConvertVec {
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A>
        where
            Self: Sized;
    }

    impl<T: Clone> ConvertVec for T {
        #[inline]
        default fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            struct DropGuard<'a, T, A: Allocator> {
                vec: &'a mut Vec<T, A>,
                num_init: usize,
            }
            impl<'a, T, A: Allocator> Drop for DropGuard<'a, T, A> {
                #[inline]
                fn drop(&mut self) {
                    // SAFETY:
                    // zvinhu zvakamiswa zvakatangwa muchiuno pazasi
                    unsafe {
                        self.vec.set_len(self.num_init);
                    }
                }
            }
            let mut vec = Vec::with_capacity_in(s.len(), alloc);
            let mut guard = DropGuard { vec: &mut vec, num_init: 0 };
            let slots = guard.vec.spare_capacity_mut();
            // .take(slots.len()) zvakafanira kuti LLVM ibvise mabhureki macheki uye ine iri nani codegen kupfuura Zip.
            //
            for (i, b) in s.iter().enumerate().take(slots.len()) {
                guard.num_init = i;
                slots[i].write(b.clone());
            }
            core::mem::forget(guard);
            // SAFETY:
            // iyo vec yakapihwa uye kutangiswa pamusoro kusvika pahurefu uhu.
            unsafe {
                vec.set_len(s.len());
            }
            vec
        }
    }

    impl<T: Copy> ConvertVec for T {
        #[inline]
        fn to_vec<A: Allocator>(s: &[Self], alloc: A) -> Vec<Self, A> {
            let mut v = Vec::with_capacity_in(s.len(), alloc);
            // SAFETY:
            // yakapihwa pamusoro nekwanisi ye `s`, uye wotangisa ku `s.len()` mu ptr::copy_to_non_overlapping pazasi.
            //
            unsafe {
                s.as_ptr().copy_to_nonoverlapping(v.as_mut_ptr(), s.len());
                v.set_len(s.len());
            }
            v
        }
    }
}

#[lang = "slice_alloc"]
#[cfg_attr(not(test), rustc_diagnostic_item = "slice")]
#[cfg(not(test))]
impl<T> [T] {
    /// Anotarisa chidimbu.
    ///
    /// Rudzi urwu rwakatsiga (kureva., Harugadzirise zvakaenzana zvinhu) uye *O*(*n*\*log(* n*)) yakaipa-kesi.
    ///
    /// Kana zvichikwanisika, kusarongeka kusarudzika kunosarudzwa nekuti kazhinji zvinokurumidza kupfuura kurongedza kwakadzikama uye hazvipe muyero wekubatsira.
    /// Ona [`sort_unstable`](slice::sort_unstable).
    ///
    /// # Kuitwa kwazvino
    ///
    /// Iyo algorithm yazvino inogadziriswa, iterative merge mhando yakafuridzirwa ne [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Iyo yakagadzirirwa kukurumidza kwazvo muzviitiko apo chidimbu chiri kuda kurongedzwa, kana chine maviri kana anopfuura akarongedzwa akateedzana akabatanidzwa imwe mushure meimwe.
    ///
    ///
    /// Zvakare, iyo inogovera kwenguva pfupi yekuchengetedza hafu saizi ye `self`, asi yezvidimbu zvidimbu iyo isiri-kugovera yekuisa mhando inoshandiswa pachinzvimbo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5, 4, 1, -3, 2];
    ///
    /// v.sort();
    /// assert!(v == [-5, -3, 1, 2, 4]);
    /// ```
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort(&mut self)
    where
        T: Ord,
    {
        merge_sort(self, |a, b| a.lt(b));
    }

    /// Anotarisa chidimbu nebasa rekuenzanisa.
    ///
    /// Rudzi urwu rwakatsiga (kureva., Harugadzirise zvakaenzana zvinhu) uye *O*(*n*\*log(* n*)) yakaipa-kesi.
    ///
    /// Basa rekuenzanisa rinofanira kutsanangura kurongeka kwakazara kwezvinhu zviri muchidimbu.Kana iyo yekuraira isiri yakakwana, marongero ezvinhu zvacho haana kutsanangurwa.
    /// Iwo odhiyo izere odha kana iri (yeese `a`, `b` uye `c`):
    ///
    /// * yakazara uye antisymmetric: chaiyo imwe ye `a < b`, `a == b` kana `a > b` ichokwadi, uye
    /// * transitive, `a < b` uye `b < c` zvinoreva `a < c`.Izvo zvakafanana zvinofanirwa kubata zvese zviri zviviri `==` uye `>`.
    ///
    /// Semuenzaniso, nepo [`f64`] isingaite [`Ord`] nekuti `NaN != NaN`, tinogona kushandisa `partial_cmp` sebasa redu rekuita kana tichiziva kuti chidimbu hachina `NaN`.
    ///
    ///
    /// ```
    /// let mut floats = [5f64, 4.0, 1.0, 3.0, 2.0];
    /// floats.sort_by(|a, b| a.partial_cmp(b).unwrap());
    /// assert_eq!(floats, [1.0, 2.0, 3.0, 4.0, 5.0]);
    /// ```
    ///
    /// Kana zvichikwanisika, kusarongeka kusarudzika kunosarudzwa nekuti kazhinji zvinokurumidza kupfuura kurongedza kwakadzikama uye hazvipe muyero wekubatsira.
    /// Ona [`sort_unstable_by`](slice::sort_unstable_by).
    ///
    /// # Kuitwa kwazvino
    ///
    /// Iyo algorithm yazvino inogadziriswa, iterative merge mhando yakafuridzirwa ne [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Iyo yakagadzirirwa kukurumidza kwazvo muzviitiko apo chidimbu chiri kuda kurongedzwa, kana chine maviri kana anopfuura akarongedzwa akateedzana akabatanidzwa imwe mushure meimwe.
    ///
    /// Zvakare, iyo inogovera kwenguva pfupi yekuchengetedza hafu saizi ye `self`, asi yezvidimbu zvidimbu iyo isiri-kugovera yekuisa mhando inoshandiswa pachinzvimbo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [5, 4, 1, 3, 2];
    /// v.sort_by(|a, b| a.cmp(b));
    /// assert!(v == [1, 2, 3, 4, 5]);
    ///
    /// // reverse kurongedza
    /// v.sort_by(|a, b| b.cmp(a));
    /// assert!(v == [5, 4, 3, 2, 1]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn sort_by<F>(&mut self, mut compare: F)
    where
        F: FnMut(&T, &T) -> Ordering,
    {
        merge_sort(self, |a, b| compare(a, b) == Less);
    }

    /// Anotarisa chidimbu nekiyi yekubvisa basa.
    ///
    /// Rudzi urwu rwakatsiga (kureva., Harugadziri zvakare zvakaenzana zvinhu) uye *O*(*m*\*n*\*log(* n *)) yakaipa-kesi, iko iko kiyi basa iri* O *(* m *).
    ///
    /// Kune anodhura makiyi mabasa (semuenzaniso
    /// mabasa asiri nyore kuwana chivakwa kana kuita kwekutanga), [`sort_by_cached_key`](slice::sort_by_cached_key) inogona kunge ichikurumidza, sezvo isingadzorere makiyi echinhu.
    ///
    ///
    /// Kana zvichikwanisika, kusarongeka kusarudzika kunosarudzwa nekuti kazhinji zvinokurumidza kupfuura kurongedza kwakadzikama uye hazvipe muyero wekubatsira.
    /// Ona [`sort_unstable_by_key`](slice::sort_unstable_by_key).
    ///
    /// # Kuitwa kwazvino
    ///
    /// Iyo algorithm yazvino inogadziriswa, iterative merge mhando yakafuridzirwa ne [timsort](https://en.wikipedia.org/wiki/Timsort).
    /// Iyo yakagadzirirwa kukurumidza kwazvo muzviitiko apo chidimbu chiri kuda kurongedzwa, kana chine maviri kana anopfuura akarongedzwa akateedzana akabatanidzwa imwe mushure meimwe.
    ///
    /// Zvakare, iyo inogovera kwenguva pfupi yekuchengetedza hafu saizi ye `self`, asi yezvidimbu zvidimbu iyo isiri-kugovera yekuisa mhando inoshandiswa pachinzvimbo.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 1, -3, 2];
    ///
    /// v.sort_by_key(|k| k.abs());
    /// assert!(v == [1, 2, -3, 4, -5]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_key", since = "1.7.0")]
    #[inline]
    pub fn sort_by_key<K, F>(&mut self, mut f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        merge_sort(self, |a, b| f(a).lt(&f(b)));
    }

    /// Anotarisa chidimbu nekiyi yekubvisa basa.
    ///
    /// Panguva yekurongedza, iro rakakosha basa rinodaidzwa kamwe chete pachinhu chimwe.
    ///
    /// Rudzi urwu rwakatsiga (kureva., Harugadziri zvakare zvakaenzana zvinhu) uye *O*(*m*\*n* + *n*\*log(* n *)) yakaipa-kesi, iko iko kiyi basa riri* O *(* m *) .
    ///
    /// Kune yakapusa kiyi mabasa (semuenzaniso, mabasa ari kuwanikwa kwepfuma kana ekutanga mashandiro), [`sort_by_key`](slice::sort_by_key) inogona kunge ichikurumidza.
    ///
    /// # Kuitwa kwazvino
    ///
    /// Iyo algorithm yazvino yakavakirwa pa [pattern-defeating quicksort][pdqsort] naOrson Peters, iyo inosanganisa iyo inokurumidza avhareji kesi yemaitiro akasarudzika quicksort pamwe nekukurumidza zvakanyanya kesi yeheapsort, uku uchizadzisa mutsara mutsara panguva yezvidimbu nemamwe mapatani.
    /// Iyo inoshandisa kumwe kusarudzika kudzivirira kesi dzakashata, asi iine yakatarwa seed kugara ichipa hunhu hwehunhu.
    ///
    /// Mumamiriro ezvinhu akaipisisa, iyo algorithm inogovera kwenguva pfupi kuchengetedza mu `Vec<(K, usize)>` kureba kwechidimbu.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut v = [-5i32, 4, 32, -3, 2];
    ///
    /// v.sort_by_cached_key(|k| k.to_string());
    /// assert!(v == [-3, -5, 2, 32, 4]);
    /// ```
    ///
    /// [pdqsort]: https://github.com/orlp/pdqsort
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "slice_sort_by_cached_key", since = "1.34.0")]
    #[inline]
    pub fn sort_by_cached_key<K, F>(&mut self, f: F)
    where
        F: FnMut(&T) -> K,
        K: Ord,
    {
        // Mubatsiri macro ekunongedzera yedu vector nerudzi diki diki, kutapudza kugoverwa.
        macro_rules! sort_by_key {
            ($t:ty, $slice:ident, $f:ident) => {{
                let mut indices: Vec<_> =
                    $slice.iter().map($f).enumerate().map(|(i, k)| (k, i as $t)).collect();
                // Izvo zvinhu zve `indices` zvakasarudzika, sezvo zvakaiswa indexed, saka chero mhando ichagadzikana mukuremekedza chidimbu chepakutanga.
                // Isu tinoshandisa `sort_unstable` pano nekuti inoda shoma kugoverwa ndangariro.
                //
                indices.sort_unstable();
                for i in 0..$slice.len() {
                    let mut index = indices[i].1;
                    while (index as usize) < i {
                        index = indices[index as usize].1;
                    }
                    indices[i].1 = index;
                    $slice.swap(i, index as usize);
                }
            }};
        }

        let sz_u8 = mem::size_of::<(K, u8)>();
        let sz_u16 = mem::size_of::<(K, u16)>();
        let sz_u32 = mem::size_of::<(K, u32)>();
        let sz_usize = mem::size_of::<(K, usize)>();

        let len = self.len();
        if len < 2 {
            return;
        }
        if sz_u8 < sz_u16 && len <= (u8::MAX as usize) {
            return sort_by_key!(u8, self, f);
        }
        if sz_u16 < sz_u32 && len <= (u16::MAX as usize) {
            return sort_by_key!(u16, self, f);
        }
        if sz_u32 < sz_usize && len <= (u32::MAX as usize) {
            return sort_by_key!(u32, self, f);
        }
        sort_by_key!(usize, self, f)
    }

    /// Kuteedzera `self` mu `Vec` nyowani.
    ///
    /// # Examples
    ///
    /// ```
    /// let s = [10, 40, 30];
    /// let x = s.to_vec();
    /// // Pano, `s` uye `x` inogona kushandurwa zvakazvimiririra.
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn to_vec(&self) -> Vec<T>
    where
        T: Clone,
    {
        self.to_vec_in(Global)
    }

    /// Kopa `self` mune `Vec` nyowani neyakagovana.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_api)]
    ///
    /// use std::alloc::System;
    ///
    /// let s = [10, 40, 30];
    /// let x = s.to_vec_in(System);
    /// // Pano, `s` uye `x` inogona kushandurwa zvakazvimiririra.
    /// ```
    #[inline]
    #[unstable(feature = "allocator_api", issue = "32838")]
    pub fn to_vec_in<A: Allocator>(&self, alloc: A) -> Vec<T, A>
    where
        T: Clone,
    {
        // NB, ona iyo `hack` module mune iyi faira kuti uwane rumwe ruzivo.
        hack::to_vec(self, alloc)
    }

    /// Inoshandura `self` kuita vector isina maonesheni kana kugoverwa.
    ///
    /// Iyo inoguma vector inogona kushandurwazve mubhokisi kuburikidza ne` Vec<T>nzira ye `into_boxed_slice`.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let s: Box<[i32]> = Box::new([10, 40, 30]);
    /// let x = s.into_vec();
    /// // `s` haigone kushandiswa zvekare nekuti yashandurwa kuita `x`.
    ///
    /// assert_eq!(x, vec![10, 40, 30]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn into_vec<A: Allocator>(self: Box<Self, A>) -> Vec<T, A> {
        // NB, ona iyo `hack` module mune iyi faira kuti uwane rumwe ruzivo.
        hack::into_vec(self)
    }

    /// Inogadzira vector nekudzokorora chidimbu `n` nguva.
    ///
    /// # Panics
    ///
    /// Iri basa richaita panic kana chinzvimbo chichifashukira.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// assert_eq!([1, 2].repeat(3), vec![1, 2, 1, 2, 1, 2]);
    /// ```
    ///
    /// panic pamusoro pekufashukira:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// b"0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_generic_slice", since = "1.40.0")]
    pub fn repeat(&self, n: usize) -> Vec<T>
    where
        T: Copy,
    {
        if n == 0 {
            return Vec::new();
        }

        // Kana `n` yakakura kudarika zero, inogona kupatsanurwa se `n = 2^expn + rem (2^expn > rem, expn >= 0, rem >= 0)`.
        // `2^expn` ndiyo nhamba inomiririrwa nechekuruboshwe '1' zvishoma ye `n`, uye `rem` ndicho chikamu chasara che `n`.
        //
        //

        // Uchishandisa `Vec` kuwana `set_len()`.
        let capacity = self.len().checked_mul(n).expect("capacity overflow");
        let mut buf = Vec::with_capacity(capacity);

        // `2^expn` kudzokorora kunoitwa nekuwedzera kaviri `buf` `expn`-times.
        buf.extend(self);
        {
            let mut m = n >> 1;
            // Kana `m > 0`, pangosara mabiti kusvika kuruboshwe '1'.
            while m > 0 {
                // `buf.extend(buf)`:
                unsafe {
                    ptr::copy_nonoverlapping(
                        buf.as_ptr(),
                        (buf.as_mut_ptr() as *mut T).add(buf.len()),
                        buf.len(),
                    );
                    // `buf` ine chinzvimbo che `self.len() * n`.
                    let buf_len = buf.len();
                    buf.set_len(buf_len * 2);
                }

                m >>= 1;
            }
        }

        // `rem` (`=n, 2 ^ expn`) Kudzokorora kunoitwa nekuteedzera kwekutanga `rem` kudzokorora kubva ku `buf` pachayo.
        //
        let rem_len = capacity - buf.len(); // `self.len() * rem`
        if rem_len > 0 {
            // `buf.extend(buf[0 .. rem_len])`:
            unsafe {
                // Uku hakusi kupindirana kubvira `2^expn > rem`.
                ptr::copy_nonoverlapping(
                    buf.as_ptr(),
                    (buf.as_mut_ptr() as *mut T).add(buf.len()),
                    rem_len,
                );
                // `buf.len() + rem_len` zvakaenzana ne `buf.capacity()` (`= self.len() * n`).
                buf.set_len(capacity);
            }
        }
        buf
    }

    /// Flattens chidimbu che `T` mune imwechete kukosha `Self::Output`.
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].concat(), "helloworld");
    /// assert_eq!([[1, 2], [3, 4]].concat(), [1, 2, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn concat<Item: ?Sized>(&self) -> <Self as Concat<Item>>::Output
    where
        Self: Concat<Item>,
    {
        Concat::concat(self)
    }

    /// Flattens chidimbu che `T` mune imwechete kukosha `Self::Output`, ichiisa yakapihwa separator pakati peumwe neumwe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!(["hello", "world"].join(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].join(&0), [1, 2, 0, 3, 4]);
    /// assert_eq!([[1, 2], [3, 4]].join(&[0, 0][..]), [1, 2, 0, 0, 3, 4]);
    /// ```
    #[stable(feature = "rename_connect_to_join", since = "1.3.0")]
    pub fn join<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }

    /// Flattens chidimbu che `T` mune imwechete kukosha `Self::Output`, ichiisa yakapihwa separator pakati peumwe neumwe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # #![allow(deprecated)]
    /// assert_eq!(["hello", "world"].connect(" "), "hello world");
    /// assert_eq!([[1, 2], [3, 4]].connect(&0), [1, 2, 0, 3, 4]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_deprecated(since = "1.3.0", reason = "renamed to join")]
    pub fn connect<Separator>(&self, sep: Separator) -> <Self as Join<Separator>>::Output
    where
        Self: Join<Separator>,
    {
        Join::join(self, sep)
    }
}

#[lang = "slice_u8_alloc"]
#[cfg(not(test))]
impl [u8] {
    /// Inodzorera vector iine kopi yechidimbu ichi apo yega yega yakavezwa kune yayo ASCII yepamusoro kesi yakaenzana.
    ///
    ///
    /// ASCII mavara 'a' kusvika 'z' akaiswa kumepu ku 'A' kusvika 'Z', asi mavara asiri eASCII haana kuchinja.
    ///
    /// Kuti uwedzere kukosha mu-nzvimbo, shandisa [`make_ascii_uppercase`].
    ///
    /// [`make_ascii_uppercase`]: u8::make_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_uppercase();
        me
    }

    /// Inodzorera vector ine kopi yechidimbu ichi apo yega yega yakavezwa kune yayo ASCII yakaderera kesi yakaenzana.
    ///
    ///
    /// ASCII mavara 'A' kusvika 'Z' akaiswa kumepu ku 'a' kusvika 'z', asi mavara asiri eASCII haana kuchinja.
    ///
    /// Kudzikisa kukosha mu-nzvimbo, shandisa [`make_ascii_lowercase`].
    ///
    /// [`make_ascii_lowercase`]: u8::make_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> Vec<u8> {
        let mut me = self.to_vec();
        me.make_ascii_lowercase();
        me
    }
}

////////////////////////////////////////////////////////////////////////////////
// Kuwedzera traits yezvimedu pamusoro pemhando dzedata
////////////////////////////////////////////////////////////////////////////////

/// Mubatsiri trait ye [`[T]: : concat`](slice::concat).
///
/// Note: iyo `Item` yerudzi paramende haina kushandiswa mune ino trait, asi inobvumira ma impls kuti ave akajairika.
/// Pasina iyo, tinowana iko kukanganisa:
///
/// ```error
/// error[E0207]: the type parameter `T` is not constrained by the impl trait, self type, or predica
///    --> src/liballoc/slice.rs:608:6
///     |
/// 608 | impl<T: Clone, V: Borrow<[T]>> Concat for [V] {
///     |      ^ unconstrained type parameter
/// ```
///
/// Izvi zvinodaro nekuti panogona kunge paine `V` mhando ine akawanda `Borrow<[_]>` impls, zvekuti akawanda `T` mhando aigona kushanda:
///
///
/// ```
/// # #[allow(dead_code)]
/// pub struct Foo(Vec<u32>, Vec<String>);
///
/// impl std::borrow::Borrow<[u32]> for Foo {
///     fn borrow(&self) -> &[u32] { &self.0 }
/// }
///
/// impl std::borrow::Borrow<[String]> for Foo {
///     fn borrow(&self) -> &[String] { &self.1 }
/// }
/// ```
///
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Concat<Item: ?Sized> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Rudzi runoguma mushure mekubatanidzwa
    type Output;

    /// Kuteedzerwa kwe [`[T]: : concat`](slice::concat)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn concat(slice: &Self) -> Self::Output;
}

/// Mubatsiri trait ye [`[T]: : Join`](slice::Join)
#[unstable(feature = "slice_concat_trait", issue = "27747")]
pub trait Join<Separator> {
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    /// Rudzi runoguma mushure mekubatanidzwa
    type Output;

    /// Kuteedzerwa kwe [`[T]: : Join`](slice::Join)
    #[unstable(feature = "slice_concat_trait", issue = "27747")]
    fn join(slice: &Self, sep: Separator) -> Self::Output;
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Concat<T> for [V] {
    type Output = Vec<T>;

    fn concat(slice: &Self) -> Vec<T> {
        let size = slice.iter().map(|slice| slice.borrow().len()).sum();
        let mut result = Vec::with_capacity(size);
        for v in slice {
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&T> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &T) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size = slice.iter().map(|v| v.borrow().len()).sum::<usize>() + slice.len() - 1;
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.push(sep.clone());
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<T: Clone, V: Borrow<[T]>> Join<&[T]> for [V] {
    type Output = Vec<T>;

    fn join(slice: &Self, sep: &[T]) -> Vec<T> {
        let mut iter = slice.iter();
        let first = match iter.next() {
            Some(first) => first,
            None => return vec![],
        };
        let size =
            slice.iter().map(|v| v.borrow().len()).sum::<usize>() + sep.len() * (slice.len() - 1);
        let mut result = Vec::with_capacity(size);
        result.extend_from_slice(first.borrow());

        for v in iter {
            result.extend_from_slice(sep);
            result.extend_from_slice(v.borrow())
        }
        result
    }
}

////////////////////////////////////////////////////////////////////////////////
// Standard trait kuitiswa kwezvimedu
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Borrow<[T]> for Vec<T> {
    fn borrow(&self) -> &[T] {
        &self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> BorrowMut<[T]> for Vec<T> {
    fn borrow_mut(&mut self) -> &mut [T] {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Clone> ToOwned for [T] {
    type Owned = Vec<T>;
    #[cfg(not(test))]
    fn to_owned(&self) -> Vec<T> {
        self.to_vec()
    }

    #[cfg(test)]
    fn to_owned(&self) -> Vec<T> {
        hack::to_vec(self, Global)
    }

    fn clone_into(&self, target: &mut Vec<T>) {
        // donhedza chero chinhu mune chakanangwa chisingazonyorwa
        target.truncate(self.len());

        // target.len <= self.len nekuda kwetruncate iri pamusoro, saka zvimedu pano zvinogara zviri-mumiganhu.
        //
        let (init, tail) = self.split_at(target.len());

        // shandisa zvekare zvirimo allocations/resources.
        target.clone_from_slice(init);
        target.extend_from_slice(tail);
    }
}

////////////////////////////////////////////////////////////////////////////////
// Sorting
////////////////////////////////////////////////////////////////////////////////

/// Inoisa `v[0]` mune pre-yakarongedzwa kuteedzana `v[1..]` kuitira kuti `v[..]` yese igadziriswe.
///
/// Iyi ndiyo yakasarudzika subroutine yekuisa mhando.
fn insert_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    if v.len() >= 2 && is_less(&v[1], &v[0]) {
        unsafe {
            // Pane nzira nhatu dzekuisa kuiswa pano:
            //
            // 1. Chinjanai zvinhu zviri pedyo kusvikira yekutanga yasvika kwainosvika.
            //    Nekudaro, nenzira iyi tinoteedzera data kutenderedza kupfuura zvakafanira.
            //    Kana zvinhu zviri zvakakura zvivakwa (zvinodhura kuteedzera), iyi nzira inononoka.
            //
            // 2. Iterate kusvikira nzvimbo chaiyo yechinhu chekutanga yawanikwa.
            // Wobva washandisa zvinhu zvichibudirira kuti zviitire nzvimbo uye wozozviisa mugomba rasara.
            // Iyi nzira yakanaka.
            //
            // 3. Kopa chinhu chekutanga mukuchinja kwenguva pfupi.Iterate kusvikira iyo chaiyo nzvimbo yacho yawanikwa.
            // Sezvatinoenderera mberi, teedzera chega chega chakayambuka chinhu mune slot yakatangira.
            // Chekupedzisira, teedzera data kubva pane yenguva pfupi kusiyanisa mugomba rasara.
            // Iyi nzira yakanaka kwazvo.
            // MaBenchmarks akaratidzira mashandiro ari nani pane ane nzira yechipiri.
            //
            // Dzese nzira dzakatariswa, uye yechitatu yakaratidza zvakanak mhedzisiro.Saka isu takasarudza iyo.
            let mut tmp = mem::ManuallyDrop::new(ptr::read(&v[0]));

            // Pakati pepakati peiyo yekuisa maitiro inogara ichiteverwa ne `hole`, iyo inoshanda zvinangwa zviviri:
            // 1. Inodzivirira kuvimbika kwe `v` kubva ku panics mu `is_less`.
            // 2. Inozadza gomba rakasara mu `v` pakupedzisira.
            //
            // Panic kuchengetedzeka:
            //
            // Kana `is_less` panics panguva ipi neipi yekuita, `hole` inodonha yozadza gomba mu `v` ne `tmp`, nekudaro ichivimbisa kuti `v` ichiri kubata chinhu chese chakatanga kubata kamwechete.
            //
            //
            //
            let mut hole = InsertionHole { src: &mut *tmp, dest: &mut v[1] };
            ptr::copy_nonoverlapping(&v[1], &mut v[0], 1);

            for i in 2..v.len() {
                if !is_less(&v[i], &*tmp) {
                    break;
                }
                ptr::copy_nonoverlapping(&v[i], &mut v[i - 1], 1);
                hole.dest = &mut v[i];
            }
            // `hole` inodonhedzwa uye nekudaro inoteedzera `tmp` mugomba rakasara mu `v`.
        }
    }

    // Kana yakadonhedzwa, makopi kubva ku `src` kuenda ku `dest`.
    struct InsertionHole<T> {
        src: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for InsertionHole<T> {
        fn drop(&mut self) {
            unsafe {
                ptr::copy_nonoverlapping(self.src, self.dest, 1);
            }
        }
    }
}

/// Inobatanidza isina-kuderera inomhanya `v[..mid]` uye `v[mid..]` uchishandisa `buf` sekuchengetedza kwenguva pfupi, uye inochengeta mhedzisiro mu `v[..]`.
///
/// # Safety
///
/// Iwo zvidimbu zviviri zvinofanirwa kunge zvisina chinhu uye `mid` inofanirwa kunge iri mumiganhu.
/// Buffer `buf` inofanirwa kunge yakareba zvakakwana kuti ubate kopi yechidimbu chipfupi.
/// Zvakare, `T` haifanire kunge iri zero-saizi mhando.
unsafe fn merge<T, F>(v: &mut [T], mid: usize, buf: *mut T, is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    let v = v.as_mut_ptr();
    let (v_mid, v_end) = unsafe { (v.add(mid), v.add(len)) };

    // Iyo yekubatanidza maitiro anotanga kuteedzera ipfupi inomhanya mu `buf`.
    // Ipapo inoteedzera iyo ichangoteedzerwa kumhanya uye iyo yakareba kumhanya kuenda kumberi (kana kumashure), ichifananidza yavo inotevera isingatore zvinhu uye kuteedzera idiki (kana yakakura) imwe mu `v`.
    //
    // Kana mangoti mapfupi kumhanya apera zvizere, maitiro acho anoitwa.Kana iyo yakareba kumhanya ikadyiwa kutanga, saka isu tinofanirwa kuteedzera chero chasara cheiyo ipfupi kumhanya mugomba rakasara mu `v`.
    //
    // Iyo yepakati mamiriro eichi chiitiko inogara ichiteverwa ne `hole`, iyo inoshanda zvinangwa zviviri:
    // 1. Inodzivirira kuvimbika kwe `v` kubva ku panics mu `is_less`.
    // 2. Inozadza gomba rakasara mu `v` kana kumhanya kwenguva refu kukatanga kudyiwa.
    //
    // Panic kuchengetedzeka:
    //
    // Kana `is_less` panics panguva ipi neipi yekuita, `hole` inodonha yozadza gomba mu `v` neyakafungidzirwa renji mu `buf`, nekudaro ichivimbisa kuti `v` ichiri kubata chinhu chese chakatanga kubata kamwechete.
    //
    //
    //
    //
    //
    let mut hole;

    if mid <= len - mid {
        // Kumhanya kwekuruboshwe ipfupi.
        unsafe {
            ptr::copy_nonoverlapping(v, buf, mid);
            hole = MergeHole { start: buf, end: buf.add(mid), dest: v };
        }

        // Pakutanga, izvi zvinongedzo zvinonongedza kutanga kweakarongeka.
        let left = &mut hole.start;
        let mut right = v_mid;
        let out = &mut hole.dest;

        while *left < hole.end && right < v_end {
            // Shandisa rutivi ruduku.
            // Kana zvakaenzana, sarudza kuruboshwe kumhanya kuti urambe wakadzikama.
            unsafe {
                let to_copy = if is_less(&*right, &**left) {
                    get_and_increment(&mut right)
                } else {
                    get_and_increment(left)
                };
                ptr::copy_nonoverlapping(to_copy, get_and_increment(out), 1);
            }
        }
    } else {
        // Kumhanya chaiko ipfupi.
        unsafe {
            ptr::copy_nonoverlapping(v_mid, buf, len - mid);
            hole = MergeHole { start: buf, end: buf.add(len - mid), dest: v_mid };
        }

        // Pakutanga, izvi zvinongedzo zvinonongedza zvakapfuura kumagumo emitsara yavo.
        let left = &mut hole.dest;
        let right = &mut hole.end;
        let mut out = v_end;

        while v < *left && buf < *right {
            // Shandisa rutivi rukuru.
            // Kana zvakaenzana, sarudza iyo chaiyo kumhanya kuti urambe wakadzikama.
            unsafe {
                let to_copy = if is_less(&*right.offset(-1), &*left.offset(-1)) {
                    decrement_and_get(left)
                } else {
                    decrement_and_get(right)
                };
                ptr::copy_nonoverlapping(to_copy, decrement_and_get(&mut out), 1);
            }
        }
    }
    // Pakupedzisira, `hole` inodonha.
    // Kana kumhanya kupfupi kwanga kusati kwanyatsodyiwa, chero zvasara zvacho zvino zvinozoteedzerwa mugomba mu `v`.

    unsafe fn get_and_increment<T>(ptr: &mut *mut T) -> *mut T {
        let old = *ptr;
        *ptr = unsafe { ptr.offset(1) };
        old
    }

    unsafe fn decrement_and_get<T>(ptr: &mut *mut T) -> *mut T {
        *ptr = unsafe { ptr.offset(-1) };
        *ptr
    }

    // Kana yakadonhedzwa, inoteedzera iyo `start..end` mu `dest..`.
    struct MergeHole<T> {
        start: *mut T,
        end: *mut T,
        dest: *mut T,
    }

    impl<T> Drop for MergeHole<T> {
        fn drop(&mut self) {
            // `T` haisi zero-saizi mhando, saka zvakanaka kupatsanura nehukuru hwayo.
            let len = (self.end as usize - self.start as usize) / mem::size_of::<T>();
            unsafe {
                ptr::copy_nonoverlapping(self.start, self.dest, len);
            }
        }
    }
}

/// Izvi zvinosanganisa mhando inokwereta mamwe (asi kwete ese) mazano kubva kuTimSort, iyo inotsanangurwa zvakadzama [here](http://svn.python.org/projects/python/trunk/Objects/listsort.txt).
///
///
/// Iyo algorithm inoratidza zvakadzama kuburuka uye kusiri kuburuka zvinotevera, izvo zvinodaidzwa kunzi kumhanya.Pane mudura wekumirira unomhanya usati wabatanidzwa.
/// Kumhanya kwega kwega kutsva kunowanikwa kunosundidzirwa mudura, uyezve mamwe mapari ekumhanyisa ari padhuze akabatanidzwa kudzamara izvi zvinopinda zvakagutsikana:
///
/// 1. ye `i` yega yega mu `1..runs.len()`: `runs[i - 1].len > runs[i].len`
/// 2. ye `i` yega yega mu `2..runs.len()`: `runs[i - 2].len > runs[i - 1].len + runs[i].len`
///
/// Izvo zvinopinda zvinowona kuti iyo yakazara yekumhanyisa nguva iri *O*(*n*\*log(* n*)) yakaipa-kesi.
///
///
fn merge_sort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Zvidimbu zvekusvika pakureba uku zvinogadziriswa uchishandisa yekuisa mhando.
    const MAX_INSERTION: usize = 20;
    // Kumhanya kupfupi kupfupi kunowedzerwa uchishandisa yekuisa mhando kutambanudza angangoita aya akawanda zvinhu.
    const MIN_RUN: usize = 10;

    // Kuronga hakuna hunhu hunonzwisisika pane zero-saizi mhando.
    if size_of::<T>() == 0 {
        return;
    }

    let len = v.len();

    // Mapfupi arrays anorongedzwa mu-nzvimbo kuburikidza neyekuisa mhando kudzivirira migove.
    if len <= MAX_INSERTION {
        if len >= 2 {
            for i in (0..len - 1).rev() {
                insert_head(&mut v[i..], &mut is_less);
            }
        }
        return;
    }

    // Govera buffer yekushandisa seyekutanga ndangariro.Isu tinochengeta hurefu 0 kuti tigone kuchengeta mariri makopi asina kudzika ezviri mukati me `v` pasina kuisa njodzi kumatare anomhanya pamakopi kana `is_less` panics.
    //
    // Kana uchibatanidza kumhanya kwakarongeka, ino bhaundha inobata kopi yeiyo ipfupi kumhanya, iyo ichagara iine kureba zvakanyanya pa `len / 2`.
    //
    let mut buf = Vec::with_capacity(len / 2);

    // Kuti tizive kumhanya kwechisikigo mu `v`, tinoipfuura tichidzokera kumashure.
    // Izvo zvinogona kuratidzika sesarudzo isinganzwisisike, asi funga chokwadi chekuti zvinosanganiswa kazhinji zvinopinda munzira yakatarisana (forwards).
    // Zvinoenderana nemabhenji, kusangana kumberi kuri kukurumidza zvishoma pane kusanganisa kumashure.
    // Kupedzisa, kuzivisa kumhanya nekupfuura kumashure kunovandudza mashandiro.
    let mut runs = vec![];
    let mut end = len;
    while end > 0 {
        // Tsvaga inotevera kumhanya kwechisikigo, uye udzorere kana ichinyatsodzika.
        let mut start = end - 1;
        if start > 0 {
            start -= 1;
            unsafe {
                if is_less(v.get_unchecked(start + 1), v.get_unchecked(start)) {
                    while start > 0 && is_less(v.get_unchecked(start), v.get_unchecked(start - 1)) {
                        start -= 1;
                    }
                    v[start..end].reverse();
                } else {
                    while start > 0 && !is_less(v.get_unchecked(start), v.get_unchecked(start - 1))
                    {
                        start -= 1;
                    }
                }
            }
        }

        // Isa zvimwe zvinhu mumhanyi kana ipfupi.
        // Kuisa mhando inokurumidza kupfuura kusanganisa mhando pane ipfupi kuteedzana, saka izvi zvinonyanya kugadzirisa mashandiro.
        while start > 0 && end - start < MIN_RUN {
            start -= 1;
            insert_head(&mut v[start..end], &mut is_less);
        }

        // Sundira kumhanya uku mudura.
        runs.push(Run { start, len: end - start });
        end = start;

        // Unganidza mamwe mapaundi ekumhanyisa ari padyo kuti ugutse izvo zvinopinda.
        while let Some(r) = collapse(&runs) {
            let left = runs[r + 1];
            let right = runs[r];
            unsafe {
                merge(
                    &mut v[left.start..right.start + right.len],
                    left.len,
                    buf.as_mut_ptr(),
                    &mut is_less,
                );
            }
            runs[r] = Run { start: left.start, len: left.len + right.len };
            runs.remove(r + 1);
        }
    }

    // Chekupedzisira, kumhanya kumwe chete kunofanirwa kuramba kuri mudura.
    debug_assert!(runs.len() == 1 && runs[0].start == 0 && runs[0].len == len);

    // Inoongorora murwi wekumhanya uye inoratidza maviri anotevera ekumhanya kuti asanganise.
    // Zvikurukuru, kana `Some(r)` ikadzoserwa, zvinoreva kuti `runs[r]` uye `runs[r + 1]` inofanira kusanganiswa zvinotevera.
    // Kana iyo algorithm ikaramba ichienderera nekuvaka kumhanya kutsva panzvimbo, `None` inodzoserwa.
    //
    // TimSort ine mukurumbira wekushandisa kwayo ngoro, sezvakatsanangurwa apa:
    // http://envisage-project.eu/timsort-specification-and-verification/
    //
    // Mhedziso yenyaya yacho ndeiyi: isu tinofanirwa kumisikidza zvinopinda pamana kumhanya kumusoro pane mudura.
    // Kumanikidza ivo pazvitatu chete zvepamusoro hazvina kukwana kuti vaone kuti zvinopinda zvicharamba zvakabata *zvese* zvinomhanyisa mudura.
    //
    // Iri basa rinonyatso tarisa zvinowoneka zvemakumi mana ekumhanya.
    // Pamusoro pezvo, kana kumhanya kwepamusoro kuchitanga paindekisi 0, ichagara ichida kubatanidza mashandiro kudzamara sitaki yadonha zvizere, kuti upedze mhando.
    //
    //
    #[inline]
    fn collapse(runs: &[Run]) -> Option<usize> {
        let n = runs.len();
        if n >= 2
            && (runs[n - 1].start == 0
                || runs[n - 2].len <= runs[n - 1].len
                || (n >= 3 && runs[n - 3].len <= runs[n - 2].len + runs[n - 1].len)
                || (n >= 4 && runs[n - 4].len <= runs[n - 3].len + runs[n - 2].len))
        {
            if n >= 3 && runs[n - 3].len < runs[n - 1].len { Some(n - 3) } else { Some(n - 2) }
        } else {
            None
        }
    }

    #[derive(Clone, Copy)]
    struct Run {
        start: usize,
        len: usize,
    }
}