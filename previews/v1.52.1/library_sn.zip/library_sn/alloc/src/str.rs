//! Unicode tambo zvidimbu.
//!
//! *[See also the `str` primitive type](str).*
//!
//! Rudzi rwe `&str` nderimwe remhando mbiri dzetambo, imwe iri `String`.
//! Kusiyana nemumwe wayo `String`, zvirimo zvirimo zvakweretwa.
//!
//! # Kushandisa Kwekutanga
//!
//! Yekutanga tambo kuzivisa ye `&str` mhando:
//!
//! ```
//! let hello_world = "Hello, World!";
//! ```
//!
//! Pano isu takazivisa tambo chaiyo, inozivikanwawo setambo tambo.
//! Tambo zvinyorwa zvine hupenyu hwakagadzikana, zvinoreva kuti tambo `hello_world` inovimbiswa kuve inoshanda kwenguva yese yechirongwa.
//!
//! Tinogona kudoma zvakajeka hupenyu hwe `hello_world 'zvakare:
//!
//! ```
//! let hello_world: &'static str = "Hello, world!";
//! ```

#![stable(feature = "rust1", since = "1.0.0")]
// Mazhinji ekushandisirwa mune ino module anongoshandiswa mukumisikidza bvunzo.
// Kwakachena kungo bvisa isina kushandiswa_imports yambiro pane kuigadzirisa.
#![allow(unused_imports)]

use core::borrow::{Borrow, BorrowMut};
use core::iter::FusedIterator;
use core::mem;
use core::ptr;
use core::str::pattern::{DoubleEndedSearcher, Pattern, ReverseSearcher, Searcher};
use core::unicode::conversions;

use crate::borrow::ToOwned;
use crate::boxed::Box;
use crate::slice::{Concat, Join, SliceIndex};
use crate::string::String;
use crate::vec::Vec;

#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::pattern;
#[stable(feature = "encode_utf16", since = "1.8.0")]
pub use core::str::EncodeUtf16;
#[stable(feature = "split_ascii_whitespace", since = "1.34.0")]
pub use core::str::SplitAsciiWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::SplitWhitespace;
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8, from_utf8_mut, Bytes, CharIndices, Chars};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{from_utf8_unchecked, from_utf8_unchecked_mut, ParseBoolError};
#[stable(feature = "str_escape", since = "1.34.0")]
pub use core::str::{EscapeDebug, EscapeDefault, EscapeUnicode};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{FromStr, Utf8Error};
#[allow(deprecated)]
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Lines, LinesAny};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{MatchIndices, RMatchIndices};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{Matches, RMatches};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplit, Split};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitN, SplitN};
#[stable(feature = "rust1", since = "1.0.0")]
pub use core::str::{RSplitTerminator, SplitTerminator};

/// Note: `str` mu `Concat<str>` haina zvazvinoreva pano.
/// Iyi mhando paramende ye trait inongovapo kuti ikwanise imwe impl.
#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Concat<str> for [S] {
    type Output = String;

    fn concat(slice: &Self) -> String {
        Join::join(slice, "")
    }
}

#[unstable(feature = "slice_concat_ext", issue = "27747")]
impl<S: Borrow<str>> Join<&str> for [S] {
    type Output = String;

    fn join(slice: &Self, sep: &str) -> String {
        unsafe { String::from_utf8_unchecked(join_generic_copy(slice, sep.as_bytes())) }
    }
}

macro_rules! specialize_for_lengths {
    ($separator:expr, $target:expr, $iter:expr; $($num:expr),*) => {{
        let mut target = $target;
        let iter = $iter;
        let sep_bytes = $separator;
        match $separator.len() {
            $(
                // zvishwe zvine saizi dzakaomeswa zvinomhanya zvakanyanya nekukasira zviitiko zvacho nehurefu hwekuparadzanisa
                //
                $num => {
                    for s in iter {
                        copy_slice_and_advance!(target, sep_bytes);
                        let content_bytes = s.borrow().as_ref();
                        copy_slice_and_advance!(target, content_bytes);
                    }
                },
            )*
            _ => {
                // inopesana isina-zero saizi kudonha
                for s in iter {
                    copy_slice_and_advance!(target, sep_bytes);
                    let content_bytes = s.borrow().as_ref();
                    copy_slice_and_advance!(target, content_bytes);
                }
            }
        }
        target
    }}
}

macro_rules! copy_slice_and_advance {
    ($target:expr, $bytes:expr) => {
        let len = $bytes.len();
        let (head, tail) = { $target }.split_at_mut(len);
        head.copy_from_slice($bytes);
        $target = tail;
    };
}

// Yakagadziridzwa kujoina kuitirwa iyo inoshanda kune ese ari maviri Vec<T>(T: Kopa) uye String's vec yemukati Parizvino (2018-05-13) pane bhagi ine mhando inference uye hunyanzvi (ona nyaya #36262) Neichi chikonzero SliceConcat<T>haina hunyanzvi hweT: Kopa uye SliceConcat<str>ndiye chete mushandisi weiri basa.
// Inosiyiwa munzvimbo yenguva iyo iyo yakagadziriswa.
//
// miganho yeString-kujoina ndeye S: Borrow<str>uye yeVec-joina Borrow <[T]> [T] uye str zvese zvinomisikidza AsRef <[T]> kune vamwe T
// => s.borrow().as_ref() uye isu tinogara tine zvidimbu
//
//
//
fn join_generic_copy<B, T, S>(slice: &[S], sep: &[T]) -> Vec<T>
where
    T: Copy,
    B: AsRef<[T]> + ?Sized,
    S: Borrow<B>,
{
    let sep_len = sep.len();
    let mut iter = slice.iter();

    // chidimbu chekutanga ndicho chega chisina kupatsanura chakatungamira
    let first = match iter.next() {
        Some(first) => first,
        None => return vec![],
    };

    // kuverenga urefu hwakazara hweiyo yakabatanidzwa Vec kana iyo `len` kuverenga kukafashukira, isu tichave panic tingadai takapera ndangariro zvakadaro uye iro rese basa rinoda kuti iyo yese Vec yakafanogovaniswa kuchengetedzeka
    //
    //
    //
    let reserved_len = sep_len
        .checked_mul(iter.len())
        .and_then(|n| {
            slice.iter().map(|s| s.borrow().as_ref().len()).try_fold(n, usize::checked_add)
        })
        .expect("attempt to join into collection with len > usize::MAX");

    // gadzira uninitialized buffer
    let mut result = Vec::with_capacity(reserved_len);
    debug_assert!(result.capacity() >= reserved_len);

    result.extend_from_slice(first.borrow().as_ref());

    unsafe {
        let pos = result.len();
        let target = result.get_unchecked_mut(pos..reserved_len);

        // kuteedzera kupatsanura uye zvidimbu pamusoro pasina mabhanhire cheki inogadzira zvishwe zvine akaomeswa makodhi ekuparadzanisa zvidiki makuru makuru kuvandudza kunogona (~ x2)
        //
        //
        let remain = specialize_for_lengths!(sep, target, iter; 0, 1, 2, 3, 4);

        // Yekusanzwisisika yekukwereta kuitiswa kunogona kudzosa akasiyana zvidimbu zvehurefu kuverenga uye iyo chaiyo kopi.
        //
        // Ita shuwa kuti hatifumure asina kuvhurwa mabheti kune iye anofona.
        let result_len = reserved_len - remain.len();
        result.set_len(result_len);
    }
    result
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Borrow<str> for String {
    #[inline]
    fn borrow(&self) -> &str {
        &self[..]
    }
}

#[stable(feature = "string_borrow_mut", since = "1.36.0")]
impl BorrowMut<str> for String {
    #[inline]
    fn borrow_mut(&mut self) -> &mut str {
        &mut self[..]
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ToOwned for str {
    type Owned = String;
    #[inline]
    fn to_owned(&self) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().to_owned()) }
    }

    fn clone_into(&self, target: &mut String) {
        let mut b = mem::take(target).into_bytes();
        self.as_bytes().clone_into(&mut b);
        *target = unsafe { String::from_utf8_unchecked(b) }
    }
}

/// Maitiro etambo tambo.
#[lang = "str_alloc"]
#[cfg(not(test))]
impl str {
    /// Inoshandura `Box<str>` kuita `Box<[u8]>` pasina kuteedzera kana kugovera.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let s = "this is a string";
    /// let boxed_str = s.to_owned().into_boxed_str();
    /// let boxed_bytes = boxed_str.into_boxed_bytes();
    /// assert_eq!(*boxed_bytes, *s.as_bytes());
    /// ```
    #[stable(feature = "str_box_extras", since = "1.20.0")]
    #[inline]
    pub fn into_boxed_bytes(self: Box<str>) -> Box<[u8]> {
        self.into()
    }

    /// Inotsiva zvese zvinoenderana nepateni neimwe tambo.
    ///
    /// `replace` inogadzira [`String`] nyowani, uye inoteedzera iyo data kubva kune iyi tambo slice mairi.
    /// Ndichiri kudaro, inoedza kutsvaga machisi epateni.
    /// Kana ikawana chero, inoitsiva neiyo yekutsiva tambo slice.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let s = "this is old";
    ///
    /// assert_eq!("this is new", s.replace("old", "new"));
    /// ```
    ///
    /// Kana iyo pateni isingaenderane:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replace("cookie monster", "little lamb"));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn replace<'a, P: Pattern<'a>>(&'a self, from: P, to: &str) -> String {
        let mut result = String::new();
        let mut last_end = 0;
        for (start, part) in self.match_indices(from) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Inotsiva yekutanga N machisi epatani neimwe tambo.
    ///
    /// `replacen` inogadzira [`String`] nyowani, uye inoteedzera iyo data kubva kune iyi tambo slice mairi.
    /// Ndichiri kudaro, inoedza kutsvaga machisi epateni.
    /// Kana ikawana chero, inoitsiva nechinotsiva tambo slice kazhinji `count` nguva.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let s = "foo foo 123 foo";
    /// assert_eq!("new new 123 foo", s.replacen("foo", "new", 2));
    /// assert_eq!("faa fao 123 foo", s.replacen('o', "a", 3));
    /// assert_eq!("foo foo new23 foo", s.replacen(char::is_numeric, "new", 1));
    /// ```
    ///
    /// Kana iyo pateni isingaenderane:
    ///
    /// ```
    /// let s = "this is old";
    /// assert_eq!(s, s.replacen("cookie monster", "little lamb", 10));
    /// ```
    #[must_use = "this returns the replaced string as a new allocation, \
                  without modifying the original"]
    #[stable(feature = "str_replacen", since = "1.16.0")]
    pub fn replacen<'a, P: Pattern<'a>>(&'a self, pat: P, to: &str, count: usize) -> String {
        // Ndinovimba kudzikamisa nguva dzekugoverwazve
        let mut result = String::with_capacity(32);
        let mut last_end = 0;
        for (start, part) in self.match_indices(pat).take(count) {
            result.push_str(unsafe { self.get_unchecked(last_end..start) });
            result.push_str(to);
            last_end = start + part.len();
        }
        result.push_str(unsafe { self.get_unchecked(last_end..self.len()) });
        result
    }

    /// Inodzorera yakaderera yakaenzana netambo slice, se [`String`] nyowani.
    ///
    /// 'Lowercase' inotsanangurwa zvinoenderana nematanho eiyo Unicode Inotorwa Nenhumbi Chivakwa `Lowercase`.
    ///
    /// Sezvo mamwe mavara anogona kuwedzera kuita akawanda mavara kana achichinja nyaya, iri basa rinodzosa [`String`] pane kugadzirisa paramende mu-nzvimbo.
    ///
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let s = "HELLO";
    ///
    /// assert_eq!("hello", s.to_lowercase());
    /// ```
    ///
    /// Muenzaniso unonyengera, une sigma:
    ///
    /// ```
    /// let sigma = "Σ";
    ///
    /// assert_eq!("σ", sigma.to_lowercase());
    ///
    /// // asi pakupera kweshoko, ndi ς, kwete σ:
    /// let odysseus = "ὈΔΥΣΣΕΎΣ";
    ///
    /// assert_eq!("ὀδυσσεύς", odysseus.to_lowercase());
    /// ```
    ///
    /// Mitauro isina nyaya haichinji.
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_lowercase());
    /// ```
    ///
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_lowercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for (i, c) in self[..].char_indices() {
            if c == 'Σ' {
                // Σ mepu kuna σ, kunze kwekuguma kweshoko kwarinonongedza ς.
                // Iyi ndiyo chete ine mamiriro (contextual) asi mutauro-wakazvimirira mepu mu `SpecialCasing.txt`, saka yakaoma-kodhi iyo pane kuve neyakajairwa "condition" michina.
                //
                // See https://github.com/rust-lang/rust/issues/26035
                //
                map_uppercase_sigma(self, i, &mut s)
            } else {
                match conversions::to_lower(c) {
                    [a, '\0', _] => s.push(a),
                    [a, b, '\0'] => {
                        s.push(a);
                        s.push(b);
                    }
                    [a, b, c] => {
                        s.push(a);
                        s.push(b);
                        s.push(c);
                    }
                }
            }
        }
        return s;

        fn map_uppercase_sigma(from: &str, i: usize, to: &mut String) {
            // See http://www.unicode.org/versions/Unicode7.0.0/ch03.pdf#G33992
            // yedudziro ye `Final_Sigma`.
            debug_assert!('Σ'.len_utf8() == 2);
            let is_word_final = case_ignoreable_then_cased(from[..i].chars().rev())
                && !case_ignoreable_then_cased(from[i + 2..].chars());
            to.push_str(if is_word_final { "ς" } else { "σ" });
        }

        fn case_ignoreable_then_cased<I: Iterator<Item = char>>(iter: I) -> bool {
            use core::unicode::{Case_Ignorable, Cased};
            match iter.skip_while(|&c| Case_Ignorable(c)).next() {
                Some(c) => Cased(c),
                None => false,
            }
        }
    }

    /// Inodzorera iwo akaenzana akaenzana netambo slice, se [`String`] nyowani.
    ///
    /// 'Uppercase' inotsanangurwa zvinoenderana nematanho eiyo Unicode Inotorwa Nenhumbi Chivakwa `Uppercase`.
    ///
    /// Sezvo mamwe mavara anogona kuwedzera kuita akawanda mavara kana achichinja nyaya, iri basa rinodzosa [`String`] pane kugadzirisa paramende mu-nzvimbo.
    ///
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let s = "hello";
    ///
    /// assert_eq!("HELLO", s.to_uppercase());
    /// ```
    ///
    /// Zvinyorwa zvisina kesi hazvina kuchinjwa:
    ///
    /// ```
    /// let new_year = "农历新年";
    ///
    /// assert_eq!(new_year, new_year.to_uppercase());
    /// ```
    ///
    /// Hunhu humwe hunogona kuve hwakawanda:
    ///
    /// ```
    /// let s = "tschüß";
    ///
    /// assert_eq!("TSCHÜSS", s.to_uppercase());
    /// ```
    ///
    #[stable(feature = "unicode_case_mapping", since = "1.2.0")]
    pub fn to_uppercase(&self) -> String {
        let mut s = String::with_capacity(self.len());
        for c in self[..].chars() {
            match conversions::to_upper(c) {
                [a, '\0', _] => s.push(a),
                [a, b, '\0'] => {
                    s.push(a);
                    s.push(b);
                }
                [a, b, c] => {
                    s.push(a);
                    s.push(b);
                    s.push(c);
                }
            }
        }
        s
    }

    /// Inoshandura [`Box<str>`] kuita [`String`] pasina kuteedzera kana kugovera.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let string = String::from("birthday gift");
    /// let boxed_str = string.clone().into_boxed_str();
    ///
    /// assert_eq!(boxed_str.into_string(), string);
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_string(self: Box<str>) -> String {
        let slice = Box::<[u8]>::from(self);
        unsafe { String::from_utf8_unchecked(slice.into_vec()) }
    }

    /// Inogadzira [`String`] nyowani nekudzokorora tambo `n` nguva.
    ///
    /// # Panics
    ///
    /// Iri basa richaita panic kana chinzvimbo chichifashukira.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// assert_eq!("abc".repeat(4), String::from("abcabcabcabc"));
    /// ```
    ///
    /// panic pamusoro pekufashukira:
    ///
    /// ```should_panic
    /// // this will panic at runtime
    /// "0123456789abcdef".repeat(usize::MAX);
    /// ```
    #[stable(feature = "repeat_str", since = "1.16.0")]
    pub fn repeat(&self, n: usize) -> String {
        unsafe { String::from_utf8_unchecked(self.as_bytes().repeat(n)) }
    }

    /// Inodzorera kopi yeiyi tambo uko yega yega hunhu yakatemerwa kune yayo ASCII yepamusoro kesi yakaenzana.
    ///
    ///
    /// ASCII mavara 'a' kusvika 'z' akaiswa kumepu ku 'A' kusvika 'Z', asi mavara asiri eASCII haana kuchinja.
    ///
    /// Kuti uwedzere kukosha mu-nzvimbo, shandisa [`make_ascii_uppercase`].
    ///
    /// Kuwedzera mavara eASCII kuwedzera kune asiri-ASCII mavara, shandisa [`to_uppercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("GRüßE, JüRGEN ❤", s.to_ascii_uppercase());
    /// ```
    ///
    /// [`make_ascii_uppercase`]: str::make_ascii_uppercase
    /// [`to_uppercase`]: #method.to_uppercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_uppercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_uppercase();
        // make_ascii_uppercase() inochengetedza iyo UTF-8 inogara iripo.
        unsafe { String::from_utf8_unchecked(bytes) }
    }

    /// Inodzorera kopi yeiyi tambo uko yega yega hunhu yakatemerwa kune yayo ASCII yakaderera kesi yakaenzana.
    ///
    ///
    /// ASCII mavara 'A' kusvika 'Z' akaiswa kumepu ku 'a' kusvika 'z', asi mavara asiri eASCII haana kuchinja.
    ///
    /// Kudzikisa kukosha mu-nzvimbo, shandisa [`make_ascii_lowercase`].
    ///
    /// Kudzikisa mavara eASCII kuwedzera kune asiri-ASCII mavara, shandisa [`to_lowercase`].
    ///
    /// # Examples
    ///
    /// ```
    /// let s = "Grüße, Jürgen ❤";
    ///
    /// assert_eq!("grüße, jürgen ❤", s.to_ascii_lowercase());
    /// ```
    ///
    /// [`make_ascii_lowercase`]: str::make_ascii_lowercase
    /// [`to_lowercase`]: #method.to_lowercase
    ///
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn to_ascii_lowercase(&self) -> String {
        let mut bytes = self.as_bytes().to_vec();
        bytes.make_ascii_lowercase();
        // make_ascii_lowercase() inochengetedza iyo UTF-8 inogara iripo.
        unsafe { String::from_utf8_unchecked(bytes) }
    }
}

/// Inoshandura chidimbu chebhokisi remabheti kuita tambo yakarongedzwa isina kutarisa kuti tambo yacho ine UTF-8 inoshanda.
///
///
/// # Examples
///
/// Kushandiswa kwekutanga:
///
/// ```
/// let smile_utf8 = Box::new([226, 152, 186]);
/// let smile = unsafe { std::str::from_boxed_utf8_unchecked(smile_utf8) };
///
/// assert_eq!("☺", &*smile);
/// ```
#[stable(feature = "str_box_extras", since = "1.20.0")]
#[inline]
pub unsafe fn from_boxed_utf8_unchecked(v: Box<[u8]>) -> Box<str> {
    unsafe { Box::from_raw(Box::into_raw(v) as *mut str) }
}