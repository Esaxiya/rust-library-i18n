//! Iyo UTF-8-yakavharidzirwa, tambo inokura.
//!
//! Iyi module ine [`String`] mhando, iyo [`ToString`] trait yekushandura kuita tambo, uye akati wandei mhosho mhando dzinogona kukonzerwa nekushanda ne [`String`] s.
//!
//!
//! # Examples
//!
//! Pane nzira dzakawanda dzekugadzira [`String`] nyowani kubva patambo chaiyo:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let s = String::from("world");
//! let s: String = "also this".into();
//! ```
//!
//! Iwe unogona kugadzira iyo [`String`] nyowani kubva kune iripo ne concatenating ne
//! `+`:
//!
//! ```
//! let s = "Hello".to_string();
//!
//! let message = s + " world!";
//! ```
//!
//! Kana iwe uine vector yechokwadi UTF-8 mabheti, unogona kugadzira [`String`] mairi.Iwe unogona kuita izvo zvakare.
//!
//! ```
//! let sparkle_heart = vec![240, 159, 146, 150];
//!
//! // Tinoziva aya mabheti ari kushanda, saka isu tinoshandisa `unwrap()`.
//! let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
//!
//! assert_eq!("💖", sparkle_heart);
//!
//! let bytes = sparkle_heart.into_bytes();
//!
//! assert_eq!(bytes, [240, 159, 146, 150]);
//! ```
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use core::char::{decode_utf16, REPLACEMENT_CHARACTER};
use core::fmt;
use core::hash;
use core::iter::{FromIterator, FusedIterator};
use core::ops::Bound::{Excluded, Included, Unbounded};
use core::ops::{self, Add, AddAssign, Index, IndexMut, Range, RangeBounds};
use core::ptr;
use core::slice;
use core::str::{lossy, pattern::Pattern};

use crate::borrow::{Cow, ToOwned};
use crate::boxed::Box;
use crate::collections::TryReserveError;
use crate::str::{self, from_boxed_utf8_unchecked, Chars, FromStr, Utf8Error};
use crate::vec::Vec;

/// Iyo UTF-8-yakavharidzirwa, tambo inokura.
///
/// Rudzi rwe `String` ndiyo yakajairika mhando tambo iyo ine muridzi pamusoro pezviri mukati metambo.Iine hukama hwepedyo nemumwe wayo waakakwereta, iyo yechinyakare [`str`].
///
/// # Examples
///
/// Unogona kugadzira `String` kubva ku [a literal string][`str`] ne [`String::from`]:
///
/// [`String::from`]: From::from
///
/// ```
/// let hello = String::from("Hello, world!");
/// ```
///
/// Unogona kuisa [`char`] kune `String` nenzira ye [`push`], uye woisa [`&str`] nenzira ye [`push_str`]:
///
/// ```
/// let mut hello = String::from("Hello, ");
///
/// hello.push('w');
/// hello.push_str("orld!");
/// ```
///
/// [`push`]: String::push
/// [`push_str`]: String::push_str
///
/// Kana iwe uine vector ye UTF-8 byte, unogona kugadzira `String` kubva pairi nenzira ye [`from_utf8`]:
///
/// ```
/// // mamwe mabheti, mu vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Tinoziva aya mabheti ari kushanda, saka isu tinoshandisa `unwrap()`.
/// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// [`from_utf8`]: String::from_utf8
///
/// # UTF-8
///
/// `String`s inogara iri UTF-8 inoshanda.Izvi zvine zvirevo zvishoma, yekutanga yacho ndeyekuti kana iwe uchida tambo isiri-UTF-8, funga [`OsString`].Izvo zvakafanana, asi pasina UTF-8 kumanikidza.Chirevo chechipiri ndechekuti haugone kunongedza mu `String`:
///
/// ```compile_fail,E0277
/// let s = "hello";
///
/// println!("The first letter of s is {}", s[0]); // ERROR!!!
/// ```
///
/// [`OsString`]: ../../std/ffi/struct.OsString.html
///
/// Indexing inoitirwa kuve yenguva-yekushanda mashandiro, asi UTF-8 encoding haitenderi isu kuti tiite izvi.Zvakare, hazvisi pachena kuti ndechipi chinhu icho indekisi inofanira kudzoka: byte, codepoint, kana grapheme sumbu.
/// Iyo [`bytes`] uye [`chars`] nzira dzinodzosera iterators pamusoro pemaviri ekutanga, zvichiteerana.
///
/// [`bytes`]: str::bytes
/// [`chars`]: str::chars
///
/// # Deref
///
/// `String`s ita [`Deref`] `<Target=str>`, uye ugare nhaka dzese nzira dze (``str`].Uye zvakare, izvi zvinoreva kuti iwe unogona kupfuudza `String` kune chiitiko chinotora [`&str`] uchishandisa ampersand (`&`):
///
/// ```
/// fn takes_str(s: &str) { }
///
/// let s = String::from("Hello");
///
/// takes_str(&s);
/// ```
///
/// Izvi zvinogadzira [`&str`] kubva ku `String` uye ndokupfuudza mukati. Iyi shanduko haina mutengo, uye saka kazhinji, mabasa anozogamuchira [`&str`] s sekupokana kunze kwekunge vachida `String` nekuda kwechimwe chikonzero.
///
/// Mune zvimwe zviitiko Rust haina ruzivo rwakakwana kuti iite shanduko iyi, inozivikanwa se [`Deref`] yekumanikidza.Mumuenzaniso unotevera tambo chidimbu [`&'a str`][`&str`] inoisa iyo trait `TraitExample`, uye basa `example_func` rinotora chero chinhu chinoshandisa trait.
/// Mune ino kesi Rust ingangoda kuita mbiri dzakashandurwa, idzo Rust isina nzira dzekuita.
/// Nechikonzero ichocho, muenzaniso unotevera haunga nyorwe.
///
/// ```compile_fail,E0277
/// trait TraitExample {}
///
/// impl<'a> TraitExample for &'a str {}
///
/// fn example_func<A: TraitExample>(example_arg: A) {}
///
/// let example_string = String::from("example_string");
/// example_func(&example_string);
/// ```
///
/// Pane sarudzo mbiri dzinogona kushanda panzvimbo.Chekutanga chaizove chekushandura mutsetse `example_func(&example_string);` kuva `example_func(example_string.as_str());`, uchishandisa nzira [`as_str()`] kuburitsa pachena tambo tambo ine tambo.
/// Nzira yechipiri inoshandura `example_func(&example_string);` kuita `example_func(&*example_string);`.
/// Mune ino kesi tiri kurekodha `String` kuenda ku [`str`][`&str`], tobva tareferensa iyo [`str`][`&str`] kudzokera ku [`&str`].
/// Nzira yechipiri yakanyanya kudimikira, zvisinei vese vanoshanda kuita shanduko zvakajeka pane kuvimba neshanduko isinganetsi.
///
/// # Representation
///
/// `String` inoumbwa nezvinhu zvitatu: chinongedzo kune mamwe mabheti, kureba uye kugona.Iyo pointer inonongedzera kune yemukati buffer `String` inoshandisa kuchengetedza data rayo.Kureba ndiyo nhamba yemabheti parizvino akachengetwa mubhafa, uye kugona ihwo hukuru hwechibhagi mumabheti.
///
/// Nekudaro, iyo urefu ichagara iri shoma pane kana yakaenzana nekwanisi.
///
/// Iyi buffer inogara yakachengetwa pamurwi.
///
/// Unogona kutarisa izvi ne [`as_ptr`], [`len`], uye [`capacity`] nzira:
///
/// ```
/// use std::mem;
///
/// let story = String::from("Once upon a time...");
///
/// // FIXME Gadziridza izvi kana vec_into_raw_parts yakagadzikana.
/// // Dzivirira otomatiki kudonhedza iyo String data
/// let mut story = mem::ManuallyDrop::new(story);
///
/// let ptr = story.as_mut_ptr();
/// let len = story.len();
/// let capacity = story.capacity();
///
/// // nyaya ine gumi nemapfumbamwe byte
/// assert_eq!(19, len);
///
/// // Tinogona kuvaka zvakare tambo kubva ptr, len, uye kugona.
/// // Izvi zvese hazvina kuchengetedzeka nekuti isu tine basa rekuona kuti zvinhu zvacho zvinoshanda:
/////
/// let s = unsafe { String::from_raw_parts(ptr, len, capacity) } ;
///
/// assert_eq!(String::from("Once upon a time..."), s);
/// ```
///
/// [`as_ptr`]: str::as_ptr
/// [`len`]: String::len
/// [`capacity`]: String::capacity
///
/// Kana `String` iine huwandu hwakakwana, inowedzera zvinhu mairi haizopa zvakare.Semuenzaniso, funga chirongwa ichi:
///
/// ```
/// let mut s = String::new();
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// Izvi zvichaburitsa zvinotevera:
///
/// ```text
/// 0
/// 5
/// 10
/// 20
/// 20
/// 40
/// ```
///
/// Pakutanga, isu hatina ndangariro dzakagoverwa zvachose, asi sezvatinobatirira patambo, inowedzera kugona kwayo nenzira kwayo.Kana isu pachinzvimbo toshandisa iyo [`with_capacity`] nzira kugovera iwo akakwana kugona pakutanga:
///
/// ```
/// let mut s = String::with_capacity(25);
///
/// println!("{}", s.capacity());
///
/// for _ in 0..5 {
///     s.push_str("hello");
///     println!("{}", s.capacity());
/// }
/// ```
///
/// [`with_capacity`]: String::with_capacity
///
/// Isu tinopedzisira tave nechimwe chakabuda.
///
/// ```text
/// 25
/// 25
/// 25
/// 25
/// 25
/// 25
/// ```
///
/// Pano, hapana chikonzero chekugovera zvimwe ndangariro mukati mechidzitiro.
///
/// [`str`]: prim@str
/// [`&str`]: prim@str
/// [`Deref`]: core::ops::Deref
/// [`as_str()`]: String::as_str
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[derive(PartialOrd, Eq, Ord)]
#[cfg_attr(not(test), rustc_diagnostic_item = "string_type")]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct String {
    vec: Vec<u8>,
}

/// Iko kunogona kukanganisa kukosha kana uchishandura `String` kubva ku UTF-8 byte vector.
///
/// Iyi mhando ndiyo yekukanganisa mhando ye [`from_utf8`] nzira pa [`String`].
/// Yakagadzirwa nenzira yakadai yekunyatso kudzivirira kuiswazve: iyo [`into_bytes`] nzira ichadzorera byte vector iyo yaishandiswa mukuyedza kwekuedza.
///
///
/// [`from_utf8`]: String::from_utf8
/// [`into_bytes`]: FromUtf8Error::into_bytes
///
/// Rudzi rwe [`Utf8Error`] rwunopihwa ne [`std::str`] inomiririra kukanganisa kunogona kuitika pakushandura chidimbu che [`u8`] s kuva [`&str`].
/// Mupfungwa iyi, yakafanana ne `FromUtf8Error`, uye unogona kuwana imwe kubva ku `FromUtf8Error` kuburikidza nenzira ye [`utf8_error`].
///
/// [`Utf8Error`]: core::str::Utf8Error
/// [`std::str`]: core::str
/// [`&str`]: prim@str
/// [`utf8_error`]: Self::utf8_error
///
/// # Examples
///
/// Kushandiswa kwekutanga:
///
/// ```
/// // mamwe asiri mabheti, mu vector
/// let bytes = vec![0, 159];
///
/// let value = String::from_utf8(bytes);
///
/// assert!(value.is_err());
/// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
/// ```
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct FromUtf8Error {
    bytes: Vec<u8>,
    error: Utf8Error,
}

/// Iyo inogona kukanganisa kukosha kana uchishandura `String` kubva ku UTF-16 byte slice.
///
/// Iyi mhando ndiyo yekukanganisa mhando ye [`from_utf16`] nzira pa [`String`].
///
/// [`from_utf16`]: String::from_utf16
/// # Examples
///
/// Kushandiswa kwekutanga:
///
/// ```
/// // 𝄞mu<invalid>ic
/// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
///           0xD800, 0x0069, 0x0063];
///
/// assert!(String::from_utf16(v).is_err());
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[derive(Debug)]
pub struct FromUtf16Error(());

impl String {
    /// Inogadzira `String` itsva isina chinhu.
    ///
    /// Tichifunga kuti `String` haina chinhu, izvi hazvipe chero yekutanga buffer.Ipo izvi zvichireva kuti iko kwekutanga kushanda kwakachipa kwazvo, kunogona kukonzera kugoverwa kwakanyanya gare gare paunowedzera data.
    ///
    /// Kana iwe uine zano rekuti ingani data iyo `String` ichabata, funga nezve [`with_capacity`] nzira yekudzivirira yakawandisa kugoverwa zvakare.
    ///
    /// [`with_capacity`]: String::with_capacity
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let s = String::new();
    /// ```
    ///
    ///
    ///
    #[inline]
    #[rustc_const_stable(feature = "const_string_new", since = "1.32.0")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const fn new() -> String {
        String { vec: Vec::new() }
    }

    /// Inogadzira nyowani isina chinhu `String` ine imwe chinzvimbo.
    ///
    /// `String`s ine yemukati buffer yekubata yavo data.
    /// Iko kugona ndiko kureba kweiyo buffer, uye kunogona kubvunzwa nenzira ye [`capacity`].
    /// Iyi nzira inogadzira isina `String`, asi imwe ine yekutanga buffer iyo inogona kubata `capacity` byte.
    /// Izvi zvinobatsira kana iwe uchigona kunge uchinge uchinge uchinge uchinge uchinge uchinge uchinge uchinge uchinge uchinge uchinge uchinge uchinge uchinge uchinge uchinge uchinge uchinge uchinge uchinge uchitsvaga iyo `String`, ichideredza huwandu hwezvekugovaniswa kwainofanira kuita.
    ///
    ///
    /// [`capacity`]: String::capacity
    ///
    /// Kana chinzvimbo chakapihwa chiri `0`, hapana mugove uchaitika, uye nzira iyi yakafanana neiyo [`new`] nzira.
    ///
    /// [`new`]: String::new
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    ///
    /// // Iyo tambo haina kana chars, kunyangwe iine simba rezvimwe
    /// assert_eq!(s.len(), 0);
    ///
    /// // Izvi zvese zvinoitwa pasina kuisazve nzvimbo ...
    /// let cap = s.capacity();
    /// for _ in 0..10 {
    ///     s.push('a');
    /// }
    ///
    /// assert_eq!(s.capacity(), cap);
    ///
    /// // ... asi izvi zvinogona kuita kuti tambo igadziriswe
    /// s.push('a');
    /// ```
    ///
    ///
    #[inline]
    #[doc(alias = "alloc")]
    #[doc(alias = "malloc")]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn with_capacity(capacity: usize) -> String {
        String { vec: Vec::with_capacity(capacity) }
    }

    // HACK(japaric): ne cfg(test) iyo yakasarudzika `[T]::to_vec` nzira, iyo inodikanwa kune iyi nzira tsananguro, haiwanikwe.
    // Sezvo isu tisingade iyi nzira yekuyedza, ini ndichango stub iyo NB ona iyo slice::hack module mu slice.rs kuti uwane rumwe ruzivo
    //
    //
    #[inline]
    #[cfg(test)]
    pub fn from_str(_: &str) -> String {
        panic!("not available with cfg(test)");
    }

    /// Inoshandura vector yemabheti kuita `String`.
    ///
    /// Tambo ([`String`]) inogadzirwa nemabheti ([`u8`]), uye vector yemabheti ([`Vec<u8>`]) inogadzirwa nemabheti, saka basa iri rinoshanduka pakati pezviviri.
    /// Haasi ese mabheti zvidimbu anoshanda `String`s, zvisinei: `String` inoda kuti ive yechokwadi UTF-8.
    /// `from_utf8()` cheki kuona kuti mabheti anoshanda UTF-8, uyezve inoita shanduko.
    ///
    /// Kana iwe uine chokwadi chekuti chidimbu chebheti chiri kushanda UTF-8, uye iwe haudi kupinza pamusoro pechiratidzo chechokwadi, pane vhezheni isina kuchengetedzeka yeiri basa, [`from_utf8_unchecked`], ine hunhu hwakafanana asi inodarika cheki.
    ///
    ///
    /// Iyi nzira ichatarisira kuti isateedzera iyo vector, nekuda kwekugona.
    ///
    /// Kana iwe uchida [`&str`] panzvimbo ye `String`, funga [`str::from_utf8`].
    ///
    /// Kupesana kweiyi nzira i [`into_bytes`].
    ///
    /// # Errors
    ///
    /// Inodzorera [`Err`] kana chidimbu chisiri UTF-8 ine tsananguro yekuti sei mabheti akapihwa asiri UTF-8.Iyo vector yawakatamisa mukati inosanganisirwa.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// // mamwe mabheti, mu vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// // Tinoziva aya mabheti ari kushanda, saka isu tinoshandisa `unwrap()`.
    /// let sparkle_heart = String::from_utf8(sparkle_heart).unwrap();
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Mabhete asiri iwo:
    ///
    /// ```
    /// // mamwe asiri mabheti, mu vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// assert!(String::from_utf8(sparkle_heart).is_err());
    /// ```
    ///
    /// Ona maHTML e [`FromUtf8Error`] kuti uwane rumwe ruzivo pane zvaunogona kuita nekanganiso iyi.
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    /// [`Vec<u8>`]: crate::vec::Vec
    /// [`&str`]: prim@str
    /// [`into_bytes`]: String::into_bytes
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8(vec: Vec<u8>) -> Result<String, FromUtf8Error> {
        match str::from_utf8(&vec) {
            Ok(..) => Ok(String { vec }),
            Err(e) => Err(FromUtf8Error { bytes: vec, error: e }),
        }
    }

    /// Inoshandura chidimbu chemabheti kuita tambo, kusanganisira asiri mavara.
    ///
    /// Tambo dzakagadzirwa nemabheti ([`u8`]), uye chidimbu chemabheti ([`&[u8]`][byteslice]) chakagadzirwa nematete, saka basa iri rinoshanduka pakati pezviviri.Haasi ese mabheti zvidimbu ndezvechokwadi tambo, zvisinei: tambo dzinofanirwa kuve dzinoshanda UTF-8.
    /// Munguva yekushandurwa uku, `from_utf8_lossy()` inotsiva chero zvisirizvo UTF-8 zvinoteedzana ne [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD], inotaridzika seiyi:
    ///
    /// [byteslice]: prim@slice
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// Kana iwe uine chokwadi chekuti chidimbu chebheti chiri kushanda UTF-8, uye iwe usingade kukwira pamusoro peiyo shanduko, pane isina kuchengetedzeka vhezheni yeiri basa, [`from_utf8_unchecked`], ine hunhu hwakafanana asi inodarika macheki.
    ///
    ///
    /// [`from_utf8_unchecked`]: String::from_utf8_unchecked
    ///
    /// Iri basa rinodzosera [`Cow<'a, str>`].Kana chidimbu chedu chisingabvumirwe UTF-8, saka tinofanirwa kuisa mavara ekutsiva, ayo anozoshandura saizi yetambo, uye nekudaro, inoda `String`.
    /// Asi kana yatove UTF-8 inoshanda, hatidi mugove mutsva.
    /// Rudzi urwu rwekudzoka runotibvumidza kubata ese maviri kesi.
    ///
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// // mamwe mabheti, mu vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = String::from_utf8_lossy(&sparkle_heart);
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    /// Mabhete asiri iwo:
    ///
    /// ```
    /// // mamwe asiri mabheti
    /// let input = b"Hello \xF0\x90\x80World";
    /// let output = String::from_utf8_lossy(input);
    ///
    /// assert_eq!("Hello �World", output);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf8_lossy(v: &[u8]) -> Cow<'_, str> {
        let mut iter = lossy::Utf8Lossy::from_bytes(v).chunks();

        let (first_valid, first_broken) = if let Some(chunk) = iter.next() {
            let lossy::Utf8LossyChunk { valid, broken } = chunk;
            if valid.len() == v.len() {
                debug_assert!(broken.is_empty());
                return Cow::Borrowed(valid);
            }
            (valid, broken)
        } else {
            return Cow::Borrowed("");
        };

        const REPLACEMENT: &str = "\u{FFFD}";

        let mut res = String::with_capacity(v.len());
        res.push_str(first_valid);
        if !first_broken.is_empty() {
            res.push_str(REPLACEMENT);
        }

        for lossy::Utf8LossyChunk { valid, broken } in iter {
            res.push_str(valid);
            if !broken.is_empty() {
                res.push_str(REPLACEMENT);
            }
        }

        Cow::Owned(res)
    }

    /// Sarudza UTF-16 - yakanyorwa vector `v` kuita `String`, ichidzosa [`Err`] kana `v` iine chero data risiri iro.
    ///
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// // 𝄞music
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0x0069, 0x0063];
    /// assert_eq!(String::from("𝄞music"),
    ///            String::from_utf16(v).unwrap());
    ///
    /// // 𝄞mu<invalid>ic
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0xD800, 0x0069, 0x0063];
    /// assert!(String::from_utf16(v).is_err());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16(v: &[u16]) -> Result<String, FromUtf16Error> {
        // Izvi hazviitwe kuburikidza collect: : <Result<_, _>> () yezvikonzero zvekuita.
        // FIXME: basa racho rinogona kurerukazve kana #48994 yakavharwa.
        let mut ret = String::with_capacity(v.len());
        for c in decode_utf16(v.iter().cloned()) {
            if let Ok(c) = c {
                ret.push(c);
            } else {
                return Err(FromUtf16Error(()));
            }
        }
        Ok(ret)
    }

    /// Sarudza UTF-16-yakadzvanywa slice `v` mu `String`, ichitsiva isiriyo data ne [the replacement character (`U+FFFD`)][U+FFFD].
    ///
    /// Kusiyana ne [`from_utf8_lossy`] iyo inodzosera [`Cow<'a, str>`], `from_utf16_lossy` inodzosera `String` sezvo iyo UTF-16 kusvika UTF-8 kutendeuka inoda kugoverwa kwendangariro.
    ///
    ///
    /// [`from_utf8_lossy`]: String::from_utf8_lossy
    /// [`Cow<'a, str>`]: crate::borrow::Cow
    /// [U+FFFD]: core::char::REPLACEMENT_CHARACTER
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// // 𝄞mus<invalid>ic<invalid>
    /// let v = &[0xD834, 0xDD1E, 0x006d, 0x0075,
    ///           0x0073, 0xDD1E, 0x0069, 0x0063,
    ///           0xD834];
    ///
    /// assert_eq!(String::from("𝄞mus\u{FFFD}ic\u{FFFD}"),
    ///            String::from_utf16_lossy(v));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn from_utf16_lossy(v: &[u16]) -> String {
        decode_utf16(v.iter().cloned()).map(|r| r.unwrap_or(REPLACEMENT_CHARACTER)).collect()
    }

    /// Inowora `String` muzvinhu zvayo zvisvinu.
    ///
    /// Inodzorera pointer mbishi kune iri pasi data, kureba kwetambo (mumabheti), uye iro rakapihwa iro dhata (mune mabheti).
    /// Idzi ndidzo nharo dzakaenzana muhurongwa hwakaenzana sekupokana ku [`from_raw_parts`].
    ///
    /// Mushure mekudaidza iri basa, ari kufona ndiye anoitisa ndangariro yakambotarisirwa ne `String`.
    /// Iyo chete nzira yekuita izvi kushandura mbishi mbichana, kureba, uye kugona kudzosera mu `String` ine [`from_raw_parts`] basa, ichibvumira muparadzi kuti aite iyo yekuchenesa.
    ///
    ///
    /// [`from_raw_parts`]: String::from_raw_parts
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(vec_into_raw_parts)]
    /// let s = String::from("hello");
    ///
    /// let (ptr, len, cap) = s.into_raw_parts();
    ///
    /// let rebuilt = unsafe { String::from_raw_parts(ptr, len, cap) };
    /// assert_eq!(rebuilt, "hello");
    /// ```
    ///
    ///
    ///
    ///
    #[unstable(feature = "vec_into_raw_parts", reason = "new API", issue = "65816")]
    pub fn into_raw_parts(self) -> (*mut u8, usize, usize) {
        self.vec.into_raw_parts()
    }

    /// Inogadzira `String` nyowani kubva pakureba, kugona, uye pointer.
    ///
    /// # Safety
    ///
    /// Izvi hazvina kuchengetedzeka zvakanyanya, nekuda kwenhamba yevapindiri vasina kuongororwa:
    ///
    /// * Ndangariro dziri pa `buf` dzinofanirwa kunge dzakambogoverwa nemugovanisi mumwechete raibhurari yakajairika inoshandisa, pamwe nekuenderana kunodiwa kweizvo chaizvo 1.
    /// * `length` inoda kuve shoma kana kuenzana ne `capacity`.
    /// * `capacity` inoda kuve iyo chaiyo kukosha.
    /// * Yekutanga `length` mabheti pa `buf` inoda kuve inoshanda UTF-8.
    ///
    /// Kutyora izvi kunogona kukonzera matambudziko sekushatisa zvemukati wedhisheni yedhairekitori.
    ///
    /// Iyo muridzi we `buf` inonyatso kuendeswa ku `String` iyo inogona kuzogovana, kuisazve nzvimbo kana kushandura zvirimo mundangariro zvakanongedzerwa kune iye anonongedza paunoda.
    /// Ita shuwa kuti hapana chimwe chinhu chinoshandisa pointer mushure mekufona basa iri.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// use std::mem;
    ///
    /// unsafe {
    ///     let s = String::from("hello");
    ///
    ///     // FIXME Gadziridza izvi kana vec_into_raw_parts yakagadzikana.
    ///     // Dzivirira otomatiki kudonhedza iyo String data
    ///     let mut s = mem::ManuallyDrop::new(s);
    ///
    ///     let ptr = s.as_mut_ptr();
    ///     let len = s.len();
    ///     let capacity = s.capacity();
    ///
    ///     let s = String::from_raw_parts(ptr, len, capacity);
    ///
    ///     assert_eq!(String::from("hello"), s);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_raw_parts(buf: *mut u8, length: usize, capacity: usize) -> String {
        unsafe { String { vec: Vec::from_raw_parts(buf, length, capacity) } }
    }

    /// Inoshandura vector yemabheti kuita `String` pasina kutarisa kuti tambo yacho ine UTF-8 inoshanda.
    ///
    /// Ona iyo yakachengeteka vhezheni, [`from_utf8`], kuti uwane rumwe ruzivo.
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Safety
    ///
    /// Iri basa harina kuchengeteka nekuti haritarise kuti mabheti akapfuudzwa kwairi anoshanda UTF-8.
    /// Kana kudzvinyirirwa uku kukatyorwa, kunogona kukonzera ndangariro kusagadzikana nezviitiko nevashandisi ve future ye `String`, sekumwe kwaraibhurari yakajairwa inotora kuti `String`s ndeyechokwadi UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// // mamwe mabheti, mu vector
    /// let sparkle_heart = vec![240, 159, 146, 150];
    ///
    /// let sparkle_heart = unsafe {
    ///     String::from_utf8_unchecked(sparkle_heart)
    /// };
    ///
    /// assert_eq!("💖", sparkle_heart);
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn from_utf8_unchecked(bytes: Vec<u8>) -> String {
        String { vec: bytes }
    }

    /// Inoshandura `String` kuita Byte vector.
    ///
    /// Izvi zvinoshandisa iyo `String`, saka hatidi kutevedzera zvirimo.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let s = String::from("hello");
    /// let bytes = s.into_bytes();
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111][..], &bytes[..]);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.vec
    }

    /// Inobvisa tambo tambo ine iyo yose `String`.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let s = String::from("foo");
    ///
    /// assert_eq!("foo", s.as_str());
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_str(&self) -> &str {
        self
    }

    /// Inoshandura `String` kuita tambo inoshanduka.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let mut s = String::from("foobar");
    /// let s_mut_str = s.as_mut_str();
    ///
    /// s_mut_str.make_ascii_uppercase();
    ///
    /// assert_eq!("FOOBAR", s_mut_str);
    /// ```
    #[inline]
    #[stable(feature = "string_as_str", since = "1.7.0")]
    pub fn as_mut_str(&mut self) -> &mut str {
        self
    }

    /// Inoshandisa tambo yakapihwa tambo kumagumo eiyi `String`.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.push_str("bar");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push_str(&mut self, string: &str) {
        self.vec.extend_from_slice(string.as_bytes())
    }

    /// Inodzorera kugona kweiyi `String`, mumabheti.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let s = String::with_capacity(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn capacity(&self) -> usize {
        self.vec.capacity()
    }

    /// Inovimbisa kuti kugona kweTring iyi ingangoita `additional` mabheti yakakura kupfuura kureba kwayo.
    ///
    /// Iko kugona kunogona kuwedzerwa kupfuura anopfuura `additional` mabheti kana ikasarudza, kudzivirira kugara uchigadziriswa.
    ///
    ///
    /// Kana iwe usiri kuda iyi "at least" maitiro, ona iyo [`reserve_exact`] nzira.
    ///
    /// # Panics
    ///
    /// Panics kana iyo nyowani nyowani ichizadza [`usize`].
    ///
    /// [`reserve_exact`]: String::reserve_exact
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Izvi zvinogona kusanyanya kuwedzera kugona:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s ikozvino ine hurefu hwe2 uye inokwana gumi
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Sezvo isu tatova neakawedzera masimba e8, kudaidza izvi ...
    /// s.reserve(8);
    ///
    /// // ... hainyatso kuwedzera.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve(&mut self, additional: usize) {
        self.vec.reserve(additional)
    }

    /// Inovimbisa kuti ichi chinzvimbo che `String` chiri `additional` mabheti akakura kupfuura kureba kwayo.
    ///
    /// Funga kushandisa nzira ye [`reserve`] kunze kwekunge iwe uchinyatso kuziva zvirinani pane inogovera.
    ///
    ///
    /// [`reserve`]: String::reserve
    ///
    /// # Panics
    ///
    /// Panics kana iyo nyowani nyowani ichizadza `usize`.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let mut s = String::new();
    ///
    /// s.reserve_exact(10);
    ///
    /// assert!(s.capacity() >= 10);
    /// ```
    ///
    /// Izvi zvinogona kusanyanya kuwedzera kugona:
    ///
    /// ```
    /// let mut s = String::with_capacity(10);
    /// s.push('a');
    /// s.push('b');
    ///
    /// // s ikozvino ine hurefu hwe2 uye inokwana gumi
    /// assert_eq!(2, s.len());
    /// assert_eq!(10, s.capacity());
    ///
    /// // Sezvo isu tatova neakawedzera masimba e8, kudaidza izvi ...
    /// s.reserve_exact(8);
    ///
    /// // ... hainyatso kuwedzera.
    /// assert_eq!(10, s.capacity());
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn reserve_exact(&mut self, additional: usize) {
        self.vec.reserve_exact(additional)
    }

    /// Inoedza kuchengetedza kugona kweinenge `additional` zvimwe zvinhu zvekuiswa mune yakapihwa `String`.
    /// Iko kuunganidzira kunogona kuchengetedza imwe nzvimbo kudzivirira kudzoreredzwa patsva.
    /// Mushure mekufona `reserve`, chinzvimbo chichava chakakura kupfuura kana chakaenzana ne `self.len() + additional`.
    /// Haina chainoita kana kugona kwatova kukwana.
    ///
    /// # Errors
    ///
    /// Kana chinzvimbo chikafashukira, kana iye anogovera akamhan'ara kukundikana, ipapo kukanganisa kunodzorerwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Pre-chengetedza ndangariro, ichibuda kana tisingakwanise
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Iye zvino tinoziva izvi hazvigone OOM pakati pebasa redu rakaoma
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve(additional)
    }

    /// Inoedza kuchengetedza hushoma hunyanzvi hweiyo chaiyo `additional` zvimwe zvinhu zvekuiswa mune yakapihwa `String`.
    ///
    /// Mushure mekufona `reserve_exact`, chinzvimbo chichava chakakura kupfuura kana chakaenzana ne `self.len() + additional`.
    /// Hapana chainoita kana kugona kwacho kwatova kukwana.
    ///
    /// Ziva kuti anogovera anogona kupa iyo yekuunganidza yakawanda nzvimbo kupfuura yainokumbira.
    /// Naizvozvo, kugona hakugone kuvimbwa nako kuti kuve kushoma.
    /// Sarudza `reserve` kana kuiswa kwe future kuri kutarisirwa.
    ///
    /// # Errors
    ///
    /// Kana chinzvimbo chikafashukira, kana iye anogovera akamhan'ara kukundikana, ipapo kukanganisa kunodzorerwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_reserve)]
    /// use std::collections::TryReserveError;
    ///
    /// fn process_data(data: &str) -> Result<String, TryReserveError> {
    ///     let mut output = String::new();
    ///
    ///     // Pre-chengetedza ndangariro, ichibuda kana tisingakwanise
    ///     output.try_reserve(data.len())?;
    ///
    ///     // Iye zvino tinoziva izvi hazvigone OOM pakati pebasa redu rakaoma
    ///     output.push_str(data);
    ///
    ///     Ok(output)
    /// }
    /// # process_data("rust").expect("why is the test harness OOMing on 4 bytes?");
    /// ```
    ///
    #[unstable(feature = "try_reserve", reason = "new API", issue = "48043")]
    pub fn try_reserve_exact(&mut self, additional: usize) -> Result<(), TryReserveError> {
        self.vec.try_reserve_exact(additional)
    }

    /// Inoderedza kugona kweiyi `String` kuenzanisa kureba kwayo.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to_fit();
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn shrink_to_fit(&mut self) {
        self.vec.shrink_to_fit()
    }

    /// Inoderedza kugona kweiyi `String` ine yakasungwa yakasungwa.
    ///
    /// Iyo chinzvimbo chinosara chingangoita chakakura seese ari maviri kureba uye kukosha kwakapihwa.
    ///
    ///
    /// Kana iyo yazvino kugona iri pasi peyakaderera muganho, iyi haina-op.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(shrink_to)]
    /// let mut s = String::from("foo");
    ///
    /// s.reserve(100);
    /// assert!(s.capacity() >= 100);
    ///
    /// s.shrink_to(10);
    /// assert!(s.capacity() >= 10);
    /// s.shrink_to(0);
    /// assert!(s.capacity() >= 3);
    /// ```
    #[inline]
    #[unstable(feature = "shrink_to", reason = "new API", issue = "56431")]
    pub fn shrink_to(&mut self, min_capacity: usize) {
        self.vec.shrink_to(min_capacity)
    }

    /// Inoshandisa iyo yakapihwa [`char`] kusvika kumagumo kweiyi `String`.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let mut s = String::from("abc");
    ///
    /// s.push('1');
    /// s.push('2');
    /// s.push('3');
    ///
    /// assert_eq!("abc123", s);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn push(&mut self, ch: char) {
        match ch.len_utf8() {
            1 => self.vec.push(ch as u8),
            _ => self.vec.extend_from_slice(ch.encode_utf8(&mut [0; 4]).as_bytes()),
        }
    }

    /// Inodzosera chidimbu cheyaka by this String`zviri mukati.
    ///
    /// Kupesana kweiyi nzira i [`from_utf8`].
    ///
    /// [`from_utf8`]: String::from_utf8
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// assert_eq!(&[104, 101, 108, 108, 111], s.as_bytes());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.vec
    }

    /// Inopfupisa iyi `String` kune yakatarwa kureba.
    ///
    /// Kana `new_len` yakakura kudarika tambo kureba zvazvino, izvi hazvina zvazvinoita.
    ///
    ///
    /// Ziva kuti iyi nzira haina maturo pane yakapihwa kugona kwetambo
    ///
    /// # Panics
    ///
    /// Panics kana `new_len` isina kureva pamuganhu we [`char`].
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// s.truncate(2);
    ///
    /// assert_eq!("he", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn truncate(&mut self, new_len: usize) {
        if new_len <= self.len() {
            assert!(self.is_char_boundary(new_len));
            self.vec.truncate(new_len)
        }
    }

    /// Inobvisa hunhu hwekupedzisira kubva patambo buffer uye ndokudzorera.
    ///
    /// Inodzorera [`None`] kana iyi `String` isina chinhu.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('o'));
    /// assert_eq!(s.pop(), Some('f'));
    ///
    /// assert_eq!(s.pop(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn pop(&mut self) -> Option<char> {
        let ch = self.chars().rev().next()?;
        let newlen = self.len() - ch.len_utf8();
        unsafe {
            self.vec.set_len(newlen);
        }
        Some(ch)
    }

    /// Inobvisa [`char`] kubva kune iyi `String` panzvimbo ye byte uye yoidzosera.
    ///
    /// Uku ndiko kushanda kwe *O*(*n*), sezvo ichida kuteedzera chese chinhu chiri mubhafa.
    ///
    /// # Panics
    ///
    /// Panics kana `idx` yakakura kudarika kana yakaenzana nehurefu hwetambo, kana ikasarara pamuganhu we [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// assert_eq!(s.remove(0), 'f');
    /// assert_eq!(s.remove(1), 'o');
    /// assert_eq!(s.remove(0), 'o');
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn remove(&mut self, idx: usize) -> char {
        let ch = match self[idx..].chars().next() {
            Some(ch) => ch,
            None => panic!("cannot remove a char from the end of a string"),
        };

        let next = idx + ch.len_utf8();
        let len = self.len();
        unsafe {
            ptr::copy(self.vec.as_ptr().add(next), self.vec.as_mut_ptr().add(idx), len - next);
            self.vec.set_len(len - (next - idx));
        }
        ch
    }

    /// Bvisa zvese zvinoenderana nepateni `pat` mu `String`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("Trees are not green, the sky is not blue.");
    /// s.remove_matches("not ");
    /// assert_eq!("Trees are green, the sky is blue.", s);
    /// ```
    ///
    /// Matches anozoonekwa obviswa iteratively, saka mune zviitiko apo mapatani anoenderana, chete yekutanga pateni ndiyo ichabviswa:
    ///
    ///
    /// ```
    /// #![feature(string_remove_matches)]
    /// let mut s = String::from("banana");
    /// s.remove_matches("ana");
    /// assert_eq!("bna", s);
    /// ```
    #[unstable(feature = "string_remove_matches", reason = "new API", issue = "72826")]
    pub fn remove_matches<'a, P>(&'a mut self, pat: P)
    where
        P: for<'x> Pattern<'x>,
    {
        use core::str::pattern::Searcher;

        let matches = {
            let mut searcher = pat.into_searcher(self);
            let mut matches = Vec::new();

            while let Some(m) = searcher.next_match() {
                matches.push(m);
            }

            matches
        };

        let len = self.len();
        let mut shrunk_by = 0;

        // Kachengeteka: kutanga uye kupera kunenge kuri pa utf8 byte miganhu pa
        // iwo maSearcher maHTML
        unsafe {
            for (start, end) in matches {
                ptr::copy(
                    self.vec.as_mut_ptr().add(end - shrunk_by),
                    self.vec.as_mut_ptr().add(start - shrunk_by),
                    len - end,
                );
                shrunk_by += end - start;
            }
            self.vec.set_len(len - shrunk_by);
        }
    }

    /// Inochengetedza chete mavara akataurwa neyakafanotaurwa.
    ///
    /// Mune mamwe mazwi, bvisa mavara ese `c` zvekuti `f(c)` inodzosera `false`.
    /// Iyi nzira inoshanda munzvimbo, ichishanyira chimiro chega chega chaizvo kamwechete muhurongwa hwepakutanga, uye inochengetedza iwo marongero evatambi vakachengetedzwa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let mut s = String::from("f_o_ob_ar");
    ///
    /// s.retain(|c| c != '_');
    ///
    /// assert_eq!(s, "foobar");
    /// ```
    ///
    /// Iyo chaiyo odha inogona kubatsira mukutevera kunze kwenyika, senge index.
    ///
    /// ```
    /// let mut s = String::from("abcde");
    /// let keep = [false, true, true, false, true];
    /// let mut i = 0;
    /// s.retain(|_| (keep[i], i += 1).0);
    /// assert_eq!(s, "bce");
    /// ```
    #[inline]
    #[stable(feature = "string_retain", since = "1.26.0")]
    pub fn retain<F>(&mut self, mut f: F)
    where
        F: FnMut(char) -> bool,
    {
        let len = self.len();
        let mut del_bytes = 0;
        let mut idx = 0;

        unsafe {
            self.vec.set_len(0);
        }

        while idx < len {
            let ch = unsafe { self.get_unchecked(idx..len).chars().next().unwrap() };
            let ch_len = ch.len_utf8();

            if !f(ch) {
                del_bytes += ch_len;
            } else if del_bytes > 0 {
                unsafe {
                    ptr::copy(
                        self.vec.as_ptr().add(idx),
                        self.vec.as_mut_ptr().add(idx - del_bytes),
                        ch_len,
                    );
                }
            }

            // Nongedzera idx kune inotevera char
            idx += ch_len;
        }

        unsafe {
            self.vec.set_len(len - del_bytes);
        }
    }

    /// Inoisa hunhu mune iyi `String` pane byte chinzvimbo.
    ///
    /// Uku ndiko kushanda kwe *O*(*n*) sezvo kuchida kuteedzera chese chinhu chiri mubhafa.
    ///
    /// # Panics
    ///
    /// Panics kana `idx` yakakura kudarika iyo `String`hurefu, kana kana isiri pamuganhu we [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let mut s = String::with_capacity(3);
    ///
    /// s.insert(0, 'f');
    /// s.insert(1, 'o');
    /// s.insert(2, 'o');
    ///
    /// assert_eq!("foo", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn insert(&mut self, idx: usize, ch: char) {
        assert!(self.is_char_boundary(idx));
        let mut bits = [0; 4];
        let bits = ch.encode_utf8(&mut bits).as_bytes();

        unsafe {
            self.insert_bytes(idx, bits);
        }
    }

    unsafe fn insert_bytes(&mut self, idx: usize, bytes: &[u8]) {
        let len = self.len();
        let amt = bytes.len();
        self.vec.reserve(amt);

        unsafe {
            ptr::copy(self.vec.as_ptr().add(idx), self.vec.as_mut_ptr().add(idx + amt), len - idx);
            ptr::copy(bytes.as_ptr(), self.vec.as_mut_ptr().add(idx), amt);
            self.vec.set_len(len + amt);
        }
    }

    /// Inoisa tambo yakatsemurwa muiyi `String` pane byte chinzvimbo.
    ///
    /// Uku ndiko kushanda kwe *O*(*n*) sezvo kuchida kuteedzera chese chinhu chiri mubhafa.
    ///
    /// # Panics
    ///
    /// Panics kana `idx` yakakura kudarika iyo `String`hurefu, kana kana isiri pamuganhu we [`char`].
    ///
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let mut s = String::from("bar");
    ///
    /// s.insert_str(0, "foo");
    ///
    /// assert_eq!("foobar", s);
    /// ```
    ///
    #[inline]
    #[stable(feature = "insert_str", since = "1.16.0")]
    pub fn insert_str(&mut self, idx: usize, string: &str) {
        assert!(self.is_char_boundary(idx));

        unsafe {
            self.insert_bytes(idx, string.as_bytes());
        }
    }

    /// Inodzorera zvinogona kuchinjika kune zviri mune iyi `String`.
    ///
    /// # Safety
    ///
    /// Iri basa harina kuchengeteka nekuti haritarise kuti mabheti akapfuudzwa kwairi anoshanda UTF-8.
    /// Kana kudzvinyirirwa uku kukatyorwa, kunogona kukonzera ndangariro kusagadzikana nezviitiko nevashandisi ve future ye `String`, sekumwe kwaraibhurari yakajairwa inotora kuti `String`s ndeyechokwadi UTF-8.
    ///
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let mut s = String::from("hello");
    ///
    /// unsafe {
    ///     let vec = s.as_mut_vec();
    ///     assert_eq!(&[104, 101, 108, 108, 111][..], &vec[..]);
    ///
    ///     vec.reverse();
    /// }
    /// assert_eq!(s, "olleh");
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub unsafe fn as_mut_vec(&mut self) -> &mut Vec<u8> {
        &mut self.vec
    }

    /// Inodzorera kureba kweiyi `String`, mumabheti, kwete [`char`] s kana graphemes.
    /// Mune mamwe mazwi, zvinogona kunge zvisiri izvo zvinotariswa nemunhu kureba kwetambo.
    ///
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = String::from("foo");
    /// assert_eq!(a.len(), 3);
    ///
    /// let fancy_f = String::from("ƒoo");
    /// assert_eq!(fancy_f.len(), 4);
    /// assert_eq!(fancy_f.chars().count(), 3);
    /// ```
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn len(&self) -> usize {
        self.vec.len()
    }

    /// Inodzorera `true` kana iyi `String` iine urefu hwe zero, uye `false` neimwe nzira.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let mut v = String::new();
    /// assert!(v.is_empty());
    ///
    /// v.push('a');
    /// assert!(!v.is_empty());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Inopatsanura tambo kuita maviri pane yakapihwa index index.
    ///
    /// Inodzorera ichangobva kupihwa `String`.
    /// `self` ine mabheti `[0, at)`, uye iyo yakadzorerwa `String` ine mabheti `[at, len)`.
    /// `at` inofanirwa kunge iri pamuganhu we UTF-8 kodhi kodhi.
    ///
    /// Ziva kuti kugona kwe `self` hakuchinje.
    ///
    /// # Panics
    ///
    /// Panics kana `at` isiri pamuganhu we `UTF-8` kodhi, kana kana iri kupfuura yekupedzisira kodhi kodhi yetambo.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// # fn main() {
    /// let mut hello = String::from("Hello, World!");
    /// let world = hello.split_off(7);
    /// assert_eq!(hello, "Hello, ");
    /// assert_eq!(world, "World!");
    /// # }
    /// ```
    #[inline]
    #[stable(feature = "string_split_off", since = "1.16.0")]
    #[must_use = "use `.truncate()` if you don't need the other half"]
    pub fn split_off(&mut self, at: usize) -> String {
        assert!(self.is_char_boundary(at));
        let other = self.vec.split_off(at);
        unsafe { String::from_utf8_unchecked(other) }
    }

    /// Inotora iyi `String`, ichibvisa zvese zvirimo.
    ///
    /// Kunyangwe izvi zvichireva kuti `String` ichave iine hurefu hwe zero, haina kubata kugona kwayo.
    ///
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let mut s = String::from("foo");
    ///
    /// s.clear();
    ///
    /// assert!(s.is_empty());
    /// assert_eq!(0, s.len());
    /// assert_eq!(3, s.capacity());
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn clear(&mut self) {
        self.vec.clear()
    }

    /// Inogadzira inodhonza iterator iyo inobvisa yakatarwa renji mu `String` uye inoburitsa iyo yakabviswa `chars`.
    ///
    ///
    /// Note: Iyo element renji inobviswa kunyangwe iyo iterator isina kudyiwa kusvika kumagumo.
    ///
    /// # Panics
    ///
    /// Panics kana pekutanga kana pekupedzisira pozha zvisiri pamuganhu we [`char`], kana kana vari kunze kwemiganhu.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Bvisa renji kumusoro kusvika the kubva patambo
    /// let t: String = s.drain(..beta_offset).collect();
    /// assert_eq!(t, "α is alpha, ");
    /// assert_eq!(s, "β is beta");
    ///
    /// // Range rakazara rinobvisa tambo
    /// s.drain(..);
    /// assert_eq!(s, "");
    /// ```
    ///
    ///
    #[stable(feature = "drain", since = "1.6.0")]
    pub fn drain<R>(&mut self, range: R) -> Drain<'_>
    where
        R: RangeBounds<usize>,
    {
        // Kuchengetedzwa kwendangariro
        //
        // Iyo String vhezheni ye Drain haina yekuchengetedza kuchengetedzeka nyaya dzeiyo vector vhezheni.
        // Iyo data ingori mabheti akajeka.
        // Nekuti iyo renji yekubvisa inoitika muDrop, kana iyo Drain iterator yakaburitswa, kubviswa hakuzoitika.
        //
        let Range { start, end } = slice::range(range, ..self.len());
        assert!(self.is_char_boundary(start));
        assert!(self.is_char_boundary(end));

        // Bvisa zvikwereti zviviri panguva imwe chete.
        // Iyo &mut Tambo haizosvikike kusvikira iteration yapera, muDrop.
        let self_ptr = self as *mut _;
        // Kachengeteka: `slice::range` uye `is_char_boundary` vanoita akakodzera miganhu macheki.
        let chars_iter = unsafe { self.get_unchecked(start..end) }.chars();

        Drain { start, end, iter: chars_iter, string: self_ptr }
    }

    /// Inobvisa iyo yakatarwa renji mu tambo, uye ndokuitsiva netambo yakapihwa.
    /// Tambo yakapihwa haidi kuve yakaenzana kureba nehurefu.
    ///
    /// # Panics
    ///
    /// Panics kana pekutanga kana pekupedzisira pozha zvisiri pamuganhu we [`char`], kana kana vari kunze kwemiganhu.
    ///
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let mut s = String::from("α is alpha, β is beta");
    /// let beta_offset = s.find('β').unwrap_or(s.len());
    ///
    /// // Chinja renji kumusoro kusvika iyo β kubva patambo
    /// s.replace_range(..beta_offset, "Α is capital alpha; ");
    /// assert_eq!(s, "Α is capital alpha; β is beta");
    /// ```
    ///
    #[stable(feature = "splice", since = "1.27.0")]
    pub fn replace_range<R>(&mut self, range: R, replace_with: &str)
    where
        R: RangeBounds<usize>,
    {
        // Kuchengetedzwa kwendangariro
        //
        // Tsiva_range haina yekuchengetedza kuchengetedzeka nyaya dze vector Splice.
        // yeiyo vector vhezheni.Iyo data ingori mabheti akajeka.

        // Yambiro: Kujekesa kusiyanisa uku kungave kusinganzwisisike (#81138)
        let start = range.start_bound();
        match start {
            Included(&n) => assert!(self.is_char_boundary(n)),
            Excluded(&n) => assert!(self.is_char_boundary(n + 1)),
            Unbounded => {}
        };
        // Yambiro: Kujekesa kusiyanisa uku kungave kusinganzwisisike (#81138)
        let end = range.end_bound();
        match end {
            Included(&n) => assert!(self.is_char_boundary(n + 1)),
            Excluded(&n) => assert!(self.is_char_boundary(n)),
            Unbounded => {}
        };

        // Kushandisa `range` zvakare kungave kusanzwisisika (#81138) Isu tinofungidzira miganho yakataurwa ne `range` inoramba yakafanana, asi kumisikidza kwekupikisa kunogona kuchinja pakati pekufona
        //
        //
        unsafe { self.as_mut_vec() }.splice((start, end), replace_with.bytes());
    }

    /// Inoshandura iyi `String` kuita [`Bhokisi`]`<`[`str`] `>`.
    ///
    /// Izvi zvinodonhedza chero yakawandisa kugona.
    ///
    /// [`str`]: prim@str
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let s = String::from("hello");
    ///
    /// let b = s.into_boxed_str();
    /// ```
    #[stable(feature = "box_str", since = "1.4.0")]
    #[inline]
    pub fn into_boxed_str(self) -> Box<str> {
        let slice = self.vec.into_boxed_slice();
        unsafe { from_boxed_utf8_unchecked(slice) }
    }
}

impl FromUtf8Error {
    /// Inodzorera chidimbu che [`u8`] s mabheti akaedza kuchinjira ku `String`.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// // mamwe asiri mabheti, mu vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(&[0, 159], value.unwrap_err().as_bytes());
    /// ```
    #[stable(feature = "from_utf8_error_as_bytes", since = "1.26.0")]
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes[..]
    }

    /// Inodzorera mabheti akaedzwa kuchinjira ku `String`.
    ///
    /// Iyi nzira yakanyatso kuvakwa kudzivirira kugoverwa.
    /// Ichapedza iko kukanganisa, kufambisa kunze mabheti, kuti kopi yemabheti haidi kuitirwa.
    ///
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// // mamwe asiri mabheti, mu vector
    /// let bytes = vec![0, 159];
    ///
    /// let value = String::from_utf8(bytes);
    ///
    /// assert_eq!(vec![0, 159], value.unwrap_err().into_bytes());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn into_bytes(self) -> Vec<u8> {
        self.bytes
    }

    /// Tora `Utf8Error` kuti uwane rumwe ruzivo nezve kutadza kutendeuka.
    ///
    /// Rudzi rwe [`Utf8Error`] rwunopihwa ne [`std::str`] inomiririra kukanganisa kunogona kuitika pakushandura chidimbu che [`u8`] s kuva [`&str`].
    /// Mupfungwa iyi, yakafanana ne `FromUtf8Error`.
    /// Ona zvinyorwa zvaro kuti uwane rumwe ruzivo rwekuishandisa.
    ///
    /// [`std::str`]: core::str
    /// [`&str`]: prim@str
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// // mamwe asiri mabheti, mu vector
    /// let bytes = vec![0, 159];
    ///
    /// let error = String::from_utf8(bytes).unwrap_err().utf8_error();
    ///
    /// // yekutanga byte haishande pano
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    pub fn utf8_error(&self) -> Utf8Error {
        self.error
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.error, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for FromUtf16Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt("invalid utf-16: lone surrogate found", f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Clone for String {
    fn clone(&self) -> Self {
        String { vec: self.vec.clone() }
    }

    fn clone_from(&mut self, source: &Self) {
        self.vec.clone_from(&source.vec);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromIterator<char> for String {
    fn from_iter<I: IntoIterator<Item = char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "string_from_iter_by_ref", since = "1.17.0")]
impl<'a> FromIterator<&'a char> for String {
    fn from_iter<I: IntoIterator<Item = &'a char>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> FromIterator<&'a str> for String {
    fn from_iter<I: IntoIterator<Item = &'a str>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl FromIterator<String> for String {
    fn from_iter<I: IntoIterator<Item = String>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Nekuti isu tiri kuteterera pamusoro pe`String`s, isu tinokwanisa kudzivirira kanenge kamwechete kupihwa nekuwana tambo yekutanga kubva kune iterator uye kuimisikidza kwairi tambo dzese dzinotevera.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(mut buf) => {
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl FromIterator<Box<str>> for String {
    fn from_iter<I: IntoIterator<Item = Box<str>>>(iter: I) -> String {
        let mut buf = String::new();
        buf.extend(iter);
        buf
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> FromIterator<Cow<'a, str>> for String {
    fn from_iter<I: IntoIterator<Item = Cow<'a, str>>>(iter: I) -> String {
        let mut iterator = iter.into_iter();

        // Nekuti isu tiri kutenderera pamusoro peCoWs, isu tinogona (potentially) kunzvenga kana kamwe chete kugoverwa nekutora chinhu chekutanga nekuchinjisa kwachiri zvinhu zvese zvinotevera.
        //
        //
        match iterator.next() {
            None => String::new(),
            Some(cow) => {
                let mut buf = cow.into_owned();
                buf.extend(iterator);
                buf
            }
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Extend<char> for String {
    fn extend<I: IntoIterator<Item = char>>(&mut self, iter: I) {
        let iterator = iter.into_iter();
        let (lower_bound, _) = iterator.size_hint();
        self.reserve(lower_bound);
        iterator.for_each(move |c| self.push(c));
    }

    #[inline]
    fn extend_one(&mut self, c: char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "extend_ref", since = "1.2.0")]
impl<'a> Extend<&'a char> for String {
    fn extend<I: IntoIterator<Item = &'a char>>(&mut self, iter: I) {
        self.extend(iter.into_iter().cloned());
    }

    #[inline]
    fn extend_one(&mut self, &c: &'a char) {
        self.push(c);
    }

    #[inline]
    fn extend_reserve(&mut self, additional: usize) {
        self.reserve(additional);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> Extend<&'a str> for String {
    fn extend<I: IntoIterator<Item = &'a str>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(s));
    }

    #[inline]
    fn extend_one(&mut self, s: &'a str) {
        self.push_str(s);
    }
}

#[stable(feature = "box_str2", since = "1.45.0")]
impl Extend<Box<str>> for String {
    fn extend<I: IntoIterator<Item = Box<str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }
}

#[stable(feature = "extend_string", since = "1.4.0")]
impl Extend<String> for String {
    fn extend<I: IntoIterator<Item = String>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: String) {
        self.push_str(&s);
    }
}

#[stable(feature = "herd_cows", since = "1.19.0")]
impl<'a> Extend<Cow<'a, str>> for String {
    fn extend<I: IntoIterator<Item = Cow<'a, str>>>(&mut self, iter: I) {
        iter.into_iter().for_each(move |s| self.push_str(&s));
    }

    #[inline]
    fn extend_one(&mut self, s: Cow<'a, str>) {
        self.push_str(&s);
    }
}

/// Iyo nyore impl iyo inomiririra kune impl ye `&str`.
///
/// # Examples
///
/// ```
/// assert_eq!(String::from("Hello world").find("world"), Some(6));
/// ```
#[unstable(
    feature = "pattern",
    reason = "API not fully fleshed out and ready to be stabilized",
    issue = "27721"
)]
impl<'a, 'b> Pattern<'a> for &'b String {
    type Searcher = <&'b str as Pattern<'a>>::Searcher;

    fn into_searcher(self, haystack: &'a str) -> <&'b str as Pattern<'a>>::Searcher {
        self[..].into_searcher(haystack)
    }

    #[inline]
    fn is_contained_in(self, haystack: &'a str) -> bool {
        self[..].is_contained_in(haystack)
    }

    #[inline]
    fn is_prefix_of(self, haystack: &'a str) -> bool {
        self[..].is_prefix_of(haystack)
    }

    #[inline]
    fn strip_prefix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_prefix_of(haystack)
    }

    #[inline]
    fn is_suffix_of(self, haystack: &'a str) -> bool {
        self[..].is_suffix_of(haystack)
    }

    #[inline]
    fn strip_suffix_of(self, haystack: &'a str) -> Option<&'a str> {
        self[..].strip_suffix_of(haystack)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for String {
    #[inline]
    fn eq(&self, other: &String) -> bool {
        PartialEq::eq(&self[..], &other[..])
    }
    #[inline]
    fn ne(&self, other: &String) -> bool {
        PartialEq::ne(&self[..], &other[..])
    }
}

macro_rules! impl_eq {
    ($lhs:ty, $rhs: ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$rhs> for $lhs {
            #[inline]
            fn eq(&self, other: &$rhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$rhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        #[allow(unused_lifetimes)]
        impl<'a, 'b> PartialEq<$lhs> for $rhs {
            #[inline]
            fn eq(&self, other: &$lhs) -> bool {
                PartialEq::eq(&self[..], &other[..])
            }
            #[inline]
            fn ne(&self, other: &$lhs) -> bool {
                PartialEq::ne(&self[..], &other[..])
            }
        }
    };
}

impl_eq! { String, str }
impl_eq! { String, &'a str }
impl_eq! { Cow<'a, str>, str }
impl_eq! { Cow<'a, str>, &'b str }
impl_eq! { Cow<'a, str>, String }

#[stable(feature = "rust1", since = "1.0.0")]
impl Default for String {
    /// Inogadzira isina `String`.
    #[inline]
    fn default() -> String {
        String::new()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Debug for String {
    #[inline]
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl hash::Hash for String {
    #[inline]
    fn hash<H: hash::Hasher>(&self, hasher: &mut H) {
        (**self).hash(hasher)
    }
}

/// Inoshandisa `+` opareta yekubatanidza tambo mbiri.
///
/// Izvi zvinoshandisa iyo `String` kuruboshwe-kuruboshwe uye inoshandisa zvakare bhaudha yayo (kuimere kana zvichidikanwa).
/// Izvi zvinoitirwa kudzivirira kugovera `String` nyowani nekuteedzera zvese zvirimo pane ese mashandiro, izvo zvinotungamira kune *O*(*n*^ 2) yekumhanyisa nguva kana uchivaka *n*-byte tambo nekudzokorora concatenation.
///
///
/// Tambo iri kurudyi-ruoko inongokweretwa chete;zvirimo zvinoteedzerwa mu `String` yakadzoserwa.
///
/// # Examples
///
/// Kubatanidza maviri `String`s inotora yekutanga nemutengo uye inokwereta yechipiri:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a + &b;
/// // `a` inofambiswa uye haichakwanise kushandiswa pano.
/// ```
///
/// Kana iwe uchida kuramba uchishandisa yekutanga `String`, unogona kuiisa uye woomerera kune iyo dombo pane:
///
/// ```
/// let a = String::from("hello");
/// let b = String::from(" world");
/// let c = a.clone() + &b;
/// // `a` ichiri kushanda pano.
/// ```
///
/// Kubatanidza zvidimbu zve `&str` zvinogona kuitwa nekushandura yekutanga kuva `String`:
///
/// ```
/// let a = "hello";
/// let b = " world";
/// let c = a.to_string() + b;
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Add<&str> for String {
    type Output = String;

    #[inline]
    fn add(mut self, other: &str) -> String {
        self.push_str(other);
        self
    }
}

/// Inoshandisa `+=` mushandisi yekushandisa kune `String`.
///
/// Iyi ine maitiro akafanana neiyo [`push_str`][String::push_str] nzira.
#[stable(feature = "stringaddassign", since = "1.12.0")]
impl AddAssign<&str> for String {
    #[inline]
    fn add_assign(&mut self, other: &str) {
        self.push_str(other);
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::Range<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::Range<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeTo<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeTo<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFrom<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeFrom<usize>) -> &str {
        &self[..][index]
    }
}
#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Index<ops::RangeFull> for String {
    type Output = str;

    #[inline]
    fn index(&self, _index: ops::RangeFull) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::Index<ops::RangeToInclusive<usize>> for String {
    type Output = str;

    #[inline]
    fn index(&self, index: ops::RangeToInclusive<usize>) -> &str {
        Index::index(&**self, index)
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::Range<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::Range<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeTo<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeTo<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFrom<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeFrom<usize>) -> &mut str {
        &mut self[..][index]
    }
}
#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::IndexMut<ops::RangeFull> for String {
    #[inline]
    fn index_mut(&mut self, _index: ops::RangeFull) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}
#[stable(feature = "inclusive_range", since = "1.26.0")]
impl ops::IndexMut<ops::RangeToInclusive<usize>> for String {
    #[inline]
    fn index_mut(&mut self, index: ops::RangeToInclusive<usize>) -> &mut str {
        IndexMut::index_mut(&mut **self, index)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl ops::Deref for String {
    type Target = str;

    #[inline]
    fn deref(&self) -> &str {
        unsafe { str::from_utf8_unchecked(&self.vec) }
    }
}

#[stable(feature = "derefmut_for_string", since = "1.3.0")]
impl ops::DerefMut for String {
    #[inline]
    fn deref_mut(&mut self) -> &mut str {
        unsafe { str::from_utf8_unchecked_mut(&mut *self.vec) }
    }
}

/// Rudzi rwema alias e [`Infallible`].
///
/// Aya ma alias aripo ekuenderana kumashure, uye anogona kupedzisira abviswa.
///
/// [`Infallible`]: core::convert::Infallible
#[stable(feature = "str_parse_error", since = "1.5.0")]
pub type ParseError = core::convert::Infallible;

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for String {
    type Err = core::convert::Infallible;
    #[inline]
    fn from_str(s: &str) -> Result<String, Self::Err> {
        Ok(String::from(s))
    }
}

/// trait yekushandura kukosha kuita `String`.
///
/// Iyi trait inoitwa otomatiki kune chero mhando inoshandisa iyo [`Display`] trait.
/// Saka nekudaro, `ToString` haifanire kuitiswa zvakananga:
/// [`Display`] inofanira kuitiswa pachinzvimbo, uye iwe unowana iyo `ToString` kuitiswa mahara.
///
///
/// [`Display`]: fmt::Display
#[cfg_attr(not(test), rustc_diagnostic_item = "ToString")]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ToString {
    /// Inoshandura kukosha kwakapihwa kuita `String`.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let i = 5;
    /// let five = String::from("5");
    ///
    /// assert_eq!(five, i.to_string());
    /// ```
    #[rustc_conversion_suggestion]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn to_string(&self) -> String;
}

/// # Panics
///
/// Mukuita uku, iyo `to_string` nzira panics kana `Display` kuitisa ichidzosera kukanganisa.
/// Izvi zvinoratidza isiriyo `Display` kuitiswa nekuti `fmt::Write for String` haina kuzombodzosera kukanganisa pachayo.
///
///
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized> ToString for T {
    // Nhungamiro yakajairika ndeyekusaita mukati mamabasa akajairwa.
    // Nekudaro, kubvisa `#[inline]` kubva munzira iyi kunokonzeresa zvisiri-zvisina basa kudzoka.
    // Ona <https://github.com/rust-lang/rust/pull/74852>, yekupedzisira kuyedza kuyedza kuibvisa.
    //
    #[inline]
    default fn to_string(&self) -> String {
        use fmt::Write;
        let mut buf = String::new();
        buf.write_fmt(format_args!("{}", self))
            .expect("a Display implementation returned an error unexpectedly");
        buf
    }
}

#[stable(feature = "char_to_string_specialization", since = "1.46.0")]
impl ToString for char {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self.encode_utf8(&mut [0; 4]))
    }
}

#[stable(feature = "str_to_string_specialization", since = "1.9.0")]
impl ToString for str {
    #[inline]
    fn to_string(&self) -> String {
        String::from(self)
    }
}

#[stable(feature = "cow_str_to_string_specialization", since = "1.17.0")]
impl ToString for Cow<'_, str> {
    #[inline]
    fn to_string(&self) -> String {
        self[..].to_owned()
    }
}

#[stable(feature = "string_to_string_specialization", since = "1.17.0")]
impl ToString for String {
    #[inline]
    fn to_string(&self) -> String {
        self.to_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for String {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "string_as_mut", since = "1.43.0")]
impl AsMut<str> for String {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<[u8]> for String {
    #[inline]
    fn as_ref(&self) -> &[u8] {
        self.as_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl From<&str> for String {
    #[inline]
    fn from(s: &str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_mut_str_for_string", since = "1.44.0")]
impl From<&mut str> for String {
    /// Inoshandura `&mut str` kuita `String`.
    ///
    /// Mhedzisiro yacho yakagoverwa pamurwi.
    #[inline]
    fn from(s: &mut str) -> String {
        s.to_owned()
    }
}

#[stable(feature = "from_ref_string", since = "1.35.0")]
impl From<&String> for String {
    #[inline]
    fn from(s: &String) -> String {
        s.clone()
    }
}

// note: test Inodhonza mu libstd, iyo inokanganisa zvikanganiso pano
#[cfg(not(test))]
#[stable(feature = "string_from_box", since = "1.18.0")]
impl From<Box<str>> for String {
    /// Inoshandura yakapihwa yakarongedzwa bhokisi re `str` kuita `String`.
    /// Izvo zvinozivikanwa kuti `str` slice ndeye muridzi.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = s1.into_boxed_str();
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: Box<str>) -> String {
        s.into_string()
    }
}

#[stable(feature = "box_from_str", since = "1.20.0")]
impl From<String> for Box<str> {
    /// Inoshandura yakapihwa `String` kune yakarongedzwa `str` chidimbu chiri chako.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let s1: String = String::from("hello world");
    /// let s2: Box<str> = Box::from(s1);
    /// let s3: String = String::from(s2);
    ///
    /// assert_eq!("hello world", s3)
    /// ```
    fn from(s: String) -> Box<str> {
        s.into_boxed_str()
    }
}

#[stable(feature = "string_from_cow_str", since = "1.14.0")]
impl<'a> From<Cow<'a, str>> for String {
    fn from(s: Cow<'a, str>) -> String {
        s.into_owned()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<&'a str> for Cow<'a, str> {
    /// Inoshandura tambo yakatsemurwa kuita Yakakweretwa musiyano.
    /// Hapana kugoverwa kwemurwi kunoitwa, uye tambo haina kutevedzwa.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// assert_eq!(Cow::from("eggplant"), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a str) -> Cow<'a, str> {
        Cow::Borrowed(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a> From<String> for Cow<'a, str> {
    /// Inoshandura tambo kuita yakasarudzika musiyano.
    /// Hapana kugoverwa kwemurwi kunoitwa, uye tambo haina kutevedzwa.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// let s2 = "eggplant".to_string();
    /// assert_eq!(Cow::from(s), Cow::<'static, str>::Owned(s2));
    /// ```
    #[inline]
    fn from(s: String) -> Cow<'a, str> {
        Cow::Owned(s)
    }
}

#[stable(feature = "cow_from_string_ref", since = "1.28.0")]
impl<'a> From<&'a String> for Cow<'a, str> {
    /// Inoshandura tambo inongedzera kuita Yakakweretwa musiyano.
    /// Hapana kugoverwa kwemurwi kunoitwa, uye tambo haina kutevedzwa.
    ///
    ///
    /// # Example
    ///
    /// ```
    /// # use std::borrow::Cow;
    /// let s = "eggplant".to_string();
    /// assert_eq!(Cow::from(&s), Cow::Borrowed("eggplant"));
    /// ```
    #[inline]
    fn from(s: &'a String) -> Cow<'a, str> {
        Cow::Borrowed(s.as_str())
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<char> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = char>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a, 'b> FromIterator<&'b str> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = &'b str>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "cow_str_from_iter", since = "1.12.0")]
impl<'a> FromIterator<String> for Cow<'a, str> {
    fn from_iter<I: IntoIterator<Item = String>>(it: I) -> Cow<'a, str> {
        Cow::Owned(FromIterator::from_iter(it))
    }
}

#[stable(feature = "from_string_for_vec_u8", since = "1.14.0")]
impl From<String> for Vec<u8> {
    /// Inoshandura yakapihwa `String` kuva vector `Vec` inobata tsika dzerudzi `u8`.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let s1 = String::from("hello world");
    /// let v1 = Vec::from(s1);
    ///
    /// for b in v1 {
    ///     println!("{}", b);
    /// }
    /// ```
    fn from(string: String) -> Vec<u8> {
        string.into_bytes()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Write for String {
    #[inline]
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.push_str(s);
        Ok(())
    }

    #[inline]
    fn write_char(&mut self, c: char) -> fmt::Result {
        self.push(c);
        Ok(())
    }
}

/// Iyo inodhonza iterator ye `String`.
///
/// Ichi chimiro chinogadzirwa nenzira ye [`drain`] pa [`String`].
/// Ona zvinyorwa zvaro zvimwe.
///
/// [`drain`]: String::drain
#[stable(feature = "drain", since = "1.6.0")]
pub struct Drain<'a> {
    /// Ichashandiswa se&'a mut Tambo muparadzi
    string: *mut String,
    /// Kutanga kwechikamu kubvisa
    start: usize,
    /// Kupera kwechikamu kubvisa
    end: usize,
    /// Yazvino yakasara renji yekubvisa
    iter: Chars<'a>,
}

#[stable(feature = "collection_debug", since = "1.17.0")]
impl fmt::Debug for Drain<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Drain").field(&self.as_str()).finish()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Sync for Drain<'_> {}
#[stable(feature = "drain", since = "1.6.0")]
unsafe impl Send for Drain<'_> {}

#[stable(feature = "drain", since = "1.6.0")]
impl Drop for Drain<'_> {
    fn drop(&mut self) {
        unsafe {
            // Shandisa Vec::drain.
            // "Reaffirm" iyo miganho inotarisa kudzivirira panic kodhi kuiswa zvakare.
            let self_vec = (*self.string).as_mut_vec();
            if self.start <= self.end && self.end <= self_vec.len() {
                self_vec.drain(self.start..self.end);
            }
        }
    }
}

impl<'a> Drain<'a> {
    /// Inodzorera yakasara (sub) tambo yeiyi iterator sechidimbu.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(string_drain_as_str)]
    /// let mut s = String::from("abc");
    /// let mut drain = s.drain(..);
    /// assert_eq!(drain.as_str(), "abc");
    /// let _ = drain.next().unwrap();
    /// assert_eq!(drain.as_str(), "bc");
    /// ```
    #[unstable(feature = "string_drain_as_str", issue = "76905")] // Note: kusagadzikana AsRef inoisa pazasi painodzikama.
    pub fn as_str(&self) -> &str {
        self.iter.as_str()
    }
}

// Kusagadzikana kana uchidzikamisa `string_drain_as_str`.
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef<str>ye Drain <'a> {fn as_ref(&self)-> &str {
//         self.as_str()
//     }
// }
//
// #[unstable(feature = "string_drain_as_str", issue = "76905")]
// impl <'a> AsRef <[u8]> ye Drain <' a> {fn as_ref(&self)->&[u8]{
//
//         self.as_str().as_bytes()
//     }
// }
//

#[stable(feature = "drain", since = "1.6.0")]
impl Iterator for Drain<'_> {
    type Item = char;

    #[inline]
    fn next(&mut self) -> Option<char> {
        self.iter.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.iter.size_hint()
    }

    #[inline]
    fn last(mut self) -> Option<char> {
        self.next_back()
    }
}

#[stable(feature = "drain", since = "1.6.0")]
impl DoubleEndedIterator for Drain<'_> {
    #[inline]
    fn next_back(&mut self) -> Option<char> {
        self.iter.next_back()
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl FusedIterator for Drain<'_> {}

#[stable(feature = "from_char_for_string", since = "1.46.0")]
impl From<char> for String {
    #[inline]
    fn from(c: char) -> Self {
        c.to_string()
    }
}