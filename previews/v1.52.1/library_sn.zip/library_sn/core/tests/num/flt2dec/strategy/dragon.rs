use super::super::*;
use core::num::bignum::Big32x40 as Big;
use core::num::flt2dec::strategy::dragon::*;

#[test]
fn test_mul_pow10() {
    let mut prevpow10 = Big::from_small(1);
    for i in 1..340 {
        let mut curpow10 = Big::from_small(1);
        mul_pow10(&mut curpow10, i);
        assert_eq!(curpow10, *prevpow10.clone().mul_small(10));
        prevpow10 = curpow10;
    }
}

#[test]
fn shortest_sanity_test() {
    f64_shortest_sanity_test(format_shortest);
    f32_shortest_sanity_test(format_shortest);
    more_shortest_sanity_test(format_shortest);
}

#[test]
#[cfg_attr(miri, ignore)] // Miri anononoka
fn exact_sanity_test() {
    // Uyu bvunzo unoguma uchimhanya izvo zvandinogona kungofungidzira ndeimwe kona-ish kesi ye `exp2` raibhurari basa, rinotsanangurwa mune chero C nguva yekumhanya yatiri kushandisa.
    // MuVS 2013 iri basa sezviri pachena rakanga riine bhudhi sezvo bvunzo iyi ikakundikana painobatanidzwa, asi neVS 2015 iyo bhagi inoratidzika kunge yakagadziriswa sezvo bvunzo dzinoita mushe.
    //
    // Iyo bhaggi inoita kunge mutsauko mukudzoka kukosha kwe `exp2(-1057)`, uko muVS 2013 inodzosera yakapetwa neiri bhatani 0x2 uye muVS 2015 inodzosera 0x20000.
    //
    //
    // Parizvino ingo teerera bvunzo iyi zvachose paMSVC sezvo ichiyedzwa kumwewo zvakadaro uye hatisi kunyanya kufarira kuyedza yega yega chikuva exp2 kuitiswa.
    //
    //
    //
    //
    //
    //
    if !cfg!(target_env = "msvc") {
        f64_exact_sanity_test(format_exact);
    }
    f32_exact_sanity_test(format_exact);
}

#[test]
fn test_to_shortest_str() {
    to_shortest_str_test(format_shortest);
}

#[test]
fn test_to_shortest_exp_str() {
    to_shortest_exp_str_test(format_shortest);
}

#[test]
fn test_to_exact_exp_str() {
    to_exact_exp_str_test(format_exact);
}

#[test]
fn test_to_exact_fixed_str() {
    to_exact_fixed_str_test(format_exact);
}