use crate::ops::DerefMut;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// Chinongedzo chekubata neasynchronous iterators.
///
/// Uyu ndiwo rukova rukuru trait.
/// Kuti uwane zvimwe nezve iyo pfungwa yenzizi kazhinji, ndapota ona iyo [module-level documentation].
/// Kunyanya, iwe ungangoda kuziva maitiro ku [implement `Stream`][impl].
///
/// [module-level documentation]: index.html
/// [impl]: index.html#implementing-stream
#[unstable(feature = "async_stream", issue = "79024")]
#[must_use = "streams do nothing unless polled"]
pub trait Stream {
    /// Rudzi rwezvinhu zvakaburitswa nerukova.
    type Item;

    /// Kuedza kuburitsa inotevera kukosha kwerukova urwu, kunyoresa iro razvino basa rekumuka kana kukosha kwacho kusati kwavapo, uye kudzorera `None` kana rwizi rwapera.
    ///
    /// # Dzorera kukosha
    ///
    /// Kune akati wandei angangoita ekudzosa kukosha, imwe neimwe inoratidza yakasarudzika rukova mamiriro:
    ///
    /// - `Poll::Pending` zvinoreva kuti inotevera rwizi rwuno kukosha haisati yagadzirira izvozvi.Maitikiro achave nechokwadi chekuti basa razvino richaziviswa kana iyo inotevera kukosha ingave yagadzirira.
    ///
    /// - `Poll::Ready(Some(val))` zvinoreva kuti rwizi rwakabudirira kuburitsa kukosha, `val`, uye inogona kuburitsa mamwe maitiro pane anotevera `poll_next` mafoni.
    ///
    /// - `Poll::Ready(None)` zvinoreva kuti rwizi rwapera, uye `poll_next` haifanire kukumbirwa zvakare.
    ///
    /// # Panics
    ///
    /// Kana rwizi ruchangopedza (radzosa `Ready(None)` from `poll_next`), ichidaidza nzira yaro ye `poll_next` zvakare panic, ichivharira zvachose, kana kukonzera mamwe marudzi ematambudziko; iyo `Stream` trait inoisa hapana zvinodikanwa pamhedzisiro yekufona kwakadai.
    ///
    /// Nekudaro, sezvo iyo `poll_next` nzira isina kumakidzwa `unsafe`, Rust yakajairwa mitemo inoshanda: mafoni haafanire kukonzera kusanzwisisika maitiro (ndangariro huwori, kushandiswa zvisirizvo kwe `unsafe` mabasa, kana zvimwe zvakadaro), zvisinei nemamiriro erukova.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;

    /// Inodzorera miganhu pane yakasara kureba kwerwizi.
    ///
    /// Zvikurukuru, `size_hint()` inodzosera Tuple uko yekutanga chinhu chiri chepazasi chakasungwa, uye chechipiri chinhu chiri chepamusoro chakasungwa.
    ///
    /// Hafu yechipiri yeTuple iyo inodzoserwa i [`Sarudzo`]`<`[`usize`] `>`.
    /// A [`None`] pano zvinoreva kuti kana pasina chinozivikanwa chepamusoro chakasungwa, kana chekumusoro chakakura kupfuura [`usize`].
    ///
    /// # Kuteedzera manotsi
    ///
    /// Izvo hazvimanikidzwe kuti kuyerera kwerukova kunopa iyo yakaziviswa nhamba yezvinhu.Rwizi rwengarava runogona kuburitsa zvakaderera pane yakasungwa yakasungwa kana kupfuura kupfuura yakasungwa yepamusoro yezvinhu.
    ///
    /// `size_hint()` inonyanya kuitirwa kuti ishandiswe mukugadzirisa kwakadai sekuchengetedza nzvimbo yezvinhu zverukova, asi haifanire kuvimbwa nayo semuenzaniso, siya mabound bheki mune isina kuchengetedzwa kodhi.
    /// Kuitwa zvisirizvo kwe `size_hint()` hakufanirwe kutungamira mukutyora kwekuchengetedza kwendangariro.
    ///
    /// Izvo zvakati, kuiswa kwacho kunofanirwa kupa fungidziro chaiyo, nekuti zvikasadaro kunenge kuri kutyora mutemo we trait.
    ///
    /// Iyo yekumisikidza kuitisa inodzosera `(0,` [`Hapana`]`)`izvo zviri chaizvo kune chero rwizi.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<S: ?Sized + Stream + Unpin> Stream for &mut S {
    type Item = S::Item;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        S::poll_next(Pin::new(&mut **self), cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}

#[unstable(feature = "async_stream", issue = "79024")]
impl<P> Stream for Pin<P>
where
    P: DerefMut + Unpin,
    P::Target: Stream,
{
    type Item = <P::Target as Stream>::Item;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.get_mut().as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
}