//! Yakagadziriswa asynchronous iteration.
//!
//! Kana futures iri asynchronous values, ipapo hova dziri asynchronous iterators.
//! Kana iwe wakazviwanira iwe neyako asynchronous muunganidzwa weimwe mhando, uye uchidikanwa kuti uite oparesheni pazvinhu zveizvo zvataurwa muunganidzwa, iwe unokurumidza kumhanyira mu 'streams'.
//! Hova dzinoshandiswa zvakanyanya mune idiomatic asynchronous Rust kodhi, saka zvakakodzera kuti ujairane nazvo.
//!
//! Tisati tatsanangura zvimwe, ngatitaurei nezvekuti module iyi yakarongedzwa sei:
//!
//! # Organization
//!
//! Iyi module yakanyanya kurongedzwa nerudzi:
//!
//! * [Traits] ndiwo chikamu chepakati: idzi traits tsanangura kuti ndedzipi nzizi dziripo uye nezvaungaite nadzo.Maitiro e traits aya akakosha kuisa imwe yekuwedzera nguva yekudzidza mukati.
//! * Mabasa anopa dzimwe nzira dzinobatsira dzekugadzira dzimwe hova dzinokosha.
//! * Structs kazhinji ndiwo marudzi ekudzoka enzira dzakasiyana pane ino module traits.Iwe unowanzo kuda kutarisa nzira iyo inogadzira iyo `struct`, pane iyo `struct` pachayo.
//! Kuti uwane rumwe ruzivo nezve nei, ona '[Implementing Stream](#kuita-kurukova)'.
//!
//! [Traits]: #traits
//!
//! Ndizvo!Ngatitsvakei muhova.
//!
//! # Stream
//!
//! Moyo uye mweya weiyi module ndeye [`Stream`] trait.Musimboti we [`Stream`] unoratidzika seizvi:
//!
//! ```
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//! trait Stream {
//!     type Item;
//!     fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>>;
//! }
//! ```
//!
//! Kusiyana ne `Iterator`, `Stream` inoita musiyano pakati pe [`poll_next`] nzira iyo inoshandiswa pakuisa `Stream`, uye nzira ye (to-be-implemented) `next` inoshandiswa pakudya rwizi.
//!
//! Vatengi ve `Stream` vanongoda kufunga nezve `next`, iyo painodaidzwa, inodzosera future iyo inoburitsa `Option<Stream::Item>`.
//!
//! future yakadzoserwa ne `next` ichaburitsa `Some(Item)` sekureba sekunge paine zvinhu, uye kana zvese zvapera, zvichaburitsa `None` kuratidza kuti iteration yapera.
//! Kana isu takamirira pane chimwe chinhu asynchronous kugadzirisa, iyo future inomirira kusvikira rwizi rwakagadzirira kuburitsa zvakare.
//!
//! Rumwe rwizi hove dzinogona kusarudza kuitazve iteration, nekudaro kudaidza `next` zvakare inogona kana kusazopedzisira yaburitsa `Some(Item)` zvakare pane imwe nguva.
//!
//! [`Stream`] 's yakazara dudziro inosanganisira dzinoverengeka dzimwe nzira futi, asi idzo nzira dzekutadza, dzakavakirwa pamusoro pe [`poll_next`], uye saka unodziwana mahara.
//!
//! [`Poll`]: super::task::Poll
//! [`poll_next`]: Stream::poll_next
//!
//! # Kuita Rukova
//!
//! Kugadzira rukova rwako pachako kunosanganisira nhanho mbiri: kugadzira `struct` kubata nyika yerukova, uye nekuzadzisa [`Stream`] yeiyo `struct`.
//!
//! Ngatigadzirei rwizi rwunonzi `Counter` runoverengwa kubva pa `1` kusvika ku `5`:
//!
//! ```no_run
//! #![feature(async_stream)]
//! # use core::stream::Stream;
//! # use core::task::{Context, Poll};
//! # use core::pin::Pin;
//!
//! // Kutanga, iyo dhizaini:
//!
//! /// Rukova runoverenga kubva pane imwe kusvika shanu
//! struct Counter {
//!     count: usize,
//! }
//!
//! // isu tinoda kuti kuverenga kwedu kutange kamwe, saka ngatiwedzerei nzira ye new() yekubatsira.
//! // Izvi hazvinyanyo kudikanwa, asi zviri nyore.
//! // Ziva kuti isu tinotanga `count` pa zero, tichaona kuti nei mu `poll_next()`'s kuitisa pazasi.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Ipapo, isu tinoshandisa `Stream` ye `Counter` yedu:
//!
//! impl Stream for Counter {
//!     // tichave tichiverenga pamwe usize
//!     type Item = usize;
//!
//!     // poll_next() ndiyo chete nzira inodikanwa
//!     fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
//!         // Kuwedzera kuverenga kwedu.Ichi ndicho chikonzero takatanga pa zero.
//!         self.count += 1;
//!
//!         // Tarisa uone kana tapedza kuverenga kana kuti kwete.
//!         if self.count < 6 {
//!             Poll::Ready(Some(self.count))
//!         } else {
//!             Poll::Ready(None)
//!         }
//!     }
//! }
//! ```
//!
//! # Laziness
//!
//! Hova dzin *simbe*.Izvi zvinoreva kuti kungogadzira rukova hakuiti _do_ yakawanda kwazvo.Hapana chinhu chinoitika chaizvo kusvikira washeedza `next`.
//! Izvi dzimwe nguva zvinokonzeresa kana uchigadzira rukova chete nekuda kwemhedzisiro yaro.
//! Iye compiler anotiyambira nezverudzi urwu rwehunhu:
//!
//! ```text
//! warning: unused result that must be used: streams do nothing unless polled
//! ```
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

mod stream;

pub use stream::Stream;