//! Traits yekushandurwa pakati pemhando.
//!
//! traits mune ino module inopa nzira yekushandura kubva kune imwe mhando kuenda kune imwe mhando.
//! trait yega yega inoshanda chinangwa chakasiyana:
//!
//! - Shandisa iyo [`AsRef`] trait yekushomeka kunongedzera-kune-revhizheni shanduko
//! - Tevedzera iyo [`AsMut`] trait yekushomeka inogona kuchinjika-kune-inogona kuchinjika shanduko
//! - Shandisa iyo [`From`] trait yekushandisa kukosha-kune-kukosha kutendeuka
//! - Shandisa iyo [`Into`] trait yekushandisa kukosha-ku-kukosha shanduko kumhando dziri kunze kweiyo crate
//! - [`TryFrom`] uye [`TryInto`] traits dzinozvibata senge [`From`] uye [`Into`], asi dzinofanirwa kuitiswa kana shanduko ikatadza.
//!
//! traits mune ino module inowanzo shandiswa se trait bound yemabasa akajairwa zvekuti kupokana kwemhando dzakasiyana kunotsigirwa.Ona zvinyorwa zve trait imwe neimwe yemienzaniso.
//!
//! Semunyori wemaraibhurari, iwe unofanirwa kugara uchida kushandisa [`From<T>`][`From`] kana [`TryFrom<T>`][`TryFrom`] pane [`Into<U>`][`Into`] kana [`TryInto<U>`][`TryInto`], se [`From`] uye [`TryFrom`] zvinopa mukana wakakura uye zvinopa zvakaenzana [`Into`] kana [`TryInto`] kuitirwa mahara, nekuda kwejira rekushandisa mune raibhurari yakajairwa.
//! Kana uchinongedzera vhezheni pamberi pe Rust 1.41, zvingave zvakakosha kuti ushandise [`Into`] kana [`TryInto`] zvakananga kana uchinge washandukira kune rudzi kunze kweiyo crate.
//!
//! # Kuitwa kweGeneric
//!
//! - [`AsRef`] uye [`AsMut`] auto-dereferensi kana mhando yemukati iri referenzi
//! - [`Kubva`]`<U>nekuti T` zvinoreva [`Into"] `</u><T><U>yeU`</u>
//! - [`TryFrom`]`<U>for T` zvinoreva [`TryInto`]`</u><T><U>yeU`</u>
//! - [`From`] uye [`Into`] inochinja, zvinoreva kuti mhando dzese dzinogona `into` ivo pachavo uye `from` pachavo
//!
//! Ona yega trait yemienzaniso yekushandisa.
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

mod num;

#[unstable(feature = "convert_float_to_int", issue = "67057")]
pub use num::FloatToInt;

/// Chitupa chinoshanda.
///
/// Zvinhu zviviri zvakakosha kucherechedza nezve iri basa.
///
/// - Izvo hazviwanzo zvakaenzana nekuvhara se `|x| x`, nekuti iko kuvhara kunogona kumanikidza `x` mune imwe mhando.
///
/// - Inofambisa iyo yekuisa `x` yakapfuudza kune basa.
///
/// Kunyangwe zvingaite senge zvisinganzwisisike kuve nebasa rinongodzosera iyo yekuisa, pane zvimwe zvinonakidza zvinoshandiswa.
///
///
/// # Examples
///
/// Uchishandisa `identity` kusaita chero chinhu mukuteedzana kweimwe, inonakidza, mabasa:
///
/// ```rust
/// use std::convert::identity;
///
/// fn manipulation(x: u32) -> u32 {
///     // Ngatifungidzirei kuti kuwedzera imwe ibasa rinonakidza.
///     x + 1
/// }
///
/// let _arr = &[identity, manipulation];
/// ```
///
/// Uchishandisa `identity` se "do nothing" base kesi mune mamiriro:
///
/// ```rust
/// use std::convert::identity;
///
/// # let condition = true;
/// #
/// # fn manipulation(x: u32) -> u32 { x + 1 }
/// #
/// let do_stuff = if condition { manipulation } else { identity };
///
/// // Ita zvimwe zvinonakidza zvinhu ...
///
/// let _results = do_stuff(42);
/// ```
///
/// Uchishandisa `identity` kuchengeta `Some` misiyano yeiyo iterator ye `Option<T>`:
///
/// ```rust
/// use std::convert::identity;
///
/// let iter = vec![Some(1), None, Some(3)].into_iter();
/// let filtered = iter.filter_map(identity).collect::<Vec<_>>();
/// assert_eq!(vec![1, 3], filtered);
/// ```
///
///
#[stable(feature = "convert_id", since = "1.33.0")]
#[rustc_const_stable(feature = "const_identity", since = "1.33.0")]
#[inline]
pub const fn identity<T>(x: T) -> T {
    x
}

/// Inoshandiswa kuita yakachipa referensi-kune-revhizheni kutendeuka.
///
/// Iyi trait yakafanana ne [`AsMut`] iyo inoshandiswa kutendeuka pakati pezvinongedzo zvinoshanduka.
/// Kana iwe uchida kuita shanduko inodhura zviri nani kushandisa [`From`] nerudzi `&T` kana kunyora tsika tsika.
///
/// `AsRef` ine siginicha yakafanana ne [`Borrow`], asi [`Borrow`] yakasiyana muzvinhu zvishoma.
///
/// - Kusiyana ne `AsRef`, [`Borrow`] ine gumbeze impl kune chero `T`, uye inogona kushandiswa kutambira chero chirevo kana kukosha.
/// - [`Borrow`] zvinodawo kuti [`Hash`], [`Eq`] uye [`Ord`] yemutengo wakakweretwa yakaenzana neiyo yemutengo.
/// Neichi chikonzero, kana iwe uchida kukwereta chete munda mumwe weichi chimiro iwe unogona kuita `AsRef`, asi kwete [`Borrow`].
///
/// **Note: Iyi trait haifanire kutadza **.Kana iko kutendeuka kukatadza, shandisa nzira yakatsaurirwa iyo inodzosera [`Option<T>`] kana [`Result<T, E>`].
///
/// # Kuitwa kweGeneric
///
/// - `AsRef` otomatiki-mareferenzi kana mhando yemukati iri referenzi kana chirevo chingachinjika (semuenzaniso: `foo.as_ref()` will work the same if `foo` has type   `&mut Foo` or `&&mut Foo`)
///
///
/// # Examples
///
/// Tichishandisa trait bound tinogona kugamuchira nharo dzemhando dzakasiyana sekureba kwadzinogona kuchinjirwa kune yakatarwa mhando `T`.
///
/// Semuenzaniso: Nekugadzira generic basa rinotora `AsRef<str>` isu tinoratidza kuti tinoda kugamuchira zvese zvinongedzo zvinogona kushandurwa kuita [`&str`] sekupokana.
/// Sezvo zvese zviri zviviri [`String`] uye [`&str`] zvichishandisa `AsRef<str>` tinogona kugamuchira zvese sekupokana kwekuisa.
///
/// [`&str`]: primitive@str
/// [`Borrow`]: crate::borrow::Borrow
/// [`Eq`]: crate::cmp::Eq
/// [`Ord`]: crate::cmp::Ord
/// [`String`]: ../../std/string/struct.String.html
///
/// ```
/// fn is_hello<T: AsRef<str>>(s: T) {
///    assert_eq!("hello", s.as_ref());
/// }
///
/// let s = "hello";
/// is_hello(s);
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsRef<T: ?Sized> {
    /// Inoita shanduko.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_ref(&self) -> &T;
}

/// Inoshandiswa kuita yakachipa inoshanduka-ku-inogona kuchinjika mareferensi kutendeuka.
///
/// Iyi trait yakafanana ne [`AsRef`] asi inoshandiswa pakushandura pakati pezvinongedzo zvinoshanduka.
/// Kana iwe uchida kuita shanduko inodhura zviri nani kushandisa [`From`] nerudzi `&mut T` kana kunyora tsika tsika.
///
/// **Note: Iyi trait haifanire kutadza **.Kana iko kutendeuka kukatadza, shandisa nzira yakatsaurirwa iyo inodzosera [`Option<T>`] kana [`Result<T, E>`].
///
/// # Kuitwa kweGeneric
///
/// - `AsMut` otomatiki-kutarisa kana iyo yemukati mhando iri inogona kuchinjika (semuenzaniso: `foo.as_mut()` will work the same if `foo` has type `&mut Foo`   or `&mut &mut Foo`)
///
///
/// # Examples
///
/// Tichishandisa `AsMut` se trait bound yebasa rakajairika tinogona kugamuchira ese mareferensi anogona kuchinjika kunyora `&mut T`.
/// Nekuti [`Box<T>`] inoshandisa `AsMut<T>` tinogona kunyora basa `add_one` iyo inotora nharo dzese dzinogona kushandurwa kuita `&mut u64`.
/// Nekuti [`Box<T>`] inoshandisa `AsMut<T>`, `add_one` inogamuchira nharo dzerudzi `&mut Box<u64>` futi:
///
/// ```
/// fn add_one<T: AsMut<u64>>(num: &mut T) {
///     *num.as_mut() += 1;
/// }
///
/// let mut boxed_num = Box::new(0);
/// add_one(&mut boxed_num);
/// assert_eq!(*boxed_num, 1);
/// ```
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait AsMut<T: ?Sized> {
    /// Inoita shanduko.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn as_mut(&mut self) -> &mut T;
}

/// Iko kukosha-kune-kukosha kushandurwa kunoshandisa iyo yekuisa kukosha.Izvo zvinopesana ne [`From`].
///
/// Mumwe anofanirwa kudzivirira kuita [`Into`] uye kushandisa [`From`] pachinzvimbo.
/// Kuteedzera [`From`] kunozvipa imwe chete nekumisikidza [`Into`] yekutenda kugumbeze kuitisa mune yakajairwa raibhurari.
///
/// Sarudza kushandisa [`Into`] pamusoro pe [`From`] kana uchitsanangura trait bound pachiitiko chakajairwa kuona kuti mhando dzinongoshandisa [`Into`] dzinogona kushandiswa zvakare.
///
/// **Note: Iyi trait haifanire kutadza **.Kana iko kutendeuka kukatadza, shandisa [`TryInto`].
///
/// # Kuitwa kweGeneric
///
/// - [`Kubva`]`<T>yeU` zvinoreva `Into<U> for T`
/// - [`Into`] inofungidzira, zvinoreva kuti `Into<T> for T` inoitwa
///
/// # Kutevedzera [`Into`] yekushandurwa kuenda kune ekunze marudzi mune ekare mavhezheni e Rust
///
/// Asati Rust 1.41, kana iyo nzira yekuenda yanga isiri chikamu che crate yazvino waisakwanisa kuita [`From`] zvakananga.
/// Semuenzaniso, tora kodhi iyi:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> From<Wrapper<T>> for Vec<T> {
///     fn from(w: Wrapper<T>) -> Vec<T> {
///         w.0
///     }
/// }
/// ```
/// Izvi zvinokundikana kuumbika mushanduro dzekare dzemutauro nekuti mitemo yenherera ye Rust yaimbove yakanyanya kuomarara.
/// Kupfuura izvi, unogona kuita [`Into`] zvakananga:
///
/// ```
/// struct Wrapper<T>(Vec<T>);
/// impl<T> Into<Vec<T>> for Wrapper<T> {
///     fn into(self) -> Vec<T> {
///         self.0
///     }
/// }
/// ```
///
/// Izvo zvakakosha kuti unzwisise kuti [`Into`] haipe [`From`] kuitiswa (sezvinoita [`From`] ne [`Into`]).
/// Naizvozvo, iwe unofanirwa kugara uchiedza kuita [`From`] wobva wadzokera ku [`Into`] kana [`From`] isingakwanise kuitiswa.
///
/// # Examples
///
/// [`String`] zvishandiso [`Into`]`<`[`Vec`] `<` [`u8`]` >> >>:
///
/// Kuti titaure kuti tinoda generic basa kutora nharo dzese dzinogona kuchinjirwa kune yakatarwa mhando `T`, tinogona kushandisa trait bound ye [`Into`]`<T>`.
///
/// Semuenzaniso: Basa `is_hello` rinotora nharo dzese dzinogona kushandurwa kuita [`Vec`]`<`[`u8`] `>`.
///
/// ```
/// fn is_hello<T: Into<Vec<u8>>>(s: T) {
///    let bytes = b"hello".to_vec();
///    assert_eq!(bytes, s.into());
/// }
///
/// let s = "hello".to_string();
/// is_hello(s);
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`Vec`]: ../../std/vec/struct.Vec.html
///
///
///
///
///
///
#[rustc_diagnostic_item = "into_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Into<T>: Sized {
    /// Inoita shanduko.
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into(self) -> T;
}

/// Inoshandiswa kuita kukosha-kune-kukosha kushandurwa iwe uchidya iyo yekuisa kukosha.Ndiyo kudzokorodza kwe [`Into`].
///
/// Mumwe anofanirwa kugara achida kushandisa `From` pamusoro pe [`Into`] nekuti kumisikidza `From` inopa otomatiki kuita kwe [`Into`] yekutenda kugumbeze kuitisa mune yakajairwa raibhurari.
///
///
/// Ingoisa [`Into`] kana uchinongedzera vhezheni pamberi pe Rust 1.41 uye uchishandura kuita mhando iri kunze kwazvino crate.
/// `From` haana kukwanisa kuita idzi mhando dzeshanduro mushanduro dzapfuura nekuda kwemitemo ye Rust yenherera.
/// Ona [`Into`] kuti uwane rumwe ruzivo.
///
/// Sarudza kushandisa [`Into`] pamusoro pekushandisa `From` uchitsanangura trait bound pane generic basa.
/// Nenzira iyi, mhando dzinoshandisa zvakananga [`Into`] dzinogona kushandiswa sekupokana futi.
///
/// Iyo `From` inobatsira zvakare pakuita kukanganisa kwekubata.Paunenge uchivaka chiitiko chinokwanisa kutadza, iyo yekudzosa mhando inowanzo kuve yeiyo fomu `Result<T, E>`.
/// Iyo `From` trait inorerutsa kukanganisa kubata nekubvumira kuti basa ridzosere imwechete kukanganisa mhando iyo inokomberedza akawanda kukanganisa mhando.Ona iyo "Examples" chikamu uye [the book][book] kuti uwane rumwe ruzivo.
///
/// **Note: Iyi trait haifanire kutadza **.Kana iko kutendeuka kukatadza, shandisa [`TryFrom`].
///
/// # Kuitwa kweGeneric
///
/// - `From<T> for U` zvinoreva kuti [`Into`` <U>yeT`</u>
/// - `From` inofungidzira, zvinoreva kuti `From<T> for T` inoitwa
///
/// # Examples
///
/// [`String`] zvishandiso `From<&str>`:
///
/// Shanduko yakajeka kubva ku `&str` kuenda kuTambo inoitwa seinotevera:
///
/// ```
/// let string = "hello".to_string();
/// let other_string = String::from("hello");
///
/// assert_eq!(string, other_string);
/// ```
///
/// Ipo uchiita kukanganisa kubata zvinowanzo kubatsira kuita `From` yerudzi rwako rwekukanganisa.
/// Nekushandura yepasi pekukanganisa mhando kune yedu pachedu kukanganisa kodhi iyo inokomberedza iri pasi kukanganisa mhando, tinogona kudzosa imwechete kukanganisa mhando tisingarasikirwe neruzivo pane chiri kukonzera chikonzero.
/// Anoshanda ne '?' anoshandura otomatiki mhando yekukanganisa kuenda kune yedu tsika yekukanganisa mhando nekudana `Into<CliError>::into` iyo inongopihwa yega kana uchiita `From`.
/// Iye compiler anobva apinza iko kuiswa kwe `Into` kunofanirwa kushandiswa.
///
/// ```
/// use std::fs;
/// use std::io;
/// use std::num;
///
/// enum CliError {
///     IoError(io::Error),
///     ParseError(num::ParseIntError),
/// }
///
/// impl From<io::Error> for CliError {
///     fn from(error: io::Error) -> Self {
///         CliError::IoError(error)
///     }
/// }
///
/// impl From<num::ParseIntError> for CliError {
///     fn from(error: num::ParseIntError) -> Self {
///         CliError::ParseError(error)
///     }
/// }
///
/// fn open_and_parse_file(file_name: &str) -> Result<i32, CliError> {
///     let mut contents = fs::read_to_string(&file_name)?;
///     let num: i32 = contents.trim().parse()?;
///     Ok(num)
/// }
/// ```
///
/// [`String`]: ../../std/string/struct.String.html
/// [`from`]: From::from
/// [book]: ../../book/ch09-00-error-handling.html
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "from_trait"]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(on(
    all(_Self = "&str", T = "std::string::String"),
    note = "to coerce a `{T}` into a `{Self}`, use `&*` as a prefix",
))]
pub trait From<T>: Sized {
    /// Inoita shanduko.
    #[lang = "from"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from(_: T) -> Self;
}

/// Kwayedza kutendeuka iyo inoshandisa `self`, inogona kana isingadhuri.
///
/// Vanyori veMaraibhurari havawanzo kuita zvakananga iyi trait, asi vanofanirwa kusarudza kushandisa iyo [`TryFrom`] trait, iyo inopa mukana wakakura uye inopa yakaenzana `TryInto` kuitisa mahara, nekuda kwejira rekushandisa mune yakajairwa raibhurari.
/// Kuti uwane rumwe ruzivo nezve izvi, ona zvinyorwa zve [`Into`].
///
/// # Kuita `TryInto`
///
/// Izvi zvinotambura zvirambidzo zvakafanana uye kufunga sekushandisa [`Into`], ona ipapo kuti uwane rumwe ruzivo.
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_into_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryInto<T>: Sized {
    /// Rudzi rwakadzorerwa muchiitiko chekukanganisa kutendeuka.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Inoita shanduko.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_into(self) -> Result<T, Self::Error>;
}

/// Rakareruka uye rwakachengeteka mhando shanduko dzinogona kukundikana munzira inodzorwa mune mamwe mamiriro.Ndiyo kudzokorodza kwe [`TryInto`].
///
/// Izvi zvinobatsira paunenge uchiita mhando yeshanduko inogona kubudirira zvishoma asi ingangodawo kubata kwakasarudzika.
/// Semuenzaniso, hapana nzira yekushandura [`i64`] kuita [`i32`] uchishandisa [`From`] trait, nekuti [`i64`] inogona kunge iine kukosha kusingatarisirwe ne [`i32`] uye nekudaro kutendeuka kucharasa data.
///
/// Izvi zvinogona kubatwa nekutora [`i64`] kuita [`i32`] (zvichinyanya kupa iyo [`i64`] 's kukosha modulo [`i32::MAX`]) kana nekungodzosera [`i32::MAX`], kana neimwe nzira.
/// [`From`] trait inoitirwa shanduko yakakwana, saka `TryFrom` trait inozivisa mugadziri kana shanduko yerudzi ikaenda yakaipa uye inoita kuti vasarudze maitiro ekuibata.
///
/// # Kuitwa kweGeneric
///
/// - `TryFrom<T> for U` zvinoreva kuti [`EdzaInto`] <U>yeT`</u>
/// - [`try_from`] inofungidzira, zvinoreva kuti `TryFrom<T> for T` inoitwa uye haigone kutadza-inosanganisirwa `Error` mhando yekufona `T::try_from()` pamutengo werudzi `T` i [`Infallible`].
/// Kana iyo [`!`] mhando yakasimbiswa [`Infallible`] uye [`!`] ichave yakaenzana.
///
/// `TryFrom<T>` inogona kuitwa seinotevera:
///
/// ```
/// use std::convert::TryFrom;
///
/// struct GreaterThanZero(i32);
///
/// impl TryFrom<i32> for GreaterThanZero {
///     type Error = &'static str;
///
///     fn try_from(value: i32) -> Result<Self, Self::Error> {
///         if value <= 0 {
///             Err("GreaterThanZero only accepts value superior than zero!")
///         } else {
///             Ok(GreaterThanZero(value))
///         }
///     }
/// }
/// ```
///
/// # Examples
///
/// Sezvatsanangurwa, [`i32`] inoisa `TryFrom <` [``i64`] `>>:
///
/// ```
/// use std::convert::TryFrom;
///
/// let big_number = 1_000_000_000_000i64;
/// // Chinyararire truncates `big_number`, inoda kuona uye kubata iyo truncation mushure mechokwadi.
/////
/// let smaller_number = big_number as i32;
/// assert_eq!(smaller_number, -727379968);
///
/// // Inodzorera kukanganisa nekuti `big_number` yakanyanya kukura kuti ikwane mu `i32`.
/////
/// let try_smaller_number = i32::try_from(big_number);
/// assert!(try_smaller_number.is_err());
///
/// // Inodzorera `Ok(3)`.
/// let try_successful_smaller_number = i32::try_from(3);
/// assert!(try_successful_smaller_number.is_ok());
/// ```
///
/// [`try_from`]: TryFrom::try_from
///
///
///
///
///
///
///
///
///
///
#[rustc_diagnostic_item = "try_from_trait"]
#[stable(feature = "try_from", since = "1.34.0")]
pub trait TryFrom<T>: Sized {
    /// Rudzi rwakadzorerwa muchiitiko chekukanganisa kutendeuka.
    #[stable(feature = "try_from", since = "1.34.0")]
    type Error;

    /// Inoita shanduko.
    #[stable(feature = "try_from", since = "1.34.0")]
    fn try_from(value: T) -> Result<Self, Self::Error>;
}

////////////////////////////////////////////////////////////////////////////////
// GENERIC IMPLS
////////////////////////////////////////////////////////////////////////////////

// Sekusimudza pamusoro&
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// Sekusimudza pamusoro pe &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsRef<U> for &mut T
where
    T: AsRef<U>,
{
    fn as_ref(&self) -> &U {
        <T as AsRef<U>>::as_ref(*self)
    }
}

// FIXME (#45742): chinja ma impls ari pamusoro e&/&mut neinotevera yakawandisa:
// // Sekusimudza pamusoro paDeref
// impl <D: ?Sized + Deref<Target: AsRef<U>>, U: Sized> AsRef <U>yeD {fn as_ref(&self)-> &U {</u>
//
//         self.deref().as_ref()
//     }
// }

// AsMut inosimudza pamusoro pe &mut
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, U: ?Sized> AsMut<U> for &mut T
where
    T: AsMut<U>,
{
    fn as_mut(&mut self) -> &mut U {
        (*self).as_mut()
    }
}

// FIXME (#45742): chinja impll iri pamusoro ye &mut neinotevera yakawandisa:
// // AsMut inosimudza pamusoro peDerefMut
// impl <D: ?Sized + Deref<Target: AsMut<U>>, U:? Yakakura> AsMut <U>yeD {fn as_mut(&mut self)-> &mut U {</u>
//
//         self.deref_mut().as_mut()
//     }
// }

// Kubva pane zvinoreva kupinda
#[stable(feature = "rust1", since = "1.0.0")]
impl<T, U> Into<U> for T
where
    U: From<T>,
{
    fn into(self) -> U {
        U::from(self)
    }
}

// Kubva (uye nekudaro Kupinda) inofungidzira
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> From<T> for T {
    fn from(t: T) -> T {
        t
    }
}

/// **Kugadzikana chitsamba:** Iyi impl haisati yavepo, asi isu tiri "reserving space" kuiwedzera mu future.
/// Ona [rust-lang/rust#64715][#64715] kuti uwane rumwe ruzivo.
///
/// [#64715]: https://github.com/rust-lang/rust/issues/64715
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[allow(unused_attributes)] // FIXME(#58633): gadzira zvine hungwaru panzvimbo.
#[rustc_reservation_impl = "permitting this impl would forbid us from adding \
                            `impl<T> From<!> for T` later; see rust-lang/rust#64715 for details"]
impl<T> From<!> for T {
    fn from(t: !) -> T {
        t
    }
}

// TryFrom zvinoreva TryInto
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryInto<U> for T
where
    U: TryFrom<T>,
{
    type Error = U::Error;

    fn try_into(self) -> Result<U, U::Error> {
        U::try_from(self)
    }
}

// Shanduro isingakanganisi zvine mutsindo zvakaenzana nekutendeuka kusinga tsanangurike nemhando yekukanganisa isingagarike.
//
#[stable(feature = "try_from", since = "1.34.0")]
impl<T, U> TryFrom<U> for T
where
    U: Into<T>,
{
    type Error = Infallible;

    fn try_from(value: U) -> Result<Self, Self::Error> {
        Ok(U::into(value))
    }
}

////////////////////////////////////////////////////////////////////////////////
// CONCRETE IMPLS
////////////////////////////////////////////////////////////////////////////////

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsRef<[T]> for [T] {
    fn as_ref(&self) -> &[T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T> AsMut<[T]> for [T] {
    fn as_mut(&mut self) -> &mut [T] {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl AsRef<str> for str {
    #[inline]
    fn as_ref(&self) -> &str {
        self
    }
}

#[stable(feature = "as_mut_str_for_str", since = "1.51.0")]
impl AsMut<str> for str {
    #[inline]
    fn as_mut(&mut self) -> &mut str {
        self
    }
}

////////////////////////////////////////////////////////////////////////////////
// HAPANA KUKanganisa-TYPE
////////////////////////////////////////////////////////////////////////////////

/// Rudzi rwekukanganisa rwezvikanganiso zvisingatomboitika.
///
/// Sezvo iyi enum isina musiyano, kukosha kwerudzi urwu hakugone kunyatsovapo.
/// Izvi zvinogona kubatsira ma generic APIs anoshandisa [`Result`] uye paramende mhando yekukanganisa, kuratidza kuti mhedzisiro inogara iri [`Ok`].
///
/// Semuenzaniso, iyo [`TryFrom`] trait (shanduko inodzosera [`Result`]) ine gumbeze kuitiswa kune ese marudzi uko reverse [`Into`] kuitiswa kuripo.
///
/// ```ignore (illustrates std code, duplicating the impl in a doctest would be an error)
/// impl<T, U> TryFrom<U> for T where U: Into<T> {
///     type Error = Infallible;
///
///     fn try_from(value: U) -> Result<Self, Infallible> {
///         Ok(U::into(value))  // Never returns `Err`
///     }
/// }
/// ```
///
/// # Future kuenderana
///
/// Iyi enum ine basa rakafanana ne [the `!`“never”type][never], iyo isina kugadzikana mune iyi vhezheni ye Rust.
/// Kana `!` yasimbiswa, isu tinoronga kuita `Infallible` mhando alias kwazviri:
///
/// ```ignore (illustrates future std change)
/// pub type Infallible = !;
/// ```
///
/// …Uye pakupedzisira kudzikisira `Infallible`.
///
/// Nekudaro pane imwe kesi apo `!` syntax inogona kushandiswa `!` isati yadzikamiswa senge izere mhando: muchinzvimbo cherudzi rwekudzoka kwebasa.
/// Kunyanya, zvinokwanisika kuitisa maviri akasiyana basa pointer mhando:
///
/// ```
/// trait MyTrait {}
/// impl MyTrait for fn() -> ! {}
/// impl MyTrait for fn() -> std::convert::Infallible {}
/// ```
///
/// Iine `Infallible` iri enum, iyi kodhi inoshanda.
/// Nekudaro kana `Infallible` ikave zita re never type, ma`impl`s maviri anotanga kuwanda uye nekudaro anozobvumidzwa nemitauro ye trait yemitauro yekubatana.
///
///
///
///
///
///
#[stable(feature = "convert_infallible", since = "1.34.0")]
#[derive(Copy)]
pub enum Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Clone for Infallible {
    fn clone(&self) -> Infallible {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Debug for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl fmt::Display for Infallible {
    fn fmt(&self, _: &mut fmt::Formatter<'_>) -> fmt::Result {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialEq for Infallible {
    fn eq(&self, _: &Infallible) -> bool {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Eq for Infallible {}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl PartialOrd for Infallible {
    fn partial_cmp(&self, _other: &Self) -> Option<crate::cmp::Ordering> {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl Ord for Infallible {
    fn cmp(&self, _other: &Self) -> crate::cmp::Ordering {
        match *self {}
    }
}

#[stable(feature = "convert_infallible", since = "1.34.0")]
impl From<!> for Infallible {
    fn from(x: !) -> Self {
        x
    }
}

#[stable(feature = "convert_infallible_hash", since = "1.44.0")]
impl Hash for Infallible {
    fn hash<H: Hasher>(&self, _: &mut H) {
        match *self {}
    }
}