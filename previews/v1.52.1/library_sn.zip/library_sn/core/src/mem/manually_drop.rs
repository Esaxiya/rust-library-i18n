use crate::ops::{Deref, DerefMut};
use crate::ptr;

/// Yekuputira inhibhidha compiler kubva ichingo daidzira ``T`'s muparadzi.
/// Ichi chinoputira chiri 0-mutengo.
///
/// `ManuallyDrop<T>` inoenderana nemamiriro akafanana ekugadzirisa se `T`.
/// Semhedzisiro, haina *mhedzisiro* pane fungidziro dzinoitwa nemugadziri nezve zvirimo.
/// Semuenzaniso, kutanga `ManuallyDrop<&mut T>` ne [`mem::zeroed`] haina kujekeswa maitiro.
/// Kana iwe uchida kubata isina kuvhurwa dhata, shandisa [`MaybeUninit<T>`] pachinzvimbo.
///
/// Ziva kuti kuwana kukosha mukati me `ManuallyDrop<T>` kwakachengeteka.
/// Izvi zvinoreva kuti `ManuallyDrop<T>` ine zvemukati zvakadonhedzwa haifanire kufumurwa kuburikidza neruzhinji yakachengeteka API.
/// Saizvozvo, `ManuallyDrop::drop` haina kuchengetedzeka.
///
/// # `ManuallyDrop` uye donhedza odha.
///
/// Rust ine yakanyatsotsanangurwa [drop order] yemitengo.
/// Kuti uve nechokwadi chekuti minda kana vagari vemo vakadonhedzwa mune yakatarwa odha, gadziridza zvakare zvirevo zvekuti iyo yakasarudzika donhwe odha ndiyo chaiyo.
///
/// Izvo zvinokwanisika kushandisa `ManuallyDrop` kudzora iyo inodonha odha, asi izvi zvinoda isina kuchengetedzwa kodhi uye zvinonetsa kuita nemazvo pamberi pekusunungura.
///
///
/// Semuenzaniso, kana iwe uchida kuona kuti chaicho munda chakadonhedzwa mushure mevamwe, chiite iyo yekupedzisira ndima yechimiro:
///
/// ```
/// struct Context;
///
/// struct Widget {
///     children: Vec<Widget>,
///     // `context` ichadonhedzwa mushure me `children`.
///     // Rust inovimbisa kuti minda inodonhedzwa muhurongwa hwekuzivisa.
///     context: Context,
/// }
/// ```
///
/// [drop order]: https://doc.rust-lang.org/reference/destructors.html
/// [`mem::zeroed`]: crate::mem::zeroed
/// [`MaybeUninit<T>`]: crate::mem::MaybeUninit
///
///
///
///
///
#[stable(feature = "manually_drop", since = "1.20.0")]
#[lang = "manually_drop"]
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(transparent)]
pub struct ManuallyDrop<T: ?Sized> {
    value: T,
}

impl<T> ManuallyDrop<T> {
    /// Putira kukosha kuti udonhedwe nemaoko.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let mut x = ManuallyDrop::new(String::from("Hello World!"));
    /// x.truncate(5); // Iwe uchiri kugona kushanda zvakachengeteka pane kukosha
    /// assert_eq!(*x, "Hello");
    /// // Asi `Drop` haizoitwe pano
    /// ```
    #[must_use = "if you don't need the wrapper, you can use `mem::forget` instead"]
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(value: T) -> ManuallyDrop<T> {
        ManuallyDrop { value }
    }

    /// Inobvisa kukosha kubva mumudziyo we `ManuallyDrop`.
    ///
    /// Izvi zvinobvumira kuti kukosha kudonhedzwe zvakare.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::mem::ManuallyDrop;
    /// let x = ManuallyDrop::new(Box::new(()));
    /// let _: Box<()> = ManuallyDrop::into_inner(x); // Izvi zvinodonhedza `Box`.
    /// ```
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[rustc_const_stable(feature = "const_manually_drop", since = "1.36.0")]
    #[inline(always)]
    pub const fn into_inner(slot: ManuallyDrop<T>) -> T {
        slot.value
    }

    /// Inotora kukosha kubva kumudziyo we `ManuallyDrop<T>` kunze.
    ///
    /// Iyi nzira inonyanya kuitirwa kuburitsa kunze kukosha mune kudonha.
    /// Panzvimbo pekushandisa [`ManuallyDrop::drop`] kudonhedza iyo kukosha, unogona kushandisa nzira iyi kutora iyo kukosha uye kuishandisa zvakadaro zvaunoda.
    ///
    /// Pese pazvinogoneka, zviri nani kushandisa [`into_inner`][`ManuallyDrop::into_inner`] pachinzvimbo, izvo zvinodzivirira kudzokorora zvirimo mu `ManuallyDrop<T>`.
    ///
    ///
    /// # Safety
    ///
    /// Iri basa semantically rinoburitsa iro rakakosheswa kukosha pasina kudzivirira kumwe kushandiswa, richisiya mamiriro echinhu ichi chisina kuchinjika.
    /// Ndiro basa rako kuona kuti iyi `ManuallyDrop` haina kushandiswa zvakare.
    ///
    ///
    ///
    #[must_use = "if you don't need the value, you can use `ManuallyDrop::drop` instead"]
    #[stable(feature = "manually_drop_take", since = "1.42.0")]
    #[inline]
    pub unsafe fn take(slot: &mut ManuallyDrop<T>) -> T {
        // Kachengeteka: isu tiri kuverenga kubva kunongedzo, iyo inovimbiswa
        // kuve inoshanda pakuverenga.
        unsafe { ptr::read(&slot.value) }
    }
}

impl<T: ?Sized> ManuallyDrop<T> {
    /// Nemaoko inodonhedza iyo yaiveko kukosha.Izvi zvakanyatsoenzana nekufona [`ptr::drop_in_place`] ine pointer kune iyo ine kukosha.
    /// Saka nekudaro, kunze kwekunge kukosha kuri mukati kuri kwakarongedzwa, anoparadza anozodaidzwa ari-munzvimbo pasina kufambisa kukosha, uye nekudaro inogona kushandiswa kudonhedza [pinned] data zvakachengeteka.
    ///
    /// Kana iwe uine muridzi weiyo kukosha, unogona kushandisa [`ManuallyDrop::into_inner`] pachinzvimbo.
    ///
    /// # Safety
    ///
    /// Iri basa rinomhanyisa kuparadza kweiyo iri kukosha.
    /// Zvimwe kunze kweshanduko dzakaitwa nemuparadzi pachayo, ndangariro inosara isina kuchinjika, uye nekudaro sekusangana kwemunyori ichiri inobata zvishoma-pateni zvinoenderana nerudzi `T`.
    ///
    ///
    /// Nekudaro, iyi kukosha kwe "zombie" haifanire kufumurwa kune yakachengeteka kodhi, uye iri basa harifanire kudaidzwa kanopfuura kamwe.
    /// Kuti ushandise kukosha mushure mekunge yadonhedzwa, kana kudonhedza kukosha kakawanda, kunogona kukonzera Undefined Behaeve (zvinoenderana nezvinoitwa ne `drop`).
    /// Izvi zvinowanzo dzivirirwa neiyo mhando sisitimu, asi vashandisi ve `ManuallyDrop` vanofanirwa kutsigira izvo zvivimbiso pasina rubatsiro kubva kumunyori.
    ///
    /// [pinned]: crate::pin
    ///
    ///
    ///
    ///
    #[stable(feature = "manually_drop", since = "1.20.0")]
    #[inline]
    pub unsafe fn drop(slot: &mut ManuallyDrop<T>) {
        // KUCHENGETEKA: isu tiri kudonhedza iyo kukosha kunongedzerwa neinogona kuchinjika chirevo
        // iyo inovimbiswa kuve inoshanda kune inonyora.
        // Zviri kumunhu anenge afona kuti ave nechokwadi chekuti `slot` haina kudonhedzwa zvakare.
        unsafe { ptr::drop_in_place(&mut slot.value) }
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> Deref for ManuallyDrop<T> {
    type Target = T;
    #[inline(always)]
    fn deref(&self) -> &T {
        &self.value
    }
}

#[stable(feature = "manually_drop", since = "1.20.0")]
impl<T: ?Sized> DerefMut for ManuallyDrop<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut T {
        &mut self.value
    }
}