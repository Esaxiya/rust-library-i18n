use crate::any::type_name;
use crate::fmt;
use crate::intrinsics;
use crate::mem::ManuallyDrop;
use crate::ptr;

/// Rudzi rwekuputira kuvaka zviitiko zvisina kutaurwa zve `T`.
///
/// # Kutanga kusagadzikana
///
/// Muunganidzi, kazhinji, anofungidzira kuti musiyano unotanga zvakanaka zvinoenderana nezvinodiwa zverudzi rwemusiyano.Semuenzaniso, musiyano werudzi rwereferenzi unofanirwa kuenderana uye isiri-NULL.
/// Ichi chinogara chiripo chinofanirwa *kugara* chakasimudzwa, kunyangwe iri kodhi isina kuchengetedzeka.
/// Semhedzisiro, zero-inotangisa musiyano wereferensi mhando inokonzeresa ipapo [undefined behavior][ub], zvisinei kuti chirevo icho chinomboshandiswa kushandisa memory.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: &i32 = unsafe { mem::zeroed() }; // undefined maitiro!⚠️
/// // Iyo yakaenzana kodhi ne `MaybeUninit<&i32>`:
/// let x: &i32 = unsafe { MaybeUninit::zeroed().assume_init() }; // undefined maitiro!⚠️
/// ```
///
/// Izvi zvinoshandiswa nemusanganisi weakasiyana optimization, senge kuregedza kumhanya-nguva cheki uye kugadzirisa `enum` dhizaini.
///
/// Saizvozvo, zvachose uninitialized memory inogona kunge iine chero zvemukati, nepo `bool` ichifanira kugara iri `true` kana `false`.Nekudaro, kugadzira uninitialized `bool` haina kujekeswa maitiro:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let b: bool = unsafe { mem::uninitialized() }; // undefined maitiro!⚠️
/// // Iyo yakaenzana kodhi ne `MaybeUninit<bool>`:
/// let b: bool = unsafe { MaybeUninit::uninit().assume_init() }; // undefined maitiro!⚠️
/// ```
///
/// Zvakare, uninitialized memory yakakosha pakuti haina kukosha kwakatarwa ("fixed" zvichireva "it won't change without being written to").Kuverenga zvakafanana uninitialized byte kakawanda kunogona kupa mhinduro dzakasiyana.
/// Izvi zvinoita kuti ive isina kujekeswa maitiro kuve neinina yekutanga data mune musiyano kunyangwe iyo musiyano iine huwandu hwakazara, iyo neimwe nzira inogona kubata chero *yakagadziriswa* bit pateni:
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem::{self, MaybeUninit};
///
/// let x: i32 = unsafe { mem::uninitialized() }; // undefined maitiro!⚠️
/// // Iyo yakaenzana kodhi ne `MaybeUninit<i32>`:
/// let x: i32 = unsafe { MaybeUninit::uninit().assume_init() }; // undefined maitiro!⚠️
/// ```
/// (Cherekedza kuti iyo mitemo yakatenderedza isina kuvhurwa manhamba haisati yapera, asi kusvika paari, zvinokurudzirwa kuti urege iyo.)
///
/// Pamusoro pezvo, yeuka kuti mhando zhinji dzine mamwe mahemeti zvinopfuura kungofungidzirwa kuti zvakatangwa padanho rerudzi.
/// Semuenzaniso, `1`-yakatangwa [`Vec<T>`] inoonekwa seyakatangwa (pasi pezvinoitwa; izvi hazviite gadziriro yakagadzikana) nekuti icho chete chinodiwa icho muunganidzi anoziva nezvazvo ndechekuti data pointer inofanira kunge isiri-null.
/// Kugadzira yakadai `Vec<T>` hakukonzere *iko* kusajeka maitiro, asi kunozokonzeresa kujekesa maitiro nemaitiro mazhinji akachengeteka (kusanganisira kuisiya).
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
///
/// # Examples
///
/// `MaybeUninit<T>` inoshanda kugonesa isina kuchengetedzeka kodhi kubata neisina kuvhurwa dhata.
/// Iyo chiratidzo kune compiler inoratidza kuti iyo data pano inogona *kwete* kutanga.
///
/// ```rust
/// use std::mem::MaybeUninit;
///
/// // Gadzira chirevo chisina kunyatsojekeswa.
/// // Muunganidzi anoziva kuti data mukati me `MaybeUninit<T>` rinogona kunge risiri iro, uye nekudaro iyi haisi UB:
/// let mut x = MaybeUninit::<&i32>::uninit();
/// // Chiise kune chakakodzera kukosha.
/// unsafe { x.as_mut_ptr().write(&0); }
/// // Bvisa iyo data yekutanga-izvi zvinongobvumidzwa *mushure me* kunyatso kumisikidza `x`!
/////
/// let x = unsafe { x.assume_init() };
/// ```
///
/// Iyo compiler inoziva kuti irege kuita zvisirizvo fungidziro kana optimizations pane ino kodhi.
///
/// Iwe unogona kufunga nezve `MaybeUninit<T>` sekunge fananei ne `Option<T>` asi pasina chero yeiyo yekumhanya-nguva yekutevera uye pasina chero chechengetedzo cheki.
///
/// ## out-pointers
///
/// Unogona kushandisa `MaybeUninit<T>` kuita "out-pointers": panzvimbo yekudzosa data kubva pane basa, riendese chinongedzera kune imwe (uninitialized) memory yekuisa mhedzisiro.
/// Izvi zvinogona kubatsira kana zvichikosha kune ari kufona kudzora kuti ndangariro mhedzisiro yacho inochengetwa sei inogovaniswa sei, uye iwe unoda kudzivirira mafambiro asina basa.
///
/// ```
/// use std::mem::MaybeUninit;
///
/// unsafe fn make_vec(out: *mut Vec<i32>) {
///     // `write` haidonhedze zvirimo zvekare, izvo zvakakosha.
///     out.write(vec![1, 2, 3]);
/// }
///
/// let mut v = MaybeUninit::uninit();
/// unsafe { make_vec(v.as_mut_ptr()); }
/// // Iye zvino tinoziva `v` inotangwa!Izvi zvakare zvinoita shuwa kuti vector inodonhedzwa nemazvo.
/////
/// let v = unsafe { v.assume_init() };
/// assert_eq!(&v, &[1, 2, 3]);
/// ```
///
/// ## Kutanga chinhu chakarongeka-ne-chinhu
///
/// `MaybeUninit<T>` inogona kushandiswa kutanga huru hombe chinhu-ne-chinhu:
///
/// ```
/// use std::mem::{self, MaybeUninit};
///
/// let data = {
///     // Gadzira uninitialized rondedzero ye `MaybeUninit`.
///     // Iyo `assume_init` yakachengeteka nekuti mhando yatiri kuti takatangisa pano iboka re`MayingaUninit`s, ayo asingade kutanga.
/////
///     let mut data: [MaybeUninit<Vec<u32>>; 1000] = unsafe {
///         MaybeUninit::uninit().assume_init()
///     };
///
///     // Kudonhedza `MaybeUninit` hakuite chinhu.
///     // Nekudaro kushandisa mbishi kunongedzera kupihwa panzvimbo pe `ptr::write` hakukonzere kuti yekare uninitialized kukosha kudonhedzwe.
/////
///     // Zvakare kana paine panic panguva iyi chiuno, isu tine memory leak, asi hapana yekuchengetedza yekuchengetedza nyaya.
/////
///     for elem in &mut data[..] {
///         *elem = MaybeUninit::new(vec![42]);
///     }
///
///     // Zvese zvinotangiswa.
///     // Shandura rondedzero kune iyo yekutanga mhando.
///     unsafe { mem::transmute::<_, [Vec<u32>; 1000]>(data) }
/// };
///
/// assert_eq!(&data[0], &[42]);
/// ```
///
/// Iwe unogona zvakare kushanda pamwe nepakati yakatangiswa arrays, iyo inogona kuwanikwa mune yakaderera-chikamu madhata.
///
/// ```
/// use std::mem::MaybeUninit;
/// use std::ptr;
///
/// // Gadzira uninitialized rondedzero ye `MaybeUninit`.
/// // Iyo `assume_init` yakachengeteka nekuti mhando yatiri kuti takatangisa pano iboka re`MayingaUninit`s, ayo asingade kutanga.
/////
/// let mut data: [MaybeUninit<String>; 1000] = unsafe { MaybeUninit::uninit().assume_init() };
/// // Verenga huwandu hwezvinhu zvatakapa.
/// let mut data_len: usize = 0;
///
/// for elem in &mut data[0..500] {
///     *elem = MaybeUninit::new(String::from("hello"));
///     data_len += 1;
/// }
///
/// // Kune chimwe nechimwe chinhu chiri munhevedzano, donha kana tikachigovera.
/// for elem in &mut data[0..data_len] {
///     unsafe { ptr::drop_in_place(elem.as_mut_ptr()); }
/// }
/// ```
///
/// ## Kutanga iyo yakagadzirirwa munda-ne-munda
///
/// Unogona kushandisa `MaybeUninit<T>`, uye iyo [`std::ptr::addr_of_mut`] macro, kutanga structs munda nemunda:
///
/// ```rust
/// use std::mem::MaybeUninit;
/// use std::ptr::addr_of_mut;
///
/// #[derive(Debug, PartialEq)]
/// pub struct Foo {
///     name: String,
///     list: Vec<u8>,
/// }
///
/// let foo = {
///     let mut uninit: MaybeUninit<Foo> = MaybeUninit::uninit();
///     let ptr = uninit.as_mut_ptr();
///
///     // Kutanga iyo `name` munda
///     unsafe { addr_of_mut!((*ptr).name).write("Bob".to_string()); }
///
///     // Kutanga iyo `list` munda Kana paine panic pano, ipapo iyo `String` mune iyo `name` munda inodonha.
/////
///     unsafe { addr_of_mut!((*ptr).list).write(vec![0, 1, 2]); }
///
///     // Yese minda yakatangwa, saka tinodaidza `assume_init` kuti titore yekutanga Foo.
///     unsafe { uninit.assume_init() }
/// };
///
/// assert_eq!(
///     foo,
///     Foo {
///         name: "Bob".to_string(),
///         list: vec![0, 1, 2]
///     }
/// );
/// ```
/// [`std::ptr::addr_of_mut`]: crate::ptr::addr_of_mut
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Layout
///
/// `MaybeUninit<T>` inovimbiswa kuva nehukuru hwakaenzana, kuenderana, uye ABI se `T`:
///
/// ```rust
/// use std::mem::{MaybeUninit, size_of, align_of};
/// assert_eq!(size_of::<MaybeUninit<u64>>(), size_of::<u64>());
/// assert_eq!(align_of::<MaybeUninit<u64>>(), align_of::<u64>());
/// ```
///
/// Zvisinei yeuka kuti mhando *iine*`MaybeUninit<T>` haisiriyo mamiriro akafanana;Rust haina vimbiso yakajairika yekuti minda ye `Foo<T>` ine hurongwa hwakafanana ne `Foo<U>` kunyangwe `T` ne `U` vane saizi yakaenzana uye kuenderana.
///
/// Kupfuurirazve nekuti chero kukosha kwechero kunoshanda kune `MaybeUninit<T>` iyo compiler haigone kushandisa non-zero/niche-filling optimizations, zvinogona kukonzera saizi yakakura.
///
/// ```rust
/// # use std::mem::{MaybeUninit, size_of};
/// assert_eq!(size_of::<Option<bool>>(), 1);
/// assert_eq!(size_of::<Option<MaybeUninit<bool>>>(), 2);
/// ```
///
/// Kana `T` iri FFI-yakachengeteka, saka ndozvakaitawo `MaybeUninit<T>`.
///
/// Ipo `MaybeUninit` iri `#[repr(transparent)]` (zvichiratidza kuti inovimbisa saizi yakafanana, kuenderana, uye ABI se `T`), izvi hazvi * shandure chero chekare mapango.
/// `Option<T>` uye `Option<MaybeUninit<T>>` inogona kunge iine saizi dzakasiyana, uye mhando dzine munda werudzi `T` dzinogona kuiswa (uye hukuru) zvakasiyana pane dai munda uyu waive `MaybeUninit<T>`.
/// `MaybeUninit` mhando yemubatanidzwa, uye `#[repr(transparent)]` pamubatanidzwa haina kugadzikana (ona [the tracking issue](https://github.com/rust-lang/rust/issues/60405)).
/// Nekufamba kwenguva, iyo chaiyo inovimbisa ye `#[repr(transparent)]` pamubatanidzwa inogona kuchinja, uye `MaybeUninit` inogona kana isingagare `#[repr(transparent)]`.
/// Izvo zvakati, `MaybeUninit<T>` icha * gara ichisimbisa kuti ine saizi yakafanana, kuenderana, uye ABI se `T`;ingori nzira iyo `MaybeUninit` inoshandisa iyo vimbiso inogona kuchinja.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "maybe_uninit", since = "1.36.0")]
// Lang chinhu kuti tikwanise kuputira mamwe marudzi mairi.Izvi zvinobatsira kumagetsi.
#[lang = "maybe_uninit"]
#[derive(Copy)]
#[repr(transparent)]
pub union MaybeUninit<T> {
    uninit: (),
    value: ManuallyDrop<T>,
}

#[stable(feature = "maybe_uninit", since = "1.36.0")]
impl<T: Copy> Clone for MaybeUninit<T> {
    #[inline(always)]
    fn clone(&self) -> Self {
        // Kwete kudaidza `T::clone()`, hatigone kuziva kana isu takatangwa zvakakwana izvo.
        *self
    }
}

#[stable(feature = "maybe_uninit_debug", since = "1.41.0")]
impl<T> fmt::Debug for MaybeUninit<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad(type_name::<Self>())
    }
}

impl<T> MaybeUninit<T> {
    /// Inogadzira `MaybeUninit<T>` nyowani yakatangwa nemutengo wakapihwa.
    /// Zvakachengeteka kufona [`assume_init`] pane kukosha kwekudzoka kweiri basa.
    ///
    /// Ziva kuti kudonhedza `MaybeUninit<T>` hakuzombofona kodhi inodonhedza `T`.
    /// Ibasa rako kuona kuti `T` inodonhedzwa kana ikatanga.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<Vec<u8>> = MaybeUninit::new(vec![42]);
    /// ```
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    pub const fn new(val: T) -> MaybeUninit<T> {
        MaybeUninit { value: ManuallyDrop::new(val) }
    }

    /// Inogadzira `MaybeUninit<T>` nyowani mune isina kuiswa mamiriro.
    ///
    /// Ziva kuti kudonhedza `MaybeUninit<T>` hakuzombofona kodhi inodonhedza `T`.
    /// Ibasa rako kuona kuti `T` inodonhedzwa kana ikatanga.
    ///
    /// Ona iyo [type-level documentation][MaybeUninit] yemimwe mienzaniso.
    ///
    /// # Example
    ///
    /// ```
    /// use std::mem::MaybeUninit;
    ///
    /// let v: MaybeUninit<String> = MaybeUninit::uninit();
    /// ```
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_stable(feature = "const_maybe_uninit", since = "1.36.0")]
    #[inline(always)]
    #[rustc_diagnostic_item = "maybe_uninit_uninit"]
    pub const fn uninit() -> MaybeUninit<T> {
        MaybeUninit { uninit: () }
    }

    /// Gadzira mutsva mutsva we `MaybeUninit<T>` zvinhu, mune isina kuiswa mamiriro.
    ///
    /// Note: mu future Rust vhezheni iyi nzira inogona kusakosha kana rondedzero chaiyo ichibvumira [repeating const expressions](https://github.com/rust-lang/rust/issues/49147).
    ///
    /// Muenzaniso pazasi unogona kushandisa `let mut buf = [MaybeUninit::<u8>::uninit(); 32];`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// #![feature(maybe_uninit_uninit_array, maybe_uninit_extra, maybe_uninit_slice)]
    ///
    /// use std::mem::MaybeUninit;
    ///
    /// extern "C" {
    ///     fn read_into_buffer(ptr: *mut u8, max_len: usize) -> usize;
    /// }
    ///
    /// /// Inodzosera chidimbu che (chingangove chidiki) che data chaive chaverengerwa
    /// fn read(buf: &mut [MaybeUninit<u8>]) -> &[u8] {
    ///     unsafe {
    ///         let len = read_into_buffer(buf.as_mut_ptr() as *mut u8, buf.len());
    ///         MaybeUninit::slice_assume_init_ref(&buf[..len])
    ///     }
    /// }
    ///
    /// let mut buf: [MaybeUninit<u8>; 32] = MaybeUninit::uninit_array();
    /// let data = read(&mut buf);
    /// ```
    ///
    #[unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[rustc_const_unstable(feature = "maybe_uninit_uninit_array", issue = "none")]
    #[inline(always)]
    pub const fn uninit_array<const LEN: usize>() -> [Self; LEN] {
        // KUCHENGETEKA: Iyo isina kuvhurwa `[MaybeUninit<_>; LEN]` inoshanda.
        unsafe { MaybeUninit::<[MaybeUninit<T>; LEN]>::uninit().assume_init() }
    }

    /// Inogadzira `MaybeUninit<T>` nyowani mune isina kuvhurika mamiriro, ndangariro dzichizadzwa ne `0` byte.Zvinoenderana ne `T` kunyangwe izvo zvatoita yekutanga chaiyo.
    ///
    /// Semuenzaniso, `MaybeUninit<usize>::zeroed()` inotangwa, asi `MaybeUninit<&'static i32>::zeroed()` haisi nekuti mareferenzi haafanire kuve asina basa.
    ///
    /// Ziva kuti kudonhedza `MaybeUninit<T>` hakuzombofona kodhi inodonhedza `T`.
    /// Ibasa rako kuona kuti `T` inodonhedzwa kana ikatanga.
    ///
    /// # Example
    ///
    /// Kururamisa mashandiro ebasa iri: kutanga dhizaina zero, uko nzvimbo dzese dzechimiro dzinogona kubata iyo bit-pateni 0 seyakafanira kukosha.
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<(u8, bool)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// assert_eq!(x, (0, false));
    /// ```
    ///
    /// *Kusava kwakakodzera* mashandisiro ebasa iri: kufonera `x.zeroed().assume_init()` apo `0` isiri yechokwadi pateni yerudzi:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// enum NotZero { One = 1, Two = 2 }
    ///
    /// let x = MaybeUninit::<(u8, NotZero)>::zeroed();
    /// let x = unsafe { x.assume_init() };
    /// // Mukati meviri, tinogadzira `NotZero` iyo isina rusarura runoshanda.
    /// // Aya maitiro asina kujekeswa.⚠️
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[inline]
    #[rustc_diagnostic_item = "maybe_uninit_zeroed"]
    pub fn zeroed() -> MaybeUninit<T> {
        let mut u = MaybeUninit::<T>::uninit();
        // KUCHENGETEKA: `u.as_mut_ptr()` inongedzera kune yakapihwa ndangariro.
        unsafe {
            u.as_mut_ptr().write_bytes(0u8, 1);
        }
        u
    }

    /// Inoisa kukosha kwe `MaybeUninit<T>`.
    /// Izvi zvinonyora pasi chero kukosha kwekare pasina kurisiya, saka chenjera kuti usashandise izvi kaviri kunze kwekunge iwe uchida kusvetuka kumhanyisa muparadzi.
    ///
    /// Kuti zvive nyore kwauri, izvi zvakare zvinodzosera zvinogona kuchinjika kune izvo (izvozvi zvakatangwa zvakachengeteka) zviri mukati me `self`.
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const fn write(&mut self, val: T) -> &mut T {
        *self = MaybeUninit::new(val);
        // Kachengeteka: Isu tangotanga iyi kukosha.
        unsafe { self.assume_init_mut() }
    }

    /// Inowana chinongedzo kune icho chine kukosha.
    /// Kuverenga kubva pane ino pointer kana kuichinja kuita chirevo chisina kujekeswa maitiro kunze kwekunge `MaybeUninit<T>` yatangwa.
    /// Kunyora kuyeuka kuti ino pointer (non-transitively) inonongedzera kune isina kujekeswa maitiro (kunze kwemukati me `UnsafeCell<T>`).
    ///
    /// # Examples
    ///
    /// Kururamisa mashandisiro eiyi nzira:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Gadzira chirevo mu `MaybeUninit<T>`.Izvi zvakanaka nekuti isu takazvitangisa.
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// assert_eq!(x_vec.len(), 3);
    /// ```
    ///
    /// *Kusaita* kushandiswa kweiyi nzira:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &*x.as_ptr() };
    /// // Isu takagadzira chirevo kune isina kuvhurwa vector!Aya maitiro asina kujekeswa.⚠️
    /// ```
    ///
    /// (Cherekedza kuti iyo mirawu yakatenderedza mareferenzi kune isina kuvhurwa dhata haisati yapedzwa, asi kusvika paari, zvinokurudzirwa kuadzivisa.)
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_ptr(&self) -> *const T {
        // `MaybeUninit` uye `ManuallyDrop` ese ari maviri `repr(transparent)` saka tinogona kukanda pointer.
        self as *const _ as *const T
    }

    /// Inotora chinongedzo chinoshanduka kune icho chine kukosha.
    /// Kuverenga kubva pane ino pointer kana kuichinja kuita chirevo chisina kujekeswa maitiro kunze kwekunge `MaybeUninit<T>` yatangwa.
    ///
    /// # Examples
    ///
    /// Kururamisa mashandisiro eiyi nzira:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// unsafe { x.as_mut_ptr().write(vec![0, 1, 2]); }
    /// // Gadzira chirevo mu `MaybeUninit<Vec<u32>>`.
    /// // Izvi zvakanaka nekuti isu takazvitangisa.
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// x_vec.push(3);
    /// assert_eq!(x_vec.len(), 4);
    /// ```
    ///
    /// *Kusaita* kushandiswa kweiyi nzira:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec = unsafe { &mut *x.as_mut_ptr() };
    /// // Isu takagadzira chirevo kune isina kuvhurwa vector!Aya maitiro asina kujekeswa.⚠️
    /// ```
    ///
    /// (Cherekedza kuti iyo mirawu yakatenderedza mareferenzi kune isina kuvhurwa dhata haisati yapedzwa, asi kusvika paari, zvinokurudzirwa kuadzivisa.)
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_as_ptr", issue = "75251")]
    #[inline(always)]
    pub const fn as_mut_ptr(&mut self) -> *mut T {
        // `MaybeUninit` uye `ManuallyDrop` ese ari maviri `repr(transparent)` saka tinogona kukanda pointer.
        self as *mut _ as *mut T
    }

    /// Inobvisa kukosha kubva mumudziyo we `MaybeUninit<T>`.Iyi inzira huru yekuona kuti data rinodonhedzwa, nekuti mhedzisiro `T` iri pasi peyakajairika kudonhedzwa kwekubata.
    ///
    /// # Safety
    ///
    /// Zviri kumunhu anofona kuti ave nechokwadi chekuti `MaybeUninit<T>` iri chaizvo mune yekutanga nyika.Kufonera izvi kana zvirimo zvisati zvatanga zvizere zvinokonzeresa kusanzwisisika maitiro.
    /// Iyo [type-level documentation][inv] ine rumwe ruzivo nezve iyi yekutanga invariant.
    ///
    /// [inv]: #initialization-invariant
    ///
    /// Pamusoro pezvo, yeuka kuti mhando zhinji dzine mamwe mahemeti zvinopfuura kungofungidzirwa kuti zvakatangwa padanho rerudzi.
    /// Semuenzaniso, `1`-yakatangwa [`Vec<T>`] inoonekwa seyakatangwa (pasi pezvinoitwa; izvi hazviite gadziriro yakagadzikana) nekuti icho chete chinodiwa icho muunganidzi anoziva nezvazvo ndechekuti data pointer inofanira kunge isiri-null.
    ///
    /// Kugadzira yakadai `Vec<T>` hakukonzere *iko* kusajeka maitiro, asi kunozokonzeresa kujekesa maitiro nemaitiro mazhinji akachengeteka (kusanganisira kuisiya).
    ///
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    /// # Examples
    ///
    /// Kururamisa mashandisiro eiyi nzira:
    ///
    /// ```rust
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<bool>::uninit();
    /// unsafe { x.as_mut_ptr().write(true); }
    /// let x_init = unsafe { x.assume_init() };
    /// assert_eq!(x_init, true);
    /// ```
    ///
    /// *Kusaita* kushandiswa kweiyi nzira:
    ///
    /// ```rust,no_run
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_init = unsafe { x.assume_init() };
    /// // `x` yakanga isati yatangwa, saka iyi yekupedzisira tambo yakakonzera kusanzwisisika maitiro.⚠️
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "maybe_uninit", since = "1.36.0")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    #[rustc_diagnostic_item = "assume_init"]
    pub const unsafe fn assume_init(self) -> T {
        // Kachengeteka: iye anodana anofanira kuvimbisa kuti `self` inotangwa.
        // Izvi zvinoreva zvakare kuti `self` inofanira kunge iri `value` musiyano.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            ManuallyDrop::into_inner(self.value)
        }
    }

    /// Inoverenga kukosha kubva mumudziyo we `MaybeUninit<T>`.Iyo inoguma `T` iri pasi peyakajairika kudonhedza kubata.
    ///
    /// Pese pazvinogoneka, zviri nani kushandisa [`assume_init`] pachinzvimbo, izvo zvinodzivirira kudzokorora zvirimo mu `MaybeUninit<T>`.
    ///
    /// # Safety
    ///
    /// Zviri kumunhu anofona kuti ave nechokwadi chekuti `MaybeUninit<T>` iri chaizvo mune yekutanga nyika.Kufonera izvi kana zvirimo zvisati zvanyatso zadziswa zvinokonzeresa maitiro.
    /// Iyo [type-level documentation][inv] ine rumwe ruzivo nezve iyi yekutanga invariant.
    ///
    /// Zvakare, izvi zvinosiya kopi yedata rakafanana kumashure mu `MaybeUninit<T>`.
    /// Paunenge uchishandisa makopi akawanda e data (nekufona `assume_init_read` kakawanda, kana kutanga kufonera `assume_init_read` uyezve [`assume_init`]), ibasa rako kuona kuti iro data rinogona kunyorwa.
    ///
    ///
    /// [inv]: #initialization-invariant
    /// [`assume_init`]: MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// Kururamisa mashandisiro eiyi nzira:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<u32>::uninit();
    /// x.write(13);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // `u32` iri `Copy`, saka tinogona kuverenga kakawanda.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(None);
    /// let x1 = unsafe { x.assume_init_read() };
    /// // Kudzokorora kukosha kwe `None` kwakanaka, saka tinogona kuverenga kakawanda.
    /// let x2 = unsafe { x.assume_init_read() };
    /// assert_eq!(x1, x2);
    /// ```
    ///
    /// *Kusaita* kushandiswa kweiyi nzira:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_extra)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Option<Vec<u32>>>::uninit();
    /// x.write(Some(vec![0, 1, 2]));
    /// let x1 = unsafe { x.assume_init_read() };
    /// let x2 = unsafe { x.assume_init_read() };
    /// // Isu zvino takagadzira makopi maviri e vector imwe chete, zvichitungamira kune yakasununguka-free️ apo ivo vaviri pavanodonhedzwa!
    /////
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[rustc_const_unstable(feature = "maybe_uninit_extra", issue = "63567")]
    #[inline(always)]
    pub const unsafe fn assume_init_read(&self) -> T {
        // Kachengeteka: iye anodana anofanira kuvimbisa kuti `self` inotangwa.
        // Kuverenga kubva ku `self.as_ptr()` kwakachengeteka nekuti `self` inofanira kutanga.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            self.as_ptr().read()
        }
    }

    /// Anodonhedza kukosha kuri munzvimbo.
    ///
    /// Kana iwe uine muridzi we `MaybeUninit`, unogona kushandisa [`assume_init`] pachinzvimbo.
    ///
    /// # Safety
    ///
    /// Zviri kumunhu anofona kuti ave nechokwadi chekuti `MaybeUninit<T>` iri chaizvo mune yekutanga nyika.Kufonera izvi kana zvirimo zvisati zvanyatso zadziswa zvinokonzeresa maitiro.
    ///
    /// Pamusoro peizvozvo, zvese zvinowedzera zvinopinda zverudzi `T` zvinofanirwa kugutsikana, sezvo `Drop` kuitiswa kwe `T` (kana nhengo dzayo) inogona kuvimba neizvi.
    /// Semuenzaniso, `1`-yakatangwa [`Vec<T>`] inoonekwa seyakatangwa (pasi pezvinoitwa; izvi hazviite gadziriro yakagadzikana) nekuti icho chete chinodiwa icho muunganidzi anoziva nezvazvo ndechekuti data pointer inofanira kunge isiri-null.
    ///
    /// Kudonhedza `Vec<T>` yakadaro zvakadaro kunozokonzeresa kujekesa maitiro.
    ///
    /// [`assume_init`]: MaybeUninit::assume_init
    /// [`Vec<T>`]: ../../std/vec/struct.Vec.html
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_extra", issue = "63567")]
    pub unsafe fn assume_init_drop(&mut self) {
        // Kachengeteka: iye anodana anofanira kuvimbisa kuti `self` inotangwa uye
        // inogutsa zvese zvinopinda zve `T`.
        // Kudonhedza kukosha munzvimbo kwakachengeteka kana zvirizvo.
        unsafe { ptr::drop_in_place(self.as_mut_ptr()) }
    }

    /// Inowana rejisheni yakagovaniswa kune iyo kukosha kukosha.
    ///
    /// Izvi zvinogona kubatsira kana isu tichida kuwana `MaybeUninit` iyo yakatangwa asi isina muridzi we `MaybeUninit` (kudzivirira kushandiswa kwe `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Kudana izvi kana zvirimo zvisati zvatanga zvizere zvinokonzeresa hunhu husina kutsanangurwa: zviri kune iye anofona kuti ave nechokwadi chekuti `MaybeUninit<T>` iri muchimiro chakatangwa.
    ///
    ///
    /// # Examples
    ///
    /// ### Kururamisa mashandisiro eiyi nzira:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut x = MaybeUninit::<Vec<u32>>::uninit();
    /// // Kutanga `x`:
    /// unsafe { x.as_mut_ptr().write(vec![1, 2, 3]); }
    /// // Iye zvino sezvo `MaybeUninit<_>` yedu ichizivikanwa kuti inotangwa, zvakanaka kugadzira rejista yakagovaniswa kwazviri:
    /////
    /// let x: &Vec<u32> = unsafe {
    ///     // Kachengeteka: `x` yakatangwa.
    ///     x.assume_init_ref()
    /// };
    /// assert_eq!(x, &vec![1, 2, 3]);
    /// ```
    ///
    /// ### *Zvisirizvo* mashandisiro eiyi nzira:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let x = MaybeUninit::<Vec<u32>>::uninit();
    /// let x_vec: &Vec<u32> = unsafe { x.assume_init_ref() };
    /// // Isu takagadzira chirevo kune isina kuvhurwa vector!Aya maitiro asina kujekeswa.⚠️
    /// ```
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{cell::Cell, mem::MaybeUninit};
    ///
    /// let b = MaybeUninit::<Cell<bool>>::uninit();
    /// // Kutanga iyo `MaybeUninit` uchishandisa `Cell::set`:
    /// unsafe {
    ///     b.assume_init_ref().set(true);
    ///    // ^^^^^^^^^^^^^^^
    ///    // Kureva kune isina kuvhurwa `Cell<bool>`: UB!
    /// }
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_ref(&self) -> &T {
        // Kachengeteka: iye anodana anofanira kuvimbisa kuti `self` inotangwa.
        // Izvi zvinoreva zvakare kuti `self` inofanira kunge iri `value` musiyano.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &*self.as_ptr()
        }
    }

    /// Inowana inoshanduka (unique) rejisheni kune irimo kukosha.
    ///
    /// Izvi zvinogona kubatsira kana isu tichida kuwana `MaybeUninit` iyo yakatangwa asi isina muridzi we `MaybeUninit` (kudzivirira kushandiswa kwe `.assume_init()`).
    ///
    /// # Safety
    ///
    /// Kudana izvi kana zvirimo zvisati zvatanga zvizere zvinokonzeresa hunhu husina kutsanangurwa: zviri kune iye anofona kuti ave nechokwadi chekuti `MaybeUninit<T>` iri muchimiro chakatangwa.
    /// Semuenzaniso, `.assume_init_mut()` haigone kushandiswa kutanga `MaybeUninit`.
    ///
    /// # Examples
    ///
    /// ### Kururamisa mashandisiro eiyi nzira:
    ///
    /// ```rust
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// # unsafe extern "C" fn initialize_buffer(buf: *mut [u8; 2048]) { *buf = [0; 2048] }
    /// # #[cfg(FALSE)]
    /// extern "C" {
    ///     /// Inotanga *ese* mabheti eiyo yekupinda bhafa.
    ///     fn initialize_buffer(buf: *mut [u8; 2048]);
    /// }
    ///
    /// let mut buf = MaybeUninit::<[u8; 2048]>::uninit();
    ///
    /// // Kutanga `buf`:
    /// unsafe { initialize_buffer(buf.as_mut_ptr()); }
    /// // Iye zvino tinoziva kuti `buf` yakatangwa, saka tinogona `.assume_init()` iyo.
    /// // Nekudaro, kushandisa `.assume_init()` kunogona kukonzera `memcpy` yemakumi maviri nemakumi maviri emabheti.
    /// // Kusimbisa buffer yedu yakatangwa pasina kuikopa, isu tinosimudzira iyo `&mut MaybeUninit<[u8; 2048]>` kuenda ku `&mut [u8; 2048]`:
    /////
    /// let buf: &mut [u8; 2048] = unsafe {
    ///     // Kachengeteka: `buf` yakatangwa.
    ///     buf.assume_init_mut()
    /// };
    ///
    /// // Iye zvino tinogona kushandisa `buf` sechinhu chakajairika slice:
    /// buf.sort_unstable();
    /// assert!(
    ///     buf.windows(2).all(|pair| pair[0] <= pair[1]),
    ///     "buffer is sorted",
    /// );
    /// ```
    ///
    /// ### *Zvisirizvo* mashandisiro eiyi nzira:
    ///
    /// Iwe haugone kushandisa `.assume_init_mut()` kutanga kukosha:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut b = MaybeUninit::<bool>::uninit();
    /// unsafe {
    ///     *b.assume_init_mut() = true;
    ///     // Isu takagadzira (mutable) yekureva kune isina kuvhurwa `bool`!
    ///     // Aya maitiro asina kujekeswa.⚠️
    /// }
    /// ```
    ///
    /// Semuenzaniso, haugone [`Read`] mune isina kuvhurwa buffer:
    ///
    /// [`Read`]: https://doc.rust-lang.org/std/io/trait.Read.html
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{io, mem::MaybeUninit};
    ///
    /// fn read_chunk (reader: &'_ mut dyn io::Read) -> io::Result<[u8; 64]>
    /// {
    ///     let mut buffer = MaybeUninit::<[u8; 64]>::uninit();
    ///     reader.read_exact(unsafe { buffer.assume_init_mut() })?;
    ///                             // ^^^^^^^^^^^^^^^^^^^^^^^^
    ///                             // (mutable) chirevo kune chisina kuvambwa ndangariro!
    ///                             // Aya maitiro asina kujekeswa.
    ///     Ok(unsafe { buffer.assume_init() })
    /// }
    /// ```
    ///
    /// Kana iwe haugone kushandisa yakananga munda kuwana kuita munda-ne-munda zvishoma nezvishoma kutanga:
    ///
    /// ```rust,no_run
    /// #![feature(maybe_uninit_ref)]
    /// use std::{mem::MaybeUninit, ptr};
    ///
    /// struct Foo {
    ///     a: u32,
    ///     b: u8,
    /// }
    ///
    /// let foo: Foo = unsafe {
    ///     let mut foo = MaybeUninit::<Foo>::uninit();
    ///     ptr::write(&mut foo.assume_init_mut().a as *mut u32, 1337);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) chirevo kune chisina kuvambwa ndangariro!
    ///                  // Aya maitiro asina kujekeswa.
    ///     ptr::write(&mut foo.assume_init_mut().b as *mut u8, 42);
    ///                  // ^^^^^^^^^^^^^^^^^^^^^
    ///                  // (mutable) chirevo kune chisina kuvambwa ndangariro!
    ///                  // Aya maitiro asina kujekeswa.
    ///     foo.assume_init()
    /// };
    /// ```
    ///
    ///
    ///
    ///
    // FIXME(#76092): Isu parizvino tinovimba nezve pamusoro kuti zvisiri izvo, kureva kuti, tine mareferenzi kune isina kuvhurwa dhata (semuenzaniso, mu `libcore/fmt/float.rs`).
    // Isu tinofanirwa kuita sarudzo yekupedzisira pamusoro pemitemo isati yadzikama.
    //
    #[unstable(feature = "maybe_uninit_ref", issue = "63568")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn assume_init_mut(&mut self) -> &mut T {
        // Kachengeteka: iye anodana anofanira kuvimbisa kuti `self` inotangwa.
        // Izvi zvinoreva zvakare kuti `self` inofanira kunge iri `value` musiyano.
        unsafe {
            intrinsics::assert_inhabited::<T>();
            &mut *self.as_mut_ptr()
        }
    }

    /// Inoburitsa hunhu kubva pamhando yemidziyo ye `MaybeUninit`.
    ///
    /// # Safety
    ///
    /// Zviri kumunhu anodana kuti avimbise kuti zvese zvinhu zveakarongeka zviri munzvimbo yekutanga.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_uninit_array)]
    /// #![feature(maybe_uninit_array_assume_init)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut array: [MaybeUninit<i32>; 3] = MaybeUninit::uninit_array();
    /// array[0] = MaybeUninit::new(0);
    /// array[1] = MaybeUninit::new(1);
    /// array[2] = MaybeUninit::new(2);
    ///
    /// // Kachengeteka: Izvozvi zvakachengeteka sezvo isu takatanga zvese zvinhu
    /// let array = unsafe {
    ///     MaybeUninit::array_assume_init(array)
    /// };
    ///
    /// assert_eq!(array, [0, 1, 2]);
    /// ```
    #[unstable(feature = "maybe_uninit_array_assume_init", issue = "80908")]
    #[inline(always)]
    pub unsafe fn array_assume_init<const N: usize>(array: [Self; N]) -> [T; N] {
        // SAFETY:
        // * Anofona anovimbisa kuti zvese zvinhu zvemudungwe zvinotangwa
        // * `MaybeUninit<T>` uye T vanovimbiswa kuve nemamiriro akafanana
        // * PamweUnint haidonhedze, saka hapana zvakapetwa kaviri Uye nekudaro kutendeuka kwakachengeteka
        //
        unsafe {
            intrinsics::assert_inhabited::<[T; N]>();
            (&array as *const _ as *const [T; N]).read()
        }
    }

    /// Kufunga kuti zvese zvinhu zvakavambwa, tora chidimbu kwavari.
    ///
    /// # Safety
    ///
    /// Zviri kumunhu anofona kuti ave nechokwadi chekuti `MaybeUninit<T>` zvinhu zviri chaizvo munzvimbo yekutanga.
    ///
    /// Kufonera izvi kana zvirimo zvisati zvanyatso zadziswa zvinokonzeresa maitiro.
    ///
    /// Ona [`assume_init_ref`] kune rumwe ruzivo uye mienzaniso.
    ///
    /// [`assume_init_ref`]: MaybeUninit::assume_init_ref
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_ref(slice: &[Self]) -> &[T] {
        // Kachengeteka: kukanda slice kune `*const [T]` kwakachengeteka sezvo iye anofona achivimbisa izvozvo
        // `slice` inotangwa, uye`MaybeUninit` inovimbiswa kuve nemamiriro akafanana ne `T`.
        // Iyo pointer inowanikwa ndeyekuti inoreva ndangariro dzinowanikwa ne `slice` inova chirevo uye nekudaro inovimbiswa kuve inoshanda pakuverenga.
        //
        unsafe { &*(slice as *const [Self] as *const [T]) }
    }

    /// Kufunga kuti zvese zvinhu zvakavambwa, tora chinoshanduka kwavari.
    ///
    /// # Safety
    ///
    /// Zviri kumunhu anofona kuti ave nechokwadi chekuti `MaybeUninit<T>` zvinhu zviri chaizvo munzvimbo yekutanga.
    ///
    /// Kufonera izvi kana zvirimo zvisati zvanyatso zadziswa zvinokonzeresa maitiro.
    ///
    /// Ona [`assume_init_mut`] kune rumwe ruzivo uye mienzaniso.
    ///
    /// [`assume_init_mut`]: MaybeUninit::assume_init_mut
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "const_maybe_uninit_assume_init", issue = "none")]
    #[inline(always)]
    pub const unsafe fn slice_assume_init_mut(slice: &mut [Self]) -> &mut [T] {
        // KUCHENGETEKA: yakafanana neyekuchengetedza manotsi e `slice_get_ref`, asi isu tine
        // chinoshandurwa chirevo icho zvakare chakavimbiswa kuve chakakodzera kunyora.
        unsafe { &mut *(slice as *mut [Self] as *mut [T]) }
    }

    /// Inotora chinongedzo kuchinhu chekutanga chemudungwe.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_ptr(this: &[MaybeUninit<T>]) -> *const T {
        this.as_ptr() as *const T
    }

    /// Inotora chinongedzo chinoshanduka kuchinhu chekutanga chemudungwe.
    #[unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[rustc_const_unstable(feature = "maybe_uninit_slice", issue = "63569")]
    #[inline(always)]
    pub const fn slice_as_mut_ptr(this: &mut [MaybeUninit<T>]) -> *mut T {
        this.as_mut_ptr() as *mut T
    }

    /// Inoteedzera zvinhu kubva ku `src` kuenda ku `this`, ichidzorera chinongedzo chinogona kuchinjika kune izvozvi zvakaiswa mukati meiyo `this`.
    ///
    /// Kana `T` isingaite `Copy`, shandisa [`write_slice_cloned`]
    ///
    /// Izvi zvakafanana ne [`slice::copy_from_slice`].
    ///
    /// # Panics
    ///
    /// Iri basa richaita panic kana iwo maviri maronda aine urefu hwakasiyana.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(); 32];
    /// let src = [0; 32];
    ///
    /// let init = MaybeUninit::write_slice(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = [0; 16];
    ///
    /// MaybeUninit::write_slice(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // Kachengeteka: isu tangoteedzera zvese zvinhu zvelen munzvimbo yekuchengetedza
    /// // yekutanga src.len() zvinhu zvevc zviri kushanda izvozvi.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice_cloned`]: MaybeUninit::write_slice_cloned
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Copy,
    {
        // Kachengeteka: &[T] uye&[ZvichidaUninit<T>] vane mamiriro akafanana
        let uninit_src: &[MaybeUninit<T>] = unsafe { super::transmute(src) };

        this.copy_from_slice(uninit_src);

        // KUCHENGETEKA: Zvinhu zvinobvumirwa zvakangoteedzerwa mu `this` saka haina kupihwa mitezo
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }

    /// Inochinjisa zvinhu kubva ku `src` kuenda ku `this`, ichidzorera chinongedzo chinoshanduka kune izvozvi zvakaiswa mukati meiyo `this`.
    /// Chero zvipi zvatova initalized zvinhu hazvisi kuzodonhedzwa.
    ///
    /// Kana `T` ichishandisa `Copy`, shandisa [`write_slice`]
    ///
    /// Izvi zvakafanana ne [`slice::clone_from_slice`] asi haidonhedze zvinhu zviripo.
    ///
    /// # Panics
    ///
    /// Iri basa richaita panic kana zvidimbu zviviri zvine urefu hwakasiyana, kana kana kuitiswa kwe `Clone` panics.
    ///
    /// Kana paine panic, izvo zvinhu zvakaumbwa kare zvinokandwa.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut dst = [MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit(), MaybeUninit::uninit()];
    /// let src = ["wibbly".to_string(), "wobbly".to_string(), "timey".to_string(), "wimey".to_string(), "stuff".to_string()];
    ///
    /// let init = MaybeUninit::write_slice_cloned(&mut dst, &src);
    ///
    /// assert_eq!(init, src);
    /// ```
    ///
    /// ```
    /// #![feature(maybe_uninit_write_slice, vec_spare_capacity)]
    /// use std::mem::MaybeUninit;
    ///
    /// let mut vec = Vec::with_capacity(32);
    /// let src = ["rust", "is", "a", "pretty", "cool", "language"];
    ///
    /// MaybeUninit::write_slice_cloned(&mut vec.spare_capacity_mut()[..src.len()], &src);
    ///
    /// // Kachengeteka: isu tichangobva kuumbiridza zvese zvinhu zvelen munzvimbo yekuchengetedza
    /// // yekutanga src.len() zvinhu zvevc zviri kushanda izvozvi.
    /// unsafe {
    ///     vec.set_len(src.len());
    /// }
    ///
    /// assert_eq!(vec, src);
    /// ```
    ///
    /// [`write_slice`]: MaybeUninit::write_slice
    #[unstable(feature = "maybe_uninit_write_slice", issue = "79995")]
    pub fn write_slice_cloned<'a>(this: &'a mut [MaybeUninit<T>], src: &[T]) -> &'a mut [T]
    where
        T: Clone,
    {
        // kusiyana copy_from_slice izvi hazvidaidze clone_from_slice pachidimbu ichi imhaka yekuti `MaybeUninit<T: Clone>` haiite Clone.
        //

        struct Guard<'a, T> {
            slice: &'a mut [MaybeUninit<T>],
            initialized: usize,
        }

        impl<'a, T> Drop for Guard<'a, T> {
            fn drop(&mut self) {
                let initialized_part = &mut self.slice[..self.initialized];
                // KUCHENGETEKA: chidimbu ichi chisina kugadzirwa chichava nezvinhu zvakangotanga chete
                // ndosaka, zvinotenderwa kuzvidonhedza.
                unsafe {
                    crate::ptr::drop_in_place(MaybeUninit::slice_assume_init_mut(initialized_part));
                }
            }
        }

        assert_eq!(this.len(), src.len(), "destination and source slices have different lengths");
        // NOTE: Isu tinofanirwa kujekesa zvakajeka kuhurefu hwakaenzana
        // kumiganhu yekutarisa kuti ikwirirwe, uye iyo optimizer ichagadzira memcpy yezviitiko zviri nyore (semuenzaniso T= u8).
        //
        let len = this.len();
        let src = &src[..len];

        // guard inodiwa b/c panic inogona kuitika panguva yedombo
        let mut guard = Guard { slice: this, initialized: 0 };

        for i in 0..len {
            guard.slice[i].write(src[i].clone());
            guard.initialized += 1;
        }

        super::forget(guard);

        // KUCHENGETEKA: Zvinhu zvinobvumirwa zvakangonyorwa mu `this` saka haina kupihwa mitezo
        unsafe { MaybeUninit::slice_assume_init_mut(this) }
    }
}