//! Basic mabasa ekubata nendangariro.
//!
//! Iyi module ine mabasa ekutsvagisa saizi uye kuenderana kwemhando, kutanga uye kukanganisa memory.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::clone;
use crate::cmp;
use crate::fmt;
use crate::hash;
use crate::intrinsics;
use crate::marker::{Copy, DiscriminantKind, Sized};
use crate::ptr;

mod manually_drop;
#[stable(feature = "manually_drop", since = "1.20.0")]
pub use manually_drop::ManuallyDrop;

mod maybe_uninit;
#[stable(feature = "maybe_uninit", since = "1.36.0")]
pub use maybe_uninit::MaybeUninit;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::transmute;

/// Inotora muridzi uye "forgets" nezve kukosha **pasina kumhanyisa muparadzi wayo**.
///
/// Chero zviwanikwa izvo kukosha kuchikwanisa, senge murwi ndangariro kana faira rekubata, zvinononoka kugara munzvimbo isingasvikike.Nekudaro, hazvipe vimbiso yekuti zvinongedzo kune ino ndangariro zvicharamba zvichishanda.
///
/// * Kana iwe uchida kuburitsa ndangariro, ona [`Box::leak`].
/// * Kana iwe uchida kuwana mbishi mbichana kumurangariro, ona [`Box::into_raw`].
/// * Kana iwe uchida kurasa kukosha nemazvo, uchimhanyisa muparadzi wayo, ona [`mem::drop`].
///
/// # Safety
///
/// `forget` haina kuiswa chiratidzo se `unsafe`, nekuti Rust yekuchengetedzwa kwekusimbisa haisanganisi garandi yekuti vaparadzi vagare vachimhanya.
/// Semuenzaniso, chirongwa chinogona kugadzira revhizheni kutenderera uchishandisa [`Rc`][rc], kana kufona [`process::exit`][exit] kuti ubude pasina kumhanya vaparadzi.
/// Nekudaro, kubvumidza `mem::forget` kubva kune yakachengeteka kodhi hakuchinje zvakanyanya Rust yekuchengetedza chengetedzo.
///
/// Izvo zvakati, kuburitsa zviwanikwa senge ndangariro kana I/O zvinhu zvinowanzo kuve zvisingadiwe.
/// Iko kudiwa kunouya mune akasarudzika mashandisiro ekushandisa maUFI kana kodhi isina kuchengetedzeka, asi kunyangwe ipapo, [`ManuallyDrop`] inowanzo sarudzwa.
///
/// Nekuti kukanganwa kukosha kunotenderwa, chero `unsafe` kodhi iwe yaunonyora inofanira kubvumidza iyi mukana.Iwe haugone kudzorera kukosha uye kutarisira kuti munhu anenge afona achazomhanyisa kukosha kweanoparadza.
///
/// [rc]: ../../std/rc/struct.Rc.html
/// [exit]: ../../std/process/fn.exit.html
///
/// # Examples
///
/// Iko canonical yakachengeteka kushandiswa kwe `mem::forget` kudzora kukosha kwekuparadza kunoitwa ne `Drop` trait.Semuenzaniso, izvi zvichaburitsa `File`, kureva
/// dzosera nzvimbo yakatorwa neshanduko asi usatombovhara iyo yepasi system sosi
///
/// ```no_run
/// use std::mem;
/// use std::fs::File;
///
/// let file = File::open("foo.txt").unwrap();
/// mem::forget(file);
/// ```
///
/// Izvi zvinobatsira kana muridzi wechiwanikwa chepasi akambotamisirwa kukodhi kunze kwe Rust, semuenzaniso nekuendesa iyo mbichana faira tsananguro kuC kodhi.
///
/// # Hukama ne `ManuallyDrop`
///
/// Ipo `mem::forget` inogona zvakare kushandiswa kuendesa *ndangariro* muridzi, kuita kudaro kukanganisa-kunowanzoitika.
/// [`ManuallyDrop`] inofanira kushandiswa pachinzvimbo.Funga, semuenzaniso, kodhi iyi:
///
/// ```
/// use std::mem;
///
/// let mut v = vec![65, 122];
/// // Gadzira `String` uchishandisa zvirimo mu `v`
/// let s = unsafe { String::from_raw_parts(v.as_mut_ptr(), v.len(), v.capacity()) };
/// // idonha `v` nekuti ndangariro yayo yave kutarisirwa ne `s`
/// mem::forget(v);  // Kanganiso, v haishande uye haifanire kupfuudzwa kune basa
/// assert_eq!(s, "Az");
/// // `s` rakadonhedzwa zvachose uye ndangariro dzayo dzakatamiswa.
/// ```
///
/// Pane nyaya mbiri nemuenzaniso uri pamusoro:
///
/// * Kana imwe kodhi yakawedzerwa pakati pekuvakwa kwe `String` nekukumbirwa kwe `mem::forget()`, panic mukati mayo inogona kukonzera kusununguka kwemaviri nekuti ndangariro imwechete inobatwa nezvose zviri zviviri `v` uye `s`.
/// * Mushure mekufonera `v.as_mut_ptr()` uye kuendesa iyo muridzi wedata kune `s`, iyo `v` kukosha hakuiti.
/// Kunyangwe kana kukosha kukangotamisirwa ku `mem::forget` (iyo isingazoiongorore), mamwe marudzi ane zvinodiwa zvakanyanya pamaitiro avo izvo zvinoita kuti zvisashande kana zvakarembera kana kusisina yavo.
/// Kushandisa zvisizvo zvisina kukodzera munzira ipi neipi, kusanganisira kuzvipfuudza kana kuzvidzorera kubva kumabasa, zvinoumba hunhu husina kujekeswa uye hunogona kutyora fungidziro dzakaitwa nemurongi.
///
/// Kuchinjira ku `ManuallyDrop` kunodzivirira nyaya mbiri idzi:
///
/// ```
/// use std::mem::ManuallyDrop;
///
/// let v = vec![65, 122];
/// // Tisati tatanura `v` muzvikamu zvayo zvisvinu, ita shuwa kuti haidonhedze!
/////
/// let mut v = ManuallyDrop::new(v);
/// // Zvino bvisa `v`.Aya mashandiro haakwanise panic, saka hakugone kuve nekudonha.
/// let (ptr, len, cap) = (v.as_mut_ptr(), v.len(), v.capacity());
/// // Pakupedzisira, gadzira `String`.
/// let s = unsafe { String::from_raw_parts(ptr, len, cap) };
/// assert_eq!(s, "Az");
/// // `s` rakadonhedzwa zvachose uye ndangariro dzayo dzakatamiswa.
/// ```
///
/// `ManuallyDrop` zvine simba zvinodzivirira zvakapetwa-zvechipiri nekuti isu tinoremadza v vuparadzi tisati taita chero chinhu.
/// `mem::forget()` haitenderi izvi nekuti inoshandisa nharo yayo, ichitimanikidza kuidana chete mushure mekutora chero chinhu chatinoda kubva ku `v`.
/// Kunyangwe dai panic yakaunzwa pakati pekuvakwa kwe `ManuallyDrop` uye kuvaka tambo (iyo isingagone kuitika mukodhi sezvakaratidzwa), zvaizoguma nekudonha kwete kusununguka kaviri.
/// Mune mamwe mazwi, `ManuallyDrop` inokanganisa parutivi rwekudonha pane kutadza kudivi re (mbiri-) kudonha.
///
/// Zvakare, `ManuallyDrop` inotitadzisa kubva ku "touch" `v` mushure mekutamisa muridzi ku `s`-yekupedzisira nhanho yekudyidzana ne `v` kuirasa pasina kumhanyisa muparadzi wayo inodzivirirwa zvachose.
///
///
/// [`Box`]: ../../std/boxed/struct.Box.html
/// [`Box::leak`]: ../../std/boxed/struct.Box.html#method.leak
/// [`Box::into_raw`]: ../../std/boxed/struct.Box.html#method.into_raw
/// [`mem::drop`]: drop
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[rustc_const_stable(feature = "const_forget", since = "1.46.0")]
#[stable(feature = "rust1", since = "1.0.0")]
pub const fn forget<T>(t: T) {
    let _ = ManuallyDrop::new(t);
}

/// Sa [`forget`], asi zvakare inogamuchira zvisina kukwana kukosha.
///
/// Iri basa ingori shim rinotarisirwa kubviswa kana `unsized_locals` ficha ikagadzikana.
///
#[inline]
#[unstable(feature = "forget_unsized", issue = "none")]
pub fn forget_unsized<T: ?Sized>(t: T) {
    intrinsics::forget(t)
}

/// Inodzorera saizi yerudzi mumabheti.
///
/// Zvikurukuru, ichi ndicho chakakanganiswa mumabheti pakati pezvinhu zvinoteedzana zvakarongeka neiyo mhando yechinhu inosanganisira yekumisikidza padding.
///
/// Nekudaro, kune chero mhando `T` uye kureba `n`, `[T; n]` ine saizi ye `n * size_of::<T>()`.
///
/// Muzhinji, saizi yerudzi haina kugadzikana pamisanganiswa, asi mamwe marudzi akadai sepakutanga ari.
///
/// Iyi tafura inotevera inopa saizi yekutanga.
///
/// Type |saizi_ye: :\<Type>()
/// ---- | ---------------
/// () |0 bool |1 u8 |1 u16 |2 u32 |4 u64 |8 u128 |16 i8 |1 i16 |2 i32 |4 i64 |8 i128 |16 f32 |4 f64 |8 char |4
///
/// Uyezve, `usize` uye `isize` vane saizi yakafanana.
///
/// Iwo marudzi `*const T`, `&T`, `Box<T>`, `Option<&T>`, uye `Option<Box<T>>` ese ane saizi yakafanana.
/// Kana `T` iri Sized, ese aya marudzi ane saizi yakafanana ne `usize`.
///
/// Iko kuchinjika kwechinongedzo hakuchinje saizi yayo.Saka nekudaro, `&T` uye `&mut T` vane saizi yakafanana.
/// Saizvozvowo zve `*const T` uye `* mut T`.
///
/// # Kukura kwezvinhu `#[repr(C)]`
///
/// Iyo `C` inomiririra yezvinhu ine yakatsanangurwa dhizaini.
/// Nemaitiro aya, saizi yezvinhu yakagadzikanawo chero bedzi minda yese ine saizi yakagadzikana.
///
/// ## Kukura kweStructs
///
/// Ye `structs`, saizi inoonekwa neinotevera algorithm.
///
/// Kune yega yega ndima mune yakarongeka nekuzivisa odhiyo:
///
/// 1. Wedzera saizi yemunda.
/// 2. Tenderedza kumusoro saizi yazvino kuenda kune iri padyo yakawanda yeinotevera munda's [alignment].
///
/// Chekupedzisira, tenderedza saizi yedhairekisheni kune iri padyo yakawanda ye [alignment] yayo.
/// Kuenderana kwechimiro kunowanzo kuve kurongeka kukuru kweminda yayo yese;izvi zvinogona kushandurwa nekushandiswa kwe `repr(align(N))`.
///
/// Kusiyana ne `C`, zero saizi structs haina kutenderedzwa kusvika kune imwechete byte muhukuru.
///
/// ## Kukura kweEnum
///
/// Enumamu dzisina dhata kunze kwekusarura dzine saizi yakafanana neC enum papuratifomu yavakarongedzerwa.
///
/// ## Kukura kweMasangano
///
/// Hukuru hwemubatanidzwa hukuru hwenzvimbo yayo hombe.
///
/// Kusiyana ne `C`, zero zero maunion haana kukomberedzwa kusvika kune imwechete byte muhukuru.
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// // Zvimwe zvekutanga
/// assert_eq!(4, mem::size_of::<i32>());
/// assert_eq!(8, mem::size_of::<f64>());
/// assert_eq!(0, mem::size_of::<()>());
///
/// // Dzimwe arrays
/// assert_eq!(8, mem::size_of::<[i32; 2]>());
/// assert_eq!(12, mem::size_of::<[i32; 3]>());
/// assert_eq!(0, mem::size_of::<[i32; 0]>());
///
///
/// // Kukura kwechirevo kuenzana
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<*const i32>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Box<i32>>());
/// assert_eq!(mem::size_of::<&i32>(), mem::size_of::<Option<&i32>>());
/// assert_eq!(mem::size_of::<Box<i32>>(), mem::size_of::<Option<Box<i32>>>());
/// ```
///
/// Uchishandisa `#[repr(C)]`.
///
/// ```
/// use std::mem;
///
/// #[repr(C)]
/// struct FieldStruct {
///     first: u8,
///     second: u16,
///     third: u8
/// }
///
/// // Hukuru hwemunda wekutanga ndi1, saka wedzera 1 pasayizi.Saizi ndeye 1.
/// // Kurongeka kwemunda wechipiri ndewechipiri, saka wedzera 1 kune saizi yepadding.Saizi ndeye 2.
/// // Hukuru hwemunda wechipiri ndi2, saka wedzera 2 pasayizi.Saizi ndeye 4.
/// // Kurongeka kwemunda wechitatu ndi1, saka wedzera 0 kune saizi yepadding.Saizi ndeye 4.
/// // Hukuru hwemunda wechitatu ndi1, saka wedzera 1 pasayizi.Saizi ndeye 5.
/// // Chekupedzisira, kuenderana kwechimiro kuri 2 (nekuti iko kurongeka kukuru pakati peminda yayo iri 2), saka wedzera 1 kuhukuru hwepadding.
/// // Saizi ndeye 6.
/// assert_eq!(6, mem::size_of::<FieldStruct>());
///
/// #[repr(C)]
/// struct TupleStruct(u8, u16, u8);
///
/// // Tuple structs anoteedzera iwo iwo mirawo.
/// assert_eq!(6, mem::size_of::<TupleStruct>());
///
/// // Ziva kuti kuodha zvekare minda kunogona kudzikisa saizi.
/// // Tinogona kubvisa zvese padding mabheti nekuisa `third` pamberi pe `second`.
/// #[repr(C)]
/// struct FieldStructOptimized {
///     first: u8,
///     third: u8,
///     second: u16
/// }
///
/// assert_eq!(4, mem::size_of::<FieldStructOptimized>());
///
/// // Saizi yemubatanidzwa ndiyo saizi yemunda mukurusa.
/// #[repr(C)]
/// union ExampleUnion {
///     smaller: u8,
///     larger: u16
/// }
///
/// assert_eq!(2, mem::size_of::<ExampleUnion>());
/// ```
///
/// [alignment]: align_of
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_size_of", since = "1.32.0")]
pub const fn size_of<T>() -> usize {
    intrinsics::size_of::<T>()
}

/// Inodzorera saizi yeiyo yakanongedzwa-kukosha mu byte.
///
/// Izvi zvinowanzo fanika ne `size_of::<T>()`.
/// Zvisinei, kana `T`*isina* saizi inozivikanwa, semuenzaniso, chidimbu [`[T]`][slice] kana [trait object], ipapo `size_of_val` inogona kushandiswa kuwana saizi ine simba-inozivikanwa.
///
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, mem::size_of_val(y));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
pub const fn size_of_val<T: ?Sized>(val: &T) -> usize {
    // KUCHENGETEKA: `val` inongedzo, saka iri yakajeka mbichana pointer
    unsafe { intrinsics::size_of_val(val) }
}

/// Inodzorera saizi yeiyo yakanongedzwa-kukosha mu byte.
///
/// Izvi zvinowanzo fanika ne `size_of::<T>()`.Nekudaro, kana `T`*isina* saizi-inozivikanwa saizi, semuenzaniso, chidimbu [`[T]`][slice] kana [trait object], ipapo `size_of_val_raw` inogona kushandiswa kuwana saizi ine simba-inozivikanwa.
///
/// # Safety
///
/// Iri basa rakachengeteka chete kudana kana zvinotevera mamiriro abata:
///
/// - Kana `T` iri `Sized`, iri basa rinogara rakachengeteka kudana.
/// - Kana muswe usina kukosheswa we `T` uri:
///     - [slice], ipapo hurefu hwesimbi yemuswe inofanira kunge iri nhamba yekutanga, uye saizi yeiyo *kukosha kwese*(ine simba muswe kureba + chiyero chekutanga) inofanira kukwana mu `isize`.
///     - [trait object], ipapo chikamu chinogadziriswa che pointer chinofanirwa kunongedza kune vtable inoshanda inowana nekusamanikidza kusingazive, uye saizi yeiyo *kukosha kwese*(inesimba muswe kureba + chiyero chekutanga) inofanira kukwana mu `isize`.
///
///     - (unstable) [extern type], zvino basa iri rinogara rakachengeteka kufona, asi may panic kana neimwe nzira idzosere kukosha kusiri iko, sezvo marongero erudzi rwekunze asingazivikanwe.
///     Aya ndiwo maitiro akafanana ne [`size_of_val`] pane chirevo cherudzi nemhando yekunze muswe.
///     - kana zvisina kudaro, zvakachengetedzwa hazvibvumidzwe kudaidza iri basa.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, mem::size_of_val(&5i32));
///
/// let x: [u8; 13] = [0; 13];
/// let y: &[u8] = &x;
/// assert_eq!(13, unsafe { mem::size_of_val_raw(y) });
/// ```
///
///
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_size_of_val_raw", issue = "46571")]
pub const unsafe fn size_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // KUCHENGETEKA: iye anofona anofanira kupa anoshanda mbichana pointer
    unsafe { intrinsics::size_of_val(val) }
}

/// Inodzorera iyo [ABI]-inodikanwa mashoma kuenderana kwerudzi.
///
/// Zvese zvinongedzo kune kukosha kwerudzi `T` zvinofanirwa kuve zvakawandisa zveiyi nhamba.
///
/// Uku ndiko kuenderana kunoshandiswa pakuvaka minda.Inogona kunge iri diki pane yakasarudzika.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of::<i32>());
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of` instead", since = "1.2.0")]
pub fn min_align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Inodzorera iyo [ABI]-inodikanwa mashoma kuenderana kwerudzi rwekukosha iyo `val` inonongedza.
///
/// Zvese zvinongedzo kune kukosha kwerudzi `T` zvinofanirwa kuve zvakawandisa zveiyi nhamba.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// # #![allow(deprecated)]
/// use std::mem;
///
/// assert_eq!(4, mem::min_align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(reason = "use `align_of_val` instead", since = "1.2.0")]
pub fn min_align_of_val<T: ?Sized>(val: &T) -> usize {
    // KUCHENGETEKA: val chirevo, saka iri yakajeka mbichana
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Inodzorera iyo [ABI]-inodikanwa mashoma kuenderana kwerudzi.
///
/// Zvese zvinongedzo kune kukosha kwerudzi `T` zvinofanirwa kuve zvakawandisa zveiyi nhamba.
///
/// Uku ndiko kuenderana kunoshandiswa pakuvaka minda.Inogona kunge iri diki pane yakasarudzika.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of::<i32>());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_align_of", since = "1.32.0")]
pub const fn align_of<T>() -> usize {
    intrinsics::min_align_of::<T>()
}

/// Inodzorera iyo [ABI]-inodikanwa mashoma kuenderana kwerudzi rwekukosha iyo `val` inonongedza.
///
/// Zvese zvinongedzo kune kukosha kwerudzi `T` zvinofanirwa kuve zvakawandisa zveiyi nhamba.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// assert_eq!(4, mem::align_of_val(&5i32));
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
#[allow(deprecated)]
pub const fn align_of_val<T: ?Sized>(val: &T) -> usize {
    // KUCHENGETEKA: val chirevo, saka iri yakajeka mbichana
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Inodzorera iyo [ABI]-inodikanwa mashoma kuenderana kwerudzi rwekukosha iyo `val` inonongedza.
///
/// Zvese zvinongedzo kune kukosha kwerudzi `T` zvinofanirwa kuve zvakawandisa zveiyi nhamba.
///
/// [ABI]: https://en.wikipedia.org/wiki/Application_binary_interface
///
/// # Safety
///
/// Iri basa rakachengeteka chete kudana kana zvinotevera mamiriro abata:
///
/// - Kana `T` iri `Sized`, iri basa rinogara rakachengeteka kudana.
/// - Kana muswe usina kukosheswa we `T` uri:
///     - [slice], ipapo hurefu hwesimbi yemuswe inofanira kunge iri nhamba yekutanga, uye saizi yeiyo *kukosha kwese*(ine simba muswe kureba + chiyero chekutanga) inofanira kukwana mu `isize`.
///     - [trait object], ipapo chikamu chinogadziriswa che pointer chinofanirwa kunongedza kune vtable inoshanda inowana nekusamanikidza kusingazive, uye saizi yeiyo *kukosha kwese*(inesimba muswe kureba + chiyero chekutanga) inofanira kukwana mu `isize`.
///
///     - (unstable) [extern type], zvino basa iri rinogara rakachengeteka kufona, asi may panic kana neimwe nzira idzosere kukosha kusiri iko, sezvo marongero erudzi rwekunze asingazivikanwe.
///     Aya ndiwo maitiro akafanana ne [`align_of_val`] pane chirevo cherudzi nemhando yekunze muswe.
///     - kana zvisina kudaro, zvakachengetedzwa hazvibvumidzwe kudaidza iri basa.
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
/// [extern type]: ../../unstable-book/language-features/extern-types.html
///
/// # Examples
///
/// ```
/// #![feature(layout_for_ptr)]
/// use std::mem;
///
/// assert_eq!(4, unsafe { mem::align_of_val_raw(&5i32) });
/// ```
///
///
///
///
///
///
#[inline]
#[unstable(feature = "layout_for_ptr", issue = "69835")]
#[rustc_const_unstable(feature = "const_align_of_val_raw", issue = "46571")]
pub const unsafe fn align_of_val_raw<T: ?Sized>(val: *const T) -> usize {
    // KUCHENGETEKA: iye anofona anofanira kupa anoshanda mbichana pointer
    unsafe { intrinsics::min_align_of_val(val) }
}

/// Inodzorera `true` kana ichidonhedza tsika dzerudzi `T` nyaya.
///
/// Ichi chingori zano rekuvandudza, uye rinogona kuitiswa zvakachengetedzeka:
/// inogona kudzosa `true` yemhando idzo dzisingade kudonhedzwa.
/// Sezvo zvakadaro kugara uchidzoka `true` kwaizove kuita kwakanaka kweichi chiitiko.Nekudaro kana iri basa richinyatsodzosa `false`, ipapo unogona kuva nechokwadi kudonhedza `T` hakuna mhedzisiro.
///
/// Kudzikisira kwepamusorosoro kwezvinhu zvakaita sekuunganidzwa, izvo zvinofanirwa kudonhedza dhata ravo nemaoko, zvinofanirwa kushandisa basa iri kudzivirira zvisingaite kuyedza kudonhedza zvese zvirimo kana zvaparadzwa.
///
/// Izvi zvinogona kusaita mutsauko mukuburitsa kunovaka (uko chiuno chisina kana mhedzisiro-mhedzisiro chinoonekwa uye kubviswa), asi kazhinji chinokunda muhombe kwekugadzirisa kwekugadzirisa.
///
/// Ziva kuti [`drop_in_place`] yatove kuita cheki iyi, saka kana basa rako rikaderedzwa kusvika kune imwe shoma nhamba ye [`drop_in_place`] mafoni, kushandisa izvi hakuna basa.
/// Kunyanya cherekedza kuti iwe unogona [`drop_in_place`] chidimbu, uye icho chichaita imwe chete inoda_drop yekutarisa kwese kukosha.
///
/// Mhando senge Vec saka ingori `drop_in_place(&mut self[..])` pasina kushandisa `needs_drop` zvakajeka.
/// Mhando senge [`HashMap`], kune rimwe divi, dzinofanirwa kudonhedza tsika imwe panguva uye dzinofanira kushandisa iyi API.
///
/// [`drop_in_place`]: crate::ptr::drop_in_place
/// [`HashMap`]: ../../std/collections/struct.HashMap.html
///
/// # Examples
///
/// Heino muenzaniso wekuti unganidzo ingashandise sei `needs_drop`:
///
/// ```
/// use std::{mem, ptr};
///
/// pub struct MyCollection<T> {
/// #   data: [T; 1],
///     /* ... */
/// }
/// # impl<T> MyCollection<T> {
/// #   fn iter_mut(&mut self) -> &mut [T] { &mut self.data }
/// #   fn free_buffer(&mut self) {}
/// # }
///
/// impl<T> Drop for MyCollection<T> {
///     fn drop(&mut self) {
///         unsafe {
///             // donhedza iyo data
///             if mem::needs_drop::<T>() {
///                 for x in self.iter_mut() {
///                     ptr::drop_in_place(x);
///                 }
///             }
///             self.free_buffer();
///         }
///     }
/// }
/// ```
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "needs_drop", since = "1.21.0")]
#[rustc_const_stable(feature = "const_needs_drop", since = "1.36.0")]
#[rustc_diagnostic_item = "needs_drop"]
pub const fn needs_drop<T>() -> bool {
    intrinsics::needs_drop::<T>()
}

/// Inodzorera kukosha kworudzi `T` inomiririrwa neese-zero byte-pateni.
///
/// Izvi zvinoreva kuti, semuenzaniso, iyo padding byte mu `(u8, u16)` haina hazvo zero zero.
///
/// Iko hakuna vimbiso yekuti iyo yese-zero byte-pateni inomiririra kukosha kweimwe mhando `T`.
/// Semuenzaniso, iyo yose-zero byte-pateni haisi yechokwadi kukosha kwemhando dzemhando (`&T`, `&mut T`) uye zvinongedzo zvemabasa.
/// Kushandisa `zeroed` pamhando dzakadai kunokonzeresa [undefined behavior][ub] nekuti [the Rust compiler assumes][inv] kuti panogara paine kukosha kwakaringana mushanduro yainofunga kuti yakatangwa.
///
///
/// Izvi zvine maitiro akafanana ne [`MaybeUninit::zeroed().assume_init()`][zeroed].
/// Iyo inobatsira kune FFI dzimwe nguva, asi kazhinji inofanirwa kudzivirirwa.
///
/// [zeroed]: MaybeUninit::zeroed
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [inv]: MaybeUninit#initialization-invariant
///
/// # Examples
///
/// Ruramisa kushandiswa kweiri basa: kutanga iyo nhamba ine zero.
///
/// ```
/// use std::mem;
///
/// let x: i32 = unsafe { mem::zeroed() };
/// assert_eq!(0, x);
/// ```
///
/// *Kusaita* kushandiswa kweiri basa: kutanga chirevo ne zero.
///
/// ```rust,no_run
/// # #![allow(invalid_value)]
/// use std::mem;
///
/// let _x: &i32 = unsafe { mem::zeroed() }; // Maitiro asina kujekeswa!
/// let _y: fn() = unsafe { mem::zeroed() }; // Uye zvakare!
/// ```
///
///
///
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_zeroed"]
pub unsafe fn zeroed<T>() -> T {
    // KUCHENGETEKA: iye anofona anofanira kuvimbisa kuti iyo-zero zero kukosha ndeye `T`.
    unsafe {
        intrinsics::assert_zero_valid::<T>();
        MaybeUninit::zeroed().assume_init()
    }
}

/// Bypassass Rust yakajairwa ndangariro-yekutanga cheki nekunyepedzera kuburitsa kukosha kwerudzi `T`, asi pasina chaunoita.
///
/// **Iri basa rakadzikiswa.** Shandisa [`MaybeUninit<T>`] pachinzvimbo.
///
/// Chikonzero chekudzora ndechekuti basa racho harigone kushandiswa nemazvo: rine mhedzisiro yakafanana ne [`MaybeUninit::uninit().assume_init()`][uninit].
///
/// Sekutsanangura kunoita [`assume_init` documentation][assume_init], [the Rust compiler assumes][inv] iyo kukosha kwakatangwa zvakanaka.
/// Semhedzisiro, kufona eg
/// `mem::uninitialized::<bool>()` inokonzeresa kusagadzikana kusaita maitiro ekudzosa `bool` isiri iyo chaiyo ingave `true` kana `false`.
/// Zvakaipisisa, zvechokwadi isina kuvhurwa ndangariro senge inodzoserwa pano yakakosha pakuti iyo compiler inoziva kuti haina kukosha kwakatarwa.
/// Izvi zvinoita kuti ive isina kujekeswa maitiro kuve neinina yekutanga data mune musiyano kunyangwe iyo musiyano iine huwandu hwakazara.
/// (Cherekedza kuti iyo mitemo yakatenderedza isina kuvhurwa manhamba haisati yapera, asi kusvika paari, zvinokurudzirwa kuti urege iyo.)
///
/// [uninit]: MaybeUninit::uninit
/// [assume_init]: MaybeUninit::assume_init
/// [inv]: MaybeUninit#initialization-invariant
///
///
///
///
///
#[inline(always)]
#[rustc_deprecated(since = "1.39.0", reason = "use `mem::MaybeUninit` instead")]
#[stable(feature = "rust1", since = "1.0.0")]
#[allow(deprecated_in_future)]
#[allow(deprecated)]
#[rustc_diagnostic_item = "mem_uninitialized"]
pub unsafe fn uninitialized<T>() -> T {
    // KUCHENGETEKA: iye anofona anofanira kuvimbisa kuti kukosha kwekutanga hakuna kukodzera kwe `T`.
    unsafe {
        intrinsics::assert_uninit_valid::<T>();
        MaybeUninit::uninit().assume_init()
    }
}

/// Chinja hunhu panzvimbo mbiri dzinogona kuchinjika, pasina kubvisa imwe yacho.
///
/// * Kana iwe uchida kuchinjanisa ine default kana dummy kukosha, ona [`take`].
/// * Kana iwe uchida kuchinjisa neiyo yakapfuura kukosha, kudzorera iyo yekare kukosha, ona [`replace`].
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// let mut x = 5;
/// let mut y = 42;
///
/// mem::swap(&mut x, &mut y);
///
/// assert_eq!(42, x);
/// assert_eq!(5, y);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn swap<T>(x: &mut T, y: &mut T) {
    // KUNYENGETEKA: anonongedzera mbishi akagadzirwa kubva kune zvakachengeteka zvinongedzo mareferenzi zvinogutsa zvese
    // zvipingamupinyi pa `ptr::swap_nonoverlapping_one`
    unsafe {
        ptr::swap_nonoverlapping_one(x, y);
    }
}

/// Inotsiva `dest` neiyo default kukosha ye `T`, ichidzorera iyo yapfuura `dest` kukosha.
///
/// * Kana iwe uchida kutsiva kukosha kwemaviri akasiyana, ona [`swap`].
/// * Kana iwe uchida kutsiva neakapasa kukosha panzvimbo peiyo default kukosha, ona [`replace`].
///
/// # Examples
///
/// Muenzaniso wakapusa:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::take(&mut v);
/// assert_eq!(vec![1, 2], old_v);
/// assert!(v.is_empty());
/// ```
///
/// `take` inobvumira kutora muridzi weyakavakwa munda nekuitsiva neiyo "empty" kukosha.
/// Pasina `take` unogona kumhanyisa muzvinhu zvakaita seizvi:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let buf = self.buf;
///         self.buf = Vec::new();
///         buf
///     }
/// }
/// ```
///
/// Ziva kuti `T` haidi kuti ishandise [`Clone`], saka haigone kana kuumbana nekumisazve `self.buf`.
/// Asi `take` inogona kushandiswa kusasanisa kukosha kwepakutanga kwe `self.buf` kubva ku `self`, ichibvumira kuti idzorerwe:
///
///
/// ```
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn get_and_reset(&mut self) -> Vec<T> {
///         mem::take(&mut self.buf)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf.len(), 2);
///
/// assert_eq!(buffer.get_and_reset(), vec![0, 1]);
/// assert_eq!(buffer.buf.len(), 0);
/// ```
#[inline]
#[stable(feature = "mem_take", since = "1.40.0")]
pub fn take<T: Default>(dest: &mut T) -> T {
    replace(dest, T::default())
}

/// Inofambisa `src` mune yakataurwa `dest`, ichidzorera iyo yapfuura `dest` kukosha.
///
/// Hapana kukosha kwakadonhedzwa.
///
/// * Kana iwe uchida kutsiva kukosha kwemaviri akasiyana, ona [`swap`].
/// * Kana iwe uchida kutsiva neiyo default kukosha, ona [`take`].
///
/// # Examples
///
/// Muenzaniso wakapusa:
///
/// ```
/// use std::mem;
///
/// let mut v: Vec<i32> = vec![1, 2];
///
/// let old_v = mem::replace(&mut v, vec![3, 4, 5]);
/// assert_eq!(vec![1, 2], old_v);
/// assert_eq!(vec![3, 4, 5], v);
/// ```
///
/// `replace` inobvumira kudyiwa kwesimba rekumisikidza nekuitsiva neimwe kukosha.
/// Pasina `replace` unogona kumhanyisa muzvinhu zvakaita seizvi:
///
/// ```compile_fail,E0507
/// struct Buffer<T> { buf: Vec<T> }
///
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         // error: cannot move out of dereference of `&mut`-pointer
///         let t = self.buf[i];
///         self.buf[i] = v;
///         t
///     }
/// }
/// ```
///
/// Ziva kuti `T` hainyatso kushandisa [`Clone`], saka isu hatigone kana kuumbiridza `self.buf[i]` kudzivirira kufamba.
/// Asi `replace` inogona kushandiswa kusanganisa kukosha kwepakutanga pane iyo index kubva ku `self`, ichibvumira kuti idzorerwe:
///
///
/// ```
/// # #![allow(dead_code)]
/// use std::mem;
///
/// # struct Buffer<T> { buf: Vec<T> }
/// impl<T> Buffer<T> {
///     fn replace_index(&mut self, i: usize, v: T) -> T {
///         mem::replace(&mut self.buf[i], v)
///     }
/// }
///
/// let mut buffer = Buffer { buf: vec![0, 1] };
/// assert_eq!(buffer.buf[0], 0);
///
/// assert_eq!(buffer.replace_index(0, 2), 0);
/// assert_eq!(buffer.buf[0], 2);
/// ```
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[must_use = "if you don't need the old value, you can just assign the new value directly"]
pub fn replace<T>(dest: &mut T, src: T) -> T {
    // Kachengeteka: Tinoverenga kubva ku `dest` asi tinyore zvakananga `src` mairi mumashure,
    // zvakadai kuti kukosha kwekare hakuwedzerwi.
    // Hapana chakadonhedzwa uye hapana chinhu apa chinogona panic.
    unsafe {
        let result = ptr::read(dest);
        ptr::write(dest, src);
        result
    }
}

/// Inoburitsa kukosha.
///
/// Izvi zvinoita nekudana kuita kwekupokana kwe [`Drop`][drop].
///
/// Izvi zvinobudirira hazviite chero mhando dzinoita `Copy`, semuenzaniso
/// integers.
/// Hunhu hwakadai hunoteedzerwa uye _then_ inoendeswa mukuita basa, saka kukosha kwacho kunopfuurira mushure mekufona kwebasa iri.
///
///
/// Iri basa harisi mashiripiti;iyo inotsanangurwa chaizvo se
///
/// ```
/// pub fn drop<T>(_x: T) { }
/// ```
///
/// Nekuti `_x` inofambiswa ichiita basa, rinobva radonhedzwa basa risati radzoka.
///
/// [drop]: Drop
///
/// # Examples
///
/// Kushandiswa kwekutanga:
///
/// ```
/// let v = vec![1, 2, 3];
///
/// drop(v); // nyatsodonhedza vector
/// ```
///
/// Sezvo [`RefCell`] inosimbisa iyo inokwereta mitemo panguva yekumhanya, `drop` inogona kuburitsa [`RefCell`] inokwereta:
///
/// ```
/// use std::cell::RefCell;
///
/// let x = RefCell::new(1);
///
/// let mut mutable_borrow = x.borrow_mut();
/// *mutable_borrow = 1;
///
/// drop(mutable_borrow); // regedza chinoshandurwa chinokweretwa pane ino slot
///
/// let borrow = x.borrow();
/// println!("{}", *borrow);
/// ```
///
/// MaNeger uye mamwe marudzi anoshandisa [`Copy`] haana kukanganiswa ne `drop`.
///
/// ```
/// #[derive(Copy, Clone)]
/// struct Foo(u8);
///
/// let x = 1;
/// let y = Foo(2);
/// drop(x); // kopi ye `x` inofambiswa uye inodonhedzwa
/// drop(y); // kopi ye `y` inofambiswa uye inodonhedzwa
///
/// println!("x: {}, y: {}", x, y.0); // ichiripo
/// ```
///
/// [`RefCell`]: crate::cell::RefCell
///
#[doc(alias = "delete")]
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn drop<T>(_x: T) {}

/// Rinodudzira `src` senge ine mhando `&U`, uye yozoverenga `src` isina kufambisa iyo yakakosha kukosha.
///
/// Iri basa rinofungidzira zvisina tsarukano kuti pointer `src` inoshanda kune [`size_of::<U>`][size_of] mabheti nekutepfenyura `&T` kuenda ku `&U` uyezve kuverenga iyo `&U` (kunze kwekuti izvi zvinoitwa nenzira chaiyo kunyangwe `&U` ichiita zvinonamira kuenderana kupfuura `&T`).
/// Izvo zvakare zvichaita zvisina kugadzikana kopi yeiyo yaivepo kukosha panzvimbo yekubuda kunze kwe `src`.
///
/// Haisi yekukanganisa-nguva kukanganisa kana `T` uye `U` vane saizi dzakasiyana, asi zvinokurudzirwa zvikuru kungoitisa iri basa apo `T` ne `U` vane saizi yakafanana.Iri basa rinokonzeresa [undefined behavior][ub] kana `U` yakakura kudarika `T`.
///
/// [ub]: ../../reference/behavior-considered-undefined.html
///
/// # Examples
///
/// ```
/// use std::mem;
///
/// #[repr(packed)]
/// struct Foo {
///     bar: u8,
/// }
///
/// let foo_array = [10u8];
///
/// unsafe {
///     // Kopa iyo data kubva ku 'foo_array' uye ubate se 'Foo'
///     let mut foo_struct: Foo = mem::transmute_copy(&foo_array);
///     assert_eq!(foo_struct.bar, 10);
///
///     // Chinja iyo yakakopwa data
///     foo_struct.bar = 20;
///     assert_eq!(foo_struct.bar, 20);
/// }
///
/// // Zviri mukati me 'foo_array' hazvifanirwe kunge zvachinja
/// assert_eq!(foo_array, [10]);
/// ```
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_transmute_copy", issue = "83165")]
pub const unsafe fn transmute_copy<T, U>(src: &T) -> U {
    // Kana U uine chinongedzo chepamusoro chakaringana, src inogona kunge isina kunyatsoenderana.
    if align_of::<U>() > align_of::<T>() {
        // Kachengeteka: `src` chirevo icho chinovimbiswa kuve chinoshanda pakuverenga.
        // Anofona anofanira kuvimbisa kuti iyo chaiyo transmutation yakachengeteka.
        unsafe { ptr::read_unaligned(src as *const T as *const U) }
    } else {
        // Kachengeteka: `src` chirevo icho chinovimbiswa kuve chinoshanda pakuverenga.
        // Isu takangotarisa kuti `src as *const U` yakanga yakanyatsoenderana.
        // Anofona anofanira kuvimbisa kuti iyo chaiyo transmutation yakachengeteka.
        unsafe { ptr::read(src as *const T as *const U) }
    }
}

/// Opaque mhando inomiririra kusarura kweiyo enum.
///
/// Ona iyo [`discriminant`] inoshanda mune ino module kuti uwane rumwe ruzivo.
#[stable(feature = "discriminant_value", since = "1.21.0")]
pub struct Discriminant<T>(<T as DiscriminantKind>::Discriminant);

// N.B. Aya maitiro e trait haagone kutorwa nekuti hatidi chero miganhu paT.

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> Copy for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> clone::Clone for Discriminant<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::PartialEq for Discriminant<T> {
    fn eq(&self, rhs: &Self) -> bool {
        self.0 == rhs.0
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> cmp::Eq for Discriminant<T> {}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> hash::Hash for Discriminant<T> {
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.0.hash(state);
    }
}

#[stable(feature = "discriminant_value", since = "1.21.0")]
impl<T> fmt::Debug for Discriminant<T> {
    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_tuple("Discriminant").field(&self.0).finish()
    }
}

/// Inodzorera kukosha kwakasarudzika kuratidza iyo enum musiyano mu `v`.
///
/// Kana `T` isiri enum, kudaidza iri basa hakuzokonzere kuita kusanzwisisika maitiro, asi kukosha kwekudzoka hakuna kuzivikanwa.
///
///
/// # Stability
///
/// Kusarura kweiyo enum kusiyanisa kunogona kuchinja kana iyo enum tsananguro ikachinja.
/// Kusarura kweimwe misiyano hakuzoshanduke pakati pemisanganiswa pamwe chete neyekuumba.
///
/// # Examples
///
/// Izvi zvinogona kushandiswa kuenzanisa enums inotakura data, uku uchizvidza iyo chaiyo data:
///
/// ```
/// use std::mem;
///
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::discriminant(&Foo::A("bar")), mem::discriminant(&Foo::A("baz")));
/// assert_eq!(mem::discriminant(&Foo::B(1)), mem::discriminant(&Foo::B(2)));
/// assert_ne!(mem::discriminant(&Foo::B(3)), mem::discriminant(&Foo::C(3)));
/// ```
///
#[stable(feature = "discriminant_value", since = "1.21.0")]
#[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
pub const fn discriminant<T>(v: &T) -> Discriminant<T> {
    Discriminant(intrinsics::discriminant_value(v))
}

/// Inodzorera iyo nhamba yezvakasiyana muiyo enum mhando `T`.
///
/// Kana `T` isiri enum, kudaidza iri basa hakuzokonzere kuita kusanzwisisika maitiro, asi kukosha kwekudzoka hakuna kuzivikanwa.
/// Zvakaenzana, kana `T` iri enum ine zvakawanda zvakasiyana kupfuura `usize::MAX` kukosha kwekudzoka hakuna kuzivikanwa.
/// Misiyano isingagarwe ichaverengerwa.
///
/// # Examples
///
/// ```
/// # #![feature(never_type)]
/// # #![feature(variant_count)]
///
/// use std::mem;
///
/// enum Void {}
/// enum Foo { A(&'static str), B(i32), C(i32) }
///
/// assert_eq!(mem::variant_count::<Void>(), 0);
/// assert_eq!(mem::variant_count::<Foo>(), 3);
///
/// assert_eq!(mem::variant_count::<Option<!>>(), 2);
/// assert_eq!(mem::variant_count::<Result<!, !>>(), 2);
/// ```
#[inline(always)]
#[unstable(feature = "variant_count", issue = "73662")]
#[rustc_const_unstable(feature = "variant_count", issue = "73662")]
pub const fn variant_count<T>() -> usize {
    intrinsics::variant_count::<T>()
}