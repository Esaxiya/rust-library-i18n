//! Iyo libcore prelude
//!
//! Iyi module inoitirwa vashandisi ve libcore iyo isingabatanidzi ne libstd futi.
//! Iyi module inopinzwa nekumisikidza kana `#![no_std]` ichishandiswa nenzira imwecheteyo seyakajairika raibhurari ye prelude.
//!

#![stable(feature = "core_prelude", since = "1.4.0")]

pub mod v1;

/// Iyo 2015 vhezheni yeiyo yepakati prelude.
///
/// Ona [module-level documentation](self) zvimwe.
#[unstable(feature = "prelude_2015", issue = "none")]
pub mod rust_2015 {
    #[unstable(feature = "prelude_2015", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Iyo 2018 vhezheni yeiyo yepakati prelude.
///
/// Ona [module-level documentation](self) zvimwe.
#[unstable(feature = "prelude_2018", issue = "none")]
pub mod rust_2018 {
    #[unstable(feature = "prelude_2018", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;
}

/// Iyo 2021 vhezheni yeiyo yepakati prelude.
///
/// Ona [module-level documentation](self) zvimwe.
#[unstable(feature = "prelude_2021", issue = "none")]
pub mod rust_2021 {
    #[unstable(feature = "prelude_2021", issue = "none")]
    #[doc(no_inline)]
    pub use super::v1::*;

    // FIXME: Wedzera zvimwe zvinhu.
}