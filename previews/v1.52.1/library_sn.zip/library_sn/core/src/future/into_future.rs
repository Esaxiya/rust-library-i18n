use crate::future::Future;

/// Shanduko kuita `Future`.
#[unstable(feature = "into_future", issue = "67644")]
pub trait IntoFuture {
    /// Zvinobuda izvo future ichagadzira kana yapera.
    #[unstable(feature = "into_future", issue = "67644")]
    type Output;

    /// Nderupi z0future0Z ratiri kuchinja kuita ichi?
    #[unstable(feature = "into_future", issue = "67644")]
    type Future: Future<Output = Self::Output>;

    /// Inogadzira future Kubva pane kukosha.
    #[unstable(feature = "into_future", issue = "67644")]
    fn into_future(self) -> Self::Future;
}

#[unstable(feature = "into_future", issue = "67644")]
impl<F: Future> IntoFuture for F {
    type Output = F::Output;
    type Future = F;

    fn into_future(self) -> Self::Future {
        self
    }
}