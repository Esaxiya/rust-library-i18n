#![stable(feature = "futures_api", since = "1.36.0")]

use crate::marker::Unpin;
use crate::ops;
use crate::pin::Pin;
use crate::task::{Context, Poll};

/// future inomiririra kuverenga kwakanyanyisa.
///
/// future kukosha uko kungave kusati kwapedza komputa izvozvi.
/// Rudzi urwu rwe "asynchronous value" runoita kuti zvive nyore kuti tambo irambe ichiita basa rinobatsira ichimirira kukosha kwayo kuti iwanikwe.
///
///
/// # Iyo `poll` nzira
///
/// Maitiro epakati e future, `poll`,*kuyedza* kugadzirisa future kuita kukosha kwekupedzisira.
/// Iyi nzira haivharire kana kukosha kwacho kusati kwagadzirira.
/// Pane kudaro, iro razvino basa rakarongerwa kumutswa kana zvichikwanisika kuita kumberi kufambira mberi ne` polling zvakare.
/// `context` yakapfuudza nzira ye `poll` inogona kupa [`Waker`], inova mubato wekumutsa basa razvino.
///
/// Paunenge uchishandisa future, haugone kufonera `poll` zvakananga, asi pachinzvimbo `.await` kukosha.
///
/// [`Waker`]: crate::task::Waker
///
///
///
#[doc(spotlight)]
#[must_use = "futures do nothing unless you `.await` or poll them"]
#[stable(feature = "futures_api", since = "1.36.0")]
#[lang = "future_trait"]
#[rustc_on_unimplemented(label = "`{Self}` is not a future", message = "`{Self}` is not a future")]
pub trait Future {
    /// Rudzi rwekukosha rwakagadzirwa pakupera.
    #[stable(feature = "futures_api", since = "1.36.0")]
    type Output;

    /// Kuedza kugadzirisa iyo future kune kukosha kwekupedzisira, kunyoresa iro razvino basa rekumutsa kana kukosha kwacho kusati kwavapo.
    ///
    /// # Dzorera kukosha
    ///
    /// Iri basa rinodzoka:
    ///
    /// - [`Poll::Pending`] kana iyo future isati yagadzirira izvozvi
    /// - [`Poll::Ready(val)`] nemhedzisiro `val` yeiyi future kana yapedza kubudirira.
    ///
    /// Kana future yapedza, vatengi havafanirwe `poll` zvakare.
    ///
    /// Kana future isati yagadzirira, `poll` inodzosera `Poll::Pending` uye inochengeta dombo re [`Waker`] rakateedzerwa kubva ku [`Context`] yazvino.
    /// Iyi [`Waker`] inozomutswa kana future yagona kufambira mberi.
    /// Semuenzaniso, future yakamirira socket kuti iverenge inogona kudaidza `.clone()` pane [`Waker`] uye ichengete.
    /// Kana chiratidzo chikasvika kumwe kunoratidza kuti socket inogona kuverenga, [`Waker::wake`] inodaidzwa uye iyo socket future basa rinomutswa.
    /// Kamwe basa paramutswa, rinofanira kuedza ku `poll` iyo future zvakare, iyo inogona kana isingakwanise kuburitsa kukosha kwekupedzisira.
    ///
    /// Ziva kuti pane dzakawanda kufona kuenda ku `poll`, chete [`Waker`] kubva ku [`Context`] yakapfuudza kune ichangoburwa kufona ndiyo inofanirwa kurongwa kuti iwane kumuka.
    ///
    /// # Nguva yekumhanya
    ///
    /// Futures chete ndeye *inert*;ivo vanofanirwa kuve *vanoshingairira* vakavhoterwa kuti vafambire mberi, zvichireva kuti nguva yega yega basa razvino parinomutswa, rinofanira kushingairira-kuvhota richimirira futures iyo ichiri kufarira.
    ///
    /// Basa re `poll` haridanwe rakadzokororwa muchiuno chakasimba-pachinzvimbo, rinongodaidzwa chete apo future inoratidza kuti yakagadzirira kufambira mberi (nekudana `wake()`).
    /// Kana iwe uchizivana ne `poll(2)` kana `select(2)` syscalls pa Unix zvakakosha kuti uzive kuti futures kazhinji haina *kwete* kutambura matambudziko akafanana e "all wakeups must poll all events";ivo vakaita kunge `epoll(4)`.
    ///
    /// Kuitwa kwe `poll` kunofanirwa kushandira kudzoka nekukurumidza, uye hakufanirwe kuvharira.Kudzoka nekukurumidza kunodzivirira zvisina kufanira kuvhara tambo kana zvishwe zvechiitiko.
    /// Kana zvichizivikanwa pamberi penguva kuti kufona ku `poll` kunogona kupedzisira kutora chinguva, iro basa rinofanira kuburitswa kudziva reshinda (kana chimwe chinhu chakafanana) kuona kuti `poll` inogona kudzoka nekukurumidza.
    ///
    /// # Panics
    ///
    /// Kana future yapedza (yadzosera `Ready` kubva ku `poll`), ichidaidza nzira yayo ye `poll` zvakare inogona panic, kuvharira zvachose, kana kukonzera mamwe marudzi ematambudziko;iyo `Future` trait inoisa hapana zvinodikanwa pamhedzisiro yekufona kwakadai.
    /// Nekudaro, sezvo nzira ye `poll` isina kumakidzwa `unsafe`, Rust yakajairwa mitemo inoshanda: mafoni haafanire kukonzera kusanzwisisika maitiro (ndangariro huwori, kushandiswa zvisirizvo kwe `unsafe` mabasa, kana zvimwe zvakadaro), zvisinei ne future mamiriro.
    ///
    ///
    /// [`Poll::Ready(val)`]: Poll::Ready
    /// [`Waker`]: crate::task::Waker
    /// [`Waker::wake`]: crate::task::Waker::wake
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "poll"]
    #[stable(feature = "futures_api", since = "1.36.0")]
    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output>;
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin> Future for &mut F {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut **self), cx)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<P> Future for Pin<P>
where
    P: Unpin + ops::DerefMut<Target: Future>,
{
    type Output = <<P as ops::Deref>::Target as Future>::Output;

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        Pin::get_mut(self).as_mut().poll(cx)
    }
}