#![stable(feature = "", since = "1.30.0")]
#![allow(non_camel_case_types)]

//! Zvishandiso zvine chekuita nekunze basa interface (FFI) zvisungo.

use crate::fmt;
use crate::marker::PhantomData;
use crate::ops::{Deref, DerefMut};

/// Zvakaenzana neC's `void` mhando painoshandiswa se [pointer].
///
/// Mukukosha, `*const c_void` yakaenzana neC's `const void*` uye `*mut c_void` yakaenzana neC's `void*`.
/// Izvo zvakati, izvi *hazvisi* zvakafanana neC's `void` yekudzosa mhando, iri Rust's `()` mhando.
///
/// To modelling pointers kune opaque mhando muFFI, kudzamara `extern type` yasimbiswa, zvinokurudzirwa kushandisa newtype inoputira yakatenderedza isina chinhu mabheti akarongeka.
///
/// Ona iyo [Nomicon] kuti uwane rumwe ruzivo.
///
/// Mumwe anogona kushandisa `std::os::raw::c_void` kana vachida kutsigira yekare Rust compiler pasi kusvika 1.1.0.
/// Mushure me Rust 1.30.0, yakatumiswazve kunze nedudziro iyi.
/// Kuti uwane rumwe ruzivo, ndapota verenga [RFC 2521].
///
/// [Nomicon]: https://doc.rust-lang.org/nomicon/ffi.html#representing-opaque-structs
/// [RFC 2521]: https://github.com/rust-lang/rfcs/blob/master/text/2521-c_void-reunification.md
///
// NB, yeLLVM kuti ione iyo void pointer mhando uye nekuwedzera mabasa senge malloc(), isu tinofanirwa kuve nayo inomiririrwa se i8 * muLLVM bitcode.
// Iyo enum inoshandiswa pano inovimbisa izvi uye inodzivirira kushandiswa zvisirizvo kworudzi rwe "raw" nekungova neakavanzika akasiyana.
// Tinoda misiyano miviri, nekuti muunganidzi anonyunyuta nezvehunhu hwe repr neimwe nzira uye isu tinoda imwe chete musiyano senge iyo enum ingadai isingagarwe uye pamwe ichiratidzira zvinongedzo zvakadaro ichave UB.
//
//
//
//
//
#[repr(u8)]
#[stable(feature = "core_c_void", since = "1.30.0")]
pub enum c_void {
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant1,
    #[unstable(
        feature = "c_void_variant",
        reason = "temporary implementation detail",
        issue = "none"
    )]
    #[doc(hidden)]
    __variant2,
}

#[stable(feature = "std_debug", since = "1.16.0")]
impl fmt::Debug for c_void {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.pad("c_void")
    }
}

/// Yekutanga kuitiswa kwe `va_list`.
// Zita racho ndiWIP, uchishandisa `VaListImpl` ikozvino.
#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[repr(transparent)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    ptr: *mut c_void,

    // Invariant pamusoro pe `'f`, saka chimwe nechimwe chinhu che `VaListImpl<'f>` chakasungirirwa kudunhu rebasa iro raanotsanangurwa mariri
    //
    _marker: PhantomData<&'f mut &'f c_void>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> fmt::Debug for VaListImpl<'f> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "va_list* {:p}", self.ptr)
    }
}

/// AArch64 Kuitwa kweABI kwe `va_list`.
/// Ona iyo [AArch64 Procedure Call Standard] kuti uwane rumwe ruzivo.
///
/// [AArch64 Procedure Call Standard]:
/// http://infocenter.arm.com/help/topic/com.arm.doc.ihi0055b/IHI0055B_aapcs64.pdf
#[cfg(all(
    target_arch = "aarch64",
    not(any(target_os = "macos", target_os = "ios")),
    not(windows)
))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    stack: *mut c_void,
    gr_top: *mut c_void,
    vr_top: *mut c_void,
    gr_offs: i32,
    vr_offs: i32,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// PowerPC Kuitwa kweABI kwe `va_list`.
#[cfg(all(target_arch = "powerpc", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gpr: u8,
    fpr: u8,
    reserved: u16,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// x86_64 Kuitwa kweABI kwe `va_list`.
#[cfg(all(target_arch = "x86_64", not(windows)))]
#[repr(C)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
#[lang = "va_list"]
pub struct VaListImpl<'f> {
    gp_offset: i32,
    fp_offset: i32,
    overflow_arg_area: *mut c_void,
    reg_save_area: *mut c_void,
    _marker: PhantomData<&'f mut &'f c_void>,
}

/// Yakaputirwa ye `va_list`
#[repr(transparent)]
#[derive(Debug)]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
pub struct VaList<'a, 'f: 'a> {
    #[cfg(any(
        all(
            not(target_arch = "aarch64"),
            not(target_arch = "powerpc"),
            not(target_arch = "x86_64")
        ),
        all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
        target_arch = "wasm32",
        target_arch = "asmjs",
        windows
    ))]
    inner: VaListImpl<'f>,

    #[cfg(all(
        any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
        any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
        not(target_arch = "wasm32"),
        not(target_arch = "asmjs"),
        not(windows)
    ))]
    inner: &'a mut VaListImpl<'f>,

    _marker: PhantomData<&'a mut VaListImpl<'f>>,
}

#[cfg(any(
    all(not(target_arch = "aarch64"), not(target_arch = "powerpc"), not(target_arch = "x86_64")),
    all(target_arch = "aarch64", any(target_os = "macos", target_os = "ios")),
    target_arch = "wasm32",
    target_arch = "asmjs",
    windows
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Chinja `VaListImpl` ive `VaList` inova binary-inoenderana neC's `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: VaListImpl { ..*self }, _marker: PhantomData }
    }
}

#[cfg(all(
    any(target_arch = "aarch64", target_arch = "powerpc", target_arch = "x86_64"),
    any(not(target_arch = "aarch64"), not(any(target_os = "macos", target_os = "ios"))),
    not(target_arch = "wasm32"),
    not(target_arch = "asmjs"),
    not(windows)
))]
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Chinja `VaListImpl` ive `VaList` inova binary-inoenderana neC's `va_list`.
    #[inline]
    pub fn as_va_list<'a>(&'a mut self) -> VaList<'a, 'f> {
        VaList { inner: self, _marker: PhantomData }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> Deref for VaList<'a, 'f> {
    type Target = VaListImpl<'f>;

    #[inline]
    fn deref(&self) -> &VaListImpl<'f> {
        &self.inner
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'a, 'f: 'a> DerefMut for VaList<'a, 'f> {
    #[inline]
    fn deref_mut(&mut self) -> &mut VaListImpl<'f> {
        &mut self.inner
    }
}

// VaArgSafe trait inoda kushandiswa munzvimbo dzeveruzhinji, zvisinei, iyo trait pachayo haifanire kubvumidzwa kushandiswa kunze kwemo module.
// Kubvumira vashandisi kuti vashandise iyo trait yerudzi nyowani (nokudaro vachibvumira iyo va_arg yemukati kuti ishandiswe pane imwe mhando nyowani) inogona kukonzera undefined maitiro.
//
// FIXME(dlrobertson): Kuti ushandise VaArgSafe trait mune yeruzhinji interface uye zvakare uve nechokwadi kuti haigone kushandiswa kumwe kunhu, iyo trait inoda kuve yeruzhinji mukati meyakavanzika module.
// Kana RFC 2145 yaitwa chete tarisa mukuvandudza izvi.
//
//
//
//
mod sealed_trait {
    /// Trait iyo inobvumidza iyo inobvumirwa mhando kuti ishandiswe ne [super::VaListImpl::arg].
    #[unstable(
        feature = "c_variadic",
        reason = "the `c_variadic` feature has not been properly tested on \
                  all supported platforms",
        issue = "44930"
    )]
    pub trait VaArgSafe {}
}

macro_rules! impl_va_arg_safe {
    ($($t:ty),+) => {
        $(
            #[unstable(feature = "c_variadic",
                       reason = "the `c_variadic` feature has not been properly tested on \
                                 all supported platforms",
                       issue = "44930")]
            impl sealed_trait::VaArgSafe for $t {}
        )+
    }
}

impl_va_arg_safe! {i8, i16, i32, i64, usize}
impl_va_arg_safe! {u8, u16, u32, u64, isize}
impl_va_arg_safe! {f64}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *mut T {}
#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<T> sealed_trait::VaArgSafe for *const T {}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> VaListImpl<'f> {
    /// Tungamira kune inotevera arg.
    #[inline]
    pub unsafe fn arg<T: sealed_trait::VaArgSafe>(&mut self) -> T {
        // KUCHENGETEKA: iye anodana anofanirwa kuchengetedza chibvumirano chekuchengetedza che `va_arg`.
        unsafe { va_arg(self) }
    }

    /// Kopa iyo `va_list` panzvimbo iripo.
    pub unsafe fn with_copy<F, R>(&self, f: F) -> R
    where
        F: for<'copy> FnOnce(VaList<'copy, 'f>) -> R,
    {
        let mut ap = self.clone();
        let ret = f(ap.as_va_list());
        // KUCHENGETEKA: iye anodana anofanirwa kuchengetedza chibvumirano chekuchengetedza che `va_end`.
        unsafe {
            va_end(&mut ap);
        }
        ret
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Clone for VaListImpl<'f> {
    #[inline]
    fn clone(&self) -> Self {
        let mut dest = crate::mem::MaybeUninit::uninit();
        // Kachengeteka: tinonyorera ku `MaybeUninit`, saka inotangwa uye `assume_init` zviri pamutemo
        unsafe {
            va_copy(dest.as_mut_ptr(), self);
            dest.assume_init()
        }
    }
}

#[unstable(
    feature = "c_variadic",
    reason = "the `c_variadic` feature has not been properly tested on \
              all supported platforms",
    issue = "44930"
)]
impl<'f> Drop for VaListImpl<'f> {
    fn drop(&mut self) {
        // FIXME: izvi zvinofanirwa kudaidza `va_end`, asi hapana nzira yakachena yeku
        // vimbisa kuti `drop` inogara ichinamira mukati mayo yaanodana, saka iyo `va_end` yaizodaidzwa yakanangana kubva kune imwechete basa seiyo inoenderana `va_copy`.
        // `man va_end` inotaura kuti C inoda izvi, uye LLVM inoteedzera iyo C semantics, saka tinofanirwa kuona kuti `va_end` inogara ichidanwa kubva kune imwechete basa se `va_copy`.
        //
        // Kuti uwane rumwe ruzivo, see https://github.com/rust-lang/rust/pull/59625andhttps://llvm.org/docs/LangRef.html#llvm-va-end-intrinsic.
        //
        // Izvi zvinoshanda izvozvi, sezvo `va_end` isiri-op pane ese aripo LLVM zvinangwa.
        //
        //
        //
    }
}

extern "rust-intrinsic" {
    /// Paradza rondedzero `ap` mushure mekutanga ne `va_start` kana `va_copy`.
    ///
    fn va_end(ap: &mut VaListImpl<'_>);

    /// Kopa iyo iripo nzvimbo yeArglist `src` kune iyo arglist `dst`.
    fn va_copy<'f>(dest: *mut VaListImpl<'f>, src: &VaListImpl<'f>);

    /// Inotakura nharo dzerudzi `T` kubva ku `va_list` `ap` uye ichiwedzera nharo `ap` kunongedzera ku.
    ///
    fn va_arg<T: sealed_trait::VaArgSafe>(ap: &mut VaListImpl<'_>) -> T;
}