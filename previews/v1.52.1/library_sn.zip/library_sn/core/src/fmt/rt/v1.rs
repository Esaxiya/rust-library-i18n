//! Iyi module yemukati inoshandiswa neiyo ifmt!nguva yekumhanya.Izvi zvivakwa zvinoburitswa kune zvimisikidzo zvakarongeka kuti zvifananidze fomati tambo pamberi penguva.
//!
//! Idzi tsananguro dzakafanana nedzadzo `ct` dzakaenzana, asi dzakasiyana pakuti idzi dzinogona kuve dzakagoverwa uye dzakagadziridzwa zvishoma kwenguva yekumhanya.
//!
//!
#![allow(missing_debug_implementations)]

#[derive(Copy, Clone)]
pub struct Argument {
    pub position: usize,
    pub format: FormatSpec,
}

#[derive(Copy, Clone)]
pub struct FormatSpec {
    pub fill: char,
    pub align: Alignment,
    pub flags: u32,
    pub precision: Count,
    pub width: Count,
}

/// Zvinogoneka kuenderana izvo zvinogona kukumbirwa sechikamu chemafomati fomati.
#[derive(Copy, Clone, PartialEq, Eq)]
pub enum Alignment {
    /// Zvinoratidza kuti zvirimo zvinofanirwa kusiiwa-kuruboshwe.
    Left,
    /// Zvinoratidza kuti zvirimo zvinofanirwa kunge zvakanyatsoenderana.
    Right,
    /// Zvinoratidza kuti zvirimo zvinofanirwa kunge zvakanangana nepakati.
    Center,
    /// Hapana kuenderana kwakakumbirwa.
    Unknown,
}

/// Inoshandiswa ne [width](https://doc.rust-lang.org/std/fmt/#width) uye [precision](https://doc.rust-lang.org/std/fmt/#precision) zvinotsanangudza.
#[derive(Copy, Clone)]
pub enum Count {
    /// Inotsanangurwa nenhamba chaiyo, inochengetera kukosha
    Is(usize),
    /// Inotsanangurwa uchishandisa `$` uye `*` syntaxes, inochengeta iyo index mu `args`
    Param(usize),
    /// Hazvina kutaurwa
    Implied,
}