//! Yakagadziriswa yekunze iteration.
//!
//! Kana iwe wakazviwana iwe uine muunganidzwa weimwe mhando, uye uchidikanwa kuti uite oparesheni pazvinhu zveizvo zvataurwa muunganidzwa, iwe unokurumidza kumhanyira mu 'iterators'.
//! MaIterator anoshandiswa zvakanyanya mune idiomatic Rust kodhi, saka zvakakodzera kuti ujairane navo.
//!
//! Tisati tatsanangura zvimwe, ngatitaurei nezvekuti module iyi yakarongedzwa sei:
//!
//! # Organization
//!
//! Iyi module yakanyanya kurongedzwa nerudzi:
//!
//! * [Traits] ndiwo chikamu chepakati: idzi traits tsanangura kuti ndedzipi iterator dziripo uye nezvaungaite navo.Maitiro e traits aya akakosha kuisa imwe yekuwedzera nguva yekudzidza mukati.
//! * [Functions] ipa dzimwe nzira dzinobatsira dzekugadzira mamwe maiterator ekutanga.
//! * [Structs] anowanzo ari marudzi ekudzoka enzira dzakasiyana siyana pane ino module traits.Iwe unowanzo kuda kutarisa nzira iyo inogadzira iyo `struct`, pane iyo `struct` pachayo.
//! Kuti uwane rumwe ruzivo nezve nei, ona '[Kutevedzera Iterator](#kuita-iterator)'.
//!
//! [Traits]: #traits
//! [Functions]: #functions
//! [Structs]: #structs
//!
//! Ndizvo!Ngatitsvakei maiterator.
//!
//! # Iterator
//!
//! Moyo uye mweya weiyi module ndeye [`Iterator`] trait.Musimboti we [`Iterator`] unoratidzika seizvi:
//!
//! ```
//! trait Iterator {
//!     type Item;
//!     fn next(&mut self) -> Option<Self::Item>;
//! }
//! ```
//!
//! Iterator ine nzira, [`next`], iyo painodaidzwa, inodzosera [`Sarudzo`]`<Item>`.
//! [`next`] inodzosera [`Some(Item)`] chero bedzi paine zvinhu, uye kana zvese zvave kuneta, zvinodzosera `None` kuratidza kuti iteration yapera.
//! Mumwe nemumwe maiterator anogona kusarudza kuitazve iteration, nekudaro kudaidza [`next`] zvakare kunogona kana kusazotanga kudzosa [`Some(Item)`] zvakare pane imwe nguva (semuenzaniso, ona [`TryIter`]).
//!
//!
//! [`Iterator`] tsananguro izere inosanganisira dzimwe nzira dzinoverengeka zvakare, asi idzo nzira dzekutadza, dzakavakirwa pamusoro pe [`next`], uye saka unodziwana mahara.
//!
//! Iterator zvakare akaumbika, uye zvakajairika kuasunga pamwechete kuita mamwe maitiro akaomarara ekugadzirisa.Ona iyo [Adapters](#adapters) chikamu pazasi kuti uwane rumwe ruzivo.
//!
//! [`Some(Item)`]: Some
//! [`next`]: Iterator::next
//! [`TryIter`]: ../../std/sync/mpsc/struct.TryIter.html
//!
//! # Iwo mafomu matatu ekuita
//!
//! Kune nzira nhatu dzakajairika dzinogona kugadzira maiterator kubva kuunganidzwa:
//!
//! * `iter()`, iyo inofamba pamusoro pe `&T`.
//! * `iter_mut()`, iyo inofamba pamusoro pe `&mut T`.
//! * `into_iter()`, iyo inofamba pamusoro pe `T`.
//!
//! Zvinhu zvakasiyana siyana muyakajairwa raibhurari zvinogona kuita chimwe kana zvimwe zvezvitatu, pazvinenge zvakakodzera.
//!
//! # Kuita Iterator
//!
//! Kugadzira iterator yako pachako kunosanganisira nhanho mbiri: kugadzira `struct` kubata mamiriro iterator, uye nekuzadzisa [`Iterator`] yeiyo `struct`.
//! Ichi ndicho chikonzero paine akawanda `ma`multimu mune iyi module: pane imwe yeayo iterator imwe neimwe uye iterator adapter.
//!
//! Ngatigadzirei iterator inonzi `Counter` iyo inoverengwa kubva pa `1` kusvika `5`:
//!
//! ```
//! // Kutanga, iyo dhizaini:
//!
//! /// Iterator iyo inoverengwa kubva pane imwe kusvika shanu
//! struct Counter {
//!     count: usize,
//! }
//!
//! // isu tinoda kuti kuverenga kwedu kutange kamwe, saka ngatiwedzerei nzira ye new() yekubatsira.
//! // Izvi hazvinyanyo kudikanwa, asi zviri nyore.
//! // Ziva kuti isu tinotanga `count` pa zero, tichaona kuti nei mu `next()`'s kuitisa pazasi.
//! impl Counter {
//!     fn new() -> Counter {
//!         Counter { count: 0 }
//!     }
//! }
//!
//! // Ipapo, isu tinoshandisa `Iterator` ye `Counter` yedu:
//!
//! impl Iterator for Counter {
//!     // tichave tichiverenga pamwe usize
//!     type Item = usize;
//!
//!     // next() ndiyo chete nzira inodikanwa
//!     fn next(&mut self) -> Option<Self::Item> {
//!         // Kuwedzera kuverenga kwedu.Ichi ndicho chikonzero takatanga pa zero.
//!         self.count += 1;
//!
//!         // Tarisa uone kana tapedza kuverenga kana kuti kwete.
//!         if self.count < 6 {
//!             Some(self.count)
//!         } else {
//!             None
//!         }
//!     }
//! }
//!
//! // Uye ikozvino tinogona kuzvishandisa!
//!
//! let mut counter = Counter::new();
//!
//! assert_eq!(counter.next(), Some(1));
//! assert_eq!(counter.next(), Some(2));
//! assert_eq!(counter.next(), Some(3));
//! assert_eq!(counter.next(), Some(4));
//! assert_eq!(counter.next(), Some(5));
//! assert_eq!(counter.next(), None);
//! ```
//!
//! Kufonera [`next`] nenzira iyi kunodzokorora.Rust ine yekuvaka iyo inogona kudaidza [`next`] pane yako iterator, kudzamara yasvika `None`.Ngatitorei izvo zvinotevera.
//!
//! Ziva zvakare kuti `Iterator` inopa kumisikidza kuitiswa kwenzira dzakadai se `nth` uye `fold` dzinodaidza `next` mukati.
//! Nekudaro, zvinokwanisika kunyora tsika yekumisikidza yenzira senge `nth` uye `fold` kana iterator ichigona kudzienzanisa zvakanyanya pasina kusheedza `next`.
//!
//! # `for` zvishwe uye `IntoIterator`
//!
//! Rust's `for` loop syntax iri chaizvo shuga kune maiterator.Heino muenzaniso wekutanga we `for`:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Izvi zvichapurinda manhamba imwe kusvika mashanu, imwe neimwe pamutsetse wayo.Asi iwe uchaona chimwe chinhu pano: isu hatina kumbofona chero chinhu pane yedu vector kuburitsa iterator.Chii chinopa?
//!
//! Iko kune trait mune yakajairwa raibhurari yekushandura chimwe chinhu kuita iterator: [`IntoIterator`].
//! Iyi trait ine nzira imwechete, [`into_iter`], iyo inoshandura chinhu chichiita [`IntoIterator`] kuita iterator.
//! Ngatitarisei iyo `for` chiuno zvakare, uye icho chinomisikidza chinoshandura chikaita:
//!
//! [`into_iter`]: IntoIterator::into_iter
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//!
//! for x in values {
//!     println!("{}", x);
//! }
//! ```
//!
//! Rust de-shuga izvi mu:
//!
//! ```
//! let values = vec![1, 2, 3, 4, 5];
//! {
//!     let result = match IntoIterator::into_iter(values) {
//!         mut iter => loop {
//!             let next;
//!             match iter.next() {
//!                 Some(val) => next = val,
//!                 None => break,
//!             };
//!             let x = next;
//!             let () = { println!("{}", x); };
//!         },
//!     };
//!     result
//! }
//! ```
//!
//! Kutanga, tinodaidza `into_iter()` pane kukosha.Ipapo, isu tinowirirana pane iterator iyo inodzoka, ichisheedza [`next`] ichidzokorora kusvikira taona `None`.
//! Panguva iyoyo, isu `break` tabuda muchiuno, uye isu tapedza kuzviita.
//!
//! Pane imwezve isinganzwisisike pano: raibhurari yakajairwa ine inonakidza kuitisa [`IntoIterator`]:
//!
//! ```ignore (only-for-syntax-highlight)
//! impl<I: Iterator> IntoIterator for I
//! ```
//!
//! Mune mamwe mazwi, vese [`Iterator`] vanoshandisa [`IntoIterator`], nekungozvidzorera ivo pachavo.Izvi zvinoreva zvinhu zviviri:
//!
//! 1. Kana iwe uchinyora [`Iterator`], unogona kuishandisa ne `for` chiuno.
//! 2. Kana iwe urikugadzira muunganidzwa, kushandisa [`IntoIterator`] kwayo inobvumidza yako yekuunganidza kuti ishandiswe neiyo `for` chiuno.
//!
//! # Iterating nereferensi
//!
//! Sezvo [`into_iter()`] inotora `self` nemutengo, uchishandisa `for` chiuno kuti iterate pamusoro peunganidzwa inoshandisa iko kuunganidzwa.Kazhinji, iwe ungangoda kurerutsa pamusoro peunganidzwa pasina kuishandisa.
//! Mazhinji maunganidzwa anopa nzira dzinopa ivo iterator pamusoro pezvirevo, zvinowanzoitwa zvinonzi `iter()` uye `iter_mut()` zvichiteerana:
//!
//! ```
//! let mut values = vec![41];
//! for x in values.iter_mut() {
//!     *x += 1;
//! }
//! for x in values.iter() {
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1); // `values` ichiri yake iyi basa.
//! ```
//!
//! Kana iyo mhando yekuunganidza `C` ichipa `iter()`, inowanzo shandisa `IntoIterator` ye `&C`, iine kuitiswa iyo inongodaidza `iter()`.
//! Saizvozvowo, muunganidzwa `C` inopa `iter_mut()` kazhinji inoshandisa `IntoIterator` ye `&mut C` nekupa `iter_mut()`.Izvi zvinogonesa iri nyore shorthand:
//!
//! ```
//! let mut values = vec![41];
//! for x in &mut values { // zvakafanana ne `values.iter_mut()`
//!     *x += 1;
//! }
//! for x in &values { // zvakafanana ne `values.iter()`
//!     assert_eq!(*x, 42);
//! }
//! assert_eq!(values.len(), 1);
//! ```
//!
//! Nepo maunganidzwa mazhinji achipa `iter()`, kwete ese anopa `iter_mut()`.
//! Semuenzaniso, kuchinjisa makiyi e [`HashSet<T>`] kana [`HashMap<K, V>`] kunogona kuisa muunganidzwa munzvimbo isingawirirane kana kiyi ikasununguka kuchinja, saka maunganidzwa aya anongopa `iter()`.
//!
//! [`into_iter()`]: IntoIterator::into_iter
//! [`HashSet<T>`]: ../../std/collections/struct.HashSet.html
//! [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
//!
//! # Adapters
//!
//! Mabasa anotora [`Iterator`] odzosa imwe [`Iterator`] anowanzozodaidzwa kuti 'iterator adapters', sezvo iri fomu re 'adapta.
//! pattern'.
//!
//! Kazhinji iterator adapters anosanganisira [`map`], [`take`], uye [`filter`].
//! Kune zvimwe, ona zvinyorwa zvavo.
//!
//! Kana iyo iterator adapter panics, iyo iterator ichave mune isina kutaurwa (asi memory yakachengeteka) nyika.
//! Iyi nyika haina kuvimbiswa kuti igare zvakafanana pamhando dze Rust, saka unofanirwa kudzivirira kuvimba nemitengo chaiyo inodzoserwa neiterator iyo yakavhunduka.
//!
//! [`map`]: Iterator::map
//! [`take`]: Iterator::take
//! [`filter`]: Iterator::filter
//!
//! # Laziness
//!
//! MaIterator (uye iterator [adapters](#adapters))*ine husimbe*. Izvi zvinoreva kuti kungo gadzira iterator hakuite _do_ yakawanda.Hapana chaicho chinoitika kudzamara wafonera [`next`].
//! Izvi dzimwe nguva zvinopa nyonganiso kana uchigadzira iyo iterator chete kune ayo mhedzisiro.
//! Semuenzaniso, iyo [`map`] nzira inodaidza kuvhara pane chimwe nechimwe chinhu icho chinoita pamusoro:
//!
//! ```
//! # #![allow(unused_must_use)]
//! let v = vec![1, 2, 3, 4, 5];
//! v.iter().map(|x| println!("{}", x));
//! ```
//!
//! Izvi hazvidhindise chero kukosha, sezvo isu takangogadzira iterator, pane kuishandisa.Iye compiler anotiyambira nezverudzi urwu rwehunhu:
//!
//! ```text
//! warning: unused result that must be used: iterators are lazy and
//! do nothing unless consumed
//! ```
//!
//! Iyo nzira yekufunga yekunyora [`map`] yemhedzisiro yayo kushandisa `for` chiuno kana kufonera iyo [`for_each`] nzira:
//!
//! ```
//! let v = vec![1, 2, 3, 4, 5];
//!
//! v.iter().for_each(|x| println!("{}", x));
//! // or
//! for x in &v {
//!     println!("{}", x);
//! }
//! ```
//!
//! [`map`]: Iterator::map
//! [`for_each`]: Iterator::for_each
//!
//! Imwe nzira yakajairika yekuongorora iterator ndeye kushandisa iyo [`collect`] nzira kuburitsa muunganidzwa mutsva.
//!
//! [`collect`]: Iterator::collect
//!
//! # Infinity
//!
//! MaIterator haafanire kuve nemugumo.Semuenzaniso, rakavhurika-renji renji isinga peri iterator:
//!
//! ```
//! let numbers = 0..;
//! ```
//!
//! Zvakajairika kushandisa iyo [`take`] iterator adapta kushandura isinga gume iterator mune inopera imwe:
//!
//! ```
//! let numbers = 0..;
//! let five_numbers = numbers.take(5);
//!
//! for number in five_numbers {
//!     println!("{}", number);
//! }
//! ```
//!
//! Izvi zvichapurinda manhamba `0` kusvika `4`, imwe neimwe pamutsetse wayo.
//!
//! Ziva kuti nzira pane dzisingaperi maitereta, kunyangwe idzo mhedzisiro inogona kugadziriswa masvomhu munguva ine kupera, inogona kusapera.
//! Kunyanya, nzira dzakadai se [`min`], idzo mune yakajairwa kesi inoda kuyambuka zvese zvinhu zviri muiterator, zvingangodaro zvisiri kudzoka zvinobudirira kune chero mahedheni asinga peri.
//!
//! ```no_run
//! let ones = std::iter::repeat(1);
//! let least = ones.min().unwrap(); // Haiwa!Chisingaperi chiuno!
//! // `ones.min()` inokonzera kusingaperi chiuno, saka hatizosvika pano!
//! println!("The smallest number one is {}.", least);
//! ```
//!
//! [`take`]: Iterator::take
//! [`min`]: Iterator::min
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::Iterator;

#[unstable(
    feature = "step_trait",
    reason = "likely to be replaced by finer-grained traits",
    issue = "42168"
)]
pub use self::range::Step;

#[stable(feature = "iter_empty", since = "1.2.0")]
pub use self::sources::{empty, Empty};
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub use self::sources::{from_fn, FromFn};
#[stable(feature = "iter_once", since = "1.2.0")]
pub use self::sources::{once, Once};
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub use self::sources::{once_with, OnceWith};
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::sources::{repeat, Repeat};
#[stable(feature = "iterator_repeat_with", since = "1.28.0")]
pub use self::sources::{repeat_with, RepeatWith};
#[stable(feature = "iter_successors", since = "1.34.0")]
pub use self::sources::{successors, Successors};

#[stable(feature = "fused", since = "1.26.0")]
pub use self::traits::FusedIterator;
#[unstable(issue = "none", feature = "inplace_iteration")]
pub use self::traits::InPlaceIterable;
#[unstable(feature = "trusted_len", issue = "37572")]
pub use self::traits::TrustedLen;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::traits::{
    DoubleEndedIterator, ExactSizeIterator, Extend, FromIterator, IntoIterator, Product, Sum,
};

#[stable(feature = "iter_cloned", since = "1.1.0")]
pub use self::adapters::Cloned;
#[stable(feature = "iter_copied", since = "1.36.0")]
pub use self::adapters::Copied;
#[stable(feature = "iterator_flatten", since = "1.29.0")]
pub use self::adapters::Flatten;
#[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
pub use self::adapters::MapWhile;
#[unstable(feature = "inplace_iteration", issue = "none")]
pub use self::adapters::SourceIter;
#[stable(feature = "iterator_step_by", since = "1.28.0")]
pub use self::adapters::StepBy;
#[unstable(feature = "trusted_random_access", issue = "none")]
pub use self::adapters::TrustedRandomAccess;
#[stable(feature = "rust1", since = "1.0.0")]
pub use self::adapters::{
    Chain, Cycle, Enumerate, Filter, FilterMap, FlatMap, Fuse, Inspect, Map, Peekable, Rev, Scan,
    Skip, SkipWhile, Take, TakeWhile, Zip,
};
#[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
pub use self::adapters::{Intersperse, IntersperseWith};

pub(crate) use self::adapters::process_results;

mod adapters;
mod range;
mod sources;
mod traits;