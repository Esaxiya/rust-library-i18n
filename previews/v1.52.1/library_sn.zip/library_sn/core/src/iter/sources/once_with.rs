use crate::iter::{FusedIterator, TrustedLen};

/// Inogadzira iterator iyo zvine usimbe inogadzira kukosha chaizvo kamwe nekukoka iyo yakavharwa yekuvhara.
///
/// Izvi zvinowanzo shandiswa kuchinjisa imwechete kukosha jenareta kuva [`chain()`] yemamwe marudzi eiyo iteration.
/// Pamwe une iterator inovhara zvinenge zvese, asi iwe unoda imwe yakasarudzika kesi.
/// Pamwe iwe une basa rinoshanda pane maiterator, asi iwe unongoda kugadzirisa imwe kukosha.
///
/// Kusiyana ne [`once()`], iri basa rinozoita nehusimbe kuburitsa kukosha pane chikumbiro.
///
/// [`chain()`]: Iterator::chain
/// [`once()`]: crate::iter::once
///
/// # Examples
///
/// Kushandiswa kwekutanga:
///
/// ```
/// use std::iter;
///
/// // imwe ndiyo yakasurukirwa nhamba
/// let mut one = iter::once_with(|| 1);
///
/// assert_eq!(Some(1), one.next());
///
/// // imwe chete, ndizvo chete zvatinowana
/// assert_eq!(None, one.next());
/// ```
///
/// Kusunga pamwe chete neimwe iterator.
/// Ngatitii isu tinoda kuyera pamusoro pefaira rega rega reiyo `.foo` dhairekitori, asi zvakare gadziriso faira,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // isu tinoda kushandura kubva kune iterator yeDirEntry-s kuenda kune iterator yePathBufs, saka tinoshandisa mepu
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // ikozvino, yedu iterator chete yedu yekumisikidza faira
/// let config = iter::once_with(|| PathBuf::from(".foorc"));
///
/// // cheni mairi iterator pamwe chete kuita imwe hombe iterator
/// let files = dirs.chain(config);
///
/// // izvi zvichatipa ese mafaera mu .foo pamwe ne .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
///
#[inline]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub fn once_with<A, F: FnOnce() -> A>(gen: F) -> OnceWith<F> {
    OnceWith { gen: Some(gen) }
}

/// Iyo iterator inoburitsa chinhu chimwe cherudzi `A` nekuisa iko kupihwa kuvhara `F: FnOnce() -> A`.
///
///
/// Iyi `struct` inogadzirwa ne [`once_with()`] basa.
/// Ona zvinyorwa zvaro zvimwe.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once_with", since = "1.43.0")]
pub struct OnceWith<F> {
    gen: Option<F>,
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> Iterator for OnceWith<F> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        let f = self.gen.take()?;
        Some(f())
    }

    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.gen.iter().size_hint()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> DoubleEndedIterator for OnceWith<F> {
    fn next_back(&mut self) -> Option<A> {
        self.next()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> ExactSizeIterator for OnceWith<F> {
    fn len(&self) -> usize {
        self.gen.iter().len()
    }
}

#[stable(feature = "iter_once_with", since = "1.43.0")]
impl<A, F: FnOnce() -> A> FusedIterator for OnceWith<F> {}

#[stable(feature = "iter_once_with", since = "1.43.0")]
unsafe impl<A, F: FnOnce() -> A> TrustedLen for OnceWith<F> {}