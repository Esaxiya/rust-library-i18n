use crate::iter::{FusedIterator, TrustedLen};

/// Inogadzira iterator iyo inoburitsa chinhu chaizvo kamwe chete.
///
/// Izvi zvinowanzo shandiswa kuchinjisa imwechete kukosha mu [`chain()`] yemamwe marudzi eiyo iteration.
/// Pamwe une iterator inovhara zvinenge zvese, asi iwe unoda imwe yakasarudzika kesi.
/// Pamwe iwe une basa rinoshanda pane maiterator, asi iwe unongoda kugadzirisa imwe kukosha.
///
/// [`chain()`]: Iterator::chain
///
/// # Examples
///
/// Kushandiswa kwekutanga:
///
/// ```
/// use std::iter;
///
/// // imwe ndiyo yakasurukirwa nhamba
/// let mut one = iter::once(1);
///
/// assert_eq!(Some(1), one.next());
///
/// // imwe chete, ndizvo chete zvatinowana
/// assert_eq!(None, one.next());
/// ```
///
/// Kusunga pamwe chete neimwe iterator.
/// Ngatitii isu tinoda kuyera pamusoro pefaira rega rega reiyo `.foo` dhairekitori, asi zvakare gadziriso faira,
///
/// `.foorc`:
///
/// ```no_run
/// use std::iter;
/// use std::fs;
/// use std::path::PathBuf;
///
/// let dirs = fs::read_dir(".foo").unwrap();
///
/// // isu tinoda kushandura kubva kune iterator yeDirEntry-s kuenda kune iterator yePathBufs, saka tinoshandisa mepu
/////
/// let dirs = dirs.map(|file| file.unwrap().path());
///
/// // ikozvino, yedu iterator chete yedu yekumisikidza faira
/// let config = iter::once(PathBuf::from(".foorc"));
///
/// // cheni mairi iterator pamwe chete kuita imwe hombe iterator
/// let files = dirs.chain(config);
///
/// // izvi zvichatipa ese mafaera mu .foo pamwe ne .foorc
/// for f in files {
///     println!("{:?}", f);
/// }
/// ```
#[stable(feature = "iter_once", since = "1.2.0")]
pub fn once<T>(value: T) -> Once<T> {
    Once { inner: Some(value).into_iter() }
}

/// Iterator inoburitsa chinhu kamwe chete.
///
/// Iyi `struct` inogadzirwa ne [`once()`] basa.Ona zvinyorwa zvaro zvimwe.
#[derive(Clone, Debug)]
#[stable(feature = "iter_once", since = "1.2.0")]
pub struct Once<T> {
    inner: crate::option::IntoIter<T>,
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> Iterator for Once<T> {
    type Item = T;

    fn next(&mut self) -> Option<T> {
        self.inner.next()
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> DoubleEndedIterator for Once<T> {
    fn next_back(&mut self) -> Option<T> {
        self.inner.next_back()
    }
}

#[stable(feature = "iter_once", since = "1.2.0")]
impl<T> ExactSizeIterator for Once<T> {
    fn len(&self) -> usize {
        self.inner.len()
    }
}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<T> TrustedLen for Once<T> {}

#[stable(feature = "fused", since = "1.26.0")]
impl<T> FusedIterator for Once<T> {}