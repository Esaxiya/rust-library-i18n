use crate::fmt;

/// Inogadzira iterator nyowani uko yega yega iteration inodaidzira yakapihwa kuvhara `F: FnMut() -> Option<T>`.
///
/// Izvi zvinobvumidza kuigadzira yetsika iterator nechero hunhu pasina kushandisa yakawanda verbose syntax yekugadzira yakatsaurwa mhando uye kuitisa iyo [`Iterator`] trait yayo.
///
/// Ziva kuti iyo `FromFn` iterator haifungidzire nezve hunhu hwekuvhara, uye nekudaro nekuchengetedza haigadzi [`FusedIterator`], kana kudarika [`Iterator::size_hint()`] kubva kune yayo default `(0, None)`.
///
///
/// Kuvhara kwacho kunogona kushandisa zvinotorwa uye nharaunda yacho kuteedzera nyika kuyambuka iterations.Zvichienderana nekuti iterator inoshandiswa sei, izvi zvingangoda kudoma [`move`] kiyi kiyi pakuvhara.
///
/// [`move`]: ../../std/keyword.move.html
/// [`FusedIterator`]: crate::iter::FusedIterator
///
/// # Examples
///
/// Ngatishandurezve kuita counter iterator kubva ku [module-level documentation]:
///
/// [module-level documentation]: crate::iter
///
/// ```
/// let mut count = 0;
/// let counter = std::iter::from_fn(move || {
///     // Kuwedzera kuverenga kwedu.Ichi ndicho chikonzero takatanga pa zero.
///     count += 1;
///
///     // Tarisa uone kana tapedza kuverenga kana kuti kwete.
///     if count < 6 {
///         Some(count)
///     } else {
///         None
///     }
/// });
/// assert_eq!(counter.collect::<Vec<_>>(), &[1, 2, 3, 4, 5]);
/// ```
///
///
///
///
///
#[inline]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub fn from_fn<T, F>(f: F) -> FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    FromFn(f)
}

/// Iyo iterator uko yega yega iteration inodaidza yakapihwa kuvhara `F: FnMut() -> Option<T>`.
///
/// Iyi `struct` inogadzirwa ne [`iter::from_fn()`] basa.
/// Ona zvinyorwa zvaro zvimwe.
///
/// [`iter::from_fn()`]: from_fn
#[derive(Clone)]
#[stable(feature = "iter_from_fn", since = "1.34.0")]
pub struct FromFn<F>(F);

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<T, F> Iterator for FromFn<F>
where
    F: FnMut() -> Option<T>,
{
    type Item = T;

    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        (self.0)()
    }
}

#[stable(feature = "iter_from_fn", since = "1.34.0")]
impl<F> fmt::Debug for FromFn<F> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FromFn").finish()
    }
}