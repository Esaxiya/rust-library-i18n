use crate::iter::{FusedIterator, TrustedLen};

/// Inogadzira iterator nyowani inoramba ichidzokorora chinhu chimwe.
///
/// Basa re `repeat()` rinodzokorora kukosha kamwe chete kakawanda.
///
/// Asingagumi iterators senge `repeat()` anowanzo shandiswa nema adapters senge [`Iterator::take()`], kuitira kuti agume.
///
/// Kana mhando yechinhu iterator yaunoda isingashandise `Clone`, kana kana iwe usiri kuda kuchengeta chinhu chakadzokororwa mundangariro, unogona kushandisa iro [`repeat_with()`] basa.
///
///
/// [`repeat_with()`]: crate::iter::repeat_with
///
/// # Examples
///
/// Kushandiswa kwekutanga:
///
/// ```
/// use std::iter;
///
/// // nhamba yechina 4ever:
/// let mut fours = iter::repeat(4);
///
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
/// assert_eq!(Some(4), fours.next());
///
/// // yup, vachiri vana
/// assert_eq!(Some(4), fours.next());
/// ```
///
/// Kuenda kupera ne [`Iterator::take()`]:
///
/// ```
/// use std::iter;
///
/// // iwo muenzaniso wekupedzisira waive wakawandisa mana.Ngativei nemana chete.
/// let mut four_fours = iter::repeat(4).take(4);
///
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
/// assert_eq!(Some(4), four_fours.next());
///
/// // ... uye zvino tapedza
/// assert_eq!(None, four_fours.next());
/// ```
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub fn repeat<T: Clone>(elt: T) -> Repeat<T> {
    Repeat { element: elt }
}

/// Iyo iterator inodzokorora chinhu kusingaperi.
///
/// Iyi `struct` inogadzirwa ne [`repeat()`] basa.Ona zvinyorwa zvaro zvimwe.
#[derive(Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Repeat<A> {
    element: A,
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> Iterator for Repeat<A> {
    type Item = A;

    #[inline]
    fn next(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
    #[inline]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (usize::MAX, None)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<A: Clone> DoubleEndedIterator for Repeat<A> {
    #[inline]
    fn next_back(&mut self) -> Option<A> {
        Some(self.element.clone())
    }
}

#[stable(feature = "fused", since = "1.26.0")]
impl<A: Clone> FusedIterator for Repeat<A> {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<A: Clone> TrustedLen for Repeat<A> {}