/// Shanduko kubva ku [`Iterator`].
///
/// Nekushandisa `FromIterator` yerudzi, iwe unotsanangura kuti ichagadzirwa sei kubva kune iterator.
/// Izvi zvakajairika kumhando dzinotsanangura kuunganidzwa kweimwe mhando.
///
/// [`FromIterator::from_iter()`] haiwanzodaidzwa kujekeswa, uye pachinzvimbo inoshandiswa nenzira ye [`Iterator::collect()`].
///
/// Ona [`Iterator::collect()`]'s zvinyorwa zvemimwe mienzaniso.
///
/// Onawo: [`IntoIterator`].
///
/// # Examples
///
/// Kushandiswa kwekutanga:
///
/// ```
/// use std::iter::FromIterator;
///
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v = Vec::from_iter(five_fives);
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Uchishandisa [`Iterator::collect()`] kushandisa zvizere `FromIterator`:
///
/// ```
/// let five_fives = std::iter::repeat(5).take(5);
///
/// let v: Vec<i32> = five_fives.collect();
///
/// assert_eq!(v, vec![5, 5, 5, 5, 5]);
/// ```
///
/// Kuita `FromIterator` yerudzi rwako:
///
/// ```
/// use std::iter::FromIterator;
///
/// // Muenzaniso wekuunganidza, izvo zvinongoputira pamusoro peVec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Ngatizvipei dzimwe nzira kuti tigone kugadzira imwe nekuwedzera zvinhu kwazviri.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // uye isu tichaisa kubva kunaIterator
/// impl FromIterator<i32> for MyCollection {
///     fn from_iter<I: IntoIterator<Item=i32>>(iter: I) -> Self {
///         let mut c = MyCollection::new();
///
///         for i in iter {
///             c.add(i);
///         }
///
///         c
///     }
/// }
///
/// // Iye zvino tinogona kugadzira iterator nyowani ...
/// let iter = (0..5).into_iter();
///
/// // ... uye gadzira MyCollection mairi
/// let c = MyCollection::from_iter(iter);
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
///
/// // collect inoshandawo!
///
/// let iter = (0..5).into_iter();
/// let c: MyCollection = iter.collect();
///
/// assert_eq!(c.0, vec![0, 1, 2, 3, 4]);
/// ```
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    message = "a value of type `{Self}` cannot be built from an iterator \
               over elements of type `{A}`",
    label = "value of type `{Self}` cannot be built from `std::iter::Iterator<Item={A}>`"
)]
pub trait FromIterator<A>: Sized {
    /// Inogadzira kukosha kubva kune iterator.
    ///
    /// Ona [module-level documentation] zvimwe.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// use std::iter::FromIterator;
    ///
    /// let five_fives = std::iter::repeat(5).take(5);
    ///
    /// let v = Vec::from_iter(five_fives);
    ///
    /// assert_eq!(v, vec![5, 5, 5, 5, 5]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_iter<T: IntoIterator<Item = A>>(iter: T) -> Self;
}

/// Shanduko kuita [`Iterator`].
///
/// Nekushandisa `IntoIterator` yerudzi, iwe unotsanangura kuti ichashandurwa sei kuita iterator.
/// Izvi zvakajairika kumhando dzinotsanangura kuunganidzwa kweimwe mhando.
///
/// Imwe bhenefiti yekushandisa `IntoIterator` ndeyekuti yako mhando ichaita [work with Rust's `for` loop syntax](crate::iter#for-loops-and-intoiterator).
///
///
/// Onawo: [`FromIterator`].
///
/// # Examples
///
/// Kushandiswa kwekutanga:
///
/// ```
/// let v = vec![1, 2, 3];
/// let mut iter = v.into_iter();
///
/// assert_eq!(Some(1), iter.next());
/// assert_eq!(Some(2), iter.next());
/// assert_eq!(Some(3), iter.next());
/// assert_eq!(None, iter.next());
/// ```
/// Kuita `IntoIterator` yerudzi rwako:
///
/// ```
/// // Muenzaniso wekuunganidza, izvo zvinongoputira pamusoro peVec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Ngatizvipei dzimwe nzira kuti tigone kugadzira imwe nekuwedzera zvinhu kwazviri.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // uye isu tichaisa IntoIterator
/// impl IntoIterator for MyCollection {
///     type Item = i32;
///     type IntoIter = std::vec::IntoIter<Self::Item>;
///
///     fn into_iter(self) -> Self::IntoIter {
///         self.0.into_iter()
///     }
/// }
///
/// // Iye zvino tinogona kugadzira muunganidzwa mutsva ...
/// let mut c = MyCollection::new();
///
/// // ... wedzera zvimwe zvinhu kwairi ...
/// c.add(0);
/// c.add(1);
/// c.add(2);
///
/// // ... uye wozoichinja kuita Iterator:
/// for (i, n) in c.into_iter().enumerate() {
///     assert_eq!(i as i32, n);
/// }
/// ```
///
/// Zvakajairika kushandisa `IntoIterator` se trait bound.Izvi zvinobvumira iyo yekuunganidza mhando kuti ichinje, chero bedzi ichiri iterator.
/// Mimwe miganhu inogona kutsanangurwa nekumisa pa
/// `Item`:
///
/// ```rust
/// fn collect_as_strings<T>(collection: T) -> Vec<String>
/// where
///     T: IntoIterator,
///     T::Item: std::fmt::Debug,
/// {
///     collection
///         .into_iter()
///         .map(|item| format!("{:?}", item))
///         .collect()
/// }
/// ```
///
///
#[rustc_diagnostic_item = "IntoIterator"]
#[stable(feature = "rust1", since = "1.0.0")]
pub trait IntoIterator {
    /// Rudzi rwezvinhu zviri kuitirwa pamusoro.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Nderupi iterator ratiri kuchinja kuita ichi?
    #[stable(feature = "rust1", since = "1.0.0")]
    type IntoIter: Iterator<Item = Self::Item>;

    /// Inogadzira iterator kubva kune kukosha.
    ///
    /// Ona [module-level documentation] zvimwe.
    ///
    /// [module-level documentation]: crate::iter
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let v = vec![1, 2, 3];
    /// let mut iter = v.into_iter();
    ///
    /// assert_eq!(Some(1), iter.next());
    /// assert_eq!(Some(2), iter.next());
    /// assert_eq!(Some(3), iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    #[lang = "into_iter"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn into_iter(self) -> Self::IntoIter;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator> IntoIterator for I {
    type Item = I::Item;
    type IntoIter = I;

    fn into_iter(self) -> I {
        self
    }
}

/// Wedzera muunganidzwa nezviri mukati meiyo iterator.
///
/// Iterator inogadzira akateedzana ehunhu, uye kuunganidzwa kunogona zvakare kufungwa nezvakateedzana ehunhu.
/// Iyo `Extend` trait inovhara iyi mukaha, ichikubvumidza iwe kuti uwedzere muunganidzwa nekusanganisira zvirimo mune iyo iterator.
/// Kana uchitambanudza muunganidzwa nekiyi yatovepo, iyo yekupinda inovandudzwa kana, mune zviitiko zvekuunganidzwa zvinotendera zvakapetwa kiyi nemakiyi akaenzana, iwo mukova unowedzerwa.
///
///
/// # Examples
///
/// Kushandiswa kwekutanga:
///
/// ```
/// // Iwe unogona kuwedzera Tambo uine zvimwe zviteshi:
/// let mut message = String::from("The first three letters are: ");
///
/// message.extend(&['a', 'b', 'c']);
///
/// assert_eq!("abc", &message[29..32]);
/// ```
///
/// Kuita `Extend`:
///
/// ```
/// // Muenzaniso wekuunganidza, izvo zvinongoputira pamusoro peVec<T>
/// #[derive(Debug)]
/// struct MyCollection(Vec<i32>);
///
/// // Ngatizvipei dzimwe nzira kuti tigone kugadzira imwe nekuwedzera zvinhu kwazviri.
/////
/// impl MyCollection {
///     fn new() -> MyCollection {
///         MyCollection(Vec::new())
///     }
///
///     fn add(&mut self, elem: i32) {
///         self.0.push(elem);
///     }
/// }
///
/// // sezvo MyCollection iine runyorwa rwe i32s, isu tinoshandisa Wedzera kune i32
/// impl Extend<i32> for MyCollection {
///
///     // Izvi zviri nyore zvishoma nekongiri mhando siginecha: tinogona kudaidza kuwedzera pane chero chinhu chinogona kushandurwa kuita Iterator iyo inotipa i32s.
///     // Nekuti isu tinoda i32s kuisa muMyCollection.
/////
///     fn extend<T: IntoIterator<Item=i32>>(&mut self, iter: T) {
///
///         // Kuitwa kwacho kwakanyatsojeka: chiuno kuburikidza neiterator, uye add() chinhu chimwe nechimwe kwatiri.
/////
///         for elem in iter {
///             self.add(elem);
///         }
///     }
/// }
///
/// let mut c = MyCollection::new();
///
/// c.add(5);
/// c.add(6);
/// c.add(7);
///
/// // ngatiwedzerei muunganidzwa wedu nedzimwe nhamba nhatu
/// c.extend(vec![1, 2, 3]);
///
/// // isu takawedzera zvinhu izvi kumagumo
/// assert_eq!("MyCollection([5, 6, 7, 1, 2, 3])", format!("{:?}", c));
/// ```
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait Extend<A> {
    /// Inowedzera muunganidzwa nezviri mukati meiyo iterator.
    ///
    /// Sezvo iyi ndiyo chete nzira inodikanwa yeiyi trait, iwo ma [trait-level] maHTML ane rumwe ruzivo.
    ///
    ///
    /// [trait-level]: Extend
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// // Iwe unogona kuwedzera Tambo uine zvimwe zviteshi:
    /// let mut message = String::from("abc");
    ///
    /// message.extend(['d', 'e', 'f'].iter());
    ///
    /// assert_eq!("abcdef", &message);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn extend<T: IntoIterator<Item = A>>(&mut self, iter: T);

    /// Inowedzera muunganidzwa nechinhu chimwe chete.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_one(&mut self, item: A) {
        self.extend(Some(item));
    }

    /// Inochengetera kugona mune yekuunganidza yenhamba yakapihwa yezvimwe zvinhu.
    ///
    /// Kuitwa kwekumisikidza hakuite chinhu.
    #[unstable(feature = "extend_one", issue = "72631")]
    fn extend_reserve(&mut self, additional: usize) {
        let _ = additional;
    }
}

#[stable(feature = "extend_for_unit", since = "1.28.0")]
impl Extend<()> for () {
    fn extend<T: IntoIterator<Item = ()>>(&mut self, iter: T) {
        iter.into_iter().for_each(drop)
    }
    fn extend_one(&mut self, _item: ()) {}
}