use crate::ops::{ControlFlow, Try};

/// Iyo iterator inokwanisa kuburitsa zvinhu kubva kumicheto miviri.
///
/// Chinhu chinoshandisa `DoubleEndedIterator` chine imwe simba rinowedzera pamusoro pechinhu chinoshandisa [`Iterator`]: kugona kutora zvakare `Item`s kubva kumashure, pamwe nekumberi.
///
///
/// Izvo zvakakosha kuti uzive kuti zvese kumashure nekudzoka zvinoshanda pane imwechete nhanho, uye usayambuke: iteration yapera pavanosangana pakati.
///
/// Nenzira imwecheteyo kune iyo [`Iterator`] protocol, kana `DoubleEndedIterator` ichidzorera [`None`] kubva ku [`next_back()`], ichichidaidza zvakare inogona kana kusazombodzosa [`Some`] zvakare.
/// [`next()`] uye [`next_back()`] inochinjaniswa nekuda kwechinangwa ichi.
///
/// [`next_back()`]: DoubleEndedIterator::next_back
/// [`next()`]: Iterator::next
///
/// # Examples
///
/// Kushandiswa kwekutanga:
///
/// ```
/// let numbers = vec![1, 2, 3, 4, 5, 6];
///
/// let mut iter = numbers.iter();
///
/// assert_eq!(Some(&1), iter.next());
/// assert_eq!(Some(&6), iter.next_back());
/// assert_eq!(Some(&5), iter.next_back());
/// assert_eq!(Some(&2), iter.next());
/// assert_eq!(Some(&3), iter.next());
/// assert_eq!(Some(&4), iter.next());
/// assert_eq!(None, iter.next());
/// assert_eq!(None, iter.next_back());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait DoubleEndedIterator: Iterator {
    /// Inobvisa uye inodzosera chinhu kubva kumagumo eiyo iterator.
    ///
    /// Inodzorera `None` kana pasisina zvimwe zvinhu.
    ///
    /// Iwo ma [trait-level] maHTML ane rumwe ruzivo.
    ///
    /// [trait-level]: DoubleEndedIterator
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let numbers = vec![1, 2, 3, 4, 5, 6];
    ///
    /// let mut iter = numbers.iter();
    ///
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&6), iter.next_back());
    /// assert_eq!(Some(&5), iter.next_back());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    /// assert_eq!(Some(&4), iter.next());
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next_back());
    /// ```
    ///
    /// # Remarks
    ///
    /// Izvo zvinhu zvakaburitswa nenzira dze`DoubleEndedIterator` dzinogona kusiyana neidzo dzakapihwa nenzira dze [``Iterator`] 's:
    ///
    ///
    /// ```
    /// let vec = vec![(1, 'a'), (1, 'b'), (1, 'c'), (2, 'a'), (2, 'b')];
    /// let uniq_by_fst_comp = || {
    ///     let mut seen = std::collections::HashSet::new();
    ///     vec.iter().copied().filter(move |x| seen.insert(x.0))
    /// };
    ///
    /// assert_eq!(uniq_by_fst_comp().last(), Some((2, 'a')));
    /// assert_eq!(uniq_by_fst_comp().next_back(), Some((2, 'b')));
    ///
    /// assert_eq!(
    ///     uniq_by_fst_comp().fold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(1, 'a'), (2, 'a')]
    /// );
    /// assert_eq!(
    ///     uniq_by_fst_comp().rfold(vec![], |mut v, x| {v.push(x); v}),
    ///     vec![(2, 'b'), (1, 'c')]
    /// );
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next_back(&mut self) -> Option<Self::Item>;

    /// Inofambira mberi iterator kubva kumashure ne `n` zvinhu.
    ///
    /// `advance_back_by` ndiyo reverse vhezheni ye [`advance_by`].Iyi nzira ichasvetuka nechido `n` zvinhu kutanga kubva kumashure nekudana [`next_back`] kusvika ku `n` nguva kusvikira [`None`] yasangana.
    ///
    /// `advance_back_by(n)` inodzosa [`Ok(())`] kana iterator ikabudirira kufambira mberi ne `n` zvinhu, kana [`Err(k)`] kana [`None`] yasangana, uko `k` ndiyo nhamba yezvinhu iyo iterator yakafambiswa isati yapera zvinhu (kureva.
    /// kureba kweterator).
    /// Ziva kuti `k` inogara iri pasi pe `n`.
    ///
    /// Kufonera `advance_back_by(0)` hakuiti chero chinhu uye kunogara kuchidzosa [`Ok(())`].
    ///
    /// [`advance_by`]: Iterator::advance_by
    /// [`next_back`]: DoubleEndedIterator::next_back
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [3, 4, 5, 6];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_back_by(2), Ok(()));
    /// assert_eq!(iter.next_back(), Some(&4));
    /// assert_eq!(iter.advance_back_by(0), Ok(()));
    /// assert_eq!(iter.advance_back_by(100), Err(1)); // `&3` chete ndiyo yakasvetwa
    /// ```
    ///
    /// [`Ok(())`]: Ok
    /// [`Err(k)`]: Err
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next_back().ok_or(i)?;
        }
        Ok(())
    }

    /// Inodzorera `n`th element kubva kumagumo eiyo iterator.
    ///
    /// Iyi ndiyo chaiyo yakadzoserwa vhezheni ye [`Iterator::nth()`].
    /// Kunyangwe senge yakawanda yekuisa indexing mashandiro, kuverenga kunotanga kubva zero, saka `nth_back(0)` inodzosa iyo yekutanga kukosha kubva kumagumo, `nth_back(1)` yechipiri, zvichingodaro.
    ///
    ///
    /// Ziva kuti zvese zvinhu zviri pakati peyekupedzisira nechakadzoserwa zvinhu zvichapedzwa, kusanganisira chinhu chakadzoserwa.
    /// Izvi zvinoreva zvakare kuti kufona `nth_back(0)` kakawanda pane imwechete iterator kunodzosa zvinhu zvakasiyana.
    ///
    /// `nth_back()` inodzosa [`None`] kana `n` yakakura kudarika kana yakaenzana nehurefu hwetereta.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(2), Some(&1));
    /// ```
    ///
    /// Kufonera `nth_back()` kakawanda hakudzosere iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth_back(1), Some(&2));
    /// assert_eq!(iter.nth_back(1), None);
    /// ```
    ///
    /// Kudzosera `None` kana paine zvishoma pane `n + 1` zvinhu:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth_back(10), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_nth_back", since = "1.37.0")]
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_back_by(n).ok()?;
        self.next_back()
    }

    /// Iyi ndiyo vhezheni vhezheni ye [`Iterator::try_fold()`]: zvinotora zvinhu kutanga kubva kumashure kweiyo iterator.
    ///
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = ["1", "2", "3"];
    /// let sum = a.iter()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert_eq!(sum, Ok(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = ["1", "rust", "3"];
    /// let mut it = a.iter();
    /// let sum = it
    ///     .by_ref()
    ///     .map(|&s| s.parse::<i32>())
    ///     .try_rfold(0, |acc, x| x.and_then(|y| Ok(acc + y)));
    /// assert!(sum.is_err());
    ///
    /// // Nekuti iyo yakapfupika-kutenderera, izvo zvasara zvinhu zvichiri kuwanikwa kuburikidza neayo iterator.
    /////
    /// assert_eq!(it.next_back(), Some(&"1"));
    /// ```
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_rfold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Iyo iterator nzira iyo inoderedza iyo iterator zvinhu kune imwechete, yekupedzisira kukosha, kutanga kubva kumashure.
    ///
    /// Iyi ndiyo vhezheni vhezheni ye [`Iterator::fold()`]: zvinotora zvinhu kutanga kubva kumashure kweiyo iterator.
    ///
    /// `rfold()` inotora nharo mbiri: kukosha kwekutanga, uye kuvhara nenharo mbiri: 'accumulator', uye chinhu.
    /// Kuvhara kunodzosera iyo kukosha iyo iyo yekuunganidza inofanira kuve nayo kune inotevera iteration.
    ///
    /// Iko kukosha kwekutanga kukosha iyo iyo accumulator ichave nayo pane yekutanga kufona.
    ///
    /// Mushure mekuisa iko kuvhara kune zvese zvinhu zveiyo iterator, `rfold()` inodzosera iyo yekuunganidza.
    ///
    /// Uku kuvhiya dzimwe nguva kunonzi 'reduce' kana 'inject'.
    ///
    /// Kupeta kunobatsira pese paunenge uine muunganidzwa wechimwe chinhu, uye uchida kuburitsa imwechete kukosha kubva pairi.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // kuwanda kwezvinhu zvese zve
    /// let sum = a.iter()
    ///            .rfold(0, |acc, &x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Uyu muenzaniso unovaka tambo, kutanga nekwakakosha kukosha uye kuenderera nechinhu chimwe nechimwe kubva kumashure kusvika kumberi.
    ///
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let zero = "0".to_string();
    ///
    /// let result = numbers.iter().rfold(zero, |acc, &x| {
    ///     format!("({} + {})", x, acc)
    /// });
    ///
    /// assert_eq!(result, "(1 + (2 + (3 + (4 + (5 + 0)))))");
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfold", since = "1.27.0")]
    fn rfold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next_back() {
            accum = f(accum, x);
        }
        accum
    }

    /// Kutsvaga kwechinhu cheiyo iterator kubva kumashure inogutsa chirevo.
    ///
    /// `rfind()` inotora kuvhara kunodzosera `true` kana `false`.
    /// Inoisa kuvhara uku kune chimwe nechimwe chinhu cheiyo iterator, kutanga kumagumo, uye kana paine mumwe wavo anodzoka `true`, ipapo `rfind()` inodzosera [`Some(element)`].
    /// Kana ivo vese vakadzoka `false`, inodzosera [`None`].
    ///
    /// `rfind()` kupfupika-kutenderera;mune mamwe mazwi, inomira kugadzirisa nekukurumidza kana iko kuvhura kwadzoka `true`.
    ///
    /// Nekuti `rfind()` inotora referensi, uye maiterator mazhinji anorerekera pane zvinongedzo, izvi zvinotungamira kune inogona kuvhiringidza mamiriro apo nharo iri revo mbiri.
    ///
    /// Unogona kuona izvi mumienzaniso pazasi, iine `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().rfind(|&&x| x == 5), None);
    /// ```
    ///
    /// Kumira pakutanga `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rfind(|&&x| x == 2), Some(&2));
    ///
    /// // isu tichiri kukwanisa kushandisa `iter`, sezvo paine zvimwe zvinhu.
    /// assert_eq!(iter.next_back(), Some(&1));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iter_rfind", since = "1.27.0")]
    fn rfind<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_rfold((), check(predicate)).break_value()
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<'a, I: DoubleEndedIterator + ?Sized> DoubleEndedIterator for &'a mut I {
    fn next_back(&mut self) -> Option<I::Item> {
        (**self).next_back()
    }
    fn advance_back_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_back_by(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<I::Item> {
        (**self).nth_back(n)
    }
}