/// Iterator iyo inoziva kureba kwayo chaiko.
///
/// Vazhinji [`Iterator`] havazive kuti kangani kavachaita, asi vamwe vanoziva.
/// Kana iyo iterator ichiziva kuti kangani iyo inogona kuitisa, kupa mukana kune iro ruzivo kunogona kubatsira.
/// Semuenzaniso, kana iwe uchida kurerekera kumashure, kutanga kwakanaka kuziva kuti mugumo uripi.
///
/// Paunenge uchiita `ExactSizeIterator`, unofanira zvakare kushandisa [`Iterator`].
/// Paunenge uchidaro, iko kuiswa kwe [`Iterator::size_hint`]*kunofanirwa* kudzosa saizi chaiyo yeiyo iterator.
///
/// Iyo [`len`] nzira ine yekumisikidza kuitisa, saka kazhinji haufanire kuitisa.
/// Nekudaro, iwe unogona kunge uchikwanisa kupa kumwe kuitisa kuitisa pane kusarongeka, saka kuipfuura apa mune zvine musoro.
///
///
/// Ziva kuti iyi trait ndeye trait yakachengeteka uye nekudaro haina *kwete* uye *haigone* kuvimbisa kuti kureba kwakadzoserwa kwakarurama.
/// Izvi zvinoreva kuti `unsafe` kodhi **haifanire** kuvimba nekurongeka kwe [`Iterator::size_hint`].
/// Iyo isina kugadzikana uye isina kuchengeteka [`TrustedLen`](super::marker::TrustedLen) trait inopa iyi yekuwedzera vimbiso.
///
/// [`len`]: ExactSizeIterator::len
///
/// # Examples
///
/// Kushandiswa kwekutanga:
///
/// ```
/// // renji renji rinonyatsoziva kangani kuti richaitisa
/// let five = 0..5;
///
/// assert_eq!(5, five.len());
/// ```
///
/// Mu [module-level docs], isu takaisa [`Iterator`], `Counter`.
/// Ngatishandisei `ExactSizeIterator` yazvo futi:
///
/// [module-level docs]: crate::iter
///
/// ```
/// # struct Counter {
/// #     count: usize,
/// # }
/// # impl Counter {
/// #     fn new() -> Counter {
/// #         Counter { count: 0 }
/// #     }
/// # }
/// # impl Iterator for Counter {
/// #     type Item = usize;
/// #     fn next(&mut self) -> Option<Self::Item> {
/// #         self.count += 1;
/// #         if self.count < 6 {
/// #             Some(self.count)
/// #         } else {
/// #             None
/// #         }
/// #     }
/// # }
/// impl ExactSizeIterator for Counter {
///     // Isu tinogona kuverenga nyore nhamba yasara yekudzokorora.
///     fn len(&self) -> usize {
///         5 - self.count
///     }
/// }
///
/// // Uye ikozvino tinogona kuzvishandisa!
///
/// let counter = Counter::new();
///
/// assert_eq!(5, counter.len());
/// ```
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait ExactSizeIterator: Iterator {
    /// Inodzorera iyo chaiyo kureba kweterator.
    ///
    /// Kuitwa kwacho kunovimbisa kuti iterator inodzoka chaizvo `len()` zvakapetwa kane [`Some(T)`] kukosha, isati yadzosa [`None`].
    ///
    /// Iyi nzira ine yekumisikidza kuitisa, saka kazhinji haufanire kuitisa iyo zvakananga.
    /// Nekudaro, kana iwe uchikwanisa kupa inoshanda zvakanyanya kuita, unogona kuzviita.
    /// Ona iwo [trait-level] maodhi semuenzaniso.
    ///
    /// Iri basa rine chengetedzo imwechete inovimbisa seye [`Iterator::size_hint`] basa.
    ///
    /// [trait-level]: ExactSizeIterator
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// // renji renji rinonyatsoziva kangani kuti richaitisa
    /// let five = 0..5;
    ///
    /// assert_eq!(5, five.len());
    /// ```
    ///
    ///
    #[doc(alias = "length")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn len(&self) -> usize {
        let (lower, upper) = self.size_hint();
        // Note: Ichi chirevo chinonyanya kuzvidzivirira, asi chinotarisa chinogara chiripo
        // kuvimbiswa ne trait.
        // Kana iyi trait yaive rust-yemukati, tinogona kushandisa debug_assert !;assert_eq!inotarisa ese Rust mushandisi ekushandisa futi.
        //
        assert_eq!(upper, Some(lower));
        lower
    }

    /// Inodzorera `true` kana iterator isina chinhu.
    ///
    /// Iyi nzira ine yekumisikidza kuitisa uchishandisa [`ExactSizeIterator::len()`], saka haufanire kuzviita iwe pachako.
    ///
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// #![feature(exact_size_is_empty)]
    ///
    /// let mut one_element = std::iter::once(0);
    /// assert!(!one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), Some(0));
    /// assert!(one_element.is_empty());
    ///
    /// assert_eq!(one_element.next(), None);
    /// ```
    #[inline]
    #[unstable(feature = "exact_size_is_empty", issue = "35428")]
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: ExactSizeIterator + ?Sized> ExactSizeIterator for &mut I {
    fn len(&self) -> usize {
        (**self).len()
    }
    fn is_empty(&self) -> bool {
        (**self).is_empty()
    }
}