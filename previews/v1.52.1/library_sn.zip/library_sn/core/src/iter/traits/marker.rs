/// Iyo iterator iyo inogara ichienderera kuburitsa `None` kana yapera simba.
///
/// Kufona kunotevera pane yakasanganiswa iterator iyo yakadzosa `None` kamwe yakavimbiswa kudzosa [`None`] zvakare.
/// Iyi trait inofanirwa kuitiswa nema iterator ese anozvibata nenzira iyi nekuti inobvumira kugadzirisa [`Iterator::fuse()`].
///
///
/// Note: Kazhinji, haufanire kushandisa `FusedIterator` mune generic mabound kana iwe uchida fused iterator.
/// Panzvimbo iyoyo, iwe unofanirwa kungodaidza [`Iterator::fuse()`] pane iterator.
/// Kana iyo iterator yatove yakasanganiswa, iyo yekuwedzera [`Fuse`] inoputira ichave isina-op isina chirango chekuita.
///
/// [`Fuse`]: crate::iter::Fuse
///
#[stable(feature = "fused", since = "1.26.0")]
#[rustc_unsafe_specialization_marker]
pub trait FusedIterator: Iterator {}

#[stable(feature = "fused", since = "1.26.0")]
impl<I: FusedIterator + ?Sized> FusedIterator for &mut I {}

/// Iyo iterator inoshuma iyo chaiyo urefu uchishandisa size_hint.
///
/// Iyo iterator inoshuma saizi hint uko ingave iri chaiyo (yakadzika yakasungwa yakaenzana neyekumusoro yakasungwa), kana iyo yepamusoro yakasungwa i [`None`].
///
/// Iyo yakasungwa yepamusoro inofanira kungova [`None`] kana iyo chaiyo iterator kureba iri yakakura kupfuura [`usize::MAX`].
/// Muchiitiko ichocho, yakasungwa yakasungirwa inofanirwa kunge iri [`usize::MAX`], zvichikonzera [`Iterator::size_hint()`] ye `(usize::MAX, None)`.
///
/// Iyo iterator inofanirwa kuburitsa chaizvo iyo nhamba yezvinhu zvayakamhan'ara kana kutsauka isati yasvika kumagumo.
///
/// # Safety
///
/// Iyi trait inofanira kungoitwa chete kana chibvumirano chikasimudzwa.
/// Vatengi veiyi trait vanofanirwa kuongorora [`Iterator::size_hint()`]’s yepamusoro yakasungwa.
///
///
///
#[unstable(feature = "trusted_len", issue = "37572")]
#[rustc_unsafe_specialization_marker]
pub unsafe trait TrustedLen: Iterator {}

#[unstable(feature = "trusted_len", issue = "37572")]
unsafe impl<I: TrustedLen + ?Sized> TrustedLen for &mut I {}

/// Iyo iterator iyo painoburitsa chinhu ichave yatora chinenge chinhu chimwe kubva kune yayo yepasi [`SourceIter`].
///
/// Kufona chero nzira inosimudzira iyo iterator, semuenzaniso
/// [`next()`] kana [`try_fold()`], inovimbisa kuti padanho rega rega imwe kukosha kweiyo iterator sosi sosi yakaburitswa kunze uye mhedzisiro yeketani yacho inogona kuiswa munzvimbo yayo, tichifungidzira zvimisikidzo zvechisimba zvinobvumidza kuiswa kwakadaro.
///
/// Mune mamwe mazwi iyi trait inoratidza kuti iyo iterator pombi inogona kuunganidzwa munzvimbo.
///
/// [`SourceIter`]: crate::iter::SourceIter
/// [`next()`]: Iterator::next
/// [`try_fold()`]: Iterator::try_fold
///
///
#[unstable(issue = "none", feature = "inplace_iteration")]
pub unsafe trait InPlaceIterable: Iterator {}