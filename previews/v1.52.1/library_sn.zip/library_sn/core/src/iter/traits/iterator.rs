// ignore-tidy-filelength Iyi faira ingangoita chete ine tsananguro ye `Iterator`.
// Hatigone kupatsanura izvozvo kuita mafaera mazhinji
//

use crate::cmp::{self, Ordering};
use crate::ops::{ControlFlow, Try};

use super::super::TrustedRandomAccess;
use super::super::{Chain, Cloned, Copied, Cycle, Enumerate, Filter, FilterMap, Fuse};
use super::super::{FlatMap, Flatten};
use super::super::{FromIterator, Intersperse, IntersperseWith, Product, Sum, Zip};
use super::super::{
    Inspect, Map, MapWhile, Peekable, Rev, Scan, Skip, SkipWhile, StepBy, Take, TakeWhile,
};

fn _assert_is_object_safe(_: &dyn Iterator<Item = ()>) {}

/// Chinongedzo chekubata nema iterators.
///
/// Iyi ndiyo huru iterator trait.
/// Kuti uwane zvimwe nezve iyo pfungwa yeva iterator kazhinji, ndapota ona [module-level documentation].
/// Kunyanya, iwe ungangoda kuziva maitiro ku [implement `Iterator`][impl].
///
/// [module-level documentation]: crate::iter
/// [impl]: crate::iter#implementing-iterator
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_on_unimplemented(
    on(
        _Self = "[std::ops::Range<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..end]` is an array of one `Range`; you might have meant to have a `Range` \
                without the brackets: `start..end`"
    ),
    on(
        _Self = "[std::ops::RangeFrom<Idx>; 1]",
        label = "if you meant to iterate from a value onwards, remove the square brackets",
        note = "`[start..]` is an array of one `RangeFrom`; you might have meant to have a \
              `RangeFrom` without the brackets: `start..`, keeping in mind that iterating over an \
              unbounded iterator will run forever unless you `break` or `return` from within the \
              loop"
    ),
    on(
        _Self = "[std::ops::RangeTo<Idx>; 1]",
        label = "if you meant to iterate until a value, remove the square brackets and add a \
                 starting value",
        note = "`[..end]` is an array of one `RangeTo`; you might have meant to have a bounded \
                `Range` without the brackets: `0..end`"
    ),
    on(
        _Self = "[std::ops::RangeInclusive<Idx>; 1]",
        label = "if you meant to iterate between two values, remove the square brackets",
        note = "`[start..=end]` is an array of one `RangeInclusive`; you might have meant to have a \
              `RangeInclusive` without the brackets: `start..=end`"
    ),
    on(
        _Self = "[std::ops::RangeToInclusive<Idx>; 1]",
        label = "if you meant to iterate until a value (including it), remove the square brackets \
                 and add a starting value",
        note = "`[..=end]` is an array of one `RangeToInclusive`; you might have meant to have a \
                bounded `RangeInclusive` without the brackets: `0..=end`"
    ),
    on(
        _Self = "std::ops::RangeTo<Idx>",
        label = "if you meant to iterate until a value, add a starting value",
        note = "`..end` is a `RangeTo`, which cannot be iterated on; you might have meant to have a \
              bounded `Range`: `0..end`"
    ),
    on(
        _Self = "std::ops::RangeToInclusive<Idx>",
        label = "if you meant to iterate until a value (including it), add a starting value",
        note = "`..=end` is a `RangeToInclusive`, which cannot be iterated on; you might have meant \
              to have a bounded `RangeInclusive`: `0..=end`"
    ),
    on(
        _Self = "&str",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "std::string::String",
        label = "`{Self}` is not an iterator; try calling `.chars()` or `.bytes()`"
    ),
    on(
        _Self = "[]",
        label = "borrow the array with `&` or call `.iter()` on it to iterate over it",
        note = "arrays are not iterators, but slices like the following are: `&[1, 2, 3]`"
    ),
    on(
        _Self = "{integral}",
        note = "if you want to iterate between `start` until a value `end`, use the exclusive range \
              syntax `start..end` or the inclusive range syntax `start..=end`"
    ),
    label = "`{Self}` is not an iterator",
    message = "`{Self}` is not an iterator"
)]
#[doc(spotlight)]
#[rustc_diagnostic_item = "Iterator"]
#[must_use = "iterators are lazy and do nothing unless consumed"]
pub trait Iterator {
    /// Rudzi rwezvinhu zviri kuitirwa pamusoro.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Item;

    /// Inofambira mberi iterator uye inodzosera iyo inotevera kukosha.
    ///
    /// Inodzorera [`None`] kana iteration yapera.
    /// Kuita kwega kwega iterator kunogona kusarudza kuitazve iteration, nekudaro kudaidza `next()` zvakare kunogona kana kusazotanga kudzosa [`Some(Item)`] zvakare pane imwe nguva.
    ///
    ///
    /// [`Some(Item)`]: Some
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // Kufona ku next() kunodzosera iyo inotevera kukosha ...
    /// assert_eq!(Some(&1), iter.next());
    /// assert_eq!(Some(&2), iter.next());
    /// assert_eq!(Some(&3), iter.next());
    ///
    /// // ... uyezve Hakuna kana zvapera.
    /// assert_eq!(None, iter.next());
    ///
    /// // Dzimwe nhare dzinogona kana kusadzorera `None`.Pano, vanogara vachidaro.
    /// assert_eq!(None, iter.next());
    /// assert_eq!(None, iter.next());
    /// ```
    ///
    #[lang = "next"]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn next(&mut self) -> Option<Self::Item>;

    /// Inodzorera miganho pane yakasara kureba kweterator.
    ///
    /// Zvikurukuru, `size_hint()` inodzosera Tuple uko yekutanga chinhu chiri chepazasi chakasungwa, uye chechipiri chinhu chiri chepamusoro chakasungwa.
    ///
    /// Hafu yechipiri yeTuple iyo inodzoserwa i [`Sarudzo`]`<`[`usize`] `>`.
    /// A [`None`] pano zvinoreva kuti kana pasina chinozivikanwa chepamusoro chakasungwa, kana chekumusoro chakakura kupfuura [`usize`].
    ///
    /// # Kuteedzera manotsi
    ///
    /// Izvo hazvimanikidzwe kuti kuitisa iterator kuburitsa yakaziviswa nhamba yezvinhu.Iyo buger iterator inogona kuburitsa yakaderera pane yakasara yakasungwa kana kupfuura kupfuura yekumusoro yakasungwa yezvinhu.
    ///
    /// `size_hint()` inonyanya kuitirwa kushandiswa kwe optimizations senge kuchengetera nzvimbo yezvinhu zveiyo iterator, asi haifanire kuvimbwa nayo semuenzaniso, siya mabound bheki cheki isina kuchengetedzeka kodhi.
    /// Kuitwa zvisirizvo kwe `size_hint()` hakufanirwe kutungamira mukutyora kwekuchengetedza kwendangariro.
    ///
    /// Izvo zvakati, kuiswa kwacho kunofanirwa kupa fungidziro chaiyo, nekuti zvikasadaro kunenge kuri kutyora mutemo we trait.
    ///
    /// Iyo yekumisikidza kuitisa inodzosera `(0,` [`Hapana`]`)`iri iro rakanakira chero iterator.
    ///
    /// [`usize`]: type@usize
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let iter = a.iter();
    ///
    /// assert_eq!((3, Some(3)), iter.size_hint());
    /// ```
    ///
    /// Muenzaniso wakaomesesa:
    ///
    /// ```
    /// // Iwo akaenzana manhamba kubva zero kusvika gumi.
    /// let iter = (0..10).filter(|x| x % 2 == 0);
    ///
    /// // Tinogona kuwedzera kubva zero kusvika kagumi.
    /// // Kuziva kuti zvishanu chaizvo zvaisazogoneka pasina kuuraya filter().
    /// assert_eq!((0, Some(10)), iter.size_hint());
    ///
    /// // Ngatitorei mamwe manhamba mashanu ne chain()
    /// let iter = (0..10).filter(|x| x % 2 == 0).chain(15..20);
    ///
    /// // ikozvino miganhu miviri yakawedzerwa neshanu
    /// assert_eq!((5, Some(15)), iter.size_hint());
    /// ```
    ///
    /// Kudzosera `None` kune yakasungwa yakasungwa:
    ///
    /// ```
    /// // isingagumi iterator haina yepamusoro yakasungwa uye yakanyanya inogoneka yakadzika yakasungwa
    /////
    /// let iter = 0..;
    ///
    /// assert_eq!((usize::MAX, None), iter.size_hint());
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, None)
    }

    /// Inoshandisa iyo iterator, kuverenga iyo nhamba yekudzokororwa uye kuidzosera.
    ///
    /// Iyi nzira ichafonera [`next`] yakadzokororwa kusvika [`None`] yasangana, ichidzosera iyo nhamba yenguva iyo yakaona [`Some`].
    /// Ziva kuti [`next`] inofanirwa kudaidzwa kanenge kamwe kunyangwe iyo iterator isina chero chinhu.
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Kufashukira Maitiro
    ///
    /// Iyo nzira haina chekuchengetedza pamusoro pekufashukira, saka kuverenga zvinhu zveiyo iterator ine zvinopfuura [`usize::MAX`] zvinhu zvinogona kuburitsa isiriyo mhedzisiro kana panics.
    ///
    /// Kana zvirevo zvekugadzirisa zvikabvumidzwa, panic inovimbiswa.
    ///
    /// # Panics
    ///
    /// Iri basa rinogona panic kana iyo iterator iine zvinopfuura [`usize::MAX`] zvinhu.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().count(), 3);
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().count(), 5);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn count(self) -> usize
    where
        Self: Sized,
    {
        self.fold(
            0,
            #[rustc_inherit_overflow_checks]
            |count, _| count + 1,
        )
    }

    /// Inoshandisa iyo iterator, ichidzorera iyo yekupedzisira chinhu.
    ///
    /// Iyi nzira ichaongorora iyo iterator kudzamara yadzoka [`None`].
    /// Ipo ichidaro, inoteedzera yezvazvino chinhu.
    /// Mushure mekunge [`None`] yadzoserwa, `last()` ichazodzorera chinhu chekupedzisira icho chaakaona.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().last(), Some(&3));
    ///
    /// let a = [1, 2, 3, 4, 5];
    /// assert_eq!(a.iter().last(), Some(&5));
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn last(self) -> Option<Self::Item>
    where
        Self: Sized,
    {
        #[inline]
        fn some<T>(_: Option<T>, x: T) -> Option<T> {
            Some(x)
        }

        self.fold(None, some)
    }

    /// Inofambira mberi iterator ne `n` zvinhu.
    ///
    /// Iyi nzira ichasvetuka nechido `n` zvinhu nekufonera [`next`] kusvika ku `n` nguva kusvikira [`None`] yasangana.
    ///
    /// `advance_by(n)` inodzosa [`Ok(())`][Ok] kana iterator ikabudirira kufambira mberi ne `n` zvinhu, kana [`Err(k)`][Err] kana [`None`] yasangana, uko `k` ndiyo nhamba yezvinhu iyo iterator yakafambiswa isati yapera zvinhu (kureva.
    /// kureba kweterator).
    /// Ziva kuti `k` inogara iri pasi pe `n`.
    ///
    /// Kufonera `advance_by(0)` hakuiti chero chinhu uye kunogara kuchidzosa [`Ok(())`][Ok].
    ///
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// #![feature(iter_advance_by)]
    ///
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.advance_by(2), Ok(()));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.advance_by(0), Ok(()));
    /// assert_eq!(iter.advance_by(100), Err(1)); // `&4` chete ndiyo yakasvetwa
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_advance_by", reason = "recently added", issue = "77404")]
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        for i in 0..n {
            self.next().ok_or(i)?;
        }
        Ok(())
    }

    /// Inodzorera `n`th element yeiyo iterator.
    ///
    /// Kufanana nekuwanda kwekuita indexing, kuverenga kunotanga kubva zero, saka `nth(0)` inodzosera kukosha kwekutanga, `nth(1)` yechipiri, zvichingodaro.
    ///
    /// Ziva kuti zvese zvakatangira zvinhu, pamwe nechinhu chakadzoserwa, zvichapedzwa kubva kune iterator.
    /// Izvi zvinoreva kuti zvinhu zvakatangira izvi zvicharaswa, uye zvakare kudaidza `nth(0)` kakawanda pane imwechete iterator kunodzosa zvinhu zvakasiyana.
    ///
    ///
    /// `nth()` inodzosa [`None`] kana `n` yakakura kudarika kana yakaenzana nehurefu hwetereta.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(1), Some(&2));
    /// ```
    ///
    /// Kufonera `nth()` kakawanda hakudzosere iterator:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.nth(1), Some(&2));
    /// assert_eq!(iter.nth(1), None);
    /// ```
    ///
    /// Kudzosera `None` kana paine zvishoma pane `n + 1` zvinhu:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// assert_eq!(a.iter().nth(10), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        self.advance_by(n).ok()?;
        self.next()
    }

    /// Inogadzira iterator inotanga panguva imwechete, asi ichitsika nemari yakapihwa pane imwe iteration.
    ///
    /// Ongorora 1: Chekutanga chinhu cheiyo iterator inogara ichidzoserwa, zvisinei nedanho rakapihwa.
    ///
    /// Cherekedza 2: Iyo nguva iyo zvinhu zvisina hanya zvinodhonzwa haina kugadziriswa.
    /// `StepBy` inoita seyakateedzana `next(), nth(step-1), nth(step-1),…`, asi zvakare yakasununguka kuita seyakateedzana
    ///
    /// `advance_n_and_return_first(step), advance_n_and_return_first(step), …`
    /// Ndeipi nzira inoshandiswa inogona kuchinja kune vamwe iterators nezvikonzero zvekuita.
    /// Nzira yechipiri ichaendesa mberi iterator pakutanga uye inogona kutora zvimwe zvinhu.
    ///
    /// `advance_n_and_return_first` yakaenzana ne:
    ///
    /// ```
    /// fn advance_n_and_return_first<I>(iter: &mut I, total_step: usize) -> Option<I::Item>
    /// where
    ///     I: Iterator,
    /// {
    ///     let next = iter.next();
    ///     if total_step > 1 {
    ///         iter.nth(total_step-2);
    ///     }
    ///     next
    /// }
    /// ```
    ///
    /// # Panics
    ///
    /// Iyo nzira ichaita panic kana danho rakapihwa riri `0`.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = [0, 1, 2, 3, 4, 5];
    /// let mut iter = a.iter().step_by(2);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_step_by", since = "1.28.0")]
    fn step_by(self, step: usize) -> StepBy<Self>
    where
        Self: Sized,
    {
        StepBy::new(self, step)
    }

    /// Inotora mairi iterator uye inogadzira iterator nyowani pamusoro pezvose zviri zviviri zvichiteedzana.
    ///
    /// `chain()` inodzosera iterator nyowani iyo inotanga kuitisa pamusoro pemitengo kubva kune yekutanga iterator uyezve pamusoro pemitengo kubva kune yechipiri iterator.
    ///
    /// Mune mamwe mazwi, inobatanidza maiterator maviri pamwechete, muketani.🔗
    ///
    /// [`once`] inowanzo shandiswa kuchinjisa imwechete kukosha muketani yemamwe marudzi eiyo iteration.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().chain(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Sezvo nharo ku `chain()` ichishandisa [`IntoIterator`], tinogona kupfuudza chero chinhu chingashandurwe kuva [`Iterator`], kwete chete [`Iterator`] pachayo.
    /// Semuenzaniso, zvidimbu (`&[T]`) zvinoshandisa [`IntoIterator`], uye saka zvinogona kupfuudzwa ku `chain()` zvakananga:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().chain(s2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&4));
    /// assert_eq!(iter.next(), Some(&5));
    /// assert_eq!(iter.next(), Some(&6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kana iwe ukashanda ne Windows API, unogona kuda kushandura [`OsStr`] kuita `Vec<u16>`:
    ///
    /// ```
    /// #[cfg(windows)]
    /// fn os_str_to_utf16(s: &std::ffi::OsStr) -> Vec<u16> {
    ///     use std::os::windows::ffi::OsStrExt;
    ///     s.encode_wide().chain(std::iter::once(0)).collect()
    /// }
    /// ```
    ///
    /// [`once`]: crate::iter::once
    /// [`OsStr`]: ../../std/ffi/struct.OsStr.html
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn chain<U>(self, other: U) -> Chain<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator<Item = Self::Item>,
    {
        Chain::new(self, other.into_iter())
    }

    /// 'Zips kumusoro' maviri maiterator kuita imwechete iterator yevaviri.
    ///
    /// `zip()` inodzosera iterator nyowani inozo iterate pamusoro pevamwe vaviri maiteri, ichidzosera Tuple uko yekutanga element inouya kubva kune yekutanga iterator, uye chechipiri chinhu chinobva kune yechipiri iterator.
    ///
    ///
    /// Mune mamwe mazwi, inotungira maiterator maviri pamwechete, kuita imwechete.
    ///
    /// Kana imwe iterator ikadzosa [`None`], [`next`] kubva kune zipped iterator inodzosa [`None`].
    /// Kana iyo yekutanga iterator ikadzosa [`None`], `zip` ichaita pfupi-dunhu uye `next` haizodaidzwe pane yechipiri iterator.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a1 = [1, 2, 3];
    /// let a2 = [4, 5, 6];
    ///
    /// let mut iter = a1.iter().zip(a2.iter());
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Sezvo nharo ku `zip()` ichishandisa [`IntoIterator`], tinogona kupfuudza chero chinhu chingashandurwe kuva [`Iterator`], kwete chete [`Iterator`] pachayo.
    /// Semuenzaniso, zvidimbu (`&[T]`) zvinoshandisa [`IntoIterator`], uye saka zvinogona kupfuudzwa ku `zip()` zvakananga:
    ///
    /// ```
    /// let s1 = &[1, 2, 3];
    /// let s2 = &[4, 5, 6];
    ///
    /// let mut iter = s1.iter().zip(s2);
    ///
    /// assert_eq!(iter.next(), Some((&1, &4)));
    /// assert_eq!(iter.next(), Some((&2, &5)));
    /// assert_eq!(iter.next(), Some((&3, &6)));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `zip()` inowanzo shandiswa kupopera isingagumi iterator kune ine muganho.
    /// Izvi zvinoshanda nekuti iyo inogumira iterator inozopedzisira yadzoka [`None`], ichipedza zipi.Zip ne `(0..)` inogona kutaridzika zvakanyanya se [`enumerate`]:
    ///
    /// ```
    /// let enumerate: Vec<_> = "foo".chars().enumerate().collect();
    ///
    /// let zipper: Vec<_> = (0..).zip("foo".chars()).collect();
    ///
    /// assert_eq!((0, 'f'), enumerate[0]);
    /// assert_eq!((0, 'f'), zipper[0]);
    ///
    /// assert_eq!((1, 'o'), enumerate[1]);
    /// assert_eq!((1, 'o'), zipper[1]);
    ///
    /// assert_eq!((2, 'o'), enumerate[2]);
    /// assert_eq!((2, 'o'), zipper[2]);
    /// ```
    ///
    /// [`enumerate`]: Iterator::enumerate
    /// [`next`]: Iterator::next
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn zip<U>(self, other: U) -> Zip<Self, U::IntoIter>
    where
        Self: Sized,
        U: IntoIterator,
    {
        Zip::new(self, other.into_iter())
    }

    /// Inogadzira iterator nyowani inoisa kopi ye `separator` pakati pezvinhu zviri padyo zveiyo yekutanga iterator.
    ///
    /// Kana `separator` isingaite [`Clone`] kana inoda kuverengerwa nguva dzese, shandisa [`intersperse_with`].
    ///
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let mut a = [0, 1, 2].iter().intersperse(&100);
    /// assert_eq!(a.next(), Some(&0));   // Chinhu chekutanga kubva ku `a`.
    /// assert_eq!(a.next(), Some(&100)); // Muparadzanisi.
    /// assert_eq!(a.next(), Some(&1));   // Chinhu chinotevera kubva ku `a`.
    /// assert_eq!(a.next(), Some(&100)); // Muparadzanisi.
    /// assert_eq!(a.next(), Some(&2));   // Chinhu chekupedzisira kubva ku `a`.
    /// assert_eq!(a.next(), None);       // Iyo iterator yapera.
    /// ```
    ///
    /// `intersperse` inogona kubatsira zvakanyanya kujoina zvinhu zveitator uchishandisa chinhu chakajairika:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let hello = ["Hello", "World", "!"].iter().copied().intersperse(" ").collect::<String>();
    /// assert_eq!(hello, "Hello World !");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse_with`]: Iterator::intersperse_with
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse(self, separator: Self::Item) -> Intersperse<Self>
    where
        Self: Sized,
        Self::Item: Clone,
    {
        Intersperse::new(self, separator)
    }

    /// Inogadzira iterator nyowani inoisa chinhu chinogadzirwa ne `separator` pakati pezvinhu zviri padyo zveiyo yekutanga iterator.
    ///
    /// Kuvhara kunodaidzwa chaizvo kamwe chete nguva yega yega chinhu painoiswa pakati pezvinhu zviviri zviri padhuze kubva kune iripasi iterator;
    /// chaizvo, kuvhara hakuna kudaidzwa kana iyo yepasi iterator ichiburitsa zvishoma pane zviviri zvinhu uye mushure mekunge chinhu chekupedzisira chaburitswa.
    ///
    ///
    /// Kana iyo iterator ikashandisa [`Clone`], zvinogona kuve nyore kushandisa [`intersperse`].
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// #[derive(PartialEq, Debug)]
    /// struct NotClone(usize);
    ///
    /// let v = vec![NotClone(0), NotClone(1), NotClone(2)];
    /// let mut it = v.into_iter().intersperse_with(|| NotClone(99));
    ///
    /// assert_eq!(it.next(), Some(NotClone(0)));  // Chinhu chekutanga kubva ku `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Muparadzanisi.
    /// assert_eq!(it.next(), Some(NotClone(1)));  // Chinhu chinotevera kubva ku `v`.
    /// assert_eq!(it.next(), Some(NotClone(99))); // Muparadzanisi.
    /// assert_eq!(it.next(), Some(NotClone(2)));  // Chinhu chekupedzisira kubva ku `v`.
    /// assert_eq!(it.next(), None);               // Iyo iterator yapera.
    /// ```
    ///
    /// `intersperse_with` inogona kushandiswa mumamiriro ezvinhu apo iyo separator inoda kuverengerwa:
    ///
    /// ```
    /// #![feature(iter_intersperse)]
    ///
    /// let src = ["Hello", "to", "all", "people", "!!"].iter().copied();
    ///
    /// // Kuvhara zvinokwereta zvinokweretesa mamiriro ayo kuburitsa chinhu.
    /// let mut happy_emojis = [" ❤️ ", " 😀 "].iter().copied();
    /// let separator = || happy_emojis.next().unwrap_or(" 🦀 ");
    ///
    /// let result = src.intersperse_with(separator).collect::<String>();
    /// assert_eq!(result, "Hello ❤️ to 😀 all 🦀 people 🦀 !!");
    /// ```
    ///
    /// [`Clone`]: crate::clone::Clone
    /// [`intersperse`]: Iterator::intersperse
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_intersperse", reason = "recently added", issue = "79524")]
    fn intersperse_with<G>(self, separator: G) -> IntersperseWith<Self, G>
    where
        Self: Sized,
        G: FnMut() -> Self::Item,
    {
        IntersperseWith::new(self, separator)
    }

    /// Inotora kuvhara uye inogadzira iyo iterator iyo inodaidzira iko kuvharwa pane chimwe nechimwe chinhu.
    ///
    /// `map()` inoshandura imwe iterator kuita imwe, kuburikidza nenharo yayo:
    /// chimwe chinhu chinoshandisa [`FnMut`].Inogadzira iterator nyowani inodaidza kuvharwa uku pane chimwe nechimwe chinhu cheiyo yekutanga iterator.
    ///
    /// Kana iwe uri kugona kufunga mumhando, unogona kufunga nezve `map()` seizvi:
    /// Kana iwe uine iterator inokupa zvinhu zveimwe mhando `A`, uye iwe uchida iterator yeimwe mhando `B`, unogona kushandisa `map()`, kupfuudza kuvhara kunotora `A` uye kunodzosera `B`.
    ///
    ///
    /// `map()` zvine pfungwa zvakafanana neiyo [`for`] chiuno.Nekudaro, sezvo `map()` iri simbe, inoshandiswa zvirinani kana uchinge uchinge uchinge uchinge uchishanda nevamwe ma iterator.
    /// Kana iwe urikuita imwe mhando yekukochekera kweimwe divi mhedzisiro, inoonekwa seyakawedzera idiomatic kushandisa [`for`] kupfuura `map()`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    /// [`FnMut`]: crate::ops::FnMut
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().map(|x| 2 * x);
    ///
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), Some(6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kana iwe uri kuita imwe mhando yemhedzisiro mhedzisiro, sarudza [`for`] kusvika `map()`:
    ///
    /// ```
    /// # #![allow(unused_must_use)]
    /// // usaite izvi:
    /// (0..5).map(|x| println!("{}", x));
    ///
    /// // haina kana kuuraya, sezvo iine husimbe.Rust inokunyevera nezve izvi.
    ///
    /// // Pane kudaro, shandisa for:
    /// for x in 0..5 {
    ///     println!("{}", x);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn map<B, F>(self, f: F) -> Map<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> B,
    {
        Map::new(self, f)
    }

    /// Inodaidza kuvhara pane chimwe nechimwe chinhu cheiyo iterator.
    ///
    /// Izvi zvakaenzana nekushandisa [`for`] chiuno pane iyo iterator, kunyange `break` ne `continue` zvisingaiti kubva pakuvharwa.
    /// Kazhinji zvinowanzoita idiomatic kushandisa `for` chiuno, asi `for_each` inogona kuve inonzwisisika kana uchigadzirisa zvinhu pakupera kwenguva refu iterator ngetani.
    ///
    /// Mune zvimwe zviitiko `for_each` inogona zvakare kukurumidza kupfuura chiuno, nekuti ichazoshandisa iteration yemukati pane maadapter akaita se `Chain`.
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// use std::sync::mpsc::channel;
    ///
    /// let (tx, rx) = channel();
    /// (0..5).map(|x| x * 2 + 1)
    ///       .for_each(move |x| tx.send(x).unwrap());
    ///
    /// let v: Vec<_> =  rx.iter().collect();
    /// assert_eq!(v, vec![1, 3, 5, 7, 9]);
    /// ```
    ///
    /// Semuenzaniso mudiki wakadai, `for` chiuno chingave chakachena, asi `for_each` inogona kunge iri nani kuti ichengetedze chimiro chinoshanda nema iterator akareba:
    ///
    /// ```
    /// (0..5).flat_map(|x| x * 100 .. x * 110)
    ///       .enumerate()
    ///       .filter(|&(i, x)| (i + x) % 3 == 0)
    ///       .for_each(|(i, x)| println!("{}:{}", i, x));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_for_each", since = "1.21.0")]
    fn for_each<F>(self, f: F)
    where
        Self: Sized,
        F: FnMut(Self::Item),
    {
        #[inline]
        fn call<T>(mut f: impl FnMut(T)) -> impl FnMut((), T) {
            move |(), item| f(item)
        }

        self.fold((), call(f));
    }

    /// Inogadzira iterator iyo inoshandisa kuvhara kuona kuti chinhu chinofanira kuburitswa.
    ///
    /// Kupiwa chinhu kuvharwa kunofanirwa kudzosa `true` kana `false`.Iyo inodzosera iterator ichaburitsa chete izvo zvinhu izvo iko kuvhara kunodzoka kwechokwadi.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = [0i32, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| x.is_positive());
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Nekuti kuvharwa kwakapfuudzwa ku `filter()` kunotora chirevo, uye maiterator mazhinji anorerekera pamusoro pezvinongedzo, izvi zvinotungamira kune zvingangovhiringidza mamiriro, uko mhando yekuvhara iri mbiri chirevo:
    ///
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|x| **x > 1); // inoda maviri * s!
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Zvakajairika kuti panzvimbo pekushandisa kuputsa pane nharo kubvisa imwe:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&x| *x > 1); // zvese&uye *
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// kana ese ari maviri:
    ///
    /// ```
    /// let a = [0, 1, 2];
    ///
    /// let mut iter = a.iter().filter(|&&x| x > 1); // maviri &s
    ///
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// yezvikamu izvi.
    ///
    /// Ziva kuti `iter.filter(f).next()` yakaenzana ne `iter.find(f)`.
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter<P>(self, predicate: P) -> Filter<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        Filter::new(self, predicate)
    }

    /// Inogadzira iterator iyo zvese mafirita nemamepu.
    ///
    /// Iyo inodzosera iterator inoburitsa chete iyo `kukosha`s iko iko kwayakapiwa kuvhara kunodzosera `Some(value)`.
    ///
    /// `filter_map` inogona kushandiswa kugadzira ngetani dze [`filter`] uye [`map`] zvakapfupika.
    /// Muenzaniso uri pazasi unoratidza kuti `map().filter().map()` inogona kupfupikiswa sei kune imwechete kufona ku `filter_map`.
    ///
    ///
    /// [`filter`]: Iterator::filter
    /// [`map`]: Iterator::map
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    ///
    /// let mut iter = a.iter().filter_map(|s| s.parse().ok());
    ///
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Heino muenzaniso mumwe chete, asi ne [`filter`] uye [`map`]:
    ///
    /// ```
    /// let a = ["1", "two", "NaN", "four", "5"];
    /// let mut iter = a.iter().map(|s| s.parse()).filter(|s| s.is_ok()).map(|s| s.unwrap());
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(5));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn filter_map<B, F>(self, f: F) -> FilterMap<Self, F>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        FilterMap::new(self, f)
    }

    /// Inogadzira iterator iyo inopa ikozvino iteration kuverenga pamwe neinotevera kukosha.
    ///
    /// Iyo iterator yakadzosera goho mapara `(i, val)`, uko `i` ndiyo iripo indekisi yeiteration uye `val` ndiyo kukosha kwakadzoserwa neiyo iterator.
    ///
    ///
    /// `enumerate()` inochengeta kuverenga kwayo se [`usize`].
    /// Kana iwe uchida kuverenga nehukuru hwakasiyana huwandu, iro [`zip`] basa rinopa zvakafanana kushanda.
    ///
    /// # Kufashukira Maitiro
    ///
    /// Iyo nzira haina chekuchengetedza pamusoro pemafashama, saka kuverenga zvinopfuura [`usize::MAX`] zvinhu zvinogona kuburitsa mhedzisiro isiriyo kana panics.
    /// Kana zvirevo zvekugadzirisa zvikabvumidzwa, panic inovimbiswa.
    ///
    /// # Panics
    ///
    /// Iyo yakadzoserwa iterator inogona panic kana iyo-yekudzoserwa index ichizadza [`usize`].
    ///
    /// [`usize`]: type@usize
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ['a', 'b', 'c'];
    ///
    /// let mut iter = a.iter().enumerate();
    ///
    /// assert_eq!(iter.next(), Some((0, &'a')));
    /// assert_eq!(iter.next(), Some((1, &'b')));
    /// assert_eq!(iter.next(), Some((2, &'c')));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn enumerate(self) -> Enumerate<Self>
    where
        Self: Sized,
    {
        Enumerate::new(self)
    }

    /// Inogadzira iterator iyo inogona kushandisa [`peek`] kutarisa kune chinotevera chinhu cheiyo iterator pasina kuishandisa.
    ///
    /// Inowedzera nzira ye [`peek`] kune iterator.Ona zvinyorwa zvaro kuti uwane rumwe ruzivo.
    ///
    /// Ziva kuti iterator yepasi ichiri kumberi apo [`peek`] inodaidzwa kekutanga: Kuti utore chinotevera chinhu, [`next`] inodaidzwa kune inoitisa iterator, saka chero mhedzisiro (kureva.
    ///
    /// chero chinhu kunze kwekutora chinotevera kukosha) cheiyo [`next`] nzira ichaitika.
    ///
    /// [`peek`]: Peekable::peek
    /// [`next`]: Iterator::next
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let xs = [1, 2, 3];
    ///
    /// let mut iter = xs.iter().peekable();
    ///
    /// // peek() ngatitarisei mu future
    /// assert_eq!(iter.peek(), Some(&&1));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), Some(&2));
    ///
    /// // isu tinogona peek() kakawanda, iyo iterator haifambe mberi
    /// assert_eq!(iter.peek(), Some(&&3));
    /// assert_eq!(iter.peek(), Some(&&3));
    ///
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // mushure mekunge iterator yapera, ndozvakaitawo peek()
    /// assert_eq!(iter.peek(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn peekable(self) -> Peekable<Self>
    where
        Self: Sized,
    {
        Peekable::new(self)
    }

    /// Inogadzira iterator iyo [`skip`] yezvinhu zvinoenderana nedanho.
    ///
    /// [`skip`]: Iterator::skip
    ///
    /// `skip_while()` inotora kuvhara sekupokana.Ichadaidza kuvhara uku pachinhu chimwe nechimwe cheiyo iterator, uye osafuratira zvinhu kusvikira yadzoka `false`.
    ///
    /// Mushure mekunge `false` yadzoserwa, `skip_while()`'s basa rapera, uye zvimwe zvese zvinhu zvaburitswa.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Nekuti iko kuvharirwa kwakapfuura `skip_while()` kunotora chirevo, uye maiterator mazhinji anorerekera pamusoro pezvinongedzo, izvi zvinotungamira kune zvingangovhiringidza mamiriro, uko mhando yegakava rekuvhara iri rejere mbiri:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0); // inoda maviri * s!
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kumira mushure mekutanga `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().skip_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&0));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// // nepo izvi zvaizove nhema, sezvo isu tatova nenhema, skip_while() haishandiswezve
    /////
    /// assert_eq!(iter.next(), Some(&-2));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip_while<P>(self, predicate: P) -> SkipWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        SkipWhile::new(self, predicate)
    }

    /// Inogadzira iterator iyo inoburitsa zvinhu zvichibva pane chirevo.
    ///
    /// `take_while()` inotora kuvhara sekupokana.Ichadaidza kuvhara uku pachinhu chimwe nechimwe cheiyo iterator, uye goho zvinhu painodzosa `true`.
    ///
    /// Mushure mekunge `false` yadzoserwa, `take_while()`'s basa rapera, uye zvimwe zvese zvinhu zvatariswa.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = [-1i32, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| x.is_negative());
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Nekuti kuvharwa kwakapfuudzwa ku `take_while()` kunotora chirevo, uye maiterator mazhinji anorerekera pamusoro pezvinongedzo, izvi zvinotungamira kune zvingangovhiringidza mamiriro, uko mhando yekuvhara iri mbiri chirevo:
    ///
    ///
    /// ```
    /// let a = [-1, 0, 1];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0); // inoda maviri * s!
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kumira mushure mekutanga `false`:
    ///
    /// ```
    /// let a = [-1, 0, 1, -2];
    ///
    /// let mut iter = a.iter().take_while(|x| **x < 0);
    ///
    /// assert_eq!(iter.next(), Some(&-1));
    ///
    /// // Tine zvimwe zvinhu zviri pasi pe zero, asi sezvo isu tatova nenhema, take_while() haishandiswezve
    /////
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Nekuti `take_while()` inoda kutarisa kukosha kuitira kuti ione kana ichifanira kuverengerwa kana kwete, vapedzisi vayo vanozoona kuti yabviswa:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<i32> = iter.by_ref()
    ///                            .take_while(|n| **n != 3)
    ///                            .cloned()
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `3` haisisipo, nekuti yaidyiwa kuitira kuti uone kana iyo iteration yaifanira kumira, asi haina kudzoserwa mu iterator.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take_while<P>(self, predicate: P) -> TakeWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        TakeWhile::new(self, predicate)
    }

    /// Inogadzira iterator iyo yese inoburitsa zvinhu zvichibva pane chirevo uye mepu.
    ///
    /// `map_while()` inotora kuvhara sekupokana.
    /// Ichadaidza kuvhara uku pachinhu chimwe nechimwe cheiyo iterator, uye goho zvinhu painodzosa [`Some(_)`][`Some`].
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter().map_while(|x| 16i32.checked_div(*x));
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Heino muenzaniso mumwe chete, asi ne [`take_while`] uye [`map`]:
    ///
    /// [`take_while`]: Iterator::take_while
    /// [`map`]: Iterator::map
    ///
    /// ```
    /// let a = [-1i32, 4, 0, 1];
    ///
    /// let mut iter = a.iter()
    ///                 .map(|x| 16i32.checked_div(*x))
    ///                 .take_while(|x| x.is_some())
    ///                 .map(|x| x.unwrap());
    ///
    /// assert_eq!(iter.next(), Some(-16));
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kumira mushure mekutanga [`None`]:
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [0, 1, 2, -3, 4, 5, -6];
    ///
    /// let iter = a.iter().map_while(|x| u32::try_from(*x).ok());
    /// let vec = iter.collect::<Vec<_>>();
    ///
    /// // Tine zvimwe zvinhu zvinokwana mu u32 (4, 5), asi `map_while` yakadzosa `None` ye `-3` (seiyo `predicate` yakadzosa `None`) uye `collect` inomira pa `None` yekutanga yakasangana.
    /////
    /// assert_eq!(vec, vec![0, 1, 2]);
    /// ```
    ///
    /// Nekuti `map_while()` inoda kutarisa kukosha kuitira kuti ione kana ichifanira kuverengerwa kana kwete, vapedzisi vayo vanozoona kuti yabviswa:
    ///
    ///
    /// ```
    /// #![feature(iter_map_while)]
    /// use std::convert::TryFrom;
    ///
    /// let a = [1, 2, -3, 4];
    /// let mut iter = a.iter();
    ///
    /// let result: Vec<u32> = iter.by_ref()
    ///                            .map_while(|n| u32::try_from(*n).ok())
    ///                            .collect();
    ///
    /// assert_eq!(result, &[1, 2]);
    ///
    /// let result: Vec<i32> = iter.cloned().collect();
    ///
    /// assert_eq!(result, &[4]);
    /// ```
    ///
    /// `-3` haisisipo, nekuti yaidyiwa kuitira kuti uone kana iyo iteration yaifanira kumira, asi haina kudzoserwa mu iterator.
    ///
    /// Ziva kuti kusiyana ne [`take_while`] iyi iterator iri **not** yakasanganiswa.
    /// Izvo zvakare hazvitsanangurwe izvo ino iterator inodzoka mushure mekutanga [`None`] yadzoserwa.
    /// Kana iwe uchida fused iterator, shandisa [`fuse`].
    ///
    /// [`fuse`]: Iterator::fuse
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "iter_map_while", reason = "recently added", issue = "68537")]
    fn map_while<B, P>(self, predicate: P) -> MapWhile<Self, P>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> Option<B>,
    {
        MapWhile::new(self, predicate)
    }

    /// Inogadzira iterator iyo inodarika yekutanga `n` zvinhu.
    ///
    /// Mushure mekunge vapedzwa, zvimwe zvese zvinhu zvinoburitswa.
    /// Panzvimbo pekuwedzeredza nzira iyi zvakananga, pachinopfuura nzira ye `nth`.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().skip(2);
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn skip(self, n: usize) -> Skip<Self>
    where
        Self: Sized,
    {
        Skip::new(self, n)
    }

    /// Inogadzira iterator iyo inoburitsa yayo yekutanga `n` zvinhu.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().take(2);
    ///
    /// assert_eq!(iter.next(), Some(&1));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// `take()` inowanzo shandiswa ine isingaperi iterator, kuti iite ipere:
    ///
    /// ```
    /// let mut iter = (0..).take(3);
    ///
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    /// Kana zviri pasi pe `n` zvinhu zviripo, `take` inozvikwanisa kusvika pahukuru hweiyo iterator yepasi:
    ///
    ///
    /// ```
    /// let v = vec![1, 2];
    /// let mut iter = v.into_iter().take(5);
    /// assert_eq!(iter.next(), Some(1));
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn take(self, n: usize) -> Take<Self>
    where
        Self: Sized,
    {
        Take::new(self, n)
    }

    /// Iyo iterator adapter yakafanana ne [`fold`] inobata mamiriro emukati uye inogadzira iterator nyowani.
    ///
    /// [`fold`]: Iterator::fold
    ///
    /// `scan()` inotora nharo mbiri: kukosha kwekutanga kunodyara mamiriro emukati, uye kuvhara nenharo mbiri, yekutanga kuve chinongedzo chinoshandurwa kune yemukati mamiriro uye yechipiri chinhu iterator.
    ///
    /// Kuvhara kwacho kunogona kupa kune yemukati mamiriro kuti igovane nyika pakati pezviitiko.
    ///
    /// Pane iteration, iko kuvhara kuchaiswa kune yega yega chinhu cheiyo iterator uye iyo yekudzosa kukosha kubva pakuvhara, iyo [`Option`], inoburitswa neiyo iterator.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().scan(1, |state, &x| {
    ///     // imwe neimwe iteration, isu tichawedzera nyika nechinhu
    ///     *state = *state * x;
    ///
    ///     // ipapo, isu tinoburitsa kuramba kwehurumende
    ///     Some(-*state)
    /// });
    ///
    /// assert_eq!(iter.next(), Some(-1));
    /// assert_eq!(iter.next(), Some(-2));
    /// assert_eq!(iter.next(), Some(-6));
    /// assert_eq!(iter.next(), None);
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn scan<St, B, F>(self, initial_state: St, f: F) -> Scan<Self, St, F>
    where
        Self: Sized,
        F: FnMut(&mut St, Self::Item) -> Option<B>,
    {
        Scan::new(self, initial_state, f)
    }

    /// Inogadzira iterator iyo inoshanda senge mepu, asi flattens nested mamiriro.
    ///
    /// Iyo [`map`] adapter inobatsira, asi chete kana iyo yekuvhara nharo ichiburitsa kukosha.
    /// Kana ikaburitsa iterator pachinzvimbo, paine imwe yekuwedzera indirection.
    /// `flat_map()` ichabvisa iyi yekuwedzera yega yega.
    ///
    /// Iwe unogona kufunga nezve `flat_map(f)` seyakafanana semantic ye [`mep`] ping, uyezve [`flatten`] ing se mu `map(f).flatten()`.
    ///
    /// Imwe nzira yekufunga nezve `flat_map()`: [`map`] 's kuvharwa kunodzosa chinhu chimwe chechinhu chimwe nechimwe, uye `flat_map()`'s kuvhara kunodzosera iterator yechinhu chimwe nechimwe.
    ///
    ///
    /// [`map`]: Iterator::map
    /// [`flatten`]: Iterator::flatten
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() inodzosera iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn flat_map<U, F>(self, f: F) -> FlatMap<Self, U, F>
    where
        Self: Sized,
        U: IntoIterator,
        F: FnMut(Self::Item) -> U,
    {
        FlatMap::new(self, f)
    }

    /// Inogadzira iterator iyo inofuratira nested mamiriro.
    ///
    /// Izvi zvinobatsira kana iwe uine iterator yeti iterator kana iyo iterator yezvinhu iyo inogona kushandurwa kuita iterators uye iwe unoda kubvisa imwe nhanho yeirection.
    ///
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let data = vec![vec![1, 2, 3, 4], vec![5, 6]];
    /// let flattened = data.into_iter().flatten().collect::<Vec<u8>>();
    /// assert_eq!(flattened, &[1, 2, 3, 4, 5, 6]);
    /// ```
    ///
    /// Mepu uyezve kugadzikana:
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() inodzosera iterator
    /// let merged: String = words.iter()
    ///                           .map(|s| s.chars())
    ///                           .flatten()
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Iwe unogona zvakare kunyora izvi maererano ne [`flat_map()`], iri nani mune iyi kesi sezvo ichiratidza chinangwa zvakajeka.
    ///
    /// ```
    /// let words = ["alpha", "beta", "gamma"];
    ///
    /// // chars() inodzosera iterator
    /// let merged: String = words.iter()
    ///                           .flat_map(|s| s.chars())
    ///                           .collect();
    /// assert_eq!(merged, "alphabetagamma");
    /// ```
    ///
    /// Flattening chete inobvisa imwe nhanho yekuisa nesting panguva:
    ///
    /// ```
    /// let d3 = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]];
    ///
    /// let d2 = d3.iter().flatten().collect::<Vec<_>>();
    /// assert_eq!(d2, [&[1, 2], &[3, 4], &[5, 6], &[7, 8]]);
    ///
    /// let d1 = d3.iter().flatten().flatten().collect::<Vec<_>>();
    /// assert_eq!(d1, [&1, &2, &3, &4, &5, &6, &7, &8]);
    /// ```
    ///
    /// Pano tinoona kuti `flatten()` haiite "deep" yakatsetseka.
    /// Panzvimbo iyoyo, nhanho imwe chete yekudyara inobviswa.Ndokunge, kana iwe `flatten()` yakarongedzwa nematatu-matatu, mhedzisiro yacho ichave maviri-mativi uye kwete imwe-yemhando.
    /// Kuti uwane chimiro-chimwe-chidimbu, unofanirwa kuenda `flatten()` zvakare.
    ///
    /// [`flat_map()`]: Iterator::flat_map
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_flatten", since = "1.29.0")]
    fn flatten(self) -> Flatten<Self>
    where
        Self: Sized,
        Self::Item: IntoIterator,
    {
        Flatten::new(self)
    }

    /// Inogadzira iterator iyo inopera mushure mekutanga [`None`].
    ///
    /// Mushure mekunge iterator yadzoka [`None`], future mafoni anogona kana anogona kusaburitsa [`Some(T)`] zvakare.
    /// `fuse()` inogadzirisa iyo iterator, ichiona kuti mushure mekunge [`None`] yapihwa, ichagara ichidzoka [`None`] zvachose.
    ///
    ///
    /// [`Some(T)`]: Some
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// // iterator iyo inoshanduka pakati peMamwe uye Hapana
    /// struct Alternate {
    ///     state: i32,
    /// }
    ///
    /// impl Iterator for Alternate {
    ///     type Item = i32;
    ///
    ///     fn next(&mut self) -> Option<i32> {
    ///         let val = self.state;
    ///         self.state = self.state + 1;
    ///
    ///         // kana iri kunyange, Some(i32), kumwe Hakuna
    ///         if val % 2 == 0 {
    ///             Some(val)
    ///         } else {
    ///             None
    ///         }
    ///     }
    /// }
    ///
    /// let mut iter = Alternate { state: 0 };
    ///
    /// // tinogona kuona iterator yedu ichidzokera nekumberi
    /// assert_eq!(iter.next(), Some(0));
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), Some(2));
    /// assert_eq!(iter.next(), None);
    ///
    /// // zvisinei, kana tango fuse ...
    /// let mut iter = iter.fuse();
    ///
    /// assert_eq!(iter.next(), Some(4));
    /// assert_eq!(iter.next(), None);
    ///
    /// // inogara ichidzoka `None` mushure mekutanga nguva.
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fuse(self) -> Fuse<Self>
    where
        Self: Sized,
    {
        Fuse::new(self)
    }

    /// Inoita chimwe chinhu nechinhu chimwe nechimwe cheiyo iterator, ichipfuura kukosha kwacho.
    ///
    /// Paunenge uchishandisa iterators, iwe unowanzo chengeta akati wandei pamwe chete.
    /// Paunenge uchishanda pane yakadaro kodhi, iwe ungangoda kutarisa zviri kuitika munzvimbo dzakasiyana mupombi.Kuti uite izvozvo, isa kufona ku `inspect()`.
    ///
    /// Zvakajairika kuti `inspect()` ishandiswe sedhiragi yekugadzirisa pane kuve mune yako yekupedzisira kodhi, asi mashandiro anogona kuiwana ichibatsira mune mamwe mamiriro apo zvikanganiso zvinoda kutemwa zvisati zvaraswa.
    ///
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = [1, 4, 2, 3];
    ///
    /// // akateedzana iterator akaoma.
    /// let sum = a.iter()
    ///     .cloned()
    ///     .filter(|x| x % 2 == 0)
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    ///
    /// // ngatiwedzere mamwe mafoni e inspect() kuti tiongorore zviri kuitika
    /// let sum = a.iter()
    ///     .cloned()
    ///     .inspect(|x| println!("about to filter: {}", x))
    ///     .filter(|x| x % 2 == 0)
    ///     .inspect(|x| println!("made it through filter: {}", x))
    ///     .fold(0, |sum, i| sum + i);
    ///
    /// println!("{}", sum);
    /// ```
    ///
    /// Izvi zvichaprinta:
    ///
    /// ```text
    /// 6
    /// about to filter: 1
    /// about to filter: 4
    /// made it through filter: 4
    /// about to filter: 2
    /// made it through filter: 2
    /// about to filter: 3
    /// 6
    /// ```
    ///
    /// Kutema matanda usati waarasa:
    ///
    /// ```
    /// let lines = ["1", "2", "a"];
    ///
    /// let sum: i32 = lines
    ///     .iter()
    ///     .map(|line| line.parse::<i32>())
    ///     .inspect(|num| {
    ///         if let Err(ref e) = *num {
    ///             println!("Parsing error: {}", e);
    ///         }
    ///     })
    ///     .filter_map(Result::ok)
    ///     .sum();
    ///
    /// println!("Sum: {}", sum);
    /// ```
    ///
    /// Izvi zvichaprinta:
    ///
    /// ```text
    /// Parsing error: invalid digit found in string
    /// Sum: 3
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn inspect<F>(self, f: F) -> Inspect<Self, F>
    where
        Self: Sized,
        F: FnMut(&Self::Item),
    {
        Inspect::new(self, f)
    }

    /// Inokwereta iterator, pane kuipedza.
    ///
    /// Izvi zvinobatsira kubvumidza kuisa iterator adapters uchiri kungochengeta muridzi weiyo yekutanga iterator.
    ///
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let iter = a.iter();
    ///
    /// let sum: i32 = iter.take(5).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 6);
    ///
    /// // tikayedza kuishandisa zvakare, hazvishande.
    /// // Mutsara unotevera unopa "kukanganisa: kushandiswa kwekutama kukosha: `iter`
    /// // assert_eq!(iter.next(), None);
    ///
    /// // ngatiedzei izvo zvakare
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// // pachinzvimbo, tinowedzera mu .by_ref()
    /// let sum: i32 = iter.by_ref().take(2).fold(0, |acc, i| acc + i);
    ///
    /// assert_eq!(sum, 3);
    ///
    /// // ikozvino izvi zvakangonaka:
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), None);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn by_ref(&mut self) -> &mut Self
    where
        Self: Sized,
    {
        self
    }

    /// Inoshandura iyo iterator kuita muunganidzwa.
    ///
    /// `collect()` inogona kutora chero chinhu chinogoneka, uye kuchichinja kuita muunganidzwa wakakodzera.
    /// Iyi ndiyo imwe yedzimba dzakasimba mune raibhurari yakajairwa, inoshandiswa mune dzakasiyana mamiriro.
    ///
    /// Iyo yakakosha pateni iyo `collect()` inoshandiswa ndeyekushandura imwe muunganidzwa kuita imwe.
    /// Iwe unotora muunganidzwa, fonera [`iter`] pairi, ita boka reshanduko, uyezve `collect()` kumagumo.
    ///
    /// `collect()` inogona zvakare kugadzira zviitiko zvemhando dzisiri zvakajairwa kuunganidzwa.
    /// Semuenzaniso, [`String`] inogona kuvakwa kubva ku [`char`] s, uye iterator yezvinhu [`Result<T, E>`][`Result`] inogona kuunganidzwa mu `Result<Collection<T>, E>`.
    ///
    /// Ona iyo mienzaniso pazasi kune zvimwe.
    ///
    /// Nekuti `collect()` yakajairika, inogona kukonzera matambudziko nerudzi infereti.
    /// Saka nekudaro, `collect()` ndiyo imwe yenguva shoma iwe yaunowona syntax nerudo inozivikanwa se 'turbofish': `::<>`.
    /// Izvi zvinobatsira iyo inference algorithm kuti inzwisise chaizvo kuti ndeupi muunganidzwa wauri kuedza kuunganidza mauri.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled: Vec<i32> = a.iter()
    ///                          .map(|&x| x * 2)
    ///                          .collect();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Ziva kuti isu taida iyo `: Vec<i32>` kuruboshwe-kuruboshwe.Izvi zvinodaro nekuti isu tinogona kuunganidzira mukati, semuenzaniso, [`VecDeque<T>`] pachinzvimbo:
    ///
    /// [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
    ///
    /// ```
    /// use std::collections::VecDeque;
    ///
    /// let a = [1, 2, 3];
    ///
    /// let doubled: VecDeque<i32> = a.iter().map(|&x| x * 2).collect();
    ///
    /// assert_eq!(2, doubled[0]);
    /// assert_eq!(4, doubled[1]);
    /// assert_eq!(6, doubled[2]);
    /// ```
    ///
    /// Uchishandisa iyo 'turbofish' pachinzvimbo chekutsanangura `doubled`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<i32>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Nekuti `collect()` inongofarira nezve izvo zvauri kuunganidzira mukati, iwe uchiri kugona kushandisa yakasarudzika mhando zano, `_`, neiyo turbofish:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let doubled = a.iter().map(|x| x * 2).collect::<Vec<_>>();
    ///
    /// assert_eq!(vec![2, 4, 6], doubled);
    /// ```
    ///
    /// Uchishandisa `collect()` kugadzira [`String`]:
    ///
    /// ```
    /// let chars = ['g', 'd', 'k', 'k', 'n'];
    ///
    /// let hello: String = chars.iter()
    ///     .map(|&x| x as u8)
    ///     .map(|x| (x + 1) as char)
    ///     .collect();
    ///
    /// assert_eq!("hello", hello);
    /// ```
    ///
    /// Kana iwe uine runyorwa rwe [`Mhedzisiro<T, E>`][`Result`] s, unogona kushandisa `collect()` kuona kana paine akakundikana:
    ///
    /// ```
    /// let results = [Ok(1), Err("nope"), Ok(3), Err("bad")];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // inotipa iko kukanganisa kwekutanga
    /// assert_eq!(Err("nope"), result);
    ///
    /// let results = [Ok(1), Ok(3)];
    ///
    /// let result: Result<Vec<_>, &str> = results.iter().cloned().collect();
    ///
    /// // inotipa runyorwa rwemhinduro
    /// assert_eq!(Ok(vec![1, 3]), result);
    /// ```
    ///
    /// [`iter`]: Iterator::next
    /// [`String`]: ../../std/string/struct.String.html
    /// [`char`]: type@char
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "if you really need to exhaust the iterator, consider `.for_each(drop)` instead"]
    fn collect<B: FromIterator<Self::Item>>(self) -> B
    where
        Self: Sized,
    {
        FromIterator::from_iter(self)
    }

    /// Inoshandisa iterator, ichigadzira maunganidzwa maviri kubva pairi.
    ///
    /// Chirevo chakapfuudzwa kuna `partition()` chinogona kudzosa `true`, kana `false`.
    /// `partition()` inodzosera peya, zvese zvinhu zvayakadzorera `true`, uye zvese zvinhu zvayakadzorera `false`.
    ///
    ///
    /// Onawo [`is_partitioned()`] uye [`partition_in_place()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let (even, odd): (Vec<i32>, Vec<i32>) = a
    ///     .iter()
    ///     .partition(|&n| n % 2 == 0);
    ///
    /// assert_eq!(even, vec![2]);
    /// assert_eq!(odd, vec![1, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn partition<B, F>(self, f: F) -> (B, B)
    where
        Self: Sized,
        B: Default + Extend<Self::Item>,
        F: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn extend<'a, T, B: Extend<T>>(
            mut f: impl FnMut(&T) -> bool + 'a,
            left: &'a mut B,
            right: &'a mut B,
        ) -> impl FnMut((), T) + 'a {
            move |(), x| {
                if f(&x) {
                    left.extend_one(x);
                } else {
                    right.extend_one(x);
                }
            }
        }

        let mut left: B = Default::default();
        let mut right: B = Default::default();

        self.fold((), extend(f, &mut left, &mut right));

        (left, right)
    }

    /// Kugadziridza zvinhu zveiyi iterator * munzvimbo-zvinoenderana nechirevo chakapihwa, zvekuti vese avo vanodzosa `true` vatangire vese avo vanodzosa `false`.
    ///
    /// Inodzorera iyo nhamba yezvinhu `true` zvakawanikwa.
    ///
    /// Iyo yakaenzana odhiyo yezvinhu zvakakamurwa haina kuchengetedzwa.
    ///
    /// Onawo [`is_partitioned()`] uye [`partition()`].
    ///
    /// [`is_partitioned()`]: Iterator::is_partitioned
    /// [`partition()`]: Iterator::partition
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_partition_in_place)]
    ///
    /// let mut a = [1, 2, 3, 4, 5, 6, 7];
    ///
    /// // Kupatsanurana munzvimbo-pakati pe evens uye zvipingaidzo
    /// let i = a.iter_mut().partition_in_place(|&n| n % 2 == 0);
    ///
    /// assert_eq!(i, 3);
    /// assert!(a[..i].iter().all(|&n| n % 2 == 0)); // evens
    /// assert!(a[i..].iter().all(|&n| n % 2 == 1)); // odds
    /// ```
    #[unstable(feature = "iter_partition_in_place", reason = "new API", issue = "62543")]
    fn partition_in_place<'a, T: 'a, P>(mut self, ref mut predicate: P) -> usize
    where
        Self: Sized + DoubleEndedIterator<Item = &'a mut T>,
        P: FnMut(&T) -> bool,
    {
        // FIXME: tinofanira kunetseka here pamusoro pekuwanda kuri kuwanda?Nzira chete yekuve nezvakawanda kupfuura
        // `usize::MAX` zvinoshandurwa zvinongedzo zvine maZST, izvo zvisina basa kupatsanura ...

        // Aya ekuvhara "factory" mabasa aripo kudzivirira genericity mu `Self`.

        #[inline]
        fn is_false<'a, T>(
            predicate: &'a mut impl FnMut(&T) -> bool,
            true_count: &'a mut usize,
        ) -> impl FnMut(&&mut T) -> bool + 'a {
            move |x| {
                let p = predicate(&**x);
                *true_count += p as usize;
                !p
            }
        }

        #[inline]
        fn is_true<T>(predicate: &mut impl FnMut(&T) -> bool) -> impl FnMut(&&mut T) -> bool + '_ {
            move |x| predicate(&**x)
        }

        // Dzokorora uchitsvaga yekutanga `false` uye uchichinjanise neyekupedzisira `true`.
        let mut true_count = 0;
        while let Some(head) = self.find(is_false(predicate, &mut true_count)) {
            if let Some(tail) = self.rfind(is_true(predicate)) {
                crate::mem::swap(head, tail);
                true_count += 1;
            } else {
                break;
            }
        }
        true_count
    }

    /// Inotarisa kana zvinhu zveiyi iterator zvakakamurwa zvinoenderana nechirevo chakapihwa, zvekuti vese avo vanodzosa `true` vatangire vese avo vanodzosa `false`.
    ///
    ///
    /// Onawo [`partition()`] uye [`partition_in_place()`].
    ///
    /// [`partition()`]: Iterator::partition
    /// [`partition_in_place()`]: Iterator::partition_in_place
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(iter_is_partitioned)]
    ///
    /// assert!("Iterator".chars().is_partitioned(char::is_uppercase));
    /// assert!(!"IntoIterator".chars().is_partitioned(char::is_uppercase));
    /// ```
    #[unstable(feature = "iter_is_partitioned", reason = "new API", issue = "62544")]
    fn is_partitioned<P>(mut self, mut predicate: P) -> bool
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        // Zvimwe zvinhu zvese zvinoyedza `true`, kana chikamu chekutanga chinomira pa `false` uye tinoongorora kuti hapasisina zvimwe zvinhu zve `true` mushure meizvozvo.
        //
        self.all(&mut predicate) || !self.any(predicate)
    }

    /// Iyo iterator nzira iyo inoshanda basa sekureba sekunge ichidzoka zvinobudirira, ichiburitsa imwechete, yekupedzisira kukosha.
    ///
    /// `try_fold()` inotora nharo mbiri: kukosha kwekutanga, uye kuvhara nenharo mbiri: 'accumulator', uye chinhu.
    /// Kuvhara kwacho kunogona kudzoka zvinobudirira, iine kukosha iyo iyo iyo yekuunganidza iyo inofanirwa kuve nayo kune inotevera iteration, kana iyo inodzosera kutadza, iine kukanganisa kwekukosha uko kunoparadzirwa kudzoka kune anofona ipapo (short-circuiting).
    ///
    ///
    /// Iko kukosha kwekutanga kukosha iyo iyo accumulator ichave nayo pane yekutanga kufona.Kana kuisa iko kuvharwa kwakabudirira kupokana nechinhu chese iterator, `try_fold()` inodzosera iyo yekupedzisira yekuunganidza seyakabudirira.
    ///
    /// Kupeta kunobatsira pese paunenge uine muunganidzwa wechimwe chinhu, uye uchida kuburitsa imwechete kukosha kubva pairi.
    ///
    /// # Cherekedza kune maImplementors
    ///
    /// Dzakati wandei dzedzimwe nzira dze (forward) dzine mashandisiro ekusarudzika maererano neiyi, saka edza kuita izvi zvakajeka kana ichigona kuita chimwe chinhu chiri nani pane default `for` loop yekumisikidza.
    ///
    /// Kunyanya, edza kuve neiyi foni `try_fold()` pane zvemukati zvikamu kubva kune ino iterator.
    /// Kana paine mafoni akawanda anodikanwa, anoshanda we `?` anogona kunge ari nyore kuseta kukosha kwechiunganidziro pamwe chete, asi chenjera chero zvinopinda zvinoda kusimudzwa pamberi pekutanga kudzoka.
    /// Iyi inzira ye `&mut self`, saka iteration inoda kuitwazve mushure mekurova chikanganiso pano.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // huwandu hwakaongororwa hwezvinhu zvese zveakarongeka
    /// let sum = a.iter().try_fold(0i8, |acc, &x| acc.checked_add(x));
    ///
    /// assert_eq!(sum, Some(6));
    /// ```
    ///
    /// Short-circuiting:
    ///
    /// ```
    /// let a = [10, 20, 30, 100, 40, 50];
    /// let mut it = a.iter();
    ///
    /// // Iyi sumhu inopfachukira kana ichiwedzera chinhu zana
    /// let sum = it.try_fold(0i8, |acc, &x| acc.checked_add(x));
    /// assert_eq!(sum, None);
    ///
    /// // Nekuti iyo yakapfupika-kutenderera, izvo zvasara zvinhu zvichiri kuwanikwa kuburikidza neayo iterator.
    /////
    /// assert_eq!(it.len(), 2);
    /// assert_eq!(it.next(), Some(&40));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_fold<B, F, R>(&mut self, init: B, mut f: F) -> R
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> R,
        R: Try<Ok = B>,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x)?;
        }
        try { accum }
    }

    /// Iyo iterator nzira iyo inoshandisa chinokanganisa basa kune chimwe nechimwe chinhu mune iterator, ichimira pakukanganisa kwekutanga uye ichidzosera iko kukanganisa.
    ///
    ///
    /// Izvi zvinogona zvakare kufungwa nezvazvo seye inokanganisa fomu ye [`for_each()`] kana seyakaverengeka vhezheni ye [`try_fold()`].
    ///
    /// [`for_each()`]: Iterator::for_each
    /// [`try_fold()`]: Iterator::try_fold
    ///
    /// # Examples
    ///
    /// ```
    /// use std::fs::rename;
    /// use std::io::{stdout, Write};
    /// use std::path::Path;
    ///
    /// let data = ["no_tea.txt", "stale_bread.json", "torrential_rain.png"];
    ///
    /// let res = data.iter().try_for_each(|x| writeln!(stdout(), "{}", x));
    /// assert!(res.is_ok());
    ///
    /// let mut it = data.iter().cloned();
    /// let res = it.try_for_each(|x| rename(x, Path::new(x).with_extension("old")));
    /// assert!(res.is_err());
    /// // Iyo ipfupi-yakatenderera, saka zvinhu zvasara zvichiri mune iterator:
    /// assert_eq!(it.next(), Some("stale_bread.json"));
    /// ```
    ///
    #[inline]
    #[stable(feature = "iterator_try_fold", since = "1.27.0")]
    fn try_for_each<F, R>(&mut self, f: F) -> R
    where
        Self: Sized,
        F: FnMut(Self::Item) -> R,
        R: Try<Ok = ()>,
    {
        #[inline]
        fn call<T, R>(mut f: impl FnMut(T) -> R) -> impl FnMut((), T) -> R {
            move |(), x| f(x)
        }

        self.try_fold((), call(f))
    }

    /// Inopeta zvese zvinhu muchiunganidziro nekuisa mashandiro, ichidzosera mhedzisiro.
    ///
    /// `fold()` inotora nharo mbiri: kukosha kwekutanga, uye kuvhara nenharo mbiri: 'accumulator', uye chinhu.
    /// Kuvhara kunodzosera iyo kukosha iyo iyo yekuunganidza inofanira kuve nayo kune inotevera iteration.
    ///
    /// Iko kukosha kwekutanga kukosha iyo iyo accumulator ichave nayo pane yekutanga kufona.
    ///
    /// Mushure mekuisa iko kuvhara kune zvese zvinhu zveiyo iterator, `fold()` inodzosera iyo yekuunganidza.
    ///
    /// Uku kuvhiya dzimwe nguva kunonzi 'reduce' kana 'inject'.
    ///
    /// Kupeta kunobatsira pese paunenge uine muunganidzwa wechimwe chinhu, uye uchida kuburitsa imwechete kukosha kubva pairi.
    ///
    /// Note: `fold()`, uye nenzira dzakafanana dzinoyambuka iyo iterator yese, inogona kusazogumira kune avo vasingagumi iterator, kunyangwe pa traits iyo mhedzisiro inogoneka munguva inogumira.
    ///
    /// Note: [`reduce()`] inogona kushandiswa kushandisa chinhu chekutanga seyakakosha kukosha, kana iyo mhando yekuunganidza uye chinhu chechinhu chakafanana.
    ///
    /// # Cherekedza kune maImplementors
    ///
    /// Dzakati wandei dzedzimwe nzira dze (forward) dzine mashandisiro ekusarudzika maererano neiyi, saka edza kuita izvi zvakajeka kana ichigona kuita chimwe chinhu chiri nani pane default `for` loop yekumisikidza.
    ///
    ///
    /// Kunyanya, edza kuve neiyi foni `fold()` pane zvemukati zvikamu kubva kune ino iterator.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// // kuwanda kwezvinhu zvese zveakarongeka
    /// let sum = a.iter().fold(0, |acc, x| acc + x);
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    /// Ngatifambei nhanho imwe neimwe yeiteration pano:
    ///
    /// | element | acc | x | result |
    /// |---------|-----|---|--------|
    /// |         | 0   |   |        |
    /// | 1       | 0   | 1 | 1      |
    /// | 2       | 1   | 2 | 3      |
    /// | 3       | 3   | 3 | 6      |
    ///
    /// Uye saka, mhedzisiro yedu, `6`.
    ///
    /// Zvakajairika kune vanhu vasina kushandisa maiterator zvakanyanya kushandisa `for` chiuno nerunyorwa rwezvinhu zvekuvaka mhedzisiro.Izvo zvinogona kushandurwa kuita `fold()`s:
    ///
    /// [`for`]: ../../book/ch03-05-control-flow.html#looping-through-a-collection-with-for
    ///
    /// ```
    /// let numbers = [1, 2, 3, 4, 5];
    ///
    /// let mut result = 0;
    ///
    /// // for chiuno:
    /// for i in &numbers {
    ///     result = result + i;
    /// }
    ///
    /// // fold:
    /// let result2 = numbers.iter().fold(0, |acc, &x| acc + x);
    ///
    /// // zvakafanana
    /// assert_eq!(result, result2);
    /// ```
    ///
    /// [`reduce()`]: Iterator::reduce
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[doc(alias = "reduce")]
    #[doc(alias = "inject")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn fold<B, F>(mut self, init: B, mut f: F) -> B
    where
        Self: Sized,
        F: FnMut(B, Self::Item) -> B,
    {
        let mut accum = init;
        while let Some(x) = self.next() {
            accum = f(accum, x);
        }
        accum
    }

    /// Inoderedza zvinhu zvacho kune imwechete, nekudzokorora kudzikisira mashandiro.
    ///
    /// Kana iyo iterator isina chinhu, inodzosera [`None`];kana zvisina kudaro, inodzosera mhedzisiro yekudzikiswa.
    ///
    /// Kune maiterator ane chinhu chimwe chete, ichi chakafanana ne [`fold()`] neyekutanga chinhu cheiyo iterator sekutanga kukosha, kupeta chese chinotevera chinhu mukati mayo.
    ///
    ///
    /// [`fold()`]: Iterator::fold
    ///
    /// # Example
    ///
    /// Tsvaga kukosha kwakanyanya:
    ///
    /// ```
    /// fn find_max<I>(iter: I) -> Option<I::Item>
    ///     where I: Iterator,
    ///           I::Item: Ord,
    /// {
    ///     iter.reduce(|a, b| {
    ///         if a >= b { a } else { b }
    ///     })
    /// }
    /// let a = [10, 20, 5, -23, 0];
    /// let b: [u32; 0] = [];
    ///
    /// assert_eq!(find_max(a.iter()), Some(&20));
    /// assert_eq!(find_max(b.iter()), None);
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "iterator_fold_self", since = "1.51.0")]
    fn reduce<F>(mut self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(Self::Item, Self::Item) -> Self::Item,
    {
        let first = self.next()?;
        Some(self.fold(first, f))
    }

    /// Kuyedza kana chinhu chese iterator chichienderana neyakafanotaurwa.
    ///
    /// `all()` inotora kuvhara kunodzosera `true` kana `false`.Inoisa kuvhara uku kuchinhu chimwe nechimwe cheiyo iterator, uye kana vese vakadzoka `true`, ndozvinoitawo `all()`.
    /// Kana chero mumwe wavo akadzoka `false`, inodzosera `false`.
    ///
    /// `all()` kupfupika-kutenderera;mune mamwe mazwi, icharega kugadzirisa ichangowana `false`, zvichipiwa kuti chero zvoitika zvimwe, mhedzisiro yacho ichavewo `false`.
    ///
    ///
    /// Iyo isina chinhu iterator inodzosera `true`.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().all(|&x| x > 0));
    ///
    /// assert!(!a.iter().all(|&x| x > 2));
    /// ```
    ///
    /// Kumira pakutanga `false`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(!iter.all(|&x| x != 2));
    ///
    /// // isu tichiri kukwanisa kushandisa `iter`, sezvo paine zvimwe zvinhu.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    ///
    ///
    #[doc(alias = "every")]
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn all<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::CONTINUE } else { ControlFlow::BREAK }
            }
        }
        self.try_fold((), check(f)) == ControlFlow::CONTINUE
    }

    /// Kuyedza kana paine chinhu cheiyo iterator chinowirirana chirevamuromo.
    ///
    /// `any()` inotora kuvhara kunodzosera `true` kana `false`.Inoisa kuvhara uku kune chimwe nechimwe chinhu cheiyo iterator, uye kana paine vamwe vavo vanodzoka `true`, ndozvinoitawo `any()`.
    /// Kana ivo vese vakadzoka `false`, inodzosera `false`.
    ///
    /// `any()` kupfupika-kutenderera;mune mamwe mazwi, icharega kugadzirisa ichangowana `true`, zvichipiwa kuti chero zvoitika zvimwe, mhedzisiro yacho ichavewo `true`.
    ///
    ///
    /// Iyo isina chinhu iterator inodzosera `false`.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert!(a.iter().any(|&x| x > 0));
    ///
    /// assert!(!a.iter().any(|&x| x > 5));
    /// ```
    ///
    /// Kumira pakutanga `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert!(iter.any(|&x| x != 2));
    ///
    /// // isu tichiri kukwanisa kushandisa `iter`, sezvo paine zvimwe zvinhu.
    /// assert_eq!(iter.next(), Some(&2));
    /// ```
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn any<F>(&mut self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut f: impl FnMut(T) -> bool) -> impl FnMut((), T) -> ControlFlow<()> {
            move |(), x| {
                if f(x) { ControlFlow::BREAK } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(f)) == ControlFlow::BREAK
    }

    /// Kutsvaga kwechinhu cheiyo iterator iyo inogutsa chirevo.
    ///
    /// `find()` inotora kuvhara kunodzosera `true` kana `false`.
    /// Inoisa kuvhara uku kune chimwe nechimwe chinhu cheiyo iterator, uye kana paine vamwe vavo vanodzoka `true`, ipapo `find()` inodzosera [`Some(element)`].
    /// Kana ivo vese vakadzoka `false`, inodzosera [`None`].
    ///
    /// `find()` kupfupika-kutenderera;mune mamwe mazwi, inomira kugadzirisa nekukurumidza kana iko kuvhura kwadzoka `true`.
    ///
    /// Nekuti `find()` inotora referensi, uye maiterator mazhinji anorerekera pane zvinongedzo, izvi zvinotungamira kune inogona kuvhiringidza mamiriro apo nharo iri revo mbiri.
    ///
    /// Unogona kuona izvi mumienzaniso pazasi, iine `&&x`.
    ///
    /// [`Some(element)`]: Some
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 2), Some(&2));
    ///
    /// assert_eq!(a.iter().find(|&&x| x == 5), None);
    /// ```
    ///
    /// Kumira pakutanga `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.find(|&&x| x == 2), Some(&2));
    ///
    /// // isu tichiri kukwanisa kushandisa `iter`, sezvo paine zvimwe zvinhu.
    /// assert_eq!(iter.next(), Some(&3));
    /// ```
    ///
    /// Ziva kuti `iter.find(f)` yakaenzana ne `iter.filter(f).next()`.
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn find<P>(&mut self, predicate: P) -> Option<Self::Item>
    where
        Self: Sized,
        P: FnMut(&Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(mut predicate: impl FnMut(&T) -> bool) -> impl FnMut((), T) -> ControlFlow<T> {
            move |(), x| {
                if predicate(&x) { ControlFlow::Break(x) } else { ControlFlow::CONTINUE }
            }
        }

        self.try_fold((), check(predicate)).break_value()
    }

    /// Inoisa basa kune izvo zvinhu zveiterator uye inodzosera iyo yekutanga isiri-imwe mhedzisiro.
    ///
    ///
    /// `iter.find_map(f)` yakaenzana ne `iter.filter_map(f).next()`.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = ["lol", "NaN", "2", "5"];
    ///
    /// let first_number = a.iter().find_map(|s| s.parse().ok());
    ///
    /// assert_eq!(first_number, Some(2));
    /// ```
    #[inline]
    #[stable(feature = "iterator_find_map", since = "1.30.0")]
    fn find_map<B, F>(&mut self, f: F) -> Option<B>
    where
        Self: Sized,
        F: FnMut(Self::Item) -> Option<B>,
    {
        #[inline]
        fn check<T, B>(mut f: impl FnMut(T) -> Option<B>) -> impl FnMut((), T) -> ControlFlow<B> {
            move |(), x| match f(x) {
                Some(x) => ControlFlow::Break(x),
                None => ControlFlow::CONTINUE,
            }
        }

        self.try_fold((), check(f)).break_value()
    }

    /// Inoisa basa kune izvo zvinhu zveiterator uye inodzosera iyo yekutanga yechokwadi mhedzisiro kana yekutanga kukanganisa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(try_find)]
    ///
    /// let a = ["1", "2", "lol", "NaN", "5"];
    ///
    /// let is_my_num = |s: &str, search: i32| -> Result<bool, std::num::ParseIntError> {
    ///     Ok(s.parse::<i32>()?  == search)
    /// };
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 2));
    /// assert_eq!(result, Ok(Some(&"2")));
    ///
    /// let result = a.iter().try_find(|&&s| is_my_num(s, 5));
    /// assert!(result.is_err());
    /// ```
    #[inline]
    #[unstable(feature = "try_find", reason = "new API", issue = "63178")]
    fn try_find<F, R>(&mut self, f: F) -> Result<Option<Self::Item>, R::Error>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> R,
        R: Try<Ok = bool>,
    {
        #[inline]
        fn check<F, T, R>(mut f: F) -> impl FnMut((), T) -> ControlFlow<Result<T, R::Error>>
        where
            F: FnMut(&T) -> R,
            R: Try<Ok = bool>,
        {
            move |(), x| match f(&x).into_result() {
                Ok(false) => ControlFlow::CONTINUE,
                Ok(true) => ControlFlow::Break(Ok(x)),
                Err(x) => ControlFlow::Break(Err(x)),
            }
        }

        self.try_fold((), check(f)).break_value().transpose()
    }

    /// Kutsvaga kwechinhu mune iterator, kudzorera index yayo.
    ///
    /// `position()` inotora kuvhara kunodzosera `true` kana `false`.
    /// Inoisa kuvhara uku kune chimwe nechimwe chinhu cheiyo iterator, uye kana mumwe wavo achidzosa `true`, ipapo `position()` inodzosera [`Some(index)`].
    /// Kana vese vakadzoka `false`, inodzosera [`None`].
    ///
    /// `position()` kupfupika-kutenderera;mune mamwe mazwi, icharega kugadzirisa ichangowana `true`.
    ///
    /// # Kufashukira Maitiro
    ///
    /// Iyo nzira haina chengetedzo kune yakafashukira, saka kana paine zvinopfuura [`usize::MAX`] zvisingaenzanisike zvinhu, zvinogona kuburitsa isiriyo mhedzisiro kana panics.
    ///
    /// Kana zvirevo zvekugadzirisa zvikabvumidzwa, panic inovimbiswa.
    ///
    /// # Panics
    ///
    /// Iri basa rinogona panic kana iyo iterator iine zvinopfuura `usize::MAX` zvisingaenderane nezvinhu.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().position(|&x| x == 2), Some(1));
    ///
    /// assert_eq!(a.iter().position(|&x| x == 5), None);
    /// ```
    ///
    /// Kumira pakutanga `true`:
    ///
    /// ```
    /// let a = [1, 2, 3, 4];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.position(|&x| x >= 2), Some(1));
    ///
    /// // isu tichiri kukwanisa kushandisa `iter`, sezvo paine zvimwe zvinhu.
    /// assert_eq!(iter.next(), Some(&3));
    ///
    /// // Iyo yakadzoserwa indekisi inoenderana ne iterator nyika
    /// assert_eq!(iter.position(|&x| x == 4), Some(0));
    ///
    /// ```
    ///
    ///
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn position<P>(&mut self, predicate: P) -> Option<usize>
    where
        Self: Sized,
        P: FnMut(Self::Item) -> bool,
    {
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            #[rustc_inherit_overflow_checks]
            move |i, x| {
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i + 1) }
            }
        }

        self.try_fold(0, check(predicate)).break_value()
    }

    /// Kutsvaga kwechinhu mune iterator kubva kurudyi, ichidzorera index yayo.
    ///
    /// `rposition()` inotora kuvhara kunodzosera `true` kana `false`.
    /// Inoisa kuvhara uku kune chimwe nechimwe chinhu cheiyo iterator, kutanga kubva kumagumo, uye kana mumwe wavo achidzoka `true`, ipapo `rposition()` inodzosera [`Some(index)`].
    ///
    /// Kana vese vakadzoka `false`, inodzosera [`None`].
    ///
    /// `rposition()` kupfupika-kutenderera;mune mamwe mazwi, icharega kugadzirisa ichangowana `true`.
    ///
    /// [`Some(index)`]: Some
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 3), Some(2));
    ///
    /// assert_eq!(a.iter().rposition(|&x| x == 5), None);
    /// ```
    ///
    /// Kumira pakutanga `true`:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter();
    ///
    /// assert_eq!(iter.rposition(|&x| x == 2), Some(1));
    ///
    /// // isu tichiri kukwanisa kushandisa `iter`, sezvo paine zvimwe zvinhu.
    /// assert_eq!(iter.next(), Some(&1));
    /// ```
    ///
    ///
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rposition<P>(&mut self, predicate: P) -> Option<usize>
    where
        P: FnMut(Self::Item) -> bool,
        Self: Sized + ExactSizeIterator + DoubleEndedIterator,
    {
        // Hapana kudiwa kwekufashukira cheki pano, nekuti `ExactSizeIterator` inoreva kuti nhamba yezvinhu inokwana mu `usize`.
        //
        #[inline]
        fn check<T>(
            mut predicate: impl FnMut(T) -> bool,
        ) -> impl FnMut(usize, T) -> ControlFlow<usize, usize> {
            move |i, x| {
                let i = i - 1;
                if predicate(x) { ControlFlow::Break(i) } else { ControlFlow::Continue(i) }
            }
        }

        let n = self.len();
        self.try_rfold(n, check(predicate)).break_value()
    }

    /// Inodzorera chakanyanya chinhu cheiyo iterator.
    ///
    /// Kana zvinhu zvinoverengeka zvakaenzana zvakaenzana, chinhu chekupedzisira chinodzoserwa.
    /// Kana iyo iterator isina chinhu, [`None`] inodzoserwa.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().max(), Some(&3));
    /// assert_eq!(b.iter().max(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn max(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.max_by(Ord::cmp)
    }

    /// Inodzosera iyo shoma chinhu cheiyo iterator.
    ///
    /// Kana zvinhu zvinoverengeka zvakaringana kushoma, chinhu chekutanga chinodzoserwa.
    /// Kana iyo iterator isina chinhu, [`None`] inodzoserwa.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let b: Vec<u32> = Vec::new();
    ///
    /// assert_eq!(a.iter().min(), Some(&1));
    /// assert_eq!(b.iter().min(), None);
    /// ```
    #[inline]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn min(self) -> Option<Self::Item>
    where
        Self: Sized,
        Self::Item: Ord,
    {
        self.min_by(Ord::cmp)
    }

    /// Inodzorera chinhu icho chinopa iyo yakanyanya kukosha kubva pane yakatarwa basa.
    ///
    ///
    /// Kana zvinhu zvinoverengeka zvakaenzana zvakaenzana, chinhu chekupedzisira chinodzoserwa.
    /// Kana iyo iterator isina chinhu, [`None`] inodzoserwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by_key(|x| x.abs()).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn max_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).max_by(compare)?;
        Some(x)
    }

    /// Inodzorera icho chinhu icho chinopa iyo yakanyanya kukosha maererano neyakafananidzwa yekuenzanisa basa.
    ///
    ///
    /// Kana zvinhu zvinoverengeka zvakaenzana zvakaenzana, chinhu chekupedzisira chinodzoserwa.
    /// Kana iyo iterator isina chinhu, [`None`] inodzoserwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().max_by(|x, y| x.cmp(y)).unwrap(), 5);
    /// ```
    #[inline]
    #[stable(feature = "iter_max_by", since = "1.15.0")]
    fn max_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::max_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Inodzorera chinhu icho chinopa iyo yakaderera kukosha kubva kune yakatarwa basa.
    ///
    ///
    /// Kana zvinhu zvinoverengeka zvakaringana kushoma, chinhu chekutanga chinodzoserwa.
    /// Kana iyo iterator isina chinhu, [`None`] inodzoserwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by_key(|x| x.abs()).unwrap(), 0);
    /// ```
    #[inline]
    #[stable(feature = "iter_cmp_by_key", since = "1.6.0")]
    fn min_by_key<B: Ord, F>(self, f: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item) -> B,
    {
        #[inline]
        fn key<T, B>(mut f: impl FnMut(&T) -> B) -> impl FnMut(T) -> (B, T) {
            move |x| (f(&x), x)
        }

        #[inline]
        fn compare<T, B: Ord>((x_p, _): &(B, T), (y_p, _): &(B, T)) -> Ordering {
            x_p.cmp(y_p)
        }

        let (_, x) = self.map(key(f)).min_by(compare)?;
        Some(x)
    }

    /// Inodzorera icho chinhu icho chinopa iyo yakaderera kukosha maererano nerakataurwa basa rekuenzanisa.
    ///
    ///
    /// Kana zvinhu zvinoverengeka zvakaringana kushoma, chinhu chekutanga chinodzoserwa.
    /// Kana iyo iterator isina chinhu, [`None`] inodzoserwa.
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [-3_i32, 0, 1, 5, -10];
    /// assert_eq!(*a.iter().min_by(|x, y| x.cmp(y)).unwrap(), -10);
    /// ```
    #[inline]
    #[stable(feature = "iter_min_by", since = "1.15.0")]
    fn min_by<F>(self, compare: F) -> Option<Self::Item>
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Ordering,
    {
        #[inline]
        fn fold<T>(mut compare: impl FnMut(&T, &T) -> Ordering) -> impl FnMut(T, T) -> T {
            move |x, y| cmp::min_by(x, y, &mut compare)
        }

        self.reduce(fold(compare))
    }

    /// Inodzosera iko iko iterator.
    ///
    /// Kazhinji, iterators iterate kubva kuruboshwe kurudyi.
    /// Mushure mekushandisa `rev()`, iyo iterator inozoita iterate kubva kurudyi kuenda kuruboshwe.
    ///
    /// Izvi zvinongogoneka kana iyo iterator ine mugumo, saka `rev()` inoshanda chete pa [`DoubleEndedIterator`] s.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut iter = a.iter().rev();
    ///
    /// assert_eq!(iter.next(), Some(&3));
    /// assert_eq!(iter.next(), Some(&2));
    /// assert_eq!(iter.next(), Some(&1));
    ///
    /// assert_eq!(iter.next(), None);
    /// ```
    #[inline]
    #[doc(alias = "reverse")]
    #[stable(feature = "rust1", since = "1.0.0")]
    fn rev(self) -> Rev<Self>
    where
        Self: Sized + DoubleEndedIterator,
    {
        Rev::new(self)
    }

    /// Inoshandura iterator yevaviri kuita mapaipi emidziyo.
    ///
    /// `unzip()` inoshandisa iyo yakazara iterator yevaviri, ichiburitsa maunganidzwa maviri: imwe kubva kuzvinhu zvekuruboshwe zvemaviri, uye imwe kubva kurudyi zvinhu.
    ///
    ///
    /// Iri basa, mune imwe nzira, rinopesana ne [`zip`].
    ///
    /// [`zip`]: Iterator::zip
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = [(1, 2), (3, 4)];
    ///
    /// let (left, right): (Vec<_>, Vec<_>) = a.iter().cloned().unzip();
    ///
    /// assert_eq!(left, [1, 3]);
    /// assert_eq!(right, [2, 4]);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn unzip<A, B, FromA, FromB>(self) -> (FromA, FromB)
    where
        FromA: Default + Extend<A>,
        FromB: Default + Extend<B>,
        Self: Sized + Iterator<Item = (A, B)>,
    {
        fn extend<'a, A, B>(
            ts: &'a mut impl Extend<A>,
            us: &'a mut impl Extend<B>,
        ) -> impl FnMut((), (A, B)) + 'a {
            move |(), (t, u)| {
                ts.extend_one(t);
                us.extend_one(u);
            }
        }

        let mut ts: FromA = Default::default();
        let mut us: FromB = Default::default();

        let (lower_bound, _) = self.size_hint();
        if lower_bound > 0 {
            ts.extend_reserve(lower_bound);
            us.extend_reserve(lower_bound);
        }

        self.fold((), extend(&mut ts, &mut us));

        (ts, us)
    }

    /// Inogadzira iterator iyo inoteedzera zvese zvayo zvinhu.
    ///
    /// Izvi zvinobatsira kana iwe uine iterator pamusoro pe `&T`, asi iwe unoda iterator pamusoro pe `T`.
    ///
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_copied: Vec<_> = a.iter().copied().collect();
    ///
    /// // yakateedzerwa yakafanana ne .map(|&x| x)
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_copied, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "iter_copied", since = "1.36.0")]
    fn copied<'a, T: 'a>(self) -> Copied<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Copy,
    {
        Copied::new(self)
    }

    /// Inogadzira iterator iyo [`clone`] yezvinhu zvacho zvese.
    ///
    /// Izvi zvinobatsira kana iwe uine iterator pamusoro pe `&T`, asi iwe unoda iterator pamusoro pe `T`.
    ///
    ///
    /// [`clone`]: Clone::clone
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let v_cloned: Vec<_> = a.iter().cloned().collect();
    ///
    /// // yakaumbwa yakafanana ne .map(|&x| x), yehuwandu
    /// let v_map: Vec<_> = a.iter().map(|&x| x).collect();
    ///
    /// assert_eq!(v_cloned, vec![1, 2, 3]);
    /// assert_eq!(v_map, vec![1, 2, 3]);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn cloned<'a, T: 'a>(self) -> Cloned<Self>
    where
        Self: Sized + Iterator<Item = &'a T>,
        T: Clone,
    {
        Cloned::new(self)
    }

    /// Inodzokorora iterator isingaperi.
    ///
    /// Panzvimbo pekumira pa [`None`], iyo iterator inozotanga zvakare, kubva pakutanga.Mushure mekudzokorora, ichatanga pakutanga zvakare.Uye zvakare.
    /// Uye zvakare.
    /// Forever.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = [1, 2, 3];
    ///
    /// let mut it = a.iter().cycle();
    ///
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// assert_eq!(it.next(), Some(&2));
    /// assert_eq!(it.next(), Some(&3));
    /// assert_eq!(it.next(), Some(&1));
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    fn cycle(self) -> Cycle<Self>
    where
        Self: Sized + Clone,
    {
        Cycle::new(self)
    }

    /// Inopfupisa izvo zvinhu zveiterator.
    ///
    /// Inotora chinhu chimwe nechimwe, ichiwedzera pamwe chete, uye inodzosera mhedzisiro.
    ///
    /// Iyo isina chinhu iterator inodzosera zero kukosha kwerudzi.
    ///
    /// # Panics
    ///
    /// Kana uchidana `sum()` uye yechinyakare manhamba erudzi ari kudzoreredzwa, nzira iyi ichaita panic kana komputa ikazara uye zvirevo zvekugadzirisa zvikabvumidzwa.
    ///
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let a = [1, 2, 3];
    /// let sum: i32 = a.iter().sum();
    ///
    /// assert_eq!(sum, 6);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn sum<S>(self) -> S
    where
        Self: Sized,
        S: Sum<Self::Item>,
    {
        Sum::sum(self)
    }

    /// Iterates pamusoro payo yese iterator, ichiwedzera zvinhu zvese
    ///
    /// Iyo isina chinhu iterator inodzosera iyo imwechete kukosha kwerudzi.
    ///
    /// # Panics
    ///
    /// Kana uchidana `product()` uye yechinyakare manhamba erudzi ari kudzorerwa, nzira ichaita panic kana komputa ikazara uye zvirevo zvekugadzirisa zvabvumidzwa.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// fn factorial(n: u32) -> u32 {
    ///     (1..=n).product()
    /// }
    /// assert_eq!(factorial(0), 1);
    /// assert_eq!(factorial(1), 1);
    /// assert_eq!(factorial(5), 120);
    /// ```
    ///
    #[stable(feature = "iter_arith", since = "1.11.0")]
    fn product<P>(self) -> P
    where
        Self: Sized,
        P: Product<Self::Item>,
    {
        Product::product(self)
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ichifananidza zvinhu zveiyi [`Iterator`] neizvo zveimwe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1].iter().cmp([1].iter()), Ordering::Equal);
    /// assert_eq!([1].iter().cmp([1, 2].iter()), Ordering::Less);
    /// assert_eq!([1, 2].iter().cmp([1].iter()), Ordering::Greater);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn cmp<I>(self, other: I) -> Ordering
    where
        I: IntoIterator<Item = Self::Item>,
        Self::Item: Ord,
        Self: Sized,
    {
        self.cmp_by(other, |x, y| x.cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ichifananidza zvinhu zveiyi [`Iterator`] neizvo zveimwe zvine chekuita nebasa rakatarwa rekufananidza.
    ///
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| x.cmp(&y)), Ordering::Less);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (x * x).cmp(&y)), Ordering::Equal);
    /// assert_eq!(xs.iter().cmp_by(&ys, |&x, &y| (2 * x).cmp(&y)), Ordering::Greater);
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn cmp_by<I, F>(mut self, other: I, mut cmp: F) -> Ordering
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Ordering,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Ordering::Equal;
                    } else {
                        return Ordering::Less;
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Ordering::Greater,
                Some(val) => val,
            };

            match cmp(x, y) {
                Ordering::Equal => (),
                non_eq => return non_eq,
            }
        }
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ichifananidza zvinhu zveiyi [`Iterator`] neizvo zveimwe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::cmp::Ordering;
    ///
    /// assert_eq!([1.].iter().partial_cmp([1.].iter()), Some(Ordering::Equal));
    /// assert_eq!([1.].iter().partial_cmp([1., 2.].iter()), Some(Ordering::Less));
    /// assert_eq!([1., 2.].iter().partial_cmp([1.].iter()), Some(Ordering::Greater));
    ///
    /// assert_eq!([f64::NAN].iter().partial_cmp([1.].iter()), None);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn partial_cmp<I>(self, other: I) -> Option<Ordering>
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp_by(other, |x, y| x.partial_cmp(&y))
    }

    /// [Lexicographically](Ord#lexicographical-comparison) ichifananidza zvinhu zveiyi [`Iterator`] neizvo zveimwe zvine chekuita nebasa rakatarwa rekufananidza.
    ///
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// use std::cmp::Ordering;
    ///
    /// let xs = [1.0, 2.0, 3.0, 4.0];
    /// let ys = [1.0, 4.0, 9.0, 16.0];
    ///
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| x.partial_cmp(&y)),
    ///     Some(Ordering::Less)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (x * x).partial_cmp(&y)),
    ///     Some(Ordering::Equal)
    /// );
    /// assert_eq!(
    ///     xs.iter().partial_cmp_by(&ys, |&x, &y| (2.0 * x).partial_cmp(&y)),
    ///     Some(Ordering::Greater)
    /// );
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn partial_cmp_by<I, F>(mut self, other: I, mut partial_cmp: F) -> Option<Ordering>
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> Option<Ordering>,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => {
                    if other.next().is_none() {
                        return Some(Ordering::Equal);
                    } else {
                        return Some(Ordering::Less);
                    }
                }
                Some(val) => val,
            };

            let y = match other.next() {
                None => return Some(Ordering::Greater),
                Some(val) => val,
            };

            match partial_cmp(x, y) {
                Some(Ordering::Equal) => (),
                non_eq => return non_eq,
            }
        }
    }

    /// Inotarisa kana zvinhu zveiyi [`Iterator`] zvakaenzana neizvo zveimwe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().eq([1].iter()), true);
    /// assert_eq!([1].iter().eq([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn eq<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        self.eq_by(other, |x, y| x == y)
    }

    /// Inotarisa kana zvinhu zveiyi [`Iterator`] zvakaenzana neizvo zveimwe zvine chekuita nebasa rakatarwa rekuenzana.
    ///
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// #![feature(iter_order_by)]
    ///
    /// let xs = [1, 2, 3, 4];
    /// let ys = [1, 4, 9, 16];
    ///
    /// assert!(xs.iter().eq_by(&ys, |&x, &y| x * x == y));
    /// ```
    #[unstable(feature = "iter_order_by", issue = "64295")]
    fn eq_by<I, F>(mut self, other: I, mut eq: F) -> bool
    where
        Self: Sized,
        I: IntoIterator,
        F: FnMut(Self::Item, I::Item) -> bool,
    {
        let mut other = other.into_iter();

        loop {
            let x = match self.next() {
                None => return other.next().is_none(),
                Some(val) => val,
            };

            let y = match other.next() {
                None => return false,
                Some(val) => val,
            };

            if !eq(x, y) {
                return false;
            }
        }
    }

    /// Inotarisa kana zvinhu zveiyi [`Iterator`] zvisina kuenzana kune izvo zveimwe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ne([1].iter()), false);
    /// assert_eq!([1].iter().ne([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ne<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialEq<I::Item>,
        Self: Sized,
    {
        !self.eq(other)
    }

    /// Inotarisa kana zvinhu zveiyi [`Iterator`] zviri [lexicographically](Ord#lexicographical-comparison) zvishoma pane izvo zveimwe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().lt([1].iter()), false);
    /// assert_eq!([1].iter().lt([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().lt([1].iter()), false);
    /// assert_eq!([1, 2].iter().lt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn lt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Less)
    }

    /// Inotarisa kana zvinhu zveiyi [`Iterator`] zviri [lexicographically](Ord#lexicographical-comparison) zvishoma kana zvakaenzana neizvo zveimwe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().le([1].iter()), true);
    /// assert_eq!([1].iter().le([1, 2].iter()), true);
    /// assert_eq!([1, 2].iter().le([1].iter()), false);
    /// assert_eq!([1, 2].iter().le([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn le<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Less | Ordering::Equal))
    }

    /// Inotarisa kana zvinhu zveiyi [`Iterator`] zviri [lexicographically](Ord#lexicographical-comparison) zvakakura pane izvo zveimwe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().gt([1].iter()), false);
    /// assert_eq!([1].iter().gt([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().gt([1].iter()), true);
    /// assert_eq!([1, 2].iter().gt([1, 2].iter()), false);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn gt<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        self.partial_cmp(other) == Some(Ordering::Greater)
    }

    /// Inotarisa kana zvinhu zveiyi [`Iterator`] zviri [lexicographically](Ord#lexicographical-comparison) zvakakura kupfuura kana zvakaenzana neizvo zveimwe.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_eq!([1].iter().ge([1].iter()), true);
    /// assert_eq!([1].iter().ge([1, 2].iter()), false);
    /// assert_eq!([1, 2].iter().ge([1].iter()), true);
    /// assert_eq!([1, 2].iter().ge([1, 2].iter()), true);
    /// ```
    #[stable(feature = "iter_order", since = "1.5.0")]
    fn ge<I>(self, other: I) -> bool
    where
        I: IntoIterator,
        Self::Item: PartialOrd<I::Item>,
        Self: Sized,
    {
        matches!(self.partial_cmp(other), Some(Ordering::Greater | Ordering::Equal))
    }

    /// Inotarisa kana zvinhu zveiyi iterator zvakarongedzwa.
    ///
    /// Izvi zvinoreva kuti, pachinhu chimwe nechimwe `a` nechinotevera chinhu `b`, `a <= b` inofanira kubata.Kana iyo iterator ikaburitsa chaizvo zero kana chinhu chimwe, `true` inodzoserwa.
    ///
    /// Ziva kuti kana `Self::Item` ingori `PartialOrd`, asi kwete `Ord`, tsananguro iri pamusoro inoreva kuti basa iri rinodzosa `false` kana paine zvinhu zviviri zvinoteedzana zvisingaenzaniswi.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted());
    /// assert!(![1, 3, 2, 4].iter().is_sorted());
    /// assert!([0].iter().is_sorted());
    /// assert!(std::iter::empty::<i32>().is_sorted());
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted());
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted(self) -> bool
    where
        Self: Sized,
        Self::Item: PartialOrd,
    {
        self.is_sorted_by(PartialOrd::partial_cmp)
    }

    /// Inotarisa kana zvinhu zveiyi iterator zvakarongedzwa uchishandisa yakapihwa enzanisa basa.
    ///
    /// Panzvimbo pekushandisa `PartialOrd::partial_cmp`, iri basa rinoshandisa yakapihwa `compare` basa kuona kurongeka kwezvinhu zviviri.
    /// Kunze kwaizvozvo, zvakaenzana ne [`is_sorted`];ona zvinyorwa zvaro kuti uwane rumwe ruzivo.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!([1, 2, 2, 9].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![1, 3, 2, 4].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!([0].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(std::iter::empty::<i32>().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// assert!(![0.0, 1.0, f32::NAN].iter().is_sorted_by(|a, b| a.partial_cmp(b)));
    /// ```
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by<F>(mut self, compare: F) -> bool
    where
        Self: Sized,
        F: FnMut(&Self::Item, &Self::Item) -> Option<Ordering>,
    {
        #[inline]
        fn check<'a, T>(
            last: &'a mut T,
            mut compare: impl FnMut(&T, &T) -> Option<Ordering> + 'a,
        ) -> impl FnMut(T) -> bool + 'a {
            move |curr| {
                if let Some(Ordering::Greater) | None = compare(&last, &curr) {
                    return false;
                }
                *last = curr;
                true
            }
        }

        let mut last = match self.next() {
            Some(e) => e,
            None => return true,
        };

        self.all(check(&mut last, compare))
    }

    /// Inotarisa kana zvinhu zveiyi iterator zvakarongedzwa uchishandisa yakapihwa kiyi yekubvisa basa.
    ///
    /// Panzvimbo pekufananidza zvinhu zveiyo iterator zvakananga, iri basa rinoenzanisa makiyi ezvinhu zvacho, sekusarudzwa ne `f`.
    /// Kunze kwaizvozvo, zvakaenzana ne [`is_sorted`];ona zvinyorwa zvaro kuti uwane rumwe ruzivo.
    ///
    /// [`is_sorted`]: Iterator::is_sorted
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(is_sorted)]
    ///
    /// assert!(["c", "bb", "aaa"].iter().is_sorted_by_key(|s| s.len()));
    /// assert!(![-2i32, -1, 0, 3].iter().is_sorted_by_key(|n| n.abs()));
    /// ```
    ///
    ///
    #[inline]
    #[unstable(feature = "is_sorted", reason = "new API", issue = "53485")]
    fn is_sorted_by_key<F, K>(self, f: F) -> bool
    where
        Self: Sized,
        F: FnMut(Self::Item) -> K,
        K: PartialOrd,
    {
        self.map(f).is_sorted()
    }

    /// Ona [TrustedRandomAccess]
    // Iri risingazivikanwe zita nderekudzivirira kupokana kwemazita mukugadzirisa nzira ona #76479.
    //
    #[inline]
    #[doc(hidden)]
    #[unstable(feature = "trusted_random_access", issue = "none")]
    unsafe fn __iterator_get_unchecked(&mut self, _idx: usize) -> Self::Item
    where
        Self: TrustedRandomAccess,
    {
        unreachable!("Always specialized");
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I: Iterator + ?Sized> Iterator for &mut I {
    type Item = I::Item;
    fn next(&mut self) -> Option<I::Item> {
        (**self).next()
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn advance_by(&mut self, n: usize) -> Result<(), usize> {
        (**self).advance_by(n)
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
}