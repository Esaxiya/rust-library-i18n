//! Mhando dzinopinza data kunzvimbo yaro mundangariro.
//!
//! Dzimwe nguva zvinobatsira kuve nezvinhu zvakavimbiswa kuti hazvifambe, mupfungwa yekuti kuiswa kwavo mundangariro hakuchinje, uye nokudaro kunogona kuvimbwa nako.
//! Muenzaniso wekutanga wechiitiko chakadai kungave kuvaka kuzvimiririra-kwakazvimiririra, sekufambisa chinhu chine zvinongedzo kwachiri kuchazvishayisa simba, izvo zvinogona kukonzera kusanzwisisika maitiro.
//!
//! Padanho repamusoro, [`Pin<P>`] inova nechokwadi chekuti iyo pointee yechero mhando yechinongedzo `P` ine nzvimbo yakagadzikana mundangariro, zvichireva kuti haigone kuendeswa kumwe kunhu uye ndangariro yayo haigone kuendeswa kudzamara yadonhedzwa.Isu tinoti iyo pointee ndeye "pinned".Zvinhu zvinowedzera kusanzwisisika kana uchikurukura mhando dzinosanganisa dzakapetwa nedata risina-kudhonzwa;[see below](#projections-and-structural-pinning) kune rumwe ruzivo.
//!
//! Nokusingaperi, ese marudzi mu Rust anotakurika.
//! Rust inobvumidza kupfuura ese marudzi ne-kukosha, uye zvakajairika smart-pointer mhando senge [`Box<T>`] uye `&mut T` inobvumidza kutsiva uye kufambisa hunhu hwainazvo: unogona kubuda mu [`Box<T>`], kana iwe unogona kushandisa [`mem::swap`].
//! [`Pin<P>`] inoputira chinongedzo `P`, saka [`Pin`]`<<[`Box`]`<T>> `inoshanda zvakanyanya senge yakajairwa
//!
//! [`Box<T>`]: when a [`Pin`]`<<[`Bhokisi`]`<T>> `inodonhedzwa, saka ita zvirimo, uye ndangariro dzinowana
//!
//! dhiri.Saizvozvo, [`Pin`]`<&mut T>`yakafanana ne `&mut T`.Nekudaro, [`Pin<P>`] hairege vatengi vachiwana [`Box<T>`] kana `&mut T` kune yakanamirwa dhata, zvinoreva kuti haugone kushandisa mashandiro akadai se [`mem::swap`]:
//!
//! ```
//! use std::pin::Pin;
//! fn swap_pins<T>(x: Pin<&mut T>, y: Pin<&mut T>) {
//!     // `mem::swap` inoda `&mut T`, asi isu hatigone kuiwana.
//!     // Isu takanamatira, hatigone kuchinjanisa zvirimo mune izvi mareferenzi.
//!     // Tinogona kushandisa `Pin::get_unchecked_mut`, asi izvo hazvina kuchengeteka nechikonzero:
//!     // hatibvumidzwe kuishandisa kufambisa zvinhu kubva mu `Pin`.
//! }
//! ```
//!
//! Izvo zvakakosha kudzokorora kuti [`Pin<P>`] haina *haichinje chokwadi chekuti Rust compiler inofunga ese marudzi anotamiswa.[`mem::swap`] inoramba ichidanwa kune chero `T`.Panzvimbo iyoyo, [`Pin<P>`] inodzivirira mamwe ma* values * (akanongedzerwa nezviratidzwa zvakamonerwa mu [`Pin<P>`]) kubva mukufambiswa nekuita kuti zvisakwanise kudaidza nzira dzinoda `&mut T` padziri (se [`mem::swap`]).
//!
//! [`Pin<P>`] inogona kushandiswa kuputira chero chinongedzo mhando `P`, uye nekudaro inopindirana ne [`Deref`] uye [`DerefMut`].[`Pin<P>`] apo `P: Deref` inofanirwa kutariswa se "`P`-style pointer" kune yakanamirwa `P::Target`-saka, [`Pin`]`<<[`Box`]`<T>> `chinongedzo chine muridzi we `T`, uye [` Pin`]`<`[`Rc`]`<T>> `chirevo-chakaverengwa chinongedzo kune chakapetwa `T`.
//! Nezvekururamisa, [`Pin<P>`] inovimba nekuitiswa kwe [`Deref`] uye [`DerefMut`] kuti isabude kunze kwavo `self` paramende, uye inongogara ichidzosera pointer kune yakanamirwa dhata pavanodaidzwa pane yakapihwa pointer.
//!
//! # `Unpin`
//!
//! Mhando zhinji dzinogara dzichimutswa zvakasununguka, kunyangwe padzinopendwa, nekuti hazvivimbe nekuva nekero yakagadzikana.Izvi zvinosanganisira ese ekutanga marudzi (senge [`bool`], [`i32`], uye mareferenzi) pamwe nemhando dzinosanganisira idzi chete mhando.Mhando dzisina hanya nekupinha dzishandise iyo [`Unpin`] auto-trait, iyo inokanzura mhedzisiro ye [`Pin<P>`].
//! Zve `T: Unpin`, [`Pin`]`<`[`Bhokisi`] `<T>>`uye [`Box<T>`] inoshanda zvakafanana, sezvinoita [`Pin`] `<&mut T>` uye `&mut T`.
//!
//! Ziva kuti kupinha uye [`Unpin`] zvinongokanganisa iyo yakanongedzwa-kunyora `P::Target`, kwete iyo pointer mhando `P` pachayo iyo yakaputirwa mu [`Pin<P>`].Semuenzaniso, kana [`Box<T>`] iri [`Unpin`] haina zvainoita pamafambiro e [`Pin`]`<<`[`Box`] `<T>>`(pano, `T` ndiyo yakanongedzwa-kutaipa).
//!
//! # Muenzaniso: unozvimiririra wega
//!
//! Tisati tapinda mune rumwe ruzivo kutsanangura zvivimbiso uye sarudzo dzakabatana ne `Pin<T>`, tinokurukura mimwe mienzaniso yekuti ingashandiswa sei.
//! Inzwa wakasununguka ku [skip to where the theoretical discussion continues](#drop-guarantee).
//!
//! ```rust
//! use std::pin::Pin;
//! use std::marker::PhantomPinned;
//! use std::ptr::NonNull;
//!
//! // Ichi chimiro chekuzvimiririra-nekuti chidimbu chemunda chakanongedzera kunhandare yedata.
//! // Hatigone kuzivisa muunganidzi nezve izvo zvine chirevo chinowanzoitika, sezvo pateni iyi isingatsanangurike nemitemo yakajairika yekukwereta.
//! //
//! // Panzvimbo iyoyo isu tinoshandisa mbishi mbichana, kunyangwe imwe inozivikanwa kuti haina basa, sekuziva kwedu kuri kunongedza patambo.
//! //
//! struct Unmovable {
//!     data: String,
//!     slice: NonNull<String>,
//!     _pin: PhantomPinned,
//! }
//!
//! impl Unmovable {
//!     // Kuona kuti data harifambe kana basa radzoka, tinoisa murwi uko richagara kwehupenyu hwechinhu, uye nzira chete yekuiwana ingave kuburikidza nekunongedzera kwairi.
//!     //
//!     //
//!     fn new(data: String) -> Pin<Box<Self>> {
//!         let res = Unmovable {
//!             data,
//!             // isu tinongogadzira iyo pointer kana iyo data yave panzvimbo neimwe nzira ichave yatotama tisati tatombotanga
//!             //
//!             slice: NonNull::dangling(),
//!             _pin: PhantomPinned,
//!         };
//!         let mut boxed = Box::pin(res);
//!
//!         let slice = NonNull::from(&boxed.data);
//!         // isu tinoziva kuti izvi zvakachengeteka nekuti kugadzirisa munda hakufambise iyo yese dhizaini
//!         unsafe {
//!             let mut_ref: Pin<&mut Self> = Pin::as_mut(&mut boxed);
//!             Pin::get_unchecked_mut(mut_ref).slice = slice;
//!         }
//!         boxed
//!     }
//! }
//!
//! let unmoved = Unmovable::new("hello".to_string());
//! // Iyo pointer inofanira kunongedza kunzvimbo chaiyo, chero bedzi iyo struct isina kufamba.
//! //
//! // Zvichakadaro, isu takasununguka kufambisa pointer kutenderera.
//! # #[allow(unused_mut)]
//! let mut still_unmoved = unmoved;
//! assert_eq!(still_unmoved.slice, NonNull::from(&still_unmoved.data));
//!
//! // Sezvo yedu mhando isingaite Unpin, izvi zvinokundikana kuumbiridza:
//! // rega mut new_unmoved= Unmovable::new("world".to_string());
//! // std::mem::swap(&mut *still_unmoved, &mut *new_unmoved);
//! ```
//!
//! # Semuenzaniso: inokanganisa ruviri-rwakabatanidzwa runyorwa
//!
//! Mune isinganzwisisike runyorwa-rwakabatana runyorwa, iko kuunganidza hakunyatso kugovera ndangariro yezvinhu zvacho.
//! Kugoverwa kunodzorwa nevatengi, uye zvinhu zvinokwanisa kurarama pane stack furemu inogara ipfupi pane zvinoita iko kuunganidzwa.
//!
//! Kugadzira iri basa, chinhu chega chega chine anonongedzera kune akamutangira uye mutsivi mune irondedzero.Zvinhu zvinogona kungowedzerwa kana zvapetwa, nekuti kufambisa zvinhu zvakapoterera kunokanganisa iwo anonongedza.Zvakare, iyo [`Drop`] kuitiswa kwechinhu chakabatanidzwa chinyorwa chinhu chinobatirira iwo anonongedzera eakafanotungamira uye mutsivi kuti ibvise pachayo kubva pachinyorwa.
//!
//! Nechisimba, isu tinofanirwa kukwanisa kuvimba ne [`drop`] kudaidzwa.Kana chinhu chikatenderwa kuendeswa kana kusambosimbiswa chisina kudaidza [`drop`], zvinongedzo mukati mazvo kubva kune zvayakavakidzana nazvo zvaizove zvisiri izvo, izvo zvaizopwanya chimiro chedata.
//!
//! Naizvozvo, kupinha kunouyawo ne [`kudonhedza"] zvine hukama.
//!
//! # `Drop` guarantee
//!
//! Icho chinangwa chekupina kugona kuvimba nekuiswa kweimwe dhata mundangariro.
//! Kuita basa iri, kwete kungofambisa iyo data inorambidzwa;kubata, kudzokororazve, kana neimwe nzira kusakanganisa ndangariro inoshandiswa kuchengeta iyo data inorambidzwa, futi.
//! Zvakatendeseka, kune yakapihwa dhata iwe unofanirwa kuchengetedza izvo zvisingaite kuti *ndangariro yayo isazoregererwe kana kudzoreredzwa kubva panguva iyo painobonyorwa kusvika panonzi [`drop`]*.Kamwe chete [`drop`] inodzoka kana panics, ndangariro inogona kushandiswazve.
//!
//! Ndangariro inogona kuva "invalidated" nekutengesa, asi zvakare nekutsiva [`Some(v)`] na [`None`], kana kudaidza [`Vec::set_len`] kuenda ku "kill" zvimwe zvinhu zvichibva pa vector.Inogona kudzokororwa nekushandisa [`ptr::write`] kuinyora zvakare pasina kudaidza muparadzi kutanga.Hapana chimwe cheizvi chinotenderwa kune yakapihwa dhata pasina kufona [`drop`].
//!
//! Urwu ndirwo chaizvo rudzi rwevimbiso yekuti irwo rwekunze rwakabatanidzwa runyorwa kubva muchikamu chakapfuura chinoda kushanda nemazvo.
//!
//! Ziva kuti ichi chivimbiso hachireve *kuti kuyeuka hakudonhe!Zvichiri zvakakwana kuti usambofonera [`drop`] pane chinhu chakapetwa (semuenzaniso, unogona kufonera [`mem::forget`] pa [`Pin`]`<<`[`Box`] `<T>>`).Mumuenzaniso weiyo yakapetwa-yakabatana runyorwa, icho chinhu chingangogara mune irwo runyorwa.Nekudaro iwe haugone kusunungura kana kushandisa zvekare chengetedzo* usina kufona [`drop`] *.
//!
//! # `Drop` implementation
//!
//! Kana mhando yako ikashandisa kupina (senge mienzaniso miviri iri pamusoro), unofanirwa kungwarira kana uchiita [`Drop`].Basa re [`drop`] rinotora `&mut self`, asi izvi zvinodaidzwa kuti *kunyangwe dai mhando yako yainge yakanyorwa kare*!Zvinoita sekunge compiler yaidaidzwa kuti [`Pin::get_unchecked_mut`].
//!
//! Izvi hazvingambokonzeresa dambudziko mukodhi yakachengeteka nekuti kumisikidza mhando inovimba nekupina inoda kodhi isina kuchengetedzeka, asi ziva kuti kusarudza kushandisa kupina mumhando yako (semuenzaniso nekuita kumwe kushanda pa [`Pin`]`<<&Self>`kana [`Pin`] `<&mut Self>` `) ine mhedzisiro yako [`Drop`] yekumisikidza futi: kana chinhu cherudzi rwako chingave chakapendwa, unofanirwa kubata [`Drop`] sekutora zvachose [` Pin`]`<<&mut Kuzvida> `.
//!
//!
//! Semuenzaniso, unogona kushandisa `Drop` seinotevera:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # struct Type { }
//! impl Drop for Type {
//!     fn drop(&mut self) {
//!         // `new_unchecked` zvakanaka nekuti isu tinoziva kukosha uku hakuzomboshandiswazve mushure mekudonhedzwa.
//!         //
//!         inner_drop(unsafe { Pin::new_unchecked(self)});
//!         fn inner_drop(this: Pin<&mut Type>) {
//!             // Chaizvoizvo donhwe kodhi inoenda apa.
//!         }
//!     }
//! }
//! ```
//!
//! Iko basa `inner_drop` rine mhando iyo [`drop`]*inofanira* kuva nayo, saka izvi zvinoita kuti uve nechokwadi chekuti hausinga netsa kushandisa `self`/`this` nenzira inopesana nekupina.
//!
//! Zvakare, kana mhando yako iri `#[repr(packed)]`, muunganidzi anozozvifambisa otenderedza minda kuti akwanise kudonha.Zvinogona kutoita izvo kuminda inoitika kuti yakanyatsoenderana.Nekuda kweizvozvo, haugone kushandisa kupina nerudzi rwe `#[repr(packed)]`.
//!
//! # Kufungidzira uye Kuumbwa Kwezvivakwa
//!
//! Paunenge uchishanda nezvakadhonzwa zvimisikidzo, mubvunzo unomuka kuti munhu anokwanisa sei kuwana minda yeiyo struct munzira inotora chete [`Pin`]`<&mut Struct>`.
//! Maitiro akajairwa ndeekunyora nzira dzekubatsira (dzinodaidzwa kuti *fungidziro*) dzinoshandura [`Pin`]`<&mut Struct>`kuita chirevo kumunda, asi irwo rudzii rwunofanirwa kuve nerevo iyoyo?Ndiyo [`Pin`]`<&mut Field>`kana `&mut Field`?
//! Mubvunzo mumwe chete unomuka neminda ye `enum`, uye zvakare kana uchifunga nezve container/wrapper mhando senge [`Vec<T>`], [`Box<T>`], kana [`RefCell<T>`].
//! (Uyu mubvunzo unoshanda kune ese ari maviri anogona kuchinjika uye akagovaniswa mareferenzi, isu tinongoshandisa yakajairika kesi yezvinoshanduka mareferenzi pano semuenzaniso.)
//!
//! Zvinoitika kuti zviri kumusoro kwemunyori wedhisheni dhizaini kuti asarudze kana pini yakafungidzirwa yeimwe munda inoshanduka [`Pin`]`<&mut Struct>`into [[Pin`]` <&mut Field> `` or `&mut Field`.Kune zvimwe zvipingamupinyi hazvo, uye chinonyanya kukosha ndechekuti kusagadzikana *:
//! munda wese unogona kuve *angave* akafungidzirwa kunongedzo,*kana* kubviswa pini sechikamu chekufungidzira.
//! Kana ese ari maviri akaitirwa munda mumwe chete, izvo zvinogona kunge zvisina kujeka!
//!
//! Semunyori wedhisheni dhizaini iwe unosvika pakusarudza kune yega yega ndima kunyatso pina "propagates" kune ino ndima kana kwete.
//! Kupinha iyo inoparadzira inonziwo "structural", nekuti inoteera chimiro cherudzi.
//! Muzvikamu zvinotevera, tinotsanangura zvinofungidzirwa kuti zviitwe pane chero sarudzo.
//!
//! ## Kupinha *haisi* chimiro che `field`
//!
//! Zvingaite senge zvinopesana-zvine mutsindo kuti munda wepini yakakamisirwa inogona kusapinhwa, asi icho ndicho chisarudzo chiri nyore kwazvo: kana [`Pin`]`<&mut Field>`isina kumbogadzirwa, hapana chinogona kutadza!Nekudaro, kana iwe ukafunga kuti imwe munda haina yekumisikidza pinning, zvese zvaunofanirwa kuve nechokwadi ndezvekuti haumbogadzira yakanamirwa chirevo kumunda iwoyo.
//!
//! Minda isina kumisikidzwa kupina inogona kuve neyekufungidzira nzira iyo inoshandura [`Pin`]`<&mut Struct>`kuita `&mut Field`:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> &mut Field {
//!         // Izvi zvakanaka nekuti `field` haina kumbofungidzirwa kupinhwa.
//!         unsafe { &mut self.get_unchecked_mut().field }
//!     }
//! }
//! ```
//!
//! Unogona zvakare `impl Unpin for Struct`*kunyangwe* iyo mhando ye `field` isiri [`Unpin`].Izvo zvinofunga rudzi irworwo nezve kupina hazvibatsire kana pasina [`Pin`]`<&mut Field>`` yakambogadzirwa.
//!
//! ## Kupinha * kuri kwechimiro kwe `field`
//!
//! Imwe sarudzo ndeyekusarudza kuti kupinha i "structural" ye `field`, zvichireva kuti kana iyo dhikisi ikapayirwa saka ndiwo munda wacho.
//!
//! Izvi zvinobvumidza kunyora fungidziro inogadzira [`Pin`]`<&mut Field>``, nekudaro uchipupura kuti munda wakaroverwa:
//!
//! ```rust,no_run
//! # use std::pin::Pin;
//! # type Field = i32;
//! # struct Struct { field: Field }
//! impl Struct {
//!     fn pin_get_field(self: Pin<&mut Self>) -> Pin<&mut Field> {
//!         // Izvi zvakanaka nekuti `field` yakanamirwa apo `self` iri.
//!         unsafe { self.map_unchecked_mut(|s| &mut s.field) }
//!     }
//! }
//! ```
//!
//! Nekudaro, dhizaini yekupinha inouya nezvimwe zvishoma zvinodiwa:
//!
//! 1. Iyo yakarongeka inofanirwa kungova [`Unpin`] kana ese masisitimu eminda ari [`Unpin`].Uku ndiko kusarongeka, asi [`Unpin`] ndeye yakachengeteka trait, saka semunyori wedhisheni ibasa rako *kwete* kuwedzera chimwe chinhu senge `impl<T> Unpin for Struct<T>`.
//! (Cherekedza kuti kuwedzera kwekuratidzira mashandiro kunoda kodhi isina kuchengetedzeka, saka chokwadi chekuti [`Unpin`] iri trait yakachengeteka hachityori musimboti wekuti unongonetsekana nezve chero izvi kana ukashandisa `zvisina kuchengeteka`.)
//! 2. Muparadzi weiyo struct haafanire kufambisa mamiriro enzvimbo kubva panharo dzayo.Iyi ndiyo poindi chaiyo yakamutswa mu [previous section][drop-impl]: `drop` inotora `&mut self`, asi iyo struct (uye nekudaro minda yayo) inogona kunge yakapihwa kare.
//!     Iwe unofanirwa kuvimbisa kuti haufambise munda mukati mekuita kwako [`Drop`].
//!     Kunyanya, sekutsanangurwa kwayamboitwa, izvi zvinoreva kuti chimiro chako hachifanirwe * kuve `#[repr(packed)]`.
//!     Ona icho chikamu chekuti unganyora sei [`drop`] nenzira iyo iyo compiler inogona kukubatsira iwe netsaona kutyora pinning.
//! 3. Iwe unofanirwa kuve nechokwadi chekuti unotsigira iyo [`Drop` guarantee][drop-guarantee]:
//!     kana yako yakarongedzwa, ndangariro ine izvo zvemukati haina kunyorwa kana kuendeswa kunze kwekudaidza vanoparadza zvemukati.
//!     Izvi zvinogona kuve zvinonyengera, sekupupurirwa ne [`VecDeque<T>`]: muparadzi we [`VecDeque<T>`] anogona kutadza kufonera [`drop`] pazvinhu zvese kana mumwe wevaparadzi panics.Izvi zvinotyora vimbiso ye [`Drop`], nekuti inogona kutungamira kuzvinhu zvinotakurwa pasina mupambi wavo kudaidzwa.([`VecDeque<T>`] haina kufungidzira, saka izvi hazvikonzere kusanzwisisika.)
//! 4. Iwe haufanire kupa chero kumwe kuita kungaite kuti dhata riburitsirwe kunze kwenzvimbo dzekuvaka kana yako mhando yakanamirwa.Semuenzaniso, kana iyo struct iine [`Option<T>`] uye paine `kutora '-kuita pamwe nerudzi `fn(Pin<&mut Struct<T>>) -> Option<T>`, iko kushanda kunogona kushandiswa kufambisa `T` kunze kwepini `Struct<T>`-zvinoreva kuti kupinha hakugone kunge kuri kwemunda wakabata izvi data.
//!
//!     Kune mumwe muenzaniso wakaomarara wekufambisa dhata kubva parudzi rwakapihwa, fungidzira kana [`RefCell<T>`] yaive nenzira `fn get_pin_mut(self: Pin<&mut Self>) -> Pin<&mut T>`.
//!     Ipapo tinogona kuita zvinotevera:
//!
//!     ```compile_fail
//!     fn exploit_ref_cell<T>(rc: Pin<&mut RefCell<T>>) {
//!         { let p = rc.as_mut().get_pin_mut(); } // Here we get pinned access to the `T`.
//!         let rc_shr: &RefCell<T> = rc.into_ref().get_ref();
//!         let b = rc_shr.borrow_mut();
//!         let content = &mut *b; // And here we have `&mut T` to the same data.
//!     }
//!     ```
//!
//!     Uku kune njodzi, zvinoreva kuti isu tinogona kutanga tanyora zvirimo mu [`RefCell<T>`] (tichishandisa `RefCell::get_pin_mut`) tobva tafambisa izvo zvemukati tichishandisa chinongedzo chinoshanduka chatakawana gare gare.
//!
//! ## Examples
//!
//! Yerudzi rwakaita se [`Vec<T>`], ese mikana (yekumisikidza kupinha kana kwete) zvine musoro.
//! [`Vec<T>`] ine pini yakaumbwa inogona kunge iine nzira dze `get_pin`/`get_pin_mut` dzekutorerwa mareferenzi kuzvinhu.Nekudaro, iyo haigone * kubvumidza kufona [`pop`][Vec::pop] pane yakanyorwa [`Vec<T>`] nekuti izvo zvinofambisa izvo (zvakagadzirwa zvakapetwa) zvirimo!Kana kukwanisa kubvumira [`push`][Vec::push], iyo inogona kuisazve nzvimbo uye nekudaro kufambisa zvirimo.
//!
//! [`Vec<T>`] isina kupinza kwechimiro inogona `impl<T> Unpin for Vec<T>`, nekuti zvirimo hazvina kumbopinhwa uye iyo [`Vec<T>`] pachayo yakanaka nekufambisawo.
//! Panguva iyoyo kupinza hakune zvainoita pa vector zvachose.
//!
//! Mune raibhurari yakajairwa, mhando dze pointer kazhinji hadzina pini yekuumbwa, uye nekudaro hadzisi kupa zvinofungidzirwa.Ichi ndicho chikonzero `Box<T>: Unpin` inobata zvese `T`.
//! Zvinoita zvine musoro kuita izvi zvemhando dzechivo, nekuti kufambisa `Box<T>` hakunyatso kufambisa iyo `T`: iyo [`Box<T>`] inogona kufambiswa zvakasununguka (aka `Unpin`) kunyangwe iyo `T` isiri.Muchokwadi, kunyangwe [`Pin`]`<<[`Bhokisi`]`<T>> `uye [` Pin`]`<&mut T>` vanogara vari [`Unpin`] pachavo, nekuda kwechikonzero chimwe chete: zvirimo (iyo `T`) zvakanyorerwa, asi zvinongedzo pachazvo zvinogona kufambiswa pasina kufambisa iro rakabayirwa.
//! Kune ese ari maviri [`Box<T>`] uye [`Pin`]`<`[`Bhokisi`] `<T>>`, kunyangwe zvirimo zvakabayirirwa zvakazvimiririra zvachose kana icho chinongedzo chakanyorerwa, zvichireva kuti kupina hakusi * kwechimiro.
//!
//! Paunenge uchiita mubatanidzwa we [`Future`], uchawanzoda pini yekuumbwa kweiyo nested futures, sezvo iwe uchida kupihwa mareferenzi kwavari kuti vafonere [`poll`].
//! Asi kana mubatanidzi wako aine chero imwe data iyo isingade kupendwa, unogona kuita kuti iwo masango asagadzike uye nekudaro unovasununguka kuwana iwo nechinoshandurwa chinongedzo kunyangwe paunenge uchingova ne "`Pin`] `<&mut Self>` `(such sezvazviri mune yako wega [`poll`] kuitiswa).
//!
//! [`Deref`]: crate::ops::Deref
//! [`DerefMut`]: crate::ops::DerefMut
//! [`mem::swap`]: crate::mem::swap
//! [`mem::forget`]: crate::mem::forget
//! [`Box<T>`]: ../../std/boxed/struct.Box.html
//! [`Vec<T>`]: ../../std/vec/struct.Vec.html
//! [`Vec::set_len`]: ../../std/vec/struct.Vec.html#method.set_len
//! [`Box`]: ../../std/boxed/struct.Box.html
//! [Vec::pop]: ../../std/vec/struct.Vec.html#method.pop
//! [Vec::push]: ../../std/vec/struct.Vec.html#method.push
//! [`Rc`]: ../../std/rc/struct.Rc.html
//! [`RefCell<T>`]: crate::cell::RefCell
//! [`drop`]: Drop::drop
//! [`VecDeque<T>`]: ../../std/collections/struct.VecDeque.html
//! [`Some(v)`]: Some
//! [`ptr::write`]: crate::ptr::write
//! [`Future`]: crate::future::Future
//! [drop-impl]: #drop-implementation
//! [drop-guarantee]: #drop-guarantee
//! [`poll`]: crate::future::Future::poll
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "pin", since = "1.33.0")]

use crate::cmp::{self, PartialEq, PartialOrd};
use crate::fmt;
use crate::hash::{Hash, Hasher};
use crate::marker::{Sized, Unpin};
use crate::ops::{CoerceUnsized, Deref, DerefMut, DispatchFromDyn, Receiver};

/// Chakanongedzwa.
///
/// Ichi chinoputira chakatenderedza mhando yechinongedzo chinoita kuti pointer "pin" ive kukosha kwayo munzvimbo, ichidzivirira kukosha kwakadomwa nekwe pointer kuti isafambiswe kunze kwekunge yaita [`Unpin`].
///
///
/// *Ona iyo [`pin` module] zvinyorwa zveitsananguro yekupina.*
///
/// [`pin` module]: self
///
// Note: iyo `Clone` inotora pazasi inokonzeresa sezvo zvichikwanisika kuitisa
// `Clone` kune zvinoshandurwa zvinongedzo.
// Ona <https://internals.rust-lang.org/t/unsoundness-in-pin/11311> kuti uwane rumwe ruzivo.
#[stable(feature = "pin", since = "1.33.0")]
#[lang = "pin"]
#[fundamental]
#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct Pin<P> {
    pointer: P,
}

// Aya anotevera mashandisiro haana kutorwa kuitira kudzivirira kusagadzikana nyaya.
// `&self.pointer` haifanire kuwanikwa kune isina kuvimbika trait kuita.
//
// Ona <https://internals.rust-lang.org/t/unsoundness-in-pin/11311/73> kuti uwane rumwe ruzivo.
//

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialEq<Pin<Q>> for Pin<P>
where
    P::Target: PartialEq<Q::Target>,
{
    fn eq(&self, other: &Pin<Q>) -> bool {
        P::Target::eq(self, other)
    }

    fn ne(&self, other: &Pin<Q>) -> bool {
        P::Target::ne(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Eq>> Eq for Pin<P> {}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref, Q: Deref> PartialOrd<Pin<Q>> for Pin<P>
where
    P::Target: PartialOrd<Q::Target>,
{
    fn partial_cmp(&self, other: &Pin<Q>) -> Option<cmp::Ordering> {
        P::Target::partial_cmp(self, other)
    }

    fn lt(&self, other: &Pin<Q>) -> bool {
        P::Target::lt(self, other)
    }

    fn le(&self, other: &Pin<Q>) -> bool {
        P::Target::le(self, other)
    }

    fn gt(&self, other: &Pin<Q>) -> bool {
        P::Target::gt(self, other)
    }

    fn ge(&self, other: &Pin<Q>) -> bool {
        P::Target::ge(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Ord>> Ord for Pin<P> {
    fn cmp(&self, other: &Self) -> cmp::Ordering {
        P::Target::cmp(self, other)
    }
}

#[stable(feature = "pin_trait_impls", since = "1.41.0")]
impl<P: Deref<Target: Hash>> Hash for Pin<P> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        P::Target::hash(self, state);
    }
}

impl<P: Deref<Target: Unpin>> Pin<P> {
    /// Gadzira `Pin<P>` nyowani kutenderedza pointer kune imwe data yerudzi iyo inoshandisa [`Unpin`].
    ///
    /// Kusiyana ne `Pin::new_unchecked`, iyi nzira yakachengeteka nekuti iyo pointer `P` inodzokorora kune [`Unpin`] mhando, iyo inokanzura iyo pinning inovimbisa.
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn new(pointer: P) -> Pin<P> {
        // SAFETY: kukosha kwakanongedzerwa ku `Unpin`, uye saka haina zvido
        // kukomberedza kupina.
        unsafe { Pin::new_unchecked(pointer) }
    }

    /// Unwraps iyi `Pin<P>` inodzosera iyo yepasi pointer.
    ///
    /// Izvi zvinoda kuti iyo data iri mukati meiyi `Pin` i [`Unpin`] kuitira kuti tigone kufuratira zvinomira zvinonamira patinomavhura.
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const fn into_inner(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: Deref> Pin<P> {
    /// Gadzira `Pin<P>` nyowani kutenderedza chirevo kune imwe dhata yerudzi iyo inogona kana isingakwanise kushandisa `Unpin`.
    ///
    /// Kana `pointer` ichidudzira kune `Unpin` mhando, `Pin::new` inofanira kushandiswa pachinzvimbo.
    ///
    /// # Safety
    ///
    /// Uyu muvaki haana kuchengetedzeka nekuti hatigone kuvimbisa kuti iyo data yakanongedzerwa ne `pointer` yakanamirwa, zvichireva kuti iyo data haizofambiswa kana kuchengetwa kwayo kusimbiswa kusvikira yadonhedzwa.
    /// Kana iyo `Pin<P>` yakavakwa isingavimbise kuti iyo data `P` inonongedza yakanyorerwa, iko kutyora chibvumirano cheAPI uye kunogona kutungamira kune isina kujekeswa maitiro mune anotevera (safe) mashandiro.
    ///
    /// Nekushandisa nzira iyi, urikugadzira promise nezve `P::Deref` uye `P::DerefMut` kuitiswa, kana zviripo.
    /// Zvinonyanya kukosha, havafanire kubuda kunze kwenharo dzavo `self`: `Pin::as_mut` uye `Pin::as_ref` vachasheedza `DerefMut::deref_mut` uye `Deref::deref`*pane yakanamirwa pointer* uye vanotarisira kuti nzira idzi kusimudzira zvinopinza zvinopinda.
    /// Zvakare, nekudana nzira iyi iwe promise kuti chirevo `P` chirevo chisingazobudiswazve;kunyanya, hazvifanirwe kunge zvichikwanisika kuwana `&mut P::Target` wobva wabuda kunze kwereferenzi (uchishandisa, semuenzaniso [`mem::swap`]).
    ///
    ///
    /// Semuenzaniso, kufonera `Pin::new_unchecked` pane `&'a mut T` hakuna kuchengeteka nekuti kunyangwe iwe uchikwanisa kuibaya kweiyo nguva yakapihwa `'a`, hauna simba pamusoro pekuti inochengetwa yakanyorwa kamwe chete `'a` yapera:
    ///
    /// ```
    /// use std::mem;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_ref<T>(mut a: T, mut b: T) {
    ///     unsafe {
    ///         let p: Pin<&mut T> = Pin::new_unchecked(&mut a);
    ///         // Izvi zvinofanirwa kureva kuti pointee `a` haigone kufamba zvakare.
    ///     }
    ///     mem::swap(&mut a, &mut b);
    ///     // Kero ye `a` yakachinja kuita` b's stack slot, saka `a` yakafambiswa kunyangwe isu takamboiisa!Tatyora chibvumirano chePINning API.
    /////
    /// }
    /// ```
    ///
    /// Iko kukosha, kana kambopetwa, kunofanirwa kuramba kwakapetwa nekusingaperi (kunze kwekunge mhando yayo ikashandisa `Unpin`).
    ///
    /// Saizvozvowo, kudaidza `Pin::new_unchecked` pa `Rc<T>` hakuna kuchengeteka nekuti panogona kunge paine mabhaisikopu kune imwechete data iyo isiri pasi pemitemo yekupina:
    ///
    /// ```
    /// use std::rc::Rc;
    /// use std::pin::Pin;
    ///
    /// fn move_pinned_rc<T>(mut x: Rc<T>) {
    ///     let pinned = unsafe { Pin::new_unchecked(Rc::clone(&x)) };
    ///     {
    ///         let p: Pin<&T> = pinned.as_ref();
    ///         // Izvi zvinofanirwa kureva kuti pointee haigone kufamba zvakare.
    ///     }
    ///     drop(pinned);
    ///     let content = Rc::get_mut(&mut x).unwrap();
    ///     // Zvino, kana `x` yaive iyo chete referenzi, isu tine revo inogona kuchinjika kune data ratakanongedza pamusoro, iro rataigona kushandisa kurifambisa sezvataona mumuenzaniso wapfuura.
    ///     // Tatyora chibvumirano chePINning API.
    /////
    ///  }
    ///  ```
    ///
    /// [`mem::swap`]: crate::mem::swap
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[lang = "new_unchecked"]
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const unsafe fn new_unchecked(pointer: P) -> Pin<P> {
        Pin { pointer }
    }

    /// Inowana yakanongedzwa yakagovaniswa mareferenzi kubva kune yakapihwa pointer.
    ///
    /// Iyi inzira yakajairwa yekubva ku `&Pin<Pointer<T>>` kuenda ku `Pin<&T>`.
    /// Iyo yakachengeteka nekuti, sechikamu chechibvumirano che `Pin::new_unchecked`, iyo poi haigone kufamba mushure mekunge `Pin<Pointer<T>>` yagadzirwa.
    ///
    /// "Malicious" kumisikidza kwe `Pointer::Deref` zvakafanirwawo kunze nechibvumirano che `Pin::new_unchecked`.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_ref(&self) -> Pin<&P::Target> {
        // Kachengeteka: ona zvinyorwa pane iri basa
        unsafe { Pin::new_unchecked(&*self.pointer) }
    }

    /// Unwraps iyi `Pin<P>` inodzosera iyo yepasi pointer.
    ///
    /// # Safety
    ///
    /// Iri basa harina kuchengeteka.Iwe unofanirwa kuvimbisa kuti iwe ucharamba uchirapa iyo pointer `P` seyakaiswa mushure mekufona basa iri, kuitira kuti zvinopinda murudzi rwe `Pin` zvigone kutsigirwa.
    /// Kana iyo kodhi inoshandisa iyo inoguma `P` isingarambe ichichengeta iyo yekupinha zvinopesana iko kutyora chibvumirano cheAPI uye kunogona kutungamira kune isina kujekeswa maitiro mune anotevera (safe) mashandiro.
    ///
    ///
    /// Kana iyo yepasi data iri [`Unpin`], [`Pin::into_inner`] inofanira kushandiswa panzvimbo.
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin_into_inner", since = "1.39.0")]
    pub const unsafe fn into_inner_unchecked(pin: Pin<P>) -> P {
        pin.pointer
    }
}

impl<P: DerefMut> Pin<P> {
    /// Inowana yakanamirwa inogona kuchinjika chirevo kubva kune yakapihwa pointer.
    ///
    /// Iyi inzira yakajairwa yekubva ku `&mut Pin<Pointer<T>>` kuenda ku `Pin<&mut T>`.
    /// Iyo yakachengeteka nekuti, sechikamu chechibvumirano che `Pin::new_unchecked`, iyo poi haigone kufamba mushure mekunge `Pin<Pointer<T>>` yagadzirwa.
    ///
    /// "Malicious" kumisikidza kwe `Pointer::DerefMut` zvakafanirwawo kunze nechibvumirano che `Pin::new_unchecked`.
    ///
    /// Iyi nzira inobatsira kana uchiita akawanda mafoni kune mabasa ayo anodya akapihwa mhando.
    ///
    /// # Example
    ///
    /// ```
    /// use std::pin::Pin;
    ///
    /// # struct Type {}
    /// impl Type {
    ///     fn method(self: Pin<&mut Self>) {
    ///         // ita chimwe chinhu
    ///     }
    ///
    ///     fn call_method_twice(mut self: Pin<&mut Self>) {
    ///         // `method` inoshandisa `self`, saka dzosera `Pin<&mut Self>` kuburikidza ne `as_mut`.
    ///         self.as_mut().method();
    ///         self.as_mut().method();
    ///     }
    /// }
    /// ```
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn as_mut(&mut self) -> Pin<&mut P::Target> {
        // Kachengeteka: ona zvinyorwa pane iri basa
        unsafe { Pin::new_unchecked(&mut *self.pointer) }
    }

    /// Inopa kukosha kutsva mundangariro kuseri kweyakaremberedzwa chirevo.
    ///
    /// Izvi zvinonyora zvakabayirwa dhata, asi izvo zvakanaka: muparadzi wayo anomhanya asati anyorwa, saka hapana kuvimbisa kwepini kunotyorwa.
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    #[inline(always)]
    pub fn set(&mut self, value: P::Target)
    where
        P::Target: Sized,
    {
        *(self.pointer) = value;
    }
}

impl<'a, T: ?Sized> Pin<&'a T> {
    /// Inovaka pini nyowani nekumaka kukosha kwemukati.
    ///
    /// Semuenzaniso, kana iwe waida kutora `Pin` yemunda wechimwe chinhu, unogona kushandisa izvi kuwana mukana kune iwo munda mune imwe tambo yekodhi.
    /// Nekudaro, kune akati wandei gotchas neaya "pinning projections";
    /// ona iyo [`pin` module] zvinyorwa kuti uwane rumwe ruzivo pane iyo musoro wenyaya.
    ///
    /// # Safety
    ///
    /// Iri basa harina kuchengeteka.
    /// Iwe unofanirwa kuvimbisa kuti iyo data yaunodzoka haifambe kwenguva yakareba sezvo kukosha kwekupokana kusingafambi (semuenzaniso, nekuti ndeimwe yeminda yeiyo kukosha), uyezve kuti haubve kunze kwegakava raunogashira basa remukati.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked<U, F>(self, func: F) -> Pin<&'a U>
    where
        U: ?Sized,
        F: FnOnce(&T) -> &U,
    {
        let pointer = &*self.pointer;
        let new_pointer = func(pointer);

        // Kachengeteka: chibvumirano chekuchengetedza che `new_unchecked` chinofanira kunge chiri
        // yakasimudzwa nemunhu akafona.
        unsafe { Pin::new_unchecked(new_pointer) }
    }

    /// Inowana mareferenzi akagovaniswa kunze kwepini.
    ///
    /// Izvi zvakachengeteka nekuti hazviite kuti ubve pane yakagovaniswa mareferensi.
    /// Zvingaite senge pane nyaya pano nekuchinja kwemukati: muchokwadi, zviri * zvinogoneka kufambisa `T` kunze kwe `&RefCell<T>`.
    /// Nekudaro, iri harisi dambudziko chero bedzi pasinawo iyo `Pin<&T>` inonongedzera kune imwechete data, uye `RefCell<T>` haikuregi iwe ugadzire yakanamirwa mareferenzi kune zvirimo.
    ///
    /// Ona hurukuro pa ["pinning projections"] kuti uwane rumwe ruzivo.
    ///
    /// Note: `Pin` zvakare inoshandisa `Deref` kune yakanangwa, iyo inogona kushandiswa kuwana kukosha kwemukati.
    /// Nekudaro, `Deref` inopa chete chirevo chinorarama kwenguva yakareba sekukwereta kwe `Pin`, kwete hupenyu hwese hwe `Pin` pachayo.
    /// Iyi nzira inobvumidza kushandura iyo `Pin` kuita chirevo neupenyu hwakafanana neiyo yekutanga `Pin`.
    ///
    /// ["pinning projections"]: self#projections-and-structural-pinning
    ///
    ///
    ///
    ///
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn get_ref(self) -> &'a T {
        self.pointer
    }
}

impl<'a, T: ?Sized> Pin<&'a mut T> {
    /// Inoshandura iyi `Pin<&mut T>` kuita `Pin<&T>` ine hupenyu hwakafanana.
    #[inline(always)]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    #[stable(feature = "pin", since = "1.33.0")]
    pub const fn into_ref(self) -> Pin<&'a T> {
        Pin { pointer: self.pointer }
    }

    /// Inowana chirevo chinoshanduka kune iyo data mukati meiyi `Pin`.
    ///
    /// Izvi zvinoda kuti iyo data iri mukati me `Pin` i `Unpin`.
    ///
    /// Note: `Pin` zvakare inoshandisa `DerefMut` kune iyo data, iyo inogona kushandiswa kuwana kukosha kwemukati.
    /// Nekudaro, `DerefMut` inopa chete chirevo chinorarama kwenguva yakareba sekukwereta kwe `Pin`, kwete iyo hupenyu hwayo iyo `Pin` pachayo.
    ///
    /// Iyi nzira inobvumidza kushandura iyo `Pin` kuita chirevo neupenyu hwakafanana neiyo yekutanga `Pin`.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn get_mut(self) -> &'a mut T
    where
        T: Unpin,
    {
        self.pointer
    }

    /// Inowana chirevo chinoshanduka kune iyo data mukati meiyi `Pin`.
    ///
    /// # Safety
    ///
    /// Iri basa harina kuchengeteka.
    /// Iwe unofanirwa kuvimbisa kuti haufe wakambofambisa iyo data kunze kweinogona kuchinjika referensi iwe yaunogamuchira kana iwe uchisheedza iri basa, kuitira kuti zvinopinda murudzi rwe `Pin` mhando zvigone kutsigirwa.
    ///
    ///
    /// Kana iyo yepasi data iri `Unpin`, `Pin::get_mut` inofanira kushandiswa panzvimbo.
    ///
    #[inline(always)]
    #[stable(feature = "pin", since = "1.33.0")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const unsafe fn get_unchecked_mut(self) -> &'a mut T {
        self.pointer
    }

    /// Gadzira pini nyowani nekumaka kukosha kwemukati.
    ///
    /// Semuenzaniso, kana iwe waida kutora `Pin` yemunda wechimwe chinhu, unogona kushandisa izvi kuwana mukana kune iwo munda mune imwe tambo yekodhi.
    /// Nekudaro, kune akati wandei gotchas neaya "pinning projections";
    /// ona iyo [`pin` module] zvinyorwa kuti uwane rumwe ruzivo pane iyo musoro wenyaya.
    ///
    /// # Safety
    ///
    /// Iri basa harina kuchengeteka.
    /// Iwe unofanirwa kuvimbisa kuti iyo data yaunodzoka haifambe kwenguva yakareba sezvo kukosha kwekupokana kusingafambi (semuenzaniso, nekuti ndeimwe yeminda yeiyo kukosha), uyezve kuti haubve kunze kwegakava raunogashira basa remukati.
    ///
    ///
    /// [`pin` module]: self#projections-and-structural-pinning
    ///
    ///
    #[stable(feature = "pin", since = "1.33.0")]
    pub unsafe fn map_unchecked_mut<U, F>(self, func: F) -> Pin<&'a mut U>
    where
        U: ?Sized,
        F: FnOnce(&mut T) -> &mut U,
    {
        // Kachengeteka: iye anofona ane basa rekusatamisa iyo
        // value kunze kweichi chirevo.
        let pointer = unsafe { Pin::get_unchecked_mut(self) };
        let new_pointer = func(pointer);
        // Kachengeteka: sezvo kukosha kwe `this` kunovimbiswa kusave nako
        // yabviswa kunze, kufona iyi ku `new_unchecked` kwakachengeteka.
        unsafe { Pin::new_unchecked(new_pointer) }
    }
}

impl<T: ?Sized> Pin<&'static T> {
    /// Tora chinongedzo chakapetwa kubva kune yakatarwa static.
    ///
    /// Izvi zvakachengeteka, nekuti `T` inokweretwa yeiyo `'static` yeupenyu hwese, iyo isingatombopera.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_ref(r: &'static T) -> Pin<&'static T> {
        // Kachengeteka: Iyo 'static yekukwereta inovimbisa iyo data haizove
        // moved/invalidated kusvikira yadonha (izvo zvisati zvamboitika).
        unsafe { Pin::new_unchecked(r) }
    }
}

impl<T: ?Sized> Pin<&'static mut T> {
    /// Tora yakanamirwa inogona kuchinjika chirevo kubva kune isingachinjiki inoshanduka referensi
    ///
    /// Izvi zvakachengeteka, nekuti `T` inokweretwa yeiyo `'static` yeupenyu hwese, iyo isingatombopera.
    ///
    #[unstable(feature = "pin_static_ref", issue = "78186")]
    #[rustc_const_unstable(feature = "const_pin", issue = "76654")]
    pub const fn static_mut(r: &'static mut T) -> Pin<&'static mut T> {
        // Kachengeteka: Iyo 'static yekukwereta inovimbisa iyo data haizove
        // moved/invalidated kusvikira yadonha (izvo zvisati zvamboitika).
        unsafe { Pin::new_unchecked(r) }
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: Deref> Deref for Pin<P> {
    type Target = P::Target;
    fn deref(&self) -> &P::Target {
        Pin::get_ref(Pin::as_ref(self))
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: DerefMut<Target: Unpin>> DerefMut for Pin<P> {
    fn deref_mut(&mut self) -> &mut P::Target {
        Pin::get_mut(Pin::as_mut(self))
    }
}

#[unstable(feature = "receiver_trait", issue = "none")]
impl<P: Receiver> Receiver for Pin<P> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Debug> fmt::Debug for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Display> fmt::Display for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&self.pointer, f)
    }
}

#[stable(feature = "pin", since = "1.33.0")]
impl<P: fmt::Pointer> fmt::Pointer for Pin<P> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.pointer, f)
    }
}

// Note: izvi zvinoreva kuti chero chinomisikidzwa che `CoerceUnsized` chinotendera kumanikidza kubva
// mhando inoisa `Deref<Target=impl !Unpin>` kune imwe mhando inoisa `Deref<Target=Unpin>` haina chokwadi.
// Chero ipi implm yakadaro ingangove isina kujeka nekuda kwezvimwe zvikonzero, zvakadaro, saka isu tinongoda kutora hanya kuti tisabvumire ma impls akadaro kumhara mu std.
//
//
#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> CoerceUnsized<Pin<U>> for Pin<P> where P: CoerceUnsized<U> {}

#[stable(feature = "pin", since = "1.33.0")]
impl<P, U> DispatchFromDyn<Pin<U>> for Pin<P> where P: DispatchFromDyn<U> {}