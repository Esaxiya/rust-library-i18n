// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Inotenderedza renji `[mid-left, mid+right)` zvekuti chinhu chiri pa `mid` chinova chinhu chekutanga.Saizvozvowo, inotenderedza huwandu `left` zvinhu kuruboshwe kana `right` zvinhu kurudyi.
///
/// # Safety
///
/// Iyo yakatarwa renji inofanirwa kuve inoshanda pakuverenga nekunyora.
///
/// # Algorithm
///
/// Algorithm 1 inoshandiswa pamitengo midiki ye `left + right` kana yakakura `T`.
/// Zvinhu zvacho zvinofambiswa munzvimbo dzazvo dzekupedzisira imwe panguva kutanga pa `mid - left` uye kufambira mberi ne `right` nhanho modulo `left + right`, zvekuti ingori imwechete yenguva pfupi inodiwa.
/// Pakupedzisira, tinodzoka ku `mid - left`.
/// Nekudaro, kana `gcd(left + right, right)` isiri 1, matanho ari pamusoro akasvetuka pamusoro pezvinhu.
/// Semuyenzaniso:
///
/// ```text
/// left = 10, right = 6
/// the `^` indicates an element in its final place
/// 6 7 8 9 10 11 12 13 14 15 . 0 1 2 3 4 5
/// after using one step of the above algorithm (The X will be overwritten at the end of the round,
/// and 12 is stored in a temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 2 3 4 5
///               ^
/// after using another step (now 2 is in the temporary):
/// X 7 8 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///               ^                 ^
/// after the third step (the steps wrap around, and 8 is in the temporary):
/// X 7 2 9 10 11 6 13 14 15 . 0 1 12 3 4 5
///     ^         ^                 ^
/// after 7 more steps, the round ends with the temporary 0 getting put in the X:
/// 0 7 2 9 4 11 6 13 8 15 . 10 1 12 3 14 5
/// ^   ^   ^    ^    ^       ^    ^    ^
/// ```
///
/// Neraki, iyo nhamba yekusvetuka pamusoro pezvinhu pakati pezvakapedzwa inogara yakaenzana, saka tinogona kungoisa nzvimbo yedu yekutanga uye kuita mamwe maround (huwandu hwakazara hwekutenderera i `gcd(left + right, right)` value).
///
/// Mhedzisiro mhedzisiro ndeyekuti zvese zvinhu zvinogadziriswa kamwe uye kamwe chete.
///
/// Algorithm 2 inoshandiswa kana `left + right` yakakura asi `min(left, right)` idiki zvakakwana kuti ikwane padanda rekuisira.
/// Zvinhu zve `min(left, right)` zvinoteedzerwa pane iyo buffer, `memmove` inoiswa kune vamwe, uye iwo ari pabhafa anodzoserwa mugomba kune iro divi rakatarisana nekwavakatangira.
///
/// Maalgorithms anokwanisa kuverengerwa kupfuura aya ari pamusoro kamwe `left + right` ikava yakakura zvakakwana.
/// Algorithm 1 inogona kuverengerwa nekukanda uye kuita akawanda maround kamwechete, asi kune mashoma mashoma maranzi paavhareji kusvika `left + right` yakakura kwazvo, uye nyaya yakaipa kwazvo yekutenderera kumwe chete inogara iriko.
/// Panzvimbo iyoyo, algorithm 3 inoshandisa kudzokorora kuchinjaniswa kwe `min(left, right)` zvinhu kusvikira dambudziko diki rekutenderera rasara.
///
/// ```text
/// left = 11, right = 4
/// [4 5 6 7 8 9 10 11 12 13 14 . 0 1 2 3]
///                  ^  ^  ^  ^   ^ ^ ^ ^ swapping the right most elements with elements to the left
/// [4 5 6 7 8 9 10 . 0 1 2 3] 11 12 13 14
///        ^ ^ ^  ^   ^ ^ ^ ^ swapping these
/// [4 5 6 . 0 1 2 3] 7 8 9 10 11 12 13 14
/// we cannot swap any more, but a smaller rotation problem is left to solve
/// ```
/// kana `left < right` kuchinjika kunoitika kubva kuruboshwe pachinzvimbo.
///
///
///
///
///
pub unsafe fn ptr_rotate<T>(mut left: usize, mut mid: *mut T, mut right: usize) {
    type BufType = [usize; 32];
    if mem::size_of::<T>() == 0 {
        return;
    }
    loop {
        // N.B. ari pazasi algorithms anogona kutadza kana aya kesi asina kuongororwa
        if (right == 0) || (left == 0) {
            return;
        }
        if (left + right < 24) || (mem::size_of::<T>() > mem::size_of::<[usize; 4]>()) {
            // Algorithm 1 Microbenchmarks inoratidza kuti avhareji mashandiro ekuchinja kusarongeka ari nani munzira yese kusvika ingangoita `left + right == 32`, asi chiitiko chakaipisisa chinotsemuka kana kutenderedza 16.
            // 24 yakasarudzwa sepakati pevhu.
            // Kana saizi ye `T` yakakura kudarika mana `usize`s, iyi algorithm zvakare inopfuura mamwe maalgorithms.
            //
            //
            let x = unsafe { mid.sub(left) };
            // kutanga kweround rekutanga
            let mut tmp: T = unsafe { x.read() };
            let mut i = right;
            // `gcd` inogona kuwanikwa pamberi pemaoko nekuverenga `gcd(left + right, right)`, asi iri kukurumidza kuita chiuno chimwe chinoverenga iyo gcd sechinhu padivi, wozoita iyo yakasara yeiyo chunk
            //
            //
            let mut gcd = right;
            // mabhenji anoratidza kuti iri kukurumidza kuchinjanisa ma temporari nzira yese kuburikidza nekuverenga imwe yenguva pfupi kamwe, kuteedzera kumashure, uyezve kunyora iyo yenguva pfupi pakupedzisira.
            // Izvi zvinogona kunge zvichikonzerwa nekuti kuchinjisa kana kutsiva ma temporari kunoshandisa chete kero yekurangarira muchiuno pane kuda kubata maviri.
            //
            //
            loop {
                tmp = unsafe { x.add(i).replace(tmp) };
                // pachinzvimbo chekuwedzera `i` uyezve kutarisa kana iri kunze kwemiganhu, tinotarisa kana `i` ichaenda kunze kwemiganhu pane inotevera kuwedzera.
                // Izvi zvinodzivirira chero kuputirwa kwema pointers kana `usize`.
                //
                if i >= left {
                    i -= left;
                    if i == 0 {
                        // kupera kweround rekutanga
                        unsafe { x.write(tmp) };
                        break;
                    }
                    // mamiriro aya anofanira kunge ari pano kana `left + right >= 15`
                    if i < gcd {
                        gcd = i;
                    }
                } else {
                    i += right;
                }
            }
            // pedzisa chunk nekuwedzera kutenderera
            for start in 1..gcd {
                tmp = unsafe { x.add(start).read() };
                i = start + right;
                loop {
                    tmp = unsafe { x.add(i).replace(tmp) };
                    if i >= left {
                        i -= left;
                        if i == start {
                            unsafe { x.add(start).write(tmp) };
                            break;
                        }
                    } else {
                        i += right;
                    }
                }
            }
            return;
        // `T` haisi zero-saizi mhando, saka zvakanaka kupatsanura nehukuru hwayo.
        } else if cmp::min(left, right) <= mem::size_of::<BufType>() / mem::size_of::<T>() {
            // Algorithm 2 Iyo `[T; 0]` apa ndeyekuona kuti izvi zvakanyatsoenderana neT
            //
            let mut rawarray = MaybeUninit::<(BufType, [T; 0])>::uninit();
            let buf = rawarray.as_mut_ptr() as *mut T;
            let dim = unsafe { mid.sub(left).add(right) };
            if left <= right {
                unsafe {
                    ptr::copy_nonoverlapping(mid.sub(left), buf, left);
                    ptr::copy(mid, mid.sub(left), right);
                    ptr::copy_nonoverlapping(buf, dim, left);
                }
            } else {
                unsafe {
                    ptr::copy_nonoverlapping(mid, buf, right);
                    ptr::copy(mid.sub(left), dim, left);
                    ptr::copy_nonoverlapping(buf, mid.sub(left), right);
                }
            }
            return;
        } else if left >= right {
            // Algorithm 3 Pane imwe nzira yekuchinjisa iyo inosanganisira kutsvaga iko kuchinjika kwekupedzisira kweiyi algorithm kungave, uye kuchinjanisa uchishandisa iyo yekupedzisira chunk pachinzvimbo chekuchinjanisa padhuze machunks seiyi algorithm iri kuita, asi iyi nzira ichiri kukurumidza.
            //
            //
            //
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(right), mid, right);
                    mid = mid.sub(right);
                }
                left -= right;
                if left < right {
                    break;
                }
            }
        } else {
            // Algorithm 3, `left < right`
            loop {
                unsafe {
                    ptr::swap_nonoverlapping(mid.sub(left), mid, left);
                    mid = mid.add(left);
                }
                right -= left;
                if right < left {
                    break;
                }
            }
        }
    }
}