//! Mahara mabasa ekugadzira `&[T]` uye `&mut [T]`.

use crate::array;
use crate::intrinsics::is_aligned_and_not_null;
use crate::mem;
use crate::ptr;

/// Inoita chidimbu kubva kunongedzera uye kureba.
///
/// Iyo `len` nharo ndiyo nhamba ye **zvinhu**, kwete iyo nhamba yemabheti.
///
/// # Safety
///
/// Maitiro haana kujekeswa kana chero eanotevera mamiriro akatyorwa:
///
/// * `data` inofanirwa kunge iri [valid] yekuverenga kwe `len * mem::size_of::<T>()` mabheti mazhinji, uye inofanirwa kunyatsoenderana.Izvi zvinoreva kunyanya:
///
///     * Iyo yese yekurangarira huwandu hweichi chidimbu chinofanirwa kunge chiri mukati mechinhu chimwe chakapihwa chinhu!
///       Slices haambofi akatenderera pane akawanda akagoverwa zvinhu.Ona [below](#incorrect-usage) semuenzaniso zvisirizvo zvisiri kufunga izvi.
///     * `data` inofanirwa kunge isiri-null uye inowirirana kunyangwe zero-kureba zvidimbu.
///     Chimwe chikonzero cheichi ndechekuti enum marongero ekugadzirisa anogona kuvimba nezvirevo (kusanganisira zvidimbu zvehurefu chero hupi) uchienderana uye usiri-null kuvasiyanisa kubva kune imwe data.
///     Iwe unogona kuwana pointer iyo inoshandiswa se `data` yemazero-kureba zvidimbu uchishandisa [`NonNull::dangling()`].
///
/// * `data` inofanirwa kunongedzera ku `len` inoteedzana nematanho ekutanga erudzi `T`.
///
/// * Ndangariro dzinotaurwa nesilice yakadzoserwa haifanire kuchinjika kwenguva yeupenyu `'a`, kunze kwemukati me `UnsafeCell`.
///
/// * Hurefu hwese `len * mem::size_of::<T>()` yechidimbu hachifanirwe kunge chakakura kupfuura `isize::MAX`.
///   Ona zvinyorwa zvekuchengetedza zve [`pointer::offset`].
///
/// # Caveat
///
/// Hupenyu hwese hwechikamu chakadzoserwa chinotorwa kubva mukushandiswa kwayo.
/// Kudzivirira kushandisa netsaona zvisina tsarukano, zvinokurudzirwa kusunga hupenyu hwese kune chero sosi yehupenyu yakachengeteka muchimiro, sekupa basa rekubatsira kutora hupenyu hwese hwekukoshesa kukosha kwechikamu, kana nerondedzero yakajeka.
///
///
/// # Examples
///
/// ```
/// use std::slice;
///
/// // ratidza chidimbu chechinhu chimwe chete
/// let x = 42;
/// let ptr = &x as *const _;
/// let slice = unsafe { slice::from_raw_parts(ptr, 1) };
/// assert_eq!(slice[0], 42);
/// ```
///
/// ### Kushandiswa zvisiri izvo
///
/// Inotevera `join_slices` basa iri **unsound** ⚠️
///
/// ```rust,no_run
/// use std::slice;
///
/// fn join_slices<'a, T>(fst: &'a [T], snd: &'a [T]) -> &'a [T] {
///     let fst_end = fst.as_ptr().wrapping_add(fst.len());
///     let snd_start = snd.as_ptr();
///     assert_eq!(fst_end, snd_start, "Slices must be contiguous!");
///     unsafe {
///         // Chirevo chiri pamusoro chinovimbisa kuti `fst` uye `snd` zvinoenderana, asi vanogona kunge vachirimo mukati me _different allocated objects_, mune iyo kesi kugadzira ichi chidimbu chisina kujekeswa maitiro.
/////
/////
///         slice::from_raw_parts(fst.as_ptr(), fst.len() + snd.len())
///     }
/// }
///
/// fn main() {
///     // `a` uye `b` zvinhu zvakasiyana zvakapihwa ...
///     let a = 42;
///     let b = 27;
///     // ... iyo ingangodaro yakaradzikwa zvinopesana mundangariro: |a |b |
///     let _ = join_slices(slice::from_ref(&a), slice::from_ref(&b)); // UB
/// }
/// ```
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts<'a, T>(data: *const T, len: usize) -> &'a [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // KUCHENGETEKA: iye anodana anofanirwa kuchengetedza chibvumirano chekuchengetedza che `from_raw_parts`.
    unsafe { &*ptr::slice_from_raw_parts(data, len) }
}

/// Inoita mashandiro akafanana ne [`from_raw_parts`], kunze kwekunge chidimbu chinoshanduka chadzoserwa.
///
/// # Safety
///
/// Maitiro haana kujekeswa kana chero eanotevera mamiriro akatyorwa:
///
/// * `data` inofanirwa kunge iri [valid] kune ese ari maviri anoverengwa uye anonyorera `len * mem::size_of::<T>()` mabheti mazhinji, uye inofanirwa kunge ichinyatsoenderana.Izvi zvinoreva kunyanya:
///
///     * Iyo yese yekurangarira huwandu hweichi chidimbu chinofanirwa kunge chiri mukati mechinhu chimwe chakapihwa chinhu!
///       Slices haambofi akatenderera pane akawanda akagoverwa zvinhu.
///     * `data` inofanirwa kunge isiri-null uye inowirirana kunyangwe zero-kureba zvidimbu.
///     Chimwe chikonzero cheichi ndechekuti enum marongero ekugadzirisa anogona kuvimba nezvirevo (kusanganisira zvidimbu zvehurefu chero hupi) uchienderana uye usiri-null kuvasiyanisa kubva kune imwe data.
///
///     Iwe unogona kuwana pointer iyo inoshandiswa se `data` yemazero-kureba zvidimbu uchishandisa [`NonNull::dangling()`].
///
/// * `data` inofanirwa kunongedzera ku `len` inoteedzana nematanho ekutanga erudzi `T`.
///
/// * Ndangariro dzinoratidzwa nesipo yakadzoserwa haifanire kuwanikwa kuburikidza nechero chinongedzo (chisina kubviswa pamutengo wekudzoka) kwenguva yehupenyu hwese `'a`.
///   Zvese zviri zviviri kuverenga uye kunyora zvinopinda zvinorambidzwa.
///
/// * Hurefu hwese `len * mem::size_of::<T>()` yechidimbu hachifanirwe kunge chakakura kupfuura `isize::MAX`.
///   Ona zvinyorwa zvekuchengetedza zve [`pointer::offset`].
///
/// [valid]: ptr#safety
/// [`NonNull::dangling()`]: ptr::NonNull::dangling
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn from_raw_parts_mut<'a, T>(data: *mut T, len: usize) -> &'a mut [T] {
    debug_assert!(is_aligned_and_not_null(data), "attempt to create unaligned or null slice");
    debug_assert!(
        mem::size_of::<T>().saturating_mul(len) <= isize::MAX as usize,
        "attempt to create slice covering at least half the address space"
    );
    // KUCHENGETEKA: iye anodana anofanirwa kuchengetedza chibvumirano chekuchengetedza che `from_raw_parts_mut`.
    unsafe { &mut *ptr::slice_from_raw_parts_mut(data, len) }
}

/// Inoshandura chirevo cheT kuita chidimbu chehurefu 1 (pasina kutevedzera).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_ref<T>(s: &T) -> &[T] {
    array::from_ref(s)
}

/// Inoshandura chirevo cheT kuita chidimbu chehurefu 1 (pasina kutevedzera).
#[stable(feature = "from_ref", since = "1.28.0")]
pub fn from_mut<T>(s: &mut T) -> &mut [T] {
    array::from_mut(s)
}