// Yekutanga kuitiswa kwakatorwa kubva ku rust-memchr.
// Copyright 2015 Andrew Gallant, bluss naNicolas Koch

use crate::cmp;
use crate::mem;

const LO_U64: u64 = 0x0101010101010101;
const HI_U64: u64 = 0x8080808080808080;

// Shandisa truncation.
const LO_USIZE: usize = LO_U64 as usize;
const HI_USIZE: usize = HI_U64 as usize;
const USIZE_BYTES: usize = mem::size_of::<usize>();

/// Inodzorera `true` kana `x` iine chero zero byte.
///
/// Kubva *Matters Computational*, J. Arndt:
///
/// "Pfungwa ndeyekubvisa imwe kubva kumabheti ega ega uye nekutsvaga mabheti uko chikwereti chakapararira kusvika pakukosha zvakanyanya."
///
/// bit."
#[inline]
fn contains_zero_byte(x: usize) -> bool {
    x.wrapping_sub(LO_USIZE) & !x & HI_USIZE != 0
}

#[cfg(target_pointer_width = "16")]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) << 8 | b as usize
}

#[cfg(not(target_pointer_width = "16"))]
#[inline]
fn repeat_byte(b: u8) -> usize {
    (b as usize) * (usize::MAX / 255)
}

/// Inodzorera iyo yekutanga indekisi inoenderana neye byte `x` mu `text`.
#[inline]
pub fn memchr(x: u8, text: &[u8]) -> Option<usize> {
    // Inokurumidza nzira yezvidimbu zvidiki
    if text.len() < 2 * USIZE_BYTES {
        return text.iter().position(|elt| *elt == x);
    }

    memchr_general_case(x, text)
}

fn memchr_general_case(x: u8, text: &[u8]) -> Option<usize> {
    // Skena kweyechete byte kukosha nekuverenga maviri `usize` mazwi panguva.
    //
    // Split `text` muzvikamu zvitatu
    // - isina kukamurwa chikamu chekutanga, pamberi peshoko rekutanga rakarongedzwa kero mune zvinyorwa
    // - muviri, tarisa nemazwi maviri panguva
    // - chikamu chekupedzisira chasara, <2 size size

    // tsvaga kusvika pamuganhu wakatarisana
    let len = text.len();
    let ptr = text.as_ptr();
    let mut offset = ptr.align_offset(USIZE_BYTES);

    if offset > 0 {
        offset = cmp::min(offset, len);
        if let Some(index) = text[..offset].iter().position(|elt| *elt == x) {
            return Some(index);
        }
    }

    // tsvaga mutumbi wechinyorwa
    let repeated_x = repeat_byte(x);
    while offset <= len - 2 * USIZE_BYTES {
        // KUCHENGETEKA: chirevo chenguva yacho chinovimbisa chinhambwe chingangoita 2 * usize_bytes
        // pakati pekukanganisa uye kupera kwechimedu.
        unsafe {
            let u = *(ptr.add(offset) as *const usize);
            let v = *(ptr.add(offset + USIZE_BYTES) as *const usize);

            // kutyora kana paine inowirirana byte
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset += USIZE_BYTES * 2;
    }

    // Tsvaga iyo tete mushure meiyo poindi iyo muviri chiuno chakamira.
    text[offset..].iter().position(|elt| *elt == x).map(|i| offset + i)
}

/// Inodzorera indekisi yekupedzisira inoenderana neye byte `x` mu `text`.
pub fn memrchr(x: u8, text: &[u8]) -> Option<usize> {
    // Skena kweyechete byte kukosha nekuverenga maviri `usize` mazwi panguva.
    //
    // Split `text` muzvikamu zvitatu:
    // - unaligned muswe, mushure mekupedzisira izwi rakatarisana kero mune zvinyorwa,
    // - muviri, yakavhenekwa nemazwi maviri panguva,
    // - mabheti ekutanga asara, <2 saizi yeshoko.
    let len = text.len();
    let ptr = text.as_ptr();
    type Chunk = usize;

    let (min_aligned_offset, max_aligned_offset) = {
        // Tinodaidza izvi kungo tiwane kureba kwekutanga uye chiremera.
        // Pakati tinogara tichigadzirisa zvidimbu zviviri kamwechete.
        // KUCHENGETEKA: kuendesa `[u8]` kuenda ku `[usize]` kwakachengeteka kunze kwekusiyana kwemasayizi anobatwa ne `align_to`.
        //
        let (prefix, _, suffix) = unsafe { text.align_to::<(Chunk, Chunk)>() };
        (prefix.len(), len - suffix.len())
    };

    let mut offset = max_aligned_offset;
    if let Some(index) = text[offset..].iter().rposition(|elt| *elt == x) {
        return Some(offset + index);
    }

    // Tsvaga mutumbi werugwaro, ita shuwa kuti hatiyambuke min_aligned_offset.
    // offset inogara ichienderana, saka kungoedza `>` kwakaringana uye kunodzivirira zvinoita kufashukira.
    //
    let repeated_x = repeat_byte(x);
    let chunk_bytes = mem::size_of::<Chunk>();

    while offset > min_aligned_offset {
        // Kachengeteka: offset inotanga pa len, suffix.len(), chero bedzi iri yakakura kudarika
        // min_aligned_offset (prefix.len()) iyo yakasara chinhambwe ingangoita 2 * chunk_bytes.
        unsafe {
            let u = *(ptr.offset(offset as isize - 2 * chunk_bytes as isize) as *const Chunk);
            let v = *(ptr.offset(offset as isize - chunk_bytes as isize) as *const Chunk);

            // Bvarura kana paine inowirirana byte.
            let zu = contains_zero_byte(u ^ repeated_x);
            let zv = contains_zero_byte(v ^ repeated_x);
            if zu || zv {
                break;
            }
        }
        offset -= 2 * chunk_bytes;
    }

    // Tsvaga iyo tete pamberi penzvimbo iyo chiuno chemuviri chakamira.
    text[..offset].iter().rposition(|elt| *elt == x)
}