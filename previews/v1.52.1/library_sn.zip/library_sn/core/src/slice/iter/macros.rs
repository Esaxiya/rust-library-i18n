//! Macros anoshandiswa nema iterator echidimbu.

// Inlining is_empty uye len inoita musiyano mukuru wekuita
macro_rules! is_empty {
    // Nzira yatino encode kureba kweZST iterator, izvi zvinoshanda zvese kuZST uye isiri-ZST.
    //
    ($self: ident) => {
        $self.ptr.as_ptr() as *const T == $self.end
    };
}

// Kuti ubvise mamwe mabound cheki (ona `position`), isu tinoteedzera kureba mune imwe nzira isingatarisirwe.
// (Kwayedzwa ne`codegen/slice-position-bounds-check`.)
macro_rules! len {
    ($self: ident) => {{
        #![allow(unused_unsafe)] // isu dzimwe nguva tinoshandiswa mukati medziviriro isina kuchengetedzeka

        let start = $self.ptr;
        let size = size_from_ptr(start.as_ptr());
        if size == 0 {
            // Iyi _cannot_ inoshandisa `unchecked_sub` nekuti isu tinovimba nekuputira kumiririra kureba kwerefu ZST slice iterators.
            //
            ($self.end as usize).wrapping_sub(start.as_ptr() as usize)
        } else {
            // Isu tinoziva kuti `start <= end`, saka inogona kuita zvirinani kupfuura `offset_from`, iyo inoda kubata mukusaina.
            // Nekuisa mireza yakakodzera pano tinogona kutaurira LLVM izvi, izvo zvinobatsira kubvisa bound cheki.
            // Kachengeteka: Nerudzi rwusingapindike, `start <= end`
            //
            let diff = unsafe { unchecked_sub($self.end as usize, start.as_ptr() as usize) };
            // Nekuudzawo LLVM kuti anonongedzera akapatsanurwa neakawanda chaiwo ehukuru hwerudzi, inogona kukwidzirisa `len() == 0` pasi kusvika `start == end` panzvimbo ye `(end - start) < size`.
            //
            // Kachengeteka: Nerudzi rwusingapindike, iwo anonongedzera akaenzana saka iyo
            //         kureba pakati pavo kunofanirwa kuve kuwanda kwehukuru hwepeee
            //
            unsafe { exact_div(diff, size) }
        }
    }};
}

// Tsananguro yakagovaniswa yeiyo `Iter` uye `IterMut` iterators
macro_rules! iterator {
    (
        struct $name:ident -> $ptr:ty,
        $elem:ty,
        $raw_mut:tt,
        {$( $mut_:tt )?},
        {$($extra:tt)*}
    ) => {
        // Inodzorera chinhu chekutanga uye inofambisa kutanga kweiyo iterator kumberi na1.
        // Yakanyanya inovandudza mashandiro kana ichienzaniswa neyakaiswa basa.
        // Iyo iterator haifanire kunge isina chinhu.
        macro_rules! next_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.post_inc_start(1)}
        }

        // Inodzosera iyo yekupedzisira chinhu uye inofambisa kupera kweiyo iterator kumashure ne1.
        // Yakanyanya inovandudza mashandiro kana ichienzaniswa neyakaiswa basa.
        // Iyo iterator haifanire kunge isina chinhu.
        macro_rules! next_back_unchecked {
            ($self: ident) => {& $( $mut_ )? *$self.pre_dec_end(1)}
        }

        // Anodzosera iterator kana T iri ZST, nekufambisa kupera kweterator kumashure ne `n`.
        // `n` haifanire kudarika `self.len()`.
        macro_rules! zst_shrink {
            ($self: ident, $n: ident) => {
                $self.end = ($self.end as * $raw_mut u8).wrapping_offset(-$n) as * $raw_mut T;
            }
        }

        impl<'a, T> $name<'a, T> {
            // Rinobatsira basa rekugadzira chidimbu kubva kune iterator.
            #[inline(always)]
            fn make_slice(&self) -> &'a [T] {
                // Kachengeteka: iyo iterator yakagadzirwa kubva kune chidimbu chine pointer
                // `self.ptr` uye kureba `len!(self)`.
                // Izvi zvinovimbisa kuti zvese zvinodiwa zve `from_raw_parts` zvinozadzikiswa.
                unsafe { from_raw_parts(self.ptr.as_ptr(), len!(self)) }
            }

            // Rinobatsira basa rekufambisa kutanga kweiyo iterator kumberi ne `offset` zvinhu, ichidzosa iyo yekutanga kutanga.
            //
            // Hazvina kuchengeteka nekuti kukanganisa hakufanirwe kudarika `self.len()`.
            #[inline(always)]
            unsafe fn post_inc_start(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    let old = self.ptr.as_ptr();
                    // KUCHENGETEKA: iye anofona anovimbisa kuti `offset` haipfuuri `self.len()`,
                    // saka iyi pointer nyowani iri mukati me `self` uye nekudaro yakavimbiswa kuve isiri-null.
                    self.ptr = unsafe { NonNull::new_unchecked(self.ptr.as_ptr().offset(offset)) };
                    old
                }
            }

            // Yekubatsira basa rekufambisa kupera kweiyo iterator kumashure ne `offset` zvinhu, ichidzosera magumo matsva.
            //
            // Hazvina kuchengeteka nekuti kukanganisa hakufanirwe kudarika `self.len()`.
            #[inline(always)]
            unsafe fn pre_dec_end(&mut self, offset: isize) -> * $raw_mut T {
                if mem::size_of::<T>() == 0 {
                    zst_shrink!(self, offset);
                    self.ptr.as_ptr()
                } else {
                    // KUCHENGETEKA: iye anofona anovimbisa kuti `offset` haipfuuri `self.len()`,
                    // iyo inovimbiswa kuti isafashukira `isize`.
                    // Zvakare, iyo inonongedza pointer iri mumiganhu ye `slice`, inozadzisa zvimwe zvinodikanwa zve `offset`.
                    self.end = unsafe { self.end.offset(-offset) };
                    self.end
                }
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T> ExactSizeIterator for $name<'_, T> {
            #[inline(always)]
            fn len(&self) -> usize {
                len!(self)
            }

            #[inline(always)]
            fn is_empty(&self) -> bool {
                is_empty!(self)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> Iterator for $name<'a, T> {
            type Item = $elem;

            #[inline]
            fn next(&mut self) -> Option<$elem> {
                // inogona kuitwa nezvidimbu, asi izvi zvinodzivirira miganho cheki

                // KUCHENGETEKA: `assume` kufona kwakachengeteka kubva pachinongedzo chekutanga
                // inofanirwa kunge isiri-null, uye zvimedu pamusoro peasina-ZSTs anofanirwa zvakare kuve neisina-null yekupedzisira pointer.
                // Kufona ku `next_unchecked!` kwakachengeteka sezvo isu tichitarisa kana iterator isina chinhu kutanga.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                let exact = len!(self);
                (exact, Some(exact))
            }

            #[inline]
            fn count(self) -> usize {
                len!(self)
            }

            #[inline]
            fn nth(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Iyi iterator ikozvino haina chinhu.
                    if mem::size_of::<T>() == 0 {
                        // Tinofanirwa kuzviita nenzira iyi sezvo `ptr` inogona kunge isingaite 0, asi `end` inogona kunge iri (nekuda kwekuvhara).
                        //
                        self.end = self.ptr.as_ptr();
                    } else {
                        // Kachengeteka: end haigone kuve 0 kana T isiri ZST nekuti ptr haisi 0 uye end>=ptr
                        unsafe {
                            self.ptr = NonNull::new_unchecked(self.end as *mut T);
                        }
                    }
                    return None;
                }
                // Kachengeteka: Isu tiri mumiganhu.`post_inc_start` inoita chinhu chakakodzera kunyangwe maZST.
                unsafe {
                    self.post_inc_start(n as isize);
                    Some(next_unchecked!(self))
                }
            }

            #[inline]
            fn last(mut self) -> Option<$elem> {
                self.next_back()
            }

            // Isu tinodarika kumisikidza kuitiswa, iyo inoshandisa `try_fold`, nekuti kuita kuri nyore kunogadzira LLVM IR shoma uye inokurumidza kuumbiridza.
            //
            //
            #[inline]
            fn for_each<F>(mut self, mut f: F)
            where
                Self: Sized,
                F: FnMut(Self::Item),
            {
                while let Some(x) = self.next() {
                    f(x);
                }
            }

            // Isu tinodarika kumisikidza kuitiswa, iyo inoshandisa `try_fold`, nekuti kuita kuri nyore kunogadzira LLVM IR shoma uye inokurumidza kuumbiridza.
            //
            //
            #[inline]
            fn all<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if !f(x) {
                        return false;
                    }
                }
                true
            }

            // Isu tinodarika kumisikidza kuitiswa, iyo inoshandisa `try_fold`, nekuti kuita kuri nyore kunogadzira LLVM IR shoma uye inokurumidza kuumbiridza.
            //
            //
            #[inline]
            fn any<F>(&mut self, mut f: F) -> bool
            where
                Self: Sized,
                F: FnMut(Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if f(x) {
                        return true;
                    }
                }
                false
            }

            // Isu tinodarika kumisikidza kuitiswa, iyo inoshandisa `try_fold`, nekuti kuita kuri nyore kunogadzira LLVM IR shoma uye inokurumidza kuumbiridza.
            //
            //
            #[inline]
            fn find<P>(&mut self, mut predicate: P) -> Option<Self::Item>
            where
                Self: Sized,
                P: FnMut(&Self::Item) -> bool,
            {
                while let Some(x) = self.next() {
                    if predicate(&x) {
                        return Some(x);
                    }
                }
                None
            }

            // Isu tinodarika kumisikidza kuitiswa, iyo inoshandisa `try_fold`, nekuti kuita kuri nyore kunogadzira LLVM IR shoma uye inokurumidza kuumbiridza.
            //
            //
            #[inline]
            fn find_map<B, F>(&mut self, mut f: F) -> Option<B>
            where
                Self: Sized,
                F: FnMut(Self::Item) -> Option<B>,
            {
                while let Some(x) = self.next() {
                    if let Some(y) = f(x) {
                        return Some(y);
                    }
                }
                None
            }

            // Isu tinodarika kumisikidza kuitiswa, iyo inoshandisa `try_fold`, nekuti kuita kuri nyore kunogadzira LLVM IR shoma uye inokurumidza kuumbiridza.
            // Zvakare, iyo `assume` inodzivirira bound cheki.
            //
            #[inline]
            #[rustc_inherit_overflow_checks]
            fn position<P>(&mut self, mut predicate: P) -> Option<usize> where
                Self: Sized,
                P: FnMut(Self::Item) -> bool,
            {
                let n = len!(self);
                let mut i = 0;
                while let Some(x) = self.next() {
                    if predicate(x) {
                        // KUCHENGETEKA: isu takavimbiswa kuve mumiganhu neiyo loop inoshanduka:
                        // kana `i >= n`, `self.next()` inodzosa `None` uye mabhureki e loop.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                    i += 1;
                }
                None
            }

            // Isu tinodarika kumisikidza kuitiswa, iyo inoshandisa `try_fold`, nekuti kuita kuri nyore kunogadzira LLVM IR shoma uye inokurumidza kuumbiridza.
            // Zvakare, iyo `assume` inodzivirira bound cheki.
            //
            #[inline]
            fn rposition<P>(&mut self, mut predicate: P) -> Option<usize> where
                P: FnMut(Self::Item) -> bool,
                Self: Sized + ExactSizeIterator + DoubleEndedIterator
            {
                let n = len!(self);
                let mut i = n;
                while let Some(x) = self.next_back() {
                    i -= 1;
                    if predicate(x) {
                        // KUCHENGETEKA: `i` inofanira kunge iri yakaderera pane `n` kubvira painotanga pa `n`
                        // uye zviri kungodzikira.
                        unsafe { assume(i < n) };
                        return Some(i);
                    }
                }
                None
            }

            #[doc(hidden)]
            unsafe fn __iterator_get_unchecked(&mut self, idx: usize) -> Self::Item {
                // Kachengeteka: iye anodana anofanira kuvimbisa kuti `i` iri mumiganhu ye
                // chidimbu chepasi, saka `i` haigone kufashukira `isize`, uye mareferenzi akadzorerwa anovimbiswa kureva chinhu chechidimbu uye nekudaro ichivimbiswa kuti chinoshanda.
                //
                // Ziva zvakare kuti iye ari kufona anovimbisawo kuti hatina kuzomboshevedzwa neindekisi imwechete zvakare, uye kuti hapana dzimwe nzira dzinozowana iyi subsquice inonzi, saka zvinoshanda kuti referensi yakadzoserwa igone kuchinjika mune
                //
                // `IterMut`
                //
                //
                //
                //
                unsafe { & $( $mut_ )? * self.ptr.as_ptr().add(idx) }
            }

            $($extra)*
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, T> DoubleEndedIterator for $name<'a, T> {
            #[inline]
            fn next_back(&mut self) -> Option<$elem> {
                // inogona kuitwa nezvidimbu, asi izvi zvinodzivirira miganho cheki

                // KUCHENGETEKA: `assume` kufona kwakachengeteka sezvo chidimbu chekutanga chinongedzera chinofanira kunge chisiri-chisina basa,
                // uye zvimedu pamusoro peisiri-ZSTs inofanirwa zvakare kuve neisina-null yekupedzisira pointer.
                // Kufona ku `next_back_unchecked!` kwakachengeteka sezvo isu tichitarisa kana iterator isina chinhu kutanga.
                //
                unsafe {
                    assume(!self.ptr.as_ptr().is_null());
                    if mem::size_of::<T>() != 0 {
                        assume(!self.end.is_null());
                    }
                    if is_empty!(self) {
                        None
                    } else {
                        Some(next_back_unchecked!(self))
                    }
                }
            }

            #[inline]
            fn nth_back(&mut self, n: usize) -> Option<$elem> {
                if n >= len!(self) {
                    // Iyi iterator ikozvino haina chinhu.
                    self.end = self.ptr.as_ptr();
                    return None;
                }
                // Kachengeteka: Isu tiri mumiganhu.`pre_dec_end` inoita chinhu chakakodzera kunyangwe maZST.
                unsafe {
                    self.pre_dec_end(n as isize);
                    Some(next_back_unchecked!(self))
                }
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<T> FusedIterator for $name<'_, T> {}

        #[unstable(feature = "trusted_len", issue = "37572")]
        unsafe impl<T> TrustedLen for $name<'_, T> {}
    }
}

macro_rules! forward_iterator {
    ($name:ident: $elem:ident, $iter_of:ty) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<'a, $elem, P> Iterator for $name<'a, $elem, P>
        where
            P: FnMut(&T) -> bool,
        {
            type Item = $iter_of;

            #[inline]
            fn next(&mut self) -> Option<$iter_of> {
                self.inner.next()
            }

            #[inline]
            fn size_hint(&self) -> (usize, Option<usize>) {
                self.inner.size_hint()
            }
        }

        #[stable(feature = "fused", since = "1.26.0")]
        impl<'a, $elem, P> FusedIterator for $name<'a, $elem, P> where P: FnMut(&T) -> bool {}
    };
}