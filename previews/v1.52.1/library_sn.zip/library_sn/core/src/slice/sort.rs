//! Slice kuronga
//!
//! Iyi module ine algorithm yekugadzirisa kubva paOsonson Peters 'pateni-inokunda quicksort, yakaburitswa pa: <https://github.com/orlp/pdqsort>
//!
//!
//! Kugadzikana kusagadzikana kunoenderana ne libcore nekuti haina kugovera ndangariro, kusiyana neyakagadzika yedu yekugadzirisa kuita.
//!

// ignore-tidy-undocumented-unsafe

use crate::cmp;
use crate::mem::{self, MaybeUninit};
use crate::ptr;

/// Kana yakadonhedzwa, makopi kubva ku `src` kuenda ku `dest`.
struct CopyOnDrop<T> {
    src: *mut T,
    dest: *mut T,
}

impl<T> Drop for CopyOnDrop<T> {
    fn drop(&mut self) {
        // Kachengeteka: Iri iboka revabatsiri.
        //          Ndokumbira utarise kune kwayo mashandisirwo echokwadi.
        //          Sezvinei, mumwe anofanirwa kuve nechokwadi chekuti `src` ne `dst` hazviwirirane sezviri kudiwa ne `ptr::copy_nonoverlapping`.
        unsafe {
            ptr::copy_nonoverlapping(self.src, self.dest, 1);
        }
    }
}

/// Inochinjisa chinhu chekutanga kurudyi kudzamara chasangana nechinhu chikuru kana chakaenzana.
fn shift_head<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // KUCHENGETEKA: Izvo zvisina kuchengetedzeka mashandiro pazasi anosanganisira indexing pasina yakasungwa cheki (`get_unchecked` uye `get_unchecked_mut`)
    // uye kuteedzera ndangariro (`ptr::copy_nonoverlapping`).
    //
    // a.Indexing:
    //  1. Takatarisa kukura kweakarongeka kusvika>=2.
    //  2. Zvese indexing zvatichaita zvinogara zviri pakati pe {0 <= index < len} zvakanyanya.
    //
    // b.Kuteedzera ndangariro
    //  1. Tiri kuwana zvinongedzo kune mareferenzi ayo anovimbiswa kuve anoshanda.
    //  2. Izvo hazvigone kupfuura nekuti isu tinowana zvinongedzo kumisiyano indices yechidimbu.
    //     Zvakare, `i` uye `i-1`.
    //  3. Kana chidimbu chakanyatsoenderana, zvinhu zvacho zvakanyatsoenderana.
    //     Ibasa remufonesi kuona kuti chidimbu chakanyatsoenderana.
    //
    // Ona zvirevo pazasi kuti uwane rumwe ruzivo.
    unsafe {
        // Kana zvinhu zviviri zvekutanga zviri zvekunze ...
        if len >= 2 && is_less(v.get_unchecked(1), v.get_unchecked(0)) {
            // Verenga chinhu chekutanga mune yakakamurwa-yakapihwa musiyano.
            // Kana inotevera yekuenzanisa yekuita panics, `hole` inodonhedzwa uye otomatiki nyora chinhu zvacho muchidimbu.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(0)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(1) };
            ptr::copy_nonoverlapping(v.get_unchecked(1), v.get_unchecked_mut(0), 1);

            for i in 2..len {
                if !is_less(v.get_unchecked(i), &*tmp) {
                    break;
                }

                // Fambisa `i`-th element imwe nzvimbo kuruboshwe, nekudaro uchichinjisa gomba kurudyi.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i - 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` inodonhedzwa uye nekudaro inoteedzera `tmp` mugomba rakasara mu `v`.
        }
    }
}

/// Inoshandura chinhu chekupedzisira kuruboshwe kusvikira chasangana nechidiki kana chakaenzana chinhu.
fn shift_tail<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    let len = v.len();
    // KUCHENGETEKA: Izvo zvisina kuchengetedzeka mashandiro pazasi anosanganisira indexing pasina yakasungwa cheki (`get_unchecked` uye `get_unchecked_mut`)
    // uye kuteedzera ndangariro (`ptr::copy_nonoverlapping`).
    //
    // a.Indexing:
    //  1. Takatarisa kukura kweakarongeka kusvika>=2.
    //  2. Zvese indexing zvatichaita zvinogara zviri pakati pe `0 <= index < len-1` zvakanyanya.
    //
    // b.Kuteedzera ndangariro
    //  1. Tiri kuwana zvinongedzo kune mareferenzi ayo anovimbiswa kuve anoshanda.
    //  2. Izvo hazvigone kupfuura nekuti isu tinowana zvinongedzo kumisiyano indices yechidimbu.
    //     Zvakare, `i` uye `i+1`.
    //  3. Kana chidimbu chakanyatsoenderana, zvinhu zvacho zvakanyatsoenderana.
    //     Ibasa remufonesi kuona kuti chidimbu chakanyatsoenderana.
    //
    // Ona zvirevo pazasi kuti uwane rumwe ruzivo.
    unsafe {
        // Kana zvinhu zviviri zvekupedzisira zvabuda-mu-odhi ...
        if len >= 2 && is_less(v.get_unchecked(len - 1), v.get_unchecked(len - 2)) {
            // Verenga chekupedzisira chinhu mune stack-yakapihwa musiyano.
            // Kana inotevera yekuenzanisa yekuita panics, `hole` inodonhedzwa uye otomatiki nyora chinhu zvacho muchidimbu.
            //
            let mut tmp = mem::ManuallyDrop::new(ptr::read(v.get_unchecked(len - 1)));
            let mut hole = CopyOnDrop { src: &mut *tmp, dest: v.get_unchecked_mut(len - 2) };
            ptr::copy_nonoverlapping(v.get_unchecked(len - 2), v.get_unchecked_mut(len - 1), 1);

            for i in (0..len - 2).rev() {
                if !is_less(&*tmp, v.get_unchecked(i)) {
                    break;
                }

                // Fambisa `i`-th element imwe nzvimbo kurudyi, nekudaro uchichinjisa gomba kuruboshwe.
                ptr::copy_nonoverlapping(v.get_unchecked(i), v.get_unchecked_mut(i + 1), 1);
                hole.dest = v.get_unchecked_mut(i);
            }
            // `hole` inodonhedzwa uye nekudaro inoteedzera `tmp` mugomba rakasara mu `v`.
        }
    }
}

/// Partial rongedza chidimbu nekuchinja akati wandei-e-e-odhiyo zvinhu kutenderedza.
///
/// Inodzorera `true` kana slice yakarongedzwa kumagumo.Iri basa ndi *O*(*n*) yakaipa-kesi.
#[cold]
fn partial_insertion_sort<T, F>(v: &mut [T], is_less: &mut F) -> bool
where
    F: FnMut(&T, &T) -> bool,
{
    // Huwandu hwehuwandu hwepedyo hwekunze-kwe-hwema jozi huchagadziriswa.
    const MAX_STEPS: usize = 5;
    // Kana chidimbu chiri chipfupi pane ichi, usachinje chero chinhu.
    const SHORTEST_SHIFTING: usize = 50;

    let len = v.len();
    let mut i = 1;

    for _ in 0..MAX_STEPS {
        // KUCHENGETEKA: Isu takatoita zvakajeka kutarisa kusungwa ne `i < len`.
        // Yedu yese inotevera indexing iri chete mune yakasarudzika `0 <= index < len`
        unsafe {
            // Tsvaga anotevera maviri maviri epedyo ekunze-kwe-ekuraira zvinhu.
            while i < len && !is_less(v.get_unchecked(i), v.get_unchecked(i - 1)) {
                i += 1;
            }
        }

        // Tapedza here?
        if i == len {
            return true;
        }

        // Usachinje zvinhu pane zvakapfupikiswa, izvo zvine mutengo wekuita.
        if len < SHORTEST_SHIFTING {
            return false;
        }

        // Chinja iro rakawanikwa zvinhu zviviri.Izvi zvinovaisa munhevedzano chaiyo.
        v.swap(i - 1, i);

        // Shift chinhu chidiki kuruboshwe.
        shift_tail(&mut v[..i], is_less);
        // Shift chinhu chikuru kurudyi.
        shift_head(&mut v[i..], is_less);
    }

    // Hauna kukwanisa kurongedza chidimbu mune mashoma nhamba yematanho.
    false
}

/// Anotarisa chidimbu achishandisa yekuisa mhando, iri *O*(*n*^ 2) yakaipa-kesi.
fn insertion_sort<T, F>(v: &mut [T], is_less: &mut F)
where
    F: FnMut(&T, &T) -> bool,
{
    for i in 1..v.len() {
        shift_tail(&mut v[..i + 1], is_less);
    }
}

/// Inotarisa `v` ichishandisa heapsort, iyo inovimbisa *O*(*n*\*log(* n*)) yakaipa-kesi.
#[cold]
#[unstable(feature = "sort_internals", reason = "internal to sort module", issue = "none")]
pub fn heapsort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Uyu murwi webhinari unoremekedza iyo isingawanzo `parent >= child`.
    let mut sift_down = |v: &mut [T], mut node| {
        loop {
            // Vana ve `node`:
            let left = 2 * node + 1;
            let right = 2 * node + 2;

            // Sarudza mwana mukuru.
            let greater =
                if right < v.len() && is_less(&v[left], &v[right]) { right } else { left };

            // Mira kana iye asinga pindike akabata pa `node`.
            if greater >= v.len() || !is_less(&v[node], &v[greater]) {
                break;
            }

            // Chinjana `node` nemwana mukuru, fambisa nhanho imwe pasi, uye ramba uchipepeta.
            v.swap(node, greater);
            node = greater;
        }
    };

    // Gadzira murwi munguva inowirirana.
    for i in (0..v.len() / 2).rev() {
        sift_down(v, i);
    }

    // Pop yakakura zvinhu kubva pamurwi.
    for i in (1..v.len()).rev() {
        v.swap(0, i);
        sift_down(&mut v[..i], 0);
    }
}

/// Zvikamu `v` muzvinhu zvidiki pane `pivot`, zvichiteverwa nezvinhu zvakakura kupfuura kana zvakaenzana ne `pivot`.
///
///
/// Inodzorera iyo nhamba yezvinhu zvidiki pane `pivot`.
///
/// Kupatsanura kunoitwa block-ne-block kuitira kudzikisira mutengo wekuita bazi.
/// Pfungwa iyi inoratidzwa mupepa re [BlockQuicksort][pdf].
///
/// [pdf]: http://drops.dagstuhl.de/opus/volltexte/2016/6389/pdf/LIPIcs-ESA-2016-38.pdf
fn partition_in_blocks<T, F>(v: &mut [T], pivot: &T, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Huwandu hwezvinhu mubhokisi chairo.
    const BLOCK: usize = 128;

    // Iyo yekuparadzanisa algorithm inodzokorora anotevera matanho kusvika apedza:
    //
    // 1. Tsvaga chivharo kubva kuruboshwe kuruboshwe kuti uone zvinhu zvakakura kupfuura kana zvakaenzana nepivot.
    // 2. Tsvaga chivharo kubva kurudyi kurudyi kuti uone zvinhu zvidiki pane pivot.
    // 3. Chinjana zvinhu zvinozivikanwa pakati perutivi rweruboshwe uye kurudyi.
    //
    // Isu tinochengeta anotevera akasiyana eiyo block yezvinhu:
    //
    // 1. `block` - Huwandu hwezvinhu mubhokisi.
    // 2. `start` - Kutanga pointer mune `offsets` array.
    // 3. `end` - End pointer mune iyo `offsets` array.
    // 4. `offsets, maIndices ezvekunze-zve-odhi zvinhu mukati meblock.

    // Iri bhuroka razvino kuruboshwe (kubva ku `l` kusvika `l.add(block_l)`).
    let mut l = v.as_mut_ptr();
    let mut block_l = BLOCK;
    let mut start_l = ptr::null_mut();
    let mut end_l = ptr::null_mut();
    let mut offsets_l = [MaybeUninit::<u8>::uninit(); BLOCK];

    // Iyo yazvino block pane kurudyi (kubva `r.sub(block_r)` to `r`).
    // KUCHENGETEKA: Zvinyorwa zve .add() zvinonyatsotaura kuti `vec.as_ptr().add(vec.len())` inogara yakachengeteka`
    let mut r = unsafe { l.add(v.len()) };
    let mut block_r = BLOCK;
    let mut start_r = ptr::null_mut();
    let mut end_r = ptr::null_mut();
    let mut offsets_r = [MaybeUninit::<u8>::uninit(); BLOCK];

    // FIXME: Patinowana maVLAs, edza kugadzira imwechete yehurefu `min(v.len(), 2 * BLOCK) `ndoda
    // kupfuura maviri akasarudzika-saizi arrays ehurefu `BLOCK`.VLAs dzinogona kunge dzichiwedzera cache.

    // Inodzorera iyo nhamba yezvinhu pakati pezvinongedzo `l` (inclusive) uye `r` (exclusive).
    fn width<T>(l: *mut T, r: *mut T) -> usize {
        assert!(mem::size_of::<T>() > 0);
        (r as usize - l as usize) / mem::size_of::<T>()
    }

    loop {
        // Isu taitwa nekuparadzanisa block-ne-block kana `l` ne `r` zvasvika padhuze.
        // Ipapo isu tinoita rimwe chigamba-chepamusoro basa kuti tigovane izvo zvasara zvinhu zviri pakati.
        let is_done = width(l, r) <= 2 * BLOCK;

        if is_done {
            // Huwandu hwezvinhu zvakasara (zvichiri zvisina kufananidzwa nepivot).
            let mut rem = width(l, r);
            if start_l < end_l || start_r < end_r {
                rem -= BLOCK;
            }

            // Chinja saizi yemabhuru kuitira kuti iro rekuruboshwe uye rerudyi bhatani risapindane, asi nyatsoenderana kuti ufukidze gasi rose rasara.
            //
            if start_l < end_l {
                block_r = rem;
            } else if start_r < end_r {
                block_l = rem;
            } else {
                block_l = rem / 2;
                block_r = rem - block_l;
            }
            debug_assert!(block_l <= BLOCK && block_r <= BLOCK);
            debug_assert!(width(l, r) == block_l + block_r);
        }

        if start_l == end_l {
            // Tsvaga `block_l` zvinhu kubva kuruboshwe.
            start_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            end_l = MaybeUninit::slice_as_mut_ptr(&mut offsets_l);
            let mut elem = l;

            for i in 0..block_l {
                // Kachengeteka: Iko kusagadzikana kuchengetedzwa pazasi kunosanganisira kushandiswa kwe `offset`.
                //         Zvinoenderana nemamiriro ezvinhu anodikanwa nebasa racho, tinovagutsa nekuti:
                //         1. `offsets_l` yakaiswa-yakakamurwa, uye nekudaro inofungidzirwa yakaparadzaniswa yakapihwa chinhu
                //         2. Basa `is_less` rinodzosera `bool`.
                //            Kukanda `bool` hakuzombo kufashukira `isize`.
                //         3. Isu takavimbisa kuti `block_l` ichave `<= BLOCK`.
                //            Uyezve, `end_l` yakatanga kuiswa kune yekutanga pointer ye `offsets_` iyo yakaziviswa pane stack.
                //            Nekudaro, isu tinoziva kuti kunyangwe mune yakaipisisa kesi (ese kukumbira kwe `is_less` anodzoka manyepo) isu tinenge tichingova kanokwana 1 byte kupfuura kumagumo.
                //        Kumwe kushanda kusina kuchengetedzeka apa kurekesa `elem`.
                //        Nekudaro, `elem` pakutanga yaive yekutanga pointer kune slice iyo inogara ichishanda.
                unsafe {
                    // Kuenzanisa kusina bazi.
                    *end_l = i as u8;
                    end_l = end_l.offset(!is_less(&*elem, pivot) as isize);
                    elem = elem.offset(1);
                }
            }
        }

        if start_r == end_r {
            // Tsvaga `block_r` zvinhu kubva kurudyi.
            start_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            end_r = MaybeUninit::slice_as_mut_ptr(&mut offsets_r);
            let mut elem = r;

            for i in 0..block_r {
                // Kachengeteka: Iko kusagadzikana kuchengetedzwa pazasi kunosanganisira kushandiswa kwe `offset`.
                //         Zvinoenderana nemamiriro ezvinhu anodikanwa nebasa racho, tinovagutsa nekuti:
                //         1. `offsets_r` yakaiswa-yakakamurwa, uye nekudaro inofungidzirwa yakaparadzaniswa yakapihwa chinhu
                //         2. Basa `is_less` rinodzosera `bool`.
                //            Kukanda `bool` hakuzombo kufashukira `isize`.
                //         3. Isu takavimbisa kuti `block_r` ichave `<= BLOCK`.
                //            Uyezve, `end_r` yakatanga kuiswa kune yekutanga pointer ye `offsets_` iyo yakaziviswa pane stack.
                //            Nekudaro, isu tinoziva kuti kunyangwe mune yakaipisisa kesi (ese kukumbira kwe `is_less` kunodzoka ichokwadi) isu tinenge tichingova kanokwana 1 byte kupfuura kumagumo.
                //        Kumwe kushanda kusina kuchengetedzeka apa kurekesa `elem`.
                //        Nekudaro, `elem` pakutanga yaive `1 *sizeof(T)` yapfuura kumagumo uye isu tinoideredza ne `1* sizeof(T)` tisati tayiwana.
                //        Uyezve, `block_r` yakasimbiswa kuve iri pasi pe `BLOCK` uye `elem` saka ichanyanya kunongedzera kutanga kwechidimbu.
                unsafe {
                    // Kuenzanisa kusina bazi.
                    elem = elem.offset(-1);
                    *end_r = i as u8;
                    end_r = end_r.offset(is_less(&*elem, pivot) as isize);
                }
            }
        }

        // Huwandu hwezvinhu zvekunze-kwe-odha kuti uchinjane pakati peruboshwe uye kurudyi.
        let count = cmp::min(width(start_l, end_l), width(start_r, end_r));

        if count > 0 {
            macro_rules! left {
                () => {
                    l.offset(*start_l as isize)
                };
            }
            macro_rules! right {
                () => {
                    r.offset(-(*start_r as isize) - 1)
                };
            }

            // Panzvimbo pekuchinjanisa vaviri panguva iyoyo, zvinonyanya kushanda kuita mvumo yekutenderera.
            // Izvi hazvina kunyatsoenzana nekuchinjanisa, asi zvinogadzira mhedzisiro yakafanana uchishandisa mashoma ndangariro mashandiro.
            //
            unsafe {
                let tmp = ptr::read(left!());
                ptr::copy_nonoverlapping(right!(), left!(), 1);

                for _ in 1..count {
                    start_l = start_l.offset(1);
                    ptr::copy_nonoverlapping(left!(), right!(), 1);
                    start_r = start_r.offset(1);
                    ptr::copy_nonoverlapping(right!(), left!(), 1);
                }

                ptr::copy_nonoverlapping(&tmp, right!(), 1);
                mem::forget(tmp);
                start_l = start_l.offset(1);
                start_r = start_r.offset(1);
            }
        }

        if start_l == end_l {
            // Zvese zvekunze-kwe-zvekuraira mubhokisi rekuruboshwe zvakafambiswa.Enda kunzvimbo inotevera.
            l = unsafe { l.offset(block_l as isize) };
        }

        if start_r == end_r {
            // Zvese zvekunze-kwe-zvekuraira mubhokisi chairo zvakafambiswa.Enda kubhucha rapfuura.
            r = unsafe { r.offset(-(block_r as isize)) };
        }

        if is_done {
            break;
        }
    }

    // Zvese zvasara izvozvi zvinonyanya kuve bhuroko rimwe (kungave kuruboshwe kana kurudyi) nezvinhu zvekunze-zveodha zvinoda kufambiswa.
    // Zvinhu zvakasara zvakadaro zvinogona kungochinjiswa kusvika kumagumo mukati memablock avo.
    //

    if start_l < end_l {
        // Kuruboshwe kuruboshwe.
        // Fambisa zvinhu zvaro zvasara zvekunze-kurongedza kurudyi.
        debug_assert_eq!(width(l, r), block_l);
        while start_l < end_l {
            unsafe {
                end_l = end_l.offset(-1);
                ptr::swap(l.offset(*end_l as isize), r.offset(-1));
                r = r.offset(-1);
            }
        }
        width(v.as_mut_ptr(), r)
    } else if start_r < end_r {
        // Iyo chaiyo block inoramba iripo.
        // Fambisa zvinhu zvaro zvasara zvekunze-kurongedza kuruboshwe kuruboshwe.
        debug_assert_eq!(width(l, r), block_r);
        while start_r < end_r {
            unsafe {
                end_r = end_r.offset(-1);
                ptr::swap(l, r.offset(-(*end_r as isize) - 1));
                l = l.offset(1);
            }
        }
        width(v.as_mut_ptr(), l)
    } else {
        // Hapana chimwe chekuita, tapedza.
        width(v.as_mut_ptr(), l)
    }
}

/// Zvikamu `v` muzvinhu zvidiki pane `v[pivot]`, zvichiteverwa nezvinhu zvakakura kupfuura kana zvakaenzana ne `v[pivot]`.
///
///
/// Inodzorera Tuple ye:
///
/// 1. Nhamba yezvinhu zvidiki pane `v[pivot]`.
/// 2. Chokwadi kana `v` yakanga yatopatsanurwa.
fn partition<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    let (mid, was_partitioned) = {
        // Isa pivot pakutanga kwechikamu.
        v.swap(0, pivot);
        let (pivot, v) = v.split_at_mut(1);
        let pivot = &mut pivot[0];

        // Verenga iyo pivot mune stack-yakapihwa musiyano wekuita nemazvo.
        // Kana inotevera yekuenzanisa yekuita panics, iyo pivot inozozvinyoronyorwa yakadzoserwa muchikamu.
        let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
        let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
        let pivot = &*tmp;

        // Tsvaga peya yekutanga yezvinhu zvekunze-zve-odha.
        let mut l = 0;
        let mut r = v.len();

        // Kachengeteka: Iko kusagadzikana pazasi kunosanganisira kunongedza rondedzero.
        // Yekutanga: Isu tatoita miganho tichitarisa pano ne `l < r`.
        // Yechipiri: Isu pakutanga tine `l == 0` uye `r == v.len()` uye takatarisa iyo `l < r` pane ese indexing oparesheni.
        //                     Kubva pano tinoziva kuti `r` inofanira kunge iri `r == l` iyo yakaratidzirwa kuve inoshanda kubva kune yekutanga.
        unsafe {
            // Tsvaga chinhu chekutanga chakakura kupfuura kana chakaenzana nepivot.
            while l < r && is_less(v.get_unchecked(l), pivot) {
                l += 1;
            }

            // Tsvaga chekupedzisira chinhu chidiki icho pivot.
            while l < r && !is_less(v.get_unchecked(r - 1), pivot) {
                r -= 1;
            }
        }

        (l + partition_in_blocks(&mut v[l..r], pivot, is_less), l >= r)

        // `_pivot_guard` inobuda pachiyero uye inonyora iyo pivot (inova stack-yakapihwa musiyano) kudzokera muchidimbu kwayaive pakutanga.
        // Iyi nhanho yakakosha mukuona kuchengetedzeka!
        //
    };

    // Isa pivot pakati pezvikamu zviviri.
    v.swap(0, mid);

    (mid, was_partitioned)
}

/// Zvikamu `v` muzvinhu zvakaenzana ne `v[pivot]` zvichiteverwa nezvinhu zvakakura kupfuura `v[pivot]`.
///
/// Inodzorera iyo nhamba yezvinhu zvakaenzana nepivot.
/// Inofungidzirwa kuti `v` haina zvinhu zvidiki pane iyo pivot.
fn partition_equal<T, F>(v: &mut [T], pivot: usize, is_less: &mut F) -> usize
where
    F: FnMut(&T, &T) -> bool,
{
    // Isa pivot pakutanga kwechikamu.
    v.swap(0, pivot);
    let (pivot, v) = v.split_at_mut(1);
    let pivot = &mut pivot[0];

    // Verenga iyo pivot mune stack-yakapihwa musiyano wekuita nemazvo.
    // Kana inotevera yekuenzanisa yekuita panics, iyo pivot inozozvinyoronyorwa yakadzoserwa muchikamu.
    // Kachengeteka: Iyo pointer pano inoshanda nekuti inowanikwa kubva kunongedzo kune chidimbu.
    let mut tmp = mem::ManuallyDrop::new(unsafe { ptr::read(pivot) });
    let _pivot_guard = CopyOnDrop { src: &mut *tmp, dest: pivot };
    let pivot = &*tmp;

    // Zvino govanisa chidimbu.
    let mut l = 0;
    let mut r = v.len();
    loop {
        // Kachengeteka: Iko kusagadzikana pazasi kunosanganisira kunongedza rondedzero.
        // Yekutanga: Isu tatoita miganho tichitarisa pano ne `l < r`.
        // Yechipiri: Isu pakutanga tine `l == 0` uye `r == v.len()` uye takatarisa iyo `l < r` pane ese indexing oparesheni.
        //                     Kubva pano tinoziva kuti `r` inofanira kunge iri `r == l` iyo yakaratidzirwa kuve inoshanda kubva kune yekutanga.
        unsafe {
            // Tsvaga chinhu chekutanga chakakura kupfuura pivot.
            while l < r && !is_less(pivot, v.get_unchecked(l)) {
                l += 1;
            }

            // Tsvaga chinhu chekupedzisira chakaenzana nepivot.
            while l < r && is_less(pivot, v.get_unchecked(r - 1)) {
                r -= 1;
            }

            // Tapedza here?
            if l >= r {
                break;
            }

            // Chinja iro rakawanikwa vaviri vekunze-kwe-odha zvinhu.
            r -= 1;
            ptr::swap(v.get_unchecked_mut(l), v.get_unchecked_mut(r));
            l += 1;
        }
    }

    // Isu takawana `l` zvinhu zvakaenzana nepivot.Wedzera 1 kuaccount yepivot pachayo.
    l + 1

    // `_pivot_guard` inobuda pachiyero uye inonyora iyo pivot (inova stack-yakapihwa musiyano) kudzokera muchidimbu kwayaive pakutanga.
    // Iyi nhanho yakakosha mukuona kuchengetedzeka!
}

/// Inoparadzira zvimwe zvinhu zvakapoterera mukuyedza kupaza mapatani ayo anogona kukonzeresa kusaenzana pakati mu quicksort.
///
#[cold]
fn break_patterns<T>(v: &mut [T]) {
    let len = v.len();
    if len >= 8 {
        // Pseudorandom nhamba jenareta kubva ku "Xorshift RNGs" bepa naGeorge Marsaglia.
        let mut random = len as u32;
        let mut gen_u32 = || {
            random ^= random << 13;
            random ^= random >> 17;
            random ^= random << 5;
            random
        };
        let mut gen_usize = || {
            if usize::BITS <= 32 {
                gen_u32() as usize
            } else {
                (((gen_u32() as u64) << 32) | (gen_u32() as u64)) as usize
            }
        };

        // Tora zvisina kujairika manhamba modulo iyi nhamba.
        // Nhamba yacho inopindirana ne `usize` nekuti `len` haina kukura kupfuura `isize::MAX`.
        let modulus = len.next_power_of_two();

        // Vamwe vanokwikwidza pivot vachange vari mune iripedyo indekisi iyi.Ngatizvitsanangurei.
        let pos = len / 4 * 2;

        for i in 0..3 {
            // Gadzira yakasarudzika nhamba modulo `len`.
            // Nekudaro, kuitira kuti tirege mashandiro anodhura isu tinotanga tatora modulo simba reviri, tobva tadzikira ne `len` kudzamara yakaringana muzera `[0, len - 1]`.
            //
            let mut other = gen_usize() & (modulus - 1);

            // `other` inovimbiswa kuve iri pasi pe `2 * len`.
            if other >= len {
                other -= len;
            }

            v.swap(pos - 1 + i, other);
        }
    }
}

/// Sarudza pivot mu `v` uye unodzosera iyo index uye `true` kana chidimbu chingangodaro chakarongedzwa.
///
/// Zvinhu zviri mu `v` zvinogona kugadziriswazve mukuita.
fn choose_pivot<T, F>(v: &mut [T], is_less: &mut F) -> (usize, bool)
where
    F: FnMut(&T, &T) -> bool,
{
    // Kureba kushoma kusarudza iyo yepakati-ye-mamidhiya nzira.
    // Mapfupi zvidimbu anoshandisa yakapusa epakati-ye-matatu nzira.
    const SHORTEST_MEDIAN_OF_MEDIANS: usize = 50;
    // Huwandu hwehuwandu hwekutsvaira hunogona kuitwa mune iri basa.
    const MAX_SWAPS: usize = 4 * 3;

    let len = v.len();

    // Zvitatu indices padyo nepatichasarudza pivot.
    let mut a = len / 4 * 1;
    let mut b = len / 4 * 2;
    let mut c = len / 4 * 3;

    // Inoverenga iyo yakazara huwandu hweswaps yatiri kuda kuita tichirongedza indices.
    let mut swaps = 0;

    if len >= 8 {
        // Inochinja indices kuitira kuti `v[a] <= v[b]`.
        let mut sort2 = |a: &mut usize, b: &mut usize| unsafe {
            if is_less(v.get_unchecked(*b), v.get_unchecked(*a)) {
                ptr::swap(a, b);
                swaps += 1;
            }
        };

        // Inochinja indices kuitira kuti `v[a] <= v[b] <= v[c]`.
        let mut sort3 = |a: &mut usize, b: &mut usize, c: &mut usize| {
            sort2(a, b);
            sort2(b, c);
            sort2(a, b);
        };

        if len >= SHORTEST_MEDIAN_OF_MEDIANS {
            // Inotsvaga wepakati pe `v[a - 1], v[a], v[a + 1]` uye inochengeta iyo index mu `a`.
            let mut sort_adjacent = |a: &mut usize| {
                let tmp = *a;
                sort3(&mut (tmp - 1), a, &mut (tmp + 1));
            };

            // Tsvaga mamidhiani munharaunda dze `a`, `b`, uye `c`.
            sort_adjacent(&mut a);
            sort_adjacent(&mut b);
            sort_adjacent(&mut c);
        }

        // Tsvaga wepakati pakati pe `a`, `b`, uye `c`.
        sort3(&mut a, &mut b, &mut c);
    }

    if swaps < MAX_SWAPS {
        (b, swaps == 0)
    } else {
        // Iyo yakanyanya kuwanda swaps yakaitwa.
        // Mikana ndeyekuti chidimbu chiri kudzika kana kunyanya kuburuka, saka kudzosera kumashure kungangobatsira kuchimhanyisa nekukurumidza.
        v.reverse();
        (len - 1 - b, true)
    }
}

/// Mhando `v` inodzokorora.
///
/// Kana slice raive neakafanotungamira mune yekutanga rondedzero, zvinotsanangurwa se `pred`.
///
/// `limit` ndiyo nhamba yeanotenderwa asina kuenzana zvikamu asati achinja kuenda ku `heapsort`.
/// Kana zero, iri basa rinobva rangoshandira heapsort.
fn recurse<'a, T, F>(mut v: &'a mut [T], is_less: &mut F, mut pred: Option<&'a T>, mut limit: u32)
where
    F: FnMut(&T, &T) -> bool,
{
    // Zvidimbu zvekusvika pakureba uku zvinogadziriswa uchishandisa yekuisa mhando.
    const MAX_INSERTION: usize = 20;

    // Chokwadi kana kupatsanura kwekupedzisira kwanga kwakaenzana zvine mutsindo.
    let mut was_balanced = true;
    // Chokwadi kana kupatsanura kwekupedzisira kusachinja zvinhu (chidimbu chakange chatopatsanurwa).
    let mut was_partitioned = true;

    loop {
        let len = v.len();

        // Mapfupi zvidimbu marongedzero uchishandisa yekuisa mhando.
        if len <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Kana pakawandisa sarudzo dzakaipa dzepivot dzakaitwa, ingo dzokera kuheapsort kuti uve nechokwadi che `O(n * log(n))` yakaipa-kesi.
        //
        if limit == 0 {
            heapsort(v, is_less);
            return;
        }

        // Kana iko kwekupedzisira kupatsanura kwanga kusisina kuenzana, edza kutyora mapatani muchidimbu nekusanganisa zvimwe zvinhu zvakapoterera.
        // Ndinovimba tichasarudza pivot iri nani panguva ino.
        if !was_balanced {
            break_patterns(v);
            limit -= 1;
        }

        // Sarudza pivot uye edza kufungidzira kana chidimbu chatove chakarongedzwa.
        let (pivot, likely_sorted) = choose_pivot(v, is_less);

        // Kana chikamu chekupedzisira chaive chakadzikama uye chisina kuchinjanisa zvinhu, uye kana kusarudzwa kwepivot kunofungidzira kuti chidimbu chingangove chakarongedzwa ...
        //
        if was_balanced && was_partitioned && likely_sorted {
            // Edza kudoma akati wandei-eku-odha zvinhu uye nekuzvichinjisa kugadzirisa nzvimbo.
            // Kana chidimbu chikazoguma chave kunyatsorongedzwa, isu tapedza.
            if partial_insertion_sort(v, is_less) {
                return;
            }
        }

        // Kana iyo pivot yakasarudzwa yakaenzana neyakatangira, saka ndicho chinhu chidiki pane chidimbu.
        // Kupatsanura chidimbu muzvinhu zvakaenzana uye zvinhu zvakakura kupfuura pivot.
        // Iyi kesi inowanzo rohwa kana slice iine zvinhu zvakawanda zvakapetwa.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Ramba uchigadzirisa zvinhu zvakakura kupfuura pivot.
                v = &mut { v }[mid..];
                continue;
            }
        }

        // Kupatsanura chidimbu.
        let (mid, was_p) = partition(v, pivot, is_less);
        was_balanced = cmp::min(mid, len - mid) >= len / 8;
        was_partitioned = was_p;

        // Gura chidimbu mu `left`, `pivot`, uye `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        // Dzosera kudivi ipfupi chete kuitira kuti udzikise huwandu hwenhare dzekudzokorora uye unoshandisa mashoma stack nzvimbo.
        // Wobva wangopfuurira nerutivi rurefu (izvi zvakafanana nekudzokorora muswe).
        //
        if left.len() < right.len() {
            recurse(left, is_less, pred, limit);
            v = right;
            pred = Some(pivot);
        } else {
            recurse(right, is_less, Some(pivot), limit);
            v = left;
        }
    }
}

/// Mhando `v` uchishandisa pateni-inokunda quicksort, inova *O*(*n*\*log(* n*)) yakaipa-kesi.
pub fn quicksort<T, F>(v: &mut [T], mut is_less: F)
where
    F: FnMut(&T, &T) -> bool,
{
    // Kuronga hakuna hunhu hunonzwisisika pane zero-saizi mhando.
    if mem::size_of::<T>() == 0 {
        return;
    }

    // Deredza nhamba yezvikamu zvisina kuenzana ku `floor(log2(len)) + 1`.
    let limit = usize::BITS - v.len().leading_zeros();

    recurse(v, &mut is_less, None, limit);
}

fn partition_at_index_loop<'a, T, F>(
    mut v: &'a mut [T],
    mut index: usize,
    is_less: &mut F,
    mut pred: Option<&'a T>,
) where
    F: FnMut(&T, &T) -> bool,
{
    loop {
        // Kune zvidimbu zvinosvika pakureba uku zvinogona kunge zvichikurumidza kungozvirongedza.
        const MAX_INSERTION: usize = 10;
        if v.len() <= MAX_INSERTION {
            insertion_sort(v, is_less);
            return;
        }

        // Sarudza pivot
        let (pivot, _) = choose_pivot(v, is_less);

        // Kana iyo pivot yakasarudzwa yakaenzana neyakatangira, saka ndicho chinhu chidiki pane chidimbu.
        // Kupatsanura chidimbu muzvinhu zvakaenzana uye zvinhu zvakakura kupfuura pivot.
        // Iyi kesi inowanzo rohwa kana slice iine zvinhu zvakawanda zvakapetwa.
        if let Some(p) = pred {
            if !is_less(p, &v[pivot]) {
                let mid = partition_equal(v, pivot, is_less);

                // Kana isu takapasa rondedzero yedu, saka takanaka.
                if mid > index {
                    return;
                }

                // Zvikasadaro, ramba uchirongedza zvinhu zvakakura kupfuura pivot.
                v = &mut v[mid..];
                index = index - mid;
                pred = None;
                continue;
            }
        }

        let (mid, _) = partition(v, pivot, is_less);

        // Gura chidimbu mu `left`, `pivot`, uye `right`.
        let (left, right) = { v }.split_at_mut(mid);
        let (pivot, right) = right.split_at_mut(1);
        let pivot = &pivot[0];

        if mid < index {
            v = right;
            index = index - mid - 1;
            pred = Some(pivot);
        } else if mid > index {
            v = left;
        } else {
            // Kana mid==index, saka tapedza, sezvo partition() yakavimbisa kuti zvinhu zvese mushure mepakati zvakakura kudarika kana zvakaenzana nepakati.
            //
            return;
        }
    }
}

pub fn partition_at_index<T, F>(
    v: &mut [T],
    index: usize,
    mut is_less: F,
) -> (&mut [T], &mut T, &mut [T])
where
    F: FnMut(&T, &T) -> bool,
{
    use cmp::Ordering::Greater;
    use cmp::Ordering::Less;

    if index >= v.len() {
        panic!("partition_at_index index {} greater than length of slice {}", index, v.len());
    }

    if mem::size_of::<T>() == 0 {
        // Kuronga hakuna hunhu hunonzwisisika pane zero-saizi mhando.Siya zvakadaro.
    } else if index == v.len() - 1 {
        // Tsvaga max element woiisa munzvimbo yekupedzisira yeakarongeka.
        // Takasununguka kushandisa `unwrap()` pano nekuti tinoziva v haifanire kunge isina chinhu.
        let (max_index, _) = v
            .iter()
            .enumerate()
            .max_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(max_index, index);
    } else if index == 0 {
        // Tsvaga min element woiisa mune yekutanga chinzvimbo cheakarongeka.
        // Takasununguka kushandisa `unwrap()` pano nekuti tinoziva v haifanire kunge isina chinhu.
        let (min_index, _) = v
            .iter()
            .enumerate()
            .min_by(|&(_, x), &(_, y)| if is_less(x, y) { Less } else { Greater })
            .unwrap();
        v.swap(min_index, index);
    } else {
        partition_at_index_loop(v, index, &mut is_less, None);
    }

    let (left, right) = v.split_at_mut(index);
    let (pivot, right) = right.split_at_mut(1);
    let pivot = &mut pivot[0];
    (left, pivot, right)
}