//! Kushanda paASCII `[u8]`.

use crate::mem;

#[lang = "slice_u8"]
#[cfg(not(test))]
impl [u8] {
    /// Cheki kana mabheti ese ari muchidimbu ichi ari mukati meASCII renji.
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn is_ascii(&self) -> bool {
        is_ascii(self)
    }

    /// Inoongorora kuti zvidimbu zviviri iASCII kesi-isinganzwisise mutambo.
    ///
    /// Zvakafanana ne `to_ascii_lowercase(a) == to_ascii_lowercase(b)`, asi pasina kugovera nekuteedzera ma temporari.
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn eq_ignore_ascii_case(&self, other: &[u8]) -> bool {
        self.len() == other.len() && self.iter().zip(other).all(|(a, b)| a.eq_ignore_ascii_case(b))
    }

    /// Inoshandura chidimbu ichi kuita ASCII yepamusoro kesi yakaenzana mu-nzvimbo.
    ///
    /// ASCII mavara 'a' kusvika 'z' akaiswa kumepu ku 'A' kusvika 'Z', asi mavara asiri eASCII haana kuchinja.
    ///
    /// Kuti udzore iyo nyowani yepamusoro yepamusoro usingachinje iyo iripo, shandisa [`to_ascii_uppercase`].
    ///
    ///
    /// [`to_ascii_uppercase`]: #method.to_ascii_uppercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_uppercase(&mut self) {
        for byte in self {
            byte.make_ascii_uppercase();
        }
    }

    /// Inoshandura chidimbu ichi kuita yayo ASCII yakaderera kesi yakaenzana mu-nzvimbo.
    ///
    /// ASCII mavara 'A' kusvika 'Z' akaiswa kumepu ku 'a' kusvika 'z', asi mavara asiri eASCII haana kuchinja.
    ///
    /// Kudzosera iyo nyowani yakadzikira kukosha pasina kugadzirisa iyo iripo, shandisa [`to_ascii_lowercase`].
    ///
    ///
    /// [`to_ascii_lowercase`]: #method.to_ascii_lowercase
    ///
    #[stable(feature = "ascii_methods_on_intrinsics", since = "1.23.0")]
    #[inline]
    pub fn make_ascii_lowercase(&mut self) {
        for byte in self {
            byte.make_ascii_lowercase();
        }
    }
}

/// Inodzorera `true` kana paine chero byte mushoko `v` is nonascii (>=128).
/// Snarfed kubva ku `../str/mod.rs`, iyo inoita chimwe chinhu chakafanana kune utf8 kusimbiswa.
#[inline]
fn contains_nonascii(v: usize) -> bool {
    const NONASCII_MASK: usize = 0x80808080_80808080u64 as usize;
    (NONASCII_MASK & v) != 0
}

/// Yakagadziriswa ASCII bvunzo iyo inoshandisa usize-at-a-nguva mashandiro panzvimbo ye byte-at-a-nguva mashandiro (pazvinogoneka).
///
/// Iyo algorithm yatinoshandisa pano iri nyore nyore.Kana `s` ipfupi, isu tinongotarisa yega yega uye kuitiswa nayo.Zvikasadaro:
///
/// - Verenga izwi rekutanga uine unaligned mutoro.
/// - Gadziridza chinongedzo, verenga anotevera mazwi kusvika kumagumo nemitoro yakaenderana.
/// - Verenga yekupedzisira `usize` kubva ku `s` nemutoro usina kukamurwa.
///
/// Kana imwe yemitoro iyi ikaburitsa chimwe chinhu icho `contains_nonascii` (above) inodzoka ichokwadi, saka tinoziva kuti mhinduro inhema.
///
///
///
#[inline]
fn is_ascii(s: &[u8]) -> bool {
    const USIZE_SIZE: usize = mem::size_of::<usize>();

    let len = s.len();
    let align_offset = s.as_ptr().align_offset(USIZE_SIZE);

    // Kana isu tisingazowane chero chinhu kubva kuIzwi-pa-a-nguva kuita, dzokera kune scalar chiuno.
    //
    // Isu tinoitawo izvi kune zvivakwa uko `size_of::<usize>()` isina kukwana kuenderana kwe `usize`, nekuti inyowani edge kesi.
    //
    //
    if len < USIZE_SIZE || len < align_offset || USIZE_SIZE < mem::align_of::<usize>() {
        return s.iter().all(|b| b.is_ascii());
    }

    // Isu tinogara tichiverenga izwi rekutanga risina kuenderana, zvinoreva kuti `align_offset` iri
    // 0, taizoverenga kukosha kwakafanana zvakare kune akaenzana kuverenga.
    let offset_to_aligned = if align_offset == 0 { USIZE_SIZE } else { align_offset };

    let start = s.as_ptr();
    // Kachengeteka: Isu tinoongorora `len < USIZE_SIZE` pamusoro.
    let first_word = unsafe { (start as *const usize).read_unaligned() };

    if contains_nonascii(first_word) {
        return false;
    }
    // Takatarisa izvi pamusoro, zvimwe zvisina kujeka.
    // Ziva kuti `offset_to_aligned` ingave `align_offset` kana `USIZE_SIZE`, ese ari maviri akaongororwa zvakajeka pamusoro.
    //
    debug_assert!(offset_to_aligned <= len);

    // KUCHENGETEKA: izwi_ptr ndiyo (yakanyatsoenderana) usize ptr yatinoshandisa kuverenga iyo
    // chepakati chunk chechidimbu.
    let mut word_ptr = unsafe { start.add(offset_to_aligned) as *const usize };

    // `byte_pos` ndiyo byte index ye `word_ptr`, inoshandiswa pakuongorora kwekupedzisira.
    let mut byte_pos = offset_to_aligned;

    // Paranoia tarisa nezve kuenderana, nekuti isu tave kuda kuita boka reasina kuenderana mitoro.
    // Mukuita izvi zvinofanirwa kunge zvisingaite kudzivirira bhagi mu `align_offset` hazvo.
    //
    debug_assert_eq!((word_ptr as usize) % mem::align_of::<usize>(), 0);

    // Verenga anotevera mazwi kudzamara izwi rekupedzisira rakaenderana, kusasanganisira iro rekupedzisira rakaenderana izwi roga kuti riitwe muswe kutarisa gare gare, kuona kuti muswe unogara uri `usize` zvakanyanya kusvika kune imwe branch `byte_pos == len`.
    //
    //
    while byte_pos < len - USIZE_SIZE {
        debug_assert!(
            // Sanity tarisa kuti kuverenga kuri mumiganhu
            (word_ptr as usize + USIZE_SIZE) <= (start.wrapping_add(len) as usize) &&
            // Uye izvo zvatinofungidzira nezve `byte_pos` zvinobata.
            (word_ptr as usize) - (start as usize) == byte_pos
        );

        // Kachengeteka: Tinoziva `word_ptr` yakanyatsoenderana (nekuda kwe
        // `align_offset`), uye tinoziva kuti tine mabheti akakwana pakati pe `word_ptr` nemagumo
        let word = unsafe { word_ptr.read() };
        if contains_nonascii(word) {
            return false;
        }

        byte_pos += USIZE_SIZE;
        // Kachengeteka: Tinoziva iyo `byte_pos <= len - USIZE_SIZE`, zvinoreva kuti
        // mushure meiyi `add`, `word_ptr` ichave yakanyanya kupfuura-yapfuura-kumagumo.
        word_ptr = unsafe { word_ptr.add(1) };
    }

    // Cheki cheSanity kuona kuti paine chete `usize` imwe chete yasara.
    // Izvi zvinofanirwa kuvimbiswa nemamiriro edu echiuno.
    debug_assert!(byte_pos <= len && len - byte_pos <= USIZE_SIZE);

    // Kachengeteka: Izvi zvinovimba ne `len >= USIZE_SIZE`, iyo yatino tarisa pakutanga.
    let last_word = unsafe { (start.add(len - USIZE_SIZE) as *const usize).read_unaligned() };

    !contains_nonascii(last_word)
}