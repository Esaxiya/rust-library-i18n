//! Inotsanangura iyo `IntoIter` muridzi wayo iterator yezvikamu.

use crate::{
    fmt,
    iter::{ExactSizeIterator, FusedIterator, TrustedLen},
    mem::{self, MaybeUninit},
    ops::Range,
    ptr,
};

/// A-kukosha [array] iterator.
#[stable(feature = "array_value_iter", since = "1.51.0")]
pub struct IntoIter<T, const N: usize> {
    /// Aya ndiwo marongero atiri kuteterera pamusoro.
    ///
    /// Zvinhu zvine indekisi `i` uko `alive.start <= i < alive.end` isati yaburitswa parizvino uye zviri zvinyorwa zvakaringana.
    /// Zvinhu zvine indices `i < alive.start` kana `i >= alive.end` zvakatoburitswa kare uye hazvifanirwe kuwanikwa zvakare!Izvo zvinhu zvakafa zvinogona kunge zviri mune isina kunyatso kuvhurwa mamiriro!
    ///
    ///
    /// Saka zvinopinda ndezvi:
    /// - `data[alive]` mupenyu (kureva kuti ane zvinhu zvinoshanda)
    /// - `data[..alive.start]` uye `data[alive.end..]` yakafa (kureva kuti zvinhu zvacho zvaive zvatoverengerwa uye hazvifanirwe kubatwa futi!)
    ///
    ///
    ///
    data: [MaybeUninit<T>; N],

    /// Zvinhu zviri mu `data` izvo zvisati zvapihwa izvozvi.
    ///
    /// Invariants:
    /// - `alive.start <= alive.end`
    /// - `alive.end <= N`
    alive: Range<usize>,
}

impl<T, const N: usize> IntoIter<T, N> {
    /// Inogadzira iterator nyowani pamusoro peiyo yakapihwa `array`.
    ///
    /// *Cherekedza*: iyi nzira inogona kudzikiswa mu future, mushure me [`IntoIterator` is implemented for arrays][array-into-iter].
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::array;
    ///
    /// for value in array::IntoIter::new([1, 2, 3, 4, 5]) {
    ///     // Rudzi rwe `value` ndeye `i32` pano, panzvimbo ye `&i32`
    ///     let _: i32 = value;
    /// }
    /// ```
    /// [array-into-iter]: https://github.com/rust-lang/rust/pull/65819
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn new(array: [T; N]) -> Self {
        // Kachengeteka: Iyo transmute pano yakanyatsochengeteka.Iwo maHTML e `MaybeUninit`
        // promise:
        //
        // > `MaybeUninit<T>` inovimbiswa kuva nehukuru hwakaenzana uye kuenderana
        // > se `T`.
        //
        // Iwo maHTML anotoratidza kutapurirana kubva pamhando ye `MaybeUninit<T>` kuenda kune yakatarwa ye `T`.
        //
        //
        // Nezvo, kutanga uku kunogutsa izvo zvinopinda.

        // FIXME(LukasKalbertodt): chaizvo shandisa `mem::transmute` pano, kana ichinge yashanda nema const generics:
        //     `mem::transmute::<[T; N], [MaybeUninit<T>; N]>(array)`
        //
        // Kusvikira panguva iyoyo, tinogona kushandisa `mem::transmute_copy` kugadzira kopi zvishoma senge imwe mhando, wobva wakanganwa `array` kuti irege kudonhedzwa.
        //
        //
        unsafe {
            let iter = Self { data: mem::transmute_copy(&array), alive: 0..N };
            mem::forget(array);
            iter
        }
    }

    /// Inodzosera chidimbu chisingachinjiki chezvinhu zvese zvisati zvaburitswa parizvino.
    ///
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_slice(&self) -> &[T] {
        // Kachengeteka: Tinoziva kuti zvinhu zvese zviri mukati me `alive` zvakatangwa nemazvo.
        unsafe {
            let slice = self.data.get_unchecked(self.alive.clone());
            MaybeUninit::slice_assume_init_ref(slice)
        }
    }

    /// Inodzosera chidimbu chinoshanduka chezvinhu zvese zvisati zvaburitswa parizvino.
    #[stable(feature = "array_value_iter", since = "1.51.0")]
    pub fn as_mut_slice(&mut self) -> &mut [T] {
        // Kachengeteka: Tinoziva kuti zvinhu zvese zviri mukati me `alive` zvakatangwa nemazvo.
        unsafe {
            let slice = self.data.get_unchecked_mut(self.alive.clone());
            MaybeUninit::slice_assume_init_mut(slice)
        }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Iterator for IntoIter<T, N> {
    type Item = T;
    fn next(&mut self) -> Option<Self::Item> {
        // Tora indekisi inotevera kubva kumberi.
        //
        // Kuwedzera `alive.start` na1 kunochengetedza izvo zvisingawanzo maererano ne `alive`.
        // Nekudaro, nekuda kweshanduko iyi, kwenguva pfupi, nzvimbo mhenyu haisi `data[alive]` zvekare, asi `data[idx..alive.end]`.
        //
        self.alive.next().map(|idx| {
            // Verenga chinhu kubva pakurongeka.
            // KUCHENGETEKA: `idx` indekisi munzvimbo yekare ye "alive" ye
            // rondedzero.Kuverenga chinhu ichi kunoreva kuti `data[idx]` inoonekwa seyakafa izvozvi (kureva kuti usabata).
            // Sezvo `idx` kwaive kutanga kwenzvimbo mhenyu, nzvimbo iri kurarama yava `data[alive]` zvakare, ichidzorera zvese zvinopinda.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        let len = self.len();
        (len, Some(len))
    }

    fn count(self) -> usize {
        self.len()
    }

    fn last(mut self) -> Option<Self::Item> {
        self.next_back()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> DoubleEndedIterator for IntoIter<T, N> {
    fn next_back(&mut self) -> Option<Self::Item> {
        // Tora indekisi inotevera kubva kumashure.
        //
        // Kuderedza `alive.end` na1 inochengetedza iyo isingaite maererano ne `alive`.
        // Nekudaro, nekuda kweshanduko iyi, kwenguva pfupi, nzvimbo mhenyu haisi `data[alive]` zvekare, asi `data[alive.start..=idx]`.
        //
        self.alive.next_back().map(|idx| {
            // Verenga chinhu kubva pakurongeka.
            // KUCHENGETEKA: `idx` indekisi munzvimbo yekare ye "alive" ye
            // rondedzero.Kuverenga chinhu ichi kunoreva kuti `data[idx]` inoonekwa seyakafa izvozvi (kureva kuti usabata).
            // Sezvo `idx` kwaive kupera kwenzvimbo mhenyu, nzvimbo iri kurarama yava `data[alive]` zvakare, ichidzorera zvese zvinopinda.
            //
            //
            unsafe { self.data.get_unchecked(idx).assume_init_read() }
        })
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> Drop for IntoIter<T, N> {
    fn drop(&mut self) {
        // Kachengeteka: Izvi zvakachengeteka: `as_mut_slice` inodzosa chaizvo iyo sub-chidimbu
        // yezvinhu zvisati zvabviswa kunze uye zvinoramba zvichidonhedzwa.
        //
        unsafe { ptr::drop_in_place(self.as_mut_slice()) }
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> ExactSizeIterator for IntoIter<T, N> {
    fn len(&self) -> usize {
        // Haizombo fashukira nekuda kweanogara ari `mupenyu.start <=
        // alive.end`.
        self.alive.end - self.alive.start
    }
    fn is_empty(&self) -> bool {
        self.alive.is_empty()
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T, const N: usize> FusedIterator for IntoIter<T, N> {}

// Iyo iterator zvechokwadi inoshuma iyo chaiyo urefu.
// Huwandu hwe "alive" zvinhu (izvo zvichiri kuburitswa) hwurefu hwenzvimbo `alive`.
// Iri renji rakaderedzwa murefu mune chero `next` kana `next_back`.
// Iyo inogara ichideredzwa ne1 mune idzodzo nzira, asi chete kana `Some(_)` ikadzoserwa.
#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
unsafe impl<T, const N: usize> TrustedLen for IntoIter<T, N> {}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: Clone, const N: usize> Clone for IntoIter<T, N> {
    fn clone(&self) -> Self {
        // Tarira, isu hatidi kunyatso fananidza iwo chaiwo iwo chaiwo mararamiro, saka isu tinogona kungonamira mukukanganisa 0 zvisinei nekuti `self` iripi.
        //
        let mut new = Self { data: MaybeUninit::uninit_array(), alive: 0..0 };

        // Shongedza zvese zvinhu zvipenyu.
        for (src, dst) in self.as_slice().iter().zip(&mut new.data) {
            // Nyora dombo mune idzva rondedzero, wobva wadzokorora yayo iripenyu renji.
            // Kana tichiumbiridza panics, isu tinonyatsodonhedza zvinhu zvakapfuura.
            dst.write(src.clone());
            new.alive.end += 1;
        }

        new
    }
}

#[stable(feature = "array_value_iter_impls", since = "1.40.0")]
impl<T: fmt::Debug, const N: usize> fmt::Debug for IntoIter<T, N> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // Chete purinda izvo izvo zvisati zvaburitswa parizvino: hatigone kuwana izvo zvakaburitswa izvo.
        //
        f.debug_tuple("IntoIter").field(&self.as_slice()).finish()
    }
}