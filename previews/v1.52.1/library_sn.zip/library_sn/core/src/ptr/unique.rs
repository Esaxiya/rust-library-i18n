use crate::convert::From;
use crate::fmt;
use crate::marker::{PhantomData, Unsize};
use crate::mem;
use crate::ops::{CoerceUnsized, DispatchFromDyn};

/// Kuputira kwakatenderedza mbishi isina-null `*mut T` iyo inoratidza kuti muridzi weiyi inoputira muridzi ane yake.
/// Inobatsira pakuvaka zvisingabvumirwe se `Box<T>`, `Vec<T>`, `String`, uye `HashMap<K, V>`.
///
/// Kusiyana ne `*mut T`, `Unique<T>` inoita "as if" yaive muenzaniso we `T`.
/// Inoshandisa `Send`/`Sync` kana `T` iri `Send`/`Sync`.
/// Izvo zvakare zvinoreva iyo mhando yeakasimba aliasing anovimbisa chiitiko che `T` inogona kutarisira:
/// chirevo chechinongedzo hachifanirwe kuchinjwa chisina nzira yakasarudzika kune yayo yakasarudzika.
///
/// Kana iwe usina chokwadi chekuti ndizvo here kushandisa `Unique` nekuda kwezvinangwa zvako, funga kushandisa `NonNull`, iyo ine mashoma semantics.
///
///
/// Kusiyana ne `*mut T`, iyo pointer inofanirwa kugara isinga-null, kunyangwe iyo pointer isina kumbobvumidzwa.
/// Izvi ndezvekuti enum dzinogona kushandisa uyu mutengo wakarambidzwa semusarura-`Option<Unique<T>>` ine saizi yakafanana ne `Unique<T>`.
/// Nekudaro iyo pointer inogona kuramba yakatetepa kana isina kurehwa.
///
/// Kusiyana ne `*mut T`, `Unique<T>` ndeye covariant pamusoro pe `T`.
/// Izvi zvinofanirwa kugara zvichinyatsoita chero mhando inokwidziridza yakasarudzika yekuda inoda.
///
///
///
#[unstable(
    feature = "ptr_internals",
    issue = "none",
    reason = "use `NonNull` instead and consider `PhantomData<T>` \
              (if you also use `#[may_dangle]`), `Send`, and/or `Sync`"
)]
#[doc(hidden)]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
pub struct Unique<T: ?Sized> {
    pointer: *const T,
    // NOTE: mucherechedzo uyu hauna mhedzisiro yekusiyana, asi zvinodikanwa
    // kuitira kudonha kuti tinzwisise kuti zvine musoro kuva ne `T`.
    //
    // Kuti uwane ruzivo, ona:
    // https://github.com/rust-lang/rfcs/blob/master/text/0769-sound-generic-drop.md#phantom-data
    _marker: PhantomData<T>,
}

/// `Unique` anonongedzera ari `Send` kana `T` iri `Send` nekuti iyo data yavanongedzera yakaiswa.
/// Ziva kuti ino aliasing invariant haina kumanikidzwa neiyo mhando system;kubviswa uchishandisa iyo `Unique` kunofanirwa kuisimbisa.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Send + ?Sized> Send for Unique<T> {}

/// `Unique` anonongedzera ari `Sync` kana `T` iri `Sync` nekuti iyo data yavanongedzera yakaiswa.
/// Ziva kuti ino aliasing invariant haina kumanikidzwa neiyo mhando system;kubviswa uchishandisa iyo `Unique` kunofanirwa kuisimbisa.
///
///
#[unstable(feature = "ptr_internals", issue = "none")]
unsafe impl<T: Sync + ?Sized> Sync for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: Sized> Unique<T> {
    /// Inogadzira `Unique` nyowani yakaturika, asi yakanyatsoenderana.
    ///
    /// Izvi zvinobatsira kutanga mhando dzinogovana nousimbe, sezvinoita `Vec::new`.
    ///
    /// Ziva kuti pointer kukosha kunogona kunge kuchimiririra pointer inoshanda kune `T`, zvinoreva kuti izvi hazvifanire kushandiswa se "not yet initialized" sentinel kukosha.
    /// Mhando dzinogovana zvine usimbe dzinofanirwa kuteedzera kutanga neimwe nzira.
    ///
    ///
    ///
    #[inline]
    pub const fn dangling() -> Self {
        // Kachengeteka: mem::align_of() inodzosera inoshanda, isiri-null pointer.Iyo
        // mamiriro ekudaidza new_unchecked() anokudzwa kudaro.
        unsafe { Unique::new_unchecked(mem::align_of::<T>() as *mut T) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Unique<T> {
    /// Inogadzira `Unique` nyowani.
    ///
    /// # Safety
    ///
    /// `ptr` inofanirwa kunge isiri-null.
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // Kachengeteka: iye anodana anofanira kuvimbisa kuti `ptr` haina-null.
        unsafe { Unique { pointer: ptr as _, _marker: PhantomData } }
    }

    /// Inogadzira `Unique` nyowani kana `ptr` isiri-null.
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // Kachengeteka: Iyo pointer yakatotariswa uye haina kushata.
            Some(unsafe { Unique { pointer: ptr as _, _marker: PhantomData } })
        } else {
            None
        }
    }

    /// Inowana iyo yepasi `*mut` pointer.
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Inosarudza zvirimo.
    ///
    /// Hupenyu hunoguma hwakasungirwa kune wega saka izvi zvinoita "as if" yanga iri mamiriro eiyo T iri kukweretwa.
    /// Kana yakareba (unbound) yeupenyu ichidikanwa, shandisa `&*my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // Kachengeteka: iye anodana anofanira kuvimbisa kuti `self` inosangana neese
        // zvinodiwa kune chirevo.
        unsafe { &*self.as_ptr() }
    }

    /// Zvinonzwisisika zvinoratidzira zvirimo.
    ///
    /// Hupenyu hunoguma hwakasungirwa kune wega saka izvi zvinoita "as if" yanga iri mamiriro eiyo T iri kukweretwa.
    /// Kana yakareba (unbound) yeupenyu ichidikanwa, shandisa `&mut *my_ptr.as_ptr()`.
    ///
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // Kachengeteka: iye anodana anofanira kuvimbisa kuti `self` inosangana neese
        // zvinodiwa kune chinoshandurwa chirevo.
        unsafe { &mut *self.as_ptr() }
    }

    /// Inokanda kunongedzera yerumwe rudzi.
    #[inline]
    pub const fn cast<U>(self) -> Unique<U> {
        // Kachengeteka: Unique::new_unchecked() inogadzira yakasarudzika nyowani uye zvido
        // iyo yakapihwa pointer yekusave isina basa.
        // Sezvo isu tiri kupfuura pachedu seye pointer, haigone kuve isina basa.
        unsafe { Unique::new_unchecked(self.as_ptr() as *mut U) }
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Clone for Unique<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> Copy for Unique<T> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<Unique<U>> for Unique<T> where T: Unsize<U> {}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Debug for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> fmt::Pointer for Unique<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<&mut T> for Unique<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // Kachengeteka: Chirevo chinoshanduka hachigone kuitika
        unsafe { Unique { pointer: reference as *mut T, _marker: PhantomData } }
    }
}