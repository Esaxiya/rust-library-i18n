use crate::cmp::Ordering;
use crate::convert::From;
use crate::fmt;
use crate::hash;
use crate::marker::Unsize;
use crate::mem::{self, MaybeUninit};
use crate::ops::{CoerceUnsized, DispatchFromDyn};
use crate::ptr::Unique;
use crate::slice::{self, SliceIndex};

/// `*mut T` asi isiri zero uye covariant.
///
/// Izvi zvinowanzo kuve chinhu chakakodzera kushandisa kana uchivaka zvivakwa zvemadhata uchishandisa zvinongedzo zvisvinu, asi pakupedzisira zvine njodzi kushandisa nekuda kweayo ekuwedzera zvivakwa.Kana iwe usina chokwadi kana uchifanira kushandisa `NonNull<T>`, ingoshandisa `*mut T`!
///
/// Kusiyana ne `*mut T`, iyo pointer inofanirwa kugara isinga-null, kunyangwe iyo pointer isina kumbobvumidzwa.Izvi ndezvekuti enum dzinogona kushandisa iri rakarambidzwa kukosha sechisarudzo-`Option<NonNull<T>>` ine saizi yakafanana ne `* mut T`.
/// Nekudaro iyo pointer inogona kuramba yakatetepa kana isina kurehwa.
///
/// Kusiyana ne `*mut T`, `NonNull<T>` yakasarudzwa kuve covariant pamusoro pe `T`.Izvi zvinoita kuti zvikwanise kushandisa `NonNull<T>` kana uchivaka mhando dzemhando dzakasiyana, asi inounza njodzi yekusagadzikana kana ikashandiswa mune imwe mhando isingafanire kunge iri covariant.
/// (Sarudzo inopesana yakagadzirirwa `*mut T` kunyangwe nehunyanzvi kusagadzikana kunogona kungokonzerwa nekufona mabasa asina kuchengeteka.)
///
/// Covariance ndiyo chaiyo yezvinhu zvakachengeteka zvakanyanya, senge `Box`, `Rc`, `Arc`, `Vec`, uye `LinkedList`.Iyi ndiyo kesi nekuti ivo vanopa yeruzhinji API iyo inoteedzana yakajairwa yakagovaniswa XOR mitemo inoshanduka ye Rust.
///
/// Kana yako mhando isingakwanise kuve covariant zvakachengeteka, iwe unofanirwa kuona kuti iine imwe yekuwedzera ndima yekupa inowoneka.Kazhinji munda uyu unenge uri [`PhantomData`] mhando senge `PhantomData<Cell<T>>` kana `PhantomData<&'a mut T>`.
///
/// Cherekedza kuti `NonNull<T>` ine `From` semuenzaniso ye `&T`.Nekudaro, izvi hazvichinje chokwadi chekuti kuchinjika kuburikidza ne (pointer yakatorwa kubva ku) yakagovaniswa rejisheni haina kujekeswa maitiro kutoti shanduko ikaitika mukati me [`UnsafeCell<T>`].Izvo zvinoenda mukugadzira chirevo chinoshanduka kubva kunongedzo yakagovaniswa.
///
/// Paunenge uchishandisa iyi `From` semuenzaniso pasina `UnsafeCell<T>`, ibasa rako kuona kuti `as_mut` haina kubvira yadaidzwa, uye `as_ptr` haimboshandisirwe shanduko.
///
/// [`PhantomData`]: crate::marker::PhantomData
/// [`UnsafeCell<T>`]: crate::cell::UnsafeCell
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "nonnull", since = "1.25.0")]
#[repr(transparent)]
#[rustc_layout_scalar_valid_range_start(1)]
#[rustc_nonnull_optimization_guaranteed]
pub struct NonNull<T: ?Sized> {
    pointer: *const T,
}

/// `NonNull` zvinongedzo hazvisi `Send` nekuti iyo data yavanoreva inogona kushevedzwa.
// NB, iyi impl haina basa, asi inofanira kupa zvirinani mameseji ekukanganisa.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Send for NonNull<T> {}

/// `NonNull` zvinongedzo hazvisi `Sync` nekuti iyo data yavanoreva inogona kushevedzwa.
// NB, iyi impl haina basa, asi inofanira kupa zvirinani mameseji ekukanganisa.
#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> !Sync for NonNull<T> {}

impl<T: Sized> NonNull<T> {
    /// Inogadzira `NonNull` nyowani yakaturika, asi yakanyatsoenderana.
    ///
    /// Izvi zvinobatsira kutanga mhando dzinogovana nousimbe, sezvinoita `Vec::new`.
    ///
    /// Ziva kuti pointer kukosha kunogona kunge kuchimiririra pointer inoshanda kune `T`, zvinoreva kuti izvi hazvifanire kushandiswa se "not yet initialized" sentinel kukosha.
    /// Mhando dzinogovana zvine usimbe dzinofanirwa kuteedzera kutanga neimwe nzira.
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_dangling", since = "1.32.0")]
    #[inline]
    pub const fn dangling() -> Self {
        // Kachengeteka: mem::align_of() inodzosera isiri-zero usize iyo inokandwa
        // kune * mut T.
        // Naizvozvo, `ptr` haisi null uye mamiriro ekudaidza new_unchecked() anokudzwa.
        unsafe {
            let ptr = mem::align_of::<T>() as *mut T;
            NonNull::new_unchecked(ptr)
        }
    }

    /// Inodzorera zvirevo zvakagovaniswa kune kukosha.Kupesana ne [`as_ref`], izvi hazvidi kuti kukosha kwacho kutange kutangwa.
    ///
    /// Kune mumwe anogona kuchinjika ona [`as_uninit_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    ///
    /// # Safety
    ///
    /// Paunenge uchidana iyi nzira, unofanirwa kuona kuti zvese zvinotevera ndezvechokwadi:
    ///
    /// * Iyo pointer inofanira kunge yakanyatsoenderana.
    ///
    /// * Inofanira kunge iri "dereferencable" mupfungwa inotsanangurwa mu [the module documentation].
    ///
    /// * Iwe unofanirwa kumisikidza Rust yekumisikidza mitemo, nekuti iyo yakadzoserwa yehupenyu `'a` yakasarudzika zvakasarudzika uye hazvireve kuti inoratidza chaiko hupenyu hwedata.
    ///
    ///   Kunyanya, kwenguva yenguva ino yehupenyu, ndangariro inonongedzerwa nechinongedzo haifanire kuchinjwa (kunze kwemukati me `UnsafeCell`).
    ///
    /// Izvi zvinoshanda kunyangwe mhedzisiro yeiyi nzira ikasashandiswa!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref(&self) -> &MaybeUninit<T> {
        // Kachengeteka: iye anodana anofanira kuvimbisa kuti `self` inosangana neese
        // zvinodiwa kune chirevo.
        unsafe { &*self.cast().as_ptr() }
    }

    /// Inodzorera yakasarudzika mareferensi kune iyo kukosha.Kupesana ne [`as_mut`], izvi hazvidi kuti kukosha kwacho kutange kutangwa.
    ///
    /// Kune mumwe waunogovana naye ona [`as_uninit_ref`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    ///
    /// # Safety
    ///
    /// Paunenge uchidana iyi nzira, unofanirwa kuona kuti zvese zvinotevera ndezvechokwadi:
    ///
    /// * Iyo pointer inofanira kunge yakanyatsoenderana.
    ///
    /// * Inofanira kunge iri "dereferencable" mupfungwa inotsanangurwa mu [the module documentation].
    ///
    /// * Iwe unofanirwa kumisikidza Rust yekumisikidza mitemo, nekuti iyo yakadzoserwa yehupenyu `'a` yakasarudzika zvakasarudzika uye hazvireve kuti inoratidza chaiko hupenyu hwedata.
    ///
    ///   Kunyanya, kwenguva yenguva ino yehupenyu, ndangariro inonongedzerwa nechinongedzo haifanirwe kuwanikwa (kuverenga kana kunyorwa) kuburikidza nechero imwe pointer.
    ///
    /// Izvi zvinoshanda kunyangwe mhedzisiro yeiyi nzira ikasashandiswa!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut(&mut self) -> &mut MaybeUninit<T> {
        // Kachengeteka: iye anodana anofanira kuvimbisa kuti `self` inosangana neese
        // zvinodiwa kune chirevo.
        unsafe { &mut *self.cast().as_ptr() }
    }
}

impl<T: ?Sized> NonNull<T> {
    /// Inogadzira `NonNull` nyowani.
    ///
    /// # Safety
    ///
    /// `ptr` inofanirwa kunge isiri-null.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_new_unchecked", since = "1.32.0")]
    #[inline]
    pub const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // Kachengeteka: iye anodana anofanira kuvimbisa kuti `ptr` haina-null.
        unsafe { NonNull { pointer: ptr as _ } }
    }

    /// Inogadzira `NonNull` nyowani kana `ptr` isiri-null.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub fn new(ptr: *mut T) -> Option<Self> {
        if !ptr.is_null() {
            // Kachengeteka: Iyo pointer yatotariswa uye haina kushata
            Some(unsafe { Self::new_unchecked(ptr) })
        } else {
            None
        }
    }

    /// Inoita mashandiro akafanana ne [`std::ptr::from_raw_parts`], kunze kwekuti `NonNull` pointer inodzoserwa, zvinopesana neyakajeka `*const` pointer.
    ///
    ///
    /// Ona zvinyorwa zve [`std::ptr::from_raw_parts`] kuti uwane rumwe ruzivo.
    ///
    /// [`std::ptr::from_raw_parts`]: crate::ptr::from_raw_parts
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn from_raw_parts(
        data_address: NonNull<()>,
        metadata: <T as super::Pointee>::Metadata,
    ) -> NonNull<T> {
        // Kachengeteka: Mhedzisiro ye `ptr::from::raw_parts_mut` haina-null nekuti `data_address` iri.
        unsafe {
            NonNull::new_unchecked(super::from_raw_parts_mut(data_address.as_ptr(), metadata))
        }
    }

    /// Sora iyo (pamwe yakafara) pointer mune iri kero uye metadata yezvinhu.
    ///
    /// Iyo pointer inogona kugadziriswazve ne [`NonNull::from_raw_parts`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (NonNull<()>, <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self.as_ptr()))
    }

    /// Inowana iyo yepasi `*mut` pointer.
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[rustc_const_stable(feature = "const_nonnull_as_ptr", since = "1.32.0")]
    #[inline]
    pub const fn as_ptr(self) -> *mut T {
        self.pointer as *mut T
    }

    /// Inodzorera yakagovaniswa mareferensi kune iyo kukosha.Kana kukosha kwacho kungasaziviswa, [`as_uninit_ref`] inofanira kushandiswa pachinzvimbo.
    ///
    /// Kune mumwe anogona kuchinjika ona [`as_mut`].
    ///
    /// [`as_uninit_ref`]: NonNull::as_uninit_ref
    /// [`as_mut`]: NonNull::as_mut
    ///
    /// # Safety
    ///
    /// Paunenge uchidana iyi nzira, unofanirwa kuona kuti zvese zvinotevera ndezvechokwadi:
    ///
    /// * Iyo pointer inofanira kunge yakanyatsoenderana.
    ///
    /// * Inofanira kunge iri "dereferencable" mupfungwa inotsanangurwa mu [the module documentation].
    ///
    /// * Iyo pointer inofanira kunongedzera kune yekutanga chiitiko ye `T`.
    ///
    /// * Iwe unofanirwa kumisikidza Rust yekumisikidza mitemo, nekuti iyo yakadzoserwa yehupenyu `'a` yakasarudzika zvakasarudzika uye hazvireve kuti inoratidza chaiko hupenyu hwedata.
    ///
    ///   Kunyanya, kwenguva yenguva ino yehupenyu, ndangariro inonongedzerwa nechinongedzo haifanire kuchinjwa (kunze kwemukati me `UnsafeCell`).
    ///
    /// Izvi zvinoshanda kunyangwe mhedzisiro yeiyi nzira ikasashandiswa!
    /// (Chikamu chekutangiswa hachisati chasarudzwa zvizere, asi kusvikira chasvika, nzira chete yakachengeteka ndeyekuona kuti dzakatangwa zvechokwadi.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_ref(&self) -> &T {
        // Kachengeteka: iye anodana anofanira kuvimbisa kuti `self` inosangana neese
        // zvinodiwa kune chirevo.
        unsafe { &*self.as_ptr() }
    }

    /// Inodzorera yakasarudzika chirevo kune iyo kukosha.Kana kukosha kwacho kungasaziviswa, [`as_uninit_mut`] inofanira kushandiswa pachinzvimbo.
    ///
    /// Kune mumwe waunogovana naye ona [`as_ref`].
    ///
    /// [`as_uninit_mut`]: NonNull::as_uninit_mut
    /// [`as_ref`]: NonNull::as_ref
    ///
    /// # Safety
    ///
    /// Paunenge uchidana iyi nzira, unofanirwa kuona kuti zvese zvinotevera ndezvechokwadi:
    ///
    /// * Iyo pointer inofanira kunge yakanyatsoenderana.
    ///
    /// * Inofanira kunge iri "dereferencable" mupfungwa inotsanangurwa mu [the module documentation].
    ///
    /// * Iyo pointer inofanira kunongedzera kune yekutanga chiitiko ye `T`.
    ///
    /// * Iwe unofanirwa kumisikidza Rust yekumisikidza mitemo, nekuti iyo yakadzoserwa yehupenyu `'a` yakasarudzika zvakasarudzika uye hazvireve kuti inoratidza chaiko hupenyu hwedata.
    ///
    ///   Kunyanya, kwenguva yenguva ino yehupenyu, ndangariro inonongedzerwa nechinongedzo haifanirwe kuwanikwa (kuverenga kana kunyorwa) kuburikidza nechero imwe pointer.
    ///
    /// Izvi zvinoshanda kunyangwe mhedzisiro yeiyi nzira ikasashandiswa!
    /// (Chikamu chekutangiswa hachisati chasarudzwa zvizere, asi kusvikira chasvika, nzira chete yakachengeteka ndeyekuona kuti dzakatangwa zvechokwadi.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[stable(feature = "nonnull", since = "1.25.0")]
    #[inline]
    pub unsafe fn as_mut(&mut self) -> &mut T {
        // Kachengeteka: iye anodana anofanira kuvimbisa kuti `self` inosangana neese
        // zvinodiwa kune chinoshandurwa chirevo.
        unsafe { &mut *self.as_ptr() }
    }

    /// Inokanda kunongedzera yerumwe rudzi.
    #[stable(feature = "nonnull_cast", since = "1.27.0")]
    #[rustc_const_stable(feature = "const_nonnull_cast", since = "1.32.0")]
    #[inline]
    pub const fn cast<U>(self) -> NonNull<U> {
        // KUCHENGETEKA: `self` inongedzera `NonNull` iyo inofanirwa kunge isiri-null
        unsafe { NonNull::new_unchecked(self.as_ptr() as *mut U) }
    }
}

impl<T> NonNull<[T]> {
    /// Inogadzira isina-null mbichana slice kubva kune yakatetepa pointer uye kureba.
    ///
    /// Iyo `len` nharo ndiyo nhamba ye **zvinhu**, kwete iyo nhamba yemabheti.
    ///
    /// Iri basa rakachengeteka, asi kuratidza kukosha kwekudzoka hakuna kuchengeteka.
    /// Ona zvinyorwa zve [`slice::from_raw_parts`] yezvidimbu zvekuchengetedza zvidimbu.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(nonnull_slice_from_raw_parts)]
    ///
    /// use std::ptr::NonNull;
    ///
    /// // gadzira chidimbu chechidimbu kana uchitanga nechinongedzo kuchinhu chekutanga
    /// let mut x = [5, 6, 7];
    /// let nonnull_pointer = NonNull::new(x.as_mut_ptr()).unwrap();
    /// let slice = NonNull::slice_from_raw_parts(nonnull_pointer, 3);
    /// assert_eq!(unsafe { slice.as_ref()[2] }, 7);
    /// ```
    ///
    /// (Cherekedza kuti uyu muenzaniso unoratidzira kuratidza kushandiswa kweiyi nzira, asi` rega slice= NonNull::from(&x[..]);` would be a better way to write code like this.)
    ///
    #[unstable(feature = "nonnull_slice_from_raw_parts", issue = "71941")]
    #[rustc_const_unstable(feature = "const_nonnull_slice_from_raw_parts", issue = "71941")]
    #[inline]
    pub const fn slice_from_raw_parts(data: NonNull<T>, len: usize) -> Self {
        // KUCHENGETEKA: `data` inongedzera `NonNull` iyo inofanirwa kunge isiri-null
        unsafe { Self::new_unchecked(super::slice_from_raw_parts_mut(data.as_ptr(), len)) }
    }

    /// Inodzorera kureba kwechinhu chisina-chisina kubviswa slice.
    ///
    /// Iko kwakadzoserwa kukosha ndiyo nhamba ye **zvinhu**, kwete iyo nhamba yemabheti.
    ///
    /// Iri basa rakachengeteka, kunyangwe iyo isina-null slice mbishi isingakwanise kuratidzwa kuchidimbu nekuti chinongedzo hachina kero inoshanda.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    #[inline]
    pub const fn len(self) -> usize {
        self.as_ptr().len()
    }

    /// Inodzorera isina-null pointer kune iyo slice's buffer.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_non_null_ptr(), NonNull::new(1 as *mut i8).unwrap());
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_non_null_ptr(self) -> NonNull<T> {
        // Kachengeteka: Tinoziva `self` haina-null.
        unsafe { NonNull::new_unchecked(self.as_ptr().as_mut_ptr()) }
    }

    /// Inodzosera pointer mbishi kune iyo bhaudhi bhaisikopo.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let slice: NonNull<[i8]> = NonNull::slice_from_raw_parts(NonNull::dangling(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 1 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self.as_non_null_ptr().as_ptr()
    }

    /// Inodzosera yakagovaniswa mareferenzi kune chidimbu cheanogona kunge asina kunyorwa kukosha.Kupesana ne [`as_ref`], izvi hazvidi kuti kukosha kwacho kutange kutangwa.
    ///
    /// Kune mumwe anogona kuchinjika ona [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: NonNull::as_ref
    /// [`as_uninit_slice_mut`]: NonNull::as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Paunenge uchidana iyi nzira, unofanirwa kuona kuti zvese zvinotevera ndezvechokwadi:
    ///
    /// * Iyo pointer inofanira kunge iri [valid] yekuverengera `ptr.len() * mem::size_of::<T>()` akawanda mabheti, uye inofanirwa kunge ichinyatsoenderana.Izvi zvinoreva kunyanya:
    ///
    ///     * Iyo yese yekurangarira huwandu hweichi chidimbu chinofanirwa kunge chiri mukati mechinhu chimwe chakapihwa chinhu!
    ///       Slices haambofi akatenderera pane akawanda akagoverwa zvinhu.
    ///
    ///     * Iyo pointer inofanirwa kuenderana kunyangwe zero-kureba zvidimbu.
    ///     Chimwe chikonzero cheichi ndechekuti enum marongero ekugadzirisa anogona kuvimba nezvirevo (kusanganisira zvidimbu zvehurefu chero hupi) uchienderana uye usiri-null kuvasiyanisa kubva kune imwe data.
    ///
    ///     Iwe unogona kuwana pointer iyo inoshandiswa se `data` yemazero-kureba zvidimbu uchishandisa [`NonNull::dangling()`].
    ///
    /// * Hurefu hwese `ptr.len() * mem::size_of::<T>()` yechidimbu hachifanirwe kunge chakakura kupfuura `isize::MAX`.
    ///   Ona zvinyorwa zvekuchengetedza zve [`pointer::offset`].
    ///
    /// * Iwe unofanirwa kumisikidza Rust yekumisikidza mitemo, nekuti iyo yakadzoserwa yehupenyu `'a` yakasarudzika zvakasarudzika uye hazvireve kuti inoratidza chaiko hupenyu hwedata.
    ///   Kunyanya, kwenguva yenguva ino yehupenyu, ndangariro inonongedzerwa nechinongedzo haifanire kuchinjwa (kunze kwemukati me `UnsafeCell`).
    ///
    /// Izvi zvinoshanda kunyangwe mhedzisiro yeiyi nzira ikasashandiswa!
    ///
    /// Onawo [`slice::from_raw_parts`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice(&self) -> &[MaybeUninit<T>] {
        // KUCHENGETEKA: iye anodana anofanirwa kuchengetedza chibvumirano chekuchengetedza che `as_uninit_slice`.
        unsafe { slice::from_raw_parts(self.cast().as_ptr(), self.len()) }
    }

    /// Inodzorera yakasarudzika chirevo kuchidimbu chemitengo ingangove isina kuvhurwa.Kupesana ne [`as_mut`], izvi hazvidi kuti kukosha kwacho kutange kutangwa.
    ///
    /// Kune mumwe waunogovana naye ona [`as_uninit_slice`].
    ///
    /// [`as_mut`]: NonNull::as_mut
    /// [`as_uninit_slice`]: NonNull::as_uninit_slice
    ///
    /// # Safety
    ///
    /// Paunenge uchidana iyi nzira, unofanirwa kuona kuti zvese zvinotevera ndezvechokwadi:
    ///
    /// * Iyo pointer inofanira kunge iri [valid] yekuverenga uye inonyorera `ptr.len() * mem::size_of::<T>()` akawanda mabheti, uye inofanirwa kunge ichinyatsoenderana.Izvi zvinoreva kunyanya:
    ///
    ///     * Iyo yese yekurangarira huwandu hweichi chidimbu chinofanirwa kunge chiri mukati mechinhu chimwe chakapihwa chinhu!
    ///       Slices haambofi akatenderera pane akawanda akagoverwa zvinhu.
    ///
    ///     * Iyo pointer inofanirwa kuenderana kunyangwe zero-kureba zvidimbu.
    ///     Chimwe chikonzero cheichi ndechekuti enum marongero ekugadzirisa anogona kuvimba nezvirevo (kusanganisira zvidimbu zvehurefu chero hupi) uchienderana uye usiri-null kuvasiyanisa kubva kune imwe data.
    ///
    ///     Iwe unogona kuwana pointer iyo inoshandiswa se `data` yemazero-kureba zvidimbu uchishandisa [`NonNull::dangling()`].
    ///
    /// * Hurefu hwese `ptr.len() * mem::size_of::<T>()` yechidimbu hachifanirwe kunge chakakura kupfuura `isize::MAX`.
    ///   Ona zvinyorwa zvekuchengetedza zve [`pointer::offset`].
    ///
    /// * Iwe unofanirwa kumisikidza Rust yekumisikidza mitemo, nekuti iyo yakadzoserwa yehupenyu `'a` yakasarudzika zvakasarudzika uye hazvireve kuti inoratidza chaiko hupenyu hwedata.
    ///   Kunyanya, kwenguva yenguva ino yehupenyu, ndangariro inonongedzerwa nechinongedzo haifanirwe kuwanikwa (kuverenga kana kunyorwa) kuburikidza nechero imwe pointer.
    ///
    /// Izvi zvinoshanda kunyangwe mhedzisiro yeiyi nzira ikasashandiswa!
    ///
    /// Onawo [`slice::from_raw_parts_mut`].
    ///
    /// [valid]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(allocator_api, ptr_as_uninit)]
    ///
    /// use std::alloc::{Allocator, Layout, Global};
    /// use std::mem::MaybeUninit;
    /// use std::ptr::NonNull;
    ///
    /// let memory: NonNull<[u8]> = Global.allocate(Layout::new::<[u8; 32]>())?;
    /// // Izvi zvakachengeteka sezvo `memory` inoshanda pakuverenga uye ichinyorera `memory.len()` akawanda mabheti.
    /// // Ziva kuti kufonera `memory.as_mut()` hakutenderwe pano sezvo zvirimo zvingave zvisina kuvhurwa.
    /// # #[allow(unused_variables)]
    /// let slice: &mut [MaybeUninit<u8>] = unsafe { memory.as_uninit_slice_mut() };
    /// # Ok::<_, std::alloc::AllocError>(())
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut(&self) -> &mut [MaybeUninit<T>] {
        // KUCHENGETEKA: iye anodana anofanirwa kuchengetedza chibvumirano chekuchengetedza che `as_uninit_slice_mut`.
        unsafe { slice::from_raw_parts_mut(self.cast().as_ptr(), self.len()) }
    }

    /// Inodzosera pointer mbishi kune chinhu kana subslice, pasina kuita mabound kutarisa.
    ///
    /// Kufonera iyi nzira ine kunze-kwemiganhu index kana kana `self` isinga dereferencable iri *[isina kujekeswa maitiro]* kunyangwe iyo inoguma pointer isiri kushandiswa.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get, nonnull_slice_from_raw_parts)]
    /// use std::ptr::NonNull;
    ///
    /// let x = &mut [1, 2, 4];
    /// let x = NonNull::slice_from_raw_parts(NonNull::new(x.as_mut_ptr()).unwrap(), x.len());
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1).as_ptr(), x.as_non_null_ptr().as_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> NonNull<I::Output>
    where
        I: SliceIndex<[T]>,
    {
        // CHENGETEKO: anofona anoona kuti `self` haigadzirisike uye `index` iri-kumiganhu.
        // Nekuda kweizvozvo, iyo inonongedza pointer haigone kuve NULL.
        unsafe { NonNull::new_unchecked(self.as_ptr().get_unchecked_mut(index)) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Clone for NonNull<T> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Copy for NonNull<T> {}

#[unstable(feature = "coerce_unsized", issue = "27732")]
impl<T: ?Sized, U: ?Sized> CoerceUnsized<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<NonNull<U>> for NonNull<T> where T: Unsize<U> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Debug for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> fmt::Pointer for NonNull<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Pointer::fmt(&self.as_ptr(), f)
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Eq for NonNull<T> {}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialEq for NonNull<T> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        self.as_ptr() == other.as_ptr()
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> Ord for NonNull<T> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        self.as_ptr().cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> PartialOrd for NonNull<T> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.as_ptr().partial_cmp(&other.as_ptr())
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> hash::Hash for NonNull<T> {
    #[inline]
    fn hash<H: hash::Hasher>(&self, state: &mut H) {
        self.as_ptr().hash(state)
    }
}

#[unstable(feature = "ptr_internals", issue = "none")]
impl<T: ?Sized> From<Unique<T>> for NonNull<T> {
    #[inline]
    fn from(unique: Unique<T>) -> Self {
        // Kachengeteka: Chinhu chakasarudzika chinongedzo hachigone kuitika, saka mamiriro e
        // new_unchecked() vanokudzwa.
        unsafe { NonNull::new_unchecked(unique.as_ptr()) }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&mut T> for NonNull<T> {
    #[inline]
    fn from(reference: &mut T) -> Self {
        // Kachengeteka: Chirevo chinoshanduka hachigone kuitika.
        unsafe { NonNull { pointer: reference as *mut T } }
    }
}

#[stable(feature = "nonnull", since = "1.25.0")]
impl<T: ?Sized> From<&T> for NonNull<T> {
    #[inline]
    fn from(reference: &T) -> Self {
        // Kachengeteka: Referenzi haigone kuve isina basa, saka mamiriro e
        // new_unchecked() vanokudzwa.
        unsafe { NonNull { pointer: reference as *const T } }
    }
}