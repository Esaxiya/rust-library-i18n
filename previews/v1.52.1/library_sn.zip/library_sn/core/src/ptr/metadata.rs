#![unstable(feature = "ptr_metadata", issue = "81513")]

use crate::fmt;
use crate::hash::{Hash, Hasher};

/// Inopa iyo pointer metadata mhando yeipi yakanongedzwa-kutaipa.
///
/// # Pointer metadata
///
/// Mhando dzakasarudzika dzemhando uye mhando dzemhando mu Rust dzinogona kufungidzirwa seyakagadzirwa nezvikamu zviviri:
/// pointer yedata ine kero yekurangarira yeiyo kukosha, uye imwe metadata.
///
/// Yemhando dzakakura-zvishoma (dzinoshandisa iyo `Sized` traits) pamwe nemhando dze `extern`, zvinongedzo zvinonzi "zvakaonda": metadata ine zero-saizi uye mhando yayo i `()`.
///
///
/// Anonongedzera ku [dynamically-sized types][dst] anonzi "akapamhamha" kana "mafuta", ane isina-zero-saizi metadata:
///
/// * Kune structs iyo yekupedzisira munda iri DST, metadata ndiyo metadata yemunda wekupedzisira
/// * Yezve `str` mhando, metadata ndeyehurefu mumabheti se `usize`
/// * Kune slice mhando senge `[T]`, metadata ndeyehurefu muzvinhu se `usize`
/// * Zve trait zvinhu zvakaita se `dyn SomeTrait`, metadata ndeye [`DynMetadata<Self>`][DynMetadata] (semuenzaniso `DynMetadata<dyn SomeTrait>`)
///
/// Mu future, mutauro we Rust unogona kuwana mhando nyowani dzemhando dzine akasiyana pointer metadata.
///
/// [dst]: https://doc.rust-lang.org/nomicon/exotic-sizes.html#dynamically-sized-types-dsts
///
/// # Iyo `Pointee` trait
///
/// Iyo poindi yeiyi trait iri yayo `Metadata` inosanganisirwa mhando, inova `()` kana `usize` kana `DynMetadata<_>` sezvakatsanangurwa pamusoro.
/// Inoitwa otomatiki kune ese marudzi.
/// Iyo inogona kufungidzirwa kuti iitwe mune yakajairwa mamiriro, kunyangwe isina inoenderana yakasungwa.
///
/// # Usage
///
/// Anonongedzera anonongedzera anogona akaora mukati kero yedata uye metadata zvinhu nenzira yavo [`to_raw_parts`] nzira.
///
/// Neimwe nzira, metadata chete inogona kubviswa neiyo [`metadata`] basa.
/// Chirevo chinogona kupfuudzwa ku [`metadata`] uye kumanikidzwa zvachose.
///
/// Iyo (possibly-wide) pointer inogona kudzoserwa pamwechete kubva kukero yayo uye metadata ine [`from_raw_parts`] kana [`from_raw_parts_mut`].
///
/// [`to_raw_parts`]: *const::to_raw_parts
///
///
///
///
///
///
///
///
///
#[lang = "pointee_trait"]
pub trait Pointee {
    /// Rudzi rwemetadata mune zvinongedzo uye mareferenzi ku `Self`.
    #[lang = "metadata_type"]
    // NOTE: Chengeta trait bound mu `static_assert_expected_bounds_for_metadata`
    //
    // mu `library/core/src/ptr/metadata.rs` muchienderana neavo vari pano:
    type Metadata: Copy + Send + Sync + Ord + Hash + Unpin;
}

/// Anonongedzera kumhando dzekushandisa iyi trait alias "akaonda".
///
/// Izvi zvinosanganisira zvemhando-`Sized` mhando uye `extern` mhando.
///
/// # Example
///
/// ```rust
/// #![feature(ptr_metadata)]
///
/// fn this_never_panics<T: std::ptr::Thin>() {
///     assert_eq!(std::mem::size_of::<&T>(), std::mem::size_of::<usize>())
/// }
/// ```
#[unstable(feature = "ptr_metadata", issue = "81513")]
// NOTE: usadzikamisa izvi pamberi pe trait aliases asati agadzikana mumutauro?
pub trait Thin = Pointee<Metadata = ()>;

/// Bvisa iyo metadata chinhu cheichi pointer.
///
/// Maitiro erudzi `*mut T`, `&T`, kana `&mut T` anogona kupfuudzwa akananga kune iri basa sezvo ivo vachimanikidza zvachose ku `* const T`.
///
///
/// # Example
///
/// ```
/// #![feature(ptr_metadata)]
///
/// assert_eq!(std::ptr::metadata("foo"), 3_usize);
/// ```
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn metadata<T: ?Sized>(ptr: *const T) -> <T as Pointee>::Metadata {
    // Kachengeteka: Kuwana iyo kukosha kubva ku `PtrRepr` mubatanidzwa kwakachengeteka sezvo * const T
    // uye PtrComponents<T>vane akafanana ndangariro marongero.
    // std chete ndiyo inogona kuita vimbiso iyi.
    unsafe { PtrRepr { const_ptr: ptr }.components.metadata }
}

/// Inogadzira (possibly-wide) mbichana pointer kubva kukero yedata uye metadata.
///
/// Iri basa rakachengeteka asi iyo yakadzoserwa pointer haina hazvo kuchengeteka kuti isaratidzwe.
/// Kune zvidimbu, ona zvinyorwa zve [`slice::from_raw_parts`] yezvekuchengetedza zvinodiwa.
/// Zve trait zvinhu, iyo metadata inofanirwa kubva kunongedzera kune imwechete yepasi yakaderedzwa mhando.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts<T: ?Sized>(
    data_address: *const (),
    metadata: <T as Pointee>::Metadata,
) -> *const T {
    // Kachengeteka: Kuwana iyo kukosha kubva ku `PtrRepr` mubatanidzwa kwakachengeteka sezvo * const T
    // uye PtrComponents<T>vane akafanana ndangariro marongero.
    // std chete ndiyo inogona kuita vimbiso iyi.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.const_ptr }
}

/// Inoita mashandiro akafanana ne [`from_raw_parts`], kunze kwekunge mbishi `*mut` yakadzorerwa, zvichipesana neyeyakajeka `* const` pointer.
///
///
/// Ona zvinyorwa zve [`from_raw_parts`] kuti uwane rumwe ruzivo.
#[unstable(feature = "ptr_metadata", issue = "81513")]
#[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
#[inline]
pub const fn from_raw_parts_mut<T: ?Sized>(
    data_address: *mut (),
    metadata: <T as Pointee>::Metadata,
) -> *mut T {
    // Kachengeteka: Kuwana iyo kukosha kubva ku `PtrRepr` mubatanidzwa kwakachengeteka sezvo * const T
    // uye PtrComponents<T>vane akafanana ndangariro marongero.
    // std chete ndiyo inogona kuita vimbiso iyi.
    unsafe { PtrRepr { components: PtrComponents { data_address, metadata } }.mut_ptr }
}

#[repr(C)]
pub(crate) union PtrRepr<T: ?Sized> {
    pub(crate) const_ptr: *const T,
    pub(crate) mut_ptr: *mut T,
    pub(crate) components: PtrComponents<T>,
}

#[repr(C)]
pub(crate) struct PtrComponents<T: ?Sized> {
    pub(crate) data_address: *const (),
    pub(crate) metadata: <T as Pointee>::Metadata,
}

// Manual impl inodiwa kudzivirira `T: Copy` yakasungwa.
impl<T: ?Sized> Copy for PtrComponents<T> {}

// Manual impl inodiwa kudzivirira `T: Clone` yakasungwa.
impl<T: ?Sized> Clone for PtrComponents<T> {
    fn clone(&self) -> Self {
        *self
    }
}

/// Iyo metadata ye `Dyn = dyn SomeTrait` trait chinhu cherudzi.
///
/// Iyo inongedzera kune vtable (chaiyo yekufona tafura) inomiririra ruzivo rwese rwunodiwa kuti utore mhando yekongiri yakachengetwa mukati me trait chinhu.
/// Iyo vtable inoshamisa iine:
///
/// * saizi yemhando
/// * mhando yekumira
/// * chinongedzo kune yerudzi rwe `drop_in_place` impl (inogona kunge isiri-op yeakajeka-yekare-data)
/// * inonongedzera kune dzese nzira dzekumisikidza kwerudzi rwe trait
///
/// Ziva kuti matatu ekutanga akakosha nekuti iwo anodikanwa kugovera, kudonhedza, uye kuendesa chero chinhu che trait.
///
/// Izvo zvinokwanisika kutumidza ichi chimiro ine mhando paramende isiri `dyn` trait chinhu (semuenzaniso `DynMetadata<u64>`) asi kwete kuti uwane kukosha kunokosha kwechimiro ichocho.
///
///
///
///
#[lang = "dyn_metadata"]
pub struct DynMetadata<Dyn: ?Sized> {
    vtable_ptr: &'static VTable,
    phantom: crate::marker::PhantomData<Dyn>,
}

/// Chirevo chekutanga chevtable ese.Inoteverwa nezviratidzo zvekushanda zve trait nzira.
///
/// Yakavanzika yekumisikidza ruzivo rwe `DynMetadata::size_of` nezvimwe.
#[repr(C)]
struct VTable {
    drop_in_place: fn(*mut ()),
    size_of: usize,
    align_of: usize,
}

impl<Dyn: ?Sized> DynMetadata<Dyn> {
    /// Inodzorera saizi yerudzi rwakabatana neiyi vtable.
    #[inline]
    pub fn size_of(self) -> usize {
        self.vtable_ptr.size_of
    }

    /// Inodzorera kuenderana kwerudzi rwakabatana neiyi vtable.
    #[inline]
    pub fn align_of(self) -> usize {
        self.vtable_ptr.align_of
    }

    /// Inodzorera saizi uye kuenderana pamwe chete se `Layout`
    #[inline]
    pub fn layout(self) -> crate::alloc::Layout {
        // Kachengeteka: iyo compiler yakaburitsa iyi vtable yekongiri Rust mhando iyo
        // inozivikanwa kuva nemamiriro akarongeka.Pfungwa imwechete seye `Layout::for_value`.
        unsafe { crate::alloc::Layout::from_size_align_unchecked(self.size_of(), self.align_of()) }
    }
}

unsafe impl<Dyn: ?Sized> Send for DynMetadata<Dyn> {}
unsafe impl<Dyn: ?Sized> Sync for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> fmt::Debug for DynMetadata<Dyn> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("DynMetadata").field(&(self.vtable_ptr as *const VTable)).finish()
    }
}

// Manual impls inodiwa kudzivirira `Dyn: $Trait` miganho.

impl<Dyn: ?Sized> Unpin for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Copy for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> Clone for DynMetadata<Dyn> {
    #[inline]
    fn clone(&self) -> Self {
        *self
    }
}

impl<Dyn: ?Sized> Eq for DynMetadata<Dyn> {}

impl<Dyn: ?Sized> PartialEq for DynMetadata<Dyn> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        crate::ptr::eq::<VTable>(self.vtable_ptr, other.vtable_ptr)
    }
}

impl<Dyn: ?Sized> Ord for DynMetadata<Dyn> {
    #[inline]
    fn cmp(&self, other: &Self) -> crate::cmp::Ordering {
        (self.vtable_ptr as *const VTable).cmp(&(other.vtable_ptr as *const VTable))
    }
}

impl<Dyn: ?Sized> PartialOrd for DynMetadata<Dyn> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<crate::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

impl<Dyn: ?Sized> Hash for DynMetadata<Dyn> {
    #[inline]
    fn hash<H: Hasher>(&self, hasher: &mut H) {
        crate::ptr::hash::<VTable, _>(self.vtable_ptr, hasher)
    }
}