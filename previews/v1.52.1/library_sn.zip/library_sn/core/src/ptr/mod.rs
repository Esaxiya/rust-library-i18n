//! Nemaoko gadzirisa ndangariro kuburikidza nemataipi mbishi.
//!
//! *[See also the pointer primitive types](pointer).*
//!
//! # Safety
//!
//! Mabasa mazhinji mumutsetse uyu anotora anonongedzera mbishi sekupokana uye kuverenga kubva kana kunyorera kwavari.Kuti izvi zvive zvakachengeteka, izvi zvinongedzo zvinofanirwa kuve *zvinoshanda*.
//! Kunyangwe chinongedzo chiri chechokwadi zvinoenderana nekushanda kwachinoshandiswa (kuverenga kana kunyora), uye kukura kwendangariro kunowanikwa (kureva kuti, mangani mabheti ari read/written).
//! Mabasa mazhinji anoshandisa `*mut T` uye `* const T` kuwana chete kukosha kumwe chete, mune izvozvi magwaro anosiya saizi uye achifungidzira kuti i `size_of::<T>()` mabheti.
//!
//! Iyo chaiyo mitemo yechokwadi haina kutemerwa parizvino.Iko kuvimbiswa kunopihwa panguva ino kwakanyanya kushoma:
//!
//! * Iyo [null] pointer haina *kumbobvira* inoshanda, kunyangwe yekuwana kwe [size zero][zst].
//! * Kuti chinongedzo chishande, zvinodikanwa, asi kwete nguva dzose zvakakwana, kuti chinongedzo chive *chisingarondedzerwe*: ndangariro renji yehukuru hwakapihwa hunotangira pa pointer hunofanirwa kuve hwese mukati memiganhu yechinhu chimwe chakapihwa.
//!
//! Ziva kuti mu Rust, yega (stack-allocated) musiyano inoonekwa sechinhu chakaparadzaniswa chakapihwa.
//! * Kunyangwe mashandiro e [size zero][zst], iyo pointer haifanire kunge ichinongedzera kune yakadzoserwa ndangariro, kureva., Dhirivhari inoita kuti anonongedzera asashande kunyangwe kune zero-saizi mashandiro.
//! Nekudaro, kukanda chero isiri zero zero manhamba *chaiyo* kune chinongedzo chinoshanda kune zero-saizi yekuwana, kunyangwe kana imwe ndangariro ikaitika kuvepo pakero iyoyo uye inotorwa.
//! Izvi zvinoenderana nekunyorera iwe wega mugove: kugovera zero-saizi zvinhu hazvina kunyanya kuoma.
//! Iyo canonical nzira yekuwana pointer iyo inoshanda kune zero-saizi yekuwana ndeye [`NonNull::dangling`].
//! * Zvese zvinowanikwa zvinoitwa nemabasa mune ino module nde *non-atomic* mupfungwa ye [atomic operations] inoshandiswa kuwiriranisa pakati petambo.
//! Izvi zvinoreva kuti haina kujekeswa maitiro ekuita maviri akafanana kusangana kune imwecheteyo nzvimbo kubva kune dzakasiyana tambo kunze kwekunge vaviri vanowana chete kuverenga kubva mundangariro.
//! Cherekedza kuti izvi zvakajeka zvinosanganisira [`read_volatile`] uye [`write_volatile`]: Kupindirana kwakasarudzika hakugone kushandiswa mukubatanidza-tambo kuwiriranisa.
//! * Mhedzisiro yekukanda chirevo kuchinongedzo inoshanda chero bedzi chinhu chiri pasi chiri kurarama uye pasina chirevo (anongonongedzera mbishi) anoshandiswa kuwana ndangariro imwechete.
//!
//! Aya maaxoms, pamwe nekushandisa zvine hungwaru kwe [`offset`] ye pointer arithmetic, zvinokwana kuita nemazvo zvinhu zvakawanda zvinobatsira mukodhi isina kuchengetedzeka.
//! Yakasimba vimbiso ichave inozopihwa pakupedzisira, sezvo iyo [aliasing] mitemo iri kuiswa.
//! Kuti uwane rumwe ruzivo, ona iyo [book] pamwe nechikamu chiri mune chirevo chakapihwa [undefined behavior][ub].
//!
//! ## Alignment
//!
//! Anoshanda mbichana mapoinzi sekutsanangurwa pamusoro hazvidi kuti zvinyatsoenderana (iko "proper" kuenderana kunotsanangurwa nerudzi rwepa poee, kureva, `*const T` inofanirwa kuenderana ne `mem::align_of::<T>()`).
//! Nekudaro, mabasa mazhinji anoda kuti nharo dzadzo dziwirirane zvakanaka, uye zvichanyatso buda izvi zvinodiwa mumagwaro avo.
//! Zvinosarudzika kusarudzika kune izvi i [`read_unaligned`] uye [`write_unaligned`].
//!
//! Kana basa richida kuenderana kwakaringana, rinozviita kunyangwe iko kuwana kwacho kune saizi 0, kureva, kunyangwe kana memory isina kunyatso kubatwa.Funga kushandisa [`NonNull::dangling`] muzviitiko zvakadaro.
//!
//! [aliasing]: ../../nomicon/aliasing.html
//! [book]: ../../book/ch19-01-unsafe-rust.html#dereferencing-a-raw-pointer
//! [ub]: ../../reference/behavior-considered-undefined.html
//! [zst]: ../../nomicon/exotic-sizes.html#zero-sized-types-zsts
//! [atomic operations]: crate::sync::atomic
//! [`offset`]: pointer::offset
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cmp::Ordering;
use crate::fmt;
use crate::hash;
use crate::intrinsics::{self, abort, is_aligned_and_not_null};
use crate::mem::{self, MaybeUninit};

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy_nonoverlapping;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::copy;

#[stable(feature = "rust1", since = "1.0.0")]
#[doc(inline)]
pub use crate::intrinsics::write_bytes;

#[cfg(not(bootstrap))]
mod metadata;
#[cfg(not(bootstrap))]
pub(crate) use metadata::PtrRepr;
#[cfg(not(bootstrap))]
#[unstable(feature = "ptr_metadata", issue = "81513")]
pub use metadata::{from_raw_parts, from_raw_parts_mut, metadata, DynMetadata, Pointee, Thin};

mod non_null;
#[stable(feature = "nonnull", since = "1.25.0")]
pub use non_null::NonNull;

mod unique;
#[unstable(feature = "ptr_internals", issue = "none")]
pub use unique::Unique;

mod const_ptr;
mod mut_ptr;

/// Inoita muparadzi (kana paine) yeinongedzwa-kukosha.
///
/// Izvi zvakaenzana zvakafanana nekudana [`ptr::read`] uye kurasa mhedzisiro, asi ine zvinotevera zvinotevera.
///
/// * Izvo *zvinodikanwa* kushandisa `drop_in_place` kudonhedza mhando dzisiri saizi senge trait zvinhu, nekuti hazvigone kuverengerwa mudura uye kudonhedzwa zvakajairika.
///
/// * Izvo zvine hushamwari kune optimizer yekuita izvi pamusoro pe [`ptr::read`] kana uchidonhedza manyore akagoverwa ndangariro (semuenzaniso, mukuitwa kwe `Box`/`Rc`/`Vec`), sezvo muunganidzi asingadi kuratidza kuti zvine mutsindo kuti agare kopi.
///
///
/// * Inogona kushandiswa kudonhedza [pinned] data kana `T` isiri `repr(packed)` (yakanyorwa data haifanire kufambiswa isati yadonhedzwa).
///
/// Maitiro asina kukamurwa haakwanise kudonhedzwa munzvimbo, anofanirwa kuteedzerwa kunzvimbo inoenderana kutanga atanga kushandisa [`ptr::read_unaligned`].Kune akarongedzwa structs, kufamba uku kunoitwa otomatiki nemunyori.
/// Izvi zvinoreva kuti iyo minda yenzvimbo dzakazara haina kudonhedzwa-munzvimbo.
///
/// [`ptr::read`]: self::read
/// [`ptr::read_unaligned`]: self::read_unaligned
/// [pinned]: crate::pin
///
/// # Safety
///
/// Maitiro haana kujekeswa kana chero eanotevera mamiriro akatyorwa:
///
/// * `to_drop` inofanirwa kunge iri [valid] kune ese ari maviri anoverenga uye anonyora.
///
/// * `to_drop` inofanira kunge yakanyatsoenderana.
///
/// * Iko kukosha `to_drop` kunongedzera kuve kunofanirwa kuve kudonhedza, izvo zvinogona kureva kuti inofanirwa kutsigira zvinowedzera zvinowedzera, izvi zvine mhando-zvinoenderana.
///
/// Pamusoro pezvo, kana `T` isiri [`Copy`], kushandisa yakanongedzwa-kukosha mushure mekufona `drop_in_place` kunogona kukonzera undefined maitiro.Ziva kuti `*to_drop = foo` kuverenga sekushandisa nekuti zvinokonzeresa kuti kukosha kudonhedzwe zvakare.
/// [`write()`] inogona kushandiswa kunyora data pasina kuita kuti idonhedzwe.
///
/// Ziva kuti kunyangwe `T` ine saizi `0`, iyo pointer inofanirwa kunge isiri-NULL uye yakanyatsoenderana.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Nemaoko bvisa chinhu chekupedzisira kubva ku vector:
///
/// ```
/// use std::ptr;
/// use std::rc::Rc;
///
/// let last = Rc::new(1);
/// let weak = Rc::downgrade(&last);
///
/// let mut v = vec![Rc::new(0), last];
///
/// unsafe {
///     // Tora pointer mbishi kune yekupedzisira chinhu mu `v`.
///     let ptr = &mut v[1] as *mut _;
///     // Pfupisa `v` kudzivirira chinhu chekupedzisira kuti chisadonhedzwe.
///     // Isu tinoita izvozvo kutanga, kudzivirira nyaya kana iyo `drop_in_place` pazasi pe panics.
///     v.set_len(1);
///     // Pasina kufona `drop_in_place`, chinhu chekupedzisira hachizombofa chakadonhedzwa, uye ndangariro yainotarisira yaizoburitswa.
/////
///     ptr::drop_in_place(ptr);
/// }
///
/// assert_eq!(v, &[0.into()]);
///
/// // Onai kuti chinhu chekupedzisira chadonhedzwa.
/// assert!(weak.upgrade().is_none());
/// ```
///
/// Cherekedza kuti mugadziri anoita kopi iyi otomatiki kana achidonhedza struct dzakazara, kureva, haufanire kunetsekana nenyaya dzakadai kunze kwekunge wafonera `drop_in_place` nemaoko.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "drop_in_place", since = "1.8.0")]
#[lang = "drop_in_place"]
#[allow(unconditional_recursion)]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Code apa haina basa, izvi zvinotsiviwa neicho chaicho chinodonhedza neyakaunganidzwa.
    //

    // Kachengeteka: ona chirevo pamusoro
    unsafe { drop_in_place(to_drop) }
}

/// Inogadzira isina chinhu mbichana pointer.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *const i32 = ptr::null();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null<T>() -> *const T {
    0 as *const T
}

/// Inogadzira null inogona kuchinjika mbishi pointer.
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let p: *mut i32 = ptr::null_mut();
/// assert!(p.is_null());
/// ```
#[inline(always)]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_promotable]
#[rustc_const_stable(feature = "const_ptr_null", since = "1.32.0")]
pub const fn null_mut<T>() -> *mut T {
    0 as *mut T
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) union Repr<T> {
    pub(crate) rust: *const [T],
    rust_mut: *mut [T],
    pub(crate) raw: FatPtr<T>,
}

#[cfg(bootstrap)]
#[repr(C)]
pub(crate) struct FatPtr<T> {
    data: *const T,
    pub(crate) len: usize,
}

#[cfg(bootstrap)]
// Manual impl inodiwa kudzivirira `T: Clone` yakasungwa.
impl<T> Clone for FatPtr<T> {
    fn clone(&self) -> Self {
        *self
    }
}

#[cfg(bootstrap)]
// Manual impl inodiwa kudzivirira `T: Copy` yakasungwa.
impl<T> Copy for FatPtr<T> {}

/// Inoita chidimbu chisina kubikwa kubva kunongedzera uye kureba.
///
/// Iyo `len` nharo ndiyo nhamba ye **zvinhu**, kwete iyo nhamba yemabheti.
///
/// Iri basa rakachengeteka, asi kushandisa kukosha kwekudzoka hakuna kuchengeteka.
/// Ona zvinyorwa zve [`slice::from_raw_parts`] yezvidimbu zvekuchengetedza zvidimbu.
///
/// [`slice::from_raw_parts`]: crate::slice::from_raw_parts
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// // gadzira chidimbu chechidimbu kana uchitanga nechinongedzo kuchinhu chekutanga
/// let x = [5, 6, 7];
/// let raw_pointer = x.as_ptr();
/// let slice = ptr::slice_from_raw_parts(raw_pointer, 3);
/// assert_eq!(unsafe { &*slice }[2], 7);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts<T>(data: *const T, len: usize) -> *const [T] {
    #[cfg(bootstrap)]
    {
        // Kachengeteka: Kuwana iyo kukosha kubva ku `Repr` mubatanidzwa kwakachengeteka sezvo * const [T]
        //
        // uye FatPtr vane zvakafanana ndondo marongero.std chete ndiyo inogona kuita vimbiso iyi.
        unsafe { Repr { raw: FatPtr { data, len } }.rust }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts(data.cast(), len)
}

/// Inoita mashandiro akafanana ne [`slice_from_raw_parts`], kunze kwekuti chidimbu chisingachinjiki chinodzoserwa, zvichipesana nechakatsvuka chisina kuchinjika.
///
///
/// Ona zvinyorwa zve [`slice_from_raw_parts`] kuti uwane rumwe ruzivo.
///
/// Iri basa rakachengeteka, asi kushandisa kukosha kwekudzoka hakuna kuchengeteka.
/// Ona zvinyorwa zve [`slice::from_raw_parts_mut`] yezvidimbu zvekuchengetedza zvidimbu.
///
/// [`slice::from_raw_parts_mut`]: crate::slice::from_raw_parts_mut
///
/// # Examples
///
/// ```rust
/// use std::ptr;
///
/// let x = &mut [5, 6, 7];
/// let raw_pointer = x.as_mut_ptr();
/// let slice = ptr::slice_from_raw_parts_mut(raw_pointer, 3);
///
/// unsafe {
///     (*slice)[2] = 99; // ipa kukosha pane indekisi muchidimbu
/// };
///
/// assert_eq!(unsafe { &*slice }[2], 99);
/// ```
#[inline]
#[stable(feature = "slice_from_raw_parts", since = "1.42.0")]
#[rustc_const_unstable(feature = "const_slice_from_raw_parts", issue = "67456")]
pub const fn slice_from_raw_parts_mut<T>(data: *mut T, len: usize) -> *mut [T] {
    #[cfg(bootstrap)]
    {
        // Kachengeteka: Kuwana iyo kukosha kubva ku `Repr` mubatanidzwa kwakachengeteka kubva * mut [T]
        // uye FatPtr vane zvakafanana ndondo marongero
        unsafe { Repr { raw: FatPtr { data, len } }.rust_mut }
    }
    #[cfg(not(bootstrap))]
    from_raw_parts_mut(data.cast(), len)
}

/// Inochinjisa iwo maitiro munzvimbo mbiri dzinogona kuchinjika dzerudzi rumwe chete, pasina kudzikisira chero.
///
/// Asi kune maviri anotevera kunze, iri basa rakaenzana ne [`mem::swap`]:
///
///
/// * Inoshanda pane mapoinzi mapoinzi pane mareferenzi.
/// Kana mareferenzi aripo, [`mem::swap`] inofanira kusarudzwa.
///
/// * Iwo maviri akanongedzera-kumaitiro anogona kupfuura.
/// Kana tsika dzikapindana, ipapo nzvimbo inopindirana yekurangarira kubva ku `x` ichashandiswa.
/// Izvi zvinoratidzwa mune yechipiri muenzaniso pazasi.
///
/// # Safety
///
/// Maitiro haana kujekeswa kana chero eanotevera mamiriro akatyorwa:
///
/// * Ose ari maviri `x` uye `y` anofanira kunge ari [valid] kune ese ari maviri anoverenga uye anonyora.
///
/// * Ose ari maviri `x` uye `y` anofanirwa kuenderana zvakanaka.
///
/// Ziva kuti kunyangwe `T` ine saizi `0`, anonongedzera anofanirwa kunge asiri-NULL uye akanyatsoenderana.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Kuchinja matunhu maviri asina-kuwanda:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 2]; // iyi i `array[0..2]`
/// let y = array[2..].as_mut_ptr() as *mut [u32; 2]; // iyi i `array[2..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     assert_eq!([2, 3, 0, 1], array);
/// }
/// ```
///
/// Kuchinja matunhu maviri akapindirana:
///
/// ```
/// use std::ptr;
///
/// let mut array = [0, 1, 2, 3];
///
/// let x = array[0..].as_mut_ptr() as *mut [u32; 3]; // iyi i `array[0..3]`
/// let y = array[1..].as_mut_ptr() as *mut [u32; 3]; // iyi i `array[1..4]`
///
/// unsafe {
///     ptr::swap(x, y);
///     // Iyo indices `1..3` yechidimbu inopindirana pakati pe `x` ne `y`.
///     // Mhedzisiro inonzwisisika ichave yavo kuva `[2, 3]`, kuitira kuti indices `0..3` i `[1, 2, 3]` (inoenderana `y` pamberi pe `swap`);kana kuti ivo vave `[0, 1]` kuitira kuti indices `1..4` i `[0, 1, 2]` (inoenderana `x` pamberi pe `swap`).
/////
///     // Uku kuita kunotsanangurwa kuita sarudzo yekupedzisira.
/////
///     assert_eq!([1, 0, 1, 2], array);
/// }
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap<T>(x: *mut T, y: *mut T) {
    // Zvipe pachedu imwe nzvimbo yekushandira nayo.
    // Hatifanirwe kunetseka nezve madonhwe: `MaybeUninit` haina zvainoita kana yadonhedzwa.
    let mut tmp = MaybeUninit::<T>::uninit();

    // Ita chinja KUSHURE: iye anofona anofanira kuvimbisa kuti `x` ne `y` zvinoshanda pakunyora uye zvakanyatsoenderana.
    // `tmp` haigone kuvhurika chero `x` kana `y` nekuti `tmp` yakangogoverwa pane stack sechinhu chakaparadzaniswa chakapihwa.
    //
    //
    //
    unsafe {
        copy_nonoverlapping(x, tmp.as_mut_ptr(), 1);
        copy(y, x, 1); // `x` uye `y` inogona kuwanda
        copy_nonoverlapping(tmp.as_ptr(), y, 1);
    }
}

/// Inochinja `count * size_of::<T>()` mabheti pakati pematunhu maviri ekurangarira anotangira pa `x` ne `y`.
/// Matunhu maviri aya haafanire kupindirana.
///
/// # Safety
///
/// Maitiro haana kujekeswa kana chero eanotevera mamiriro akatyorwa:
///
/// * Ose ari maviri `x` uye `y` anofanirwa kuve [valid] kune ese ari maviri kuverenga uye anonyora nezve` count *
///   saizi_ye: :<T>() `byte.
///
/// * Ose ari maviri `x` uye `y` anofanirwa kuenderana zvakanaka.
///
/// * Iyo nzvimbo yekurangarira inotangira pa `x` ine saizi ye` count *
///   saizi_ye: :<T>() `byte haifanire * kupindirana nedunhu rekurangarira kutanga pa `y` nehukuru hwakaenzana.
///
/// Ziva kuti kunyangwe kana saizi yakanyatsoteedzerwa (`count * size_of: :<T>()`) iri `0`, zvinongedzo zvinofanirwa kunge zvisina-NULL uye zvakanyatsoenderana.
///
///
/// [valid]: self#safety
///
/// # Examples
///
/// Kushandiswa kwekutanga:
///
/// ```
/// use std::ptr;
///
/// let mut x = [1, 2, 3, 4];
/// let mut y = [7, 8, 9];
///
/// unsafe {
///     ptr::swap_nonoverlapping(x.as_mut_ptr(), y.as_mut_ptr(), 2);
/// }
///
/// assert_eq!(x, [7, 8, 3, 4]);
/// assert_eq!(y, [1, 2, 9]);
/// ```
///
#[inline]
#[stable(feature = "swap_nonoverlapping", since = "1.27.0")]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
pub const unsafe fn swap_nonoverlapping<T>(x: *mut T, y: *mut T, count: usize) {
    let x = x as *mut u8;
    let y = y as *mut u8;
    let len = mem::size_of::<T>() * count;
    // KUCHENGETEKA: iye anofona anofanira kuvimbisa kuti `x` ne `y` vari
    // inoshanda kunyora uye kunyatsoenderana.
    unsafe { swap_nonoverlapping_bytes(x, y, len) }
}

#[inline]
pub(crate) unsafe fn swap_nonoverlapping_one<T>(x: *mut T, y: *mut T) {
    // Yemhando diki pane iyo block optimization pazasi, ingo chinja zvakananga kudzivirira kusagadzikana codegen.
    //
    if mem::size_of::<T>() < 32 {
        // Kachengeteka: iye anodana anofanira kuvimbisa kuti `x` uye `y` ndezvechokwadi
        // for inonyora, yakanyatsoenderana, uye isiri-kupindirana.
        unsafe {
            let z = read(x);
            copy_nonoverlapping(y, x, 1);
            write(y, z);
        }
    } else {
        // KUCHENGETEKA: iye anodana anofanirwa kuchengetedza chibvumirano chekuchengetedza che `swap_nonoverlapping`.
        unsafe { swap_nonoverlapping(x, y, 1) };
    }
}

#[inline]
#[rustc_const_unstable(feature = "const_swap", issue = "83163")]
const unsafe fn swap_nonoverlapping_bytes(x: *mut u8, y: *mut u8, len: usize) {
    // Maitiro pano ndee kushandisa simd kuchinjanisa x&y zvinobudirira.
    // Kuedzwa kunoratidza kuti kuchinjisa chero makumi matatu nemaviri mabheti kana makumi matanhatu nematanhatu panguva kunonyanya kushanda kune Intel Haswell E processor.
    // LLVM inokwanisa kuwedzera kana tikapa fomati #[repr(simd)], kunyangwe isu tisinganyatso shandisa ichi chimiro zvakananga.
    //
    //
    // FIXME repr(simd) yakaputsika pane emscripten uye redox
    #[cfg_attr(not(any(target_os = "emscripten", target_os = "redox")), repr(simd))]
    struct Block(u64, u64, u64, u64);
    struct UnalignedBlock(u64, u64, u64, u64);

    let block_size = mem::size_of::<Block>();

    // Loop kuburikidza x&y, kuteedzera iwo `Block` panguva iyo Iyo optimizer inofanira kubhedhenura chiuno zvizere kune mazhinji marudzi NB
    // Hatigone kushandisa chiuno sezvo `range` impl inodaidza `mem::swap` ichidzokororazve
    //
    let mut i = 0;
    while i + block_size <= len {
        // Gadzira imwe isina kuvhurwa ndangariro sekukanda nzvimbo Kuzivisa `t` pano inodzivirira kuenzanisa stack kana chiuno ichi chisingashandiswe
        //
        let mut t = mem::MaybeUninit::<Block>::uninit();
        let t = t.as_mut_ptr() as *mut u8;

        // KUCHENGETEKA: Sezvo `i < len`, uye semunhu afona anofanira kuvimbisa kuti `x` ne `y` zvinoshanda
        // ye `len` byte, `x + i` uye `y + i` inofanirwa kunge iri kero dzechokwadi, dzinozadzisa chibvumirano chekuchengetedza che `add`.
        //
        // Zvakare, ari kufona anofanirwa kuvimbisa kuti `x` ne `y` zvinoshanda pakunyora, zvakanyatsoenderana, uye kusapindirana, zvinozadzisa chibvumirano chekuchengetedza che `copy_nonoverlapping`.
        //
        //
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            // Chinja bhuroketi remabheti e x&y, uchishandisa t sechigunzva chenguva pfupi Izvi zvinofanirwa kuve zvakagadziriswa kuita inoshanda SIMD mashandiro panowanikwa
            //
            copy_nonoverlapping(x, t, block_size);
            copy_nonoverlapping(y, x, block_size);
            copy_nonoverlapping(t, y, block_size);
        }
        i += block_size;
    }

    if i < len {
        // Chinja chero mabheti asara
        let mut t = mem::MaybeUninit::<UnalignedBlock>::uninit();
        let rem = len - i;

        let t = t.as_mut_ptr() as *mut u8;

        // Kachengeteka: ona yapfuura chengetedzo kutaura.
        unsafe {
            let x = x.add(i);
            let y = y.add(i);

            copy_nonoverlapping(x, t, rem);
            copy_nonoverlapping(y, x, rem);
            copy_nonoverlapping(t, y, rem);
        }
    }
}

/// Inofambisa `src` muiyo yakanongedzwa `dst`, ichidzosa iyo yapfuura `dst` kukosha.
///
/// Hapana kukosha kwakadonhedzwa.
///
/// Iri basa rakaenzana semhando ne [`mem::replace`] kunze kwekuti rinoshanda pane anonongedzera mbichana pane mareferensi.
/// Kana mareferenzi aripo, [`mem::replace`] inofanira kusarudzwa.
///
/// # Safety
///
/// Maitiro haana kujekeswa kana chero eanotevera mamiriro akatyorwa:
///
/// * `dst` inofanirwa kunge iri [valid] kune ese ari maviri anoverenga uye anonyora.
///
/// * `dst` inofanira kunge yakanyatsoenderana.
///
/// * `dst` inofanirwa kunongedzera kukoshesiti yakatangwa zvakanaka yerudzi `T`.
///
/// Ziva kuti kunyangwe `T` ine saizi `0`, iyo pointer inofanirwa kunge isiri-NULL uye yakanyatsoenderana.
///
/// [valid]: self#safety
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let mut rust = vec!['b', 'u', 's', 't'];
///
/// // `mem::replace` ichave nemhedzisiro imwechete pasina kuda iyo isina kuchengetedzeka block.
/////
/// let b = unsafe {
///     ptr::replace(&mut rust[0], 'r')
/// };
///
/// assert_eq!(b, 'b');
/// assert_eq!(rust, &['r', 'u', 's', 't']);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn replace<T>(dst: *mut T, mut src: T) -> T {
    // Kachengeteka: iye anodana anofanira kuvimbisa kuti `dst` inoshanda kuva
    // kukanda kunongedzo inogona kuchinjika (inoshanda kunyora, kuenderana, kutanga), uye haigone kupfuura `src` sezvo `dst` inofanirwa kunongedzera kuchinhu chakapihwa chakasiyana.
    //
    //
    unsafe {
        mem::swap(&mut *dst, &mut src); // haigoni kuwirirana
    }
    src
}

/// Inoverenga kukosha kubva ku `src` pasina kuifambisa.Izvi zvinosiya ndangariro mu `src` isina kuchinjika.
///
/// # Safety
///
/// Maitiro haana kujekeswa kana chero eanotevera mamiriro akatyorwa:
///
/// * `src` inofanira kunge iri [valid] yekuverenga.
///
/// * `src` inofanira kunge yakanyatsoenderana.Shandisa [`read_unaligned`] kana zvisiri izvo.
///
/// * `src` inofanirwa kunongedzera kukoshesiti yakatangwa zvakanaka yerudzi `T`.
///
/// Ziva kuti kunyangwe `T` ine saizi `0`, iyo pointer inofanirwa kunge isiri-NULL uye yakanyatsoenderana.
///
/// # Examples
///
/// Kushandiswa kwekutanga:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Nemaoko shandisa [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Gadzira kopi isinganzwisisike yemutengo pa `a` mu `tmp`.
///         let tmp = ptr::read(a);
///
///         // Kubuda panguva ino (kungave nekudzoka zvakajeka kana kudana basa iro panics) raizoita kuti kukosha kwe `tmp` kudonhedzwe ukuwo kukosha kwakadaro kuchiri kutaurwa ne `a`.
///         // Izvi zvinogona kukonzera kusanzwisisika maitiro kana `T` isiri `Copy`.
/////
/////
///
///         // Gadzira kopi isinganzwisisike yemutengo pa `b` mu `a`.
///         // Izvi zvakachengeteka nekuti zvinoshandurwa zvinongedzo hazvigone alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Sezvo pamusoro, kubuda apa kunogona kukonzeresa kujekesa hunhu nekuti iwo iwo mutengo wakatarwa unotsanangurwa ne `a` uye `b`.
/////
///
///         // Fambisa `tmp` mu `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` yakatamiswa (`write` inotora muridzi wekupokana kwayo kwechipiri), saka hapana chakadonhedzwa zvachose pano.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
/// ## Kuva muridzi weiyo Yakadzoserwa Kukosha
///
/// `read` inogadzira kopi isinganzwisisike ye `T`, zvisinei kuti `T` i [`Copy`].
/// Kana `T` isiri [`Copy`], kushandisa zvese kukosha kwakadzoserwa uye kukosha pa `*src` kunogona kukanganisa kuchengetedzwa kwendangariro.
/// Ziva kuti kupa `*src` kuverenga sekushandisa nekuti ichaedza kudonhedza kukosha ku `* src`.
///
/// [`write()`] inogona kushandiswa kunyora data pasina kuita kuti idonhedzwe.
///
/// ```
/// use std::ptr;
///
/// let mut s = String::from("foo");
/// unsafe {
///     // `s2` ikozvino inonongedzera kune imwechete yepasi ndangariro se `s`.
///     let mut s2: String = ptr::read(&s);
///
///     assert_eq!(s2, "foo");
///
///     // Kugovera ku `s2` kunokonzera kukosha kwayo kwepakutanga kudonhedzwa.
///     // Beyond ino poindi, `s` haifanire kushandiswa, sekurangarira kwepasi kwasunungurwa.
/////
///     s2 = String::default();
///     assert_eq!(s2, "");
///
///     // Kugovera ku `s` kwaizokonzeresa kuti kukosha kwekare kudonhedzwe zvekare, zvichizogumira mune isina kujekeswa maitiro.
/////
///     // s= String::from("bar");//Kanganiso
///
///     // `ptr::write` inogona kushandiswa kunyora kukosha pasina kuisiya.
///     ptr::write(&mut s, String::from("bar"));
/// }
///
/// assert_eq!(s, "bar");
/// ```
///
/// [valid]: self#safety
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // Kachengeteka: iye anodana anofanira kuvimbisa kuti `src` inoshanda pakuverenga.
    // `src` haigone kupfuura `tmp` nekuti `tmp` yakangogoverwa pane stack sechinhu chakaparadzaniswa chakapihwa.
    //
    //
    // Zvakare, sezvo isu takangonyora kukosha kwakaringana mu `tmp`, zvinovimbiswa kuti zvinotangwa nemazvo.
    //
    unsafe {
        copy_nonoverlapping(src, tmp.as_mut_ptr(), 1);
        tmp.assume_init()
    }
}

/// Inoverenga kukosha kubva ku `src` pasina kuifambisa.Izvi zvinosiya ndangariro mu `src` isina kuchinjika.
///
/// Kusiyana ne [`read`], `read_unaligned` inoshanda nemasaini asina kuenderana.
///
/// # Safety
///
/// Maitiro haana kujekeswa kana chero eanotevera mamiriro akatyorwa:
///
/// * `src` inofanira kunge iri [valid] yekuverenga.
///
/// * `src` inofanirwa kunongedzera kukoshesiti yakatangwa zvakanaka yerudzi `T`.
///
/// Sa [`read`], `read_unaligned` inogadzira kopi ye `T`, kunyangwe `T` iri [`Copy`].
/// Kana `T` isiri [`Copy`], uchishandisa zvese kukosha kwakadzoserwa uye kukosha pa `*src` kunogona [violate memory safety][read-ownership].
///
/// Ziva kuti kunyangwe `T` ine saizi `0`, iyo pointer inofanirwa kunge isiri-NULL.
///
/// [read-ownership]: read#ownership-of-the-returned-value
/// [valid]: self#safety
///
/// ## Pa `packed` inodzika
///
/// Parizvino hazvigoneke kugadzira anonongedzera mbishi kune asina kuenderana minda yeyakaunganidzwa fomati.
///
/// Kuedza kugadzira pointer mbishi kune `unaligned` struct munda ine chirevo senge `&packed.unaligned as *const FieldType` inogadzira iripakati isina kugadzirirwa rejisiti usati washandura iyo kune yakasviba pointer.
///
/// Kuti chirevo ichi ndechechinguvana uye nekukasira kukosheswa hakukoshi sezvo muunganidzi achigara achitarisira kuti mareferenzi aenderane zvakanaka.
/// Nekuda kweizvozvo, kushandisa `&packed.unaligned as *const FieldType` kunokanganisa izvozvi* zvisina kujekesa maitiro * muchirongwa chako.
///
/// Muenzaniso wezvausingafanirwe kuita uye kuti izvi zvinowirirana sei ne `read_unaligned` ndeiyi:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let packed = Packed {
///     _padding: 0x00,
///     unaligned: 0x01020304,
/// };
///
/// let v = unsafe {
///     // Pano isu tinoedza kutora kero ye 32-bit manhamba isina kuenderana.
///     let unaligned =
///         // Chirevo chenguva pfupi chisina kusarudzika chakagadzirwa pano chinoguma nehunhu husina kujekeswa zvisinei nekuti chirevo chacho chinoshandiswa here kana kuti kwete.
/////
///         &packed.unaligned
///         // Kukanda kunongedzera mbishi hakubatsire;iko kukanganisa kwakatoitika.
///         as *const u32;
///
///     let v = std::ptr::read_unaligned(unaligned);
///
///     v
/// };
/// ```
///
/// Kuwana minda isina kukamurwa zvakananga ne eg `packed.unaligned` yakachengeteka zvakadaro.
///
///
///
///
///
///
// FIXME: Gadziridza maHTML zvichienderana nemhedzisiro yeRFC #2582 neshamwari.
/// # Examples
///
/// Verenga kukosha kweizeize kubva kubheti buffer:
///
/// ```
/// use std::mem;
///
/// fn read_usize(x: &[u8]) -> usize {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_ptr() as *const usize;
///
///     unsafe { ptr.read_unaligned() }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
pub const unsafe fn read_unaligned<T>(src: *const T) -> T {
    let mut tmp = MaybeUninit::<T>::uninit();
    // Kachengeteka: iye anodana anofanira kuvimbisa kuti `src` inoshanda pakuverenga.
    // `src` haigone kupfuura `tmp` nekuti `tmp` yakangogoverwa pane stack sechinhu chakaparadzaniswa chakapihwa.
    //
    //
    // Zvakare, sezvo isu takangonyora kukosha kwakaringana mu `tmp`, zvinovimbiswa kuti zvinotangwa nemazvo.
    //
    unsafe {
        copy_nonoverlapping(src as *const u8, tmp.as_mut_ptr() as *mut u8, mem::size_of::<T>());
        tmp.assume_init()
    }
}

/// Inonyora nzvimbo yekurangarira pamwe neakapihwa kukosha pasina kuverenga kana kudonhedza kukosha kwekare.
///
/// `write` haina kudonhedza zvirimo mu `dst`.
/// Izvi zvakachengeteka, asi zvinogona kuburitsa mugove kana zviwanikwa, saka chengetedzo inofanira kutorwa kuti isanyora chinhu chinofanira kudonhedzwa.
///
///
/// Uyezve, haina kudonhedza `src`.Semantically, `src` inoendeswa munzvimbo yakanongedzwa ne `dst`.
///
/// Izvi zvakakodzera kutanga uninitialized memory, kana kunyora pamusoro ndangariro iyo yaimbove [`read`] kubva.
///
/// # Safety
///
/// Maitiro haana kujekeswa kana chero eanotevera mamiriro akatyorwa:
///
/// * `dst` inofanirwa kunge iri [valid] yekunyora.
///
/// * `dst` inofanira kunge yakanyatsoenderana.Shandisa [`write_unaligned`] kana zvisiri izvo.
///
/// Ziva kuti kunyangwe `T` ine saizi `0`, iyo pointer inofanirwa kunge isiri-NULL uye yakanyatsoenderana.
///
/// [valid]: self#safety
///
/// # Examples
///
/// Kushandiswa kwekutanga:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write(y, z);
///     assert_eq!(std::ptr::read(y), 12);
/// }
/// ```
///
/// Nemaoko shandisa [`mem::swap`]:
///
/// ```
/// use std::ptr;
///
/// fn swap<T>(a: &mut T, b: &mut T) {
///     unsafe {
///         // Gadzira kopi isinganzwisisike yemutengo pa `a` mu `tmp`.
///         let tmp = ptr::read(a);
///
///         // Kubuda panguva ino (kungave nekudzoka zvakajeka kana kudana basa iro panics) raizoita kuti kukosha kwe `tmp` kudonhedzwe ukuwo kukosha kwakadaro kuchiri kutaurwa ne `a`.
///         // Izvi zvinogona kukonzera kusanzwisisika maitiro kana `T` isiri `Copy`.
/////
/////
///
///         // Gadzira kopi isinganzwisisike yemutengo pa `b` mu `a`.
///         // Izvi zvakachengeteka nekuti zvinoshandurwa zvinongedzo hazvigone alias.
///         ptr::copy_nonoverlapping(b, a, 1);
///
///         // Sezvo pamusoro, kubuda apa kunogona kukonzeresa kujekesa hunhu nekuti iwo iwo mutengo wakatarwa unotsanangurwa ne `a` uye `b`.
/////
///
///         // Fambisa `tmp` mu `b`.
///         ptr::write(b, tmp);
///
///         // `tmp` yakatamiswa (`write` inotora muridzi wekupokana kwayo kwechipiri), saka hapana chakadonhedzwa zvachose pano.
/////
///     }
/// }
///
/// let mut foo = "foo".to_owned();
/// let mut bar = "bar".to_owned();
///
/// swap(&mut foo, &mut bar);
///
/// assert_eq!(foo, "bar");
/// assert_eq!(bar, "foo");
/// ```
///
///
///
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
pub unsafe fn write<T>(dst: *mut T, src: T) {
    // Tiri kudaidza maInternics zvakananga kuti tidzivise mafoni ekufona mukodhi yakagadzirwa se `intrinsics::copy_nonoverlapping` iri basa rekumonera.
    //
    extern "rust-intrinsic" {
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // Kachengeteka: iye anodana anofanira kuvimbisa kuti `dst` inoshanda kune anonyora.
    // `dst` haikwanisi kupfuura `src` nekuti iye ari kufona ane chinjana chinosvika ku `dst` nepo `src` iri yeiri basa.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T, dst, 1);
        intrinsics::forget(src);
    }
}

/// Inonyora nzvimbo yekurangarira pamwe neakapihwa kukosha pasina kuverenga kana kudonhedza kukosha kwekare.
///
/// Kusiyana ne [`write()`], iyo pointer inogona kunge isina kuenderana.
///
/// `write_unaligned` haina kudonhedza zvirimo mu `dst`.Izvi zvakachengeteka, asi zvinogona kuburitsa mugove kana zviwanikwa, saka chengetedzo inofanira kutorwa kuti isanyorazve chinhu chinofanira kudonhedzwa.
///
/// Uyezve, haina kudonhedza `src`.Semantically, `src` inoendeswa munzvimbo yakanongedzwa ne `dst`.
///
/// Izvi zvakakodzera kutanga uninitialized memory, kana kunyora pamusoro memory iyo yakamboverengerwa ne [`read_unaligned`].
///
/// # Safety
///
/// Maitiro haana kujekeswa kana chero eanotevera mamiriro akatyorwa:
///
/// * `dst` inofanirwa kunge iri [valid] yekunyora.
///
/// Ziva kuti kunyangwe `T` ine saizi `0`, iyo pointer inofanirwa kunge isiri-NULL.
///
/// [valid]: self#safety
///
/// ## Pa `packed` inodzika
///
/// Parizvino hazvigoneke kugadzira anonongedzera mbishi kune asina kuenderana minda yeyakaunganidzwa fomati.
///
/// Kuedza kugadzira pointer mbishi kune `unaligned` struct munda ine chirevo senge `&packed.unaligned as *const FieldType` inogadzira iripakati isina kugadzirirwa rejisiti usati washandura iyo kune yakasviba pointer.
///
/// Kuti chirevo ichi ndechechinguvana uye nekukasira kukosheswa hakukoshi sezvo muunganidzi achigara achitarisira kuti mareferenzi aenderane zvakanaka.
/// Nekuda kweizvozvo, kushandisa `&packed.unaligned as *const FieldType` kunokanganisa izvozvi* zvisina kujekesa maitiro * muchirongwa chako.
///
/// Muenzaniso wezvausingafanirwe kuita uye kuti izvi zvinowirirana sei ne `write_unaligned` ndeiyi:
///
/// ```no_run
/// #[repr(packed, C)]
/// struct Packed {
///     _padding: u8,
///     unaligned: u32,
/// }
///
/// let v = 0x01020304;
/// let mut packed: Packed = unsafe { std::mem::zeroed() };
///
/// let v = unsafe {
///     // Pano isu tinoedza kutora kero ye 32-bit manhamba isina kuenderana.
///     let unaligned =
///         // Chirevo chenguva pfupi chisina kusarudzika chakagadzirwa pano chinoguma nehunhu husina kujekeswa zvisinei nekuti chirevo chacho chinoshandiswa here kana kuti kwete.
/////
///         &mut packed.unaligned
///         // Kukanda kunongedzera mbishi hakubatsire;iko kukanganisa kwakatoitika.
///         as *mut u32;
///
///     std::ptr::write_unaligned(unaligned, v);
///
///     v
/// };
/// ```
///
/// Kuwana minda isina kukamurwa zvakananga ne eg `packed.unaligned` yakachengeteka zvakadaro.
///
///
///
///
///
///
///
///
///
// FIXME: Gadziridza maHTML zvichienderana nemhedzisiro yeRFC #2582 neshamwari.
/// # Examples
///
/// Nyora kukosha kweizeize kune bhata buffer:
///
/// ```
/// use std::mem;
///
/// fn write_usize(x: &mut [u8], val: usize) {
///     assert!(x.len() >= mem::size_of::<usize>());
///
///     let ptr = x.as_mut_ptr() as *mut usize;
///
///     unsafe { ptr.write_unaligned(val) }
/// }
/// ```
#[inline]
#[stable(feature = "ptr_unaligned", since = "1.17.0")]
#[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
pub const unsafe fn write_unaligned<T>(dst: *mut T, src: T) {
    // Kachengeteka: iye anodana anofanira kuvimbisa kuti `dst` inoshanda kune anonyora.
    // `dst` haikwanisi kupfuura `src` nekuti iye ari kufona ane chinjana chinosvika ku `dst` nepo `src` iri yeiri basa.
    //
    unsafe {
        copy_nonoverlapping(&src as *const T as *const u8, dst as *mut u8, mem::size_of::<T>());
        // Tiri kudana zvemukati zvakananga kudzivisa mashandiro ebasa mukodhi yakagadzirwa.
        intrinsics::forget(src);
    }
}

/// Inoita kuverenga kwakaomarara kweiyo kukosha kubva ku `src` pasina kuifambisa.Izvi zvinosiya ndangariro mu `src` isina kuchinjika.
///
/// Maitiro akasimba anoitirwa kuita pane I/O ndangariro, uye inovimbiswa kuti isazoregedzwe kana kugadziriswazve nemusanganisi pane mamwe mabasa asina kugadzikana.
///
/// # Notes
///
/// Rust haisati yave neyakaomarara uye yakasarudzika memory modhi, saka chaiyo semantics yezvinoreva "volatile" pano inogona kuchinja nekufamba kwenguva.
/// Izvo zviri kutaurwa, iyo semantics inozogara ichizoguma yakafanana yakafanana ne [C11's definition of volatile][c11].
///
/// Iyo compiler haifanire kuchinjisa hama kana odha yekusagadzikana ndangariro mashandiro.
/// Nekudaro, zvinochinja-chinja ndangariro mashandiro pane zero-saizi mhando (semuenzaniso, kana zero-saizi mhando yakapfuudzwa kuna `read_volatile`) ndeemapundu uye anogona kufuratirwa.
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Maitiro haana kujekeswa kana chero eanotevera mamiriro akatyorwa:
///
/// * `src` inofanira kunge iri [valid] yekuverenga.
///
/// * `src` inofanira kunge yakanyatsoenderana.
///
/// * `src` inofanirwa kunongedzera kukoshesiti yakatangwa zvakanaka yerudzi `T`.
///
/// Sa [`read`], `read_volatile` inogadzira kopi ye `T`, kunyangwe `T` iri [`Copy`].
/// Kana `T` isiri [`Copy`], uchishandisa zvese kukosha kwakadzoserwa uye kukosha pa `*src` kunogona [violate memory safety][read-ownership].
/// Nekudaro, kuchengetera isiri-[`Copy`] mhando mune isina kugadzikana ndangariro dzinenge zvisiri zvechokwadi.
///
/// Ziva kuti kunyangwe `T` ine saizi `0`, iyo pointer inofanirwa kunge isiri-NULL uye yakanyatsoenderana.
///
/// [valid]: self#safety
/// [read-ownership]: read#ownership-of-the-returned-value
///
/// Kungofanana neC, kunyangwe kuvhiyiwa kuchichinjika hakune chekuita pamibvunzo inosanganisira kuwana panguva imwe chete kubva kune dzakawanda tambo.Kupinda kwakasununguka kunozvibata chaizvo senge isiri-maatomu kuwana mune izvo.
///
/// Kunyanya, mujaho uripakati pe `read_volatile` uye chero basa rekunyora kunzvimbo imwechete haina kujekeswa maitiro.
///
/// # Examples
///
/// Kushandiswa kwekutanga:
///
/// ```
/// let x = 12;
/// let y = &x as *const i32;
///
/// unsafe {
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn read_volatile<T>(src: *const T) -> T {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(src) {
        // Kwete kuvhunduka kuchengeta codegen kukanganisa kudiki.
        abort();
    }
    // KUCHENGETEKA: iye anodana anofanirwa kuchengetedza chibvumirano chekuchengetedza che `volatile_load`.
    unsafe { intrinsics::volatile_load(src) }
}

/// Inoita inonyora nyora yenzvimbo yekurangarira ine yakapihwa kukosha pasina kuverenga kana kudonhedza iyo yekare kukosha.
///
/// Maitiro akasimba anoitirwa kuita pane I/O ndangariro, uye inovimbiswa kuti isazoregedzwe kana kugadziriswazve nemusanganisi pane mamwe mabasa asina kugadzikana.
///
/// `write_volatile` haina kudonhedza zvirimo mu `dst`.Izvi zvakachengeteka, asi zvinogona kuburitsa mugove kana zviwanikwa, saka chengetedzo inofanira kutorwa kuti isanyorazve chinhu chinofanira kudonhedzwa.
///
/// Uyezve, haina kudonhedza `src`.Semantically, `src` inoendeswa munzvimbo yakanongedzwa ne `dst`.
///
/// # Notes
///
/// Rust haisati yave neyakaomarara uye yakasarudzika memory modhi, saka chaiyo semantics yezvinoreva "volatile" pano inogona kuchinja nekufamba kwenguva.
/// Izvo zviri kutaurwa, iyo semantics inozogara ichizoguma yakafanana yakafanana ne [C11's definition of volatile][c11].
///
/// Iyo compiler haifanire kuchinjisa hama kana odha yekusagadzikana ndangariro mashandiro.
/// Nekudaro, zvinochinja-chinja ndangariro mashandiro pane zero-saizi mhando (semuenzaniso, kana zero-saizi mhando yakapfuudzwa kuna `write_volatile`) ndeemapundu uye anogona kufuratirwa
///
/// [c11]: http://www.open-std.org/jtc1/sc22/wg14/www/docs/n1570.pdf
///
/// # Safety
///
/// Maitiro haana kujekeswa kana chero eanotevera mamiriro akatyorwa:
///
/// * `dst` inofanirwa kunge iri [valid] yekunyora.
///
/// * `dst` inofanira kunge yakanyatsoenderana.
///
/// Ziva kuti kunyangwe `T` ine saizi `0`, iyo pointer inofanirwa kunge isiri-NULL uye yakanyatsoenderana.
///
/// [valid]: self#safety
///
/// Kungofanana neC, kunyangwe kuvhiyiwa kuchichinjika hakune chekuita pamibvunzo inosanganisira kuwana panguva imwe chete kubva kune dzakawanda tambo.Kupinda kwakasununguka kunozvibata chaizvo senge isiri-maatomu kuwana mune izvo.
///
/// Kunyanya, mujaho uri pakati pe `write_volatile` uye chero kumwe kuita (kuverenga kana kunyora) panzvimbo imwechete haina kujekeswa maitiro.
///
/// # Examples
///
/// Kushandiswa kwekutanga:
///
/// ```
/// let mut x = 0;
/// let y = &mut x as *mut i32;
/// let z = 12;
///
/// unsafe {
///     std::ptr::write_volatile(y, z);
///     assert_eq!(std::ptr::read_volatile(y), 12);
/// }
/// ```
///
///
///
///
///
///
///
///
///
///
///
///
#[inline]
#[stable(feature = "volatile", since = "1.9.0")]
pub unsafe fn write_volatile<T>(dst: *mut T, src: T) {
    if cfg!(debug_assertions) && !is_aligned_and_not_null(dst) {
        // Kwete kuvhunduka kuchengeta codegen kukanganisa kudiki.
        abort();
    }
    // KUCHENGETEKA: iye anodana anofanirwa kuchengetedza chibvumirano chekuchengetedza che `volatile_store`.
    unsafe {
        intrinsics::volatile_store(dst, src);
    }
}

/// Rongedza pointer `p`.
///
/// Verenga offset (maererano nezvinhu zve `stride` stride) iyo inofanirwa kuiswa kunongedzera `p` kuitira kuti pointer `p` ienderane ne `a`.
///
/// Note: Uku kumisikidza kwave kwakanyatsogadzirirwa kwete panic.Icho UB cheichi kusvika panic.
/// Shanduko chete yechokwadi inogona kuitwa pano shanduko ye `INV_TABLE_MOD_16` uye zvinowirirana zvinowirirana.
///
/// Kana tikambofunga kuita kuti zvikwanisike kudaidza zvemukati ne `a` isiri simba-revaviri, zvingangodaro zvine hungwaru kungochinjisa kuita kwekusaziva pane kuyedza kugadzirisa izvi kuti zvigadzirise shanduko iyoyo.
///
///
/// Chero mibvunzo enda kuna@nagisa.
///
///
///
#[lang = "align_offset"]
pub(crate) unsafe fn align_offset<T: Sized>(p: *const T, a: usize) -> usize {
    // FIXME(#75598): Kushandisa kwakananga kweizvi zvemukati kunovandudza codegen zvakanyanya pa opt-level <=
    // 1, uko nzira dzeshanduro dzeaya mashandiro dzisina kuiswa mukati.
    use intrinsics::{
        unchecked_shl, unchecked_shr, unchecked_sub, wrapping_add, wrapping_mul, wrapping_sub,
    };

    /// Verenga kuwanda kwemodular inverse ye `x` modulo `m`.
    ///
    /// Uku kumisikidza kwakagadzirirwa `align_offset` uye kune zvinotevera zvirevo.
    ///
    /// * `m` isimba-reviri;
    /// * `x < m`; (kana `x ≥ m`, pfuura `x % m` panzvimbo)
    ///
    /// Kuitwa kweiri basa hakuzi panic.Ever.
    #[inline]
    unsafe fn mod_inv(x: usize, m: usize) -> usize {
        /// Multiplicative modular inverse tafura modulo 2⁴=16.
        ///
        /// Ziva, kuti tafura iyi haina kukosha uko inverse isipo (kureva., `0⁻¹ mod 16`, `2⁻¹ mod 16`, nezvimwewo)
        ///
        const INV_TABLE_MOD_16: [u8; 8] = [1, 11, 13, 7, 9, 3, 5, 15];
        /// Modulo inoitirwa iyo `INV_TABLE_MOD_16`.
        const INV_TABLE_MOD: usize = 16;
        /// INV_TABLE_MOD²
        const INV_TABLE_MOD_SQUARED: usize = INV_TABLE_MOD * INV_TABLE_MOD;

        let table_inverse = INV_TABLE_MOD_16[(x & (INV_TABLE_MOD - 1)) >> 1] as usize;
        // Kachengeteka: `m` inodikanwa kuve simba-re-maviri, saka isiri zero.
        let m_minus_one = unsafe { unchecked_sub(m, 1) };
        if m <= INV_TABLE_MOD {
            table_inverse & m_minus_one
        } else {
            // Isu tinorexesa "up" tichishandisa fomula inotevera:
            //
            // $$ xy 1 (mod 2ⁿ) → xy (2, xy) ≡ 1 (mod 2²ⁿ) $$
            //
            // kusvika 2²ⁿ ≥ m.Ipapo isu tinogona kudzikisira kune yedu yatinoda `m` nekutora mhedzisiro `mod m`.
            let mut inverse = table_inverse;
            let mut going_mod = INV_TABLE_MOD_SQUARED;
            loop {
                // y=y * (2, xy) modhi n
                //
                // Ziva, kuti isu tinoshandisa kuputira mashandiro pano tichida-fomula yekutanga inoshandisa eg, kubvisa `mod n`.
                // Zvakanaka chose kuzviitira `mod usize::MAX` pachinzvimbo, nekuti isu tinotora mhedzisiro `mod n` kumagumo zvakadaro.
                //
                //
                inverse = wrapping_mul(inverse, wrapping_sub(2usize, wrapping_mul(x, inverse)));
                if going_mod >= m {
                    return inverse & m_minus_one;
                }
                going_mod = wrapping_mul(going_mod, going_mod);
            }
        }
    }

    let stride = mem::size_of::<T>();
    // KUCHENGETEKA: `a` isimba-re-maviri, saka isiri zero.
    let a_minus_one = unsafe { unchecked_sub(a, 1) };
    if stride == 1 {
        // `stride == 1` kesi inogona kuverengerwa zvakapusa kuburikidza ne `-p (mod a)`, asi kuita kudaro kunotadzisa kugona kweLLVM kusarudza mirairo senge `lea`.Panzvimbo iyoyo tinoverenga
        //
        //    round_up_to_next_alignment(p, a) - p
        //
        // iyo inogovera mashandiro akatenderedza kutakura-kutakura, asi kufungidzira `and` yakakwana kuti LLVM ikwanise kushandisa akasiyana siyana optimization iyo yaanoziva nezvayo.
        //
        //
        return wrapping_sub(
            wrapping_add(p as usize, a_minus_one) & wrapping_sub(0, a),
            p as usize,
        );
    }

    let pmoda = p as usize & a_minus_one;
    if pmoda == 0 {
        // Yakagadzirirwa kare.Yay!
        return 0;
    } else if stride == 0 {
        // Kana iyo pointer isina kuenderana, uye chinhu chiri zero-saizi, saka hapana huwandu hwezvinhu hunombo gadzirisa pointer.
        //
        return usize::MAX;
    }

    let smoda = stride & a_minus_one;
    // Kachengeteka: a isimba-ye-maviri nokudaro isiri zero.stride==0 kesi inobatwa pamusoro.
    let gcdpow = unsafe { intrinsics::cttz_nonzero(stride).min(intrinsics::cttz_nonzero(a)) };
    // Kachengeteka: gcdpow ine yepamusoro-yakasungwa ndiyo inonyanya kuwanda huwandu hwebiti mune usize.
    let gcd = unsafe { unchecked_shl(1usize, gcdpow) };

    // Kachengeteka: gcd inogara iri huru kana yakaenzana na1.
    if p as usize & unsafe { unchecked_sub(gcd, 1) } == 0 {
        // Iyi branch inogadzirisa inotevera inotevera mutsara kusangana.
        //
        // ` p + so = 0 mod a `
        //
        // `p` heino poindi kukosha, `s`, nhanho ye `T`, `o` offset mu`T`s, uye `a`, iko kunyorerwa kwakabatana.
        //
        // Iine `g = gcd(a, s)`, uye mamiriro ari pamusoro apa achisimbisa kuti `p` inogovaniswawo ne `g`, tinogona kureva `a' = a/g`, `s' = s/g`, `p' = p/g`, zvino izvi zvinova zvakaenzana ne:
        //
        // ` p' + s'o = 0 mod a' `
        // ` o = (a' - (p' mod a')) * (s'^-1 mod a') `
        //
        // Izwi rekutanga ndi "the relative alignment of `p` to `a`" (rakakamurwa ne `g`), izwi rechipiri ndi "how does incrementing `p` by `s` bytes change the relative alignment of `p`" (rakakamuraniswazve ne `g`).
        //
        // Kupatsanurwa ne `g` kunofanirwa kuita iyo inverse yakanyatsogadzirwa kana `a` uye `s` isiri co-prime.
        //
        // Zvakare, mhedzisiro inogadzirwa nemhinduro iyi haisi "minimal", saka zvakafanira kutora mhedzisiro `o mod lcm(s, a)`.Tinogona kutsiva `lcm(s, a)` ne `a'` chete.
        //
        //
        //
        //
        //

        // KUCHENGETEKA: `gcdpow` ine yepamusoro-yakasungwa haina kukura kupfuura iyo nhamba yekutevera 0-mabithi mu `a`.
        //
        let a2 = unsafe { unchecked_shr(a, gcdpow) };
        // Kachengeteka: `a2` haina-zero.Kuchinja `a` ne `gcdpow` hakugone kuburitsa chero seti mabheti
        // mu `a` (yeyo ine chaizvo imwe).
        let a2minus1 = unsafe { unchecked_sub(a2, 1) };
        // KUCHENGETEKA: `gcdpow` ine yepamusoro-yakasungwa haina kukura kupfuura iyo nhamba yekutevera 0-mabithi mu `a`.
        //
        let s2 = unsafe { unchecked_shr(smoda, gcdpow) };
        // KUCHENGETEKA: `gcdpow` ine yepamusoro-yakasungwa haina kukura kupfuura iyo nhamba yekutevera 0-mabiti mukati
        // `a`.
        // Zvakare, kubvisa kwacho hakugoni kufashukira, nekuti `a2 = a >> gcdpow` ichagara yakanyanyisa kukura kupfuura `(p % a) >> gcdpow`.
        let minusp2 = unsafe { unchecked_sub(a2, unchecked_shr(pmoda, gcdpow)) };
        // Kachengeteka: `a2` isimba-re-mbiri, sezvakaratidzwa pamusoro.`s2` iri zvishoma pasi pe `a2`
        // nekuti `(s % a) >> gcdpow` iri pasi pe `a >> gcdpow`.
        return wrapping_mul(minusp2, unsafe { mod_inv(s2, a2) }) & a2minus1;
    }

    // Haigone kuenderana zvachose.
    usize::MAX
}

/// Inofananidza anonongedzera mbishi ekuenzana.
///
/// Izvi zvakafanana nekushandisa `==` opareta, asi zvishoma generic:
/// nharo dzinofanirwa kuve `*const T` mbishi mapoinzi, kwete chero chinhu chinoshandisa `PartialEq`.
///
/// Izvi zvinogona kushandiswa kuenzanisa `&T` mareferensi (ayo anomanikidza ku `*const T` zvachose) nekero yavo pane kuenzanisa iwo maitiro avanonongedzera (zvinova zvinoitwa ne `PartialEq for &T`).
///
///
/// # Examples
///
/// ```
/// use std::ptr;
///
/// let five = 5;
/// let other_five = 5;
/// let five_ref = &five;
/// let same_five_ref = &five;
/// let other_five_ref = &other_five;
///
/// assert!(five_ref == same_five_ref);
/// assert!(ptr::eq(five_ref, same_five_ref));
///
/// assert!(five_ref == other_five_ref);
/// assert!(!ptr::eq(five_ref, other_five_ref));
/// ```
///
/// Zvimedu zvinoenzaniswa nehurefu hwazvo (mafuta anonongedzera):
///
/// ```
/// let a = [1, 2, 3];
/// assert!(std::ptr::eq(&a[..3], &a[..3]));
/// assert!(!std::ptr::eq(&a[..2], &a[..3]));
/// assert!(!std::ptr::eq(&a[0..2], &a[1..3]));
/// ```
///
/// Traits inofananidzwawo nekuita kwavo:
///
/// ```
/// #[repr(transparent)]
/// struct Wrapper { member: i32 }
///
/// trait Trait {}
/// impl Trait for Wrapper {}
/// impl Trait for i32 {}
///
/// let wrapper = Wrapper { member: 10 };
///
/// // Anonongedza ane akaenzana kero.
/// assert!(std::ptr::eq(
///     &wrapper as *const Wrapper as *const u8,
///     &wrapper.member as *const i32 as *const u8
/// ));
///
/// // Zvinhu zvine kero dzakaenzana, asi `Trait` ine maitiro akasiyana.
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait,
///     &wrapper.member as &dyn Trait,
/// ));
/// assert!(!std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait,
///     &wrapper.member as &dyn Trait as *const dyn Trait,
/// ));
///
/// // Kuchinja chirevo ku `*const u8` kufananidza nekero.
/// assert!(std::ptr::eq(
///     &wrapper as &dyn Trait as *const dyn Trait as *const u8,
///     &wrapper.member as &dyn Trait as *const dyn Trait as *const u8,
/// ));
/// ```
///
///
#[stable(feature = "ptr_eq", since = "1.17.0")]
#[inline]
pub fn eq<T: ?Sized>(a: *const T, b: *const T) -> bool {
    a == b
}

/// Hash mbichana mbichana.
///
/// Izvi zvinogona kushandiswa kuita hashi re `&T` rejista (iyo inomanikidza ku `*const T` zvisina tsarukano) nekero yayo pane kukosha kwayo kwainongedzera (zvinova zvinoitwa ne `Hash for &T`).
///
///
/// # Examples
///
/// ```
/// use std::collections::hash_map::DefaultHasher;
/// use std::hash::{Hash, Hasher};
/// use std::ptr;
///
/// let five = 5;
/// let five_ref = &five;
///
/// let mut hasher = DefaultHasher::new();
/// ptr::hash(five_ref, &mut hasher);
/// let actual = hasher.finish();
///
/// let mut hasher = DefaultHasher::new();
/// (five_ref as *const i32).hash(&mut hasher);
/// let expected = hasher.finish();
///
/// assert_eq!(actual, expected);
/// ```
///
#[stable(feature = "ptr_hash", since = "1.35.0")]
pub fn hash<T: ?Sized, S: hash::Hasher>(hashee: *const T, into: &mut S) {
    use crate::hash::Hash;
    hashee.hash(into);
}

// Impls yezvinongedzo zvebasa
macro_rules! fnptr_impls_safety_abi {
    ($FnTy: ty, $($Arg: ident),*) => {
        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialEq for $FnTy {
            #[inline]
            fn eq(&self, other: &Self) -> bool {
                *self as usize == *other as usize
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Eq for $FnTy {}

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> PartialOrd for $FnTy {
            #[inline]
            fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
                (*self as usize).partial_cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> Ord for $FnTy {
            #[inline]
            fn cmp(&self, other: &Self) -> Ordering {
                (*self as usize).cmp(&(*other as usize))
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> hash::Hash for $FnTy {
            fn hash<HH: hash::Hasher>(&self, state: &mut HH) {
                state.write_usize(*self as usize)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Pointer for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Iyo yepakati kukanda sekushandisa inodiwa kune AVR
                // kuitira kuti nzvimbo yekero yeiyo source function pointer ichengetedzwe mune yekupedzisira function pointer.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }

        #[stable(feature = "fnptr_impls", since = "1.4.0")]
        impl<Ret, $($Arg),*> fmt::Debug for $FnTy {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                // HACK: Iyo yepakati kukanda sekushandisa inodiwa kune AVR
                // kuitira kuti nzvimbo yekero yeiyo source function pointer ichengetedzwe mune yekupedzisira function pointer.
                //
                //
                // https://github.com/avr-rust/rust/issues/143
                fmt::Pointer::fmt(&(*self as usize as *const ()), f)
            }
        }
    }
}

macro_rules! fnptr_impls_args {
    ($($Arg: ident),+) => {
        fnptr_impls_safety_abi! { extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+) -> Ret, $($Arg),+ }
        fnptr_impls_safety_abi! { unsafe extern "C" fn($($Arg),+ , ...) -> Ret, $($Arg),+ }
    };
    () => {
        // Hapana akasiyana mabasa ane 0 paramita
        fnptr_impls_safety_abi! { extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { extern "C" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "Rust" fn() -> Ret, }
        fnptr_impls_safety_abi! { unsafe extern "C" fn() -> Ret, }
    };
}

fnptr_impls_args! {}
fnptr_impls_args! { A }
fnptr_impls_args! { A, B }
fnptr_impls_args! { A, B, C }
fnptr_impls_args! { A, B, C, D }
fnptr_impls_args! { A, B, C, D, E }
fnptr_impls_args! { A, B, C, D, E, F }
fnptr_impls_args! { A, B, C, D, E, F, G }
fnptr_impls_args! { A, B, C, D, E, F, G, H }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K }
fnptr_impls_args! { A, B, C, D, E, F, G, H, I, J, K, L }

/// Gadzira `const` mbichana pointer kune imwe nzvimbo, pasina kugadzira revo yepakati.
///
/// Kugadzira chirevo ne `&`/`&mut` kunongobvumidzwa chete kana iyo pointer yakanyatsoenderana uye ichinongedzera kune yekutanga data.
/// Kune zviitiko zvisina izvo zvinodiwa, zvinongedzo zvisvinu zvinofanirwa kushandiswa panzvimbo.
/// Nekudaro, `&expr as *const _` inogadzira rejisiti isati yaikanda kunongedzo mbishi, uye chirevo ichocho chinoenderana nemitemo imwecheteyo sekumwe kunongedzera.
///
/// Iyi macro inogona kugadzira mbishi mbichana *isina* kugadzira referensi kutanga.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let packed = Packed { f1: 1, f2: 2 };
/// // `&packed.f2` yaizogadzira isina kuenderana mareferenzi, uye nekudaro ive Undefined Maitiro!
/// let raw_f2 = ptr::addr_of!(packed.f2);
/// assert_eq!(unsafe { raw_f2.read_unaligned() }, 2);
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of($place:expr) {
    &raw const $place
}

/// Gadzira `mut` mbichana pointer kune imwe nzvimbo, pasina kugadzira revo yepakati.
///
/// Kugadzira chirevo ne `&`/`&mut` kunongobvumidzwa chete kana iyo pointer yakanyatsoenderana uye ichinongedzera kune yekutanga data.
/// Kune zviitiko zvisina izvo zvinodiwa, zvinongedzo zvisvinu zvinofanirwa kushandiswa panzvimbo.
/// Nekudaro, `&mut expr as *mut _` inogadzira rejisiti isati yaikanda kunongedzo mbishi, uye chirevo ichocho chinoenderana nemitemo imwecheteyo sekumwe kunongedzera.
///
/// Iyi macro inogona kugadzira mbishi mbichana *isina* kugadzira referensi kutanga.
///
/// # Example
///
/// ```
/// use std::ptr;
///
/// #[repr(packed)]
/// struct Packed {
///     f1: u8,
///     f2: u16,
/// }
///
/// let mut packed = Packed { f1: 1, f2: 2 };
/// // `&mut packed.f2` yaizogadzira isina kuenderana mareferenzi, uye nekudaro ive Undefined Maitiro!
/// let raw_f2 = ptr::addr_of_mut!(packed.f2);
/// unsafe { raw_f2.write_unaligned(42); }
/// assert_eq!({packed.f2}, 42); // `{...}` mauto anoteedzera munda pachinzvimbo chekugadzira chirevo.
/// ```
///
#[stable(feature = "raw_ref_macros", since = "1.51.0")]
#[rustc_macro_transparency = "semitransparent"]
#[allow_internal_unstable(raw_ref_op)]
pub macro addr_of_mut($place:expr) {
    &raw mut $place
}