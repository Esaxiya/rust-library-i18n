use super::*;
use crate::cmp::Ordering::{self, Equal, Greater, Less};
use crate::intrinsics;
use crate::slice::{self, SliceIndex};

#[lang = "mut_ptr"]
impl<T: ?Sized> *mut T {
    /// Inodzorera `true` kana iyo pointer isiri.
    ///
    /// Ziva kuti mhando dzisina saizi dzine akawanda anokwanisa nongedzera, sezvo chete iyo mbichana data pointer inofungidzirwa, kwete kureba kwavo, vtable, nezvimwe.
    /// Naizvozvo, zvinongedzo zviviri zvisina basa zvinogona kunge zvisingaenzane zvakaenzana.
    ///
    /// ## Maitiro panguva yekuongorora kweconst
    ///
    /// Kana iri basa rikashandiswa panguva yekuongorora kweconst, inogona kudzosa `false` yezvinongedzo zvinoshanduka kuva zvisina basa panguva yekumhanya.
    /// Kunyanya, kana pointer kune imwe ndangariro ikakanganiswa kupfuura miganhu yayo nenzira yekuti pointer inoguma haina basa, basa racho richaramba richidzosa `false`.
    ///
    /// Iko hakuna nzira yekuti CTFE izive mhedzisiro chinzvimbo cheiyo ndangariro, saka isu hatigone kuziva kana iyo pointer haina basa kana kwete.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// assert!(!ptr.is_null());
    /// ```
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_ptr_is_null", issue = "74939")]
    #[inline]
    pub const fn is_null(self) -> bool {
        // Enzanisa kuburikidza nekanda kune yakatetepa pointer, saka mafuta anonongedzera ari kungo tarisa yavo "data" chikamu che null-ness.
        //
        (self as *mut u8).guaranteed_eq(null_mut())
    }

    /// Inokanda kunongedzera yerumwe rudzi.
    #[stable(feature = "ptr_cast", since = "1.38.0")]
    #[rustc_const_stable(feature = "const_ptr_cast", since = "1.38.0")]
    #[inline]
    pub const fn cast<U>(self) -> *mut U {
        self as _
    }

    /// Sora iyo (pamwe yakafara) pointer mune iri kero uye metadata yezvinhu.
    ///
    /// Iyo pointer inogona kugadziriswazve ne [`from_raw_parts_mut`].
    #[cfg(not(bootstrap))]
    #[unstable(feature = "ptr_metadata", issue = "81513")]
    #[rustc_const_unstable(feature = "ptr_metadata", issue = "81513")]
    #[inline]
    pub const fn to_raw_parts(self) -> (*mut (), <T as super::Pointee>::Metadata) {
        (self.cast(), super::metadata(self))
    }

    /// Inodzorera `None` kana iyo pointer isiri, kana zvimwe inodzosera yakagovaniswa revo kune iyo kukosha kwakaputirwa mu `Some`.Kana iyo kukosha kungave isina kuvhurwa, [`as_uninit_ref`] inofanira kushandiswa panzvimbo.
    ///
    /// Kune mumwe anogona kuchinjika ona [`as_mut`].
    ///
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    /// [`as_mut`]: #method.as_mut
    ///
    /// # Safety
    ///
    /// Paunenge uchidana iyi nzira, unofanirwa kuona kuti *chero* iyo pointer iri NULL *kana* zvese zvinotevera ichokwadi:
    ///
    /// * Iyo pointer inofanira kunge yakanyatsoenderana.
    ///
    /// * Inofanira kunge iri "dereferencable" mupfungwa inotsanangurwa mu [the module documentation].
    ///
    /// * Iyo pointer inofanira kunongedzera kune yekutanga chiitiko ye `T`.
    ///
    /// * Iwe unofanirwa kumisikidza Rust yekumisikidza mitemo, nekuti iyo yakadzoserwa yehupenyu `'a` yakasarudzika zvakasarudzika uye hazvireve kuti inoratidza chaiko hupenyu hwedata.
    ///   Kunyanya, kwenguva yenguva ino yehupenyu, ndangariro inonongedzerwa nechinongedzo haifanire kuchinjwa (kunze kwemukati me `UnsafeCell`).
    ///
    /// Izvi zvinoshanda kunyangwe mhedzisiro yeiyi nzira ikasashandiswa!
    /// (Chikamu chekutangiswa hachisati chasarudzwa zvizere, asi kusvikira chasvika, nzira chete yakachengeteka ndeyekuona kuti dzakatangwa zvechokwadi.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_ref() {
    ///         println!("We got back the value: {}!", val_back);
    ///     }
    /// }
    /// ```
    ///
    /// # Shanduro isina kuvharwa
    ///
    /// Kana iwe uine chokwadi chekuti pointer haigone kuve isina basa uye urikutsvaga imwe mhando ye `as_ref_unchecked` iyo inodzosera iyo `&T` pachinzvimbo che `Option<&T>`, ziva kuti iwe unogona kuratidza chirevo zvakananga.
    ///
    ///
    /// ```
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     let val_back = &*ptr;
    ///     println!("We got back the value: {}!", val_back);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_ref<'a>(self) -> Option<&'a T> {
        // Kachengeteka: iye anodana anofanira kuvimbisa kuti `self` inoshanda kune a
        // referensi kana isiri null.
        if self.is_null() { None } else { unsafe { Some(&*self) } }
    }

    /// Inodzorera `None` kana iyo pointer isiri, kana zvimwe ichidzosera yakagovaniswa revo kune iyo kukosha kwakaputirwa mu `Some`.
    /// Kupesana ne [`as_ref`], izvi hazvidi kuti kukosha kwacho kutange kutangwa.
    ///
    /// Kune mumwe anogona kuchinjika ona [`as_uninit_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    ///
    /// # Safety
    ///
    /// Paunenge uchidana iyi nzira, unofanirwa kuona kuti *chero* iyo pointer iri NULL *kana* zvese zvinotevera ichokwadi:
    ///
    /// * Iyo pointer inofanira kunge yakanyatsoenderana.
    ///
    /// * Inofanira kunge iri "dereferencable" mupfungwa inotsanangurwa mu [the module documentation].
    ///
    /// * Iwe unofanirwa kumisikidza Rust yekumisikidza mitemo, nekuti iyo yakadzoserwa yehupenyu `'a` yakasarudzika zvakasarudzika uye hazvireve kuti inoratidza chaiko hupenyu hwedata.
    ///
    ///   Kunyanya, kwenguva yenguva ino yehupenyu, ndangariro inonongedzerwa nechinongedzo haifanire kuchinjwa (kunze kwemukati me `UnsafeCell`).
    ///
    /// Izvi zvinoshanda kunyangwe mhedzisiro yeiyi nzira ikasashandiswa!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// #![feature(ptr_as_uninit)]
    ///
    /// let ptr: *mut u8 = &mut 10u8 as *mut u8;
    ///
    /// unsafe {
    ///     if let Some(val_back) = ptr.as_uninit_ref() {
    ///         println!("We got back the value: {}!", val_back.assume_init());
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_ref<'a>(self) -> Option<&'a MaybeUninit<T>>
    where
        T: Sized,
    {
        // Kachengeteka: iye anodana anofanira kuvimbisa kuti `self` inosangana neese
        // zvinodiwa kune chirevo.
        if self.is_null() { None } else { Some(unsafe { &*(self as *const MaybeUninit<T>) }) }
    }

    /// Inoverenga zvakatemwa kubva kunongedzera.
    ///
    /// `count` iri muzvikamu zveT;semuenzaniso, `count` ye3 inomiririra pointer offset ye `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Kana chero eanotevera mamiriro akatyorwa, mhedzisiro ndeye Undefined Maitiro:
    ///
    /// * Dzese dzinotanga uye dzinoguma pointer dzinofanirwa kunge dziri mumiganhu kana imwe byte yapfuura kupera kwechinhu chimwe chakagoverwa.
    /// Ziva kuti mu Rust, yega (stack-allocated) musiyano inoonekwa sechinhu chakaparadzaniswa chakapihwa.
    ///
    /// * Iyo yakagadziriswa offset,**mumabheti**, haigone kufashukira `isize`.
    ///
    /// * Kukanganiswa kuri mumiganhu hakugone kuvimba ne "wrapping around" nzvimbo yekero.Ndokunge, iyo isingagumi-chaiyoiyo chiyero,**mumabheti** inofanirwa kukwana musize.
    ///
    /// Iyo compiler uye yakajairwa raibhurari kazhinji inoedza kuve nechokwadi kuti kugoverwa hakutombosvika kune saizi uko kukanganisa kuri kunetsa.
    /// Semuenzaniso, `Vec` uye `Box` vanoona kuti havafi vakapa zvinopfuura `isize::MAX` byte, saka `vec.as_ptr().add(vec.len())` inogara yakachengeteka.
    ///
    /// Mazhinji mapuratifomu asingatombogone kuvaka kwakadai kupihwa.
    /// Semuenzaniso, hapana inozivikanwa 64-bit chikuva chingamboshandira chikumbiro che2 <sup>63</sup> byte nekuda kwekukanganisa-patafura tafura kana kutsemura kero nzvimbo.
    /// Nekudaro, mamwe mapuratifomu makumi matatu nematatu uye gumi nematanhatu anogona kubudirira kusevenzesa chikumbiro cheanopfuura ma `isize::MAX` mabheti ane zvinhu zvakaita sePanyama Kero Yekuwedzera.
    ///
    /// Saka nekudaro, ndangariro yakawanikwa zvakananga kubva kune vanogovera kana ndangariro dzakatemwa mafaera *inogona* kuve yakakura kwazvo kubata nebasa iri.
    ///
    /// Funga kushandisa [`wrapping_offset`] pachinzvimbo kana zvipingamupinyi izvi zvichinetsa kugutsa.
    /// Iyo chete mukana weiyi nzira ndeyekuti inogonesa ine hukasha compiler optimizations.
    ///
    /// [`wrapping_offset`]: #method.wrapping_offset
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.offset(1));
    ///     println!("{}", *ptr.offset(2));
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // KUCHENGETEKA: iye anodana anofanirwa kuchengetedza chibvumirano chekuchengetedza che `offset`.
        // Iyo yakawanikwa pointer inoshanda kune anonyora sezvo iye ari kufona achifanira kuvimbisa kuti inonongedzera kuchinhu chimwe chete chakapihwa se `self`.
        //
        unsafe { intrinsics::offset(self, count) as *mut T }
    }

    /// Inoverenga zvakatemwa kubva kunongedzera uchishandisa kuputira arithmetic.
    /// `count` iri muzvikamu zveT;semuenzaniso, `count` ye3 inomiririra pointer offset ye `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Uku kushanda pachako kunogara kwakachengeteka, asi kushandisa chinoguma pointer hakusi.
    ///
    /// Iyo inonongedzera pointer inoramba yakanamatira kune imwecheteyo chinhu chakapihwa icho `self` inonongedza.
    /// Inogona *kwete* kushandiswa kuwana chakasiyana chakapihwa chinhu.Ziva kuti mu Rust, yega (stack-allocated) musiyano inoonekwa sechinhu chakaparadzaniswa chakapihwa.
    ///
    /// Mune mamwe mazwi, `let z = x.wrapping_offset((y as isize) - (x as isize))` haina * kuita `z` yakafanana ne `y` kunyangwe isu tichifungidzira kuti `T` ine saizi `1` uye hapana kufashukira: `z` ichiri yakanamatira kuchinhu `x` chakanamatira, uye kuireferesa haina Kujekeswa Maitiro kunze kwekunge `x` uye `y` inongedzera muchinhu chimwe chakagoverwa.
    ///
    /// Inofananidzwa ne [`offset`], iyi nzira inononoka kuita chinodiwa chekugara mukati mechinhu chimwe chete chakapihwa: [`offset`] iri pakarepo Undefined Maitiro kana uchidarika miganhu yechinhu;`wrapping_offset` inogadzira pointer asi ichiri kutungamira kune Undefined Maitiro kana pointer ikasarudzika kana iri kunze kwemiganhu yechinhu chakasungirirwa.
    /// [`offset`] inogona kukwidziridzwa zvirinani uye nekudaro inosarudzwa mukuita-inonzwisisika kodhi.
    ///
    /// Iko kunonoka cheki kunongotarisa kukosha kweiyo pointer iyo yakatariswa, kwete iyo yepakati tsika inoshandiswa panguva yekuverenga kwemhedzisiro mhedzisiro.
    /// Semuenzaniso, `x.wrapping_offset(o).wrapping_offset(o.wrapping_neg())` inogara yakafanana ne `x`.Mune mamwe mazwi, kusiya chinhu chakapihwa uyezve kuchipinda mukati gare gare kunotenderwa.
    ///
    /// Kana iwe uchida kuyambuka chinhu miganhu, kandira iyo pointer kune iyo nhamba uye ita arithmetic ipapo.
    ///
    /// [`offset`]: #method.offset
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// // Iterate ndichishandisa mbichana mbichana mukuwedzera kwezvinhu zviviri
    /// let mut data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *mut u8 = data.as_mut_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_offset(6);
    ///
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         *ptr = 0;
    ///     }
    ///     ptr = ptr.wrapping_offset(step);
    /// }
    /// assert_eq!(&data, &[0, 2, 0, 4, 0]);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_wrapping_offset", since = "1.16.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_offset(self, count: isize) -> *mut T
    where
        T: Sized,
    {
        // Kachengeteka: iyo `arith_offset` yemukati haina zvido zvekudaidzwa.
        unsafe { intrinsics::arith_offset(self, count) as *mut T }
    }

    /// Inodzorera `None` kana iyo pointer isiri, kana zvimwe ichidzorera yakasarudzika rejisheni kune kukosha kwakaputirwa mu `Some`.Kana iyo kukosha kungave isina kuvhurwa, [`as_uninit_mut`] inofanira kushandiswa panzvimbo.
    ///
    /// Kune mumwe waunogovana naye ona [`as_ref`].
    ///
    /// [`as_uninit_mut`]: #method.as_uninit_mut
    /// [`as_ref`]: #method.as_ref-1
    ///
    /// # Safety
    ///
    /// Paunenge uchidana iyi nzira, unofanirwa kuona kuti *chero* iyo pointer iri NULL *kana* zvese zvinotevera ichokwadi:
    ///
    /// * Iyo pointer inofanira kunge yakanyatsoenderana.
    ///
    /// * Inofanira kunge iri "dereferencable" mupfungwa inotsanangurwa mu [the module documentation].
    ///
    /// * Iyo pointer inofanira kunongedzera kune yekutanga chiitiko ye `T`.
    ///
    /// * Iwe unofanirwa kumisikidza Rust yekumisikidza mitemo, nekuti iyo yakadzoserwa yehupenyu `'a` yakasarudzika zvakasarudzika uye hazvireve kuti inoratidza chaiko hupenyu hwedata.
    ///   Kunyanya, kwenguva yenguva ino yehupenyu, ndangariro inonongedzerwa nechinongedzo haifanirwe kuwanikwa (kuverenga kana kunyorwa) kuburikidza nechero imwe pointer.
    ///
    /// Izvi zvinoshanda kunyangwe mhedzisiro yeiyi nzira ikasashandiswa!
    /// (Chikamu chekutangiswa hachisati chasarudzwa zvizere, asi kusvikira chasvika, nzira chete yakachengeteka ndeyekuona kuti dzakatangwa zvechokwadi.)
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { ptr.as_mut().unwrap() };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Ichapurinda: "[4, 2, 3]".
    /// ```
    ///
    /// # Shanduro isina kuvharwa
    ///
    /// Kana iwe uine chokwadi chekuti pointer haigone kuve isina basa uye urikutsvaga imwe mhando ye `as_mut_unchecked` iyo inodzosera iyo `&mut T` pachinzvimbo che `Option<&mut T>`, ziva kuti iwe unogona kuratidza chirevo zvakananga.
    ///
    ///
    /// ```
    /// let mut s = [1, 2, 3];
    /// let ptr: *mut u32 = s.as_mut_ptr();
    /// let first_value = unsafe { &mut *ptr };
    /// *first_value = 4;
    /// # assert_eq!(s, [4, 2, 3]);
    /// println!("{:?}", s); // Ichapurinda: "[4, 2, 3]".
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_as_ref", since = "1.9.0")]
    #[inline]
    pub unsafe fn as_mut<'a>(self) -> Option<&'a mut T> {
        // Kachengeteka: iye anodana anofanira kuvimbisa kuti `self` inoshanda ku
        // chirevo chinoshanduka kana chisiri chisina basa.
        if self.is_null() { None } else { unsafe { Some(&mut *self) } }
    }

    /// Inodzorera `None` kana iyo pointer isina basa, kana zvikadaro inodzosera yakasarudzika chirevo kune kukosha kwakaputirwa ne `Some`.
    /// Kupesana ne [`as_mut`], izvi hazvidi kuti kukosha kwacho kutange kutangwa.
    ///
    /// Kune mumwe waunogovana naye ona [`as_uninit_ref`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_ref`]: #method.as_uninit_ref-1
    ///
    /// # Safety
    ///
    /// Paunenge uchidana iyi nzira, unofanirwa kuona kuti *chero* iyo pointer iri NULL *kana* zvese zvinotevera ichokwadi:
    ///
    /// * Iyo pointer inofanira kunge yakanyatsoenderana.
    ///
    /// * Inofanira kunge iri "dereferencable" mupfungwa inotsanangurwa mu [the module documentation].
    ///
    /// * Iwe unofanirwa kumisikidza Rust yekumisikidza mitemo, nekuti iyo yakadzoserwa yehupenyu `'a` yakasarudzika zvakasarudzika uye hazvireve kuti inoratidza chaiko hupenyu hwedata.
    ///
    ///   Kunyanya, kwenguva yenguva ino yehupenyu, ndangariro inonongedzerwa nechinongedzo haifanirwe kuwanikwa (kuverenga kana kunyorwa) kuburikidza nechero imwe pointer.
    ///
    /// Izvi zvinoshanda kunyangwe mhedzisiro yeiyi nzira ikasashandiswa!
    ///
    /// [the module documentation]: crate::ptr#safety
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_mut<'a>(self) -> Option<&'a mut MaybeUninit<T>>
    where
        T: Sized,
    {
        // Kachengeteka: iye anodana anofanira kuvimbisa kuti `self` inosangana neese
        // zvinodiwa kune chirevo.
        if self.is_null() { None } else { Some(unsafe { &mut *(self as *mut MaybeUninit<T>) }) }
    }

    /// Inodzosera kana zvirevo zviviri zvakavimbiswa kuti zvakaenzana.
    ///
    /// Panguva yekumhanya basa iri rinoita se `self == other`.
    /// Nekudaro, mune mamwe mamiriro (semuenzaniso, kuumbiridza-nguva ongororo), hazviwanzo kuitika kuenzanisa kuenzana kwezvinongedzo zviviri, saka basa iri rinogona kudzosa zvine mutsindo `false` yemanongedzo ayo anozozove akaenzana.
    ///
    /// Asi painodzoka `true`, anonongedzera anovimbiswa kuenzana.
    ///
    /// Iri basa igirazi re [`guaranteed_ne`], asi kwete inverse.Iko kune pointer kufananidza kune ayo maviri mabasa anodzosa `false`.
    ///
    /// [`guaranteed_ne`]: #method.guaranteed_ne
    ///
    /// Iko kukosha kwekudzoka kunogona kuchinja zvichienderana neiyo compiler vhezheni uye isina kuchengetedzeka kodhi inogona kusatsamira pamhedzisiro yeiri basa kuti rive neruzha.
    /// Zvinokurudzirwa kuti ushandise chete basa iri kuita optimizations uko kwekunyepedzera `false` yekudzosa kukosha neichi chiitiko kusingabate mhedzisiro, asi kungoita chete.
    /// Mhedzisiro yekushandisa nzira iyi kugadzira nguva yekumhanya uye kuumbiridza-yenguva kodhi kuzvibata zvakasiyana hazvina kuongororwa.
    /// Iyi nzira haifanire kushandiswa kuunza mutsauko wakadai, uye haufanire zvakare kudzikamiswa tisati tanzwisisa zviri nani iyi nyaya.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const fn guaranteed_eq(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_eq(self as *const _, other as *const _)
    }

    /// Inodzosera kunyangwe zvirevo zviviri zvakavimbiswa kusaenzana.
    ///
    /// Panguva yekumhanya basa iri rinoita se `self != other`.
    /// Nekudaro, mune mamwe mamiriro (semuenzaniso, kuumbiridza-nguva yekuongorora), hazviwanzo kuitika kuti uone kusaenzana kwezvinongedzo zviviri, saka basa iri rinogona kudzosa zvine hukasha `false` yezvinongedzo izvo zvichazonyatso kuve zvisina kuenzana.
    ///
    /// Asi painodzoka `true`, iwo anonongedzera anovimbiswa kusaenzana.
    ///
    /// Iri basa igirazi re [`guaranteed_eq`], asi kwete inverse.Iko kune pointer kufananidza kune ayo maviri mabasa anodzosa `false`.
    ///
    /// [`guaranteed_eq`]: #method.guaranteed_eq
    ///
    /// Iko kukosha kwekudzoka kunogona kuchinja zvichienderana neiyo compiler vhezheni uye isina kuchengetedzeka kodhi inogona kusatsamira pamhedzisiro yeiri basa kuti rive neruzha.
    /// Zvinokurudzirwa kuti ushandise chete basa iri kuita optimizations uko kwekunyepedzera `false` yekudzosa kukosha neichi chiitiko kusingabate mhedzisiro, asi kungoita chete.
    /// Mhedzisiro yekushandisa nzira iyi kugadzira nguva yekumhanya uye kuumbiridza-yenguva kodhi kuzvibata zvakasiyana hazvina kuongororwa.
    /// Iyi nzira haifanire kushandiswa kuunza mutsauko wakadai, uye haufanire zvakare kudzikamiswa tisati tanzwisisa zviri nani iyi nyaya.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    #[inline]
    pub const unsafe fn guaranteed_ne(self, other: *mut T) -> bool
    where
        T: Sized,
    {
        intrinsics::ptr_guaranteed_ne(self as *const _, other as *const _)
    }

    /// Inotarisa chinhambwe pakati pezvinongedzo zviviri.Iko kukosha kwakadzoserwa kuri muzvikamu zveT: daro mumabheti rakakamurwa ne `mem::size_of::<T>()`.
    ///
    /// Iri basa ndiko kutendeuka kwe [`offset`].
    ///
    /// [`offset`]: #method.offset-1
    ///
    /// # Safety
    ///
    /// Kana chero eanotevera mamiriro akatyorwa, mhedzisiro ndeye Undefined Maitiro:
    ///
    /// * Zvese zviri zviviri zvekutanga uye chimwe chinongedzo chinofanira kunge chiri mumiganhu kana imwe byte yapfuura kupera kwechinhu chimwe chakagoverwa.
    /// Ziva kuti mu Rust, yega (stack-allocated) musiyano inoonekwa sechinhu chakaparadzaniswa chakapihwa.
    ///
    /// * Ose anongedzera anofanirwa kuve *akatorwa kubva* kunongedzera kuchinhu chimwe chete.
    ///   (Ona pazasi semuenzaniso.)
    ///
    /// * Iyo nhambwe pakati pezvinongedzo, mumabheti, inofanira kunge iri chaiyo yakawanda yehukuru hwe `T`.
    ///
    /// * Iyo daro pakati pezvinongedzera,**mumabheti**, haigone kufashukira `isize`.
    ///
    /// * Iyo daro iri mumiganhu haigone kuvimba ne "wrapping around" iyo kero nzvimbo.
    ///
    /// Rust mhando hadzina kumbokura kupfuura `isize::MAX` uye Rust migove haimboputira yakatenderedza nzvimbo yekero, saka maviri anonongedzera mukati meimwe kukosha kwechero Rust mhando `T` ichagara ichigutsa maviri ekupedzisira mamiriro.
    ///
    /// Raibhurari yakajairwa zvakare inowanzo chengetedza kuti kugoverwa hakusvike pakukura apo chinokanganisa chiri kunetsa.
    /// Semuenzaniso, `Vec` uye `Box` vanoona kuti havafi vakapa zvinopfuura `isize::MAX` byte, saka `ptr_into_vec.offset_from(vec.as_ptr())` inogara ichigutsa iwo maviri ekupedzisira mamiriro.
    ///
    /// Mazhinji mapuratifomu asingatombogone kuvaka kwakakura kwakadai.
    /// Semuenzaniso, hapana inozivikanwa 64-bit chikuva chingamboshandira chikumbiro che2 <sup>63</sup> byte nekuda kwekukanganisa-patafura tafura kana kutsemura kero nzvimbo.
    /// Nekudaro, mamwe mapuratifomu makumi matatu nematatu uye gumi nematanhatu anogona kubudirira kusevenzesa chikumbiro cheanopfuura ma `isize::MAX` mabheti ane zvinhu zvakaita sePanyama Kero Yekuwedzera.
    /// Saka nekudaro, ndangariro yakawanikwa zvakananga kubva kune vanogovera kana ndangariro dzakatemwa mafaera *inogona* kuve yakakura kwazvo kubata nebasa iri.
    /// (Cherekedza kuti [`offset`] uye [`add`] zvakare vane muganho wakafanana uye nekudaro haigone kushandiswa pane zvakakura zvakakura kudaro.)
    ///
    /// [`add`]: #method.add
    ///
    /// # Panics
    ///
    /// Iri basa panics kana `T` iri Zero-Sized Type ("ZST").
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let mut a = [0; 5];
    /// let ptr1: *mut i32 = &mut a[1];
    /// let ptr2: *mut i32 = &mut a[3];
    /// unsafe {
    ///     assert_eq!(ptr2.offset_from(ptr1), 2);
    ///     assert_eq!(ptr1.offset_from(ptr2), -2);
    ///     assert_eq!(ptr1.offset(2), ptr2);
    ///     assert_eq!(ptr2.offset(-2), ptr1);
    /// }
    /// ```
    ///
    /// *Kuita zvisirizvo*:
    ///
    /// ```rust,no_run
    /// let ptr1 = Box::into_raw(Box::new(0u8));
    /// let ptr2 = Box::into_raw(Box::new(1u8));
    /// let diff = (ptr2 as isize).wrapping_sub(ptr1 as isize);
    /// // Gadzira ptr2_imwe "alias" ye ptr2, asi yakatorwa kubva ku ptr1.
    /// let ptr2_other = (ptr1 as *mut u8).wrapping_offset(diff);
    /// assert_eq!(ptr2 as usize, ptr2_other as usize);
    /// // Sezvo ptr2_other uye ptr2 zvakatorwa kubva kunongedzera kuzvinhu zvakasiyana, komputa yavo kusanzwisisika maitiro, kunyangwe ivo vachinongedzera kukero imwechete!
    /////
    /////
    /// unsafe {
    ///     let zero = ptr2_other.offset_from(ptr2); // Asina kujekeswa Maitiro
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "ptr_offset_from", since = "1.47.0")]
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    #[inline]
    pub const unsafe fn offset_from(self, origin: *const T) -> isize
    where
        T: Sized,
    {
        // KUCHENGETEKA: iye anodana anofanirwa kuchengetedza chibvumirano chekuchengetedza che `offset_from`.
        unsafe { (self as *const T).offset_from(origin) }
    }

    /// Inoverenga zvakatemwa kubva kunongedzera (zviri nyore zve `.offset(count as isize)`).
    ///
    /// `count` iri muzvikamu zveT;semuenzaniso, `count` ye3 inomiririra pointer offset ye `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Kana chero eanotevera mamiriro akatyorwa, mhedzisiro ndeye Undefined Maitiro:
    ///
    /// * Dzese dzinotanga uye dzinoguma pointer dzinofanirwa kunge dziri mumiganhu kana imwe byte yapfuura kupera kwechinhu chimwe chakagoverwa.
    /// Ziva kuti mu Rust, yega (stack-allocated) musiyano inoonekwa sechinhu chakaparadzaniswa chakapihwa.
    ///
    /// * Iyo yakagadziriswa offset,**mumabheti**, haigone kufashukira `isize`.
    ///
    /// * Kukanganiswa kuri mumiganhu hakugone kuvimba ne "wrapping around" nzvimbo yekero.Ndokunge, iyo isingaperi-chaiyoiyo chiyero chinofanirwa kukwana mu `usize`.
    ///
    /// Iyo compiler uye yakajairwa raibhurari kazhinji inoedza kuve nechokwadi kuti kugoverwa hakutombosvika kune saizi uko kukanganisa kuri kunetsa.
    /// Semuenzaniso, `Vec` uye `Box` vanoona kuti havafi vakapa zvinopfuura `isize::MAX` byte, saka `vec.as_ptr().add(vec.len())` inogara yakachengeteka.
    ///
    /// Mazhinji mapuratifomu asingatombogone kuvaka kwakadai kupihwa.
    /// Semuenzaniso, hapana inozivikanwa 64-bit chikuva chingamboshandira chikumbiro che2 <sup>63</sup> byte nekuda kwekukanganisa-patafura tafura kana kutsemura kero nzvimbo.
    /// Nekudaro, mamwe mapuratifomu makumi matatu nematatu uye gumi nematanhatu anogona kubudirira kusevenzesa chikumbiro cheanopfuura ma `isize::MAX` mabheti ane zvinhu zvakaita sePanyama Kero Yekuwedzera.
    ///
    /// Saka nekudaro, ndangariro yakawanikwa zvakananga kubva kune vanogovera kana ndangariro dzakatemwa mafaera *inogona* kuve yakakura kwazvo kubata nebasa iri.
    ///
    /// Funga kushandisa [`wrapping_add`] pachinzvimbo kana zvipingamupinyi izvi zvichinetsa kugutsa.
    /// Iyo chete mukana weiyi nzira ndeyekuti inogonesa ine hukasha compiler optimizations.
    ///
    /// [`wrapping_add`]: #method.wrapping_add
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let s: &str = "123";
    /// let ptr: *const u8 = s.as_ptr();
    ///
    /// unsafe {
    ///     println!("{}", *ptr.add(1) as char);
    ///     println!("{}", *ptr.add(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn add(self, count: usize) -> Self
    where
        T: Sized,
    {
        // KUCHENGETEKA: iye anodana anofanirwa kuchengetedza chibvumirano chekuchengetedza che `offset`.
        unsafe { self.offset(count as isize) }
    }

    /// Inoverenga zvakatemwa kubva kunongedzera (zviri nyore zve` .offset ((kuverenga se isize).wrapping_neg())`).
    ///
    /// `count` iri muzvikamu zveT;semuenzaniso, `count` ye3 inomiririra pointer offset ye `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Kana chero eanotevera mamiriro akatyorwa, mhedzisiro ndeye Undefined Maitiro:
    ///
    /// * Dzese dzinotanga uye dzinoguma pointer dzinofanirwa kunge dziri mumiganhu kana imwe byte yapfuura kupera kwechinhu chimwe chakagoverwa.
    /// Ziva kuti mu Rust, yega (stack-allocated) musiyano inoonekwa sechinhu chakaparadzaniswa chakapihwa.
    ///
    /// * Iyo computed offset haigone kudarika `isize::MAX`**byte**.
    ///
    /// * Kukanganiswa kuri mumiganhu hakugone kuvimba ne "wrapping around" nzvimbo yekero.Ndokunge, iyo isingagumi-chaiyoiyo chiyero chinofanirwa kukwana musize.
    ///
    /// Iyo compiler uye yakajairwa raibhurari kazhinji inoedza kuve nechokwadi kuti kugoverwa hakutombosvika kune saizi uko kukanganisa kuri kunetsa.
    /// Semuenzaniso, `Vec` uye `Box` vanoona kuti havafi vakapa zvinopfuura `isize::MAX` byte, saka `vec.as_ptr().add(vec.len()).sub(vec.len())` inogara yakachengeteka.
    ///
    /// Mazhinji mapuratifomu asingatombogone kuvaka kwakadai kupihwa.
    /// Semuenzaniso, hapana inozivikanwa 64-bit chikuva chingamboshandira chikumbiro che2 <sup>63</sup> byte nekuda kwekukanganisa-patafura tafura kana kutsemura kero nzvimbo.
    /// Nekudaro, mamwe mapuratifomu makumi matatu nematatu uye gumi nematanhatu anogona kubudirira kusevenzesa chikumbiro cheanopfuura ma `isize::MAX` mabheti ane zvinhu zvakaita sePanyama Kero Yekuwedzera.
    ///
    /// Saka nekudaro, ndangariro yakawanikwa zvakananga kubva kune vanogovera kana ndangariro dzakatemwa mafaera *inogona* kuve yakakura kwazvo kubata nebasa iri.
    ///
    /// Funga kushandisa [`wrapping_sub`] pachinzvimbo kana zvipingamupinyi izvi zvichinetsa kugutsa.
    /// Iyo chete mukana weiyi nzira ndeyekuti inogonesa ine hukasha compiler optimizations.
    ///
    /// [`wrapping_sub`]: #method.wrapping_sub
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// let s: &str = "123";
    ///
    /// unsafe {
    ///     let end: *const u8 = s.as_ptr().add(3);
    ///     println!("{}", *end.sub(1) as char);
    ///     println!("{}", *end.sub(2) as char);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const unsafe fn sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        // KUCHENGETEKA: iye anodana anofanirwa kuchengetedza chibvumirano chekuchengetedza che `offset`.
        unsafe { self.offset((count as isize).wrapping_neg()) }
    }

    /// Inoverenga zvakatemwa kubva kunongedzera uchishandisa kuputira arithmetic.
    /// (kurerukirwa kwe `.wrapping_offset(count as isize)`)
    ///
    /// `count` iri muzvikamu zveT;semuenzaniso, `count` ye3 inomiririra pointer offset ye `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Uku kushanda pachako kunogara kwakachengeteka, asi kushandisa chinoguma pointer hakusi.
    ///
    /// Iyo inonongedzera pointer inoramba yakanamatira kune imwecheteyo chinhu chakapihwa icho `self` inonongedza.
    /// Inogona *kwete* kushandiswa kuwana chakasiyana chakapihwa chinhu.Ziva kuti mu Rust, yega (stack-allocated) musiyano inoonekwa sechinhu chakaparadzaniswa chakapihwa.
    ///
    /// Mune mamwe mazwi, `let z = x.wrapping_add((y as usize) - (x as usize))` haina * kuita `z` yakafanana ne `y` kunyangwe isu tichifungidzira kuti `T` ine saizi `1` uye hapana kufashukira: `z` ichiri yakanamatira kuchinhu `x` chakanamatira, uye kuireferesa haina Kujekeswa Maitiro kunze kwekunge `x` uye `y` inongedzera muchinhu chimwe chakagoverwa.
    ///
    /// Inofananidzwa ne [`add`], iyi nzira inononoka kuita chinodiwa chekugara mukati mechinhu chimwe chete chakapihwa: [`add`] iri pakarepo Undefined Maitiro kana uchidarika miganhu yechinhu;`wrapping_add` inogadzira pointer asi ichiri kutungamira kune Undefined Maitiro kana pointer ikasarudzika kana iri kunze kwemiganhu yechinhu chakasungirirwa.
    /// [`add`] inogona kukwidziridzwa zvirinani uye nekudaro inosarudzwa mukuita-inonzwisisika kodhi.
    ///
    /// Iko kunonoka cheki kunongotarisa kukosha kweiyo pointer iyo yakatariswa, kwete iyo yepakati tsika inoshandiswa panguva yekuverenga kwemhedzisiro mhedzisiro.
    /// Semuenzaniso, `x.wrapping_add(o).wrapping_sub(o)` inogara yakafanana ne `x`.Mune mamwe mazwi, kusiya chinhu chakapihwa uyezve kuchipinda mukati gare gare kunotenderwa.
    ///
    /// Kana iwe uchida kuyambuka chinhu miganhu, kandira iyo pointer kune iyo nhamba uye ita arithmetic ipapo.
    ///
    /// [`add`]: #method.add
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// // Iterate ndichishandisa mbichana mbichana mukuwedzera kwezvinhu zviviri
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let step = 2;
    /// let end_rounded_up = ptr.wrapping_add(6);
    ///
    /// // Ichi chiuno chinopurinda "1, 3, 5, "
    /// while ptr != end_rounded_up {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_add(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_add(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset(count as isize)
    }

    /// Inoverenga zvakatemwa kubva kunongedzera uchishandisa kuputira arithmetic.
    /// (kurerukirwa kwe`. wrapping_offset ((kuverenga se isize).wrapping_neg())`)
    ///
    /// `count` iri muzvikamu zveT;semuenzaniso, `count` ye3 inomiririra pointer offset ye `3 * size_of::<T>()` byte.
    ///
    /// # Safety
    ///
    /// Uku kushanda pachako kunogara kwakachengeteka, asi kushandisa chinoguma pointer hakusi.
    ///
    /// Iyo inonongedzera pointer inoramba yakanamatira kune imwecheteyo chinhu chakapihwa icho `self` inonongedza.
    /// Inogona *kwete* kushandiswa kuwana chakasiyana chakapihwa chinhu.Ziva kuti mu Rust, yega (stack-allocated) musiyano inoonekwa sechinhu chakaparadzaniswa chakapihwa.
    ///
    /// Mune mamwe mazwi, `let z = x.wrapping_sub((x as usize) - (y as usize))` haina * kuita `z` yakafanana ne `y` kunyangwe isu tichifungidzira kuti `T` ine saizi `1` uye hapana kufashukira: `z` ichiri yakanamatira kuchinhu `x` chakanamatira, uye kuireferefeta iri Undefined Maitiro kunze kwe `x` uye `y` inongedzera muchinhu chimwe chakagoverwa.
    ///
    /// Inofananidzwa ne [`sub`], iyi nzira inononoka kuita chinodiwa chekugara mukati mechinhu chimwe chete chakapihwa: [`sub`] iri pakarepo Undefined Maitiro kana uchidarika miganhu yechinhu;`wrapping_sub` inogadzira pointer asi ichiri kutungamira kune Undefined Maitiro kana pointer ikasarudzika kana iri kunze kwemiganhu yechinhu chakasungirirwa.
    /// [`sub`] inogona kukwidziridzwa zvirinani uye nekudaro inosarudzwa mukuita-inonzwisisika kodhi.
    ///
    /// Iko kunonoka cheki kunongotarisa kukosha kweiyo pointer iyo yakatariswa, kwete iyo yepakati tsika inoshandiswa panguva yekuverenga kwemhedzisiro mhedzisiro.
    /// Semuenzaniso, `x.wrapping_add(o).wrapping_sub(o)` inogara yakafanana ne `x`.Mune mamwe mazwi, kusiya chinhu chakapihwa uyezve kuchipinda mukati gare gare kunotenderwa.
    ///
    /// Kana iwe uchida kuyambuka chinhu miganhu, kandira iyo pointer kune iyo nhamba uye ita arithmetic ipapo.
    ///
    /// [`sub`]: #method.sub
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// // Iterate ndichishandisa mbichana mbichana mukuwedzera kwezvinhu zviviri (backwards)
    /// let data = [1u8, 2, 3, 4, 5];
    /// let mut ptr: *const u8 = data.as_ptr();
    /// let start_rounded_down = ptr.wrapping_sub(2);
    /// ptr = ptr.wrapping_add(4);
    /// let step = 2;
    /// // Ichi chiuno chinopurinda "5, 3, 1, "
    /// while ptr != start_rounded_down {
    ///     unsafe {
    ///         print!("{}, ", *ptr);
    ///     }
    ///     ptr = ptr.wrapping_sub(step);
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    #[inline]
    pub const fn wrapping_sub(self, count: usize) -> Self
    where
        T: Sized,
    {
        self.wrapping_offset((count as isize).wrapping_neg())
    }

    /// Inoisa kukosha kwe pointer ku `ptr`.
    ///
    /// Kana `self` iri (fat) inonongedzera kune isina kusimbwa mhando, ichi chiitiko chinongokanganisa chikamu che pointer, nepo kune ma (thin) anonongedzera kumhando dzakakura, izvi zvine mhedzisiro imwechete seyakareruka basa.
    ///
    /// Iyo inonongedzera pointer ichave neprancance ye `val`, kureva, kune mafuta pointer, iko kushanda kwakafanana zvakafanana nekugadzira nyowani mafuta pointer ine data pointer kukosha kwe `val` asi metadata ye `self`.
    ///
    ///
    /// # Examples
    ///
    /// Iri basa rinonyanya kukosha pakubvumira byte-wise pointer arithmetic pane anokwanisa mafuta zvinongedzo.
    ///
    /// ```
    /// #![feature(set_ptr_value)]
    /// # use core::fmt::Debug;
    /// let mut arr: [i32; 3] = [1, 2, 3];
    /// let mut ptr = &mut arr[0] as *mut dyn Debug;
    /// let thin = ptr as *mut u8;
    /// unsafe {
    ///     ptr = ptr.set_ptr_value(thin.add(8));
    ///     # assert_eq!(*(ptr as *mut i32), 3);
    ///     println!("{:?}", &*ptr); // tichapurinda "3"
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "set_ptr_value", issue = "75091")]
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[inline]
    pub fn set_ptr_value(mut self, val: *mut u8) -> Self {
        let thin = &mut self as *mut *mut T as *mut *mut u8;
        // Kachengeteka: Kana paine chitupa chakatetepa, mashandiro aya akafanana
        // kune yakapusa basa.
        // Muchiitiko cheye mafuta pointer, ine yazvino mafuta pointer kurongedza kuitisa, yekutanga munda yeakadai pointer inogara iri data pointer, iyo yakapihwawo saizvozvo.
        //
        unsafe { *thin = val };
        self
    }

    /// Inoverenga kukosha kubva ku `self` pasina kuifambisa.
    /// Izvi zvinosiya ndangariro mu `self` isina kuchinjika.
    ///
    /// Ona [`ptr::read`] yezvekuchengetedza kunetsekana uye mienzaniso.
    ///
    /// [`ptr::read`]: crate::ptr::read()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read(self) -> T
    where
        T: Sized,
    {
        // KUCHENGETEKA: iye anodana anofanirwa kuchengetedza chibvumirano chekuchengetedza che ``.
        unsafe { read(self) }
    }

    /// Inoita kuverenga kwakaomarara kweiyo kukosha kubva ku `self` pasina kuifambisa.Izvi zvinosiya ndangariro mu `self` isina kuchinjika.
    ///
    /// Maitiro akasimba anoitirwa kuita pane I/O ndangariro, uye inovimbiswa kuti isazoregedzwe kana kugadziriswazve nemusanganisi pane mamwe mabasa asina kugadzikana.
    ///
    ///
    /// Ona [`ptr::read_volatile`] yezvekuchengetedza kunetsekana uye mienzaniso.
    ///
    /// [`ptr::read_volatile`]: crate::ptr::read_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn read_volatile(self) -> T
    where
        T: Sized,
    {
        // KUCHENGETEKA: iye anodana anofanirwa kuchengetedza chibvumirano chekuchengetedza che `read_volatile`.
        unsafe { read_volatile(self) }
    }

    /// Inoverenga kukosha kubva ku `self` pasina kuifambisa.
    /// Izvi zvinosiya ndangariro mu `self` isina kuchinjika.
    ///
    /// Kusiyana ne `read`, iyo pointer inogona kunge isina kuenderana.
    ///
    /// Ona [`ptr::read_unaligned`] yezvekuchengetedza kunetsekana uye mienzaniso.
    ///
    /// [`ptr::read_unaligned`]: crate::ptr::read_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_read", issue = "80377")]
    #[inline]
    pub const unsafe fn read_unaligned(self) -> T
    where
        T: Sized,
    {
        // KUCHENGETEKA: iye anodana anofanirwa kuchengetedza chibvumirano chekuchengetedza che `read_unaligned`.
        unsafe { read_unaligned(self) }
    }

    /// Makopi `count * size_of<T>` byte kubva ku `self` kusvika `dest`.
    /// Kwazviri nekwairi kuenda kunogona kusangana.
    ///
    /// NOTE: izvi zvine *zvakafanana* nharo kurongeka se [`ptr::copy`].
    ///
    /// Ona [`ptr::copy`] yezvekuchengetedza kunetsekana uye mienzaniso.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // KUCHENGETEKA: iye anodana anofanirwa kuchengetedza chibvumirano chekuchengetedza che `copy`.
        unsafe { copy(self, dest, count) }
    }

    /// Makopi `count * size_of<T>` byte kubva ku `self` kusvika `dest`.
    /// Kwayakabva nekwairi kuenda zvingasa * nyongana.
    ///
    /// NOTE: izvi zvine *zvakafanana* nharo kurongeka se [`ptr::copy_nonoverlapping`].
    ///
    /// Ona [`ptr::copy_nonoverlapping`] yezvekuchengetedza kunetsekana uye mienzaniso.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_to_nonoverlapping(self, dest: *mut T, count: usize)
    where
        T: Sized,
    {
        // KUCHENGETEKA: iye anodana anofanirwa kuchengetedza chibvumirano chekuchengetedza che `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(self, dest, count) }
    }

    /// Makopi `count * size_of<T>` byte kubva ku `src` kusvika `self`.
    /// Kwazviri nekwairi kuenda kunogona kusangana.
    ///
    /// NOTE: izvi zvine *pakatarisana* nharo kurongeka kwe [`ptr::copy`].
    ///
    /// Ona [`ptr::copy`] yezvekuchengetedza kunetsekana uye mienzaniso.
    ///
    /// [`ptr::copy`]: crate::ptr::copy()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // KUCHENGETEKA: iye anodana anofanirwa kuchengetedza chibvumirano chekuchengetedza che `copy`.
        unsafe { copy(src, self, count) }
    }

    /// Makopi `count * size_of<T>` byte kubva ku `src` kusvika `self`.
    /// Kwayakabva nekwairi kuenda zvingasa * nyongana.
    ///
    /// NOTE: izvi zvine *pakatarisana* nharo kurongeka kwe [`ptr::copy_nonoverlapping`].
    ///
    /// Ona [`ptr::copy_nonoverlapping`] yezvekuchengetedza kunetsekana uye mienzaniso.
    ///
    /// [`ptr::copy_nonoverlapping`]: crate::ptr::copy_nonoverlapping()
    #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub const unsafe fn copy_from_nonoverlapping(self, src: *const T, count: usize)
    where
        T: Sized,
    {
        // KUCHENGETEKA: iye anodana anofanirwa kuchengetedza chibvumirano chekuchengetedza che `copy_nonoverlapping`.
        unsafe { copy_nonoverlapping(src, self, count) }
    }

    /// Inoita muparadzi (kana paine) yeinongedzwa-kukosha.
    ///
    /// Ona [`ptr::drop_in_place`] yezvekuchengetedza kunetsekana uye mienzaniso.
    ///
    /// [`ptr::drop_in_place`]: crate::ptr::drop_in_place()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn drop_in_place(self) {
        // KUCHENGETEKA: iye anodana anofanirwa kuchengetedza chibvumirano chekuchengetedza che `drop_in_place`.
        unsafe { drop_in_place(self) }
    }

    /// Inonyora nzvimbo yekurangarira pamwe neakapihwa kukosha pasina kuverenga kana kudonhedza kukosha kwekare.
    ///
    ///
    /// Ona [`ptr::write`] yezvekuchengetedza kunetsekana uye mienzaniso.
    ///
    /// [`ptr::write`]: crate::ptr::write()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write(self, val: T)
    where
        T: Sized,
    {
        // KUCHENGETEKA: iye anodana anofanirwa kuchengetedza chibvumirano chekuchengetedza che `write`.
        unsafe { write(self, val) }
    }

    /// Inodenha memset pane yakatarwa pointer, kumisikidza `count * size_of::<T>()` mabheti endangariro kutanga pa `self` kusvika `val`.
    ///
    ///
    /// Ona [`ptr::write_bytes`] yezvekuchengetedza kunetsekana uye mienzaniso.
    ///
    /// [`ptr::write_bytes`]: crate::ptr::write_bytes()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_bytes(self, val: u8, count: usize)
    where
        T: Sized,
    {
        // KUCHENGETEKA: iye anodana anofanirwa kuchengetedza chibvumirano chekuchengetedza che `write_bytes`.
        unsafe { write_bytes(self, val, count) }
    }

    /// Inoita inonyora nyora yenzvimbo yekurangarira ine yakapihwa kukosha pasina kuverenga kana kudonhedza iyo yekare kukosha.
    ///
    /// Maitiro akasimba anoitirwa kuita pane I/O ndangariro, uye inovimbiswa kuti isazoregedzwe kana kugadziriswazve nemusanganisi pane mamwe mabasa asina kugadzikana.
    ///
    ///
    /// Ona [`ptr::write_volatile`] yezvekuchengetedza kunetsekana uye mienzaniso.
    ///
    /// [`ptr::write_volatile`]: crate::ptr::write_volatile()
    ///
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn write_volatile(self, val: T)
    where
        T: Sized,
    {
        // KUCHENGETEKA: iye anodana anofanirwa kuchengetedza chibvumirano chekuchengetedza che `write_volatile`.
        unsafe { write_volatile(self, val) }
    }

    /// Inonyora nzvimbo yekurangarira pamwe neakapihwa kukosha pasina kuverenga kana kudonhedza kukosha kwekare.
    ///
    ///
    /// Kusiyana ne `write`, iyo pointer inogona kunge isina kuenderana.
    ///
    /// Ona [`ptr::write_unaligned`] yezvekuchengetedza kunetsekana uye mienzaniso.
    ///
    /// [`ptr::write_unaligned`]: crate::ptr::write_unaligned()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[rustc_const_unstable(feature = "const_ptr_write", issue = "none")]
    #[inline]
    pub const unsafe fn write_unaligned(self, val: T)
    where
        T: Sized,
    {
        // KUCHENGETEKA: iye anodana anofanirwa kuchengetedza chibvumirano chekuchengetedza che `write_unaligned`.
        unsafe { write_unaligned(self, val) }
    }

    /// Inoisa kukosha pa `self` ne `src`, ichidzosa iyo yekare kukosha, pasina kudonhedza chero.
    ///
    ///
    /// Ona [`ptr::replace`] yezve kuchengetedzeka kunetseka uye mienzaniso.
    ///
    /// [`ptr::replace`]: crate::ptr::replace()
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn replace(self, src: T) -> T
    where
        T: Sized,
    {
        // KUCHENGETEKA: iye anodana anofanirwa kuchengetedza chibvumirano chekuchengetedza che `replace`.
        unsafe { replace(self, src) }
    }

    /// Inochinjisa iwo maitiro munzvimbo mbiri dzinogona kuchinjika dzerudzi rumwe chete, pasina kudzikisira chero.
    /// Dzinogona kupindirana, kusiyana ne `mem::swap` iri imwe yakafanana.
    ///
    /// Ona [`ptr::swap`] yezvekuchengetedza kunetsekana uye mienzaniso.
    ///
    /// [`ptr::swap`]: crate::ptr::swap()
    ///
    #[stable(feature = "pointer_methods", since = "1.26.0")]
    #[inline]
    pub unsafe fn swap(self, with: *mut T)
    where
        T: Sized,
    {
        // KUCHENGETEKA: iye anodana anofanirwa kuchengetedza chibvumirano chekuchengetedza che `swap`.
        unsafe { swap(self, with) }
    }

    /// Inobatanidza iyo offset iyo inoda kuiswa kune iyo pointer kuti iite ienderane ne `align`.
    ///
    /// Kana zvisingaite kuenzanisa pointer, iko kuita kunodzosera `usize::MAX`.
    /// Zvinotenderwa kuitiswa kusvika *nguva dzose* kudzoka `usize::MAX`.
    /// Kuita kwako chete kwealgorithm kunogona kuvimba nekutora chinoshandisirwa pano, kwete iko kurongeka.
    ///
    /// Iko kukanganisa kunoratidzwa muhuwandu hwe `T` zvinhu, uye kwete mabheti.Iko kukosha kwakadzoserwa kunogona kushandiswa nenzira ye `wrapping_add`.
    ///
    /// Iko hakuna vimbiso chero ipi inogumbura iyo pointer haizofashukira kana kupfuura kupfuura mugove uyo pointer inonongedzera mairi.
    ///
    /// Zviri kumunhu anenge afona kuti ave nechokwadi chekuti chakadzoserwa chakarurama mune mamwe mazwi kunze kwekuenderana.
    ///
    /// # Panics
    ///
    /// Iko basa panics kana `align` isiri simba-re-maviri.
    ///
    /// # Examples
    ///
    /// Kuwana padhuze ne `u8` se `u16`
    ///
    /// ```
    /// # fn foo(n: usize) {
    /// # use std::mem::align_of;
    /// # unsafe {
    /// let x = [5u8, 6u8, 7u8, 8u8, 9u8];
    /// let ptr = x.as_ptr().add(n) as *const u8;
    /// let offset = ptr.align_offset(align_of::<u16>());
    /// if offset < x.len() - n - 1 {
    ///     let u16_ptr = ptr.add(offset) as *const u16;
    ///     assert_ne!(*u16_ptr, 500);
    /// } else {
    ///     // nepo chinongedzo chichienderana ne `offset`, chinganongedze kunze kwechikamu
    /////
    /// }
    /// # } }
    /// ```
    ///
    ///
    ///
    #[stable(feature = "align_offset", since = "1.36.0")]
    pub fn align_offset(self, align: usize) -> usize
    where
        T: Sized,
    {
        if !align.is_power_of_two() {
            panic!("align_offset: align is not a power-of-two");
        }
        // Kachengeteka: `align` yakaongororwa kuve simba rechipiri pamusoro
        unsafe { align_offset(self, align) }
    }
}

#[lang = "mut_slice_ptr"]
impl<T> *mut [T] {
    /// Inodzorera kureba kwechinhu chisina kubikwa.
    ///
    /// Iko kwakadzoserwa kukosha ndiyo nhamba ye **zvinhu**, kwete iyo nhamba yemabheti.
    ///
    /// Iri basa rakachengetedzeka, kunyangwe kana chidimbu chisina kubikwa chisingakwanise kukandirwa kunongedzo yechidimbu nekuti chinongedzo hachina basa kana kusagadzwa.
    ///
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_len)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.len(), 3);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_len", issue = "71146")]
    #[rustc_const_unstable(feature = "const_slice_ptr_len", issue = "71146")]
    pub const fn len(self) -> usize {
        #[cfg(bootstrap)]
        {
            // KUCHENGETEKA: izvi zvakachengeteka nekuti `*const [T]` ne `FatPtr<T>` zvine marongero akafanana.
            // `std` chete ndiyo inogona kuita vimbiso iyi.
            unsafe { Repr { rust_mut: self }.raw }.len
        }
        #[cfg(not(bootstrap))]
        metadata(self)
    }

    /// Inodzosera pointer mbishi kune iyo bhaudhi bhaisikopo.
    ///
    /// Izvi zvakaenzana nekukanda `self` kusvika `*mut T`, asi zvimwe mhando-yakachengeteka.
    ///
    /// # Examples
    ///
    /// ```rust
    /// #![feature(slice_ptr_get)]
    /// use std::ptr;
    ///
    /// let slice: *mut [i8] = ptr::slice_from_raw_parts_mut(ptr::null_mut(), 3);
    /// assert_eq!(slice.as_mut_ptr(), 0 as *mut i8);
    /// ```
    #[inline]
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[rustc_const_unstable(feature = "slice_ptr_get", issue = "74265")]
    pub const fn as_mut_ptr(self) -> *mut T {
        self as *mut T
    }

    /// Inodzosera pointer mbishi kune chinhu kana subslice, pasina kuita mabound kutarisa.
    ///
    /// Kufonera iyi nzira ine kunze-kwemiganhu index kana kana `self` isinga dereferencable iri *[isina kujekeswa maitiro]* kunyangwe iyo inoguma pointer isiri kushandiswa.
    ///
    ///
    /// [undefined behavior]: https://doc.rust-lang.org/reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// let x = &mut [1, 2, 4] as *mut [i32];
    ///
    /// unsafe {
    ///     assert_eq!(x.get_unchecked_mut(1), x.as_mut_ptr().add(1));
    /// }
    /// ```
    ///
    #[unstable(feature = "slice_ptr_get", issue = "74265")]
    #[inline]
    pub unsafe fn get_unchecked_mut<I>(self, index: I) -> *mut I::Output
    where
        I: SliceIndex<[T]>,
    {
        // CHENGETEKO: anofona anoona kuti `self` haigadzirisike uye `index` iri-kumiganhu.
        unsafe { index.get_unchecked_mut(self) }
    }

    /// Inodzorera `None` kana iyo pointer isiri, kana zvimwe ichidzorera slice yakagovaniswa kune kukosha kwakaputirwa ne `Some`.
    /// Kupesana ne [`as_ref`], izvi hazvidi kuti kukosha kwacho kutange kutangwa.
    ///
    /// Kune mumwe anogona kuchinjika ona [`as_uninit_slice_mut`].
    ///
    /// [`as_ref`]: #method.as_ref-1
    /// [`as_uninit_slice_mut`]: #method.as_uninit_slice_mut
    ///
    /// # Safety
    ///
    /// Paunenge uchidana iyi nzira, unofanirwa kuona kuti *chero* iyo pointer iri NULL *kana* zvese zvinotevera ichokwadi:
    ///
    /// * Iyo pointer inofanira kunge iri [valid] yekuverengera `ptr.len() * mem::size_of::<T>()` akawanda mabheti, uye inofanirwa kunge ichinyatsoenderana.Izvi zvinoreva kunyanya:
    ///
    ///     * Iyo yese yekurangarira huwandu hweichi chidimbu chinofanirwa kunge chiri mukati mechinhu chimwe chakapihwa chinhu!
    ///       Slices haambofi akatenderera pane akawanda akagoverwa zvinhu.
    ///
    ///     * Iyo pointer inofanirwa kuenderana kunyangwe zero-kureba zvidimbu.
    ///     Chimwe chikonzero cheichi ndechekuti enum marongero ekugadzirisa anogona kuvimba nezvirevo (kusanganisira zvidimbu zvehurefu chero hupi) uchienderana uye usiri-null kuvasiyanisa kubva kune imwe data.
    ///
    ///     Iwe unogona kuwana pointer iyo inoshandiswa se `data` yemazero-kureba zvidimbu uchishandisa [`NonNull::dangling()`].
    ///
    /// * Hurefu hwese `ptr.len() * mem::size_of::<T>()` yechidimbu hachifanirwe kunge chakakura kupfuura `isize::MAX`.
    ///   Ona zvinyorwa zvekuchengetedza zve [`pointer::offset`].
    ///
    /// * Iwe unofanirwa kumisikidza Rust yekumisikidza mitemo, nekuti iyo yakadzoserwa yehupenyu `'a` yakasarudzika zvakasarudzika uye hazvireve kuti inoratidza chaiko hupenyu hwedata.
    ///   Kunyanya, kwenguva yenguva ino yehupenyu, ndangariro inonongedzerwa nechinongedzo haifanire kuchinjwa (kunze kwemukati me `UnsafeCell`).
    ///
    /// Izvi zvinoshanda kunyangwe mhedzisiro yeiyi nzira ikasashandiswa!
    ///
    /// Onawo [`slice::from_raw_parts`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice<'a>(self) -> Option<&'a [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // KUCHENGETEKA: iye anodana anofanirwa kuchengetedza chibvumirano chekuchengetedza che `as_uninit_slice`.
            Some(unsafe { slice::from_raw_parts(self as *const MaybeUninit<T>, self.len()) })
        }
    }

    /// Inodzorera `None` kana iyo pointer isina basa, kana zvikasadaro inodzosera chidimbu chakasarudzika kune kukosha kwakaputirwa ne `Some`.
    /// Kupesana ne [`as_mut`], izvi hazvidi kuti kukosha kwacho kutange kutangwa.
    ///
    /// Kune mumwe waunogovana naye ona [`as_uninit_slice`].
    ///
    /// [`as_mut`]: #method.as_mut
    /// [`as_uninit_slice`]: #method.as_uninit_slice-1
    ///
    /// # Safety
    ///
    /// Paunenge uchidana iyi nzira, unofanirwa kuona kuti *chero* iyo pointer iri NULL *kana* zvese zvinotevera ichokwadi:
    ///
    /// * Iyo pointer inofanira kunge iri [valid] yekuverenga uye inonyorera `ptr.len() * mem::size_of::<T>()` akawanda mabheti, uye inofanirwa kunge ichinyatsoenderana.Izvi zvinoreva kunyanya:
    ///
    ///     * Iyo yese yekurangarira huwandu hweichi chidimbu chinofanirwa kunge chiri mukati mechinhu chimwe chakapihwa chinhu!
    ///       Slices haambofi akatenderera pane akawanda akagoverwa zvinhu.
    ///
    ///     * Iyo pointer inofanirwa kuenderana kunyangwe zero-kureba zvidimbu.
    ///     Chimwe chikonzero cheichi ndechekuti enum marongero ekugadzirisa anogona kuvimba nezvirevo (kusanganisira zvidimbu zvehurefu chero hupi) uchienderana uye usiri-null kuvasiyanisa kubva kune imwe data.
    ///
    ///     Iwe unogona kuwana pointer iyo inoshandiswa se `data` yemazero-kureba zvidimbu uchishandisa [`NonNull::dangling()`].
    ///
    /// * Hurefu hwese `ptr.len() * mem::size_of::<T>()` yechidimbu hachifanirwe kunge chakakura kupfuura `isize::MAX`.
    ///   Ona zvinyorwa zvekuchengetedza zve [`pointer::offset`].
    ///
    /// * Iwe unofanirwa kumisikidza Rust yekumisikidza mitemo, nekuti iyo yakadzoserwa yehupenyu `'a` yakasarudzika zvakasarudzika uye hazvireve kuti inoratidza chaiko hupenyu hwedata.
    ///   Kunyanya, kwenguva yenguva ino yehupenyu, ndangariro inonongedzerwa nechinongedzo haifanirwe kuwanikwa (kuverenga kana kunyorwa) kuburikidza nechero imwe pointer.
    ///
    /// Izvi zvinoshanda kunyangwe mhedzisiro yeiyi nzira ikasashandiswa!
    ///
    /// Onawo [`slice::from_raw_parts_mut`][].
    ///
    /// [valid]: crate::ptr#safety
    ///
    ///
    ///
    ///
    ///
    ///
    #[inline]
    #[unstable(feature = "ptr_as_uninit", issue = "75402")]
    pub unsafe fn as_uninit_slice_mut<'a>(self) -> Option<&'a mut [MaybeUninit<T>]> {
        if self.is_null() {
            None
        } else {
            // KUCHENGETEKA: iye anodana anofanirwa kuchengetedza chibvumirano chekuchengetedza che `as_uninit_slice_mut`.
            Some(unsafe { slice::from_raw_parts_mut(self as *mut MaybeUninit<T>, self.len()) })
        }
    }
}

// Kuenzana kwezvinongedzo
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialEq for *mut T {
    #[inline]
    fn eq(&self, other: &*mut T) -> bool {
        *self == *other
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Eq for *mut T {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Ord for *mut T {
    #[inline]
    fn cmp(&self, other: &*mut T) -> Ordering {
        if self < other {
            Less
        } else if self == other {
            Equal
        } else {
            Greater
        }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> PartialOrd for *mut T {
    #[inline]
    fn partial_cmp(&self, other: &*mut T) -> Option<Ordering> {
        Some(self.cmp(other))
    }

    #[inline]
    fn lt(&self, other: &*mut T) -> bool {
        *self < *other
    }

    #[inline]
    fn le(&self, other: &*mut T) -> bool {
        *self <= *other
    }

    #[inline]
    fn gt(&self, other: &*mut T) -> bool {
        *self > *other
    }

    #[inline]
    fn ge(&self, other: &*mut T) -> bool {
        *self >= *other
    }
}