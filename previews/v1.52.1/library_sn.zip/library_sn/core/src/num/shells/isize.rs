//! Makondinendi eiyo poindi-saizi yakasainwa yenhamba yemhando.
//!
//! *[See also the `isize` primitive type][isize].*
//!
//! Kodhi nyowani inofanirwa kushandisa inosanganisirwa constants yakanangana neyekutanga mhando.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `isize`"
)]

int_module! { isize }