//! Makonenti eiyo 32-bit yakasainwa manhamba emhando.
//!
//! *[See also the `i32` primitive type][i32].*
//!
//! Kodhi nyowani inofanirwa kushandisa inosanganisirwa constants yakanangana neyekutanga mhando.

#![stable(feature = "rust1", since = "1.0.0")]
#![rustc_deprecated(
    since = "TBD",
    reason = "all constants in this module replaced by associated constants on `i32`"
)]

int_module! { i32 }