//! Constants yakanangana neiyo `f32` imwechete-chaiyo yakatwasuka poindi mhando.
//!
//! *[See also the `f32` primitive type][f32].*
//!
//! Masvomhu akakosha manhamba anowanikwa mune `consts` sub-module.
//!
//! Kune iwo maratidziro akatsanangurwa zvakananga mune iyi module (seakasiyana neakatsanangurwa mu `consts` sub-module), kodhi nyowani inofanira kushandisa zvinowirirana zvinotsanangurwa zvakanangana nerudzi rwe `f32`.
//!
//!
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::convert::FloatToInt;
#[cfg(not(test))]
use crate::intrinsics;
use crate::mem;
use crate::num::FpCategory;

/// Iyo radix kana hwaro hwekumiririrwa kwemukati kwe `f32`.
/// Shandisa [`f32::RADIX`] panzvimbo.
///
/// # Examples
///
/// ```rust
/// // nzira yakadzikiswa
/// # #[allow(deprecated, deprecated_in_future)]
/// let r = std::f32::RADIX;
///
/// // nzira yakatarwa
/// let r = f32::RADIX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `RADIX` associated constant on `f32`")]
pub const RADIX: u32 = f32::RADIX;

/// Nhamba yemadhigirii akakosha mu base 2.
/// Shandisa [`f32::MANTISSA_DIGITS`] panzvimbo.
///
/// # Examples
///
/// ```rust
/// // nzira yakadzikiswa
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::MANTISSA_DIGITS;
///
/// // nzira yakatarwa
/// let d = f32::MANTISSA_DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MANTISSA_DIGITS` associated constant on `f32`"
)]
pub const MANTISSA_DIGITS: u32 = f32::MANTISSA_DIGITS;

/// Huwandu hwehuwandu hwehuwandu hwakakosha mune base 10.
/// Shandisa [`f32::DIGITS`] panzvimbo.
///
/// # Examples
///
/// ```rust
/// // nzira yakadzikiswa
/// # #[allow(deprecated, deprecated_in_future)]
/// let d = std::f32::DIGITS;
///
/// // nzira yakatarwa
/// let d = f32::DIGITS;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `DIGITS` associated constant on `f32`")]
pub const DIGITS: u32 = f32::DIGITS;

/// [Machine epsilon] kukosha kwe `f32`.
/// Shandisa [`f32::EPSILON`] panzvimbo.
///
/// Uyu ndiwo mutsauko pakati pe `1.0` uye inotevera inotevera nhamba inomiririrwa.
///
/// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
///
/// # Examples
///
/// ```rust
/// // nzira yakadzikiswa
/// # #[allow(deprecated, deprecated_in_future)]
/// let e = std::f32::EPSILON;
///
/// // nzira yakatarwa
/// let e = f32::EPSILON;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `EPSILON` associated constant on `f32`"
)]
pub const EPSILON: f32 = f32::EPSILON;

/// Diki diki kupera `f32` kukosha.
/// Shandisa [`f32::MIN`] panzvimbo.
///
/// # Examples
///
/// ```rust
/// // nzira yakadzikiswa
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN;
///
/// // nzira yakatarwa
/// let min = f32::MIN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MIN` associated constant on `f32`")]
pub const MIN: f32 = f32::MIN;

/// Diki diki chaiyo yakajairwa `f32` kukosha.
/// Shandisa [`f32::MIN_POSITIVE`] panzvimbo.
///
/// # Examples
///
/// ```rust
/// // nzira yakadzikiswa
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_POSITIVE;
///
/// // nzira yakatarwa
/// let min = f32::MIN_POSITIVE;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_POSITIVE` associated constant on `f32`"
)]
pub const MIN_POSITIVE: f32 = f32::MIN_POSITIVE;

/// Yakakura kwazvo inopera `f32` kukosha.
/// Shandisa [`f32::MAX`] panzvimbo.
///
/// # Examples
///
/// ```rust
/// // nzira yakadzikiswa
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX;
///
/// // nzira yakatarwa
/// let max = f32::MAX;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `MAX` associated constant on `f32`")]
pub const MAX: f32 = f32::MAX;

/// Imwe yakakura kupfuura pasipasi inogoneka yakajairwa simba re2 exponent.
/// Shandisa [`f32::MIN_EXP`] panzvimbo.
///
/// # Examples
///
/// ```rust
/// // nzira yakadzikiswa
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_EXP;
///
/// // nzira yakatarwa
/// let min = f32::MIN_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_EXP` associated constant on `f32`"
)]
pub const MIN_EXP: i32 = f32::MIN_EXP;

/// Simba rinokwanisika simba rechipiri rinoburitsa.
/// Shandisa [`f32::MAX_EXP`] panzvimbo.
///
/// # Examples
///
/// ```rust
/// // nzira yakadzikiswa
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_EXP;
///
/// // nzira yakatarwa
/// let max = f32::MAX_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_EXP` associated constant on `f32`"
)]
pub const MAX_EXP: i32 = f32::MAX_EXP;

/// Minimum inogoneka yakajairika simba regumi exponent.
/// Shandisa [`f32::MIN_10_EXP`] panzvimbo.
///
/// # Examples
///
/// ```rust
/// // nzira yakadzikiswa
/// # #[allow(deprecated, deprecated_in_future)]
/// let min = std::f32::MIN_10_EXP;
///
/// // nzira yakatarwa
/// let min = f32::MIN_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MIN_10_EXP` associated constant on `f32`"
)]
pub const MIN_10_EXP: i32 = f32::MIN_10_EXP;

/// Simba rinokwanisika rinokwana gumi exponent.
/// Shandisa [`f32::MAX_10_EXP`] panzvimbo.
///
/// # Examples
///
/// ```rust
/// // nzira yakadzikiswa
/// # #[allow(deprecated, deprecated_in_future)]
/// let max = std::f32::MAX_10_EXP;
///
/// // nzira yakatarwa
/// let max = f32::MAX_10_EXP;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `MAX_10_EXP` associated constant on `f32`"
)]
pub const MAX_10_EXP: i32 = f32::MAX_10_EXP;

/// Kwete Nhamba (NaN).
/// Shandisa [`f32::NAN`] panzvimbo.
///
/// # Examples
///
/// ```rust
/// // nzira yakadzikiswa
/// # #[allow(deprecated, deprecated_in_future)]
/// let nan = std::f32::NAN;
///
/// // nzira yakatarwa
/// let nan = f32::NAN;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(since = "TBD", reason = "replaced by the `NAN` associated constant on `f32`")]
pub const NAN: f32 = f32::NAN;

/// Infinity (∞).
/// Shandisa [`f32::INFINITY`] panzvimbo.
///
/// # Examples
///
/// ```rust
/// // nzira yakadzikiswa
/// # #[allow(deprecated, deprecated_in_future)]
/// let inf = std::f32::INFINITY;
///
/// // nzira yakatarwa
/// let inf = f32::INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `INFINITY` associated constant on `f32`"
)]
pub const INFINITY: f32 = f32::INFINITY;

/// Negative infinity (−∞).
/// Shandisa [`f32::NEG_INFINITY`] panzvimbo.
///
/// # Examples
///
/// ```rust
/// // nzira yakadzikiswa
/// # #[allow(deprecated, deprecated_in_future)]
/// let ninf = std::f32::NEG_INFINITY;
///
/// // nzira yakatarwa
/// let ninf = f32::NEG_INFINITY;
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_deprecated(
    since = "TBD",
    reason = "replaced by the `NEG_INFINITY` associated constant on `f32`"
)]
pub const NEG_INFINITY: f32 = f32::NEG_INFINITY;

/// Yekutanga yemasvomhu nguva dzose.
#[stable(feature = "rust1", since = "1.0.0")]
pub mod consts {
    // FIXME: kutsiva nemasvomhu emanzwiro kubva cmath.

    /// Archimedes 'anogara ari (π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const PI: f32 = 3.14159265358979323846264338327950288_f32;

    /// Iyo yakazara denderedzwa inogara iri (τ)
    ///
    /// Zvakaenzana na 2π.
    #[stable(feature = "tau_constant", since = "1.47.0")]
    pub const TAU: f32 = 6.28318530717958647692528676655900577_f32;

    /// π/2
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_2: f32 = 1.57079632679489661923132169163975144_f32;

    /// π/3
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_3: f32 = 1.04719755119659774615421446109316763_f32;

    /// π/4
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_4: f32 = 0.785398163397448309615660845819875721_f32;

    /// π/6
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_6: f32 = 0.52359877559829887307710723054658381_f32;

    /// π/8
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_PI_8: f32 = 0.39269908169872415480783042290993786_f32;

    /// 1/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_PI: f32 = 0.318309886183790671537767526745028724_f32;

    /// 2/π
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_PI: f32 = 0.636619772367581343075535053490057448_f32;

    /// 2/sqrt(π)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_2_SQRT_PI: f32 = 1.12837916709551257389615890312154517_f32;

    /// sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const SQRT_2: f32 = 1.41421356237309504880168872420969808_f32;

    /// 1/sqrt(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const FRAC_1_SQRT_2: f32 = 0.707106781186547524400844362104849039_f32;

    /// Euler nhamba (e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const E: f32 = 2.71828182845904523536028747135266250_f32;

    /// log<sub>2</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG2_E: f32 = 1.44269504088896340735992468100189214_f32;

    /// log<sub>2</sub>(10)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG2_10: f32 = 3.32192809488736234787031942948939018_f32;

    /// log<sub>10</sub>(e)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LOG10_E: f32 = 0.434294481903251827651128918916605082_f32;

    /// log<sub>10</sub>(2)
    #[stable(feature = "extra_log_consts", since = "1.43.0")]
    pub const LOG10_2: f32 = 0.301029995663981195213738894724493027_f32;

    /// ln(2)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_2: f32 = 0.693147180559945309417232121458176568_f32;

    /// ln(10)
    #[stable(feature = "rust1", since = "1.0.0")]
    pub const LN_10: f32 = 2.30258509299404568401799145468436421_f32;
}

#[lang = "f32"]
#[cfg(not(test))]
impl f32 {
    /// Iyo radix kana hwaro hwekumiririrwa kwemukati kwe `f32`.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const RADIX: u32 = 2;

    /// Nhamba yemadhigirii akakosha mu base 2.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MANTISSA_DIGITS: u32 = 24;

    /// Huwandu hwehuwandu hwehuwandu hwakakosha mune base 10.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const DIGITS: u32 = 6;

    /// [Machine epsilon] kukosha kwe `f32`.
    ///
    /// Uyu ndiwo mutsauko pakati pe `1.0` uye inotevera inotevera nhamba inomiririrwa.
    ///
    /// [Machine epsilon]: https://en.wikipedia.org/wiki/Machine_epsilon
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const EPSILON: f32 = 1.19209290e-07_f32;

    /// Diki diki kupera `f32` kukosha.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN: f32 = -3.40282347e+38_f32;
    /// Diki diki chaiyo yakajairwa `f32` kukosha.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_POSITIVE: f32 = 1.17549435e-38_f32;
    /// Yakakura kwazvo inopera `f32` kukosha.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX: f32 = 3.40282347e+38_f32;

    /// Imwe yakakura kupfuura pasipasi inogoneka yakajairwa simba re2 exponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_EXP: i32 = -125;
    /// Simba rinokwanisika simba rechipiri rinoburitsa.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_EXP: i32 = 128;

    /// Minimum inogoneka yakajairika simba regumi exponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MIN_10_EXP: i32 = -37;
    /// Simba rinokwanisika rinokwana gumi exponent.
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const MAX_10_EXP: i32 = 38;

    /// Kwete Nhamba (NaN).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NAN: f32 = 0.0_f32 / 0.0_f32;
    /// Infinity (∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const INFINITY: f32 = 1.0_f32 / 0.0_f32;
    /// Negative infinity (−∞).
    #[stable(feature = "assoc_int_consts", since = "1.43.0")]
    pub const NEG_INFINITY: f32 = -1.0_f32 / 0.0_f32;

    /// Inodzorera `true` kana kukosha uku kuri `NaN`.
    ///
    /// ```
    /// let nan = f32::NAN;
    /// let f = 7.0_f32;
    ///
    /// assert!(nan.is_nan());
    /// assert!(!f.is_nan());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_nan(self) -> bool {
        self != self
    }

    // FIXME(#50145): `abs` haiwanikwe pachena mu libcore nekuda kwekunetseka nezve kutakurika, saka kuita uku ndekwekushandisa wega mukati.
    //
    //
    #[inline]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    const fn abs_private(self) -> f32 {
        f32::from_bits(self.to_bits() & 0x7fff_ffff)
    }

    /// Inodzorera `true` kana kukosha uku kuri infinity kana kusingaite infinity, uye `false` neimwe nzira.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(!f.is_infinite());
    /// assert!(!nan.is_infinite());
    ///
    /// assert!(inf.is_infinite());
    /// assert!(neg_inf.is_infinite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_infinite(self) -> bool {
        self.abs_private() == Self::INFINITY
    }

    /// Inodzorera `true` kana nhamba iyi isinga peri kana `NaN`.
    ///
    /// ```
    /// let f = 7.0f32;
    /// let inf = f32::INFINITY;
    /// let neg_inf = f32::NEG_INFINITY;
    /// let nan = f32::NAN;
    ///
    /// assert!(f.is_finite());
    ///
    /// assert!(!nan.is_finite());
    /// assert!(!inf.is_finite());
    /// assert!(!neg_inf.is_finite());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_finite(self) -> bool {
        // Iko hakuna kudikanwa kwekubata NaN zvakasiyana: kana pachako kuri NaN, kuenzanisa hakusi kwechokwadi, chaizvo sezvaidiwa.
        //
        self.abs_private() < Self::INFINITY
    }

    /// Inodzorera `true` kana nhamba iri [subnormal].
    ///
    /// ```
    /// #![feature(is_subnormal)]
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(!min.is_subnormal());
    /// assert!(!max.is_subnormal());
    ///
    /// assert!(!zero.is_subnormal());
    /// assert!(!f32::NAN.is_subnormal());
    /// assert!(!f32::INFINITY.is_subnormal());
    /// // Maitiro pakati pe `0` ne `min` haana kujairika.
    /// assert!(lower_than_min.is_subnormal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[unstable(feature = "is_subnormal", issue = "79288")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_subnormal(self) -> bool {
        matches!(self.classify(), FpCategory::Subnormal)
    }

    /// Inodzorera `true` kana nhamba isiri zero, isingagumi, [subnormal], kana `NaN`.
    ///
    ///
    /// ```
    /// let min = f32::MIN_POSITIVE; // 1.17549435e-38f32
    /// let max = f32::MAX;
    /// let lower_than_min = 1.0e-40_f32;
    /// let zero = 0.0_f32;
    ///
    /// assert!(min.is_normal());
    /// assert!(max.is_normal());
    ///
    /// assert!(!zero.is_normal());
    /// assert!(!f32::NAN.is_normal());
    /// assert!(!f32::INFINITY.is_normal());
    /// // Maitiro pakati pe `0` ne `min` haana kujairika.
    /// assert!(!lower_than_min.is_normal());
    /// ```
    /// [subnormal]: https://en.wikipedia.org/wiki/Denormal_number
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_normal(self) -> bool {
        matches!(self.classify(), FpCategory::Normal)
    }

    /// Inodzorera iyo inoyerera poindi chikamu cheiyo nhamba.
    /// Kana chivakwa chimwe chete chiri kuzoedzwa, zvinowanzo mhanyisa kushandisa chirevo chakatarwa pachinzvimbo.
    ///
    ///
    /// ```
    /// use std::num::FpCategory;
    ///
    /// let num = 12.4_f32;
    /// let inf = f32::INFINITY;
    ///
    /// assert_eq!(num.classify(), FpCategory::Normal);
    /// assert_eq!(inf.classify(), FpCategory::Infinite);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    pub const fn classify(self) -> FpCategory {
        const EXP_MASK: u32 = 0x7f800000;
        const MAN_MASK: u32 = 0x007fffff;

        let bits = self.to_bits();
        match (bits & MAN_MASK, bits & EXP_MASK) {
            (0, 0) => FpCategory::Zero,
            (_, 0) => FpCategory::Subnormal,
            (0, EXP_MASK) => FpCategory::Infinite,
            (_, EXP_MASK) => FpCategory::Nan,
            _ => FpCategory::Normal,
        }
    }

    /// Inodzorera `true` kana `self` iine chiratidzo chakanakisa, kusanganisira `+0.0`, `NaNs ine yakanaka chiratidzo chidiki uye yakanaka infinity.
    ///
    ///
    /// ```
    /// let f = 7.0_f32;
    /// let g = -7.0_f32;
    ///
    /// assert!(f.is_sign_positive());
    /// assert!(!g.is_sign_positive());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_positive(self) -> bool {
        !self.is_sign_negative()
    }

    /// Inodzorera `true` kana `self` iine chiratidzo chisina kunaka, kusanganisira `-0.0`, `NaN` ine isina chiratidzo chiratidzo uye isina infinity.
    ///
    ///
    /// ```
    /// let f = 7.0f32;
    /// let g = -7.0f32;
    ///
    /// assert!(!f.is_sign_negative());
    /// assert!(g.is_sign_negative());
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[rustc_const_unstable(feature = "const_float_classify", issue = "72505")]
    #[inline]
    pub const fn is_sign_negative(self) -> bool {
        // IEEE754 inoti: isSignMinus(x) ichokwadi kana uye chete kana x ine chiratidzo chisina kunaka.
        // isSignMinus inoshanda kune zeros neNaNs futi.
        self.to_bits() & 0x8000_0000 != 0
    }

    /// Inotora iyo inodzosera (inverse) yenhamba, `1/x`.
    ///
    /// ```
    /// let x = 2.0_f32;
    /// let abs_difference = (x.recip() - (1.0 / x)).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn recip(self) -> f32 {
        1.0 / self
    }

    /// Inoshandura radians kuita madhigirii.
    ///
    /// ```
    /// let angle = std::f32::consts::PI;
    ///
    /// let abs_difference = (angle.to_degrees() - 180.0).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_degrees(self) -> f32 {
        // Shandisa zvinogara zvichitaurwa zviri nani.
        const PIS_IN_180: f32 = 57.2957795130823208767981548141051703_f32;
        self * PIS_IN_180
    }

    /// Inoshandura madhigirii kuita radians.
    ///
    /// ```
    /// let angle = 180.0f32;
    ///
    /// let abs_difference = (angle.to_radians() - std::f32::consts::PI).abs();
    ///
    /// assert!(abs_difference <= f32::EPSILON);
    /// ```
    #[stable(feature = "f32_deg_rad_conversions", since = "1.7.0")]
    #[inline]
    pub fn to_radians(self) -> f32 {
        let value: f32 = consts::PI;
        self * (value / 180.0f32)
    }

    /// Inodzorera huwandu hwenhamba mbiri.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.max(y), y);
    /// ```
    ///
    /// Kana imwe yenharo iri NaN, saka imwe nharo inodzoserwa.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn max(self, other: f32) -> f32 {
        intrinsics::maxnumf32(self, other)
    }

    /// Inodzorera hushoma hwenhamba mbiri.
    ///
    /// ```
    /// let x = 1.0f32;
    /// let y = 2.0f32;
    ///
    /// assert_eq!(x.min(y), x);
    /// ```
    ///
    /// Kana imwe yenharo iri NaN, saka imwe nharo inodzoserwa.
    #[stable(feature = "rust1", since = "1.0.0")]
    #[inline]
    pub fn min(self, other: f32) -> f32 {
        intrinsics::minnumf32(self, other)
    }

    /// Inotenderera yakananga zero uye inoshandura kuenda kune chero yechinyakare manhamba erudzi, uchifungidzira kuti kukosha kwacho kwapera uye kunoenderana nerudzi irworwo.
    ///
    ///
    /// ```
    /// let value = 4.6_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<u16>() };
    /// assert_eq!(rounded, 4);
    ///
    /// let value = -128.9_f32;
    /// let rounded = unsafe { value.to_int_unchecked::<i8>() };
    /// assert_eq!(rounded, i8::MIN);
    /// ```
    ///
    /// # Safety
    ///
    /// Iko kukosha kunofanirwa:
    ///
    /// * Kwete kuva `NaN`
    /// * Kwete kusaguma
    /// * Iva anomiririrwa nerudzi rwekudzoka `Int`, mushure mekubvisa chikamu chayo chidiki
    #[stable(feature = "float_approx_unchecked_to", since = "1.44.0")]
    #[inline]
    pub unsafe fn to_int_unchecked<Int>(self) -> Int
    where
        Self: FloatToInt<Int>,
    {
        // KUCHENGETEKA: iye anodana anofanirwa kuchengetedza chibvumirano chekuchengetedza che `FloatToInt::to_int_unchecked`.
        //
        unsafe { FloatToInt::<Int>::to_int_unchecked(self) }
    }

    /// Raw transmutation ku `u32`.
    ///
    /// Izvi parizvino zvakafanana ne `transmute::<f32, u32>(self)` pane ese mapuratifomu.
    ///
    /// Ona `from_bits` kune imwe nhaurirano yekutakurika kwechiitiko ichi (panenge pasina nyaya).
    ///
    /// Ziva kuti basa iri rakasiyana ne `as` kukanda, kunoedza kuchengetedza iyo *nhamba* kukosha, uye kwete iyo bitwise kukosha.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// assert_ne!((1f32).to_bits(), 1f32 as u32); // to_bits() haasi kukanda!
    /// assert_eq!((12.5f32).to_bits(), 0x41480000);
    ///
    /// ```
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_bits(self) -> u32 {
        // KUCHENGETEKA: `u32` iri pachena dhatatype rekare saka tinogona kugara tichipfuudza kwariri
        unsafe { mem::transmute(self) }
    }

    /// Raw transmutation kubva ku `u32`.
    ///
    /// Izvi parizvino zvakafanana ne `transmute::<u32, f32>(v)` pane ese mapuratifomu.
    /// Zvinoitika izvi zvinotakurika zvinoshamisa, nekuda kwezvikonzero zviviri:
    ///
    /// * Mafuro uye maInt ane hukama hwakaenzana pane ese mapuratifomu akatsigirwa.
    /// * IEEE-754 inonyatso tsanangudza iyo diki mamisirwo emafloats.
    ///
    /// Nekudaro pane imwe bakoat: pamberi peiyo 2008 vhezheni yeIEEE-754, maitiro ekududzira iyo NaN yekuisa chiratidzo ikasati yanyatso tsanangurwa.
    /// Mazhinji mapuratifomu (kunyanya x86 neARM) akasarudza dudziro iyo yakazove yakamisikidzwa muna2008, asi vamwe havana (kunyanya MIPS).
    /// Nekuda kweizvozvo, ese maNaNs anoratidza pa MIPS akanyarara NaNs pa x86, uye zvinopesana.
    ///
    /// Panzvimbo pekuyedza kuchengetedza kusaina-ness muchinjika-chikuva, kumisikidza uku kunofarira kuchengetedza mabheti chaiwo.
    /// Izvi zvinoreva kuti chero mubhadharo wakabhadharwa muNaN unochengetedzwa kunyangwe mhedzisiro yenzira iyi ikatumirwa pamusoro peneti kubva kumuchina we x86 kuenda ku MIPS imwe.
    ///
    ///
    /// Kana mhedzisiro yenzira iyi ikangoshandiswa neyakavakwa imwechete iyo yakavagadzira, saka hapana chinotakurika chinotakurika.
    ///
    /// Kana iko kuiswa kusiri NaN, saka hapana chinotakurika chinotakurika.
    ///
    /// Kana iwe usina hanya nekuratidzira (zvingangoita), saka hapana chinotakurika chinotakurika.
    ///
    /// Ziva kuti basa iri rakasiyana ne `as` kukanda, kunoedza kuchengetedza iyo *nhamba* kukosha, uye kwete iyo bitwise kukosha.
    ///
    /// # Examples
    ///
    /// ```
    /// let v = f32::from_bits(0x41480000);
    /// assert_eq!(v, 12.5);
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "float_bits_conv", since = "1.20.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_bits(v: u32) -> Self {
        // Kachengeteka: `u32` yakajeka dhatatype dhata saka tinogona kugara tichipfuudza kubva pairi
        // Zvinoitika kuti nyaya dzekuchengetedza ne sNaN dzaive dzakawandisa!Hooray!
        unsafe { mem::transmute(v) }
    }

    /// Dzorera iyo yekumiririra inomiririra iyi inoyerera poindi nhamba seyaka byte mune hombe-endian (network) byte odha.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_be_bytes();
    /// assert_eq!(bytes, [0x41, 0x48, 0x00, 0x00]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_be_bytes(self) -> [u8; 4] {
        self.to_bits().to_be_bytes()
    }

    /// Dzorera iyo yekumiririra inomiririra iyi inoyerera poindi yenhamba seye byte yakarongeka mune diki-endian byte odha.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_le_bytes();
    /// assert_eq!(bytes, [0x00, 0x00, 0x48, 0x41]);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_le_bytes(self) -> [u8; 4] {
        self.to_bits().to_le_bytes()
    }

    /// Dzorera iyo yekumiririra inomiririra iyi inoyerera poindi yenhamba seye byte yakarongeka mune yemuno byte odha.
    ///
    /// Sekushandisa kwepuratifomu yechinyakare chikuva, inotakurika kodhi inofanirwa kushandisa [`to_be_bytes`] kana [`to_le_bytes`], sezvazvinokodzera, pachinzvimbo.
    ///
    ///
    /// [`to_be_bytes`]: f32::to_be_bytes
    /// [`to_le_bytes`]: f32::to_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let bytes = 12.5f32.to_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         [0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         [0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn to_ne_bytes(self) -> [u8; 4] {
        self.to_bits().to_ne_bytes()
    }

    /// Dzorera iyo yekumiririra inomiririra iyi inoyerera poindi yenhamba seye byte yakarongeka mune yemuno byte odha.
    ///
    ///
    /// [`to_ne_bytes`] inofanirwa kusarudzwa pane izvi pese pazvinogoneka.
    ///
    /// [`to_ne_bytes`]: f32::to_ne_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(num_as_ne_bytes)]
    /// let num = 12.5f32;
    /// let bytes = num.as_ne_bytes();
    /// assert_eq!(
    ///     bytes,
    ///     if cfg!(target_endian = "big") {
    ///         &[0x41, 0x48, 0x00, 0x00]
    ///     } else {
    ///         &[0x00, 0x00, 0x48, 0x41]
    ///     }
    /// );
    /// ```
    #[unstable(feature = "num_as_ne_bytes", issue = "76976")]
    #[inline]
    pub fn as_ne_bytes(&self) -> &[u8; 4] {
        // KUCHENGETEKA: `f32` iri pachena dhatatype rekare saka tinogona kugara tichipfuudza kwariri
        unsafe { &*(self as *const Self as *const _) }
    }

    /// Gadzira inoyerera poindi kukosha kubva kune inomiririra seye byte yakarongeka mune hombe endian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_be_bytes([0x41, 0x48, 0x00, 0x00]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_be_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_be_bytes(bytes))
    }

    /// Gadzira inoyerera poindi kukosha kubva kune inomiririra seye byte yakarongedzwa mune mashoma endian.
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_le_bytes([0x00, 0x00, 0x48, 0x41]);
    /// assert_eq!(value, 12.5);
    /// ```
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_le_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_le_bytes(bytes))
    }

    /// Gadzira inoyerera poindi poindi kubva kumiriri kwayo seye byte yakarongeka mune yemuno endian.
    ///
    /// Sezvo chinongedzo chepuratifomu endianness ichishandiswa, inotakurika kodhi ingangoda kushandisa [`from_be_bytes`] kana [`from_le_bytes`], sezvakakodzera panzvimbo.
    ///
    ///
    /// [`from_be_bytes`]: f32::from_be_bytes
    /// [`from_le_bytes`]: f32::from_le_bytes
    ///
    /// # Examples
    ///
    /// ```
    /// let value = f32::from_ne_bytes(if cfg!(target_endian = "big") {
    ///     [0x41, 0x48, 0x00, 0x00]
    /// } else {
    ///     [0x00, 0x00, 0x48, 0x41]
    /// });
    /// assert_eq!(value, 12.5);
    /// ```
    ///
    #[stable(feature = "float_to_from_bytes", since = "1.40.0")]
    #[rustc_const_unstable(feature = "const_float_bits_conv", issue = "72447")]
    #[inline]
    pub const fn from_ne_bytes(bytes: [u8; 4]) -> Self {
        Self::from_bits(u32::from_ne_bytes(bytes))
    }

    /// Inodzorera odha pakati peako nehumwe hunhu.
    /// Kusiyana neyakajairwa chikamu kuenzanisa pakati penzvimbo dzinoyerera, iyi enzaniso inogara ichiburitsa kuodha zvinoenderana neiyo yakazaraOrder chirevo sekutsanangurwa muIEEE 754 (2008 kudzokorora) inoyerera poindi.
    /// Maitiro akarairwa nenzira inotevera.
    /// - Negative yakanyarara NaN
    /// - Kuipa kusaina NaN
    /// - Kusakwana kusingaperi
    /// - Nhamba dzisina kunaka
    /// - Nhamba dzakasarudzika dzisina kujairika
    /// - Negative zero
    /// - Positive zero
    /// - Nhamba dzakanaka dzisina kujairika
    /// - Nhamba dzakanaka
    /// - Positive infinity
    /// - Yakanaka kuratidza NaN
    /// - Yakanyarara yakanyarara NaN
    ///
    /// Ziva kuti basa iri harigare richienderana ne [`PartialOrd`] uye [`PartialEq`] kuitiswa kwe `f32`.Kunyanya, ivo vanoona isina kunaka uye yakanaka zero seyakaenzana, nepo `total_cmp` isingaiti.
    ///
    /// # Example
    ///
    /// ```
    /// #![feature(total_cmp)]
    /// struct GoodBoy {
    ///     name: String,
    ///     weight: f32,
    /// }
    ///
    /// let mut bois = vec![
    ///     GoodBoy { name: "Pucci".to_owned(), weight: 0.1 },
    ///     GoodBoy { name: "Woofer".to_owned(), weight: 99.0 },
    ///     GoodBoy { name: "Yapper".to_owned(), weight: 10.0 },
    ///     GoodBoy { name: "Chonk".to_owned(), weight: f32::INFINITY },
    ///     GoodBoy { name: "Abs. Unit".to_owned(), weight: f32::NAN },
    ///     GoodBoy { name: "Floaty".to_owned(), weight: -5.0 },
    /// ];
    ///
    /// bois.sort_by(|a, b| a.weight.total_cmp(&b.weight));
    /// # assert!(bois.into_iter().map(|b| b.weight)
    /// #     .zip([-5.0, 0.1, 10.0, 99.0, f32::INFINITY, f32::NAN].iter())
    /// #     .all(|(a, b)| a.to_bits() == b.to_bits()))
    /// ```
    ///
    ///
    ///
    #[unstable(feature = "total_cmp", issue = "72599")]
    #[inline]
    pub fn total_cmp(&self, other: &Self) -> crate::cmp::Ordering {
        let mut left = self.to_bits() as i32;
        let mut right = other.to_bits() as i32;

        // Kana paine zvakaipa, flip mabhii ese kunze kwechiratidzo kuti uwane iwo marongero akafanana seaviri anokwenenzvera manhamba
        //
        // Nei izvi zvichishanda?IEEE 754 inoyangarara ine minda mitatu:
        // Saina bit, exponent uye mantissa.Iyo seti yeanoburitsa uye mantissa minda seyese ine iyo chivakwa iyo yavo yakatarwa kurongeka yakaenzana neiyo huwandu hukuru uko ukuru hunotsanangurwa.
        // Iko kukura hakuwanzo kutsanangurwa pane NaN kukosha, asi IEEE 754 yakazaraOrder inotsanangudza iyo NaN tsika zvakare kuteedzera zvishoma kuita kurongeka.Izvi zvinotungamira kuodha yakatsanangurwa mune iyo doc chirevo.
        // Nekudaro, iyo inomiririra hukuru hwakaenzana nenhamba dzisina kunaka uye dzakanaka-chete chiratidzo chidiki chakasiyana.
        // Kuti tienzanise zvirinyore zvakayangarara senhamba dzakasainwa, tinofanirwa kupuruzira mabhenefiti uye mantissa mabhii kana paine nhamba dzisina kunaka.
        // Isu tinonyatso shandura manhamba kuita "two's complement" fomu.
        //
        // Kuti uite kubhenekera, isu tinogadzira mask uye XOR tichipesana nayo.
        // Isu hatina mataundi kuverenga "all-ones except for the sign bit" masiki kubva kune yakasainwa-yakasainwa kukosha: kurudyi kusuduruka chiratidzo-kunotambanudzira iyo nhamba, saka isu "fill" masiki nemasaini mabhii, uye tobva tashandura kuenda kune unsigned kusundira imwezve zero zvishoma.
        //
        // Pamusoro pezvakanaka tsika, iyo mask ese zero, saka haina-op.
        //
        //
        //
        //
        //
        //
        //
        //
        //
        left ^= (((left >> 31) as u32) >> 1) as i32;
        right ^= (((right >> 31) as u32) >> 1) as i32;

        left.cmp(&right)
    }

    /// Dzivirira kukosha kune imwe nguva kunze kwekunge iri NaN.
    ///
    /// Inodzorera `max` kana `self` yakakura kudarika `max`, uye `min` kana `self` iri pasi pe `min`.
    /// Zvikasadaro izvi zvinodzosera `self`.
    ///
    /// Ziva kuti basa iri rinodzosa NaN kana kukosha kwekutanga kwaive NaN futi.
    ///
    /// # Panics
    ///
    /// Panics kana `min > max`, `min` iri NaN, kana `max` iri NaN.
    ///
    /// # Examples
    ///
    /// ```
    /// assert!((-3.0f32).clamp(-2.0, 1.0) == -2.0);
    /// assert!((0.0f32).clamp(-2.0, 1.0) == 0.0);
    /// assert!((2.0f32).clamp(-2.0, 1.0) == 1.0);
    /// assert!((f32::NAN).clamp(-2.0, 1.0).is_nan());
    /// ```
    ///
    #[must_use = "method returns a new number and does not mutate the original value"]
    #[stable(feature = "clamp", since = "1.50.0")]
    #[inline]
    pub fn clamp(self, min: f32, max: f32) -> f32 {
        assert!(min <= max);
        let mut x = self;
        if x < min {
            x = min;
        }
        if x > max {
            x = max;
        }
        x
    }
}