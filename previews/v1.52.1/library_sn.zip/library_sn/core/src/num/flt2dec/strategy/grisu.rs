//! Rust kuchinjiswa kweiyo Grisu3 algorithm yakatsanangurwa mu "Printing Floating-Point Manhamba nekukurumidza uye nenzira kwayo neveNhamba" [^ 1].
//! Iyo inoshandisa ingangoita 1KB yetafura yakamisikidzwa, uyezve, inokurumidza kwazvo kune zvakawanda zvigadzirwa.
//!
//! [^1]: Florian Loitsch.2010. Kudhinda zvinoyerera-poindi manhamba nekukurumidza uye
//!   chaizvo nenhamba.SIGPLAN Kwete.45, 6 (Chikumi 2010), 233-243.
//!

use crate::mem::MaybeUninit;
use crate::num::diy_float::Fp;
use crate::num::flt2dec::{round_up, Decoded, MAX_SIG_DIGITS};

// ona zvirevo mu `format_shortest_opt` zvechirevo.
#[doc(hidden)]
pub const ALPHA: i16 = -60;
#[doc(hidden)]
pub const GAMMA: i16 = -32;

/*
# the following Python code generates this table:
for i in xrange(-308, 333, 8):
    if i >= 0: f = 10**i; e = 0
    else: f = 2**(80-4*i) // 10 **-i;e=4* ini, makumi masere
    l = f.bit_length()
    f = ((f << 64 >> (l-1)) + 1) >> 1; e += l - 64
    print '    (%#018x, %5d, %4d),' % (f, e, i)
*/

#[doc(hidden)]
pub static CACHED_POW10: [(u64, i16, i16); 81] = [
    // (f, e, k)
    (0xe61acf033d1a45df, -1087, -308),
    (0xab70fe17c79ac6ca, -1060, -300),
    (0xff77b1fcbebcdc4f, -1034, -292),
    (0xbe5691ef416bd60c, -1007, -284),
    (0x8dd01fad907ffc3c, -980, -276),
    (0xd3515c2831559a83, -954, -268),
    (0x9d71ac8fada6c9b5, -927, -260),
    (0xea9c227723ee8bcb, -901, -252),
    (0xaecc49914078536d, -874, -244),
    (0x823c12795db6ce57, -847, -236),
    (0xc21094364dfb5637, -821, -228),
    (0x9096ea6f3848984f, -794, -220),
    (0xd77485cb25823ac7, -768, -212),
    (0xa086cfcd97bf97f4, -741, -204),
    (0xef340a98172aace5, -715, -196),
    (0xb23867fb2a35b28e, -688, -188),
    (0x84c8d4dfd2c63f3b, -661, -180),
    (0xc5dd44271ad3cdba, -635, -172),
    (0x936b9fcebb25c996, -608, -164),
    (0xdbac6c247d62a584, -582, -156),
    (0xa3ab66580d5fdaf6, -555, -148),
    (0xf3e2f893dec3f126, -529, -140),
    (0xb5b5ada8aaff80b8, -502, -132),
    (0x87625f056c7c4a8b, -475, -124),
    (0xc9bcff6034c13053, -449, -116),
    (0x964e858c91ba2655, -422, -108),
    (0xdff9772470297ebd, -396, -100),
    (0xa6dfbd9fb8e5b88f, -369, -92),
    (0xf8a95fcf88747d94, -343, -84),
    (0xb94470938fa89bcf, -316, -76),
    (0x8a08f0f8bf0f156b, -289, -68),
    (0xcdb02555653131b6, -263, -60),
    (0x993fe2c6d07b7fac, -236, -52),
    (0xe45c10c42a2b3b06, -210, -44),
    (0xaa242499697392d3, -183, -36),
    (0xfd87b5f28300ca0e, -157, -28),
    (0xbce5086492111aeb, -130, -20),
    (0x8cbccc096f5088cc, -103, -12),
    (0xd1b71758e219652c, -77, -4),
    (0x9c40000000000000, -50, 4),
    (0xe8d4a51000000000, -24, 12),
    (0xad78ebc5ac620000, 3, 20),
    (0x813f3978f8940984, 30, 28),
    (0xc097ce7bc90715b3, 56, 36),
    (0x8f7e32ce7bea5c70, 83, 44),
    (0xd5d238a4abe98068, 109, 52),
    (0x9f4f2726179a2245, 136, 60),
    (0xed63a231d4c4fb27, 162, 68),
    (0xb0de65388cc8ada8, 189, 76),
    (0x83c7088e1aab65db, 216, 84),
    (0xc45d1df942711d9a, 242, 92),
    (0x924d692ca61be758, 269, 100),
    (0xda01ee641a708dea, 295, 108),
    (0xa26da3999aef774a, 322, 116),
    (0xf209787bb47d6b85, 348, 124),
    (0xb454e4a179dd1877, 375, 132),
    (0x865b86925b9bc5c2, 402, 140),
    (0xc83553c5c8965d3d, 428, 148),
    (0x952ab45cfa97a0b3, 455, 156),
    (0xde469fbd99a05fe3, 481, 164),
    (0xa59bc234db398c25, 508, 172),
    (0xf6c69a72a3989f5c, 534, 180),
    (0xb7dcbf5354e9bece, 561, 188),
    (0x88fcf317f22241e2, 588, 196),
    (0xcc20ce9bd35c78a5, 614, 204),
    (0x98165af37b2153df, 641, 212),
    (0xe2a0b5dc971f303a, 667, 220),
    (0xa8d9d1535ce3b396, 694, 228),
    (0xfb9b7cd9a4a7443c, 720, 236),
    (0xbb764c4ca7a44410, 747, 244),
    (0x8bab8eefb6409c1a, 774, 252),
    (0xd01fef10a657842c, 800, 260),
    (0x9b10a4e5e9913129, 827, 268),
    (0xe7109bfba19c0c9d, 853, 276),
    (0xac2820d9623bf429, 880, 284),
    (0x80444b5e7aa7cf85, 907, 292),
    (0xbf21e44003acdd2d, 933, 300),
    (0x8e679c2f5e44ff8f, 960, 308),
    (0xd433179d9c8cb841, 986, 316),
    (0x9e19db92b4e31ba9, 1013, 324),
    (0xeb96bf6ebadf77d9, 1039, 332),
];

#[doc(hidden)]
pub const CACHED_POW10_FIRST_E: i16 = -1087;
#[doc(hidden)]
pub const CACHED_POW10_LAST_E: i16 = 1039;

#[doc(hidden)]
pub fn cached_power(alpha: i16, gamma: i16) -> (i16, Fp) {
    let offset = CACHED_POW10_FIRST_E as i32;
    let range = (CACHED_POW10.len() as i32) - 1;
    let domain = (CACHED_POW10_LAST_E - CACHED_POW10_FIRST_E) as i32;
    let idx = ((gamma as i32) - offset) * range / domain;
    let (f, e, k) = CACHED_POW10[idx as usize];
    debug_assert!(alpha <= e && e <= gamma);
    (k, Fp { f, e })
}

/// Kupiwa `x > 0`, inodzosera `(k, 10^k)` yakadai kuti `10^k <= x < 10^(k+1)`.
#[doc(hidden)]
pub fn max_pow10_no_more_than(x: u32) -> (u8, u32) {
    debug_assert!(x > 0);

    const X9: u32 = 10_0000_0000;
    const X8: u32 = 1_0000_0000;
    const X7: u32 = 1000_0000;
    const X6: u32 = 100_0000;
    const X5: u32 = 10_0000;
    const X4: u32 = 1_0000;
    const X3: u32 = 1000;
    const X2: u32 = 100;
    const X1: u32 = 10;

    if x < X4 {
        if x < X2 {
            if x < X1 { (0, 1) } else { (1, X1) }
        } else {
            if x < X3 { (2, X2) } else { (3, X3) }
        }
    } else {
        if x < X6 {
            if x < X5 { (4, X4) } else { (5, X5) }
        } else if x < X8 {
            if x < X7 { (6, X6) } else { (7, X7) }
        } else {
            if x < X9 { (8, X8) } else { (9, X9) }
        }
    }
}

/// Ipfupi modhi kuitiswa kweGrisu.
///
/// Iyo inodzosera `None` apo yaizodzosera inexact inomiririra neimwe nzira.
pub fn format_shortest_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.minus > 0);
    assert!(d.plus > 0);
    assert!(d.mant.checked_add(d.plus).is_some());
    assert!(d.mant.checked_sub(d.minus).is_some());
    assert!(buf.len() >= MAX_SIG_DIGITS);
    assert!(d.mant + d.plus < (1 << 61)); // isu tinoda anokwana matatu mabiti ezvekuwedzera kunyatso

    // tanga neakajairwa kukosha neakagovaniswa exponent
    let plus = Fp { f: d.mant + d.plus, e: d.exp }.normalize();
    let minus = Fp { f: d.mant - d.minus, e: d.exp }.normalize_to(plus.e);
    let v = Fp { f: d.mant, e: d.exp }.normalize_to(plus.e);

    // tsvaga chero `cached = 10^minusk` yakadai kuti `ALPHA <= minusk + plus.e + 64 <= GAMMA`.
    // sezvo `plus` yakajairwa, izvi zvinoreva `2^(62 + ALPHA) <= plus * cached < 2^(64 + GAMMA)`;
    // tichipa sarudzo dzedu dze `ALPHA` uye `GAMMA`, izvi zvinoisa `plus * cached` mu `[4, 2^32)`.
    //
    // zviri pachena kuti zvinoda kuwedzera `GAMMA - ALPHA`, kuti tirege kuda akawanda akachengetedzwa masimba gumi, asi pane zvimwe zvekufunga.
    //
    //
    // 1. isu tinoda kuchengeta `floor(plus * cached)` mukati me `u32` sezvo ichida chikamu chinodhura.
    //    (izvi hazvinyatso kudzivirirwa, zvasara zvinotarisirwa kuti zvive nemazvo fungidziro.)
    // 2.
    // iyo yasara ye `floor(plus * cached)` inowedzerwazve ne10, uye haifanire kufashukira.
    //
    // yekutanga inopa `64 + GAMMA <= 32`, nepo yechipiri ichipa `10 * 2^-ALPHA <= 2^64`;
    // -60 uye -32 ndiyo yakanyanya kuwanda renji neichi chipingaidzo, uye V8 inoishandisawo.
    let (minusk, cached) = cached_power(ALPHA - plus.e - 64, GAMMA - plus.e - 64);

    // chiyero fps.izvi zvinopa kukanganisa kukuru kwe1 ulp (yakaratidza kubva kuTheorem 5.1).
    let plus = plus.mul(&cached);
    let minus = minus.mul(&cached);
    let v = v.mul(&cached);
    debug_assert_eq!(plus.e, minus.e);
    debug_assert_eq!(plus.e, v.e);

    // +-chaiyo renji yekubvisa
    //   | <---|---------------------- unsafe region --------------------------> |
    //   |     |                                                                 |
    //   |  |<--->|  | <--------------- safe region ---------------> |           |
    //   |  |     |  |                                               |           |
    //   | 1 ulp | 1 ulp || 1 ulp | 1 ulp || 1 ulp | 1 ulp |
    //   |<--->|<--->|                 |<--->|<--->|                 |<--->|<--->|
    //   |-----|-----|-------...-------|-----|-----|-------...-------|-----|-----|
    //   |   minus   |                 |     v     |                 |   plus    | minus1     minus0           v - 1 ulp   v + 1 ulp           plus0       plus1
    //
    //
    // pamusoro pe `minus`, `v` uye `plus` ari *akaenzana* fungidziro (kukanganisa <1 ulp).
    // sezvo isu tisingazive iko kukanganisa kuri kwakanaka kana kushata, isu tinoshandisa maenzanisi maviri akapatsanurwa zvakaenzana uye tine yakanyanya kukanganisa ye2 ulps.
    //
    // iyo "unsafe region" inguva yakasununguka yatinotanga kugadzira.
    // iyo "safe region" inguva yekuchengetedza yatinongogamuchira chete.
    // isu tinotanga neiyo chaiyo repr mukati isina kuchengetedzeka dunhu, uye edza kutsvaga repedyo repr ku `v` iri mukati medunhu rakachengeteka.
    // kana tisingakwanise, tinorega.
    //
    let plus1 = plus.f + 1;
    // rega plus0 = plus.f, 1;//chete kwetsananguro rega minus0 = minus.f + 1;//chete kutsanangurwa
    //
    let minus1 = minus.f - 1;
    let e = -plus.e as usize; // akagovana chinongedzo

    // paradzanisa `plus1` muzvikamu zvakakosha uye zvidimbu.
    // zvikamu zvakasanganiswa zvinovimbiswa kuti zvinokwana mu u32, nekuti simba rakachengetwa rinovimbisa `plus < 2^32` uye yakajairwa `plus.f` inogara iri pasi pe `2^64 - 2^4` nekuda kwezvinodiwa chaizvo.
    //
    let plus1int = (plus1 >> e) as u32;
    let plus1frac = plus1 & ((1 << e) - 1);

    // kuverenga iyo yakakura kwazvo `10^max_kappa` isingapfuure `plus1` (nokudaro `plus1 < 10^(max_kappa+1)`).
    // ichi ndicho chisungo chepamusoro che `kappa` pazasi.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(plus1int);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // Dzidziso 6.2: kana `k` iri rakakura kwazvo st
    // `0 <= y mod 10^k <= y - x`,              ipapo `V = floor(y / 10^k) * 10^k` iri mu `[x, y]` uye chimwe chezvimiririro zvipfupi (zvine huwandu hushoma hwehuwandu hwakakosha) mune iyo nhanho.
    //
    //
    // tsvaga iyo urefu hwemadhijita `kappa` pakati pe `(minus1, plus1)` sekureva kweTheorem 6.2.
    // Dzidziso 6.2 inogona kutorwa kusasiya `x` nekuda `y mod 10^k < y - x` pachinzvimbo.
    // (semuenzaniso, `x` =32000, `y` =32777; `kappa` =2 kubvira `y mod 10 ^ 3=777 <y, x=777`.) Iyo algorithm inovimba nechikamu chekupedzisira chekusimbisa kusasiya `y`.
    //
    let delta1 = plus1 - minus1;
    // rega delta1int=(delta1>> e) seizeize;//chete kutsanangurwa
    let delta1frac = delta1 & ((1 << e) - 1);

    // ipa zvikamu zvakakosha, uku uchitsvaga chokwadi padanho rega rega.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = plus1int; // manhamba achiri kuzopihwa
    loop {
        // isu tinogara tiine kana imwe chete manhamba ekupa, se `plus1 >= 10^kappa` zvinopinda:
        // - `delta1int <= remainder < 10^(kappa+1)`
        // - `plus1int = d[0..n-1] * 10^(kappa+1) + remainder`   (zvinotevera `remainder = plus1int % 10^(kappa+1)`)
        //
        //

        // paradzanisa `remainder` ne `10^kappa`.ese ari maviri akayerwa ne `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        let plus1rem = ((r as u64) << e) + plus1frac; // ==(plus1% 10 ^ kappa) * 2 ^ e
        if plus1rem < delta1 {
            // `plus1 % 10^kappa < delta1 = plus1 - minus1`; isu tawana chaiyo `kappa`.
            let ten_kappa = (ten_kappa as u64) << e; // chikero 10 ^ kappa dzokera kune yakagovaniswa exponent
            return round_and_weed(
                // Kachengeteka: isu takatanga iyo memory pamusoro.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                plus1rem,
                delta1,
                plus1 - v.f,
                ten_kappa,
                1,
            );
        }

        // tsemura chiuno kana isu tapa ese akakosha manhamba.
        // iyo chaiyo nhamba yemadhijiti ndi `max_kappa + 1` se `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // dzosera zvinopinda
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // ipa zvikamu zvidimbu, uku uchitsvaga chokwadi padanho rega rega.
    // nguva ino tinovimba nekudzokorodza kuwanda, sezvo kupatsanurwa kucharasikirwa nemazvo.
    let mut remainder = plus1frac;
    let mut threshold = delta1frac;
    let mut ulp = 1;
    loop {
        // iyo inotevera manhamba inofanirwa kuve yakakosha sekuyedza kwatakaita izvo zvisati zvaitika zvinowira, uko `m = max_kappa + 1` (#manhamba muchikamu chakabatana):
        //
        // - `remainder < 2^e`
        // - `plus1frac * 10^(n-m) = d[m..n-1] * 2^e + remainder`

        remainder *= 10; // haifashukire, `2^e * 10 < 2^64`
        threshold *= 10;
        ulp *= 10;

        // paradzanisa `remainder` na `10^kappa`.
        // ese ari maviri akayerwa ne `2^e / 10^kappa`, saka iyo yekupedzisira iri pano.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        if r < threshold {
            let ten_kappa = 1 << e; // yakajeka disisor
            return round_and_weed(
                // Kachengeteka: isu takatanga iyo memory pamusoro.
                unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..i]) },
                exp,
                r,
                threshold,
                (plus1 - v.f) * ulp,
                ten_kappa,
                ulp,
            );
        }

        // dzosera zvinopinda
        kappa -= 1;
        remainder = r;
    }

    // isu takagadzira ese akakosha manhamba e `plus1`, asi ndisina chokwadi kana iri iyo chaiyo.
    // semuenzaniso, kana `minus1` iri 3.14153 ... uye `plus1` iri 3.14158 ..., pane zvimiro zvishanu zvakapfupika zvakasiyana kubva ku 3.14154 kusvika ku 3.14158 asi isu tinongova neyakanyanya.
    // isu tinofanirwa kuteedzana tichideredza manhamba ekupedzisira uye tarisa kana iri iri repitiri repr.
    // kune vanokwikwidza vapfumbamwe (. 1 kusvika ..9), saka izvi zvinokurumidza.("rounding" chikamu)
    //
    // basa rinotarisa kana iyi "optimal" repr iri mukati mematanho e ulp, uye zvakare, zvinokwanisika kuti iyo "second-to-optimal" repr inogona kunyatsoita nekuda kwekukanganisa kutenderera.
    // mune chero zviitiko izvi zvinodzosera `None`.
    // ("weeding" chikamu)
    //
    // nharo dzese pano dzakayerwa neyakajairika (asi isingazivikanwe) kukosha `k`, kuti:
    // - `remainder = (plus1 % 10^kappa) * k`
    // - `threshold = (plus1 - minus1) * k` (uye zvakare, `remainder < threshold`)
    // - `plus1v = (plus1 - v) * k` (uye zvakare, `threshold > plus1v` kubva kune vasati vasvika)
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    fn round_and_weed(
        buf: &mut [u8],
        exp: i16,
        remainder: u64,
        threshold: u64,
        plus1v: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        assert!(!buf.is_empty());

        // gadzira zviyero zviviri ku `v` (chaiyo `plus1 - v`) mukati me 1.5 ulps.
        // chinomiririra chinoguma chinofanirwa kuve chinomiririra chepedyo kune ese ari maviri.
        //
        // pano `plus1 - v` inoshandiswa sezvo kuverenga kunoitwa zvine chekuita ne `plus1` kuitira kudzivirira overflow/underflow (saka mazita anoita kunge akachinjaniswa mazita).
        //
        let plus1v_down = plus1v + ulp; // plus1 - (v, 1 ulp)
        let plus1v_up = plus1v - ulp; // plus1 - (v + 1 ulp)

        // deredza dhijitari yekupedzisira uye mira pamumiriri wepedyo ku `v + 1 ulp`.
        let mut plus1w = remainder; // plus1w(n) = plus1, w(n)
        {
            let last = buf.last_mut().unwrap();

            // isu tinoshanda nenhamba dzinofungidzirwa `w(n)`, iyo pakutanga yakaenzana ne `plus1 - plus1 % 10^kappa`.mushure mekumhanyisa loop muviri `n` nguva, `w(n) = plus1 - plus1 % 10^kappa - n * 10^kappa`.
            // tinoisa `plus1w(n) = plus1 - w(n) = plus1 % 10^kappa + n * 10^kappa` (nekudaro `zvasara= plus1w(0)`) kurerutsa macheki.
            // ziva kuti `plus1w(n)` iri kugara ichiwedzera.
            //
            // isu tine matatu mamiriro ekumisa.chero chazvo chichaita kuti chiuno chitadze kuenderera, asi isu tinobva tave nemumiriri mumwe anozivikanwa kuti ari padyo ne `v + 1 ulp` zvakadaro.
            // isu tichavaratidza sa TC1 kusvika TC3 kupfupika.
            //
            // TC1: `w(n) <= v + 1 ulp`, kureva, iyi ndiyo yekupedzisira repr inogona kuve yepedyo.
            // izvi zvakaenzana ne `plus1 - w(n) = plus1w(n) >= plus1 - (v + 1 ulp) = plus1v_up`.
            // inosanganiswa ne TC2 (inoongorora kana `w(n+1)` is valid), izvi zvinodzivirira kufashukira kunogona kuitika pakuverenga kwe `plus1w(n)`.
            //
            // TC2: `w(n+1) < minus1`, i.e., repr inotevera hainyatsotenderedza kusvika ku `v`.
            // izvi zvakaenzana ne `plus1 - w(n) + 10^kappa = plus1w(n) + 10^kappa > plus1 - minus1 = threshold`.
            // ruoko rwekuruboshwe runogona kufashukira, asi isu tinoziva `threshold > plus1v`, saka kana TC1 iri nhema, `threshold - plus1w(n) > threshold - (plus1v - 1 ulp) > 1 ulp` uye isu tinogona kuyedza zvakachengeteka kana `threshold - plus1w(n) < 10^kappa` pachinzvimbo.
            //
            //
            // TC3: `abs(w(n) - (v + 1 ulp)) <= abs(w(n+1) - (v + 1 ulp))`, kureva kuti, inotevera repr iri
            // hapana padyo ne `v + 1 ulp` pane yazvino repr.
            // yakapihwa `z(n) = plus1v_up - plus1w(n)`, inova `abs(z(n)) <= abs(z(n+1))`.zvakare tichifunga kuti TC1 manyepo, isu tine `z(n) > 0`.tine zviitiko zviviri zvekufunga nezvazvo:
            //
            // - apo `z(n+1) >= 0`: TC3 inova `z(n) <= z(n+1)`.
            // sezvo `plus1w(n)` iri kuwedzera, `z(n)` inofanira kunge ichiderera uye izvi zviri pachena kuti manyepo.
            // - apo `z(n+1) < 0`:
            //   - TC3a: chirevo chiri `plus1v_up < plus1w(n) + 10^kappa`.uchifungidzira TC2 manyepo, `threshold >= plus1w(n) + 10^kappa` saka haigone kufashukira.
            //   - TC3b: TC3 inova `z(n) <= -z(n+1)`, kureva. `plus1v_up - plus1w(n) >=     plus1w(n+1) - plus1v_up = plus1w(n) + 10^kappa - plus1v_up`.
            //   iyo yakasiyiwa TC1 inopa `plus1v_up > plus1w(n)`, saka haigone kufashukira kana kufashukira kana ichibatanidzwa neTC3a.
            //
            // Nekudaro, isu tinofanirwa kumira kana `TC1 || TC2 || (TC3a && TC3b)`.zvinotevera zvakaenzana nekutendeuka kwayo, `!TC1 && !TC2 && (!TC3a || !TC3b)`.
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            while plus1w < plus1v_up
                && threshold - plus1w >= ten_kappa
                && (plus1w + ten_kappa < plus1v_up
                    || plus1v_up - plus1w >= plus1w + ten_kappa - plus1v_up)
            {
                *last -= 1;
                debug_assert!(*last > b'0'); // repfupi repr haigone ne `0`
                plus1w += ten_kappa;
            }
        }

        // tarisa kana mumiriri uyu zvakare ari wepedyo anomiririra `v - 1 ulp`.
        //
        // izvi zvakangofanana kumamiriro ekugumisa kwe `v + 1 ulp`, iine ese `plus1v_up` yakatsiviwa ne `plus1v_down` pachinzvimbo.
        // kufashukira kuongorora kwakabata zvakafanana.
        if plus1w < plus1v_down
            && threshold - plus1w >= ten_kappa
            && (plus1w + ten_kappa < plus1v_down
                || plus1v_down - plus1w >= plus1w + ten_kappa - plus1v_down)
        {
            return None;
        }

        // ikozvino tine chinomiririra chepedyo ku `v` pakati pe `plus1` ne `minus1`.
        // izvi zvakasununguka zvakanyanya, hazvo, saka tinoramba chero `w(n)` isiri pakati pe `plus0` ne `minus0`, kureva, `plus1 - plus1w(n) <= minus0` kana `plus1 - plus1w(n) >= plus0`.
        // isu tinoshandisa chokwadi icho `threshold = plus1 - minus1` uye `plus1 - plus0 = minus0 - minus1 = 2 ulp`.
        //
        if 2 * ulp <= plus1w && plus1w <= threshold - 4 * ulp { Some((buf, exp)) } else { None }
    }
}

/// Iyo ipfupi modhi kuitiswa kweGrisu neDragoni kudzoka.
///
/// Izvi zvinofanirwa kushandiswa kune dzakawanda kesi.
pub fn format_shortest<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_shortest as fallback;
    // KUCHENGETEKA: Anokwereta anotarisa haana kungwara zvakakwana kuti titendere kushandisa `buf`
    // mune yechipiri branch, saka isu tinosuka iyo yehupenyu pano.
    // Asi isu tinongoshandisa zvakare `buf` kana `format_shortest_opt` yadzoka `None` saka izvi zvakanaka.
    match format_shortest_opt(d, unsafe { &mut *(buf as *mut _) }) {
        Some(ret) => ret,
        None => fallback(d, buf),
    }
}

/// Iyo chaiyo uye yakagadziriswa modhi kuitiswa kweGrisu.
///
/// Iyo inodzosera `None` apo yaizodzosera inexact inomiririra neimwe nzira.
pub fn format_exact_opt<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> Option<(/*digits*/ &'a [u8], /*exp*/ i16)> {
    assert!(d.mant > 0);
    assert!(d.mant < (1 << 61)); // isu tinoda anokwana matatu mabiti ezvekuwedzera kunyatso
    assert!(!buf.is_empty());

    // gadzirisa uye kuyera `v`.
    let v = Fp { f: d.mant, e: d.exp }.normalize();
    let (minusk, cached) = cached_power(ALPHA - v.e - 64, GAMMA - v.e - 64);
    let v = v.mul(&cached);

    // paradzanisa `v` muzvikamu zvakakosha uye zvidimbu.
    let e = -v.e as usize;
    let vint = (v.f >> e) as u32;
    let vfrac = v.f & ((1 << e) - 1);

    // ese ekare `v` uye nyowani `v` (yakayerwa ne `10^-k`) ine kukanganisa kwe <1 ulp (Theorem 5.1).
    // sezvo isu tisingazive iko kukanganisa kuri kwakanaka kana kushata, isu tinoshandisa maenzanisi maviri akapatsanurwa zvakaenzana uye tine yakanyanya kukanganisa ye2 ulps (zvakafanana kune ipfupi kesi).
    //
    //
    // icho chinangwa ndechekutsvaga iwo akakomberedzwa akateedzana manhamba ayo akajairika kune ese ari maviri `v - 1 ulp` uye `v + 1 ulp`, kuitira kuti isu tivimbe zvakanyanya.
    // kana izvi zvisingaite, isu hatizive kuti ndeipi chaiyo inoburitsa `v`, saka tinorega tichidzokera kumashure.
    //
    // `err` inotsanangurwa se `1 ulp * 2^e` pano (zvakafanana kune ulp mu `vfrac`), uye isu tichazvikwirisa pese panosvika `v`.
    //
    //
    //
    let mut err = 1;

    // kuverenga iyo yakakura kwazvo `10^max_kappa` isingapfuure `v` (nokudaro `v < 10^(max_kappa+1)`).
    // ichi ndicho chisungo chepamusoro che `kappa` pazasi.
    let (max_kappa, max_ten_kappa) = max_pow10_no_more_than(vint);

    let mut i = 0;
    let exp = max_kappa as i16 - minusk + 1;

    // kana isu tiri kushanda neyekupedzisira-manhamba kukamurwa, tinoda kupfupisa iyo buffer pamberi peiyo chaiyo kupa kuitira kuti tirege kutenderera zvakapetwa.
    //
    // ziva kuti isu tinofanirwa kuwedzera iyo buffer zvakare kana kutenderera kukaitika!
    let len = if exp <= limit {
        // oops, hatigone kana kuburitsa *imwe* manhamba.
        // izvi zvinogoneka apo, toti, isu tine chimwe chinhu senge 9.5 uye iri kutenderedzwa kusvika gumi.
        //
        // mumutemo isu tinogona kubva tadaidza `possibly_round` ine isina bhafa, asi kuyera `max_ten_kappa << e` na10 kunogona kukonzera kufashukira.
        //
        // nekudaro isu tiri kuve nehusimbe pano uye nekukudza iyo yekukanganisa renji nechinhu chegumi.
        // izvi zvichawedzera nhema nhema chiyero, asi chete chaizvo,*chaizvo* zvishoma;
        // zvinogona kungoonekwa zvinechekuita kana mantissa yakakura kupfuura makumi matanhatu.
        //
        // KUCHENGETEKA: `len=0`, saka chisungo chekutanga iyi ndangariro chidiki.
        return unsafe {
            possibly_round(buf, 0, exp, limit, v.f / 10, (max_ten_kappa as u64) << e, err << e)
        };
    } else if ((exp as i32 - limit as i32) as usize) < buf.len() {
        (exp - limit) as usize
    } else {
        buf.len()
    };
    debug_assert!(len > 0);

    // ipa zvikamu zvakakosha.
    // iko kukanganisa kwakadzikira chose, saka hatidi kuti titarise muchikamu chino.
    let mut kappa = max_kappa as i16;
    let mut ten_kappa = max_ten_kappa; // 10^kappa
    let mut remainder = vint; // manhamba achiri kuzopihwa
    loop {
        // isu tinogara tiine kana imwe chete manhamba ekupa zvinopinda.
        // - `remainder < 10^(kappa+1)`
        // - `vint = d[0..n-1] * 10^(kappa+1) + remainder`   (zvinotevera kuti `remainder = vint % 10^(kappa+1)`)
        //
        //

        // paradzanisa `remainder` ne `10^kappa`.ese ari maviri akayerwa ne `2^-e`.
        let q = remainder / ten_kappa;
        let r = remainder % ten_kappa;
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // iyo buffer izere?mhanyisa iyo inotenderera ichipfuura neakasara.
        if i == len {
            let vrem = ((r as u64) << e) + vfrac; // ==(v% 10 ^ kappa) * 2 ^ e
            // Kachengeteka: isu takatanga `len` mabheti mazhinji.
            return unsafe {
                possibly_round(buf, len, exp, limit, vrem, (ten_kappa as u64) << e, err << e)
            };
        }

        // tsemura chiuno kana isu tapa ese akakosha manhamba.
        // iyo chaiyo nhamba yemadhijiti ndi `max_kappa + 1` se `plus1 < 10^(max_kappa+1)`.
        if i > max_kappa as usize {
            debug_assert_eq!(ten_kappa, 1);
            debug_assert_eq!(kappa, 0);
            break;
        }

        // dzosera zvinopinda
        kappa -= 1;
        ten_kappa /= 10;
        remainder = r;
    }

    // kupa zvikamu zvidimbu.
    //
    // musimboti isu tinogona kuenderera kune yekupedzisira iripo manhamba uye kutarisa kuti nderechokwadi here.
    // zvinosuruvarisa isu tiri kushanda pamwe nemagumo-akakura manhamba, saka tinoda imwe nzira yekuona kufashukira.
    // V8 inoshandisa `remainder > err`, inova inhema kana yekutanga `i` yakakosha manhamba e `v - 1 ulp` uye `v` akasiyana.
    // zvisinei izvi zvinoramba zvakawandisa zvakawanda zvisingaiti.
    //
    // sezvo chikamu chinotevera chiine kufashukira kwakaringana, isu pachinzvimbo tinoshandisa chitauro chakasimba.
    // tinoenderera mberi kusvika `err` inodarika `10^kappa / 2`, kuitira kuti huwandu pakati pe `v - 1 ulp` ne `v + 1 ulp` huve nemamiririri maviri kana anopfuura akatenderedzwa.
    //
    // izvi zvakafanana kune maviri ekufananidza ekutanga kubva ku `possibly_round`, kune chirevo.
    //
    let mut remainder = vfrac;
    let maxerr = 1 << (e - 1);
    while err < maxerr {
        // zvinowanzoitika, uko `m = max_kappa + 1` (#manhamba muchikamu chakabatana):
        // - `remainder < 2^e`
        // - `vfrac * 10^(n-m) = d[m..n-1] * 2^e + remainder`
        // - `err = 10^(n-m)`

        remainder *= 10; // haifashukire, `2^e * 10 < 2^64`
        err *= 10; // haifashukire, `err * 10 < 2^e * 5 < 2^64`

        // paradzanisa `remainder` na `10^kappa`.
        // ese ari maviri akayerwa ne `2^e / 10^kappa`, saka iyo yekupedzisira iri pano.
        let q = remainder >> e;
        let r = remainder & ((1 << e) - 1);
        debug_assert!(q < 10);
        buf[i] = MaybeUninit::new(b'0' + q as u8);
        i += 1;

        // iyo buffer izere?mhanyisa iyo inotenderera ichipfuura neakasara.
        if i == len {
            // Kachengeteka: isu takatanga `len` mabheti mazhinji.
            return unsafe { possibly_round(buf, len, exp, limit, r, 1 << e, err) };
        }

        // dzosera zvinopinda
        remainder = r;
    }

    // kuwedzera kuverenga hakuna zvakunobatsira (`possibly_round` inonyatsokundikana), saka tinorega.
    return None;

    // isu takagadzira ese akakumbirwa manhamba e `v`, ayo anofanirwa kunge akafananawo nenhamba dzinoenderana dze `v - 1 ulp`.
    // ikozvino isu tarisa kana paine yakasarudzika inomiririrwa yakagovaniswa nese ari `v - 1 ulp` uye `v + 1 ulp`;izvi zvinogona kunge zvakafanana kune zvakagadzirwa manhamba, kana kune yakatenderedzwa-up vhezheni yeavo manhamba.
    //
    // kana iyo renji iine mamiririri mazhinji ehurefu hwakaenzana, hatigone kuve nechokwadi uye tinofanirwa kudzosa `None` pachinzvimbo.
    //
    // nharo dzese pano dzakayerwa neyakajairika (asi isingazivikanwe) kukosha `k`, kuti:
    // - `remainder = (v % 10^kappa) * k`
    // - `ten_kappa = 10^kappa * k`
    // - `ulp = 2^-e * k`
    //
    // KUCHENGETEKA: yekutanga `len` mabheti e `buf` anofanirwa kutanga.
    //
    unsafe fn possibly_round(
        buf: &mut [MaybeUninit<u8>],
        mut len: usize,
        mut exp: i16,
        limit: i16,
        remainder: u64,
        ten_kappa: u64,
        ulp: u64,
    ) -> Option<(&[u8], i16)> {
        debug_assert!(remainder < ten_kappa);

        // 10^kappa
        //    :   :   :<->:   :
        //    :   :   :   :   :
        //    : | 1 ulp | 1 ulp |:
        //    :|<--->|<--->|  :
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // (yeiyo mareferenzi, mutsetse une madonhwe unoratidza kukosha chaiko kwezvinogona kumiririrwa nenhamba yakapihwa manhamba.)
        //
        //
        // kukanganisa kwakakura kwazvo zvekuti pane zvinokwana zvitatu zvinomiririrwa pakati pe `v - 1 ulp` ne `v + 1 ulp`.
        // hatigone kuona kuti ndechipi chakarurama.
        //
        if ulp >= ten_kappa {
            return None;
        }

        // 10^kappa
        //   :<------->:
        //   :         :
        //   : | 1 ulp | 1 ulp |
        //   : |<--->|<--->|
        // ----|-----|-----|----
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // muchokwadi, 1/2 ulp inokwana kuunza maviri angangomiririrwa.
        // (rangarira kuti isu tinoda yakasarudzika inomiririra kune ese `v - 1 ulp` uye `v + 1 ulp`.) izvi hazvifashukire, se `ulp < ten_kappa` kubva kekutanga cheki.
        //
        //
        if ten_kappa - ulp <= ulp {
            return None;
        }

        // remainder
        //       :<->|                           :
        //       :   |                           :
        //       : <---------10 ^ kappa-- -------->:
        //     | :   |                           :
        //     | 1 ulp | 1 ulp |:
        //     |<--->|<--->|                     :
        // ----|-----|-----|------------------------
        //     |     v     | v - 1 ulp   v + 1 ulp
        //
        // kana `v + 1 ulp` iri padyo nemumiririri wezasi (iyo yatove mu `buf`), ipapo tinogona kudzoka zvakachengeteka.
        // ziva kuti `v - 1 ulp`*inogona* kuve yakaderera pane inomiririrwa ikozvino, asi se `1 ulp < 10^kappa / 2`, iyi mamiriro akakwana:
        // nhambwe iri pakati pe `v - 1 ulp` nemumiriri wazvino haugone kudarika `10^kappa / 2`.
        //
        // mamiriro acho akaenzana ne `remainder + ulp < 10^kappa / 2`.
        // sezvo izvi zvichigona kufashukira, tanga watarisa kana `remainder < 10^kappa / 2`.
        // isu takatobvumikisa kuti `ulp < 10^kappa / 2`, chero bedzi `10^kappa` isina kufashukira mushure mezvose, cheki yechipiri yakanaka.
        //
        //
        //
        //
        if ten_kappa - remainder > remainder && ten_kappa - 2 * remainder >= 2 * ulp {
            // Kachengeteka: yedu yekufona yakatanga iyo memory.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // : <-------zvasara------> |:
        //   :                          |   :
        //   : <---------10 ^ kappa-- ------->:
        //   :                    |     |   : |
        //   : | 1 ulp | 1 ulp |
        //   :                    |<--->|<--->|
        // -----------------------|-----|-----|-----
        //                        |     v     |                    v - 1 ulp   v + 1 ulp
        //
        // kune rimwe divi, kana `v - 1 ulp` iri padyo nemumiririri wakakomberedzwa, isu tinofanirwa kukomberedza uye kudzoka.
        // nekuda kwechikonzero chimwe chete isu hatidi kutarisa `v + 1 ulp`.
        //
        // mamiriro acho akaenzana ne `remainder - ulp >= 10^kappa / 2`.
        // zvakare isu tinotanga tarisa kana `remainder > ulp` (ona kuti iyi haisi `remainder >= ulp`, sezvo `10^kappa` isiri zero).
        //
        // onawo kuti `remainder - ulp <= 10^kappa`, saka cheki yechipiri haifashukire.
        //
        if remainder > ulp && ten_kappa - (remainder - ulp) <= remainder - ulp {
            if let Some(c) =
                // KUCHENGETEKA: wedu anofona anofanira kunge akatanga iyo memory.
                round_up(unsafe { MaybeUninit::slice_assume_init_mut(&mut buf[..len]) })
            {
                // ingo wedzera imwe yekuwedzera kana isu tavakumbirwa iyo yakatarwa chaiyo.
                // isu tinodawo kutarisa kuti, kana iyo yekutanga buffer yakanga isina chinhu, iyo yekuwedzera digit inogona kungowedzerwa chete kana `exp == limit` (edge kesi).
                //
                exp += 1;
                if exp > limit && len < buf.len() {
                    buf[len] = MaybeUninit::new(c);
                    len += 1;
                }
            }
            // KUCHENGETEKA: isu newedu wekufonera takatanga memory iyoyo.
            return Some((unsafe { MaybeUninit::slice_assume_init_ref(&buf[..len]) }, exp));
        }

        // kana zvisina kudaro isu taparadzwa (kureva., mamwe maitiro pakati pe `v - 1 ulp` ne `v + 1 ulp` ari kutenderera pasi uye mamwe ari kutenderera kumusoro) uye kurega.
        //
        None
    }
}

/// Iyo chaiyo uye yakagadziriswa modhi kuitiswa kweGrisu neDragoni kudonha.
///
/// Izvi zvinofanirwa kushandiswa kune dzakawanda kesi.
pub fn format_exact<'a>(
    d: &Decoded,
    buf: &'a mut [MaybeUninit<u8>],
    limit: i16,
) -> (/*digits*/ &'a [u8], /*exp*/ i16) {
    use crate::num::flt2dec::strategy::dragon::format_exact as fallback;
    // KUCHENGETEKA: Anokwereta anotarisa haana kungwara zvakakwana kuti titendere kushandisa `buf`
    // mune yechipiri branch, saka isu tinosuka iyo yehupenyu pano.
    // Asi isu tinongoshandisa zvakare `buf` kana `format_exact_opt` yadzoka `None` saka izvi zvakanaka.
    match format_exact_opt(d, unsafe { &mut *(buf as *mut _) }, limit) {
        Some(ret) => ret,
        None => fallback(d, buf, limit),
    }
}