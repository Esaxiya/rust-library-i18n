//! Inosarudza kukosha-kwepfungwa kukosha muzvikamu zvakasiyana uye zvikanganiso zvikero.

use crate::num::dec2flt::rawfp::RawFloat;
use crate::num::FpCategory;

/// Yakatemwa isina kusainwa kukwana, sekuti:
///
/// - Iko kukosha kwepakutanga kwakaenzana ne `mant * 2^exp`.
///
/// - Chero nhamba kubva ku `(mant - minus)*2^exp` kuenda ku `(mant + plus)* 2^exp` inotenderera kune iyo yekutanga kukosha.
/// Mhando yacho inosanganisirwa chete kana `inclusive` iri `true`.
///
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub struct Decoded {
    /// Iyo yakawedzera mantissa.
    pub mant: u64,
    /// Yakadzika yekukanganisa renji.
    pub minus: u64,
    /// Iyo yepamusoro yekukanganisa renji.
    pub plus: u64,
    /// Iyo yakagovaniswa inotsanangudza mu base 2.
    pub exp: i16,
    /// Ichokwadi kana renji yekukanganisa ichibatanidzwa.
    ///
    /// MuIEEE 754, izvi ichokwadi apo mantissa yekutanga yaive kunyange.
    pub inclusive: bool,
}

/// Yakatemwa isina kusainwa kukosha.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum FullDecoded {
    /// Not-a-number.
    Nan,
    /// Infinities, ingave yakanaka kana yakaipa.
    Infinite,
    /// Zero, ingave yakanaka kana yakaipa.
    Zero,
    /// Kupedzisa manhamba pamwe nemamwe madhizaini akadzorerwa.
    Finite(Decoded),
}

/// Rudzi rwepfungwa dzinoyerera iyo inogona kuve `decode`d.
pub trait DecodableFloat: RawFloat + Copy {
    /// Iwo mashoma akanaka akaenzana kukosha.
    fn min_pos_norm_value() -> Self;
}

impl DecodableFloat for f32 {
    fn min_pos_norm_value() -> Self {
        f32::MIN_POSITIVE
    }
}

impl DecodableFloat for f64 {
    fn min_pos_norm_value() -> Self {
        f64::MIN_POSITIVE
    }
}

/// Inodzorera chiratidzo (chechokwadi kana chisina) uye `FullDecoded` kukosha kubva kupihwa yakayangarara poindi nhamba.
///
pub fn decode<T: DecodableFloat>(v: T) -> (/*negative?*/ bool, FullDecoded) {
    let (mant, exp, sign) = v.integer_decode();
    let even = (mant & 1) == 0;
    let decoded = match v.classify() {
        FpCategory::Nan => FullDecoded::Nan,
        FpCategory::Infinite => FullDecoded::Infinite,
        FpCategory::Zero => FullDecoded::Zero,
        FpCategory::Subnormal => {
            // vavakidzani: (mant, 2, exp)-(mant, exp)-(mant + 2, exp)
            // Float::integer_decode inogara ichichengetedza iyo inoburitsa, saka mantissa yakaverengerwa zvisizvo.
            //
            FullDecoded::Finite(Decoded { mant, minus: 1, plus: 1, exp, inclusive: even })
        }
        FpCategory::Normal => {
            let minnorm = <T as DecodableFloat>::min_pos_norm_value().integer_decode();
            if mant == minnorm.0 {
                // vavakidzani: (maxmant, exp, 1)-(zvisingaiti, exp)-(zvisingaiti + 1, exp)
                // iko maxmant=kusanzwisisika * 2, 1
                FullDecoded::Finite(Decoded {
                    mant: mant << 2,
                    minus: 1,
                    plus: 2,
                    exp: exp - 2,
                    inclusive: even,
                })
            } else {
                // vavakidzani: (mant, 1, exp)-(mant, exp)-(mant + 1, exp)
                FullDecoded::Finite(Decoded {
                    mant: mant << 1,
                    minus: 1,
                    plus: 1,
                    exp: exp - 1,
                    inclusive: even,
                })
            }
        }
    };
    (sign < 0, decoded)
}