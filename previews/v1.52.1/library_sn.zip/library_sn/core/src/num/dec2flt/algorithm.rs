//! Iwo akasiyana algorithms kubva bepa.

use crate::cmp::min;
use crate::cmp::Ordering::{Equal, Greater, Less};
use crate::num::dec2flt::num::{self, Big};
use crate::num::dec2flt::rawfp::{self, fp_to_float, next_float, prev_float, RawFloat, Unpacked};
use crate::num::dec2flt::table;
use crate::num::diy_float::Fp;

/// Nhamba yezvakakosha mabits muFp
const P: u32 = 64;

// Isu tinongochengeta yakanakisa fungidziro ye *zvese* zvinotsanangudza, saka iyo inoshanduka "h" nemamiriro akasanganiswa anogona kusiiwa.
// Izvi zvinotengesa mashandiro emaviri kilobytes enzvimbo.

fn power_of_ten(e: i16) -> Fp {
    assert!(e >= table::MIN_E);
    let i = e - table::MIN_E;
    let sig = table::POWERS.0[i as usize];
    let exp = table::POWERS.1[i as usize];
    Fp { f: sig, e: exp }
}

// Mune akawanda maumbirwo, inoyerera poindi mashandiro ane yakajeka bit saizi, saka iko iko iko kweyekuverenga kunoonekwa pane imwe-yekushanda hwaro.
//
#[cfg(any(not(target_arch = "x86"), target_feature = "sse2"))]
mod fpu_precision {
    pub fn set_precision<T>() {}
}

// Pa x86, iyo x87 FPU inoshandiswa pakuyangarara mashandiro kana iyo SSE/SSE2 yekuwedzera isipo.
// x87 FPU inoshanda nemakumi masere makumi masere ekuita nekukasira, zvinoreva kuti mashandiro anotenderedza kusvika kumasere makumi masere zvichikonzera kutenderera zvakapetwa kuti zviitike kana kukosha kuchizomiririrwa se
//
// 32/64 bit float tsika.Kuti ukunde izvi, izwi rekutonga reFPU rinogona kumisikidzwa kuitira kuti komputa dziitwe nenzira chaiyo inodiwa.
//
#[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
mod fpu_precision {
    use crate::mem::size_of;

    /// Chimiro chinoshandiswa kuchengetedza kukosha kwepakutanga kweiyo FPU yekudhira izwi, kuti igone kudzoreredzwa kana chimiro chadonhedzwa.
    ///
    ///
    /// Iyo x87 FPU ndeye 16-bits rejista ine minda iri seinotevera:
    ///
    /// | 12-15 | 10-11 | 8-9 | 6-7 |  5 |  4 |  3 |  2 |  1 |  0 |
    /// |------:|------:|----:|----:|---:|---:|---:|---:|---:|---:|
    /// |       | RC    | PC  |     | PM | UM | OM | ZM | DM | IM |
    ///
    /// Zvinyorwa zveminda yese zviripo mu IA-32 Architectures Software Inokudziridza Manual (Vhoriyamu 1).
    ///
    /// Iyo yega munda inoenderana nekodhi inotevera kodhi PC, Precision Control.
    /// Iyi munda inosarudzika chaiyo yekuita kunoitwa neFPU.
    /// Inogona kusetwa ku:
    ///  - 0b00, chaiyo imwechete kureva, makumi matatu nemaviri-mabheti
    ///  - 0b10, zvakapetwa kaviri kureva, makumi matanhatu nemasere
    ///  - 0b11, yakapetwa kaviri chaiyo kureva, makumi masere-makumi masere (default mamiriro) Iyo 0b01 kukosha kwakachengetwa uye hakufanirwe kushandiswa.
    ///
    pub struct FPUControlWord(u16);

    fn set_cw(cw: u16) {
        // Kachengeteka: iwo murayiridzo we `fldcw` wakaongororwa kuti ugone kushanda nemazvo
        // chero `u16`
        unsafe {
            asm!(
                "fldcw ({})",
                in(reg) &cw,
                // FIXME: Tiri kushandisa ATT syntax kutsigira LLVM 8 uye LLVM 9.
                options(att_syntax, nostack),
            )
        }
    }

    /// Inoisa iwo chaiwo ndima yeiyo FPU ku `T` uye inodzosera `FPUControlWord`.
    pub fn set_precision<T>() -> FPUControlWord {
        let mut cw = 0_u16;

        // Compute iyo kukosha kweiyo Precision Control munda iyo yakakodzera kune `T`.
        let cw_precision = match size_of::<T>() {
            4 => 0x0000, // Makumi matatu nematatu
            8 => 0x0200, // 64 bits
            _ => 0x0300, // default, makumi masere
        };

        // Tora kukosha kwepakutanga kweshoko rinodzora kuti udzorere gare gare, kana chimiro che `FPUControlWord` chakadonhedzwa CHIKURE: iyo kuraira kwe `fnstcw` yakaongororwa kuti ikwanise kushanda nemazvo neiyo `u16`
        //
        //
        //
        unsafe {
            asm!(
                "fnstcw ({})",
                in(reg) &mut cw,
                // FIXME: Tiri kushandisa ATT syntax kutsigira LLVM 8 uye LLVM 9.
                options(att_syntax, nostack),
            )
        }

        // Seta iro rinodzora izwi kune chaunoda chairo.
        // Izvi zvinoitwa nekufukidza kure kwekare kwakajeka (bits 8 uye 9, 0x300) uye nekuitsiva neiyo chaiyo mureza wakanyorwa pamusoro.
        set_cw((cw & 0xFCFF) | cw_precision);

        FPUControlWord(cw)
    }

    impl Drop for FPUControlWord {
        fn drop(&mut self) {
            set_cw(self.0)
        }
    }
}

/// Iyo inokurumidza nzira yeBellerophon uchishandisa muchina-saizi manhamba uye inoyangarara.
///
/// Izvi zvinoburitswa mune rakasiyana basa kuitira kuti rigone kuyedzwa usati wavaka bignum.
///
pub fn fast_path<T: RawFloat>(integral: &[u8], fractional: &[u8], e: i64) -> Option<T> {
    let num_digits = integral.len() + fractional.len();
    // log_10(f64::MAX_SIG) ~ 15.95.
    // Isu tinofananidza iyo chaiyo kukosha kune MAX_SIG padhuze nekumagumo, uku kungokurumidza, kwakachipa kurambwa (uye zvakare kunosunungura iyo yasara yekodhi kubva kunetseka nezvekufashukira).
    //
    if num_digits > 16 {
        return None;
    }
    if e.abs() >= T::CEIL_LOG5_OF_MAX_SIG as i64 {
        return None;
    }
    let f = num::from_str_unchecked(integral.iter().chain(fractional.iter()));
    if f > T::MAX_SIG {
        return None;
    }

    // Iyo yekukurumidza nzira inosarudzika zvinoenderana nesvomhu kutenderedzwa kune chaiyo nhamba yemabiti pasina chero yepakati kutenderera.
    // Pa x86 (isina SSE kana SSE2) izvi zvinoda iko iko kweiyo x87 FPU stack kuti ishandurwe kuitira kuti itenderedze zvakananga ku 64/32 bit.
    // Basa re `set_precision` rinotarisira kumisikidza iwo chaiwo pazvivakwa zvinoda kumisikidza nekushandura nyika yepasirese (sezwi rekutonga re x87 FPU).
    //
    //
    let _cw = fpu_precision::set_precision::<T>();

    // Mhosva e <0 haigone kupetwa ichipinda mune imwe branch.
    // Masimba asina kunaka anokonzeresa muchikamu chinodzokorodzwa muchikamu chebhinari, chakakomberedzwa, chinokonzeresa (uye dzimwe nguva chakakosha!) Zvikanganiso mune yekupedzisira mhedzisiro.
    //
    if e >= 0 {
        Some(T::from_int(f) * T::short_fast_pow10(e as usize))
    } else {
        Some(T::from_int(f) / T::short_fast_pow10(e.abs() as usize))
    }
}

/// Algorithm Bellerophon kodhi kadiki isinganetsi nekuongororwa kusiri-kuduku kwenhamba.
///
/// Inotenderera `` f '' kune ichiyangarara ine 64 zvishoma kukosha uye ichiipamhidzira nekufungidzira kwakanakisa kwe `10^e` (mune imwecheteyo inoyerera poindi fomati).Izvi zvinowanzo kukwana kuti uwane mhedzisiro chaiyo.
/// Nekudaro, kana mhedzisiro yave padhuze nepakati pakati pezviviri zvakatarisana ne (ordinary) ichiyangarara, iyo yakakomberedza kutenderedza kukanganisa kubva pakuwandisa maviri ekufungidzira zvinoreva kuti mhedzisiro inogona kubviswa nemabhureki mashoma
/// Kana izvi zvikaitika, iterative Algorithm R inogadzirisa zvinhu kumusoro.
///
/// Ruoko-wavy "close to halfway" inoitwa chaizvo nekuongororwa kwenhamba mupepa.
/// Mumashoko aClinger:
///
/// > Slop, inoratidzwa muzvikamu zveiyo isingakoshe zvishoma, inosanganisirwa yakasungirwa iko kukanganisa
/// > akaunganidzwa panguva inoyerera poindi yekufungidzira kune f * 10 ^ e.(Slop iri
/// > kwete yakasungirwa chikanganiso chechokwadi, asi inoganhurira mutsauko uripakati pekufungidzira z uye
/// > fungidziro yakanakisa inoshandisa p bits yezvakakosha.)
///
///
pub fn bellerophon<T: RawFloat>(f: &Big, e: i16) -> T {
    let slop = if f <= &Big::from_u64(T::MAX_SIG) {
        // Mhosva abs(e) <log5(2^N) dziri mu fast_path()
        if e >= 0 { 0 } else { 3 }
    } else {
        if e >= 0 { 1 } else { 4 }
    };
    let z = rawfp::big_to_fp(f).mul(&power_of_ten(e)).normalize();
    let exp_p_n = 1 << (P - T::SIG_BITS as u32);
    let lowbits: i64 = (z.f % exp_p_n) as i64;
    // Iyo slop yakakura zvakakwana kuita mutsauko kana uchikomberedza n bits?
    //
    if (lowbits - exp_p_n as i64 / 2).abs() <= slop {
        algorithm_r(f, e, fp_to_float(z))
    } else {
        fp_to_float(z)
    }
}

/// Iyo iterative algorithm inovandudza iyo inoyerera poindi fungidziro ye `f * 10^e`.
///
/// Imwe iteration inowana chimwe chinhu munzvimbo yekupedzisira padyo, izvo zvinotora zvinotyisa kureba kusangana kana `z0` yakatodzikama zvinyoro.
/// Neraki, kana ikashandiswa sekudonha kweBellerophon, iko kutanga kwekufungidzira kwakadzimwa neakawanda ULP.
///
fn algorithm_r<T: RawFloat>(f: &Big, e: i16, z0: T) -> T {
    let mut z = z0;
    loop {
        let raw = z.unpack();
        let (m, k) = (raw.sig, raw.k);
        let mut x = f.clone();
        let mut y = Big::from_u64(m);

        // Tsvaga yakanaka manhamba `x`, `y` zvekuti `x / y` iri `(f *10^e) / (m* 2^k)` chaiyo.
        // Izvi hazvingodziviriri chete kubata nezviratidzo zve `e` uye `k`, isu zvakare tinobvisa simba rezvinhu zviviri zvakajairika ku `10^e` uye `2^k` kuita kuti nhamba dzive diki.
        //
        make_ratio(&mut x, &mut y, e, k);

        let m_digits = [(m & 0xFF_FF_FF_FF) as u32, (m >> 32) as u32];
        // Izvi zvakanyorwa zvakanetsa nekuti bignums edu haatsigire nhamba dzisina kunaka, saka isu tinoshandisa iyo chaiyo kukosha + chiratidzo chemasaini.
        // Kuwedzeredza nema m_digits hakugone kufashukira.
        // Kana `x` kana `y` yakakura zvakakwana zvekuti tinofanirwa kunetseka nezvekufashukira, saka zvakare akakura zvakakwana zvekuti `make_ratio` yaderedza chidimbu nechikamu che2 ^ 64 kana kudarika.
        //
        //
        let (d2, d_negative) = if x >= y {
            // Haudi x zvekare, chengetedza clone().
            x.sub(&y).mul_pow2(1).mul_digits(&m_digits);
            (x, false)
        } else {
            // Zvichiri kuda y, gadzira kopi.
            let mut y = y.clone();
            y.sub(&x).mul_pow2(1).mul_digits(&m_digits);
            (y, true)
        };

        if d2 < y {
            let mut d2_double = d2;
            d2_double.mul_pow2(1);
            if m == T::MIN_SIG && d_negative && d2_double > y {
                z = prev_float(z);
            } else {
                return z;
            }
        } else if d2 == y {
            if m % 2 == 0 {
                if m == T::MIN_SIG && d_negative {
                    z = prev_float(z);
                } else {
                    return z;
                }
            } else if d_negative {
                z = prev_float(z);
            } else {
                z = next_float(z);
            }
        } else if d_negative {
            z = prev_float(z);
        } else {
            z = next_float(z);
        }
    }
}

/// Tichipiwa `x = f` uye `y = m` apo `f` inomiririra madhijimendi ekupinda senguva dzose uye `m` ndiyo kukosha kwechiyero chekuyangarara, ita chiyero `x / y` yakaenzana ne `(f *10^e) / (m* 2^k)`, pamwe ichideredzwa nesimba revaviri zvakafanana.
///
///
fn make_ratio(x: &mut Big, y: &mut Big, e: i16, k: i16) {
    let (e_abs, k_abs) = (e.abs() as usize, k.abs() as usize);
    if e >= 0 {
        if k >= 0 {
            // x=f *10 ^ e, y=m* 2 ^ k, kunze kwekunge tichideredza chidimbu neimwe simba rezviviri.
            let common = min(e_abs, k_abs);
            x.mul_pow5(e_abs).mul_pow2(e_abs - common);
            y.mul_pow2(k_abs - common);
        } else {
            // x=f *10 ^ e* 2^abs(k), y=m Izvi hazvigone kufashukira nekuti zvinoda kuti zvive zvakanaka `e` uye isina kunaka `k`, izvo zvinogona kungoitika chete pamitengo iri padhuze ne1, zvinoreva kuti `e` ne `k` zvichave zvidiki diki.
            //
            //
            //
            x.mul_pow5(e_abs).mul_pow2(e_abs + k_abs);
        }
    } else {
        if k >= 0 {
            // x=f, y=m *10^abs(e)* 2 ^ k Izvi hazvigone kufashukira futi, ona pamusoro.
            //
            y.mul_pow5(e_abs).mul_pow2(k_abs + e_abs);
        } else {
            // x=f *2^abs(k), y=m* 10^abs(e), zvakare ichideredza nesimba rakafanana reviri.
            let common = min(e_abs, k_abs);
            x.mul_pow2(k_abs - common);
            y.mul_pow5(e_abs).mul_pow2(e_abs - common);
        }
    }
}

/// Chaizvoizvo, Algorithm M ndiyo nzira yakapusa yekushandura decimal kuita float.
///
/// Isu tinogadzira reshiyo yakaenzana ne `f * 10^e`, tobva takanda masimba maviri kusvikira yapa kujeka kwakakodzera.
/// Bhainari inotsanangudza `k` ndiyo nhamba yenguva dzatakawanza manhamba kana dhinomineta nemaviri, kureva, nguva dzose `f *10^e` yakaenzana `(u / v)* 2^k`.
/// Kana tawana kukosha, isu tinongoda kukomberedza nekuongorora zvasara zvechikamu, zvinoitwa mumabasa ekubatsira zvakare pazasi.
///
///
/// Iyi algorithm inononoka, kunyangwe iine optimization inotsanangurwa mu `quick_start()`.
/// Nekudaro, ndiwo akareruka ealgorithms ekugadzirisa kufashukira, kufashukira, uye mhedzisiro isina kujairika.
/// Uku kumisikidza kunotora nzvimbo apo Bellerophon neAlgorithm R vanokurirwa.
/// Kuona kufashukira uye kufashukira kuri nyore: Iyo reshiyo haisati iri yekumusoro-kukosha, asi iyo minimum/maximum exponent yasvika.
/// Muchiitiko chekufashukira, isu tinongodzosera infinity.
///
/// Kubata kufashukira uye zvisizvo zvakashata zvakanyanya.
/// Rimwe dambudziko hombe nderekuti, neicho chidiki chinoburitsa, iyo reshiyo inogona kunge ichiri yakanyanya kukura kune chakakosha.
/// Ona underflow() kuti uwane rumwe ruzivo.
///
pub fn algorithm_m<T: RawFloat>(f: &Big, e: i16) -> T {
    let mut u;
    let mut v;
    let e_abs = e.abs() as usize;
    let mut k = 0;
    if e < 0 {
        u = f.clone();
        v = Big::from_small(1);
        v.mul_pow5(e_abs).mul_pow2(e_abs);
    } else {
        // FIXME inogoneka kugonesa: generalize big_to_fp kuitira kuti tigone kuita zvakaenzana ne fp_to_float(big_to_fp(u)) pano, chete pasina kutenderera zvakapetwa.
        //
        u = f.clone();
        u.mul_pow5(e_abs).mul_pow2(e_abs);
        v = Big::from_small(1);
    }
    quick_start::<T>(&mut u, &mut v, &mut k);
    let mut rem = Big::from_small(0);
    let mut x = Big::from_small(0);
    let min_sig = Big::from_u64(T::MIN_SIG);
    let max_sig = Big::from_u64(T::MAX_SIG);
    loop {
        u.div_rem(&v, &mut x, &mut rem);
        if k == T::MIN_EXP_INT {
            // Isu tinofanirwa kumira pane yakaderera exponent, kana isu tikamirira kusvika `k < T::MIN_EXP_INT`, ipapo tinobva tave kure nechinhu cheviri.
            // Nehurombo izvi zvinoreva kuti isu tinofanirwa kuve neakasarudzika-makesi akajairwa neanodzika mashoma.
            // FIXME tsvaga iyo yakanyanya kunaka fomati, asi mhanyisa iyo `tiny-pow10` bvunzo kuti uve nechokwadi chekuti ichokwadi!
            //
            //
            if x >= min_sig && x <= max_sig {
                break;
            }
            return underflow(x, v, rem);
        }
        if k > T::MAX_EXP_INT {
            return T::INFINITY;
        }
        if x < min_sig {
            u.mul_pow2(1);
            k -= 1;
        } else if x > max_sig {
            v.mul_pow2(1);
            k += 1;
        } else {
            break;
        }
    }
    let q = num::to_u64(&x);
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    round_by_remainder(v, rem, q, z)
}

/// Inosvetuka pamusoro peakawanda Algorithm M iterations nekutarisa iyo yakareba urefu.
fn quick_start<T: RawFloat>(u: &mut Big, v: &mut Big, k: &mut i16) {
    // Kureba kuri kufungidzira kwechigadziko maviri logarithm, uye log(u / v) = log(u), log(v).
    // Iko kufungidzira kwakadzimwa nevazhinji 1, asi nguva dzose kuri pasi-fungidziro, saka kukanganisa kuri pa log(u) uye log(v) kune chiratidzo chimwe chete uye kudzima (kana ese ari maviri akakura).
    // Naizvozvo iko kukanganisa kwe log(u / v) kuri kwakawandawo futi.
    // Chiyero chakanangwa ndechimwe apo u/v iri mune iri-renji kukosha.Nekudaro mamiriro edu ekugumisa i log2(u / v) achive akakosha mabhanditi, plus/minus imwe.
    // FIXME Kutarisa chechipiri bit kunogona kugadzirisa fungidziro uye kudzivirira kumwe kupatsanuka.
    //
    //
    let target_ratio = T::SIG_BITS as i16;
    let log2_u = u.bit_length() as i16;
    let log2_v = v.bit_length() as i16;
    let mut u_shift: i16 = 0;
    let mut v_shift: i16 = 0;
    assert!(*k == 0);
    loop {
        if *k == T::MIN_EXP_INT {
            // Kufashukira kana kusanzwisisika.Siya icho kune chikuru basa.
            break;
        }
        if *k == T::MAX_EXP_INT {
            // Kufashukira.Siya icho kune chikuru basa.
            break;
        }
        let log2_ratio = (log2_u + u_shift) - (log2_v + v_shift);
        if log2_ratio < target_ratio - 1 {
            u_shift += 1;
            *k -= 1;
        } else if log2_ratio > target_ratio + 1 {
            v_shift += 1;
            *k += 1;
        } else {
            break;
        }
    }
    u.mul_pow2(u_shift as usize);
    v.mul_pow2(v_shift as usize);
}

fn underflow<T: RawFloat>(x: Big, v: Big, rem: Big) -> T {
    if x < Big::from_u64(T::MIN_SIG) {
        let q = num::to_u64(&x);
        let z = rawfp::encode_subnormal(q);
        return round_by_remainder(v, rem, q, z);
    }
    // Ratio haisi mu-renji yakatarwa neiyo shoma exponent, saka isu tinofanirwa kukomberedza mabhureki akawandisa uye kugadzirisa chinongedzo nenzira kwayo.
    // Iko kukosha chaiko ikozvino kunoratidzika seichi:
    //
    //        x lsb
    // /--------------\/
    // 1010101010101010.10101010101010 * 2^k
    // \-----/\-------/ \------------/
    //    q trunc.(inomiririrwa ne rem)
    //
    // Naizvozvo, kana mabheti akakomberedzwa ari!= 0.5 ULP, ivo vanosarudza kutenderera vega.
    // Kana ivo vakaenzana uye iyo yasara isiri zero, kukosha kuchiri kuda kutenderedzwa.
    // Chete kana mabheji akakomberedzwa ari 1/2 uye iyo yasara iri zero, isu tine hafu-kusvika-kunyange mamiriro.
    //
    let bits = x.bit_length();
    let lsb = bits - T::SIG_BITS as usize;
    let q = num::get_bits(&x, lsb, bits);
    let k = T::MIN_EXP_INT + lsb as i16;
    let z = rawfp::encode_normal(Unpacked::new(q, k));
    let q_even = q % 2 == 0;
    match num::compare_with_half_ulp(&x, lsb) {
        Greater => next_float(z),
        Less => z,
        Equal if rem.is_zero() && q_even => z,
        Equal => next_float(z),
    }
}

/// Zvakajairika kutenderera-kusvika-kunyangwe, zvakaomeserwa nekuita kutenderera zvichibva pane zvakasara zveboka.
fn round_by_remainder<T: RawFloat>(v: Big, r: Big, q: u64, z: T) -> T {
    let mut v_minus_r = v;
    v_minus_r.sub(&r);
    if r < v_minus_r {
        z
    } else if r > v_minus_r {
        next_float(z)
    } else if q % 2 == 0 {
        z
    } else {
        next_float(z)
    }
}