//! Ekushandisa mashandiro emabignums ayo asingaite pfungwa yakawandisa kuti ashanduke kuita nzira.

// FIXME Iri zita remu module rine nhamo, nekuti mamwe ma module anotumirawo `core::num`.

use crate::cmp::Ordering::{self, Equal, Greater, Less};

pub use crate::num::bignum::Big32x40 as Big;

/// Edza kana kutora mabiti ese asina kukosha kupfuura `ones_place` kunounza kukanganisa kwakaringana kushoma, kuenzana, kana kukura kupfuura 0.5 ULP.
///
pub fn compare_with_half_ulp(f: &Big, ones_place: usize) -> Ordering {
    if ones_place == 0 {
        return Less;
    }
    let half_bit = ones_place - 1;
    if f.get_bit(half_bit) == 0 {
        // <0.5 ULP
        return Less;
    }
    // Kana mabiti ese asara ari zero, iri= 0.5 ULP, zvikasadaro> 0.5 Kana pasisina mamwe mabiti (half_bit==0), pazasi zvakare zvinodzoka zvakaenzana.
    //
    for i in 0..half_bit {
        if f.get_bit(i) == 1 {
            return Greater;
        }
    }
    Equal
}

/// Inoshandura tambo yeASCII iine madhijitari chete kuva `u64`.
///
/// Haiti kuita cheki yekufashukira kana mavara asiri iwo, saka kana iye ari kufona akasangwarira, mhedzisiro ndeyekunyepedzera uye anogona panic (kunyangwe isiri `unsafe`).
/// Pamusoro pezvo, tambo dzisina chinhu dzinobatwa se zero.
/// Iri basa riripo nekuti
///
/// 1. kushandisa `FromStr` pa `&[u8]` inoda `from_utf8_unchecked`, zvinova zvakaipa, uye
/// 2. kubatanidza pamwechete mhedzisiro ye `integral.parse()` uye `fractional.parse()` yakanyanya kuomarara pane iri rese basa.
///
pub fn from_str_unchecked<'a, T>(bytes: T) -> u64
where
    T: IntoIterator<Item = &'a u8>,
{
    let mut result = 0;
    for &c in bytes {
        result = result * 10 + (c - b'0') as u64;
    }
    result
}

/// Inoshandura tambo yeASCII manhamba kuita bignum.
///
/// Sa `from_str_unchecked`, iri basa rinovimba nemuparadzanisi kusora asiri emadhijiti.
pub fn digits_to_big(integral: &[u8], fractional: &[u8]) -> Big {
    let mut f = Big::from_small(0);
    for &c in integral.iter().chain(fractional) {
        let n = (c - b'0') as u32;
        f.mul_small(10);
        f.add_small(n);
    }
    f
}

/// Inoputira bignum kuita makumi matanhatu nenhamba.Panics kana nhamba yacho yakanyanyisa kukura.
pub fn to_u64(x: &Big) -> u64 {
    assert!(x.bit_length() < 64);
    let d = x.digits();
    if d.len() < 2 { d[0] as u64 } else { (d[1] as u64) << 32 | d[0] as u64 }
}

/// Inoburitsa huwandu hwebiti.

/// Index 0 ndiyo isinganyanyi kukosha uye huwandu ihafu-yakavhurika senguva dzose.
/// Panics kana ikabvunzwa kuti ibvise mabiti akawanda kupfuura kukodzera mumhando yekudzoka.
pub fn get_bits(x: &Big, start: usize, end: usize) -> u64 {
    assert!(end - start <= 64);
    let mut result: u64 = 0;
    for i in (start..end).rev() {
        result = result << 1 | x.get_bit(i) as u64;
    }
    result
}