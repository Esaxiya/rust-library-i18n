use crate::cmp;
use crate::fmt;
use crate::mem;
use crate::num::NonZeroUsize;
use crate::ptr::NonNull;

// Nepo basa iri richishandiswa munzvimbo imwechete uye kuitiswa kwacho kunogona kuiswa mukati, kuyedza kwekutanga kuzviita kwakaita kuti rustc inonoke:
//
//
// * https://github.com/rust-lang/rust/pull/72189
// * https://github.com/rust-lang/rust/pull/79827
//
const fn size_align<T>() -> (usize, usize) {
    (mem::size_of::<T>(), mem::align_of::<T>())
}

/// Kurongedzwa kwe block of memory.
///
/// Muenzaniso we `Layout` unotsanangura kumwe kurongeka kwendangariro.
/// Iwe unovaka `Layout` kumusoro senge yekuisa yekupa kune anogovera.
///
/// Zvese zvimiro zvine saizi inosangana uye simba-re-maviri kuenderana.
///
/// (Ziva kuti marongero *haadi* anodikanwa kuti ave neusina zero saizi, kunyangwe `GlobalAlloc` inoda kuti zvese zvikumbiro zvendangariro zvive zvisina zero muhukuru.
/// Anofona anofanirwa kuve nechokwadi chekuti mamiriro akaita seaya asangana, shandisa chaiwo vanogovera vane zvakasununguka zvinodiwa, kana kushandisa yakanyanya kureruka `Allocator` interface.)
///
///
///
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[lang = "alloc_layout"]
pub struct Layout {
    // saizi yebhokisi rakakumbirwa ndangariro, kuyerwa nemabheti.
    size_: usize,

    // kuenderana kwechikwata chakakumbirwa chendangariro, chakayerwa nemabheti.
    // isu tinoona kuti ichi chinogara chiri simba-re-vaviri, nekuti ma API senge `posix_memalign` anochida uye chipingamupinyi chinonzwisisika kumanikidza paVagadziri veMagadzirirwo.
    //
    //
    // (Zvisinei, isu hatidi zvakafanana tichiti `align>= sizeof(void *)`, even though that is* also* a requirement of `posix_memalign`.)
    //
    //
    align_: NonZeroUsize,
}

impl Layout {
    /// Inogadzira `Layout` kubva pane yakapihwa `size` uye `align`, kana inodzosera `LayoutError` kana chero eanotevera mamiriro asina kusangana:
    ///
    /// * `align` haifanire kuva zero,
    ///
    /// * `align` rinofanira kuva simba rezviviri,
    ///
    /// * `size`, painotenderedzwa kusvika kune yakawanda yepadyo ye `align`, haifanire kufashukira (kureva, kukosha kwakatenderedzwa kunofanirwa kuve kushoma kana kuenzana ne `usize::MAX`).
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn from_size_align(size: usize, align: usize) -> Result<Self, LayoutError> {
        if !align.is_power_of_two() {
            return Err(LayoutError { private: () });
        }

        // (simba-re-maviri rinoreva kuenderana!=0.)

        // Yakapetwa kumusoro saizi ndeiyi:
        //   size_rounded_up=(size + align, 1)&! (fambisa, 1);
        //
        // Isu tinoziva kubva kumusoro kuti kuenderana!=0.
        // Kana kuwedzera (align, 1) kusingafashukire, ipapo kutenderera kunenge kwakanaka.
        //
        // Zvakare,&-masking ne! (Align, 1) ichabvisa chete yakaderera-odha-mabheti.
        // Nekudaro kana kufashukira kukaitika pamwe nemari, iyo&-mask haigone kubvisa zvakakwana kuti ibvise kufashukira.
        //
        //
        // Pamusoro zvinoreva kuti kutarisa kwekupfupisa kuri kudikanwa uye kwakaringana.
        //
        if size > usize::MAX - (align - 1) {
            return Err(LayoutError { private: () });
        }

        // Kachengeteka: mamiriro e `from_size_align_unchecked` anga ari
        // yakaongororwa pamusoro.
        unsafe { Ok(Layout::from_size_align_unchecked(size, align)) }
    }

    /// Inogadzira dhizaini, ichipfuura cheki dzese.
    ///
    /// # Safety
    ///
    /// Iri basa harina kuchengeteka sezvo risingatarise zvirevo kubva ku [`Layout::from_size_align`].
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub const unsafe fn from_size_align_unchecked(size: usize, align: usize) -> Self {
        // Kachengeteka: iye anodana anofanira kuona kuti `align` yakakura kudarika zero.
        Layout { size_: size, align_: unsafe { NonZeroUsize::new_unchecked(align) } }
    }

    /// Hushoma saizi mumabheti echirangaridzo cheiyi dhizaini.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn size(&self) -> usize {
        self.size_
    }

    /// Iwo mashoma Byte kuenderana kweye memory block yeiyi dhizaini.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "const_alloc_layout", since = "1.50.0")]
    #[inline]
    pub const fn align(&self) -> usize {
        self.align_.get()
    }

    /// Inogadzira `Layout` yakakodzera kubata mutengo werudzi `T`.
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[rustc_const_stable(feature = "alloc_layout_const_new", since = "1.42.0")]
    #[inline]
    pub const fn new<T>() -> Self {
        let (size, align) = size_align::<T>();
        // Kachengeteka: kuenderana kunovimbiswa ne Rust kuve simba reviri uye
        // saizi + align combo inovimbiswa kukwana munzvimbo yedu yekero.
        // Nekuda kweizvozvo shandisa unchecked muvaki pano kudzivirira kuisa kodhi iyo panics kana isina kugadzirirwa zvakakwana.
        //
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Inogadzira dhizaini inotsanangura rekodhi inogona kushandiswa kugovera chimiro chekutsigira `T` (inogona kunge iri trait kana imwe mhando isina kusarudzika sechidimbu).
    ///
    ///
    #[stable(feature = "alloc_layout", since = "1.28.0")]
    #[inline]
    pub fn for_value<T: ?Sized>(t: &T) -> Self {
        let (size, align) = (mem::size_of_val(t), mem::align_of_val(t));
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // KUCHENGETEKA: ona chikonzero mu `new` nei ichi chiri kushandisa musiyano usina kuchengeteka
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Inogadzira dhizaini inotsanangura rekodhi inogona kushandiswa kugovera chimiro chekutsigira `T` (inogona kunge iri trait kana imwe mhando isina kusarudzika sechidimbu).
    ///
    /// # Safety
    ///
    /// Iri basa rakachengeteka chete kudana kana zvinotevera mamiriro abata:
    ///
    /// - Kana `T` iri `Sized`, iri basa rinogara rakachengeteka kudana.
    /// - Kana muswe usina kukosheswa we `T` uri:
    ///     - [slice], ipapo kureba kwemuswe wekucheka unofanirwa kuve unoverengerwa mukati, uye saizi yeiyo *kukosha kwese*(ine simba muswe kureba + chiyero chekutanga) inofanira kukwana mu `isize`.
    ///     - [trait object], ipapo chikamu chinogadziriswa che pointer chinofanirwa kunongedzera kune chaiyo vtable yerudzi `T` yakawanikwa neiyo unsizing coersion, uye saizi yeiyo *kukosha kwese*(ine simba muswe kureba + chiyero chakaenzana) inofanira kukwana mu `isize`.
    ///
    ///     - (unstable) [extern type], zvino basa iri rinogara rakachengeteka kufona, asi may panic kana neimwe nzira idzosere kukosha kusiri iko, sezvo marongero erudzi rwekunze asingazivikanwe.
    ///     Aya maitiro akafanana ne [`Layout::for_value`] pane chirevo kune yekunze mhando muswe.
    ///     - kana zvisina kudaro, zvakachengetedzwa hazvibvumidzwe kudaidza iri basa.
    ///
    /// [trait object]: ../../book/ch17-02-trait-objects.html
    /// [extern type]: ../../unstable-book/language-features/extern-types.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "layout_for_ptr", issue = "69835")]
    pub unsafe fn for_value_raw<T: ?Sized>(t: *const T) -> Self {
        // KUNYENGETEKA: isu tinopfuudza izvo zvinodiwa zveaya mabasa kune anofona
        let (size, align) = unsafe { (mem::size_of_val_raw(t), mem::align_of_val_raw(t)) };
        debug_assert!(Layout::from_size_align(size, align).is_ok());
        // KUCHENGETEKA: ona chikonzero mu `new` nei ichi chiri kushandisa musiyano usina kuchengeteka
        unsafe { Layout::from_size_align_unchecked(size, align) }
    }

    /// Inogadzira `NonNull` iyo yakaturika, asi yakanyatsoenderana neiyi Layout.
    ///
    /// Ziva kuti pointer kukosha kunogona kunge kuchimiririra pointer inoshanda, zvinoreva kuti izvi hazvifanire kushandiswa se "not yet initialized" sentinel kukosha.
    /// Mhando dzinogovana zvine usimbe dzinofanirwa kuteedzera kutanga neimwe nzira.
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub const fn dangling(&self) -> NonNull<u8> {
        // Kachengeteka: kuenderana kunovimbiswa kuve isiri zero
        unsafe { NonNull::new_unchecked(self.align() as *mut u8) }
    }

    /// Inogadzira dhizaini inotsanangudza rekodhi iyo inogona kubata kukosha kweiyo yakafanana dhizaini se `self`, asi izvo zvakare zvinowirirana nekuenderana `align` (kuyerwa nemabheti).
    ///
    ///
    /// Kana `self` yatosangana nematanho akatemerwa, zvobva zvadzoka `self`.
    ///
    /// Ziva kuti iyi nzira haina kuwedzera chero padding kune iyo saizi saizi, zvisinei nekuti iyo yakadzoserwa dhizaini ine kusiyana kwakasiyana.
    /// Mune mamwe mazwi, kana `K` ine saizi 16, `K.align_to(32)` ichave ichiripo * ine saizi 16.
    ///
    /// Inodzorera kukanganisa kana kusanganiswa kwe `self.size()` uye yakapihwa `align` ichityora mamiriro akanyorwa mu [`Layout::from_size_align`].
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn align_to(&self, align: usize) -> Result<Self, LayoutError> {
        Layout::from_size_align(self.size(), cmp::max(self.align(), align))
    }

    /// Inodzorera huwandu hwepadding yatinofanira kuisa mushure me `self` kuona kuti kero inotevera inogutsa `align` (kuyerwa nemabheti).
    ///
    /// semuenzaniso, kana `self.size()` iri 9, ipapo `self.padding_needed_for(4)` inodzoka 3, nekuti ndiyo nhamba shoma yemabheti epadding anodikanwa kuti uwane kero yakaenderana ne4 (uchifungidzira kuti inoenderana memory block inotangira pakero ina-yakatarisana).
    ///
    ///
    /// Iko kukosha kwekudzoka kweiri basa hakuna chirevo kana `align` isiri simba-re-maviri.
    ///
    /// Ziva kuti iko kushandiswa kwemutengo wakadzoserwa kunoda kuti `align` ive shoma kana kuenzana nekuenderana kwekero yekutanga yekero rese rakagoverwa ndangariro.Imwe nzira yekugutsa ichi chipingaidzo ndeyekuona `align <= self.align()`.
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[rustc_const_unstable(feature = "const_alloc_layout", issue = "67521")]
    #[inline]
    pub const fn padding_needed_for(&self, align: usize) -> usize {
        let len = self.size();

        // Yakapetwa kumusoro kukosha ndeye:
        //   len_rounded_up=(len + align, 1)&! (fambisa, 1);
        // uyezve tinodzosera iyo padding mutsauko: `len_rounded_up - len`.
        //
        // Isu tinoshandisa modular arithmetic mukati mese:
        //
        // 1. align inovimbiswa kuve> 0, saka pindirana, 1 inogara ichishanda.
        //
        // 2.
        // `len + align - 1` inogona kufashukira nekuwanda kwe `align - 1`, saka iyo&-mask ine `!(align - 1)` ichave nechokwadi chekuti mune yekufashukira, `len_rounded_up` ichave iri 0.
        //
        //    Nekudaro iyo yakadzoserwa padding, kana ikawedzerwa ku `len`, inobereka 0, izvo zvishoma zvinogutsa kuenderana `align`.
        //
        // (Ehe, kuyedza kugovera mabhuroko endangariro ane saizi uye padding inopfachukira nenzira iri pamusoro inofanirwa kukonzera kuti mupi aburitse chikanganiso zvakadaro.)
        //
        //
        //
        //

        let len_rounded_up = len.wrapping_add(align).wrapping_sub(1) & !align.wrapping_sub(1);
        len_rounded_up.wrapping_sub(len)
    }

    /// Inogadzira dhizaini nekutenderedza saizi yeiyi dhizaini kusvika kune yakawanda yeakarongedzwa marongero.
    ///
    ///
    /// Izvi zvakaenzana nekuwedzera mhedzisiro ye `padding_needed_for` kuhukuru hwesimba razvino.
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn pad_to_align(&self) -> Layout {
        let pad = self.padding_needed_for(self.align());
        // Izvi hazvigone kufashukira.Kutora kubva kune inogara iripo yeRarongedzo:
        // > `size`, painotenderedzwa kusvika kune yakawanda yepadyo ye `align`,
        // > haifanire kufashukira (kureva., iyo yakakomberedzwa kukosha inofanira kunge iri pasi pe
        // > `usize::MAX`)
        let new_size = self.size() + pad;

        Layout::from_size_align(new_size, self.align()).unwrap()
    }

    /// Inogadzira dhizaini inotsanangura zvinyorwa zve `n` zviitiko zve `self`, ine huwandu hwakakodzera hwekupfekedza pakati peimwe neimwe kuona kuti chiitiko chega chega chakapihwa saizi yayo yakakumbirwa uye kuenderana.
    /// Pakubudirira, inodzosera `(k, offs)` uko `k` ndiyo marongero eakarongedzwa uye `offs` ndiyo nhambwe iri pakati pekutanga kwechinhu chimwe nechimwe mune yakarongeka.
    ///
    /// Pane arithmetic kufashukira, inodzosera `LayoutError`.
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat(&self, n: usize) -> Result<(Self, usize), LayoutError> {
        // Izvi hazvigone kufashukira.Kutora kubva kune inogara iripo yeRarongedzo:
        // > `size`, painotenderedzwa kusvika kune yakawanda yepadyo ye `align`,
        // > haifanire kufashukira (kureva., iyo yakakomberedzwa kukosha inofanira kunge iri pasi pe
        // > `usize::MAX`)
        let padded_size = self.size() + self.padding_needed_for(self.align());
        let alloc_size = padded_size.checked_mul(n).ok_or(LayoutError { private: () })?;

        // KUCHENGETEKA: self.align yatove kuzivikanwa kuve inoshanda uye alloc_size yave iri
        // padded kare.
        unsafe { Ok((Layout::from_size_align_unchecked(alloc_size, self.align()), padded_size)) }
    }

    /// Inogadzira dhizaini inotsanangura rekodhi ye `self` ichiteverwa ne `next`, kusanganisira chero padding inodiwa kuona kuti `next` ichaenderana zvakanaka, asi *hapana trailing padding*.
    ///
    /// Kuti uenzanise C inomiririra dhizaini `repr(C)`, unofanirwa kufonera `pad_to_align` mushure mekuwedzera chimiro pamwe neminda yese.
    /// (Iko hakuna nzira yekufananidza yakasarudzika Rust inomiririra dhizaini `repr(Rust)`, as it is unspecified.)
    ///
    /// Ziva kuti kuenderana kwenzira dzinoguma ichave yakanyanya kuwanda yeiyo `self` uye `next`, kuitira kuti uve nechokwadi chekuenzanirana kwezvikamu zvese zviri zviviri.
    ///
    /// Inodzorera `Ok((k, offset))`, uko `k` kurongeka kweiyo concatenated rekodhi uye `offset` inzvimbo ine hukama, mumabheti, ekutanga kwe `next` yakadzamidzirwa mukati meiyo concatenated rekodhi (uchifungidzira kuti iyo rekodhi pachayo inotanga kubva pakubvisa 0).
    ///
    ///
    /// Pane arithmetic kufashukira, inodzosera `LayoutError`.
    ///
    /// # Examples
    ///
    /// Kuti uverenge marongero eiyo `#[repr(C)]` chimiro uye zvinokonzereswa neminda kubva kuminda yayo 'marongero:
    ///
    /// ```rust
    /// # use std::alloc::{Layout, LayoutError};
    /// pub fn repr_c(fields: &[Layout]) -> Result<(Layout, Vec<usize>), LayoutError> {
    ///     let mut offsets = Vec::new();
    ///     let mut layout = Layout::from_size_align(0, 1)?;
    ///     for &field in fields {
    ///         let (new_layout, offset) = layout.extend(field)?;
    ///         layout = new_layout;
    ///         offsets.push(offset);
    ///     }
    ///     // Rangarira kupedzisa ne `pad_to_align`!
    ///     Ok((layout.pad_to_align(), offsets))
    /// }
    /// # // test kuti zvinoshanda
    /// # #[repr(C)] struct S { a: u64, b: u32, c: u16, d: u32 }
    /// # let s = Layout::new::<S>();
    /// # let u16 = Layout::new::<u16>();
    /// # let u32 = Layout::new::<u32>();
    /// # let u64 = Layout::new::<u64>();
    /// # assert_eq!(repr_c(&[u64, u32, u16, u32]), Ok((s, vec![0, 8, 12, 16])));
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn extend(&self, next: Self) -> Result<(Self, usize), LayoutError> {
        let new_align = cmp::max(self.align(), next.align());
        let pad = self.padding_needed_for(next.align());

        let offset = self.size().checked_add(pad).ok_or(LayoutError { private: () })?;
        let new_size = offset.checked_add(next.size()).ok_or(LayoutError { private: () })?;

        let layout = Layout::from_size_align(new_size, new_align)?;
        Ok((layout, offset))
    }

    /// Inogadzira dhizaini inotsanangura zvinyorwa zve `n` zviitiko zve `self`, isina padding pakati peimwe nhambo.
    ///
    /// Ziva kuti, kusiyana ne `repeat`, `repeat_packed` haivimbise kuti zviitiko zvakadzokororwa zve `self` zvichanyatsoenderana, kunyangwe kana chiitiko chakapihwa che `self` chakanyatsoenderana.
    /// Mune mamwe mazwi, kana chimiro chakadzoserwa ne `repeat_packed` chishandiswa kugovera rondedzero, hazvivimbiswe kuti zvinhu zvese zviri mumutsara zvichaenderana.
    ///
    /// Pane arithmetic kufashukira, inodzosera `LayoutError`.
    ///
    ///
    ///
    ///
    ///
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn repeat_packed(&self, n: usize) -> Result<Self, LayoutError> {
        let size = self.size().checked_mul(n).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(size, self.align())
    }

    /// Inogadzira dhizaini inotsanangura rekodhi ye `self` ichiteverwa ne `next` isina yekuwedzera padding pakati pezviviri.
    /// Sezvo pasina padding yakaiswa, kuenderana kwe `next` hakuna basa, uye haina kusanganiswa *zvachose* muchimiro chinoguma.
    ///
    ///
    /// Pane arithmetic kufashukira, inodzosera `LayoutError`.
    ///
    #[unstable(feature = "alloc_layout_extra", issue = "55724")]
    #[inline]
    pub fn extend_packed(&self, next: Self) -> Result<Self, LayoutError> {
        let new_size = self.size().checked_add(next.size()).ok_or(LayoutError { private: () })?;
        Layout::from_size_align(new_size, self.align())
    }

    /// Inogadzira dhizaini inotsanangura zvinyorwa zve `[T; n]`.
    ///
    /// Pane arithmetic kufashukira, inodzosera `LayoutError`.
    #[stable(feature = "alloc_layout_manipulation", since = "1.44.0")]
    #[inline]
    pub fn array<T>(n: usize) -> Result<Self, LayoutError> {
        let (layout, offset) = Layout::new::<T>().repeat(n)?;
        debug_assert_eq!(offset, mem::size_of::<T>());
        Ok(layout.pad_to_align())
    }
}

#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
pub type LayoutErr = LayoutError;

/// Iyo parameter yakapihwa `Layout::from_size_align` kana imwe `Layout` mugadziri haigutse zvimisikidzo zvayo zvakanyorwa.
///
///
#[stable(feature = "alloc_layout_error", since = "1.50.0")]
#[derive(Clone, PartialEq, Eq, Debug)]
pub struct LayoutError {
    private: (),
}

// (isu tinoda izvi zasi kwekupinza kwe trait Kanganiso)
#[stable(feature = "alloc_layout", since = "1.28.0")]
impl fmt::Display for LayoutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("invalid parameters to Layout::from_size_align")
    }
}