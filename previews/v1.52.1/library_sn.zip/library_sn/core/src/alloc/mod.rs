//! Ndangariro kugoverwa APIs

#![stable(feature = "alloc_module", since = "1.28.0")]

mod global;
mod layout;

#[stable(feature = "global_alloc", since = "1.28.0")]
pub use self::global::GlobalAlloc;
#[stable(feature = "alloc_layout", since = "1.28.0")]
pub use self::layout::Layout;
#[stable(feature = "alloc_layout", since = "1.28.0")]
#[rustc_deprecated(
    since = "1.52.0",
    reason = "Name does not follow std convention, use LayoutError",
    suggestion = "LayoutError"
)]
#[allow(deprecated, deprecated_in_future)]
pub use self::layout::LayoutErr;

#[stable(feature = "alloc_layout_error", since = "1.50.0")]
pub use self::layout::LayoutError;

use crate::fmt;
use crate::ptr::{self, NonNull};

/// Iko kukanganisa kwe `AllocError` kunoratidza kutadza kugoverwa kungave kuri nekuda kwekuneta kwesimba kana chimwe chinhu chisina kunaka kana uchibatanidza nharo dzakapihwa dzakapihwa nemugoveri uyu.
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub struct AllocError;

// (isu tinoda izvi zasi kwekupinza kwe trait Kanganiso)
#[unstable(feature = "allocator_api", issue = "32838")]
impl fmt::Display for AllocError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("memory allocation failed")
    }
}

/// Kuitwa kwe `Allocator` kunogona kugovera, kukura, kushomeka, uye kugadziridza zvimisikidzo zvematare zvinotsanangurwa kuburikidza ne [`Layout`][].
///
/// `Allocator` yakagadzirirwa kuitirwa paZSTs, mareferenzi, kana zvinongedzo zvehungwaru nekuti kuve neyakagovana senge `MyAlloc([u8; N])` haigone kufambiswa, pasina kukwidziridza iwo mainongedzo kumenduru yakapihwa.
///
/// Kusiyana ne [`GlobalAlloc`][], zero-saizi migove inobvumidzwa mu `Allocator`.
/// Kana mugadziri wepasi asingatsigire izvi (sajemalloc) kana kudzorera null pointer (senge `libc::malloc`), izvi zvinofanirwa kubatwa nekuitwa.
///
/// ### Parizvino yakapihwa ndangariro
///
/// Dzimwe dzenzira dzinoda kuti memory block ive *parizvino yakapihwa* kuburikidza neyakagovana.Izvi zvinoreva kuti:
///
/// * kero yekutanga yeiyo memory block yakambodzoserwa ne [`allocate`], [`grow`], kana [`shrink`], uye
///
/// * memory block haisati yambogadziriswa, uko mablock anogona kuendeswa zvakananga nekupfuudzwa ku [`deallocate`] kana kuchinjwa nekuendeswa ku [`grow`] kana [`shrink`] iyo inodzosera `Ok`.
///
/// Kana `grow` kana `shrink` dzadzoka `Err`, iyo yakapfuura pointer inoramba ichishanda.
///
/// [`allocate`]: Allocator::allocate
/// [`grow`]: Allocator::grow
/// [`shrink`]: Allocator::shrink
/// [`deallocate`]: Allocator::deallocate
///
/// ### Kuyeuka ndangariro
///
/// Dzimwe dzenzira dzinoda kuti dhizaini *ikwane* memory block.
/// Zvazvinoreva pakurongwa kwe "fit" memory memory zvinoreva (kana zvakaenzana, kune memory memory kusvika "fit" dhizaini) ndeyekuti mamiriro anotevera anofanira kubata:
///
/// * Iyo block inofanira kugoverwa pamwe chete kuenderana se [`layout.align()`], uye
///
/// * Iyo yakapihwa [`layout.size()`] inofanira kuwira mukati mehurefu `min ..= max`, uko:
///   - `min` hukuru hwegadziriro ichangobva kushandiswa kugovera bhuroka, uye
///   - `max` saizi yazvino chaiyo yakadzoserwa kubva ku [`allocate`], [`grow`], kana [`shrink`].
///
/// [`layout.align()`]: Layout::align
/// [`layout.size()`]: Layout::size
///
/// # Safety
///
/// * Ndangariro dzinovharira dzakadzoserwa kubva kune anogovera dzinofanira kunongedzera kune yakakodzera ndangariro uye chengetedza hunhu hwavo kudzamara muenzaniso uye ese ayo matombo anowiswa,
///
/// * Kubatanidza kana kufambisa mugoveri hakufanirwe kuita kuti zviyeuchidzo zvendangariro zvadzoserwa kubva kune unozvipa.Mugoveri akaumbwa anofanirwa kuzvibata seakagovana mumwe chete, uye
///
/// * chero chinongedzo kune memory block inova [*currently allocated*] inogona kupfuudzwa kune chero imwe nzira yeanogovera.
///
/// [*currently allocated*]: #currently-allocated-memory
///
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "allocator_api", issue = "32838")]
pub unsafe trait Allocator {
    /// Kuedza kugovera block of memory.
    ///
    /// Pakubudirira, inodzosera musangano we [`NonNull<[u8]>`][NonNull] saizi uye yekumisidzana vimbiso ye `layout`.
    ///
    /// Bhokisi rakadzorerwa rinogona kunge riine saizi yakakura kupfuura yakatsanangurwa ne `layout.size()`, uye inogona kana inogona kunge isina kutanga mukati.
    ///
    /// # Errors
    ///
    /// Kudzosera `Err` kunoratidza kuti chero ndangariro yakaneta kana `layout` haisangane saizi yemugovanisi kana zvipingamupinyi zvekuenderana.
    ///
    /// Maitirwo anokurudzirwa kudzosa `Err` pakurangarira ndangariro pane kuvhunduka kana kubvisa nhumbu, asi ichi hachisi chinhu chakasimba.
    /// (Zvikurukuru: zviri *pamutemo* kushandisa iyi trait iri pamusoro penzvimbo yekuzvarwa yekugovera raibhurari iyo inobvisa pakurangarira kuneta.)
    ///
    /// Vatengi vanoshuvira kubvisa komputa mukupindura kukanganisa kwekugovera vanokurudzirwa kufonera [`handle_alloc_error`] basa, pane kukumbira zvakananga `panic!` kana zvakafanana.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError>;

    /// Inoita se `allocate`, asi zvakare inovimbisa kuti iyo yekudzosa ndangariro haina zero-yakatangwa.
    ///
    /// # Errors
    ///
    /// Kudzosera `Err` kunoratidza kuti chero ndangariro yakaneta kana `layout` haisangane saizi yemugovanisi kana zvipingamupinyi zvekuenderana.
    ///
    /// Maitirwo anokurudzirwa kudzosa `Err` pakurangarira ndangariro pane kuvhunduka kana kubvisa nhumbu, asi ichi hachisi chinhu chakasimba.
    /// (Zvikurukuru: zviri *pamutemo* kushandisa iyi trait iri pamusoro penzvimbo yekuzvarwa yekugovera raibhurari iyo inobvisa pakurangarira kuneta.)
    ///
    /// Vatengi vanoshuvira kubvisa komputa mukupindura kukanganisa kwekugovera vanokurudzirwa kufonera [`handle_alloc_error`] basa, pane kukumbira zvakananga `panic!` kana zvakafanana.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let ptr = self.allocate(layout)?;
        // Kachengeteka: `alloc` inodzosera inoshanda memory block
        unsafe { ptr.as_non_null_ptr().as_ptr().write_bytes(0, ptr.len()) }
        Ok(ptr)
    }

    /// Inobvisa ndangariro inotaurwa ne `ptr`.
    ///
    /// # Safety
    ///
    /// * `ptr` inofanirwa kuratidza demo rekurangarira [*currently allocated*] kuburikidza nemugovanisi, uye
    /// * `layout` unofanirwa [*fit*] iyo block memory.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout);

    /// Kuedza kuwedzera memory memory.
    ///
    /// Inodzorera [`NonNull<[u8]>`][NonNull] nyowani ine pointer uye saizi chaiyo yeyakapihwa ndangariro.Iyo pointer yakakodzera kubata data rakatsanangurwa ne `new_layout`.
    /// Kuti uite izvi, iye anogovera anogona kuwedzera mugove unorehwa ne `ptr` kuti ikwane chimiro chitsva.
    ///
    /// Kana izvi zvadzosa `Ok`, saka muridzi weye memory block inotsanangurwa ne `ptr` yakaendeswa kune akagovera.
    /// Ndangariro dzinogona kana kuti hadzina kunge dzakasunungurwa, uye dzinofanirwa kutorwa sedzisingabvumirwe kunze kwekunge dzadzoserwa kumashure kune akafona zvakare kuburikidza nemutengo wekudzoka weiyi nzira.
    ///
    /// Kana nzira iyi ikadzosa `Err`, saka muridzi weye memory block haina kuendeswa kune inovagovera, uye zviri mukati memusoro block hazvina kuchinjika.
    ///
    /// # Safety
    ///
    /// * `ptr` inofanirwa kuratidza demo rekurangarira [*currently allocated*] kuburikidza nemugovanisi.
    /// * `old_layout` unofanirwa [*fit*] iyo block yekumusoro (Iyo `new_layout` nharo haifanire kuikwana.).
    /// * `new_layout.size()` inofanirwa kuve yakakura kudarika kana kuenzana ne `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Inodzorera `Err` kana marongero matsva asinga svike saizi yemugadziri uye zvipingamupinyi zvekunongedza kweanopa, kana kana kukura neimwe nzira kuchikundikana.
    ///
    /// Maitirwo anokurudzirwa kudzosa `Err` pakurangarira ndangariro pane kuvhunduka kana kubvisa nhumbu, asi ichi hachisi chinhu chakasimba.
    /// (Zvikurukuru: zviri *pamutemo* kushandisa iyi trait iri pamusoro penzvimbo yekuzvarwa yekugovera raibhurari iyo inobvisa pakurangarira kuneta.)
    ///
    /// Vatengi vanoshuvira kubvisa komputa mukupindura kukanganisa kwekugovera vanokurudzirwa kufonera [`handle_alloc_error`] basa, pane kukumbira zvakananga `panic!` kana zvakafanana.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // Kachengeteka: nekuti `new_layout.size()` inofanirwa kuve yakakura kudarika kana yakaenzana ne
        // `old_layout.size()`, zvese zvekare uye nyowani ndangariro kugoverwa zvinoshanda pakuverenga uye kunyorera `old_layout.size()` mabheti.
        // Zvakare, nekuti mugove wekare wanga usati waendeswa, haugone kupfuura `new_ptr`.
        // Nekudaro, kufona ku `copy_nonoverlapping` kwakachengeteka.
        // Chibvumirano chekuchengetedza che `dealloc` chinofanira kuchengetedzwa neanodana.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Inoita sa `grow`, asi zvakare inovimbisa kuti izvo zvitsva zvirimo zvakaiswa zero vasati vadzorerwa.
    ///
    /// Iyo memory block ichave iine zvinotevera zvirimo mushure mekubudirira kufona ku
    /// `grow_zeroed`:
    ///   * Byte `0..old_layout.size()` inochengetwa kubva kune yekutanga kugoverwa.
    ///   * Byte `old_layout.size()..old_size` inogona kuchengetedzwa kana zeroed, zvinoenderana neyakagoverwa kuitisa.
    ///   `old_size` inoreva kukura kweye memory block pamberi peiyo `grow_zeroed` kufona, iyo inogona kuve yakakura kudarika saizi iyo yakatanga kukumbirwa payakapihwa.
    ///   * Mabheti `old_size..new_size` akaiswa zero.`new_size` inoreva kukura kweye memory block yakadzoserwa ne `grow_zeroed` kufona.
    ///
    /// # Safety
    ///
    /// * `ptr` inofanirwa kuratidza demo rekurangarira [*currently allocated*] kuburikidza nemugovanisi.
    /// * `old_layout` unofanirwa [*fit*] iyo block yekumusoro (Iyo `new_layout` nharo haifanire kuikwana.).
    /// * `new_layout.size()` inofanirwa kuve yakakura kudarika kana kuenzana ne `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Inodzorera `Err` kana marongero matsva asinga svike saizi yemugadziri uye zvipingamupinyi zvekunongedza kweanopa, kana kana kukura neimwe nzira kuchikundikana.
    ///
    /// Maitirwo anokurudzirwa kudzosa `Err` pakurangarira ndangariro pane kuvhunduka kana kubvisa nhumbu, asi ichi hachisi chinhu chakasimba.
    /// (Zvikurukuru: zviri *pamutemo* kushandisa iyi trait iri pamusoro penzvimbo yekuzvarwa yekugovera raibhurari iyo inobvisa pakurangarira kuneta.)
    ///
    /// Vatengi vanoshuvira kubvisa komputa mukupindura kukanganisa kwekugovera vanokurudzirwa kufonera [`handle_alloc_error`] basa, pane kukumbira zvakananga `panic!` kana zvakafanana.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() >= old_layout.size(),
            "`new_layout.size()` must be greater than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate_zeroed(new_layout)?;

        // Kachengeteka: nekuti `new_layout.size()` inofanirwa kuve yakakura kudarika kana yakaenzana ne
        // `old_layout.size()`, zvese zvekare uye nyowani ndangariro kugoverwa zvinoshanda pakuverenga uye kunyorera `old_layout.size()` mabheti.
        // Zvakare, nekuti mugove wekare wanga usati waendeswa, haugone kupfuura `new_ptr`.
        // Nekudaro, kufona ku `copy_nonoverlapping` kwakachengeteka.
        // Chibvumirano chekuchengetedza che `dealloc` chinofanira kuchengetedzwa neanodana.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), old_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Kuedza kudzikisira memory memory.
    ///
    /// Inodzorera [`NonNull<[u8]>`][NonNull] nyowani ine pointer uye saizi chaiyo yeyakapihwa ndangariro.Iyo pointer yakakodzera kubata data rakatsanangurwa ne `new_layout`.
    /// Kuti uite izvi, anogovera anogona kudzikisira mugove unorehwa ne `ptr` kuti ikwane marongero matsva.
    ///
    /// Kana izvi zvadzosa `Ok`, saka muridzi weye memory block inotsanangurwa ne `ptr` yakaendeswa kune akagovera.
    /// Ndangariro dzinogona kana kuti hadzina kunge dzakasunungurwa, uye dzinofanirwa kutorwa sedzisingabvumirwe kunze kwekunge dzadzoserwa kumashure kune akafona zvakare kuburikidza nemutengo wekudzoka weiyi nzira.
    ///
    /// Kana nzira iyi ikadzosa `Err`, saka muridzi weye memory block haina kuendeswa kune inovagovera, uye zviri mukati memusoro block hazvina kuchinjika.
    ///
    /// # Safety
    ///
    /// * `ptr` inofanirwa kuratidza demo rekurangarira [*currently allocated*] kuburikidza nemugovanisi.
    /// * `old_layout` unofanirwa [*fit*] iyo block yekumusoro (Iyo `new_layout` nharo haifanire kuikwana.).
    /// * `new_layout.size()` inofanira kunge iri diki pane kana yakaenzana ne `old_layout.size()`.
    ///
    /// [*currently allocated*]: #currently-allocated-memory
    /// [*fit*]: #memory-fitting
    ///
    /// # Errors
    ///
    /// Inodzorera `Err` kana marongero matsva asinga svike saizi yemugadziri uye zvipingamupinyi zvekunongedza kweanopa, kana kana kudzikira neimwe nzira kukatadza.
    ///
    /// Maitirwo anokurudzirwa kudzosa `Err` pakurangarira ndangariro pane kuvhunduka kana kubvisa nhumbu, asi ichi hachisi chinhu chakasimba.
    /// (Zvikurukuru: zviri *pamutemo* kushandisa iyi trait iri pamusoro penzvimbo yekuzvarwa yekugovera raibhurari iyo inobvisa pakurangarira kuneta.)
    ///
    /// Vatengi vanoshuvira kubvisa komputa mukupindura kukanganisa kwekugovera vanokurudzirwa kufonera [`handle_alloc_error`] basa, pane kukumbira zvakananga `panic!` kana zvakafanana.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        debug_assert!(
            new_layout.size() <= old_layout.size(),
            "`new_layout.size()` must be smaller than or equal to `old_layout.size()`"
        );

        let new_ptr = self.allocate(new_layout)?;

        // Kachengeteka: nekuti `new_layout.size()` inofanira kunge iri pasi kana kuenzana ne
        // `old_layout.size()`, zvese zvekare uye nyowani ndangariro kugoverwa zvinoshanda pakuverenga uye kunyorera `new_layout.size()` mabheti.
        // Zvakare, nekuti mugove wekare wanga usati waendeswa, haugone kupfuura `new_ptr`.
        // Nekudaro, kufona ku `copy_nonoverlapping` kwakachengeteka.
        // Chibvumirano chekuchengetedza che `dealloc` chinofanira kuchengetedzwa neanodana.
        unsafe {
            ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_mut_ptr(), new_layout.size());
            self.deallocate(ptr, old_layout);
        }

        Ok(new_ptr)
    }

    /// Inogadzira "by reference" adapter yeichi chiitiko che `Allocator`.
    ///
    /// Iyo adapta yakadzoserwa zvakare inoshandisa `Allocator` uye inongokwereta izvi.
    #[inline(always)]
    fn by_ref(&self) -> &Self
    where
        Self: Sized,
    {
        self
    }
}

#[unstable(feature = "allocator_api", issue = "32838")]
unsafe impl<A> Allocator for &A
where
    A: Allocator + ?Sized,
{
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // Kachengeteka: chibvumirano chekuchengetedza chinofanira kuchengetedzwa neanodana
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // Kachengeteka: chibvumirano chekuchengetedza chinofanira kuchengetedzwa neanodana
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // Kachengeteka: chibvumirano chekuchengetedza chinofanira kuchengetedzwa neanodana
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // Kachengeteka: chibvumirano chekuchengetedza chinofanira kuchengetedzwa neanodana
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}