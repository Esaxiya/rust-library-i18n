use crate::alloc::Layout;
use crate::cmp;
use crate::ptr;

/// Mugoveri wekurangarira uyo anogona kunyoreswa seyakajairika raibhurari kuburikidza neiyo `#[global_allocator]` hunhu.
///
/// Dzimwe dzenzira dzinoda kuti memory block ive *parizvino yakapihwa* kuburikidza neyakagovana.Izvi zvinoreva kuti:
///
/// * kero yekutanga yeiyo memory block yakambodzoserwa nefoni yapfuura kunzira yekugovera yakadai se `alloc`, uye
///
/// * memory block haisati yambogadziriswa, uko mablock anotakuriswa pamwe nekupfuudzwa kune nzira yekutengesa senge `dealloc` kana nekupfuudzwa kune imwe nzira yekutamisa nzvimbo iyo inodzosera isiri-null pointer.
///
///
/// # Example
///
/// ```no_run
/// use std::alloc::{GlobalAlloc, Layout, alloc};
/// use std::ptr::null_mut;
///
/// struct MyAllocator;
///
/// unsafe impl GlobalAlloc for MyAllocator {
///     unsafe fn alloc(&self, _layout: Layout) -> *mut u8 { null_mut() }
///     unsafe fn dealloc(&self, _ptr: *mut u8, _layout: Layout) {}
/// }
///
/// #[global_allocator]
/// static A: MyAllocator = MyAllocator;
///
/// fn main() {
///     unsafe {
///         assert!(alloc(Layout::new::<u32>()).is_null())
///     }
/// }
/// ```
///
/// # Safety
///
/// `GlobalAlloc` trait ndeye `unsafe` trait nekuda kwezvikonzero zvinoverengeka, uye vanomisikidza vanofanirwa kuona kuti vanoteerera zvibvumirano izvi:
///
/// * Hunhu husina kujeka kana vagoveri vepasirese vakasununguka.Ichi chibvumirano chinogona kukwidziridzwa mu future, asi parizvino panic kubva kune chero eaya mabasa ingatungamira mukusagadzikana kwendangariro.
///
/// * `Layout` mibvunzo uye kuverenga zvakawandisa zvinofanirwa kuve zvechokwadi.Vachafonera iyi trait vanobvumidzwa kuvimba nezvibvumirano zvinotsanangurwa pane imwe neimwe nzira, uye vanoteedzera vanofanirwa kuona kuti zvibvumirano zvakadaro zvinoramba zviri zvechokwadi.
///
/// * Iwe haugone kuvimba nezvakagoverwa zvichinyatso kuitika, kunyangwe paine pachena mirwi migove mune sosi.
/// Iyo yekugadzirisa inogona kuona zvisina kushandiswa mugove iyo inogona kubvisa zvachose kana kutamira mudura uye nekudaro haizombokumbira iyo inogovera.
/// Iyo optimizer inogona kuramba ichifungidzira kuti kugoverwa hakukanganise, saka kodhi iyo yaimbotadza nekuda kwekutadza kwemugadziri inogona ikozvino kushanda kamwe kamwe nekuti optimizer yakashanda yakatenderedza kudiwa kwekugoverwa.
/// Zvakawanda zvakaringana, muenzaniso unotevera wekodhi hauna kujeka, zvisinei nekuti wako anogovera tsika anotendera kuverenga mangani magovana akaitika.
///
///   ```rust,ignore (unsound and has placeholders)
///   drop(Box::new(42));
///   let number_of_heap_allocs = /* call private allocator API */;
///   unsafe { std::intrinsics::assume(number_of_heap_allocs > 0); }
///   ```
///
///   Ziva kuti optimizations yataurwa pamusoro apa haisi iyo chete optimization inogona kuiswa.Iwe unogona kazhinji kusavimba nemirwi migove ichiitika kana ichikwanisa kubviswa pasina kuchinja maitiro maitiro.
///   Kunyangwe kugoverwa kuchiitika kana kusiri hakusi chikamu chehunhu hwechirongwa, kunyangwe kana chikaonekwa kuburikidza neyakagovana iyo inoteedzera kugoverwa nekudhinda kana neimwe nzira kuve nemhedzisiro.
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "global_alloc", since = "1.28.0")]
pub unsafe trait GlobalAlloc {
    /// Govera ndangariro sekutsanangurwa kwayakaitwa `layout`.
    ///
    /// Inodzorera pointer kune ichangobva kupihwa ndangariro, kana null kuratidza kutadza kugoverwa.
    ///
    /// # Safety
    ///
    /// Iri basa harina kuchengeteka nekuti hunhu husina kujekeswa hunogona kukonzeresa kana iye ari kufona asina kuona kuti `layout` ine saizi isina zero.
    ///
    /// (Kuwedzeredza kubvisa kunogona kupa miganho yakanangana nehunhu, semuenzaniso, kuvimbisa kero ye sentinel kana null pointer mukupindura chikumbiro chemazizi-saizi.)
    ///
    /// Iyo yakagoverwa block ye memory inogona kana inogona kusatangwa.
    ///
    /// # Errors
    ///
    /// Kudzosera null pointer kunoratidza kuti chero ndangariro yakaneta kana `layout` haina kusangana nehukuru hwemugoveri kana zvipingamupinyi zvekuenderana.
    ///
    /// Maitirwo anokurudzirwa kuti vadzokere kuneta pakurangarira pane kubvisa, asi ichi hachisi chinhu chakasimba.
    /// (Zvikurukuru: zviri *pamutemo* kushandisa iyi trait iri pamusoro penzvimbo yekuzvarwa yekugovera raibhurari iyo inobvisa pakurangarira kuneta.)
    ///
    /// Vatengi vanoshuvira kubvisa komputa mukupindura kukanganisa kwekugovera vanokurudzirwa kufonera [`handle_alloc_error`] basa, pane kukumbira zvakananga `panic!` kana zvakafanana.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc(&self, layout: Layout) -> *mut u8;

    /// Shingairira block yeyendangariro pane yakapihwa `ptr` pointer neiyo yakapihwa `layout`.
    ///
    /// # Safety
    ///
    /// Iri basa harina kuchengeteka nekuti hunhu husina kujekeswa hunogona kukonzeresa kana iye ari kufona asina kuona zvese zvinotevera:
    ///
    ///
    /// * `ptr` inofanirwa kuratidza danda rekurangarira parizvino rakagoverwa kuburikidza nemugovanisi,
    ///
    /// * `layout` inofanirwa kuve yakafanana marongero aishandiswa kugovera iro block yekumusoro.
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout);

    /// Inoita sa `alloc`, asi zvakare inovimbisa kuti zvirimo zvakaiswa zero vasati vadzorerwa.
    ///
    /// # Safety
    ///
    /// Iri basa harina kuchengeteka nekuda kwezvikonzero zvakafanana izvo `alloc` iri.
    /// Nekudaro iyo yakapihwa block yeyeuchidzo inovimbiswa kutanga.
    ///
    /// # Errors
    ///
    /// Kudzosera null pointer kunoratidza kuti chero ndangariro yakaneta kana `layout` haina kusangana nehukuru hweyakagoverwa kana zvipingamupinyi zvekunongedza, sezvazvakaita mu `alloc`.
    ///
    /// Vatengi vanoshuvira kubvisa komputa mukupindura kukanganisa kwekugovera vanokurudzirwa kufonera [`handle_alloc_error`] basa, pane kukumbira zvakananga `panic!` kana zvakafanana.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let size = layout.size();
        // Kachengeteka: chibvumirano chekuchengetedza che `alloc` chinofanira kuchengetedzwa neanodana.
        let ptr = unsafe { self.alloc(layout) };
        if !ptr.is_null() {
            // KUCHENGETEKA: sekugoverwa kwakabudirira, dunhu kubva ku `ptr`
            // yehukuru `size` inovimbiswa kuve inoshanda kune anonyora.
            unsafe { ptr::write_bytes(ptr, 0, size) };
        }
        ptr
    }

    /// Shinyura kana kukura bhurugwa rekurangarira kune yakapihwa `new_size`.
    /// Iyo block inotsanangurwa neakapihwa `ptr` pointer uye `layout`.
    ///
    /// Kana izvi zvikadzosa non-null pointer, saka muridzi weye memory block inotaurwa ne `ptr` yakaendeswa kune uyu anogovera.
    /// Ndangariro dzinogona kana kunge dzisina kutamiswa, uye dzinofanirwa kutorwa senge dzisingashandisike (kunze kwekunge zvadzoreredzwa kumunhu akafona zvekare kuburikidza nemutengo wekudzoka weiyi nzira).
    /// Iyo nyowani memory block inopihwa pamwe ne `layout`, asi iine `size` yakagadziridzwa kuita `new_size`.
    /// Iyi nyowani dhizaini inofanira kushandiswa kana uchigadzirisa nyowani memory block ne `dealloc`.
    /// Iyo renji `0..min(layout.size(), new_size) `yeiyo nyowani yekumusoro block inovimbiswa kuve nemitengo yakafanana neiyo yekutanga block.
    ///
    /// Kana nzira iyi ikadzoka null, saka muridzi weye memory block haina kuendeswa kune inovagovera, uye zvirimo zveye memory block hazvina kuchinjika.
    ///
    /// # Safety
    ///
    /// Iri basa harina kuchengeteka nekuti hunhu husina kujekeswa hunogona kukonzeresa kana iye ari kufona asina kuona zvese zvinotevera:
    ///
    /// * `ptr` inofanirwa kupihwa parizvino kuburikidza nemugoveri uyu,
    ///
    /// * `layout` inofanirwa kunge iri iyo marongero aishandiswa kugovera iro block of memory,
    ///
    /// * `new_size` inofanira kuva yakakura kudarika zero.
    ///
    /// * `new_size`, painotenderedzwa kusvika kune yakawanda yepadyo ye `layout.align()`, haifanire kufashukira (kureva, kukosha kwakatenderedzwa kunofanira kunge kuri pasi pe `usize::MAX`).
    ///
    /// (Kuwedzeredza kubvisa kunogona kupa miganho yakanangana nehunhu, semuenzaniso, kuvimbisa kero ye sentinel kana null pointer mukupindura chikumbiro chemazizi-saizi.)
    ///
    /// # Errors
    ///
    /// Inodzosera null kana iyo nyowani dhizaini isingasangane nehukuru uye kuenderana zvipingamupinyi zvemupi weanogovera, kana kana kuiswazve neimwe nzira ikakundikana.
    ///
    /// Maitirwo anokurudzirwa kuti vadzokere kuneta pakurangarira pane kuvhunduka kana kubvisa nhumbu, asi ichi hachisi chinhu chakasimba.
    /// (Zvikurukuru: zviri *pamutemo* kushandisa iyi trait iri pamusoro penzvimbo yekuzvarwa yekugovera raibhurari iyo inobvisa pakurangarira kuneta.)
    ///
    /// Vatengi vanoshuvira kubvisa komputa mukupindura kukanganisa kwekugadzirisa nzvimbo vanokurudzirwa kufonera [`handle_alloc_error`] basa, pane kukumbira zvakananga `panic!` kana zvakafanana.
    ///
    ///
    /// [`handle_alloc_error`]: ../../alloc/alloc/fn.handle_alloc_error.html
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "global_alloc", since = "1.28.0")]
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // Kachengeteka: iye anodana anofanira kuona kuti `new_size` haifashukire.
        // `layout.align()` inouya kubva ku `Layout` uye nekudaro inovimbiswa kuve inoshanda.
        let new_layout = unsafe { Layout::from_size_align_unchecked(new_size, layout.align()) };
        // Kachengeteka: iye anodana anofanira kuona kuti `new_layout` yakakura kudarika zero.
        let new_ptr = unsafe { self.alloc(new_layout) };
        if !new_ptr.is_null() {
            // KUCHENGETEKA: iro rakambopihwa block harigone kupfuura iro richangobva kupihwa block.
            // Chibvumirano chekuchengetedza che `dealloc` chinofanira kuchengetedzwa neanodana.
            unsafe {
                ptr::copy_nonoverlapping(ptr, new_ptr, cmp::min(layout.size(), new_size));
                self.dealloc(ptr, layout);
            }
        }
        new_ptr
    }
}