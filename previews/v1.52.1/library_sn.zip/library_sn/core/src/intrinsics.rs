//! Komputa intrinsics.
//!
//! Tsananguro dzinoenderana dziri mu `compiler/rustc_codegen_llvm/src/intrinsic.rs`.
//! Inoenderana const kuitisa iri mu `compiler/rustc_mir/src/interpret/intrinsics.rs`
//!
//! # Const mukati
//!
//! Note: chero shanduko kuumbwe hwezvinhu zvekunze zvinofanirwa kukurukurwa nechikwata chemutauro.
//! Izvi zvinosanganisira shanduko mukugadzikana kwesimba.
//!
//! Kuti ugadzire chinhu chemukati chinoshandiswa panguva yekubatanidza, mumwe anofanirwa kuteedzera kuisirwa kubva ku <https://github.com/rust-lang/miri/blob/master/src/shims/intrinsics.rs> kuenda ku `compiler/rustc_mir/src/interpret/intrinsics.rs` uye nekuwedzera `#[rustc_const_unstable(feature = "foo", issue = "01234")]` kune iyo yemukati.
//!
//!
//! Kana chinhu chemukati chichifanirwa kushandiswa kubva ku `const fn` ine `rustc_const_stable` hunhu, hunhu hwemukati hunofanirwa kunge huri `rustc_const_stable`, futi.
//! Shanduko yakadaro haifanire kuitwa pasina kubvunzana neT-lang, nekuti inobika chimiro mumutauro chisingakwanise kudzokororwa mumushandisi kodhi pasina rutsigiro rwekuumbiridza.
//!
//! # Volatiles
//!
//! Iyo isina kugadzikana intrinsics inopa mashandiro anoitirwa kuita pane I/O ndangariro, iyo inovimbiswa kuti isazogadziriswazve nemusanganisi kune mamwe matsimba epamhepo.Ona iyo LLVM zvinyorwa pa [[volatile]].
//!
//! [volatile]: http://llvm.org/docs/LangRef.html#volatile-memory-accesses
//!
//! # Atomics
//!
//! Iyo maatomu epamhepo anopa zvakajairika maatomu mashandiro pamashoko emuchina, aine akawanda anokwanisika ndangariro kurongeka.Ivo vanoteerera iwo akafanana semantics se C++ 11.Ona iyo LLVM zvinyorwa pa [[atomics]].
//!
//! [atomics]: http://llvm.org/docs/Atomics.html
//!
//! Yekukurumidza kuzorodza pakurangarira ndangariro:
//!
//! * Wana, chipingamupinyi chekuwana kukiya.Inoteverwa kuverenga uye kunyora kunoitika mushure mechipingamupinyi.
//! * Kusunungurwa, chipingamupinyi pakusunungura kiyi.Kufanoverenga kuverenga nekunyora kunoitika pamberi pechipingamupinyi.
//! * Sequentially inopindirana, sequentially inoenderana mashandiro anovimbiswa kuti zviitike zvakateedzana.Iyi ndiyo yakajairwa modhi yekushanda nemhando dzeatomiki uye yakaenzana ne Java's `volatile`.
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!
//!

#![unstable(
    feature = "core_intrinsics",
    reason = "intrinsics are unlikely to ever be stabilized, instead \
                      they should be used through stabilized interfaces \
                      in the rest of the standard library",
    issue = "none"
)]
#![allow(missing_docs)]

use crate::marker::DiscriminantKind;
use crate::mem;

// Izvi zvinotengeswa zvinoshandiswa kurerutsa ma-intra-doc zvinongedzo
#[allow(unused_imports)]
#[cfg(all(target_has_atomic = "8", target_has_atomic = "32", target_has_atomic = "ptr"))]
use crate::sync::atomic::{self, AtomicBool, AtomicI32, AtomicIsize, AtomicU32, Ordering};

#[stable(feature = "drop_in_place", since = "1.8.0")]
#[rustc_deprecated(
    reason = "no longer an intrinsic - use `ptr::drop_in_place` directly",
    since = "1.52.0"
)]
#[inline]
pub unsafe fn drop_in_place<T: ?Sized>(to_drop: *mut T) {
    // Kachengeteka: ona `ptr::drop_in_place`
    unsafe { crate::ptr::drop_in_place(to_drop) }
}

extern "rust-intrinsic" {
    // NB, izvi zvemukati zvinotora zvinongedzo zvisvinu nekuti zvinoshandura zvakasarudzika ndangariro, izvo zvisingaenderane ne `&` kana `&mut`.
    //

    /// Inochengetera kukosha kana kukosha kwazvino kwakafanana neiyo `old` kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pamhando dze [`atomic`] kuburikidza ne `compare_exchange` nzira nekupfuura [`Ordering::SeqCst`] seese ari ma `success` ne `failure` parameter.
    ///
    /// Semuyenzaniso, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Inochengetera kukosha kana kukosha kwazvino kwakafanana neiyo `old` kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pamhando dze [`atomic`] kuburikidza ne `compare_exchange` nzira nekupfuura [`Ordering::Acquire`] seese ari ma `success` ne `failure` parameter.
    ///
    /// Semuyenzaniso, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Inochengetera kukosha kana kukosha kwazvino kwakafanana neiyo `old` kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pamhando dze [`atomic`] kuburikidza ne `compare_exchange` nzira nekupfuura [`Ordering::Release`] se `success` uye [`Ordering::Relaxed`] se `failure` parameter.
    /// Semuyenzaniso, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Inochengetera kukosha kana kukosha kwazvino kwakafanana neiyo `old` kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pamhando dze [`atomic`] kuburikidza ne `compare_exchange` nzira nekupfuura [`Ordering::AcqRel`] se `success` uye [`Ordering::Acquire`] se `failure` parameter.
    /// Semuyenzaniso, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Inochengetera kukosha kana kukosha kwazvino kwakafanana neiyo `old` kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pamhando dze [`atomic`] kuburikidza ne `compare_exchange` nzira nekupfuura [`Ordering::Relaxed`] seese ari ma `success` ne `failure` parameter.
    ///
    /// Semuyenzaniso, [`AtomicBool::compare_exchange`].
    ///
    pub fn atomic_cxchg_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Inochengetera kukosha kana kukosha kwazvino kwakafanana neiyo `old` kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pamhando dze [`atomic`] kuburikidza ne `compare_exchange` nzira nekupfuura [`Ordering::SeqCst`] se `success` uye [`Ordering::Relaxed`] se `failure` parameter.
    /// Semuyenzaniso, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Inochengetera kukosha kana kukosha kwazvino kwakafanana neiyo `old` kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pamhando dze [`atomic`] kuburikidza ne `compare_exchange` nzira nekupfuura [`Ordering::SeqCst`] se `success` uye [`Ordering::Acquire`] se `failure` parameter.
    /// Semuyenzaniso, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Inochengetera kukosha kana kukosha kwazvino kwakafanana neiyo `old` kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pamhando dze [`atomic`] kuburikidza ne `compare_exchange` nzira nekupfuura [`Ordering::Acquire`] se `success` uye [`Ordering::Relaxed`] se `failure` parameter.
    /// Semuyenzaniso, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Inochengetera kukosha kana kukosha kwazvino kwakafanana neiyo `old` kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pamhando dze [`atomic`] kuburikidza ne `compare_exchange` nzira nekupfuura [`Ordering::AcqRel`] se `success` uye [`Ordering::Relaxed`] se `failure` parameter.
    /// Semuyenzaniso, [`AtomicBool::compare_exchange`].
    ///
    ///
    pub fn atomic_cxchg_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Inochengetera kukosha kana kukosha kwazvino kwakafanana neiyo `old` kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pamhando dze [`atomic`] kuburikidza ne `compare_exchange_weak` nzira nekupfuura [`Ordering::SeqCst`] seese ari ma `success` ne `failure` parameter.
    ///
    /// Semuyenzaniso, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Inochengetera kukosha kana kukosha kwazvino kwakafanana neiyo `old` kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pamhando dze [`atomic`] kuburikidza ne `compare_exchange_weak` nzira nekupfuura [`Ordering::Acquire`] seese ari ma `success` ne `failure` parameter.
    ///
    /// Semuyenzaniso, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_acq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Inochengetera kukosha kana kukosha kwazvino kwakafanana neiyo `old` kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pamhando dze [`atomic`] kuburikidza ne `compare_exchange_weak` nzira nekupfuura [`Ordering::Release`] se `success` uye [`Ordering::Relaxed`] se `failure` parameter.
    /// Semuyenzaniso, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_rel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Inochengetera kukosha kana kukosha kwazvino kwakafanana neiyo `old` kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pamhando dze [`atomic`] kuburikidza ne `compare_exchange_weak` nzira nekupfuura [`Ordering::AcqRel`] se `success` uye [`Ordering::Acquire`] se `failure` parameter.
    /// Semuyenzaniso, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Inochengetera kukosha kana kukosha kwazvino kwakafanana neiyo `old` kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pamhando dze [`atomic`] kuburikidza ne `compare_exchange_weak` nzira nekupfuura [`Ordering::Relaxed`] seese ari ma `success` ne `failure` parameter.
    ///
    /// Semuyenzaniso, [`AtomicBool::compare_exchange_weak`].
    ///
    pub fn atomic_cxchgweak_relaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Inochengetera kukosha kana kukosha kwazvino kwakafanana neiyo `old` kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pamhando dze [`atomic`] kuburikidza ne `compare_exchange_weak` nzira nekupfuura [`Ordering::SeqCst`] se `success` uye [`Ordering::Relaxed`] se `failure` parameter.
    /// Semuyenzaniso, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Inochengetera kukosha kana kukosha kwazvino kwakafanana neiyo `old` kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pamhando dze [`atomic`] kuburikidza ne `compare_exchange_weak` nzira nekupfuura [`Ordering::SeqCst`] se `success` uye [`Ordering::Acquire`] se `failure` parameter.
    /// Semuyenzaniso, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_failacq<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Inochengetera kukosha kana kukosha kwazvino kwakafanana neiyo `old` kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pamhando dze [`atomic`] kuburikidza ne `compare_exchange_weak` nzira nekupfuura [`Ordering::Acquire`] se `success` uye [`Ordering::Relaxed`] se `failure` parameter.
    /// Semuyenzaniso, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acq_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);
    /// Inochengetera kukosha kana kukosha kwazvino kwakafanana neiyo `old` kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pamhando dze [`atomic`] kuburikidza ne `compare_exchange_weak` nzira nekupfuura [`Ordering::AcqRel`] se `success` uye [`Ordering::Relaxed`] se `failure` parameter.
    /// Semuyenzaniso, [`AtomicBool::compare_exchange_weak`].
    ///
    ///
    pub fn atomic_cxchgweak_acqrel_failrelaxed<T: Copy>(dst: *mut T, old: T, src: T) -> (T, bool);

    /// Inotakura iko iko kukosha kweiyo pointer.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `load` nzira nekupfuura [`Ordering::SeqCst`] se `order`.
    /// Semuyenzaniso, [`AtomicBool::load`].
    ///
    pub fn atomic_load<T: Copy>(src: *const T) -> T;
    /// Inotakura iko iko kukosha kweiyo pointer.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `load` nzira nekupfuura [`Ordering::Acquire`] se `order`.
    /// Semuyenzaniso, [`AtomicBool::load`].
    ///
    pub fn atomic_load_acq<T: Copy>(src: *const T) -> T;
    /// Inotakura iko iko kukosha kweiyo pointer.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `load` nzira nekupfuura [`Ordering::Relaxed`] se `order`.
    /// Semuyenzaniso, [`AtomicBool::load`].
    ///
    pub fn atomic_load_relaxed<T: Copy>(src: *const T) -> T;
    pub fn atomic_load_unordered<T: Copy>(src: *const T) -> T;

    /// Inochengetera iyo kukosha pane yakatarwa nzvimbo yekurangarira.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `store` nzira nekupfuura [`Ordering::SeqCst`] se `order`.
    /// Semuyenzaniso, [`AtomicBool::store`].
    ///
    pub fn atomic_store<T: Copy>(dst: *mut T, val: T);
    /// Inochengetera iyo kukosha pane yakatarwa nzvimbo yekurangarira.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `store` nzira nekupfuura [`Ordering::Release`] se `order`.
    /// Semuyenzaniso, [`AtomicBool::store`].
    ///
    pub fn atomic_store_rel<T: Copy>(dst: *mut T, val: T);
    /// Inochengetera iyo kukosha pane yakatarwa nzvimbo yekurangarira.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `store` nzira nekupfuura [`Ordering::Relaxed`] se `order`.
    /// Semuyenzaniso, [`AtomicBool::store`].
    ///
    pub fn atomic_store_relaxed<T: Copy>(dst: *mut T, val: T);
    pub fn atomic_store_unordered<T: Copy>(dst: *mut T, val: T);

    /// Inochengetera kukosha kunzvimbo yakatarwa yekurangarira, ichidzosa iyo yekare kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `swap` nzira nekupfuura [`Ordering::SeqCst`] se `order`.
    /// Semuyenzaniso, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg<T: Copy>(dst: *mut T, src: T) -> T;
    /// Inochengetera kukosha kunzvimbo yakatarwa yekurangarira, ichidzosa iyo yekare kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `swap` nzira nekupfuura [`Ordering::Acquire`] se `order`.
    /// Semuyenzaniso, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Inochengetera kukosha kunzvimbo yakatarwa yekurangarira, ichidzosa iyo yekare kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `swap` nzira nekupfuura [`Ordering::Release`] se `order`.
    /// Semuyenzaniso, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Inochengetera kukosha kunzvimbo yakatarwa yekurangarira, ichidzosa iyo yekare kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `swap` nzira nekupfuura [`Ordering::AcqRel`] se `order`.
    /// Semuyenzaniso, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Inochengetera kukosha kunzvimbo yakatarwa yekurangarira, ichidzosa iyo yekare kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `swap` nzira nekupfuura [`Ordering::Relaxed`] se `order`.
    /// Semuyenzaniso, [`AtomicBool::swap`].
    ///
    pub fn atomic_xchg_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Inowedzera kune iyo yazvino kukosha, ichidzosa iyo yapfuura kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `fetch_add` nzira nekupfuura [`Ordering::SeqCst`] se `order`.
    /// Semuyenzaniso, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd<T: Copy>(dst: *mut T, src: T) -> T;
    /// Inowedzera kune iyo yazvino kukosha, ichidzosa iyo yapfuura kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `fetch_add` nzira nekupfuura [`Ordering::Acquire`] se `order`.
    /// Semuyenzaniso, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Inowedzera kune iyo yazvino kukosha, ichidzosa iyo yapfuura kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `fetch_add` nzira nekupfuura [`Ordering::Release`] se `order`.
    /// Semuyenzaniso, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Inowedzera kune iyo yazvino kukosha, ichidzosa iyo yapfuura kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `fetch_add` nzira nekupfuura [`Ordering::AcqRel`] se `order`.
    /// Semuyenzaniso, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Inowedzera kune iyo yazvino kukosha, ichidzosa iyo yapfuura kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `fetch_add` nzira nekupfuura [`Ordering::Relaxed`] se `order`.
    /// Semuyenzaniso, [`AtomicIsize::fetch_add`].
    ///
    pub fn atomic_xadd_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bvisa kubva pane yazvino kukosha, udzore iyo yapfuura kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `fetch_sub` nzira nekupfuura [`Ordering::SeqCst`] se `order`.
    /// Semuyenzaniso, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bvisa kubva pane yazvino kukosha, udzore iyo yapfuura kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `fetch_sub` nzira nekupfuura [`Ordering::Acquire`] se `order`.
    /// Semuyenzaniso, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bvisa kubva pane yazvino kukosha, udzore iyo yapfuura kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `fetch_sub` nzira nekupfuura [`Ordering::Release`] se `order`.
    /// Semuyenzaniso, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bvisa kubva pane yazvino kukosha, udzore iyo yapfuura kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `fetch_sub` nzira nekupfuura [`Ordering::AcqRel`] se `order`.
    /// Semuyenzaniso, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bvisa kubva pane yazvino kukosha, udzore iyo yapfuura kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `fetch_sub` nzira nekupfuura [`Ordering::Relaxed`] se `order`.
    /// Semuyenzaniso, [`AtomicIsize::fetch_sub`].
    ///
    pub fn atomic_xsub_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Zvishoma nezvishoma uye neiyo yazvino kukosha, kudzorera iyo yapfuura kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `fetch_and` nzira nekupfuura [`Ordering::SeqCst`] se `order`.
    /// Semuyenzaniso, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and<T: Copy>(dst: *mut T, src: T) -> T;
    /// Zvishoma nezvishoma uye neiyo yazvino kukosha, kudzorera iyo yapfuura kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `fetch_and` nzira nekupfuura [`Ordering::Acquire`] se `order`.
    /// Semuyenzaniso, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Zvishoma nezvishoma uye neiyo yazvino kukosha, kudzorera iyo yapfuura kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `fetch_and` nzira nekupfuura [`Ordering::Release`] se `order`.
    /// Semuyenzaniso, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Zvishoma nezvishoma uye neiyo yazvino kukosha, kudzorera iyo yapfuura kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `fetch_and` nzira nekupfuura [`Ordering::AcqRel`] se `order`.
    /// Semuyenzaniso, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Zvishoma nezvishoma uye neiyo yazvino kukosha, kudzorera iyo yapfuura kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `fetch_and` nzira nekupfuura [`Ordering::Relaxed`] se `order`.
    /// Semuyenzaniso, [`AtomicBool::fetch_and`].
    ///
    pub fn atomic_and_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Bitwise nand neiyo yazvino kukosha, kudzorera iyo yapfuura kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`AtomicBool`] mhando kuburikidza ne `fetch_nand` nzira nekupfuura [`Ordering::SeqCst`] se `order`.
    /// Semuyenzaniso, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand neiyo yazvino kukosha, kudzorera iyo yapfuura kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`AtomicBool`] mhando kuburikidza ne `fetch_nand` nzira nekupfuura [`Ordering::Acquire`] se `order`.
    /// Semuyenzaniso, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand neiyo yazvino kukosha, kudzorera iyo yapfuura kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`AtomicBool`] mhando kuburikidza ne `fetch_nand` nzira nekupfuura [`Ordering::Release`] se `order`.
    /// Semuyenzaniso, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand neiyo yazvino kukosha, kudzorera iyo yapfuura kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`AtomicBool`] mhando kuburikidza ne `fetch_nand` nzira nekupfuura [`Ordering::AcqRel`] se `order`.
    /// Semuyenzaniso, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Bitwise nand neiyo yazvino kukosha, kudzorera iyo yapfuura kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`AtomicBool`] mhando kuburikidza ne `fetch_nand` nzira nekupfuura [`Ordering::Relaxed`] se `order`.
    /// Semuyenzaniso, [`AtomicBool::fetch_nand`].
    ///
    pub fn atomic_nand_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Zvishoma nezvishoma kana neiyo yazvino kukosha, kudzorera iyo yapfuura kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `fetch_or` nzira nekupfuura [`Ordering::SeqCst`] se `order`.
    /// Semuyenzaniso, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or<T: Copy>(dst: *mut T, src: T) -> T;
    /// Zvishoma nezvishoma kana neiyo yazvino kukosha, kudzorera iyo yapfuura kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `fetch_or` nzira nekupfuura [`Ordering::Acquire`] se `order`.
    /// Semuyenzaniso, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Zvishoma nezvishoma kana neiyo yazvino kukosha, kudzorera iyo yapfuura kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `fetch_or` nzira nekupfuura [`Ordering::Release`] se `order`.
    /// Semuyenzaniso, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Zvishoma nezvishoma kana neiyo yazvino kukosha, kudzorera iyo yapfuura kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `fetch_or` nzira nekupfuura [`Ordering::AcqRel`] se `order`.
    /// Semuyenzaniso, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Zvishoma nezvishoma kana neiyo yazvino kukosha, kudzorera iyo yapfuura kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `fetch_or` nzira nekupfuura [`Ordering::Relaxed`] se `order`.
    /// Semuyenzaniso, [`AtomicBool::fetch_or`].
    ///
    pub fn atomic_or_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Zvishoma nezvishoma xor neiyo yazvino kukosha, ichidzosa iyo yapfuura kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `fetch_xor` nzira nekupfuura [`Ordering::SeqCst`] se `order`.
    /// Semuyenzaniso, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor<T: Copy>(dst: *mut T, src: T) -> T;
    /// Zvishoma nezvishoma xor neiyo yazvino kukosha, ichidzosa iyo yapfuura kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `fetch_xor` nzira nekupfuura [`Ordering::Acquire`] se `order`.
    /// Semuyenzaniso, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Zvishoma nezvishoma xor neiyo yazvino kukosha, ichidzosa iyo yapfuura kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `fetch_xor` nzira nekupfuura [`Ordering::Release`] se `order`.
    /// Semuyenzaniso, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Zvishoma nezvishoma xor neiyo yazvino kukosha, ichidzosa iyo yapfuura kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `fetch_xor` nzira nekupfuura [`Ordering::AcqRel`] se `order`.
    /// Semuyenzaniso, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Zvishoma nezvishoma xor neiyo yazvino kukosha, ichidzosa iyo yapfuura kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] mhando kuburikidza ne `fetch_xor` nzira nekupfuura [`Ordering::Relaxed`] se `order`.
    /// Semuyenzaniso, [`AtomicBool::fetch_xor`].
    ///
    pub fn atomic_xor_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maximum neiyo yazvino kukosha uchishandisa saini yekuenzanisa.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] yakasainwa manhamba emhando kuburikidza neiyo `fetch_max` nzira nekupfuura [`Ordering::SeqCst`] se `order`.
    /// Semuyenzaniso, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum neiyo yazvino kukosha uchishandisa saini yekuenzanisa.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] yakasainwa manhamba emhando kuburikidza neiyo `fetch_max` nzira nekupfuura [`Ordering::Acquire`] se `order`.
    /// Semuyenzaniso, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum neiyo yazvino kukosha uchishandisa saini yekuenzanisa.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] yakasainwa manhamba emhando kuburikidza neiyo `fetch_max` nzira nekupfuura [`Ordering::Release`] se `order`.
    /// Semuyenzaniso, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum neiyo yazvino kukosha uchishandisa saini yekuenzanisa.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] yakasainwa manhamba emhando kuburikidza neiyo `fetch_max` nzira nekupfuura [`Ordering::AcqRel`] se `order`.
    /// Semuyenzaniso, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum ine kukosha kwazvino.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] yakasainwa manhamba emhando kuburikidza neiyo `fetch_max` nzira nekupfuura [`Ordering::Relaxed`] se `order`.
    /// Semuyenzaniso, [`AtomicI32::fetch_max`].
    ///
    pub fn atomic_max_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum neiyo yazvino kukosha uchishandisa saini yekuenzanisa.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] yakasainwa manhamba emhando kuburikidza neiyo `fetch_min` nzira nekupfuura [`Ordering::SeqCst`] se `order`.
    /// Semuyenzaniso, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum neiyo yazvino kukosha uchishandisa saini yekuenzanisa.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] yakasainwa manhamba emhando kuburikidza neiyo `fetch_min` nzira nekupfuura [`Ordering::Acquire`] se `order`.
    /// Semuyenzaniso, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum neiyo yazvino kukosha uchishandisa saini yekuenzanisa.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] yakasainwa manhamba emhando kuburikidza neiyo `fetch_min` nzira nekupfuura [`Ordering::Release`] se `order`.
    /// Semuyenzaniso, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum neiyo yazvino kukosha uchishandisa saini yekuenzanisa.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] yakasainwa manhamba emhando kuburikidza neiyo `fetch_min` nzira nekupfuura [`Ordering::AcqRel`] se `order`.
    /// Semuyenzaniso, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum neiyo yazvino kukosha uchishandisa saini yekuenzanisa.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] yakasainwa manhamba emhando kuburikidza neiyo `fetch_min` nzira nekupfuura [`Ordering::Relaxed`] se `order`.
    /// Semuyenzaniso, [`AtomicI32::fetch_min`].
    ///
    pub fn atomic_min_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Minimum ine iyo yazvino kukosha uchishandisa isinganikwe kuenzanisa.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] isina kusainwa manhamba emhando kuburikidza neiyo `fetch_min` nzira nekupfuura [`Ordering::SeqCst`] se `order`.
    /// Semuyenzaniso, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum ine iyo yazvino kukosha uchishandisa isinganikwe kuenzanisa.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] isina kusainwa manhamba emhando kuburikidza neiyo `fetch_min` nzira nekupfuura [`Ordering::Acquire`] se `order`.
    /// Semuyenzaniso, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum ine iyo yazvino kukosha uchishandisa isinganikwe kuenzanisa.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] isina kusainwa manhamba emhando kuburikidza neiyo `fetch_min` nzira nekupfuura [`Ordering::Release`] se `order`.
    /// Semuyenzaniso, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum ine iyo yazvino kukosha uchishandisa isinganikwe kuenzanisa.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] isina kusainwa manhamba emhando kuburikidza nenzira ye `fetch_min` nekupfuura [`Ordering::AcqRel`] se `order`.
    /// Semuyenzaniso, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Minimum ine iyo yazvino kukosha uchishandisa isinganikwe kuenzanisa.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] isina kusainwa manhamba emhando kuburikidza neiyo `fetch_min` nzira nekupfuura [`Ordering::Relaxed`] se `order`.
    /// Semuyenzaniso, [`AtomicU32::fetch_min`].
    ///
    pub fn atomic_umin_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Maximum neiyo yazvino kukosha uchishandisa isina kusainwa kuenzanisa.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] isina kusainwa manhamba emhando kuburikidza neiyo `fetch_max` nzira nekupfuura [`Ordering::SeqCst`] se `order`.
    /// Semuyenzaniso, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum neiyo yazvino kukosha uchishandisa isina kusainwa kuenzanisa.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] isina kusainwa manhamba emhando kuburikidza neiyo `fetch_max` nzira nekupfuura [`Ordering::Acquire`] se `order`.
    /// Semuyenzaniso, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acq<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum neiyo yazvino kukosha uchishandisa isina kusainwa kuenzanisa.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] isina kusainwa manhamba emhando kuburikidza nenzira ye `fetch_max` nekupfuura [`Ordering::Release`] se `order`.
    /// Semuyenzaniso, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_rel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum neiyo yazvino kukosha uchishandisa isina kusainwa kuenzanisa.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] isina kusainwa manhamba emhando kuburikidza neiyo `fetch_max` nzira nekupfuura [`Ordering::AcqRel`] se `order`.
    /// Semuyenzaniso, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_acqrel<T: Copy>(dst: *mut T, src: T) -> T;
    /// Maximum neiyo yazvino kukosha uchishandisa isina kusainwa kuenzanisa.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa pane iyo [`atomic`] isina kusainwa manhamba emhando kuburikidza neiyo `fetch_max` nzira nekupfuura [`Ordering::Relaxed`] se `order`.
    /// Semuyenzaniso, [`AtomicU32::fetch_max`].
    ///
    pub fn atomic_umax_relaxed<T: Copy>(dst: *mut T, src: T) -> T;

    /// Iyo `prefetch` yemukati inongedzo kune iyo kodhi jenareta yekuisa preetch rairo kana ikatsigirwa;kana zvisina kudaro, haisi-op.
    /// Prefetches haina kana hunhu pamafambiro echirongwa asi inogona kuchinja maitiro ayo ekuita.
    ///
    /// Iyo nharo ye `locality` inofanirwa kuve inowanzo kuverengera uye inzvimbo yenzvimbo yekutsanangudza kubva ku (0), hapana nzvimbo, kusvika ku (3), yakanyanyisa yemuno inochengetwa.
    ///
    ///
    /// Ichi chemukati hachina shamwari yakagadzikana.
    ///
    ///
    pub fn prefetch_read_data<T>(data: *const T, locality: i32);
    /// Iyo `prefetch` yemukati inongedzo kune iyo kodhi jenareta yekuisa preetch rairo kana ikatsigirwa;kana zvisina kudaro, haisi-op.
    /// Prefetches haina kana hunhu pamafambiro echirongwa asi inogona kuchinja maitiro ayo ekuita.
    ///
    /// Iyo nharo ye `locality` inofanirwa kuve inowanzo kuverengera uye inzvimbo yenzvimbo yekutsanangudza kubva ku (0), hapana nzvimbo, kusvika ku (3), yakanyanyisa yemuno inochengetwa.
    ///
    ///
    /// Ichi chemukati hachina shamwari yakagadzikana.
    ///
    ///
    pub fn prefetch_write_data<T>(data: *const T, locality: i32);
    /// Iyo `prefetch` yemukati inongedzo kune iyo kodhi jenareta yekuisa preetch rairo kana ikatsigirwa;kana zvisina kudaro, haisi-op.
    /// Prefetches haina kana hunhu pamafambiro echirongwa asi inogona kuchinja maitiro ayo ekuita.
    ///
    /// Iyo nharo ye `locality` inofanirwa kuve inowanzo kuverengera uye inzvimbo yenzvimbo yekutsanangudza kubva ku (0), hapana nzvimbo, kusvika ku (3), yakanyanyisa yemuno inochengetwa.
    ///
    ///
    /// Ichi chemukati hachina shamwari yakagadzikana.
    ///
    ///
    pub fn prefetch_read_instruction<T>(data: *const T, locality: i32);
    /// Iyo `prefetch` yemukati inongedzo kune iyo kodhi jenareta yekuisa preetch rairo kana ikatsigirwa;kana zvisina kudaro, haisi-op.
    /// Prefetches haina kana hunhu pamafambiro echirongwa asi inogona kuchinja maitiro ayo ekuita.
    ///
    /// Iyo nharo ye `locality` inofanirwa kuve inowanzo kuverengera uye inzvimbo yenzvimbo yekutsanangudza kubva ku (0), hapana nzvimbo, kusvika ku (3), yakanyanyisa yemuno inochengetwa.
    ///
    ///
    /// Ichi chemukati hachina shamwari yakagadzikana.
    ///
    ///
    pub fn prefetch_write_instruction<T>(data: *const T, locality: i32);
}

extern "rust-intrinsic" {
    /// Fenzi yeatomu.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa mu [`atomic::fence`] nekupfuura [`Ordering::SeqCst`] se `order`.
    ///
    ///
    pub fn atomic_fence();
    /// Fenzi yeatomu.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa mu [`atomic::fence`] nekupfuura [`Ordering::Acquire`] se `order`.
    ///
    ///
    pub fn atomic_fence_acq();
    /// Fenzi yeatomu.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa mu [`atomic::fence`] nekupfuura [`Ordering::Release`] se `order`.
    ///
    ///
    pub fn atomic_fence_rel();
    /// Fenzi yeatomu.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa mu [`atomic::fence`] nekupfuura [`Ordering::AcqRel`] se `order`.
    ///
    ///
    pub fn atomic_fence_acqrel();

    /// Iyo compiler-chete memory chipingaidzo.
    ///
    /// Yekupinda ndangariro haizombogadziriswazve kuyambuka ichi chipingaidzo nemuunganidzi, asi hapana mirairo ichaiburitswa.
    /// Izvi zvinokodzera mashandiro patambo imwechete iyo inogona kubvisirwa, senge kana uchitaurirana nevanobata masaini.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa mu [`atomic::compiler_fence`] nekupfuura [`Ordering::SeqCst`] se `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence();
    /// Iyo compiler-chete memory chipingaidzo.
    ///
    /// Yekupinda ndangariro haizombogadziriswazve kuyambuka ichi chipingaidzo nemuunganidzi, asi hapana mirairo ichaiburitswa.
    /// Izvi zvinokodzera mashandiro patambo imwechete iyo inogona kubvisirwa, senge kana uchitaurirana nevanobata masaini.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa mu [`atomic::compiler_fence`] nekupfuura [`Ordering::Acquire`] se `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acq();
    /// Iyo compiler-chete memory chipingaidzo.
    ///
    /// Yekupinda ndangariro haizombogadziriswazve kuyambuka ichi chipingaidzo nemuunganidzi, asi hapana mirairo ichaiburitswa.
    /// Izvi zvinokodzera mashandiro patambo imwechete iyo inogona kubvisirwa, senge kana uchitaurirana nevanobata masaini.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa mu [`atomic::compiler_fence`] nekupfuura [`Ordering::Release`] se `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_rel();
    /// Iyo compiler-chete memory chipingaidzo.
    ///
    /// Yekupinda ndangariro haizombogadziriswazve kuyambuka ichi chipingaidzo nemuunganidzi, asi hapana mirairo ichaiburitswa.
    /// Izvi zvinokodzera mashandiro patambo imwechete iyo inogona kubvisirwa, senge kana uchitaurirana nevanobata masaini.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati inowanikwa mu [`atomic::compiler_fence`] nekupfuura [`Ordering::AcqRel`] se `order`.
    ///
    ///
    ///
    ///
    pub fn atomic_singlethreadfence_acqrel();

    /// Zvemashiripiti zvemukati zvinowana zvarinoreva kubva kune hunhu hwakanamatira pabasa.
    ///
    /// Semuenzaniso, dataflow inoshandisa izvi kujekesa zvirevo zvekuti `rustc_peek(potentially_uninitialized)` inogona kunyatso tarisa kuti dataflow yakanyatso kuenzanisa kuti haina kuvhurwa panguva iyoyo mukutenderera kuyerera.
    ///
    ///
    /// Ichi chemukati hachifanirwe kushandiswa kunze kwekomputa.
    ///
    ///
    ///
    pub fn rustc_peek<T>(_: T) -> T;

    /// Inobvisa kuitwa kweichi chiitiko.
    ///
    /// Imwe mushandisi-inoshamwaridzika uye yakagadzikana vhezheni yeichi chiitiko i [`std::process::abort`](../../std/process/fn.abort.html).
    ///
    pub fn abort() -> !;

    /// Inozivisa iyo optimizer kuti iyi poindi mukodhi haigoneke, zvichigonesa kumwe kuwedzera optimization.
    ///
    /// NB, izvi zvakasiyana zvakanyanya kubva ku `unreachable!()` macro: Kusiyana nemacro, iyo panics painourayiwa, iri *undefined hunhu* kusvika kodhi yakamisikidzwa nebasa iri.
    ///
    ///
    /// Iyo yakasimbiswa vhezheni yeiyi yemukati ndeye [`core::hint::unreachable_unchecked`](crate::hint::unreachable_unchecked).
    ///
    ///
    #[rustc_const_unstable(feature = "const_unreachable_unchecked", issue = "53188")]
    pub fn unreachable() -> !;

    /// Inozivisa iyo optimizer kuti mamiriro anogara ari echokwadi.
    /// Kana mamiriro acho ari enhema, maitiro acho haana kujekeswa.
    ///
    /// Hapana kodhi inogadzirwa yeichi chemukati, asi iyo optimizer ichaedza kuichengetedza (uye mamiriro ayo) pakati pemapashure, ayo anogona kukanganisa kugona kweyakavakidzana kodhi uye kudzikisira mashandiro.
    /// Iyo haifanire kushandiswa kana iyo inogara ichikwanisa kuwanikwa neyakagadzirisa yega, kana kana isingakwanise chero akakosha optimizations.
    ///
    /// Ichi chemukati hachina shamwari yakagadzikana.
    ///
    ///
    ///
    #[rustc_const_unstable(feature = "const_assume", issue = "76972")]
    pub fn assume(b: bool);

    /// Mazano kune iye anonyora kuti branch mamiriro anogona kunge ari echokwadi.
    /// Inodzorera kukosha kwakapfuudzwa kwairi.
    ///
    /// Chero kushandiswa chero kusine zvirevo zve `if` zvinogona kunge kusingaite.
    ///
    /// Ichi chemukati hachina shamwari yakagadzikana.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn likely(b: bool) -> bool;

    /// Mazano kune iye anonyora kuti branch mamiriro anogona kunge ari enhema.
    /// Inodzorera kukosha kwakapfuudzwa kwairi.
    ///
    /// Chero kushandiswa chero kusine zvirevo zve `if` zvinogona kunge kusingaite.
    ///
    /// Ichi chemukati hachina shamwari yakagadzikana.
    #[rustc_const_unstable(feature = "const_likely", issue = "none")]
    pub fn unlikely(b: bool) -> bool;

    /// Inoita musungo wekutyora, kuti uongororwe nedebugger.
    ///
    /// Ichi chemukati hachina shamwari yakagadzikana.
    pub fn breakpoint();

    /// Saizi yerudzi rwemabheti.
    ///
    /// Zvikurukuru, ichi ndicho chakakanganiswa mumabheti pakati pezvinhu zvinoteedzana zverudzi rumwe chete, kusanganisira kuenderana padding.
    ///
    ///
    /// Iyo yakasimbiswa vhezheni yeiyi yemukati ndeye [`core::mem::size_of`](crate::mem::size_of).
    #[rustc_const_stable(feature = "const_size_of", since = "1.40.0")]
    pub fn size_of<T>() -> usize;

    /// Iwo mashoma kuenderana kwerudzi.
    ///
    /// Iyo yakasimbiswa vhezheni yeiyi yemukati ndeye [`core::mem::align_of`](crate::mem::align_of).
    #[rustc_const_stable(feature = "const_min_align_of", since = "1.40.0")]
    pub fn min_align_of<T>() -> usize;
    /// Iyo yakasarudzika kuenderana kwerudzi.
    ///
    /// Ichi chemukati hachina shamwari yakagadzikana.
    #[rustc_const_unstable(feature = "const_pref_align_of", issue = "none")]
    pub fn pref_align_of<T>() -> usize;

    /// Kukura kweiyo inorehwa kukosha mumabheti.
    ///
    /// Iyo yakasimbiswa vhezheni yeiyi yemukati ndeye [`mem::size_of_val`].
    #[rustc_const_unstable(feature = "const_size_of_val", issue = "46571")]
    pub fn size_of_val<T: ?Sized>(_: *const T) -> usize;
    /// Iko kuenderana kunodiwa kweiyo yakatarwa kukosha.
    ///
    /// Iyo yakasimbiswa vhezheni yeiyi yemukati ndeye [`core::mem::align_of_val`](crate::mem::align_of_val).
    #[rustc_const_unstable(feature = "const_align_of_val", issue = "46571")]
    pub fn min_align_of_val<T: ?Sized>(_: *const T) -> usize;

    /// Inowana yakamira tambo chidimbu chine zita rerudzi.
    ///
    /// Iyo yakasimbiswa vhezheni yeiyi yemukati ndeye [`core::any::type_name`](crate::any::type_name).
    #[rustc_const_unstable(feature = "const_type_name", issue = "63084")]
    pub fn type_name<T: ?Sized>() -> &'static str;

    /// Inotora chinongedzo icho chakasarudzika pasirese kune yakatarwa mhando.
    /// Iri basa rinodzosera iyo yakafanana kukosha kwerudzi zvisinei nechero ipi crate yainodhonzwa mukati.
    ///
    ///
    /// Iyo yakasimbiswa vhezheni yeiyi yemukati ndeye [`core::any::TypeId::of`](crate::any::TypeId::of).
    #[rustc_const_unstable(feature = "const_type_id", issue = "77125")]
    pub fn type_id<T: ?Sized + 'static>() -> u64;

    /// Muchengeti wemabasa asina kuchengeteka asingatomboitwe kana `T` isina vagari:
    /// Izvi zvinoenderana ne panic, kana kuita chero chinhu.
    ///
    /// Ichi chemukati hachina shamwari yakagadzikana.
    #[rustc_const_unstable(feature = "const_assert_type", issue = "none")]
    pub fn assert_inhabited<T>();

    /// Muchengeti wemabasa asina kuchengeteka asingatomboitwe kana `T` isingatenderi zero-kutanga: Izvi zvichaita kunge panic, kana kuita chero chinhu.
    ///
    ///
    /// Ichi chemukati hachina shamwari yakagadzikana.
    pub fn assert_zero_valid<T>();

    /// Muchengeti wemabasa asina kuchengeteka asingatomboitwe kana `T` iine zvisina kukodzera mapatani: Izvi zvinoenderana ne panic, kana kuita chero chinhu.
    ///
    ///
    /// Ichi chemukati hachina shamwari yakagadzikana.
    pub fn assert_uninit_valid<T>();

    /// Inowana chirevo kune yakamira `Location` inoratidza kwayakadaidzirwa.
    ///
    /// Funga kushandisa [`core::panic::Location::caller`](crate::panic::Location::caller) panzvimbo.
    #[rustc_const_unstable(feature = "const_caller_location", issue = "76156")]
    pub fn caller_location() -> &'static crate::panic::Location<'static>;

    /// Inofambisa kukosha kunze kwechiyero isina kumhanya inodonhedza glue.
    ///
    /// Izvi zviripo zve [`mem::forget_unsized`] chete;zvakajairwa `forget` inoshandisa `ManuallyDrop` pachinzvimbo.
    ///
    #[rustc_const_unstable(feature = "const_intrinsic_forget", issue = "none")]
    pub fn forget<T: ?Sized>(_: T);

    /// Zvinodudzira zvakare mabits e kukosha kweimwe mhando seimwe mhando.
    ///
    /// Mhando mbiri idzi dzinofanirwa kunge dzakaenzana.
    /// Kana yepakutanga, kana mhedzisiro, inogona kunge iri [invalid value](../../nomicon/what-unsafe-does.html).
    ///
    /// `transmute` yakafanana nenzira yakafanana nechenjera kuenda kune imwe mhando kuenda kune imwe.Iyo inoteedzera mabhii kubva kune sosi kukosha kune iyo yekuenda kukosha, uye inokanganwa iyo yekutanga.
    /// Izvo zvakaenzana neC's `memcpy` pasi pehood, senge `transmute_copy`.
    ///
    /// Nekuti `transmute` ndeye-yeakakosha mashandiro, kuenderana kweiyo * akapfuudzwa tsika ivo pachavo haisi kunetsekana.
    /// Sezvinei nechero rimwe basa, compiler yatovimbisa kuti ese `T` uye `U` akanyatsoenderana.
    /// Nekudaro, kana uchiparadzira hunhu huno *nongedzera kumwe kunhu*(senge zvinongedzo, mareferenzi, mabhokisi…), anofona anofanirwa kuona kuenderana kwakaringana kweanongedzera-kune kukosha.
    ///
    /// `transmute` iri **zvinoshamisa** isina kuchengetedzeka.Kune yakawanda nhamba yenzira dzekukonzera [undefined behavior][ub] neiri basa.`transmute` inofanirwa kuve yekupedzisira mhedziso.
    ///
    /// Iyo [nomicon](../../nomicon/transmutes.html) ine zvimwe zvinyorwa.
    ///
    /// [ub]: ../../reference/behavior-considered-undefined.html
    ///
    /// # Examples
    ///
    /// Pane zvinhu zvishoma izvo `transmute` inobatsira chaizvo.
    ///
    /// Kushandura pointer kuita pointer yebasa.Izvi * hazvitakurike kumachina uko kunongedzera mashandiro uye zvinongedzo zve data zvine saizi dzakasiyana.
    ///
    /// ```
    /// fn foo() -> i32 {
    ///     0
    /// }
    /// let pointer = foo as *const ();
    /// let function = unsafe {
    ///     std::mem::transmute::<*const (), fn() -> i32>(pointer)
    /// };
    /// assert_eq!(function(), 0);
    /// ```
    ///
    /// Kuwedzera hupenyu hwese, kana kupfupisa hupenyu hwusingaperi.Izvi zvave kumberi, zvisina kuchengetedzeka Rust!
    ///
    /// ```
    /// struct R<'a>(&'a i32);
    /// unsafe fn extend_lifetime<'b>(r: R<'b>) -> R<'static> {
    ///     std::mem::transmute::<R<'b>, R<'static>>(r)
    /// }
    ///
    /// unsafe fn shorten_invariant_lifetime<'b, 'c>(r: &'b mut R<'static>)
    ///                                              -> &'b mut R<'c> {
    ///     std::mem::transmute::<&'b mut R<'static>, &'b mut R<'c>>(r)
    /// }
    /// ```
    ///
    /// # Alternatives
    ///
    /// Usaora moyo: kushandiswa kwakawanda kwe `transmute` kunogona kuwanikwa kuburikidza nedzimwe nzira.
    /// Pazasi pane zvakajairika mashandisirwo e `transmute` ayo anogona kutsiviwa neakachengeteka anovaka.
    ///
    /// Kuchinja mbishi bytes(`&[u8]`) kuenda `u32`, `f64`, nezvimwe.
    ///
    /// ```
    /// let raw_bytes = [0x78, 0x56, 0x34, 0x12];
    ///
    /// let num = unsafe {
    ///     std::mem::transmute::<[u8; 4], u32>(raw_bytes)
    /// };
    ///
    /// // shandisa `u32::from_ne_bytes` panzvimbo
    /// let num = u32::from_ne_bytes(raw_bytes);
    /// // kana kushandisa `u32::from_le_bytes` kana `u32::from_be_bytes` kutsanangura kusagadzikana
    /// let num = u32::from_le_bytes(raw_bytes);
    /// assert_eq!(num, 0x12345678);
    /// let num = u32::from_be_bytes(raw_bytes);
    /// assert_eq!(num, 0x78563412);
    /// ```
    ///
    /// Kuchinja chinongedzo kuva `usize`:
    ///
    /// ```
    /// let ptr = &0;
    /// let ptr_num_transmute = unsafe {
    ///     std::mem::transmute::<&i32, usize>(ptr)
    /// };
    ///
    /// // Shandisa `as` kukanda pachinzvimbo
    /// let ptr_num_cast = ptr as *const i32 as usize;
    /// ```
    ///
    /// Kuchinja `*mut T` kuita `&mut T`:
    ///
    /// ```
    /// let ptr: *mut i32 = &mut 0;
    /// let ref_transmuted = unsafe {
    ///     std::mem::transmute::<*mut i32, &mut i32>(ptr)
    /// };
    ///
    /// // Shandisa reborrow pachinzvimbo
    /// let ref_casted = unsafe { &mut *ptr };
    /// ```
    ///
    /// Kuchinja `&mut T` kuita `&mut U`:
    ///
    /// ```
    /// let ptr = &mut 0;
    /// let val_transmuted = unsafe {
    ///     std::mem::transmute::<&mut i32, &mut u32>(ptr)
    /// };
    ///
    /// // Ikozvino, isa pamwechete `as` uye kubvisazve, cherekedza kusungwa kwe `as` `as` hakusi kuchinja
    /////
    /// let val_casts = unsafe { &mut *(ptr as *mut i32 as *mut u32) };
    /// ```
    ///
    /// Kuchinja `&str` kuita `&[u8]`:
    ///
    /// ```
    /// // iyi haisi nzira yakanaka yekuita izvi.
    /// let slice = unsafe { std::mem::transmute::<&str, &[u8]>("Rust") };
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Unogona kushandisa `str::as_bytes`
    /// let slice = "Rust".as_bytes();
    /// assert_eq!(slice, &[82, 117, 115, 116]);
    ///
    /// // Kana, ingoshandisa tete tete, kana iwe uchidzora pamusoro petambo chaiyo
    /////
    /// assert_eq!(b"Rust", &[82, 117, 115, 116]);
    /// ```
    ///
    /// Kuchinja `Vec<&T>` kuita `Vec<Option<&T>>`.
    ///
    /// Kupfuudza mhando yemukati yezvirimo mumudziyo, unofanirwa kuve nechokwadi chekusatyora chero chinhu chemidziyo.
    /// Zve `Vec`, izvi zvinoreva kuti ese saizi *uye kuenderana* kwemhando dzemukati dzinofanirwa kuenderana.
    /// Mimwe midziyo inogona kuvimba nesaizi yerudzi, kuenderana, kana kunyangwe iyo `TypeId`, mune iyo kesi kutenderera kwaisazogoneka zvachose pasina kutyora zvinopinda mumidziyo.
    ///
    ///
    /// ```
    /// let store = [0, 1, 2, 3];
    /// let v_orig = store.iter().collect::<Vec<&i32>>();
    ///
    /// // clone iyo vector sezvatinozoishandisa zvakare gare gare
    /// let v_clone = v_orig.clone();
    ///
    /// // Uchishandisa transmute: izvi zvinotsamira pane isingazivikanwe dhizaini dhizaini ye `Vec`, iri zano rakaipa uye rinogona kukonzera Undefined Maitiro.
    /////
    /// // Nekudaro, haina-kopi.
    /// let v_transmuted = unsafe {
    ///     std::mem::transmute::<Vec<&i32>, Vec<Option<&i32>>>(v_clone)
    /// };
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Iyi ndiyo nzira yakataurwa, yakachengeteka.
    /// // Iyo inoteedzera iyo vector yese, hazvo, mune mutsva mutsva.
    /// let v_collected = v_clone.into_iter()
    ///                          .map(Some)
    ///                          .collect::<Vec<Option<&i32>>>();
    ///
    /// let v_clone = v_orig.clone();
    ///
    /// // Iyi ndiyo chaiyo isina-kopi, isina kuchengeteka nzira ye "transmuting" `Vec`, isina kuvimba nedanho re data.
    /// // Panzvimbo pekudaidzira `transmute` chaiyo, isu tinoita pointer cast, asi maererano nekushandura yepakutanga mhando yerudzi (`&i32`) kune iyo nyowani (`Option<&i32>`), izvi zvine zvese zvakafanana mapango.
    /////
    /// // Kunze kweruzivo rwapihwa pamusoro, zvakare bvunza [`from_raw_parts`] zvinyorwa.
    /////
    /// let v_from_raw = unsafe {
    ///     // FIXME Gadziridza izvi kana vec_into_raw_parts yakagadzikana.
    ///     // Ita shuwa kuti yekutanga vector haina kudonhedzwa.
    ///     let mut v_clone = std::mem::ManuallyDrop::new(v_clone);
    ///     Vec::from_raw_parts(v_clone.as_mut_ptr() as *mut Option<&i32>,
    ///                         v_clone.len(),
    ///                         v_clone.capacity())
    /// };
    /// ```
    ///
    /// [`from_raw_parts`]: ../../std/vec/struct.Vec.html#method.from_raw_parts
    ///
    /// Kuita `split_at_mut`:
    ///
    /// ```
    /// use std::{slice, mem};
    ///
    /// // Kune nzira dzakawanda dzekuita izvi, uye kune akawanda matambudziko neinotevera (transmute) nzira.
    /////
    /// fn split_at_mut_transmute<T>(slice: &mut [T], mid: usize)
    ///                              -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = mem::transmute::<&mut [T], &mut [T]>(slice);
    ///         // kutanga: transmute haina mhando yakachengeteka;zvese zvinotarisa ndezvekuti T uye
    ///         // U vakaenzana saizi.
    ///         // Chechipiri, pano chaipo, iwe une mareferenzi maviri anogona kuchinongedzwa kune imwechete ndangariro.
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Izvi zvinobvisa mhando matambudziko ekuchengetedza.`&mut *` icha* chete *kukupa `&mut T` kubva ku `&mut T` kana `* mut T`.
    /////
    /// fn split_at_mut_casts<T>(slice: &mut [T], mid: usize)
    ///                          -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let slice2 = &mut *(slice as *mut [T]);
    ///         // zvisinei, iwe uchine mareferenzi maviri anogona kuchinongedzwa kune imwechete ndangariro.
    /////
    ///         (&mut slice[0..mid], &mut slice2[mid..len])
    ///     }
    /// }
    ///
    /// // Aya ndiwo mashandiro anoita raibhurari yakajairwa.
    /// // Iyi ndiyo nzira yakanakisa, kana iwe uchida kuita chakadai
    /// fn split_at_stdlib<T>(slice: &mut [T], mid: usize)
    ///                       -> (&mut [T], &mut [T]) {
    ///     let len = slice.len();
    ///     assert!(mid <= len);
    ///     unsafe {
    ///         let ptr = slice.as_mut_ptr();
    ///         // Izvi zvino zvine mareferenzi matatu anonongedzwa kunongedzera kune imwechete ndangariro.`slice`, iyo rvalue ret.0, uye iyo rvalue ret.1.
    ///         // `slice` haina kuzomboshandiswa mushure me `let ptr = ...`, uye saka munhu anogona kuitora se "dead", uye nekudaro, iwe unongova nezvikamu zviviri chaizvo zvinoshanduka.
    /////
    /////
    /////
    ///         (slice::from_raw_parts_mut(ptr, mid),
    ///          slice::from_raw_parts_mut(ptr.add(mid), len - mid))
    ///     }
    /// }
    /// ```
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    // NOTE: Ipo izvi zvichiita kuti yemukati const igadzikane, isu tine imwe tsika kodhi mu const fn
    // macheki anodzivirira kushandiswa kwayo mukati me `const fn`.
    #[rustc_const_stable(feature = "const_transmute", since = "1.46.0")]
    #[rustc_diagnostic_item = "transmute"]
    pub fn transmute<T, U>(e: T) -> U;

    /// Inodzorera `true` kana iyo chaiyo mhando yakapihwa se `T` inoda donhwe glue;inodzosera `false` kana iyo chaiyo mhando yakapihwa `T` yekushandisa `Copy`.
    ///
    ///
    /// Kana iyo chaiyo mhando isingade kudonhedza glue kana kushandisa `Copy`, ipapo kukosha kwekudzoka kweiri basa hakuna kuzivikanwa.
    ///
    /// Iyo yakasimbiswa vhezheni yeiyi yemukati ndeye [`mem::needs_drop`](crate::mem::needs_drop).
    ///
    ///
    #[rustc_const_stable(feature = "const_needs_drop", since = "1.40.0")]
    pub fn needs_drop<T>() -> bool;

    /// Inoverenga zvakatemwa kubva kunongedzera.
    ///
    /// Izvi zvinoitwa sechinhu chemukati chekudzivirira kushandurwa kuenda nekubva kunhamba, nekuti iko kutendeuka kwaizorasa ruzivo rwekutsiva.
    ///
    /// # Safety
    ///
    /// Dzese dzinotanga uye dzinoguma pointer dzinofanirwa kunge dziri mumiganhu kana imwe byte yapfuura kupera kwechinhu chakapihwa.
    /// Kana imwe poindi iri kunze kwemiganhu kana arithmetic yekufashukira kunoitika saka chero kumwe kushandiswa kweiyo yakadzoserwa kukosha kunoguma neisina kujekeswa maitiro.
    ///
    ///
    /// Iyo yakasimbiswa vhezheni yeiyi yemukati ndeye [`pointer::offset`].
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Inoverenga zvakatemwa kubva kunongedzera, zvinogona kuputira.
    ///
    /// Izvi zvinoitwa sechinhu chemukati chekudzivirira kushandurwa kuenda nekubva kunhamba, sezvo iko kutendeuka kuchitadzisa mamwe magadziriso.
    ///
    /// # Safety
    ///
    /// Kusiyana neiyo `offset` yemukati, ichi chemukati hachirambidze kunongedzera chinongedzo kunongedza mukati kana imwe byte yapfuura kumagumo kwechinhu chakapihwa, uye inoputira neyechipiri inozadzisa arithmetic.
    /// Iko kukosha kunoguma hakureve kuti kunoshanda kuti usvike pakuwana memory.
    ///
    /// Iyo yakasimbiswa vhezheni yeiyi yemukati ndeye [`pointer::wrapping_offset`].
    ///
    ///
    ///
    #[must_use = "returns a new pointer rather than modifying its argument"]
    #[rustc_const_unstable(feature = "const_ptr_offset", issue = "71499")]
    pub fn arith_offset<T>(dst: *const T, offset: isize) -> *const T;

    /// Yakaenzana neyakakodzera `llvm.memcpy.p0i8.0i8.*` yemukati, ine saizi ye `count`*`size_of::<T>()` uye kuenderana kwe
    ///
    /// `min_align_of::<T>()`
    ///
    /// Iyo paramende isina kugadzikana yakaiswa ku `true`, saka haigadziriswe kunze kwekunge saizi yakaenzana zero.
    ///
    /// Ichi chemukati hachina shamwari yakagadzikana.
    ///
    pub fn volatile_copy_nonoverlapping_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Yakaenzana neyakakodzera `llvm.memmove.p0i8.0i8.*` yemukati, ine saizi ye `count* size_of::<T>()` uye kuenderana kwe
    ///
    /// `min_align_of::<T>()`
    ///
    /// Iyo paramende isina kugadzikana yakaiswa ku `true`, saka haigadziriswe kunze kwekunge saizi yakaenzana zero.
    ///
    /// Ichi chemukati hachina shamwari yakagadzikana.
    ///
    pub fn volatile_copy_memory<T>(dst: *mut T, src: *const T, count: usize);
    /// Yakaenzana neyakakodzera `llvm.memset.p0i8.*` yemukati, ine saizi ye `count* size_of::<T>()` uye kuenderana kwe `min_align_of::<T>()`.
    ///
    ///
    /// Iyo paramende isina kugadzikana yakaiswa ku `true`, saka haigadziriswe kunze kwekunge saizi yakaenzana zero.
    ///
    /// Ichi chemukati hachina shamwari yakagadzikana.
    ///
    ///
    pub fn volatile_set_memory<T>(dst: *mut T, val: u8, count: usize);

    /// Inoita mutoro unotsvedza kubva ku `src` pointer.
    ///
    /// Iyo yakasimbiswa vhezheni yeiyi yemukati ndeye [`core::ptr::read_volatile`](crate::ptr::read_volatile).
    pub fn volatile_load<T>(src: *const T) -> T;
    /// Inoita chitoro chisina kugadzikana kune iyo `dst` pointer.
    ///
    /// Iyo yakasimbiswa vhezheni yeiyi yemukati ndeye [`core::ptr::write_volatile`](crate::ptr::write_volatile).
    pub fn volatile_store<T>(dst: *mut T, val: T);

    /// Inoita mutoro usingachinjiki kubva ku `src` pointer Iyo pointer haina kudikanwa kuti ienderane.
    ///
    ///
    /// Ichi chemukati hachina shamwari yakagadzikana.
    pub fn unaligned_volatile_load<T>(src: *const T) -> T;
    /// Inoita chitoro chisina kugadzikana kune iyo `dst` pointer.
    /// Iyo pointer haidiwe kuti ienderane.
    ///
    /// Ichi chemukati hachina shamwari yakagadzikana.
    pub fn unaligned_volatile_store<T>(dst: *mut T, val: T);

    /// Inodzorera iyo square square ye `f32`
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f32::sqrt`](../../std/primitive.f32.html#method.sqrt)
    pub fn sqrtf32(x: f32) -> f32;
    /// Inodzorera iyo square square ye `f64`
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f64::sqrt`](../../std/primitive.f64.html#method.sqrt)
    pub fn sqrtf64(x: f64) -> f64;

    /// Inosimudza `f32` kune iyo manhamba simba.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f32::powi`](../../std/primitive.f32.html#method.powi)
    pub fn powif32(a: f32, x: i32) -> f32;
    /// Inosimudza `f64` kune iyo manhamba simba.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f64::powi`](../../std/primitive.f64.html#method.powi)
    pub fn powif64(a: f64, x: i32) -> f64;

    /// Inodzorera sine ye `f32`.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f32::sin`](../../std/primitive.f32.html#method.sin)
    pub fn sinf32(x: f32) -> f32;
    /// Inodzorera sine ye `f64`.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f64::sin`](../../std/primitive.f64.html#method.sin)
    pub fn sinf64(x: f64) -> f64;

    /// Inodzorera cosine ye `f32`.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f32::cos`](../../std/primitive.f32.html#method.cos)
    pub fn cosf32(x: f32) -> f32;
    /// Inodzorera cosine ye `f64`.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f64::cos`](../../std/primitive.f64.html#method.cos)
    pub fn cosf64(x: f64) -> f64;

    /// Inosimudza `f32` kune `f32` simba.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f32::powf`](../../std/primitive.f32.html#method.powf)
    pub fn powf32(a: f32, x: f32) -> f32;
    /// Inosimudza `f64` kune `f64` simba.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f64::powf`](../../std/primitive.f64.html#method.powf)
    pub fn powf64(a: f64, x: f64) -> f64;

    /// Inodzorera exponential ye `f32`.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f32::exp`](../../std/primitive.f32.html#method.exp)
    pub fn expf32(x: f32) -> f32;
    /// Inodzorera exponential ye `f64`.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f64::exp`](../../std/primitive.f64.html#method.exp)
    pub fn expf64(x: f64) -> f64;

    /// Inodzosera 2 yakasimudzwa kune simba re `f32`.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f32::exp2`](../../std/primitive.f32.html#method.exp2)
    pub fn exp2f32(x: f32) -> f32;
    /// Inodzosera 2 yakasimudzwa kune simba re `f64`.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f64::exp2`](../../std/primitive.f64.html#method.exp2)
    pub fn exp2f64(x: f64) -> f64;

    /// Inodzorera iyo yakasikwa logarithm ye `f32`.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f32::ln`](../../std/primitive.f32.html#method.ln)
    pub fn logf32(x: f32) -> f32;
    /// Inodzorera iyo yakasikwa logarithm ye `f64`.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f64::ln`](../../std/primitive.f64.html#method.ln)
    pub fn logf64(x: f64) -> f64;

    /// Inodzorera base base logarithm ye `f32`.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f32::log10`](../../std/primitive.f32.html#method.log10)
    pub fn log10f32(x: f32) -> f32;
    /// Inodzorera base base logarithm ye `f64`.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f64::log10`](../../std/primitive.f64.html#method.log10)
    pub fn log10f64(x: f64) -> f64;

    /// Inodzorera base base logarithm ye `f32`.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f32::log2`](../../std/primitive.f32.html#method.log2)
    pub fn log2f32(x: f32) -> f32;
    /// Inodzorera base base logarithm ye `f64`.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f64::log2`](../../std/primitive.f64.html#method.log2)
    pub fn log2f64(x: f64) -> f64;

    /// Inodzorera `a * b + c` ye `f32` kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f32::mul_add`](../../std/primitive.f32.html#method.mul_add)
    pub fn fmaf32(a: f32, b: f32, c: f32) -> f32;
    /// Inodzorera `a * b + c` ye `f64` kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f64::mul_add`](../../std/primitive.f64.html#method.mul_add)
    pub fn fmaf64(a: f64, b: f64, c: f64) -> f64;

    /// Inodzorera iyo chaiyo kukosha kwe `f32`.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f32::abs`](../../std/primitive.f32.html#method.abs)
    pub fn fabsf32(x: f32) -> f32;
    /// Inodzorera iyo chaiyo kukosha kwe `f64`.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f64::abs`](../../std/primitive.f64.html#method.abs)
    pub fn fabsf64(x: f64) -> f64;

    /// Inodzorera hushoma hwemhando mbiri dze `f32`.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f32::min`]
    pub fn minnumf32(x: f32, y: f32) -> f32;
    /// Inodzorera hushoma hwemhando mbiri dze `f64`.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f64::min`]
    pub fn minnumf64(x: f64, y: f64) -> f64;
    /// Inodzorera yakakwira miviri ye `f32` kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f32::max`]
    pub fn maxnumf32(x: f32, y: f32) -> f32;
    /// Inodzorera yakakwira miviri ye `f64` kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f64::max`]
    pub fn maxnumf64(x: f64, y: f64) -> f64;

    /// Kopa chiratidzo kubva ku `y` kuenda ku `x` ye `f32` kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f32::copysign`](../../std/primitive.f32.html#method.copysign)
    pub fn copysignf32(x: f32, y: f32) -> f32;
    /// Kopa chiratidzo kubva ku `y` kuenda ku `x` ye `f64` kukosha.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f64::copysign`](../../std/primitive.f64.html#method.copysign)
    pub fn copysignf64(x: f64, y: f64) -> f64;

    /// Inodzorera iyo yakakura kwazvo nhamba isingasviki kana yakaenzana ne `f32`.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f32::floor`](../../std/primitive.f32.html#method.floor)
    pub fn floorf32(x: f32) -> f32;
    /// Inodzorera iyo yakakura kwazvo nhamba isingasviki kana yakaenzana ne `f64`.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f64::floor`](../../std/primitive.f64.html#method.floor)
    pub fn floorf64(x: f64) -> f64;

    /// Inodzosera iyo diki manhamba yakakura kupfuura kana yakaenzana ne `f32`.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f32::ceil`](../../std/primitive.f32.html#method.ceil)
    pub fn ceilf32(x: f32) -> f32;
    /// Inodzosera iyo diki manhamba yakakura kupfuura kana yakaenzana ne `f64`.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f64::ceil`](../../std/primitive.f64.html#method.ceil)
    pub fn ceilf64(x: f64) -> f64;

    /// Inodzorera iyo yakazara chikamu che `f32`.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f32::trunc`](../../std/primitive.f32.html#method.trunc)
    pub fn truncf32(x: f32) -> f32;
    /// Inodzorera iyo yakazara chikamu che `f64`.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f64::trunc`](../../std/primitive.f64.html#method.trunc)
    pub fn truncf64(x: f64) -> f64;

    /// Inodzorera iyo yepedyo nhamba kune `f32`.
    /// Inogona kukwidza inexact inoyerera-poindi yakasarudzika kana nharo isiri yekuwanda.
    pub fn rintf32(x: f32) -> f32;
    /// Inodzorera iyo yepedyo nhamba kune `f64`.
    /// Inogona kukwidza inexact inoyerera-poindi yakasarudzika kana nharo isiri yekuwanda.
    pub fn rintf64(x: f64) -> f64;

    /// Inodzorera iyo yepedyo nhamba kune `f32`.
    ///
    /// Ichi chemukati hachina shamwari yakagadzikana.
    pub fn nearbyintf32(x: f32) -> f32;
    /// Inodzorera iyo yepedyo nhamba kune `f64`.
    ///
    /// Ichi chemukati hachina shamwari yakagadzikana.
    pub fn nearbyintf64(x: f64) -> f64;

    /// Inodzorera iyo yepedyo nhamba kune `f32`.Inotenderera hafu-nzira kesi kure kubva zero.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f32::round`](../../std/primitive.f32.html#method.round)
    pub fn roundf32(x: f32) -> f32;
    /// Inodzorera iyo yepedyo nhamba kune `f64`.Inotenderera hafu-nzira kesi kure kubva zero.
    ///
    /// Iyo yakagadzika vhezheni yeiyi yemukati ndeye
    /// [`f64::round`](../../std/primitive.f64.html#method.round)
    pub fn roundf64(x: f64) -> f64;

    /// Float yekuwedzera iyo inobvumidza optimizations zvichibva pane algebraic mitemo.
    /// Unogona kufunga kuti zvigadzirwa zvakaperera.
    ///
    /// Ichi chemukati hachina shamwari yakagadzikana.
    pub fn fadd_fast<T: Copy>(a: T, b: T) -> T;

    /// Kubvisa kuyangarara iyo inobvumidza optimizations zvichibva pane algebraic mitemo.
    /// Unogona kufunga kuti zvigadzirwa zvakaperera.
    ///
    /// Ichi chemukati hachina shamwari yakagadzikana.
    pub fn fsub_fast<T: Copy>(a: T, b: T) -> T;

    /// Kuwedzeredza kuyangarara iyo inobvumidza optimizations zvichibva pane algebraic mitemo.
    /// Unogona kufunga kuti zvigadzirwa zvakaperera.
    ///
    /// Ichi chemukati hachina shamwari yakagadzikana.
    pub fn fmul_fast<T: Copy>(a: T, b: T) -> T;

    /// Float kupatsanurana iyo inobvumidza optimizations zvichibva pane algebraic mitemo.
    /// Unogona kufunga kuti zvigadzirwa zvakaperera.
    ///
    /// Ichi chemukati hachina shamwari yakagadzikana.
    pub fn fdiv_fast<T: Copy>(a: T, b: T) -> T;

    /// Float yasara iyo inobvumidza optimizations zvichienderana nemitemo yealgebraic.
    /// Unogona kufunga kuti zvigadzirwa zvakaperera.
    ///
    /// Ichi chemukati hachina shamwari yakagadzikana.
    pub fn frem_fast<T: Copy>(a: T, b: T) -> T;

    /// Chinja neLLVM's fptoui/fptosi, iyo inogona kudzosa undef yemitengo kunze kwehurefu
    /// (<https://github.com/rust-lang/rust/issues/10184>)
    ///
    /// Yakadzikama se [`f32::to_int_unchecked`] uye [`f64::to_int_unchecked`].
    pub fn float_to_int_unchecked<Float: Copy, Int: Copy>(value: Float) -> Int;

    /// Inodzorera iyo nhamba yemabiti akaiswa mune yakasarudzika mhando `T`
    ///
    /// Shanduro dzakadzikama dzeichi chemukati dzinowanikwa pane ekutanga manhamba nenzira ye `count_ones`.
    /// Semuyenzaniso,
    /// [`u32::count_ones`]
    #[rustc_const_stable(feature = "const_ctpop", since = "1.40.0")]
    pub fn ctpop<T: Copy>(x: T) -> T;

    /// Inodzorera iyo nhamba yekutungamira isingamise mabheti (zeroes) mune yakazara nhamba `T`.
    ///
    /// Shanduro dzakadzikama dzeichi chemukati dzinowanikwa pane ekutanga manhamba nenzira ye `leading_zeros`.
    /// Semuyenzaniso,
    /// [`u32::leading_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 3);
    /// ```
    ///
    /// `x` ine kukosha `0` inodzosera iyo hupamhi hwe `T`.
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz;
    ///
    /// let x = 0u16;
    /// let num_leading = ctlz(x);
    /// assert_eq!(num_leading, 16);
    /// ```
    #[rustc_const_stable(feature = "const_ctlz", since = "1.40.0")]
    pub fn ctlz<T: Copy>(x: T) -> T;

    /// Sa `ctlz`, asi yakawedzera-isina kuchengeteka sezvo ichidzosa `undef` painopihwa `x` ine kukosha `0`.
    ///
    ///
    /// Ichi chemukati hachina shamwari yakagadzikana.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::ctlz_nonzero;
    ///
    /// let x = 0b0001_1100_u8;
    /// let num_leading = unsafe { ctlz_nonzero(x) };
    /// assert_eq!(num_leading, 3);
    /// ```
    #[rustc_const_stable(feature = "constctlz", since = "1.50.0")]
    pub fn ctlz_nonzero<T: Copy>(x: T) -> T;

    /// Inodzorera iyo nhamba yekuteedzera isina kumisikidza bits (zeroes) mune yakazara nhamba `T`.
    ///
    /// Shanduro dzakadzikama dzeichi chemukati dzinowanikwa pane ekutanga manhamba nenzira ye `trailing_zeros`.
    /// Semuyenzaniso,
    /// [`u32::trailing_zeros`]
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 3);
    /// ```
    ///
    /// `x` ine kukosha `0` inodzosera iyo hupamhi hwe `T`:
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz;
    ///
    /// let x = 0u16;
    /// let num_trailing = cttz(x);
    /// assert_eq!(num_trailing, 16);
    /// ```
    #[rustc_const_stable(feature = "const_cttz", since = "1.40.0")]
    pub fn cttz<T: Copy>(x: T) -> T;

    /// Sa `cttz`, asi yakawedzera-isina kuchengeteka sezvo ichidzosa `undef` painopihwa `x` ine kukosha `0`.
    ///
    ///
    /// Ichi chemukati hachina shamwari yakagadzikana.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(core_intrinsics)]
    ///
    /// use std::intrinsics::cttz_nonzero;
    ///
    /// let x = 0b0011_1000_u8;
    /// let num_trailing = unsafe { cttz_nonzero(x) };
    /// assert_eq!(num_trailing, 3);
    /// ```
    #[rustc_const_unstable(feature = "const_cttz", issue = "none")]
    pub fn cttz_nonzero<T: Copy>(x: T) -> T;

    /// Inodzorera mabheti mune yakasarudzika mhando `T`.
    ///
    /// Shanduro dzakadzikama dzeichi chemukati dzinowanikwa pane ekutanga manhamba nenzira ye `swap_bytes`.
    /// Semuyenzaniso,
    /// [`u32::swap_bytes`]
    #[rustc_const_stable(feature = "const_bswap", since = "1.40.0")]
    pub fn bswap<T: Copy>(x: T) -> T;

    /// Inodzoreredza mabiti mune yakasarudzika mhando `T`.
    ///
    /// Shanduro dzakadzikama dzeichi chemukati dzinowanikwa pane ekutanga manhamba nenzira ye `reverse_bits`.
    /// Semuyenzaniso,
    /// [`u32::reverse_bits`]
    #[rustc_const_stable(feature = "const_bitreverse", since = "1.40.0")]
    pub fn bitreverse<T: Copy>(x: T) -> T;

    /// Inoita yakatariswa kuwanda kuwedzerwa.
    ///
    /// Shanduro dzakadzikama dzeichi chemukati dzinowanikwa pane ekutanga manhamba nenzira ye `overflowing_add`.
    /// Semuyenzaniso,
    /// [`u32::overflowing_add`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn add_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Inoita kuongororwa kwakadzvanywa nenhamba
    ///
    /// Shanduro dzakadzikama dzeichi chemukati dzinowanikwa pane ekutanga manhamba nenzira ye `overflowing_sub`.
    /// Semuyenzaniso,
    /// [`u32::overflowing_sub`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn sub_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Inoita yakatariswa kuwanda kuwanda
    ///
    /// Shanduro dzakadzikama dzeichi chemukati dzinowanikwa pane ekutanga manhamba nenzira ye `overflowing_mul`.
    /// Semuyenzaniso,
    /// [`u32::overflowing_mul`]
    #[rustc_const_stable(feature = "const_int_overflow", since = "1.40.0")]
    pub fn mul_with_overflow<T: Copy>(x: T, y: T) -> (T, bool);

    /// Inoita kupatsanurwa chaiko, zvichikonzera kusajeka maitiro uko `x % y != 0` kana `y == 0` kana `x == T::MIN && y == -1`
    ///
    ///
    /// Ichi chemukati hachina shamwari yakagadzikana.
    pub fn exact_div<T: Copy>(x: T, y: T) -> T;

    /// Inoita chikamu chisina kuongororwa, zvichikonzera kusanzwisisika maitiro uko `y == 0` kana `x == T::MIN && y == -1`
    ///
    ///
    /// Zvokuputira zvakachengeteka zveichi chemukati zviripo pane zviyero zvekutanga kuburikidza nenzira ye `checked_div`.
    /// Semuyenzaniso,
    /// [`u32::checked_div`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_div<T: Copy>(x: T, y: T) -> T;
    /// Inodzorera zvasara zvechikamu chisina kuongororwa, zvichikonzera kusanzwisisika maitiro kana `y == 0` kana `x == T::MIN && y == -1`
    ///
    ///
    /// Zvokuputira zvakachengeteka zveichi chemukati zviripo pane zviyero zvekutanga kuburikidza nenzira ye `checked_rem`.
    /// Semuyenzaniso,
    /// [`u32::checked_rem`]
    #[rustc_const_stable(feature = "const_int_unchecked_arith", since = "1.52.0")]
    pub fn unchecked_rem<T: Copy>(x: T, y: T) -> T;

    /// Inoita isingataridzwe kuruboshwe kusuduruka, zvichikonzera kusanzwisisika maitiro kana `y < 0` kana `y >= N`, uko N iri hupamhi hweT mumabits.
    ///
    ///
    /// Zvokuputira zvakachengeteka zveichi chemukati zviripo pane zviyero zvekutanga kuburikidza nenzira ye `checked_shl`.
    /// Semuyenzaniso,
    /// [`u32::checked_shl`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shl<T: Copy>(x: T, y: T) -> T;
    /// Inoita isingatariswe kurudyi kuchinjika, zvichikonzera kusanzwisisika maitiro kana `y < 0` kana `y >= N`, uko N iri hupamhi hweT mumabits.
    ///
    ///
    /// Zvokuputira zvakachengeteka zveichi chemukati zviripo pane zviyero zvekutanga kuburikidza nenzira ye `checked_shr`.
    /// Semuyenzaniso,
    /// [`u32::checked_shr`]
    #[rustc_const_stable(feature = "const_int_unchecked", since = "1.40.0")]
    pub fn unchecked_shr<T: Copy>(x: T, y: T) -> T;

    /// Inodzorera mhedzisiro yekuwedzera kusatariswa, zvichikonzera kusanzwisisika maitiro kana `x + y > T::MAX` kana `x + y < T::MIN`.
    ///
    ///
    /// Ichi chemukati hachina shamwari yakagadzikana.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_add<T: Copy>(x: T, y: T) -> T;

    /// Inodzorera mhedzisiro yekubvisa zvisina kuongororwa, zvichikonzera kusanzwisisika maitiro kana `x - y > T::MAX` kana `x - y < T::MIN`.
    ///
    ///
    /// Ichi chemukati hachina shamwari yakagadzikana.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_sub<T: Copy>(x: T, y: T) -> T;

    /// Inodzorera mhedzisiro yekusaongororwa kumisikidzwa, zvichikonzera kusanzwisisika maitiro kana `x *y > T::MAX` kana `x* y < T::MIN`.
    ///
    ///
    /// Ichi chemukati hachina shamwari yakagadzikana.
    #[rustc_const_unstable(feature = "const_int_unchecked_arith", issue = "none")]
    pub fn unchecked_mul<T: Copy>(x: T, y: T) -> T;

    /// Inoita tenderera kuruboshwe.
    ///
    /// Shanduro dzakadzikama dzeichi chemukati dzinowanikwa pane ekutanga manhamba nenzira ye `rotate_left`.
    /// Semuyenzaniso,
    /// [`u32::rotate_left`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_left<T: Copy>(x: T, y: T) -> T;

    /// Inoita tenderera kurudyi.
    ///
    /// Shanduro dzakadzikama dzeichi chemukati dzinowanikwa pane ekutanga manhamba nenzira ye `rotate_right`.
    /// Semuyenzaniso,
    /// [`u32::rotate_right`]
    #[rustc_const_stable(feature = "const_int_rotate", since = "1.40.0")]
    pub fn rotate_right<T: Copy>(x: T, y: T) -> T;

    /// Inodzorera (a + b) modhi 2 <sup>N</sup>, uko N iri hupamhi hweT mumabheti.
    ///
    /// Shanduro dzakadzikama dzeichi chemukati dzinowanikwa pane ekutanga manhamba nenzira ye `wrapping_add`.
    /// Semuyenzaniso,
    /// [`u32::wrapping_add`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_add<T: Copy>(a: T, b: T) -> T;
    /// Inodzorera (a, b) modhi 2 <sup>N</sup>, uko N iri hupamhi hweT mumabheti.
    ///
    /// Shanduro dzakadzikama dzeichi chemukati dzinowanikwa pane ekutanga manhamba nenzira ye `wrapping_sub`.
    /// Semuyenzaniso,
    /// [`u32::wrapping_sub`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_sub<T: Copy>(a: T, b: T) -> T;
    /// Inodzorera (a * b) modhi 2 <sup>N</sup>, uko N iri hupamhi hweT mumabheti.
    ///
    /// Shanduro dzakadzikama dzeichi chemukati dzinowanikwa pane ekutanga manhamba nenzira ye `wrapping_mul`.
    /// Semuyenzaniso,
    /// [`u32::wrapping_mul`]
    #[rustc_const_stable(feature = "const_int_wrapping", since = "1.40.0")]
    pub fn wrapping_mul<T: Copy>(a: T, b: T) -> T;

    /// Makomputa `a + b`, achiguta pamatanho ehuwandu.
    ///
    /// Shanduro dzakadzikama dzeichi chemukati dzinowanikwa pane ekutanga manhamba nenzira ye `saturating_add`.
    /// Semuyenzaniso,
    /// [`u32::saturating_add`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_add<T: Copy>(a: T, b: T) -> T;
    /// Makomputa `a - b`, achiguta pamatanho ehuwandu.
    ///
    /// Shanduro dzakadzikama dzeichi chemukati dzinowanikwa pane ekutanga manhamba nenzira ye `saturating_sub`.
    /// Semuyenzaniso,
    /// [`u32::saturating_sub`]
    #[rustc_const_stable(feature = "const_int_saturating", since = "1.40.0")]
    pub fn saturating_sub<T: Copy>(a: T, b: T) -> T;

    /// Inodzorera kukosha kwesarudzo yemaonero mu 'v';
    /// kana `T` isina rusarura, inodzosera `0`.
    ///
    /// Iyo yakasimbiswa vhezheni yeiyi yemukati ndeye [`core::mem::discriminant`](crate::mem::discriminant).
    #[rustc_const_unstable(feature = "const_discriminant", issue = "69821")]
    pub fn discriminant_value<T>(v: &T) -> <T as DiscriminantKind>::Discriminant;

    /// Inodzorera huwandu hwezvakasiyana zverudzi `T` yakakandwa ku `usize`;
    /// kana `T` isina zvimwe, inodzosera `0`.Misiyano isingagarwe ichaverengerwa.
    ///
    /// Iyo-yeku-kugadzikana vhezheni yeiyi yemukati ndeye [`mem::variant_count`].
    #[rustc_const_unstable(feature = "variant_count", issue = "73662")]
    pub fn variant_count<T>() -> usize;

    /// Rust's "try catch" inovaka iyo inosheedzera iro basa pointer `try_fn` ine data pointer `data`.
    ///
    /// Iyo nharo yechitatu ibasa rakadaidzwa kana panic ikaitika.
    /// Iri basa rinotora pointer yedata uye chinongedzo kune chakanangwa-chakasarudzika chinhu chakabatwa.
    ///
    /// Kuti uwane rumwe ruzivo ona iyo compiler sosi pamwe ne std yekubata kuitiswa.
    ///
    pub fn r#try(try_fn: fn(*mut u8), data: *mut u8, catch_fn: fn(*mut u8, *mut u8)) -> i32;

    /// Inoburitsa chitoro che `!nontemporal` zvinoenderana neLLVM (ona zvinyorwa zvavo).
    /// Pamwe haife yakatsiga.
    pub fn nontemporal_store<T>(ptr: *mut T, val: T);

    /// Ona zvinyorwa zve `<*const T>::offset_from` kuti uwane rumwe ruzivo.
    #[rustc_const_unstable(feature = "const_ptr_offset_from", issue = "41079")]
    pub fn ptr_offset_from<T>(ptr: *const T, base: *const T) -> isize;

    /// Ona zvinyorwa zve `<*const T>::guaranteed_eq` kuti uwane rumwe ruzivo.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_eq<T>(ptr: *const T, other: *const T) -> bool;

    /// Ona zvinyorwa zve `<*const T>::guaranteed_ne` kuti uwane rumwe ruzivo.
    #[rustc_const_unstable(feature = "const_raw_ptr_comparison", issue = "53020")]
    pub fn ptr_guaranteed_ne<T>(ptr: *const T, other: *const T) -> bool;

    /// Govera panguva yekubatanidza.Haifanire kudaidzwa panguva yekumhanya.
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    pub fn const_allocate(size: usize, align: usize) -> *mut u8;
}

// Mamwe mabasa anotsanangurwa pano nekuti netsaona akaitwa kuti awanikwe mune ino module pane solid.
// Ona <https://github.com/rust-lang/rust/issues/15702>.
// (`transmute` inowirawo muchikamu ichi, asi haigone kuputirwa nekuda kwekutarisa kuti `T` ne `U` vane saizi yakafanana.)
//

/// Inotarisa kuti `ptr` yakanyatsoenderana zvine chekuita ne `align_of::<T>()`.
///
pub(crate) fn is_aligned_and_not_null<T>(ptr: *const T) -> bool {
    !ptr.is_null() && ptr as usize % mem::align_of::<T>() == 0
}

/// Makopi `count *size_of::<T>()` byte kubva ku `src` kusvika `dst`.Kwayakabva uye kwairi kuenda hakufanirwe* kupindirana.
///
/// Kwenzvimbo dzekurangarira dzinogona kupfuura, shandisa [`copy`] pachinzvimbo.
///
/// `copy_nonoverlapping` yakafanana nechimiro neC's [`memcpy`], asi negakava rekupokana rakachinjaniswa.
///
/// [`memcpy`]: https://en.cppreference.com/w/c/string/byte/memcpy
///
/// # Safety
///
/// Maitiro haana kujekeswa kana chero eanotevera mamiriro akatyorwa:
///
/// * `src` inofanirwa kunge iri [valid] yekuverenga kwe `count * size_of::<T>()` byte.
///
/// * `dst` inofanirwa kunge iri [valid] yekunyora nezve `count * size_of::<T>()` byte.
///
/// * Ose ari maviri `src` uye `dst` anofanirwa kuenderana zvakanaka.
///
/// * Iyo nzvimbo yekurangarira inotangira pa `src` ine saizi ye` count *
///   saizi_ye: :<T>() `byte haifanire * kupindirana nedunhu rekurangarira kutanga pa `dst` nehukuru hwakaenzana.
///
/// Sa [`read`], `copy_nonoverlapping` inogadzira kopi ye `T`, zvisinei nekuti `T` i [`Copy`].
/// Kana `T` isiri [`Copy`], uchishandisa *zvese zviri* zviri mudunhu zvinotangira pa `*src` uye dunhu rinotangira pa `* dst` rinogona [violate memory safety][read-ownership].
///
///
/// Ziva kuti kunyangwe kana saizi yakanyatsoteedzerwa (`count * size_of: :<T>()`) iri `0`, zvinongedzo zvinofanirwa kunge zvisina-NULL uye zvakanyatsoenderana.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Nemaoko shandisa [`Vec::append`]:
///
/// ```
/// use std::ptr;
///
/// /// Inofambisa zvese zvinhu zve `src` kuita `dst`, ichisiya `src` isina chinhu.
/// fn append<T>(dst: &mut Vec<T>, src: &mut Vec<T>) {
///     let src_len = src.len();
///     let dst_len = dst.len();
///
///     // Ita shuwa kuti `dst` ine chinokwana kugona kubata ese ma `src`.
///     dst.reserve(src_len);
///
///     unsafe {
///         // Kufona kwekukanganisa kunogara kwakachengeteka nekuti `Vec` haife yakapa zvinopfuura `isize::MAX` byte.
/////
///         let dst_ptr = dst.as_mut_ptr().offset(dst_len as isize);
///         let src_ptr = src.as_ptr();
///
///         // Truncate `src` isina kukanda zvirimo.
///         // Isu tinoita izvi kutanga, kudzivirira matambudziko kuitira kana chimwe chinhu chikaenderera pasi panics.
///         src.set_len(0);
///
///         // Idzi nzvimbo mbiri hadzigone kuwiriranwa nekuti zvinoshandurwa zvinongedzo hazvisi ma alias, uye maviri akasiyana vectors haakwanise kuve neyeyeuchidzo imwechete.
/////
/////
///         ptr::copy_nonoverlapping(src_ptr, dst_ptr, src_len);
///
///         // Zivisa `dst` kuti ikozvino inobata zvirimo mu `src`.
///         dst.set_len(dst_len + src_len);
///     }
/// }
///
/// let mut a = vec!['r'];
/// let mut b = vec!['u', 's', 't'];
///
/// append(&mut a, &mut b);
///
/// assert_eq!(a, &['r', 'u', 's', 't']);
/// assert!(b.is_empty());
/// ```
///
/// [`Vec::append`]: ../../std/vec/struct.Vec.html#method.append
///
///
///
///
///
#[doc(alias = "memcpy")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy_nonoverlapping<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Ita macheki aya chete panguva yekumhanya
    /*if cfg!(debug_assertions)
        && !(is_aligned_and_not_null(src)
            && is_aligned_and_not_null(dst)
            && is_nonoverlapping(src, dst, count))
    {
        // Kwete kuvhunduka kuchengeta codegen kukanganisa kudiki.
        abort();
    }*/

    // Kachengeteka: chibvumirano chekuchengetedza che `copy_nonoverlapping` chinofanira kunge chiri
    // yakasimudzwa nemunhu akafona.
    unsafe { copy_nonoverlapping(src, dst, count) }
}

/// Makopi `count * size_of::<T>()` byte kubva ku `src` kusvika `dst`.Kwazviri nekwairi kuenda kunogona kusangana.
///
/// Kana kwayakaenda uye kwainoenda kusingazo * pindike, [`copy_nonoverlapping`] inogona kushandiswa pachinzvimbo.
///
/// `copy` yakafanana nechimiro neC's [`memmove`], asi negakava rekupokana rakachinjaniswa.
/// Kuteedzera kunoitika sekunge mabheti akateedzerwa kubva ku `src` kuenda kune yechinguvana rondedzero uye ndokuteedzerwa kubva pakurongwa kuenda ku `dst`.
///
/// [`memmove`]: https://en.cppreference.com/w/c/string/byte/memmove
///
/// # Safety
///
/// Maitiro haana kujekeswa kana chero eanotevera mamiriro akatyorwa:
///
/// * `src` inofanirwa kunge iri [valid] yekuverenga kwe `count * size_of::<T>()` byte.
///
/// * `dst` inofanirwa kunge iri [valid] yekunyora nezve `count * size_of::<T>()` byte.
///
/// * Ose ari maviri `src` uye `dst` anofanirwa kuenderana zvakanaka.
///
/// Sa [`read`], `copy` inogadzira kopi ye `T`, kunyangwe `T` iri [`Copy`].
/// Kana `T` isiri [`Copy`], uchishandisa zvese kukosha mudunhu kutanga pa `*src` uye dunhu rinotangira pa `* dst` rinogona [violate memory safety][read-ownership].
///
///
/// Ziva kuti kunyangwe kana saizi yakanyatsoteedzerwa (`count * size_of: :<T>()`) iri `0`, zvinongedzo zvinofanirwa kunge zvisina-NULL uye zvakanyatsoenderana.
///
/// [`read`]: crate::ptr::read
/// [read-ownership]: crate::ptr::read#ownership-of-the-returned-value
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Nyatso gadzira Rust vector kubva kune isina kuchengetedzeka buffer:
///
/// ```
/// use std::ptr;
///
/// /// # Safety
//////
/// /// * `ptr` inofanira kunge yakanyatsoenderana nerudzi rwayo uye isiri zero.
/// /// * `ptr` inofanirwa kuve inoshanda pakuverenga kwe `elts` zvinhu zvinoenderana zverudzi `T`.
/// /// * Izvo zvinhu hazvifanire kushandiswa mushure mekushevedza basa iri kunze kwekunge `T: Copy`.
/// # #[allow(dead_code)]
/// unsafe fn from_buf_raw<T>(ptr: *const T, elts: usize) -> Vec<T> {
///     let mut dst = Vec::with_capacity(elts);
///
///     // KUCHENGETEKA: Chirevo chedu chinogonesa kuti sosi yacho inowirirana uye inoshanda,
///     // uye `Vec::with_capacity` inova nechokwadi chekuti tine nzvimbo yekushandisa yekuinyora.
///     ptr::copy(ptr, dst.as_mut_ptr(), elts);
///
///     // Kachengeteka: Takazvigadzira neiyi yakawanda nzvimbo pakutanga,
///     // uye yapfuura `copy` yakatanga zvinhu izvi.
///     dst.set_len(elts);
///     dst
/// }
/// ```
///
///
///
///
///
#[doc(alias = "memmove")]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
#[inline]
pub const unsafe fn copy<T>(src: *const T, dst: *mut T, count: usize) {
    extern "rust-intrinsic" {
        #[rustc_const_unstable(feature = "const_intrinsic_copy", issue = "80697")]
        fn copy<T>(src: *const T, dst: *mut T, count: usize);
    }

    // FIXME: Ita macheki aya chete panguva yekumhanya
    /*if cfg!(debug_assertions) && !(is_aligned_and_not_null(src) && is_aligned_and_not_null(dst)) {
        // Kwete kuvhunduka kuchengeta codegen kukanganisa kudiki.
        abort();
    }*/

    // Kachengeteka: chibvumirano chekuchengetedza che `copy` chinofanira kuchengetedzwa neanodana.
    unsafe { copy(src, dst, count) }
}

/// Inoisa `count * size_of::<T>()` mabheti endangariro kutanga pa `dst` kusvika `val`.
///
/// `write_bytes` yakafanana neC's [`memset`], asi inoisa `count * size_of::<T>()` byte ku `val`.
///
/// [`memset`]: https://en.cppreference.com/w/c/string/byte/memset
///
/// # Safety
///
/// Maitiro haana kujekeswa kana chero eanotevera mamiriro akatyorwa:
///
/// * `dst` inofanirwa kunge iri [valid] yekunyora nezve `count * size_of::<T>()` byte.
///
/// * `dst` inofanira kunge yakanyatsoenderana.
///
/// Pamusoro pezvo, anofona anofanira kuona kuti kunyora `count * size_of::<T>()` byte kunharaunda yakapihwa yekuyeuka kunogonesa kukosha kwe `T`.
/// Uchishandisa dunhu rekurangarira rakanyorwa se `T` ine kukosha kusingaite kwe `T` haina kujekeswa maitiro.
///
/// Ziva kuti kunyangwe kana saizi yakanyatsoteedzerwa (`count * size_of: :<T>()`) iri `0`, iyo pointer inofanirwa kunge isiri-NULL uye yakanyatsoenderana.
///
/// [valid]: crate::ptr#safety
///
/// # Examples
///
/// Kushandiswa kwekutanga:
///
/// ```
/// use std::ptr;
///
/// let mut vec = vec![0u32; 4];
/// unsafe {
///     let vec_ptr = vec.as_mut_ptr();
///     ptr::write_bytes(vec_ptr, 0xfe, 2);
/// }
/// assert_eq!(vec, [0xfefefefe, 0xfefefefe, 0, 0]);
/// ```
///
/// Kugadzira isina kukosha kukosha:
///
/// ```
/// use std::ptr;
///
/// let mut v = Box::new(0i32);
///
/// unsafe {
///     // Inodonhedza iyo yakambobatwa kukosha nekunyora iyo `Box<T>` ine null pointer.
/////
///     ptr::write_bytes(&mut v as *mut Box<i32>, 0, 1);
/// }
///
/// // Panguva ino, kushandisa kana kudonhedza `v` mhedzisiro mune isina kujekeswa maitiro.
/// // drop(v); // ERROR
///
/// // Kunyangwe ichidonhedza `v` "uses" iyo, uye nekudaro haina kujekeswa maitiro.
/// // mem::forget(v); // ERROR
///
/// // Muchokwadi, `v` haishande zvinoenderana neyekutanga mhando dhizaini inowirirana, saka *chero* oparesheni inoibata haina kujekeswa maitiro.
/////
/// // rega v2 =v;//Kanganiso
///
/// unsafe {
///     // Ngatitorei panzvimbo inokosheswa kukosha
///     ptr::write(&mut v as *mut Box<i32>, Box::new(42i32));
/// }
///
/// // Ikozvino bhokisi rakanaka
/// assert_eq!(*v, 42);
/// ```
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[inline]
pub unsafe fn write_bytes<T>(dst: *mut T, val: u8, count: usize) {
    extern "rust-intrinsic" {
        fn write_bytes<T>(dst: *mut T, val: u8, count: usize);
    }

    debug_assert!(is_aligned_and_not_null(dst), "attempt to write to unaligned or null pointer");

    // Kachengeteka: chibvumirano chekuchengetedza che `write_bytes` chinofanira kuchengetedzwa neanodana.
    unsafe { write_bytes(dst, val, count) }
}