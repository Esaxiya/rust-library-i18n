//! Module yekushanda nedhata rakakweretwa.

#![stable(feature = "rust1", since = "1.0.0")]

/// trait yekukwereta dhata.
///
/// Mu Rust, zvakajairika kupa zvimiro zvakasiyana zverudzi rwemakesi ekushandisa akasiyana.
/// Semuenzaniso, nzvimbo yekuchengetera uye manejimendi yeiyo kukosha inogona kusarudzwa chaizvo senge yakakodzera kune kumwe kushandiswa nekushandisa mhando dzemaporesita senge [`Box<T>`] kana [`Rc<T>`].
/// Beyond izvi zvakajairika zviputira zvinogona kushandiswa nechero mhando, mamwe marudzi anopa zvakasarudzika maficha anopa anodhura mashandiro.
/// Muenzaniso werudzi rwakadai i [`String`] iyo inowedzera kugona kuwedzera tambo kune yakakosha [`str`].
/// Izvi zvinoda kuchengeta rumwe ruzivo rusina basa netambo yakapusa, isingachinjiki.
///
/// Aya marudzi anopa mukana kune iyo yepasi data kuburikidza nereferenzi kune iyo mhando yeiyo data.Ivo vanonzi vano'kweretwa se 'mhando iyoyo.
/// Semuenzaniso, [`Box<T>`] inogona kukweretwa se `T` nepo [`String`] inogona kukweretwa se `str`.
///
/// Mhando dzinoratidza kuti dzinogona kukweretwa seimwe mhando `T` nekushandisa `Borrow<T>`, ichipa chirevo kune `T` munzira ye trait's [`borrow`].Rudzi rwakasununguka kukwereta semhando dzakasiyana dzakasiyana.
/// Kana ichida kukwereta zvine mutsindo senge mhando-ichibvumira iyo yepasi data kuti igadziriswe, inogona kuwedzera kushandisa [`BorrowMut<T>`].
///
/// Kupfuurirazve, kana ichipa mashandisiro e traits yekuwedzera, zvinoda kutariswa kuti vanofanirwa kuzvibata zvakafanana kune izvo zvemhando yepasi semhedzisiro yekuita semumiriri werudzi irworwo.
/// Generic kodhi inowanzo shandisa `Borrow<T>` kana ichivimba neyakafanana maitiro eaya akawedzera trait kuita.
/// Aya traits angangoonekwa seanowedzera trait bound.
///
/// Kunyanya `Eq`, `Ord` uye `Hash` inofanirwa kunge yakaenzana nemitero yakweretwa uye ndeyayo: `x.borrow() == y.borrow()` inofanira kupa mhedzisiro yakafanana ne `x == y`.
///
/// Kana generic kodhi ichingoda kushandira ese marudzi ayo anogona kupa chirevo kune inoenderana mhando `T`, zvinowanzova zvirinani kushandisa [`AsRef<T>`] sezvo mamwe marudzi anogona kuitisa zvakachengeteka.
///
/// [`Box<T>`]: ../../std/boxed/struct.Box.html
/// [`Mutex<T>`]: ../../std/sync/struct.Mutex.html
/// [`Rc<T>`]: ../../std/rc/struct.Rc.html
/// [`String`]: ../../std/string/struct.String.html
/// [`borrow`]: Borrow::borrow
///
/// # Examples
///
/// Sekutora data, [`HashMap<K, V>`] ine zvese makiyi uye kukosha.Kana iyo kiyi iri chaiyo data yakaputirwa nemhando yekugadzirisa yeimwe mhando, zvinofanirwa, zvakadaro, zvichiri kukwanisika kutsvaga kukosha uchishandisa chirevo chekiyi data.
/// Semuenzaniso, kana kiyi iri tambo, saka inogona kunge yakachengetwa neiyo hash mepu se [`String`], nepo ichigona kunge ichitsvaga uchishandisa [`&str`][`str`].
/// Nekudaro, `insert` inoda kushanda pane `String` nepo `get` ichida kukwanisa kushandisa `&str`.
///
/// Zvishoma zvakareruka, zvikamu zvinoenderana zve `HashMap<K, V>` zvinotaridzika seizvi:
///
/// ```
/// use std::borrow::Borrow;
/// use std::hash::Hash;
///
/// pub struct HashMap<K, V> {
///     # marker: ::std::marker::PhantomData<(K, V)>,
///     // minda yakasiyiwa
/// }
///
/// impl<K, V> HashMap<K, V> {
///     pub fn insert(&self, key: K, value: V) -> Option<V>
///     where K: Hash + Eq
///     {
///         # unimplemented!()
///         // ...
///     }
///
///     pub fn get<Q>(&self, k: &Q) -> Option<&V>
///     where
///         K: Borrow<Q>,
///         Q: Hash + Eq + ?Sized
///     {
///         # unimplemented!()
///         // ...
///     }
/// }
/// ```
///
/// Iyo yose hashi mepu yakajairika pamusoro pekiyi mhando `K`.Nekuti makiyi aya anochengetwa neiyo hash mepu, mhando iyi inofanirwa kuve neyako kiyi data.
/// Paunenge uchiisa yakakosha-kukosha vaviri, mepu inopihwa yakadaro `K` uye inoda kutsvaga chaiyo hash bhakiti uye woongorora kana kiyi yatovepo zvichibva paiyo `K`.Saka zvinoda `K: Hash + Eq`.
///
/// Paunenge uchitsvaga kukosha mumepu, zvisinei, kuve nekupa chirevo ku `K` sekiyi yekutsvaga kunoda kugara uchigadzira kukosha kwakadaro.
/// Nezve tambo makiyi, izvi zvaizoreva kuti `String` kukosha kunofanirwa kugadzirwa kungotsvaga kwezviitiko panongowanikwa `str`.
///
/// Panzvimbo iyoyo, iyo `get` nzira ndeye generic pamusoro perudzi rweiyo yepasi kiyi data, inonzi `Q` mune nzira siginecha pamusoro.Inotaura kuti `K` inokwereta se `Q` nekuda iyo `K: Borrow<Q>`.
/// Nekuwedzera inoda `Q: Hash + Eq`, inoratidza chiratidzo chekuti `K` uye `Q` dziite ma `Hash` uye `Eq` traits anoburitsa zvakafanana.
///
/// Kuitwa kwe `get` kunovimba zvakanyanya pakuita zvakafanana kwe `Hash` nekumisikidza bhatani rekiyi yehash nekufonera `Hash::hash` pamutengo we `Q` kunyangwe hazvo yakaisa kiyi zvichibva pahash value yakaverengerwa kubva ku `K` kukosha.
///
///
/// Nekuda kweizvozvo, iyo hash mepu inoputsika kana `K` ichiputira `Q` kukosha inogadzira rakasiyana hash pane `Q`.Semuenzaniso, fungidzira iwe une mhando inoputira tambo asi ichifananidza ASCII mavara asina hanya nenyaya yavo:
///
/// ```
/// pub struct CaseInsensitiveString(String);
///
/// impl PartialEq for CaseInsensitiveString {
///     fn eq(&self, other: &Self) -> bool {
///         self.0.eq_ignore_ascii_case(&other.0)
///     }
/// }
///
/// impl Eq for CaseInsensitiveString { }
/// ```
///
/// Nekuti zviyero zviviri zvakaenzana zvinoda kuburitsa yakafanana hash kukosha, kumisikidzwa kwe `Hash` kunoda kufuratira ASCII kesi, zvakare:
///
/// ```
/// # use std::hash::{Hash, Hasher};
/// # pub struct CaseInsensitiveString(String);
/// impl Hash for CaseInsensitiveString {
///     fn hash<H: Hasher>(&self, state: &mut H) {
///         for c in self.0.as_bytes() {
///             c.to_ascii_lowercase().hash(state)
///         }
///     }
/// }
/// ```
///
/// Inogona here `CaseInsensitiveString` kuisa `Borrow<str>`?Ichokwadi inogona kupa chirevo kune tambo chidimbu kuburikidza neyayo yaive neyayo tambo.
/// Asi nekuti kuiswa kwayo kwe `Hash` kwakasiyana, kunozvibata zvakasiyana ne `str` uye nekudaro hakufanirwe, kuita, `Borrow<str>`.
/// Kana ichida kubvumira vamwe kupinda kune yepasi `str`, inogona kuzviita kuburikidza ne `AsRef<str>` iyo isingatakure chero zvimwe zvinodiwa.
///
/// [`Hash`]: crate::hash::Hash
/// [`HashMap<K, V>`]: ../../std/collections/struct.HashMap.html
/// [`String`]: ../../std/string/struct.String.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_diagnostic_item = "Borrow"]
pub trait Borrow<Borrowed: ?Sized> {
    /// Chaizvoizvo inokwereta kubva kune yayo yeinokosha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::Borrow;
    ///
    /// fn check<T: Borrow<str>>(s: T) {
    ///     assert_eq!("Hello", s.borrow());
    /// }
    ///
    /// let s = "Hello".to_string();
    ///
    /// check(s);
    ///
    /// let s = "Hello";
    ///
    /// check(s);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow(&self) -> &Borrowed;
}

/// trait yekukwereta data.
///
/// Seimwe shamwari ye [`Borrow<T>`] iyi trait inobvumidza mhando kukwereta senge iri yepasi mhando nekupa inogona kuchinjika chirevo.
/// Ona [`Borrow<T>`] kuti uwane rumwe ruzivo nezve kukwereta seimwe mhando.
///
#[stable(feature = "rust1", since = "1.0.0")]
pub trait BorrowMut<Borrowed: ?Sized>: Borrow<Borrowed> {
    /// Inobvumirana inokwereta kubva kune yayo yeinokosha.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::borrow::BorrowMut;
    ///
    /// fn check<T: BorrowMut<[i32]>>(mut v: T) {
    ///     assert_eq!(&mut [1, 2, 3], v.borrow_mut());
    /// }
    ///
    /// let v = vec![1, 2, 3];
    ///
    /// check(v);
    /// ```
    #[stable(feature = "rust1", since = "1.0.0")]
    fn borrow_mut(&mut self) -> &mut Borrowed;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for T {
    #[rustc_diagnostic_item = "noop_method_borrow"]
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for T {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> Borrow<T> for &mut T {
    fn borrow(&self) -> &T {
        &**self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> BorrowMut<T> for &mut T {
    fn borrow_mut(&mut self) -> &mut T {
        &mut **self
    }
}