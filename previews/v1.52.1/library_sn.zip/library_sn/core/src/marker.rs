//! Yekutanga traits uye mhando dzinomiririra zvakakosha zvimiro zvemhando.
//!
//! Rust mhando dzinogona kuverengerwa munzira dzakasiyana dzinobatsira zvinoenderana nekwavo kwemukati mezvivakwa.
//! Aya maratidziro anomiririrwa se traits.
//!

#![stable(feature = "rust1", since = "1.0.0")]

use crate::cell::UnsafeCell;
use crate::cmp;
use crate::fmt::Debug;
use crate::hash::Hash;
use crate::hash::Hasher;

/// Mhando dzinogona kuendeswa kuyambuka tambo miganhu.
///
/// Iyi trait inoitwa otomatiki kana compiler yaona zvakakodzera.
///
/// Muenzaniso weiyo isiri-`Send` mhando ndeye referensi-yekuverenga pointer [`rc::Rc`][`Rc`].
/// Kana tambo mbiri dzichiedza kubatanidza [`Rc`] s idzo dzinonongedzera kune imwecheteyo-yakatarwa kukosha, ivo vanogona kuyedza kugadzirisa iyo rejista kuverenga panguva imwe chete, inova [undefined behavior][ub] nekuti [`Rc`] haishandise maatomu mashandiro.
///
/// Hama yake [`sync::Arc`][arc] inoshandisa maatomu mashandiro (inokonzeresa pamusoro) uye saka i `Send`.
///
/// Ona [the Nomicon](../../nomicon/send-and-sync.html) kuti uwane rumwe ruzivo.
///
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [ub]: ../../reference/behavior-considered-undefined.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "send_trait")]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be sent between threads safely",
    label = "`{Self}` cannot be sent between threads safely"
)]
pub unsafe auto trait Send {
    // empty.
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Send for *mut T {}

/// Mhando dzine saizi inogara ichizivikanwa panguva yekubatanidza.
///
/// Yese mhando parameter ine yakasungirirwa yakasungwa ye `Sized`.Iyo yakakosha syntax `?Sized` inogona kushandiswa kubvisa iyi yakasungwa kana isina kukodzera.
///
/// ```
/// # #![allow(dead_code)]
/// struct Foo<T>(T);
/// struct Bar<T: ?Sized>(T);
///
/// // chimiro FooUse(Foo<[i32]>);//kukanganisa: Saizi haina kuitirwa [i32]
/// struct BarUse(Bar<[i32]>); // OK
/// ```
///
/// Iyo yega yekusarudzika ndeye yakasarudzika `Self` mhando ye trait.
/// trait haina kana `Sized` yakasungwa yakasungwa sezvo izvi zvisingawirirane ne [trait chinhu] s apo, netsananguro, iyo trait inoda kushanda pamwe neese anogona kuita, uye nokudaro inogona kunge iri saizi.
///
///
/// Kunyangwe Rust ichikurega uchisunga `Sized` ku trait, haugone kuishandisa kuumba trait chinhu gare gare:
///
/// ```
/// # #![allow(unused_variables)]
/// trait Foo { }
/// trait Bar: Sized { }
///
/// struct Impl;
/// impl Foo for Impl { }
/// impl Bar for Impl { }
///
/// let x: &dyn Foo = &Impl;    // OK
/// // rega y: &dyn Bar= &Impl;//kukanganisa: trait `Bar` haigone kuitwa chinhu
/////
/// ```
///
/// [trait object]: ../../book/ch17-02-trait-objects.html
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "sized"]
#[rustc_on_unimplemented(
    message = "the size for values of type `{Self}` cannot be known at compilation time",
    label = "doesn't have a size known at compile-time"
)]
#[fundamental] // ye Default, semuenzaniso, iyo inoda kuti `[T]: !Default` iongororwe
#[rustc_specialization_trait]
pub trait Sized {
    // Empty.
}

/// Mhando dzinogona kuve "unsized" kune yakasimba-saizi mhando.
///
/// Semuenzaniso, iyo yakakura mhando mhando `[i8; 2]` inoshandisa `Unsize<[i8]>` uye `Unsize<dyn fmt::Debug>`.
///
/// Zvese zviitwa zve `Unsize` zvinopihwa otomatiki nemunyori.
///
/// `Unsize` inoitwa ye:
///
/// - `[T; N]` iri `Unsize<[T]>`
/// - `T` iri `Unsize<dyn Trait>` apo `T: Trait`
/// - `Foo<..., T, ...>` iri `Unsize<Foo<..., U, ...>>` kana:
///   - `T: Unsize<U>`
///   - Foo iri chimiro
///   - Ndima yekupedzisira chete ye `Foo` ine mhando inosanganisira `T`
///   - `T` haisi chikamu cherudzi rwemimwe minda
///   - `Bar<T>: Unsize<Bar<U>>`, kana munda wekupedzisira we `Foo` une mhando `Bar<T>`
///
/// `Unsize` inoshandiswa pamwe chete ne [`ops::CoerceUnsized`] kubvumira "user-defined" midziyo yakadai se [`Rc`] kuti ive nemhando dzakakura zvine simba.
/// Ona iyo [DST coercion RFC][RFC982] uye [the nomicon entry on coercion][nomicon-coerce] kuti uwane rumwe ruzivo.
///
/// [`ops::CoerceUnsized`]: crate::ops::CoerceUnsized
/// [`Rc`]: ../../std/rc/struct.Rc.html
/// [RFC982]: https://github.com/rust-lang/rfcs/blob/master/text/0982-dst-coercion.md
/// [nomicon-coerce]: ../../nomicon/coercions.html
///
///
///
#[unstable(feature = "unsize", issue = "27732")]
#[lang = "unsize"]
pub trait Unsize<T: ?Sized> {
    // Empty.
}

/// Inodikanwa trait yemakondinendi anoshandiswa mumitambo yematehwe.
///
/// Chero chero mhando inowana `PartialEq` inoshandisa yega iyi trait,*zvisinei* kuti ndeyayo mhando-paramita inoitisa `Eq`.
///
/// Kana chinhu che `const` chiine imwe mhando isingaite iyi trait, saka rudzi irworwo kana (1.) harushandise `PartialEq` (zvinoreva kuti iyo nguva dzose haizopa iyo nzira yekuenzanisa, iyo kodhi yekugadzira inofungidzira kuti iripo), kana (2.) inoshandisa *yayo* vhezheni ye `PartialEq` (iyo yatinofungidzira haienderane neyekuumbwa-kuenzana kuenzanisa).
///
///
/// Mune imwe yezviitiko zviviri zviri pamusoro, isu tinoramba kushandiswa kweichi chinogara chiri mumutambo wepateni.
///
/// Onawo iyo [structural match RFC][RFC1445], uye [issue 63438] iyo yakakurudzira kutama kubva kune yakasarudzika-based dhizaini kune ino trait.
///
/// [RFC1445]: https://github.com/rust-lang/rfcs/blob/master/text/1445-restrict-constants-in-patterns.md
/// [issue 63438]: https://github.com/rust-lang/rust/issues/63438
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(PartialEq)]`")]
#[lang = "structural_peq"]
pub trait StructuralPartialEq {
    // Empty.
}

/// Inodikanwa trait yemakondinendi anoshandiswa mumitambo yematehwe.
///
/// Chero chero mhando inowana `Eq` inoshandisa yega iyi trait,*zvisinei* kuti ndeyayo mhando paramita inoshandisa `Eq`.
///
/// Uku kubira kushanda kutenderedza muganho mune yedu mhando system.
///
/// # Background
///
/// Tinoda kuda kuti mhando dzema consts anoshandiswa mumatehwe machisi ane hunhu `#[derive(PartialEq, Eq)]`.
///
/// Mune imwe nyika yakanaka, tinogona kutarisa izvo zvinodiwa nekungotarisa kuti iyo yakapihwa mhando inoshandisa zvese iyo `StructuralPartialEq` trait *uye* iyo `Eq` trait.
/// Nekudaro, iwe unogona kuve nemaADTs ayo *anoita*`derive(PartialEq, Eq)`, uye uve kesi yatinoda kuti compiler igamuchire, uye zvakadaro iyo yemhando yenguva dzose inotadza kuita `Eq`.
///
/// Sezvinei, nyaya yakaita seiyi:
///
/// ```rust
/// #[derive(PartialEq, Eq)]
/// struct Wrap<X>(X);
///
/// fn higher_order(_: &()) { }
///
/// const CFN: Wrap<fn(&())> = Wrap(higher_order);
///
/// fn main() {
///     match CFN {
///         CFN => {}
///         _ => {}
///     }
/// }
/// ```
///
/// (Dambudziko mukodhi iri pamusoro nderekuti `Wrap<fn(&())>` haiite `PartialEq`, kana `Eq`, nekuti `for <'a> fn(&'a _)` does not implement those traits.)
///
/// Naizvozvo, hatigone kuvimba nekutadza kuongorora kwe `StructuralPartialEq` uye `Eq` chete.
///
/// Sekunyepedzera kushanda takatenderedza izvi, isu tinoshandisa maviri akapatsanurwa traits jekiseni neese maviri eanowana (`#[derive(PartialEq)]` uye `#[derive(Eq)]`) uye wotarisa kuti ese ari maviri aripo sechikamu cheyakaumbwa-mutambo kutarisa.
///
///
///
///
///
///
///
///
///
///
#[unstable(feature = "structural_match", issue = "31434")]
#[rustc_on_unimplemented(message = "the type `{Self}` does not `#[derive(Eq)]`")]
#[lang = "structural_teq"]
pub trait StructuralEq {
    // Empty.
}

/// Mhando dzine tsika dzadzo dzinogona kuteedzerwa nekungoteedzera mabiti.
///
/// Nokusingaperi, zvisungo zvinoshanduka zvine 'kufamba semantics.'Mune mamwe mazwi:
///
/// ```
/// #[derive(Debug)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `x` yatamira mu `y`, uye saka haigone kushandiswa
///
/// // println! ("{: ?}", x);//kukanganisa: kushandiswa kwekutama kukosha
/// ```
///
/// Nekudaro, kana mhando ikashandisa `Copy`, pachinzvimbo iine 'kopi semantics':
///
/// ```
/// // Tinogona kuwana `Copy` kuitiswa.
/// // `Clone` inodawo, sezvo iri supertrait ye `Copy`.
/// #[derive(Debug, Copy, Clone)]
/// struct Foo;
///
/// let x = Foo;
///
/// let y = x;
///
/// // `y` ikopi ye `x`
///
/// println!("{:?}", x); // A-OK!
/// ```
///
/// Izvo zvakakosha kuti uzive kuti mune iyi mienzaniso miviri, mutsauko chete ndewekuti iwe unobvumidzwa kuwana `x` mushure mekupihwa basa.
/// Pasi pehood, ese ari maviri kopi uye kufamba zvinogona kukonzera mabhii ari kuteedzerwa mundangariro, kunyange izvi dzimwe nguva zvakagadziridzwa kure.
///
/// ## Ndingaite sei kuti ndiite `Copy`?
///
/// Pane nzira mbiri dzekushandisa `Copy` pane yako mhando.Chakareruka kushandisa `derive`:
///
/// ```
/// #[derive(Copy, Clone)]
/// struct MyStruct;
/// ```
///
/// Iwe unogona zvakare kushandisa `Copy` uye `Clone` nemaoko:
///
/// ```
/// struct MyStruct;
///
/// impl Copy for MyStruct { }
///
/// impl Clone for MyStruct {
///     fn clone(&self) -> MyStruct {
///         *self
///     }
/// }
/// ```
///
/// Pane musiyano mudiki pakati pezviviri: iyo `derive` zano ichaisawo `Copy` yakasungwa pamhando paramita, isingagare ichidikanwa.
///
/// ## Ndeupi musiyano uripo pakati pe `Copy` ne `Clone`?
///
/// Makopi anoitika zvachose, semuenzaniso sechikamu chebasa `y = x`.Hunhu hwe `Copy` hahuremerwe;inogara iri yakapusa-huchenjeri kopi.
///
/// Cloning chiito chakajeka, `x.clone()`.Kuitwa kwe [`Clone`] kunogona kupa chero mhando-yakasarudzika maitiro anodikanwa kutevedzera tsika zvakachengeteka.
/// Semuenzaniso, kuiswa kwe [`Clone`] kwe [`String`] kunoda kuteedzera yakanongedzwa-tambo buffer mumurwi.
/// Imwe yakapusa kopi kopi ye [`String`] tsika yaizongoteedzera iyo pointer, zvichitungamira kune yakasununguka pasi pasi tambo.
/// Neichi chikonzero, [`String`] iri [`Clone`] asi kwete `Copy`.
///
/// [`Clone`] supertrait ye `Copy`, saka zvese zviri `Copy` zvinofanirwa kuitawo [`Clone`].
/// Kana mhando iri `Copy` saka kuiswa kwayo kwe [`Clone`] kunongoda kudzosa `*self` (ona muenzaniso uri pamusoro).
///
/// ## Rudzi rwangu rungave rini `Copy`?
///
/// Rudzi runogona kuita `Copy` kana zvese zvaro zvikaita `Copy`.Semuenzaniso, ichi chimiro chinogona kunge chiri `Copy`:
///
/// ```
/// # #[allow(dead_code)]
/// #[derive(Copy, Clone)]
/// struct Point {
///    x: i32,
///    y: i32,
/// }
/// ```
///
/// Chimiro chinogona kuva `Copy`, uye [`i32`] iri `Copy`, saka `Point` inokodzera kuve `Copy`.
/// Kupesana, funga
///
/// ```
/// # #![allow(dead_code)]
/// # struct Point;
/// struct PointList {
///     points: Vec<Point>,
/// }
/// ```
///
/// Iyo struct `PointList` haigone kushandisa `Copy`, nekuti [`Vec<T>`] haisi `Copy`.Kana isu tichiedza kuwana `Copy` kuitiswa, isu tinowana kukanganisa:
///
/// ```text
/// the trait `Copy` may not be implemented for this type; field `points` does not implement `Copy`
/// ```
///
/// Yakagovaniswa mareferensi (`&T`) zvakare i `Copy`, saka mhando inogona kuva `Copy`, kunyangwe kana iine mareferenzi akagovaniswa emhando `T` ayo ari *asiri*`Copy`.
/// Chimbofunga chinotevera chimiro, icho chinogona kushandisa `Copy`, nekuti inongobata *yakagovaniswa rejisiti* kune yedu isiri-`Copy` mhando `PointList` kubva kumusoro:
///
/// ```
/// # #![allow(dead_code)]
/// # struct PointList;
/// #[derive(Copy, Clone)]
/// struct PointListWrapper<'a> {
///     point_list_ref: &'a PointList,
/// }
/// ```
///
/// ## Rini *risingakwanise* mhando yangu kuva `Copy`?
///
/// Mimwe mhando haigone kuteedzerwa zvakachengeteka.Semuenzaniso, kuteedzera `&mut T` kwaizogadzira isingachinjiki inogona kuchinjika.
/// Kuteedzera [`String`] kwaizodzokorodza mutoro wekutarisa iyo [`String`] 's buffer, inotungamira kune yakapetwa mahara.
///
/// Kugadzira iyo yekupedzisira kesi, chero mhando irikushandisa [`Drop`] haigone kuve `Copy`, nekuti iri kugadzirisa zvimwe zviwanikwa kunze kwayo [`size_of::<T>`] mabheti.
///
/// Kana iwe ukaedza kuita `Copy` pane struct kana enum ine isina-`Copy` dhata, iwe unowana iko kukanganisa [E0204].
///
/// [E0204]: ../../error-index.html#E0204
///
/// ## Rudzi * rwangu runofanira kuva `Copy` rini?
///
/// Kazhinji kutaura, kana mhando yako _can_ ichiita `Copy`, inofanirwa.
/// Ramba uchifunga, zvakadaro, kuti kushandisa `Copy` chikamu cheveruzhinji API yerudzi rwako.
/// Kana iyo mhando ikave isiri-`Copy` mu future, zvinogona kuve kuchenjera kusiya iyo `Copy` kuitisa izvozvi, kudzivirira kutyora API shanduko.
///
/// ## Kuwedzera vanoshanda
///
/// Pamusoro peiyo [implementors listed below][impls], anotevera marudzi anoshandisawo `Copy`:
///
/// * Yekuita chinhu mhando (kureva, iwo akasarudzika mhando akatsanangurwa pabasa rega rega)
/// * Anoshanda pointer mhando (semuenzaniso, `fn() -> i32`)
/// * Mhando dzearray, dzese saizi, kana chinhu chechinhu chichiisawo `Copy` (semuenzaniso, `[i32; 123456]`)
/// * Mhando dzeTuple, kana chinhu chimwe nechimwe chichiisawo `Copy` (semuenzaniso, `()`, `(i32, bool)`)
/// * Mhando dzekuvhara, kana dzikatora hapana kukosha kubva kunharaunda kana kana ese akadaro akabatwa maitiro anoshandisa `Copy` pachavo.
///   Ziva kuti misiyano yakatorwa neyakagovaniswa mareferensi inogara ichiita `Copy` (kunyangwe kana iyo yakasarudzika isingaiti), nepo misiyano yakatorwa nechinoshandurwa chirevo isingamboite `Copy`
///
///
/// [`Vec<T>`]: ../../std/vec/struct.Vec.html
/// [`String`]: ../../std/string/struct.String.html
/// [`size_of::<T>`]: crate::mem::size_of
/// [impls]: #implementors
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[lang = "copy"]
// FIXME(matthewjasper) Izvi zvinobvumidza kuteedzera mhando isingaite `Copy` nekuda kwekusagutsikana kwemiganhu yehupenyu (kuteedzera `A<'_>` kana chete `A<'static>: Copy` uye `A<'_>: Clone`).
// Tine hunhu pano izvozvi nekuti chete kune akati wandei aripo pa `Copy` ayo atovepo muraibhurari yakajairwa, uye hapana nzira yekuchengeteka maitiro aya izvozvi.
//
//
//
//
#[rustc_unsafe_specialization_marker]
pub trait Copy: Clone {
    // Empty.
}

/// Derive macro inogadzira impl yeiyo trait `Copy`.
#[rustc_builtin_macro]
#[stable(feature = "builtin_macro_prelude", since = "1.38.0")]
#[allow_internal_unstable(core_intrinsics, derive_clone_copy)]
pub macro Copy($item:item) {
    /* compiler built-in */
}

/// Mhando idzo zvakachengeteka kugovana mareferenzi pakati peshinda.
///
/// Iyi trait inoitwa otomatiki kana compiler yaona zvakakodzera.
///
/// Tsananguro chaiyo ndeiyi: mhando `T` iri [`Sync`] kana uye chete kana `&T` iri [`Send`].
/// Mune mamwe mazwi, kana pasina mukana we [undefined behavior][ub] (inosanganisira maratidziro edhata) kana uchipfuura `&T` mareferenzi pakati peshinda.
///
/// Seizvo munhu angatarisira, echinyakare mhando senge [`u8`] uye [`f64`] ese ari [`Sync`], uyezve zviri nyore akaunganidzwa marudzi ane iwo, senge tuples, structs uye enums.
/// Mimwe mienzaniso yedzakakosha [`Sync`] mhando dzinosanganisira "immutable" mhando senge `&T`, uye idzo dzine nyore kugarwa nhaka, senge [`Box<T>`][box], [`Vec<T>`][vec] uye mazhinji mamwe marudzi ekuunganidza.
///
/// (Generic parameter inofanirwa kuve [`Sync`] kuti mudziyo wavo uve [`Sync`].)
///
/// Mhedzisiro inoshamisa yedudziro ndeyekuti `&mut T` iri `Sync` (kana `T` iri `Sync`) kunyangwe ichiratidzika senge inogona kupa shanduko isingaenderane.
/// Icho hunyengeri ndechekuti chinongedzo chinoshandurwa kuseri kwereferenzi yakagovaniswa (ndokuti, `& &mut T`) inova inoverengwa-chete, sekunge yaive `& &T`.
/// Nekudaro hapana njodzi yerudzi rwe data.
///
/// Mhando dzisiri `Sync` ndidzo dzine "interior mutability" mune isina-tambo-yakachengeteka fomu, senge [`Cell`][cell] uye [`RefCell`][refcell].
/// Aya marudzi anotendera shanduko yezviri mukati kunyangwe kuburikidza isingachinjiki, yakagovaniswa mareferenzi.
/// Semuenzaniso nzira ye `set` pa [`Cell<T>`][cell] inotora `&self`, saka zvinongoda revo yakagovaniswa [`&Cell<T>`][cell].
/// Maitiro acho haaenderanise, saka [`Cell`][cell] haigone kuve `Sync`.
///
/// Mumwe muenzaniso weiyo isiri-`Sync` mhando ndeye referensi-yekuverenga pointer [`Rc`][rc].
/// Ukapihwa chero chirevo [`&Rc<T>`][rc], unogona kuumbiridza [`Rc<T>`][rc] nyowani, uchigadzirisa kuverenga kunoverengeka nenzira isiri yeatomu.
///
/// Zvezviitiko kana munhu achida tambo-yakachengeteka mukati kutenderera, Rust inopa [atomic data types], pamwe nekukiya kwakajeka kuburikidza ne [`sync::Mutex`][mutex] uye [`sync::RwLock`][rwlock].
/// Aya marudzi anoona kuti chero shanduko haigone kukonzeresa kumhanyisa dhata, nekudaro mhando dziri `Sync`.
/// Saizvozvo, [`sync::Arc`][arc] inopa tambo-yakachengeteka analogue ye [`Rc`][rc].
///
/// Chero chero mhando nekuchinja kwemukati inofanirwa zvakare kushandisa iyo [`cell::UnsafeCell`][unsafecell] yekumonera yakatenderedza iyo value(s) iyo inogona kuchinjika kuburikidza neyakagovaniswa mareferenzi.
/// Kukundikana kuita izvi i [undefined behavior][ub].
/// Semuenzaniso, [`transmute`][transmute]-ing kubva ku `&T` kuenda ku `&mut T` hazvishande.
///
/// Ona [the Nomicon][nomicon-send-and-sync] kuti uwane rumwe ruzivo nezve `Sync`.
///
/// [box]: ../../std/boxed/struct.Box.html
/// [vec]: ../../std/vec/struct.Vec.html
/// [cell]: crate::cell::Cell
/// [refcell]: crate::cell::RefCell
/// [rc]: ../../std/rc/struct.Rc.html
/// [arc]: ../../std/sync/struct.Arc.html
/// [atomic data types]: crate::sync::atomic
/// [mutex]: ../../std/sync/struct.Mutex.html
/// [rwlock]: ../../std/sync/struct.RwLock.html
/// [unsafecell]: crate::cell::UnsafeCell
/// [ub]: ../../reference/behavior-considered-undefined.html
/// [transmute]: crate::mem::transmute
/// [nomicon-send-and-sync]: ../../nomicon/send-and-sync.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
#[cfg_attr(not(test), rustc_diagnostic_item = "sync_trait")]
#[lang = "sync"]
#[rustc_on_unimplemented(
    message = "`{Self}` cannot be shared between threads safely",
    label = "`{Self}` cannot be shared between threads safely"
)]
pub unsafe auto trait Sync {
    // FIXME(estebank): kamwe rutsigiro rwekuwedzera manotsi mu `rustc_on_unimplemented` nyika mu beta, uye yakawedzeredzwa kutarisa kuti kuvhara kuri kupi kwese muketani inodikanwa, wedzera seizvi (#48534):
    //
    //
    // ```
    // on(
    //     closure,
    //     note="`{Self}` cannot be shared safely, consider marking the closure `move`"
    // ),
    // ```

    // Empty
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *const T {}
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized> !Sync for *mut T {}

macro_rules! impls {
    ($t: ident) => {
        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Hash for $t<T> {
            #[inline]
            fn hash<H: Hasher>(&self, _: &mut H) {}
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialEq for $t<T> {
            fn eq(&self, _other: &$t<T>) -> bool {
                true
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Eq for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::PartialOrd for $t<T> {
            fn partial_cmp(&self, _other: &$t<T>) -> Option<cmp::Ordering> {
                Option::Some(cmp::Ordering::Equal)
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> cmp::Ord for $t<T> {
            fn cmp(&self, _other: &$t<T>) -> cmp::Ordering {
                cmp::Ordering::Equal
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Copy for $t<T> {}

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Clone for $t<T> {
            fn clone(&self) -> Self {
                Self
            }
        }

        #[stable(feature = "rust1", since = "1.0.0")]
        impl<T: ?Sized> Default for $t<T> {
            fn default() -> Self {
                Self
            }
        }

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralPartialEq for $t<T> {}

        #[unstable(feature = "structural_match", issue = "31434")]
        impl<T: ?Sized> StructuralEq for $t<T> {}
    };
}

/// Zero-saizi mhando inoshandiswa kuratidza zvinhu izvo "act like" vane yavo `T`.
///
/// Kuwedzera munda we `PhantomData<T>` kune yako mhando inotaurira compiler kuti yako mhando inoita sekunge inochengeta kukosha kworudzi `T`, kunyangwe isiri chaizvo.
/// Ruzivo urwu runoshandiswa kana uchikomberedza zvimwe zvekuchengetedza zvinhu.
///
/// Kuti uwane kutsanangurwa kwakadzama kwemaitiro ekushandisa `PhantomData<T>`, ndapota ona [the Nomicon](../../nomicon/phantom-data.html).
///
/// # Chinyorwa chinotyisa 👻👻👻
///
/// Kunyangwe ivo vese vaine mazita anotyisa, `PhantomData` uye 'phantom mhando' zvine hukama, asi hazvina kufanana.Iyo phantom mhando paramende ingori mhando paramende iyo isingatombo shandiswa.
/// Mu Rust, izvi zvinowanzo kukonzera kuti muunganidzi anyunyute, uye mhinduro ndeyokuwedzera "dummy" kushandisa nenzira ye `PhantomData`.
///
/// # Examples
///
/// ## Asina kushandiswa ehupenyu parameter
///
/// Zvichida kesi yakajairika yekushandisa ye `PhantomData` idhisheni ine risingashandiswi paramende yehupenyu, kazhinji sechikamu cheimwe kodhi isina kuchengetedzeka.
/// Semuenzaniso, heino struct `Slice` ine zvinongedzo zviviri zverudzi `*const T`, zvinofungidzirwa zvichinongedzera munongedzo kumwe kunhu:
///
/// ```compile_fail,E0392
/// struct Slice<'a, T> {
///     start: *const T,
///     end: *const T,
/// }
/// ```
///
/// Icho chinangwa ndechekuti iyo yepasi data iri chete inoshanda kune yehupenyu `'a`, saka `Slice` haifanire kurarama kupfuura `'a`.
/// Nekudaro, ichi chinangwa hachiratidzwe mukodhi, nekuti hapana mashandisiro ehupenyu `'a` uye nekudaro hazvizivikanwe kuti ndeipi dhata inoshanda kune.
/// Tinogona kugadzirisa izvi nekuudza compiler kuti aite *sekunge* iyo `Slice` struct yaive nereferenzi `&'a T`:
///
/// ```
/// use std::marker::PhantomData;
///
/// # #[allow(dead_code)]
/// struct Slice<'a, T: 'a> {
///     start: *const T,
///     end: *const T,
///     phantom: PhantomData<&'a T>,
/// }
/// ```
///
/// Izvi zvakare zvinoda chirevo `T: 'a`, zvichiratidza kuti chero mareferenzi mu `T` anoshanda pamusoro pehupenyu hwese `'a`.
///
/// Kana uchitanga `Slice` iwe unongopa iyo kukosha `PhantomData` yemunda `phantom`:
///
/// ```
/// # #![allow(dead_code)]
/// # use std::marker::PhantomData;
/// # struct Slice<'a, T: 'a> {
/// #     start: *const T,
/// #     end: *const T,
/// #     phantom: PhantomData<&'a T>,
/// # }
/// fn borrow_vec<T>(vec: &Vec<T>) -> Slice<'_, T> {
///     let ptr = vec.as_ptr();
///     Slice {
///         start: ptr,
///         end: unsafe { ptr.add(vec.len()) },
///         phantom: PhantomData,
///     }
/// }
/// ```
///
/// ## Asina kushandiswa mhando parameter
///
/// Izvo dzimwe nguva zvinoitika kuti iwe usina kushandisa mhando paramita iyo inoratidza kuti ndeipi mhando yedhata iyo struct iri "tied" kune, kunyangwe iyo data isiri kunyatso kuwanikwa mune iyo struct pachayo.
/// Heino muenzaniso apo izvi zvinomuka ne [FFI].
/// Iyo yekunze interface inoshandisa mabato erudzi `*mut ()` kureva Rust kukosha kwemhando dzakasiyana.
/// Isu tinoteedzera Rust mhando tichishandisa phantom mhando paramende pane iyo struct `ExternalResource` inoputira mubato.
///
/// [FFI]: ../../book/ch19-01-unsafe-rust.html#using-extern-functions-to-call-external-code
///
/// ```
/// # #![allow(dead_code)]
/// # trait ResType { }
/// # struct ParamType;
/// # mod foreign_lib {
/// #     pub fn new(_: usize) -> *mut () { 42 as *mut () }
/// #     pub fn do_stuff(_: *mut (), _: usize) {}
/// # }
/// # fn convert_params(_: ParamType) -> usize { 42 }
/// use std::marker::PhantomData;
/// use std::mem;
///
/// struct ExternalResource<R> {
///    resource_handle: *mut (),
///    resource_type: PhantomData<R>,
/// }
///
/// impl<R: ResType> ExternalResource<R> {
///     fn new() -> Self {
///         let size_of_res = mem::size_of::<R>();
///         Self {
///             resource_handle: foreign_lib::new(size_of_res),
///             resource_type: PhantomData,
///         }
///     }
///
///     fn do_stuff(&self, param: ParamType) {
///         let foreign_params = convert_params(param);
///         foreign_lib::do_stuff(self.resource_handle, foreign_params);
///     }
/// }
/// ```
///
/// ## Kuva muridzi uye cheki yekudonha
///
/// Kuwedzera munda werudzi `PhantomData<T>` kunoratidza kuti yako mhando ine data rorudzi `T`.Izvi zvinoreva kuti kana mhando yako ikadonhedzwa, inogona kudonhedza imwe kana zvimwe zviitiko zverudzi `T`.
/// Izvi zvine chekuita ne Rust compiler's [drop check] ongororo.
///
/// Kana yako struct isiri *yega* iyo data yerudzi `T`, zvirinani kushandisa remberi mhando, senge `PhantomData<&'a T>` (ideally) kana `PhantomData<*const T>` (kana pasina hupenyu hwese hunoshanda), kuti usaratidze muridzi.
///
///
/// [drop check]: ../../nomicon/dropck.html
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
///
#[lang = "phantom_data"]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct PhantomData<T: ?Sized>;

impls! { PhantomData }

mod impls {
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Sync + ?Sized> Send for &T {}
    #[stable(feature = "rust1", since = "1.0.0")]
    unsafe impl<T: Send + ?Sized> Send for &mut T {}
}

/// Compiler-yemukati trait yakashandiswa kuratidza mhando ye enum discriminants.
///
/// Iyi trait inogadziriswa yega yega mhando uye haiwedzere chero vimbiso ku [`mem::Discriminant`].
/// Iyo **isina kujekeswa maitiro** kutapurirana pakati pe `DiscriminantKind::Discriminant` ne `mem::Discriminant`.
///
/// [`mem::Discriminant`]: crate::mem::Discriminant
///
#[unstable(
    feature = "discriminant_kind",
    issue = "none",
    reason = "this trait is unlikely to ever be stabilized, use `mem::discriminant` instead"
)]
#[lang = "discriminant_kind"]
pub trait DiscriminantKind {
    /// Mhando yerusarura, iyo inofanirwa kugutsa trait bound inodikanwa ne `mem::Discriminant`.
    ///
    #[lang = "discriminant_type"]
    type Discriminant: Clone + Copy + Debug + Eq + PartialEq + Hash + Send + Sync + Unpin;
}

/// Compiler-yemukati trait yakashandiswa kuona kana mhando ine chero `UnsafeCell` mukati, asi kwete kuburikidza neyakarerekera.
///
/// Izvi zvinokanganisa, semuenzaniso, kunyangwe `static` yerudzi irworwo yakaiswa mune yekuverenga-chete static memory kana inonyorwa static memory.
///
#[lang = "freeze"]
pub(crate) unsafe auto trait Freeze {}

impl<T: ?Sized> !Freeze for UnsafeCell<T> {}
unsafe impl<T: ?Sized> Freeze for PhantomData<T> {}
unsafe impl<T: ?Sized> Freeze for *const T {}
unsafe impl<T: ?Sized> Freeze for *mut T {}
unsafe impl<T: ?Sized> Freeze for &T {}
unsafe impl<T: ?Sized> Freeze for &mut T {}

/// Mhando dzinogona kufambiswa zvakanaka mushure mekuiswa.
///
/// Rust pachayo haina fungidziro yemhando isingazungunuke, uye inofunga mafambiro (semuenzaniso, kuburikidza nebasa kana [`mem::replace`]) kuti igare yakachengeteka.
///
/// Iyo [`Pin`][Pin] mhando inoshandiswa pachinzvimbo kudzivirira kufamba kuburikidza neiyo mhando system.Anonongedza `P<T>` akaputirwa mune iyo [`Pin<P<T>>`][Pin] inoputira haigone kubviswa kunze.
/// Ona iyo [`pin` module] zvinyorwa kuti uwane rumwe ruzivo nezve kupinza.
///
/// Kuteedzera iyo `Unpin` trait ye `T` inosimudza zvirambidzo zvekusvinura mhando, iyo inobvumidza kufambisa `T` kunze kwe [`Pin<P<T>>`][Pin] nemabasa akaita se [`mem::replace`].
///
///
/// `Unpin` haina mhedzisiro zvachose kune isina-kudhonzwa dhata.
/// Kunyanya, [`mem::replace`] nemufaro inofambisa `!Unpin` dhata (inoshanda kune chero `&mut T`, kwete chete kana `T: Unpin`).
/// Nekudaro, haugone kushandisa [`mem::replace`] pane data rakaputirwa mukati me [`Pin<P<T>>`][Pin] nekuti haugone kuwana iyo `&mut T` yaunoda iyo, uye *izvo* ndizvo zvinoita kuti system iyi ishande.
///
/// Saka izvi, semuenzaniso, zvinogona kungoitwa pamhando dzekushandisa `Unpin`:
///
/// ```rust
/// # #![allow(unused_must_use)]
/// use std::mem;
/// use std::pin::Pin;
///
/// let mut string = "this".to_string();
/// let mut pinned_string = Pin::new(&mut string);
///
/// // Tinoda chirevo chinoshanduka kufonera `mem::replace`.
/// // Tinogona kuwana chirevo chakadai ne (implicitly) ichikumbira `Pin::deref_mut`, asi izvo zvinongogoneka nekuti `String` inoshandisa `Unpin`.
/////
/// mem::replace(&mut *pinned_string, "other".to_string());
/// ```
///
/// Iyi trait inoitwa otomatiki kune angangoita ese marudzi.
///
/// [`mem::replace`]: crate::mem::replace
/// [Pin]: crate::pin::Pin
/// [`pin` module]: crate::pin
///
///
///
///
///
///
#[stable(feature = "pin", since = "1.33.0")]
#[rustc_on_unimplemented(
    on(_Self = "std::future::Future", note = "consider using `Box::pin`",),
    message = "`{Self}` cannot be unpinned"
)]
#[lang = "unpin"]
pub auto trait Unpin {}

/// Mucherechedzo mhando isingaite `Unpin`.
///
/// Kana mhando iine `PhantomPinned`, haizoite `Unpin` nekukanganisa.
#[stable(feature = "pin", since = "1.33.0")]
#[derive(Debug, Default, Copy, Clone, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct PhantomPinned;

#[stable(feature = "pin", since = "1.33.0")]
impl !Unpin for PhantomPinned {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a T {}

#[stable(feature = "pin", since = "1.33.0")]
impl<'a, T: ?Sized + 'a> Unpin for &'a mut T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *const T {}

#[stable(feature = "pin_raw", since = "1.38.0")]
impl<T: ?Sized> Unpin for *mut T {}

/// Maitiro e `Copy` emhando dzechinyakare.
///
/// Maitiro asingakwanise kutsanangurwa mu Rust anoitwa mu `traits::SelectionContext::copy_clone_conditions()` mu `rustc_trait_selection`.
///
///
mod copy_impls {

    use super::Copy;

    macro_rules! impl_copy {
        ($($t:ty)*) => {
            $(
                #[stable(feature = "rust1", since = "1.0.0")]
                impl Copy for $t {}
            )*
        }
    }

    impl_copy! {
        usize u8 u16 u32 u64 u128
        isize i8 i16 i32 i64 i128
        f32 f64
        bool char
    }

    #[unstable(feature = "never_type", issue = "35121")]
    impl Copy for ! {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *const T {}

    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for *mut T {}

    /// Yakagovaniswa mareferensi inogona kutevedzwa, asi zvinoshandurwa zvinongedzo *hazvigone*!
    #[stable(feature = "rust1", since = "1.0.0")]
    impl<T: ?Sized> Copy for &T {}
}