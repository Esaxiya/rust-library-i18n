//! Nzira dzekugadzira `str` kubva kumabheti slice.

use crate::mem;

use super::validations::run_utf8_validation;
use super::Utf8Error;

/// Inoshandura chidimbu chemabheti kuita tambo chidimbu.
///
/// Tambo chidimbu ([`&str`]) chakagadzirwa nemabheti ([`u8`]), uye chidimbu chetete ([`&[u8]`][byteslice]) chakagadzirwa nematete, saka basa iri rinoshanduka pakati pezviviri.
/// Haasi ese mabheti zvidimbu anoshanda tambo zvidimbu, zvisinei: [`&str`] inoda kuti ive inoshanda UTF-8.
/// `from_utf8()` cheki kuona kuti mabheti anoshanda UTF-8, uyezve inoita shanduko.
///
/// [`&str`]: str
/// [byteslice]: slice
///
/// Kana iwe uine chokwadi chekuti chidimbu chebheti chiri kushanda UTF-8, uye iwe haudi kupinza pamusoro pechiratidzo chechokwadi, pane vhezheni isina kuchengetedzeka yeiri basa, [`from_utf8_unchecked`], ine hunhu hwakafanana asi inodarika cheki.
///
///
/// Kana iwe uchida `String` panzvimbo ye `&str`, funga [`String::from_utf8`][string].
///
/// [string]: ../../std/string/struct.String.html#method.from_utf8
///
/// Nekuti iwe unogona kukanda-kugovera `[u8; N]`, uye iwe unogona kutora [`&[u8]`][byteslice] yacho, iri basa ndiyo imwe nzira yekuve neyakagovaniswa-yakatemwa tambo.Pane muenzaniso weizvi muchikamu chemienzaniso pazasi.
///
/// [byteslice]: slice
///
/// # Errors
///
/// Inodzorera `Err` kana slice isiri UTF-8 ine tsananguro yekuti sei slice yakapihwa isiri UTF-8.
///
/// # Examples
///
/// Kushandiswa kwekutanga:
///
/// ```
/// use std::str;
///
/// // mamwe mabheti, mu vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// // Isu tinoziva aya mabheti anoshanda, saka ingoshandisa `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
/// Mabhete asiri iwo:
///
/// ```
/// use std::str;
///
/// // mamwe asiri mabheti, mu vector
/// let sparkle_heart = vec![0, 159, 146, 150];
///
/// assert!(str::from_utf8(&sparkle_heart).is_err());
/// ```
///
/// Ona maHTML e [`Utf8Error`] kuti uwane rumwe ruzivo pamusoro pemhando dzemhosho dzinogona kudzoserwa.
///
/// A "stack allocated string":
///
/// ```
/// use std::str;
///
/// // mamwe mabheti, mune yakakamurwa-yakapihwa array
/// let sparkle_heart = [240, 159, 146, 150];
///
/// // Isu tinoziva aya mabheti anoshanda, saka ingoshandisa `unwrap()`.
/// let sparkle_heart = str::from_utf8(&sparkle_heart).unwrap();
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
///
///
///
///
///
///
///
///
///
#[stable(feature = "rust1", since = "1.0.0")]
pub fn from_utf8(v: &[u8]) -> Result<&str, Utf8Error> {
    run_utf8_validation(v)?;
    // Kachengeteka: Kumhanya chete kusimbiswa.
    Ok(unsafe { from_utf8_unchecked(v) })
}

/// Inoshandura chidimbu chinoshanduka chemabheti kuita tambo inoshanduka.
///
/// # Examples
///
/// Kushandiswa kwekutanga:
///
/// ```
/// use std::str;
///
/// // "Hello, Rust!" seinoshanduka vector
/// let mut hellorust = vec![72, 101, 108, 108, 111, 44, 32, 82, 117, 115, 116, 33];
///
/// // Sezvo isu tichiziva aya mabheti ari kushanda, tinogona kushandisa `unwrap()`
/// let outstr = str::from_utf8_mut(&mut hellorust).unwrap();
///
/// assert_eq!("Hello, Rust!", outstr);
/// ```
///
/// Mabhete asiri iwo:
///
/// ```
/// use std::str;
///
/// // Dzimwe dzisingaite mabheti mune inoshanduka vector
/// let mut invalid = vec![128, 223];
///
/// assert!(str::from_utf8_mut(&mut invalid).is_err());
/// ```
/// Ona maHTML e [`Utf8Error`] kuti uwane rumwe ruzivo pamusoro pemhando dzemhosho dzinogona kudzoserwa.
///
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub fn from_utf8_mut(v: &mut [u8]) -> Result<&mut str, Utf8Error> {
    run_utf8_validation(v)?;
    // Kachengeteka: Kumhanya chete kusimbiswa.
    Ok(unsafe { from_utf8_unchecked_mut(v) })
}

/// Inoshandura chidimbu chemabheti kuita tambo slice pasina kutarisa kuti tambo yacho ine UTF-8 inoshanda.
///
/// Ona iyo yakachengeteka vhezheni, [`from_utf8`], kuti uwane rumwe ruzivo.
///
/// # Safety
///
/// Iri basa harina kuchengeteka nekuti haritarise kuti mabheti akapfuudzwa kwairi anoshanda UTF-8.
/// Kana kudzvinyirirwa uku kukatyorwa, maitiro asina kujekeswa mhedzisiro, seyasara ese e Rust anofungidzira kuti [`&str`] s ndeyechokwadi UTF-8.
///
///
/// [`&str`]: str
///
/// # Examples
///
/// Kushandiswa kwekutanga:
///
/// ```
/// use std::str;
///
/// // mamwe mabheti, mu vector
/// let sparkle_heart = vec![240, 159, 146, 150];
///
/// let sparkle_heart = unsafe {
///     str::from_utf8_unchecked(&sparkle_heart)
/// };
///
/// assert_eq!("💖", sparkle_heart);
/// ```
///
#[inline]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_const_unstable(feature = "const_str_from_utf8_unchecked", issue = "75196")]
#[rustc_allow_const_fn_unstable(const_fn_transmute)]
pub const unsafe fn from_utf8_unchecked(v: &[u8]) -> &str {
    // KUCHENGETEKA: iye anofona anofanira kuvimbisa kuti mabheti `v` anoshanda UTF-8.
    // Zvakare inovimba ne `&str` uye `&[u8]` iine mamiriro akafanana.
    unsafe { mem::transmute(v) }
}

/// Inoshandura chidimbu chemabheti kuita tambo slice pasina kutarisa kuti tambo yacho ine UTF-8 inoshanda here;chinoshandurwa vhezheni.
///
///
/// Ona iyo isingachinjiki vhezheni, [`from_utf8_unchecked()`] kuti uwane rumwe ruzivo.
///
/// # Examples
///
/// Kushandiswa kwekutanga:
///
/// ```
/// use std::str;
///
/// let mut heart = vec![240, 159, 146, 150];
/// let heart = unsafe { str::from_utf8_unchecked_mut(&mut heart) };
///
/// assert_eq!("💖", heart);
/// ```
#[inline]
#[stable(feature = "str_mut_extras", since = "1.20.0")]
pub unsafe fn from_utf8_unchecked_mut(v: &mut [u8]) -> &mut str {
    // Kachengeteka: iye anodana anofanira kuvimbisa kuti mabheti `v`
    // ndezvechokwadi UTF-8, saka iyo yakakandwa ku `*mut str` yakachengeteka.
    // Zvakare, iyo poreser dereferensi yakachengeteka nekuti iyo pointer inouya kubva kunongedzo iyo inovimbiswa kuve inoshanda kune yekunyora.
    //
    unsafe { &mut *(v as *mut [u8] as *mut str) }
}