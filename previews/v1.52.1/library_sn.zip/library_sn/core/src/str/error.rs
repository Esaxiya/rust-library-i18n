//! Inotsanangura utf8 yekukanganisa mhando.

use crate::fmt;

/// Zvikanganiso zvinogona kuitika kana uchiedza kududzira kuteedzana kwe [`u8`] kunge tambo.
///
/// Saka nekudaro, iyo `from_utf8` mhuri yemabasa uye nzira dzevose [`String`] s uye [`&str`] s vanoshandisa iko kukanganisa, semuenzaniso.
///
/// [`String`]: ../../std/string/struct.String.html#method.from_utf8
/// [`&str`]: super::from_utf8
///
/// # Examples
///
/// Iyi nzira yemhando yekukanganisa inogona kushandiswa kugadzira mashandiro akafanana ne `String::from_utf8_lossy` pasina kugovera murwi memory.
///
///
/// ```
/// fn from_utf8_lossy<F>(mut input: &[u8], mut push: F) where F: FnMut(&str) {
///     loop {
///         match std::str::from_utf8(input) {
///             Ok(valid) => {
///                 push(valid);
///                 break
///             }
///             Err(error) => {
///                 let (valid, after_valid) = input.split_at(error.valid_up_to());
///                 unsafe {
///                     push(std::str::from_utf8_unchecked(valid))
///                 }
///                 push("\u{FFFD}");
///
///                 if let Some(invalid_sequence_length) = error.error_len() {
///                     input = &after_valid[invalid_sequence_length..]
///                 } else {
///                     break
///                 }
///             }
///         }
///     }
/// }
/// ```
///
///
#[derive(Copy, Eq, PartialEq, Clone, Debug)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct Utf8Error {
    pub(super) valid_up_to: usize,
    pub(super) error_len: Option<u8>,
}

impl Utf8Error {
    /// Inodzorera iyo indekisi mune yakapihwa tambo kusvika kune chaiyo UTF-8 yakaverengerwa.
    ///
    /// Iyo ndiyo yakanyanya index index yekuti `from_utf8(&input[..index])` yaizodzoka `Ok(_)`.
    ///
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga:
    ///
    /// ```
    /// use std::str;
    ///
    /// // mamwe asiri mabheti, mu vector
    /// let sparkle_heart = vec![0, 159, 146, 150];
    ///
    /// // std::str::from_utf8 inodzosera Utf8Error
    /// let error = str::from_utf8(&sparkle_heart).unwrap_err();
    ///
    /// // yechipiri byte haishande pano
    /// assert_eq!(1, error.valid_up_to());
    /// ```
    ///
    #[stable(feature = "utf8_error", since = "1.5.0")]
    #[inline]
    pub fn valid_up_to(&self) -> usize {
        self.valid_up_to
    }

    /// Inopa rumwe ruzivo nezve kutadza:
    ///
    /// * `None`: kupera kwekupinza kwakasvikwa zvisingatarisirwi.
    ///   `self.valid_up_to()` iri 1 kusvika kumatatu mabheti kubva kumagumo ekupinza.
    ///   Kana rwizi rwe byte (rwakadai sefaira kana reti sokisi) riri kudomedzerwa zvakawedzera, iyi inogona kunge iri `char` inoshanda ine UTF-8 byte kuteedzana iri kutenderera akawanda machunks.
    ///
    ///
    /// * `Some(len)`: imwe isingatarisirwi yakasangana.
    ///   Kureba kwakapihwa ndekwekusaenderana kwekuteedzana kwette kunotanga pane indekisi yakapihwa ne `valid_up_to()`.
    ///   Kugadziriswa kunofanira kutangazve mushure meizvozvo kuteedzana (mushure mekuisa [`U+FFFD REPLACEMENT CHARACTER`][U+FFFD]) mune yekurasikirwa kwekumisikidza.
    ///
    /// [U+FFFD]: ../../std/char/constant.REPLACEMENT_CHARACTER.html
    ///
    ///
    ///
    #[stable(feature = "utf8_error_error_len", since = "1.20.0")]
    #[inline]
    pub fn error_len(&self) -> Option<usize> {
        self.error_len.map(|len| len as usize)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for Utf8Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        if let Some(error_len) = self.error_len {
            write!(
                f,
                "invalid utf-8 sequence of {} bytes from index {}",
                error_len, self.valid_up_to
            )
        } else {
            write!(f, "incomplete utf-8 byte sequence from index {}", self.valid_up_to)
        }
    }
}

/// Iko kukanganisa kwakadzorerwa pakudongorera `bool` uchishandisa [`from_str`] inokundikana
///
/// [`from_str`]: super::FromStr::from_str
#[derive(Debug, Clone, PartialEq, Eq)]
#[stable(feature = "rust1", since = "1.0.0")]
pub struct ParseBoolError {
    pub(super) _priv: (),
}

#[stable(feature = "rust1", since = "1.0.0")]
impl fmt::Display for ParseBoolError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        "provided string was not `true` or `false`".fmt(f)
    }
}