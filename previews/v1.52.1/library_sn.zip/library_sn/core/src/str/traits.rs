//! Trait kuitiswa kwe `str`.

use crate::cmp::Ordering;
use crate::ops;
use crate::ptr;
use crate::slice::SliceIndex;

use super::ParseBoolError;

/// Inoshandisa kurongedza tambo.
///
/// Tambo dzakarairwa [lexicographically](Ord#lexicographical-comparison) nemitengo yadzo.
/// Izvi zvinoraira Unicode kodhi kodhi zvinoenderana nenzvimbo dzadzo mumakodhi machati.
/// Izvi hazvisi chaizvo zvakafanana ne "alphabetical" odha, iyo inosiyana nemutauro nenzvimbo.
/// Kurongedza tambo zvinoenderana neyetsika-inogamuchirwa zviyero zvinoda locale-yakatarwa dhata iri kunze kwenzvimbo ye `str` mhando.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl Ord for str {
    #[inline]
    fn cmp(&self, other: &str) -> Ordering {
        self.as_bytes().cmp(other.as_bytes())
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl PartialEq for str {
    #[inline]
    fn eq(&self, other: &str) -> bool {
        self.as_bytes() == other.as_bytes()
    }
    #[inline]
    fn ne(&self, other: &str) -> bool {
        !(*self).eq(other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl Eq for str {}

/// Inoshandisa kuenzanisa mashandiro patambo.
///
/// Tambo dzinoenzaniswa [lexicographically](Ord#lexicographical-comparison) nemitengo yadzo.
/// Izvi zvinofananidza Unicode kodhi kodhi zvinoenderana nenzvimbo dzadzo mumakodhi machati.
/// Izvi hazvisi chaizvo zvakafanana ne "alphabetical" odha, iyo inosiyana nemutauro nenzvimbo.
/// Kufananidza tambo zvinoenderana neyetsika-inogamuchirwa zviyero zvinoda locale-yakatarwa dhata iri kunze kwenzvimbo ye `str` mhando.
///
#[stable(feature = "rust1", since = "1.0.0")]
impl PartialOrd for str {
    #[inline]
    fn partial_cmp(&self, other: &str) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::Index<I> for str
where
    I: SliceIndex<str>,
{
    type Output = I::Output;

    #[inline]
    fn index(&self, index: I) -> &I::Output {
        index.index(self)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<I> ops::IndexMut<I> for str
where
    I: SliceIndex<str>,
{
    #[inline]
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        index.index_mut(self)
    }
}

#[inline(never)]
#[cold]
#[track_caller]
fn str_index_overflow_fail() -> ! {
    panic!("attempted to index str up to maximum usize");
}

/// Inoshandisa substring slicing ne syntax `&self[..]` kana `&mut self[..]`.
///
/// Inodzosera chidimbu chetambo yese, kureva, inodzosera `&self` kana `&mut self`.Zvakaenzana ne`&self [0 ..
/// len] `kana`&mut self [0 ..
/// len]`.
/// Kusiyana nemamwe mabasa ekunongedza, izvi hazvimbofa zvakaita panic.
///
/// Uku kuvhiya ndiko *O*(1).
///
/// 1.20.0 isati yasvika, aya mabasa ekunyora akange achiri kutsigirwa nekumisikidzwa kwakananga kwe `Index` ne `IndexMut`.
///
/// Zvakaenzana ne `&self[0 .. len]` kana `&mut self[0 .. len]`.
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFull {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        Some(slice)
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        Some(slice)
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        slice
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        slice
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        slice
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        slice
    }
}

/// Inoshandisa substring slicing ne syntax `&self[begin .. end]` kana `&mut self[begin .. end]`.
///
/// Inodzorera chimedu chetambo yakapihwa kubva pa byte renji [`kutanga`, `end`).
///
/// Uku kuvhiya ndiko *O*(1).
///
/// 1.20.0 isati yasvika, aya mabasa ekunyora akange achiri kutsigirwa nekumisikidzwa kwakananga kwe `Index` ne `IndexMut`.
///
/// # Panics
///
/// Panics kana `begin` kana `end` isinganongedze kutanga kwekutanga kwechimiro (sekutsanangurwa ne `is_char_boundary`), kana `begin > end`, kana kana `end > len`.
///
///
/// # Examples
///
/// ```
/// let s = "Löwe 老虎 Léopard";
/// assert_eq!(&s[0 .. 1], "L");
///
/// assert_eq!(&s[1 .. 9], "öwe 老");
///
/// // izvi zvichaita panic:
/// // byte 2 nhema mukati me `ö`:
/// // &s [2 ..3];
///
/// // byte 8 nhema mukati me `老`&s [1 ..
/// // 8];
///
/// // byte 100 iri kunze kwetambo&s [3 ..
/// // 100];
/// ```
///
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::Range<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SAFETY: ingo tarisa kuti `start` uye `end` vari pamuganhu wemoto,
            // uye isu tiri kupfuura mune yakachengeteka referensi, saka iyo yekudzorera kukosha ichave imwechete.
            // Takatarisawo char char, saka ichi chinoshanda UTF-8.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SAFETY: ingo tarisa kuti `start` uye `end` vari pamuganhu wemadiro.
            // Isu tinoziva pointer yakasarudzika nekuti takaiwana kubva ku `slice`.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // KUCHENGETEKA: iye anodana anovimbisa kuti `self` iri mumiganhu ye `slice`
        // iyo inogutsa ese mamiriro e `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // Kachengeteka: ona zvirevo zve `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = self.end - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, self.end);
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        // is_char_boundary inotarisa kuti iyo index iri mu [0, .len()] haigone kushandisa `get` sezviri pamusoro, nekuda kwedambudziko reNLL
        //
        if self.start <= self.end
            && slice.is_char_boundary(self.start)
            && slice.is_char_boundary(self.end)
        {
            // SAFETY: ingo tarisa kuti `start` uye `end` vari pamuganhu wemoto,
            // uye isu tiri kupfuura mune yakachengeteka referensi, saka iyo yekudzorera kukosha ichave imwechete.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, self.end)
        }
    }
}

/// Inoshandisa substring slicing ne syntax `&self[.. end]` kana `&mut self[.. end]`.
///
/// Inodzorera chimedu chetambo yakapihwa kubva pa byte renji [`0`, `end`).
/// Zvakaenzana ne `&self[0 .. end]` kana `&mut self[0 .. end]`.
///
/// Uku kuvhiya ndiko *O*(1).
///
/// 1.20.0 isati yasvika, aya mabasa ekunyora akange achiri kutsigirwa nekumisikidzwa kwakananga kwe `Index` ne `IndexMut`.
///
/// # Panics
///
/// Panics kana `end` isinganongedze kutanga kwekutanga kwechimiro (sekutsanangurwa ne `is_char_boundary`), kana kana `end > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeTo<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.end) {
            // KUCHENGETEKA: ingo tarisa kuti `end` iri pamuganhu we char,
            // uye isu tiri kupfuura mune yakachengeteka referensi, saka iyo yekudzorera kukosha ichave imwechete.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.end) {
            // KUCHENGETEKA: ingo tarisa kuti `end` iri pamuganhu we char,
            // uye isu tiri kupfuura mune yakachengeteka referensi, saka iyo yekudzorera kukosha ichave imwechete.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        let ptr = slice.as_ptr();
        ptr::slice_from_raw_parts(ptr, self.end) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        let ptr = slice.as_mut_ptr();
        ptr::slice_from_raw_parts_mut(ptr, self.end) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let end = self.end;
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, 0, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.end) {
            // KUCHENGETEKA: ingo tarisa kuti `end` iri pamuganhu we char,
            // uye isu tiri kupfuura mune yakachengeteka referensi, saka iyo yekudzorera kukosha ichave imwechete.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, 0, self.end)
        }
    }
}

/// Inoshandisa substring slicing ne syntax `&self[begin ..]` kana `&mut self[begin ..]`.
///
/// Inodzorera chimedu chetambo yakapihwa kubva pa byte renji [`kutanga`, `len`).Zvakaenzana ne`&self [tanga ..
/// len] `kana`&mut self [tanga ..
/// len]`.
///
/// Uku kuvhiya ndiko *O*(1).
///
/// 1.20.0 isati yasvika, aya mabasa ekunyora akange achiri kutsigirwa nekumisikidzwa kwakananga kwe `Index` ne `IndexMut`.
///
/// # Panics
///
/// Panics kana `begin` isinganongedze kutanga kwekutanga kwechimiro (sekutsanangurwa ne `is_char_boundary`), kana kana `begin > len`.
///
///
///
#[stable(feature = "str_checked_slicing", since = "1.20.0")]
unsafe impl SliceIndex<str> for ops::RangeFrom<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if slice.is_char_boundary(self.start) {
            // KUCHENGETEKA: ingo tarisa kuti `start` iri pamuganhu we char,
            // uye isu tiri kupfuura mune yakachengeteka referensi, saka iyo yekudzorera kukosha ichave imwechete.
            Some(unsafe { &*self.get_unchecked(slice) })
        } else {
            None
        }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if slice.is_char_boundary(self.start) {
            // KUCHENGETEKA: ingo tarisa kuti `start` iri pamuganhu we char,
            // uye isu tiri kupfuura mune yakachengeteka referensi, saka iyo yekudzorera kukosha ichave imwechete.
            Some(unsafe { &mut *self.get_unchecked_mut(slice) })
        } else {
            None
        }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        let slice = slice as *const [u8];
        // KUCHENGETEKA: iye anodana anovimbisa kuti `self` iri mumiganhu ye `slice`
        // iyo inogutsa ese mamiriro e `add`.
        let ptr = unsafe { slice.as_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts(ptr, len) as *const str
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        let slice = slice as *mut [u8];
        // Kachengeteka: yakafanana ne `get_unchecked`.
        let ptr = unsafe { slice.as_mut_ptr().add(self.start) };
        let len = slice.len() - self.start;
        ptr::slice_from_raw_parts_mut(ptr, len) as *mut str
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        let (start, end) = (self.start, slice.len());
        match self.get(slice) {
            Some(s) => s,
            None => super::slice_error_fail(slice, start, end),
        }
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if slice.is_char_boundary(self.start) {
            // KUCHENGETEKA: ingo tarisa kuti `start` iri pamuganhu we char,
            // uye isu tiri kupfuura mune yakachengeteka referensi, saka iyo yekudzorera kukosha ichave imwechete.
            unsafe { &mut *self.get_unchecked_mut(slice) }
        } else {
            super::slice_error_fail(slice, self.start, slice.len())
        }
    }
}

/// Inoshandisa substring slicing ne syntax `&self[begin ..= end]` kana `&mut self[begin ..= end]`.
///
/// Inodzorera chidimbu chetambo yakapihwa kubva pa byte renji [`begin`, `end`].Zvakaenzana ne `&self [begin .. end + 1]` kana `&mut self[begin .. end + 1]`, kunze kwekunge `end` iine kukosha kwakanyanya kwe `usize`.
///
/// Uku kuvhiya ndiko *O*(1).
///
/// # Panics
///
/// Panics kana `begin` isinganongedze kutanga kwekutanga kwechimiro (sekutsanangurwa ne `is_char_boundary`), kana `end` isinganongedze kumhedzisiro yehunhu hwechimiro (`end + 1` ingangove yekutanga byte offset kana yakaenzana ne `len`), kana `begin > end`, kana kana `end >= len`.
///
///
///
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if *self.end() == usize::MAX { None } else { self.into_slice_range().get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // KUCHENGETEKA: iye anodana anofanirwa kuchengetedza chibvumirano chekuchengetedza che `get_unchecked`.
        unsafe { self.into_slice_range().get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // KUCHENGETEKA: iye anodana anofanirwa kuchengetedza chibvumirano chekuchengetedza che `get_unchecked_mut`.
        unsafe { self.into_slice_range().get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if *self.end() == usize::MAX {
            str_index_overflow_fail();
        }
        self.into_slice_range().index_mut(slice)
    }
}

/// Inoshandisa substring slicing ne syntax `&self[..= end]` kana `&mut self[..= end]`.
///
/// Inodzorera chidimbu chetambo yakapihwa kubva pa byte renji [0, `end`].
/// Yakaenzana ne `&self [0 .. end + 1]`, kunze kwekunge `end` ine yakanyanya kukosha ye `usize`.
///
/// Uku kuvhiya ndiko *O*(1).
///
/// # Panics
///
/// Panics kana `end` isinganongedze kumagumo byte yehunhu (`end + 1` ingave yekutanga byte offset sekutsanangurwa ne `is_char_boundary`, kana yakaenzana ne `len`), kana kana `end >= len`.
///
///
///
///
#[stable(feature = "inclusive_range", since = "1.26.0")]
unsafe impl SliceIndex<str> for ops::RangeToInclusive<usize> {
    type Output = str;
    #[inline]
    fn get(self, slice: &str) -> Option<&Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get(slice) }
    }
    #[inline]
    fn get_mut(self, slice: &mut str) -> Option<&mut Self::Output> {
        if self.end == usize::MAX { None } else { (..self.end + 1).get_mut(slice) }
    }
    #[inline]
    unsafe fn get_unchecked(self, slice: *const str) -> *const Self::Output {
        // KUCHENGETEKA: iye anodana anofanirwa kuchengetedza chibvumirano chekuchengetedza che `get_unchecked`.
        unsafe { (..self.end + 1).get_unchecked(slice) }
    }
    #[inline]
    unsafe fn get_unchecked_mut(self, slice: *mut str) -> *mut Self::Output {
        // KUCHENGETEKA: iye anodana anofanirwa kuchengetedza chibvumirano chekuchengetedza che `get_unchecked_mut`.
        unsafe { (..self.end + 1).get_unchecked_mut(slice) }
    }
    #[inline]
    fn index(self, slice: &str) -> &Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index(slice)
    }
    #[inline]
    fn index_mut(self, slice: &mut str) -> &mut Self::Output {
        if self.end == usize::MAX {
            str_index_overflow_fail();
        }
        (..self.end + 1).index_mut(slice)
    }
}

/// Paridza kukosha kubva patambo
///
/// Kubva kuStr's's [`from_str`] nzira inowanzo shandiswa zvisingaiti, kuburikidza ne [`str`] 's [`parse`] nzira.
/// Ona [`parse`] 'zvinyorwa zvemienzaniso.
///
/// [`from_str`]: FromStr::from_str
/// [`parse`]: str::parse
///
/// `FromStr` haina paramende yeupenyu hwese, uye nekudaro iwe unogona chete kuenzanisa mhando dzisina iyo yehupenyu paramende ivo pachavo.
///
/// Mune mamwe mazwi, unogona kuenzanisa `i32` ne `FromStr`, asi kwete `&i32`.
/// Unogona kuenzanisa chimiro chine `i32`, asi kwete iyo iine `&i32`.
///
/// # Examples
///
/// Kwekutanga kuitiswa kwe `FromStr` pane muenzaniso `Point` mhando:
///
/// ```
/// use std::str::FromStr;
/// use std::num::ParseIntError;
///
/// #[derive(Debug, PartialEq)]
/// struct Point {
///     x: i32,
///     y: i32
/// }
///
/// impl FromStr for Point {
///     type Err = ParseIntError;
///
///     fn from_str(s: &str) -> Result<Self, Self::Err> {
///         let coords: Vec<&str> = s.trim_matches(|p| p == '(' || p == ')' )
///                                  .split(',')
///                                  .collect();
///
///         let x_fromstr = coords[0].parse::<i32>()?;
///         let y_fromstr = coords[1].parse::<i32>()?;
///
///         Ok(Point { x: x_fromstr, y: y_fromstr })
///     }
/// }
///
/// let p = Point::from_str("(1,2)");
/// assert_eq!(p.unwrap(), Point{ x: 1, y: 2} )
/// ```
#[stable(feature = "rust1", since = "1.0.0")]
pub trait FromStr: Sized {
    /// Iko kukanganisa kwakabatana uko kunogona kudzoserwa kubva paring.
    #[stable(feature = "rust1", since = "1.0.0")]
    type Err;

    /// Anodzora tambo `s` kudzorera kukosha kwerudzi urwu.
    ///
    /// Kana kukanganisa kukabudirira, dzosera kukosha mukati me [`Ok`], zvikasadaro kana tambo isina kurongeka-yakadzoserwa kukanganisa kwakanangana neiyo mukati [`Err`].
    /// Rudzi rwekukanganisa rwakananga kuitiswa kwe trait.
    ///
    /// # Examples
    ///
    /// Kushandiswa kwekutanga ne [`i32`], mhando inoshandisa `FromStr`:
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// let s = "5";
    /// let x = i32::from_str(s).unwrap();
    ///
    /// assert_eq!(5, x);
    /// ```
    ///
    #[stable(feature = "rust1", since = "1.0.0")]
    fn from_str(s: &str) -> Result<Self, Self::Err>;
}

#[stable(feature = "rust1", since = "1.0.0")]
impl FromStr for bool {
    type Err = ParseBoolError;

    /// Parisa `bool` kubva patambo.
    ///
    /// Inoburitsa `Result<bool, ParseBoolError>`, nekuti `s` inogona kana inogona kusatombooneka.
    ///
    ///
    /// # Examples
    ///
    /// ```
    /// use std::str::FromStr;
    ///
    /// assert_eq!(FromStr::from_str("true"), Ok(true));
    /// assert_eq!(FromStr::from_str("false"), Ok(false));
    /// assert!(<bool as FromStr>::from_str("not even a boolean").is_err());
    /// ```
    ///
    /// Tarira, muzviitiko zvakawanda, iyo `.parse()` nzira pa `str` yakanyanyisa.
    ///
    /// ```
    /// assert_eq!("true".parse(), Ok(true));
    /// assert_eq!("false".parse(), Ok(false));
    /// assert!("not even a boolean".parse::<bool>().is_err());
    /// ```
    #[inline]
    fn from_str(s: &str) -> Result<bool, ParseBoolError> {
        match s {
            "true" => Ok(true),
            "false" => Ok(false),
            _ => Err(ParseBoolError { _priv: () }),
        }
    }
}